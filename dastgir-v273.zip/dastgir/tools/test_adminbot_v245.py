#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v245: the model said «دسترسی به کد ندارم» even though it HAS the tools.

Root cause: the prompt's intro said «تغییر همهٔ محتوا» — content-only framing
a weak brain latches onto. Fix #1: the intro now says code is first-class.
Fix #2: a server-side refusal interceptor — if a final answer looks like
«I can't touch the code», the agent loop pushes back ONCE with the truth
and takes the retry.
"""
import os, sys, json, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v245-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
SCRIPT, CALLS = [], []
def fake_chat(*a, **k):
    CALLS.append(1)
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]
yes = lambda: t('بله')
def P(tool, args):
    return json.dumps({"reply": "ok", "tool": {"name": tool, "args": args}},
                      ensure_ascii=False)

# ================= 1. the prompt no longer frames content-only
P_ = AI.ADMIN_PROMPT
ck('به کل سایت دسترسی داری' in P_ and 'کد سایت' in P_[:400],
   'intro states full-site access in the first lines')
ck('محتوا + کدِ کل سایت' in P_, 'tools header covers content AND code')
ck('مطلقاً نادرست است' in P_, 'explicit anti-refusal line for code')
ck('code_search' in P_ and 'code_edit' in P_, 'code tools documented')
ck('تغییر همهٔ محتوا در اختیار' not in P_, 'stale content-only phrase gone')

# ================= 2. refusal detector unit checks
ck(AI._looks_like_refusal('متأسفانه من به کد سایت دسترسی ندارم'),
   'classic refusal detected')
ck(AI._looks_like_refusal('نمی‌توانم کد را تغییر بدهم'), 'cannot-change detected')
ck(AI._looks_like_refusal('این فقط محتواست، به پنل بروید'), 'panel-redirect detected')
ck(not AI._looks_like_refusal('بله، فایل را خواندم و خط ۱۲ را پیدا کردم'),
   'normal answer not flagged')
ck(not AI._looks_like_refusal(''), 'empty not flagged')

# ================= 3. refusal → server pushes back once → model complies
CALLS.clear(); SCRIPT.clear()
SCRIPT.append(json.dumps({"reply": "متأسفانه من دسترسی به کد سایت ندارم و نمی‌توانم تغییر بدهم.",
                          "tool": None}, ensure_ascii=False))
SCRIPT.append(P('code_search', {"query": "دکمهٔ خرید"}))
r = t('دکمهٔ خرید را سبز کن')
# v246: the autopilot adds one mini-edit call after the bare final answer
# v246: model lane 3 calls (refusal, search, final) + autopilot mini ×2
ck(len(CALLS) == 5, 'refusal → retry → search → final (+ 2 autopilot tries)')
ck('🔍' in r and 'دکمهٔ خرید' in r, 'retry produced the real search result')
ck('دسترسی ندارم' not in r, 'the refusal text never reaches the owner')

# refusal → retry → edit proposal lands on the «بله» wall
CALLS.clear(); SCRIPT.clear()
_heading = next(ln for ln in (ROOT / 'README.md').read_text(encoding='utf-8').split('\n')
                if ln.startswith('# '))
SCRIPT.append(json.dumps({"reply": "من فقط دستیار محتوایی هستم؛ به کد دسترسی ندارم.",
                          "tool": None}, ensure_ascii=False))
SCRIPT.append(json.dumps({"reply": "باشه، انجام می‌دهم.",
                          "tool": {"name": "code_edit",
                                   "args": {"path": "README.md",
                                            "edits": [{"old": _heading,
                                                       "new": _heading + " (تست)"}],
                                            "summary": "تست"}}}, ensure_ascii=False))
r = t('یه چیزی در کد عوض کن')
ck(len(CALLS) == 2 and '🛠 تغییر کد به صف استقرار رفت' in r, 'v268: retried edit executes at once')
yes()
ck(db._one("SELECT COUNT(*) c FROM audit WHERE action='admin_ai_tool'"
           " AND detail LIKE 'code_edit README.md%'")['c'] >= 1,
   'the retried edit executed for real')

# ================= 4. stubborn refusal passes through after ONE retry (no loop)
CALLS.clear(); SCRIPT.clear()
SCRIPT.append(json.dumps({"reply": "باز هم می‌گویم: به کد سایت دسترسی ندارم.",
                          "tool": None}, ensure_ascii=False))
SCRIPT.append(json.dumps({"reply": "نه، واقعاً نمی‌توانم کد را عوض کنم.",
                          "tool": None}, ensure_ascii=False))
r = t('همین را عوض کن')
ck(len(CALLS) == 2, 'exactly one retry even for a stubborn model')
ck('نمی‌توانم' in r or 'نتیجه' in r, 'final answer returned (no hang)')

# ================= 5. normal answers are NOT retried
CALLS.clear(); SCRIPT.clear()
SCRIPT.append(json.dumps({"reply": "سایت ۱۲ کسب‌وکار دارد.", "tool": None},
                         ensure_ascii=False))
r = t('چند کسب‌وکار داریم؟')
ck(len(CALLS) == 1, 'a plain answer costs exactly one model call')
ck('۱۲' in r, 'plain answer delivered as-is')

# tool proposal on the first try → no retry either
CALLS.clear(); SCRIPT.clear()
SCRIPT.append(P('code_list', {"path": ""}))
r = t('فایل‌ها را نشان بده')
ck(len(CALLS) == 2, 'immediate tool on first try — no refusal retry')

print(f'v245 refusal-proof copilot: {n} checks green')
