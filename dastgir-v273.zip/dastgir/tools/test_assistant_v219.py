#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v219 «سهمیهٔ عادلانه + مسیریابی مدل قوی» — offline tests with a fake model.

Fair quota: rule answers are free and unlimited; the 5/20/50 quota and the
daily cap gate MODEL-written answers only. An exhausted model budget degrades
to rules (flagged) instead of erroring. Smart routing: long (>150 chars) or
multi-turn (4+ messages) questions use AI_MODEL_SMART; the rest use the cheap
model. No network: assistant._chat is replaced by a stub.
"""
import os, sys, tempfile, json, subprocess
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v219-')
os.environ['BZ_DATA_DIR'] = TMP
for k in ('AI_BASE_URL', 'AI_API_KEY', 'AI_MODEL', 'AI_MODEL_SMART', 'AI_FALLBACK_BASE_URL', 'AI_FALLBACK_API_KEY', 'AI_FALLBACK_MODEL'):
    os.environ.pop(k, None)
sys.path.insert(0, str(ROOT / 'server'))
import db, assistant as A
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
ctx = lambda key, **kw: dict({"channel": "web", "user_key": key, "customer": None, "owner": None}, **kw)

# ---- 1. rule answers are free and unlimited (no model key at all)
for i, t in enumerate(["کافه", "ورود", "تعرفه", "نزدیک من", "ثبت مغازه", "کافه", "ورود", "تعرفه"]):
    r = A.answer(t, ctx("free1"))
    assert r["ok"] and r["source"] == "rule", t
ck(True, '8 rule answers, all ok, no quota wall')
ck(A.usage_today("free1") == 8 and A.quota_used_today("free1") == 0, 'messages counted in n, model quota untouched')
ck(A.remaining("free1", "free") == 5 and r["degraded"] == "", 'remaining full, nothing degraded')

# v259 (دستور مدیر: «توکن فقط برای پنل کاربری و مدیرتیم»): مهمان به‌طور
# پیش‌فرض مدل صدا نمی‌زند؛ این سوئیت معنای سهمیه/سقف/مسیریابی را می‌سنجد پس
# سوییچ مدلِ مهمان را لحظه‌ای روشن می‌کند (رفتار پیش‌فرضِ خاموش در v259 قفل است).
db.set_settings({"ai_guest_model": "1"})

# ---- 2. model answers consume quota; exhaustion degrades gracefully
calls = []
def fake_chat(base, key, model, messages, timeout, max_tokens=220):
    calls.append(model)
    ans = {"answer": "پاسخ مدل تستی.", "links": [{"label": "جست‌وجو", "href": "/businesses"}],
           "scope": True, "intent": "search"}
    return json.dumps(ans, ensure_ascii=False), 100
A._chat = fake_chat
os.environ.update(AI_BASE_URL="https://api.example.invalid/v1", AI_API_KEY="test-key-not-real",
                  AI_MODEL="fake-lite")
# v269 (دستور مدیر: هوش سایت جدا از محیط مدیر): چت کاربران از
# اسلات مستقل AI_SITE_* می‌خواند.
os.environ.update(AI_SITE_BASE_URL="https://site.example.invalid/v1",
                  AI_SITE_API_KEY="test-site-key-not-real",
                  AI_SITE_MODEL="site-model")
for t in ["کافه", "رستوران", "داروخانه", "کتابفروشی", "آرایشگاه"]:
    r = A.answer(t, ctx("paid1"))
ck(r["ok"] and r["source"] == "llm" and r["model"] == "fast", 'configured → model writes, routed to cheap (fast)')
ck(A.quota_used_today("paid1") == 5 and A.remaining("paid1", "free") == 0, '5 model answers consume the free quota')
ck(len(calls) == 5, 'exactly one provider call per model answer')
r = A.answer("نانوایی", ctx("paid1"))
ck(r["ok"] and r["source"] == "rule" and r["degraded"] == "quota", 'quota out → rule answer, flagged quota (no error)')
ck(A.quota_used_today("paid1") == 5 and len(calls) == 5, 'degraded answer costs no quota and no provider call')
r = A.answer("این چیز دقیقاً چیست؟", ctx("paid1"))
ck(r["ok"] and r["source"] == "rule-fallback" and r["degraded"] == "quota", 'unknown + quota out → rule fallback, flagged')
r = A.answer("کافه", ctx("paid1"))
ck(r["source"] == "cache" and r["degraded"] == "" and len(calls) == 5, 'v220: cached answer served free despite exhausted quota')
ck("test-key-not-real" not in json.dumps(r), 'key never leaks into the answer payload')

# ---- 3. v269 (دستور مدیر: هوش سایت جدا و تک‌مدل): چت کاربران همیشه روی
# تک‌مدل سایت می‌رود؛ AI_MODEL_SMART فقط در محیط مدیر معنا دارد.
os.environ["AI_MODEL_SMART"] = "fake-smart"
db.set_settings({"ai_quota_free": "100"})
long_q = "لطفاً با جزئیات کامل توضیح بده که " + "چطور بهترین مغازه را پیدا کنم؟ " * 8
assert len(long_q) > 150
r = A.answer(long_q, ctx("smart1"))
ck(r["source"] == "llm" and r["model"] == "fast" and calls[-1] == "site-model", 'long question stays on the single site model (v269)')
hist = [{"role": "user", "text": "سلام"}, {"role": "assistant", "text": "سلام!"},
        {"role": "user", "text": "کافه"}, {"role": "assistant", "text": "باشه"}]
r = A.answer("کافه", ctx("smart1"), hist)
ck(r["model"] == "fast" and calls[-1] == "site-model", 'multi-turn follow-up stays on the site model (v269)')
r = A.answer("چایخانه", ctx("smart1"))   # v220: fresh text, "کافه" is cached by §2
ck(r["model"] == "fast" and calls[-1] == "site-model", 'short question stays on the site model (v269)')
ck(A.needs_smart("x" * 150) is False and A.needs_smart("x" * 151) is True, 'length boundary at 150 chars')
ck(A.needs_smart("کافه", hist[:3]) is False and A.needs_smart("کافه", hist) is True, 'turn boundary at 4 messages')
ck(A.stats()["month"]["smart"] == 0, 'v269: the user side never burns a smart tier')
os.environ.pop("AI_MODEL_SMART")
long_q2 = "برای جشن تولد فرزندم " + "کدام قنادی سفارش آنلاین دارد؟ " * 8
assert len(long_q2) > 150
r = A.answer(long_q2, ctx("smart1"))   # v220: long_q is cached; a new long text still reaches the model
ck(r["source"] == "llm" and r["model"] == "fast" and calls[-1] == "site-model", 'long question still on the single site model')
db.set_settings({"ai_quota_free": "5"})

# ---- 4. the global cap gates the model only
db.set_settings({"ai_daily_cap": "0"})
r = A.answer("گل‌فروشی", ctx("cap1"))   # v220: fresh texts — §2 words are cached
ck(r["ok"] and r["source"] == "rule" and r["degraded"] == "cap", 'rules served under a zero cap, state flagged')
r = A.answer("آن شیء دقیقاً چیست؟", ctx("cap1"))
ck(r["ok"] and r["degraded"] == "cap" and r["source"] == "rule-fallback", 'cap out → graceful fallback, flagged cap')
db.set_settings({"ai_daily_cap": "2000"})
r = A.answer("گل‌فروشی", ctx("cap1"))
ck(r["source"] == "llm" and r["degraded"] == "", 'cap restored → model answers again')
db.set_settings({"ai_guest_model": "0"})   # v259: سوییچ برمی‌گردد به پیش‌فرض خاموش

# ---- 5. admin switch and empty text behave as before
db.set_settings({"ai_enabled": "0"})
ck(A.answer("کافه", ctx("off1"))["error"] == "disabled", 'admin switch still disables everything')
db.set_settings({"ai_enabled": "1"})
ck(A.answer("   ", ctx("off1"))["error"] == "empty", 'empty text rejected')
ck(A.usage_today("off1") == 0, 'empty text counted nowhere')

# ---- 6. pre-v219 databases gain the new columns automatically
TMP2 = tempfile.mkdtemp(prefix='ai-v219-legacy-')
LEGACY = (
    "import os, sys; os.environ['BZ_DATA_DIR'] = sys.argv[1]; "
    "sys.path.insert(0, sys.argv[2]); import db; "
    "con = db.connect(); "
    "con.execute(\"CREATE TABLE ai_usage(day TEXT,user_key TEXT,channel TEXT,n INTEGER,llm_calls INTEGER,tokens INTEGER,PRIMARY KEY(day,user_key))\"); "
    "con.execute(\"INSERT INTO ai_usage VALUES('2026-01-01','olduser','web',7,3,100)\"); "
    "con.commit(); con.close(); db.init(); "
    "cols = {r[1] for r in db.connect().execute('PRAGMA table_info(ai_usage)')}; "
    "assert {'q', 'smart_calls'} <= cols, cols; "
    "rw = db._one('SELECT n, q, smart_calls FROM ai_usage'); "
    "assert (rw['n'], rw['q'], rw['smart_calls']) == (7, 0, 0), dict(rw); "
    "print('migration OK')"
)
p = subprocess.run([sys.executable, "-c", LEGACY, TMP2, str(ROOT / "server")],
                   capture_output=True, text=True, timeout=120)
ck(p.returncode == 0 and "migration OK" in p.stdout, 'legacy ai_usage auto-gains q + smart_calls, rows kept' + ("" if p.returncode == 0 else f" [{p.stderr[-300:]}]"))

# ---- 7. bot footer and panel show the smart-quota wording + smart stats
sent = []
A.bot_reply("bale", "u7", "70", "کافه", lambda c, t, m=None: sent.append(t))
ck(sent and "پاسخ هوشمند دیگر امروز" in sent[0], 'bot footer shows remaining smart answers')
import views_panel2 as P
html = P.assistant_page(db.get_settings(), "tok", {})
ck("پاسخ مدل قوی ۳۰ روز" in html, 'panel shows the smart-model stat card')
ck("همیشه رایگان و نامحدود" in html, 'panel quota note explains free rules')

print(f"v219: {n} checks passed")
