#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v221 «رشته‌های ماندگار گفت‌وگو» — offline tests with a fake model.

Bots and signed-in web keep a server-side thread (ai_threads) that survives
restarts and wins over client-supplied history; linked speakers share one
thread across web + bots. Guests are never persisted. Threads: 10-minute
TTL (v270 دستور مدیر — was 48h), 20 msgs/thread, prompts see the last 6,
wiped with the account, never backed up. No network: assistant._chat is
replaced by a stub.
"""
import os, sys, tempfile, json, subprocess, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v221-')
os.environ['BZ_DATA_DIR'] = TMP
for k in ('AI_BASE_URL', 'AI_API_KEY', 'AI_MODEL', 'AI_MODEL_SMART', 'AI_FALLBACK_BASE_URL', 'AI_FALLBACK_API_KEY', 'AI_FALLBACK_MODEL'):
    os.environ.pop(k, None)
sys.path.insert(0, str(ROOT / 'server'))
import db, assistant as A
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
ctx = lambda key, **kw: dict({"channel": "web", "user_key": key, "customer": None, "owner": None}, **kw)
bctx = lambda key, cust=None: dict({"channel": "bale", "user_key": key, "customer": cust, "owner": None})

# ---- 1. thread layer: keys, window, cap, clip, TTL
ck(A.thread_key(ctx("ip:1.2.3.4")) is None, 'guests get no thread key')
ck(A.thread_key(ctx("cust:9", customer={"id": 9})) == "cust:9", 'signed-in web keyed by account')
ck(A.thread_key(bctx("bale:77")) == "bale:77", 'unlinked bot user keyed by platform id')
ck(A.thread_key(bctx("cust:9", {"id": 9})) == "cust:9", 'linked bot user shares the account thread')
A.thread_append("t1", "سلام", "درود بر شما")
ck(A.thread_get("t1") == [{"role": "user", "text": "سلام"}, {"role": "assistant", "text": "درود بر شما"}],
   'append/get roundtrip, oldest-first')
for i in range(5):
    A.thread_append("t1", f"u{i}", f"a{i}")
ck(len(A.thread_get("t1")) == 6 and len(A.thread_get("t1", limit=20)) == 12, 'prompt window 6, full read on demand')
for i in range(15):
    A.thread_append("tcap", f"u{i}", f"a{i}")
ck(db._one("SELECT COUNT(*) c FROM ai_threads WHERE tkey='tcap'")["c"] == 20, 'per-thread cap 20, oldest evicted')
A.thread_append("tclip", "x" * 500, "y" * 1500)
row = db._rows("SELECT text FROM ai_threads WHERE tkey='tclip' ORDER BY id")
ck(len(row[0]["text"]) == 400 and len(row[1]["text"]) == 1200, 'stored text clipped (400/1200)')
con = db.connect()
con.execute("INSERT INTO ai_threads(tkey,role,text,created) VALUES('told','user','پیر',1)")
con.commit(); con.close()
ck(A.thread_get("told") == [], 'expired rows invisible')
A.thread_append("told", "تازه", "نو")
ck(db._one("SELECT COUNT(*) c FROM ai_threads WHERE text='پیر'")["c"] == 0, 'append prunes expired rows')
ck(A.threads_active() >= 3, 'active-thread counter works')
A.threads_forget("t1")
ck(A.thread_get("t1") == [], 'explicit forget wipes one thread')

# ---- 2. signed-in web: thread builds, feeds the model, beats client history
calls = []
def fake_chat(base, key, model, messages, timeout, max_tokens=220):
    calls.append([m["content"] for m in messages])
    ans = {"answer": "مدل: " + messages[-1]["content"][:30], "links": [], "scope": True, "intent": "search"}
    return json.dumps(ans, ensure_ascii=False), 100
A._chat = fake_chat
os.environ.update(AI_BASE_URL="https://api.example.invalid/v1", AI_API_KEY="test-key-not-real",
                  AI_MODEL="fake-lite")
# v269 (دستور مدیر: هوش سایت جدا از محیط مدیر): چت کاربران از
# اسلات مستقل AI_SITE_* می‌خواند.
os.environ.update(AI_SITE_BASE_URL="https://site.example.invalid/v1",
                  AI_SITE_API_KEY="test-site-key-not-real",
                  AI_SITE_MODEL="site-model")
cust = db.customer_by_phone("09120000011", create=True)
ckey, cc = f"cust:{cust['id']}", ctx(f"cust:{cust['id']}", customer=cust)
A.answer("کدام کتابفروشی خوب است", cc)
ck(db._one("SELECT COUNT(*) c FROM ai_threads WHERE tkey=?", (ckey,))["c"] == 2, 'web exchange persisted (2 rows)')
A.answer("تلفنش چیست", cc)
ck(any("کتابفروشی" in m for m in calls[-1][1:-1]), 'second turn sees the first via the server thread')
r = A.answer("سومی", cc, [{"role": "user", "text": "BOGUSMARKER"}])
ck(not any("BOGUSMARKER" in m for m in calls[-1]) and any("تلفن" in m for m in calls[-1][1:-1]),
   'server thread wins over client-supplied history')
ck(A.needs_smart("x", A.thread_get(ckey)) is True, 'grown thread trips the multi-turn router')

# ---- 3. bots: persistent threads + cross-channel sharing
# v259 (دستور مدیر: «توکن فقط برای پنل کاربری و مدیرتیم»): کاربرِ باتِ
# بدون اتصال حساب هم مهمان است و پیش‌فرض مدل صدا نمی‌زند؛ این بخش تداوم
# رشته را با مدل می‌سنجد پس سوییچ لحظه‌ای روشن می‌شود.
db.set_settings({"ai_guest_model": "1"})
sent = []
A.bot_reply("bale", "bu1", "71", "متن اول بات", lambda c, t, m=None: sent.append(t))
A.bot_reply("bale", "bu1", "71", "متن دوم بات", lambda c, t, m=None: sent.append(t))
ck(db._one("SELECT COUNT(*) c FROM ai_threads WHERE tkey='bale:bu1'")["c"] == 4, 'bot turns persist under the platform key')
ck(any("متن اول بات" in m for m in calls[-1][1:-1]), 'second bot turn sees the first (no RAM involved)')
cust2 = db.customer_by_phone("09120000022", create=True)
ckey2 = f"cust:{cust2['id']}"
A.bot_reply("bale", "bu2", "72", "از بات وصل شدم", lambda c, t, m=None: sent.append(t), customer=cust2)
ck(db._one("SELECT COUNT(*) c FROM ai_threads WHERE tkey=?", (ckey2,))["c"] == 2, 'linked bot message lands in the account thread')
A.answer("از وب ادامه میدهم", ctx(ckey2, customer=cust2))
ck(any("از بات وصل شدم" in m for m in calls[-1][1:-1]), 'web turn sees the bot turn: cross-channel thread')

db.set_settings({"ai_guest_model": "0"})   # v259: سوییچ برمی‌گردد به پیش‌فرض خاموش

# ---- 4. guests are never persisted
A.answer("کافه", ctx("ip:9.9.9.9"))
ck(db._one("SELECT COUNT(*) c FROM ai_threads WHERE tkey LIKE 'ip:%'")["c"] == 0, 'no rows for guest keys, ever')

# ---- 5. the thread survives a restart (a second process sees it)
CHILD = ("import os, sys; os.environ['BZ_DATA_DIR'] = sys.argv[1]; sys.path.insert(0, sys.argv[2]); "
         "import db, assistant as A; db.init(); "
         "c = db.customer_by_phone('09120000011'); "
         "A.answer('پیام ماندگار تست', {'channel': 'web', 'user_key': f\"cust:{c['id']}\", 'customer': c, 'owner': None}); "
         "print('child OK')")
p = subprocess.run([sys.executable, "-c", CHILD, TMP, str(ROOT / "server")],
                   capture_output=True, text=True, timeout=120)
ck(p.returncode == 0 and any("ماندگار" in m["text"] for m in A.thread_get(ckey)),
   'a separate process appends, this one reads: restart-safe' + ("" if p.returncode == 0 else f" [{p.stderr[-200:]}]"))

# ---- 6. account delete wipes the thread; export carries it
cust3 = db.customer_by_phone("09120000033", create=True)
ckey3 = f"cust:{cust3['id']}"
A.answer("حرف محرمانهٔ من", ctx(ckey3, customer=cust3))
csv = db.customer_export_csv(cust3["id"])
ck("دستیار هوشمند" in csv and "حرف محرمانهٔ من" in csv, 'data export includes the transcript')
db.customer_delete(cust3["id"])
ck(db._one("SELECT COUNT(*) c FROM ai_threads WHERE tkey=?", (ckey3,))["c"] == 0, 'account delete wipes the thread')

# ---- 7. panel + backup exclusion
import views_panel2 as P
ck("رشته‌های فعال گفت‌وگو" in P.assistant_page(db.get_settings(), "tok", {}), 'panel shows the active-thread count')
ck("ai_threads" not in db.export_all(), 'transient threads excluded from backups')

print(f"v221: {n} checks passed")
