#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v256: مدرکِ بی‌توکن‌بودن بسته — اسکن کل فایل‌ها برای رازهای واقعی.

روش: هر رشتهٔ «شبیه کلید» (aa-…/sk-…/AIza…/gsk_…/kira_…/Bearer …) در کل درخت
پیدا می‌شود؛ هش SHA-256 هر کدام با فهرست سیاهِ «هش کلیدهای واقعی که
روزی استفاده شدند» مقایسه می‌شود. خودِ کلید واقعی هرگز در بسته نیست —
فقط هش یک‌طرفه‌اش (که برگشت‌ناپذیر است).

خروجی: گزارش شمردنی + کد خروج ۱ اگر حتی یک راز واقعی پیدا شود.
اجرا: python3 tools/scan_tokens.py [مسیر]   (پیش‌فرض: ریشهٔ همین بسته)
"""
import hashlib
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# فهرست سیاه: هش SHA-256 کلیدهای واقعی که در طول پروژه استفاده شدند.
# (کلید به‌خودی‌خود هرگز داخل بسته نمی‌آید — فقط هش.)
REAL_TOKEN_SHA = {
    # AvalAI aa-… key pasted by the owner on 2026-09-10 (baked in v253/v255, removed in v256)
    "a415b87134b42ca583c621849da783e8ee6850681bbe2cc0f50147ff5a52ff60":
        "avalai aa- key (owner, 2026-09-10)",
    # Claude aa-… key baked in v259/v260, retired in v261 (restricted: 403
    # model_access_limited on sonnet-5) — must never reappear in the package
    "494ffd7d20f479a7800887dca8589b186ffd5f989632a6aea1425e76edd7e20b":
        "avalai aa- key, model-restricted (owner, v259-v260)",
    # v261 unlimited key, retired in v263 (replaced by 3 per-model keys)
    "f00a76da5c0e56fdbaea62f4497c9603a59959e24d46aada0398cf094f26e8f4":
        "avalai aa- key, unlimited (owner, v261-v262)",
}

# خانواده‌های شکل کلید — برای پیدا کردن «کاندیدها». کاندیدها اغلب
# کلیدهای فیکِ تست‌ها هستند؛ فقط تطبیق هش با فهرست سیاه یعنی راز واقعی.
FAMILIES = {
    "aa-gateway": re.compile(r"aa-[A-Za-z0-9]{30,}"),
    "openai-sk":  re.compile(r"sk-[A-Za-z0-9_\-]{30,}"),
    "gemini":     re.compile(r"AIza[A-Za-z0-9_\-]{30,}"),
    "groq":       re.compile(r"gsk_[A-Za-z0-9]{30,50}"),
    "kira":       re.compile(r"kira_[A-Za-z0-9]{16,}"),  # v266: مغز پنجم
    "bearer":     re.compile(r"Bearer\s+[A-Za-z0-9._\-]{30,}"),
}


def _sha(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8", "replace")).hexdigest()


def scan(root: Path):
    """Returns (files_scanned, candidates, real_hits, brain_ai_lines)."""
    files = [p for p in sorted(root.rglob("*"))
             if p.is_file() and "__pycache__" not in p.parts]
    candidates, hits = 0, []
    for p in files:
        try:
            txt = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for fam, rx in FAMILIES.items():
            for m in rx.findall(txt):
                candidates += 1
                if _sha(m) in REAL_TOKEN_SHA:
                    hits.append((str(p.relative_to(root)), fam))
    brain = root / "deploy" / "brain.env"
    brain_ai = 0
    if brain.is_file():
        brain_ai = sum(1 for ln in brain.read_text(encoding="utf-8")
                       .splitlines() if ln.startswith("AI_"))
    return files, candidates, hits, brain_ai


def main() -> int:
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT
    files, candidates, hits, brain_ai = scan(root)
    print("🧾 مدرک بی‌توکن‌بودن — اسکن", root)
    print("   فایل‌های اسکن‌شده:", len(files))
    print("   رشته‌های شبیه کلید (کلیدهای فیک تست/نمونه):", candidates)
    print("   خط‌های AI_ در deploy/brain.env:", brain_ai)
    if hits:
        print("   ❌ راز واقعی پیدا شد:")
        for p, fam in hits:
            print("     -", p, "(", fam, ")")
        return 1
    print("   ✅ راز واقعی: ۰ مورد در کل بسته")
    return 0


if __name__ == "__main__":
    sys.exit(main())
