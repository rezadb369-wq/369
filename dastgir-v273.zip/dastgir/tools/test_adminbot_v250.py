#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v250: پایان دروغ «ابزار شناخته نشد» — هر رد شدن، دلیلش را صادقانه می‌گوید.

Why (LIVE evidence from the production server, 2026-09-10): the owner's
تشخیص report was all green, yet a real request died with
«ابزار پیشنهادی معتبر شناخته نشد (ابزار «setting» شناخته نشد)». The name
WAS valid — one of the ARG gates failed (locked brand key / secret key /
missing key / a toggle answered with «فعال» instead of the tiny v249
on/off vocabulary) and the old message blamed the tool name.
Fix: (a) every setting-lane rejection now carries a Persian reason;
(b) toggle vocabulary widened (فعال/غیرفعال/yes/no/بله/نه/enable/disable);
(c) setting args repair widened (setting/setting_key/key_name→key,
new_value/v/to/new→value, "Site Title"→site_title normalization);
(d) aa-… gateway keys (AvalAI) get a paste-ready /کلید openai command that
reuses the live brain's base_url — v259 (دستور مدیر: «توکن کلود دقیق پیاده
بشه»): bare aa-… now installs DIRECTLY as Claude (live-tested), see §14;
(e) assistant.py says «درست بود ولی اجرا نشد: <reason>» when the name was
fine and only the args failed.
"""
import os, sys, json, time, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v250-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
SCRIPT = []
def fake_chat(*a, **k):
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]
P = lambda name, args: json.dumps(
    {"reply": "می‌خواهم این کار را بکنم.", "tool": {"name": name, "args": args}},
    ensure_ascii=False)
S = lambda key, value: {"name": "setting", "args": {"key": key, "value": value}}

# ================= 1. the live production case: valid name, locked key
# v251 (دستور مدیر — «همه‌جا کم‌دسترسی بود»): site_name باز شد؛ قفل فقط برای
# احراز هویت/قفل‌اوت ماند — با نام کلید در پیام.
nm, ag = CT.parse_tool_call(S('site_name', 'فروشگاه من'))
ck(nm == 'setting' and ag['value'] == 'فروشگاه من',
   'site_name: now WRITABLE by the owner (v251 policy)')
ck(CT.parse_tool_call(S('owner_token', 'x'))[0] == 'setting' and
   CT.reject_reason(S('owner_token', 'x')) == '',
   'owner_token: ACCEPTED with «بله» (v265 full access; production case)')

# ================= 2. service keys writable, values never logged (v251)
ck(CT.parse_tool_call(S('tg_token', '123:ABC'))[0] == 'setting',
   'tg_token: service key now writable via bot')
ck(CT.parse_tool_call(S('sms_key', 'x'))[0] == 'setting',
   'sms_key: service key now writable via bot')

# ================= 3. missing / malformed key
ck('کلید تنظیم' in CT.reject_reason({"name": "setting", "args": {"value": "x"}}),
   'missing key: says the key was not sent')
ck('شکل کلید' in CT.reject_reason(S('عنوان سایت', 'x')),
   'persian key: says the shape is invalid')

# ================= 4. toggle vocabulary widened (the other live suspect)
ck(CT.parse_tool_call(S('reviews_moderated', 'فعال')) == ('setting', {'key': 'reviews_moderated', 'value': '1'}),
   'toggle «فعال» → 1')
ck(CT.parse_tool_call(S('blog_enabled', 'غیرفعال')) == ('setting', {'key': 'blog_enabled', 'value': '0'}),
   'toggle «غیرفعال» → 0')
ck(CT.parse_tool_call(S('chat_enabled', 'yes'))[1]['value'] == '1'
   and CT.parse_tool_call(S('chat_enabled', 'نه'))[1]['value'] == '0',
   'toggle yes/نه mapped')
ck(CT.parse_tool_call(S('reg_open', 'روشن'))[1]['value'] == '1',
   'toggle «روشن» still works (v249 regression)')
nm, ag = CT.parse_tool_call(S('reg_open', 'شاید'))
ck(nm is None and 'روشن یا خاموش' in CT.reject_reason(S('reg_open', 'شاید')),
   'bad toggle word: honest reason')

# ================= 5. numeric gates with reasons
ck('بین 2 و 19' in CT.reject_reason(S('map_zoom', '42')),
   'map_zoom 42: range reason')
ck('۹۰' in CT.reject_reason(S('map_lat', '999')),
   'map_lat 999: range reason')
ck(CT.parse_tool_call(S('map_zoom', '14'))[1]['value'] == '14',
   'map_zoom 14 ok (regression)')

# ================= 6. arg repair + key normalization
nm, ag = CT.parse_tool_call({"name": "set_setting",
                             "args": {"setting": "Map-Lat", "new_value": "35.7"}})
ck(nm == 'setting' and ag == {'key': 'map_lat', 'value': '35.7'},
   'set_setting + setting/Map-Lat/new_value fully repaired')
nm, ag = CT.parse_tool_call({"name": "setting", "args": {"key_name": "tagline",
                                                         "to": "خرید محلی"}})
ck(nm == 'setting' and ag['key'] == 'tagline' and ag['value'] == 'خرید محلی',
   'key_name/to aliases repaired')
ck(CT.parse_tool_call(S('tagline', 'x')) == CT.parse_tool_call(S('tagline', 'x')),
   'parse is deterministic/idempotent')

# ================= 7. dynamic DB keys: parse → precheck → execute end-to-end
nm, ag = CT.parse_tool_call(S('phone_raw', '02191001100'))
ok, why = CT.tool_precheck('setting', ag)
ck(nm == 'setting' and ok, 'dynamic key phone_raw parses + passes precheck (exists in DB)')
ok2, msg = CT.tool_execute('setting', ag)
ck(ok2 and db.get_settings().get('phone_raw') == '02191001100',
   'phone_raw actually written to the DB')
nm, ag = CT.parse_tool_call(S('unicorn_x', 'x'))
ok, why = CT.tool_precheck('setting', ag)
ck(nm == 'setting' and not ok and why == 'key',
   'invented dynamic key stopped by precheck (invented ids never pass)')
nm, ag = CT.parse_tool_call(S('unicorn_key', 'x'))
ok, why = CT.tool_precheck('setting', ag)
ck(nm == 'setting' and not ok and why == 'key',
   'v251: invented «…_key» passes parse, stopped at precheck (must exist in DB)')

# ================= 8. plain text settings still work (regression)
ok2, msg = CT.tool_execute('setting', CT.parse_tool_call(S('tagline', 'فروشگاه من'))[1])
ck(ok2 and db.get_settings().get('tagline') == 'فروشگاه من',
   'tagline write (regression)')

# ================= 9. E2E: auth keys now EXECUTE at once (v265+v268)
SCRIPT.append(P('setting', {"key": "owner_token", "value": "x"}))
r = t('توکن مدیر را عوض کن')
ck('🔑 توکن تازهٔ ورود ذخیره شد' in r and 'نشانی تازهٔ پنل' in r,
   'v268: E2E owner_token executed (full access)')
ck('معتبر شناخته نشد' not in r, 'E2E owner_token: old misleading wording gone')

# ================= 9b. E2E: site_name rename now WORKS end-to-end (v251)
SCRIPT.append(P('setting', {"key": "site_name", "value": "فروشگاه من"}))
r = t('اسم سایت را عوض کن')
ck('✏️ «site_name» ذخیره شد' in r and 'معتبر شناخته نشد' not in r and 'درست بود ولی اجرا نشد' not in r,
   'v268: E2E site_name executed (v251 owner power)')
t('بله')
ck(db.get_settings().get('site_name') == 'فروشگاه من',
   'v268: E2E site_name renamed at once')
db.set_setting('site_name', 'دست گیر')   # restore for the remaining checks

# ================= 10. E2E: unknown tool keeps the old (correct) wording
SCRIPT.append(P('time_travel', {"when": "yesterday"}))
r = t('زمان را به عقب ببر')
ck('معتبر شناخته نشد' in r and 'time_travel' in r and 'درست بود' not in r,
   'E2E unknown tool: old wording, no fake reason')
ck(CT.reject_reason({"name": "time_travel", "args": {}}) == '',
   'reject_reason empty for unknown names (unit)')

# ================= 11. E2E: فعال toggle now goes through end-to-end
SCRIPT.append(P('setting', {"key": "reviews_moderated", "value": "فعال"}))
r = t('نظرات قبل از نمایش تأیید شوند')
ck('✏️ «reviews_moderated» ذخیره شد' in r and 'معتبر شناخته نشد' not in r and 'درست بود ولی اجرا نشد' not in r,
   'v268: E2E فعال toggle executed, no rejection at all')
A._pending_clear()

# ================= 12. code lane gets its honest generic reason
ck('ابزار کد' in CT.reject_reason({"name": "code_read", "args": {}}),
   'code_read without path: lane-named reason')

# ================= 13. ai_setup unaffected (regression)
nm, ag = CT.parse_tool_call({"name": "ai_setup",
                             "args": {"provider": "gemini",
                                      "key": "AIza" + "a" * 32}})
ck(nm == 'ai_setup', 'ai_setup gemini still parses (regression)')

# ================= 14. /کلید aa-… → direct Claude install (v259 policy)
# v259 (دستور مدیر: «توکن کلود دقیق پیاده بشه»): bare aa-… no longer prints
# a paste-ready /کلید openai hint — it live-tests and installs as Claude.
r = t('/کلید aa-fake' + 'k' * 44)
ck('کلید تست شد' in r and 'نصبش در صف' in r,
   'aa- key: live-tested and queued as a direct Claude install')
ck('aa-fake' not in r, 'aa- install never echoes the key back')

# ================= 15. aa- must NOT be silently swallowed as astra
nm, ag = CT.parse_tool_call({"name": "ai_setup",
                             "args": {"provider": "astra",
                                      "key": "aa-fake" + "k" * 44}})
ck(nm is None, 'astra lane still rejects aa- shapes (no silent rerouting)')

print(f'v250 honest rejections: {n} checks green')
