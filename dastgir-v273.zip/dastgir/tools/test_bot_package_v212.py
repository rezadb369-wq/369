#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v212 «بستهٔ کامل بات»: photo cards, /near by location, typing action,
setMyCommands, live order receipt (editMessageText) — offline, no network."""
import os, sys, tempfile, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; TMP=tempfile.mkdtemp(prefix='bot-v212-')
os.environ['BZ_DATA_DIR']=TMP; os.environ.pop('BALE_SET_COMMANDS',None)
sys.path.insert(0,str(ROOT/'server'))
import db, bot_menu, bale, soroush
n=0
def ck(ok,label):
    global n
    assert ok,label; n+=1; print('  ✓',label)

# ---- transport layer: capture outgoing API calls instead of HTTP
calls=[]
def fake_call(platform):
    def _c(method,payload=None):
        calls.append((platform,method,payload or {}))
        if method=='sendMessage': return {'ok':True,'result':{'message_id':4200+len(calls)}}
        if method in ('sendPhoto','editMessageText','sendChatAction','setMyCommands','answerCallbackQuery'): return {'ok':True,'result':True}
        return {'ok':False}
    return _c
bale._call=fake_call('bale'); soroush._call=fake_call('soroush')
os.environ['BALE_BOT_TOKEN']='x'; os.environ['BALE_WEBHOOK_SECRET']='y'*40
os.environ['SOROUSH_BOT_TOKEN']='x'; os.environ['SOROUSH_WEBHOOK_SECRET']='y'*40

try:
    db.init()
    # transport shapes
    def flat(): return '\n'.join([x[1]+json.dumps(x[2],ensure_ascii=False) for x in sent]+[json.dumps(x[2],ensure_ascii=False) for x in calls])
    ck(bale.send_photo('1','https://daastgir.ir/assets/img/uploads/a.jpg','کپشن',{'inline_keyboard':[]}) and calls[-1][1]=='sendPhoto' and calls[-1][2]['photo'].startswith('https://'),'Bale sendPhoto uses documented URL form')
    ck(not bale.send_photo('1','http://insecure/x.jpg','') and not soroush.send_photo('1','/relative.jpg',''),'non-HTTPS covers are never sent as photos')
    ck(bale.send_chat_action('1','typing') and calls[-1][2]=={'chat_id':'1','action':'typing'},'Bale sendChatAction typing payload')
    ck(bale.send_chat_action('1','bogus') and calls[-1][2]['action']=='typing','unknown chat action falls back to typing')
    ck(bale.edit_message_text('1',77,'متن',{'inline_keyboard':[]}) and calls[-1][2]['message_id']==77,'Bale editMessageText payload carries message_id')
    ck(not bale.edit_message_text('1','77','متن') and not soroush.edit_message_text('1',None,'x'),'editMessageText rejects non-integer message ids')
    ck(isinstance(bale.send_message_id('1','سلام'),int) and isinstance(soroush.send_message_id('1','سلام'),int),'send_message_id returns platform message_id')
    before=len(calls); ck(bale.set_my_commands(bot_menu.BOT_COMMANDS) is False and len(calls)==before,'Bale setMyCommands is a no-op unless BALE_SET_COMMANDS=1 (not in official docs)')
    os.environ['BALE_SET_COMMANDS']='1'; ck(bale.set_my_commands(bot_menu.BOT_COMMANDS) and calls[-1][1]=='setMyCommands','Bale setMyCommands opt-in sends the command list'); os.environ.pop('BALE_SET_COMMANDS')
    ck(soroush.set_my_commands(bot_menu.BOT_COMMANDS) and [c['command'] for c in calls[-1][2]['commands']]==['start','search','near','orders','bookings','register','help'],'Soroush setMyCommands publishes the seven documented commands')
    ck(all(len(c)<=32 and c.islower() and len(d)<=256 for c,d in bot_menu.BOT_COMMANDS),'command names respect BotCommand limits')
    res=bot_menu.register_commands(); ck(res=={'bale':False,'soroush':True},'register_commands is best-effort per platform')
    ck(bot_menu.typing('bale','5') and calls[-1][1]=='sendChatAction','typing helper reaches transport')
    ck(bot_menu.typing('unknown','5') is False,'typing helper ignores unknown platforms')

    # ---- data
    sent=[]
    def send(chat,text,markup=None): sent.append((str(chat),text,markup)); return True
    c=db.customer_by_phone('09123456789',create=True); owner=db.owner_by_phone('09123456789',create=True)
    con=db.connect()
    con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,?,?,?)",(c['id'],'bale','b1','20'))
    con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,?,?,?)",(c['id'],'soroush','s1','21'))
    hours=json.dumps({d:[["00:00","23:59"]] for d in db.DAY_KEYS})
    con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id,address,phone,lat,lng,cover,hours,verified) VALUES('near-a','کافه نزدیک','cafe','published',?,?,?,35.7000,51.4000,'/assets/img/uploads/c1.jpg',?,1)",(owner['id'],'خیابان اول','09120000001',hours))
    con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id,address,phone,lat,lng,hours,phone_public) VALUES('near-b','نانوایی دور','bakery','published',?,?,?,35.7300,51.4300,?,0)",(owner['id'],'خیابان دوم','09120000002',hours))
    con.execute("INSERT INTO businesses(slug,name,cat_slug,status,lat,lng) VALUES('near-h','مخفی','cafe','hidden',35.7001,51.4001)")
    con.execute("INSERT INTO businesses(slug,name,cat_slug,status,lat,lng) VALUES('near-far','خیلی دور','cafe','published',36.9,50.1)")
    con.commit(); con.close()
    a=db.business(slug='near-a'); b=db.business(slug='near-b')
    # hours format may differ; force open-state through db helper check
    open_a=db.is_open_now(a)

    # ---- cards
    cap=bot_menu.card_caption(a,0.42)
    ck('کافه نزدیک' in cap and '✅' in cap and '⭐' in cap and 'متر' in cap and 'خیابان اول' in cap and len(cap)<=1024,'card caption: name, verified, rating, distance, address within 1024')
    ck(('🟢' in cap or '⚪️' in cap or '🔴' in cap or '🟠' in cap),'card caption carries an open/closed line')
    kb=bot_menu.card_buttons(c['id'],a)['inline_keyboard']
    labels=[x['text'] for x in kb[0]]
    ck(labels==['📞 تماس','🗺 مسیر','🌐 صفحه'] and kb[0][2]['url'].endswith('/b/near-a') and 'google.com/maps' in kb[0][1]['url'],'card buttons: تماس / مسیر / صفحه in order')
    kb_b=bot_menu.card_buttons(c['id'],b)['inline_keyboard']
    ck(all(x['text']!='📞 تماس' for x in kb_b[0]),'phone button hidden when phone_public=0')
    ck(bot_menu._cover_url(a)=='https://daastgir.ir/assets/img/uploads/c1.jpg' and bot_menu._cover_url(b)=='','cover resolves to absolute HTTPS or empty')
    ck(bot_menu._cover_url({'cover':'javascript:alert(1)'})=='' and bot_menu._cover_url({'cover':'http://x/y.jpg'})=='','unsafe cover schemes are dropped')
    calls.clear(); sent.clear(); ck(bot_menu.send_card('bale','20',c['id'],a,send),'card with cover is sent')
    ck(calls and calls[-1][1]=='sendPhoto' and calls[-1][2]['caption']==bot_menu.card_caption(a) and not sent,'cover business goes out as sendPhoto with caption')
    calls.clear(); sent.clear(); bot_menu.send_card('bale','20',c['id'],b,send)
    ck(not calls and sent and 'نانوایی دور' in sent[-1][1],'business without cover falls back to text card')
    saved=bale._call; bale._call=lambda m,p=None:{'ok':False}; calls.clear(); sent.clear(); bot_menu.send_card('bale','20',c['id'],a,send); bale._call=saved
    ck(sent and 'کافه نزدیک' in sent[-1][1],'rejected sendPhoto falls back to text card')

    # search → cards
    calls.clear(); sent.clear(); ck(bot_menu.handle_message('bale','b1','20','/search کافه',send),'/search consumed')
    ck(any(x[1]=='sendChatAction' for x in calls) and any(x[1]=='sendPhoto' for x in calls),'search sends typing then a photo card')
    ck('مخفی' not in flat() and any('/businesses?q=' in str(x[2]) for x in sent),'search cards exclude hidden rows and link the site search')
    # favorites → cards
    db.favorite_add(c['id'],a['id']); calls.clear(); sent.clear(); bot_menu.handle_callback('soroush','s1','21','dg198:favorites',send)
    ck(any(x[1]=='sendPhoto' and x[0]=='soroush' for x in calls) and f"dg198:fav_remove:{a['id']}" in str(sent[-1][2]),'favorites render cards on Soroush and keep removal buttons')

    # phone callback
    sent.clear(); ck(bot_menu.handle_callback('bale','b1','20',f"dg198:card_phone:{a['id']}",send) and '09120000001' in sent[-1][1],'تماس callback reveals public phone')
    sent.clear(); bot_menu.handle_callback('bale','b1','20',f"dg198:card_phone:{b['id']}",send); ck('09120000002' not in sent[-1][1],'تماس callback respects phone_public=0')
    sent.clear(); bot_menu.handle_callback('bale','b1','20','dg198:card_phone:999999',send); ck('عمومی ثبت نشده' in sent[-1][1],'unknown business phone request is safe')
    sent.clear(); bot_menu.handle_callback('bale','stranger','30',f"dg198:card_phone:{a['id']}",send); ck('09120000001' not in sent[-1][1],'unlinked user cannot pull phones via callback')

    # near me
    sent.clear(); ck(bot_menu.handle_message('bale','b1','20','/near',send) and sent[-1][2]['keyboard'][0][0].get('request_location') is True,'/near offers request_location keyboard')
    sent.clear(); bot_menu.handle_callback('soroush','s1','21','dg198:near',send); ck(sent[-1][2]['keyboard'][0][0]['request_location'],'near callback whitelisted')
    ck('📍 نزدیک من' in str(bot_menu._buttons(True)),'main menu shows «نزدیک من»')
    calls.clear(); sent.clear(); bot_menu.handle_location('bale','b1','20',35.7005,51.4005,send)
    alltext=flat()
    ck('کافه نزدیک' in alltext and 'مخفی' not in alltext and 'خیلی دور' not in alltext,'near-me lists nearby published rows only (5 km, no hidden)')
    ck('از شما' in alltext and 'متر' in alltext,'near-me cards show distance')
    ck(open_a and 'نزدیک‌ترین کسب‌وکارهای باز' in alltext,'open businesses (24h hours) get the open headline')
    con=db.connect(); con.execute("UPDATE businesses SET hours=? WHERE slug IN ('near-a','near-b')",(json.dumps({db.DAY_KEYS[0]:[["03:00","03:01"]]}),)); con.commit(); con.close()
    calls.clear(); sent.clear(); bot_menu.handle_location('bale','b1','20',35.7005,51.4005,send); alltext2=flat()
    ck('نزدیک‌ترین‌ها' in alltext2 and 'کافه نزدیک' in alltext2,'without open rows the closed fallback headline still lists nearest')
    con=db.connect(); con.execute("UPDATE businesses SET hours=? WHERE slug IN ('near-a','near-b')",(hours,)); con.commit(); con.close()
    ck(sent[0][2]=={'remove_keyboard':True},'location reply removes the request keyboard')
    sent.clear(); bot_menu.handle_location('bale','b1','20','abc',None,send); ck('معتبر نبود' in sent[-1][1],'invalid coordinates rejected')
    sent.clear(); bot_menu.handle_location('bale','b1','20',95,200,send); ck('معتبر نبود' in sent[-1][1],'out-of-range coordinates rejected')
    sent.clear(); bot_menu.handle_location('bale','b1','20',10.0,10.0,send); ck('ثبت نشده' in sent[-1][1],'empty radius yields a clear message')
    sent.clear(); bot_menu.handle_location('bale','stranger','30',35.7,51.4,send)
    # v269 (رفع پین کهنه؛ سیاست v234: «guests welcome» — موقعیت هرگز ذخیره
    # نمی‌شود): کاربر متصل‌نشده دیگر دیوار ورود نمی‌گیرد؛ مثل مهمان سرویس
    # می‌گیرد (فقط بدون دکمهٔ علاقه‌مندی).
    ck(sent and all('متصل کنید' not in str(x[1]) for x in sent),'unlinked user is served as a guest (v234 policy)')
    con=db.connect(); ck(not [r for r in con.execute("PRAGMA table_info(businesses)") if 'customer_lat' in r['name']],'no customer location column exists (location is not stored)'); con.close()

    # live receipt
    oid=db.create_order(a['id'],c['id'],'کاربر','09123456789','نشانی محرمانه','',[{'title':'اسپرسو','price':50000,'qty':2}])
    calls.clear(); db.notify_customer(c['id'],'order',f'وضعیت سفارش #{oid} به «تأیید شد» تغییر کرد.',f'/me/order/{oid}')
    first=[x for x in calls if x[1]=='sendMessage']
    ck(len(first)==2 and {x[0] for x in first}=={'bale','soroush'} and 'رسید سفارش' in first[0][2]['text'] and 'نشانی محرمانه' not in first[0][2]['text'],'first order notification sends one receipt per platform without private address')
    rows=db._rows("SELECT * FROM order_receipts WHERE order_id=?",(oid,)); ck(len(rows)==2,'receipt message ids stored per platform')
    db.set_order_status(oid,'ready'); calls.clear(); db.notify_customer(c['id'],'order',f'وضعیت سفارش #{oid} به «آمادهٔ تحویل» تغییر کرد.',f'/me/order/{oid}')
    edits=[x for x in calls if x[1]=='editMessageText']
    ck(len(edits)==2 and not [x for x in calls if x[1]=='sendMessage'] and all(x[2]['message_id']==r['message_id'] for x,r in zip(sorted(edits),sorted(rows,key=lambda r:r['platform']))),'status change edits the stored receipts instead of sending new messages')
    txt=edits[0][2]['text']; ck('✅ ثبت شد' in txt and '✅ تأیید شد' in txt and '🔵 آمادهٔ تحویل' in txt and '⚪️ تحویل شد' in txt,'receipt renders the progress steps')
    ck('📣 وضعیت سفارش' in txt and 'آمادهٔ تحویل» تغییر کرد' in txt,'receipt embeds the latest notification sentence (no information lost)')
    db.set_order_status(oid,'cancelled'); ck('❌' in db.order_receipt_text(oid),'cancelled receipt shows cancel line')
    saved=bale._call; bale._call=lambda m,p=None:({'ok':False} if m=='editMessageText' else fake_call('bale')(m,p)); calls.clear(); db.notify_customer(c['id'],'order','x',f'/me/order/{oid}'); bale._call=saved
    ck([x for x in calls if x[0]=='bale' and x[1]=='sendMessage'],'failed edit (e.g. message >48h) re-sends and re-stores the receipt')
    other=db.customer_by_phone('09121111111',create=True); con=db.connect(); con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,?,?,?)",(other['id'],'bale','b2','22')); con.commit(); con.close()
    calls.clear(); db.notify_customer(other['id'],'order','forged',f'/me/order/{oid}')
    ck(calls and all('رسید سفارش' not in str(x[2]) for x in calls) and calls[-1][1]=='sendMessage','foreign customer never receives another customer receipt')
    calls.clear(); db.notify_customer(c['id'],'chat','پاسخ جدید','/me/chat/1'); ck(all(x[1]=='sendMessage' and '🔔' in x[2]['text'] for x in calls),'non-order notifications keep the plain path')

    # webhook routing (location message) via App handler
    import app as appmod, io
    class Req:
        def __init__(s,body): s.rfile=io.BytesIO(body); s.wfile=io.BytesIO()
    handled=[]
    real=bot_menu.handle_location; bot_menu.handle_location=lambda *a,**k: handled.append(a) or True
    class H(appmod.App):
        def __init__(s,path,body):
            s.path=path; s.headers={'Content-Length':str(len(body)),'Content-Type':'application/json'}; s.rfile=io.BytesIO(body); s.wfile=io.BytesIO(); s.client_address=('127.0.0.1',1); s.command='POST'; s.request_version='HTTP/1.1'; s.requestline='POST'
            s.do_POST()
        def log_message(s,*a): pass
    body=json.dumps({'update_id':9001,'message':{'message_id':1,'from':{'id':'b1'},'chat':{'id':'20','type':'private'},'location':{'latitude':35.7,'longitude':51.4}}}).encode()
    try:
        H('/api/bale/webhook/'+'y'*40,body)
        ck(handled and handled[-1][0]=='bale' and handled[-1][3]==35.7,'Bale webhook routes location messages to handle_location')
        handled.clear(); H('/api/soroush/webhook/'+'y'*40,json.dumps({'update_id':9002,'message':{'message_id':2,'from':{'id':'s1'},'chat':{'id':'21','type':'private'},'location':{'latitude':35.7,'longitude':51.4}}}).encode())
        ck(handled and handled[-1][0]=='soroush','Soroush webhook routes location messages to handle_location')
        handled.clear(); H('/api/bale/webhook/'+'y'*40,json.dumps({'update_id':9003,'message':{'message_id':3,'from':{'id':'b1'},'chat':{'id':'77','type':'group'},'location':{'latitude':35.7,'longitude':51.4}}}).encode())
        ck(not handled,'group location messages are ignored')
    finally:
        bot_menu.handle_location=real
    ck(all(len(x.encode())<=64 for x in ('dg198:near','dg198:card_phone:999999999999')),'new callbacks stay within 64 bytes')
    ck(db._rows("SELECT 1 FROM order_receipts WHERE order_id=?",(oid,)),'receipt rows exist before account deletion')
    db.customer_delete(c['id']); ck(not db._rows("SELECT 1 FROM order_receipts WHERE order_id=?",(oid,)),'customer deletion purges receipt chat ids')
    print(f"\nAll {n} bot-package v212 checks passed.")
except Exception:
    import traceback; traceback.print_exc(); sys.exit(1)
