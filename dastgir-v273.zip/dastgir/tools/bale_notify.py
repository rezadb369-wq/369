#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v241: one-way admin notifier for the codeguard cron (runs as root).

Standalone on purpose — no app imports, so it keeps working even when the
app's own code is mid-rollback. Reads BALE_ADMIN_TOKEN / BALE_ADMIN_CHAT
from /etc/dastgir-secrets.env (or the environment); never prints anything.
"""
import json
import os
import re
import sys
import urllib.request

ENV_FILE = os.environ.get("DASTGIR_SECRETS", "/etc/dastgir-secrets.env")
API = "https://tapi.bale.ai/bot"


def _from_file(key):
    try:
        with open(ENV_FILE, encoding="utf-8") as f:
            for line in f:
                m = re.match(r'^\s*(?:export\s+)?' + re.escape(key) +
                             r'=(["\']?)(.*)\1\s*$', line)
                if m:
                    return m.group(2).strip()
    except OSError:
        pass
    return ""


def main():
    text = " ".join(sys.argv[1:]).strip() or "اطلاع‌رسانی کدگارد"
    tok = os.environ.get("BALE_ADMIN_TOKEN") or _from_file("BALE_ADMIN_TOKEN")
    raw = os.environ.get("BALE_ADMIN_CHAT") or _from_file("BALE_ADMIN_CHAT")
    # v259 (دستور مدیر: مدیرتیم): چند شناسه با کاما — به همه خبر می‌رسد.
    chats = [c.strip() for c in str(raw or "").split(",")]
    chats = [c for c in chats if c and c.lstrip("-").isdigit()]
    if not tok or not chats:
        return
    for chat in chats:
        try:
            req = urllib.request.Request(
                API + tok + "/sendMessage",
                data=json.dumps({"chat_id": int(chat), "text": text[:900]},
                                ensure_ascii=False).encode("utf-8"),
                headers={"Content-Type": "application/json",
                         "User-Agent": "Daastgir/259"},
                method="POST")
            urllib.request.urlopen(req, timeout=10)
        except Exception:
            pass


if __name__ == "__main__":
    main()
