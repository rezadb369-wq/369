#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v220 «کش معنایی پاسخ‌ها» — offline tests with a fake model.

Repeated public (guest, history-less) questions are served from ai_cache:
free, no provider call, even when the model budget is out. Matching is an
exact normalized hit or token-set Jaccard >= 0.75 with rule-hint agreement.
Signed-in answers (may embed personal data) and follow-ups are never cached.
"""
import os, sys, tempfile, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v220-')
os.environ['BZ_DATA_DIR'] = TMP
for k in ('AI_BASE_URL', 'AI_API_KEY', 'AI_MODEL', 'AI_MODEL_SMART', 'AI_FALLBACK_BASE_URL', 'AI_FALLBACK_API_KEY', 'AI_FALLBACK_MODEL'):
    os.environ.pop(k, None)
sys.path.insert(0, str(ROOT / 'server'))
import db, assistant as A
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
ctx = lambda key, **kw: dict({"channel": "web", "user_key": key, "customer": None, "owner": None}, **kw)
calls = []
def fake_chat(base, key, model, messages, timeout, max_tokens=220):
    calls.append(model)
    ans = {"answer": "پاسخ مدل: " + messages[-1]["content"][:40],
           "links": [{"label": "جست‌وجو", "href": "/businesses"}],
           "scope": True, "intent": "search"}
    return json.dumps(ans, ensure_ascii=False), 100
A._chat = fake_chat
os.environ.update(AI_BASE_URL="https://api.example.invalid/v1", AI_API_KEY="test-key-not-real",
                  AI_MODEL="fake-lite")
# v269 (دستور مدیر: هوش سایت جدا از محیط مدیر): چت کاربران از
# اسلات مستقل AI_SITE_* می‌خواند.
os.environ.update(AI_SITE_BASE_URL="https://site.example.invalid/v1",
                  AI_SITE_API_KEY="test-site-key-not-real",
                  AI_SITE_MODEL="site-model")
# v259 (دستور مدیر: «توکن فقط برای پنل کاربری و مدیرتیم»): این سوئیت مکانیک
# کش را می‌سنجد (پر شدن با مدلِ مهمان + خواندن رایگان) پس سوییچ مدلِ مهمان را
# لحظه‌ای روشن می‌کند؛ رفتار پیش‌فرضِ خاموش در v259 قفل است.
db.set_settings({"ai_guest_model": "1"})

Q1 = "بهترین کافه برای دورهمی دوستانه"

# ---- 1. store on first ask, free hit on repeat and paraphrase, miss otherwise
r = A.answer(Q1, ctx("g1"))
ck(r["source"] == "llm" and A.quota_used_today("g1") == 1, 'first ask reaches the model and costs quota')
ncalls = len(calls)
r = A.answer(Q1, ctx("g2"))
ck(r["source"] == "cache" and r["model"] == "fast" and len(calls) == ncalls, 'repeat served from cache, no provider call')
ck(A.quota_used_today("g2") == 0 and r["remaining"] == 5, 'cache hit costs no quota')
r = A.answer("برای دورهمی دوستانه بهترین کافه", ctx("g3"))
ck(r["source"] == "cache", 'word-order paraphrase hits (identical token set)')
r = A.answer("نزدیک‌ترین پمپ بنزین", ctx("g3"))
ck(r["source"] == "llm", 'different question misses the cache')
ck(A.cache_stats()["hits"] == 2, 'two hits recorded')

# ---- 2. spelling variants hit: ZWNJ, punctuation, ي/ك
A.answer("داروخانه شبانه‌روزی", ctx("g4"))
r = A.answer("داروخانه شبانه روزی؟؟", ctx("g4"))
ck(r["source"] == "cache", 'ZWNJ + punctuation variants hit')
A.answer("چایخانه سنتی", ctx("g5"))
r = A.answer("چايخانه سنتي", ctx("g5"))
ck(r["source"] == "cache", 'Arabic ي variants hit')

# ---- 3. signed-in and follow-up answers never touch the cache
cust = db.customer_by_phone("09120000001", create=True)
ckey = f"cust:{cust['id']}"
r = A.answer(Q1, ctx(ckey, customer=cust))
ck(r["source"] == "llm" and A.quota_used_today(ckey) == 1, 'signed-in user never gets cached answers')
r = A.answer(Q1, ctx("g6"), [{"role": "user", "text": "سلام"}])
ck(r["source"] == "llm", 'follow-up with history bypasses the cache')
r = A.answer("رستوران ایتالیایی خوب", ctx(ckey, customer=cust))
ck(r["source"] == "llm", 'signed-in model answer served fresh')
r = A.answer("رستوران ایتالیایی خوب", ctx("g7"))
ck(r["source"] == "llm", 'signed-in answer was not stored for guests')

# ---- 4. cache stays available when the model budget is out
for t in ["موزه شهر", "سینما آزادی", "پارک جنگلی", "استخر سرپوشیده", "باشگاه ورزشی"]:
    A.answer(t, ctx("paidC"))
ck(A.quota_used_today("paidC") == 5, 'quota burned with five fresh questions')
r = A.answer("کتابخانه ملی", ctx("paidC"))
ck(r["source"] == "rule" and r["degraded"] == "quota", 'fresh question with quota out → flagged rules')
r = A.answer(Q1, ctx("paidC"))
ck(r["source"] == "cache" and r["degraded"] == "" and A.quota_used_today("paidC") == 5, 'cached answer free despite exhausted quota')

# ---- 5. expiry and size cap
con = db.connect()
con.execute("INSERT INTO ai_cache(q_norm,tokens,answer,links,intent,model,mtokens,hits,created,expires) "
            "VALUES('منقضی تست','منقضی تست','قدیمی','[]','search','fast',10,0,1,1)")
con.commit(); con.close()
ck(A.cache_lookup("منقضی تست", ctx("g8")) is None, 'expired row never matches')
A.cache_store("سؤال تازهٔ هرز", ctx("g8"), None, "جواب", [], "search", "fast", 10)
ck(db._one("SELECT COUNT(*) c FROM ai_cache WHERE q_norm='منقضی تست'")["c"] == 0, 'storing prunes expired rows')
for i in range(505):
    A.cache_store(f"bulkq {i} extra words here", ctx("g8"), None, "b", [], "search", "fast", 10)
ck(db._one("SELECT COUNT(*) c FROM ai_cache")["c"] == 500, 'cache capped at 500 rows')
ck(db._one("SELECT COUNT(*) c FROM ai_cache WHERE q_norm='bulkq 0 extra words here'")["c"] == 0, 'oldest rows evicted first')
r = A.answer("bulkq 504 extra words here", ctx("g9"))
ck(r["source"] == "cache", 'newest bulk row still matches exactly')

# ---- 6. near-miss guards: one swapped content word, intent mismatch
r = A.answer("بهترین رستوران ایتالیایی شهر", ctx("g10"))
ck(r["source"] == "llm", 'italian-restaurant question answered by the model')
ncalls = len(calls)
r = A.answer("بهترین رستوران چینی شهر", ctx("g10"))
ck(r["source"] == "llm" and len(calls) == ncalls + 1, 'one swapped word (0.6 similarity) misses')
A.cache_store("متن آزمایشی تعرفه", ctx("g10"), None, "ans", [], "plans", "fast", 10)
ck(A.cache_lookup("متن آزمایشی تعرفه", ctx("g10"), None, "orders") is None, 'rule-hint/intent mismatch misses')
ck(A.cache_lookup("متن آزمایشی تعرفه", ctx("g10"), None, "plans")["text"] == "ans", 'matching hint hits')

db.set_settings({"ai_guest_model": "0"})   # v259: سوییچ برمی‌گردد به پیش‌فرض خاموش

# ---- 7. stats, panel, clear, backup exclusion
st = A.cache_stats()
ck(st["rows"] == 500 and st["hits"] >= 1 and st["saved"] > 0, f'stats: rows/hits/tokens-saved ({st})')
import views_panel2 as P
html = P.assistant_page(db.get_settings(), "tok", {})
ck("کش پاسخ‌های پرتکرار" in html and "cache_clear" in html, 'panel shows cache stats + clear button')
A.cache_clear()
ck(A.cache_stats() == {"rows": 0, "hits": 0, "saved": 0}, 'cache_clear empties everything')
ck("ai_cache" not in db.export_all(), 'transient cache excluded from backups')

print(f"v220: {n} checks passed")
