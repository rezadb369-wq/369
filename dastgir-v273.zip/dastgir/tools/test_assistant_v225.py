#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v225 «ابزارهای ثبت نوبت و نظر» — same safe pattern as v223.

book: Jalali date + 24h time, booking_on shops only, the verified account
phone, login + «بله» gated. review: text-only (stars live on the site form),
self-reviews blocked, moderated-or-not message matches the setting.
"""
import os, sys, tempfile, json, datetime
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v225-')
os.environ['BZ_DATA_DIR'] = TMP
for k in ('AI_BASE_URL', 'AI_API_KEY', 'AI_MODEL', 'AI_MODEL_SMART', 'AI_FALLBACK_BASE_URL', 'AI_FALLBACK_API_KEY', 'AI_FALLBACK_MODEL'):
    os.environ.pop(k, None)
sys.path.insert(0, str(ROOT / 'server')); sys.path.insert(0, str(ROOT / 'tools'))
import db, assistant as A
from layout import g2j
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
db.set_settings({"ai_quota_free": "100"})
own = db.owner_by_phone("09120000101", create=True)
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id,booking_on) VALUES(?,?,?,?,?,?)",
            ("book-shop", "آرایشگاه ابزار", "services", "published", own["id"], 1))
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id,booking_on) VALUES(?,?,?,?,?,?)",
            ("off-shop", "مغازه تعطیل", "services", "published", own["id"], 0))
con.commit(); con.close()
biz = db.business(slug="book-shop")
cust = db.customer_by_phone("09120000102", create=True)
db._run("UPDATE customers SET name='کیان ابزار' WHERE id=?", (cust["id"],))
cust = db._one("SELECT * FROM customers WHERE id=?", (cust["id"],))
noname = db.customer_by_phone("09120000103", create=True)
selfc = db.customer_by_phone(own["phone"], create=True)   # same phone as the owner
ckey = f"cust:{cust['id']}"
ctx = {"channel": "web", "user_key": ckey, "customer": cust, "owner": None}

t = datetime.date.today()
jy, jm, jd = g2j(t.year, t.month, t.day)
VALID = f"{jy + 1}/03/15"
PAST = f"{jy - 1}/03/15"
leap = next(Y for Y in range(jy + 1, jy + 9) if g2j(Y + 622, 3, 20) == (Y, 12, 30))
common = next(Y for Y in range(jy + 1, jy + 9) if g2j(Y + 622, 3, 20) != (Y, 12, 30))
TODAY_J = f"{jy:04d}/{jm:02d}/{jd:02d}"

# ---- 1. strict parsing for the new tools
ck(A.parse_tool_call({"name": "book", "args": {"slug": "a", "date": "1", "time": "2", "name": "ن"}}) ==
   ("book", {"slug": "a", "date": "1", "time": "2", "name": "ن"}), 'book parses')
ck(A.parse_tool_call({"name": "book", "args": {"slug": "a", "date": "1", "time": "2"}})[1]["name"] == "", 'book name optional')
for junk in ({"name": "book", "args": {"slug": "a", "date": "1"}}, {"name": "book", "args": {"slug": "a b", "date": "1", "time": "2"}},
             {"name": "book", "args": {"slug": "a", "date": "", "time": "2"}}, {"name": "book", "args": "x"},
             {"name": "review", "args": {"slug": "a", "body": ""}}, {"name": "review", "args": {"slug": "a", "body": "x" * 2001}},
             {"name": "review", "args": {"slug": "a"}}, {"name": "review", "args": {}},
             {"name": "hack", "args": {}}, None, "x"):
    assert A.parse_tool_call(junk) == (None, {}), junk
ck(True, 'malformed book/review/unknown rejected')
ck(A.parse_tool_call({"name": "review", "args": {"slug": "a", "body": " خوب "}}) == ("review", {"slug": "a", "body": "خوب"}), 'review parses, body stripped')
ck(A.parse_answer_json('{"answer":"x","tool_call":{"name":"book","args":{"slug":"s","date":"d","time":"t"}}}')["tool_call"]["name"] == "book", 'answer parser passes book through')

# ---- 2. Jalali + time normalization
ck(A._norm_jalali(f"{jy + 1}/3/5") == f"{jy + 1:04d}/03/05", 'unpadded date normalized')
fa_in = f"{jy + 1}-۳-۵".replace("0", "۰").replace("1", "۱").replace("2", "۲").replace("3", "۳").replace("4", "۴").replace("5", "۵").replace("6", "۶").replace("7", "۷").replace("8", "۸").replace("9", "۹")
ck(A._norm_jalali(fa_in) == f"{jy + 1:04d}/03/05", 'Persian digits + dashes normalized')
ck(A._norm_jalali(VALID) == f"{jy + 1:04d}/03/15" and A._norm_jalali(TODAY_J) == TODAY_J, 'future + today accepted')
for bad in (PAST, f"{jy + 1}/13/01", f"{jy + 1}/06/32", f"{jy + 1}/07/31", f"{common}/12/30",
            f"{jy + 1}/12/31", "2026-09-15", "1500/01/01", "12/30", "فردا", "", None):
    assert A._norm_jalali(bad) == "", bad
ck(True, 'past / impossible / Gregorian / garbage dates rejected')
ck(A._norm_jalali(f"{leap}/12/30") == f"{leap:04d}/12/30", 'Esfand 30 in a leap year accepted')
ck(A._norm_time("9:30") == "09:30" and A._norm_time("۱۷:۳۰") == "17:30" and A._norm_time("00:00") == "00:00", 'times normalized')
for bad in ("24:00", "10:60", "10 صبح", "9", "", None):
    assert A._norm_time(bad) == "", bad
ck(True, 'bad times rejected')

# ---- 3. book flow
calls = []
def fake_chat(base, key, model, messages, timeout, max_tokens=220):
    calls.append(1)
    q = str(messages[-1].get("content") or "")
    tc = None
    if "BOOK-OK" in q: tc = {"name": "book", "args": {"slug": "book-shop", "date": VALID, "time": "10:00"}}
    elif "BOOK-NAMED" in q: tc = {"name": "book", "args": {"slug": "book-shop", "date": VALID, "time": "11:00", "name": "نام همراه"}}
    elif "BOOK-PAST" in q: tc = {"name": "book", "args": {"slug": "book-shop", "date": PAST, "time": "10:00"}}
    elif "BOOK-BADTIME" in q: tc = {"name": "book", "args": {"slug": "book-shop", "date": VALID, "time": "25:00"}}
    elif "BOOK-NOBOOK" in q: tc = {"name": "book", "args": {"slug": "off-shop", "date": VALID, "time": "10:00"}}
    elif "BOOK-NOBIZ" in q: tc = {"name": "book", "args": {"slug": "nope", "date": VALID, "time": "10:00"}}
    elif "REV-OK" in q: tc = {"name": "review", "args": {"slug": "book-shop", "body": "عالی بود، ممنون از برخورد خوبتان"}}
    elif "REV-SELF" in q: tc = {"name": "review", "args": {"slug": "book-shop", "body": "مغازه خودم عالیه"}}
    elif "REV-NOBIZ" in q: tc = {"name": "review", "args": {"slug": "nope", "body": "x"}}
    elif "REV-EMPTY" in q: tc = {"name": "review", "args": {"slug": "book-shop", "body": "  "}}
    elif "REV-LONG" in q: tc = {"name": "review", "args": {"slug": "book-shop", "body": "ن" * 600}}
    return json.dumps({"answer": "مدل.", "links": [], "scope": True, "intent": "booking", "tool_call": tc}, ensure_ascii=False), 10
A._chat = fake_chat
os.environ.update(AI_BASE_URL="https://api.example.invalid/v1", AI_API_KEY="test-key-not-real", AI_MODEL="fake-lite")
# v269 (دستور مدیر: هوش سایت جدا از محیط مدیر): چت کاربران از
# اسلات مستقل AI_SITE_* می‌خواند.
os.environ.update(AI_SITE_BASE_URL="https://site.example.invalid/v1",
                  AI_SITE_API_KEY="test-site-key-not-real",
                  AI_SITE_MODEL="site-model")

r = A.answer("BOOK-OK لطفا", ctx)
ck("⚠️" in r["text"] and "آرایشگاه ابزار" in r["text"] and "به نام کیان ابزار" in r["text"], 'book proposal names biz + account name')
ck("۱۰:۰۰" in r["text"], 'time shown in Persian digits')
ck(A.pending_get(ckey)["tool"] == "book", 'pending stored')
ck(db._one("SELECT COUNT(*) c FROM bookings WHERE customer_id=?", (cust["id"],))["c"] == 0, 'nothing written before confirm')
ou0, cu0 = db.owner_unread(own["id"]), db.notifications_unread(cust["id"])
r = A.answer("بله", ctx)
ck("ثبت شد" in r["text"] and r["intent"] == "confirm", '«بله» books it')
row = db._one("SELECT * FROM bookings WHERE customer_id=?", (cust["id"],))
ck(row["phone"] == cust["phone"] and row["date"] == f"{jy + 1:04d}/03/15" and row["time"] == "10:00" and row["status"] == "new", 'row uses the verified phone + normalized date/time')
ck(db.owner_unread(own["id"]) == ou0 + 1 and db.notifications_unread(cust["id"]) == cu0 + 1, 'owner + customer notified')
ck("assistant_tool" in [a["action"] for a in db._rows("SELECT action FROM audit")] and A.pending_get(ckey) is None, 'audited, pending consumed')
r = A.answer("BOOK-NAMED لطفا", ctx); A.answer("بله", ctx)
ck(db._one("SELECT name n FROM bookings WHERE time='11:00'")["n"] == "نام همراه", 'explicit name arg wins over the account name')

nctx = {"channel": "web", "user_key": f"cust:{noname['id']}", "customer": noname, "owner": None}
r = A.answer("BOOK-OK لطفا", nctx)
ck("اسمتان" in r["text"] and A.pending_get(f"cust:{noname['id']}") is None, 'nameless account asked for a name, no pending')
ck("تاریخ شمسی" in A.answer("BOOK-PAST لطفا", ctx)["text"], 'past date explained')
ck("۲۴ساعته" in A.answer("BOOK-BADTIME لطفا", ctx)["text"], 'bad time explained')
ck("نوبت نمی‌پذیرد" in A.answer("BOOK-NOBOOK لطفا", ctx)["text"], 'booking_off shop refused')
ck("پیدا نکردم" in A.answer("BOOK-NOBIZ لطفا", ctx)["text"], 'unknown shop refused')
r = A.answer("BOOK-OK لطفا", {"channel": "web", "user_key": "guest9", "customer": None, "owner": None})
ck("/login" in [h for _, h in r["links"]], 'guest gets the login nudge')
ncalls = len(calls)
A.answer("BOOK-OK لطفا تکراری", ctx); A.answer("BOOK-OK لطفا تکراری", ctx)
ck(len(calls) == ncalls + 2, 'book answers never cached')

# ---- 4. review flow
db.set_settings({"reviews_moderated": "1"})
r = A.answer("REV-OK لطفا", ctx)
ck("⚠️" in r["text"] and "عالی بود" in r["text"], 'review proposal quotes the exact text')
r = A.answer("بله", ctx)
ck("پس از تأیید" in r["text"], 'moderated message matches the setting')
rev = db._one("SELECT * FROM reviews WHERE customer_id=?", (cust["id"],))
ck(rev["rating"] == 0 and rev["body"] == "عالی بود، ممنون از برخورد خوبتان" and rev["author"] == "کیان ابزار" and rev["status"] == "pending", 'text-only pending review stored')
ck(db._one("SELECT COUNT(*) c FROM owner_notifications WHERE kind='social'")["c"] == 1, 'owner notified about the review')
db.set_settings({"reviews_moderated": "0"})
A.answer("REV-OK دوباره", ctx); r = A.answer("بله", ctx)
ck("نمایش داده شد" in r["text"] and db._one("SELECT status s FROM reviews ORDER BY id DESC LIMIT 1")["s"] == "approved", 'unmoderated review approved at once')
sctx = {"channel": "web", "user_key": f"cust:{selfc['id']}", "customer": selfc, "owner": None}
ck("خودتان" in A.answer("REV-SELF لطفا", sctx)["text"], 'self-review blocked')
ck("پیدا نکردم" in A.answer("REV-NOBIZ لطفا", ctx)["text"], 'review for unknown shop refused')
r = A.answer("REV-EMPTY لطفا", ctx)
ck("⚠️" not in r["text"] and A.pending_get(ckey) is None, 'empty body silently dropped, no pending')
A.answer("REV-LONG لطفا", ctx); A.answer("بله", ctx)
ck(db._one("SELECT LENGTH(body) l FROM reviews ORDER BY id DESC LIMIT 1")["l"] == 600, '600-char body survives the pending round-trip intact')
r = A.answer("REV-OK لطفا", {"channel": "web", "user_key": "guest9", "customer": None, "owner": None})
ck("/login" in [h for _, h in r["links"]], 'guest review → login nudge')
ck("book" in A.ANSWER_PROMPT and "review" in A.ANSWER_PROMPT and "شمسی" in A.ANSWER_PROMPT and "بدون ستاره" in A.ANSWER_PROMPT, 'prompt documents the new tools + formats')

print(f"v225: {n} checks passed")
