#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v248: «ابزار پیشنهادی معتبر شناخته نشد» root-caused and self-repaired.

The message meant: the model DID propose a tool but invented its NAME or
mis-shaped its ARGS (edit_code, read_file, old/new at top level, …) — not
a file-reading problem (the server always reads files). This version
repairs such calls automatically:
  name: exact → alias table → token-set swap (save_post↔post_save) →
        close spelling (difflib ≥0.8)
  args: file→path, top-level old/new→edits, start/end→from/to_line,
        q/term→query, dir→path, name→key, val→value
Unrepairable calls now name the tool in the owner-facing message.
"""
import os, sys, json, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v248-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
SCRIPT = []
def fake_chat(*a, **k):
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]
yes = lambda: t('بله')
def P(tool, args):
    return json.dumps({"reply": "ok", "tool": {"name": tool, "args": args}},
                      ensure_ascii=False)
def jobs():
    d = os.path.join(TMP, 'code-jobs')
    return [json.load(open(os.path.join(d, x), encoding='utf-8'))
            for x in sorted(os.listdir(d))] if os.path.isdir(d) else []

heading = next(ln for ln in (ROOT / 'README.md').read_text(encoding='utf-8').split('\n')
               if ln.startswith('# '))

# ================= 1. name repair unit checks
NT = CT.normalize_tool_name
for invented, canonical in [
        ("read_file", "code_read"), ("edit_code", "code_edit"),
        ("editFile", "code_edit"), ("search_code", "code_search"),
        ("list_files", "code_list"), ("ls", "code_list"),
        ("save_post", "post_save"), ("delete_post", "post_delete"),
        ("code_edt", "code_edit"), ("CODE_READ", "code_read"),
        ("restart", "service_restart"), ("save_setting", "setting"),
        ("block_customer", "customer_moderate"), ("find_text", "code_search")]:
    ck(NT(invented) == canonical, f'name repair: {invented} → {canonical}')
ck(NT("format_disk") is None, 'unknown junk name stays unknown')
ck(NT("") is None and NT(None) is None, 'empty name stays None')
ck(NT("rm -rf") is None, 'shell-ish name not magically mapped')

# ================= 2. arg repair unit checks
name, a = CT.parse_tool_call({"name": "code_edit", "args": {
    "path": "README.md", "old": heading, "new": heading + " X"}})
ck(name == "code_edit" and a["edits"][0]["old"] == heading,
   'top-level old/new wrapped into edits')
name, a = CT.parse_tool_call({"name": "code_read", "args": {"file": "README.md"}})
ck(name == "code_read" and a["path"] == "README.md" and a["from_line"] == 1,
   'file→path + default range')
name, a = CT.parse_tool_call({"name": "code_search", "args": {"q": "دست گیر"}})
ck(name == "code_search" and a["query"] == "دست گیر", 'q→query')
name, a = CT.parse_tool_call({"name": "code_list", "args": {"dir": "docs"}})
ck(name == "code_list" and a["path"] == "docs", 'dir→path')

# ================= 3. E2E: weak model uses «edit_code» + old/new — repaired
SCRIPT.append(P('edit_code', {"path": "README.md",
                              "old": heading, "new": heading + " (تست)"}))
r = t('عنوان را در کد عوض کن')
ck('معتبر شناخته نشد' not in r, 'invented name no longer rejected')
ck('🛠 تغییر کد به صف استقرار رفت' in r and 'تأیید می‌کنی' not in r,
   'v268: edit_code repaired → real code_edit executed')
yes()
ck(any(j['kind'] == 'code_edit' and j['path'] == 'README.md' for j in jobs()),
   'v268: repaired call queued at once')

# ================= 4. E2E: read_file repaired → immediate read (no «بله»)
SCRIPT.append(P('read_file', {"file": "README.md", "start": 1, "end": 5}))
r = t('اول این فایل را نشانم بده')
ck('README.md' in r and '1|' in r and 'تأیید' not in r,
   'read_file → code_read runs immediately with repaired args')

# ================= 5. unrepairable name → specific, honest message
SCRIPT.append(P('time_travel', {"target": "yesterday"}))
r = t('زمان را به عقب ببر')
ck('معتبر شناخته نشد' in r and '«time_travel»' in r,
   'unrepairable call names the tool it rejected')

# ================= 6. security pins still hold after repair
name, _ = CT.parse_tool_call({"name": "edit_code",
                              "args": {"path": "server/adminbot.py",
                                       "old": "x", "new": "y"}})
ck(name is None, 'locked path refused at parse (name repair unlocks nothing)')
SCRIPT.append(P('edit_code', {"path": "server/adminbot.py",
                              "old": "import", "new": "import2"}))
r = t('مغز بات را عوض کن')
ck('قفل' in r and 'درست بود ولی اجرا نشد' in r,
   'locked-path call rejected with a visible, honest notice (v250)')
SCRIPT.append(P('save_setting', {"name": "owner_token", "value": "x"}))
r = t('توکن مالک را عوض کن')
ck('🔑 توکن تازهٔ ورود ذخیره شد' in r,
   'v265+v268: repaired secret-key call executed (name→key repair + full access)')

# ================= 7. prompt + old suites' phrase intact
ck('عیناً از همین فهرست بنویس' in AI.ADMIN_PROMPT, 'prompt demands exact tool names')
ck('معتبر شناخته نشد' in
   json.dumps([t for t in ['معتبر شناخته نشد']], ensure_ascii=False), 'phrase kept for old suites')

print(f'v248 self-repairing tool calls: {n} checks green')
