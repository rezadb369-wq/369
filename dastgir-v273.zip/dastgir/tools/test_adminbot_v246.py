#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v246: root-cause fix for «می‌گه اجرا شد، آخر می‌گه نشد».

Investigation findings this version is built on (simulated with a real
weak model through the REAL pipeline):
  P2: model answers «حتماً انجام می‌دهم!» with NO tool → the bot used to
      pass the lie through and nothing happened.  ← the user's bug.
  P3/P4: wrong tool name / broken args → bare notice, no progress.
  P5: raw text (no JSON) → passed through, no action.
  P6: tool sent as a JSON *string* → dropped.

Fix: the SERVER is now the agent (autopilot): search → pick file → read a
small region → ask the model only for the tiny old→new edit (JSON or even
fenced blocks) → fuzzy-resolve → the usual «بله» wall. Plus lenient parse,
context diet, a no-tool success-claim guard, and keyless «کجاست» answers.
"""
import os, sys, json, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v246-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT, adminbot_code as CODE
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
SCRIPT, CALLS = [], []
def fake_chat(*a, **k):
    CALLS.append(1)
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]
yes = lambda: t('بله')

# fixture file inside the editable tree (removed at the end)
FIX = ROOT / 'docs' / 'ap-fix-v246.js'
FIX.write_text('const AUTOPILOT_X = "old";\n'
               '// دکمهٔ جادویی اینجاست\n'
               'function magic(){ return 1; }\n', encoding='utf-8')
try:
    # ================= 1. THE user's bug: model promises, no tool → autopilot
    CALLS.clear(); SCRIPT.clear()
    SCRIPT.append(json.dumps({"reply": "بله حتماً، الان انجامش می‌دهم!", "tool": None},
                             ensure_ascii=False))
    SCRIPT.append(json.dumps({"old": 'const AUTOPILOT_X = "old";',
                              "new": 'const AUTOPILOT_X = "new";'}, ensure_ascii=False))
    r = t('متغیر AUTOPILOT_X را در کد تغییر بده')
    ck(len(CALLS) == 2, 'weak model + autopilot = exactly 2 model calls')
    ck('می‌دهم' not in r, 'the empty promise never reaches the owner')
    ck('🛠 تغییر کد به صف استقرار رفت' in r and 'تأیید می‌کنی' not in r,
       'v268: autopilot edit executes at once')
    _cd = os.path.join(TMP, 'code-jobs')
    _job = json.load(open(os.path.join(_cd, sorted(os.listdir(_cd))[-1]), encoding='utf-8'))
    ck(_job['edits'][0]['old'] == 'const AUTOPILOT_X = "old";',
       'the edit quotes the exact file text')
    ck(_job['kind'] == 'code_edit' and _job['path'] == 'docs/ap-fix-v246.js',
       'v268: queued for the root guard without «بله»')

    # ================= 2. mini-model answers with fenced blocks instead of JSON
    CALLS.clear(); SCRIPT.clear()
    SCRIPT.append('باشه این کار را انجام می‌دهم')          # raw text, no JSON
    SCRIPT.append('```js\nconst AUTOPILOT_X = "old";\n```\n```js\nconst AUTOPILOT_X = "v2";\n```')
    r = t('متغیر AUTOPILOT_X را در کد تغییر بده')
    ck('🛠 تغییر کد به صف استقرار رفت' in r, 'fenced old/new blocks accepted from a weak brain')

    # ================= 3. mini-model is useless twice → honest failure
    CALLS.clear(); SCRIPT.clear()
    SCRIPT.append('نمی‌دانم چطور.')                        # main: useless, no tool
    SCRIPT.append('نمی‌دانم')                              # mini try 1
    SCRIPT.append('باز هم نمی‌دانم')                       # mini try 2
    r = t('متغیر AUTOPILOT_X را در کد تغییر بده')
    ck(len(CALLS) == 3, 'mini edit asked twice, then gave up')
    ck('پیدا کردم' in r and '/کلید' in r, 'honest failure: found the spot, admits the brain failed')
    ck('تأیید می‌کنی' not in r, 'no fake confirmable proposal on failure')

    # ================= 4. «کجاست» answered deterministically (no edit model)
    CALLS.clear(); SCRIPT.clear()
    SCRIPT.append(json.dumps({"reply": "بگذار بگردم…", "tool": None}, ensure_ascii=False))
    r = t('«دکمهٔ جادویی» در کد کجاست؟')
    ck('docs/ap-fix-v246.js' in r and ':' in r, 'locate answered with file:line')
    ck('تأیید می‌کنی' not in r, 'locate never proposes an edit')

    # ================= 5. keyless bot still answers «کجاست»
    _cfg = AI.configured
    AI.configured = lambda: False
    r = t('«دکمهٔ جادویی» کجاست؟')
    ck('docs/ap-fix-v246.js' in r, 'keyless locate works (server-side search only)')
    r = t('متغیر AUTOPILOT_X را تغییر بده')
    ck('/کلید' in r, 'keyless change request teaches the key fix')
    AI.configured = _cfg

    # ================= 6. strong-model path untouched (tool on first try)
    CALLS.clear(); SCRIPT.clear()
    SCRIPT.append(json.dumps({"reply": "می‌خوانم",
                              "tool": {"name": "code_read",
                                       "args": {"path": "docs/ap-fix-v246.js",
                                                "from_line": 1, "to_line": 3}}},
                             ensure_ascii=False))
    SCRIPT.append(json.dumps({"reply": "این فایل کوچک است.", "tool": None},
                             ensure_ascii=False))
    r = t('فایل تست را بخوان')
    ck(len(CALLS) == 2 and 'ap-fix-v246.js' in r, 'strong path: read tool works, no autopilot')

    # ================= 7. lenient parse (P6): tool as a JSON string
    CALLS.clear(); SCRIPT.clear()
    SCRIPT.append('{"reply": "ok", "tool": "{\\"name\\": \\"code_status\\", \\"args\\": {}}"}')
    r = t('جریان استقرار کد چطوره؟')
    ck('صف استقرار' in r, 'tool-as-string now parsed (used to be dropped)')

    # ================= 8. no-tool success-claims get the honesty stamp
    CALLS.clear(); SCRIPT.clear()
    SCRIPT.append(json.dumps({"reply": "انجام شد! رنگ فوتر عوض شد.", "tool": None},
                             ensure_ascii=False))
    r = t('متن فوتر را در تنظیمات عوض کن')
    ck('هیچ تغییری اجرا نشده' in r, 'a bare «انجام شد» gets the honesty warning')

    # ================= 9. context diet
    snap = A.admin_snapshot()
    ck(len(snap) <= 7000, f'snapshot capped at 7000 (now {len(snap)})')
    CODE._side_save('docs/ap-fix-v246.js', 1, 3, 'x' * 9000)
    ctx = CODE.code_context()
    ck(len(ctx) <= 2800, f'code context capped (~2400+header; now {len(ctx)})')

    # ================= 10. unit checks
    ck(AI.code_change_intent('رنگ دکمهٔ خرید را عوض کن'), 'code intent detected')
    ck(not AI.code_change_intent('متن صفحهٔ درباره را عوض کن'),
       'content request NOT hijacked by the autopilot')
    ck(AI.mine_query('«دکمهٔ جادویی» را سبز کن') == 'دکمهٔ جادویی',
       'quoted phrase mined as the query')
    ck(AI.mine_query('متغیر AUTOPILOT_X را تغییر بده') == 'AUTOPILOT_X',
       'latin token mined')
    o, nw = AI._extract_edit('blah ```js\nAAA\n``` more ```js\nBBB\n``` end')
    ck(o == 'AAA' and nw == 'BBB', 'fence extraction')
    o, nw = AI._extract_edit('old: AAA\nnew: BBB')
    ck(o == 'AAA' and nw == 'BBB', 'old:/new: extraction')
    ck(AI._extract_edit('نمی‌دانم') == (None, None), 'garbage → no edit')
    ck(not [h for h in CODE.search_hits('owner_chat') if h[0] == 'server/adminbot.py'],
       'search still never leaks locked files')

    print(f'v246 autopilot redesign: {n} checks green')
finally:
    FIX.unlink(missing_ok=True)
