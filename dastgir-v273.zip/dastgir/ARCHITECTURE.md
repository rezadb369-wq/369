# ARCHITECTURE — دست گیر (v271)

نقشهٔ ساختمان برای هر کس که می‌خواهد کد را بفهمد یا دست بزند.
تاریخ به‌روزرسانی: v112 — همراه `WHATS-NEW.md` و `HANDBOOK.md`.

---

## ۱) نمای کلی

- **پشته:** پایتون ۳ خالص (`http.server` سفارشی‌شده) + SQLite + HTML/CSS/JS دست‌نویس.
  **صفر وابستگی** — روی Pydroid 3 اندروید هم اجرا می‌شود.
- **داده:** یک فایل `data/bazarche.db` با ۵۷ جدول + ۶ آبجکت FTS (businesses, items, reviews, chat,
  orders, tickets, favorites, haggles, ads, visits, shield_events, …) + پوشهٔ `data/uploads/`.
- **ورودی اجرا:** `run.py` → `server/app.py` (`serve_forever` روی `0.0.0.0:8080`،
  `ThreadingHTTPServer`).
- **حالت‌های اجرا:** پیش‌فرض / `seed_demo` / `strict` (حلقه‌محور بی‌شبکه برای باتری تست).

## ۲) مسیر یک درخواست

```
مرورگر → Handler (app.py)
  1) server/shield.py      سپر: rate limit / اسکنر / UA مخرب → 429/404/403
  2) app.py route          مسیرها: /robots.txt, /sitemap, static, /api/*, صفحات
  3) app.py auth           کلید پنل (query/path/keyfile) · سشن (HMAC cookie) · OTP
  4) db.rate_ok            سهمیهٔ per-action (کامنت/پیام/…) در لایه داده
  5) views_*.py            HTML سرور-رندر با server/ui.py (کروم + کروم‌هدر CSS توکن)
  6) db.py                 SQLite (WAL) — تنها نقطهٔ تماس با داده
```

## ۳) ماژول‌ها (`server/`)

| فایل | خطوط | نقش |
|---|---|---|
| `app.py` | ~3520 | HTTP handler، مسیریابی، auth/سشن، آپلود، robots/sitemap، روتر API |
| `db.py` | ~5470 | لایهٔ داده: ۶۳ جدول، CRUD، `rate_ok`، `sparkline_svg`، مایگریشن‌ها |
| `features.py` | ~1160 | زیرسیستم‌های چندجدولی: چت، سفارش، تیکت، علاقه‌مندی، چانه، تیک‌ها |
| `ui.py` | ~1180 | کروم عمومی، منوی پایین، کروم‌هدر `<style>` توکن روز، بامپ `?vNNN` |
| `views_public.py` / `public2` | ~1570/~960 | خانه، جستجو، دسته، شهر، صفحهٔ کسب‌وکار، محصول |
| `views_catalog.py` | ~630 | کاتالوگ/مقایسه/کشف |
| `views_chat.py` / `customer` | ~220/~510 | چت و پنل مشتری |
| `views_owner.py` | ~1680 | پنل دکان‌دار کامل |
| `views_panel.py` / `panel2` | ~1400/~2070 | پنل مالک (از جمله `/panel/traffic` سپر) |
| `views_extra.py` | ~150 | صفحه‌های ریز (درباره/تماس/offline) |
| `shield.py` | 148 | سپر ضد-اسپم v112 (rate، اسکنر، UA، مسدودسازی) |
| `analytics.py` | ~330 | v114 آمار بازدید واقعی: IP/دستگاه/bz_cid/نشست، فیلتر بات، گزارش پنل، GA4 در ui.py |
| `uploads.py` / `sms.py` / `qr.py` | ~550/~110/~270 | فایل (EXIF-strip)، کد یک‌بارمصرف، QR |
| `assistant.py` | ~2100 | مغز گفت‌وگو: چت عمومی (پرامپت آزاد)، کاپیلوت مدیر، زنجیرهٔ fallback، بودجه/کاهش‌هزینه |
| `bale.py` / `soroush.py` | ~600/~450 | رابط webhook پیام‌رسان‌ها (ورود، منو، اعلان) |
| `bot_menu.py` / `bot_register.py` | ~800/~700 | منوی مشترک حساب‌آگاه + ثبت‌نام/چرخهٔ عمر در بات |
| `adminbot.py` | ~1250 | بات مدیر: گزارش، سلامت، دستور «تشخیص»، دیسپچ، اجرای فوری AI + «بله» فقط دستورهای مستقیم |
| `adminbot_content.py` | ~1500 | ابزارهای محتوای پنل + اعتبارسنجی/ترمیم فراخوانی + دلیل‌های رد شدن |
| `adminbot_code.py` | ~500 | لاین کد: خواندن/ویرایش/نوشتن/برگشت با مسیرهای قفل و اعمال از راه دور |

**زیرسیستم هوش مصنوعی و استقرار:** کلیدها فقط از `/etc/dastgir-secrets.env` خوانده
می‌شوند؛ انبار ۹خطی `deploy/brain.env` با دستور صریح مدیر داخل بسته است
(۵ کلید مغز مدیر + timeout + ۳ خط اسلات مستقل هوش عمومی سایت `AI_SITE_*` از
v269 — جایگزینی کامل `AI_*` قبلی + فعال‌شدن خودکار حین نصب). **v269 (دستور
مدیر: محیط‌ها جدا):** چت عمومی کاربران فقط از `AI_SITE_*` می‌خواند
(`site_config()` در `assistant.py`؛ تک‌مدل، سوئیچ مدل با تنظیم `ai_site_model`)
و `admin_answer`/`admin_agent` فقط از ۵ مغز مدیر (`config()`) — بدون fallback
دوطرفه؛ تعویض کلید سایت با `/کلید سایت` و مدلش با «مدل سایت» (تست زنده)،
کلیدهای مدیر با `/کلید` و `/مغز`. توکن فقط برای کاربران واردشده و بات مدیر
است (دروازهٔ مهمان `degraded=login` + سوییچ `ai_guest_model`)؛ مدیرتیم با
`BALE_ADMIN_CHAT` کاما-جدا. کرون `/etc/cron.d/dastgir-codeguard` صف
`data/code-jobs/` را با `deploy/codeguard.sh` اعمال می‌کند (بکاپ →
کامپایل‌چک → سلامت → رسید/برگشت؛ کلید site در اسلات `AI_SITE_*` می‌نشیند و
`AI_BRAIN_*` دست‌نخورده می‌ماند) و `deploy/apply-brain.sh` مغزِ
`deploy/brain.env` را جایگزین کامل می‌کند.

**v270 (دستور مدیر: حافظهٔ کوتاه + نظارت):** حافظهٔ گفت‌وگوی کاربر در
`ai_threads` فقط ۱۰ دقیقه می‌ماند (`THREAD_TTL = 600`؛ پیش‌تر ۴۸ ساعت) — هم
پنجرهٔ پرامپت و هم ماندگاری از همان ثابت می‌خوانند. جدا از آن، `chat_log()`
هر تبادل چت عمومی را در `data/site_chats.log` به‌صورت JSONL ثبت می‌کند
(`ts/when/channel/user/q/a/source/model/intent`) در هر چهار مسیر بازگشت
`answer()`؛ `user` کلید ساختگی است و `ip:*` به `guest` ماسک می‌شود. مدیر فایل
را با «چت‌ها» در بات مدیر می‌گیرد — `send_document()` مولتی‌پارت تازه، چون
`_call` فقط JSON می‌فرستاد. توجه: `_cmd_of` تنها واژهٔ اول را می‌گیرد، پس
میان‌برهای چندواژه‌ای با متن کامل تطبیق داده می‌شوند.

**v271 (دستور مدیر: گزینهٔ دیده‌شدنی):** دو ردیف تازه در `KEYBOARD`
(`هوش سایت`/`کلیدها`/`چت‌ها`) + `SITE_KEYBOARD` (سوئیچ مدل سایت با یک
ضربه، همان دروازهٔ تست زندهٔ `do_sitemodel`) + `KEY_KEYBOARD` (شش اسلات
کلید؛ pending با `action=key_for` کلید لخت بعدی را به `do_ai_key` با
اسلات صریح می‌دهد). رفع ریشه‌ای: `CODE.parse` تا v270 اسلات `muse` را دور
می‌انداخت. سمت وب، `assist.js` تایمر ۱۰ دقیقه‌ای حافظهٔ چت را نشان می‌دهد
(۶۰۰۰۰۰ms — هم‌اندازهٔ `THREAD_TTL`) و در انقضا تاریخچهٔ کلاینت را پاک
می‌کند.

**قوانین معماری:** نماها هرگز مستقیم SQL نمی‌زنند (فقط `db.` و `features.`) ·
هیچ import غیر-استانداردی مجاز نیست (نگهبان: `tools/test_open.py`) ·
HTML در پایتون ساخته می‌شود؛ JS فقط رفتار، نه داده.

## ۴) سیستم تم (v111 «رسمی»)

```
site/assets/css/
  tokens.css      همهٔ توکن‌های معنایی: :root (روز) + [data-theme] (شب)
  main.css        ساختار/کامپوننت‌ها — بی‌رنگ‌های هاردکد؛ zoom نقشه هم اینجاست
  pages.css       صفحه‌های خاص (از جمله رنگ .spark از توکن)
  theme-night.css فقط توکن/استثنای کنتراست شب (guard: test_appearance)
  theme-light.css فقط توکن روز
```
- رنگ‌های روز در کروم‌هدر از توکن‌های `ui.py` تزریق می‌شوند تا بدون فایل خارجی هم کامل باشد.
- رنگ مالک (تنظیمات پنل) فقط توکن‌های **روز** را بازمی‌نویسد.
- سلسله‌مراتب تغییر رنگ: توکن → main/pages → theme-*. رنگ خام در ویوها ممنوع.
- نگهبان‌ها: `tools/contrast_audit.py` (AA هر دو تم، متن واقعی صفحات) و
  `tools/test_appearance.py` (توکن‌های ضروری، ممنوعیت override ساختاری، fade،
  prefers-reduced-motion، حداقل ۱۲px).

## ۵) لایه‌های امنیت

۱. **سپر (shield.py):** نخستین لایهٔ هر درخواست — آستانه‌های `BZ_SHIELD_*`؛
رخدادها در جدول `shield_events` + نمودار `/panel/traffic`.
۲. **Auth:** پنل = کلید+رمز (PBKDF2)؛ مشتری/دکان‌دار = سشن HMAC؛ OTP سهمیه‌دار.
۳. **rate_ok:** سهمیهٔ معنایی هر کنش در `db.py` (مثلاً ۳ کامنت/ساعت/IP).
۴. **محتوا:** HTML-escape همه‌جا، EXIF-strip، مجوز فایل چت قبل از سرو،
`Content-Security-Policy` هدر.

## ۶) سرویس‌ورکر و کش

`site/sw.js` — `VERSION='bz-v112'`؛ کش پوسته با استراتژی network-first برای HTML و
cache-first برای assets. **هر تغییر asset ⇒ بامپ `?vNNN` در `ui.py` و `VERSION`
در `sw.js`** وگرنه کاربران قدیمی CSS کهنه می‌بینند.

## ۷) نقشهٔ تست (۱۰۱ مجموعه در `tools/`)

- هسته: `test_all` (۱۴۷)، `test_v3` (۱۵۳)، `test_open_parity` (۵۲۵).
- زیرسیستم: chat_v73, favorites_v74, haggle, isolation, tickets, actions, gates,
  trash, discovery, onboarding, admin_extras, analytics, prices, remaining_v76, section1,
  section4_v75, context, open, v3_owner, v68, v69.
- کیفیت UI: `test_browser` (Playwright: a11y@1440، ۱۱ عرض، تعاملات)،
  `test_appearance`، `contrast_audit`.
- پنل (v117): `test_panel_security` (43)، `test_panel_robust` (16)،
  `test_panel_ux` (32)، `test_panel_mod` (28)، `bench_panel`،
  `mobile_audit` (۲۴ صفحه × ۴ دستگاه).
- داده/حریم خصوصی (v117 فاز ۶): `test_geoip_fa` (17)، `test_privacy_v117` (14).
- UX عمومی (v117 فاز ۷): `public_audit` (۲۵ صفحه × ۴ دستگاه)،
  `contrast_audit` (۱۲ صفحه × ۲ تم).
- `seed_demo.py` دادهٔ نمایشی می‌سازد؛ تست‌ها روی `data/test_*.db` جدا اجرا می‌شوند.
- بات مدیر/دستیار (v233–v259): `test_adminbot_v2xx` (۲۳ سوئیت) · دستیار: `test_assistant_v2xx` (۲۰ سوئیت) · بات‌ها/پنل‌ها: `test_bots_v234`، `test_bot_panels_v235` · اسکنر رازها: `tools/scan_tokens.py`.

## ۸) پروتکل تغییر

۱. مشکل را در `WHATS-NEW.md` ثبت کن. ۲. تغییر + تست مرتبط را سبز کن.
۳. باتری کامل را اجرا کن. ۴. بامپ نسخه در ۵ جا (`VERSION.txt`، `sw.js`، سربرگ `README.md`، `DIAG_LATEST`، `CURRENT-STATE.md`)، زیپ بدون `data/`،
۵. اسناد (این سه فایل + فایل‌های حافظه) به‌روز. ریپو: `rezadb369-wq/369`.
