/* v222 — دستیار هوشمند دست گیر
   (1) floating live bar + one-time invite on every public page
   (2) the chat page /assistant. Talks only to same-origin /api/assistant/*.
   (3) v222: attaches geolocation to chat only if already granted elsewhere. */
(function () {
  'use strict';
  const $ = (sel, root) => (root || document).querySelector(sel);
  const fa = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]);
  const HINTS = [
    'آنلاین · بپرسید: «داروخانهٔ شبانه‌روزی نزدیک من؟»',
    'آنلاین · «بهترین کافهٔ باز الان کجاست؟»',
    'آنلاین · «ثبت مغازه‌ام چقدر طول می‌کشه؟»',
    'آنلاین · «آخرین سفارشم در چه وضعیتیه؟»',
    'آنلاین · «برای تعمیر موبایل کجا برم؟»',
  ];

  /* ---------- floating bar + invite ---------- */
  const bar = $('[data-ai-bar]');
  if (bar) {
    const live = $('[data-ai-live]', bar);
    setTimeout(() => { bar.hidden = false; }, 1500);
    let i = 0;
    setInterval(() => { if (live) { i = (i + 1) % HINTS.length; live.textContent = HINTS[i]; } }, 4500);
    fetch('/api/assistant/status', { credentials: 'same-origin' }).then((r) => r.json()).then((r) => {
      if (r && r.enabled === false) bar.hidden = true;
    }).catch(() => {});

    const invite = $('[data-ai-invite]');
    const KEY = 'dastgir.ai.invited.v213';
    let seen = false;
    try { seen = localStorage.getItem(KEY) === '1'; } catch (e) {}
    if (invite && !seen) {
      const close = () => { invite.hidden = true; try { localStorage.setItem(KEY, '1'); } catch (e) {} };
      setTimeout(() => { invite.hidden = false; }, 6000);
      invite.querySelectorAll('[data-ai-invite-close]').forEach((b) => b.addEventListener('click', close));
      invite.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => { try { localStorage.setItem(KEY, '1'); } catch (e) {} }));
      document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !invite.hidden) close(); });
    }
  }

  /* ---------- chat page ---------- */
  const pageEl = $('[data-ai-page]');
  if (!pageEl) return;
  const log = $('[data-ai-log]', pageEl);
  const form = $('[data-ai-form]', pageEl);
  const input = $('#ai-input', pageEl);
  const quotaEl = $('[data-ai-quota]', pageEl);
  const history = [];
  let busy = false;

  /* v271 (دستور مدیر: «چت تا ده دقیقه برای کاربر بمونه»): the visible
     10-minute memory clock. The server thread (ai_threads) expires after
     600s; this shows the SAME window, restarts on every exchange, and when
     it runs out the client history is cleared and the user is told — so a
     new conversation starts fresh on both sides. */
  const MEM_MS = 600000;
  let memUntil = 0, memTick = null;
  const memEl = document.createElement('div');
  memEl.setAttribute('data-ai-mem', '');
  memEl.hidden = true;
  memEl.style.cssText = 'font-size:12px;opacity:.75;padding:4px 2px;text-align:center';
  if (quotaEl && quotaEl.parentNode) quotaEl.parentNode.insertBefore(memEl, quotaEl);
  else pageEl.insertBefore(memEl, pageEl.firstChild);
  const memRender = () => {
    const left = Math.max(0, memUntil - Date.now());
    const m = Math.floor(left / 60000), s = Math.floor((left % 60000) / 1000);
    memEl.textContent = '⏱ حافظهٔ چت: ' + fa(m) + ':' + (s < 10 ? '۰' : '') + fa(s);
    if (left <= 0) {
      if (memTick) { clearInterval(memTick); memTick = null; }
      memEl.hidden = true;
      if (history.length) {
        history.length = 0;
        bubble('⏱ ده دقیقه گذشت — حافظهٔ چت پاک شد؛ گفت‌وگوی تازه شروع می‌شود.', 'bot');
      }
    }
  };
  const memReset = () => {
    memUntil = Date.now() + MEM_MS;
    memEl.hidden = false;
    memRender();
    if (!memTick) memTick = setInterval(memRender, 1000);
  };

  const setQuota = (r) => {
    if (!quotaEl || !r || typeof r.remaining !== 'number' || typeof r.quota !== 'number') return;
    quotaEl.textContent = (r.tier_label ? r.tier_label + ' · ' : '') + fa(r.remaining) + ' از ' + fa(r.quota) + ' پاسخ هوشمند امروز';
    quotaEl.classList.toggle('ai-quota-warn', r.remaining === 0);
  };

  const bubble = (text, who, links) => {
    const div = document.createElement('div');
    div.className = 'ai-msg ' + (who === 'user' ? 'ai-user' : 'ai-bot');
    const p = document.createElement('p'); p.textContent = text; div.appendChild(p);
    if (links && links.length) {
      const wrap = document.createElement('div'); wrap.className = 'ai-links';
      links.forEach((l) => {
        if (!l || !l.href || !/^\//.test(l.href)) return;
        const a = document.createElement('a'); a.href = l.href; a.textContent = l.label || l.href; wrap.appendChild(a);
      });
      div.appendChild(wrap);
    }
    log.appendChild(div); log.scrollTop = log.scrollHeight; return div;
  };

  /* v222: attach coords only if the user already granted geolocation
     elsewhere (e.g. /nearby) — chat itself never triggers a permission prompt. */
  let geoCache = null;
  const geoGet = () => new Promise((resolve) => {
    try {
      if (geoCache && Date.now() - geoCache.at < 10 * 60 * 1000) return resolve(geoCache);
      if (!navigator.geolocation || !navigator.permissions || !navigator.permissions.query) return resolve(null);
      navigator.permissions.query({ name: 'geolocation' }).then((st) => {
        if (!st || st.state !== 'granted') return resolve(null);
        navigator.geolocation.getCurrentPosition(
          (p) => { geoCache = { lat: p.coords.latitude, lon: p.coords.longitude, at: Date.now() }; resolve(geoCache); },
          () => resolve(null), { timeout: 4000, maximumAge: 600000 });
      }).catch(() => resolve(null));
    } catch (e) { resolve(null); }
  });

  const ask = (text) => {
    text = String(text || '').trim().slice(0, 400);
    if (!text || busy) return;
    busy = true;
    memReset();   // v271: the 10-minute memory clock (re)starts on activity
    const starts = $('[data-ai-starts]', pageEl); if (starts) starts.hidden = true;
    bubble(text, 'user'); history.push({ role: 'user', text });
    const typing = bubble('در حال فکر کردن', 'bot'); typing.classList.add('ai-typing');
    input.value = ''; input.style.height = '';
    geoGet().then((g) => {
      const payload = { text, history: history.slice(-8) };
      if (g && typeof g.lat === 'number' && typeof g.lon === 'number') { payload.lat = g.lat; payload.lon = g.lon; }
      return fetch('/api/assistant/chat', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
    }).then((r) => r.json().catch(() => ({ ok: false, text: 'پاسخ نامعتبر بود.' })))
      .then((r) => {
        typing.remove();
        bubble(r.text || 'پاسخی دریافت نشد.', 'bot', r.links);
        history.push({ role: 'assistant', text: r.text || '' });
        if (history.length > 10) history.splice(0, history.length - 10);
        memReset();   // v271: window restarts from the last exchange
        setQuota(r);
      })
      .catch(() => { typing.remove(); bubble('ارتباط برقرار نشد؛ دوباره تلاش کنید.', 'bot'); })
      .finally(() => { busy = false; input.focus(); });
  };

  form.addEventListener('submit', (e) => { e.preventDefault(); ask(input.value); });
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ask(input.value); } });
  input.addEventListener('input', () => { input.style.height = ''; input.style.height = Math.min(140, input.scrollHeight) + 'px'; });
  pageEl.addEventListener('click', (e) => { const b = e.target.closest('[data-ai-q]'); if (b) ask(b.getAttribute('data-ai-q')); });
  const q = new URLSearchParams(location.search).get('q');
  if (q) ask(q); else input.focus();
})();
