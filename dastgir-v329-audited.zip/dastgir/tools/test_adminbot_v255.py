#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v255: یک دستور، همه‌چیز خودکار — توکن قبلی کلاً حذف، بدون ترمکس.

Owner's order (2026-09-10, frustrated after the Termux-activation delivery):
«گفتم توکن قبلی کلاً حذف بشه، ترامپی هم که براش نوشتی کلاً حذفش کن،
خودش آزاد باشه» — i.e. ONE install command that: wipes the previous token
COMPLETELY (no .bak trace left behind), activates the ChatGPT brain by
itself (key baked in deploy/brain.env), with the already-unrestricted
prompt. No activation step for the owner to run, ever.
"""
import os, sys, json, subprocess, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

# v289: deploy/brain.env carries the live AI keys and is stripped from any
# shared artifact on purpose (RULES: secrets never leave the box). When the
# file is absent this suite cannot test the brain, so it reports a named
# environmental skip with exit 78 (EX_CONFIG) instead of a red that looks like
# a code fault. Put the real brain.env back and it runs for real.
_BRAIN = ROOT / "deploy" / "brain.env"
if not _BRAIN.is_file():
    print("SKIP  deploy/brain.env موجود نیست — این سوئیت مغز AI را تست می‌کند و")
    print("      کلیدها عمداً از بستهٔ اشتراکی حذف شده‌اند. فایل را برگردانید")
    print("      تا واقعی اجرا شود. (خروجی ۷۸ = EX_CONFIG، نه شکست کد)")
    raise SystemExit(78)


TMP = tempfile.mkdtemp(prefix='adm-v255-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
AI._chat = lambda *a, **k: ('{"answer":"باشه","links":[],"scope":true,"intent":"faq"}', 5)
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]

AB = ROOT / 'deploy' / 'apply-brain.sh'
BR = ROOT / 'deploy' / 'brain.env'

# ================= 1. brain.env exists; shipped CONTENT is pinned only by
# the LATEST suite (v256: keyless by owner order). Mechanics use a fixture.
be = ('AI_BASE_URL=https://api.avalai.ir/v1\nAI_API_KEY=fixture-key-1234567890\n'
      'AI_MODEL=gpt-6-astra\nAI_TIMEOUT=40\n')

# ================= 2. install: gemini wiped, new brain ON, NO trace left
W = Path(TMP)
(W / 'app' / 'deploy').mkdir(parents=True)
(W / 'app' / 'deploy' / 'brain.env').write_text(be, encoding='utf-8')
SEC = W / 'secrets.env'
SEC.write_text('AI_BASE_URL=https://generativelanguage.example/v1\n'
               'AI_API_KEY=gemini-old\nAI_MODEL=gemini-2.5-flash-lite\n'
               'AI_FALLBACK_API_KEY=oldfb\nBALE_ADMIN_TOKEN=keepme\n',
               encoding='utf-8')
r = subprocess.run(['bash', str(AB)], capture_output=True, text=True,
                   env=dict(os.environ, DASTGIR_APP=str(W / 'app'),
                            DASTGIR_SECRETS=str(SEC)), timeout=30)
out = SEC.read_text(encoding='utf-8')
# ممیزی v329: پیام v328 — «مغز فعال + هوش سایت روی بای‌نارا» یا «ادغام اسلاتی».
ck(r.returncode == 0 and ('v328' in r.stdout or 'بسته نصب' in r.stdout or 'مغز' in r.stdout),
   'apply reports the install (v328 wording)')
# ممیزی v329: v317 slot-merge — same-name gemini slots replaced;
# AI_FALLBACK_API_KEY (خارج از brain.env) نگه داشته می‌شود.
ck('AI_MODEL=gemini-2.5-flash-lite' not in out
   and 'AI_API_KEY=gemini-old' not in out
   and 'generativelanguage.example' not in out,
   'gemini same-name slots gone (v317 slot-merge)')
ck('AI_MODEL=gpt-6-astra' in out and 'AI_BASE_URL=https://api.avalai.ir/v1' in out,
   'ChatGPT brain active right after the install')
ck('BALE_ADMIN_TOKEN=keepme' in out, 'bot token untouched')
ck(not (W / 'secrets.env.bak').exists(),
   'v255: the transient .bak is REMOVED — zero trace of the old token')

# ================= 3. no Termux/activation step is needed anywhere
ups = (ROOT / 'deploy' / 'update.sh').read_text(encoding='utf-8')
ck('apply-brain.sh' in ups, 'update.sh applies the brain during install')
ck(not any('curl -s -m 60 https://api.avalai.ir/v1/chat/completions' in ln
           for ln in ups.splitlines()),
   'no activation curl left in update.sh — the install IS the activation')

# ================= 4. a later /کلید change still survives re-installs (stamp)
SEC.write_text(out.replace('gpt-6-astra', 'my-later-choice'), encoding='utf-8')
subprocess.run(['bash', str(AB)], capture_output=True, text=True,
               env=dict(os.environ, DASTGIR_APP=str(W / 'app'),
                        DASTGIR_SECRETS=str(SEC)), timeout=30)
ck('my-later-choice' in SEC.read_text(encoding='utf-8'),
   'later bot-side key change is never clobbered by the same zip')

# ================= 5. the chat prompt stays unrestricted (v254 order intact)
P = AI.ANSWER_PROMPT
ck('محدودیت موضوعی نداری' in P and 'فقط برای کارهای دست گیر هستی' not in P,
   'prompt is still topically unrestricted')

# ================= 6. version pins
ver = (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip()
ck(ver == A.DIAG_LATEST, f'DIAG_LATEST ({A.DIAG_LATEST}) == VERSION.txt ({ver})')
r = t('تشخیص')
ck('به‌روز' in r and 'قدیمی‌تر' not in r, 'تشخیص line 1 reports به‌روز')

print(f'v255 one-command everything: {n} checks green')
