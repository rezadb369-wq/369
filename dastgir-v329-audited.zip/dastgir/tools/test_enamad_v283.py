#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v283 — نشان اعتماد الکترونیکی (اینماد) استاندارد و دقیق روی سایت.

قراردادی که قفل می‌شود (طبق اسکریپت رسمی اینماد + الزامات تأیید آن):
  · لینک تأیید و لوگو هر دو referrerpolicy="origin" دارند (اینماد با همین
    رفرر نمایش/اعتبار را ثبت می‌کند).
  · لوگو مستقیم از trustseal.enamad.ir می‌آید — نه کپی محلی، نه کش ما
    (سرویس‌ورکر فقط same-origin را کش می‌کند) تا وضعیت نشان همیشه زنده باشد.
  · target="_blank" + rel="noopener" (بدون noreferrer که رفرر را می‌کشد).
  · نمایش در فوتر همهٔ صفحه‌های عمومی، روی کاشی سفید استاندارد.
  · CSP سایت (img-src … https:) تصویر بیرونی را مجاز می‌کند.
"""
import os
import re
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))
os.environ["BZ_DATA_DIR"] = tempfile.mkdtemp(prefix="v283-")

import db            # noqa: E402
import ui            # noqa: E402

FAILS = []
ID = "7660147"
CODE = "kuhoa5a38FhfpKwFi0facKhDHTSJncoE"


def ck(cond, label):
    print(("  ✓ " if cond else "  ✗ ") + label)
    if not cond:
        FAILS.append(label)


def main():
    print("== v283: اینماد استاندارد در فوتر سایت ==")
    db.init()
    s = db.get_settings()
    html = ui.footer(s, [])

    ck(f"trustseal.enamad.ir/?id={ID}&amp;Code={CODE}" in html,
       "لینک صفحهٔ تأیید اینماد با id و Code دقیق در فوتر است")
    ck(f'src="https://trustseal.enamad.ir/logo.aspx?id={ID}&amp;Code={CODE}"' in html,
       "لوگو مستقیم از سرور اینماد hotlink شده (بدون کپی محلی)")
    ck(html.count('referrerpolicy="origin"') >= 2,
       "referrerpolicy=origin روی هم <a> و هم <img> (الزام تأیید اینماد)")
    ck('target="_blank"' in html and 'rel="noopener"' in html
       and "noreferrer" not in html,
       "target=_blank + rel=noopener و بدون noreferrer (رفرر حفظ می‌شود)")
    ck(f'code="{CODE}"' in html and 'style="cursor:pointer"' in html,
       "ویژگی‌های اسکریپت رسمی اینماد (code و cursor) دست‌نخورده‌اند")
    ck('width="80" height="80"' in html and 'alt="نشان اعتماد الکترونیکی"' in html,
       "ابعاد صریح (بدون CLS) + alt فارسی برای دسترس‌پذیری")
    ck('class="trust-row"' in html, "کانتینر استاندارد trust-row در فوتر")

    # سیاست‌های سرور/سرویس‌ورکر که نمایش زندهٔ نشان را تضمین می‌کنند
    app = (ROOT / "server" / "app.py").read_text(encoding="utf-8")
    ck(re.search(r"img-src 'self' data: blob: https:", app) is not None,
       "CSP: img-src دامنه‌های https (از جمله اینماد) را مجاز می‌کند")
    sw = (ROOT / "site" / "sw.js").read_text(encoding="utf-8")
    ck("if (url.origin !== self.location.origin) return;" in sw,
       "سرویس‌ورکر دامنهٔ بیرونی را کش نمی‌کند → نشان همیشه زنده")

    css = (ROOT / "site" / "assets" / "css" / "main.css").read_text(encoding="utf-8")
    ck(".trust-row" in css and ".trust-row img" in css,
       "main.css: استایل کاشی سفید نشان تعریف شده")
    uis = (ROOT / "server" / "ui.py").read_text(encoding="utf-8")
    # v289: کش‌شکن از VERSION.txt — عدد ثابت از v286 به بعد همیشه قرمز بود
    _ver = (ROOT / "VERSION.txt").read_text(encoding="utf-8").strip()
    # ممیزی v329 (v298): av() منبع واحد است — لترال ?v در سورس نیست.
    ck(("main.css?v" + _ver) in uis or "av('/assets/css/main.css')" in uis,
       "کش‌شکن main.css?v" + _ver + " برای تغییر استایل (av یا لترال)")

    print()
    if FAILS:
        print(f"  {len(FAILS)} مورد ناموفق:")
        for f in FAILS:
            print("   -", f)
        return 1
    print("  همه موفق — v283 enamad trust-seal PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
