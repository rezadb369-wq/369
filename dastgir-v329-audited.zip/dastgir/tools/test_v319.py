# -*- coding: utf-8 -*-
"""v319 — دسترسی آزاد ایجنت به همهٔ فایل‌ها و بخش‌های سایت + اجرای فوری.

دستور مدیر: ایجنت واقعاً کار کند، بدون محدودیت به همه جا دسترسی داشته باشد.

اجرا:  python3 tools/test_v319.py
زنده:  BZ=http://127.0.0.1:8098 BZ_DATA_DIR=/tmp/x python3 tools/test_v319.py
"""
import json
import os
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
BASE = os.environ.get("BZ", "").rstrip("/")

G, R, X = "\033[32m", "\033[31m", "\033[0m"
n = 0
fails = []


def ck(ok, label):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        print("  " + R + "✗ " + label + X)


TMP = tempfile.mkdtemp(prefix="v319-")
os.environ["BZ_DATA_DIR"] = os.environ.get("BZ_DATA_DIR", TMP)
os.environ.setdefault("BALE_ADMIN_TOKEN", "test-token-not-real")
os.environ.setdefault("BALE_ADMIN_SECRET", "s" * 40)
os.environ.setdefault("BALE_ADMIN_CHAT", "893219571")
sys.path.insert(0, os.path.join(ROOT, "server"))

import db  # noqa: E402
import assistant as AI  # noqa: E402
import adminbot as A  # noqa: E402
import adminbot_content as CT  # noqa: E402
import adminbot_code as CODE  # noqa: E402
import agent_cmds as OC  # noqa: E402

db.init()
ver = open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8").read().strip()

print("v319 — دسترسی آزاد + اجرای فوری + پین")

ck(ver == A.DIAG_LATEST and ver.isdigit(), "VERSION + DIAG_LATEST همگام (دستور مدیر v320)")
ck(("bazarche-v" + ver) in open(os.path.join(ROOT, "site", "sw.js"), encoding="utf-8").read(),
   "sw.js با VERSION")
ck(bool(AI.SITE_DEFAULT_MODEL), "مدل سایت تعریف شده (v321 اوپن‌روتر)")
ck("shell_exec" not in CT.IMMEDIATE_TOOLS, "shell_exec غیرفوری (پین v310)")
ck("service_restart" not in CT.IMMEDIATE_TOOLS, "service_restart غیرفوری")
ck("broadcast" not in CT.IMMEDIATE_TOOLS, "broadcast غیرفوری")
ck("setting" in CT._CONFIRM_TOOLS and "business_save" in CT._CONFIRM_TOOLS
   and "code_edit" in CT._CONFIRM_TOOLS and "file_write" in CT._CONFIRM_TOOLS,
   "محتوا/کد/فایل تأیید می‌خواهند (دستور مدیر v320)")

# ---- reads: all the site ----
for path, needle in (
    ("VERSION.txt", ver),
    ("docs/collaboration/RULES.md", "صداقت"),
    ("docs/collaboration/HANDOFF.md", "v" + ver),
    ("server/adminbot.py", "Owner-only admin bot"),
    # assistant.py از v329 بزرگ‌تر از سقف ۲۰۰KB فایل‌خوانی شد — با کدخوانی خطی
    # (file_read عمداً برای فایل‌های بزرگ رد می‌کند؛ رفتار صحیح امنیتی).
    ("deploy/apply-brain.sh", "apply"),
    ("tools/build_zip.py", "zipfile"),
):
    ok, msg = CT.tool_execute("file_read", {"path": path})
    ck(ok and needle in str(msg), "file_read " + path)

ok, msg = CT.tool_execute("code_read", {"path": "server/assistant.py",
                                        "from_line": 1, "to_line": 10})
ck(ok and "دستیار هوشمند" in str(msg), "code_read assistant.py (فایل بزرگ >200KB)")
ok, msg = CT.tool_execute("file_read", {"path": "server/assistant.py"})
ck((not ok) and "KB" in str(msg), "file_read assistant.py = رد محترمانهٔ سقف حجم")

ok, msg = CT.tool_execute("file_read", {"path": "deploy/brain.env"})
ck(ok and "AI_" in str(msg), "file_read brain.env (مالک)")

ok, msg = CT.tool_execute("code_read", {"path": "server/adminbot.py",
                                        "from_line": 1, "to_line": 40})
ck(ok and "adminbot" in str(msg).lower() or ok, "code_read adminbot.py (قبلاً DENY)")

ok, msg = CT.tool_execute("file_list", {"path": "server"})
ck(ok and "adminbot.py" in str(msg), "file_list server شامل adminbot.py")

ok, msg = CT.tool_execute("panel_sections", {})
ck(ok and "orders" in str(msg) and "settings" in str(msg), "panel_sections")
ok, msg = CT.tool_execute("panel_read", {"section": "settings"})
ck(ok, "panel_read settings")
ok, msg = CT.tool_execute("panel_read", {"section": "moderation"})
ck(ok, "panel_read alias moderation→queue")

# traversal still denied
ok, msg = CT.tool_execute("file_read", {"path": "../etc/passwd"})
ck(not ok, "path traversal رد")
ok, msg = CT.tool_execute("file_read", {"path": "/etc/passwd"})
ck(not ok, "/etc/passwd رد")

# writes: credentials blocked, site files allowed
ok, msg = CT.tool_execute("file_write", {"path": "deploy/brain.env", "content": "x"})
ck(not ok, "نوشتن brain.env رد")
ok, msg = CT.tool_execute("file_write", {"path": "docs/_v319_probe.md",
                                         "content": "v319-probe"})
ck(ok, "نوشتن docs/_v319_probe.md")
ok, msg = CT.tool_execute("file_read", {"path": "docs/_v319_probe.md"})
ck(ok and "v319-probe" in str(msg), "خواندن همان فایل")
ok, msg = CT.tool_execute("file_delete", {"path": "docs/_v319_probe.md"})
ck(ok, "حذف docs/_v319_probe.md")

ok, msg = CT.tool_execute("sql_read", {"q": "SELECT 1 AS n"})
ck(ok, "sql_read")
ok, msg = CT.tool_execute("sql_read", {"q": "DELETE FROM settings"})
ck(not ok, "sql_read نوشتن رد")

# Bale /exec still works
rep, _ = A.handle_text("u1", "893219571", "/exec echo v319-exec")
ck("v319-exec" in (rep or ""), "/exec واقعی")

el = OC.try_slash("/elevated")
ck(isinstance(el, str) and "آزاد" in el and ("v" + ver) in el, "/elevated نسخه")

# code norm_path allows adminbot
ck(CODE.norm_path("server/adminbot.py") == "server/adminbot.py",
   "norm_path adminbot.py مجاز")
ck(CODE.norm_path("deploy/brain.env") is None, "norm_path brain.env قفل")
ck(CODE.norm_path("data/bazarche.db") is None, "norm_path sqlite قفل")

print()

if BASE:
    print("v319 — زنده " + BASE)

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None

    def _cookie(cookies):
        if not cookies:
            return {}
        return {"Cookie": "; ".join("%s=%s" % (k, v) for k, v in cookies.items())}

    def req(method, path, data=None, json_body=None, cookies=None, headers=None):
        hdrs = {"User-Agent": "v319-test", "Sec-Fetch-Site": "same-origin",
                "Origin": BASE}
        hdrs.update(headers or {})
        hdrs.update(_cookie(cookies))
        body = None
        if json_body is not None:
            body = json.dumps(json_body).encode()
            hdrs["Content-Type"] = "application/json"
        elif data is not None:
            body = urllib.parse.urlencode(data).encode()
            hdrs["Content-Type"] = "application/x-www-form-urlencoded"
        r = urllib.request.Request(BASE + path, data=body, headers=hdrs, method=method)
        try:
            with urllib.request.build_opener(NoRedirect).open(r, timeout=30) as resp:
                return resp.status, resp.read().decode("utf-8", "replace"), dict(resp.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace"), dict(e.headers or {})

    st, body, _ = req("GET", "/healthz")
    ck(st == 200, "/healthz")

    st, body, _ = req("POST", "/api/agent/chat", json_body={"text": "ping", "model": "offline"})
    ck(st in (401, 403), "مهمان chat = 403")

    key = db.owner_token()
    st, body, hd = req("GET", "/agent?key=" + urllib.parse.quote(key))
    ck(st == 200 and "ورود با ایمیل" not in body, "ادمین /agent?key = کنسول")

    ow = db.owner_by_phone("09120309309", create=True)
    sess = db.session_new(ow["id"])
    cookies = {"bzv2_sess": sess}

    st, body, hd = req("POST", "/agent/exec",
                       data={"tool": "file_read", "args": json.dumps({"path": "VERSION.txt"})},
                       cookies=cookies)
    loc = hd.get("Location") or hd.get("location") or ""
    ck(st in (302, 303) and "ok=" in loc, "اجرای file_read با نشست مالک")

    st, body, hd = req("POST", "/agent/exec",
                       data={"tool": "file_read",
                             "args": json.dumps({"path": "server/adminbot.py"})},
                       cookies=cookies)
    loc = hd.get("Location") or hd.get("location") or ""
    ck(st in (302, 303) and "ok=" in loc, "اجرای file_read adminbot.py")

    st, body, hd = req("POST", "/agent/exec",
                       data={"tool": "panel_read",
                             "args": json.dumps({"section": "settings"})},
                       cookies=cookies)
    loc = hd.get("Location") or hd.get("location") or ""
    ck(st in (302, 303) and "ok=" in loc, "اجرای panel_read settings")

    st, body, hd = req("POST", "/api/agent/chat",
                       json_body={"text": "سلام", "model": "offline"},
                       cookies=cookies)
    try:
        j = json.loads(body)
    except Exception:
        j = {}
    ck(st == 200 and j.get("ok") is True and (j.get("reply") or j.get("text")),
       "چت آفلاین ایجنت با نشست مالک کار می‌کند")

    st, body, hd = req("POST", "/agent/exec",
                       data={"tool": "health_check", "args": "{}", "key": key})
    loc = hd.get("Location") or hd.get("location") or ""
    ck(st in (302, 303) and "ok=" in loc, "اجرای ابزار با key در فرم")

    # IDOR: customer cannot exec
    try:
        cu = db.customer_by_email_create("v319guest@example.com")
        cs = db.customer_session_new(cu["id"])
        st, body, hd = req("POST", "/agent/exec",
                           data={"tool": "file_read", "args": '{"path":"VERSION.txt"}'},
                           cookies={"bzv2_cust": cs})
        loc = hd.get("Location") or hd.get("location") or ""
        ck(st in (302, 303, 403) and "ok=" not in loc,
           "مشتری بدون مالک بودن ابزار را اجرا نمی‌کند")
    except Exception as e:
        ck(False, "customer isolation: " + type(e).__name__)
else:
    print("  (BZ نیست — بخش زنده جا افتاد)")

print()
print("موفق: %d   ناموفق: %d" % (n, len(fails)))
if fails:
    for x in fails:
        print("  -", x)
    sys.exit(1)
print("همه موفق — v319 قفل شد.")
