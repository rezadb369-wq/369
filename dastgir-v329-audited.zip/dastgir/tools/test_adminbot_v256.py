#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v256: کلاً بدون توکن — با مدرک (v259: سیاست با دستور جدید مدیر عوض شد).

Owner's order (2026-09-10): «آقا کلا توکن ها را حذف کن کلا کلا کلا با مدرک».
v259 owner order: «توکن کلود را تست و دقیق پیاده کن» — the package now
ships the Claude brain in deploy/brain.env (base + aa- key + sonnet model +
opus smart + timeout 40); install = full replacement + instant activation.
This suite now enforces the v259 brain policy (v273: 5th brain = GLM):
1) brain.env ships the exact 6-line 5-brain store (keys shape-checked, never
   printed).
2) tools/scan_tokens.py still passes (the new key is the owner's live asset,
   not a leaked old secret — the old-key blocklist stays clean).
3) The OLD AvalAI key (v256 hash) stays absent from the whole tree.
"""
import os, sys, json, subprocess, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

# v289: deploy/brain.env carries the live AI keys and is stripped from any
# shared artifact on purpose (RULES: secrets never leave the box). When the
# file is absent this suite cannot test the brain, so it reports a named
# environmental skip with exit 78 (EX_CONFIG) instead of a red that looks like
# a code fault. Put the real brain.env back and it runs for real.
_BRAIN = ROOT / "deploy" / "brain.env"
if not _BRAIN.is_file():
    print("SKIP  deploy/brain.env موجود نیست — این سوئیت مغز AI را تست می‌کند و")
    print("      کلیدها عمداً از بستهٔ اشتراکی حذف شده‌اند. فایل را برگردانید")
    print("      تا واقعی اجرا شود. (خروجی ۷۸ = EX_CONFIG، نه شکست کد)")
    raise SystemExit(78)


TMP = tempfile.mkdtemp(prefix='adm-v256-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
AI._chat = lambda *a, **k: ('{"answer":"باشه","links":[],"scope":true,"intent":"faq"}', 5)
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]

BR = ROOT / 'deploy' / 'brain.env'

# ================= 1. the package ships the 4-brain key store (v263 policy)
# v259 (دستور مدیر: «توکن کلود دقیق پیاده بشه»): brain.env دیگر خالی نیست —
# مغز Claude است؛ نصب = جایگزینی کامل + فعال‌شدن خودکار. کلید فقط شکل‌چک
# می‌شود و هرگز چاپ نمی‌شود (حتی در پیام خطا).
import re as _re_brain
be = BR.read_text(encoding='utf-8')
_ai = [ln for ln in be.splitlines() if ln.startswith('AI_')]
# v269 (دستور مدیر: «هوش مصنوعی سایت جدا باشه»): اسلات هوش عمومی سایت
# (AI_SITE_BASE_URL/KEY/MODEL) به انبار اضافه شد — ۹ خط: ۵ کلید مغز +
# timeout + ۳ خط سایت.
# ممیزی v329 (v318/v321): انبار ۹خطی = OR + اسلات دستی (BASE/KEY/MODEL) +
# ۳خط سایت روی بای‌نارا + TIMEOUT + BYNARA؛ کلیدهای کلاد/GLM جداگانه inject می‌شوند.
ck(len(_ai) == 9 and
   'AI_TIMEOUT=40' in _ai and
   'AI_SITE_BASE_URL=https://router.bynara.id/v1' in _ai and
   'AI_SITE_MODEL=ling-3.0-flash-sante-free' in _ai and
   any(_re_brain.match(r'^AI_SITE_API_KEY=sk-nry-[A-Za-z0-9_\-]{20,}$', ln) for ln in _ai) and
   any(_re_brain.match(r'^AI_BRAIN_OR_KEY=sk-or-v1-[A-Za-z0-9]{32,}$', ln) for ln in _ai) and
   any(_re_brain.match(r'^AI_BRAIN_BYNARA_KEY=sk-nry-[A-Za-z0-9_\-]{20,}$', ln) for ln in _ai) and
   any(ln.startswith('AI_BASE_URL=') for ln in _ai) and
   any(ln.startswith('AI_API_KEY=') for ln in _ai) and
   any(ln.startswith('AI_MODEL=') for ln in _ai) and
   not any(ln.startswith('AI_FALLBACK_') for ln in _ai),
   'brain.env = v321 9-line store (OR+custom+site-byNara+timeout+bynara)')

# ================= 2. the token scan — the مدرک — passes on the whole tree
r = subprocess.run([sys.executable, str(ROOT / 'tools' / 'scan_tokens.py')],
                   capture_output=True, text=True, timeout=120)
ck(r.returncode == 0 and 'راز واقعی: ۰' in r.stdout,
   'scan_tokens.py: zero real secrets in the whole package')
ck('فایل‌های اسکن‌شده:' in r.stdout, 'the scan reports its file count (auditable)')

# ================= 3. the real key is gone from every text file
import hashlib
REAL_SHA = 'a415b87134b42ca583c621849da783e8ee6850681bbe2cc0f50147ff5a52ff60'
hits = []
for p in ROOT.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:
        try:
            txt = p.read_text(encoding='utf-8', errors='ignore')
        except OSError:
            continue
        if 'aa-' in txt or 'sk-' in txt:
            for fam in (r'aa-[A-Za-z0-9]{30,}', r'sk-[A-Za-z0-9_\-]{30,}'):
                import re as _re
                for m in _re.findall(fam, txt):
                    if hashlib.sha256(m.encode()).hexdigest() == REAL_SHA:
                        hits.append(str(p))
ck(not hits, 'the real AvalAI key appears in 0 files (hash-checked)')

# ================= 4. installing v263 REPLACES every old AI key with the 5-brain store
# v259 (دستور مدیر): نصب دیگر مغز را خاموش نمی‌گذارد — همهٔ AI_* قبلی کامل
# پاک و مغز Claude همان لحظه فعال می‌شود (صفر دستور اضافه).
W = Path(TMP)
(W / 'app' / 'deploy').mkdir(parents=True)
(W / 'app' / 'deploy' / 'brain.env').write_text(be, encoding='utf-8')
SEC = W / 'secrets.env'
SEC.write_text('AI_BASE_URL=https://api.avalai.ir/v1\n'
               'AI_API_KEY=gemini-old\nAI_MODEL=gemini-2.5-flash-lite\n'
               'AI_FALLBACK_API_KEY=oldfb\nBALE_ADMIN_TOKEN=keepme\n',
               encoding='utf-8')
r = subprocess.run(['bash', str(ROOT / 'deploy' / 'apply-brain.sh')],
                   capture_output=True, text=True,
                   env=dict(os.environ, DASTGIR_APP=str(W / 'app'),
                            DASTGIR_SECRETS=str(SEC)), timeout=30)
out = SEC.read_text(encoding='utf-8')
ck(r.returncode == 0, 'apply-brain runs clean on the keyed package')
# ممیزی v329: بستهٔ v321 — OR + BYNARA + اسلات دستی + سایت + TIMEOUT.
ck('AI_BRAIN_OR_KEY=sk-or-v1-' in out and
   'AI_BRAIN_BYNARA_KEY=sk-nry-' in out and
   'AI_SITE_MODEL=ling-3.0-flash-sante-free' in out and
   'AI_TIMEOUT=40' in out and
   'BALE_ADMIN_TOKEN=keepme' in out,
   'install ships the v321 9-line store from the package')
# ممیزی v329: v317 slot-merge — same-name gemini slots replaced;
# AI_FALLBACK خارج از اسلات‌های brain.env می‌ماند.
ck('gemini-old' not in out and 'gemini-2.5-flash-lite' not in out,
   'old same-name gemini slots wiped (v317 slot-merge; fallback may stay)')
ck('BALE_ADMIN_TOKEN=keepme' in out, 'the bot login token stays (it is not an AI key)')
ck(not (W / 'secrets.env.bak').exists(), 'no .bak trace is left behind')

# ================= 5. تشخیص names the live Claude brain (v259 policy)
# v259 (دستور مدیر): بعد از نصب، خط ۲ باید مغز Claude را سبز نشان بدهد؛
# اگر روزی کلید نباشد، راه برگشت /کلید Muse است.
os.environ['AI_BASE_URL'] = 'https://api.avalai.ir/v1'
os.environ['AI_API_KEY'] = 'aa-fixture' + 'k' * 42
os.environ['AI_MODEL'] = 'claude-sonnet-5'
os.environ.pop('AI_MODEL_SMART', None)
r = t('تشخیص')
ck('claude-sonnet-5 @ api.avalai.ir' in r and '✅ پاسخ داد' in r,
   'تشخیص line 2: live Claude brain, reachable')
ck('aa-fixture' not in r, 'تشخیص never prints the key')
os.environ['AI_BASE_URL'] = ''
os.environ['AI_API_KEY'] = ''
os.environ['AI_MODEL'] = ''
r = t('تشخیص')
ck('هیچ کلیدی وصل نیست' in r and '/کلید Muse' in r,
   'تشخیص OFF state still honest, way back is /کلید Muse')

# ================= 6. re-enabling later still works (mechanics intact)
FIX = ('AI_BASE_URL=https://api.avalai.ir/v1\nAI_API_KEY=fixture-key-1234567890\n'
       'AI_MODEL=gpt-6-astra\nAI_TIMEOUT=40\n')
(W / 'app' / 'deploy' / 'brain.env').write_text(FIX, encoding='utf-8')
SEC.write_text('BALE_ADMIN_TOKEN=keepme\n', encoding='utf-8')
subprocess.run(['bash', str(ROOT / 'deploy' / 'apply-brain.sh')],
               capture_output=True, text=True,
               env=dict(os.environ, DASTGIR_APP=str(W / 'app'),
                        DASTGIR_SECRETS=str(SEC)), timeout=30)
ck('AI_MODEL=gpt-6-astra' in SEC.read_text(encoding='utf-8'),
   'a future brain.env (owner order) can still activate a key')

# ============ 8. v273: the live 5th-brain key exists ONLY in brain.env
# The real aa-… key is read from the packaged store, hashed, and hunted
# across the whole tree — it must appear in deploy/brain.env and nowhere
# else (never in docs, suites, logs, or chat fixtures). The key itself is
# NEVER printed here.
# ممیزی v329: کلید GLM از brain.env حذف شد (v317 slot-merge)؛
# شکار هش روی کلید bynara/OR بسته انجام می‌شود — فقط در brain.env.
_KK = [ln.split('=', 1)[1] for ln in be.splitlines()
      if ln.startswith('AI_BRAIN_BYNARA_KEY=') or ln.startswith('AI_BRAIN_OR_KEY=')]
assert len(_KK) >= 1, 'brain.env ships at least one brain key slot (bynara/OR)'
_KKSHA = hashlib.sha256(_KK[0].encode()).hexdigest()
_khits = []
for _kp in ROOT.rglob('*'):
    if _kp.is_file() and '__pycache__' not in _kp.parts:
        try:
            _ktxt = _kp.read_text(encoding='utf-8', errors='ignore')
        except OSError:
            continue
        # v272 (دستور مدیر): اسلات مغز پنجم حالا کلید aa- سایت است؛
        # اسکن هر دو شکل را می‌گیرد — راز فقط در brain.env.
        # ممیزی v329: شکار هر سه خانواده — aa- / sk-or-v1- / sk-nry-.
        for _km in (_re.findall(r'aa-[A-Za-z0-9]{30,}', _ktxt)
                    + _re.findall(r'sk-or-v1-[A-Za-z0-9]{32,}', _ktxt)
                    + _re.findall(r'sk-nry-[A-Za-z0-9_\-]{20,}', _ktxt)):
            if hashlib.sha256(_km.encode()).hexdigest() == _KKSHA:
                _khits.append(str(_kp.relative_to(ROOT)))
ck(sorted(set(_khits)) == ['deploy/brain.env'],
   'the live brain key appears ONLY in deploy/brain.env (hash-checked)')

# ================= 7. version pins
ver = (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip()
ck(ver == A.DIAG_LATEST, f'DIAG_LATEST ({A.DIAG_LATEST}) == VERSION.txt ({ver})')
r = t('تشخیص')
ck('به‌روز' in r and 'قدیمی‌تر' not in r, 'تشخیص line 1 reports به‌روز')

print(f'v256 token-free with evidence: {n} checks green')
