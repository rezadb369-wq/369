#!/usr/bin/env python3
"""آزمون متمرکز سامانهٔ لوگوی v179؛ بدون نیاز به سرور یا شبکه."""
from __future__ import annotations
import base64, hashlib, io, re
from pathlib import Path
from PIL import Image, ImageChops

ROOT = Path(__file__).resolve().parent.parent
IMG = ROOT / "site/assets/img"


def colored_bounds(im: Image.Image, threshold: int = 245):
    rgb = im.convert("RGB")
    r, g, b = rgb.split()
    darkest = ImageChops.darker(ImageChops.darker(r, g), b)
    mask = darkest.point(lambda value: 255 if value < threshold else 0)
    return mask.getbbox()


def main():
    source_path = IMG / "logo-source.png"
    source_bytes = source_path.read_bytes()
    source_hash = hashlib.sha256(source_bytes).hexdigest()
    source = Image.open(io.BytesIO(source_bytes))
    assert source.size == (768, 768), source.size
    bounds = colored_bounds(source)
    assert bounds and bounds[0] <= 45 and bounds[1] <= 40
    assert bounds[2] >= 720 and bounds[3] >= 755, bounds

    # SVGهای مستقل مشتق target-sized هستند؛ رابط سایت PNG کامل را مستقیم می‌گیرد.
    for name in ("logo.svg", "logo-mark.svg", "logo-lockup.svg"):
        text = (IMG / name).read_text(encoding="utf-8")
        assert 'viewBox="0 0 256 256"' in text
        data = re.search(r"base64,([^\"]+)", text).group(1)
        embedded = Image.open(io.BytesIO(base64.b64decode(data)))
        assert embedded.size == (256, 256)
        assert len(text.encode()) < 40_000
    assert 'aria-label="دست گیر"' in (IMG / "logo-lockup.svg").read_text()

    # فاویکون برای سازگاری مستقل است، ولی در ۱۲۸px بالاتر از اندازهٔ نمایش ساخته می‌شود.
    favicon = (IMG / "favicon.svg").read_text(encoding="utf-8")
    assert 'viewBox="0 0 128 128"' in favicon and "clipPath" in favicon
    data = re.search(r"base64,([^\"]+)", favicon).group(1)
    embedded = Image.open(io.BytesIO(base64.b64decode(data)))
    assert embedded.size == (128, 128)
    assert len(favicon.encode()) < 12_000

    # سازنده هرگز منبع ۷۶۸px را بازنویسی یا به‌صورت اتلافی فشرده نمی‌کند.
    assert hashlib.sha256(source_path.read_bytes()).hexdigest() == source_hash

    specs = {
        "app-192.png": (192, 192, "RGBA"),
        "app-512.png": (512, 512, "RGBA"),
        "maskable-512.png": (512, 512, "RGB"),
    }
    for name, spec in specs.items():
        im = Image.open(IMG / "icons" / name)
        assert (im.size[0], im.size[1], im.mode) == spec, (name, im.size, im.mode)
        assert colored_bounds(im), name

    maskable = Image.open(IMG / "icons/maskable-512.png")
    b = colored_bounds(maskable)
    assert b[0] >= 80 and b[1] >= 80 and b[2] <= 432 and b[3] <= 432, b

    svg_total = sum((IMG / n).stat().st_size for n in
                    ("logo.svg", "logo-mark.svg", "favicon.svg", "logo-lockup.svg"))
    assert svg_total < 130_000, svg_total

    css = (ROOT / "site/assets/css/main.css").read_text()
    assert ".brand-mark img { width: 38px; height: 38px" in css
    assert "background: #ffffff" in css
    display = Image.open(IMG / "logo-display.png")
    assert display.size == (192, 192) and (IMG / "logo-display.png").stat().st_size < 40_000
    ui = (ROOT / "server/ui.py").read_text()
    # ممیزی v329 (v298): av() منبع واحد — قبول لترال v183 یا av().
    assert (ui.count('/assets/img/logo-display.png?v183') >= 2
            or ui.count("av('/assets/img/logo-display.png')") >= 2)
    _ver = (ROOT / "VERSION.txt").read_text().strip()
    # ممیزی v329 (v298): av() منبع واحد — قبول لترال نسخهٔ جاری.
    assert ("main.css?v" + _ver) in ui or "av('/assets/css/main.css')" in ui
    assert _ver.isdigit() and int(_ver) >= 206
    sw = (ROOT / "site/sw.js").read_text()
    # ممیزی v329: sw ممکن است av-style یا همان لترال قدیمی داشته باشد.
    assert f"bazarche-v{_ver}" in sw and (
        "/assets/img/logo-display.png?v183" in sw
        or "logo-display.png" in sw)
    print("PASS logo-v183: full source preserved, fast display asset, derivatives, PWA, refs")


if __name__ == "__main__":
    main()
