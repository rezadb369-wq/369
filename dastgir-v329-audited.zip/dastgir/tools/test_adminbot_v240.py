#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v240: the admin copilot gets EVERYTHING the panel can edit.

Covers the new surface: dynamic settings, business category/map/images,
item images/options/spec, coupons, toplists, flashdeals, city events, ads,
plans, badges, stories, claims, ticket replies, customer block/unblock,
order/booking status, area rename, trash restore, review delete -- plus
the photo pipeline: the owner sends a photo in Bale, adminbot stores it
(uploads.save_image) and tools reference it as "__last__", resolved
server-side only. Security pins: secret/locked settings still refused,
arbitrary filesystem paths in image fields refused, unknown tools dropped.
"""
import os, sys, json, time, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='adm-v240-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT, uploads
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')

SCRIPT = []
def fake_chat(*a, **k):
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True

def propose(model_answer, question='تغییر بده'):
    SCRIPT.append(model_answer)
    return A.handle_text('u1', CHAT, question)[0]

# ممیزی v329: سیاست v320 — propose خودکار «بله» می‌زند تا تست‌های پین
# قدیمی (که اجرای فوری انتظار داشتند) بدون بازنویسی صدها assertion سبز بمانند.
# تست‌هایی که خودشان «بله» می‌زنند pending خالی پیام آرام می‌گیرند.
_propose_raw = propose
def propose(model_answer, question='تغییر بده'):
    r = _propose_raw(model_answer, question)
    if ('برای اعمال' in r or 'گزارش اقدام پیشنهادی' in r
            or 'گزارش اقدام:' in r):
        r2 = A.handle_text('u1', CHAT, 'بله')[0]
        return (r + "\n" + str(r2)) if r2 else r
    return r


db.init()
CHAT = '893219571'
t = lambda text, chat=CHAT: A.handle_text('u1', chat, text)[0]
yes = lambda: t('بله')

# ---- fixture: owner + claim, customers, businesses, pending review, ticket, order, booking, plan
owner = db._one("SELECT * FROM owners ORDER BY id LIMIT 1") or \
    db._run("INSERT INTO owners(name,phone) VALUES('مالک تست','09120000099')") and \
    db._one("SELECT * FROM owners ORDER BY id DESC LIMIT 1")
buyer = db.customer_by_phone('09120000051', create=True)
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,phone,city,area,published_once) "
            "VALUES('pub9','فروشگاه نه','services','published','0219','تهران','سعادت‌آباد',1)")
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,phone,city,published_once) "
            "VALUES('pend9','در انتظار نه','services','pending','0218','تبریز',0)")
con.commit(); con.close()
B1, B2 = 1, 2
db._run("INSERT INTO claims(biz_id,owner_id,note) VALUES(?,?,?)", (B1, owner['id'], 'مالکم'))
CLAIM = db._one("SELECT id FROM claims ORDER BY id DESC")['id']
con = db.connect()
con.execute("INSERT INTO reviews(biz_id,author,rating,body,status) VALUES(1,'ک',5,'خوب','pending')")
con.execute("INSERT INTO tickets(owner_id,subject,status) VALUES(?,'مشکل تست','open')", (owner['id'],))
con.commit(); con.close()
RID, TID = 1, 1
db.create_order(B1, buyer['id'], 'خریدار', '09120000051', 'آدرس', '',
                [{'item_id': None, 'title': 'کالا', 'price': 700, 'qty': 1}])
OID = db._one("SELECT id FROM orders ORDER BY id DESC")['id']
con = db.connect()
con.execute("INSERT INTO bookings(biz_id,name,phone,date,time,status) "
            "VALUES(1,'نوبت تست','09120000051','2026-09-20','17:30','new')")
con.commit(); con.close()
KID = db._one("SELECT id FROM bookings ORDER BY id DESC")['id']
PLAN = db._one("SELECT id,slug FROM plans ORDER BY id LIMIT 1")
# a real uploaded image on disk (as if the owner had sent a photo)
_real = ROOT / 'site' / 'assets' / 'img' / 'og-default.png'
png = _real.read_bytes()[:3 * 1024 * 1024] if _real.exists() else bytes.fromhex(
    '89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000'
    '000d49444154789c626001000000ffff030000060005000000000049454e44ae426082')
ck(len(png) > 100, 'fixture image bytes available')
IMG_PATH, _err = uploads.save_image(png, prefix='admin')
ck('assets/img/uploads/admin-' in IMG_PATH, 'fixture image saved to uploads')
ck(CT.image_save(IMG_PATH), 'image side-file saved')

def audits():
    return len(db.audit_log(2000, action='admin_ai_tool'))

def P(tool, args):
    return json.dumps({"reply": "ok", "tool": {"name": tool, "args": args}},
                      ensure_ascii=False)

# ================= 1. photo pipeline: webhook → save → __last__
A._download_file = lambda fid, max_bytes=3 * 1024 * 1024 + 1: png
SENT.clear()
A.handle_update({"update_id": 100, "message": {
    "chat": {"id": int(CHAT), "type": "private"}, "from": {"id": 1},
    "photo": [{"file_id": "AbcDef12345678", "file_size": 100},
              {"file_id": "AbcDef12345678", "file_size": 900}]}})
ck(any('عکس ثبت شد' in s for s in SENT), 'photo acknowledged')
last = CT.image_last()
ck('assets/img/uploads/admin-' in last, '__last__ resolves to the uploaded photo')
ck(IMG_PATH != last, 'each photo gets a fresh file')
A.handle_update({"update_id": 101, "message": {
    "chat": {"id": int(CHAT), "type": "private"}, "from": {"id": 1}, "photo": []}})
A._download_file = lambda fid, max_bytes=3 * 1024 * 1024 + 1: b''
SENT.clear()
A.handle_update({"update_id": 102, "message": {
    "chat": {"id": int(CHAT), "type": "private"}, "from": {"id": 1},
    "photo": [{"file_id": "AbcDef12345678", "file_size": 10}]}})
ck(any('دانلود نشد' in s for s in SENT), 'failed download is friendly')
stranger_photo = A.handle_update({"update_id": 103, "message": {
    "chat": {"id": 111, "type": "private"}, "from": {"id": 111},
    "photo": [{"file_id": "AbcDef12345678", "file_size": 10}]}})
ck(stranger_photo is None, "stranger's photo ignored")

# ================= 2. business: category move + map pin + images via __last__
r = propose(P('business_save', {"id": B1, "cat_slug": "resturan" if db._one(
    "SELECT id FROM categories WHERE slug='resturan'") else "services",
    "lat": "35.7", "lng": "51.4", "images": ["__last__"], "cover": "__last__"}))
# ممیزی v329: سیاست v320 — اول گزارش، بعد بله.
ck('به‌روز شد' in r or 'برای اعمال' in r, 'v320: biz edit presented for confirm')
yes()
b = db._one("SELECT cat_slug,lat,lng,images,cover FROM businesses WHERE id=?", (B1,))
ck(b['lat'] == 35.7 and b['lng'] == 51.4, 'map pin stored')
imgs = json.loads(b['images'])
ck(imgs and 'assets/img/uploads/admin-' in imgs[0], 'images resolved from __last__')
ck('assets/img/uploads/admin-' in b['cover'], 'cover resolved from __last__')
r = propose(P('business_save', {"id": B1, "cat_slug": "no-such-cat"}))
ck('والد' in r or 'معتبر' in r, 'move to missing category refused')
r = propose(P('business_save', {"id": B1, "images": ["assets/img/../../etc/passwd"]}))
ck('درست بود ولی اجرا نشد' in r, 'path traversal in images refused at parse (v250 honest notice)')
r = propose(P('business_save', {"id": B1, "cover": "assets/img/uploads/nope.webp"}))
ck('عکسی' in r, 'non-existent image path refused at precheck')

# ================= 3. item: images + options + spec
r = propose(P('item_save', {"id": 0, "biz_id": B1, "title": "پیتزا مخصوص",
                            "price": "250000", "options": [{"name": "بزرگ", "price": 30000}],
                            "spec": {"خمیر": "نازک"}, "images": ["__last__"]}))
ck('📦 محتوا ذخیره شد' in r, 'v268: item with options/spec saved at once')
yes()
it = db._one("SELECT * FROM items WHERE title='پیتزا مخصوص'")
ck(json.loads(it['options']) == [{"name": "بزرگ", "price": 30000}], 'options stored as JSON')
ck(json.loads(it['spec']) == {"خمیر": "نازک"}, 'spec stored as JSON')
ck('assets/img/uploads/admin-' in json.loads(it['images'])[0], 'item image resolved')
name, _ = CT.parse_tool_call({'name': 'item_save', 'args': {
    'id': 0, 'biz_id': B1, 'options': 'not-a-list'}})
ck(name is None, 'non-list options refused')

# ================= 4. dynamic settings: any panel key, secrets still locked
db.set_setting('order_cancel_minutes', '30')      # exists in settings now
r = propose(P('setting', {"key": "order_cancel_minutes", "value": "45"}))
yes()
ck(db.get_settings()['order_cancel_minutes'] == '45', 'existing numeric key updated')
r = propose(P('setting', {"key": "ai_daily_cap", "value": "3000"}))
ck('«ai_daily_cap» ذخیره شد' in r, 'v268: dynamic key written at once')
yes()
ck(db.get_settings().get('ai_daily_cap') == '3000', 'dynamic key written')
name, _ = CT.parse_tool_call({'name': 'setting', 'args': {"key": "owner_token", "value": "x"}})
ck(name == 'setting', 'v265: owner_token writable (full access)')
name, _ = CT.parse_tool_call({'name': 'setting', 'args': {"key": "panel_allow_ips", "value": "1.2.3.4"}})
ck(name == 'setting', 'v265: panel_allow_ips writable (full access)')
name, _ = CT.parse_tool_call({'name': 'setting', 'args': {"key": "Bad Key!", "value": "x"}})
ck(name is None, 'malformed key refused')
r = propose(P('setting', {"key": "totally_unknown_xyz", "value": "1"}))
ck('شناخته نشد' in r, 'never-existed key refused at precheck')

# ================= 5. coupons
r = propose(P('coupon_save', {"id": 0, "biz_id": B1, "code": "NOWRUZ",
                              "title": "جشن نوروز", "percent": 20, "expires": "2026-12-20"}))
ck('کد «NOWRUZ» ذخیره شد' in r, 'v268: coupon saved at once')
yes()
c = db._one("SELECT * FROM coupons WHERE code='NOWRUZ'")
ck(c and c['percent'] == 20 and c['biz_id'] == B1, 'coupon stored')
r = propose(P('coupon_delete', {"id": c['id']}))
yes()
ck(not db._one("SELECT id FROM coupons WHERE code='NOWRUZ'"), 'coupon deleted')

# ================= 6. toplists (manual list with real biz ids)
r = propose(P('toplist_save', {"id": 0, "title": "برترین‌های تست", "kind": "manual",
                               "items": [B1], "limit_n": 5}))
ck('لیست «برترین‌های تست»' in r, 'toplist proposed')
yes()
tl = db._one("SELECT * FROM toplists WHERE title='برترین‌های تست'")
ck(json.loads(tl['items']) == [B1], 'toplist items stored')
r = propose(P('toplist_save', {"id": 0, "title": "بد", "kind": "manual", "items": [9999]}))
ck('پیدا نشد' in r, 'toplist with unknown biz refused')

# ================= 7. flashdeal
r = propose(P('flashdeal_save', {"id": 0, "biz_id": B1, "title": "حراج تست",
                                 "percent": 30, "starts": "2026-09-11 08:00",
                                 "ends": "2026-09-13 20:00"}))
yes()
fd = db._one("SELECT * FROM flashdeals WHERE title='حراج تست'")
ck(fd and fd['starts'] == '2026-09-11 08:00:00', 'flashdeal stored (T/seconds normalised)')
name, _ = CT.parse_tool_call({'name': 'flashdeal_save', 'args': {
    'biz_id': B1, 'title': 'x', 'percent': 150, 'ends': '2026-09-13 20:00'}})
ck(name is None, 'percent >99 refused')

# ================= 8. city event
r = propose(P('event_save', {"id": 0, "title": "جشنواره تست", "place": "پارک شهر",
                             "date": "2026-10-01", "time": "17:00", "image": "__last__"}))
yes()
ev = db._one("SELECT * FROM cityevents WHERE title='جشنواره تست'")
ck(ev and 'assets/img/uploads/admin-' in ev['image'], 'event image resolved')

# ================= 9. ad (banner)
r = propose(P('ad_save', {"id": 0, "title": "بنر تست", "body": "متن",
                          "url": "https://daastgir.ir", "slot": "home", "weight": 5}))
yes()
ad = db._one("SELECT * FROM ads WHERE title='بنر تست'")
ck(ad and ad['slot'] == 'home' and ad['weight'] == 5, 'ad stored')
name, _ = CT.parse_tool_call({'name': 'ad_save', 'args': {'title': 'x', 'url': 'javascript:alert(1)'}})
ck(name is None, 'javascript: url refused')

# ================= 10. plans
r = propose(P('plan_save', {"id": PLAN['id'], "name": db._one(
    "SELECT name FROM plans WHERE id=?", (PLAN['id'],))['name'], "price": "990000"}))
ck('پلن' in r, 'plan edit proposed')
yes()
ck(db._one("SELECT price FROM plans WHERE id=?", (PLAN['id'],))['price'] == 990000,
   'plan price updated')

# ================= 11. badges
r = propose(P('badge_save', {"id": 0, "slug": "trust", "name": "مورد اعتماد", "color": "#059669"}))
yes()
bg = db._one("SELECT * FROM badges WHERE slug='trust'")
ck(bg and bg['name'] == 'مورد اعتماد', 'badge created')
name, _ = CT.parse_tool_call({'name': 'badge_save', 'args': {'name': 'x', 'color': 'red'}})
ck(name is None, 'non-hex colour refused')

# ================= 12. story with the owner's photo
r = propose(P('story_add', {"biz_id": B1, "image": "__last__", "caption": "تست"}))
ck('استوری' in r, 'story proposed')
yes()
st = db._one("SELECT * FROM stories WHERE biz_id=? ORDER BY id DESC", (B1,))
ck(st and 'assets/img/uploads/admin-' in st['image'] and st['expires'] > time.time(),
   'story live with resolved image')
r = propose(P('story_add', {"biz_id": B1, "image": "assets/img/uploads/missing.webp"}))
ck('عکسی' in r, 'story without a real image refused')

# ================= 13. claim moderation assigns ownership
r = propose(P('claim_moderate', {"id": CLAIM, "action": "approve"}))
ck('واگذار شد' in r, 'v268: claim approved at once')
yes()
ck(db._one("SELECT owner_id FROM businesses WHERE id=?", (B1,))['owner_id'] == owner['id'],
   'claim approval transferred the business')
r = propose(P('claim_moderate', {"id": CLAIM, "action": "approve"}))
ck('قبلاً' in r, 'already-decided claim refused')

# ================= 14. ticket reply notifies the owner
on0 = db._one("SELECT COUNT(*) c FROM owner_notifications")['c']
r = propose(P('ticket_reply', {"id": TID, "body": "پاسخ تست از دستیار"}))
ck('تیکت' in r, 'ticket reply proposed')
yes()
tk = db._one("SELECT status,unread_user FROM tickets WHERE id=?", (TID,))
ck(tk['status'] == 'answered' and tk['unread_user'] == 1, 'ticket answered (panel parity)')
ck(db._one("SELECT COUNT(*) c FROM owner_notifications")['c'] == on0 + 1,
   'ticket reply notified the owner')

# ================= 15. customer block/unblock (kills sessions like the panel)
r = propose(P('customer_moderate', {"phone": "09120000051", "action": "block"}))
ck('مسدود' in r, 'block proposed')
yes()
ck(db._one("SELECT status FROM customers WHERE phone='09120000051'")['status'] == 'blocked',
   'customer blocked')
r = propose(P('customer_moderate', {"phone": "09120000051", "action": "unblock"}))
yes()
ck(db._one("SELECT status FROM customers WHERE phone='09120000051'")['status'] == 'active',
   'customer unblocked')
r = propose(P('customer_moderate', {"phone": "09990000000", "action": "block"}))
ck('پیدا نشد' in r, 'unknown phone refused')

# ================= 16. order + booking status
r = propose(P('order_status', {"id": OID, "status": "confirmed"}))
yes()
ck(db._one("SELECT status FROM orders WHERE id=?", (OID,))['status'] == 'confirmed',
   'order status updated')
name, _ = CT.parse_tool_call({'name': 'order_status', 'args': {"id": OID, "status": "shipped"}})
ck(name is None, 'invalid order status refused')
r = propose(P('booking_status', {"id": KID, "status": "done"}))
yes()
ck(db._one("SELECT status FROM bookings WHERE id=?", (KID,))['status'] == 'done',
   'booking status updated')

# ================= 17. area rename
con = db.connect()
con.execute("UPDATE businesses SET area='سعادت‌آباد' WHERE id=?", (B1,))
con.commit(); con.close()
r = propose(P('area_rename', {"old": "سعادت‌آباد", "new": "سعادت آباد"}))
ck('محله' in r, 'area rename proposed')
yes()
ck(db._one("SELECT area FROM businesses WHERE id=?", (B1,))['area'] == 'سعادت آباد',
   'area renamed everywhere')
r = propose(P('area_rename', {"old": "محلهٔ ناموجود", "new": "x"}))
ck('پیدا نشد' in r, 'unknown area refused')

# ================= 18. trash restore (item from earlier suites)
con = db.connect()
con.execute("INSERT INTO items(biz_id,title,price,kind) VALUES(?,'قربانی تست',100,'product')", (B1,))
con.commit(); con.close()
VICTIM = db._one("SELECT id FROM items WHERE title='قربانی تست'")['id']
db.delete_item(VICTIM)
TRASH = db._one("SELECT id FROM trash WHERE entity='item' AND ref_id=?", (VICTIM,))
ck(TRASH, 'deleted item landed in trash')
r = propose(P('trash_restore', {"id": TRASH['id']}))
ck('بازیافت' in r, 'v268: trash restored at once')
yes()
ck(db._one("SELECT id FROM items WHERE id=?", (VICTIM,)), 'item restored from trash')

# ================= 19. review delete (silent, abuse path)
r = propose(P('review_delete', {"id": RID}))
yes()
ck(not db._one("SELECT id FROM reviews WHERE id=?", (RID,)), 'review deleted')

# ================= 20. every execution above wrote an audit row; unknown tool still dropped
ck(audits() >= 18, 'every mutation audit-logged')
ck('معتبر شناخته نشد' in propose('{"reply":"ok","tool":{"name":"format_disk","args":{}}}'),
   'unknown tool dropped with a visible notice')

# ================= 21. inventory shows the new surfaces + last photo
snap = A.admin_snapshot()
for word in ('کدهای تخفیف', 'لیست‌ها', 'رویدادها', 'بنرها', 'پلن‌ها',
             'تیکت‌های باز', 'آخرین عکس ارسالی مدیر'):
    ck(word in snap, f'inventory shows {word}')
ck(IMG_PATH not in snap or CT.image_last(), 'inventory photo line consistent')

# ================= 22. help mentions photos
ck('عکس' in A.handle_text('u1', CHAT, 'راهنما')[0], 'help explains the photo flow')

print(f'v240 full-power tools: {n} checks green')
