#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v243: GPT-6 Astra (and any OpenAI-compatible gateway) as the copilot's
brain — installed from the Bale chat itself:
  /کلید astra sk-…
  /کلید openai <base> <key> <model>
Live key test → job → codeguard installs base/key/model (+AI_TIMEOUT=40),
keeps the previous brain as fallback, restarts, notifies. Keys are never
echoed, logged, or remembered.
"""
import os, sys, json, time, subprocess, tempfile, urllib.error
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v243-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT, adminbot_code as CODE
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')

SCRIPT = []
def fake_chat(*a, **k):
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text, chat=CHAT: A.handle_text('u1', chat, text)[0]
yes = lambda: t('بله')
def P(tool, args):
    return json.dumps({"reply": "ok", "tool": {"name": tool, "args": args}},
                      ensure_ascii=False)
def jobs():
    d = os.path.join(TMP, 'code-jobs')
    return [json.load(open(os.path.join(d, x), encoding='utf-8'))
            for x in sorted(os.listdir(d))] if os.path.isdir(d) else []

SK = "sk-astra" + "x" * 30
GW_KEY = "gh_" + "k" * 30

# ================= 1. /کلید astra — direct GPT-6 Astra key
r = t('/کلید astra ' + SK)
ck('صف' in r and SK not in r, 'astra key accepted, never echoed')
ck(any(j['kind'] == 'ai_key' and j['provider'] == 'astra' and j['key'] == SK
       for j in jobs()), 'astra job queued with the exact key')
r = t('/کلید astra کلید-خراب')
ck('شکل کلید' in r or 'معتبر' in r, 'malformed astra key refused')

# ================= 2. /کلید openai — any OpenAI-compatible gateway
r = t('/کلید openai https://api.gw.example/v1 ' + GW_KEY + ' gpt-6-astra')
ck('صف' in r and GW_KEY not in r, 'gateway key accepted')
j = [x for x in jobs() if x.get('provider') == 'openai']
ck(j and j[-1]['base'] == 'https://api.gw.example/v1'
   and j[-1]['model'] == 'gpt-6-astra' and j[-1]['key'] == GW_KEY,
   'gateway job carries base+model+key')
r = t('/کلید openai ' + 'sk-directkey1234567890abcdef' + ' gpt-6-astra')
ck('صف' in r, '2-token openai form defaults to api.openai.com')
j2 = [x for x in jobs() if x.get('provider') == 'openai']
ck(j2[-1]['base'] == 'https://api.openai.com/v1', 'default base applied')
r = t('/کلید openai http://insecure.example/v1 ' + GW_KEY + ' m')
ck('نامعتبر' in r or 'شکل' in r or 'معتبر' in r, 'non-https base refused')
r = t('/کلید openai https://a.b/v1 کوتاه m')
ck('شکل کلید' in r or 'معتبر' in r, 'short gateway key refused')

# ================= 3. bare sk- key auto-detected as astra
r = t('/کلید ' + SK)
ck('صف' in r and any(j['provider'] == 'astra' for j in jobs()
                     if j['kind'] == 'ai_key'), 'bare sk- key auto-routed to astra')

# ================= 4. live key test failures are clear
def deny(*a, **k):
    raise urllib.error.HTTPError("u", 401, "Unauthorized", {}, None)
AI._chat = deny
r = t('/کلید astra ' + "sk-" + "y" * 30)
ck('قبول نکرد' in r, '401 key gets the fix-it message')
AI._chat = fake_chat

# ================= 5. model-proposal path (v268: no wall) hides the key too
SCRIPT.append(P('ai_setup', {"provider": "openai", "base": "https://api.gw.example/v1",
                             "key": GW_KEY, "model": "gpt-6-astra"}))
# ممیزی v329: v316 «کلید» لخت = دستور مستقیم — متن نباید با «کلید» شروع شود؛
# v320: اول گزارش، بعد «بله».
r = t('اتصال گیت‌وی‌ام: ' + GW_KEY)
ck(('برای اعمال' in r or 'گزارش اقدام' in r) and GW_KEY not in r,
   'v320: key install proposed for confirm, key hidden')
yes()
ck(any(j.get('provider') == 'openai' for j in jobs()), 'v320: queued after «بله»')

# ================= 6. usage text teaches all providers
# v259 (دستور مدیر: «توکن کلود دقیق پیاده بشه»): راهنما حالا Claude را
# پیش‌فرض می‌داند و مثالش claude-sonnet-5 است (v260: شناسهٔ مستند AvalAI)؛
# astra از لاین chatgpt می‌آید.
r = t('/کلید')
ck('astra' in r and 'openai' in r and 'gemini' in r and 'Muse' in r, 'usage lists every provider')
ck('claude-sonnet-5' in r, 'usage shows the Claude example')

# ================= 7. redaction covers sk- keys on the wire
SENT.clear()
A.handle_update({"update_id": 300, "message": {
    "chat": {"id": int(CHAT), "type": "private"}, "from": {"id": 1},
    "text": "این کلید را دیدی؟ " + SK}})
ck(all(SK not in s for s in SENT), 'sk- keys redacted in every reply')

# ================= 8. codeguard installs astra as root (timeout + fallback)
G = Path(tempfile.mkdtemp(prefix='cg243-'))
APP = G / 'app'
(APP / 'data' / 'code-jobs').mkdir(parents=True)
(APP / 'data' / 'code-backups').mkdir(parents=True)
(APP / 'server').mkdir(parents=True)
(APP / 'server' / 'x.py').write_text('X = 1\n', encoding='utf-8')
SEC = G / 'secrets.env'
SEC.write_text('AI_BASE_URL=https://old/v1\nAI_API_KEY=oldkey\nAI_MODEL=oldmodel\n'
               'AI_TIMEOUT=12\n', encoding='utf-8')
(APP / 'data' / 'code-jobs' / 'a.json').write_text(
    json.dumps({"kind": "ai_key", "provider": "astra", "key": SK}), encoding='utf-8')
def stub(name, body):
    s = G / name; s.write_text('#!/usr/bin/env bash\n' + body, encoding='utf-8')
    s.chmod(0o755); return str(s)
SYSCTL = stub('systemctl', 'true')
NOTIFY = stub('notify', 'echo "$1" >> "$NLOG"')
CURL_OK = stub('curl-ok', 'exit 0')
subprocess.run(['bash', str(ROOT / 'deploy' / 'codeguard.sh')],
               env=dict(os.environ, DASTGIR_APP=str(APP), DASTGIR_SYSTEMCTL=SYSCTL,
                        DASTGIR_CURL=CURL_OK, DASTGIR_NOTIFY=NOTIFY,
                        DASTGIR_CODEGUARD_LOG=str(G / 'g.log'),
                        DASTGIR_HEALTHZ='http://x/h', SLOG=str(G / 's.log'),
                        NLOG=str(G / 'n.log'), DASTGIR_SECRETS=str(SEC)),
               capture_output=True, timeout=90)
env_txt = SEC.read_text(encoding='utf-8')
ck('AI_BASE_URL=https://api.openai.com/v1' in env_txt, 'astra base installed')
ck('AI_MODEL=gpt-6-astra' in env_txt, 'astra model installed')
ck('AI_API_KEY=' + SK in env_txt, 'astra key installed')
ck('AI_TIMEOUT=40' in env_txt and 'AI_TIMEOUT=12' not in env_txt,
   'long timeout set for the reasoning model')
ck('AI_FALLBACK_API_KEY' not in env_txt,
   'v251 (owner order): previous brain fully replaced, no fallback kept')
ck('مغز هوش مصنوعی جدید' in (G / 'n.log').read_text(encoding='utf-8'),
   'owner notified about the new brain')

# ================= 9. codeguard installs a generic gateway
SEC.write_text('AI_API_KEY=oldkey\n', encoding='utf-8')
(APP / 'data' / 'code-jobs').mkdir(exist_ok=True)
(APP / 'data' / 'code-jobs' / 'b.json').write_text(
    json.dumps({"kind": "ai_key", "provider": "openai", "key": GW_KEY,
                "base": "https://api.gw.example/v1", "model": "gpt-6-astra"}),
    encoding='utf-8')
subprocess.run(['bash', str(ROOT / 'deploy' / 'codeguard.sh')],
               env=dict(os.environ, DASTGIR_APP=str(APP), DASTGIR_SYSTEMCTL=SYSCTL,
                        DASTGIR_CURL=CURL_OK, DASTGIR_NOTIFY=NOTIFY,
                        DASTGIR_CODEGUARD_LOG=str(G / 'g2.log'),
                        DASTGIR_HEALTHZ='http://x/h', SLOG=str(G / 's.log'),
                        NLOG=str(G / 'n2.log'), DASTGIR_SECRETS=str(SEC)),
               capture_output=True, timeout=90)
env_txt = SEC.read_text(encoding='utf-8')
ck('AI_BASE_URL=https://api.gw.example/v1' in env_txt and
   'AI_MODEL=gpt-6-astra' in env_txt and ('AI_API_KEY=' + GW_KEY) in env_txt,
   'generic gateway installed (base+model+key)')
ck('AI_FALLBACK_API_KEY' not in env_txt,
   'v251 (owner order): fallback chain not kept on re-install either')

# ================= 10. codeguard rejects a tampered job
SEC.write_text('', encoding='utf-8')
(APP / 'data' / 'code-jobs' / 'c.json').write_text(
    json.dumps({"kind": "ai_key", "provider": "openai", "key": GW_KEY,
                "base": "file:///etc/passwd", "model": "x"}), encoding='utf-8')
subprocess.run(['bash', str(ROOT / 'deploy' / 'codeguard.sh')],
               env=dict(os.environ, DASTGIR_APP=str(APP), DASTGIR_SYSTEMCTL=SYSCTL,
                        DASTGIR_CURL=CURL_OK, DASTGIR_NOTIFY=NOTIFY,
                        DASTGIR_CODEGUARD_LOG=str(G / 'g3.log'),
                        DASTGIR_HEALTHZ='http://x/h', SLOG=str(G / 's.log'),
                        NLOG=str(G / 'n3.log'), DASTGIR_SECRETS=str(SEC)),
               capture_output=True, timeout=90)
ck(SEC.read_text(encoding='utf-8') == '', 'non-http base job wrote nothing')

# ================= 11. prompt knows astra
ck('astra' in AI.ADMIN_PROMPT and 'openai' in AI.ADMIN_PROMPT,
   'prompt documents astra + generic gateways')

print(f'v243 astra brain: {n} checks green')
