#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""test_v285.py — round v285: media news/events, person AI quota, map badge contrast,
Q&A edit/delete, slogan, featured products, plans.ai_daily + pricing, rules rewrite,
QR picker, security/speed pins, cleanup pins, cache buster."""
import os, re, sys, tempfile, shutil
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "server"))
DATA = tempfile.mkdtemp(prefix="v285-data-")
os.environ["BZ_DATA_DIR"] = DATA

ok = fail = 0
def check(name, cond, detail=""):
    global ok, fail
    if cond: ok += 1; print("  OK   %s" % name)
    else:    fail += 1; print("  FAIL %s  %s" % (name, detail))

import db
db.init()
SRC = {n: open(os.path.join(ROOT, "server", n), encoding="utf-8").read()
       for n in ("app.py", "views_panel.py", "views_panel2.py", "views_public.py",
                 "views_public2.py", "views_owner.py", "views_catalog.py",
                 "assistant.py", "uploads.py", "db.py", "ui.py")}
CSS = open(os.path.join(ROOT, "site/assets/css/main.css"), encoding="utf-8").read()
MAPP = open(os.path.join(ROOT, "site/assets/js/mappage.js"), encoding="utf-8").read()
ap = SRC["app.py"]

print("== A) DB: new columns persist + media helpers ==")
BID = db.save_business({"name": "فروشگاه نمونه", "slug": "b285", "cat_slug": "food",
                        "city": "نجف‌آباد", "slogan": "کیفیت، تعهد، تکریم"})
PID = db.save_post({"biz_id": BID, "title": "رویداد", "slug": "p285", "body": "متن",
                    "cover": "/assets/img/uploads/x.webp",
                    "video": "/assets/img/uploads/v.mp4", "status": "published"})
EID = db.save_cityevent({"biz_id": BID, "title": "جشنواره", "date": "1404-06-10",
                         "image": "/assets/img/uploads/ev.webp",
                         "video": "/assets/img/uploads/ev.mp4"})
db.save_plan({"name": "طلایی", "slug": "gold285", "price": "999000", "features": "*",
              "ai_daily": "300", "active": 1})
r1 = db.post("p285"); r2 = db.cityevent(eid=EID); r3 = db.business(slug="b285")
pl = db.plan(slug="gold285")
check("post cover+video persist", r1 and r1["cover"].endswith("x.webp") and r1["video"].endswith("v.mp4"))
check("event image+video persist", r2 and r2["image"].endswith("ev.webp") and r2["video"].endswith("ev.mp4"))
check("business slogan persist", r3 and r3["slogan"] == "کیفیت، تعهد، تکریم")
check("plan ai_daily", pl and int(pl["ai_daily"]) == 300)
import uploads, ui
emb = uploads.embed_from_url("https://www.aparat.com/video/video/embed/videohash/Ab12cd/vt/frame")
check("embed aparat -> iframe", emb and emb[0] == "iframe" and "aparat.com" in emb[1])
emb2 = uploads.embed_from_url("https://www.youtube.com/watch?v=AbCdEf12345")
check("embed youtube -> nocookie iframe", emb2 and emb2[0] == "iframe" and "youtube-nocookie.com/embed/AbCdEf12345" in emb2[1])
emb3 = uploads.embed_from_url("https://example.com/wp-content/v.mp4")
check("embed direct https mp4 -> video", emb3 and emb3[0] == "video")
check("embed javascript: rejected", uploads.embed_from_url("javascript:alert(1)") is None)
check("embed unknown host rejected", uploads.embed_from_url("https://evil.example/x") is None)
check("embed http:// rejected", uploads.embed_from_url("http://www.aparat.com/v/Ab12cd") is None)
me = ui.media_embed("/assets/img/uploads/v.mp4", "t")
check("media_embed file -> <video>", me.startswith("<video") and "controls" in me)
me2 = ui.media_embed(emb[1], "t")
check("media_embed aparat -> <iframe>", "<iframe" in me2 and "allowfullscreen" in me2)
check("media_embed empty/garbage -> ''", ui.media_embed("") == "" and ui.media_embed("data:text/html,x") == "")
check("save_news_media cap 64MB", "NEWS_VIDEO_MAX = 64 * 1024 * 1024" in SRC["uploads.py"])

print("== B) person-scoped AI quota + plan override ==")
import assistant
cust = db.customer_by_phone("09121234567", create=True)
owner = db.owner_by_phone("09121234567", create=True)
db.set_business_owner(BID, owner["id"])
assistant._count("cust:%s" % cust["id"], "test", 0, 0, "t", quota=1)
assistant._count("cust:%s" % cust["id"], "test", 0, 0, "t", quota=1)
assistant._count("owner:%s" % owner["id"], "test", 0, 0, "t", quota=1)
check("person_used combines customer+owner", assistant.person_used(cust, owner) == 3,
      "used=%s" % assistant.person_used(cust, owner))
rem, tier = assistant.person_remaining(cust, owner)
check("person_remaining (free 5-3=2)", rem == 2 and tier == "free", "rem=%s tier=%s" % (rem, tier))
check("plan_ai_quota -1 before subscription", assistant.plan_ai_quota(cust, None) == -1)
res = db.request_subscription(BID, "gold285")
sid = res[0] if isinstance(res, tuple) else res
db.activate_subscription(sid)
check("plan_ai_quota override via phone-derived owner", assistant.plan_ai_quota(cust, None) == 300)
check("quota_for plan override wins", assistant.quota_for("plus", None, owner) == 300)
rem2, tier2 = assistant.person_remaining(cust, owner)
check("person_remaining after override (300-3)", rem2 == 297, "rem=%s" % rem2)
check("answer() takes customer/owner", "customer=None, owner=None" in SRC["assistant.py"])
check("status API uses person_remaining", "person_remaining" in ap)
check("owner strip live quota (data-quota-rem + poll)",
      "data-quota-rem" in SRC["views_owner.py"] and "/api/assistant/status" in SRC["views_owner.py"])

print("== C) map featured badge contrast ==")
def lum(hexc):
    hexc = hexc.lstrip("#")
    r, g, b = (int(hexc[i:i+2], 16) / 255 for i in (0, 2, 4))
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)
def ratio(a, b):
    la, lb = lum(a), lum(b)
    if la < lb: la, lb = lb, la
    return (la + 0.05) / (lb + 0.05)
m = re.search(r"\.badge-featured\s*\{([^}]+)\}", CSS)
check("badge-featured light block", bool(m) and "linear-gradient" in m.group(1))
stops = re.findall(r"#([0-9a-fA-F]{6})", re.search(r"linear-gradient\(([^)]+)\)", m.group(1)).group(1)) if m else []
txt = re.search(r"color:\s*#([0-9a-fA-F]{6})", m.group(1)) if m else None
lr = ratio(min(stops, key=lum), txt.group(1)) if len(stops) >= 2 and txt else 0
check("day contrast >= 4.5 (%.1f)" % lr, lr >= 4.5)
d = re.search(r':root\[data-theme="dark"\] \.badge-featured\s*\{([^}]+)\}', CSS)
check("dark override exists", bool(d))
if d:
    dstops = re.findall(r"#([0-9a-fA-F]{6})", d.group(1))
    dgrad = re.search(r"linear-gradient\(([^)]+)\)", d.group(1))
    dstops = re.findall(r"#([0-9a-fA-F]{6})", dgrad.group(1)) if dgrad else []
    dtxt = re.search(r"color:\s*#([0-9a-fA-F]{6})", d.group(1))
    dr = ratio(min(dstops, key=lum), dtxt.group(1)) if len(dstops) >= 2 and dtxt else 0
    check("night contrast >= 4.5 (%.1f)" % dr, dr >= 4.5)
check("mappage.js badge markup", "badge-featured" in MAPP)

print("== D) Q&A edit/delete ==")
qid = db.add_question(BID, "پرسشگر", "سوال اولیه")
db.question_set_body(qid, "سوال اصلاح‌شده")
qq = db.question(qid)
check("question edited persisted", qq["body"] == "سوال اصلاح‌شده" and qq["edited"])
db.answer_question(qid, "پاسخ اول")
db.answer_set(qid, "پاسخ ویرایش‌شده")
check("answer edited persisted", db.question(qid)["answer_edited"])
db.answer_clear(qid)
check("answer cleared", db.question(qid)["answered"] is None)
db.answer_question(qid, "پاسخ دوم")
db.question_soft_delete(qid)
check("soft delete hides question", qid not in [x["id"] for x in db.questions(BID)])
for name, needle, src in (
        ("route regex", r'/qa/(\d+)/(edit|delete|answer-edit|answer-delete)', ap),
        ("rate limit qaedit", 'rate_ok("qaedit:"', ap),
        ("asker ownership check", 'mine = bool(cust and row["customer_id"]', ap),
        ("owner gate db.owns", 'db.owns(own["id"], row["biz_id"])', ap),
        ("edit window 15min", "QA_EDIT_WINDOW = 15 * 60", SRC["db.py"]),
        ("content_gate on edits", 'content_gate("qa"', ap),
        ("edited pill qa_block", "qa-edited", SRC["views_public2.py"]),
        ("edited pill CSS", ".qa-edited", CSS),
        ("owner delete-answer UI", "answer-delete", SRC["views_owner.py"])):
    check("pin: " + name, needle in src)

print("== E) slogan + featured products rendering ==")
check("about renders biz-slogan", "biz-slogan" in SRC["views_public.py"])
check("about shows تنوع + ویژه count", "تنوع" in SRC["views_public.py"] and "n_feat" in SRC["views_public.py"])
check("catalog featured shelf", "محصولات ویژه" in SRC["views_catalog.py"] and "special-card" in SRC["views_catalog.py"])
db.save_item({"biz_id": BID, "title": "کالای عادی", "kind": "product", "available": 1})
db.save_item({"biz_id": BID, "title": "کالای ویژه", "kind": "product", "available": 1, "featured": 1})
check("items_count total/featured", db.items_count(BID) == 2 and db.items_count(BID, featured_only=True) == 1)
import views_catalog
cat_html = views_catalog.catalog_section(db.business(slug="b285"))
check("catalog_section renders shelf + item", "محصولات ویژه" in cat_html and "کالای ویژه" in cat_html)
check("owner form slogan input", 'name="slogan"' in SRC["views_owner.py"])
check("admin form slogan input", 'name="slogan"' in SRC["views_panel.py"])
check("admin route persists slogan", '"slogan"' in ap)
check("slogan maxlength 120", 'maxlength="120"' in SRC["views_owner.py"] and 'maxlength="120"' in SRC["views_panel.py"])

print("== F) media routes + security + speed pins ==")
check("MAX_FILE default unchanged 3MB", "MAX_FILE = 3 * 1024 * 1024" in SRC["uploads.py"])
check("_save_news_media handler", "_save_news_media" in ap or "save_news_media" in ap)
check("video kind re-check on upload", "فایل انتخابی ویدیو نیست" in ap)
check("admin-only raised body cap", "NEWS_VIDEO_MAX + 8 * 1024 * 1024" in ap)
check("embed rejection message", "لینک ویدیو پذیرفته نشد" in ap)
check("Range support 206", 'self.headers.get("Range"' in ap and "206" in ap and "Accept-Ranges" in ap)
check("ETag/304 kept", "ETag" in ap and "304" in ap)
check("CSP frame-src allowlist", "frame-src https://www.aparat.com https://www.youtube-nocookie.com https://www.youtube.com" in ap)
check("CSP media-src https", "media-src" in ap and "https:" in ap)
check("qr rate limit 60/min", 'rate_ok("qr:" + self.client_key(), limit=60, window=60)' in ap)
check("news-save rate limit", 'rate_ok("news-save:"' in ap)
check("event save drops pagecache", "_pagecache_drop" in SRC["db.py"].split("def save_cityevent")[1].split("\ndef ")[0])
check("event delete drops pagecache", "_pagecache_drop" in SRC["db.py"].split("def delete_cityevent")[1].split("\ndef ")[0])
check("index idx_questions_status", "idx_questions_status" in SRC["db.py"])
check("index idx_items_biz_feat", "idx_items_biz_feat" in SRC["db.py"])
check("SECURITY_HEADERS intact", "X-Frame-Options" in ap and "Cross-Origin-Opener-Policy" in ap
      and "nosniff" in ap and "Referrer-Policy" in ap)

print("== G) pricing page ==")
import views_public
s_min = {"path": "/pricing", "query": {}, "user": None, "session_id": "t", "client_key": "k"}
price_html = views_public.pricing(s_min)
check("pricing AI line", "پیام هوشمند" in price_html and "sparkles" in price_html)
check("pricing comparison AI row", price_html.count("پیام هوشمند روزانه") >= 1)
check("pricing feature chips", "plan-chip" in price_html)
check("pricing trust strip", "plan-trust" in price_html and "پرداخت امن" in price_html)
check("plan form ai_daily field", 'name="ai_daily"' in SRC["views_panel2.py"])
check("plan route saves ai_daily", "ai_daily" in ap)
check("pricing CSS added", ".plan-chip" in CSS and ".plan-trust" in CSS)

print("== H) rules rewrite ==")
rules = db.get_page("rules")["body"]
for token in ("قانون تجارت الکترونیکی", "حقوق مصرف", "مادهٔ ۱", "daastgir.ir"):
    check("rules has «%s»" % token, token in rules)
n_made = len(set(re.findall(r"مادهٔ \d+", rules)))
check("rules articles >= 10 (%d)" % n_made, n_made >= 10)
check("migration guard _RULES_V1", "_RULES_V1" in SRC["db.py"])
check("static_page renders ## as h2", "rules-h" in SRC["views_public.py"])
db.save_page("rules", "قوانین", "متن دلخواه مدیر")
check("admin-edited rules preserved", db.get_page("rules")["body"] == "متن دلخواه مدیر")

print("== I) QR picker ==")
import views_owner
check("owner_qr view exists", "def owner_qr" in SRC["views_owner.py"])
check("qr route registered", 'path == "/my/qr"' in ap)
check("menu points to /my/qr", "/my/qr" in SRC["ui.py"])
s = {"path": "/my/qr", "query": {}, "user": {"id": owner["id"], "is_admin": False},
     "session_id": "x", "client_key": "k"}
html = views_owner.owner_qr(s, owner, {}, BID)
check("owner_qr renders QR + slug", "b285" in html and "/qr/b285.svg" in html)
check("owner_qr print + download", "window.print" in html and "dl=1" in html)
check("qr print CSS", "qr-page" in CSS)

print("== J) cleanup + cache buster ==")
check("admin-edit.js removed", not os.path.exists(os.path.join(ROOT, "site/assets/js/admin-edit.js")))
check("_harness removed", not os.path.exists(os.path.join(ROOT, "site/assets/_harness")))
check("retired README kept (md rule)", os.path.exists(os.path.join(ROOT, "tools/retired/README.md")))
# ممیزی v329 (v298): av() منبع واحد — قبول لترال نسخه یا av().
_ver = open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8").read().strip()
check("cache buster av/VERSION",
      ("main.css?v" + _ver) in SRC["ui.py"] or "av('/assets/css/main.css')" in SRC["ui.py"])
check("no v284 css refs left", "main.css?v284" not in SRC["ui.py"])

shutil.rmtree(DATA, ignore_errors=True)
print("\n== result: %d OK, %d FAIL ==" % (ok, fail))
sys.exit(1 if fail else 0)
