#!/usr/bin/env python3
# دستور مدیر: پین انتشار با v281 هماهنگ شد؛ رفتار محصول تغییر نکرده است.
# -*- coding: utf-8 -*-
"""v259: مغز Claude — فقط پنل کاربری و مدیرتیم، با دسترسی کامل.

Owner's order (2026-09-10): «توکن کلود را تست کن؛ فقط برای پنل کاربری و
مدیرتیم باشه؛ تمام دسترسی‌ها؛ از ربات بله مثل دستیار همه‌کاره فایل‌ها و
داده‌ها را اجرا کنه؛ بدون توصیهٔ امنیتی؛ کلید دقیق پیاده بشه».

Pins:
1) Guest gate: guests (signed-out) never call the model (degraded=login,
   rules + free semantic cache + login upsell); quota untouched. Signed-in
   users get full smart answers. Panel switch ai_guest_model (default OFF).
2) Team: BALE_ADMIN_CHAT is a comma list — every member answers with full
   access; outsiders still denied.
3) Claude lane: provider muse (aa-… via https://api.avalai.ir/v1,
   claude-sonnet-5 + smart claude-opus-5, timeout 40) in /کلید, bare
   aa-… auto-install, ai_setup parse/reasons, prompt, codeguard; aa-… keys
   are redacted everywhere. The real key is NEVER printed here.
"""
import os, sys, json, subprocess, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

# v289: deploy/brain.env carries the live AI keys and is stripped from any
# shared artifact on purpose (RULES: secrets never leave the box). When the
# file is absent this suite cannot test the brain, so it reports a named
# environmental skip with exit 78 (EX_CONFIG) instead of a red that looks like
# a code fault. Put the real brain.env back and it runs for real.
_BRAIN = ROOT / "deploy" / "brain.env"
if not _BRAIN.is_file():
    print("SKIP  deploy/brain.env موجود نیست — این سوئیت مغز AI را تست می‌کند و")
    print("      کلیدها عمداً از بستهٔ اشتراکی حذف شده‌اند. فایل را برگردانید")
    print("      تا واقعی اجرا شود. (خروجی ۷۸ = EX_CONFIG، نه شکست کد)")
    raise SystemExit(78)


TMP = tempfile.mkdtemp(prefix='adm-v259-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '111, 222'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'https://api.example.invalid/v1'
os.environ['AI_API_KEY'] = 'test-key-not-real'
os.environ['AI_MODEL'] = 'fake-lite'
# v269 (دستور مدیر: هوش سایت کاملاً جدا از محیط مدیر): چت کاربران از
# اسلات AI_SITE_* می‌خواند — انتظارهای «پاسخ هوشمند کاربر» این سوئیت
# به همان اسلات وصل می‌شوند، نه شکاف‌های قدیمی.
os.environ['AI_SITE_BASE_URL'] = 'https://site.example.invalid/v1'
os.environ['AI_SITE_API_KEY'] = 'test-site-key-not-real'
os.environ['AI_SITE_MODEL'] = 'site-model'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT, \
    adminbot_code as CODE
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
calls = []
def fake_chat(base, key, model, messages, timeout, max_tokens=220):
    calls.append(model)
    return json.dumps({"answer": "پاسخ هوشمند تستی.",
                       "links": [], "scope": True, "intent": "faq"}), 100
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append((cid, text)) or True
db.init()
t = lambda text, chat='111': A.handle_text('u1', chat, text)[0]
ctx = lambda key, **kw: dict({"channel": "web", "user_key": key,
                              "customer": None, "owner": None}, **kw)
AA = 'aa-fake' + 'k' * 44          # same-shape dummy, never a real key

# ================= 1. guest gate: no model for signed-out users
ck(AI.is_guest(ctx("g1")) and not AI.guest_model_allowed(),
   'guest detected; guest-model switch defaults to OFF')
ncalls = len(calls)
r = AI.answer("بهترین رستوران شهر را معرفی کن", ctx("g1"))
ck(r["ok"] and r["degraded"] == "login" and r["source"] in ("rule", "rule-fallback")
   and len(calls) == ncalls,
   'guest gets rules with degraded=login, the model is never called')
ck("وارد" in r["text"] and "/login" in [h for _, h in r["links"]],
   'guest answer carries the login upsell + /login link')
ck(AI.quota_used_today("g1") == 0 and AI.remaining("g1", "free") == 5,
   'gated answer costs no quota')
cust = db.customer_by_phone("09120000259", create=True)
r = AI.answer("بهترین رستوران شهر را معرفی کن",
              ctx(f"cust:{cust['id']}", customer=cust))
ck(r["source"] == "llm" and r["degraded"] == "" and len(calls) == ncalls + 1,
   'signed-in user gets the full smart answer')
db.set_settings({"ai_guest_model": "1"})
ck(AI.guest_model_allowed(), 'panel switch turns the guest model on')
r = AI.answer("سؤال تازهٔ مهمان برای مدل", ctx("g2"))
ck(r["source"] == "llm", 'guest with the switch ON reaches the model')
db.set_settings({"ai_guest_model": "0"})
r = AI.answer("سؤال دیگر مهمان", ctx("g3"))
ck(r["degraded"] == "login", 'switch back OFF → guests gated again')

# ================= 2. the free cache still serves gated guests
AI.cache_store("سؤال کشویی تکراری", ctx("g9"), None, "جواب کش‌شده",
               [], "", "fast", 10)
r = AI.answer("سؤال کشویی تکراری", ctx("g9"))
ck(r["source"] == "cache" and r["text"] == "جواب کش‌شده" and r["degraded"] == "",
   'gated guest still gets the $0 cached answer')

# ================= 3. panel shows the switch + the v259 policy note
import views_panel2 as P
html = P.assistant_page(db.get_settings(), "tok", {})
ck('name="ai_guest_model"' in html and 'فقط پنل کاربری و مدیرتیم' in html,
   'panel has the guest-model switch + policy note')
ck('"ai_guest_model"' in (ROOT / 'server' / 'app.py').read_text(encoding='utf-8')
   and db.DEFAULT_SETTINGS.get("ai_guest_model") == "0",
   'panel POST accepts the switch; default OFF in db defaults')

# ================= 4. team: every chat id answers, outsiders denied
ck(A.owner_chats() == ["111", "222"] and A.owner_chat() == "111",
   'comma list parsed; owner_chat() stays backward-compatible')
ck(A.is_team_chat("111") and A.is_team_chat("222")
   and not A.is_team_chat("999"),
   'team membership check')
ck("دستورات" in t("راهنما", "222"),
   'second team member gets full answers')
ck(t("راهنما", "999") == A.DENIED, 'outsider still denied')

# ================= 5. Claude lane in /کلید (+ bare aa-…)
r = t("/کلید")
ck("/کلید Muse" in r and "claude-sonnet-5" in r and "aa-…" in r,
   'usage teaches Claude as the default')
r = t("/کلید Muse " + AA)
ck("کلید تست شد" in r and "نصبش در صف" in r and AA not in r,
   '/کلید Muse: live-tested, queued, key never echoed')
r = t("/کلید " + AA)
ck("کلید تست شد" in r and AA not in r,
   'bare aa-… installs directly as Claude (v259 policy)')
dj = os.path.join(TMP, "code-jobs")
queued = [json.load(open(os.path.join(dj, x), encoding="utf-8"))
          for x in sorted(os.listdir(dj))]
ck(any(j.get("kind") == "ai_key" and j.get("provider") == "muse"
       for j in queued),
   'Claude install queued with provider=muse')
ck('muse' in AI.ADMIN_PROMPT and 'aa-' in AI.ADMIN_PROMPT,
   'copilot prompt documents the muse lane + aa- keys')

# ================= 6. ai_setup parse + reasons know muse
nm, ag = CODE.parse("ai_setup", {"provider": "muse", "key": AA})
ck(nm == "ai_setup" and ag["provider"] == "muse",
   'muse lane parses a well-shaped aa- key')
ck(CODE.parse("ai_setup", {"provider": "muse", "key": "aa-short"})[0] is None,
   'muse lane rejects a short key')
ck(CODE.parse("ai_setup", {"provider": "astra", "key": AA})[0] is None,
   'astra lane still rejects aa- shapes')
ck('Muse' in CT.reject_reason({"name": "ai_setup",
                               "args": {"provider": "astra", "key": AA}}),
   'aa- on astra: reason redirects to Muse')

# ================= 7. aa-… keys are redacted everywhere
ck("aa-fake" not in A._redact("کلید من " + AA + " است") and
   "مخفی شد" in A._redact(AA),
   'aa- keys redacted in bot replies')
ck(A._redact("متن عادی بدون کلید") == "متن عادی بدون کلید",
   'redaction leaves normal text untouched')

# ================= 8. codeguard installs a muse key into its brain slot (v263 policy)
# v263 (دستور مدیر: ۴ مغز): /کلید Muse دیگر مغز تازه نمی‌سازد — کلید در اسلات
# مغز فعال (opus/sonnet/haiku) می‌نشیند و بقیهٔ خط‌ها دست‌نخورده می‌مانند.
G = Path(tempfile.mkdtemp(prefix='cg259-'))
APP = G / 'app'
(APP / 'data' / 'code-jobs').mkdir(parents=True)
(APP / 'data' / 'code-backups').mkdir(parents=True)
(APP / 'server').mkdir(parents=True)
(APP / 'server' / 'x.py').write_text('X = 1\n', encoding='utf-8')
SEC = G / 'secrets.env'
SEC.write_text('AI_BASE_URL=https://old/v1\nAI_API_KEY=oldkey\nAI_MODEL=oldmodel\n'
               'AI_TIMEOUT=12\nAI_FALLBACK_API_KEY=oldfb\n', encoding='utf-8')
(APP / 'data' / 'code-jobs' / 'm.json').write_text(
    json.dumps({"kind": "ai_key", "provider": "muse", "key": AA, "slot": "opus"}),
    encoding='utf-8')
def stub(name, body):
    s = G / name; s.write_text('#!/usr/bin/env bash\n' + body, encoding='utf-8')
    s.chmod(0o755); return str(s)
SYSCTL = stub('systemctl', 'true')
NOTIFY = stub('notify', 'echo "$1" >> "$NLOG"')
CURL_OK = stub('curl-ok', 'exit 0')
subprocess.run(['bash', str(ROOT / 'deploy' / 'codeguard.sh')],
               env=dict(os.environ, DASTGIR_APP=str(APP), DASTGIR_SYSTEMCTL=SYSCTL,
                        DASTGIR_CURL=CURL_OK, DASTGIR_NOTIFY=NOTIFY,
                        DASTGIR_CODEGUARD_LOG=str(G / 'g.log'),
                        DASTGIR_HEALTHZ='http://x/h', SLOG=str(G / 's.log'),
                        NLOG=str(G / 'n.log'), DASTGIR_SECRETS=str(SEC)),
               capture_output=True, timeout=90)
env_txt = SEC.read_text(encoding='utf-8')
ck(('AI_BRAIN_OPUS_KEY=' + AA) in env_txt,
   'muse key lands in the opus slot')
ck('AI_API_KEY=oldkey' in env_txt and 'AI_MODEL=oldmodel' in env_txt and
   'AI_FALLBACK_API_KEY=oldfb' in env_txt,
   'slot install touches nothing else (legacy lines stay for custom mode)')
ck('مغز هوش مصنوعی جدید' in (G / 'n.log').read_text(encoding='utf-8'),
   'owner notified about the new brain')

# ================= 9. version pins (5-way)
# دستور مدیر: پین نسخه همیشه آخرین انتشار را دنبال می‌کند (v280).
ver = (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip()
# v289 (دستور مدیر، RULES §۲): پین نسخه از روی VERSION.txt خوانده می‌شود.
# پیش از این عدد ۲۸۱ سخت‌کد بود و از v282 به بعد همیشه قرمز می‌شد؛
# خودِ ناملموس (هماهنگی ۵ نقطه + کش‌شکن) همان‌طور تست می‌ماند.
ck(ver == A.DIAG_LATEST,
   'VERSION.txt == DIAG_LATEST == ' + ver)
ck(("bazarche-v" + ver) in (ROOT / 'site' / 'sw.js').read_text(encoding='utf-8'),
   'sw.js cache pinned to bazarche-v' + ver)
ck(any(('دست گیر — v' + ver) in ln for ln in
       (ROOT / 'README.md').read_text(encoding='utf-8').splitlines()),
   'README header bumped to v' + ver)
ck(('v' + ver) in (ROOT / 'docs' / 'collaboration' / 'CURRENT-STATE.md')
   .read_text(encoding='utf-8').splitlines()[0],
   'CURRENT-STATE header bumped to v' + ver)

# ================= 10. v260: model IDs are AvalAI-docs-verbatim, 404 named
# Root cause of «اصلاً وصل نیست»: v259 shipped claude-sonnet-4-6, but the
# documented AvalAI id is claude-sonnet-5 (the 4.6 page shows the Bedrock
# id anthropic.claude-sonnet-4-6) — every call died with HTTP 404, which
# تشخیص mislabeled as «کلید نامعتبر؟». Both fixed and pinned here.
import urllib.error as _urlerr
ck(CODE.AI_PROVIDERS["muse"] ==
   ("https://api.avalai.ir/v1", "claude-sonnet-5"),
   'muse provider default is the documented sonnet-5 id')
_be = (ROOT / 'deploy' / 'brain.env').read_text(encoding='utf-8')
# ممیزی v329 (v318/v321): انبار ۹خطی = OR + اسلات دستی (BASE/KEY/MODEL)
# + ۳خط سایت بای‌نارا + TIMEOUT + BYNARA. کلیدهای کلاد/GLM جداگانه inject.
_ai_lines = [ln for ln in _be.splitlines() if ln.startswith('AI_')]
ck(len(_ai_lines) == 9 and
   'AI_BRAIN_OR_KEY=sk-or-v1-' in _be and
   'AI_BRAIN_BYNARA_KEY=sk-nry-' in _be and
   'AI_TIMEOUT=40' in _be and
   'AI_SITE_BASE_URL=https://router.bynara.id/v1' in _be and
   'AI_SITE_MODEL=ling-3.0-flash-sante-free' in _be and
   any(ln.startswith('AI_SITE_API_KEY=sk-nry-') for ln in _ai_lines) and
   any(ln.startswith('AI_BASE_URL=') for ln in _ai_lines) and
   any(ln.startswith('AI_API_KEY=') for ln in _ai_lines) and
   any(ln.startswith('AI_MODEL=') for ln in _ai_lines) and
   'sonnet-4-6' not in _be and 'opus-4-8' not in _be and
   'AI_FALLBACK_' not in _be,
   'packaged brain = v321 9-line byNara store')
_old_chat = AI._chat
def _chat_404(*a, **k):
    raise _urlerr.HTTPError("u", 404, "not found", {}, None)
AI._chat = _chat_404
os.environ['AI_BASE_URL'] = 'https://api.avalai.ir/v1'
os.environ['AI_API_KEY'] = 'aa-fixture' + 'k' * 42
os.environ['AI_MODEL'] = 'claude-sonnet-5'
os.environ.pop('AI_MODEL_SMART', None)
r = t('تشخیص')
ck('HTTP 404' in r and 'مدل/آدرس نادرست' in r,
   'تشخیص names a 404 as model/address (never key)')
AI._chat = _old_chat

# ================= 11. v261: 403 body tells key-limit from geo-block
# Live v260 case: the owner's key returned 403 model_access_limited (valid
# key, but not allowed for sonnet-5) — the old label said «regional block»
# and sent the owner down the wrong road. The body is read (max 400 chars;
# a key never appears in an error body) and the label names the true cause.
import io as _io
def _chat_403limited(*a, **k):
    raise _urlerr.HTTPError("u", 403, "forbidden", {},
                            _io.BytesIO(b'{"error":{"code":"model_access_limited"}}'))
AI._chat = _chat_403limited
r = t('تشخیص')
ck('HTTP 403' in r and 'دسترسی ندارد' in r and 'منطقه‌ای' not in r,
   '403 + model_access_limited → key-limit label, not geo')
def _chat_403geo(*a, **k):
    raise _urlerr.HTTPError("u", 403, "forbidden", {}, _io.BytesIO(b'{}'))
AI._chat = _chat_403geo
r = t('تشخیص')
ck('HTTP 403' in r and 'منطقه‌ای' in r,
   'plain 403 keeps the geo-block label')
AI._chat = _old_chat

# ================= 12. v262: OpenRouter fallback (free backup, primary untouched)
# Owner order: the sk-or-v1-… key installs as AI_FALLBACK_* — Claude stays
# primary. Failover is automatic (assistant.generate tries primary, then
# fallback); the key was live-tested before packaging (auth/key + a real
# chat ping on the free model, 2026-09-10). Bare sk-or-v1- pastes must
# route to openrouter, never to astra (which would replace the brain!).
ck(CODE.AI_PROVIDERS["openrouter"] ==
   ("https://openrouter.ai/api/v1", "nvidia/nemotron-3-ultra-550b-a55b:free"),
   'openrouter preset: base + the live-tested free model')
_orfx = 'sk-or-v1-' + 'd' * 64
ck(CODE._KEY_RX["openrouter"].match(_orfx) and
   not CODE._KEY_RX["astra"].match(_orfx) and
   CODE._KEY_RX["astra"].match('sk-' + 'e' * 30),
   'sk-or-v1- keys are openrouter-only; plain sk- still astra')
ck(CODE._MODEL_RX.match('nvidia/nemotron-3-ultra-550b-a55b:free') and
   not CODE._MODEL_RX.match('has space') and
   not CODE._MODEL_RX.match('a;b') and
   not CODE._MODEL_RX.match('a"b'),
   'model ids allow a/b:free, still reject spaces/quotes/semicolons')
import re as _re12
ck('AI_BRAIN_OR_KEY=sk-or-v1-' in _be and
   any(_re12.match(r'^AI_BRAIN_OR_KEY=sk-or-v1-[A-Za-z0-9]{32,}$', ln)
       for ln in _be.splitlines()),
   'packaged brain carries the openrouter key in its slot')
nm, _aa = CT.parse_tool_call({"name": "ai_setup",
                              "args": {"provider": "openrouter", "key": _orfx}})
ck(nm == "ai_setup",
   'ai_setup accepts provider=openrouter')
ck('openrouter' in CT._ai_setup_reason({"provider": "astra", "key": _orfx}),
   'astra + sk-or key names openrouter as the fix')
os.environ['AI_BRAIN_SONNET_KEY'] = 'aa-fixture' + 'k' * 42
os.environ['AI_BRAIN_OR_KEY'] = 'sk-or-v1-' + 'f' * 40
db.set_settings({"ai_brain_active": "sonnet"})
_old_chat = AI._chat
def _chat_primary_dead(*a, **k):
    if a[2].startswith('nvidia/'):
        return ('{"answer":"test ok","links":[],"scope":true,"intent":"plans"}', 90)
    raise _urlerr.HTTPError("u", 500, "dead", {}, None)
AI._chat = _chat_primary_dead
_parsed, _tok, _calls, _smart = AI.generate("test", {}, None, ("unknown", ""))
ck(_parsed is None and _calls == 1,
   'v265: primary 500 → None after 1 call (no automatic switch, ever)')
AI._chat = lambda *a, **k: ('{}', 1)
r = t('تشخیص')
ck('سوئیچ خودکار' in r and 'خاموش' in r and 'یدک' not in r,
   'v265: تشخیص shows the no-auto-switch policy (no backup line)')
for _k in ('AI_BRAIN_SONNET_KEY', 'AI_BRAIN_OR_KEY'):
    os.environ.pop(_k, None)
AI._chat = _old_chat
_cg = (ROOT / 'deploy' / 'codeguard.sh').read_text(encoding='utf-8')
ck('ai_key:openrouter-key' in _cg and
   '"openrouter": ("https://openrouter.ai/api/v1"' in _cg and
   '"AI_FALLBACK_BASE_URL=", "AI_FALLBACK_API_KEY=", "AI_FALLBACK_MODEL="' in _cg and
   'ai_key:muse-" + slot' in _cg and 'AI_BRAIN_" + slot.upper()' in _cg,
   'codeguard installs keys into slots (v251 wipe kept for foreign installs)')

# ================= 13. v263→v266: /مغز switches between 5 brains, instantly
# Owner order: opus/sonnet/haiku each with its own aa- key + openrouter as
# the 4th brain + GLM (AvalAI gateway) as the 5th (v273: کیرا کلا حذف شد).
# a site setting (ai_brain_active);
# config() resolves (base, key, model) from the key slots at read time —
# no queue, no restart. Switching live-tests the target first; a dead
# target refuses and the old brain stays.
ck(AI.BRAINS["haiku"][2] == "claude-haiku-4-5" and
   AI.BRAINS["opus"][2] == "claude-opus-5" and
   AI.BRAINS["sonnet"][2] == "claude-sonnet-5" and
   AI.BRAINS["glm"][2] == "glm-5.3-flash" and
   AI.BRAINS["glm"][0] == "https://api.avalai.ir/v1" and
   len(AI.BRAINS) == 6,  # ممیزی v329: +bynara (v317)
   'v273 (دستور مدیر): مغز پنجم = GLM-5.3-Flash روی AvalAI، کیرا کلا حذف شد')
os.environ['AI_BRAIN_OPUS_KEY'] = 'aa-opus' + 'o' * 45
os.environ['AI_BRAIN_SONNET_KEY'] = 'aa-sonnet' + 's' * 43
os.environ['AI_BRAIN_HAIKU_KEY'] = 'aa-haiku' + 'h' * 44
os.environ['AI_BRAIN_OR_KEY'] = 'sk-or-v1-' + 'g' * 40
os.environ['AI_BRAIN_GLM_KEY'] = 'aa-glmk' + 'k' * 39
db.set_settings({"ai_brain_active": "opus"})
_c = AI.config()
ck(_c["model"] == "claude-opus-5" and _c["api_key"].startswith("aa-opus") and
   _c["model_smart"] == "claude-opus-5" and _c["brain"] == "opus" and
   _c["fb_model"] == "" and _c["fb_api_key"] == "",
   'active opus resolves (key+model+smart mirror, v265: NO backup)')
db.set_settings({"ai_brain_active": "haiku"})
_c = AI.config()
ck(_c["model"] == "claude-haiku-4-5" and _c["api_key"].startswith("aa-haiku"),
   'active haiku resolves to the docs-verbatim id')
db.set_settings({"ai_brain_active": "openrouter"})
_c = AI.config()
ck(_c["model"].startswith("nvidia/") and _c["api_key"].startswith("sk-or-v1-") and
   _c["fb_model"] == "",
   'active openrouter resolves; v265: nothing becomes a backup')
db.set_settings({"ai_brain_active": "glm"})
_c = AI.config()
ck(_c["model"] == "glm-5.3-flash" and _c["api_key"].startswith("aa-glmk") and
   _c["brain"] == "glm" and _c["fb_model"] == "" and
   _c["base_url"] == "https://api.avalai.ir/v1",
   'v273: مغز پنجم (GLM) روی AvalAI resolve می‌شود (بدون fallback)')
for _k in ('AI_BRAIN_OPUS_KEY', 'AI_BRAIN_SONNET_KEY', 'AI_BRAIN_HAIKU_KEY', 'AI_BRAIN_OR_KEY', 'AI_BRAIN_GLM_KEY'):
    os.environ.pop(_k, None)
os.environ['AI_MODEL'] = 'legacy-model'
_c = AI.config()
ck(_c["model"] == "legacy-model" and _c["brain"] == "custom",
   'no slot keys → legacy slots (custom brain, old behavior intact)')
os.environ.pop('AI_MODEL', None)
os.environ['AI_BRAIN_SONNET_KEY'] = 'aa-sonnet' + 's' * 43
os.environ['AI_BRAIN_OR_KEY'] = 'sk-or-v1-' + 'g' * 40
db.set_settings({"ai_brain_active": "sonnet"})
r = t('/مغز')
ck('اپوس ۵' in r and 'هایکو ۴.۵' in r and 'اوپن‌روتر' in r and 'سونت ۵' in r and
   'GLM' in r and 'فعال' in r and '/مغز اپوس' in r,
   'v272: /مغز lists all 5 brains (5th = GLM) with the active one marked')
os.environ['AI_BRAIN_OPUS_KEY'] = 'aa-opus' + 'o' * 45
os.environ['AI_BRAIN_HAIKU_KEY'] = 'aa-haiku' + 'h' * 44
_old_chat = AI._chat
AI._chat = lambda *a, **k: ('{}', 1)
r = t('/مغز اوپن')
ck('اوپن‌روتر' in r and db.get_settings().get("ai_brain_active") == "openrouter",
   '/مغز اوپن switches instantly (no queue)')
r = t('/مغز چیزخیالی')
ck('اپوس' in r and db.get_settings().get("ai_brain_active") == "openrouter",
   'unknown brain name → usage, switch refused')
def _chat_403x(*a, **k):
    raise _urlerr.HTTPError("u", 403, "denied", {}, None)
AI._chat = _chat_403x
r = t('/مغز هایکو')
ck('سوئیچ نشد' in r and db.get_settings().get("ai_brain_active") == "openrouter",
   'dead target (403) → honest refusal, old brain stays')
AI._chat = lambda *a, **k: ('{}', 1)
r = t('تشخیص')
ck('مغز فعال' in r and 'اوپن‌روتر' in r,
   'تشخیص names the active brain')
AI._chat = _old_chat
for _k in ('AI_BRAIN_OPUS_KEY', 'AI_BRAIN_SONNET_KEY', 'AI_BRAIN_HAIKU_KEY', 'AI_BRAIN_OR_KEY', 'AI_BRAIN_GLM_KEY'):
    os.environ.pop(_k, None)
db.set_settings({"ai_brain_active": "sonnet"})

# ================= 14. v264: business CREATE via bot + one-tap brain picker
# Owner order: adding a business must work (the model proposes id:0) and the
# answering brain must be picked BEFORE messaging (a button, not typed /مغز).
import time as _time
_CAT = (db._one("SELECT slug FROM categories LIMIT 1") or {}).get("slug") or "services"
assert _CAT, "seed has no category"
# -- business_save create mode (parse)
n2, a2 = CT.parse_tool_call({"name": "business_save",
                             "args": {"id": 0, "name": "چلوکبابی v264",
                                      "cat_slug": _CAT}})
ck(n2 == "business_save" and a2["id"] == 0 and
   a2["fields"]["name"] == "چلوکبابی v264",
   'business_save id=0 + name + cat parses as CREATE')
ck("cat_slug" in CT.reject_reason(
    {"name": "business_save", "args": {"id": 0, "name": "x"}}),
   'create without a category names cat_slug (NOT NULL at the DB)')
ck(CT.parse_tool_call({"name": "business_save",
                       "args": {"id": 0, "phone": "021"}})[0] is None and
   "نام (name)" in CT.reject_reason(
       {"name": "business_save",
        "args": {"id": 0, "phone": "021", "cat_slug": _CAT}}),
   'nameless create refused with a specific reason (not the generic one)')
ck("hours" in CT.reject_reason(
    {"name": "business_save",
     "args": {"id": 0, "name": "x", "cat_slug": _CAT,
              "hours": {"xyz": [["09:00", "22:00"]]}}}),
   'bad hours in a create names hours')
# -- precheck + execute: a real INSERT
ok, why = CT.tool_precheck("business_save",
                           {"id": 0, "fields": {"name": "چلوکبابی v264",
                                                "cat_slug": _CAT}})
ck(ok, 'create precheck passes with a real category')
ok, why = CT.tool_precheck("business_save",
                           {"id": 0, "fields": {"name": "x",
                                                "cat_slug": "no-such-cat"}})
ck(not ok and why == "cat" and "معتبر" in CT.fail_text("business_save", why),
   'invented cat_slug refused with the specific cat sentence')
A._pending_write(_time.time() + 300, "ai_tool",
                 json.dumps({"name": "business_save",
                             "args": {"id": 0,
                                      "fields": {"name": "چلوکبابی v264",
                                                 "cat_slug": _CAT}}}))
r = t("بله")
ck("ساخته شد" in r and (db._one("SELECT id FROM businesses WHERE name=?",
                                ("چلوکبابی v264",)) or {}).get("id", 0) > 0,
   '«بله» on a create proposal INSERTs the business')
_new_id = db._one("SELECT id FROM businesses WHERE name=?",
                  ("چلوکبابی v264",))["id"]
A._pending_write(_time.time() + 300, "ai_tool",
                 json.dumps({"name": "business_save",
                             "args": {"id": _new_id,
                                      "fields": {"phone": "021-99"}}}))
r = t("بله")
ck("به‌روز شد" in r and
   db._one("SELECT phone FROM businesses WHERE id=?", (_new_id,))["phone"] == "021-99",
   'edit still executes with the old wording')
ck("«ساخت تازه»" in AI.ADMIN_PROMPT and "id: 0" in AI.ADMIN_PROMPT,
   'prompt documents the business create shape')
# -- one-tap brain picker
r, kb = A.handle_text("u1", "111", "مغز")
ck(kb == A.BRAIN_KEYBOARD and len(kb["keyboard"]) == 3 and
   "اپوس ۵" in kb["keyboard"][0] and "هایکو ۴.۵" in kb["keyboard"][1] and
   "GLM ۵.۳" in kb["keyboard"][2],
   'v272: bare مغز swaps in the 3-row picker (5th button = GLM)')
ck("پرمصرف" in r and "ارزان" in r and "رایگان" in r and "مغز پنجم" in r,
   'v273: brain list carries honest cost hints (5th = GLM)')
os.environ["AI_BRAIN_OPUS_KEY"] = "aa-opus" + "o" * 45
os.environ["AI_BRAIN_SONNET_KEY"] = "aa-sonnet" + "s" * 43
_old_chat2 = AI._chat
AI._chat = lambda *a, **k: ("{}", 1)
db.set_settings({"ai_brain_active": "sonnet"})
for _row in A.BRAIN_KEYBOARD["keyboard"]:
    for _btn in _row:
        assert A._fa2en(_btn.strip()) in A._BRAIN_TAPS, _btn
r, kb = A.handle_text("u1", "111", "اپوس ۵")
ck(db.get_settings().get("ai_brain_active") == "opus" and kb == A.KEYBOARD,
   'tapping اپوس ۵ switches instantly and restores the main keyboard')
r, kb = A.handle_text("u1", "111", "اپوس ۵")
ck("همین الان فعال" in r and kb == A.KEYBOARD,
   'tapping the active brain restores the main keyboard too')
AI._chat = _old_chat2
for _k in ("AI_BRAIN_OPUS_KEY", "AI_BRAIN_SONNET_KEY"):
    os.environ.pop(_k, None)
db.set_settings({"ai_brain_active": "sonnet"})
# ممیزی v329: v316 — کیبورد ۷ ردیف؛ مقایسه با پیشوند ردیف (نه لیست exact).
_K = A.KEYBOARD["keyboard"]
ck(len(_K) == 7 and any(r[:2] == ["مغز", "تشخیص"] for r in _K)
   and any(r[:2] == ["هوش سایت", "کلیدها"] for r in _K)
   and any(r and r[0] == "اسپم" for r in _K),
   'main keyboard: v316 7 rows keep مغز/هوش سایت/اسپم')

# ================= 15. v265: never auto-switch + full panel access + look reset
# Owner order (3 parts): 1) the whole site look back to factory default;
# 2) the AIs get FULL access to the admin panel (even the 4 login/security
# keys); 3) NEVER switch brains automatically — not even when tokens run out.
import time as _time15
_old_chat15 = AI._chat
# -- no backup slots anywhere
os.environ["AI_BRAIN_SONNET_KEY"] = "aa-s15" + "k" * 44
os.environ["AI_BRAIN_OR_KEY"] = "sk-or-v1-" + "m" * 40
db.set_settings({"ai_brain_active": "sonnet"})
_c15 = AI.config()
ck(_c15["fb_base_url"] == "" and _c15["fb_api_key"] == "" and _c15["fb_model"] == "",
   '4-brain config carries NO backup slots')
os.environ.update(AI_FALLBACK_BASE_URL="https://fb.example.invalid/v1",
                  AI_FALLBACK_API_KEY="fb-key", AI_FALLBACK_MODEL="fb-model")
db.set_settings({"ai_brain_active": "custom"})
ck(AI.config()["fb_model"] == "", 'legacy AI_FALLBACK_* honored no more')
for _k in ("AI_FALLBACK_BASE_URL", "AI_FALLBACK_API_KEY", "AI_FALLBACK_MODEL"):
    os.environ.pop(_k, None)
db.set_settings({"ai_brain_active": "sonnet"})
# -- dead primary, token-out shape (402): honest error, single call
_calls15 = []
def _chat_402(*a, **k):
    _calls15.append(a[2])
    raise _urlerr.HTTPError("u", 402, "out of credit", {}, None)
AI._chat = _chat_402
_g, _t, _cc, _s = AI.generate("test", {}, None, ("unknown", ""))
# v269 (دستور مدیر: هوش سایت جدا): generate حالا اسلات سایت را صدا می‌زند
# (AI_SITE_MODEL همین هارنس) — قاعدهٔ «یک فراخوانی، بدون یدک» پابرجاست.
ck(_g is None and _cc == 1 and len(_calls15) == 1 and "site-model" in _calls15[0],
   'token-out site brain → None after exactly 1 call (backup never touched)')
r, src, _tl = AI.admin_answer("test", "snap")
ck(src == "error" and "سونت ۵" in r and "توکنش تمام شده" in r and
   "سوئیچ خودکار" in r,
   'admin path names the dead brain + the reason + the manual remedies')
ck("اعتبار/توکنش تمام شده" in AI._brain_fail_fa("http-402:x", "opus") and
   "سهمیه‌اش تمام شده" in AI._brain_fail_fa("http-429:x", "opus") and
   "کلیدش نامعتبر" in AI._brain_fail_fa("http-401:x", "haiku"),
   'token-out/rate/key failure each gets its own honest reason')
AI._chat = _old_chat15
for _k in ("AI_BRAIN_SONNET_KEY", "AI_BRAIN_OR_KEY"):
    os.environ.pop(_k, None)
# -- full access: the 4 auth keys
for _k15 in ("owner_token", "owner_pass_hash", "panel_allow_ips", "admin_bot"):
    _nm, _aa = CT.parse_tool_call({"name": "setting",
                                   "args": {"key": _k15, "value": "v265"}})
    _ok, _ = CT.tool_precheck(_nm, _aa)
    ck(_nm == "setting" and _ok, f'auth key writes with «بله»: {_k15}')
A._pending_write(_time15.time() + 300, "ai_tool",
                 json.dumps({"name": "setting",
                             "args": {"key": "owner_pass_hash",
                                      "value": "pw-v265"}}))
r = t("بله")
ck("هش" in r and db.check_owner_pass("pw-v265") and
   db.get_settings().get("owner_pass_hash", "").startswith("pbkdf2$"),
   'panel password from chat stored ONLY as a PBKDF2 hash')
db.set_owner_pass("")
A._pending_write(_time15.time() + 300, "ai_tool",
                 json.dumps({"name": "setting",
                             "args": {"key": "owner_token", "value": "TOK-V265"}}))
r = t("بله")
ck("TOK-V265" in r and "panel/settings?key=" in r and
   db.get_settings().get("owner_token") == "TOK-V265",
   'token change replies once with the new panel link')
ck('owner_token' in AI.ADMIN_PROMPT and 'owner_pass_hash' in AI.ADMIN_PROMPT,
   'prompt documents the full-access auth keys')
db.set_settings({"owner_token": "SUPERSECRET265"})
ck("SUPERSECRET265" not in json.dumps(A.admin_snapshot(), ensure_ascii=False,
                                      default=str),
   'snapshot still hides auth values from the model (read-never)')
A._pending_write(_time15.time() + 300, "ai_tool",
                 json.dumps({"name": "setting",
                             "args": {"key": "panel_allow_ips", "value": "9.9.9.9"}}))
t("بله")
_row15 = db.connect().execute(
    "SELECT detail FROM audit WHERE action='admin_ai_tool' "
    "ORDER BY rowid DESC LIMIT 1").fetchone()
ck(_row15 and "panel_allow_ips" in _row15[0] and "9.9.9.9" not in _row15[0],
   'audit log masks auth values (key name only)')
# -- the whole look back to factory default
db.set_settings({"color_primary": "#ff0000", "color_accent": "#00ff00",
                 "site_logo": "logo.png", "hero_title": "dirty"})
r = t("ظاهر پیش‌فرض")
ck("بله" in r and db.get_settings().get("color_primary") == "#ff0000",
   'appearance reset asks for «بله» first (writes nothing yet)')
r = t("بله")
_s15 = db.get_settings()
ck("پیش‌فرض" in r and _s15["color_primary"] == db.DEFAULT_SETTINGS["color_primary"] and
   _s15["site_logo"] == "" and _s15["hero_title"] == db.DEFAULT_SETTINGS["hero_title"],
   '«بله» restores all 9 factory appearance values')
_ap = (ROOT / "server" / "app.py").read_text(encoding="utf-8")
_reset15 = _ap.split('if form.get("reset"):')[1].split("return self.redirect")[0]
ck('"site_logo"' in _reset15 and "hero_title" in _reset15,
   'panel reset covers the logo too (same 9 keys)')
ck("ظاهر پیش‌فرض" in A.do_help()[0], 'help advertises ظاهر پیش‌فرض')

# ============ 16. v273: مغز پنجم — GLM (AvalAI gateway؛ کیرا کلا حذف شد)
# دستور مدیر v273: «تمام توکن‌ها از سایت اول (AvalAI) می‌گیرم؛ کیرا کلا
# حذف بشه؛ کلید GLM فقط برای پنل مدیریتی باشه و از بات تنظیم بشه».
# Provider glm (https://api.avalai.ir/v1, glm-5.3-flash). Fixtures only —
# the real key lives in deploy/brain.env and is NEVER printed here.
ck(CODE.AI_PROVIDERS["glm"] == ("https://api.avalai.ir/v1", "glm-5.3-flash"),
   'v273 (دستور مدیر): provider مغز پنجم = glm روی AvalAI/GLM-5.3-Flash')
ck(CODE._KEY_RX["glm"].match("aa-" + "a" * 40) and
   not CODE._KEY_RX["glm"].match("aa-short") and
   not CODE._KEY_RX["glm"].match("kira_" + "k" * 32) and
   not CODE._KEY_RX["glm"].match("sk-or-v1-" + "x" * 40),
   'v273: مغز پنجم فقط aa- می‌پذیرد (کیرا کلا حذف شد)')
n16, a16 = CT.parse_tool_call({"name": "ai_setup",
                               "args": {"provider": "glm", "key": "aa-" + "a" * 40}})
ck(n16 == "ai_setup" and a16["provider"] == "glm",
   'ai_setup parses the glm provider')
ck(CT.parse_tool_call({"name": "ai_setup",
                       "args": {"provider": "glm", "key": "nope"}})[0] is None,
   'ai_setup refuses a malformed glm key')
ck(CT.parse_tool_call({"name": "ai_setup",
                       "args": {"provider": "kiraai", "key": "aa-" + "a" * 40}})[0] is None,
   'v273: provider کیرا دیگر وجود ندارد')
_old_chat16 = AI._chat
AI._chat = lambda *a, **k: ("{}", 1)
r16, _ = A.do_ai_key("glm aa-" + "a" * 40)
ck("مغز پنجم" in r16, '/کلید glm installs the 5th brain (live-tested)')
r16, _ = A.do_ai_key("kira_" + "k" * 32)
ck("مغز پنجم" not in r16, 'v273: کلید لخت کیرا دیگر مغز پنجم نصب نمی‌شود')
_nb16, _ab16 = CT.parse_tool_call({"name": "brain_switch", "args": {"brain": "جی‌ال‌ام"}})
ck(_nb16 == "brain_switch" and _ab16["brain"] == "glm" and
   CT.parse_tool_call({"name": "brain_switch", "args": {"brain": "glm"}})[1]["brain"] == "glm" and
   CT.parse_tool_call({"name": "brain_switch", "args": {"brain": "کیرا"}})[0] is None,
   'v273: brain_switch parses جی‌ال‌ام/glm; کیرا رد می‌شود')
os.environ["AI_BRAIN_GLM_KEY"] = "aa-glm" + "g" * 40
db.set_settings({"ai_brain_active": "sonnet"})
r16 = t("/مغز glm")
ck("GLM" in r16 and db.get_settings().get("ai_brain_active") == "glm",
   'v273: /مغز glm switches instantly (live-tested first)')
db.set_settings({"ai_brain_active": "sonnet"})
r16, kb16 = A.handle_text("u1", "111", "جی‌ال‌ام")
ck(db.get_settings().get("ai_brain_active") == "glm" and kb16 == A.KEYBOARD,
   'tapping جی‌ال‌ام switches and restores the main keyboard')
os.environ.pop("AI_BRAIN_GLM_KEY", None)
db.set_settings({"ai_brain_active": "sonnet"})
r16 = t("/مغز glm")
ck(r16.startswith("⚠️") and db.get_settings().get("ai_brain_active") == "sonnet",
   'glm without a key → honest refusal, old brain stays')   # v273
ck("kira_" not in A._redact("k=kira_" + "k" * 32) and "مخفی" in A._redact("kira_" + "k" * 32),
   'kira_ keys redacted in chat/memory')
ck("ai_key:glm-key" in _cg and "AI_BRAIN_GLM_KEY=" in _cg,
   'v273: codeguard installs the glm slot (other lines untouched)')
import re as _re16
# ممیزی v329: GLM/OPUS از brain.env حذف شدند (v317 slot-merge)؛
# OR + BYNARA در انبار هستند.
_be16 = [ln for ln in (ROOT / "deploy" / "brain.env").read_text(encoding="utf-8").splitlines()
         if ln.startswith("AI_BRAIN_OR_KEY=") or ln.startswith("AI_BRAIN_BYNARA_KEY=")]
ck(len(_be16) == 2
   and _re16.match(r"^AI_BRAIN_OR_KEY=sk-or-v1-", _be16[0])
   and _re16.match(r"^AI_BRAIN_BYNARA_KEY=sk-nry-", _be16[1]),
   'v321: brain.env ships OR + bynara slots (shape-checked, never printed)')
ck("glm" in A.do_ai_key("")[0] and "مغز پنجم" in A.do_ai_key("")[0],
   'v273: help advertises the /کلید glm path')
AI._chat = _old_chat16
db.set_settings({"ai_brain_active": "sonnet"})

# ================= 17. v267: «کلید ورود» — the owner's own panel login, served directly
# Owner order (angry, with screenshot): «دسترسی تمام» — asking for your own
# login key got a security lecture from the model instead of the key.
# Reads are now served by a direct command (no model in the loop): the
# panel URL with the live token + a «بله»-gated password (re)creation that
# is hash-stored and shown once. Fixtures only; audit never holds values.
import re as _re17
_s17 = db.get_settings()
_ot17, _op17, _su17 = _s17.get("owner_token"), _s17.get("owner_pass_hash"), _s17.get("site_url")
db.set_settings({"owner_token": "tok17-fixture", "owner_pass_hash": "", "site_url": "https://site17.test"})
# ممیزی v329: تیم این تست = «111, 222»؛ غریبه باید «999» باشد.
r17_denied, _ = A.handle_text("u1", "999", "کلید ورود")
ck("/panel?key=" not in str(r17_denied) and "tok17-fixture" not in str(r17_denied)
   and r17_denied.startswith("⛔"),
   'outsider never receives the panel login URL/token')
r17, _ = A.handle_text("u1", "111", "کلید ورود")
ck("/panel?key=tok17-fixture" in r17 and "https://site17.test/panel?key=tok17-fixture" in r17 and "بله" in r17,
   '«کلید ورود» shows the live panel login URL (team chat only)')
r17 = t("کلید ورودم به سایت بده")
ck("/panel?key=tok17-fixture" in r17 and "متاسفانه" not in r17 and "امنیتی" not in r17,
   'screenshot phrasing 1 routed to the key (never a lecture)')
r17 = t("تو ترموس باید چه کدی بدم تا کلید ورود به پنلم دریافت کنم")
ck("/panel?key=tok17-fixture" in r17 and "متاسفانه" not in r17,
   'screenshot phrasing 2 routed to the key (never a lecture)')
r17 = t("رمز پنلم چیه؟")
ck("/panel?key=tok17-fixture" in r17, '«رمز پنلم چیه» reaches the login command too')
ck("همین نشانی برای ورود کافی است" in A.handle_text("u1", "111", "کلید ورود")[0],
   'no-password state says the URL alone logs in (team chat)')
db.set_owner_pass("old17")
r17 = t("کلید ورود")
ck("تعیین شده" in r17, 'password-set state says the password is also needed')
r17 = t("بله")
_pw17 = _re17.search(r"[A-Za-z0-9_\-]{16,}", r17).group(0)
ck(db.check_owner_pass(_pw17) and db.owner_pass_set() and _pw17 != "old17",
   '«بله» creates a fresh panel password, hash-stored, shown once')
_row17 = db.connect().execute("SELECT detail FROM audit ORDER BY rowid DESC LIMIT 3").fetchall()
ck(all(_pw17 not in (row[0] or "") for row in _row17),
   'audit log never holds the password value')
r17, _ = A.handle_text("u9", "222", "کلید ورودم به سایت بده")
ck("/panel?key=tok17-fixture" in r17, 'team chat gets the login key too (full access)')
ck("«کلید ورود» را بفرست" in AI.ADMIN_PROMPT, 'prompt redirects login-key asks to the direct command')
ck("کلید ورود" in A.do_help()[0], 'help advertises کلید ورود')
_old_chat17 = AI._chat
AI._chat = lambda *a, **k: ("{}", 1)
r17, _ = A.do_ai_key("glm aa-" + "a" * 40)
ck("مغز پنجم" in r17, '/کلید AI flow untouched by the login branch')
AI._chat = _old_chat17
db.set_settings({k: v for k, v in (("owner_token", _ot17), ("owner_pass_hash", _op17), ("site_url", _su17)) if v is not None})

# ============ 18. v268→v273: مغز پنجم GLM چندمدله + اجرای فوری بدون «بله»
# Owner orders with 2 screenshots: (1) tokens ran out — the paid VND lane
# is 402-dead on a 0 wallet while ~30M free-pool tokens sit unused →
# all 41 gateway models probed, 5 free-lane ids live-verified and
# switchable via /مدل; (2) a multi-color `setting` request failed args
# validation, then its «بله» expired → batch `items` + Persian key-name
# repair + NO confirm wall: valid AI proposals execute at once.
ck(AI.GLM_MODELS == ("glm-5.3-flash", "glm-5.3", "glm-5.2", "glm-5.1",
                     "glm-5-turbo"),
   'v273 (دستور مدیر): مغز پنجم = خانوادهٔ GLM روی AvalAI، پیش‌فرض اول')
ck(AI.BRAINS["glm"][2] == AI.GLM_MODELS[0] and
   CODE.AI_PROVIDERS["glm"][1] == AI.GLM_MODELS[0],
   'brain slot + install default both = the verified default')
# ممیزی v329 (v328): لخت /مدل حالا بای‌نارا است؛ فهرست GLM = «/مدل glm».
r18 = t('/مدل glm')
ck(all(m in r18 for m in AI.GLM_MODELS) and 'فعلی' in r18 and '/مدل 2' in r18,
   '/مدل glm lists all 5 with the active one marked')
_old_chat18 = AI._chat
AI._chat = lambda *a, **k: ('{}', 1)
os.environ['AI_BRAIN_GLM_KEY'] = 'aa-glm' + 'g' * 40
r18 = t('/مدل glm 2')
ck('glm-5.3' in r18 and
   db.get_settings().get('ai_brain_glm_model') == 'glm-5.3',
   'v273: /مدل 2 switches to glm-5.3 (live-tested first)')
db.set_settings({'ai_brain_active': 'glm'})
ck(AI.config()['model'] == 'glm-5.3',
   'config() serves the switched GLM model')
r18 = t('/مدل glm 99')
ck('درست نیست' in r18 and
   db.get_settings().get('ai_brain_glm_model') == 'glm-5.3',
   '/مدل 99 refused, old model stays')
def _chat_402_18(*a, **k):
    raise _urlerr.HTTPError('u', 402, 'insufficient', {}, None)
AI._chat = _chat_402_18
r18 = t('/مدل glm 3')
ck('عوض نشد' in r18 and
   db.get_settings().get('ai_brain_glm_model') == 'glm-5.3',
   'dead model (402) -> honest refusal, old model stays')
AI._chat = _old_chat18
os.environ.pop('AI_BRAIN_GLM_KEY', None)
db.set_settings({'ai_brain_active': 'sonnet', 'ai_brain_glm_model': ''})
# -- immediate execution (screenshot-1 failure is dead)
SCRIPT18 = []
def _chat18(base, key, model, messages, timeout, max_tokens=220):
    return (SCRIPT18.pop(0), 5) if SCRIPT18 else ('{"reply":"باشه","tool":null}', 5)
AI._chat = _chat18
P18 = lambda name, args: json.dumps(
    {"reply": "انجام می‌دهم.", "tool": {"name": name, "args": args}},
    ensure_ascii=False)
# ممیزی v329 (v320 دستور مدیر): هر نوشتن اول گزارش + دیوار تأیید؛ «بله» اجرا.
SCRIPT18.append(P18('setting', {"key": "site_name", "value": "مغازهٔ ۲۶۸"}))
r18 = t('اسم سایت را عوض کن')
ck('گزارش اقدام پیشنهادی' in r18 and 'site_name' in r18 and
   'برای اعمال' in r18,
   'v320: setting proposal shows the report + confirm wall')
ck(db.get_settings().get('site_name') != 'مغازهٔ ۲۶۸',
   'not executed before confirmation')
r18 = t('بله')
ck('✏️ «site_name» ذخیره شد' in r18,
   '«بله» executes the setting immediately (combined report+result)')
ck(db.get_settings().get('site_name') == 'مغازهٔ ۲۶۸' and
   not os.path.exists(os.path.join(TMP, 'pending.json')),
   'executed for real, nothing parked')
db.set_setting('site_name', 'دست گیر')
SCRIPT18.append(P18('setting', {"items": [
    {"key": "رنگ اصلی", "value": "#1d4ed8"},
    {"key": "color_accent", "value": "#b45309"}]}))
r18 = t('رنگ‌ها را عوض کن')
ck('گزارش اقدام پیشنهادی' in r18 or 'برای اعمال' in r18,
   'batch items also go through the confirm wall')
r18 = t('بله')
ck('2 تنظیم ذخیره شد' in r18 and 'color_primary' in r18,
   'batch items execute after «بله» (screenshot-1 shape)')
ck(db.get_settings().get('color_primary') == '#1d4ed8',
   'Persian «رنگ اصلی» repaired to color_primary')
A._pending_clear()
r18 = t('بله')
ck('چیزی در انتظار تأیید نیست' in r18,
   'empty «بله» gets the calm message (no restart lecture)')
ck('مدل' in A.do_help()[0], 'help advertises مدل')
AI._chat = _old_chat18

print(f'v259 Claude brain (user panel + team only): {n} checks green')
