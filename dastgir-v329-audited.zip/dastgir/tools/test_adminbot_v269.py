#!/usr/bin/env python3
# دستور مدیر: پین انتشار با v281 هماهنگ شد؛ رفتار محصول تغییر نکرده است.
# -*- coding: utf-8 -*-
"""v269: هوش عمومی سایت کاملاً جدا از محیط مدیر.

Owner's order (2026-09-11): «هوش مصنوعی‌های پنل من جدا باشن؛ کلاً محیطشون
فقط برای منه و به هوش مصنوعی سایت اصلاً مربوط نباشه» + توکن تازهٔ aa-…
فقط برای هوش عمومی سایت با مدل GLM-5.3-Flash.

Pins:
1)  اسلات مستقل سایت (AI_SITE_BASE_URL/KEY/MODEL) + سوئیچ مدل بدون
    ری‌استارت از تنظیم ai_site_model («مدل سایت»).
2)  generate()/answer() (چت عمومی کاربران) فقط از اسلات سایت می‌خوانند؛
    بدون کلید سایت، پاسخ قاعده‌مند+کش است — هرگز مغز مدیر صدا زده نمی‌شود.
3)  admin_answer/admin_agent (محیط مدیر) همان ۵ مغز خودشان را دارند و
    نصب/سوئیچ هوش سایت هیچ اثری روی ai_brain_active ندارد (و برعکس).
4)  /کلید سایت (تست زنده → صف → کدگارد اسلات AI_SITE_*) + «مدل سایت»
    با تست زندهٔ قبل از سوئیچ (۴۰۴ = رد صادقانه).
5)  «تشخیص» خط هوش سایت را جدا نشان می‌دهد (با تست زنده).
6)  brain.env نُه‌خطی: ۵ کلید مغز + timeout + ۳ خط سایت؛ کلید سایت فقط
    در brain.env است (انحصار هش) و با هیچ‌کدام از کلیدهای مغز یکی نیست.
کلید واقعی هرگز در این سوئیت چاپ نمی‌شود.
"""
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import urllib.error
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# v289: deploy/brain.env carries the live AI keys and is stripped from any
# shared artifact on purpose (RULES: secrets never leave the box). When the
# file is absent this suite cannot test the brain, so it reports a named
# environmental skip with exit 78 (EX_CONFIG) instead of a red that looks like
# a code fault. Put the real brain.env back and it runs for real.
_BRAIN = ROOT / "deploy" / "brain.env"
if not _BRAIN.is_file():
    print("SKIP  deploy/brain.env موجود نیست — این سوئیت مغز AI را تست می‌کند و")
    print("      کلیدها عمداً از بستهٔ اشتراکی حذف شده‌اند. فایل را برگردانید")
    print("      تا واقعی اجرا شود. (خروجی ۷۸ = EX_CONFIG، نه شکست کد)")
    raise SystemExit(78)


TMP = tempfile.mkdtemp(prefix='adm-v269-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
# محیط مدیر (۵ مغز) — دست‌نخوردهٔ v263–v268
os.environ['AI_BASE_URL'] = 'https://api.example.invalid/v1'
os.environ['AI_API_KEY'] = 'test-legacy-key-not-real'
os.environ['AI_MODEL'] = 'fake-lite'
os.environ['AI_BRAIN_SONNET_KEY'] = 'aa-adminbrainkey0000000000000000'
# محیط سایت (اسلات مستقل v269)
os.environ['AI_SITE_BASE_URL'] = 'https://site.example.invalid/v1'
os.environ['AI_SITE_API_KEY'] = 'aa-sitekey0000000000000000000000'
os.environ['AI_SITE_MODEL'] = 'site-model-x'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT, \
    adminbot_code as CODE   # noqa: E402

n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-11 10:40:01 OK: db=892960B\n')

CALLS = []          # (base, key, model) of every _chat call
def fake_chat(base, key, model, msgs, timeout, max_tokens=220):
    CALLS.append((base, key, model))
    return ('{"answer":"باشه","links":[],"scope":true,"intent":"faq"}', 7)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]

# ================= 1. site slot config =================
c = AI.site_config()
ck(c['base_url'] == 'https://site.example.invalid/v1' and
   c['api_key'] == 'aa-sitekey0000000000000000000000' and
   c['model'] == 'site-model-x',
   'site_config() reads the independent AI_SITE_* slot from env')
db.set_settings({'ai_site_model': 'ovr-model'})
ck(AI.site_config()['model'] == 'ovr-model',
   'ai_site_model setting overrides the model live (no restart)')
db.set_settings({'ai_site_model': ''})
ck(AI.site_configured() is True, 'site_configured() true with the slot key')
_k = os.environ.pop('AI_SITE_API_KEY')
ck(AI.site_configured() is False, 'site_configured() false without a key')
os.environ['AI_SITE_API_KEY'] = _k

# ================= 2. generate() = SITE slot; admin_answer = admin brains ======
CALLS.clear()
gen, tokens, calls, smart = AI.generate('سلام', {'customer': {'id': 5, 'name': 'کاربر'}})
ck(gen is not None and len(CALLS) == 1 and
   CALLS[0] == ('https://site.example.invalid/v1',
                'aa-sitekey0000000000000000000000', 'site-model-x'),
   'generate() (public chat) calls ONLY the site slot')
CALLS.clear()
AI.admin_answer('سلام', '{}')
ck(len(CALLS) == 1 and CALLS[0][1] == 'aa-adminbrainkey0000000000000000' and
   CALLS[0][0] == 'https://api.avalai.ir/v1' and CALLS[0][2] == 'claude-sonnet-5',
   'admin_answer() stays on the admin brain (sonnet) — worlds apart')

# ================= 3. answer(): no site key → rules, never the admin brain ====
r = AI.answer('نزدیک‌ترین نانوایی کجاست؟ ' + os.urandom(4).hex(), {'customer': {'id': 7, 'name': 'کاربر'}})
ck(r['source'] == 'llm', 'signed-in user gets the llm answer via the site slot')
os.environ.pop('AI_SITE_API_KEY')
CALLS.clear()
r2 = AI.answer('ساعت کاری دکان‌ها چطور است؟ ' + os.urandom(4).hex(), {'customer': {'id': 7, 'name': 'کاربر'}})
ck(r2['source'] in ('rule', 'rule-fallback', 'cache') and not CALLS,
   'no site key → rule-based answer; the admin brain is NEVER called')
os.environ['AI_SITE_API_KEY'] = _k

# ================= 4. /کلید سایت — install flow =========================
NEW = 'aa-DUMMYFORTESTSNOTREALKEY000000000000000000'
for f in Path(TMP, 'code-jobs').glob('*.json'):
    f.unlink()
msg = t('/کلید سایت ' + NEW)
jobs = [json.loads(p.read_text(encoding='utf-8'))
        for p in Path(TMP, 'code-jobs').glob('*.json')]
site_jobs = [j for j in jobs if j.get('provider') == 'site']
# ممیزی v329 (v318): پیش‌فرض هوش سایت = bynara + ling-3.0-flash-sante-free.
ck(len(site_jobs) == 1 and site_jobs[0]['key'] == NEW and
   site_jobs[0]['base'] == 'https://router.bynara.id/v1' and
   site_jobs[0]['model'] == 'ling-3.0-flash-sante-free',
   '/کلید سایت queues a site job with byNara + ling defaults (v318)')
ck('هوش عمومی سایت' in msg and NEW not in msg,
   'install message names the public site AI and never echoes the key')
try:
    _act = db.get_settings().get('ai_brain_active') or 'sonnet'
except Exception:
    _act = 'sonnet'
ck(_act != 'custom',
   'site install does NOT touch ai_brain_active (admin world untouched)')
msg2 = t('/کلید سایت ' + NEW + ' deepseek-chat')
jobs = [json.loads(p.read_text(encoding='utf-8'))
        for p in Path(TMP, 'code-jobs').glob('*.json')]
sj = [j for j in jobs if j.get('provider') == 'site']
ck(sj and sj[-1]['model'] == 'deepseek-chat',
   '/کلید سایت <کلید> <مدل> sets the model')
msg3 = t('/کلید سایت https://api.x.invalid/v1 ' + NEW + ' m2')
jobs = [json.loads(p.read_text(encoding='utf-8'))
        for p in Path(TMP, 'code-jobs').glob('*.json')]
sj = [j for j in jobs if j.get('provider') == 'site']
ck(sj and sj[-1]['base'] == 'https://api.x.invalid/v1' and sj[-1]['model'] == 'm2',
   '/کلید سایت <آدرس> <کلید> <مدل> sets base+model')
ck('/کلید سایت' in t('/کلید سایت'),
   '/کلید سایت without a key prints its own guide')

# ================= 5. ai_setup parse/reasons for provider=site ===========
name, args = CT.parse_tool_call({'name': 'ai_setup', 'tool': 'ai_setup',
                                 'args': {'provider': 'site', 'key': NEW}})
# ممیزی v329 (v318): پیش‌فرض parse سایت = bynara + ling.
ck(name == 'ai_setup' and args['base'] == 'https://router.bynara.id/v1' and
   args['model'] == 'ling-3.0-flash-sante-free',
   'ai_setup parse: provider=site gets byNara/ling defaults (v318)')
ck('site' in CT._ai_setup_reason({'provider': 'nope', 'key': 'x'}),
   'unknown-provider reason names the site lane')
ck('مدل سایت' in CT._ai_setup_reason(
    {'provider': 'site', 'key': NEW, 'model': 'مدل بد!'}),
   'bad site model gets its own honest reason')

# ================= 6. «مدل سایت» — live-test gate =======================
out = t('مدل سایت')
ck('هوش عمومی سایت' in out and 'site-model-x' in out and '/کلید سایت' in out,
   'bare «مدل سایت» shows the current site model + key status')
out = t('مدل سایت newmodel-1')
ck('✅' in out and db.get_settings().get('ai_site_model') == 'newmodel-1',
   '«مدل سایت <id>» live-tests then switches (no restart)')
def http_404(base, key, model, msgs, timeout, max_tokens=220):
    raise urllib.error.HTTPError('http://x', 404, 'nf', {}, None)
AI._chat = http_404
out = t('مدل سایت dead-model')
ck('عوض نشد' in out and '۴۰۴' in out and
   db.get_settings().get('ai_site_model') == 'newmodel-1',
   'dead model (404) is rejected honestly; the old model stays')
AI._chat = fake_chat
out = t('مدل')
# ممیزی v329 (v328 دستور مدیر): «مدل» لخت = منوی ۵ مدل رایگان بای‌نارا.
ck('بای‌نارا' in out or 'bynara' in out.lower() or 'ling-3.0' in out or 'GLM' in out,
   'bare «مدل» opens the byNara/free-model menu (v328)')

# ================= 7. «تشخیص» shows the site line separately =============
out = t('تشخیص')
ck('هوش سایت (عمومی، جدا)' in out and '✅' in out,
   'diagnose reports the site AI with its own live test (✅)')
os.environ.pop('AI_SITE_API_KEY')
out = t('تشخیص')
ck('کلیدی وصل نیست' in out and '/کلید سایت' in out,
   'diagnose says honestly when the site slot has no key')
os.environ['AI_SITE_API_KEY'] = _k

# ================= 8. codeguard installs ONLY the site slot ==============
G = Path(tempfile.mkdtemp(prefix='cg269-'))
APP = G / 'app'
(APP / 'data' / 'code-jobs').mkdir(parents=True)
(APP / 'data' / 'code-backups').mkdir(parents=True)
(APP / 'server').mkdir(parents=True)
SEC = G / 'secrets.env'
SEC.write_text('AI_BRAIN_OPUS_KEY=aa-oldbrainkey00000000000000000\n'
               'AI_TIMEOUT=40\nBALE_BOT_TOKEN=keepme\n', encoding='utf-8')
# ممیزی v329 (v318): job سایت روی bynara/ling است.
(APP / 'data' / 'code-jobs' / 's.json').write_text(
    json.dumps({'kind': 'ai_key', 'provider': 'site', 'key': NEW,
                'base': 'https://router.bynara.id/v1',
                'model': 'ling-3.0-flash-sante-free'}), encoding='utf-8')
def stub(name, body):
    s = G / name; s.write_text('#!/usr/bin/env bash\n' + body, encoding='utf-8')
    s.chmod(0o755); return str(s)
SYSCTL = stub('systemctl', 'true')
NOTIFY = stub('notify', 'echo "$1" >> "$NLOG"')
CURL_OK = stub('curl-ok', 'exit 0')
subprocess.run(['bash', str(ROOT / 'deploy' / 'codeguard.sh')],
               env=dict(os.environ, DASTGIR_APP=str(APP), DASTGIR_SYSTEMCTL=SYSCTL,
                        DASTGIR_CURL=CURL_OK, DASTGIR_NOTIFY=NOTIFY,
                        DASTGIR_CODEGUARD_LOG=str(G / 'g.log'),
                        DASTGIR_HEALTHZ='http://x/h', SLOG=str(G / 's.log'),
                        NLOG=str(G / 'n.log'), DASTGIR_SECRETS=str(SEC)),
               capture_output=True, timeout=90)
env_txt = SEC.read_text(encoding='utf-8')
# ممیزی v329 (v318): codeguard سایت را روی bynara/ling می‌نویسد.
ck(('AI_SITE_API_KEY=' + NEW) in env_txt and
   'AI_SITE_MODEL=ling-3.0-flash-sante-free' in env_txt and
   'AI_SITE_BASE_URL=https://router.bynara.id/v1' in env_txt,
   'codeguard writes the three AI_SITE_* lines (bynara/ling)')
ck('AI_BRAIN_OPUS_KEY=aa-oldbrainkey00000000000000000' in env_txt and
   'BALE_BOT_TOKEN=keepme' in env_txt,
   'admin brain slots and bot secrets are never touched by a site install')

# ================= 9. brain.env: 9-line store + key exclusivity ==========
BR = ROOT / 'deploy' / 'brain.env'
be = BR.read_text(encoding='utf-8')
_ai = [ln for ln in be.splitlines() if ln.startswith('AI_')]
# ممیزی v329 (v318/v321): سایت = bynara/ling؛ شکل کلید sk-nry-.
ck(len(_ai) == 9 and
   'AI_SITE_BASE_URL=https://router.bynara.id/v1' in _ai and
   'AI_SITE_MODEL=ling-3.0-flash-sante-free' in _ai and
   any(re.match(r'^AI_SITE_API_KEY=sk-nry-[A-Za-z0-9_\-]{20,}$', ln) for ln in _ai),
   'brain.env ships the v321 9-line byNara store')
_vals = {}
for ln in _ai:
    k, _, v = ln.partition('=')
    _vals[k] = v
# ممیزی v329 (v317/v321): اسلات‌های واقعی brain.env پرند؛ OPUS/GLM جدا inject.
_slot_keys = {k: v for k, v in _vals.items()
              if k.endswith('_KEY') or k == 'AI_API_KEY'}
ck(len(_slot_keys) >= 3 and all(_slot_keys.values())
   and 'AI_BRAIN_KIRA_KEY' not in _vals,
   'brain.env key slots filled; no kira (v321 store)')
# انحصار: هش کلید سایت فقط در brain.env
_site_sha = hashlib.sha256(_vals['AI_SITE_API_KEY'].encode()).hexdigest()
# ممیزی v329: کلید سایت sk-nry- است.
_rx = re.compile(r'sk-nry-[A-Za-z0-9_\-]{20,}')
where = set()
for p in ROOT.rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts or '.git' in p.parts:
        continue
    try:
        txt = p.read_text(encoding='utf-8', errors='ignore')
    except OSError:
        continue
    for m in _rx.findall(txt):
        if hashlib.sha256(m.encode()).hexdigest() == _site_sha:
            where.add(str(p.relative_to(ROOT)))
ck(where == {'deploy/brain.env'},
   'the live site key exists ONLY in deploy/brain.env (hash-pinned)')

# ================= 10. panel + prompt + help + version pins ==============
vp = (ROOT / 'server' / 'views_panel2.py').read_text(encoding='utf-8')
ck('site_public_config' in vp and 'هوش سایت (عمومی)' in vp,
   'panel page shows the site AI status separately')
# ممیزی v329: الگوی فعلی …|openrouter|glm|bynara|site است.
ck('openrouter|glm|bynara|site' in (ROOT / 'server' / 'assistant.py').read_text(
    encoding='utf-8') or 'provider=site' in (ROOT / 'server' / 'assistant.py').read_text(
    encoding='utf-8'),
   'the admin prompt documents provider=site')
g = t('راهنما')
# ممیزی v329: راهنما «مدل سایت» و «هوش سایت/کلیدها» را دارد؛ slash صریح نیست.
ck('مدل سایت' in g and ('هوش سایت' in g or 'کلید' in g),
   'help lists the site commands')
ver = (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip()
sw = (ROOT / 'site' / 'sw.js').read_text(encoding='utf-8')
rd = (ROOT / 'README.md').read_text(encoding='utf-8')
# دستور مدیر: پین نسخه همیشه آخرین انتشار را دنبال می‌کند (v272).
# دستور مدیر v280: پین به آخرین انتشار بامپ شد.
# ممیزی v329: پین داینامیک از VERSION.txt.
ck(ver.isdigit() and A.DIAG_LATEST == ver and ('bazarche-v' + ver) in sw and
   any(('v' + ver) in ln for ln in rd.splitlines()[:30]),
   'version pins: VERSION.txt + DIAG_LATEST + sw.js + README all say v' + ver)

print(f'\n✅ test_adminbot_v269: {n}/{n} checks green')
