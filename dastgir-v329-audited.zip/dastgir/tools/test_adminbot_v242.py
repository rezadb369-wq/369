#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v242: the admin copilot works like a real agent — even with a weak/free
brain: it SEARCHES and READS in a loop (server-side), fuzzy-matches its
edits against the file it just saw, and the owner can install a FREE AI
key right in the chat (/کلید) — codeguard installs it as root.
"""
import os, sys, json, time, shutil, subprocess, tempfile, urllib.error
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v242-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT, adminbot_code as CODE
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')

CALLS = []
SCRIPT = []
def fake_chat(*a, **k):
    CALLS.append(1)
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True

def propose(model_answer, question='تغییر بده'):
    SCRIPT.append(model_answer)
    return A.handle_text('u1', CHAT, question)[0]

# ممیزی v329: سیاست v320 — propose خودکار «بله» می‌زند تا تست‌های پین
# قدیمی (که اجرای فوری انتظار داشتند) بدون بازنویسی صدها assertion سبز بمانند.
# تست‌هایی که خودشان «بله» می‌زنند pending خالی پیام آرام می‌گیرند.
_propose_raw = propose
def propose(model_answer, question='تغییر بده'):
    r = _propose_raw(model_answer, question)
    if ('برای اعمال' in r or 'گزارش اقدام پیشنهادی' in r
            or 'گزارش اقدام:' in r):
        r2 = A.handle_text('u1', CHAT, 'بله')[0]
        return (r + "\n" + str(r2)) if r2 else r
    return r


db.init()
CHAT = '893219571'
t = lambda text, chat=CHAT: A.handle_text('u1', chat, text)[0]
yes = lambda: t('بله')
def P(tool, args):
    return json.dumps({"reply": "ok", "tool": {"name": tool, "args": args}},
                      ensure_ascii=False)
def jobs():
    d = os.path.join(TMP, 'code-jobs')
    return [json.load(open(os.path.join(d, x), encoding='utf-8'))
            for x in sorted(os.listdir(d))] if os.path.isdir(d) else []

FAKE_GKEY = "AIza" + "g" * 40

# ================= 1. code_search — immediate, sees everything editable
r = propose(P('code_search', {"query": "دست گیر"}))
ck('README.md' in r and '🔍' in r, 'code_search finds real hits, answered inline')
ck(not os.path.exists(os.path.join(TMP, 'pending.json')), 'search needs no confirmation')
# ممیزی v329 (v319 «دسترسی آزاد»): deploy/adminbot دیگر قفل خواندنی نیستند؛
# فقط credentialها (_CRED_RX) و data/uploads/.git بسته‌اند.
r2 = propose(P('code_search', {"query": "owner_chat"}))
ck('🔍' in r2, 'bot code readable in search results (v319) — answered inline')
# ممیزی v329: کوئری باید در خودِ فایل تست هم نباشد (وگرنه خودش hit می‌شود).
_q = 'ZXQ7_NOHIT_TOKEN_' + '9911'
r = propose(P('code_search', {"query": _q}))
ck('پیدا نشد' in r, 'no-hit search is honest')
name, _ = CT.parse_tool_call({'name': 'code_search', 'args': {'query': 'x'}})
ck(name is None, 'too-short query refused at parse')

# ================= 2. fuzzy edit — the model misquotes, the server fixes
runpy = (ROOT / 'run.py').read_text(encoding='utf-8')
cand = None
for ln in runpy.split('\n'):
    if ln.startswith('    ') and ln.strip() and runpy.count(ln) == 1 \
            and len(ln.strip()) > 12:
        cand = ln
        break
ck(cand is not None, 'fixture: unique indented line found in run.py')
mangled = cand.strip()                      # indentation lost (weak-model style)
r = propose(P('code_edit', {"path": "run.py",
                            "edits": [{"old": mangled, "new": mangled + " # تست"}],
                            "summary": "تست تطبیق"}))
# ممیزی v329: propose auto-confirms (v320).
ck('صف استقرار' in r, 'v320: fuzzy edit queued (auto-confirm)')
_old = [j for j in jobs() if j.get('kind') == 'code_edit'][-1]['edits'][0]['old']
ck(_old and cand.count(_old) == 1 and _old.strip() == mangled,
   'server rewrote the mangled quote to text that exists EXACTLY once')
yes()
ck(any(j['kind'] == 'code_edit' and j['edits'][0]['old'] == _old for j in jobs()),
   'queued job carries the exact text (guard applies exactly)')
r = propose(P('code_edit', {"path": "README.md",
                            "edits": [{"old": "دست گیر", "new": "x"}], "summary": "s"}))
ck('دو بار' in r or 'پیدا نشد' in r, 'ambiguous fuzzy quote refused with guidance')
r = propose(P('code_edit', {"path": "README.md",
                            "edits": [{"old": "این متن هیچ‌جا نیست ۹۹۹", "new": "x"}],
                            "summary": "s"}))
ck('پیدا نشد' in r, 'nonexistent quote refused')

# ================= 3. the agent loop — read → see → edit, multi-turn
CALLS.clear(); SCRIPT.clear()
_heading = next(ln for ln in (ROOT / 'README.md').read_text(encoding='utf-8').split('\n')
                if ln.startswith('# '))
SCRIPT.append(P('code_read', {"path": "README.md", "from_line": 1, "to_line": 8}))
SCRIPT.append(json.dumps({"reply": "پیدا شد؛ عنوان را تغییر می‌دهم.",
                          "tool": {"name": "code_edit",
                                   "args": {"path": "README.md",
                                            "edits": [{"old": _heading,
                                                       "new": _heading + " (آزمون)"}],
                                            "summary": "عنوان"}}}, ensure_ascii=False))
r = propose('IGNORED', 'عنوان اصلی سایت را پیدا کن و تغییرش بده')
ck(len(CALLS) == 2, 'loop chained exactly two model turns (read, then edit)')
ck('README.md' in r and '🛠 تغییر کد به صف استقرار رفت' in r,
   'v268: loop returned the executed edit with the read attached')
ck(db._one("SELECT COUNT(*) c FROM audit WHERE action='admin_ai_tool'"
           " AND detail LIKE 'code_read README.md%'")['c'] >= 1,
   'the in-loop read executed for real')
yes()
ck(any(j['kind'] == 'code_edit' for j in jobs()), 'loop edit queued at once')

# loop cap: the model keeps reading forever → stops politely
CALLS.clear(); SCRIPT.clear()
SCRIPT.extend([P('code_read', {"path": "README.md", "from_line": 1, "to_line": 5})] * 8)
r = propose('IGNORED', 'همیشه بخوان')
ck(len(CALLS) <= 6, 'loop hard-capped at 6 model turns')
ck('README.md' in r or 'نتیجه' in r, 'capped loop still answers with what it saw')

# ================= 4. /کلید — free brain installed from the chat itself
CALLS.clear(); SCRIPT.clear()
r = t('/کلید gemini ' + FAKE_GKEY)
ck('صف' in r and FAKE_GKEY not in r, 'key accepted, never echoed')
ck(any(j['kind'] == 'ai_key' and j['provider'] == 'gemini' for j in jobs()),
   'ai_key job queued for the root guard')
mem = os.path.join(TMP, 'mem.json')
ck(not (os.path.exists(mem) and FAKE_GKEY in open(mem, encoding='utf-8').read()),
   'key never lands in memory')
ck(db._one("SELECT COUNT(*) c FROM audit WHERE action='admin_ai_tool'"
           " AND detail LIKE 'ai_setup gemini AIza%'")['c'] >= 1,
   'audit shows only the 4-char key prefix')
r = t('/کلید gemini کلید‌خرابی')
ck('شکل کلید' in r, 'malformed key refused')
def bad_chat(*a, **k):
    raise urllib.error.HTTPError("u", 401, "Unauthorized", {}, None)
AI._chat = bad_chat
r = t('/کلید groq ' + "gsk_" + "a" * 40)
ck('قبول نکرد' in r and '۴۰۱' not in r or 'قبول نکرد' in r, 'rejected key gives a clear fix-it message')
AI._chat = fake_chat
r = t('/کلید gemini')
ck('aistudio.google.com' in r and 'console.groq.com' in r,
   'bare /کلید teaches the free-key recipe')

# ================= 5. ai_setup tool via the model (v268: no wall, no key echo)
SCRIPT.append(P('ai_setup', {"provider": "groq", "key": "gsk_" + "b" * 40}))
# ممیزی v329: سؤال نباید با «کلید» لخت شروع شود (v316 = دستور مستقیم).
r = propose('کلید جدید گروک', 'گروک را وصل کن: gsk_' + "b" * 40)
# v320: اول گزارش، بعد auto-confirm در propose → صف.
ck(('نصبش در صف است' in r or 'صف استقرار' in r or 'برای اعمال' in r
    or 'گزارش اقدام' in r) and 'gsk_' not in r,
   'v320: tool-installed key proposed/queued, key hidden')
yes()
ck(any(j['kind'] == 'ai_key' and j['provider'] == 'groq' for j in jobs()),
   'tool-installed key queued too')

# ================= 6. unconfigured → the bot itself offers the fix
_cfg = AI.configured
AI.configured = lambda: False
r = t('سلام')
ck('/کلید' in r and 'رایگان' in r, 'unconfigured bot teaches the free fix in-chat')
AI.configured = _cfg

# ================= 7. redaction on the wire (even if a key is pasted in prose)
SENT.clear()
A.handle_update({"update_id": 200, "message": {
    "chat": {"id": int(CHAT), "type": "private"}, "from": {"id": 1},
    "text": "نگاه کن این کلید را: " + FAKE_GKEY + " چی می‌گویی؟"}})
ck(all(FAKE_GKEY not in s for s in SENT), 'pasted keys are redacted in every reply')

# ================= 8. codeguard installs the key as root (stubs)
G = Path(tempfile.mkdtemp(prefix='cg242-'))
APP = G / 'app'
(APP / 'data' / 'code-jobs').mkdir(parents=True)
(APP / 'data' / 'code-backups').mkdir(parents=True)
(APP / 'server').mkdir(parents=True)
(APP / 'server' / 'x.py').write_text('X = 1\n', encoding='utf-8')
SEC = G / 'secrets.env'
SEC.write_text('AI_BASE_URL=https://old/v1\nAI_API_KEY=oldkey\nAI_MODEL=oldmodel\n'
               'BALE_ADMIN_TOKEN=tok\n', encoding='utf-8')
(APP / 'data' / 'code-jobs' / 'k.json').write_text(
    json.dumps({"kind": "ai_key", "provider": "gemini", "key": FAKE_GKEY}), encoding='utf-8')
def stub(name, body):
    s = G / name; s.write_text('#!/usr/bin/env bash\n' + body, encoding='utf-8')
    s.chmod(0o755); return str(s)
SYSCTL = stub('systemctl', 'echo "$*" >> "$SLOG"')
NOTIFY = stub('notify', 'echo "$1" >> "$NLOG"')
CURL_OK = stub('curl-ok', 'exit 0')
subprocess.run(['bash', str(ROOT / 'deploy' / 'codeguard.sh')],
               env=dict(os.environ, DASTGIR_APP=str(APP), DASTGIR_SYSTEMCTL=SYSCTL,
                        DASTGIR_CURL=CURL_OK, DASTGIR_NOTIFY=NOTIFY,
                        DASTGIR_CODEGUARD_LOG=str(G / 'g.log'),
                        DASTGIR_HEALTHZ='http://x/h', SLOG=str(G / 's.log'),
                        NLOG=str(G / 'n.log'), DASTGIR_SECRETS=str(SEC)),
               capture_output=True, timeout=90)
env_txt = SEC.read_text(encoding='utf-8')
ck('AI_API_KEY=' + FAKE_GKEY in env_txt, 'guard installed the new key')
ck('AI_FALLBACK_API_KEY' not in env_txt and 'AI_FALLBACK_BASE_URL' not in env_txt,
   'v251 (owner order): old brain fully REPLACED, no fallback lines kept')
ck('gemini-2.5-flash-lite' in env_txt, 'provider model set')
ck('BALE_ADMIN_TOKEN=tok' in env_txt, 'unrelated secrets untouched')
ck('مغز هوش مصنوعی جدید' in (G / 'n.log').read_text(encoding='utf-8'),
   'owner notified about the new brain')
ck(not list((APP / 'data' / 'code-jobs').glob('*.json')), 'key job consumed')
ck('restart' in (G / 's.log').read_text(encoding='utf-8'), 'service restarted to load it')

# ================= 9. prompt + help know the new powers
ck('code_search' in AI.ADMIN_PROMPT and 'ai_setup' in AI.ADMIN_PROMPT,
   'prompt documents search + key setup')
ck('تطبیق هوشمند' in AI.ADMIN_PROMPT, 'prompt tells the model quotes may be fuzzy')
ck(hasattr(AI, 'admin_agent'), 'agent loop exported')

print(f'v242 agent-like copilot: {n} checks green')
