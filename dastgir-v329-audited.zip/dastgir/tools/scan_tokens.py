#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v256: مدرکِ بی‌توکن‌بودن بسته — اسکن کل فایل‌ها برای رازهای واقعی.

روش: هر رشتهٔ «شبیه کلید» (aa-…/sk-…/AIza…/gsk_…/kira_…/Bearer …) در کل درخت
پیدا می‌شود؛ هش SHA-256 هر کدام با فهرست سیاهِ «هش کلیدهای واقعی که
روزی استفاده شدند» مقایسه می‌شود. خودِ کلید واقعی هرگز در بسته نیست —
فقط هش یک‌طرفه‌اش (که برگشت‌ناپذیر است).

خروجی: گزارش شمردنی + کد خروج ۱ اگر حتی یک راز واقعی پیدا شود.
اجرا: python3 tools/scan_tokens.py [مسیر]   (پیش‌فرض: ریشهٔ همین بسته)
"""
import hashlib
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# فهرست سیاه: هش SHA-256 کلیدهای واقعی که در طول پروژه استفاده شدند.
# (کلید به‌خودی‌خود هرگز داخل بسته نمی‌آید — فقط هش.)
REAL_TOKEN_SHA = {
    # AvalAI aa-… key pasted by the owner on 2026-09-10 (baked in v253/v255, removed in v256)
    "a415b87134b42ca583c621849da783e8ee6850681bbe2cc0f50147ff5a52ff60":
        "avalai aa- key (owner, 2026-09-10)",
    # Claude aa-… key baked in v259/v260, retired in v261 (restricted: 403
    # model_access_limited on sonnet-5) — must never reappear in the package
    "494ffd7d20f479a7800887dca8589b186ffd5f989632a6aea1425e76edd7e20b":
        "avalai aa- key, model-restricted (owner, v259-v260)",
    # v261 unlimited key, retired in v263 (replaced by 3 per-model keys)
    "f00a76da5c0e56fdbaea62f4497c9603a59959e24d46aada0398cf094f26e8f4":
        "avalai aa- key, unlimited (owner, v261-v262)",
}

# خانواده‌های شکل کلید — برای پیدا کردن «کاندیدها». کاندیدها اغلب
# کلیدهای فیکِ تست‌ها هستند؛ فقط تطبیق هش با فهرست سیاه یعنی راز واقعی.
FAMILIES = {
    "aa-gateway": re.compile(r"aa-[A-Za-z0-9]{30,}"),
    "openai-sk":  re.compile(r"sk-[A-Za-z0-9_\-]{30,}"),
    "gemini":     re.compile(r"AIza[A-Za-z0-9_\-]{30,}"),
    "groq":       re.compile(r"gsk_[A-Za-z0-9]{30,50}"),
    "kira":       re.compile(r"kira_[A-Za-z0-9]{16,}"),  # v266: مغز پنجم
    "bearer":     re.compile(r"Bearer\s+[A-Za-z0-9._\-]{30,}"),
}

# v297 (FINDINGS-v296 F1/F2): the six shapes above only catch vendor API keys,
# so a plain password shipped as BOT_GATE_PASS=… in deploy/gate.env sailed
# straight through and the scanner still printed "0 real secrets". Anything
# assigned to a secret-named variable in a shipped file is now a finding,
# whatever its shape. Placeholders and empty values are allowed.
SECRET_NAME_RX = re.compile(
    r"^[A-Z0-9_]*(?:PASS|PASSWORD|SECRET|TOKEN|APIKEY|API_KEY|PRIVATE_KEY"
    r"|PASSPHRASE|SALT|CREDENTIAL|PHONE)[A-Z0-9_]*$")

PLACEHOLDER_RX = re.compile(
    r"^(\s*|['\"]?\s*(?:\.\.\.|xxx+|<[^>]*>|\{\{[^}]*\}\}|\$\{[^}]*\}|\*+)"
    r"|['\"]?(?:changeme|change_me|your[_-]?\w*|example|placeholder|dummy|none|null|test|fake|sample)\w*"
    r"|['\"]?(?:aa-\.{3}|sk-\.{3})\s*)$", re.IGNORECASE)

# Only files that actually ship in the release zip are scanned for this: the
# whole tree is walked, but a secret is only a *leak* if the artifact carries
# it. Test fixtures with obvious dummy values are excluded by PLACEHOLDER_RX.
SHIPPED_SECRET_FILES = ("gate.env", "brain.env", "secrets.env", ".env")


def _is_real_secret(value: str) -> bool:
    """True when a secret-named variable holds something that looks like a
    real value rather than a placeholder, a path, or a template slot."""
    v = value.strip().strip("'\"")
    if not v:
        return False
    if PLACEHOLDER_RX.match(value.strip()):
        return False
    if len(v) < 6:
        return False
    # A path to a secrets file is not itself a secret (apply-brain.sh points
    # SECRETS= at /etc/dastgir-secrets.env).
    if v.startswith("/") or v.startswith("$") or v.startswith("~"):
        return False
    return True


# A one-way digest is safe to ship — that is precisely the point of hashing
# the gate credentials. Never flag *_HASH / *_SHA* as a leak.
SAFE_SUFFIX_RX = re.compile(r"(?:_HASH|_SHA256?|_DIGEST|_HEX)$")


def scan_secret_assignments(root: Path):
    """Walk every text file and report secret-named assignments that hold a
    real-looking value. Returns [(relpath, varname, line_no)].

    ممیزی v329: deploy/brain.env عمداً بستهٔ کلید استقرار است (دستور مدیر
    v317/v321 — apply-brain.sh)؛ از گزارش leak جدا مستثناست. کلیدهای
    بازنشسته همچنان با فهرست هش REAL_TOKEN_SHA در کل درخت گرفته می‌شوند."""
    out = []
    for p in sorted(root.rglob("*")):
        if not p.is_file() or "__pycache__" in p.parts:
            continue
        # intentional deploy key package — not a leak (see docstring)
        if p.name == "brain.env" and p.parent.name == "deploy":
            continue
        # .py sources legitimately contain variable names like PASSWORD_FIELD;
        # only treat KEY=value lines in env-shaped files as assignments.
        if p.suffix.lower() not in (".env", "") and p.suffix.lower() != ".sh":
            continue
        try:
            txt = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for i, ln in enumerate(txt.splitlines(), 1):
            s = ln.strip()
            if not s or s.startswith("#") or "=" not in s:
                continue
            k, _, v = s.partition("=")
            k = k.strip().lstrip("export ").strip()
            if not k or not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", k):
                continue
            if (SECRET_NAME_RX.match(k.upper()) and not SAFE_SUFFIX_RX.search(k.upper())
                    and _is_real_secret(v)):
                out.append((str(p.relative_to(root)), k, i))
    return out



def _sha(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8", "replace")).hexdigest()


def scan(root: Path):
    """Returns (files_scanned, candidates, real_hits, brain_ai_lines)."""
    files = [p for p in sorted(root.rglob("*"))
             if p.is_file() and "__pycache__" not in p.parts]
    candidates, hits = 0, []
    for p in files:
        try:
            txt = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for fam, rx in FAMILIES.items():
            for m in rx.findall(txt):
                candidates += 1
                if _sha(m) in REAL_TOKEN_SHA:
                    hits.append((str(p.relative_to(root)), fam))
    brain = root / "deploy" / "brain.env"
    brain_ai = 0
    if brain.is_file():
        brain_ai = sum(1 for ln in brain.read_text(encoding="utf-8")
                       .splitlines() if ln.startswith("AI_"))
    return files, candidates, hits, brain_ai


def main() -> int:
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT
    files, candidates, hits, brain_ai = scan(root)
    leaks = scan_secret_assignments(root)
    print("🧾 مدرک بی‌توکن‌بودن — اسکن", root)
    print("   فایل‌های اسکن‌شده:", len(files))
    print("   رشته‌های شبیه کلید (کلیدهای فیک تست/نمونه):", candidates)
    print("   خط‌های AI_ در deploy/brain.env:", brain_ai)
    if leaks:
        print("   ❌ راز/دادهٔ شخصی با مقدار واقعی در بسته:")
        for rel, var, ln in leaks:
            print("     - %s:%d  %s=<مقدار پنهان>" % (rel, ln, var))
    if hits or leaks:
        if hits:
            print("   ❌ کلید واقعی شناخته‌شده پیدا شد:")
            for p, fam in hits:
                print("     -", p, "(", fam, ")")
        return 1
    print("   ✅ راز واقعی: ۰ مورد در کل بسته")
    return 0


if __name__ == "__main__":
    sys.exit(main())
