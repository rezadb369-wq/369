#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v239 admin copilot content tools -- offline tests.

The admin AI now has FULL power over site CONTENT (complete replacement
values): settings text/toggles, pages, posts, categories, businesses,
items, reviews, moderation, broadcasts. It must never say "I can't" for a
content task (the prompt forbids it and the tool list covers the panel's
own content surfaces). Site CODE, files and secrets stay untouchable:
the allow-list refuses them at parse time, before any confirmation.

Flow under test (mirrors production): model proposes JSON {"reply","tool"}
→ adminbot validates + prechecks → immediate execution (v268: no «بله») →
re-parse + re-precheck + execute via the site's own savers + audit row.
No model, no network: _chat is scripted.
"""
import os, sys, json, time, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='adm-v239-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')

# scripted model: pop scripted JSON answers, else a neutral reply
SCRIPT = []
def fake_chat(*a, **k):
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat

def propose(model_answer, question='تغییر بده'):
    SCRIPT.append(model_answer)
    return A.handle_text('u1', CHAT, question)[0]

# ممیزی v329: سیاست v320 — propose خودکار «بله» می‌زند تا تست‌های پین
# قدیمی (که اجرای فوری انتظار داشتند) بدون بازنویسی صدها assertion سبز بمانند.
# تست‌هایی که خودشان «بله» می‌زنند pending خالی پیام آرام می‌گیرند.
_propose_raw = propose
def propose(model_answer, question='تغییر بده'):
    r = _propose_raw(model_answer, question)
    if ('برای اعمال' in r or 'گزارش اقدام پیشنهادی' in r
            or 'گزارش اقدام:' in r):
        r2 = A.handle_text('u1', CHAT, 'بله')[0]
        return (r + "\n" + str(r2)) if r2 else r
    return r


db.init()
CHAT = '893219571'
t = lambda text, chat=CHAT: A.handle_text('u1', chat, text)[0]

# ---- fixture: customer, business (pending + published + hidden), review, post
buyer = db.customer_by_phone('09120000051', create=True)
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,phone,city,published_once) "
            "VALUES('pub9','فروشگاه نه','services','published','0219','تهران',1)")
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,phone,city,published_once) "
            "VALUES('pend9','در انتظار نه','services','pending','0218','تبریز',0)")
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,phone,city,published_once) "
            "VALUES('hid9','پنهان نه','services','hidden','0217','شیراز',1)")
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,phone,city,published_once) "
            "VALUES('never9','هرگز منتشر نشده','services','hidden','0216','قم',0)")
con.commit(); con.close()
BID_PUB, BID_PEND, BID_HID, BID_NEVER = 1, 2, 3, 4
con = db.connect()
con.execute("INSERT INTO reviews(biz_id,author,rating,body,status,customer_id) "
            "VALUES(1,'کاربر',5,'عالی بود','pending',?)", (buyer['id'],))
con.execute("INSERT INTO reviews(biz_id,author,rating,body,status) "
            "VALUES(1,'کاربر۲',4,'خوب بود','approved')")
con.commit(); con.close()
RID_PEND, RID_APPROVED = 1, 2
db.set_setting('owner_token', 'SECRET-TOKEN-XYZ')

def audits():
    return len(db.audit_log(1000, action='admin_ai_tool'))

# ================= 1. end-to-end: propose → execute at once → audit (v268)
before = audits()
r = propose('{"reply":"می‌نویسم","tool":{"name":"setting","args":{"key":"tagline","value":"مارکت‌پلیس محلی"}}}')
# ممیزی v329: propose خودکار «بله» می‌زند (v320) — اجرای نهایی در همان پاسخ است.
ck('✏️ «tagline» ذخیره شد.' in r, 'setting executed (auto-confirm v320)')
ck(db.get_settings().get('tagline') == 'مارکت‌پلیس محلی', 'tagline really changed')
ck(audits() == before + 1, 'audit row written')
ck(db.get_settings().get('owner_token') == 'SECRET-TOKEN-XYZ', 'unrelated settings untouched')

# stray «بله» with nothing pending → calm note, no double write
r2 = t('بله')
ck(r2 == 'چیزی در انتظار تأیید نیست ✅', 'no double execution')
ck(db.get_settings().get('tagline') == 'مارکت‌پلیس محلی', 'value unchanged after stray «بله»')

# ================= 2. decline + expiry (v268: direct commands still confirm)
r = t('ریستارت')
ck('بفرست: بله' in r, 'direct restart still asks «بله»')
ck(t('نه') == 'لغو شد ✅', '«نه» cancels')
ck(t('بله') == 'چیزی در انتظار تأیید نیست ✅', 'cancelled restart left nothing pending')
A._pending_write(time.time() - 1, 'restart', '')
ck(t('بله').startswith('⌛'), 'expired direct confirm asks to re-request')

# ================= 3. strangers + commands stay intact
ck(t('درخواست محتوا', chat='111').startswith('⛔'), 'stranger tool request denied')
ck('وضعیت دستگیر' in t('وضعیت'), 'status not hijacked')
ck('در انتظار نه' in t('تأیید'), 'biz queue not hijacked')

# ================= 4. plain / broken model output (v238 contract)
ck(propose('سلام، این متن ساده است') == 'سلام، این متن ساده است', 'plain text passes through')
ck(propose('{broken json') == '{broken json', 'broken JSON passes through')
# v240: a rejected proposal is dropped AND visibly explained (never silent)
_r = propose('{"reply":"ok","tool":{"name":"rm -rf","args":{}}}')
ck('معتبر شناخته نشد' in _r and 'ok' in _r, 'unknown tool dropped with a visible notice')
ck(db.get_settings().get('tagline') == 'مارکت‌پلیس محلی', 'unknown tool wrote nothing')
# ================= 5. v265 full access: even auth keys write (v268: at once)
# (v251's lock is gone by owner order; describe/audit masking stays).
for k in ('owner_token', 'owner_pass_hash', 'panel_allow_ips', 'admin_bot'):
    name, args = CT.parse_tool_call({'name': 'setting', 'args': {'key': k, 'value': 'x'}})
    ck(name == 'setting', f'auth key accepted at parse: {k}')
ck('مقدار پنهان' in CT.tool_describe('setting', {'key': 'owner_token', 'value': 'SEKRET'}) and
   'SEKRET' not in CT.tool_describe('setting', {'key': 'owner_token', 'value': 'SEKRET'}),
   'auth values masked in describe (never shown by tools)')
name, args = CT.parse_tool_call({'name': 'setting', 'args': {'key': 'tagline', 'value': 'ok'}})
ck(name == 'setting' and args['value'] == 'ok', 'content key accepted')

# ================= 6. toggle normalisation
r = propose('{"reply":"ok","tool":{"name":"setting","args":{"key":"prices_enabled","value":"خاموش"}}}')
# ممیزی v329: propose auto-confirm (v320).
ck(db.get_settings().get('prices_enabled') == '0', 'v320: fa «خاموش» → 0')
ck('prices_enabled' in CT.tool_describe('setting', {'key': 'prices_enabled', 'value': '1'}), 'toggle describe names the key')
r = propose('{"reply":"ok","tool":{"name":"setting","args":{"key":"prices_enabled","value":"روشن"}}}')
# ممیزی v329: propose auto-confirm (v320).
ck(db.get_settings().get('prices_enabled') == '1', 'v320: fa «روشن» → 1')
name, _ = CT.parse_tool_call({'name': 'setting', 'args': {'key': 'prices_enabled', 'value': 'شاید'}})
ck(name is None, 'garbage toggle value refused')

# ================= 7. pages (full replacement, verbatim content)
body = 'دربارهٔ ما — کسب‌وکارهای محلی.\nخط دوم با نیم‌فاصله: دست‌گیر'
r = propose(json.dumps({"reply": "ok", "tool": {"name": "page", "args":
                       {"slug": "about", "title": "دربارهٔ دست گیر", "body": body}}},
                      ensure_ascii=False))
# ممیزی v329: propose auto-confirms (v320).
ck('صفحهٔ about' in r or 'برای اعمال' in r, 'page proposal described')
pg = db.get_page('about')
ck(pg['title'] == 'دربارهٔ دست گیر' and pg['body'] == body, 'page written verbatim (ZWNJ kept)')
# v240: any existing page slug is editable; unknown slugs pass parse but fail precheck
name, _ = CT.parse_tool_call({'name': 'page', 'args': {'slug': 'home', 'title': 'x', 'body': 'y'}})
ck(name == 'page', 'v240: unknown slug passes parse (dynamic pages)')
ok, why = CT.tool_precheck('page', {'slug': 'home', 'title': 'x', 'body': 'y'})
ck(not ok and why == 'missing', 'v240: unknown page slug refused at precheck')
name, _ = CT.parse_tool_call({'name': 'page', 'args': {'slug': 'rules', 'title': '', 'body': 'y'}})
ck(name is None, 'empty title refused')

# ================= 8. posts: create → update (cover kept) → delete
r = propose('{"reply":"ok","tool":{"name":"post_save","args":{"id":0,"title":"بازارچه تازه","excerpt":"خلاصه","body":"متن کامل"}}}')
# ممیزی v329: propose auto-confirms (v320).
ck(db._one("SELECT title FROM posts WHERE title='بازارچه تازه'") is not None, 'post created (auto-confirm)')
con = db.connect(); con.execute("UPDATE posts SET cover='img/x.webp' WHERE id=1"); con.commit(); con.close()
r = propose('{"reply":"ok","tool":{"name":"post_save","args":{"id":1,"title":"بازارچه تازه‌تر","excerpt":"خلاصه۲","body":"متن۲"}}}')
t('بله')
p = db._one("SELECT title,cover FROM posts WHERE id=1")
ck(p['title'] == 'بازارچه تازه‌تر' and p['cover'] == 'img/x.webp', 'post updated, cover preserved')
r = propose('{"reply":"ok","tool":{"name":"post_delete","args":{"id":1}}}')
t('بله')
ck(not db._one("SELECT id FROM posts WHERE id=1"), 'post deleted')
r = propose('{"reply":"ok","tool":{"name":"post_save","args":{"id":999,"title":"x","body":"y"}}}')
ck('پیدا نشد' in r, 'update of missing post fails precheck')

# ================= 9. categories: create → update (icon kept) → delete rules
r = propose('{"reply":"ok","tool":{"name":"category_save","args":{"id":0,"name":"کافه‌ها","blurb":"نوشیدنی"}}}')
# ممیزی v329: propose auto-confirms (v320).
ck('دستهٔ «کافه‌ها» ذخیره شد' in r, 'v320: category created (auto-confirm)')
ck('ذخیره شد' in r, 'category create confirmed in reply')
cat = db._one("SELECT * FROM categories WHERE name='کافه‌ها'")
ck(cat and cat['icon'] == 'store', 'default icon applied')
con = db.connect(); con.execute("UPDATE categories SET icon='coffee',image='img/c.webp' WHERE id=?", (cat['id'],)); con.commit(); con.close()
r = propose('{"reply":"ok","tool":{"name":"category_save","args":{"id":%d,"name":"کافه‌ها و رستوران‌ها","sort":"5"}}}' % cat['id'])
t('بله')
cat2 = db._one("SELECT * FROM categories WHERE id=?", (cat['id'],))
ck(cat2['name'] == 'کافه‌ها و رستوران‌ها' and cat2['icon'] == 'coffee'
   and cat2['image'] == 'img/c.webp' and cat2['sort'] == 5, 'category updated, icon/image kept')
r = propose('{"reply":"ok","tool":{"name":"category_save","args":{"id":0,"name":"بدون والد","parent":"nope"}}}')
ck('والد' in r, 'bad parent fails precheck')
# delete: category with businesses refuses (services has pub9 etc.)
svc = db._one("SELECT id FROM categories WHERE slug='services'")
r = propose('{"reply":"ok","tool":{"name":"category_delete","args":{"id":%d}}}' % svc['id'])
ck('کسب‌وکار' in r or 'زیردسته' in r, 'category with businesses not deleted')
ck(db._one("SELECT id FROM categories WHERE id=?", (svc['id'],)), 'services category still there')
r = propose('{"reply":"ok","tool":{"name":"category_delete","args":{"id":%d}}}' % cat['id'])
ck('حذف شد' in r, 'empty category deleted')

# ================= 10. business content: fields, hours validation
r = propose(json.dumps({"reply": "ok", "tool": {"name": "business_save", "args":
                       {"id": 1, "descr": "توضیح تازه", "tags": "سوپر،محلی",
                        "hours": {"sat": [["09:00", "22:00"]]}}}}, ensure_ascii=False))
ck('«فروشگاه نه» به‌روز شد' in r, 'v268: business updated at once')
t('بله')
b = db._one("SELECT descr,tags,hours FROM businesses WHERE id=1")
ck(b['descr'] == 'توضیح تازه' and b['tags'] == 'سوپر،محلی', 'business text updated')
ck(json.loads(b['hours'])['sat'] == [['09:00', '22:00']], 'hours stored as wizard JSON')
for bad in ('{"sat":[["25:00","22:00"]]}', '{"sat":[["22:00","09:00"]]}', '{"xyz":[["09:00","22:00"]]}'):
    name, _ = CT.parse_tool_call({'name': 'business_save',
                                  'args': {'id': 1, 'hours': json.loads(bad)}})
    ck(name is None, f'malformed hours refused: {bad[:24]}')
name, _ = CT.parse_tool_call({'name': 'business_save', 'args': {'id': 1, 'hours': 'sat'}})
ck(name is None, 'non-dict hours refused')
r = propose('{"reply":"ok","tool":{"name":"business_save","args":{"id":999,"descr":"x"}}}')
ck('پیدا نشد' in r, 'missing business fails precheck')

# ================= 11. biz moderation with predicates
r = propose('{"reply":"ok","tool":{"name":"biz_moderate","args":{"id":%d,"action":"approve"}}}' % BID_PEND)
ck('«در انتظار نه» → published' in r, 'v268: biz approved at once')
ck('published' in r, 'pending → published')
r = propose('{"reply":"ok","tool":{"name":"biz_moderate","args":{"id":%d,"action":"approve"}}}' % BID_PEND)
ck('قبلاً' in r, 'double approve refused (already)')
r = propose('{"reply":"ok","tool":{"name":"biz_moderate","args":{"id":1,"action":"hide"}}}')
t('بله')
ck(db._one("SELECT status FROM businesses WHERE id=1")['status'] == 'hidden', 'published → hidden')
r = propose('{"reply":"ok","tool":{"name":"biz_moderate","args":{"id":%d,"action":"show"}}}' % BID_HID)
t('بله')
ck(db._one("SELECT status FROM businesses WHERE id=%d" % BID_HID)['status'] == 'published',
   'hidden(published_once) → published')
r = propose('{"reply":"ok","tool":{"name":"biz_moderate","args":{"id":%d,"action":"show"}}}' % BID_NEVER)
ck('منتشر نشده' in r, 'show without published_once refused (v209 invariant)')

# ================= 12. items: full content create → update → delete(trash)
r = propose('{"reply":"ok","tool":{"name":"item_save","args":{"id":0,"biz_id":1,"title":"نان سنگک","descr":"تازه","price":"120000","kind":"product","stock":"10","available":"1"}}}')
ck('📦 محتوا ذخیره شد' in r, 'v268: item created at once')
ck('ذخیره شد' in r, 'item create confirmed in reply')
it = db._one("SELECT * FROM items WHERE title='نان سنگک'")
ck(it and it['price'] == 120000 and it['stock'] == 10 and it['kind'] == 'product', 'item fields stored')
r = propose('{"reply":"ok","tool":{"name":"item_save","args":{"id":%d,"biz_id":1,"price":"135000","old_price":"120000"}}}' % it['id'])
t('بله')
it2 = db._one("SELECT price,old_price,title FROM items WHERE id=?", (it['id'],))
ck(it2['price'] == 135000 and it2['old_price'] == 120000 and it2['title'] == 'نان سنگک', 'partial item update keeps title')
r = propose('{"reply":"ok","tool":{"name":"item_delete","args":{"id":%d}}}' % it['id'])
ck('سطل بازیافت' in r, 'item deleted to trash')
ck(db._one("SELECT id FROM trash WHERE entity='item' AND ref_id=?", (it['id'],)), 'trash row exists')
r = propose('{"reply":"ok","tool":{"name":"item_save","args":{"id":0,"biz_id":999,"title":"x"}}}')
ck('پیدا نشد' in r, 'item for missing biz fails precheck')
name, _ = CT.parse_tool_call({'name': 'item_save', 'args': {'id': 0, 'biz_id': 1, 'kind': 'weapon'}})
ck(name is None, 'bad item kind refused')

# ================= 13. review moderation + notifications
nt0 = db._one("SELECT COUNT(*) c FROM notifications")['c']
r = propose('{"reply":"ok","tool":{"name":"review_moderate","args":{"id":%d,"action":"approve"}}}' % RID_PEND)
ck('تأیید و منتشر شد' in r, 'v268: review approved at once')
t('بله')
ck(db._one("SELECT status FROM reviews WHERE id=%d" % RID_PEND)['status'] == 'approved', 'review approved')
r = propose('{"reply":"ok","tool":{"name":"review_moderate","args":{"id":%d,"action":"reject"}}}' % RID_PEND)
ck('قبلاً' in r, 'already-moderated review refused')
con = db.connect()
con.execute("INSERT INTO reviews(biz_id,author,rating,body,status,customer_id) "
            "VALUES(1,'کاربر۳',2,'بد بود','pending',?)", (buyer['id'],))
con.commit(); con.close()
RID2 = db._one("SELECT id FROM reviews WHERE author='کاربر۳'")['id']
nt0 = db._one("SELECT COUNT(*) c FROM notifications")['c']
r = propose('{"reply":"ok","tool":{"name":"review_moderate","args":{"id":%d,"action":"reject","reply":"متأسفیم"}}}' % RID2)
t('بله')
ck(db._one("SELECT status FROM reviews WHERE id=%d" % RID2)['status'] == 'rejected', 'review rejected')
ck(db._one("SELECT reply FROM reviews WHERE id=%d" % RID2)['reply'] == 'متأسفیم', 'reject reply stored')
ck(db._one("SELECT COUNT(*) c FROM notifications")['c'] == nt0 + 2,
   'reject notifies the author (reply + rejection, panel parity)')

# ================= 14. broadcast reaches every active customer
cust_n = db._one("SELECT COUNT(*) c FROM customers WHERE status='active'")['c']
nt0 = db._one("SELECT COUNT(*) c FROM notifications")['c']
r = propose('{"reply":"ok","tool":{"name":"broadcast","args":{"text":"فروش ویژهٔ امروز"}}}')
ck('پیام همگانی' in CT.tool_describe('broadcast', {'text': 'x'}), 'broadcast describe intact')
ck('ارسال شد' in r, 'broadcast executed at once')
ck(db._one("SELECT COUNT(*) c FROM notifications")['c'] == nt0 + cust_n,
   f'broadcast delivered to all {cust_n} active customers')
name, _ = CT.parse_tool_call({'name': 'broadcast', 'args': {'text': 'x' * 501}})
ck(name is None, 'oversize broadcast refused')

# ================= 15. snapshot: content inventory + secrets still hidden
snap = A.admin_snapshot()
ck('SECRET-TOKEN-XYZ' not in snap and 'owner_token' not in snap, 'secrets still redacted')
ck('دسته‌ها' in snap and 'کافه‌ها و رستوران‌ها' not in snap, 'content inventory present (deleted cat gone)')
ck('مقاله‌ها' in snap and 'کسب‌وکارها' in snap and 'صفحات: about' in snap, 'inventory sections present')
ck('pub9' not in snap and 'فروشگاه نه' in snap, 'businesses listed by name')

# ================= 16. no quota / no audit for reads; prompt contract
u0 = db._one("SELECT COUNT(*) c FROM ai_usage")['c']
a0 = audits()
propose('{"reply":"فقط جواب","tool":null}')
ck(db._one("SELECT COUNT(*) c FROM ai_usage")['c'] == u0, 'no quota rows for admin')
ck(audits() == a0, 'no audit rows for admin reads')
ck('هرگز نگو' in AI.ADMIN_PROMPT and 'نمی‌توانم' in AI.ADMIN_PROMPT, 'prompt forbids refusals')
for tool in CT.TOOLS:
    ck(tool in AI.ADMIN_PROMPT, f'prompt documents tool {tool}')
ck('SECRET-TOKEN-XYZ' not in AI.ADMIN_PROMPT and 'SECRET' not in AI.ADMIN_PROMPT, 'no secret VALUES in prompt (key names are documented, v265)')

# ================= 17. help advertises content powers
ck('تمام‌قد' in A.handle_text('u1', CHAT, 'راهنما')[0], 'help mentions full-power content editing')

# ================= 18. v268: every proposal executes at once; questions clear direct pending
propose('{"reply":"ok","tool":{"name":"setting","args":{"key":"footer_note","value":"اول"}}}')
ck(db.get_settings().get('footer_note') == 'اول', 'first proposal executed at once')
propose('{"reply":"ok","tool":{"name":"setting","args":{"key":"footer_note","value":"دوم"}}}')
ck(db.get_settings().get('footer_note') == 'دوم', 'second proposal executed at once (last wins)')
ck(t('بله') == 'چیزی در انتظار تأیید نیست ✅', 'nothing parked by proposals')
t('ریستارت')
t('راستی وضعیت چطوره؟')                       # any question clears pending
ck(t('بله') == 'چیزی در انتظار تأیید نیست ✅', 'question cleared the pending (v238 pin, v268 wording)')

# ================= 19. execute re-validates: tampered pending writes nothing
A._pending_write(time.time() + 300, 'ai_tool', 'not json at all')
ck('ناخوانا' in t('بله'), 'corrupt pending refused')
A._pending_write(time.time() + 300, 'ai_tool',
                 json.dumps({'name': 'setting', 'args': {'key': 'owner_token', 'value': 'HACKED'}}))
ck('🔑' in t('بله') and db.get_settings().get('owner_token') == 'HACKED',
   'v265: auth key in pending executes after «بله» (full access)')
A._pending_write(time.time() + 300, 'ai_tool',
                 json.dumps({'name': 'business_save', 'args': {'id': 999, 'fields': {'descr': 'x'}}}))
ck('پیدا نشد' in t('بله'), 'stale entity in pending refused at execute')

print(f'v239 content tools: {n} checks green')
