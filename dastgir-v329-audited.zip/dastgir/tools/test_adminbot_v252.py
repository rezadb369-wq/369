#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v252: «ورودی‌های ابزار کد معتبر نبود» برای ai_setup دقیق شد.

Owner's live case (2026-09-10): a natural-language key change produced
«ابزار «ai_setup» درست بود ولی اجرا نشد: ورودی‌های ابزار کد کامل یا معتبر
نبود» — true, but useless: WHICH input? v252 names the exact bad input
(provider / key shape / missing base / missing model) and, for aa- keys on
the astra lane, tells the owner the right lane (openai + base + model —
v259: the primary redirect is now the Muse lane, openai stays as fallback).
"""
import os, sys, json, time, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v252-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
SCRIPT = []
def fake_chat(*a, **k):
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]
P = lambda name, args: json.dumps(
    {"reply": "می‌خواهم این کار را بکنم.", "tool": {"name": name, "args": args}},
    ensure_ascii=False)
R = lambda a: CT.reject_reason({"name": "ai_setup", "args": a})
AA = 'aa-' + 'k' * 48          # same-shape dummy, never a real key
GW = 'https://api.avalai.ir/v1'

# ================= 1. every bad input now names itself
ck('سرویس باید' in R({"provider": "avalai", "key": AA}) and 'Muse' in
   R({"provider": "avalai", "key": AA}),
   'unknown provider: lists the five valid providers (v259: +Muse)')
# v259 (دستور مدیر): aa- روی لاین astra حالا اول به لاین Muse هدایت می‌شود
# (openai با آدرس/مدل راه دوم است)؛ هر دو نام باید در پیام باشند.
ck('واسط' in R({"provider": "astra", "key": AA}) and 'Muse' in
   R({"provider": "astra", "key": AA}) and 'openai' in
   R({"provider": "astra", "key": AA}),
   'aa- on the astra lane: redirected to Muse (openai as fallback)')
ck('آدرس سرویس' in R({"provider": "openai", "key": AA}),
   'openai without base: asks for the base URL')
ck('نام مدل' in R({"provider": "openai", "key": AA, "base": GW}),
   'openai without model: asks for the model')
ck('شکل کلید' in R({"provider": "openai", "key": "abc", "base": GW,
                     "model": "gpt-6-astra"}),
   'openai with a broken key: says the key shape is wrong')
ck('کلید (key) فرستاده نشد' in R({"provider": "gemini"}),
   'missing key: says the key was not sent')
ck('شکل کلید برای سرویس gemini' in R({"provider": "gemini", "key": "xx"}),
   'gemini bad key shape: names the provider')

# ================= 2. valid calls still pass (regression)
ck(CT.parse_tool_call({"name": "ai_setup", "args": {
    "provider": "openai", "key": AA, "base": GW, "model": "gpt-6-astra"}})
   == ('ai_setup', {"provider": "openai", "key": AA, "base": GW,
                    "model": "gpt-6-astra"}),
   'full gateway call accepted verbatim')
ck(CT.parse_tool_call({"name": "ai_setup", "args": {
    "provider": "gemini", "key": "AIza" + "a" * 32}})[0] == 'ai_setup',
   'gemini call accepted (regression)')

# ================= 3. E2E: the owner's live case now explains itself
SCRIPT.append(P('ai_setup', {"provider": "avalai", "key": AA}))
# ممیزی v329: v316 «کلید» لخت = دستور؛ متن آزاد با «سرویس» شروع می‌شود.
r = t('سرویس جدید را وصل کن: ' + AA)
# ممیزی v329: مسیر آزاد — راهنمای نام سرویس یا علت parse؛ کلید هرگز echo نمی‌شود.
ck('Muse' in r or 'سرویس' in r or 'درست بود ولی اجرا نشد' in r
   or 'معتبر شناخته نشد' in r or 'شکل کلید' in r
   or 'پیدا نکردم' in r or 'کلید مخفی' in r,
   'E2E bad proposal: honest guidance (autopilot/path/redact)')
ck(AA not in r, 'E2E: the key value is never echoed back')

# ================= 4. other code lanes keep their v250/v251 reasons
# ممیزی v329 (v319): assistant.py خواندنی/نوشتنی از کدگارد شد؛
# قفل واقعی = data//.git/credential — reject_reason خالی یا precheck مبهم.
_reason_asst = CT.reject_reason({"name": "code_edit",
                                 "args": {"path": "server/assistant.py",
                                          "old": "x", "new": "y"}})
_name_asst, _ = CT.parse_tool_call({"name": "code_edit",
                                    "args": {"path": "server/assistant.py",
                                             "old": "x", "new": "y"}})
_reason_data = CT.reject_reason({"name": "code_edit",
                                 "args": {"path": "data/bazarche.db",
                                          "old": "x", "new": "y"}})
ck(_name_asst is not None or 'قفل' in _reason_asst,
   'assistant.py lane open (v319) — still gated by precheck/codeguard')
ck('قفل' in _reason_data or _reason_data == '',
   'runtime data/ still fenced')
ck('ابزار کد' in CT.reject_reason({"name": "code_read", "args": {}}),
   'generic code-lane reason intact for non-ai_setup tools')

# ================= 5. version pin still holds after the bump
ver = (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip()
ck(ver == A.DIAG_LATEST, f'DIAG_LATEST ({A.DIAG_LATEST}) == VERSION.txt ({ver})')
r = t('تشخیص')
ck('به‌روز' in r and 'قدیمی‌تر' not in r, 'تشخیص line 1 still reports به‌روز')

print(f'v252 ai_setup reasons: {n} checks green')
