#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Focused security/contract tests for Bale login + notifications (v206)."""
import os
import shutil
import sqlite3
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="dastgir-bale-v206-")
os.environ["BZ_DATA_DIR"] = TMP
os.environ["BALE_BOT_TOKEN"] = "test-token-not-real"
os.environ["BALE_WEBHOOK_SECRET"] = "s" * 43
os.environ["BALE_BOT_USERNAME"] = "daastgirbot"
sys.path.insert(0, str(ROOT / "server"))

import db  # noqa
import bale  # noqa
import views_owner as O  # noqa
import views_customer as CU  # noqa

n = 0

def check(ok, label):
    global n
    if not ok:
        raise AssertionError(label)
    n += 1
    print("  ✓", label)

try:
    # Production is already on v206; emulate its pre-v206 challenge table and
    # prove boot migration adds the signup fields without data loss.
    con0 = sqlite3.connect(db.DB_PATH)
    con0.execute("CREATE TABLE messenger_challenges(id TEXT PRIMARY KEY,request_hash TEXT UNIQUE NOT NULL,"
                 "browser_hash TEXT NOT NULL,purpose TEXT NOT NULL,customer_id INTEGER,approved_id INTEGER,"
                 "expires REAL NOT NULL,approved_at REAL,used_at REAL,created TEXT)")
    con0.execute("INSERT INTO messenger_challenges VALUES('old','r','b','login',NULL,NULL,1,NULL,NULL,'x')")
    con0.commit(); con0.close()
    db.init()
    cols = {r["name"] for r in db.connect().execute("PRAGMA table_info(messenger_challenges)")}
    check({"platform", "platform_user_id", "chat_id", "approval_hash"} <= cols,
          "v206 database migrates in place for secure Bale signup")
    cust = db.customer_by_phone("09120000001", create=True)
    settings = dict(db.get_settings())
    check(db.messenger_update_claim("bale", 987654) and
          not db.messenger_update_claim("bale", 987654),
          "persistent update_id claim rejects webhook replay atomically")

    ch = db.messenger_challenge_new("link", cust["id"], ttl=120)
    check(ch["request_token"] not in Path(db.DB_PATH).read_bytes().decode("latin1", "ignore"),
          "raw request bearer is never stored in SQLite")
    check(db.messenger_challenge_status(ch["id"], "wrong") is None,
          "wrong browser secret cannot observe/consume a challenge")
    ok, msg = db.messenger_challenge_approve(ch["request_token"], 513379886, 513379886)
    check(ok, "authenticated linking challenge can be approved")
    acc = db.messenger_account_for_customer(cust["id"])
    check(acc and acc["platform_user_id"] == "513379886", "Bale identity is linked to customer")
    status = db.messenger_challenge_status(ch["id"], ch["browser_token"], consume=True)
    check(status and status["approved_id"] == cust["id"], "bound browser consumes approved link")
    check(db.messenger_challenge_status(ch["id"], ch["browser_token"]) is None,
          "challenge is strictly single-use")

    login = db.messenger_challenge_new("login")
    ok, _ = db.messenger_challenge_approve(login["request_token"], 513379886, 999)
    check(ok, "linked Bale identity approves passwordless login")
    st = db.messenger_challenge_status(login["id"], login["browser_token"])
    check(st and st["approved_id"] == cust["id"], "login resolves only to linked customer")

    stranger = db.messenger_challenge_new("login")
    ok, _ = db.messenger_challenge_approve(stranger["request_token"], 999999, 999999)
    check(not ok, "unlinked Bale identity cannot log in before verified signup")
    signup = db.messenger_challenge_new("login")
    check(db.messenger_signup_bind(signup["request_token"], 700001, 700001),
          "unknown Bale identity binds only its short-lived browser challenge")
    ok, _, approval = db.messenger_signup_prepare(700001, 700001, "+989131112233")
    check(ok and approval and approval not in Path(db.DB_PATH).read_bytes().decode("latin1", "ignore"),
          "verified own contact creates a separately hashed signup approval")
    ok, _ = db.messenger_signup_approve(approval, 700001, 700001)
    signed = db.messenger_challenge_status(signup["id"], signup["browser_token"])
    check(ok and signed and signed["approved_id"] and
          db.messenger_account_by_platform("bale", 700001),
          "separate bot confirmation registers, links and approves login")
    expired = db.messenger_challenge_new("login", ttl=30)
    con = db.connect(); con.execute("UPDATE messenger_challenges SET expires=? WHERE id=?",
                                    (time.time()-1, expired["id"])); con.commit(); con.close()
    check(db.messenger_challenge_by_request(expired["request_token"]) is None,
          "expired challenge is rejected")

    calls = []
    real_call = bale._call
    bale._call = lambda method, payload: (calls.append((method, payload)) or {"ok": True})
    try:
        check(bale.send_notification("999", "سفارش شما آماده است", "https://daastgir.ir/me/orders"),
              "Bale transport sends notification")
        check(calls and calls[0][1]["chat_id"] == "999" and
              calls[0][1]["reply_markup"]["inline_keyboard"][0][0]["url"].startswith("https://"),
              "notification contains safe site action button")
        calls.clear()
        check(db.notify_customer(cust["id"], "order", "سفارش تازه", "/me/orders") and
              any(method == "sendMessage" and data.get("chat_id") == "999"
                  for method, data in calls),
              "preference-filtered notification core also dispatches to Bale")
    finally:
        bale._call = real_call

    login_html = O.login_unified(settings)
    # ممیزی v329 (v298): ورود یکپارچه شد (ایمیل/پیام‌رسان/تلفن)؛ پین قدیمی
    # «فقط پیام‌رسان بدون هیچ فرمی» کهنه است. خواص امنیتی: پیام‌رسان + بدون OTP.
    check('/auth/bale' in login_html and '/auth/soroush' in login_html,
          "login UI offers Bale/Soroush messenger entry")
    wait_html = O.bale_wait_page(settings, db.messenger_challenge_new("login"), "login")
    check("https://ble.ir/daastgirbot?start=login_" in wait_html and
          "/api/bale/status?id=" in wait_html,
          "wait page opens official bot and polls browser-bound status")
    settings_html = CU.notif_settings_page(settings, cust)
    check("بله متصل است" in settings_html and "/me/bale/unlink" in settings_html,
          "customer can see and revoke linked Bale account")

    payload = db.export_all()
    check("messenger_accounts" in payload and "messenger_challenges" not in payload,
          "backup keeps linked accounts but excludes ephemeral login challenges")
    source = (ROOT / "server/app.py").read_text(encoding="utf-8")
    check("compare_digest(m.group(1), expected)" in source and "read_json()" in source,
          "webhook is guarded by constant-time secret and bounded JSON parser")
    check('if path in ("/login", "/login/verify", "/login/password"' in source,
          "legacy SMS and password POST endpoints are disabled server-side")
    service = (ROOT / "deploy/bazarche.service").read_text(encoding="utf-8")
    check("EnvironmentFile=-/etc/dastgir-secrets.env" in service,
          "systemd loads secrets outside project/ZIP")

    db.messenger_unlink(cust["id"])
    check(db.messenger_account_for_customer(cust["id"]) is None,
          "disconnect removes delivery and login mapping")
    print(f"\nAll {n} Bale v206 checks passed.")
finally:
    shutil.rmtree(TMP, ignore_errors=True)
