# -*- coding: utf-8 -*-
"""
v309 — بخش ایجنت بدون کلید بله (دستور مدیر).

دستور مدیر (۲۰۲۶-۰۹-۲۰): «بخش ایجنت سایت دیگه نیاز به کلید از بله نداشته باشه.»
تغییر: نشست مالک/ادمین (ورود ایمیلی مالک یا کلید پنل) = دسترسی کامل به
/agent و /panel/agent و /api/agent/* — بدون کلید بله. کلید بله به کانال
اختیاری تبدیل شد؛ مرز امنیتی مشتریِ فقط-ایمیلی سر جایش ماند (بدون کلید،
اجرای ابزار ندارد).

اجرا (سرور زنده):
  BZ_DATA_DIR=/tmp/bz309 PORT=8097 python3 run.py   (در یک ترمینال)
  BZ_DATA_DIR=/tmp/bz309 BZ=http://127.0.0.1:8097 python3 tools/test_agent_nokey_v309.py
"""
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8097").rstrip("/")
KEY = db.owner_token()

G, R, X = "\033[32m", "\033[31m", "\033[0m"
n = 0
fails = []


def ck(ok, label):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        print("  " + R + "✗ " + label + X)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def _cookie_hdr(cookies):
    if not cookies:
        return {}
    return {"Cookie": "; ".join("%s=%s" % (k, v) for k, v in cookies.items())}


def get(path, cookies=None):
    o = urllib.request.build_opener(NoRedirect)
    hdrs = {"User-Agent": "bz-test"}
    hdrs.update(_cookie_hdr(cookies))
    req = urllib.request.Request(BASE + path, headers=hdrs)
    try:
        r = o.open(req, timeout=30)
        return r.status, r.read().decode("utf-8", "replace"), r.headers
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), (e.headers or {})


def post_form(path, data, cookies=None):
    o = urllib.request.build_opener(NoRedirect)
    hdrs = {"User-Agent": "bz-test",
            "Content-Type": "application/x-www-form-urlencoded",
            "Sec-Fetch-Site": "same-origin", "Origin": BASE}
    hdrs.update(_cookie_hdr(cookies))
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(BASE + path, data=body, headers=hdrs, method="POST")
    try:
        r = o.open(req, timeout=30)
        return r.status, r.read().decode("utf-8", "replace"), r.headers
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), (e.headers or {})


def post_json(path, payload, cookies=None):
    o = urllib.request.build_opener(NoRedirect)
    hdrs = {"User-Agent": "bz-test", "Content-Type": "application/json",
            "Sec-Fetch-Site": "same-origin", "Origin": BASE}
    hdrs.update(_cookie_hdr(cookies))
    req = urllib.request.Request(BASE + path, data=json.dumps(payload).encode(),
                                 headers=hdrs, method="POST")
    try:
        r = o.open(req, timeout=60)
        return r.status, r.read().decode("utf-8", "replace"), r.headers
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), (e.headers or {})


print("v309 — ایجنت بدون کلید بله (سرور زنده: %s)" % BASE)

# ۰) پیش‌نیاز
st, body, hd = get("/healthz")
ck(st == 200, "سرور زنده است (/healthz)")
if st != 200:
    print(R + "سرور در دسترس نیست — اول سرور را بالا بیاورید." + X)
    sys.exit(2)

# ۱) غریبه → دروازهٔ ایمیل (بدون تغییر)
st, body, hd = get("/agent")
ck(st == 200 and "/login/email" in body, "غریبه /agent = دروازهٔ ورود ایمیلی")

# ۲) ادمین با کلید پنل → کنسول کامل، بدون دروازهٔ کلید بله
st, body, hd = get("/agent?key=" + urllib.parse.quote(KEY))
# v322+: میز کار تب‌دار جای کنسول قدیمی «صفحه همه‌کاره» را گرفت (آرشیو ممیزی v329)
CONSOLE = "میز کار ایجنت"
GATE = "ورود با ایمیل — پنل ایجنت"
ck(st == 200 and CONSOLE in body and GATE not in body, "ادمین /agent?key = کنسول کامل")
ck("کلید خصوصی ایجنت لازم است" not in body, "دروازهٔ «کلید از بله» برای ادمین حذف شد")

# ۳) status با ادمین — قبل از v309 این مسیر ۴۰۳ می‌داد
st, body, hd = get("/api/agent/status?key=" + urllib.parse.quote(KEY))
try:
    j = json.loads(body)
except Exception:
    j = {}
ck(st == 200 and j.get("ok") is True, "/api/agent/status با ادمین = ۲۰۰ ok (قبلاً ۴۰۳)")

# ۳ب) غریبه status = ۴۰۳ (نگهبان سر جایش)
st, body, hd = get("/api/agent/status")
ck(st == 403, "غریبه /api/agent/status = ۴۰۳ (مرز امنیتی intact)")

# ۴) نشست مالک (نتیجهٔ ورود ایمیلی مالک) → کنسول بدون کلید بله
ow = db.owner_by_phone("09120309309", create=True)
sess = db.session_new(ow["id"])
st, body, hd = get("/agent", cookies={"bzv2_sess": sess})
ck(st == 200 and CONSOLE in body and GATE not in body and "کلید خصوصی ایجنت لازم است" not in body,
   "نشست مالک = کنسول کامل بدون کلید بله")

# ۵) مشتریِ فقط-ایمیلی → هنوز دروازهٔ کلید (مرز حفظ شد)
cu = db.customer_by_email_create("only309@example.com")
cs = db.customer_session_new(cu["id"])
st, body, hd = get("/agent", cookies={"bzv2_cust": cs})
ck(st == 200 and "کلید خصوصی ایجنت لازم است" in body,
   "مشتری فقط-ایمیلی = دروازهٔ کلید (مرز امنیتی حفظ شد)")

# ۵ب) مشتریِ بدون کلید نمی‌تواند ابزار اجرا کند
st, body, hd = post_form("/agent/exec", {"tool": "health_check", "args": "{}"},
                         cookies={"bzv2_cust": cs})
loc = hd.get("Location") or ""
ck(st in (302, 303, 403) and "ok=" not in loc, "اجرای ابزار توسط مشتری بدون کلید = مسدود")

# ۶) اجرای ابزار با نشست مالک (بدون هیچ کلید بله)
st, body, hd = post_form("/agent/exec", {"tool": "health_check", "args": "{}"},
                         cookies={"bzv2_sess": sess})
loc = hd.get("Location") or ""
ck(st in (302, 303) and "/agent?ok=" in loc, "اجرای ابزار با نشست مالک (/agent/exec) = ok")

# ۷) چت JSON با نشست مالک، حالت offline (هرگز مدل صدا زده نمی‌شود)
st, body, hd = post_json("/api/agent/chat", {"text": "سلام", "model": "offline"},
                         cookies={"bzv2_sess": sess})
try:
    j = json.loads(body)
except Exception:
    j = {}
ck(st == 200 and j.get("ok") is True, "چت ایجنت (offline) با نشست مالک = ۲۰۰ ok")

# ۸) رگرسیون: کانال اختیاری بله هنوز کار می‌کند.
# جریان واقعی (مثل v308): اول ورود ایمیلی (نشست مشتری)، بعد لینک یک‌بارمصرف
# ak کوکی را ست می‌کند و کنسول با «کوکی + نشست» باز می‌شود.
tok309, _exp = db.agent_key_new(ip="203.0.113.9", ttl=3600)
st, body, hd = get("/agent?ak=" + urllib.parse.quote(tok309))
setc = hd.get("Set-Cookie") or ""
ck(st in (302, 303) and "bzv2_agent=" in setc, "لینک بله /agent?ak = کوکی ست می‌شود (کانال اختیاری)")
st, body, hd = get("/agent", cookies={"bzv2_agent": tok309, "bzv2_cust": cs})
ck(st == 200 and CONSOLE in body and GATE not in body and "کلید خصوصی ایجنت لازم است" not in body,
   "کوکی ایجنت + نشست مشتری = کنسول (کانال بله حفظ شد)")

# ۹) نسخهٔ پنلی با ادمین — بدون کلید بله
st, body, hd = get("/panel/agent?key=" + urllib.parse.quote(KEY))
# v322+: صفحهٔ پنلی هم میز کار ایجنت است (نه کنسول قدیمی) — ممیزی v329
ck(st == 200 and "میز کار ایجنت" in body and "نیاز به کلید بله" not in body,
   "/panel/agent با ادمین = فعال بدون کلید بله")

# ۱۰) POST پنلی ایجنت با ادمین تنها (بدون کوکی ایجنت) — قبل از v309 این ۴۰۳ بود
st, body, hd = post_form("/panel/agent/exec",
                         {"tool": "health_check", "args": "{}", "key": KEY})
loc = hd.get("Location") or ""
ck(st in (302, 303) and "ok=" in loc, "POST /panel/agent/exec با ادمین تنها = ok (قبلاً ۴۰۳)")

print()
if fails:
    print(R + "FAIL" + X + " %d/%d: " % (len(fails), n + len(fails)) + " · ".join(fails))
    sys.exit(1)
print(G + "PASS" + X + " %d بررسی — v309 ایجنت بدون کلید بله سبز است." % n)
