#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v284 — «روش دوم» ورود با پیام‌رسان: کلید یک‌بارمصرف + لینک ربات.

قرارداد امنیتی که قفل می‌شود:
  · کلید ۹۶ بیتی تصادفی، فقط یک‌بار در همان مرورگر نمایش داده می‌شود
    (صدور بدون کوکی مرورگرِ همان چالش ممکن نیست) و در دیتابیس فقط
    هَش آن ذخیره می‌شود.
  · یک‌بارمصرف، TTL حداکثر ۵ دقیقه، حداکثر ۵ تلاش، وابسته به یک چالش؛
    صدور کلید جدید، کلید قبلیِ همان چالش را می‌سوزاند.
  · تأیید نهایی فقط با «ارسال شمارهٔ خودم» (contact.user_id == فرستنده،
    در هر دو وبهوک بله و سروش چک می‌شود) — شمارهٔ تایپ‌شده قبول نیست.
  · تضاد هویت در هر دو جهت رد می‌شود: حساب پیام‌رسانِ وصل به مشتری دیگر،
    یا شمارهٔ وصل به حساب پیام‌رسان دیگر. مشتری مسدود هم رد می‌شود.
  · هیچ‌وقت کلید خام یا شمارهٔ کامل در لاگ ثبت نمی‌شود.
  · اندپوینت /api/login-key: ریت‌لیمیت ۳ در ۱۰ دقیقه، فقط چالش loginِ
    تأییدنشده، پاسخ no-store.
"""
import os
import re
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))
os.environ["BZ_DATA_DIR"] = tempfile.mkdtemp(prefix="v284-")

import db  # noqa: E402

FAILS = []
TOTAL = [0]
KEYS = []          # every raw key issued during the test
PHONES = []        # every verified phone used


def ck(cond, label):
    TOTAL[0] += 1
    print(("  ✓ " if cond else "  ✗ ") + label)
    if not cond:
        FAILS.append(label)


def issue(platform="bale"):
    ch = db.messenger_challenge_new(purpose="login")
    key = db.messenger_login_key_new(ch["id"], platform)
    KEYS.append(key)
    return ch, key


def mk_customer(phone, name="ت", status="active"):
    con = db.connect()
    con.execute("INSERT INTO customers(phone,name,status) VALUES(?,?,?)",
                (phone, name, status))
    con.commit()
    cid = con.execute("SELECT id FROM customers WHERE phone=?", (phone,)).fetchone()["id"]
    con.close()
    PHONES.append(phone)
    return cid


def main():
    print("== v284: کلید یک‌بارمصرف ورود با پیام‌رسان ==")
    db.init()

    # ---- 1) مسیر عادی: اول کلید، بعد شماره ------------------------------
    ch, key = issue()
    ok, note, need = db.messenger_login_key_claim(key, "bale", "uid1", "chat1")
    ck(ok is True and need is True and "ارسال شماره" in note,
       "کلید درست ثبت شد و درخواست شماره می‌دهد")
    ph = "09121234567"
    PHONES.append(ph)
    res = db.messenger_login_key_redeem_contact("bale", "uid1", "chat1", ph)
    ck(res is not None and res[0] is True, "شمارهٔ تأییدشده ورود را کامل کرد")
    st = db.messenger_challenge_status(ch["id"], ch["browser_token"])
    cust = db.customer_by_phone(ph)
    ck(st is not None and st.get("approved_id") == cust["id"],
       "چالش ورود با همان مشتری approve شد")
    st2 = db.messenger_challenge_status(ch["id"], ch["browser_token"], consume=True)
    st3 = db.messenger_challenge_status(ch["id"], ch["browser_token"], consume=True)
    ck(st2 is not None and st3 is None, "تأییدیه فقط یک‌بار مصرف می‌شود")
    acc = db._one("SELECT * FROM messenger_accounts WHERE platform='bale' "
                  "AND platform_user_id='uid1'")
    ck(acc is not None and acc["customer_id"] == cust["id"],
       "اتصال حساب پیام‌رسان ثبت شد")

    # ---- 2) مسیر معکوس: اول شماره، بعد کلید -----------------------------
    ch2, key2 = issue()
    ph2 = "09122223344"
    PHONES.append(ph2)
    ck(db.messenger_login_key_stash_contact("bale", "uid2", "chat2", ph2) is True,
       "شمارهٔ تأییدشده قبل از کلید نگه داشته می‌شود")
    ok, note, need = db.messenger_login_key_claim(key2, "bale", "uid2", "chat2")
    ck(ok is True and need is False and "تأیید" in note,
       "با رسیدن کلید، ورود فوراً تکمیل شد")
    st = db.messenger_challenge_status(ch2["id"], ch2["browser_token"])
    ck(st is not None and st.get("approved_id") == db.customer_by_phone(ph2)["id"],
       "مسیر معکوس هم چالش را approve می‌کند")

    # ---- 3) کلید غلط / پلتفرم غلط ---------------------------------------
    ck(db.messenger_login_key_lookup("not-a-real-key") is None,
       "کلید ناشناخته هیچ ردیفی برنمی‌گرداند")
    ck(db.messenger_login_key_claim("not-a-real-key", "bale", "u", "c")[0] is False,
       "کلید ناشناخته claim نمی‌شود")
    ch3, key3 = issue("soroush")
    ck(db.messenger_login_key_claim(key3, "bale", "u", "c")[0] is False,
       "کلید سروش روی پلتفرم بله کار نمی‌کند (و برعکس)")

    # ---- 4) سقف ۵ تلاش ----------------------------------------------------
    ch4, key4 = issue()
    db.messenger_login_key_claim(key4, "bale", "uid4", "chat4")
    fails = 0
    for _ in range(5):
        r = db.messenger_login_key_redeem_contact("bale", "uid4", "chat4", "123")
        if r is not None and r[0] is False:
            fails += 1
    ck(fails == 5 and db.messenger_login_key_lookup(key4) is None,
       "بعد از ۵ تلاش ناموفق کلید می‌سوزد (dead)")

    # ---- 5) یک‌بارمصرفی و سوزاندن کلید قبلی ------------------------------
    ch5, keyA = issue()
    keyB = db.messenger_login_key_new(ch5["id"], "bale")
    KEYS.append(keyB)
    ck(db.messenger_login_key_lookup(keyA) is None
       and db.messenger_login_key_lookup(keyB) is not None,
       "صدور کلید تازه، کلید قبلی همان چالش را باطل می‌کند")
    ch6, key6 = issue()
    db.messenger_login_key_claim(key6, "bale", "uid6", "chat6")
    ph6 = "09126667788"
    PHONES.append(ph6)
    db.messenger_login_key_redeem_contact("bale", "uid6", "chat6", ph6)
    ck(db.messenger_login_key_lookup(key6) is None,
       "کلید مصرف‌شده (done) دیگر lookup نمی‌شود")

    # ---- 6) انقضا ----------------------------------------------------------
    ch7, key7 = issue()
    db._run("UPDATE messenger_login_keys SET expires=1 WHERE key_hash=?",
            (db._secret_hash(key7),))
    ck(db.messenger_login_key_lookup(key7) is None
       and db.messenger_login_key_claim(key7, "bale", "u", "c")[0] is False,
       "کلید منقضی‌شده کار نمی‌کند")

    # ---- 7) تضاد A: این uid به مشتری دیگری وصل است -----------------------
    cxA = mk_customer("09129000001", "الف")
    cyA = mk_customer("09129000002", "ب")
    db._run("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,"
            "chat_id,active) VALUES(?,?,?,?,'1')", (cxA, "bale", "uidX", "chatX"))
    chA, keyA2 = issue()
    db.messenger_login_key_claim(keyA2, "bale", "uidX", "chatX")
    r = db.messenger_login_key_redeem_contact("bale", "uidX", "chatX", "09129000002")
    ck(r is not None and r[0] is False and "متصل است" in r[1],
       "تضاد A رد شد: uid متعلق به مشتری دیگر است")

    # ---- 8) تضاد B: این شماره به uid دیگری وصل است -----------------------
    chB, keyB2 = issue()
    db._run("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,"
            "chat_id,active) VALUES(?,?,?,?,'1')", (cyA, "bale", "uidOLD", "chatOLD"))
    db.messenger_login_key_claim(keyB2, "bale", "uidNEW", "chatNEW")
    r = db.messenger_login_key_redeem_contact("bale", "uidNEW", "chatNEW", "09129000002")
    ck(r is not None and r[0] is False and "متصل شده" in r[1],
       "تضاد B رد شد: شماره به حساب پیام‌رسان دیگری وصل است")

    # ---- 9) مشتری مسدود -----------------------------------------------------
    blk = mk_customer("09129000003", "مسدود", status="blocked")
    chC, keyC = issue()
    db.messenger_login_key_claim(keyC, "bale", "uidC", "chatC")
    r = db.messenger_login_key_redeem_contact("bale", "uidC", "chatC", "09129000003")
    ck(r is not None and r[0] is False and "اجازه" in r[1],
       "مشتری مسدود با کلید هم وارد نمی‌شود")

    # ---- 10) لاگ: بدون کلید خام، بدون شمارهٔ کامل -------------------------
    con = db.connect()
    rows = con.execute("SELECT action, detail FROM audit "
                       "WHERE action='messenger_login_key'").fetchall()
    con.close()
    ck(len(rows) >= 1, "هر ورود موفق در audit ثبت می‌شود")
    blob = "\n".join(f"{r['action']} {r['detail']}" for r in rows)
    ck(not any(k in blob for k in KEYS), "هیچ کلید خامی در لاگ نیست")
    ck(not any(p in blob for p in PHONES), "هیچ شمارهٔ کاملی در لاگ نیست")

    # ---- 11) پین منبع: اندپوینت /api/login-key ----------------------------
    app = (ROOT / "server" / "app.py").read_text(encoding="utf-8")
    ep = app[app.index('if path == "/api/login-key"'):]
    ep = ep[:ep.index("# ---- v233 admin bot webhook")]
    ck('db.rate_ok("lkey:"' in ep and "limit=3" in ep and "window=600" in ep,
       "ریت‌لیمیت ۳ درخواست در ۱۰ دقیقه روی اندپوینت")
    ck('"bzv2_"' in ep and "messenger_challenge_status" in ep,
       "صدور کلید فقط با کوکی مرورگرِ همان چالش")
    ck("purpose\") != \"login" in ep.replace("'", '"') or 'purpose") != "login"' in ep,
       "فقط چالش login (نه link) کلید می‌گیرد")
    ck("approved_id" in ep and '"no-store"' in ep,
       "چالش approve‌شده کلید نمی‌گیرد؛ پاسخ no-store است")

    # ---- 12) پین منبع: وبهوک‌ها ---------------------------------------------
    ck(app.count("messenger_login_key_redeem_contact(") >= 2
       and app.count("messenger_login_key_claim(") >= 2
       and app.count("messenger_login_key_stash_contact(") >= 2,
       "هر دو وبهوک (بله+سروش) سه قلاب کلید را دارند")
    ck(app.count('str(contact.get("user_id")) != str(uid)') >= 1
       or app.count('contact.get("user_id") is None') >= 1,
       "شماره فقط با contact.user_id == فرستنده پذیرفته می‌شود")
    ck(re.search(r"\[A-Za-z0-9_-\]\{16,24\}", app) is not None,
       "regex کلید ۱۶ تا ۲۴ نویسه (payload دیپ‌لینک را نمی‌بلعد)")

    # ---- 13) پین منبع: صفحهٔ انتظار + CSS + کش‌باستر -----------------------
    vo = (ROOT / "server" / "views_owner.py").read_text(encoding="utf-8")
    ck(vo.count('data-lk-fallback') >= 2 and vo.count("/api/login-key") >= 1,
       "پنل روش دوم در هر دو صفحهٔ انتظار (بله+سروش)")
    ck('data-lk-key' in vo and 'data-lk-link' in vo and "lkCopy" in vo,
       "کلید و لینک ربات با دکمهٔ کپی")
    ck("20000" in vo and "lkdet.open=true" in vo,
       "بعد از ۲۰ ثانیه بی‌نتیجه‌ماندن، پنل خودکار باز می‌شود")
    css = (ROOT / "site" / "assets" / "css" / "main.css").read_text(encoding="utf-8")
    ck(".lk-fallback" in css and ".lk-box" in css, "استایل‌های .lk-* در main.css")
    ui = (ROOT / "server" / "ui.py").read_text(encoding="utf-8")
    # v289: کش‌باستر از VERSION.txt
    _ver = (ROOT / "VERSION.txt").read_text(encoding="utf-8").strip()
    # ممیزی v329 (v298): av() منبع واحد.
    ck(("main.css?v" + _ver) in ui or "av('/assets/css/main.css')" in ui,
       "کش‌باستر main.css?v" + _ver + " (av یا لترال)")

    if FAILS:
        print("\nشکست: " + "; ".join(FAILS))
        return 1
    print(f"\nهمهٔ {TOTAL[0]} بررسی سبز ✅")
    return 0


if __name__ == "__main__":
    sys.exit(main())
