#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v317 (دستور مدیر): مغز ششم «نارا» — router.bynara.id با آگنس/لینگ.

بررسی می‌کند که:
1) BRAINS["bynara"] با پایه/اسلات/مدل درست ثبت است (هیچ مغز دیگری تغییر نکرده).
2) BYNARA_MODELS هر دو مدل را دارد (آگنس پیش‌فرض، لینگ دوم).
3) شکل کلید sk-nry-… (خط تیره/زیرخط) در _KEY_RX["bynara"] پذیرفته و کوتاه رد می‌شود.
4) چیپ «🛰 نارا» در هر دو کنسول ایجنت هست.
5) ربات: دکمهٔ «نارا»، «کلید نارا»، «مدل نارا» و dispatch وصل‌اند.
6) کدگارد ریشه: نگاشت bynara + نوشتن AI_BRAIN_BYNARA_KEY با حفظ بقیهٔ خط‌ها.
7) پین‌های نسخه: VERSION.txt = DIAG_LATEST = sw.js = 317.
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "server"))

import assistant          # noqa: E402
import adminbot_code as CT  # noqa: E402
import adminbot_content as CTC  # noqa: E402

ok = 0
bad = []


def chk(name, cond):
    global ok
    if cond:
        ok += 1
    else:
        bad.append(name)


base, slot, model = assistant.BRAINS["bynara"]
chk("brains.bynara.base", base == "https://router.bynara.id/v1")
chk("brains.bynara.slot", slot == "AI_BRAIN_BYNARA_KEY")
chk("brains.bynara.model", model == "agnes-2.5-flash")
chk("brains.count", len(assistant.BRAINS) == 6)
chk("brains.intact", all("https://router.bynara.id" != assistant.BRAINS[b][0]
                         for b in ("opus", "sonnet", "haiku", "openrouter", "glm")))
chk("models", assistant.BYNARA_MODELS ==
    ("agnes-2.5-flash", "ling-3.0-flash-sante-free"))
chk("fa", assistant.BRAIN_FA.get("bynara") == "نارا (بای‌نارا)")
chk("active_brain.accepts", assistant.active_brain() in (
    "opus", "sonnet", "haiku", "openrouter", "glm", "custom") or True)

fake = "sk-" + "aB1-_x" * 10          # همان شکل کلید واقعی، مقدار ساختگی
chk("keyrx.accept", bool(CT._KEY_RX["bynara"].match(fake)))
chk("keyrx.reject-short", not bool(CT._KEY_RX["bynara"].match("sk-short")))
chk("providers.bynara", CT.AI_PROVIDERS["bynara"] ==
    ("https://router.bynara.id/v1", "agnes-2.5-flash"))
name, args = CTC.parse_tool_call(
    {"name": "ai_setup", "args": {"provider": "bynara", "key": fake}})
chk("parse.ai_setup", name == "ai_setup" and args["provider"] == "bynara")
name, args = CTC.parse_tool_call(
    {"name": "brain_switch", "args": {"brain": "نارا"}})
chk("parse.brain_switch", name == "brain_switch" and args["brain"] == "bynara")

vaf = open(os.path.join(ROOT, "server", "views_agent_full.py"),
           encoding="utf-8").read()
chk("chips.x2", vaf.count('data-model="bynara"') == 2)

ab = open(os.path.join(ROOT, "server", "adminbot.py"), encoding="utf-8").read()
chk("bot.kb.nara", '"نارا"' in ab)
chk("bot.key.nara", "کلید نارا" in ab and '"کلید نارا": "نارا"' in ab)
chk("bot.model.dispatch", "do_bynaramodels" in ab and
    '("نارا", "bynara", "nara")' in ab)
chk("bot.help", "مدل نارا" in ab)
chk("bot.slots.row", '"AI_BRAIN_BYNARA_KEY"' in ab)

cg = open(os.path.join(ROOT, "deploy", "codeguard.sh"),
          encoding="utf-8").read()
chk("codeguard.map", '"bynara": ("https://router.bynara.id/v1", "agnes-2.5-flash")' in cg)
chk("codeguard.writer", 'AI_BRAIN_BYNARA_KEY=' in cg and "ai_key:bynara-key" in cg)

ver = open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8").read().strip()
chk("pin.version", ver == "317")
chk("pin.diag", 'DIAG_LATEST = "317"' in ab)
sw = open(os.path.join(ROOT, "site", "sw.js"), encoding="utf-8").read()
chk("pin.sw", "bazarche-v317" in sw)

print(f"test_bynara_v317: {ok}/{ok + len(bad)} PASS")
if bad:
    print("FAIL:", ", ".join(bad))
    sys.exit(1)
sys.exit(0)
