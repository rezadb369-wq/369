# -*- coding: utf-8 -*-
"""v241: full-site CODE access for the admin copilot — the in-process half.

The systemd unit keeps the app sandboxed (ReadWritePaths = data/ and
uploads/ only), so the app itself can never write code files. Instead:

* ``code_list`` / ``code_read`` run immediately (reads are allowed): the
  model explores the real tree and the last read region is parked in a
  side-file so the NEXT snapshot carries it (``code_context``).
* ``code_edit`` / ``code_write`` / ``code_revert`` are normal proposals:
  strict parse → precheck → the owner's «بله» → a job JSON is dropped in
  ``data/code-jobs/``. The root-side ``deploy/codeguard.sh`` cron applies
  the job (backup → apply → py_compile → sw.js bump → restart → healthz →
  auto-rollback + Bale notify on failure). ``service_restart`` reuses the
  legacy adminbot-cmd queue.

Hard locks (unchanged by design): secrets (outside the app dir), the
runtime data/ tree, uploads, the delivery guard itself (deploy/, tools/,
VERSION.txt, sw.js) and the bot's own brains (adminbot*.py, assistant.py,
bale.py) — breaking those is not healthz-visible, so the tool that could
fix them must never be the thing that broke them. Everything else under
the app root — server/, site/, docs/, templates, run.py — is editable.
"""
import json
import os
import re
import time
import urllib.error

import db

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# --- keep in sync with the embedded applier in deploy/codeguard.sh ---
DENY_PREFIXES = ("data/", "deploy/", "tools/", "docs/superpowers/",
                 "site/assets/img/uploads/", "site/assets/chat-files/",
                 "backups/", ".git/")
DENY_FILES = {"VERSION.txt", "site/sw.js", "server/adminbot.py",
              "server/adminbot_content.py", "server/adminbot_code.py",
              "server/assistant.py", "server/bale.py"}
TEXT_EXT = (".py", ".html", ".js", ".css", ".md", ".json", ".txt", ".svg",
            ".webmanifest", ".xml", ".yml", ".yaml", ".toml", ".cfg", ".ini",
            ".conf", ".map", ".csv")
AI_PROVIDERS = {"gemini": ("https://generativelanguage.googleapis.com/v1beta/openai",
                           "gemini-2.5-flash-lite"),
                "groq": ("https://api.groq.com/openai/v1",
                         "llama-3.3-70b-versatile"),
                "astra": ("https://api.openai.com/v1", "gpt-6-astra"),
                # v259 (دستور مدیر: مغز Claude) — v260: شناسه‌های مستند AvalAI.
                "muse": ("https://api.avalai.ir/v1", "claude-sonnet-5"),
                # v262→v265: OpenRouter مغز چهارم مستقل است (نه یدک).
                "openrouter": ("https://openrouter.ai/api/v1",
                               "nvidia/nemotron-3-ultra-550b-a55b:free"),
                # v273 (دستور مدیر: «کیرا کلا حذف بشه؛ کلید GLM فقط برای
                # پنل مدیریتی و از بات قابل تنظیم باشه»): مغز پنجم = GLM روی
                # AvalAI؛ تست زندهٔ کلید مغز پنجم هم با همین مدل است.
                "glm": ("https://api.avalai.ir/v1", "glm-5.3-flash"),
                # v317 (دستور مدیر: «کلید byNara را به همهٔ قسمت‌ها اضافه
                # کن»): مغز ششم = روتر byNara؛ تست زنده با agnes-2.5-flash
                # (تست‌شده ۲۰۲۶-۰۹-۲۲). ۵۰ مدل: assistant.BYNARA_MODELS.
                "bynara": ("https://router.bynara.id/v1", "agnes-2.5-flash"),
                # v269 (دستور مدیر: هوش سایت کاملاً جدا از محیط مدیر):
                # اسلات هوش عمومی سایت (AI_SITE_*) — v317: پیش‌فرض byNara
                # + agnes-2.5-flash (کلید: AI_SITE_* یا به‌عنوان پس‌انداز،
                # همان کلید byNara — assistant.site_config).
                "site": ("https://router.bynara.id/v1", "agnes-2.5-flash")}
_KEY_RX = {"gemini": re.compile(r"^AIza[A-Za-z0-9_\-]{30,}$"),
           "groq": re.compile(r"^gsk_[A-Za-z0-9]{30,50}$"),
           "astra": re.compile(r"^sk-(?!or-v1-)[A-Za-z0-9_\-]{20,}$"),  # v262: sk-or-v1-… is openrouter, never astra
           # v292: کلیدهای واقعی AvalAI می‌توانند - و _ داشته باشند؛ شکل
           # سخت‌گیرانهٔ قبلی (فقط حروف/رقم) کلید سالم را «بی‌شکل» می‌خواند.
           "muse": re.compile(r"^aa-[A-Za-z0-9_\-]{20,120}$"),
           "openai": re.compile(r"^[A-Za-z0-9_\-]{20,120}$"),
           "openrouter": re.compile(r"^sk-or-v1-[A-Za-z0-9]{32,}$"),
           # v273 (دستور مدیر: کیرا کلا حذف شد): کلید مغز پنجم = کلید aa-
           # مدیر (AvalAI). شکل قدیمی kira_ دیگر پذیرفته نمی‌شود.
           "glm": re.compile(r"^aa-[A-Za-z0-9_\-]{20,120}$"),
           # v317: کلید روتر byNara — شکل واقعی sk-nry-… (تست‌شده).
           "bynara": re.compile(r"^sk-nry-[A-Za-z0-9_\-]{20,120}$"),
           # v269: هوش سایت (عمومی) — اسلات مستقل؛ هر کلید سازگار با OpenAI.
           "site": re.compile(r"^[A-Za-z0-9_\-]{20,120}$")}
_BASE_RX = re.compile(r"^https://[A-Za-z0-9.\-]+(?:/[A-Za-z0-9._\-]*){0,3}/?$")
_MODEL_RX = re.compile(r"^[A-Za-z0-9._\-/:]{1,80}$")  # v262: OpenRouter-style ids (a/b:free)

_PATH_RX = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_./\-]{0,200}$")
MAX_EDIT_CHARS = 3000        # per old/new block
MAX_EDITS = 8                # per proposal
MAX_WRITE_CHARS = 24000      # code_write content
MAX_FILE_BYTES = 400000      # readable/writable file size
READ_SPAN = 250              # max lines per code_read
CHAT_CAP = 3600              # what the bot echoes back (Bale ~4096)
CONTEXT_CAP = 2400           # what the model sees in the snapshot (v246 diet)
SIDE_TTL = 1800              # seconds the read side-file stays fresh
RESTART_RATE = 120           # min seconds between restart jobs


def jobs_dir():
    return os.path.join(db.DATA_DIR, "code-jobs")


def backups_dir():
    return os.path.join(db.DATA_DIR, "code-backups")


def _code_sidefile():
    return os.environ.get("ADMINBOT_CODE") or "/tmp/dastgir-admin-code.json"


# ------------------------------------------------------------------ paths

def norm_path(p):
    """Relative app-root path or None. No abs, no .., no whitespace, must
    realpath inside ROOT, must not hit a locked prefix/file."""
    p = str(p or "").strip().strip("/")
    if not p or not _PATH_RX.match(p) or p.endswith("/"):
        return None
    if ".." in p or "/./" in p or "//" in p:
        return None
    if "__pycache__" in p:
        return None
    low = p.lower()
    if any(low == d.rstrip("/") or low.startswith(d) for d in DENY_PREFIXES):
        return None
    if p in DENY_FILES:
        return None
    real = os.path.realpath(os.path.join(ROOT, p))
    if not real.startswith(ROOT + os.sep):
        return None
    return p


def _is_text(p):
    return os.path.splitext(p)[1].lower() in TEXT_EXT


def search_hits(query, max_hits=25, max_files=1200):
    """v246: pure code search — [(rel_path, line_no, line_text), …] over the
    editable tree only (locked files/prefixes never appear)."""
    q = str(query or "").lower()
    if len(q) < 2:
        return []
    hits, seen = [], 0
    for dirpath, dirnames, filenames in os.walk(ROOT):
        rel_dir = os.path.relpath(dirpath, ROOT).replace(os.sep, "/")
        dirnames[:] = [d for d in dirnames
                       if norm_path((rel_dir + "/" + d) if rel_dir != "." else d)]
        for fn in sorted(filenames):
            rel = (rel_dir + "/" + fn) if rel_dir != "." else fn
            if norm_path(rel) is None or not _is_text(rel):
                continue
            seen += 1
            if seen > max_files:
                break
            fp = os.path.join(dirpath, fn)
            try:
                if os.path.getsize(fp) > MAX_FILE_BYTES:
                    continue
                body = open(fp, encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            for i, ln in enumerate(body.split("\n")):
                if q in ln.lower():
                    hits.append((rel, i + 1, ln.strip()[:90]))
                    if len(hits) >= max_hits:
                        return hits
            if seen > max_files:
                break
    return hits


def read_region(path, around, before=30, after=40, cap=3800):
    """(from_line, to_line, text) around a line, or None. Locked/missing/
    binary-safe. The autopilot feeds ONLY this small region to a weak brain."""
    p = norm_path(path)
    if not p or not _is_text(p):
        return None
    f = os.path.join(ROOT, p)
    try:
        if os.path.getsize(f) > MAX_FILE_BYTES:
            return None
        lines = open(f, encoding="utf-8", errors="replace").read().split("\n")
    except OSError:
        return None
    a = max(1, around - before)
    b = min(len(lines), around + after)
    text = "\n".join(lines[a - 1:b])
    return a, b, text[:cap]


def read_file(path):
    """Whole file text (editable tree only) or None."""
    p = norm_path(path)
    if not p or not _is_text(p):
        return None
    try:
        if os.path.getsize(os.path.join(ROOT, p)) > MAX_FILE_BYTES:
            return None
        return open(os.path.join(ROOT, p), encoding="utf-8").read()
    except (OSError, UnicodeDecodeError):
        return None


# ------------------------------------------------------------------ parse

def parse(name, a):
    """Strict arg validation (pure, no IO). Returns (name, args) or (None, {})."""
    if name == "code_list":
        p = str(a.get("path") or "").strip().strip("/")
        if p:
            if not _PATH_RX.match(p) or p in DENY_FILES:
                return None, {}
            low = p.lower()
            if any(low == d.rstrip("/") or low.startswith(d) for d in DENY_PREFIXES):
                return None, {}
        return name, {"path": p}
    if name == "code_read":
        p = norm_path(a.get("path"))
        if not p or not _is_text(p):
            return None, {}
        try:
            frm = max(1, int(a.get("from_line") or 1))
            to = frm - 1 + READ_SPAN
            if a.get("to_line") is not None:
                to = int(a.get("to_line"))
        except (TypeError, ValueError):
            return None, {}
        if to < frm or to - frm + 1 > READ_SPAN:
            return None, {}
        return name, {"path": p, "from_line": frm, "to_line": to}
    if name == "code_edit":
        p = norm_path(a.get("path"))
        if not p or not _is_text(p):
            return None, {}
        raw = a.get("edits")
        if isinstance(raw, str):            # idempotent re-parse
            try:
                raw = json.loads(raw)
            except ValueError:
                raw = None
        if not isinstance(raw, list) or not raw or len(raw) > MAX_EDITS:
            return None, {}
        edits = []
        for e in raw:
            if not isinstance(e, dict):
                return None, {}
            old, new = str(e.get("old") or ""), str(e.get("new") or "")
            if not old or old == new or len(old) > MAX_EDIT_CHARS \
                    or len(new) > MAX_EDIT_CHARS or "\x00" in old + new:
                return None, {}
            edits.append({"old": old, "new": new})
        return name, {"path": p, "edits": edits,
                      "summary": str(a.get("summary") or "")[:120]}
    if name == "code_write":
        p = norm_path(a.get("path"))
        if not p or not _is_text(p):
            return None, {}
        content = str(a.get("content") or "")
        if not content.strip() or len(content) > MAX_WRITE_CHARS:
            return None, {}
        return name, {"path": p, "content": content,
                      "summary": str(a.get("summary") or "")[:120]}
    if name == "code_revert":
        p = norm_path(a.get("path"))
        if not p:
            return None, {}
        return name, {"path": p}
    if name == "code_status":
        return name, {}
    if name == "code_search":
        q = str(a.get("query") or "").strip()
        if len(q) < 2 or len(q) > 60 or "\x00" in q:
            return None, {}
        return name, {"query": q}
    if name == "ai_setup":
        prov = str(a.get("provider") or "").strip().lower()
        key = str(a.get("key") or "").strip()
        if prov == "openai":        # v243: any OpenAI-compatible gateway
            base = str(a.get("base") or "").strip().rstrip("/")
            model = str(a.get("model") or "").strip()
            if not _KEY_RX["openai"].match(key) or not _BASE_RX.match(base) \
                    or not _MODEL_RX.match(model):
                return None, {}
            return name, {"provider": prov, "key": key,
                          "base": base, "model": model}
        if prov == "site":          # v269: هوش عمومی سایت (اسلات AI_SITE_*)
            if not _KEY_RX["site"].match(key):
                return None, {}
            base = str(a.get("base") or "").strip().rstrip("/") \
                or AI_PROVIDERS["site"][0]
            model = str(a.get("model") or "").strip() \
                or AI_PROVIDERS["site"][1]
            if not _BASE_RX.match(base) or not _MODEL_RX.match(model):
                return None, {}
            return name, {"provider": prov, "key": key,
                          "base": base, "model": model}
        if prov not in AI_PROVIDERS or not _KEY_RX[prov].match(key):
            return None, {}
        out = {"provider": prov, "key": key}
        if prov == "muse":
            # v271 (دستور مدیر: توکن تک‌تک مدل‌ها): اسلات صریح تا کلید هر
            # مغز کلاد جداگانه نصب شود (اپوس/سونت/هایکو).
            slot = str(a.get("slot") or "").strip().lower()
            if slot in ("opus", "sonnet", "haiku"):
                out["slot"] = slot
        return name, out
    if name == "brain_switch":
        # v263: سوئیچ فوری مغز (دستور مستقیم /مغز — بدون صف و ری‌استارت).
        b = str(a.get("brain") or "").strip().lower()
        b = {"اپوس": "opus", "سونت": "sonnet", "سانت": "sonnet",
             "هایکو": "haiku", "هايکو": "haiku", "open": "openrouter",
             "اوپن": "openrouter", "اوپنروتر": "openrouter",
             "جی‌ال‌ام": "glm", "جی ال ام": "glm",
             "بای‌نارا": "bynara", "باینارا": "bynara", "بای نارا": "bynara",
             "آژنس": "bynara", "اجنس": "bynara"}.get(b, b)   # v317
        if b not in ("opus", "sonnet", "haiku", "openrouter", "glm",
                     "bynara"):
            return None, {}
        return name, {"brain": b}
    if name == "service_restart":
        return name, {}
    return None, {}


def resolve_edit(src, old):
    """(exact_text, reason) — weak models misquote whitespace, so the server
    fixes the quote against the file it just showed: exact → trimmed →
    indentation-insensitive unique match."""
    if old in src:
        return old, ""
    a = old.strip()
    if a and a in src:
        return a, ""
    pat = [ln.strip() for ln in a.split("\n") if ln.strip()]
    if not pat:
        return None, "nomatch"
    lines = src.split("\n")
    hits = []
    for i in range(len(lines) - len(pat) + 1):
        if [ln.strip() for ln in lines[i:i + len(pat)]] == pat:
            hits.append("\n".join(lines[i:i + len(pat)]))
            if len(hits) > 1:
                return None, "ambiguous"
    if not hits:
        return None, "nomatch"
    return hits[0], ""


def deploy_receipts(last=3):
    """v244: what codeguard ACTUALLY did (root side appends this log)."""
    try:
        p = os.path.join(db.DATA_DIR, "code-deploys.log")
        lines = [l.strip() for l in open(p, encoding="utf-8").read().split("\n")
                 if l.strip()]
        return lines[-last:]
    except OSError:
        return []


def code_status_text():
    """Real deployment state: queue + receipts + a loud signal when the
    root guard isn't running (jobs stuck > 3 minutes)."""
    jd = jobs_dir()
    names = [x for x in os.listdir(jd) if x.endswith(".json")] \
        if os.path.isdir(jd) else []
    now = time.time()
    oldest, stale = 0.0, 0
    for x in names:
        try:
            age = now - os.path.getmtime(os.path.join(jd, x))
        except OSError:
            continue
        oldest = max(oldest, age)
        if age > 180:
            stale += 1
    out = []
    if names:
        extra = f" (قدیمی‌ترین {int(oldest // 60)} دقیقه)" if oldest > 90 else ""
        out.append(f"صف استقرار: {len(names)} کار{extra}")
        if stale:
            out.append(f"⚠️ {stale} کار بیش از ۳ دقیقه در صف مانده — کدگارد اجرا "
                       "نمی‌شود! کرون /etc/cron.d/dastgir-codeguard نصب/فعال نیست.")
    else:
        out.append("صف استقرار: خالی")
    r = deploy_receipts()
    out.append("آخرین استقرارها: " + (" | ".join(r) if r else "هنوز هیچی ثبت نشده"))
    return "\n".join(out)


# ------------------------------------------------------------------ precheck

def _muse_slot(args):
    """v263: /کلید Muse در کدام مغز می‌نشیند — اسلات صریح، وگرنه مغز
    فعالِ کلاد، وگرنه سونت."""
    s = str((args or {}).get("slot") or "").strip().lower()
    if s in ("opus", "sonnet", "haiku"):
        return s
    try:
        b = (db.get_settings().get("ai_brain_active") or "sonnet").strip().lower()
    except Exception:
        b = "sonnet"
    return b if b in ("opus", "sonnet", "haiku") else "sonnet"


def precheck(name, args):
    """No writes. Returns (ok, reason)."""
    try:
        if name == "code_list":
            d = os.path.join(ROOT, args["path"]) if args["path"] else ROOT
            if not os.path.isdir(d):
                return False, "missing"
            return True, ""
        if name == "code_read":
            f = os.path.join(ROOT, args["path"])
            if not os.path.isfile(f):
                return False, "missing"
            if os.path.getsize(f) > MAX_FILE_BYTES:
                return False, "big"
            return True, ""
        if name in ("code_edit", "code_revert"):
            f = os.path.join(ROOT, args["path"])
            if name == "code_revert":
                if not _newest_backup(args["path"]):
                    return False, "missing"
                return True, ""
            if not os.path.isfile(f):
                return False, "missing"
            if os.path.getsize(f) > MAX_FILE_BYTES:
                return False, "big"
            try:
                src = open(f, encoding="utf-8").read()
            except (OSError, UnicodeDecodeError):
                return False, "binary"
            for e in args["edits"]:
                exact, why = resolve_edit(src, e["old"])   # v242 fuzzy quote fix
                if not exact:
                    return False, why
                if len(exact) > MAX_EDIT_CHARS:
                    return False, "big"
                e["old"] = exact          # server-side rewrite to the exact text
                if src.count(exact) != 1:
                    return False, "ambiguous"
                src = src.replace(exact, e["new"], 1)
            if len(src) > MAX_FILE_BYTES:
                return False, "big"
            return True, ""
        if name == "code_write":
            f = os.path.join(ROOT, args["path"])
            if os.path.isfile(f) and os.path.getsize(f) > MAX_FILE_BYTES:
                return False, "big"
            parent = os.path.dirname(f)
            if os.path.exists(parent) and not os.path.isdir(parent):
                return False, "missing"
            return True, ""
        if name == "code_status":
            return True, ""
        if name == "code_search":
            return True, ""
        if name == "ai_setup":
            import assistant          # lazy: avoids an import cycle
            if args["provider"] == "site":
                # v269: اسلات هوش سایت — base/model صریح (پیش‌فرض در parse).
                base, model = args["base"], args["model"]
            elif args["provider"] in AI_PROVIDERS:
                base, model = AI_PROVIDERS[args["provider"]]
                if args["provider"] == "muse":
                    # v263: هر مدل کلید خودش را دارد — کلید تازه با مدل
                    # همان مغزی تست می‌شود که قرار است در آن بنشیند.
                    model = {"opus": "claude-opus-5", "sonnet": "claude-sonnet-5",
                             "haiku": "claude-haiku-4-5"}.get(_muse_slot(args), model)
            else:                     # v243: generic OpenAI-compatible
                base, model = args["base"], args["model"]
            try:
                assistant._chat(base, args["key"], model,
                                [{"role": "user", "content": "ping"}], 30, 5)
                return True, ""
            except urllib.error.HTTPError as e:
                if e.code == 403:
                    return False, "akey:403"
                return False, "akey:" + str(e.code)
            except Exception:
                return False, "akey:network"
        if name == "brain_switch":
            import assistant          # lazy: avoids an import cycle
            brain = args["brain"]
            base, slot, model = assistant.BRAINS[brain]
            key = (os.environ.get(slot) or "").strip()
            if not key:
                return False, "bkey:" + brain
            try:
                assistant._chat(base, key, model,
                                [{"role": "user", "content": "ping"}], 30, 5)
                return True, ""
            except urllib.error.HTTPError as e:
                return False, "btest:%s:%s" % (brain, e.code)
            except Exception:
                return False, "btest:%s:network" % brain
        if name == "service_restart":
            if _restart_recent():
                return False, "rate"
            return True, ""
    except OSError:
        return False, "missing"
    return False, "missing"


# ------------------------------------------------------------------ execute

def execute(name, args):
    """Runs the tool. Reads answer directly; writes only queue a job for the
    root-side codeguard cron. Returns (ok, message)."""
    try:
        ok, why = precheck(name, args)
        if not ok:
            return False, why

        if name == "code_list":
            base = os.path.join(ROOT, args["path"]) if args["path"] else ROOT
            out, hidden = [], 0
            for e in sorted(os.listdir(base))[:80]:
                rel = (args["path"] + "/" + e) if args["path"] else e
                full = os.path.join(base, e)
                locked = (norm_path(rel) is None)
                tag = "🔒" if locked else ("/" if os.path.isdir(full) else "")
                if locked and os.path.isfile(full):
                    hidden += 1
                    continue
                out.append(e + tag)
            msg = "🗂 " + (args["path"] or "(ریشهٔ سایت)") + ": " + " · ".join(out[:60])
            if hidden:
                msg += f" · (+{hidden} فایل قفل‌شده)"
            db.log("admin_ai_tool", f"code_list {args['path'] or '/'}")
            return True, msg[:CHAT_CAP]

        if name == "code_read":
            f = os.path.join(ROOT, args["path"])
            lines = open(f, encoding="utf-8", errors="replace").read().split("\n")
            a, b = args["from_line"], min(args["to_line"], len(lines))
            picked = [f"{i+1:>4}| {lines[i]}" for i in range(a - 1, max(a - 1, b))]
            body = "\n".join(picked)
            _side_save(args["path"], a, b, body)
            db.log("admin_ai_tool", f"code_read {args['path']} {a}-{b}")
            head = body[:CHAT_CAP - 200]
            if len(body) > len(head):
                head += f"\n… (ادامه: از خط {b + 1})"
            return True, f"📄 {args['path']} خطوط {a}–{b}:\n{head}"

        if name == "code_status":
            db.log("admin_ai_tool", "code_status")
            return True, "🚦 وضعیت واقعی استقرار:\n" + code_status_text()

        if name == "code_search":
            hits = search_hits(args["query"])
            db.log("admin_ai_tool", "code_search " + args["query"][:40])
            if not hits:
                return True, ("🔍 چیزی برای «" + args["query"] + "» پیدا نشد "
                              "(یا فقط در بخش‌های قفل‌شده بود).")
            more = "" if len(hits) < 25 else "\n… (نمایش ۲۵ نتیجهٔ اول)"
            shown = [f"{p}:{ln}: {s}" for p, ln, s in hits]
            return True, ("🔍 «" + args["query"] + "» — " + str(len(hits)) +
                          " نتیجه:\n" + "\n".join(shown) + more)[:CHAT_CAP]

        if name == "ai_setup":
            job = {"kind": "ai_key", "provider": args["provider"],
                   "key": args["key"], "ts": int(time.time())}
            if args["provider"] in ("openai", "site"):
                job["base"] = args["base"]
                job["model"] = args["model"]
            if args["provider"] == "muse":
                # v263: کلید کلاد در مغز فعال می‌نشیند (نه مغز تازهٔ جدا).
                job["slot"] = _muse_slot(args)
            if args["provider"] in ("gemini", "groq", "astra", "openai"):
                # v263: نصب خارجی = مغز دستی؛ /مغز هر وقت بخواهی برمی‌گرداند.
                # v269: provider=site عمداً اینجاست نیست — هوش سایت هیچ
                # اثری روی مغز فعال مدیر ندارد (دستور مدیر: محیط‌ها جدا).
                try:
                    db.set_settings({"ai_brain_active": "custom"})
                except Exception:
                    pass
            _enqueue(job)
            db.log("admin_ai_tool",
                   "ai_setup " + args["provider"] +
                   (" " + args["model"] if args.get("model") else "") +
                   " " + args["key"][:4] + "***")
            if args["provider"] == "site":
                return True, ("🌐 کلید هوش سایت تست شد و نصبش در صف است؛ "
                              "هوش عمومی سایت (جدا از مغزهای شما) تا یک دقیقهٔ "
                              "دیگر با مدل " + args["model"] + " تازه می‌شود.")
            if args["provider"] == "openrouter":
                return True, ("🧠 کلید اوپن‌روتر تست شد و نصبش در صف است؛ "
                              "مغز چهارم تازه می‌شود.")
            if args["provider"] == "glm":
                # v273 (دستور مدیر): مغز پنجم = GLM؛ کلید فقط در اسلات
                # AI_BRAIN_GLM_KEY می‌نشیند (پنل مدیریتی).
                return True, ("🧠 کلید مغز پنجم (GLM) تست شد و نصبش در صف است؛ "
                              "GLM 5.3 Flash تازه می‌شود.")
            if args["provider"] == "bynara":
                # v317 (دستور مدیر): مغز ششم = byNara؛ کلید در اسلات
                # AI_BRAIN_BYNARA_KEY می‌نشیند و هوش سایت هم با همین کلید
                # راه می‌افتد (assistant.site_config).
                return True, ("🧠 کلید مغز ششم (byNara) تست شد و نصبش در صف است؛ "
                              "آژنس ۲.۵ فلش تازه می‌شود و هوش عمومی سایت هم "
                              "با همین کلید کار می‌کند.")
            if args["provider"] == "muse":
                import assistant as _AI       # lazy: brain names
                _fa = _AI.BRAIN_FA.get(job.get("slot"), "کلاد")
                return True, ("🧠 کلید تست شد و نصبش در صف است؛ تا یک دقیقهٔ دیگر "
                              "دستیار با مغز جدید جواب می‌دهد (سرویس یک‌بار ری‌استارت "
                              f"می‌شود؛ کلید در مغز {_fa} نشست).")
            return True, ("🧠 کلید تست شد و نصبش در صف است؛ تا یک دقیقهٔ دیگر "
                          "دستیار با مغز جدید جواب می‌دهد (سرویس یک‌بار ری‌استارت می‌شود).")

        if name == "brain_switch":
            import assistant as _AI       # lazy: avoids an import cycle
            db.set_settings({"ai_brain_active": args["brain"]})
            db.log("admin_ai_tool", "brain_switch " + args["brain"])
            return True, ("🧠 مغز فعال شد: " +
                          _AI.BRAIN_FA.get(args["brain"], args["brain"]) +
                          " — از همین حالا جواب می‌دهد (پنل و بات، بدون ری‌استارت).")

        if name in ("code_edit", "code_write", "code_revert"):
            job = {"kind": name, "path": args["path"], "ts": int(time.time())}
            if name == "code_edit":
                job["edits"] = args["edits"]
                job["summary"] = args["summary"]
            elif name == "code_write":
                job["content"] = args["content"]
                job["summary"] = args["summary"]
            _enqueue(job)
            db.log("admin_ai_tool",
                   f"{name} {args['path']} " + (args.get("summary") or "")[:60])
            return True, ("🛠 تغییر کد به صف استقرار رفت؛ "   # v268: no «بله» anymore
                          "کمتر از یک دقیقه دیگر اعمال می‌شود و نتیجهٔ سلامت "
                          "سایت همین‌جا اعلام می‌شود.")

        if name == "service_restart":
            _enqueue({"cmd": "restart", "ts": int(time.time())}, legacy=True)
            db.log("admin_ai_tool", "service_restart")
            return True, "🔁 راه‌اندازی مجدد به صف رفت؛ چند ثانیه طول می‌کشد."
    except OSError:
        return False, "missing"
    return False, "missing"


def _enqueue(job, legacy=False):
    d = (os.path.join(db.DATA_DIR, "adminbot-cmd") if legacy else jobs_dir())
    os.makedirs(d, exist_ok=True)
    name = f"{'cmd' if legacy else 'code'}-{int(time.time() * 10)}-{os.getpid()}.json"
    with open(os.path.join(d, name), "w", encoding="utf-8") as f:
        json.dump(job, f, ensure_ascii=False)


def _restart_recent():
    """True if a restart job is queued/ran inside RESTART_RATE seconds."""
    for d in (os.path.join(db.DATA_DIR, "adminbot-cmd"), jobs_dir()):
        try:
            for n in os.listdir(d):
                p = os.path.join(d, n)
                if os.path.getmtime(p) > time.time() - RESTART_RATE:
                    try:
                        j = json.load(open(p, encoding="utf-8"))
                    except (OSError, ValueError):
                        continue
                    if j.get("cmd") == "restart" or j.get("kind") == "restart":
                        return True
        except OSError:
            continue
    return False


# ------------------------------------------------------------------ backups index

def _newest_backup(rel):
    """Newest backup entry for a relative path (index written by codeguard)."""
    try:
        idx = json.load(open(os.path.join(backups_dir(), "index.json"),
                             encoding="utf-8"))
    except (OSError, ValueError):
        return None
    for e in sorted(idx, key=lambda x: -int(x.get("ts", 0))):
        if e.get("path") == rel and os.path.isfile(
                os.path.join(backups_dir(), e.get("file", ""))):
            return e
    return None


# ------------------------------------------------------------------ read sidecar

def _side_save(path, frm, to, body):
    try:
        with open(_code_sidefile(), "w", encoding="utf-8") as f:
            json.dump({"path": path, "from": frm, "to": to,
                       "content": body[:16000], "ts": time.time()}, f,
                      ensure_ascii=False)
    except OSError:
        pass


def code_context():
    """Snapshot block: the file the model last read, so its next code_edit
    can quote the exact text. Returns '' when stale/absent."""
    try:
        d = json.load(open(_code_sidefile(), encoding="utf-8"))
        if time.time() - float(d.get("ts", 0)) > SIDE_TTL:
            return ""
        body = str(d.get("content") or "")[:CONTEXT_CAP]
        if not body:
            return ""
        return (f"\n# آخرین فایل کدی که خواندی: {d.get('path')} "
                f"خطوط {d.get('from')}–{d.get('to')}\n"
                "(برای code_edit متنِ old را عیناً از همین‌جا کپی کن)\n" + body)
    except (OSError, ValueError, TypeError):
        return ""
