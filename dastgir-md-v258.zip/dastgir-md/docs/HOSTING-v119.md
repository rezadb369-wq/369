# 🚀 استقرار روی هاست و دامنه — راهنمای عملی v119

> 🗄️ **سند آرشیوی** — عکسِ وضعیت در زمان خودش. وضعیت فعلی: `docs/collaboration/CURRENT-STATE.md`.

> مکمل `DEPLOY.md` است. این سند بر پایهٔ تحقیق هاستینگ پایتون (هاست اشتراکی
> cPanel/DirectAdmin در برابر VPS ایرانی) + ویژگی‌های تازهٔ v119
> (`/healthz`، `security.txt`، محدودیت IP پنل، هدرهای امنیتی) نوشته شد.

---

## ۰) انتخاب: VPS ایرانی یا هاست اشتراکی پایتون؟

| گزینه | مزیت | نکته |
|---|---|---|
| **VPS ایرانی** (آروان، پارس‌پک، ایران‌سرور) | سرعت بالا برای کاربر ایرانی، کنترل کامل، systemd + nginx | **پیشنهاد اول** — کمترین پلن (۱ گیگ رم) کافی است؛ سایت stdlib-only است |
| هاست اشتراکی با Python (cPanel) | ارزان‌تر | باید «Setup Python App» + Passenger داشته باشد؛ منابع محدود؛ برای شروع با حجم کم قابل قبول |

سایت هیچ وابستگی نصب‌شونده‌ای ندارد (`pip` لازم نیست!) — فقط پایتون 3.11+.

## ۱) دامنه

- `.ir` از **nic.ir** (ثبت داخلی، ارزان) یا `.com` از ثبت‌کنندهٔ معتبر.
- رکوردها:
  ```
  A    @      IP-سرور
  A    www    IP-سرور
  ```
- سپس در **پنل → تنظیمات → عمومی** فیلد `site_url` را با دامنه پر کنید
  (مثلاً `bazarche-najafabad.ir`). این برای QR، sitemap و لینک‌های خروجی لازم است.

## ۲) آپلود و اجرا (VPS)

```bash
scp bazarche-najafabad-v119.zip root@IP:/var/www/
ssh root@IP
cd /var/www && unzip bazarche-najafabad-v119.zip -d bazarche
cd bazarche && python3 run.py        # تست: باید بالا بیاید؛ Ctrl+C
```

**systemd** — `/etc/systemd/system/bazarche.service`:
```ini
[Unit]
Description=Bazarche
After=network.target
[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/bazarche
ExecStart=/usr/bin/python3 /var/www/bazarche/run.py
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1
[Install]
WantedBy=multi-user.target
```
```bash
systemctl daemon-reload && systemctl enable --now bazarche
```

## ۳) nginx + SSL (رایگان)

```nginx
server {
    listen 80;
    server_name bazarche-najafabad.ir www.bazarche-najafabad.ir;
    client_max_body_size 10M;
    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    location /assets/ {
        alias /var/www/bazarche/site/assets/;
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }
}
```
```bash
ln -s /etc/nginx/sites-available/bazarche /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
certbot --nginx -d bazarche-najafabad.ir -d www.bazarche-najafabad.ir
```

> ⚠️ هدر `X-Forwarded-Proto` را حتماً بفرستید: v119 فقط وقتی آن را ببیند
> `Strict-Transport-Security` (HSTS) و `upgrade-insecure-requests` فعال می‌شود.

## ۴) چک‌لیست امنیتی استقرار (v119)

- [ ] **کلید پنل را بچرخانید** (پنل ← تنظیمات ← امنیت ← تولید کلید جدید) — کلید داخل زیپ عمومی شده
- [ ] **رمز عبور پنل** بگذارید (تب امنیت)
- [ ] **محدودیت آی‌پی پنل**: آی‌پی‌های ثابت خودتان را در «محدودیت آی‌پی پنل» وارد کنید
- [ ] `ufw allow 22,80,443/tcp && ufw deny 8000` (پورت 8080 از بیرون بسته)
- [ ] پنل ← تنظیمات ← `site_url` = دامنه
- [ ] پشتیبان‌گیری شبانه: `0 3 * * * cp /var/www/bazarche/data/bazarche.db /var/backups/bz-$(date +\%F).db`
- [ ] ناظر سلامت: uptime-kuma یا cron به `https://دامنه/healthz` (۲۰۰ = سالم)
- [ ] `/.well-known/security.txt` را چک کنید (ایمیل تماس در تنظیمات پر شده باشد)

## ۵) راستی‌آزمایی پس از استقرار

```bash
curl -sI https://دامنه/ | grep -iE "strict-transport|cross-origin|content-security"
# انتظار: HSTS + COOP + CORP + CSP با upgrade-insecure-requests
curl -s https://دامنه/healthz        # → ok
curl -s https://دامنه/.well-known/security.txt
curl -s https://دامنه/sitemap.xml | head -5   # URLها باید دامنه باشند نه 127.0.0.1
```

## ۶) مسیر جایگزین: هاست اشتراکی با cPanel

۱. «Setup Python App» → Python 3.11+ → App Root = پوشهٔ پروژه.
۲. فایل `passenger_wsgi.py` — به‌جای WSGI معمول، یک wrapper ساده:
   ```python
   import os, sys
   sys.path.insert(0, os.path.dirname(__file__))
   from run import app  # ← app از run.py در دسترس است
   application = app
   ```
   (اگر `run.py` اپلیکیشن را جدا نمی‌کند، یک `passenger_wsgi.py` بنویسید که
   سرور را در یک رشته راه بیندازد و `application` = `handler` باشد — در
   `run.py` ساختار `App` همین است.)
۳. دایرکتوری `data/` باید قابل‌نوشتن باشد (`chmod 755` + مالک همان کاربر).
۴. به‌جای systemd از «restart app» پنل هاست استفاده کنید.

> برای شروع ساده و مطمئن، **VPS ایرانی با nginx + systemd** (بخش ۲–۳) توصیهٔ
> نهایی است؛ هاست اشتراکیِ پایتون برای مقیاس کوچک جواب می‌دهد ولی با
> Passenger تنظیماتش حساستر است.

## ۷) مقیاس بعدی (اگر ترافیک واقعاً بالا رفت)

- nginx در نقش reverse proxy همین الان کافی است (~۲۴۰rps رندر کامل در سندباکس).
- برای «چند هزار کاربر هم‌زمان»: چند worker (چند نمونهٔ run.py روی پورت‌های
  متفاوت پشت nginx upstream + همان DB مشترک — SQLite WAL چندخواننده را
  تحمل می‌کند؛ نوشتن کم است). مستند: `docs/audit-2026-08-performance.md`.
