# گزارش ممیزی — فاز ۴: سلامت و یکپارچگی (v116-audit)

> 🗄️ **سند آرشیوی** — عکسِ وضعیت در زمان خودش. وضعیت فعلی: `docs/collaboration/CURRENT-STATE.md`.

تاریخ: ۲۰۲۶-۰۸-۲۹ · ابزارها: باتری ۳۰ مجموعهٔ `tools/test_*.py` +
`tools/test_migration.py` (تازه) + `mobile_audit.py` + `contrast_audit.py` +
Playwright (PWA/آفلاین).

## ۱) یافته‌ها و اصلاحات

| # | یافته | شدت | اصلاح |
|---|-------|------|-------|
| H1 | **پشتیبان «کامل» پنل ۱۸ جدول دادهٔ واقعی را نداشت** — orders/order_items (سفارش‌ها!)، stories/story_views، favorites، follows، haggles، notifications، points، redemptions، price_alerts، price_history، flashdeals، toplists، trash، visits، searches، audit. بازیابی از پشتیبان یعنی **از دست رفتن silencioso سفارش‌ها و استوری‌ها** | 🔴 بحرانی | `db.py`: هر ۱۸ جدول به `export_all()` و `_RESTORE_ORDER` اضافه شد (والد قبل از فرزند). راستی‌آزمایی: round-trip واقعی روی کپی DB (پاک‌سازی → import → شمارش‌ها مو به مو برابر). عمداً خارج: sessions/otp/ratelimit (وضعیت امنیتی زودهنگام — بازیابی‌شان خطر است)، `businesses_fts*` (هنگام boot بازسازی می‌شود)، cities (هنگام boot از seed باز می‌گردد). |
| H2 | **ستون‌های SCHEMA بدون مهاجرت** — `businesses.views` در CREATE TABLE هست ولی هیچ ALTER نداشت؛ DB ساخته‌شده قبل از آن ستون هرگز آن را نمی‌گرفت (تست با شبیه‌سازی DB کهنه زنده گرفته شد) | 🔴 بحرانی (خاموش) | `db.py`: تابع `_reconcile_schema()` در init() — خودِ SCHEMA را پارس می‌کند و هر ستون سادهٔ غایب را ALTER ADD می‌کند. دیگر هیچ ستونی جا نمی‌ماند (PK/UNIQUE/NOT NULL-بدون-پیش‌فرض مستثنی — ساختار جدول تازه‌اند). |
| H3 | **نقص قانون ۴۴px در ۳۲ صفحه/دستگاه** — هدف‌های لمس ۲۷–۴۳px: `.btn`→42، `.btn-sm`→40، `.fav-btn`→40، `.bill-toggle`→38، `.city-chip` (دو min-height متضاد در یک قاعده!)، `.brand`→40، breadcrumb→32، story-chip→27، follow/helpful/story→32-34، pager→42، chip.sub→34 و ~۱۰ مورد دیگر | 🟠 زیاد | همه به `var(--tap)`=44px: `mobile-refine.css` (۶ قاعده)، `main.css` (۱۳ قاعده)، `pages.css` (۹ قاعده). نتیجه: `mobile_audit.py` = **صفر ایراد** در ۴ دستگاه × همهٔ صفحات. |
| H4 | flaky در `test_analytics` — بلاک 80.191/16 چنداستانی است (۹۲/۲۰۰ آی‌پی تصادفی非تهران) ولی تست «تهران» قطعی می‌خواست | 🟡 کم (باگ تست) | تست حالا سازگاری visits با خروجی geoip را می‌سنجد؛ ۶ اجرای پشت‌سرهم سبز. |

## ۲) سالم تأییدشده (اجرایی)

- **باتری کامل ۳۰ مجموعه** سبز: all 147/0 · gates 83/0 · actions 55/0 ·
  tickets 42/0 · discovery 36/0 · onboarding 34/0 · admin_extras 43/0 ·
  v3 153/0 · v3_owner 53/0 · chat 99/0 · favorites 27/0 · haggle 61/0 ·
  isolation 30/0 · open 46/0 · open_parity 525 ترکیب/۰ اختلاف · prices 53/0 ·
  remaining 27/0 · section1 27/0 · section4 34/0 · trash 38/0 · v68 19/0 ·
  v69 14/0 · context 28/0 · analytics 56/0 · browser ✓ · appearance 39/0 ·
  abuse 15/0 · security 11/0 · robustness 7/0 · migration 17/0
- **مهاجرت DB قدیمی** (M1): ستون‌های v115 (prov/city/utm)، views، جدول events
  همه برمی‌گردند؛ دادهٔ موجود سالم؛ init() دوم بی‌اثر (idempotent).
- **PWA** (M4 + مرورگر واقعی): sw.js سرو می‌شود، مانیفست installable
  (standalone+icons+start_url)، SW ثبت و فعال می‌شود، **بارگذاری آفلاین** صفحهٔ
  فارسی «اتصال برقرار نیست» را می‌آورد نه خطای مرورگر.
- **کنتراست**: هر دو تم × صفحات = ۰ خطا.
- سرور: ۰ Traceback در کل فاز.

## ۳) نکتهٔ انتشار

`site/sw.js` هنوز `bazarche-v115` است — در انتشار v116 همراه markers `?v116`
بالا می‌رود (تست M4 فعلاً v115 را درست می‌داند و در v116 به‌روز می‌شود).
