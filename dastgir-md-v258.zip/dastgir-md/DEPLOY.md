# 🚀 راهنمای عرضهٔ رسمی روی دامنه و هاست

این سند مرحله‌به‌مرحله توضیح می‌دهد چطور سایت را از حالت محلی (Pydroid) به
یک سایت واقعی روی اینترنت تبدیل کنید.

---

## گام ۰ — پیش از هر چیز: کلید پنل را بررسی کنید ⚠️

در نصب تازه، کلید پنل در اولین اجرا به‌صورت تصادفی ساخته می‌شود و در زیپ نیست؛
ولی اگر کلیدتان را روزی با کسی در میان گذاشته‌اید (یا در تصویر/پیامی لو رفته)،
قبل از آپلود عوضش کنید:

۱. سایت را محلی اجرا کنید (`python3 run.py`)
۲. پنل → **تنظیمات سایت** → زبانهٔ **امنیت** → دکمهٔ **«تولید کلید جدید»**
۳. نشانی جدید را جایی امن یادداشت کنید

---

## گام ۱ — انتخاب هاست

سایت با پایتون استاندارد نوشته شده و به هیچ کتابخانه‌ای نیاز ندارد.
هر هاستی که **پایتون ۳.۱۱ یا جدیدتر** اجرا کند کافی است (همان نسخه‌ای که
Pydroid 3 روی اندروید هم از آن استفاده می‌کند):

| گزینه | مناسب برای | توضیح |
|---|---|---|
| **سرور مجازی ایرانی (VPS)** | ✅ پیشنهاد اول | آروان، پارس‌پک، ایران‌سرور — سرعت بالا برای کاربران داخل ایران |
| هاست اشتراکی با پشتیبانی Python | بودجهٔ کم | باید WSGI/Passenger داشته باشد |
| VPS خارجی | ترافیک بین‌المللی | ممکن است برای کاربر ایرانی کند باشد |

> 💡 برای یک سایت شهری با چند هزار بازدید در ماه، **کمترین پلن VPS
> (۱ گیگ رم) کاملاً کافی است.**

---

## گام ۲ — دامنه

- دامنهٔ `.ir` را از [ای‌ران‌نیک](https://www.nic.ir) بگیرید (ارزان، مخصوص ایران)
- یا `.com` از هر ثبت‌کنندهٔ معتبر
- در پنل دامنه، رکورد **A** را به IP سرورتان وصل کنید:

```
A    @      IP-سرور-شما
A    www    IP-سرور-شما
```

---

## گام ۳ — آپلود و اجرا روی سرور

```bash
# ۱) فایل‌ها را کپی کنید
scp -r bazarche root@YOUR_SERVER_IP:/var/www/

# ۲) وارد سرور شوید
ssh root@YOUR_SERVER_IP
cd /var/www/bazarche

# ۳) تست اولیه
python3 run.py          # باید بدون خطا بالا بیاید؛ با Ctrl+C ببندید
```

### اجرای دائمی با systemd

فایل `/etc/systemd/system/bazarche.service` را بسازید:

```ini
[Unit]
Description=دست گیر
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/bazarche
ExecStart=/usr/bin/python3 /var/www/bazarche/run.py
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
```

سپس:

```bash
systemctl daemon-reload
systemctl enable --now bazarche
systemctl status bazarche      # باید active (running) باشد
```

---

## گام ۴ — Nginx + گواهی SSL رایگان

نصب:

```bash
apt update && apt install -y nginx certbot python3-certbot-nginx
```

فایل `/etc/nginx/sites-available/bazarche`:

```nginx
server {
    listen 80;
    server_name bazarche-najafabad.ir www.bazarche-najafabad.ir;

    client_max_body_size 10M;

    location / {
        proxy_pass         http://127.0.0.1:8080;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
    }

    # دارایی‌های ثابت را مستقیم و با کش طولانی بده
    location /assets/ {
        alias /var/www/bazarche/site/assets/;
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }
}
```

فعال‌سازی و گرفتن SSL:

```bash
ln -s /etc/nginx/sites-available/bazarche /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

# گواهی رایگان Let's Encrypt (تمدید خودکار)
certbot --nginx -d bazarche-najafabad.ir -d www.bazarche-najafabad.ir
```

پس از این، سایت روی `https://bazarche-najafabad.ir` بالا می‌آید و
قابلیت **نصب روی گوشی (PWA)** هم فعال می‌شود.

---

## گام ۵ — امنیت

```bash
# فقط پورت‌های لازم باز باشند
ufw allow 22,80,443/tcp && ufw enable

# پورت ۸۰۰۰ نباید از بیرون در دسترس باشد (فقط Nginx به آن وصل می‌شود)
ufw deny 8000
```

**چک‌لیست:**
- [ ] کلید پنل عوض شده (گام ۰)
- [ ] نشانی پنل را در جای عمومی نگذارید
- [ ] بکاپ‌گیر خودکار نصب شده: `sudo bash tools/install-backup.sh`
- [ ] پایش لحظه‌ای نصب شده: `sudo bash tools/install-monitor.sh`
- [ ] توکن تلگرام ست شده و `--telegram-test` موفق است
- [ ] از پنل → پشتیبان‌گیری، یک «دیتابیس (SQLite)» دانلود و امن نگه دارید

---

## گام ۶ — پشتیبان‌گیری خودکار (امن)

> ⚠️ **هرگز** با `cp` مستقیم از فایل `.db` بکاپ نگیرید: دیتابیس در حالت
> WAL کار می‌کند و تراکنش‌های تازه در فایل `-wal` می‌مانند؛ کپیِ خامِ
> `.db` ممکن است ناقص یا ناهماهنگ باشد. از `tools/backup.py` استفاده کنید
> که با API رسمی پشتیبان‌گیری SQLite یک اسنپ‌شات **سازگار** می‌گیرد — بدون
> توقف سایت.

نصب خودکار (systemd timer یا cron):

```bash
sudo bash /var/www/bazarche/tools/install-backup.sh
```

این اسکریپت هر شب ساعت ۳ بکاپ می‌گیرد و نسخه‌ها را می‌چرخاند
(۱۴ روزانه + ۸ هفتگی + ۱۲ ماهانه). بکاپ‌ها در `/var/backups/bazarche/`
نگه داشته می‌شوند و هر کدام شامل `data/bazarche.db` + عکس‌ها + شناسنامهٔ
سلامت (sha256) است.

بررسی سلامت یک بکاپ:

```bash
python3 /var/www/bazarche/tools/backup.py --verify /var/backups/bazarche/backup-XXXX.zip
```

بازیابی: توقف سرویس → باز کردن زیپ روی پوشهٔ برنامه → بالا آوردن:

```bash
sudo systemctl stop bazarche
sudo unzip -o /var/backups/bazarche/backup-XXXX.zip -d /var/www/bazarche
sudo chown -R www-data:www-data /var/www/bazarche
sudo systemctl start bazarche
```

> برای حفاظت واقعی در برابر خرابی/هک سرور، هر چند روز یک‌بار از پنل
> مدیریت → پشتیبان‌گیری → **«بکاپ کامل»** یا **«دیتابیس (SQLite)»** را
> دانلود و روی کامپیوتر خودتان نگه دارید — یا بکاپ را خودکار به ابر
> بفرستید (بخش بعد).

### بکاپ به ابر (تلگرام / S3) و پایش لحظه‌ای

```bash
# بکاپ به تلگرام (توکن tg_token/tg_chat_id را در پنل → تنظیمات بگذارید)
python3 /var/www/bazarche/tools/backup.py --telegram-test
# بکاپ به S3-سازگار (آروان‌کلاد و…) با متغیرهای BZ_S3_* در /etc/default/bazarche
python3 /var/www/bazarche/tools/backup.py --s3-test

# پایش لحظه‌ای سلامت + هشدار تلگرام (هر ۲ دقیقه)
sudo bash /var/www/bazarche/tools/install-monitor.sh
```

جزئیات کامل در `UPGRADE.md` (بخش‌های ۷ و ۸).

---

## گام ۷ — گوگل مپ (اختیاری)

سایت به‌صورت پیش‌فرض از **OpenStreetMap** استفاده می‌کند که رایگان است و
در ایران بدون مشکل کار می‌کند. اگر گوگل مپ می‌خواهید:

۱. از [Google Cloud Console](https://console.cloud.google.com) یک
   **Maps JavaScript API key** بسازید
۲. در بخش Restrictions، دامنهٔ خود را وارد کنید
۳. در پنل → تنظیمات → زبانهٔ **نقشه** → کلید را بچسبانید

> اگر گوگل به هر دلیلی (تحریم، اتمام اعتبار، کلید نامعتبر) بالا نیاید،
> سایت **خودکار** به OpenStreetMap سوئیچ می‌کند و کاربر چیزی متوجه نمی‌شود.

---

## گام ۸ — بعد از عرضه

- [ ] سایت را در [Google Search Console](https://search.google.com/search-console) ثبت کنید
- [ ] فایل `sitemap.xml` (`https://دامنه/sitemap.xml`) را معرفی کنید
- [ ] پنل → تنظیمات → توضیح سئو را دقیق پر کنید
- [ ] چند کسب‌وکار واقعی اضافه کنید تا صفحه خالی نباشد
- [ ] از بخش «اخبار شهر» برای جذب ترافیک گوگل استفاده کنید

---

## عیب‌یابی سریع

| مشکل | راه‌حل |
|---|---|
| سایت بالا نمی‌آید | `systemctl status bazarche` و `journalctl -u bazarche -n 50` |
| تغییرات ذخیره نمی‌شود | دسترسی نوشتن پوشهٔ `data/`: `chown -R www-data /var/www/bazarche/data` |
| نقشه سفید است | مشکلی نیست؛ اینترنت کاربر برای تایل‌ها لازم است |
| کلید پنل را گم کردم | روی سرور: `cd server && python3 -c "import db; print(db.owner_token())"` |

---

*ساخته‌شده در Arena.ai Agent Mode*
