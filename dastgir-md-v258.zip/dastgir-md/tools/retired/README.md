# آزمون‌های بازنشسته

- `test_onboarding_v156.py` — فرم تک‌صفحه‌ای `/submit` را می‌آزمود که در v208 با ویزارد مرحله‌ای `/register-business` جایگزین شد.
  پوشش معادل: `tools/test_register_web_v208.py` (ماندگاری همهٔ فیلدها، ساعت کاری، تصاویر، مرورگر) و `tools/test_browser.py`.
