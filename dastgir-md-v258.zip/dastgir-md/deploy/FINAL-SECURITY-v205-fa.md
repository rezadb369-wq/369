# گزارش بازبینی نهایی بات‌ها — v205

> 🗄️ **سند آرشیوی** — عکسِ وضعیت در زمان خودش. وضعیت فعلی: `docs/collaboration/CURRENT-STATE.md`.

## مرزهای دسترسی

- دادهٔ مشتری با `customer_id` متصل به platform identity محدود است.
- دادهٔ مالک با `owner_id` و مالکیت هم‌زمان کسب‌وکار محدود است.
- سفارش، نوبت، گفتگو و درخواست موجودی متعلق به حساب دیگر در projection یا mutation قابل دسترسی نیست.
- نقش مالک صرف وجود owner session نیست؛ شمارهٔ مشتری متصل باید با مالک فعال دارای کسب‌وکار منطبق باشد.

## عملیات تغییردهنده

- لغو نوبت/موجودی و حذف علاقه‌مندی حداقل دو مرحله و دارای predicate مالکیت/وضعیت هستند.
- پاسخ کوتاه و عملیات مالک token تصادفی پنج‌دقیقه‌ای و یک‌بارمصرف دارند.
- فقط SHA-256 token در SQLite ذخیره می‌شود؛ bearer خام در callback کوتاه‌عمر است.
- مصرف token، بررسی نقش/مالکیت/وضعیت و mutation اتمیک است.
- گذار پرشی سفارش یا نوبت حتی confirmation تولید نمی‌کند.

## webhook و ضد replay

- URL هر webhook راز مستقل ۳۲ تا ۱۰۰ نویسه‌ای دارد و با `compare_digest` بررسی می‌شود.
- JSON به ۲۶۲۱۴۴ بایت محدود است؛ update_id باید عددی باشد.
- `(platform, update_id)` به‌صورت پایدار و اتمیک claim می‌شود.
- webhook دارای نرخ ۱۸۰ درخواست در دقیقه برای هر client key است.
- منو و callbackهای حساب فقط در private chat اجرا می‌شوند.
- callbackها namespace و regex allow-list و سقف پلتفرم را رعایت می‌کنند.

## اعلان و پلتفرم

- بله و سروش از هستهٔ مشترک استفاده می‌کنند.
- preference پیش از in-app، FCM و messenger fan-out اعمال می‌شود.
- `push=False` فقط FCM را خاموش می‌کند و بات‌های مجاز را خاموش نمی‌کند.
- Rubika در runtime/UI فعال نیست؛ رکوردهای قدیمی مخرب حذف نشده‌اند.

## استقرار و رازها

- tokenهای واقعی فقط در `/etc/dastgir-secrets.env` با `root:root/600` هستند.
- ZIP شامل data، upload، chat-files، env، pyc و cache نیست.
- updater جدید ابتدا backup سازگار SQLite می‌گیرد، staging را می‌سنجد و clean rsync انجام می‌دهد.
- راهنمای کامل Termius: `deploy/FINAL-v205-TERMIUS-fa.md`.

## آزمون‌های نهایی

- امنیت مستقل: 25/25
- منو و همهٔ قابلیت‌ها: 66/66
- Bale core: 26/26
- Bale HTTP: 45/45
- Soroush core: 13/13
- Soroush HTTP: 48/48
- public performance: 12/12
- compile، shell syntax، fresh schema/index، notification metadata، backup exclusions، browser/login، logo و credential policy: PASS
