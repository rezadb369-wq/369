# استقرار نسخهٔ ۲۱۲ روی سایت اصلی (daastgir.ir) — راهنمای Termius

> 🗄️ **سند آرشیوی** — عکسِ وضعیت در زمان خودش. وضعیت فعلی: `docs/collaboration/CURRENT-STATE.md`.

سرور: `130.185.78.237` · مسیر برنامه: `/opt/dastgir` · سرویس: `bazarche` · پورت داخلی: `8080`
نسخهٔ ۲۱۲ شامل همهٔ تغییرات ۲۰۷ تا ۲۱۱ است؛ اگر آن‌ها نصب نشده‌اند، مستقیم همین را نصب کنید.
مهاجرت پایگاه داده خودکار است (`CREATE TABLE IF NOT EXISTS order_receipts` + ستون‌های v211). داده‌ها، آپلودها و فایل‌های گفت‌وگو حفظ می‌شوند و قبل از به‌روزرسانی پشتیبان خودکار در `/var/backups/dastgir` گرفته می‌شود.

---

## گام ۱ — دانلود و صحت‌سنجی ZIP

```bash
cd /root && rm -f dastgir-v212.zip \
 && curl -fL -A 'curl/8.5' -o dastgir-v212.zip https://x0.at/Cl7S.zip \
 && echo '1fe74363249559f6642d499bf992cbf4acde740dac2f12bd481da1b5c2be2917  dastgir-v212.zip' | sha256sum -c - \
 && unzip -t dastgir-v212.zip | tail -2
```

خروجی مورد انتظار: `dastgir-v212.zip: OK` و `No errors detected`. اگر هش نخواند، **ادامه ندهید**.

## گام ۲ — نصب (پشتیبان خودکار + توقف/شروع سرویس + healthz)

```bash
sudo bash /opt/dastgir/deploy/update.sh /root/dastgir-v212.zip
```

خروجی پایانی باید باشد: `نسخه 212 با موفقیت نصب شد.`

> اگر اسکریپت `update.sh` روی سرور قدیمی‌تر است و ارور داد، نسخهٔ داخل همین ZIP را استفاده کنید:
> ```bash
> cd /root && rm -rf /tmp/dg212 && mkdir /tmp/dg212 && unzip -q dastgir-v212.zip -d /tmp/dg212 \
>  && sudo bash /tmp/dg212/dastgir/deploy/update.sh /root/dastgir-v212.zip
> ```

## گام ۳ — بررسی‌های پس از نصب

```bash
cat /opt/dastgir/VERSION.txt
systemctl is-active bazarche
curl -s http://127.0.0.1:8080/healthz; echo
curl -s https://daastgir.ir/sw.js | grep -o "bazarche-v[0-9]*"
curl -s https://daastgir.ir/ | grep -o 'app.js?v[0-9]*'
journalctl -u bazarche -n 30 --no-pager
```

انتظار: `212` · `active` · `ok` · `bazarche-v212` · `app.js?v212` · بدون Traceback در لاگ.

بررسی جدول جدید و ثبت منوی دستورات بات:

```bash
sudo -u www-data python3 - <<'EOF'
import sqlite3;c=sqlite3.connect('/opt/dastgir/data/bazarche.db')
print('order_receipts:',c.execute("select count(*) from sqlite_master where name='order_receipts'").fetchone()[0])
print(c.execute("select action,detail,created from audit where action='bot.commands' order by rowid desc limit 1").fetchall())
EOF
```

`order_receipts: 1` و یک ردیف `bot.commands` مثل `bale=skip,soroush=ok` (در بله `skip` طبیعی است — بخش ۵).

## گام ۴ — تست دستی بات‌ها (۲ دقیقه)

در بله و سروش با حساب متصل:
1. `/start` → دکمهٔ جدید «📍 نزدیک من» باید دیده شود.
2. `/search کافه` → برای هر نتیجه یک کارت (عکس کاور اگر دارد) با «📞 تماس / 🗺 مسیر / 🌐 صفحه».
3. `/near` → دکمهٔ «📍 ارسال موقعیت من» → ارسال موقعیت → کارت‌ها با «… متر از شما».
4. یک سفارش آزمایشی ثبت کنید و از پنل دکان‌دار وضعیت را «تأیید شد» و بعد «آمادهٔ تحویل» کنید → **همان پیامِ** «🧾 رسید سفارش» در بات به‌روز می‌شود (پیام جدید نمی‌آید).

## گام ۵ — (اختیاری) منوی دستورات در بله

`setMyCommands` در مستندات رسمی بله نیست؛ به‌صورت پیش‌فرض تلاش نمی‌شود. اگر می‌خواهید امتحان شود:

```bash
sudo sh -c 'grep -q "^BALE_SET_COMMANDS=" /etc/dastgir-secrets.env || echo "BALE_SET_COMMANDS=1" >> /etc/dastgir-secrets.env'
sudo systemctl restart bazarche && sleep 3 && curl -s http://127.0.0.1:8080/healthz; echo
```

بی‌ضرر است: اگر بله رد کند فقط `bale=skip` لاگ می‌شود. (هیچ توکنی را در چت یا خروجی چاپ نکنید.)

## بازگشت (Rollback) در صورت مشکل

```bash
ls -t /var/backups/dastgir | head -3          # آخرین پشتیبان قبل از نصب
sudo bash /opt/dastgir/deploy/update.sh /root/dastgir-v211.zip   # یا هر ZIP قبلیِ موجود
```

پایگاه داده با نسخهٔ قبلی سازگار می‌ماند (فقط جدول/ستون اضافه شده، چیزی حذف نشده).

## اگر کش مرورگر قدیمی ماند

سرویس‌ورکر با نام کش `bazarche-v212` خودش کش قبلی را دور می‌ریزد؛ در بدترین حالت یک بار صفحه را با Ctrl+F5 باز کنید.
