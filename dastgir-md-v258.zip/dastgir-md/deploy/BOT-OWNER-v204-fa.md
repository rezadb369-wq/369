# پنل مالک در بات‌ها — v204

> 🗄️ **سند آرشیوی** — عکسِ وضعیت در زمان خودش. وضعیت فعلی: `docs/collaboration/CURRENT-STATE.md`.

## امکانات

`/owner` خلاصهٔ روز و مسیرهای سفارش، نوبت امروز، پیام مشتری، درخواست موجودی و فراخوان را نشان می‌دهد. دسترسی فقط با زنجیرهٔ معتبر حساب پیام‌رسان→مشتری→شمارهٔ مالک فعال→کسب‌وکار انجام می‌شود.

## عملیات تأییدی

تغییر وضعیت سفارش و نوبت، موجودشدن و فراخوان ابتدا confirmation تصادفی پنج‌دقیقه‌ای می‌سازند. token به owner متصل، یک‌بارمصرف و خارج از backup است. مصرف token، مالکیت و گذار وضعیت در `BEGIN IMMEDIATE` دوباره بررسی می‌شود.

گذار سفارش: `new→confirmed→ready→done`؛ گذار نوبت: `new→confirmed→done`. اطلاعات تلفن، نشانی/یادداشت سفارش، note درخواست موجودی و مسیر داخلی فایل وارد بات نمی‌شود.

فراخوان بات فقط متن استاندارد دارد؛ entitlement و سقف سه فراخوان در ساعت رعایت می‌شود. متن سفارشی از `/my/broadcast` سایت ارسال می‌شود.

## خلاصهٔ خودکار ۹ صبح

پس از استقرار پروژه در `/opt/dastgir`:

```bash
sudo APP_DIR=/opt/dastgir bash /opt/dastgir/tools/install-owner-summary.sh
systemctl list-timers dastgir-owner-summary.timer --no-pager
sudo systemctl start dastgir-owner-summary.service
journalctl -u dastgir-owner-summary.service -n 50 --no-pager
```

Timer ساعت `09:00 Asia/Tehran` اجرا می‌شود و `Persistent=true` دارد. جدول `owner_daily_summaries` از ارسال تکراری در retry همان روز جلوگیری می‌کند. نوع اعلان `summary` تنظیم مستقل دارد و `push=False` فقط FCM را خاموش می‌کند؛ بات‌های متصل فعال می‌مانند.
