# استقرار نسخهٔ ۲۱۷ («دستیار هوشمند دست گیر») روی daastgir.ir — راهنمای Termius

> 🗄️ **سند آرشیوی** — عکسِ وضعیت در زمان خودش. وضعیت فعلی: `docs/collaboration/CURRENT-STATE.md`.

سرور: `130.185.78.237` · مسیر برنامه: `/opt/dastgir` · سرویس: `bazarche` · پورت داخلی: `8080`
نسخهٔ ۲۱۳ شامل همهٔ تغییرات ۲۰۷ تا ۲۱۲ است؛ اگر آن‌ها نصب نشده‌اند، مستقیم همین را نصب کنید.
مهاجرت پایگاه داده خودکار است (`ai_usage` و `ai_intents` با `CREATE TABLE IF NOT EXISTS`). قبل از به‌روزرسانی پشتیبان خودکار در `/var/backups/dastgir` گرفته می‌شود.

---

## گام ۰ — کلید مدل (یک بار، قبل از نصب)

> کلیدی که در گفت‌وگو ارسال شد، در همان پنل AvalAI (chat.avalai.ir/platform → API Keys) **یک بار Rotate/Regenerate** کنید و کلید تازه را فقط در فایل زیر بگذارید. همین.

فایل `/etc/dastgir-secrets.env` را باز کنید (`sudo nano /etc/dastgir-secrets.env`) و این سه خط را اضافه کنید (مقدار کلید را خودتان جای `...` بگذارید؛ بدون فاصله و بدون کوتیشن):

```
AI_BASE_URL=https://api.avalai.ir/v1
AI_API_KEY=...
AI_MODEL=gemini-2.5-flash-lite
```

اختیاری‌ها (فعلاً لازم نیست):

```
AI_MODEL_SMART=            # مدل قوی‌تر برای موارد سخت؛ خالی = همان مدل اصلی
AI_TIMEOUT=12              # ثانیه
AI_FALLBACK_BASE_URL=      # سرویس‌دهندهٔ دوم در صورت خطای اولی
AI_FALLBACK_API_KEY=
AI_FALLBACK_MODEL=
```

مجوز فایل را محکم کنید و مطمئن شوید سرویس آن را می‌خواند:

```bash
sudo chmod 600 /etc/dastgir-secrets.env && sudo chown root:root /etc/dastgir-secrets.env
grep -c '^AI_' /etc/dastgir-secrets.env        # انتظار: 3 (یا بیشتر)
grep -n 'EnvironmentFile' /etc/systemd/system/bazarche.service
```

تنظیمات پیشنهادی همان کلید در پنل AvalAI: مدل مجاز فقط `gemini-2.5-flash-lite`، محدودیت IP به `130.185.78.237`، بودجهٔ ماهانه ۵–۱۰ واحد، guardrail روشن.

## گام ۱ — دانلود و صحت‌سنجی ZIP

```bash
cd /root && rm -f dastgir-v217.zip \
 && curl -fL -A 'curl/8.5' -o dastgir-v217.zip https://x0.at/mrJF.zip \
 && echo 'bba2e0c6dece1955603e0583382b518435633291c393c1cca5ea6a919f0fd507  dastgir-v217.zip' | sha256sum -c - \
 && unzip -t dastgir-v217.zip | tail -2
```

خروجی مورد انتظار: `dastgir-v217.zip: OK` و `No errors detected`. اگر هش نخواند، **ادامه ندهید**.

## گام ۲ — نصب

```bash
sudo bash /opt/dastgir/deploy/update.sh /root/dastgir-v217.zip
```

خروجی پایانی باید باشد: `نسخه 215 با موفقیت نصب شد.`

## گام ۳ — بررسی‌های پس از نصب

```bash
cat /opt/dastgir/VERSION.txt
systemctl is-active bazarche
curl -s http://127.0.0.1:8080/healthz; echo
curl -s https://daastgir.ir/sw.js | grep -o "bazarche-v[0-9]*"
curl -s https://daastgir.ir/ | grep -o 'assist.js?v[0-9]*\|app.js?v[0-9]*'
curl -s https://daastgir.ir/api/assistant/status; echo
journalctl -u bazarche -n 30 --no-pager | grep -v 'AI_API_KEY'
```

انتظار: `217` · `active` · `ok` · `bazarche-v217` · `assist.js?v217` و `app.js?v217` · JSON با `"enabled": true, "quota": 5` · بدون Traceback.

بررسی این‌که مدل واقعاً وصل است (پاسخ باید `"source": "llm"` بدهد؛ این یک پیام از سهمیهٔ IP سرور مصرف می‌کند):

```bash
curl -s -X POST http://127.0.0.1:8080/api/assistant/chat -H 'Content-Type: application/json' \
  -d '{"text":"یه جایی می‌خوام که شب‌ها هم دارو بفروشه"}'; echo
```

اگر `"source": "rule-fallback"` آمد: در پنل `https://daastgir.ir/panel/assistant` بخش «آخرین خطای مدل» را ببینید (`http-401` = کلید غلط، `http-403` = IP/مدل مجاز نیست، `http-429` = بودجه، `TimeoutError` = شبکه).

## گام ۴ — تست دستی (۲ دقیقه)

1. سایت: بعد از چند ثانیه دکمهٔ «✨ دستیار هوشمند» کنار «پشتیبانی» ظاهر می‌شود → چیپ «نزدیک من» → پاسخ با دکمه‌های داخلی. سپس بنویسید «یک شعر بگو» → باید مؤدبانه رد کند.
2. پنل: `/panel/assistant` شمارنده‌ها را نشان می‌دهد؛ سهمیه‌ها همان‌جا قابل تغییرند.
3. بله/سروش: در چت بات بنویسید «داروخانه» → کارت/لینک؛ «چطور مغازه‌ام را ثبت کنم؟» → دکمهٔ «➕ ثبت همین‌جا در بات». دستورهای منو (`/orders` …) مثل قبل کار می‌کنند.

## بازگشت (Rollback)

```bash
ls -t /var/backups/dastgir | head -3
sudo bash /opt/dastgir/deploy/update.sh /root/dastgir-v212.zip
```

برای خاموش‌کردن فقط دستیار (بدون rollback): `/panel/assistant` → کلید «دستیار هوشمند فعال باشد» را خاموش کنید.
