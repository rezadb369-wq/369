# راهنمای سخت‌سازی SSH (v286 — ممیزی امنیتی)

چرا: گزارش بات مدیر در ۲۴ ساعت **۱۱٬۴۸۲ ورود ناموفق SSH** نشان داد — یعنی
دست‌کم ~۸ تلاش در دقیقه از بات‌های اینترنتی که رمز را حدس می‌زنند. این
«بارش پس‌زمینهٔ اینترنت» برای هر سرور عمومی طبیعی است، اما سه لایهٔ زیر
خطر را عملاً صفر می‌کنند. `install.sh` از v286 لایهٔ ۱ (fail2ban) را خودش
نصب می‌کند؛ لایه‌های ۲ و ۳ را یک‌بار دستی انجام دهید (جمعاً ~۱۵ دقیقه).

> ⚠️ قانون طلایی ضدِ قفل‌شدن: تا وقتی از یک ترمینالِ بازِ دیگر مطمئن نشده‌اید
> ورودِ جدید کار می‌کند، ترمینالِ فعلی را نبندید و sshd را restart نکنید.

---

## لایهٔ ۱ — fail2ban (بنِ خودکار IP متجاوز)

```bash
sudo apt-get install -y fail2ban
sudo systemctl enable --now fail2ban
sudo fail2ban-client status sshd
```

تنظیم قوی‌تر (اختیاری) — فایل `/etc/fail2ban/jail.d/sshd.local`:

```ini
[sshd]
enabled  = true
maxretry = 3
findtime = 10m
bantime  = 24h
```

سپس `sudo systemctl restart fail2ban`.
IP خودتان را هرگز بن نکنید — در صورت نیاز:
`sudo fail2ban-client set sshd unbanip <IP>`

## لایهٔ ۲ — ورود فقط با کلید (رمز را کلاً ببندید)

۱. روی کامپیوتر/گوشی خودتان کلید بسازید (اگر ندارید):

```bash
ssh-keygen -t ed25519
ssh-copy-id root@IP_SERVER     # یا هر کاربرِ مدیر
```

۲. **همین حالا با کلید وارد شوید و مطمئن شوید کار می‌کند** (بدون پرسیدن رمز).

۳. فقط وقتی ورود با کلید تأیید شد، در سرور:

```bash
sudo sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
sudo sshd -t && sudo systemctl restart ssh
```

(`sudo sshd -t` اول تنظیم را اعتبارسنجی می‌کند — اگر خطا داد restart نکنید.)

۴. یک ترمینالِ بازِ دیگر نگه دارید و از پنجرهٔ تازه تست ورود کنید.

## لایهٔ ۳ (اختیاری) — جابه‌جایی پورت SSH

بیشترِ بات‌ها فقط پورت ۲۲ را می‌کوبند؛ پورتِ دیگر نویز را ~۹۹٪ کم می‌کند:

```bash
sudo sed -i 's/^#\?Port .*/Port 2244/' /etc/ssh/sshd_config   # عدد دلخواه
sudo ufw allow 2244/tcp && sudo sshd -t && sudo systemctl restart ssh
# بعد از تأییدِ ورود روی پورت تازه، پورت قدیم را ببندید:
sudo ufw delete allow 22/tcp && sudo ufw delete allow OpenSSH
```

---

## راستی‌آزمایی

```bash
sudo journalctl -u ssh --since "24 hours ago" | grep -c Failed   # باید برود به ~۰ (پس از لایهٔ ۲/۳)
sudo fail2ban-client status sshd                                   # تعداد بن‌های فعال
```

در گزارشِ «🖥 سیستم» ربات مدیر، عدد «ورود ناموفق SSH» پس از این لایه‌ها
باید ظرف ۲۴ ساعت به صفرِ عملی برسد؛ از v286 خودِ گزارش وقتی عدد ≥۵۰۰ باشد
هشدار «⚠️ سنگین» هم نشان می‌دهد.

## یادداشت‌ها

- این موارد مربوط به SSHِ سیستم‌عامل است، نه سایت — اپلیکیشنِ «دست گیر»
  لایه‌های خودش را دارد (سپر ضدتهدید، ضداسپام v275–v279، کلید پنل + رمز،
  allowlist آی‌پی پنل در /panel/security).
- اگر از Termux/گوشی به سرور وصل می‌شوید، همان کلید ed25519 را در
  `~/.ssh/` گوشی هم بگذارید.
- بکاپ‌گیری offsite (cron موجود) از SSH همین سرور استفاده می‌کند — اگر
  لایهٔ ۲/۳ را اعمال کردید، کلید و پورت جدید را در اسکریپت بکاپِ مبدأ هم
  به‌روز کنید.
