# -*- coding: utf-8 -*-
"""Shared, account-aware bot menu for Bale and Soroush Plus."""
import re
import math
import db
import notifmeta

SITE = "https://daastgir.ir"
CALLBACK_PREFIX = "dg198:"
PLATFORM_LABEL = {"bale": "بله", "soroush": "سروش‌پلاس"}


def _buttons(linked, owner=False):
    rows = []
    if linked:
        rows.append([{"text": "📦 سفارش‌های من", "callback_data": CALLBACK_PREFIX + "orders"},
                     {"text": "📅 نوبت‌های من", "callback_data": CALLBACK_PREFIX + "bookings"}])
        rows.append([{"text": "🔔 اعلان‌ها", "callback_data": CALLBACK_PREFIX + "notifications"},
                     {"text": "📌 موجودشدن‌ها", "callback_data": CALLBACK_PREFIX + "stock"}])
        rows.append([{"text": "❤️ علاقه‌مندی‌ها", "callback_data": CALLBACK_PREFIX + "favorites"},
                     {"text": "🔍 جست‌وجو", "callback_data": CALLBACK_PREFIX + "search"}])
        rows.append([{"text": "💬 پیام‌های من", "callback_data": CALLBACK_PREFIX + "messages"},
                     {"text": "👤 حساب من", "callback_data": CALLBACK_PREFIX + "account"}])
        if owner:
            rows.append([{"text":"🏪 پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}])
    else:
        rows.append([{"text": "🔐 ورود یا ثبت‌نام", "url": SITE + "/login"}])
    rows.append([{"text": "❓ راهنما", "callback_data": CALLBACK_PREFIX + "help"},
                 {"text": "🌐 دست گیر", "url": SITE}])
    return {"inline_keyboard": rows}


def _back():
    return {"inline_keyboard": [[{"text": "🏠 منوی اصلی",
                                  "callback_data": CALLBACK_PREFIX + "menu"}],
                                [{"text": "🌐 مشاهده در دست گیر", "url": SITE + "/me"}]]}


def _account(platform, platform_user_id):
    acc = db.messenger_account_by_platform(platform, platform_user_id)
    if not acc or acc.get("customer_status") == "blocked":
        return None, None
    customer = db.customer_by_id(acc["customer_id"])
    return acc, customer


def _owner_account(platform,platform_user_id):
    _,customer=_account(platform,platform_user_id)
    if not customer:return None
    owner=db.owner_by_phone(customer.get("phone") or "",create=False)
    return owner if owner and owner.get("status")!="blocked" and db.owner_business_count(owner["id"]) else None


def _masked_phone(value):
    phone = db.norm_phone(value or "")
    return phone[:4] + "••••" + phone[-3:] if len(phone) == 11 else "ثبت نشده"


def send_menu(platform, platform_user_id, chat_id, send):
    acc, customer = _account(platform, platform_user_id)
    label = PLATFORM_LABEL.get(platform, "پیام‌رسان")
    if customer:
        name = (customer.get("name") or "کاربر دست گیر").strip()
        text = (f"سلام {name} 👋\n\nحساب {label} شما با موفقیت به دست گیر متصل است. "
                "از منوی امن زیر استفاده کنید.")
        return send(chat_id, text, _buttons(True,bool(_owner_account(platform,platform_user_id))))
    handoff = (" اگر با دکمهٔ سایت وارد این گفت‌وگو شده‌اید، کلید ورود از قبل "
               "کپی شده است؛ همین‌جا Paste و ارسالش کنید.") if platform == "soroush" else ""
    text = (f"به بات رسمی دست گیر در {label} خوش آمدید 👋\n\n"
            "برای مشاهدهٔ اطلاعات شخصی، ابتدا از سایت رسمی وارد یا ثبت‌نام شوید."
            + handoff + " بات هیچ‌گاه رمز، کد بانکی یا اطلاعات کارت درخواست نمی‌کند.")
    return send(chat_id, text, _buttons(False))


def send_account(platform, platform_user_id, chat_id, send):
    acc, customer = _account(platform, platform_user_id)
    if not customer:
        return send(chat_id, "این حساب پیام‌رسان هنوز به دست گیر متصل نیست.", _buttons(False))
    owner = db.owner_by_phone(customer.get("phone") or "", create=False)
    n_biz = db.owner_business_count(owner["id"]) if owner and owner.get("status") != "blocked" else 0
    label = PLATFORM_LABEL.get(platform, "پیام‌رسان")
    name = (customer.get("name") or "ثبت نشده").strip()
    text = ("👤 حساب من\n\n"
            f"نام: {name}\n"
            f"شماره: {_masked_phone(customer.get('phone'))}\n"
            f"پیام‌رسان متصل: {label}\n"
            f"کسب‌وکارهای تحت مدیریت: {n_biz}\n"
            "وضعیت حساب: فعال ✅")
    return send(chat_id, text, _back())


def _fa_int(value):
    return str(int(value or 0)).translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))


def _short(value, limit=64):
    return re.sub(r"[\r\n\t]+", " ", str(value or "")).strip()[:limit]


def send_orders(platform, platform_user_id, chat_id, send):
    _, customer = _account(platform, platform_user_id)
    if not customer:
        return send(chat_id, "برای مشاهدهٔ سفارش‌ها ابتدا حساب خود را متصل کنید.", _buttons(False))
    rows = db.customer_order_summaries(customer["id"], 5)
    if not rows:
        return send(chat_id, "📦 سفارش‌های من\n\nهنوز سفارشی ثبت نکرده‌اید.", _back())
    prices = db.get_settings().get("prices_enabled") == "1"
    lines = ["📦 آخرین سفارش‌های من", ""]
    buttons = []
    for row in rows:
        total = f" · {_fa_int(row['total'])} تومان" if prices else ""
        lines.append(f"#{_fa_int(row['id'])} · {_short(row['bizname'])}\n{row['status_label']}{total}")
        buttons.append([{"text": f"#{_fa_int(row['id'])} · {_short(row['bizname'], 36)}",
                         "callback_data": CALLBACK_PREFIX + f"order:{row['id']}"}])
    buttons.append([{"text": "📋 همهٔ سفارش‌ها در سایت", "url": SITE + "/me/orders"}])
    buttons.append([{"text": "🏠 منوی اصلی", "callback_data": CALLBACK_PREFIX + "menu"}])
    return send(chat_id, "\n\n".join(lines), {"inline_keyboard": buttons})


def send_order(platform, platform_user_id, chat_id, order_id, send):
    _, customer = _account(platform, platform_user_id)
    if not customer:
        return send(chat_id, "برای مشاهدهٔ سفارش ابتدا حساب خود را متصل کنید.", _buttons(False))
    row = db.customer_order_detail(customer["id"], order_id)
    if not row:
        return send(chat_id, "این سفارش پیدا نشد یا متعلق به حساب شما نیست.", _back())
    prices = db.get_settings().get("prices_enabled") == "1"
    items = []
    for item in row["items"][:20]:
        price = f" · {_fa_int(item['price'])} تومان" if prices else ""
        items.append(f"• {_short(item['title'], 80)} × {_fa_int(item['qty'])}{price}")
    if len(row["items"]) > 20:
        items.append("• ادامهٔ اقلام در سایت…")
    total = f"\nمجموع: {_fa_int(row['total'])} تومان" if prices else ""
    text = (f"📦 سفارش #{_fa_int(row['id'])}\n\n"
            f"کسب‌وکار: {_short(row['bizname'], 100)}\n"
            f"وضعیت: {row['status_label']}\n"
            f"زمان ثبت: {_short(row['created'], 19)}{total}\n\n"
            "اقلام:\n" + ("\n".join(items) if items else "بدون قلم ثبت‌شده"))
    markup = {"inline_keyboard": [
        [{"text": "🌐 مشاهدهٔ کامل سفارش", "url": SITE + f"/me/order/{row['id']}"}],
        [{"text": "↩️ بازگشت به سفارش‌ها", "callback_data": CALLBACK_PREFIX + "orders"}],
        [{"text": "🏠 منوی اصلی", "callback_data": CALLBACK_PREFIX + "menu"}],
    ]}
    return send(chat_id, text[:4096], markup)


def send_bookings(platform, platform_user_id, chat_id, send):
    _, customer = _account(platform, platform_user_id)
    if not customer:
        return send(chat_id, "برای مشاهدهٔ نوبت‌ها ابتدا حساب خود را متصل کنید.", _buttons(False))
    rows = db.customer_booking_summaries(customer["id"], 5)
    if not rows:
        return send(chat_id, "📅 نوبت‌های من\n\nهنوز نوبت متصل به حساب شما ثبت نشده است.", _back())
    lines=["📅 آخرین نوبت‌های من",""];buttons=[]
    for row in rows:
        lines.append(f"#{_fa_int(row['id'])} · {_short(row['bizname'])}\n{_short(row['date'],20)} · {_short(row['time'],12)} · {row['status_label']}")
        buttons.append([{"text":f"#{_fa_int(row['id'])} · {_short(row['bizname'],30)}",
                         "callback_data":CALLBACK_PREFIX+f"booking:{row['id']}"}])
    buttons.append([{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}])
    return send(chat_id,"\n\n".join(lines),{"inline_keyboard":buttons})


def send_booking(platform, platform_user_id, chat_id, booking_id, send):
    _, customer = _account(platform, platform_user_id)
    if not customer:
        return send(chat_id,"برای مشاهدهٔ نوبت ابتدا حساب خود را متصل کنید.",_buttons(False))
    row=db.customer_booking_detail(customer["id"],booking_id)
    if not row:
        return send(chat_id,"این نوبت پیدا نشد یا متعلق به حساب شما نیست.",_back())
    text=(f"📅 نوبت #{_fa_int(row['id'])}\n\nکسب‌وکار: {_short(row['bizname'],100)}\n"
          f"تاریخ: {_short(row['date'],20)}\nساعت: {_short(row['time'],12)}\n"
          f"وضعیت: {row['status_label']}")
    buttons=[[{"text":"🌐 مشاهدهٔ کسب‌وکار","url":SITE+f"/b/{row['bizslug']}"}]]
    if row["status"] in ("new","confirmed"):
        buttons.append([{"text":"لغو نوبت","callback_data":CALLBACK_PREFIX+f"booking_cancel:{row['id']}"}])
    buttons.extend([[{"text":"↩️ بازگشت به نوبت‌ها","callback_data":CALLBACK_PREFIX+"bookings"}],
                    [{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]])
    return send(chat_id,text,{"inline_keyboard":buttons})


def confirm_booking_cancel(platform, platform_user_id, chat_id, booking_id, send):
    _,customer=_account(platform,platform_user_id)
    if not customer or not db.customer_booking_detail(customer["id"],booking_id):
        return send(chat_id,"این نوبت پیدا نشد یا متعلق به حساب شما نیست.",_back())
    markup={"inline_keyboard":[
        [{"text":"✅ بله، نوبت لغو شود","callback_data":CALLBACK_PREFIX+f"booking_cancel_yes:{booking_id}"}],
        [{"text":"↩️ خیر، بازگشت","callback_data":CALLBACK_PREFIX+f"booking:{booking_id}"}]]}
    return send(chat_id,"آیا مطمئن هستید که می‌خواهید این نوبت را لغو کنید؟",markup)


def cancel_booking(platform, platform_user_id, chat_id, booking_id, send):
    _,customer=_account(platform,platform_user_id)
    if not customer:
        return send(chat_id,"حساب متصل پیدا نشد.",_buttons(False))
    result=db.customer_booking_cancel(customer["id"],booking_id)
    if result=="cancelled":
        return send(chat_id,"نوبت با موفقیت لغو شد و به کسب‌وکار اطلاع داده شد.",
                    {"inline_keyboard":[[{"text":"📅 نوبت‌های من","callback_data":CALLBACK_PREFIX+"bookings"}],
                                        [{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})
    if result=="final":
        return send(chat_id,"این نوبت قبلاً نهایی یا لغو شده و قابل لغو نیست.",_back())
    return send(chat_id,"این نوبت پیدا نشد یا متعلق به حساب شما نیست.",_back())


def send_notifications(platform,platform_user_id,chat_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:
        return send(chat_id,"برای مدیریت اعلان‌ها ابتدا حساب خود را متصل کنید.",_buttons(False))
    kinds=notifmeta.kinds("cust");state=db.pref_state("cust",customer["id"],kinds)
    lines=["🔔 تنظیم اعلان‌ها","","با لمس هر گزینه، همان دسته روشن یا خاموش می‌شود:"]
    buttons=[]
    for kind in kinds:
        _,label,_=notifmeta.meta("cust",kind);on=state[kind]
        lines.append(f"{'✅' if on else '🔕'} {label}")
        buttons.append([{"text":f"{'✅' if on else '🔕'} {label}","callback_data":CALLBACK_PREFIX+f"notif:{kind}"}])
    buttons.append([{"text":"⚙️ تنظیمات کامل در سایت","url":SITE+"/me/notif-settings"}])
    buttons.append([{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}])
    return send(chat_id,"\n".join(lines),{"inline_keyboard":buttons})


def toggle_notification(platform,platform_user_id,chat_id,kind,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:
        return send(chat_id,"حساب متصل پیدا نشد.",_buttons(False))
    if kind not in notifmeta.kinds("cust"):
        return send(chat_id,"دستهٔ اعلان نامعتبر است.",_back())
    new_state=not db.kind_enabled("cust",customer["id"],kind)
    if not db.set_customer_pref(customer["id"],kind,new_state):
        return send(chat_id,"ذخیرهٔ تنظیم اعلان انجام نشد.",_back())
    return send_notifications(platform,platform_user_id,chat_id,send)


_STOCK_LABELS={"open":"در انتظار موجودشدن","fulfilled":"موجود شد","dismissed":"لغو شده"}


def send_stock(platform,platform_user_id,chat_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:
        return send(chat_id,"برای مشاهدهٔ پیگیری موجودی ابتدا حساب خود را متصل کنید.",_buttons(False))
    rows=db.customer_stock_requests(customer["id"],10)
    if not rows:
        return send(chat_id,"📌 پیگیری موجودی\n\nهنوز درخواست «موجود شد خبرم کن» ندارید.",_back())
    lines=["📌 پیگیری‌های موجودی من",""];buttons=[]
    for row in rows:
        title=_short(row.get("item_title") or "درخواست عمومی",60)
        lines.append(f"#{_fa_int(row['id'])} · {title}\n{_short(row['biz_name'],50)} · {_STOCK_LABELS.get(row['status'],row['status'])} · {_fa_int(row['qty'])} عدد")
        if row["status"]=="open":
            buttons.append([{"text":f"لغو #{_fa_int(row['id'])} · {_short(title,28)}","callback_data":CALLBACK_PREFIX+f"stock_cancel:{row['id']}"}])
        link=(SITE+f"/item/{row['item_id']}") if row.get("item_id") else (SITE+f"/b/{row['biz_slug']}")
        buttons.append([{"text":f"مشاهده #{_fa_int(row['id'])} در سایت","url":link}])
    buttons.append([{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}])
    return send(chat_id,"\n\n".join(lines)[:4096],{"inline_keyboard":buttons})


def confirm_stock_cancel(platform,platform_user_id,chat_id,request_id,send):
    _,customer=_account(platform,platform_user_id)
    rows=db.customer_stock_requests(customer["id"],20) if customer else []
    row=next((x for x in rows if int(x["id"])==int(request_id) and x["status"]=="open"),None)
    if not row:
        return send(chat_id,"این درخواست پیدا نشد، نهایی شده یا متعلق به حساب شما نیست.",_back())
    markup={"inline_keyboard":[
        [{"text":"✅ بله، پیگیری لغو شود","callback_data":CALLBACK_PREFIX+f"stock_cancel_yes:{request_id}"}],
        [{"text":"↩️ خیر، بازگشت","callback_data":CALLBACK_PREFIX+"stock"}]]}
    return send(chat_id,"آیا پیگیری موجودشدن این مورد لغو شود؟",markup)


def cancel_stock(platform,platform_user_id,chat_id,request_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:return send(chat_id,"حساب متصل پیدا نشد.",_buttons(False))
    result=db.customer_stock_request_cancel(customer["id"],request_id)
    if result=="cancelled":return send(chat_id,"پیگیری موجودشدن لغو شد.",{"inline_keyboard":[[{"text":"📌 موجودشدن‌ها","callback_data":CALLBACK_PREFIX+"stock"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})
    return send(chat_id,"این درخواست پیدا نشد، نهایی شده یا متعلق به حساب شما نیست.",_back())


def _map_url(row):
    try:
        lat,lng=float(row.get("lat")),float(row.get("lng"))
        if not (math.isfinite(lat) and math.isfinite(lng) and -90<=lat<=90 and -180<=lng<=180):return ""
        return f"https://www.google.com/maps/dir/?api=1&destination={lat:.6f},{lng:.6f}"
    except (TypeError,ValueError):return ""


def send_search_help(chat_id,send):
    return send(chat_id,"🔍 جست‌وجوی کسب‌وکار\n\nنام، خدمت، کالا یا محله را بعد از /search بنویسید.\nمثال:\n/search تعمیر موبایل",{"inline_keyboard":[[{"text":"🌐 جست‌وجوی پیشرفته در سایت","url":SITE+"/businesses"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


def send_search(platform,platform_user_id,chat_id,query,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:return send(chat_id,"برای جست‌وجو ابتدا حساب خود را متصل کنید.",_buttons(False))
    query=_short(query,60)
    if len(db.normalize_fa(query))<2:return send_search_help(chat_id,send)
    rows=db.search_business_summaries(query,5)
    if not rows:return send(chat_id,f"برای «{query}» نتیجه‌ای پیدا نشد.",{"inline_keyboard":[[{"text":"🔍 جست‌وجوی دیگر","callback_data":CALLBACK_PREFIX+"search"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})
    lines=[f"🔍 نتیجهٔ جست‌وجوی «{query}»",""];buttons=[]
    for row in rows:
        verified=" · تأییدشده ✅" if row.get("verified") else ""
        address=f"\n{_short(row.get('address'),90)}" if row.get("address") else ""
        lines.append(f"• {_short(row['name'],80)}{verified}{address}")
        actions=[{"text":f"مشاهدهٔ {_short(row['name'],24)}","url":SITE+f"/b/{row['slug']}"}]
        map_url=_map_url(row)
        if map_url:actions.append({"text":"مسیر","url":map_url})
        buttons.append(actions)
        if not db.fav_state(customer["id"],row["id"]):
            buttons.append([{"text":f"❤️ افزودن {_short(row['name'],22)}","callback_data":CALLBACK_PREFIX+f"fav_add:{row['id']}"}])
    buttons.append([{"text":"🔍 جست‌وجوی دیگر","callback_data":CALLBACK_PREFIX+"search"}])
    buttons.append([{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}])
    return send(chat_id,"\n\n".join(lines)[:4096],{"inline_keyboard":buttons})


def send_favorites(platform,platform_user_id,chat_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:return send(chat_id,"برای مشاهدهٔ علاقه‌مندی‌ها ابتدا حساب خود را متصل کنید.",_buttons(False))
    rows=db.favorite_summaries(customer["id"],5)
    if not rows:return send(chat_id,"❤️ علاقه‌مندی‌های من\n\nهنوز کسب‌وکاری ذخیره نکرده‌اید.",{"inline_keyboard":[[{"text":"🔍 جست‌وجو","callback_data":CALLBACK_PREFIX+"search"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})
    lines=["❤️ علاقه‌مندی‌های من",""];buttons=[]
    for row in rows:
        address=f" — {_short(row.get('address'),60)}" if row.get("address") else ""
        lines.append(f"• {_short(row['name'],80)}{address}")
        actions=[{"text":f"مشاهدهٔ {_short(row['name'],24)}","url":SITE+f"/b/{row['slug']}"}]
        map_url=_map_url(row)
        if map_url:actions.append({"text":"مسیر","url":map_url})
        buttons.append(actions)
        buttons.append([{"text":f"حذف {_short(row['name'],26)}","callback_data":CALLBACK_PREFIX+f"fav_remove:{row['id']}"}])
    buttons.append([{"text":"📋 همه در سایت","url":SITE+"/me/favorites"}])
    buttons.append([{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}])
    return send(chat_id,"\n".join(lines),{"inline_keyboard":buttons})


def add_favorite(platform,platform_user_id,chat_id,biz_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:return send(chat_id,"حساب متصل پیدا نشد.",_buttons(False))
    if not db.favorite_add(customer["id"],biz_id):return send(chat_id,"کسب‌وکار منتشرشده پیدا نشد.",_back())
    return send(chat_id,"کسب‌وکار به علاقه‌مندی‌های شما اضافه شد.",{"inline_keyboard":[[{"text":"❤️ علاقه‌مندی‌ها","callback_data":CALLBACK_PREFIX+"favorites"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


def confirm_favorite_remove(platform,platform_user_id,chat_id,biz_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer or not db.fav_state(customer["id"],biz_id):return send(chat_id,"این علاقه‌مندی پیدا نشد یا متعلق به حساب شما نیست.",_back())
    return send(chat_id,"این کسب‌وکار از علاقه‌مندی‌ها حذف شود؟",{"inline_keyboard":[[{"text":"✅ بله، حذف شود","callback_data":CALLBACK_PREFIX+f"fav_remove_yes:{biz_id}"}],[{"text":"↩️ خیر، بازگشت","callback_data":CALLBACK_PREFIX+"favorites"}]]})


def remove_favorite(platform,platform_user_id,chat_id,biz_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer or not db.favorite_remove(customer["id"],biz_id):return send(chat_id,"این علاقه‌مندی پیدا نشد یا متعلق به حساب شما نیست.",_back())
    return send(chat_id,"کسب‌وکار از علاقه‌مندی‌های شما حذف شد.",{"inline_keyboard":[[{"text":"❤️ علاقه‌مندی‌ها","callback_data":CALLBACK_PREFIX+"favorites"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


CHAT_REPLIES={"thanks":"متشکرم، پیام شما را دریافت کردم.","contact":"لطفاً برای هماهنگی با من تماس بگیرید.","details":"لطفاً جزئیات بیشتری بفرستید."}


def send_messages(platform,platform_user_id,chat_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:return send(chat_id,"برای مشاهدهٔ پیام‌ها ابتدا حساب خود را متصل کنید.",_buttons(False))
    rows=db.customer_chat_summaries(customer["id"],5)
    if not rows:return send(chat_id,"💬 پیام‌های من\n\nهنوز گفتگویی ندارید.",{"inline_keyboard":[[{"text":"🌐 شروع گفتگو در سایت","url":SITE+"/businesses"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})
    lines=["💬 آخرین گفتگوهای من",""];buttons=[]
    for row in rows:
        last=row.get("last") or {};preview=_short(last.get("body"),70)
        if last.get("attachment_id"):preview=(preview+" · " if preview else "")+"📎 فایل"
        unread=f" · {_fa_int(row['unread'])} خوانده‌نشده" if row.get("unread") else ""
        lines.append(f"• {_short(row['bizname'],70)}{unread}\n{preview or 'بدون پیام'}")
        buttons.append([{"text":f"گفتگو با {_short(row['bizname'],28)}","callback_data":CALLBACK_PREFIX+f"chat:{row['id']}"}])
    buttons.append([{"text":"📋 همهٔ گفتگوها در سایت","url":SITE+"/me/chats"}]);buttons.append([{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}])
    return send(chat_id,"\n\n".join(lines)[:4096],{"inline_keyboard":buttons})


def send_chat(platform,platform_user_id,chat_id,thread_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:return send(chat_id,"حساب متصل پیدا نشد.",_buttons(False))
    row=db.customer_chat_detail(customer["id"],thread_id,6)
    if not row:return send(chat_id,"این گفتگو پیدا نشد یا متعلق به حساب شما نیست.",_back())
    lines=[f"💬 گفتگو با {_short(row['bizname'],90)}",f"وضعیت: {'باز' if row['status']=='open' else 'بسته'}",""]
    has_file=False
    for message in row["messages"]:
        who="شما" if message["sender"]=="customer" else ("مدیر دست گیر" if message["sender"]=="admin" else "کسب‌وکار")
        body=_short(message.get("body"),240)
        if message.get("attachment_id"):
            has_file=True;body+=(" · " if body else "")+f"📎 {_short(message.get('file_name'),70)}"
        lines.append(f"{who}: {body or 'فایل'}")
    if has_file:lines.extend(["","برای مشاهده یا ارسال فایل، گفتگو را در سایت باز کنید."])
    buttons=[]
    if row["status"]=="open":
        buttons.extend([[{"text":"🙏 متشکرم","callback_data":CALLBACK_PREFIX+f"chat_reply:{thread_id}:thanks"},
                         {"text":"📞 لطفاً تماس بگیرید","callback_data":CALLBACK_PREFIX+f"chat_reply:{thread_id}:contact"}],
                        [{"text":"ℹ️ جزئیات بیشتر","callback_data":CALLBACK_PREFIX+f"chat_reply:{thread_id}:details"}]])
    buttons.extend([[{"text":"🌐 ادامه و ارسال فایل در سایت","url":SITE+f"/me/chat/{thread_id}"}],
                    [{"text":"↩️ بازگشت به پیام‌ها","callback_data":CALLBACK_PREFIX+"messages"}]])
    return send(chat_id,"\n".join(lines)[:4096],{"inline_keyboard":buttons})


def confirm_chat_reply(platform,platform_user_id,chat_id,thread_id,code,send):
    _,customer=_account(platform,platform_user_id);text=CHAT_REPLIES.get(code)
    token=db.customer_chat_reply_prepare(customer["id"],thread_id,text) if customer and text else ""
    if not token:return send(chat_id,"این گفتگو بسته است، پیدا نشد یا متعلق به حساب شما نیست.",_back())
    return send(chat_id,f"این پاسخ ارسال شود؟\n\n«{text}»",{"inline_keyboard":[[{"text":"✅ بله، ارسال شود","callback_data":CALLBACK_PREFIX+f"chat_reply_yes:{token}"}],[{"text":"↩️ خیر، بازگشت","callback_data":CALLBACK_PREFIX+f"chat:{thread_id}"}]]})


def send_chat_reply(platform,platform_user_id,chat_id,token,send):
    _,customer=_account(platform,platform_user_id)
    result=db.customer_chat_reply_confirmed(customer["id"],token) if customer else None
    if not result:return send(chat_id,"این تأیید منقضی یا قبلاً استفاده شده است، یا گفتگو دیگر باز نیست.",_back())
    thread_id=result["thread_id"]
    return send(chat_id,"پاسخ کوتاه شما ارسال شد.",{"inline_keyboard":[[{"text":"💬 بازگشت به گفتگو","callback_data":CALLBACK_PREFIX+f"chat:{thread_id}"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


def send_owner(platform,platform_user_id,chat_id,send):
    owner=_owner_account(platform,platform_user_id)
    if not owner:return send(chat_id,"پنل کسب‌وکار فقط برای مالک متصل و فعال در دسترس است.",_back())
    s=db.owner_bot_summary(owner["id"])
    text=("🏪 پنل کسب‌وکار\n\n"
          f"کسب‌وکارها: {_fa_int(s['businesses'])}\nسفارش جدید: {_fa_int(s['new_orders'])}\n"
          f"نوبت امروز: {_fa_int(s['today_bookings'])}\nگفتگوی خوانده‌نشده: {_fa_int(s['unread_chats'])}\n"
          f"درخواست موجودی باز: {_fa_int(s['open_stock'])}")
    keys=[[{"text":"📦 سفارش‌ها","callback_data":CALLBACK_PREFIX+"owner_orders"},{"text":"📅 نوبت امروز","callback_data":CALLBACK_PREFIX+"owner_bookings"}],
          [{"text":"💬 پیام مشتریان","callback_data":CALLBACK_PREFIX+"owner_messages"},{"text":"📌 موجودی","callback_data":CALLBACK_PREFIX+"owner_stock"}],
          [{"text":"📣 فراخوان","callback_data":CALLBACK_PREFIX+"owner_broadcast"}],[{"text":"🌐 پنل کامل سایت","url":SITE+"/my"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]
    return send(chat_id,text,{"inline_keyboard":keys})


def send_owner_orders(platform,user,chat_id,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    rows=db.owner_order_summaries(owner["id"],5);lines=["📦 آخرین سفارش‌های کسب‌وکار",""];keys=[]
    for r in rows:
        lines.append(f"#{_fa_int(r['id'])} · {_short(r['bizname'],50)} · {_short(r['name'],40)}\n{r['status_label']}")
        keys.append([{"text":f"سفارش #{_fa_int(r['id'])}","callback_data":CALLBACK_PREFIX+f"owner_order:{r['id']}"}])
    if not rows:lines.append("سفارشی ثبت نشده است.")
    keys.extend([[{"text":"🌐 همه در سایت","url":SITE+"/my/orders"}],[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]])
    return send(chat_id,"\n\n".join(lines),{"inline_keyboard":keys})


def send_owner_order(platform,user,chat_id,order_id,send):
    owner=_owner_account(platform,user);r=db.owner_order_detail(owner["id"],order_id) if owner else None
    if not r:return send(chat_id,"سفارش پیدا نشد یا متعلق به کسب‌وکار شما نیست.",_back())
    items=[f"• {_short(x['title'],70)} × {_fa_int(x['qty'])}" for x in r["items"]]
    text=f"📦 سفارش #{_fa_int(r['id'])}\n\nکسب‌وکار: {_short(r['bizname'],80)}\nمشتری: {_short(r['name'],60)}\nوضعیت: {r['status_label']}\n\n"+"\n".join(items)
    nxt={"new":("confirmed","تأیید سفارش"),"confirmed":("ready","آمادهٔ تحویل"),"ready":("done","تحویل شد")}.get(r["status"]);keys=[]
    if nxt:keys.append([{"text":"✅ "+nxt[1],"callback_data":CALLBACK_PREFIX+f"owner_act:order_status:{order_id}:{nxt[0]}"}])
    keys.extend([[{"text":"🌐 پنل سفارش‌ها","url":SITE+"/my/orders"}],[{"text":"↩️ سفارش‌ها","callback_data":CALLBACK_PREFIX+"owner_orders"}]])
    return send(chat_id,text[:4096],{"inline_keyboard":keys})


def send_owner_bookings(platform,user,chat_id,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    rows=db.owner_today_bookings(owner["id"],8);lines=["📅 نوبت‌های امروز",""];keys=[]
    for r in rows:
        lines.append(f"#{_fa_int(r['id'])} · {_short(r['bizname'],45)} · {_short(r['name'],40)}\n{_short(r['time'],12)} · {r['status_label']}")
        nxt=("confirmed","تأیید نوبت") if r["status"]=="new" else (("done","انجام شد") if r["status"]=="confirmed" else None)
        if nxt:keys.append([{"text":f"#{_fa_int(r['id'])} · {nxt[1]}","callback_data":CALLBACK_PREFIX+f"owner_act:booking_status:{r['id']}:{nxt[0]}"}])
    if not rows:lines.append("برای امروز نوبت بازی ثبت نشده است.")
    keys.extend([[{"text":"🌐 همهٔ نوبت‌ها","url":SITE+"/my/bookings"}],[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]])
    return send(chat_id,"\n\n".join(lines),{"inline_keyboard":keys})


def send_owner_messages(platform,user,chat_id,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    rows=db.owner_chat_summaries(owner["id"],5);lines=["💬 پیام‌های مشتریان",""];keys=[]
    for r in rows:
        last=r.get("last") or {};preview=_short(last.get("body"),70) or ("📎 فایل" if last.get("attachment_id") else "بدون پیام")
        lines.append(f"• {_short(r.get('custname') or 'مشتری',45)} · {_short(r['bizname'],45)}\n{preview}")
        keys.append([{"text":f"گفتگو با {_short(r.get('custname') or 'مشتری',28)}","callback_data":CALLBACK_PREFIX+f"owner_chat:{r['id']}"}])
    if not rows:lines.append("گفتگویی ثبت نشده است.")
    keys.extend([[{"text":"🌐 صندوق کامل","url":SITE+"/my/chats"}],[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]])
    return send(chat_id,"\n\n".join(lines)[:4096],{"inline_keyboard":keys})


def send_owner_chat(platform,user,chat_id,thread_id,send):
    owner=_owner_account(platform,user);r=db.owner_chat_detail(owner["id"],thread_id,6) if owner else None
    if not r:return send(chat_id,"گفتگو پیدا نشد یا متعلق به کسب‌وکار شما نیست.",_back())
    lines=[f"💬 {_short(r.get('custname') or 'مشتری',60)} · {_short(r['bizname'],60)}",""]
    for m in r["messages"]:
        who="شما" if m["sender"]=="owner" else ("مدیر" if m["sender"]=="admin" else "مشتری");body=_short(m.get("body"),220)
        if m.get("attachment_id"):body+=(" · " if body else "")+"📎 "+_short(m.get("file_name"),60)
        lines.append(f"{who}: {body or 'فایل'}")
    return send(chat_id,"\n".join(lines)[:4096],{"inline_keyboard":[[{"text":"🌐 پاسخ و فایل در سایت","url":SITE+f"/my/chat/{thread_id}"}],[{"text":"↩️ پیام مشتریان","callback_data":CALLBACK_PREFIX+"owner_messages"}]]})


def send_owner_stock(platform,user,chat_id,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    rows=db.stock_requests_open(owner["id"])[:8];lines=["📌 درخواست‌های موجودی باز",""];keys=[]
    for r in rows:
        lines.append(f"#{_fa_int(r['id'])} · {_short(r.get('item_title') or 'هر کالا',60)} · {_short(r['biz_name'],45)} · تعداد {_fa_int(r['qty'])}")
        keys.append([{"text":f"موجود شد · #{_fa_int(r['id'])}","callback_data":CALLBACK_PREFIX+f"owner_act:stock_fulfill:{r['id']}:yes"}])
    if not rows:lines.append("درخواست بازی وجود ندارد.")
    keys.extend([[{"text":"🌐 مدیریت کامل","url":SITE+"/my/broadcast"}],[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]])
    return send(chat_id,"\n\n".join(lines),{"inline_keyboard":keys})


def send_owner_broadcast(platform,user,chat_id,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    rows=[b for b in db.businesses_of(owner["id"]) if db.broadcast_allowed(b["id"])]
    keys=[[{"text":"📣 "+_short(b["name"],32),"callback_data":CALLBACK_PREFIX+f"owner_act:broadcast:{b['id']}:news"}] for b in rows[:8]]
    text="📣 فراخوان آماده\n\nبا تأیید دوم، یک خبر کوتاه استاندارد برای دنبال‌کنندگان کسب‌وکار ارسال می‌شود. متن سفارشی فقط در پنل سایت نوشته می‌شود."
    if not rows:text="📣 فراخوان\n\nهیچ کسب‌وکار واجد دسترسی فراخوان نیست."
    keys.extend([[{"text":"🌐 فراخوان سفارشی در سایت","url":SITE+"/my/broadcast"}],[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]])
    return send(chat_id,text,{"inline_keyboard":keys})


def confirm_owner_action(platform,user,chat_id,action,target,value,send):
    owner=_owner_account(platform,user);token=db.owner_bot_action_prepare(owner["id"],action,target,value) if owner else ""
    if not token:return send(chat_id,"این عملیات معتبر نیست، مجاز نیست یا وضعیت قبلاً تغییر کرده است.",_back())
    labels={"order_status":"تغییر وضعیت سفارش","booking_status":"تغییر وضعیت نوبت","stock_fulfill":"اعلام موجودشدن","broadcast":"ارسال فراخوان"}
    return send(chat_id,f"آیا «{labels.get(action,'عملیات')}» انجام شود؟",{"inline_keyboard":[[{"text":"✅ بله، انجام شود","callback_data":CALLBACK_PREFIX+f"owner_yes:{token}"}],[{"text":"↩️ خیر، بازگشت","callback_data":CALLBACK_PREFIX+"owner"}]]})


def execute_owner_action(platform,user,chat_id,token,send):
    owner=_owner_account(platform,user);result=db.owner_bot_action_confirm(owner["id"],token) if owner else None
    if not result:return send(chat_id,"این تأیید منقضی، استفاده‌شده یا نامعتبر است.",_back())
    if not result.get("ok"):return send(chat_id,"فراخوان به‌دلیل محدودیت نرخ یا دسترسی ارسال نشد.",_back())
    extra=f" و به {_fa_int(result.get('recipients',0))} دنبال‌کننده رسید" if result["action"]=="broadcast" else ""
    return send(chat_id,"عملیات با موفقیت انجام شد"+extra+".",{"inline_keyboard":[[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


def send_help(platform, platform_user_id, chat_id, send):
    linked = bool(_account(platform, platform_user_id)[1])
    text = ("❓ راهنمای بات دست گیر\n\n"
            "• /start یا /menu — نمایش منوی اصلی\n"
            "• /account — مشاهدهٔ خلاصهٔ امن حساب\n"
            "• /orders — پنج سفارش اخیر و جزئیات امن\n"
            "• /bookings — نوبت‌ها، وضعیت و لغو با تأیید دوم\n"
            "• /notifications — روشن/خاموش‌کردن دسته‌های اعلان\n"
            "• /stock — پیگیری‌های موجودشدن و لغو با تأیید دوم\n"
            "• /favorites — کسب‌وکارهای ذخیره‌شده\n"
            "• /search عبارت — جست‌وجوی کسب‌وکار و مسیر\n"
            "• /messages — خلاصهٔ گفتگو و پاسخ کوتاه دومرحله‌ای\n"
            "• /owner — پنل روزانهٔ مالک کسب‌وکار\n"
            "• /help — نمایش این راهنما\n\n"
            "عملیات حساب فقط در گفت‌وگوی خصوصی انجام می‌شود. برای امنیت، درخواست‌هایی را "
            "که خودتان آغاز نکرده‌اید تأیید نکنید.")
    return send(chat_id, text, _back() if linked else _buttons(False))


def _allowed(platform, platform_user_id, chat_id, send):
    if db.rate_ok(f"bot-menu:{platform}:{platform_user_id}", limit=24,
                  window=60, always=True):
        return True
    send(chat_id, "درخواست‌های شما زیاد است؛ یک دقیقه بعد دوباره تلاش کنید.")
    return False


def handle_message(platform, platform_user_id, chat_id, text, send):
    """Handle only menu commands; return True when the message was consumed."""
    raw=str(text or "").strip()
    search_match=re.fullmatch(r"/search(?:@\w+)?(?:\s+(.+))?",raw,re.I)
    persian_search=re.fullmatch(r"جست(?:‌|\s*)وجو(?:\s+(.+))?",raw)
    if search_match or persian_search:
        if not _allowed(platform,platform_user_id,chat_id,send):return True
        query=(search_match or persian_search).group(1) or ""
        (send_search(platform,platform_user_id,chat_id,query,send) if query else send_search_help(chat_id,send))
        return True
    value = re.sub(r"@\w+", "", raw, count=1).lower()
    actions = {
        "menu": ("/start", "/menu", "منو", "🏠 منوی اصلی"),
        "account": ("/account", "حساب", "حساب من", "👤 حساب من"),
        "orders": ("/orders", "سفارش", "سفارش‌ها", "سفارش‌های من", "📦 سفارش‌های من"),
        "bookings": ("/bookings", "نوبت", "نوبت‌ها", "نوبت‌های من", "📅 نوبت‌های من"),
        "notifications": ("/notifications", "اعلان", "اعلان‌ها", "🔔 اعلان‌ها"),
        "stock": ("/stock", "موجودشدن", "موجودشدن‌ها", "📌 موجودشدن‌ها"),
        "favorites": ("/favorites", "علاقه‌مندی", "علاقه‌مندی‌ها", "❤️ علاقه‌مندی‌ها"),
        "search": ("جست‌وجو", "🔍 جست‌وجو"),
        "messages": ("/messages", "پیام", "پیام‌ها", "پیام‌های من", "💬 پیام‌های من"),
        "owner": ("/owner", "پنل کسب‌وکار", "🏪 پنل کسب‌وکار"),
        "help": ("/help", "راهنما", "❓ راهنما"),
    }
    action = next((key for key, values in actions.items() if value in values), "")
    if not action:
        return False
    if not _allowed(platform, platform_user_id, chat_id, send):
        return True
    if action == "menu": send_menu(platform, platform_user_id, chat_id, send)
    elif action == "account": send_account(platform, platform_user_id, chat_id, send)
    elif action == "orders": send_orders(platform, platform_user_id, chat_id, send)
    elif action == "bookings": send_bookings(platform, platform_user_id, chat_id, send)
    elif action == "notifications": send_notifications(platform,platform_user_id,chat_id,send)
    elif action == "stock": send_stock(platform,platform_user_id,chat_id,send)
    elif action == "favorites": send_favorites(platform,platform_user_id,chat_id,send)
    elif action == "search": send_search_help(chat_id,send)
    elif action == "messages": send_messages(platform,platform_user_id,chat_id,send)
    elif action == "owner": send_owner(platform,platform_user_id,chat_id,send)
    else: send_help(platform, platform_user_id, chat_id, send)
    return True


def handle_callback(platform, platform_user_id, chat_id, data, send):
    """Handle namespaced menu callbacks; return True when consumed."""
    if not str(data or "").startswith(CALLBACK_PREFIX):
        return False
    action = str(data)[len(CALLBACK_PREFIX):]
    order_match = re.fullmatch(r"order:(\d{1,12})", action)
    booking_match = re.fullmatch(r"booking:(\d{1,12})", action)
    cancel_match = re.fullmatch(r"booking_cancel:(\d{1,12})", action)
    cancel_yes_match = re.fullmatch(r"booking_cancel_yes:(\d{1,12})", action)
    notif_match = re.fullmatch(r"notif:([a-z_]{2,24})", action)
    stock_cancel_match = re.fullmatch(r"stock_cancel:(\d{1,12})", action)
    stock_cancel_yes_match = re.fullmatch(r"stock_cancel_yes:(\d{1,12})", action)
    fav_add_match = re.fullmatch(r"fav_add:(\d{1,12})", action)
    fav_remove_match = re.fullmatch(r"fav_remove:(\d{1,12})", action)
    fav_remove_yes_match = re.fullmatch(r"fav_remove_yes:(\d{1,12})", action)
    chat_match=re.fullmatch(r"chat:(\d{1,12})",action)
    chat_reply_match=re.fullmatch(r"chat_reply:(\d{1,12}):(thanks|contact|details)",action)
    chat_reply_yes_match=re.fullmatch(r"chat_reply_yes:([A-Za-z0-9_-]{8,24})",action)
    owner_order_match=re.fullmatch(r"owner_order:(\d{1,12})",action)
    owner_chat_match=re.fullmatch(r"owner_chat:(\d{1,12})",action)
    owner_action_match=re.fullmatch(r"owner_act:(order_status|booking_status|stock_fulfill|broadcast):(\d{1,12}):(confirmed|ready|done|yes|news)",action)
    owner_yes_match=re.fullmatch(r"owner_yes:([A-Za-z0-9_-]{8,24})",action)
    owner_static=("owner","owner_orders","owner_bookings","owner_messages","owner_stock","owner_broadcast")
    if (action not in ("menu", "account", "orders", "bookings", "notifications", "stock", "favorites", "search", "messages", "help")+owner_static
            and not any((order_match,booking_match,cancel_match,cancel_yes_match,
                         notif_match,stock_cancel_match,stock_cancel_yes_match,
                         fav_add_match,fav_remove_match,fav_remove_yes_match,
                         chat_match,chat_reply_match,chat_reply_yes_match,
                         owner_order_match,owner_chat_match,owner_action_match,owner_yes_match))):
        return False
    if not _allowed(platform, platform_user_id, chat_id, send):
        return True
    if action == "menu": send_menu(platform, platform_user_id, chat_id, send)
    elif action == "account": send_account(platform, platform_user_id, chat_id, send)
    elif action == "orders": send_orders(platform, platform_user_id, chat_id, send)
    elif action == "bookings": send_bookings(platform, platform_user_id, chat_id, send)
    elif action == "notifications": send_notifications(platform,platform_user_id,chat_id,send)
    elif action == "stock": send_stock(platform,platform_user_id,chat_id,send)
    elif action == "favorites": send_favorites(platform,platform_user_id,chat_id,send)
    elif action == "search": send_search_help(chat_id,send)
    elif action == "messages": send_messages(platform,platform_user_id,chat_id,send)
    elif action == "owner":send_owner(platform,platform_user_id,chat_id,send)
    elif action == "owner_orders":send_owner_orders(platform,platform_user_id,chat_id,send)
    elif action == "owner_bookings":send_owner_bookings(platform,platform_user_id,chat_id,send)
    elif action == "owner_messages":send_owner_messages(platform,platform_user_id,chat_id,send)
    elif action == "owner_stock":send_owner_stock(platform,platform_user_id,chat_id,send)
    elif action == "owner_broadcast":send_owner_broadcast(platform,platform_user_id,chat_id,send)
    elif owner_order_match:send_owner_order(platform,platform_user_id,chat_id,int(owner_order_match.group(1)),send)
    elif owner_chat_match:send_owner_chat(platform,platform_user_id,chat_id,int(owner_chat_match.group(1)),send)
    elif owner_action_match:confirm_owner_action(platform,platform_user_id,chat_id,owner_action_match.group(1),int(owner_action_match.group(2)),owner_action_match.group(3),send)
    elif owner_yes_match:execute_owner_action(platform,platform_user_id,chat_id,owner_yes_match.group(1),send)
    elif order_match: send_order(platform, platform_user_id, chat_id, int(order_match.group(1)), send)
    elif booking_match: send_booking(platform, platform_user_id, chat_id, int(booking_match.group(1)), send)
    elif cancel_match: confirm_booking_cancel(platform, platform_user_id, chat_id, int(cancel_match.group(1)), send)
    elif cancel_yes_match: cancel_booking(platform, platform_user_id, chat_id, int(cancel_yes_match.group(1)), send)
    elif notif_match: toggle_notification(platform,platform_user_id,chat_id,notif_match.group(1),send)
    elif stock_cancel_match: confirm_stock_cancel(platform,platform_user_id,chat_id,int(stock_cancel_match.group(1)),send)
    elif stock_cancel_yes_match: cancel_stock(platform,platform_user_id,chat_id,int(stock_cancel_yes_match.group(1)),send)
    elif fav_add_match: add_favorite(platform,platform_user_id,chat_id,int(fav_add_match.group(1)),send)
    elif fav_remove_match: confirm_favorite_remove(platform,platform_user_id,chat_id,int(fav_remove_match.group(1)),send)
    elif fav_remove_yes_match: remove_favorite(platform,platform_user_id,chat_id,int(fav_remove_yes_match.group(1)),send)
    elif chat_match:send_chat(platform,platform_user_id,chat_id,int(chat_match.group(1)),send)
    elif chat_reply_match:confirm_chat_reply(platform,platform_user_id,chat_id,int(chat_reply_match.group(1)),chat_reply_match.group(2),send)
    elif chat_reply_yes_match:send_chat_reply(platform,platform_user_id,chat_id,chat_reply_yes_match.group(1),send)
    else: send_help(platform, platform_user_id, chat_id, send)
    return True
