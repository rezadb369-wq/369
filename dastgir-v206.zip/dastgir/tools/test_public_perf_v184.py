#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Focused public/mobile performance checks. Requires run.py."""
from __future__ import annotations
import gzip
import http.client
import os
from pathlib import Path
import sys
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
BASE_HOST = "127.0.0.1"
PORT = int(os.environ.get("BZ_PORT", "8080"))
BASE = os.environ.get("BZ", f"http://{BASE_HOST}:{PORT}")


def check(ok, label):
    if not ok: raise AssertionError(label)
    print("✓", label)


def get(path, headers=None):
    c = http.client.HTTPConnection(BASE_HOST, PORT, timeout=15)
    c.request("GET", path, headers=headers or {})
    r = c.getresponse(); body = r.read(); h = dict(r.getheaders()); code = r.status
    c.close(); return code, h, body


def main():
    src = ROOT / "site/assets/img/logo-source.png"
    display = ROOT / "site/assets/img/logo-display.png"
    check(src.stat().st_size > display.stat().st_size * 7,
          "header logo transfer is reduced by more than 7×")

    for path in ("/assets/css/pages.css?v182", "/assets/js/app.js?v206"):
        code, h, compressed = get(path, {"Accept-Encoding": "gzip"})
        raw = (ROOT / ("site" + path.split("?")[0])).read_bytes()
        check(code == 200 and h.get("Content-Encoding") == "gzip" and
              len(compressed) < len(raw) * .45, f"{path} is gzip-compressed")
        check("max-age=31536000" in h.get("Cache-Control", "") and
              "immutable" in h.get("Cache-Control", ""),
              f"{path} has immutable release caching")
        etag = h.get("ETag")
        code304, _, body304 = get(path, {"If-None-Match": etag})
        check(code304 == 304 and not body304, f"{path} supports zero-body revalidation")

    code, h, _ = get("/assets/js/app.js")
    check(code == 200 and h.get("Cache-Control") == "no-cache",
          "unversioned service-worker asset remains safely revalidated")
    code, h, home_gz = get("/", {"Accept-Encoding": "gzip"})
    check(code == 200 and h.get("Content-Encoding") == "gzip" and len(home_gz) < 25_000,
          "public home HTML is compressed below 25 KB")

    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--no-sandbox"])
        for width, theme in ((1440, "light"), (390, "dark")):
            page = browser.new_page(viewport={"width": width, "height": 900})
            page.add_init_script(f"localStorage.setItem('bz-theme','{theme}')")
            errors = []; page.on("pageerror", lambda e: errors.append(str(e)))
            page.goto(BASE + "/", wait_until="networkidle")
            logo = page.locator(".brand-mark img").first
            state = logo.evaluate("""e => ({src:e.getAttribute('src'), complete:e.complete,
                nw:e.naturalWidth, nh:e.naturalHeight, w:e.getBoundingClientRect().width,
                h:e.getBoundingClientRect().height,
                overflow:document.documentElement.scrollWidth > innerWidth})""")
            check(state["src"] == "/assets/img/logo-display.png?v183" and state["complete"] and
                  state["nw"] == 192 and state["nh"] == 192 and
                  state["w"] == 38 and state["h"] == 38,
                  f"optimized logo renders unchanged at {width}px/{theme}")
            check(not state["overflow"] and not errors,
                  f"no overflow or page errors at {width}px/{theme}")
            page.close()
        browser.close()

    check((ROOT / "VERSION.txt").read_text().strip() == "206" and
          "bazarche-v206" in (ROOT / "site/sw.js").read_text(),
          "release and service-worker markers are v206")
    print("\nهمهٔ آزمون‌های کارایی عمومی v206 موفق بودند.")


if __name__ == "__main__":
    main()
