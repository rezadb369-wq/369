#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Real HTTP/webhook/browser-cookie flow for Bale v206, using a local fake API."""
import http.cookiejar
import http.server
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="dastgir-bale-http-")
PORT, FAKE = 8094, 8093
SECRET = "W" * 43
received = []

class Fake(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0)); body = self.rfile.read(n)
        try: received.append((self.path, json.loads(body)))
        except Exception: received.append((self.path, {}))
        out = b'{"ok":true,"result":true}'
        self.send_response(200); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out))); self.end_headers(); self.wfile.write(out)
    def log_message(self, *args): pass

fake = http.server.ThreadingHTTPServer(("127.0.0.1", FAKE), Fake)
threading.Thread(target=fake.serve_forever, daemon=True).start()
env = dict(os.environ, BZ_DATA_DIR=TMP, PORT=str(PORT),
           BALE_BOT_TOKEN="unit-test-token", BALE_WEBHOOK_SECRET=SECRET,
           BALE_BOT_USERNAME="daastgirbot", BALE_API_ROOT=f"http://127.0.0.1:{FAKE}/bot")
sys.path.insert(0, str(ROOT / "server")); os.environ["BZ_DATA_DIR"] = TMP
import db  # noqa
db.init(); cust = db.customer_by_phone("09120000002", create=True)
owner=db.owner_by_phone("09120000002", create=True)
con = db.connect(); con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,'bale','513379886','513379886')", (cust["id"],)); con.execute("INSERT INTO businesses(slug,name,cat_slug,status,address,lat,lng,owner_id) VALUES('bot-order-shop','فروشگاه بات','services','published','خیابان تست',35.7,51.4,?)",(owner['id'],)); con.commit(); con.close()
biz=db.business(slug='bot-order-shop'); bot_order_id=db.create_order(biz['id'],cust['id'],'مشتری','09120000002','','',[{'title':'کالای تست بات','price':12000,'qty':2}]); bot_booking_id=db.add_booking(biz['id'],'مشتری','09120000002','1405/07/20','10:30','خصوصی',cust['id']); con=db.connect();con.execute("INSERT INTO items(biz_id,title,stock,available) VALUES(?,?,0,0)",(biz['id'],'کالای پیگیری'));bot_item_id=con.execute('SELECT last_insert_rowid()').fetchone()[0];con.commit();con.close();db.stock_request_add(biz['id'],bot_item_id,cust['id'],qty=2);bot_stock_id=db.customer_stock_requests(cust['id'])[0]['id'];bot_chat_id=db.chat_start(biz['id'],cust['id'],'پرسش بات');db.chat_send(bot_chat_id,'owner','پاسخ از فروشگاه')
proc = subprocess.Popen([sys.executable, str(ROOT / "run.py")], cwd=ROOT, env=env,
                        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

npass = 0
def check(ok, label):
    global npass
    if not ok: raise AssertionError(label)
    npass += 1; print("  ✓", label)

def request(opener, path, data=None):
    raw = json.dumps(data).encode() if isinstance(data, dict) else data
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}{path}", data=raw)
    if isinstance(data, dict): req.add_header("Content-Type", "application/json")
    try:
        r = opener.open(req, timeout=10); return r.status, r.read().decode(), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode(), dict(e.headers)

try:
    for _ in range(50):
        try:
            if urllib.request.urlopen(f"http://127.0.0.1:{PORT}/healthz", timeout=.3).status == 200: break
        except Exception: time.sleep(.1)
    jar = http.cookiejar.CookieJar(); op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
    code, login_page, _ = request(op, "/login")
    check(code == 200 and "/auth/bale" in login_page and "/auth/soroush" in login_page and
          'action="/login"' not in login_page,
          "public login is messenger-only with no SMS/password form")
    check(request(op, "/login", {})[0] == 404 and
          request(op, "/login/password", {})[0] == 404,
          "legacy OTP and password POST endpoints are unavailable")
    menu_update = {"update_id": 900, "message": {"text": "/menu",
                   "from": {"id": 513379886},
                   "chat": {"id": 513379886, "type":"private"}}}
    code, _, _ = request(op, "/api/bale/webhook/" + SECRET, menu_update)
    menu_payload = received[-1][1]
    check(code == 200 and "متصل است" in menu_payload.get("text", "") and
          "dg198:account" in json.dumps(menu_payload), "linked Bale user receives shared secure menu")
    account_cb = {"update_id": 901, "callback_query": {"id":"menu-cb", "data":"dg198:account",
                  "from":{"id":513379886}, "message":{"chat":{"id":513379886,"type":"private"}}}}
    code, _, _ = request(op, "/api/bale/webhook/" + SECRET, account_cb)
    check(code == 200 and any("0912••••002" in x[1].get("text", "") for x in received[-2:]),
          "Bale account callback returns only a masked phone")
    orders_update={"update_id":903,"message":{"text":"/orders","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}}
    code,_,_=request(op,"/api/bale/webhook/"+SECRET,orders_update);orders_payload=received[-1][1]
    check(code==200 and f"dg198:order:{bot_order_id}" in json.dumps(orders_payload),"Bale lists only linked-customer order actions")
    detail_update={"update_id":904,"callback_query":{"id":"order-cb","data":f"dg198:order:{bot_order_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}}
    code,_,_=request(op,"/api/bale/webhook/"+SECRET,detail_update)
    check(code==200 and any("کالای تست بات" in x[1].get("text","") for x in received[-2:]),"Bale returns owned order detail")
    bookings_update={"update_id":905,"message":{"text":"/bookings","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}}
    code,_,_=request(op,"/api/bale/webhook/"+SECRET,bookings_update)
    check(code==200 and f"dg198:booking:{bot_booking_id}" in json.dumps(received[-1][1]),"Bale lists linked-customer bookings")
    booking_detail={"update_id":906,"callback_query":{"id":"book-cb","data":f"dg198:booking:{bot_booking_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}}
    code,_,_=request(op,"/api/bale/webhook/"+SECRET,booking_detail)
    check(code==200 and any("1405/07/20" in x[1].get("text","") and "خصوصی" not in x[1].get("text","") for x in received[-2:]),"Bale returns safe booking detail")
    ask_cancel={"update_id":907,"callback_query":{"id":"cancel-ask","data":f"dg198:booking_cancel:{bot_booking_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}}
    request(op,"/api/bale/webhook/"+SECRET,ask_cancel)
    check(db.customer_booking_detail(cust['id'],bot_booking_id)['status']=='new' and f"dg198:booking_cancel_yes:{bot_booking_id}" in json.dumps(received[-1][1]),"Bale cancellation requires a second confirmation")
    yes_cancel={"update_id":908,"callback_query":{"id":"cancel-yes","data":f"dg198:booking_cancel_yes:{bot_booking_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}}
    code,_,_=request(op,"/api/bale/webhook/"+SECRET,yes_cancel)
    check(code==200 and db.customer_booking_detail(cust['id'],bot_booking_id)['status']=='cancelled',"Bale confirmed cancellation updates the owned booking")
    notif_update={"update_id":880,"message":{"text":"/notifications","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}};code,_,_=request(op,"/api/bale/webhook/"+SECRET,notif_update)
    check(code==200 and "dg198:notif:booking" in json.dumps(received[-1][1]),"Bale renders notification preferences")
    notif_toggle={"update_id":881,"callback_query":{"id":"notif-cb","data":"dg198:notif:booking","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/bale/webhook/"+SECRET,notif_toggle)
    check(not db.kind_enabled('cust',cust['id'],'booking'),"Bale notification toggle persists to shared site preferences")
    stock_update={"update_id":882,"message":{"text":"/stock","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}};code,_,_=request(op,"/api/bale/webhook/"+SECRET,stock_update)
    check(code==200 and f"dg198:stock_cancel:{bot_stock_id}" in json.dumps(received[-1][1]),"Bale lists customer stock tracking")
    stock_ask={"update_id":883,"callback_query":{"id":"stock-ask","data":f"dg198:stock_cancel:{bot_stock_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/bale/webhook/"+SECRET,stock_ask)
    check(db.stock_request_status(biz['id'],bot_item_id,cust['id'])=='open' and 'stock_cancel_yes' in json.dumps(received[-1][1]),"Bale stock cancellation requires confirmation")
    stock_yes={"update_id":884,"callback_query":{"id":"stock-yes","data":f"dg198:stock_cancel_yes:{bot_stock_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/bale/webhook/"+SECRET,stock_yes)
    check(db.stock_request_status(biz['id'],bot_item_id,cust['id'])=='dismissed',"Bale confirmed stock cancellation persists")
    search_update={"update_id":885,"message":{"text":"/search فروشگاه بات","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}};code,_,_=request(op,"/api/bale/webhook/"+SECRET,search_update)
    check(code==200 and '/b/bot-order-shop' in json.dumps(received[-1][1]) and 'google.com/maps' in json.dumps(received[-1][1]),"Bale search returns site and route actions")
    fav_add={"update_id":886,"callback_query":{"id":"fav-add","data":f"dg198:fav_add:{biz['id']}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/bale/webhook/"+SECRET,fav_add)
    check(db.fav_state(cust['id'],biz['id']),"Bale search result adds shared favorite")
    fav_list={"update_id":887,"message":{"text":"/favorites","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}};request(op,"/api/bale/webhook/"+SECRET,fav_list)
    check(f"dg198:fav_remove:{biz['id']}" in json.dumps(received[-1][1]),"Bale lists shared favorites")
    fav_ask={"update_id":888,"callback_query":{"id":"fav-ask","data":f"dg198:fav_remove:{biz['id']}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/bale/webhook/"+SECRET,fav_ask)
    check(db.fav_state(cust['id'],biz['id']) and 'fav_remove_yes' in json.dumps(received[-1][1]),"Bale favorite removal requires confirmation")
    fav_yes={"update_id":889,"callback_query":{"id":"fav-yes","data":f"dg198:fav_remove_yes:{biz['id']}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/bale/webhook/"+SECRET,fav_yes)
    check(not db.fav_state(cust['id'],biz['id']),"Bale confirmed favorite removal persists")
    chat_list={"update_id":890,"message":{"text":"/messages","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}};request(op,"/api/bale/webhook/"+SECRET,chat_list)
    check(f"dg198:chat:{bot_chat_id}" in json.dumps(received[-1][1]),"Bale lists customer conversations")
    chat_detail={"update_id":891,"callback_query":{"id":"chat-detail","data":f"dg198:chat:{bot_chat_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/bale/webhook/"+SECRET,chat_detail)
    check('پاسخ از فروشگاه' in received[-1][1].get('text','') and '/me/chat/' in json.dumps(received[-1][1]),"Bale shows safe conversation summary and site handoff")
    chat_ask={"update_id":892,"callback_query":{"id":"chat-ask","data":f"dg198:chat_reply:{bot_chat_id}:thanks","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/bale/webhook/"+SECRET,chat_ask)
    before_msgs=len(db.chat_messages(bot_chat_id));yes_data=received[-1][1]['reply_markup']['inline_keyboard'][0][0]['callback_data'];check('chat_reply_yes' in yes_data and len(db.chat_messages(bot_chat_id))==before_msgs,"Bale short reply requires one-use confirmation")
    chat_yes={"update_id":893,"callback_query":{"id":"chat-yes","data":yes_data,"from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/bale/webhook/"+SECRET,chat_yes)
    check(len(db.chat_messages(bot_chat_id))==before_msgs+1,"Bale confirmed short reply persists")
    db._run("DELETE FROM ratelimit WHERE bucket=?",('bot-menu:bale:513379886',))
    owner_menu={"update_id":894,"message":{"text":"/owner","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}};request(op,"/api/bale/webhook/"+SECRET,owner_menu)
    check('پنل کسب‌وکار' in received[-1][1].get('text','') and 'owner_orders' in json.dumps(received[-1][1]),"Bale exposes daily owner dashboard to linked shopkeeper")
    owner_detail={"update_id":895,"callback_query":{"id":"owner-detail","data":f"dg198:owner_order:{bot_order_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/bale/webhook/"+SECRET,owner_detail)
    check('owner_act:order_status' in json.dumps(received[-1][1]),"Bale owner sees safe next order transition")
    owner_ask={"update_id":896,"callback_query":{"id":"owner-ask","data":f"dg198:owner_act:order_status:{bot_order_id}:confirmed","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/bale/webhook/"+SECRET,owner_ask);owner_yes=received[-1][1]['reply_markup']['inline_keyboard'][0][0]['callback_data']
    check(db.order(bot_order_id)['status']=='new' and 'owner_yes:' in owner_yes,"Bale owner change requires one-use confirmation")
    owner_confirm={"update_id":897,"callback_query":{"id":"owner-confirm","data":owner_yes,"from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/bale/webhook/"+SECRET,owner_confirm)
    check(db.order(bot_order_id)['status']=='confirmed',"Bale confirmed owner transition persists")
    before=len(received);group_menu={"update_id":902,"message":{"text":"/menu","from":{"id":513379886},"chat":{"id":-20,"type":"group"}}}
    code, _, _=request(op,"/api/bale/webhook/"+SECRET,group_menu)
    check(code==200 and len(received)==before,"Bale menu ignores group chats")

    code, html, _ = request(op, "/auth/bale")
    check(code == 200 and "ورود با بله" in html, "Bale login challenge renders over HTTP")
    token = re.search(r"start=login_([A-Za-z0-9_-]+)", html).group(1)
    code, _, _ = request(op, "/api/bale/webhook/badbadbadbadbadbadbadbadbadbadbadbad", {})
    check(code == 404, "wrong webhook secret is indistinguishable from missing route")
    update = {"update_id": 1001, "message": {"text": "/start login_" + token,
                           "from": {"id": 513379886}, "chat": {"id": 513379886, "type":"private"}}}
    code, body, _ = request(op, "/api/bale/webhook/" + SECRET, update)
    check(code == 200 and json.loads(body)["ok"], "valid webhook accepts /start update")
    callback = next(x[1]["reply_markup"]["inline_keyboard"][0][0]["callback_data"]
                    for x in received if x[0].endswith("/sendMessage") and x[1].get("reply_markup") and
                    x[1]["reply_markup"]["inline_keyboard"][0][0].get("callback_data", "").startswith("bz185:"))
    update = {"update_id": 1002, "callback_query": {"id": "cb1", "data": callback,
              "from": {"id": 513379886}, "message": {"chat": {"id": 513379886, "type":"private"}}}}
    code, _, _ = request(op, "/api/bale/webhook/" + SECRET, update)
    check(code == 200, "approval callback reaches application")
    code, body, _ = request(op, "/api/bale/webhook/" + SECRET, update)
    check(code == 200 and json.loads(body).get("duplicate") is True,
          "duplicate update_id is acknowledged but never executed twice")
    cid = json.loads(re.search(r"encodeURIComponent\((\"[A-Za-z0-9_-]+\")\)", html).group(1))
    code, body, _ = request(op, "/api/bale/status?id=" + cid)
    out = json.loads(body)
    check(out["status"] == "approved" and out["redirect"] == "/my",
          "bound browser receives approval and normal site session")
    code, page, _ = request(op, "/me")
    check(code == 200 and "حساب" in page, "minted customer session opens private account")
    code, page, _ = request(op, "/my")
    check(code == 200, "same phone also receives its eligible owner session")
    code, body, _ = request(op, "/api/bale/status?id=" + cid)
    check(json.loads(body)["status"] == "expired", "consumed approval cannot be replayed")

    # Exercise the one-time account-link flow through the authenticated browser.
    db.messenger_unlink(cust["id"], "bale")
    code, link_html, _ = request(op, "/me/bale/connect")
    check(code == 200 and "اتصال حساب بله" in link_html,
          "authenticated customer can start one-time Bale linking")
    link_token = re.search(r"start=link_([A-Za-z0-9_-]+)", link_html).group(1)
    link_cid = json.loads(re.search(r"encodeURIComponent\((\"[A-Za-z0-9_-]+\")\)", link_html).group(1))
    update = {"update_id": 2001, "message": {"text": "/start link_" + link_token,
              "from": {"id": 888001}, "chat": {"id": 888001, "type":"private"}}}
    code, _, _ = request(op, "/api/bale/webhook/" + SECRET, update)
    check(code == 200, "bot resolves authenticated linking challenge")
    callback = next(x[1]["reply_markup"]["inline_keyboard"][0][0]["callback_data"]
                    for x in reversed(received)
                    if x[0].endswith("/sendMessage") and x[1].get("reply_markup") and
                    x[1]["reply_markup"]["inline_keyboard"][0][0].get("callback_data", "").startswith("bz185:"))
    update = {"update_id": 2002, "callback_query": {"id": "cb-link", "data": callback,
              "from": {"id": 888001}, "message": {"chat": {"id": 888001, "type":"private"}}}}
    code, _, _ = request(op, "/api/bale/webhook/" + SECRET, update)
    code, body, _ = request(op, "/api/bale/status?id=" + link_cid)
    account = db.messenger_account_for_customer(cust["id"])
    check(code == 200 and json.loads(body)["status"] == "approved" and
          account and account["platform_user_id"] == "888001",
          "explicit bot confirmation completes browser-bound account link")

    # Unknown Bale identity: verified own contact, then a separate confirmation.
    signup_op = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    code, signup_html, _ = request(signup_op, "/auth/bale")
    signup_token = re.search(r"start=login_([A-Za-z0-9_-]+)", signup_html).group(1)
    signup_cid = json.loads(re.search(
        r"encodeURIComponent\((\"[A-Za-z0-9_-]+\")\)", signup_html).group(1))
    update = {"update_id": 3001, "message": {"text": "/start login_" + signup_token,
              "from": {"id": 700001}, "chat": {"id": 700001, "type":"private"}}}
    request(signup_op, "/api/bale/webhook/" + SECRET, update)
    contact_call = next(x for x in reversed(received)
                        if x[0].endswith("/sendMessage") and
                        (x[1].get("reply_markup") or {}).get("keyboard"))
    check(contact_call[1]["reply_markup"]["keyboard"][0][0].get("request_contact") is True,
          "unknown Bale user receives official own-contact signup button")
    update = {"update_id": 3002, "message": {"contact": {
              "phone_number": "+989131234567", "user_id": 700001},
              "from": {"id": 700001}, "chat": {"id": 700001, "type":"private"}}}
    request(signup_op, "/api/bale/webhook/" + SECRET, update)
    signup_callback = next(x[1]["reply_markup"]["inline_keyboard"][0][0]["callback_data"]
                           for x in reversed(received)
                           if x[0].endswith("/sendMessage") and
                           str((x[1].get("reply_markup") or {})).find("bz186:signup:") >= 0)
    check(signup_callback.startswith("bz186:signup:"),
          "verified own contact still requires separate registration approval")
    update = {"update_id": 3003, "callback_query": {"id": "cb-signup",
              "data": signup_callback, "from": {"id": 700001},
              "message": {"chat": {"id": 700001, "type":"private"}}}}
    request(signup_op, "/api/bale/webhook/" + SECRET, update)
    code, body, _ = request(signup_op, "/api/bale/status?id=" + signup_cid)
    check(code == 200 and json.loads(body)["status"] == "approved" and
          db.messenger_account_by_platform("bale", 700001),
          "Bale-only flow creates, links and signs in a new customer")

    # Two login challenges above used two of six slots for this IP.
    codes = []
    for _ in range(5):
        fresh = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        codes.append(request(fresh, "/auth/bale")[0])
    check(codes[:4] == [200] * 4 and codes[4] == 429,
          "security-critical challenge issuance is rate-limited even if spam limits are disabled")
    print(f"\nAll {npass} Bale HTTP v206 checks passed.")
finally:
    proc.terminate()
    try: proc.wait(timeout=5)
    except Exception: proc.kill()
    fake.shutdown(); fake.server_close(); shutil.rmtree(TMP, ignore_errors=True)
