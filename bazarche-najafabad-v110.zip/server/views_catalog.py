# -*- coding: utf-8 -*-
"""
Catalog: products, services and bespoke ("کار سفارشی") work.

The three kinds share one table but behave differently:
  product → has a price and stock-like availability
  service → has a duration, often priced "from"
  custom  → usually no fixed price at all; drives a quote request instead
"""

import json
import db
from ui import (icon, fa, esc, page, breadcrumb, empty_state, section_head,
                stat_card, flash, json_embed)

KIND_ICON = {"product": "shopping", "service": "zap", "custom": "sparkles"}
UP_JS = '<script type="module" src="/assets/js/upload.js?v109"></script>'


def _msg(q):
    q = q or {}
    if q.get("ok"):
        return flash("ok", q["ok"][0])
    if q.get("err"):
        return flash("err", q["err"][0])
    return ""


# ==========================================================================
#  PUBLIC — item card + catalog strip on a business page
# ==========================================================================
def item_card(it, show_biz=False, delay=0, prices_on=True):
    cover = it.get("cover") or it.get("image")
    img = (f'<img src="{esc(cover)}" alt="{esc(it["title"])}" loading="lazy" decoding="async">'
           if cover else
           f'<span class="item-ph">{icon(KIND_ICON.get(it["kind"], "tag"))}</span>')

    badges = ""
    if prices_on and it.get("has_discount"):
        badges += f'<span class="badge badge-off">{fa(it["discount_pct"])}٪ تخفیف</span>'
    if it.get("featured"):
        badges += f'<span class="badge badge-featured">{icon("star")}<span>ویژه</span></span>'
    if it["kind"] == "custom":
        badges += f'<span class="badge badge-info">{icon("sparkles")}<span>سفارشی</span></span>'
    if prices_on and db.haggle_allowed(it):
        badges += (f'<span class="badge badge-accent">{icon("tag")}'
                   f'<span>چانه‌زنی</span></span>')
    if not it.get("available") or not it.get("in_stock", True):
        badges += f'<span class="badge badge-closed">{icon("x")}<span>ناموجود</span></span>'

    n_more = max(0, len(it.get("image_list", [])) - 1)
    more = (f'<span class="item-more">{icon("image")}<span>{fa(n_more)}+</span></span>'
            if n_more else "")

    meta = ""
    if it.get("duration"):
        meta += f'<span class="card-meta" style="margin:0">{icon("clock")}<span>{esc(it["duration"])}</span></span>'
    if it.get("stock_tracked") and it.get("in_stock"):
        meta += f'<span class="card-meta" style="margin:0">{icon("box")}<span>{fa(it["stock"])} عدد موجود</span></span>'
    if show_biz:
        meta += (f'<a class="card-meta" style="margin:0" href="/b/{esc(it["bizslug"])}">'
                 f'{icon("store")}<span>{esc(it["bizname"])}</span></a>')

    # trust badges: the small print that decides a sale — Basalam leans on
    # «دست‌ساز», Digikala on returns, Torob on delivery. Show at most three
    # so the card does not turn into a wall of pills.
    flags = "".join(f'<span class="item-flag">{icon(ic)}<span>{esc(t)}</span></span>'
                    for t, ic in (it.get("flags") or [])[:3])

    chips = "".join(f'<span class="badge badge-neutral">{esc(t)}</span>'
                    for t in it.get("tag_list", [])[:3])
    opts = "".join(f'<span class="item-opt">{esc(o)}</span>'
                   for o in it.get("option_list", [])[:4])

    price_html = ""
    if prices_on:
        price_html = esc(it["price_text"])
        if it.get("has_discount"):
            price_html = f'<s>{esc(it["old_price_text"])}</s>{price_html}'

    cta = ""
    if not prices_on:
        if it["price_type"] == "call" or it["kind"] == "custom":
            cta = (f'<a class="btn btn-accent btn-sm" href="/b/{esc(it["bizslug"])}/chat">'
                   f'{icon("message")}<span>گفتگو با دکان‌دار</span></a>')
        else:
            cta = (f'<a class="btn btn-glass btn-sm" href="/b/{esc(it["bizslug"])}">'
                   f'{icon("store")}<span>مشاهدهٔ فروشگاه</span></a>')
    elif it["price_type"] == "call" or it["kind"] == "custom":
        cta = (f'<a class="btn btn-accent btn-sm" href="/b/{esc(it["bizslug"])}/chat">'
               f'{icon("message")}<span>گفتگو با دکان‌دار</span></a>')
    elif db.haggle_allowed(it):
        # the whole point of the feature: the offer is one tap from the price
        cta = (f'<a class="btn btn-accent btn-sm" href="/haggle/{it["id"]}">'
               f'{icon("tag")}<span>پیشنهاد قیمت</span></a>')
    elif it.get("price"):
        # fixed-price product -> real ordering, not just a phone number
        cta = (f'<button class="btn btn-primary btn-sm" type="button" data-add-cart'
               f' data-id="{it["id"]}" data-title="{esc(it["title"])}"'
               f' data-price="{int(it["price"])}" data-biz="{it.get("biz_id") or ""}"'
               f' data-bizname="{esc(it.get("bizname") or "")}">'
               f'{icon("cart")}<span>افزودن به سبد</span></button>')

    note = (f'<div class="item-note">{icon("info")}<span>{esc(it["note"])}</span></div>'
            if it.get("note") else "")

    return f'''<article class="item-card card card-hover tilt reveal-3d" data-tilt="5" data-delay="{delay}">
  <span class="sheen" aria-hidden="true"></span>
  <div class="item-media"><a class="item-media-link" href="/item/{it['id']}" aria-label="مشاهدهٔ {esc(it['title'])}">{img}</a>
    <div class="media-badges layer-2">{badges}</div>{more}</div>
  <div class="card-body layer-1">
    <h3 class="card-title"><a href="/item/{it['id']}">{esc(it["title"])}</a></h3>
    {f'<p class="card-desc">{esc(it["descr"])}</p>' if it.get("descr") else ''}
    {f'<div class="item-opts">{opts}</div>' if opts else ''}
    {f'<div class="item-flags">{flags}</div>' if flags else ''}
    <div class="cluster mt-sm">{chips}</div>
    {note}
    <div class="item-foot{' prices-hidden' if not prices_on else ''}">
      {f'<strong class="item-price nums">{price_html}</strong>' if price_html else ''}
      {cta}
    </div>
    {f'<div class="cluster mt-sm">{meta}</div>' if meta else ''}
  </div>
</article>'''


def catalog_section(biz, token="", prices_on=True):
    """Rendered inside the business detail page."""
    rows = db.items(biz_id=biz["id"], only_available=False)
    if not rows:
        return ""
    groups = [("product", "محصولات"), ("service", "خدمات"), ("custom", "کارهای سفارشی")]
    out = ""
    for kind, label in groups:
        sub = [r for r in rows if r["kind"] == kind]
        if not sub:
            continue
        cards = "".join(item_card(r, delay=i * 50, prices_on=prices_on)
                        for i, r in enumerate(sub))
        out += f'''<section class="card glass card-pad mt-lg reveal">
          <div class="between mb-lg">
            <h2 class="card-title">{icon(KIND_ICON[kind])} {label}</h2>
            <span class="badge badge-neutral">{fa(len(sub))} مورد</span>
          </div>
          <div class="item-grid">{cards}</div>
        </section>'''
    return out


# ==========================================================================
#  PUBLIC — city-wide catalog browser
# ==========================================================================
def browse(s, q="", kind="", token=""):
    cats = db.category_tree()
    rows = db.search_items(term=q, kind=kind)
    prices_on = s.get("prices_enabled") == "1"

    chips = "".join(
        f'<a class="chip{" is-active" if kind == k else ""}" '
        f'href="/catalog?kind={k}{"&q=" + esc(q) if q else ""}">{icon(ic)}<span>{lbl}</span></a>'
        for k, lbl, ic in [("", "همه", "grid"), ("product", "محصولات", "shopping"),
                           ("service", "خدمات", "zap"), ("custom", "کارهای سفارشی", "sparkles")])

    if rows:
        grid = f'<div class="item-grid lg">{"".join(item_card(r, show_biz=True, delay=(i % 8) * 40, prices_on=prices_on) for i, r in enumerate(rows))}</div>'
    else:
        grid = empty_state("search", "موردی پیدا نشد",
                           "عبارت جست‌وجو یا نوع را تغییر دهید."
                           if (q or kind) else
                           "هنوز کسب‌وکاری محصول یا خدمتی ثبت نکرده است.")

    base = (s.get("site_url") or "").strip().rstrip("/")
    if base and not base.startswith(("http://", "https://")):
        base = "https://" + base
    head_extra = ""
    if s.get("seo_schema") == "1":
        # Breadcrumb + a city-wide ItemList so the products feed itself can
        # be understood as a catalogue (E-Commerce SEO).
        _ld_objs = [db.jsonld_breadcrumb([("خانه", "/"), ("محصولات و خدمات", "/catalog")], base),
                    {"@context": "https://schema.org", "@type": "ItemList",
                     "itemListElement": [
                        {"@type": "ListItem", "position": i + 1, "name": it.get("title"),
                         "url": f"{base}/b/{it.get('bizslug')}"}
                        for i, it in enumerate(rows[:30])]}]
        head_extra = "".join(
            '<script type="application/ld+json">' + json_embed(o) + '</script>'
            for o in _ld_objs)
    body = f'''
<div class="container-wide">
  {breadcrumb(("محصولات و خدمات", None))}
  <header class="page-hero">
    <span class="eyebrow">{icon("shopping")}<span>ویترین شهر</span></span>
    <h1>محصولات و خدمات نجف‌آباد</h1>
    <p>هر آنچه کسب‌وکارهای شهر ارائه می‌دهند — از محصول آماده تا کار کاملاً سفارشی.</p>
  </header>
</div>
<section class="section-sm"><div class="container-wide">
  <form class="dir-toolbar" method="get" action="/catalog" data-live-search>
    <input type="hidden" name="kind" value="{esc(kind)}">
    <div class="dir-row">
      <span class="search-wrap">{icon("search", cls="search-icon")}
        <label class="sr-only" for="cq">جست‌وجو</label>
        <input class="input" id="cq" name="q" type="search" value="{esc(q)}"
               placeholder="نام محصول، خدمت یا کسب‌وکار…" autocomplete="off"
               aria-autocomplete="list">
        <div class="live-sugg" hidden></div></span>
      <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
    </div>
    <div class="dir-chips">{chips}</div>
  </form>
  <div class="dir-meta">
    <span><strong class="nums">{fa(len(rows))}</strong> مورد یافت شد</span>
  </div>
  {grid}
</div></section>'''
    return page(s, "محصولات و خدمات", body, "/catalog", token=token, cats=cats,
                extra_head=head_extra)


# ==========================================================================
#  PUBLIC — full product/service detail
# ==========================================================================
def item_detail(s, item_id, token=""):
    it=db.item(item_id)
    if not it or not it.get("bizslug"): return None
    biz=db.business(bid=it["biz_id"])
    if not biz or biz.get("status")!="published": return None
    prices_on=s.get("prices_enabled")=="1"
    imgs=it.get("image_list") or ([it.get("image")] if it.get("image") else [])
    gallery=(f'<div class="item-detail-media"><img src="{esc(imgs[0])}" alt="{esc(it["title"])}"></div>' if imgs else
             f'<div class="item-detail-media item-ph">{icon(KIND_ICON.get(it["kind"],"shopping"))}</div>')
    specs="".join(f'<div class="info-row"><span class="k">{esc(k)}</span><strong class="v">{esc(v)}</strong></div>' for k,v in (it.get("spec_rows") or []))
    price=(f'<div class="item-detail-price nums">{esc(it["price_text"])}</div>' if prices_on else '')
    buy=''
    if prices_on and it.get("price") and it.get("available"):
        buy=f'''<div class="item-buy" data-item-buy>
          <label for="item-qty-{it['id']}">تعداد</label>
          <input class="input item-qty nums" id="item-qty-{it['id']}" type="number" min="1" max="99" value="1" data-cart-qty>
          <button class="btn btn-primary" type="button" data-add-cart data-id="{it['id']}" data-title="{esc(it['title'])}" data-price="{int(it['price'])}" data-biz="{it['biz_id']}" data-bizname="{esc(it.get('bizname') or biz['name'])}">{icon("cart")}<span>افزودن به سبد</span></button></div>'''
    elif not prices_on:
        buy=f'<a class="btn btn-primary" href="/b/{esc(biz["slug"])}">{icon("store")}<span>مشاهده و ارتباط با فروشگاه</span></a>'
    body=f'''<div class="container-wide" data-item-detail>
      {breadcrumb(("محصولات","/catalog"),(it["title"],None))}
      <section class="item-detail-grid section-sm"><div>{gallery}</div>
        <div class="card glass card-pad item-detail-copy">
          <span class="eyebrow">{icon(KIND_ICON.get(it["kind"],"shopping"))}<span>{esc(it["kind_label"])}</span></span>
          <h1>{esc(it["title"])}</h1><p>{esc(it.get("descr") or "")}</p>{price}
          <a class="item-store-link" href="/b/{esc(biz['slug'])}">{icon("store")}<span>{esc(biz['name'])}</span>{icon("chevron-left")}</a>
          {f'<div class="item-specs">{specs}</div>' if specs else ''}{buy}
        </div></section></div>'''
    return page(s,it["title"],body,"/catalog",token=token,cats=db.category_tree())


# ==========================================================================
#  OWNER — manage catalog
# ==========================================================================
def manage(s, owner, bid, q=None, admin_token=""):
    biz = db.business(bid=bid)
    if not biz:
        return None
    if not admin_token and biz.get("owner_id") != owner["id"]:
        return None

    rows = db.items(biz_id=bid)
    base = "/panel/catalog" if admin_token else "/my/catalog"
    K = f'<input type="hidden" name="key" value="{esc(admin_token)}">' if admin_token else ""
    kq = f"?key={esc(admin_token)}" if admin_token else ""

    trs = "".join(f'''<tr>
      <td><div style="display:flex;align-items:center;gap:10px">
        {f'<img src="{esc(it["image"])}" alt="" width="40" height="40" style="border-radius:8px;object-fit:cover">' if it.get("image") else f'<span class="stat-icon" style="width:40px;height:40px">{icon(KIND_ICON.get(it["kind"],"tag"))}</span>'}
        <div><strong>{esc(it["title"])}</strong><br>
          <small class="text-muted">{esc(it["kind_label"])}</small></div></div></td>
      <td class="num">{esc(it["price_text"])}</td>
      <td>{'<span class="badge badge-open">موجود</span>' if it["available"] else '<span class="badge badge-closed">ناموجود</span>'}</td>
      <td>{'<span class="badge badge-featured">ویژه</span>' if it["featured"] else '<span class="text-muted text-xs">—</span>'}</td>
      <td class="actions">
        <a class="btn-icon" href="{base}/{bid}/item/{it['id']}{kq}"
           aria-label="ویرایش {esc(it['title'])}" title="ویرایش">{icon("edit")}</a>
        <form method="post" action="{base}/{bid}/item/{it['id']}/delete" style="display:inline"
              data-confirm="حذف «{esc(it['title'])}»؟">{K}
          <button class="btn-icon" type="submit" aria-label="حذف {esc(it['title'])}"
            title="حذف" style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for it in rows)

    if not trs:
        trs = f'''<tr><td colspan="5"><div class="empty-state" style="padding:var(--space-2xl)">
          <span class="icon-wrap">{icon("shopping")}</span>
          <h3>هنوز محصول یا خدمتی ثبت نشده</h3>
          <p>محصولات، خدمات و کارهای سفارشی خود را اضافه کنید تا مشتریان
             دقیقاً بدانند چه ارائه می‌دهید.</p></div></td></tr>'''

    n_prod = sum(1 for r in rows if r["kind"] == "product")
    n_serv = sum(1 for r in rows if r["kind"] == "service")
    n_cust = sum(1 for r in rows if r["kind"] == "custom")

    content = f'''{_msg(q)}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("layers", len(rows), "کل موارد")}
  {stat_card("shopping", n_prod, "محصول", delay=60)}
  {stat_card("zap", n_serv, "خدمت", delay=120)}
  {stat_card("sparkles", n_cust, "کار سفارشی", delay=180)}
</div>

<div class="card glass card-pad mb-lg">
  <div class="between mb-lg">
    <h2 class="card-title">{icon("shopping")} کاتالوگ {esc(biz["name"])}</h2>
    <a class="btn btn-primary" href="{base}/{bid}/item/new{kq}">
      {icon("plus")}<span>افزودن مورد</span></a>
  </div>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>عنوان</th><th>قیمت</th><th>موجودی</th><th>ویژه</th><th>عملیات</th></tr></thead>
    <tbody>{trs}</tbody></table></div>
</div>

<div class="alert alert-info">{icon("info")}
  <span>برای کارهایی که قیمت ثابت ندارند، نوع «کار سفارشی» و حالت قیمت
    «قیمت با تماس» را انتخاب کنید — مشتری به‌جای قیمت، دکمهٔ «گفتگو با دکان‌دار» می‌بیند.</span></div>'''

    title = f"کاتالوگ: {biz['name']}"
    sub = "محصولات، خدمات و کارهای سفارشی خود را مدیریت کنید."
    if admin_token:
        from ui import panel_page
        return panel_page(s, title, sub, content, "/panel/businesses", admin_token)
    from views_owner import shell
    return shell(s, title, sub, content, "/my/businesses", owner)


def item_edit(s, owner, bid, iid=None, q=None, admin_token=""):
    biz = db.business(bid=bid)
    if not biz:
        return None
    if not admin_token and biz.get("owner_id") != owner["id"]:
        return None

    it = db.item(iid) if iid else None
    if it and it["biz_id"] != bid:
        return None
    new = it is None
    v = lambda k, d="": esc(it.get(k, d)) if it else esc(d)
    num = lambda k: (it.get(k) if it and it.get(k) else "")

    base = "/panel/catalog" if admin_token else "/my/catalog"
    K = f'<input type="hidden" name="key" value="{esc(admin_token)}">' if admin_token else ""
    kq = f"?key={esc(admin_token)}" if admin_token else ""

    kinds = "".join(
        f'<option value="{k}"{" selected" if it and it["kind"] == k else ""}>{lbl}</option>'
        for k, lbl in [("product", "محصول"), ("service", "خدمت"), ("custom", "کار سفارشی")])
    ptypes = "".join(
        f'<option value="{k}"{" selected" if it and it["price_type"] == k else ""}>{lbl}</option>'
        for k, lbl in [("fixed", "قیمت ثابت"), ("from", "شروع از"),
                       ("call", "قیمت با تماس"), ("free", "رایگان")])

    existing = json_embed(it["image_list"] if it else [])
    stock_val = "" if (not it or not it.get("stock_tracked")) else it["stock"]

    content = f'''{_msg(q)}
<form method="post" action="{base}/{bid}/item/{iid or 'new'}"
      enctype="multipart/form-data" data-validate>
  {K}

  <div class="form-grid">
    <div class="form-main">

      <div class="card glass card-pad mb-lg">
        <h2 class="card-title mb-lg">{icon("tag")} مشخصات اصلی</h2>
        <div class="grid grid-2" style="gap:0 var(--space-md)">
          <div class="field"><label class="field-label" for="i-kind">نوع<span class="req">*</span></label>
            <select class="select" id="i-kind" name="kind" required data-kind>{kinds}</select>
            <p class="field-hint">«کار سفارشی» برای کارهایی که قیمت ثابت ندارند.</p></div>
          <div class="field"><label class="field-label" for="i-title">عنوان<span class="req">*</span></label>
            <input class="input" id="i-title" name="title" required minlength="2" value="{v('title')}"
                   placeholder="مثلاً: چلوکباب کوبیده"></div>
        </div>
        <div class="field"><label class="field-label" for="i-desc">توضیحات</label>
          <textarea class="textarea" id="i-desc" name="descr" style="min-height:120px"
            placeholder="جزئیات، مواد اولیه، شرایط…">{v('descr')}</textarea></div>
        <div class="grid grid-2" style="gap:0 var(--space-md)">
          <div class="field"><label class="field-label" for="i-tags">برچسب‌ها</label>
            <input class="input" id="i-tags" name="tags" value="{v('tags')}"
                   placeholder="تند، گیاهی، ویژه"></div>
          <div class="field"><label class="field-label" for="i-opts">گزینه‌ها / تنوع</label>
            <input class="input" id="i-opts" name="options" value="{v('options')}"
                   placeholder="کوچک، متوسط، بزرگ">
            <p class="field-hint">با ویرگول جدا کنید.</p></div>
        </div>
      </div>

      <div class="card glass card-pad mb-lg">
        <h2 class="card-title mb-lg">{icon("image")} تصاویر</h2>
        <div data-imagefield data-name="images" data-max="6"
             data-existing='{existing}'></div>
      </div>

      <div class="card glass card-pad mb-lg">
        <h2 class="card-title mb-lg">{icon("wallet")} قیمت</h2>
        <div class="grid grid-3" style="gap:0 var(--space-md)">
          <div class="field"><label class="field-label" for="i-ptype">نحوهٔ قیمت‌گذاری</label>
            <select class="select" id="i-ptype" name="price_type" data-ptype>{ptypes}</select></div>
          <div class="field" data-price-field><label class="field-label" for="i-price">قیمت (تومان)</label>
            <input class="input nums" id="i-price" name="price" inputmode="numeric"
                   data-money value="{num('price')}" placeholder="۲۵۰٬۰۰۰"></div>
          <div class="field" data-price-field><label class="field-label" for="i-old">قیمت قبلی</label>
            <input class="input nums" id="i-old" name="old_price" inputmode="numeric"
                   data-money value="{num('old_price')}" placeholder="اختیاری">
            <p class="field-hint">برای نمایش تخفیف، خط‌خورده نشان داده می‌شود.</p></div>
        </div>
        <div class="grid grid-2" style="gap:0 var(--space-md)">
          <div class="field" data-price-field><label class="field-label" for="i-unit">واحد</label>
            <input class="input" id="i-unit" name="unit" value="{v('unit')}"
                   placeholder="هر پرس / هر متر / هر جلسه"></div>
          <div class="field" data-service-field><label class="field-label" for="i-dur">مدت زمان</label>
            <input class="input" id="i-dur" name="duration" value="{v('duration')}"
                   placeholder="۴۵ دقیقه"></div>
        </div>
      </div>

      <div class="card glass card-pad mb-lg">
        <h2 class="card-title mb-lg">{icon("box")} موجودی و سفارش</h2>
        <div class="grid grid-3" style="gap:0 var(--space-md)">
          <div class="field"><label class="field-label" for="i-stock">تعداد موجودی</label>
            <input class="input nums" id="i-stock" name="stock" inputmode="numeric"
                   value="{stock_val}" placeholder="خالی = نامحدود"></div>
          <div class="field"><label class="field-label" for="i-min">حداقل سفارش</label>
            <input class="input" id="i-min" name="min_order" value="{v('min_order')}"
                   placeholder="مثلاً ۲ عدد"></div>
          <div class="field"><label class="field-label" for="i-code">کد کالا</label>
            <input class="input" id="i-code" name="code" value="{v('code')}"
                   placeholder="اختیاری"></div>
        </div>
        <div class="field" style="margin-bottom:0">
          <label class="field-label" for="i-note">یادداشت برای مشتری</label>
          <input class="input" id="i-note" name="note" value="{v('note')}"
                 placeholder="مثلاً: ۲۴ ساعت قبل سفارش دهید">
        </div>
      </div>

      <div class="card glass card-pad mb-lg">
        <h2 class="card-title mb-lg">{icon("shield")} اعتماد و ارسال</h2>
        <p class="text-sm text-muted mb-lg">این‌ها همان چیزهایی است که مشتری
          پیش از خرید دنبالش می‌گردد. هرچه بیشتر پر کنید، بیشتر فروش می‌رود.</p>
        <div class="grid grid-2" style="gap:0 var(--space-md)">
          <div class="field"><label class="field-label" for="i-brand">برند / سازنده</label>
            <input class="input" id="i-brand" name="brand" value="{v('brand')}"
                   placeholder="مثلاً: تولید خودمان"></div>
          <div class="field"><label class="field-label" for="i-warr">گارانتی یا ضمانت</label>
            <input class="input" id="i-warr" name="warranty" value="{v('warranty')}"
                   placeholder="مثلاً: ۶ ماه ضمانت تعویض"></div>
          <div class="field"><label class="field-label" for="i-prep">زمان آماده‌سازی</label>
            <input class="input" id="i-prep" name="prep_days" value="{v('prep_days')}"
                   placeholder="مثلاً: ۲ روز کاری"></div>
          <div class="field"><label class="field-label" for="i-del">نحوهٔ تحویل</label>
            <input class="input" id="i-del" name="delivery" value="{v('delivery')}"
                   placeholder="مثلاً: پیک رایگان در شهر"></div>
          <div class="field"><label class="field-label" for="i-weight">وزن / اندازه</label>
            <input class="input" id="i-weight" name="weight" value="{v('weight')}"
                   placeholder="مثلاً: ۵۰۰ گرم"></div>
          <div class="field"><label class="field-label" for="i-bulk">قیمت عمده</label>
            <input class="input" id="i-bulk" name="bulk_price" value="{v('bulk_price')}"
                   placeholder="مثلاً: بالای ۱۰ عدد ۱۵٪ تخفیف"></div>
        </div>
        <div class="field">
          <label class="field-label" for="i-spec">مشخصات فنی</label>
          <textarea class="textarea" id="i-spec" name="spec" style="min-height:84px"
            placeholder="هر خط یک مورد — مثلاً:&#10;رنگ = قرمز&#10;جنس = پنبه">{v('spec')}</textarea>
          <p class="field-hint">با «=» بنویسید تا مرتب و جدولی نمایش داده شود.</p>
        </div>
        <div class="field" style="margin-bottom:0">
          <label class="field-label" for="i-video">لینک ویدئوی کوتاه</label>
          <input class="input" id="i-video" name="video" dir="ltr" value="{v('video')}"
                 placeholder="آپارات یا هر لینک ویدئو — اختیاری">
        </div>
        <div class="cluster mt-lg">
          <label class="check"><input type="checkbox" name="handmade"
            {" checked" if it and it["handmade"] else ""}><span>دست‌ساز است</span></label>
          <label class="check"><input type="checkbox" name="returnable"
            {" checked" if it and it["returnable"] else ""}><span>قابل مرجوع کردن</span></label>
        </div>
      </div>

      <div class="card glass card-pad mb-lg">
        <h2 class="card-title mb-md">{icon("tag")} چانه‌زنی</h2>
        <p class="text-sm text-muted mb-lg">اگر باز باشد، مشتری می‌تواند مثل
          خرید حضوری قیمت پیشنهاد بدهد. «کف قیمت» را فقط شما می‌بینید — هر
          پیشنهادی برابر یا بالاتر از آن، <strong>خودکار پذیرفته می‌شود</strong>،
          حتی وقتی گوشی دستتان نیست.</p>
        <label class="switch mb-md"><input type="checkbox" name="haggle"
          {" checked" if it and it["haggle"] else ""}><span class="track"></span>
          <span>مشتری بتواند برای این کالا قیمت پیشنهاد بدهد</span></label>
        <div class="field" style="margin-bottom:0">
          <label class="field-label" for="i-floor">کف قیمت شما (تومان)</label>
          <input class="input nums" id="i-floor" name="floor_price" inputmode="numeric"
                 value="{num('floor_price')}" placeholder="کمترین قیمتی که راضی‌کننده است">
          <p class="field-hint">این عدد هرگز به مشتری نشان داده نمی‌شود. اگر
            خالی بماند، هر پیشنهادی برای تأیید دستی به شما می‌رسد.</p>
        </div>
      </div>
    </div>

    <aside class="form-side">
      <div class="card glass card-pad">
        <h2 class="card-title mb-lg">{icon("settings")} وضعیت</h2>
        <label class="switch mb-md"><input type="checkbox" name="available"
          {" checked" if (not it or it["available"]) else ""}><span class="track"></span>
          <span>موجود / قابل ارائه</span></label>
        <label class="switch mb-md"><input type="checkbox" name="featured"
          {" checked" if it and it["featured"] else ""}><span class="track"></span>
          <span>نمایش به‌عنوان ویژه</span></label>
        <div class="field" style="margin-bottom:0">
          <label class="field-label" for="i-sort">ترتیب نمایش</label>
          <input class="input nums" id="i-sort" name="sort" type="number"
                 value="{it['sort'] if it else 0}">
          <p class="field-hint">عدد کوچک‌تر، بالاتر.</p>
        </div>
      </div>

      <div class="card glass card-pad mt-md">
        <h3 class="card-title mb-md">{icon("eye")} پیش‌نمایش</h3>
        <div class="item-preview" data-preview-card>
          <div class="ip-media" data-pv-img><span>{icon("image")}</span></div>
          <div class="ip-body">
            <strong data-pv-title>عنوان محصول</strong>
            <div class="ip-price nums" data-pv-price>—</div>
          </div>
        </div>
        <p class="field-hint mt-sm">تقریبی — همان‌طور که مشتری می‌بیند.</p>
      </div>

      <div class="form-actions mt-md">
        <button class="btn btn-primary btn-lg btn-block" type="submit">
          {icon("check")}<span>{"افزودن به کاتالوگ" if new else "ذخیرهٔ تغییرات"}</span></button>
        <a class="btn btn-ghost btn-block mt-sm" href="{base}/{bid}{kq}">
          {icon("x")}<span>انصراف</span></a>
      </div>
    </aside>
  </div>
</form>
<script type="module" src="/assets/js/imagefield.js?v109"></script>
<script type="module" src="/assets/js/itemform.js?v109"></script>'''

    title = "افزودن مورد جدید" if new else f"ویرایش: {it['title']}"
    sub = "محصول، خدمت یا کار سفارشی."
    if admin_token:
        from ui import panel_page
        return panel_page(s, title, sub, content, "/panel/businesses", admin_token)
    from views_owner import shell
    return shell(s, title, sub, content, "/my/businesses", owner)


# ==========================================================================
#  OWNER — inquiries inbox
# ==========================================================================
def inquiry_list(s, owner, q=None, admin_token=""):
    if admin_token:
        rows = db.inquiries()
    else:
        mine = {b["id"] for b in db.businesses_of(owner["id"])}
        rows = [r for r in db.inquiries() if r["biz_id"] in mine]

    base = "/panel/inquiry" if admin_token else "/my/inquiry"
    K = f'<input type="hidden" name="key" value="{esc(admin_token)}">' if admin_token else ""
    BADGE = {"new": "badge-warn", "quoted": "badge-info",
             "won": "badge-open", "lost": "badge-closed"}
    LABEL = {"new": "جدید", "quoted": "پاسخ‌داده‌شده",
             "won": "انجام شد", "lost": "منتفی"}

    # Privacy (v65): the customer's phone number is shown to the ADMIN only.
    # A shopkeeper sees the message and the name, never the number.
    def _phone_meta(r):
        if admin_token and r.get("phone"):
            return (f'<span aria-hidden="true">·</span>'
                    f'<a href="tel:{esc(r["phone"])}" class="nums">{esc(r["phone"])}</a>')
        return (f'<span aria-hidden="true">·</span>'
                f'<span class="text-muted">شمارهٔ تماس: محرمانه</span>')

    items = "".join(f'''<article class="review">
      <div class="review-head">
        <span class="avatar" aria-hidden="true">{esc(r['name'][:1])}</span>
        <div style="flex:1"><strong>{esc(r['name'])}</strong>
          <div class="card-meta" style="margin-top:3px">
            {f'<span>{esc(r["itemtitle"])}</span><span aria-hidden="true">·</span>' if r.get("itemtitle") else ''}
            <span>{esc(str(r['created'])[:16])}</span>
            {_phone_meta(r)}</div></div>
        <span class="badge {BADGE.get(r['status'],'badge-neutral')}">{LABEL.get(r['status'],r['status'])}</span>
      </div>
      <p class="review-body">{esc(r['body'])}</p>
      {f'<div class="text-xs text-muted mt-sm">بودجهٔ اعلامی: {esc(r["budget"])}</div>' if r.get("budget") else ''}
      {f'<div class="review-reply"><strong>{icon("tag")}پاسخ شما</strong>{esc(r["quote"])}</div>' if r.get("quote") else ''}
      <form method="post" action="{base}/{r['id']}" class="mt-md">{K}
        <label class="sr-only" for="qt{r['id']}">پاسخ شما</label>
        <input class="input" id="qt{r['id']}" name="quote" value="{esc(r['quote'])}"
               placeholder="پاسخ خود را بنویسید…">
        <div class="cluster mt-sm">
          <button class="btn btn-primary btn-sm" type="submit" name="action" value="quote">
            {icon("send")}<span>ثبت پاسخ</span></button>
          <button class="btn btn-glass btn-sm" type="submit" name="action" value="won">
            {icon("check")}<span>انجام شد</span></button>
          <button class="btn btn-ghost btn-sm" type="submit" name="action" value="lost">
            {icon("x")}<span>منتفی</span></button>
          <button class="btn btn-ghost btn-sm" type="submit" name="action" value="delete"
            style="color:var(--color-destructive)">{icon("trash")}<span>حذف</span></button>
        </div>
      </form></article>''' for r in rows)

    if not items:
        items = empty_state("message", "پیامی ثبت نشده",
                            "وقتی مشتری از صفحهٔ کسب‌وکارتان پیام بفرستد، اینجا می‌بینید.")

    n_new = sum(1 for r in rows if r["status"] == "new")
    content = f'''{_msg(q)}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("message", len(rows), "کل پیام‌ها")}
  {stat_card("bell", n_new, "جدید", delay=60)}
  {stat_card("check-circle", sum(1 for r in rows if r["status"] == "won"), "انجام‌شده", delay=120)}
  {stat_card("tag", sum(1 for r in rows if r["status"] == "quoted"), "پاسخ‌داده‌شده", delay=180)}
</div>
<div class="card glass card-pad">{items}</div>'''

    title = "پیام‌های مشتریان"
    sub = "پیام‌هایی که مشتریان از صفحهٔ کسب‌وکار شما فرستاده‌اند."
    if admin_token:
        from ui import panel_page
        return panel_page(s, title, sub, content, "/panel/inquiries", admin_token)
    from views_owner import shell
    return shell(s, title, sub, content, "/my/inquiries", owner)
