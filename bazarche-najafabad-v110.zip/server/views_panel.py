# -*- coding: utf-8 -*-
"""Owner control panel — full authority over every part of the site."""

import json
from urllib.parse import urlencode
import db
from ui import (icon, stars, fa, fa_group, esc, panel_page, stat_card, flash, cat_icon,
                cat_options, json_embed)

ICON_CHOICES = ["store","restaurant","cafe","bakery","confectionery","shopping",
                "clothing","jewellery","medical","auto","realestate","barber",
                "education","mobile","gym","homeservice","flowers","photography",
                "pin","map","compass","mosque"]

DAYS = [("sat","شنبه"),("sun","یک‌شنبه"),("mon","دوشنبه"),("tue","سه‌شنبه"),
        ("wed","چهارشنبه"),("thu","پنج‌شنبه"),("fri","جمعه")]

MAP_JS = '<script type="module" src="/assets/js/mappage.js?v109"></script>'


def _msg(q):
    if q.get("ok"):
        return flash("ok", q["ok"][0])
    if q.get("err"):
        return flash("err", q["err"][0])
    return ""


# ------------------------------------------------------------------ dashboard
def approve_btn(b, token, back=""):
    """Approve / reject controls, shown only where they make sense."""
    bid = b["id"]
    hidden = (f'<input type="hidden" name="key" value="{esc(token)}">'
              f'<input type="hidden" name="back" value="{esc(back)}">')
    if b["status"] == "pending":
        return (f'<form method="post" action="/panel/business/{bid}/status" style="display:inline">'
                f'{hidden}<input type="hidden" name="status" value="published">'
                f'<button class="btn-icon btn-approve" type="submit" title="تأیید و انتشار"'
                f' aria-label="تأیید {esc(b["name"])}">{icon("check-circle")}</button></form>'
                f'<form method="post" action="/panel/business/{bid}/status" style="display:inline"'
                f' data-confirm="درخواست «{esc(b["name"])}» رد شود؟">'
                f'{hidden}<input type="hidden" name="status" value="rejected">'
                f'<button class="btn-icon" type="submit" title="رد درخواست"'
                f' aria-label="رد {esc(b["name"])}" style="color:var(--color-destructive)">'
                f'{icon("x-circle")}</button></form>')
    if b["status"] == "published":
        return (f'<form method="post" action="/panel/business/{bid}/status" style="display:inline">'
                f'{hidden}<input type="hidden" name="status" value="hidden">'
                f'<button class="btn-icon" type="submit" title="مخفی کردن"'
                f' aria-label="مخفی کردن {esc(b["name"])}">{icon("eye")}</button></form>')
    # hidden or rejected -> offer to publish
    return (f'<form method="post" action="/panel/business/{bid}/status" style="display:inline">'
            f'{hidden}<input type="hidden" name="status" value="published">'
            f'<button class="btn-icon btn-approve" type="submit" title="انتشار"'
            f' aria-label="انتشار {esc(b["name"])}">{icon("check-circle")}</button></form>')


def pending_box(s, token):
    """Big, unmissable queue of businesses waiting for a decision."""
    waiting = db.businesses(status="pending", order="newest")
    if not waiting:
        return ""
    cat_names = {c["slug"]: c["name"] for c in db.categories(only_active=False)}
    cards = "".join(f'''<div class="pending-card">
      <div class="pending-main">
        <strong>{esc(b["name"])}</strong>
        <div class="text-xs text-muted">{esc(cat_names.get(b.get("cat_slug"), b.get("cat_slug")))} · {esc(b.get("address") or "بدون نشانی")}</div>
        <p class="text-sm text-muted mt-sm">{esc((b.get("descr") or "")[:150])}</p>
        <div class="cluster mt-sm">
          {f'<span class="badge badge-neutral">{icon("phone")}<span class="nums">{esc(b["phone"])}</span></span>' if b.get("phone") else ""}
          <span class="badge badge-neutral">{icon("calendar")}<span>{esc(str(b["created"])[:10])}</span></span>
        </div>
      </div>
      <div class="pending-actions">
        <a class="btn btn-glass btn-sm" href="/panel/business/{b["id"]}?key={esc(token)}">
          {icon("edit")}<span>بررسی و ویرایش</span></a>
        <form method="post" action="/panel/business/{b["id"]}/status">
          <input type="hidden" name="key" value="{esc(token)}">
          <input type="hidden" name="status" value="published">
          <button class="btn btn-primary btn-sm btn-block" type="submit">
            {icon("check")}<span>تأیید و انتشار</span></button></form>
        <form method="post" action="/panel/business/{b["id"]}/status"
              data-confirm="درخواست «{esc(b["name"])}» رد شود؟">
          <input type="hidden" name="key" value="{esc(token)}">
          <input type="hidden" name="status" value="rejected">
          <button class="btn btn-ghost btn-sm btn-block" type="submit"
                  style="color:var(--color-destructive)">{icon("x")}<span>رد</span></button></form>
      </div>
    </div>''' for b in waiting)
    return f'''<div class="card glass card-pad mb-lg pending-box">
      <div class="between mb-lg">
        <h2 class="card-title">{icon("bell")} در انتظار تأیید شما</h2>
        <span class="badge badge-warn">{fa(len(waiting))} درخواست</span>
      </div>
      <p class="text-sm text-muted mb-lg">این کسب‌وکارها را کاربران ثبت کرده‌اند و
        تا تأیید شما روی سایت دیده نمی‌شوند.</p>
      <div class="pending-list">{cards}</div>
    </div>'''


def dashboard(s, token, q=None):
    st = db.stats()
    recent_biz = db.businesses(status=None, order="newest", limit=5)
    pend_rev = db.reviews(status="pending")[:5]
    new_book = [b for b in db.bookings() if b["status"] == "new"][:5]

    rows = "".join(f'''<tr><td><strong>{esc(b['name'])}</strong><br>
      <small class="text-muted">{esc(b['cat_slug'])}</small></td>
      <td class="num">{fa(b['views'])}</td>
      <td><span class="badge {"badge-open" if b['status']=='published' else "badge-warn"}">
        {esc({"published":"منتشرشده","pending":"در انتظار تأیید","hidden":"مخفی","rejected":"رد شده"}.get(b['status'],b['status']))}</span></td>
      <td class="actions"><a class="btn-icon" href="/panel/business/{b['id']}?key={esc(token)}"
        aria-label="ویرایش {esc(b['name'])}">{icon("edit")}</a></td></tr>'''
      for b in recent_biz) or '<tr><td colspan="4" class="text-center text-muted">هنوز کسب‌وکاری ثبت نشده</td></tr>'

    todo = ""
    if st["pending_biz"]:
        todo += f'<a class="todo-item" href="/panel/businesses?key={esc(token)}&status=pending">{icon("clock")}<span>{fa(st["pending_biz"])} کسب‌وکار در انتظار تأیید</span>{icon("chevron-left")}</a>'
    if st["pending_reviews"]:
        todo += f'<a class="todo-item" href="/panel/reviews?key={esc(token)}&status=pending">{icon("message")}<span>{fa(st["pending_reviews"])} نظر در انتظار بررسی</span>{icon("chevron-left")}</a>'
    if st["new_bookings"]:
        todo += f'<a class="todo-item" href="/panel/bookings?key={esc(token)}">{icon("calendar")}<span>{fa(st["new_bookings"])} نوبت جدید</span>{icon("chevron-left")}</a>'
    if st["new_messages"]:
        todo += f'<a class="todo-item" href="/panel/messages?key={esc(token)}">{icon("mail")}<span>{fa(st["new_messages"])} پیام خوانده‌نشده</span>{icon("chevron-left")}</a>'
    if not todo:
        todo = f'<div class="alert alert-success">{icon("check-circle")}<span>همه‌چیز مرتب است — کار معوقی ندارید.</span></div>'

    # ---- admin insight: market gaps (zero-result searches) + a revenue/growth
    # snapshot. The most useful thing a directory operator sees is what people
    # are looking for and cannot find — that is which trade to recruit next.
    _zrows = "".join(
        f'<tr><td><strong>{esc(r["term"])}</strong></td>'
        f'<td class="num nums">{fa(r["n"])}</td></tr>'
        for r in db.top_searches(days=30, limit=6, zero_only=True))
    _st_search = db.search_totals(30)
    _revenue = sum(x["amount"] for x in db.subscriptions(status="active"))
    _live = len([x for x in db.subscriptions(status="active") if x["is_live"]])
    _gap_card = f'''<div class="card glass card-pad mb-lg">
  <div class="between mb-md">
    <h2 class="card-title">{icon("search")} جست‌وجوهای بی‌نتیجه</h2>
    <a class="btn btn-glass btn-sm" href="/panel/insights?key={esc(token)}">{icon("chart")}<span>جزئیات</span></a>
  </div>
  <p class="text-sm text-muted mb-md">این‌ها را مردم خواسته‌اند و پیدا نکرده‌اند —
     نشانهٔ صنف‌هایی که باید به بازارچه دعوت کنید.</p>
  {f'<div class="table-wrap"><table class="table"><tbody>{_zrows}</tbody></table></div>' if _zrows else '<p class="text-sm text-muted">هر جست‌وجویی نتیجه داشته — عالی است.</p>'}
</div>'''
    _rev_card = f'''<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-md">{icon("trending")} درآمد و رشد (۳۰ روز)</h2>
  <div class="grid grid-3" style="gap:10px">
    {stat_card("wallet", _revenue, "درآمد اشتراک (تومان)")}
    {stat_card("check-circle", _live, "اشتراک فعال", delay=60)}
    {stat_card("search", _st_search['total'], "جست‌وجو", delay=120)}
  </div>
</div>'''

    # ---- v53: site weight / health — what actually drives phone load time
    _w = db.asset_weights()
    _total_kb = _w["uploads"] + _w["cats"] + _w["sprite"] + _w["video"]
    _weight_label = f'{fa_group(_total_kb)} KB' if _total_kb < 1024 else f'{fa(_total_kb // 1024)} MB'
    # a verdict the owner can act on, not just a number (v54)
    if _total_kb < 3000:
        _verdict = ("badge-open", "سبک و سریع — عالی است")
        _tip = "سایت در محدودهٔ ایده‌آل است. همین حال را نگه دارید."
    elif _total_kb < 8000:
        _verdict = ("badge-warn", "متوسط — قابل قبول")
        _tip = "اگر گوشی‌های قدیمی کند بودند، ویدیوی هیرو یا عکس‌های دسته را فشرده‌تر کنید."
    else:
        _verdict = ("badge-closed", "سنگین — لود کند می‌شود")
        _tip = "حجم زیاد شده. ویدیوی هیرو بزرگ‌ترین مقصر است؛ آن را فشرده‌تر یا حذف کنید."
    _health_card = f'''<div class="card glass card-pad mb-lg">
  <div class="between mb-md">
    <h2 class="card-title">{icon("activity")} وزن و سلامت سایت</h2>
    <span class="badge {_verdict[0]}">{_verdict[1]}</span>
  </div>
  <p class="text-sm text-muted mb-lg">این‌ها همان‌هایی‌اند که سرعت بارگذاری سایت را روی گوشی می‌سازند — نه سرور. هرچه کمتر، سایت سریع‌تر.</p>
  <div class="grid grid-4" style="gap:10px">
    {stat_card("image", f'{fa_group(_w["cats"])} KB', f'{fa(_w["cat_files"])} عکس دسته‌بندی')}
    {stat_card("upload", f'{fa_group(_w["uploads"])} KB', f'{fa(_w["upload_files"])} فایل آپلودی')}
    {stat_card("file", f'{fa_group(_w["video"])} KB', "ویدیوی پس‌زمینه (حذف‌شده)")}
    {stat_card("layers", f'{fa_group(_w["sprite"])} KB', "اسپرایت سنگین (حذف‌شده)", delay=60)}
  </div>
  <p class="text-sm mt-lg"><strong>مجموع: {_weight_label}</strong>
    <span class="text-muted">— {esc(_tip)}</span></p>
</div>'''

    # ---- v29: customer activity + live audit trail on the dashboard
    _cust = db.customer_counts()
    _audit = db.audit_log(8)
    _audit_rows = "".join(
        f'<tr><td><code>{esc(r["action"])}</code></td>'
        f'<td class="text-muted text-sm">{esc(r["detail"])}</td>'
        f'<td class="nums text-muted">{esc(str(r["created"])[5:16])}</td></tr>'
        for r in _audit)
    _activity_card = f'''<div class="card glass card-pad mb-lg">
  <div class="between mb-md">
    <h2 class="card-title">{icon("activity")} آخرین فعالیت‌ها</h2>
    <a class="btn btn-glass btn-sm" href="/panel/audit?key={esc(token)}">{icon("list")}<span>همه</span></a>
  </div>
  {f'<div class="table-wrap"><table class="table"><tbody>{_audit_rows}</tbody></table></div>' if _audit_rows else '<p class="text-sm text-muted">هنوز فعالیتی ثبت نشده.</p>'}
</div>'''

    content = f'''{_msg(q or {})}
{pending_box(s, token)}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("store", st['businesses'], "کسب‌وکار منتشرشده", href=f"/panel/businesses?key={esc(token)}")}
  {stat_card("layers", st['categories'], "دستهٔ فعال", delay=60, href=f"/panel/categories?key={esc(token)}")}
  {stat_card("eye", st['views'], "بازدید کل", delay=120, href=f"/panel/insights?key={esc(token)}")}
  {stat_card("message", st['reviews'], "نظر تأییدشده", delay=180, href=f"/panel/reviews?key={esc(token)}")}
</div>
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("users", _cust['customers'], "مشتری ثبت‌نام‌شده", href=f"/panel/customers?key={esc(token)}")}
  {stat_card("cart", _cust['orders'], "سفارش آنلاین", delay=60, href=f"/panel/orders?key={esc(token)}")}
  {stat_card("message", _cust['chats'], "گفتگو", delay=120, href=f"/panel/chats?key={esc(token)}")}
  {stat_card("mail", _cust['messages'], "پیام جدید", delay=180, href=f"/panel/messages?key={esc(token)}")}
</div>
{_gap_card}
{_rev_card}
{_health_card}
{_activity_card}

<div class="grid grid-2 mb-lg" style="grid-template-columns:minmax(0,1fr) minmax(0,340px);align-items:start">
  <div class="card glass card-pad">
    <div class="between mb-lg"><h2 class="card-title">{icon("store")} آخرین کسب‌وکارها</h2>
      <a class="btn btn-primary btn-sm" href="/panel/business/new?key={esc(token)}">
        {icon("plus")}<span>افزودن</span></a></div>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>کسب‌وکار</th><th>بازدید</th><th>وضعیت</th><th>عملیات</th></tr></thead>
      <tbody>{rows}</tbody></table></div>
  </div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-md">{icon("bell")} کارهای در انتظار</h2>
    <div class="todo-list">{todo}</div>
  </div>
</div>

<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("zap")} دسترسی سریع</h2>
  <div class="grid grid-4" style="gap:10px">
    <a class="btn btn-glass" href="/panel/business/new?key={esc(token)}">{icon("plus")}<span>کسب‌وکار جدید</span></a>
    <a class="btn btn-glass" href="/panel/categories?key={esc(token)}">{icon("layers")}<span>دسته‌بندی‌ها</span></a>
    <a class="btn btn-glass" href="/panel/appearance?key={esc(token)}">{icon("palette")}<span>ظاهر سایت</span></a>
    <a class="btn btn-glass" href="/panel/settings?key={esc(token)}">{icon("settings")}<span>تنظیمات</span></a>
    <a class="btn btn-glass" href="/panel/posts?key={esc(token)}">{icon("book")}<span>خبر جدید</span></a>
    <a class="btn btn-glass" href="/panel/backup?key={esc(token)}">{icon("database")}<span>پشتیبان</span></a>
    <a class="btn btn-glass" href="/" target="_blank" rel="noopener">{icon("external")}<span>دیدن سایت</span></a>
  </div>
</div>'''
    return panel_page(s, "داشبورد مدیریت",
                      "نمای کلی سایت و کارهای در انتظار شما.", content, "/panel", token)


# ------------------------------------------------------------------ businesses
def biz_list(s, token, q=None):
    q = q or {}
    g = lambda k, d="": (q.get(k) or [d])[0]
    term, status, cat = g("q"), g("status"), g("cat")
    sort = g("sort", "newest")
    page = int(g("page", "1") or 1)

    res = db.admin_businesses(q=term, status=status, cat=cat, page=page, sort=sort)
    rows, total, pages, cur = res["rows"], res["total"], res["pages"], res["page"]
    cats = db.categories(only_active=False)
    cmap = {c["slug"]: c for c in cats}

    STATUS = {"published": ("badge-open", "منتشرشده"),
              "pending": ("badge-warn", "در انتظار تأیید"),
              "hidden": ("badge-neutral", "مخفی"),
              "rejected": ("badge-closed", "رد شده")}

    trs = "".join(f'''<tr>
      <td><label class="check" style="min-height:0">
        <input type="checkbox" name="ids" value="{b["id"]}" form="bulk-form" data-bulk-item>
        <span class="sr-only">انتخاب {esc(b["name"])}</span></label></td>
      <td><div style="display:flex;align-items:center;gap:10px">
        {cat_icon(cmap.get(b["cat_slug"],{}).get("icon","store"), 34)}
        <div><strong>{esc(b["name"])}</strong><br>
          <small class="text-muted">{esc(cmap.get(b["cat_slug"],{}).get("name", b["cat_slug"]))}</small></div></div></td>
      <td class="num">{fa(round(b.get("rating") or 0, 1))}</td>
      <td class="num">{fa(b["views"])}</td>
      <td>{'<span class="badge badge-featured">ویژه</span>' if b["featured"] else '<span class="text-muted text-xs">—</span>'}</td>
      <td><span class="badge {STATUS.get(b["status"], ("badge-neutral",""))[0]}">
        {esc(STATUS.get(b["status"], ("", b["status"]))[1])}</span></td>
      <td class="actions">
        {approve_btn(b, token)}
        <a class="btn-icon" href="/b/{esc(b["slug"])}" target="_blank" rel="noopener"
           aria-label="مشاهدهٔ {esc(b["name"])}" title="مشاهده">{icon("eye")}</a>
        <a class="btn-icon" href="/panel/business/{b["id"]}?key={esc(token)}"
           aria-label="ویرایش {esc(b["name"])}" title="ویرایش">{icon("edit")}</a>
        <a class="btn-icon" href="/panel/catalog/{b["id"]}?key={esc(token)}"
           aria-label="کاتالوگ {esc(b["name"])}" title="کاتالوگ">{icon("shopping")}</a>
        <form method="post" action="/panel/business/{b["id"]}/delete" style="display:inline"
              data-confirm="حذف «{esc(b["name"])}»؟">
          <input type="hidden" name="key" value="{esc(token)}">
          <button class="btn-icon" type="submit" aria-label="حذف {esc(b["name"])}"
            title="حذف" style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for b in rows)

    if not trs:
        trs = f'''<tr><td colspan="7"><div class="empty-state" style="padding:var(--space-2xl)">
          <span class="icon-wrap">{icon("store")}</span>
          <h3>{"نتیجه‌ای یافت نشد" if (term or status or cat) else "هنوز کسب‌وکاری نیست"}</h3>
          <p>{"عبارت جست‌وجو یا فیلترها را تغییر دهید." if (term or status or cat)
              else "اولین کسب‌وکار را اضافه کنید تا روی سایت نمایش داده شود."}</p>
          <a class="btn btn-primary mt-lg" href="/panel/business/new?key={esc(token)}">
            {icon("plus")}<span>افزودن کسب‌وکار</span></a></div></td></tr>'''

    def link(**kw):
        p = {"key": token, "q": term, "status": status, "cat": cat,
             "sort": sort, "page": cur}
        p.update(kw)
        return "/panel/businesses?" + urlencode({k: v for k, v in p.items() if v not in ("", None)})

    filt = "".join(f'<a class="chip{" is-active" if status == v else ""}" href="{link(status=v, page=1)}">{t}</a>'
                   for v, t in [("", "همه"), ("pending", "در انتظار تأیید"),
                                ("published", "منتشرشده"), ("hidden", "مخفی"),
                                ("rejected", "رد شده")])

    # group_selectable: filtering by a parent should sweep its whole branch
    cat_opts = cat_options(cats, selected=cat, blank="همهٔ دسته‌ها",
                           group_selectable=True)
    sort_opts = "".join(
        f'<option value="{v}"{" selected" if sort == v else ""}>{t}</option>'
        for v, t in [("newest", "جدیدترین"), ("oldest", "قدیمی‌ترین"),
                     ("name", "حروف الفبا"), ("views", "پربازدیدترین"),
                     ("rating", "بیشترین امتیاز")])

    pager = ""
    if pages > 1:
        nums = ""
        for n in range(1, pages + 1):
            if n == 1 or n == pages or abs(n - cur) <= 2:
                nums += (f'<span class="pg-cur">{fa(n)}</span>' if n == cur
                         else f'<a href="{link(page=n)}">{fa(n)}</a>')
            elif abs(n - cur) == 3:
                nums += '<span class="pg-gap">…</span>'
        pager = f'''<nav class="pager" aria-label="صفحه‌بندی">
          {f'<a href="{link(page=cur-1)}">{icon("chevron-right")}<span>قبلی</span></a>' if cur > 1 else ""}
          {nums}
          {f'<a href="{link(page=cur+1)}"><span>بعدی</span>{icon("chevron-left")}</a>' if cur < pages else ""}
        </nav>'''

    bulk_cats = cat_options(cats)

    content = f'''{_msg(q)}
{pending_box(s, token) if not status else ""}

<form class="dir-toolbar" method="get" action="/panel/businesses" style="position:static">
  <input type="hidden" name="key" value="{esc(token)}">
  <div class="dir-row">
    <span class="search-wrap">{icon("search", cls="search-icon")}
      <label class="sr-only" for="ab-q">جست‌وجو</label>
      <input class="input" id="ab-q" name="q" type="search" value="{esc(term)}"
             placeholder="نام، نشانی، تلفن یا برچسب…" autocomplete="off"></span>
    <label class="sr-only" for="ab-cat">دسته</label>
    <select class="select" id="ab-cat" name="cat" onchange="this.form.submit()">{cat_opts}</select>
    <label class="sr-only" for="ab-sort">مرتب‌سازی</label>
    <select class="select" id="ab-sort" name="sort" onchange="this.form.submit()">{sort_opts}</select>
    <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
  </div>
  <div class="dir-chips">{filt}</div>
</form>

<div class="dir-meta">
  <span><strong class="nums">{fa(total)}</strong> کسب‌وکار
    {f'· صفحهٔ {fa(cur)} از {fa(pages)}' if pages > 1 else ""}</span>
  <div class="cluster">
    <a class="btn btn-glass btn-sm" href="/panel/businesses/export?key={esc(token)}">
      {icon("download")}<span>خروجی CSV</span></a>
    <a class="btn btn-glass btn-sm" href="/panel/businesses/import?key={esc(token)}">
      {icon("upload")}<span>ورود از CSV</span></a>
    <a class="btn btn-primary btn-sm" href="/panel/business/new?key={esc(token)}">
      {icon("plus")}<span>کسب‌وکار جدید</span></a>
  </div>
</div>

<form id="bulk-form" method="post" action="/panel/businesses/bulk" data-bulk
      data-confirm-delete="کسب‌وکارهای انتخاب‌شده حذف شوند؟">
  <input type="hidden" name="key" value="{esc(token)}">
  <div class="bulk-bar" data-bulk-bar hidden>
    <strong><span data-bulk-count>۰</span> مورد انتخاب شده</strong>
    <div class="cluster">
      <button class="btn btn-glass btn-sm" type="submit" name="action" value="publish">
        {icon("check")}<span>انتشار</span></button>
      <button class="btn btn-glass btn-sm" type="submit" name="action" value="hide">
        {icon("eye")}<span>مخفی</span></button>
      <button class="btn btn-glass btn-sm" type="submit" name="action" value="feature">
        {icon("sparkles")}<span>ویژه</span></button>
      <button class="btn btn-glass btn-sm" type="submit" name="action" value="unfeature">
        {icon("x")}<span>لغو ویژه</span></button>
      <select class="select" name="cat_to" style="min-width:150px" aria-label="انتقال به دسته">
        <option value="">انتقال به دسته…</option>{bulk_cats}</select>
      <button class="btn btn-glass btn-sm" type="submit" name="action" value="move">
        {icon("layers")}<span>انتقال</span></button>
      <button class="btn btn-ghost btn-sm" type="submit" name="action" value="delete"
              style="color:var(--color-destructive)">{icon("trash")}<span>حذف</span></button>
    </div>
  </div>
</form>

<div class="card glass card-pad">
  <div class="table-wrap"><table class="table">
    <thead><tr>
      <th style="width:38px"><label class="check" style="min-height:0">
        <input type="checkbox" data-bulk-all>
        <span class="sr-only">انتخاب همه</span></label></th>
      <th>کسب‌وکار</th><th>امتیاز</th><th>بازدید</th><th>ویژه</th>
      <th>وضعیت</th><th>عملیات</th></tr></thead>
    <tbody>{trs}</tbody></table></div>
  {pager}
</div>
<script type="module" src="/assets/js/bulk.js"></script>'''
    return panel_page(s, "مدیریت کسب‌وکارها",
                      "جست‌وجو، فیلتر، عملیات گروهی و ورود/خروجی CSV.",
                      content, "/panel/businesses", token)


def biz_edit(s, token, bid=None, q=None):
    cats = db.categories(only_active=False)
    b = db.business(bid=bid) if bid else None
    new = b is None
    v = lambda k, d="": esc(b.get(k, d)) if b else esc(d)

    opts = cat_options(cats, selected=(b["cat_slug"] if b else ""))

    hm = b["hours_map"] if b else {}
    hrows = ""
    for k, label in DAYS:
        rng = hm.get(k) or []
        o = rng[0][0] if rng else "09:00"
        c = rng[0][1] if rng else "21:00"
        closed = "" if rng else " checked"
        hrows += f'''<div class="hours-row">
          <span class="text-sm fw-700">{label}</span>
          <input class="input" type="time" name="h_{k}_open" value="{esc(o)}" aria-label="ساعت شروع {label}">
          <input class="input" type="time" name="h_{k}_close" value="{esc(c)}" aria-label="ساعت پایان {label}">
          <label class="check"><input type="checkbox" name="h_{k}_closed"{closed}><span>تعطیل</span></label>
        </div>'''

    st_opts = "".join(f'<option value="{val}"{" selected" if b and b["status"]==val else ""}>{t}</option>'
                      for val, t in [("published","منتشرشده"),("pending","در انتظار"),("hidden","مخفی")])

    lat = b["lat"] if b and b["lat"] else s.get("map_lat", "32.6340")
    lng = b["lng"] if b and b["lng"] else s.get("map_lng", "51.3670")

    review_bar = ""
    if b and b["status"] != "published":
        lbl = {"pending": "این کسب‌وکار در انتظار تأیید شماست.",
               "hidden": "این کسب‌وکار مخفی است و روی سایت دیده نمی‌شود.",
               "rejected": "این درخواست قبلاً رد شده است."}.get(b["status"], "")
        review_bar = f'''<div class="card glass card-pad mb-lg review-bar">
          <div class="between">
            <div><strong>{icon("bell")} {esc(lbl)}</strong>
              <p class="text-sm text-muted mt-sm">پس از بررسی اطلاعات، تصمیم خود را ثبت کنید.</p></div>
            <div class="cluster">
              <form method="post" action="/panel/business/{bid}/status">
                <input type="hidden" name="key" value="{esc(token)}">
                <input type="hidden" name="back" value="/panel/business/{bid}">
                <input type="hidden" name="status" value="published">
                <button class="btn btn-primary" type="submit">
                  {icon("check")}<span>تأیید و انتشار</span></button></form>
              <form method="post" action="/panel/business/{bid}/status"
                    data-confirm="این درخواست رد شود؟">
                <input type="hidden" name="key" value="{esc(token)}">
                <input type="hidden" name="back" value="/panel/business/{bid}">
                <input type="hidden" name="status" value="rejected">
                <button class="btn btn-ghost" type="submit"
                        style="color:var(--color-destructive)">{icon("x")}<span>رد</span></button></form>
            </div>
          </div></div>'''

    content = f'''{_msg(q or {})}
{review_bar}
<form method="post" action="/panel/business/{bid or 'new'}" data-validate>
  <input type="hidden" name="key" value="{esc(token)}">

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("store")} اطلاعات پایه</h2>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="f-name">نام کسب‌وکار<span class="req">*</span></label>
        <input class="input" id="f-name" name="name" required minlength="2" value="{v('name')}"></div>
      <div class="field"><label class="field-label" for="f-cat">دسته<span class="req">*</span></label>
        <select class="select" id="f-cat" name="cat_slug" required>
          <option value="">انتخاب کنید…</option>{opts}</select></div>
    </div>
    <div class="field"><label class="field-label" for="f-desc">توضیحات<span class="req">*</span></label>
      <textarea class="textarea" id="f-desc" name="descr" required minlength="10">{v('descr')}</textarea></div>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="f-phone">تلفن</label>
        <input class="input" id="f-phone" name="phone" type="tel" value="{v('phone')}"></div>
      <div class="field"><label class="field-label" for="f-wa">واتساپ</label>
        <input class="input" id="f-wa" name="whatsapp" type="tel" value="{v('whatsapp')}"
               placeholder="989123456789"></div>
    </div>
    <div class="field"><label class="field-label" for="f-addr">نشانی</label>
      <input class="input" id="f-addr" name="address" value="{v('address')}"></div>
    <div class="field"><label class="field-label" for="f-area">محله</label>
      <input class="input" id="f-area" name="area" value="{v('area')}" maxlength="100" placeholder="مثلاً امیرآباد"></div>
    <div class="grid grid-2" style="align-items:start">
      <div class="field"><label class="field-label" for="f-prov">استان</label>
        <select class="select" id="f-prov" name="province">
          <option value="">—</option>
          {"".join(f'<option value="{esc(p)}"{" selected" if v("province")==p else ""}>{esc(p)}</option>' for p in db.provinces())}
        </select></div>
      <div class="field"><label class="field-label" for="f-city">شهر</label>
        <input class="input" id="f-city" name="city" value="{v('city')}" maxlength="100" placeholder="نام شهر"></div>
    </div>
    <div class="field"><label class="field-label" for="f-tags">برچسب‌ها</label>
      <input class="input" id="f-tags" name="tags" value="{v('tags')}" placeholder="با ویرگول جدا کنید"></div>
    <div class="grid grid-3" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="f-ig">اینستاگرام</label>
        <input class="input" id="f-ig" name="instagram" value="{v('instagram')}"></div>
      <div class="field"><label class="field-label" for="f-tg">تلگرام</label>
        <input class="input" id="f-tg" name="telegram" value="{v('telegram')}"></div>
      <div class="field"><label class="field-label" for="f-web">وب‌سایت</label>
        <input class="input" id="f-web" name="website" value="{v('website')}"></div>
    </div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("pin")} موقعیت روی نقشه</h2>
    <p class="text-sm text-muted mb-md">روی نقشه بزنید یا نشانگر را بکشید تا موقعیت دقیق ثبت شود.</p>
    <div class="map-stage" data-map-wrap data-map="pending" style="min-height:340px;border-radius:var(--radius-lg)">
      <div data-map-canvas data-pick data-lat="{lat}" data-lng="{lng}" style="position:absolute;inset:0"></div>
      <div class="map-legend">{icon("info")}<span data-map-status>در حال بارگذاری…</span></div>
    </div>
    <div class="grid grid-2 mt-md" style="gap:0 var(--space-md)">
      <div class="field" style="margin-bottom:0"><label class="field-label" for="f-lat">عرض جغرافیایی</label>
        <input class="input nums" id="f-lat" name="lat" value="{esc(lat)}"></div>
      <div class="field" style="margin-bottom:0"><label class="field-label" for="f-lng">طول جغرافیایی</label>
        <input class="input nums" id="f-lng" name="lng" value="{esc(lng)}"></div>
    </div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("clock")} ساعت کاری</h2>
    <div class="hours-grid">{hrows}</div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("settings")} وضعیت و نشان‌ها</h2>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="f-status">وضعیت انتشار</label>
        <select class="select" id="f-status" name="status">{st_opts}</select></div>
    </div>
    <label class="switch mb-md"><input type="checkbox" name="featured"
      {" checked" if b and b['featured'] else ""}><span class="track"></span>
      <span>کسب‌وکار ویژه (اولویت در نتایج)</span></label>
    <label class="switch mb-md"><input type="checkbox" name="verified"
      {" checked" if b and b['verified'] else ""}><span class="track"></span>
      <span>نشان «تأییدشده»</span></label>
    <label class="switch mb-md"><input type="checkbox" name="booking_on"
      {" checked" if b and b['booking_on'] else ""}><span class="track"></span>
      <span>فعال‌سازی رزرو نوبت آنلاین</span></label>
  </div>

  <div class="cluster">
    <button class="btn btn-primary btn-lg" type="submit">{icon("check")}
      <span>{"ایجاد کسب‌وکار" if new else "ذخیرهٔ تغییرات"}</span></button>
    <a class="btn btn-ghost btn-lg" href="/panel/businesses?key={esc(token)}">
      {icon("x")}<span>انصراف</span></a>
    {f'<a class="btn btn-glass btn-lg" href="/panel/gallery/{bid}?key={esc(token)}">{icon("image")}<span>گالری</span></a>' if b else ''}
    {f'<a class="btn btn-glass btn-lg" href="/panel/catalog/{bid}?key={esc(token)}">{icon("shopping")}<span>کاتالوگ</span></a>' if b else ''}
    {f'<a class="btn btn-outline btn-lg" href="/b/{esc(b["slug"])}" target="_blank" rel="noopener">{icon("external")}<span>مشاهده در سایت</span></a>' if b else ''}
  </div>
</form>'''
    return panel_page(s, "کسب‌وکار جدید" if new else f"ویرایش: {b['name']}",
                      "همهٔ اطلاعات این کسب‌وکار را می‌توانید تغییر دهید.",
                      content, "/panel/businesses", token, extra_js=MAP_JS)


# ------------------------------------------------------------------ categories
def cat_list(s, token, q=None):
    tree = db.category_tree(only_active=False)
    all_icons = sorted({c["icon"] for c in db.categories(only_active=False)}
                       | set(ICON_CHOICES))
    icons = "".join(f'<option value="{i}">{i}</option>' for i in all_icons)
    n_all = len(db.categories(only_active=False))

    def row(c, child=False):
        pad = ' style="padding-inline-start:34px"' if child else ''
        kid_note = ""
        if not child and c.get("children"):
            kid_note = (f'<br><small class="text-muted">'
                        f'{fa(len(c["children"]))} زیردسته · '
                        f'{fa(c["total"])} کسب‌وکار با زیرمجموعه‌ها</small>')
        return f'''<tr class="{"cat-child" if child else "cat-parent"}">
      <td{pad}><div style="display:flex;align-items:center;gap:12px">
        {cat_icon(c['icon'], 32 if child else 40)}
        <div>{"↳ " if child else ""}<strong>{esc(c['name'])}</strong>{kid_note}</div></div></td>
      <td><code class="text-xs">{esc(c['slug'])}</code></td>
      <td class="num nums">{fa(c['count'])}</td>
      <td><span class="badge {"badge-open" if c['active'] else "badge-neutral"}">
        {"فعال" if c['active'] else "غیرفعال"}</span></td>
      <td class="actions">
        <a class="btn-icon" href="/panel/category/{c['id']}?key={esc(token)}"
           aria-label="ویرایش {esc(c['name'])}" title="ویرایش">{icon("edit")}</a>
        <form method="post" action="/panel/category/{c['id']}/delete" style="display:inline"
              data-confirm="حذف دستهٔ «{esc(c['name'])}»؟">
          <input type="hidden" name="key" value="{esc(token)}">
          <button class="btn-icon" type="submit" aria-label="حذف {esc(c['name'])}" title="حذف"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>'''

    trs = ""
    for c in tree:
        trs += row(c)
        for k in c.get("children", []):
            trs += row(k, child=True)

    parent_opts = '<option value="">— دستهٔ اصلی (بدون والد) —</option>' + "".join(
        f'<option value="{esc(c["slug"])}">{esc(c["name"])}</option>' for c in tree)

    content = f'''{_msg(q or {})}
<div class="grid grid-2" style="grid-template-columns:minmax(0,1fr) minmax(0,360px);align-items:start">
  <div class="card glass card-pad">
    <div class="between mb-lg"><h2 class="card-title">{icon("layers")} دسته‌بندی‌ها</h2>
      <span class="badge badge-neutral">{fa(len(tree))} دستهٔ اصلی · {fa(n_all)} مجموع</span></div>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>دسته</th><th>شناسه</th><th>تعداد</th><th>وضعیت</th><th>عملیات</th></tr></thead>
      <tbody>{trs}</tbody></table></div>
  </div>

  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("plus")} افزودن دسته</h2>
    <form method="post" action="/panel/category/new" data-validate>
      <input type="hidden" name="key" value="{esc(token)}">
      <div class="field"><label class="field-label" for="nc-name">نام دسته<span class="req">*</span></label>
        <input class="input" id="nc-name" name="name" required minlength="2"
               placeholder="مثلاً: خدمات دامپزشکی"></div>
      <div class="field"><label class="field-label" for="nc-parent">زیرمجموعهٔ کدام دسته؟</label>
        <select class="select" id="nc-parent" name="parent">{parent_opts}</select>
        <p class="field-hint">اگر خالی بماند، یک دستهٔ اصلی روی صفحهٔ نخست ساخته می‌شود.</p></div>
      <div class="field"><label class="field-label" for="nc-icon">آیکون</label>
        <select class="select" id="nc-icon" name="icon" data-icon-select>{icons}</select>
        <div class="icon-preview mt-sm" data-icon-preview>{cat_icon('store', 64)}</div></div>
      <div class="field"><label class="field-label" for="nc-blurb">توضیح کوتاه</label>
        <textarea class="textarea" id="nc-blurb" name="blurb" style="min-height:80px"></textarea></div>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>ایجاد دسته</span></button>
    </form>
  </div>
</div>'''
    return panel_page(s, "مدیریت دسته‌بندی‌ها",
                      "دسته‌های سایت را اضافه، ویرایش یا حذف کنید.",
                      content, "/panel/categories", token)


def cat_edit(s, token, cid, q=None):
    c = db.category_by_id(cid) if hasattr(db, "category_by_id") else None
    if c is None:
        for x in db.categories(only_active=False):
            if x["id"] == cid:
                c = x
                break
    if not c:
        return None
    all_icons = sorted({x["icon"] for x in db.categories(only_active=False)}
                       | set(ICON_CHOICES))
    icons = "".join(f'<option value="{i}"{" selected" if c["icon"]==i else ""}>{i}</option>'
                    for i in all_icons)
    # a category may not be its own parent, and a parent that already has
    # children cannot itself become a child (we only support two levels)
    has_kids = bool(db.category_children(c["slug"], only_active=False))
    cur_parent = (c.get("parent") or "")
    if has_kids:
        parent_opts = ('<option value="">— دستهٔ اصلی —</option>')
        parent_note = "این دسته زیردسته دارد، پس خودش باید دستهٔ اصلی بماند."
    else:
        parent_opts = ('<option value="">— دستهٔ اصلی (بدون والد) —</option>' + "".join(
            f'<option value="{esc(x["slug"])}"'
            f'{" selected" if cur_parent == x["slug"] else ""}>{esc(x["name"])}</option>'
            for x in db.category_tree(only_active=False) if x["slug"] != c["slug"]))
        parent_note = "با انتخاب والد، این دسته زیرمجموعه می‌شود."
    content = f'''{_msg(q or {})}
<div class="card glass card-pad" style="max-width:640px">
  <form method="post" action="/panel/category/{cid}" data-validate>
    <input type="hidden" name="key" value="{esc(token)}">
    <div class="field"><label class="field-label" for="c-name">نام دسته<span class="req">*</span></label>
      <input class="input" id="c-name" name="name" required value="{esc(c['name'])}"></div>
    <div class="field"><label class="field-label" for="c-parent">زیرمجموعهٔ کدام دسته؟</label>
      <select class="select" id="c-parent" name="parent"{" disabled" if has_kids else ""}>{parent_opts}</select>
      {'<input type="hidden" name="parent" value="">' if has_kids else ''}
      <p class="field-hint">{esc(parent_note)}</p></div>
    <div class="field"><label class="field-label" for="c-icon">آیکون</label>
      <select class="select" id="c-icon" name="icon" data-icon-select>{icons}</select>
      <div class="icon-preview mt-sm" data-icon-preview>{cat_icon(c['icon'], 64)}</div></div>
    <div class="field"><label class="field-label" for="c-blurb">توضیح کوتاه</label>
      <textarea class="textarea" id="c-blurb" name="blurb" style="min-height:80px">{esc(c['blurb'])}</textarea></div>
    <div class="field"><label class="field-label" for="c-sort">ترتیب نمایش</label>
      <input class="input nums" id="c-sort" name="sort" type="number" value="{c['sort']}"></div>
    <label class="switch mb-lg"><input type="checkbox" name="active"{" checked" if c['active'] else ""}>
      <span class="track"></span><span>دسته فعال باشد</span></label>
    <div class="cluster">
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
      <a class="btn btn-ghost" href="/panel/categories?key={esc(token)}">{icon("x")}<span>انصراف</span></a>
    </div>
  </form>
</div>'''
    return panel_page(s, f"ویرایش دسته: {c['name']}", "تغییر نام، آیکون و ترتیب نمایش.",
                      content, "/panel/categories", token)


# ------------------------------------------------------------------ reviews
def rev_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or [""])[0]
    rows = db.reviews(status=status or None)

    items = "".join(f'''<article class="review">
      <div class="review-head"><span class="avatar" aria-hidden="true">{esc(r['author'][:1])}</span>
        <div style="flex:1"><strong>{esc(r['author'])}</strong>
          <div class="card-meta" style="margin-top:3px">{stars(r['rating'])}
            <span class="nums">{fa(r['rating'])}٫۰</span><span aria-hidden="true">·</span>
            <a href="/b/{esc(r['bizslug'])}">{esc(r['bizname'])}</a></div></div>
        <span class="badge {"badge-open" if r['status']=='approved' else ("badge-warn" if r['status']=='pending' else "badge-closed")}">
          {esc({"approved":"تأییدشده","pending":"در انتظار","rejected":"رد شده"}.get(r['status']))}</span>
      </div>
      <p class="review-body">{esc(r['body'])}</p>
      {f'<div class="review-reply"><strong>{icon("store")}پاسخ شما</strong>{esc(r["reply"])}</div>' if r['reply'] else ''}
      <form method="post" action="/panel/review/{r['id']}" class="mt-md">
        <input type="hidden" name="key" value="{esc(token)}">
        <label class="sr-only" for="rp{r['id']}">پاسخ به نظر</label>
        <textarea class="textarea" id="rp{r['id']}" name="reply" style="min-height:80px"
          placeholder="پاسخ رسمی…">{esc(r['reply'])}</textarea>
        <div class="cluster mt-sm">
          <button class="btn btn-primary btn-sm" type="submit" name="action" value="reply">
            {icon("send")}<span>ثبت پاسخ</span></button>
          <button class="btn btn-glass btn-sm" type="submit" name="action" value="approve">
            {icon("check")}<span>تأیید</span></button>
          <button class="btn btn-glass btn-sm" type="submit" name="action" value="reject">
            {icon("x")}<span>رد</span></button>
          <button class="btn btn-ghost btn-sm" type="submit" name="action" value="delete"
            style="color:var(--color-destructive)">{icon("trash")}<span>حذف</span></button>
        </div>
      </form></article>''' for r in rows)

    if not items:
        items = f'''<div class="empty-state"><span class="icon-wrap">{icon("message")}</span>
          <h3>نظری در این بخش نیست</h3><p>وقتی مشتریان نظر ثبت کنند، اینجا نمایش داده می‌شود.</p></div>'''

    filt = "".join(f'<a class="chip{" is-active" if status==v else ""}" '
                   f'href="/panel/reviews?key={esc(token)}&status={v}">{t}</a>'
                   for v, t in [("","همه"),("pending","در انتظار"),
                                ("approved","تأییدشده"),("rejected","رد شده")])
    content = f'''{_msg(q)}
<div class="cluster mb-lg">{filt}</div>
<div class="card glass card-pad">{items}</div>'''
    return panel_page(s, "مدیریت نظرات", "تأیید، رد و پاسخ به نظرات مشتریان.",
                      content, "/panel/reviews", token)


# ------------------------------------------------------------------ bookings
BOOK_BADGE = {"new":"badge-warn","confirmed":"badge-info",
              "done":"badge-open","cancelled":"badge-closed"}
BOOK_LABEL = {"new":"جدید","confirmed":"تأییدشده","done":"انجام‌شده","cancelled":"لغو"}


def book_list(s, token, q=None):
    rows = db.bookings()
    for k in rows:
        k["_badge"] = BOOK_BADGE.get(k["status"], "badge-neutral")
        k["_label"] = BOOK_LABEL.get(k["status"], k["status"])
    trs = "".join(f'''<tr>
      <td><strong>{esc(k['name'])}</strong><br><small class="text-muted nums">{esc(k['phone'])}</small></td>
      <td>{esc(k['bizname'])}</td>
      <td class="num">{esc(k['date'])} — {esc(k['time'])}</td>
      <td>{esc(k['note'])[:40] or '<span class="text-muted">—</span>'}</td>
      <td><span class="badge {k['_badge']}">{esc(k['_label'])}</span></td>
      <td class="actions">
        <form method="post" action="/panel/booking/{k['id']}" style="display:flex;gap:4px">
          <input type="hidden" name="key" value="{esc(token)}">
          <button class="btn-icon" type="submit" name="status" value="confirmed"
            aria-label="تأیید نوبت" title="تأیید">{icon("check")}</button>
          <button class="btn-icon" type="submit" name="status" value="done"
            aria-label="انجام شد" title="انجام شد">{icon("check-circle")}</button>
          <button class="btn-icon" type="submit" name="status" value="cancelled"
            aria-label="لغو نوبت" title="لغو" style="color:var(--color-destructive)">{icon("x")}</button>
        </form></td></tr>''' for k in rows)
    if not trs:
        trs = f'<tr><td colspan="6"><div class="empty-state" style="padding:var(--space-2xl)">' \
              f'<span class="icon-wrap">{icon("calendar")}</span><h3>نوبتی ثبت نشده</h3>' \
              f'<p>پس از فعال‌سازی رزرو در هر کسب‌وکار، درخواست‌ها اینجا می‌آیند.</p></div></td></tr>'
    content = f'''{_msg(q or {})}
<div class="card glass card-pad">
  <div class="table-wrap"><table class="table">
    <thead><tr><th>مشتری</th><th>کسب‌وکار</th><th>زمان</th><th>توضیح</th><th>وضعیت</th><th>عملیات</th></tr></thead>
    <tbody>{trs}</tbody></table></div></div>'''
    return panel_page(s, "نوبت‌های رزروشده", "درخواست‌های رزرو مشتریان را مدیریت کنید.",
                      content, "/panel/bookings", token)





# ------------------------------------------------------------------ posts
def post_list(s, token, q=None):
    rows = db.posts(status=None)
    trs = "".join(f'''<tr><td><strong>{esc(p['title'])}</strong><br>
      <small class="text-muted">{esc(p['excerpt'])[:60]}</small></td>
      <td class="num">{esc(str(p['created'])[:10])}</td>
      <td><span class="badge {"badge-open" if p['status']=='published' else "badge-neutral"}">
        {"منتشرشده" if p['status']=='published' else "پیش‌نویس"}</span></td>
      <td class="actions">
        <a class="btn-icon" href="/blog/{esc(p['slug'])}" target="_blank" rel="noopener"
           aria-label="مشاهدهٔ {esc(p['title'])}">{icon("eye")}</a>
        <form method="post" action="/panel/post/{p['id']}/delete" style="display:inline"
              data-confirm="حذف «{esc(p['title'])}»؟">
          <input type="hidden" name="key" value="{esc(token)}">
          <button class="btn-icon" type="submit" aria-label="حذف {esc(p['title'])}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for p in rows)
    if not trs:
        trs = '<tr><td colspan="4" class="text-center text-muted" style="padding:var(--space-xl)">هنوز مطلبی نیست</td></tr>'
    content = f'''{_msg(q or {})}
<div class="grid grid-2" style="grid-template-columns:minmax(0,1fr) minmax(0,380px);align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("book")} مطالب</h2>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>عنوان</th><th>تاریخ</th><th>وضعیت</th><th></th></tr></thead>
      <tbody>{trs}</tbody></table></div></div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("plus")} مطلب جدید</h2>
    <form method="post" action="/panel/post/new" data-validate>
      <input type="hidden" name="key" value="{esc(token)}">
      <div class="field"><label class="field-label" for="p-title">عنوان<span class="req">*</span></label>
        <input class="input" id="p-title" name="title" required minlength="3"></div>
      <div class="field"><label class="field-label" for="p-ex">خلاصه</label>
        <textarea class="textarea" id="p-ex" name="excerpt" style="min-height:70px"></textarea></div>
      <div class="field"><label class="field-label" for="p-body">متن<span class="req">*</span></label>
        <textarea class="textarea" id="p-body" name="body" required minlength="20"
          style="min-height:160px"></textarea>
        <p class="field-hint">هر خط جدید یک پاراگراف می‌شود.</p></div>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>انتشار</span></button>
    </form></div></div>'''
    return panel_page(s, "اخبار و مقالات", "مطالب بخش وبلاگ سایت را مدیریت کنید.",
                      content, "/panel/posts", token)


# ------------------------------------------------------------------ messages
def msg_list(s, token, q=None):
    rows = db.messages()
    items = "".join(f'''<article class="review">
      <div class="review-head"><span class="avatar" aria-hidden="true">{esc((m['name'] or '?')[:1])}</span>
        <div style="flex:1"><strong>{esc(m['name'])}</strong>
          <div class="card-meta" style="margin-top:3px"><span>{esc(m['subject'])}</span>
            <span aria-hidden="true">·</span><span>{esc(str(m['created'])[:16])}</span></div></div>
        <span class="badge {"badge-warn" if m['status']=='new' else "badge-neutral"}">
          {"جدید" if m['status']=='new' else "خوانده‌شده"}</span></div>
      <p class="review-body">{esc(m['body'])}</p>
      <div class="cluster mt-md">
        <a class="btn btn-primary btn-sm" href="mailto:{esc(m['email'])}">{icon("mail")}<span>پاسخ ایمیلی</span></a>
        <form method="post" action="/panel/message/{m['id']}" style="display:inline">
          <input type="hidden" name="key" value="{esc(token)}">
          <button class="btn btn-glass btn-sm" type="submit" name="action" value="read">
            {icon("check")}<span>خوانده شد</span></button></form>
        <form method="post" action="/panel/message/{m['id']}" style="display:inline"
              data-confirm="حذف این پیام؟">
          <input type="hidden" name="key" value="{esc(token)}">
          <button class="btn btn-ghost btn-sm" type="submit" name="action" value="delete"
            style="color:var(--color-destructive)">{icon("trash")}<span>حذف</span></button></form>
      </div></article>''' for m in rows)
    if not items:
        items = f'<div class="empty-state"><span class="icon-wrap">{icon("mail")}</span>' \
                f'<h3>پیامی نیست</h3><p>پیام‌های فرم تماس اینجا نمایش داده می‌شوند.</p></div>'
    content = f'{_msg(q or {})}<div class="card glass card-pad">{items}</div>'
    return panel_page(s, "پیام‌های دریافتی", "پیام‌های ارسالی از فرم تماس.",
                      content, "/panel/messages", token)


# ------------------------------------------------------------------ pages
def pages_edit(s, token, q=None):
    about = db.get_page("about")
    rules = db.get_page("rules")
    content = f'''{_msg(q or {})}
<div class="tabs mb-lg" data-tabs role="tablist" aria-label="صفحات ثابت">
  <button role="tab" id="t-ab" aria-controls="p-ab" aria-selected="true">درباره ما</button>
  <button role="tab" id="t-ru" aria-controls="p-ru" aria-selected="false" tabindex="-1">قوانین</button>
</div>
<div class="tab-panel" id="p-ab" role="tabpanel" aria-labelledby="t-ab">
  <div class="card glass card-pad">
    <form method="post" action="/panel/pages" data-validate>
      <input type="hidden" name="key" value="{esc(token)}">
      <input type="hidden" name="slug" value="about">
      <div class="field"><label class="field-label" for="ab-t">عنوان</label>
        <input class="input" id="ab-t" name="title" value="{esc(about['title'])}"></div>
      <div class="field"><label class="field-label" for="ab-b">متن صفحه</label>
        <textarea class="textarea" id="ab-b" name="body" style="min-height:280px">{esc(about['body'])}</textarea>
        <p class="field-hint">هر خط جدید یک پاراگراف می‌شود.</p></div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
    </form></div></div>
<div class="tab-panel" id="p-ru" role="tabpanel" aria-labelledby="t-ru" hidden>
  <div class="card glass card-pad">
    <form method="post" action="/panel/pages" data-validate>
      <input type="hidden" name="key" value="{esc(token)}">
      <input type="hidden" name="slug" value="rules">
      <div class="field"><label class="field-label" for="ru-t">عنوان</label>
        <input class="input" id="ru-t" name="title" value="{esc(rules['title'])}"></div>
      <div class="field"><label class="field-label" for="ru-b">متن صفحه</label>
        <textarea class="textarea" id="ru-b" name="body" style="min-height:280px">{esc(rules['body'])}</textarea></div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
    </form></div></div>'''
    return panel_page(s, "صفحات ثابت", "متن صفحات «درباره ما» و «قوانین» را ویرایش کنید.",
                      content, "/panel/pages", token)


# ------------------------------------------------------------------ appearance
def appearance(s, token, q=None):
    colors = [("رنگ اصلی","color_primary",s.get("color_primary"),"دکمه‌ها، لینک‌ها و عناصر تعاملی"),
              ("رنگ تأکید","color_accent",s.get("color_accent"),"دکمهٔ فراخوان و نشان ویژه"),
              ("پس‌زمینه","color_background",s.get("color_background"),"پس‌زمینهٔ کلی صفحات"),
              ("متن اصلی","color_foreground",s.get("color_foreground"),"رنگ متن بدنه و عناوین")]
    crows = "".join(f'''<div class="color-row">
      <input type="color" name="{k}" value="{esc(v)}" aria-label="{n}" data-color-sync>
      <div class="meta"><strong>{n}</strong><small>{d}</small></div>
      <code>{esc(v)}</code></div>''' for n, k, v, d in colors)

    content = f'''{_msg(q or {})}
<form method="post" action="/panel/appearance" enctype="multipart/form-data">
  <input type="hidden" name="key" value="{esc(token)}">

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("image")} لوگوی سایت</h2>
    <p class="text-sm text-muted mb-lg">تصویری از گالری گوشی انتخاب کنید.
      اگر خالی بماند، نشان پیش‌فرض نمایش داده می‌شود.</p>
    <div data-imagefield data-name="logo" data-max="1"
         data-existing='{json_embed([s.get("site_logo")] if s.get("site_logo") else [])}'></div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("palette")} رنگ‌های سایت</h2>
    {crows}
    <div class="alert alert-info mt-lg">{icon("info")}
      <span>تغییر رنگ بلافاصله روی کل سایت اعمال می‌شود. اگر کنتراست کم شد،
        دکمهٔ «بازگشت به پیش‌فرض» را بزنید.</span></div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("edit")} متن‌های صفحهٔ اصلی</h2>
    <div class="field"><label class="field-label" for="a-h1">عنوان اصلی (هیرو)</label>
      <textarea class="textarea" id="a-h1" name="hero_title" style="min-height:80px">{esc(s.get('hero_title'))}</textarea>
      <p class="field-hint">برای شکستن خط، Enter بزنید.</p></div>
    <div class="field"><label class="field-label" for="a-lead">متن معرفی</label>
      <textarea class="textarea" id="a-lead" name="hero_lead" style="min-height:90px">{esc(s.get('hero_lead'))}</textarea></div>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="a-cta">متن دکمهٔ فراخوان</label>
        <input class="input" id="a-cta" name="hero_cta" value="{esc(s.get('hero_cta'))}"></div>
      <div class="field"><label class="field-label" for="a-fn">متن پاورقی</label>
        <input class="input" id="a-fn" name="footer_note" value="{esc(s.get('footer_note'))}"></div>
    </div>
  </div>

  <div class="cluster">
    <button class="btn btn-primary btn-lg" type="submit">{icon("check")}<span>ذخیرهٔ ظاهر</span></button>
    <button class="btn btn-ghost btn-lg" type="submit" name="reset" value="1">
      {icon("refresh")}<span>بازگشت به پیش‌فرض</span></button>
  </div>
</form>'''
    return panel_page(s, "ظاهر و رنگ‌ها",
                      "لوگو، رنگ‌ها، متن‌های اصلی و جلوه‌های بصری سایت.",
                      content, "/panel/appearance", token,
                      extra_js='<script type="module" src="/assets/js/imagefield.js?v109"></script>')


# ------------------------------------------------------------------ settings
def settings_page(s, token, q=None):
    prov = s.get("map_provider", "auto")
    popts = "".join(f'<option value="{v}"{" selected" if prov==v else ""}>{t}</option>'
                    for v, t in [("auto","خودکار (گوگل، در نبود آن OpenStreetMap)"),
                                 ("google","فقط گوگل مپ"),("osm","فقط OpenStreetMap")])
    content = f'''{_msg(q or {})}
<div class="tabs mb-lg" data-tabs role="tablist" aria-label="بخش‌های تنظیمات">
  <button role="tab" id="t-g" aria-controls="p-g" aria-selected="true">عمومی</button>
  <button role="tab" id="t-m" aria-controls="p-m" aria-selected="false" tabindex="-1">نقشه</button>
  <button role="tab" id="t-f" aria-controls="p-f" aria-selected="false" tabindex="-1">امکانات</button>
  <button role="tab" id="t-x" aria-controls="p-x" aria-selected="false" tabindex="-1">پیامک</button>
  <button role="tab" id="t-s" aria-controls="p-s" aria-selected="false" tabindex="-1">امنیت</button>
</div>

<div class="tab-panel" id="p-g" role="tabpanel" aria-labelledby="t-g">
  <form method="post" action="/panel/settings">
    <input type="hidden" name="key" value="{esc(token)}">
    <div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-lg">{icon("settings")} اطلاعات سایت</h2>
      <div class="grid grid-2" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="g-n">نام سایت</label>
          <input class="input" id="g-n" name="site_name" value="{esc(s.get('site_name'))}"></div>
        <div class="field"><label class="field-label" for="g-t">شعار</label>
          <input class="input" id="g-t" name="tagline" value="{esc(s.get('tagline'))}"></div>
      </div>
      <div class="field"><label class="field-label" for="g-u">آدرس سایت</label>
        <input class="input" id="g-u" name="site_url" dir="ltr"
               placeholder="bazarche-najafabad.ir"
               value="{esc(s.get('site_url', ''))}">
        <p class="field-hint">تا وقتی دامنه نگرفته‌اید خالی بگذارید — سایت خودش
          آدرس را از مرورگر برمی‌دارد. بعد از خرید دامنه اینجا بنویسید تا
          بارکدهای QR، نقشهٔ سایت و لینک‌های اشتراک‌گذاری همه به آن اشاره کنند.</p></div>
      <div class="field"><label class="field-label" for="g-d">توضیح سئو</label>
        <textarea class="textarea" id="g-d" name="description" style="min-height:80px">{esc(s.get('description'))}</textarea></div>
      <div class="grid grid-2" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="g-p">تلفن نمایشی</label>
          <input class="input" id="g-p" name="phone" value="{esc(s.get('phone'))}"></div>
        <div class="field"><label class="field-label" for="g-pr">تلفن (برای لینک تماس)</label>
          <input class="input" id="g-pr" name="phone_raw" value="{esc(s.get('phone_raw'))}"></div>
      </div>
      <div class="field"><label class="field-label" for="g-e">ایمیل</label>
        <input class="input" id="g-e" name="email" type="email" value="{esc(s.get('email'))}"></div>
      <div class="field"><label class="field-label" for="g-a">نشانی</label>
        <input class="input" id="g-a" name="address" value="{esc(s.get('address'))}"></div>
      <div class="grid grid-3" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="g-ig">اینستاگرام</label>
          <input class="input" id="g-ig" name="instagram" value="{esc(s.get('instagram'))}"></div>
        <div class="field"><label class="field-label" for="g-tg">تلگرام</label>
          <input class="input" id="g-tg" name="telegram" value="{esc(s.get('telegram'))}"></div>
        <div class="field"><label class="field-label" for="g-wa">واتساپ</label>
          <input class="input" id="g-wa" name="whatsapp" value="{esc(s.get('whatsapp'))}"></div>
      </div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
    </div>
  </form>
</div>

<div class="tab-panel" id="p-m" role="tabpanel" aria-labelledby="t-m" hidden>
  <form method="post" action="/panel/settings">
    <input type="hidden" name="key" value="{esc(token)}">
    <div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-lg">{icon("map")} تنظیمات نقشه</h2>
      <div class="field"><label class="field-label" for="m-p">سرویس نقشه</label>
        <select class="select" id="m-p" name="map_provider">{popts}</select></div>
      <div class="field"><label class="field-label" for="m-k">کلید Google Maps API</label>
        <input class="input" id="m-k" name="gmaps_key" value="{esc(s.get('gmaps_key'))}"
               placeholder="AIza… (خالی بگذارید تا OpenStreetMap استفاده شود)" dir="ltr">
        <p class="field-hint">اگر کلید وارد نشود یا گوگل در دسترس نباشد،
          سایت به‌صورت خودکار از OpenStreetMap استفاده می‌کند.</p></div>
      <div class="grid grid-3" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="m-lat">عرض مرکز نقشه</label>
          <input class="input nums" id="m-lat" name="map_lat" value="{esc(s.get('map_lat'))}"></div>
        <div class="field"><label class="field-label" for="m-lng">طول مرکز نقشه</label>
          <input class="input nums" id="m-lng" name="map_lng" value="{esc(s.get('map_lng'))}"></div>
        <div class="field"><label class="field-label" for="m-z">بزرگ‌نمایی</label>
          <input class="input nums" id="m-z" name="map_zoom" type="number" min="1" max="20"
                 value="{esc(s.get('map_zoom'))}"></div>
      </div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
    </div>
  </form>
</div>

<div class="tab-panel" id="p-f" role="tabpanel" aria-labelledby="t-f" hidden>
  <form method="post" action="/panel/settings">
    <input type="hidden" name="key" value="{esc(token)}">
    <input type="hidden" name="features_tab" value="1">
    <div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-lg">{icon("zap")} فعال/غیرفعال کردن امکانات</h2>
      <label class="switch mb-md"><input type="checkbox" name="reg_open"
        {" checked" if s.get('reg_open')=='1' else ""}><span class="track"></span>
        <span>ثبت کسب‌وکار جدید توسط کاربران باز باشد</span></label>
      <label class="switch mb-md"><input type="checkbox" name="reviews_moderated"
        {" checked" if s.get('reviews_moderated')=='1' else ""}><span class="track"></span>
        <span>نظرات پیش از انتشار بررسی شوند</span></label>
      <label class="switch mb-md"><input type="checkbox" name="booking_enabled"
        {" checked" if s.get('booking_enabled')=='1' else ""}><span class="track"></span>
        <span>رزرو نوبت آنلاین فعال باشد</span></label>
      <label class="switch mb-md"><input type="checkbox" name="blog_enabled"
        {" checked" if s.get('blog_enabled')=='1' else ""}><span class="track"></span>
        <span>بخش اخبار و مقالات فعال باشد</span></label>
      <label class="switch mb-md"><input type="checkbox" name="catalog_enabled"
        {" checked" if s.get('catalog_enabled')=='1' else ""}><span class="track"></span>
        <span>کاتالوگ محصولات و خدمات فعال باشد</span></label>
      <label class="switch mb-md"><input type="checkbox" name="inquiry_enabled"
        {" checked" if s.get('inquiry_enabled')=='1' else ""}><span class="track"></span>
        <span>ارتباط با دکان‌دار (بدون شمارهٔ تلفن) فعال باشد</span></label>
      <label class="switch mb-md"><input type="checkbox" name="owner_login"
        {" checked" if s.get('owner_login')=='1' else ""}><span class="track"></span>
        <span>ورود صاحبان کسب‌وکار با پیامک فعال باشد</span></label>
      <label class="switch mb-md"><input type="checkbox" name="claims_enabled"
        {" checked" if s.get('claims_enabled')=='1' else ""}><span class="track"></span>
        <span>درخواست تصاحب کسب‌وکار فعال باشد</span></label>
      <hr class="divider">
      <label class="switch mb-lg"><input type="checkbox" name="maintenance"
        {" checked" if s.get('maintenance')=='1' else ""}><span class="track"></span>
        <span>حالت تعمیر و نگهداری (سایت برای بازدیدکنندگان بسته می‌شود)</span></label>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
    </div>
  </form>
</div>

<div class="tab-panel" id="p-x" role="tabpanel" aria-labelledby="t-x" hidden>
  <form method="post" action="/panel/settings">
    <input type="hidden" name="key" value="{esc(token)}">
    <div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-lg">{icon("message")} سرویس پیامک</h2>
      <div class="alert alert-info mb-lg">{icon("info")}
        <span>تا وقتی کلید وارد نشود، کد ورود روی صفحه نمایش داده می‌شود و
          سایت کاملاً بدون اینترنت کار می‌کند. با وارد کردن کلید، پیامک واقعی ارسال می‌شود.</span></div>
      <div class="field"><label class="field-label" for="x-key">کلید API (کاوه‌نگار)</label>
        <input class="input" id="x-key" name="sms_key" dir="ltr"
               value="{esc(s.get('sms_key'))}" placeholder="خالی = نمایش کد روی صفحه"></div>
      <div class="grid grid-2" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="x-send">شمارهٔ فرستنده</label>
          <input class="input" id="x-send" name="sms_sender" dir="ltr"
                 value="{esc(s.get('sms_sender'))}" placeholder="۱۰۰۰۴۳۴۶"></div>
        <div class="field"><label class="field-label" for="x-tpl">نام الگو (Lookup)</label>
          <input class="input" id="x-tpl" name="sms_template" dir="ltr"
                 value="{esc(s.get('sms_template'))}" placeholder="verify">
          <p class="field-hint">برای ارسال مطمئن‌تر کد تأیید.</p></div>
      </div>
      <div class="card glass card-pad mt-lg">
        <h3 class="card-title mb-md">{icon("send")} اعلان تلگرام (اختیاری و رایگان)</h3>
        <p class="text-sm text-muted mb-md">رویدادهای مهم (ثبت جدید، پیام مشتری، رزرو) به تلگرام شما هم
          ارسال می‌شود. با @BotFather ربات بسازید و توکن و شناسهٔ چت را اینجا بگذارید.</p>
        <div class="field"><label class="field-label" for="x-tg">توکن ربات</label>
          <input class="input" id="x-tg" name="tg_token" dir="ltr"
                 value="{esc(s.get('tg_token'))}" placeholder="123456:ABC-..."></div>
        <div class="field"><label class="field-label" for="x-tgc">شناسهٔ چت (عددی)</label>
          <input class="input" id="x-tgc" name="tg_chat_id" dir="ltr"
                 value="{esc(s.get('tg_chat_id'))}" placeholder="123456789"></div>
      </div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
    </div>
  </form>
</div>

<div class="tab-panel" id="p-s" role="tabpanel" aria-labelledby="t-s" hidden>
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("lock")} رمز عبور پنل</h2>
    <p class="text-sm text-muted mb-lg">علاوه بر کلید، برای ورود به پنل رمز عبور هم بخواهید.
      تا وقتی رمز تعیین نشده، پنل فقط با کلید باز می‌شود.</p>
    <form method="post" action="/panel/security" class="mb-md">
      <input type="hidden" name="key" value="{esc(token)}">
      <div class="field"><label class="field-label" for="op">رمز عبور جدید</label>
        <input class="input" id="op" type="password" name="owner_password"
               autocomplete="new-password" minlength="6" placeholder="دست‌کم ۶ نویسه" dir="ltr"></div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>تنظیم رمز عبور</span></button>
    </form>
    <form method="post" action="/panel/security" data-confirm="رمز عبور حذف شود؟">
      <input type="hidden" name="key" value="{esc(token)}">
      <input type="hidden" name="clear_password" value="1">
      <button class="btn btn-ghost" type="submit"{" disabled" if not s.get('owner_pass_hash') else ""}>
        {icon("x")}<span>حذف رمز عبور</span></button>
    </form>
  </div>
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("shield")} کلید دسترسی پنل</h2>
    <p class="text-sm text-muted mb-lg">این نشانی را نزد خود نگه دارید. هرکس آن را داشته باشد
      به پنل مدیریت دسترسی کامل دارد.</p>
    <div class="field"><label class="field-label" for="tok">نشانی ورود به پنل</label>
      <input class="input" id="tok" value="/panel?key={esc(token)}" readonly dir="ltr"></div>
    <div class="cluster">
      <button class="btn btn-glass" type="button" data-copy="/panel?key={esc(token)}">
        {icon("share")}<span>کپی نشانی</span></button>
      <form method="post" action="/panel/rotate-token" style="display:inline"
            data-confirm="کلید فعلی باطل می‌شود و باید نشانی جدید را یادداشت کنید. ادامه؟">
        <input type="hidden" name="key" value="{esc(token)}">
        <button class="btn btn-danger" type="submit">{icon("refresh")}<span>تولید کلید جدید</span></button>
      </form>
    </div>
    <div class="alert alert-warn mt-lg">{icon("alert")}
      <span>پیش از آپلود روی هاست حتماً کلید جدید بسازید تا کلید موجود در فایل زیپ باطل شود.</span></div>
  </div>
</div>'''
    return panel_page(s, "تنظیمات سایت",
                      "اطلاعات کلی، نقشه، امکانات و امنیت.", content, "/panel/settings", token)


# ------------------------------------------------------------------ backup
def backup_page(s, token, q=None):
    st = db.stats()
    content = f'''{_msg(q or {})}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("store", st['businesses'], "کسب‌وکار")}
  {stat_card("layers", st['categories'], "دسته", delay=60)}
  {stat_card("message", st['reviews'], "نظر", delay=120)}
  {stat_card("book", st['posts'], "مطلب", delay=180)}
</div>
<div class="grid grid-2" style="align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("download")} دریافت پشتیبان</h2>
    <p class="text-sm text-muted mb-lg">یک فایل JSON شامل همهٔ داده‌های سایت
      (کسب‌وکارها، دسته‌ها، نظرات، تنظیمات و رنگ‌ها) دانلود می‌شود.</p>
    <div class="cluster">
      <a class="btn btn-primary" href="/panel/backup/export?key={esc(token)}">
        {icon("download")}<span>فایل JSON</span></a>
      <a class="btn btn-glass" href="/panel/backup/full?key={esc(token)}">
        {icon("database")}<span>بکاپ کامل (JSON + تصاویر)</span></a>
    </div>
    <p class="text-sm text-muted mt-md">آخرین پشتیبان: <strong class="nums">
      {esc(s.get('last_backup_at') or 'هنوز نگرفته‌اید')}</strong></p>
  </div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("upload")} بازیابی از فایل</h2>
    <form method="post" action="/panel/backup/import" data-validate>
      <input type="hidden" name="key" value="{esc(token)}">
      <div class="field"><label class="field-label" for="bk-json">محتوای فایل پشتیبان</label>
        <textarea class="textarea" id="bk-json" name="payload" required dir="ltr"
          style="min-height:180px;font-family:ui-monospace,monospace;font-size:12px"
          placeholder='{{"settings": [...], "businesses": [...]}}'></textarea>
        <p class="field-hint">محتوای فایل JSON را اینجا بچسبانید.</p></div>
      <div class="alert alert-warn mb-lg">{icon("alert")}
        <span>بازیابی همهٔ داده‌های فعلی را جایگزین می‌کند.</span></div>
      <button class="btn btn-danger btn-block" type="submit">
        {icon("upload")}<span>بازیابی داده‌ها</span></button>
    </form>
  </div>
</div>'''
    return panel_page(s, "پشتیبان‌گیری و بازیابی",
                      "از داده‌های سایت نسخهٔ پشتیبان بگیرید یا بازیابی کنید.",
                      content, "/panel/backup", token)


def password_gate(s, err=""):
    from ui import page
    err_html = flash("err", err) if err else ""
    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass" style="text-align:center">
    <div class="auth-head"><span class="mark">{icon("lock")}</span>
      <h1>رمز عبور پنل</h1>
      <p>پنل مدیریت با رمز عبور محافظت می‌شود. آن را وارد کنید.</p></div>
    {err_html}
    <form method="post" action="/panel/login">
      <input type="hidden" name="key" value="{esc(s.get('owner_token',''))}">
      <div class="field"><label class="field-label" for="pw">رمز عبور</label>
        <input class="input" id="pw" type="password" name="password"
               autocomplete="current-password" required autofocus
               placeholder="••••••••"></div>
      <button class="btn btn-primary btn-block mt-lg" type="submit">
        {icon("shield")}<span>ورود به پنل</span></button>
    </form>
  </div></div></div>'''
    return page(s, "رمز عبور پنل", body, "", cats=[], show_chrome=False)


def login_gate(s):
    from ui import page
    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass" style="text-align:center">
    <div class="auth-head"><span class="mark">{icon("lock")}</span>
      <h1>دسترسی محدود</h1>
      <p>برای ورود به پنل مدیریت، نشانی همراه با کلید دسترسی لازم است.</p></div>
    <div class="alert alert-info" style="text-align:start">{icon("info")}
      <span>نشانی صحیح پنل هنگام اجرای <code>run.py</code> در Pydroid چاپ می‌شود.</span></div>
    <a class="btn btn-primary btn-block mt-lg" href="/">{icon("store")}<span>بازگشت به سایت</span></a>
  </div></div></div>'''
    return page(s, "دسترسی محدود", body, "", cats=[], show_chrome=False)


# ==========================================================================
#  OWNERS  &  CLAIMS  (admin)
# ==========================================================================
def owner_list(s, token, q=None):
    rows = db.owners()
    trs = "".join(f'''<tr>
      <td><div style="display:flex;align-items:center;gap:10px">
        <span class="avatar" style="width:36px;height:36px;font-size:14px" aria-hidden="true">
          {esc((o["name"] or o["phone"])[:1])}</span>
        <div><strong>{esc(o["name"] or "بدون نام")}</strong><br>
          <small class="text-muted nums">{esc(o["phone"])}</small></div></div></td>
      <td class="num">{fa(o["n_biz"])}</td>
      <td class="num nums">{fa(str(o["created"])[:10])}</td>
      <td class="num nums">{fa(str(o["last_login"] or "—")[:16])}</td>
      <td><span class="badge {"badge-open" if o["status"]=="active" else "badge-closed"}">
        {"فعال" if o["status"]=="active" else "مسدود"}</span></td>
      <td class="actions">
        <form method="post" action="/panel/owner/{o["id"]}" style="display:inline">
          <input type="hidden" name="key" value="{esc(token)}">
          <input type="hidden" name="status" value="{"blocked" if o["status"]=="active" else "active"}">
          <button class="btn-icon" type="submit"
            aria-label="{"مسدودسازی" if o["status"]=="active" else "فعال‌سازی"} {esc(o["phone"])}"
            title="{"مسدود کن" if o["status"]=="active" else "فعال کن"}">
            {icon("lock" if o["status"]=="active" else "check")}</button></form>
        <form method="post" action="/panel/owner/{o["id"]}" style="display:inline"
              data-confirm="حساب {esc(o["phone"])} حذف شود؟ کسب‌وکارهایش حذف نمی‌شوند و بدون مالک می‌مانند.">
          <input type="hidden" name="key" value="{esc(token)}">
          <input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف حساب"
            aria-label="حذف حساب {esc(o["phone"])}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for o in rows)
    if not trs:
        trs = '<tr><td colspan="6" class="text-center text-muted" style="padding:var(--space-xl)">هنوز کسی ثبت‌نام نکرده</td></tr>'
    content = f'''{_msg(q or {})}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("users", len(rows), "کل صاحبان")}
  {stat_card("check-circle", sum(1 for o in rows if o["status"]=="active"), "فعال", delay=60)}
  {stat_card("store", sum(o["n_biz"] for o in rows), "کسب‌وکار واگذارشده", delay=120)}
  {stat_card("lock", sum(1 for o in rows if o["status"]!="active"), "مسدود", delay=180)}
</div>
<div class="card glass card-pad">
  <div class="table-wrap"><table class="table">
    <thead><tr><th>کاربر</th><th>کسب‌وکار</th><th>عضویت</th><th>آخرین ورود</th><th>وضعیت</th><th></th></tr></thead>
    <tbody>{trs}</tbody></table></div></div>'''
    return panel_page(s, "صاحبان کسب‌وکار",
                      "کسانی که با شمارهٔ موبایل وارد می‌شوند و کسب‌وکار خود را مدیریت می‌کنند.",
                      content, "/panel/owners", token)


def claim_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or [""])[0]
    rows = db.claims(status or None)
    items = "".join(f'''<article class="review">
      <div class="review-head">
        <span class="avatar" aria-hidden="true">{esc((c["ownername"] or c["phone"])[:1])}</span>
        <div style="flex:1"><strong>{esc(c["ownername"] or "بدون نام")}</strong>
          <div class="card-meta" style="margin-top:3px">
            <span class="nums">{esc(c["phone"])}</span><span aria-hidden="true">·</span>
            <span>می‌خواهد <a href="/b/{esc(c["bizslug"])}">{esc(c["bizname"])}</a> را تصاحب کند</span>
            <span aria-hidden="true">·</span><span>{esc(str(c["created"])[:16])}</span></div></div>
        <span class="badge {"badge-open" if c["status"]=="approved" else ("badge-warn" if c["status"]=="pending" else "badge-closed")}">
          {esc({"approved":"تأییدشده","pending":"در انتظار","rejected":"رد شده"}.get(c["status"]))}</span>
      </div>
      {f'<p class="review-body">{esc(c["note"])}</p>' if c.get("note") else ""}
      {"" if c["status"] != "pending" else f"""<form method="post" action="/panel/claim/{c["id"]}" class="mt-md">
        <input type="hidden" name="key" value="{esc(token)}">
        <div class="cluster">
          <button class="btn btn-primary btn-sm" type="submit" name="action" value="approve">
            {icon("check")}<span>تأیید و واگذاری</span></button>
          <a class="btn btn-glass btn-sm" href="tel:{esc(c["phone"])}">{icon("phone")}<span>تماس برای احراز</span></a>
          <button class="btn btn-ghost btn-sm" type="submit" name="action" value="reject"
            style="color:var(--color-destructive)">{icon("x")}<span>رد</span></button>
        </div></form>"""}
    </article>''' for c in rows)
    if not items:
        items = f'''<div class="empty-state"><span class="icon-wrap">{icon("shield")}</span>
          <h3>درخواستی نیست</h3>
          <p>وقتی صاحب کسب‌وکاری بگوید «این مال من است»، اینجا برای تأیید می‌بینید.</p></div>'''
    filt = "".join(f'<a class="chip{" is-active" if status==v else ""}" '
                   f'href="/panel/claims?key={esc(token)}&status={v}">{t}</a>'
                   for v, t in [("","همه"),("pending","در انتظار"),
                                ("approved","تأییدشده"),("rejected","رد شده")])
    content = f'{_msg(q)}<div class="cluster mb-lg">{filt}</div><div class="card glass card-pad">{items}</div>'
    return panel_page(s, "درخواست‌های تصاحب",
                      "پیش از تأیید، با شمارهٔ اعلامی تماس بگیرید و مالکیت را احراز کنید.",
                      content, "/panel/claims", token)


# ==========================================================================
#  CSV IMPORT PAGE
# ==========================================================================
def csv_import(s, token, q=None, result=None):
    cats = db.categories(only_active=False)
    sample = "name,cat_slug,descr,phone,address,tags,status\n" \
             "کبابی نمونه,restaurant,کباب سنتی,03142600000,خیابان امام,کباب,published"

    res_html = ""
    if result:
        added, updated, errors = result
        rows = "".join(f'<li>{icon("alert")}<span>{esc(e)}</span></li>' for e in errors[:20])
        res_html = f'''<div class="card glass card-pad mb-lg">
          <h2 class="card-title mb-lg">{icon("check-circle")} نتیجهٔ ورود</h2>
          <div class="grid grid-3" data-stagger>
            {stat_card("plus", added, "افزوده‌شده")}
            {stat_card("refresh", updated, "به‌روزشده", delay=60)}
            {stat_card("alert", len(errors), "خطا", delay=120)}
          </div>
          {f'<div class="prose mt-lg"><ul>{rows}</ul></div>' if errors else ""}
          {f'<p class="text-xs text-muted mt-md">{fa(len(errors)-20)} خطای دیگر نمایش داده نشد.</p>' if len(errors) > 20 else ""}
        </div>'''

    cat_rows = "، ".join(f"<code>{esc(c['slug'])}</code>" for c in cats[:20])

    content = f'''{_msg(q or {})}
{res_html}
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-lg">{icon("upload")} ورود کسب‌وکارها از فایل CSV</h2>
  <p class="text-sm text-muted mb-lg">محتوای فایل CSV را اینجا بچسبانید. اگر نام یا
    شمارهٔ تماس با کسب‌وکار موجودی یکسان باشد، به‌جای ایجاد تکراری
    <strong>به‌روزرسانی</strong> می‌شود.</p>
  <form method="post" action="/panel/businesses/import" data-validate>
    <input type="hidden" name="key" value="{esc(token)}">
    <div class="field">
      <label class="field-label" for="csv">محتوای CSV<span class="req">*</span></label>
      <textarea class="textarea" id="csv" name="csv" required dir="ltr"
        style="min-height:220px;font-family:ui-monospace,monospace;font-size:12px"
        placeholder="{esc(sample)}"></textarea>
    </div>
    <button class="btn btn-primary btn-lg" type="submit">
      {icon("upload")}<span>شروع ورود</span></button>
    <a class="btn btn-ghost btn-lg" href="/panel/businesses?key={esc(token)}">
      {icon("x")}<span>انصراف</span></a>
  </form>
</div>

<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("info")} راهنمای ستون‌ها</h2>
  <div class="prose" style="max-width:none">
    <p>سطر اول باید نام ستون‌ها باشد. ستون‌های پشتیبانی‌شده:</p>
    <p><code>{"</code>، <code>".join(db.CSV_COLUMNS)}</code></p>
    <p><strong>الزامی:</strong> <code>name</code> و <code>cat_slug</code></p>
    <p><strong>شناسهٔ دسته‌های موجود:</strong> {cat_rows}</p>
    <p><code>status</code> یکی از: <code>published</code>، <code>pending</code>،
       <code>hidden</code>. <code>featured</code> و <code>verified</code> با
       <code>1</code> یا خالی.</p>
  </div>
  <hr class="divider">
  <p class="text-sm text-muted mb-md">نمونه:</p>
  <pre style="background:var(--color-muted);padding:14px;border-radius:var(--radius-md);
    overflow-x:auto;font-size:12px;direction:ltr;text-align:left">{esc(sample)}</pre>
  <a class="btn btn-glass mt-lg" href="/panel/businesses/export?key={esc(token)}">
    {icon("download")}<span>دانلود نمونه از داده‌های فعلی</span></a>
</div>'''
    return panel_page(s, "ورود از CSV",
                      "افزودن یا به‌روزرسانی گروهی کسب‌وکارها.",
                      content, "/panel/businesses", token)
