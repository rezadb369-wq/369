#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prove every panel action REALLY changes the database — not just returns 303.
Each check reads the data back after the request.
"""

import os
import sys
import json
import urllib.parse
import urllib.request
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db

sys.path.insert(0, HERE)
db.rate_clear()   # spam protection would otherwise throttle the run
import reset_testdata as _reset   # leftovers would break the counts below
_reset.wipe_fixtures()

BASE = os.environ.get("BZ", "http://127.0.0.1:8080")
P, F = [], []


def ok(name, cond, detail=""):
    (P if cond else F).append(name)
    print(("  ✓ " if cond else "  ✗ ") + name + (f"   [{detail}]" if detail and not cond else ""))


def sec(t):
    print("\n" + "─" * 62)
    print("  " + t)
    print("─" * 62)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


class C:
    def __init__(self):
        self.op = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()), NoRedirect())

    def get(self, p):
        try:
            r = self.op.open(urllib.request.Request(BASE + p), timeout=20)
            return r.getcode(), r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")

    def post(self, p, d):
        body = urllib.parse.urlencode(d, doseq=True).encode()
        req = urllib.request.Request(BASE + p, data=body, headers={
            "Content-Type": "application/x-www-form-urlencoded"})
        try:
            r = self.op.open(req, timeout=20)
            return r.getcode(), r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")


def otp(ph):
    con = db.connect()
    r = con.execute("SELECT code FROM otp WHERE phone=?", (db.norm_phone(ph),)).fetchone()
    con.close()
    return r["code"] if r else ""


def main():
    tok = db.owner_token()
    a, g, o = C(), C(), C()

    sec("مدیر: کسب‌وکار")
    a.post("/panel/business/new", {
        "key": tok, "name": "آزمون عملیات", "cat_slug": "restaurant",
        "descr": "برای اثبات کارکرد دکمه‌ها.", "phone": "03199999999",
        "address": "نشانی", "status": "published"})
    b = [x for x in db.businesses(status=None) if x["name"] == "آزمون عملیات"]
    ok("ایجاد", bool(b))
    bid = b[0]["id"] if b else 0

    a.post(f"/panel/business/{bid}", {
        "key": tok, "name": "آزمون عملیات ویرایش‌شده", "cat_slug": "cafe",
        "descr": "توضیح تازه.", "phone": "03188888888",
        "address": "نشانی نو", "status": "published"})
    x = db.business(bid=bid)
    ok("ویرایش نام", x["name"] == "آزمون عملیات ویرایش‌شده")
    ok("ویرایش دسته", x["cat_slug"] == "cafe")
    ok("ویرایش تلفن", x["phone"] == "03188888888")

    a.post(f"/panel/business/{bid}/toggle", {"key": tok, "field": "featured"})
    ok("دکمهٔ ویژه", db.business(bid=bid)["featured"] == 1)
    a.post(f"/panel/business/{bid}/toggle", {"key": tok, "field": "featured"})
    ok("لغو ویژه", db.business(bid=bid)["featured"] == 0)

    for st in ("hidden", "pending", "rejected", "published"):
        a.post(f"/panel/business/{bid}/status", {"key": tok, "status": st})
        ok(f"وضعیت → {st}", db.business(bid=bid)["status"] == st)

    sec("مدیر: دسته‌بندی")
    a.post("/panel/category/new", {"key": tok, "name": "دستهٔ آزمون",
                                   "icon": "gym", "blurb": "توضیح"})
    c = [x for x in db.categories(only_active=False) if x["name"] == "دستهٔ آزمون"]
    ok("ایجاد دسته", bool(c))
    cid = c[0]["id"] if c else 0
    a.post(f"/panel/category/{cid}", {"key": tok, "name": "دستهٔ ویرایش‌شده",
                                      "icon": "flowers", "blurb": "نو", "sort": "5"})
    c2 = db.category_by_id(cid)
    ok("ویرایش نام دسته", c2 and c2["name"] == "دستهٔ ویرایش‌شده")
    ok("ویرایش آیکون", c2 and c2["icon"] == "flowers")
    ok("غیرفعال شد (بدون active)", c2 and c2["active"] == 0)
    a.post(f"/panel/category/{cid}", {"key": tok, "name": "دستهٔ ویرایش‌شده",
                                      "icon": "flowers", "sort": "5", "active": "on"})
    ok("فعال‌سازی مجدد", db.category_by_id(cid)["active"] == 1)
    a.post(f"/panel/category/{cid}/delete", {"key": tok})
    ok("حذف دسته", db.category_by_id(cid) is None)

    sec("مدیر: کاتالوگ")
    a.post(f"/panel/catalog/{bid}/item/new", {
        "key": tok, "kind": "product", "title": "کالای آزمون",
        "price_type": "fixed", "price": "50000", "available": "on"})
    it = db.items(biz_id=bid)
    ok("افزودن کالا", len(it) == 1)
    iid = it[0]["id"] if it else 0
    a.post(f"/panel/catalog/{bid}/item/{iid}", {
        "key": tok, "kind": "service", "title": "کالای ویرایش‌شده",
        "price_type": "from", "price": "75000", "unit": "ساعت", "available": "on"})
    i2 = db.item(iid)
    ok("ویرایش کالا", i2["title"] == "کالای ویرایش‌شده")
    ok("تغییر نوع", i2["kind"] == "service")
    ok("تغییر قیمت", i2["price"] == 75000)
    a.post(f"/panel/catalog/{bid}/item/{iid}/delete", {"key": tok})
    ok("حذف کالا", db.item(iid) is None)

    sec("مدیر: نظرات")
    b0 = db.businesses(status=None)[0]
    g.post(f"/b/{b0['slug']}/review", {"author": "منتقد", "rating": "4",
                                       "body": "نظری برای آزمون عملیات."})
    r = db.reviews(status="pending")
    ok("ثبت نظر", bool(r))
    rid = r[0]["id"] if r else 0
    a.post(f"/panel/review/{rid}", {"key": tok, "action": "approve"})
    ok("تأیید نظر", any(x["id"] == rid for x in db.reviews(status="approved")))
    a.post(f"/panel/review/{rid}", {"key": tok, "action": "reject"})
    ok("رد نظر", any(x["id"] == rid for x in db.reviews(status="rejected")))
    a.post(f"/panel/review/{rid}", {"key": tok, "reply": "پاسخ مدیر"})
    ok("پاسخ به نظر", [x for x in db.reviews() if x["id"] == rid][0]["reply"] == "پاسخ مدیر")
    a.post(f"/panel/review/{rid}", {"key": tok, "action": "delete"})
    ok("حذف نظر", not any(x["id"] == rid for x in db.reviews()))

    sec("مدیر: مطلب / پیام")
    a.post("/panel/post/new", {"key": tok, "title": "مطلب آزمون",
                               "excerpt": "خ", "body": "متن"})
    po = [x for x in db.posts(status=None) if x["title"] == "مطلب آزمون"]
    ok("انتشار مطلب", bool(po))
    if po:
        a.post(f"/panel/post/{po[0]['id']}/delete", {"key": tok})
        ok("حذف مطلب", not [x for x in db.posts(status=None) if x["title"] == "مطلب آزمون"])

    before_messages = len(db.messages())
    code, _ = g.post("/contact", {"name": "پیام‌دهنده", "email": "x@y.ir",
                        "subject": "س", "body": "متن پیام آزمون."})
    ok("پشتیبانی یک‌طرفه غیرفعال و به تیکت هدایت می‌شود",
       code in (302,303) and len(db.messages()) == before_messages)

    sec("مدیر: صفحات ثابت و تنظیمات")
    a.post("/panel/pages", {"key": tok, "slug": "about",
                            "title": "درباره آزمون", "body": "متن آزمون"})
    ok("ذخیرهٔ صفحهٔ ثابت", db.get_page("about")["title"] == "درباره آزمون")
    ok("روی سایت دیده می‌شود", "درباره آزمون" in g.get("/about")[1])

    for key, val, label in [("site_name", "نام آزمون", "نام سایت"),
                            ("tagline", "شعار آزمون", "شعار"),
                            ("email", "test@ops.ir", "ایمیل")]:
        a.post("/panel/settings", {"key": tok, key: val,
                                   "site_name": val if key == "site_name" else "بازارچه",
                                   "tagline": val if key == "tagline" else "ش",
                                   "email": val if key == "email" else "e@e.ir"})
        ok(f"تنظیم {label}", db.get_settings().get(key) == val)

    for t in ("reg_open", "booking_enabled", "blog_enabled",
              "catalog_enabled", "maintenance"):
        a.post("/panel/settings", {"key": tok, t: "on"})
        on = db.get_settings().get(t) == "1"
        a.post("/panel/settings", {"key": tok, "reg_open": "on"})  # clear others
        ok(f"کلید {t}", on)
    a.post("/panel/settings", {"key": tok, "reg_open": "on", "booking_enabled": "on",
                               "blog_enabled": "on",
                               "catalog_enabled": "on", "inquiry_enabled": "on",
                               "reviews_moderated": "on", "owner_login": "on",
                               "claims_enabled": "on"})

    sec("مدیر: صاحبان و تصاحب")
    PH = "09127770000"
    o.post("/login", {"phone": PH})
    o.post("/login/verify", {"phone": PH, "code": otp(PH)})
    own = db.owner_by_phone(PH)
    ok("ایجاد حساب فروشنده", bool(own))
    a.post(f"/panel/owner/{own['id']}", {"key": tok, "status": "blocked"})
    ok("مسدودسازی کاربر", db.owner_by_id(own["id"])["status"] == "blocked")
    a.post(f"/panel/owner/{own['id']}", {"key": tok, "status": "active"})
    ok("فعال‌سازی مجدد", db.owner_by_id(own["id"])["status"] == "active")

    o2 = C()
    o2.post("/login", {"phone": PH})
    o2.post("/login/verify", {"phone": PH, "code": otp(PH)})
    db.set_business_owner(bid, None)
    o2.post("/my/claim", {"biz_id": bid})
    cl = db.claims(status="pending")
    ok("ثبت درخواست تصاحب", bool(cl))
    if cl:
        a.post(f"/panel/claim/{cl[0]['id']}", {"key": tok, "action": "reject"})
        ok("رد تصاحب", db.claims(status="rejected"))
        o2.post("/my/claim", {"biz_id": bid})
        cl2 = db.claims(status="pending")
        if cl2:
            a.post(f"/panel/claim/{cl2[0]['id']}", {"key": tok, "action": "approve"})
            ok("تأیید تصاحب → واگذاری", db.business(bid=bid)["owner_id"] == own["id"])

    sec("فروشنده: عملیات")
    o3 = C()
    o3.post("/login", {"phone": PH})
    o3.post("/login/verify", {"phone": PH, "code": otp(PH)})
    o3.post(f"/my/business/{bid}", {
        "name": "نام از سمت فروشنده", "cat_slug": "cafe",
        "descr": "توضیح از سمت فروشنده.", "phone": "03177777777",
        "address": "نشانی فروشنده", "booking_on": "on"})
    x = db.business(bid=bid)
    ok("ویرایش توسط فروشنده", x["name"] == "نام از سمت فروشنده")
    ok("فعال‌سازی نوبت", x["booking_on"] == 1)

    o3.post(f"/my/catalog/{bid}/item/new", {
        "kind": "custom", "title": "کار سفارشی فروشنده",
        "price_type": "call", "available": "on"})
    ok("افزودن کالا توسط فروشنده", len(db.items(biz_id=bid)) == 1)

    g.post(f"/b/{x['slug']}/book", {"name": "مشتری", "phone": "09120001111",
                                    "date": "2026-10-01", "time": "18:00"})
    bk = db.bookings()
    ok("ثبت نوبت", bool(bk))
    if bk:
        o3.post(f"/my/booking/{bk[0]['id']}", {"status": "confirmed"})
        ok("تأیید نوبت توسط فروشنده", db.bookings()[0]["status"] == "confirmed")

    # v88: customers reach a shop through chat now, not the anonymous /ask
    # inquiry. Seed one inquiry directly to keep covering the owner's
    # back-office quote/won workflow.
    db.add_inquiry(bid, "پرسشگر", "", "متن استعلام برای آزمون.")
    iq = db.inquiries(biz_id=bid)
    ok("ثبت استعلام", bool(iq))
    if iq:
        o3.post(f"/my/inquiry/{iq[0]['id']}", {"action": "quote", "quote": "۵۰۰ هزار"})
        ok("پاسخ استعلام", db.inquiries(biz_id=bid)[0]["status"] == "quoted")
        o3.post(f"/my/inquiry/{iq[0]['id']}", {"action": "won"})
        ok("علامت تبدیل‌شده", db.inquiries(biz_id=bid)[0]["status"] == "won")

    sec("حذف نهایی")
    a.post(f"/panel/business/{bid}/delete", {"key": tok})
    ok("حذف کسب‌وکار", db.business(bid=bid) is None)
    ok("کالاهایش هم حذف شد (cascade)", not db.items(biz_id=bid))

    print("\n" + "═" * 62)
    print(f"  موفق: {len(P)}   ناموفق: {len(F)}")
    if F:
        for n in F:
            print("    ✗ " + n)
    print("═" * 62)
    return 1 if F else 0


if __name__ == "__main__":
    sys.exit(main())
