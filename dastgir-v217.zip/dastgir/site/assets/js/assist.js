/* v213.2 — دستیار هوشمند دست گیر
   (1) floating live bar + one-time invite on every public page
   (2) the chat page /assistant. Talks only to same-origin /api/assistant/*. */
(function () {
  'use strict';
  const $ = (sel, root) => (root || document).querySelector(sel);
  const fa = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]);
  const HINTS = [
    'آنلاین · بپرسید: «داروخانهٔ شبانه‌روزی نزدیک من؟»',
    'آنلاین · «بهترین کافهٔ باز الان کجاست؟»',
    'آنلاین · «ثبت مغازه‌ام چقدر طول می‌کشه؟»',
    'آنلاین · «آخرین سفارشم در چه وضعیتیه؟»',
    'آنلاین · «برای تعمیر موبایل کجا برم؟»',
  ];

  /* ---------- floating bar + invite ---------- */
  const bar = $('[data-ai-bar]');
  if (bar) {
    const live = $('[data-ai-live]', bar);
    setTimeout(() => { bar.hidden = false; }, 1500);
    let i = 0;
    setInterval(() => { if (live) { i = (i + 1) % HINTS.length; live.textContent = HINTS[i]; } }, 4500);
    fetch('/api/assistant/status', { credentials: 'same-origin' }).then((r) => r.json()).then((r) => {
      if (r && r.enabled === false) bar.hidden = true;
    }).catch(() => {});

    const invite = $('[data-ai-invite]');
    const KEY = 'dastgir.ai.invited.v213';
    let seen = false;
    try { seen = localStorage.getItem(KEY) === '1'; } catch (e) {}
    if (invite && !seen) {
      const close = () => { invite.hidden = true; try { localStorage.setItem(KEY, '1'); } catch (e) {} };
      setTimeout(() => { invite.hidden = false; }, 6000);
      invite.querySelectorAll('[data-ai-invite-close]').forEach((b) => b.addEventListener('click', close));
      invite.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => { try { localStorage.setItem(KEY, '1'); } catch (e) {} }));
      document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !invite.hidden) close(); });
    }
  }

  /* ---------- chat page ---------- */
  const pageEl = $('[data-ai-page]');
  if (!pageEl) return;
  const log = $('[data-ai-log]', pageEl);
  const form = $('[data-ai-form]', pageEl);
  const input = $('#ai-input', pageEl);
  const quotaEl = $('[data-ai-quota]', pageEl);
  const history = [];
  let busy = false;

  const setQuota = (r) => {
    if (!quotaEl || !r || typeof r.remaining !== 'number' || typeof r.quota !== 'number') return;
    quotaEl.textContent = (r.tier_label ? r.tier_label + ' · ' : '') + fa(r.remaining) + ' از ' + fa(r.quota) + ' پیام امروز';
    quotaEl.classList.toggle('ai-quota-warn', r.remaining === 0);
  };

  const bubble = (text, who, links) => {
    const div = document.createElement('div');
    div.className = 'ai-msg ' + (who === 'user' ? 'ai-user' : 'ai-bot');
    const p = document.createElement('p'); p.textContent = text; div.appendChild(p);
    if (links && links.length) {
      const wrap = document.createElement('div'); wrap.className = 'ai-links';
      links.forEach((l) => {
        if (!l || !l.href || !/^\//.test(l.href)) return;
        const a = document.createElement('a'); a.href = l.href; a.textContent = l.label || l.href; wrap.appendChild(a);
      });
      div.appendChild(wrap);
    }
    log.appendChild(div); log.scrollTop = log.scrollHeight; return div;
  };

  const ask = (text) => {
    text = String(text || '').trim().slice(0, 400);
    if (!text || busy) return;
    busy = true;
    const starts = $('[data-ai-starts]', pageEl); if (starts) starts.hidden = true;
    bubble(text, 'user'); history.push({ role: 'user', text });
    const typing = bubble('در حال فکر کردن', 'bot'); typing.classList.add('ai-typing');
    input.value = ''; input.style.height = '';
    fetch('/api/assistant/chat', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, history: history.slice(-8) }),
    }).then((r) => r.json().catch(() => ({ ok: false, text: 'پاسخ نامعتبر بود.' })))
      .then((r) => {
        typing.remove();
        bubble(r.text || 'پاسخی دریافت نشد.', 'bot', r.links);
        history.push({ role: 'assistant', text: r.text || '' });
        if (history.length > 10) history.splice(0, history.length - 10);
        setQuota(r);
      })
      .catch(() => { typing.remove(); bubble('ارتباط برقرار نشد؛ دوباره تلاش کنید.', 'bot'); })
      .finally(() => { busy = false; input.focus(); });
  };

  form.addEventListener('submit', (e) => { e.preventDefault(); ask(input.value); });
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ask(input.value); } });
  input.addEventListener('input', () => { input.style.height = ''; input.style.height = Math.min(140, input.scrollHeight) + 'px'; });
  pageEl.addEventListener('click', (e) => { const b = e.target.closest('[data-ai-q]'); if (b) ask(b.getAttribute('data-ai-q')); });
  const q = new URLSearchParams(location.search).get('q');
  if (q) ask(q); else input.focus();
})();
