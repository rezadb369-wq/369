# -*- coding: utf-8 -*-
"""v213 «دستیار هوشمند دست گیر» — site-scoped assistant for web + Bale + Soroush.

Design (agreed):
  * The language model NEVER acts. It only maps free text to a closed intent
    JSON ({"intent", "q", "reply"}); every answer is produced here from the
    same read-only helpers the menus already use (search summaries, order
    summaries, plans…). Writes (orders, bookings, registration) are never
    performed by the assistant — it links/hands off to the existing flows,
    which carry their own confirmation steps.
  * Provider-agnostic OpenAI-compatible endpoint. Configured ONLY by env
    (`/etc/dastgir-secrets.env`): AI_BASE_URL, AI_API_KEY, AI_MODEL,
    optional AI_MODEL_SMART, AI_FALLBACK_BASE_URL/AI_FALLBACK_API_KEY/
    AI_FALLBACK_MODEL, AI_TIMEOUT. The key is never logged, rendered or
    serialised (see `public_config`).
  * Rule-based first: obvious requests («سفارش‌های من», «ثبت کسب‌وکار», …)
    are answered with zero model calls. The model is consulted only for
    ambiguous text, and when it is missing/failing/over budget the rules
    still answer — the assistant degrades, never disappears.
  * Daily quota per person: 5 (no plan) / 20 (حرفه‌ای = plus) / 50
    (ویژهٔ دست گیر = pro), admin-adjustable in /panel/assistant, plus a
    global daily cap that bounds the monthly bill.
"""
import os, re, json, time, datetime, threading, urllib.parse, urllib.request, urllib.error
import db

SITE = "https://daastgir.ir"
VERSION = 217

# ------------------------------------------------------------------ config
def _env(name, default=""):
    return (os.environ.get(name) or default).strip()


def config():
    """Live env snapshot. Values are read on every call so a service restart
    after editing the EnvironmentFile is the only deployment step."""
    base = _env("AI_BASE_URL").rstrip("/")
    return {
        "base_url": base,
        "api_key": _env("AI_API_KEY"),
        "model": _env("AI_MODEL", "gemini-2.5-flash-lite"),
        "model_smart": _env("AI_MODEL_SMART"),
        "fb_base_url": _env("AI_FALLBACK_BASE_URL").rstrip("/"),
        "fb_api_key": _env("AI_FALLBACK_API_KEY"),
        "fb_model": _env("AI_FALLBACK_MODEL"),
        "timeout": max(3.0, min(40.0, float(_env("AI_TIMEOUT", "12") or 12))),
    }


def configured():
    c = config()
    return bool(c["base_url"] and c["api_key"] and c["model"])


def public_config():
    """What the admin panel may show. The key is reduced to a boolean."""
    c = config()
    return {"base_url": c["base_url"], "model": c["model"],
            "model_smart": c["model_smart"], "has_key": bool(c["api_key"]),
            "fallback": bool(c["fb_base_url"] and c["fb_api_key"] and c["fb_model"]),
            "fallback_model": c["fb_model"], "timeout": c["timeout"]}


def enabled():
    s = db.get_settings()
    return s.get("ai_enabled", "1") == "1"


# ------------------------------------------------------------------ quota
PLAN_SLUG_TIER = {"plus": "plus", "pro": "pro"}     # seeded slugs (db.DEFAULT_PLANS)


def _int_setting(s, key, default):
    try:
        return max(0, int(str(s.get(key, default) or default)))
    except (TypeError, ValueError):
        return default


def tier_of(customer=None, owner=None):
    """Highest live plan among the person's businesses → 'free'|'plus'|'pro'.
    Owner is derived from the customer phone when only a customer is known
    (same rule as bot_menu._owner_account)."""
    o = owner
    if not o and customer and customer.get("phone"):
        try:
            o = db.owner_by_phone(customer.get("phone") or "", create=False)
        except Exception:
            o = None
    if not o or o.get("status") == "blocked":
        return "free"
    best = "free"
    try:
        for b in db.businesses_of(o["id"]):
            sub = db.subscription_of(b["id"])
            if not sub:
                continue
            t = PLAN_SLUG_TIER.get(sub.get("plan_slug") or "", "")
            if t == "pro":
                return "pro"
            if t == "plus":
                best = "plus"
    except Exception:
        pass
    return best


TIER_LABEL = {"free": "بدون اشتراک", "plus": "اشتراک حرفه‌ای", "pro": "اشتراک ویژهٔ دست گیر"}


def quota_for(tier):
    s = db.get_settings()
    return {"free": _int_setting(s, "ai_quota_free", 5),
            "plus": _int_setting(s, "ai_quota_plus", 20),
            "pro": _int_setting(s, "ai_quota_pro", 50)}.get(tier, 5)


def _today():
    return datetime.date.today().isoformat()


def usage_today(user_key):
    r = db._one("SELECT n FROM ai_usage WHERE day=? AND user_key=?", (_today(), user_key))
    return int(r["n"]) if r else 0


def global_today():
    r = db._one("SELECT COALESCE(SUM(n),0) n FROM ai_usage WHERE day=?", (_today(),))
    return int(r["n"]) if r else 0


def global_cap():
    return _int_setting(db.get_settings(), "ai_daily_cap", 2000)


def remaining(user_key, tier):
    return max(0, quota_for(tier) - usage_today(user_key))


def _count(user_key, channel, llm_calls, tokens, intent):
    day = _today()
    con = db.connect()
    con.execute("INSERT INTO ai_usage(day,user_key,channel,n,llm_calls,tokens) VALUES(?,?,?,1,?,?) "
                "ON CONFLICT(day,user_key) DO UPDATE SET n=n+1, llm_calls=llm_calls+excluded.llm_calls, "
                "tokens=tokens+excluded.tokens, channel=excluded.channel",
                (day, user_key, channel, int(llm_calls), int(tokens)))
    con.execute("INSERT INTO ai_intents(day,intent,n) VALUES(?,?,1) "
                "ON CONFLICT(day,intent) DO UPDATE SET n=n+1", (day, intent[:32]))
    con.commit(); con.close()


def stats(days=30):
    """Admin projection: totals for today / 7d / N days + intent mix."""
    today = datetime.date.today()
    def since(n):
        d = (today - datetime.timedelta(days=n - 1)).isoformat()
        r = db._one("SELECT COALESCE(SUM(n),0) n, COALESCE(SUM(llm_calls),0) llm, "
                    "COALESCE(SUM(tokens),0) tok, COUNT(DISTINCT user_key) users "
                    "FROM ai_usage WHERE day>=?", (d,))
        return {"n": int(r["n"]), "llm": int(r["llm"]), "tokens": int(r["tok"]), "users": int(r["users"])}
    d30 = (today - datetime.timedelta(days=days - 1)).isoformat()
    intents = db._rows("SELECT intent, SUM(n) n FROM ai_intents WHERE day>=? "
                       "GROUP BY intent ORDER BY n DESC LIMIT 12", (d30,))
    daily = db._rows("SELECT day, SUM(n) n, SUM(llm_calls) llm FROM ai_usage WHERE day>=? "
                     "GROUP BY day ORDER BY day DESC LIMIT 14", (d30,))
    return {"today": since(1), "week": since(7), "month": since(days),
            "intents": intents, "daily": daily}


# ------------------------------------------------------------------ knowledge
# Grounding facts the model may paraphrase. Anything outside this + live data
# is off-topic by contract.
KNOWLEDGE = [
    ("دست گیر چیست؟", "دست گیر (daastgir.ir) راهنمای محلی کسب‌وکارهای شهر است: جست‌وجوی مغازه و خدمات، کسب‌وکارهای نزدیک شما روی نقشه، محصولات و قیمت‌ها، پیشنهادهای روز، سفارش و نوبت آنلاین، رویدادهای شهر، و صفحهٔ اختصاصی برای هر کسب‌وکار. ثبت کسب‌وکار همیشه رایگان است."),
    ("جست‌وجو", "در صفحهٔ /businesses با نام کسب‌وکار، صنف، محصول یا محله جست‌وجو می‌کنید؛ فیلتر دسته، «الان باز»، مرتب‌سازی (ویژه/امتیاز/جدید) دارد. دسته‌بندی کامل در /categories."),
    ("نزدیک من", "صفحهٔ /nearby با اجازهٔ موقعیت، کسب‌وکارهای بازِ اطراف را با فاصله و مسیر نشان می‌دهد؛ نقشهٔ کامل شهر در /map. موقعیت ذخیره نمی‌شود."),
    ("صفحهٔ کسب‌وکار", "هر کسب‌وکار در /b/<slug> دارد: معرفی، نشانی و مسیر، ساعت کاری زنده (باز/بسته)، تلفن (اگر عمومی باشد)، گالری، کاتالوگ محصولات/خدمات با قیمت، نظرات و امتیاز چندمعیاره، پرسش‌وپاسخ، دکمهٔ ذخیره (قلب)، دنبال‌کردن، رزرو نوبت و سفارش (اگر فعال باشد)، و پیام به دکان‌دار."),
    ("ثبت کسب‌وکار", "رایگان است. از /register-business مرحله‌به‌مرحله: دسته ← معرفی ← مکان (استان/شهر/محله/نقشه) ← تماس ← ساعت کاری ← تا ۶ عکس ← پیش‌نمایش و تأیید. ورود با شمارهٔ موبایل و کد پیامکی است؛ رمز لازم نیست. پس از تأیید مدیر منتشر می‌شود (معمولاً کمتر از یک روز کاری). در بات بله/سروش هم با /register_business می‌شود."),
    ("تصاحب کسب‌وکار موجود", "اگر کسب‌وکارتان از قبل در سایت هست، وارد شوید و از /my/claim درخواست دهید؛ اگر شمارهٔ ثبت‌شده با شمارهٔ شما یکی باشد فوراً وصل می‌شود، وگرنه مدیر بررسی می‌کند."),
    ("پنل دکان‌دار", "در /my: کسب‌وکارهای من (ویرایش، گالری، کاتالوگ، ساعت کاری، پنهان/نمایش، حذف)، سفارش‌ها و تغییر وضعیت، نوبت‌ها، پیام‌ها، نظرات و پاسخ به آن‌ها، پرسش‌ها، استوری ۲۴ ساعته، پیشنهاد روز، فراخوان به دنبال‌کننده‌ها، آمار بازدید و تماس، اشتراک (/my/plan) و تیکت پشتیبانی."),
    ("سفارش آنلاین", "در کسب‌وکارهایی که کاتالوگ فعال دارند، کالا را به سبد اضافه و سفارش ثبت می‌کنید (پرداخت حضوری/کارت‌به‌کارت طبق توافق با دکان‌دار؛ سایت پول نمی‌گیرد). پیگیری در /me/orders؛ لغو مستقیم تا مدت محدود، بعد از آن با تأیید دکان‌دار. اعلان وضعیت در سایت و بات."),
    ("نوبت آنلاین", "کسب‌وکارهایی که نوبت‌دهی را روشن کرده‌اند دکمهٔ «رزرو نوبت» دارند؛ نوبت‌های شما در /me قابل مشاهده و لغو (با تأیید دوم) است."),
    ("حساب مشتری", "ورود در /login با پیامک. در /me: سفارش‌ها، نوبت‌ها، علاقه‌مندی‌ها (/me/favorites)، دنبال‌شده‌ها، گفت‌وگو با دکان‌داران، اعلان‌ها، اتصال به بات بله/سروش، خروجی داده و حذف حساب."),
    ("پلن‌ها و تعرفه", "پلن پایه رایگان و دائمی است. «حرفه‌ای»: نشان ویژه و بالاتر بودن در فهرست، تا ۶۰ محصول و ۲۰ تصویر، آمار، پاسخ به نظرات، رزرو، پرسش‌وپاسخ. «ویژهٔ دست گیر»: همهٔ امکانات + جایگاه ثابت صفحهٔ نخست، بنر، ۳۰۰ محصول، پشتیبانی مستقیم. قیمت‌ها در /pricing؛ خرید از /my/plan با کارت‌به‌کارت و تأیید مدیر. سهمیهٔ دستیار هوشمند: پایه ۵، حرفه‌ای ۲۰، ویژه ۵۰ پیام در روز."),
    ("پیشنهاد روز و استوری", "پیشنهادهای زمان‌دار کسب‌وکارها در /deals؛ استوری‌های ۲۴ ساعته در صفحهٔ نخست و صفحهٔ هر کسب‌وکار."),
    ("مقایسهٔ قیمت", "در /prices (اگر فعال باشد) قیمت یک کالا را بین کسب‌وکارهای شهر مقایسه می‌کنید و برای کاهش قیمت هشدار می‌گیرید. محصولات همهٔ شهر در /catalog."),
    ("رویدادها و اخبار", "رویدادهای شهر در /events و اخبار/مقالات در /blog. برترین‌های شهر (فهرست‌های منتخب) در /lists."),
    ("نظرات و امتیاز", "نظر فقط با حساب کاربری؛ امتیاز چندمعیاره (کیفیت، قیمت، سرعت، برخورد، نوبت‌دهی) بر اساس امکانات هر کسب‌وکار. نظرات پیش از انتشار بررسی می‌شوند و دکان‌دار می‌تواند پاسخ دهد. گزارش تخلف در هر صفحه هست."),
    ("پشتیبانی", "پشتیبانی فقط از مسیر تیکت (/my/tickets پس از ورود) تا پاسخ گم نشود و وضعیت رسیدگی معلوم باشد. دست گیر هیچ‌وقت رمز، کد پیامکی یا اطلاعات کارت نمی‌پرسد."),
    ("بات‌های پیام‌رسان", "بات رسمی دست گیر در بله و سروش‌پلاس: از /me حساب را وصل می‌کنید؛ دستورها: /search، /near (ارسال موقعیت)، /orders، /bookings، /favorites، /notifications، /register_business، /owner و هر متن آزاد به همین دستیار می‌رسد. رسید سفارش زنده در بات به‌روز می‌شود."),
    ("حریم خصوصی", "شمارهٔ شما به کسب‌وکارها نشان داده نمی‌شود مگر خودتان در سفارش اجازه دهید؛ گفت‌وگو با دکان‌دار بدون شماره است. موقعیت مکانی فقط برای همان جست‌وجو استفاده می‌شود. خروجی و حذف کامل داده از /me/account."),
    ("اعلان‌ها", "اعلان سفارش، نوبت، پاسخ نظر و موجودشدن کالا در مرکز اعلان سایت، اعلان گوشی (وب‌پوش) و بات‌ها؛ تنظیم دسته‌ها در /me/notif-settings."),
]

INTENTS = ("search", "near", "register", "claim", "orders", "bookings", "favorites",
           "plans", "support", "login", "owner", "account", "faq", "greeting",
           "off_topic", "unknown")

# Rule table: (intent, regex). Order matters; first match wins.
_RULES = [
    ("greeting", r"^(سلام|درود|هی|hi|hello|سلام\s*علیکم|خسته نباشید)[\s!.،؟]*$"),
    ("orders", r"سفارش|order|خرید(های)?\s*من|پیگیری\s*سفارش|سبد"),
    ("bookings", r"نوبت|رزرو|وقت\s*(گرفتن|بگیرم)|booking"),
    ("favorites", r"علاقه|ذخیره\s*شده|favorite|نشان\s*کرده"),
    ("register", r"ثبت\s*(کسب|مغازه|فروشگاه|شغل|کار)|کسب\s*و\s*کار(م)?\s*(را|رو)?\s*(ثبت|اضافه)|مغازه(م|‌ام)?\s*(را|رو)?\s*(ثبت|اضافه)|register|چطور.*ثبت"),
    ("claim", r"تصاحب|تحویل\s*(بگیرم|گرفتن)|مال\s*من|صاحبش\s*منم"),
    ("plans", r"تعرفه|پلن|اشتراک|قیمت\s*(ثبت|پلن|اشتراک)|هزینه|رایگان|حرفه‌?ای|ویژه"),
    ("support", r"پشتیبان|تیکت|شکایت|مشکل\s*دارم|گزارش|ارتباط\s*با\s*(مدیر|ما)|تماس\s*با"),
    ("login", r"ورود|لاگین|login|وارد\s*(بشم|شوم|شم)|ثبت‌?نام|رمز|کد\s*پیامک"),
    ("owner", r"پنل|کسب‌?وکار(های)?\s*من|داشبورد|مدیریت\s*مغازه|آمار\s*بازدید"),
    ("account", r"حساب\s*(من|کاربری)|پروفایل|اطلاعات\s*من|شماره‌?ام"),
    ("near", r"نزدیک|اطراف|دور\s*و\s*بر|همین\s*حوالی|نزدیکم|near|کجا\s*هست\s*نزدیک"),
    # faq only when the question is visibly about the site itself; generic
    # «X چیست» goes to the model (or the off-topic fallback).
    ("faq", r"دست\s*گیر|راهنما|help|کمک|امکانات|حریم|خصوصی|بات|بله|سروش|پیام‌?رسان|سایت|اینجا|این\s*سامانه"),
]
_NEAR_WORDS = re.compile(r"(نزدیک(?:م|\s*من|\s*ما)?|اطراف(?:م|\s*من)?|دور\s*و\s*بر(?:م)?|همین\s*حوالی|near\s*me|near)", re.U)
_SEARCH_LEAD = re.compile(
    r"^(?:لطفا|لطفاً)?\s*(?:یک|یه)?\s*(?:جست\s*و\s*جو(?:ی)?|جستجو(?:ی)?|سرچ|پیدا\s*کن|دنبال|می‌?خوام|میخوام|می‌?خواهم|کجا(?:ست)?|بگرد)\s*", re.U)
_SEARCH_TAIL = re.compile(r"\s*(?:را|رو)?\s*(?:پیدا\s*کن|می‌?خوام|میخوام|می‌?گردم|بگرد|هست\??|کجاست\??|دارید\??)\s*$", re.U)


def _norm(text):
    return re.sub(r"\s+", " ", str(text or "").replace("ي", "ی").replace("ك", "ک").strip())


def rule_intent(text):
    """Deterministic classifier. Returns (intent, query) or (None, '')."""
    t = _norm(text)
    if not t:
        return "unknown", ""
    low = t.lower()
    if len(t) > 400:
        return "off_topic", ""
    if re.match(r"^/?(search|جست‌?وجو)\b", low):
        q = re.sub(r"^/?(search|جست‌?وجو)\s*", "", t).strip()
        return ("search", q) if q else ("search", "")
    for intent, pat in _RULES:
        if re.search(pat, low):
            if intent == "near":
                rest = _strip_search(_NEAR_WORDS.sub(" ", t))
                rest = re.sub(r"\b(کجاست|کجا|هست|چی|چیه|بگو|به\s*من|برام|برای\s*من|یک|یه)\b", " ", rest)
                rest = re.sub(r"\s+", " ", rest).strip(" ؟?.،")
                return "near", (rest if 2 <= len(rest) <= 40 else "")
            return intent, ""
    # «کافه», «داروخانه شبانه‌روزی», «پیدا کن نانوایی» → search (short noun phrases)
    if _SEARCH_LEAD.match(low) or _SEARCH_TAIL.search(low):
        return "search", _strip_search(t)
    # Short noun phrases («کافه», «تعمیرگاه موبایل») are searches — but not
    # questions or imperatives («یک شعر بگو», «ترجمه کن»), which go to the model.
    if 2 <= len(t) <= 40 and len(t.split()) <= 4 and not _NOT_SEARCH.search(low):
        return "search", t
    return None, ""


_NOT_SEARCH = re.compile(
    r"[?؟]|\b(بگو|بنویس|بساز|ترجمه|توضیح|حل|بده|کن|کنید|چیست|چیه|کیه|کیست|چرا|چند|کدام|کدوم|"
    r"شعر|داستان|جوک|لطیفه|کد|برنامه|python|java|html|فوتبال|هوا|اخبار|سیاست|پزشک|دارو\s*چی)\b", re.U)


def _strip_search(t):
    q = _SEARCH_LEAD.sub("", t)
    q = _SEARCH_TAIL.sub("", q)
    return q.strip(" ؟?.،")[:60]


# ------------------------------------------------------------------ model
SYSTEM_PROMPT = (
    "تو «دستیار دست گیر» هستی؛ دست گیر یک راهنمای محلی کسب‌وکارهای شهر است (جست‌وجوی مغازه و خدمات، "
    "کسب‌وکارهای نزدیک، ثبت کسب‌وکار، سفارش و نوبت آنلاین، پلن‌ها، پشتیبانی تیکتی، بات بله و سروش). "
    "وظیفهٔ تو فقط تشخیص نیت پیام کاربر است؛ هیچ کاری انجام نمی‌دهی و هیچ اطلاعاتی خارج از دانش داده‌شده نمی‌سازی.\n"
    "فقط و فقط یک JSON با این کلیدها برگردان:\n"
    '{"intent": یکی از ' + json.dumps(list(INTENTS), ensure_ascii=False) + ', "q": "عبارت جست‌وجو یا خالی", '
    '"reply": "حداکثر دو جملهٔ کوتاه فارسی، محترمانه و ساده"}\n'
    "قواعد:\n"
    "- اگر پیام به دست گیر یا خرید/خدمات محلی ربطی ندارد (برنامه‌نویسی، سیاست، پزشکی، درس، شعر، ترجمه، هر چیز عمومی) intent را off_topic بگذار.\n"
    "- اگر کاربر دنبال نوع مغازه/کالا/خدمت است intent=search و q را کوتاه و تمیز بنویس (مثلاً «داروخانه شبانه‌روزی»).\n"
    "- «نزدیک من/اطراف» ← near. «ثبت مغازه/کسب‌وکارم» ← register. سؤال دربارهٔ قیمت/تعرفه/اشتراک ← plans.\n"
    "- برای faq فقط از «دانش» زیر پاسخ بده و در reply خلاصهٔ درست همان را بنویس؛ اگر در دانش نیست intent=unknown.\n"
    "- هرگز رمز، کد پیامکی یا اطلاعات بانکی نخواه و وعدهٔ انجام کار (ثبت سفارش، لغو، پرداخت) نده.\n"
    "دانش:\n" + "\n".join(f"• {q}: {a}" for q, a in KNOWLEDGE)
)

_log_lock = threading.Lock()
_last_error = {"when": 0, "what": ""}


def last_error():
    return dict(_last_error)


def _record_error(what):
    with _log_lock:
        _last_error["when"] = int(time.time())
        _last_error["what"] = str(what)[:120]


def _chat(base_url, api_key, model, messages, timeout, max_tokens=220):
    """One OpenAI-compatible chat.completions call. Returns (content, tokens).
    Raises on transport/HTTP errors; the caller decides about fallback."""
    body = json.dumps({
        "model": model, "messages": messages, "temperature": 0,
        "max_tokens": int(max_tokens), "response_format": {"type": "json_object"},
    }).encode("utf-8")
    req = urllib.request.Request(
        base_url + "/chat/completions", data=body, method="POST",
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + api_key,
                 "User-Agent": "dastgir-assistant/214"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8", "replace"))
    content = (((data.get("choices") or [{}])[0].get("message") or {}).get("content")) or ""
    usage = data.get("usage") or {}
    tokens = int(usage.get("total_tokens") or 0)
    return content, tokens


def parse_model_json(content):
    """Tolerant parse: strips ``` fences and trailing prose; validates intent."""
    s = str(content or "").strip()
    s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.I | re.S).strip()
    m = re.search(r"\{.*\}", s, re.S)
    if not m:
        return None
    try:
        obj = json.loads(m.group(0))
    except ValueError:
        return None
    if not isinstance(obj, dict):
        return None
    intent = str(obj.get("intent") or "").strip().lower()
    if intent not in INTENTS:
        return None
    return {"intent": intent, "q": _norm(obj.get("q") or "")[:60],
            "reply": _norm(obj.get("reply") or "")[:300]}


def llm_intent(text, history=None, smart=False):
    """Ask the model for an intent JSON. Returns (parsed|None, tokens, calls).
    Tries primary then fallback provider; never raises."""
    c = config()
    attempts = []
    if c["base_url"] and c["api_key"]:
        attempts.append((c["base_url"], c["api_key"], (c["model_smart"] if smart and c["model_smart"] else c["model"])))
    if c["fb_base_url"] and c["fb_api_key"] and c["fb_model"]:
        attempts.append((c["fb_base_url"], c["fb_api_key"], c["fb_model"]))
    if not attempts:
        return None, 0, 0
    msgs = [{"role": "system", "content": SYSTEM_PROMPT}]
    for h in (history or [])[-4:]:
        role = "assistant" if h.get("role") == "assistant" else "user"
        msgs.append({"role": role, "content": _norm(h.get("text"))[:300]})
    msgs.append({"role": "user", "content": _norm(text)[:400]})
    calls = 0
    for base, key, model in attempts:
        calls += 1
        try:
            content, tokens = _chat(base, key, model, msgs, c["timeout"])
            parsed = parse_model_json(content)
            if parsed:
                return parsed, tokens, calls
            _record_error("bad-json:" + model)
        except urllib.error.HTTPError as e:
            _record_error(f"http-{e.code}:{model}")
        except Exception as e:                       # timeout, DNS, TLS…
            _record_error(type(e).__name__ + ":" + model)
    return None, 0, calls


# ------------------------------------------------------------------ grounded generation (v213.1)
ANSWER_PROMPT = (
    "تو «دستیار هوشمند دست گیر» هستی. دست گیر (daastgir.ir) راهنمای محلی کسب‌وکارهای شهر است: جست‌وجوی مغازه و خدمات، "
    "کسب‌وکارهای نزدیک، محصولات و قیمت‌ها، سفارش و نوبت آنلاین، صفحهٔ اختصاصی و ثبت رایگان برای هر کسب‌وکار، بات‌های بله و سروش.\n"
    "پاسخ را خودت، طبیعی، گرم و مثل یک راهنمای محلیِ باتجربه به فارسی بنویس (نه از روی قالب). کوتاه و مفید: معمولاً ۱ تا ۵ جمله؛ فهرست فقط وقتی چند کسب‌وکار یا گزینه داری. "
    "به تاریخچهٔ گفت‌وگو توجه کن و سؤال‌های پیگیری («ساعت کارش؟»، «تلفنش؟»، «اون یکی چی؟») را با همان کسب‌وکار قبلی جواب بده. "
    "اگر سؤال مبهم است یک سؤال روشن‌کننده بپرس (مثلاً کدام محله؟ چه نوع خدمتی؟). وقتی چند کسب‌وکار داری، بهترین را با دلیل (باز بودن، امتیاز، تأییدشده، نزدیکی) پیشنهاد بده.\n"
    "قواعد سخت:\n"
    "۱) فقط دربارهٔ دست گیر و آنچه در «داده‌های سایت» زیر آمده پاسخ بده. اگر سؤال به سایت، خرید/خدمات محلی، کسب‌وکارها، حساب کاربر، ثبت، سفارش، نوبت، پلن یا پشتیبانی ربطی ندارد "
    "(مثل برنامه‌نویسی، سیاست، درس، شعر، پزشکی عمومی، ترجمه، اخبار)، در یک جملهٔ مؤدبانه بگو فقط برای کارهای دست گیر هستی و یک پیشنهاد مرتبط بده. در این حالت scope را false بگذار.\n"
    "۲) هیچ کسب‌وکار، قیمت، ساعت، شماره یا آماری را از خودت نساز؛ فقط از داده‌های داده‌شده استفاده کن. اگر نتیجهٔ جست‌وجو خالی است، صادقانه بگو فعلاً چنین چیزی در سایت ثبت نشده و راه جایگزین بده "
    "(دستهٔ نزدیک، جست‌وجوی دیگر، صفحهٔ نزدیک من، یا این‌که اگر خودش صاحب چنین کسب‌وکاری است رایگان ثبت کند).\n"
    "۳) تو هیچ کاری انجام نمی‌دهی (سفارش، لغو، پرداخت، ثبت)؛ کاربر را به مسیر درست سایت راهنمایی کن. هرگز رمز، کد پیامکی یا اطلاعات بانکی نخواه.\n"
    "۴) وقتی کسب‌وکاری را نام می‌بری، لینک آن را در links بده. حداکثر ۵ لینک؛ فقط مسیرهای داخلی که در داده‌ها آمده (با / شروع می‌شوند).\n"
    "۵) اگر سؤال دربارهٔ اطلاعات شخصی کاربر است و او وارد نشده، بگو باید وارد شود و لینک /login بده.\n"
    "۶) از اعداد فارسی استفاده کن. اسم سایت همیشه «دست گیر» (با فاصله).\n"
    "۷) نقش کاربر را در نظر بگیر (بخش «دربارهٔ همین کاربر»):\n"
    "   - دکان‌دار: مثل یک مشاور کسب‌وکار محلی کمک کن — وضعیت سفارش‌ها/نوبت‌ها/پیام‌های بی‌پاسخش را از داده‌ها بگو، برای بیشتر دیده‌شدن راهکارهای عملیِ داخل سایت بده "
    "(کامل‌کردن پروفایل و ساعت کاری، عکس باکیفیت، کاتالوگ با قیمت، پاسخ به نظرات، استوری و پیشنهاد روز، فراخوان به دنبال‌کننده‌ها، QR ویترین، پلن حرفه‌ای)، "
    "متن پیشنهادی برای پاسخ به نظر مشتری یا معرفی دکان بنویس اگر خواست، و مسیر دقیق هر کار در /my را بده.\n"
    "   - مشتری: مثل یک راهنمای محلی مهربان — بهترین گزینه را با دلیل پیشنهاد بده، وضعیت سفارش/نوبتش را از داده‌ها بگو، نحوهٔ لغو/پیگیری/ذخیره/دنبال‌کردن را توضیح بده.\n"
    "   - مهمان: امکانات را معرفی کن و در جای مناسب ورود یا ثبت رایگان کسب‌وکار را پیشنهاد بده.\n"
    "خروجی فقط JSON: {\"answer\": \"متن پاسخ\", \"links\": [{\"label\": \"...\", \"href\": \"/...\"}], \"scope\": true|false, \"intent\": \"یکی از "
    + "/".join(INTENTS) + "\"}"
)


def _site_facts():
    s = db.get_settings()
    f = [f"نام سایت: دست گیر — {s.get('tagline') or ''}".strip(" —")]
    if s.get("description") and s.get("description") not in ("توضیح", "توضیحات"):
        f.append("معرفی: " + str(s.get("description"))[:300])
    for k, label in (("reg_open", "ثبت کسب‌وکار توسط کاربران باز است"), ("booking_enabled", "نوبت‌دهی آنلاین فعال است"),
                     ("orders_enabled", "سفارش آنلاین فعال است"), ("catalog_enabled", "کاتالوگ محصولات فعال است"),
                     ("prices_enabled", "مقایسهٔ قیمت فعال است"), ("chat_enabled", "گفت‌وگو با دکان‌دار فعال است")):
        if s.get(k) == "1":
            f.append(label)
    f.append("مسیرهای مهم: / خانه، /businesses فهرست و جست‌وجو (?q=)، /nearby نزدیک من، /map نقشه، /categories دسته‌ها، "
             "/catalog محصولات، /deals پیشنهادها، /events رویدادها، /blog اخبار، /pricing تعرفه‌ها، /register-business ثبت رایگان کسب‌وکار، "
             "/my/claim تصاحب کسب‌وکار موجود، /login ورود با پیامک، /me حساب مشتری، /me/orders سفارش‌ها، /me/favorites علاقه‌مندی‌ها، "
             "/my پنل دکان‌دار، /my/plan اشتراک کسب‌وکار، /my/tickets پشتیبانی تیکتی، /contact تماس. صفحهٔ هر کسب‌وکار: /b/<slug>")
    return f


def _biz_line(r):
    parts = [r.get("name") or ""]
    if r.get("cat_slug"): parts.append("دسته: " + str(r.get("cat_name") or r["cat_slug"]))
    if r.get("address"): parts.append("نشانی: " + str(r["address"])[:70])
    if r.get("open") is True: parts.append("الان باز")
    elif r.get("open") is False: parts.append("الان بسته")
    if r.get("verified"): parts.append("تأییدشده")
    if r.get("rating"): parts.append(f"امتیاز {r['rating']} ({r.get('nreviews') or 0} نظر)")
    if r.get("phone_public") and r.get("phone"): parts.append("تلفن: " + str(r["phone"]))
    return " | ".join(parts) + f" | لینک: /b/{r.get('slug')}"


def _search_pack(text, q):
    """Live search hits for the model. Tries the extracted query, then the raw
    text, then single significant words — so «نانوایی سنگکی» still finds bakeries."""
    cats = {c["slug"]: c for c in db.categories(only_active=False)}
    tried, rows = [], []
    cands = [x for x in (q, text) if x and len(db.normalize_fa(x)) >= 2]
    words = [w for w in re.split(r"[\s،,؟?]+", _norm(text)) if len(w) >= 3 and not _NOT_SEARCH.search(w)]
    for cand in cands + words[:4]:
        cand = cand[:60]
        if cand in tried: continue
        tried.append(cand)
        try:
            hits = db.search_business_summaries(cand, 6)
        except Exception:
            hits = []
        for h in hits:
            if all(h["id"] != r["id"] for r in rows):
                rows.append(h)
        if len(rows) >= 6: break
    out = []
    for r in rows[:6]:
        try:
            full = db.business(bid=r["id"]) or {}
            r["open"] = db.is_open_now(full) if full.get("hours") else None
            r["rating"] = full.get("rating"); r["nreviews"] = full.get("nreviews"); r["phone_public"] = full.get("phone_public")
        except Exception:
            pass
        c = cats.get(r.get("cat_slug")); r["cat_name"] = c["name"] if c else ""
        out.append(_biz_line(r))
    # matching categories (so the model can suggest a category page)
    low = db.normalize_fa(text)
    catm = [c for c in cats.values() if c.get("active") and c.get("name") and db.normalize_fa(c["name"]) in low][:4]
    return out, [f"{c['name']} ({c.get('total') or c.get('count') or 0} کسب‌وکار) لینک: /businesses?cat={c['slug']}" for c in catm], tried


def _extra_pack(text):
    """Products/prices, deals, upcoming events and category list relevant to the words."""
    out = []
    low = db.normalize_fa(text)
    words = [w for w in re.split(r"[\s،,؟?]+", low) if len(w) >= 3 and not _NOT_SEARCH.search(w)]
    try:
        items = db.items(only_available=True)
        hits = [i for i in items if any(w in db.normalize_fa(f"{i.get('title')} {i.get('descr') or ''}") for w in words)][:8]
        if hits:
            out.append("## محصولات/خدمات مرتبط (کاتالوگ زنده)")
            for i in hits:
                price = f"{int(i['price']):,} تومان" if i.get("price") else "قیمت توافقی"
                out.append(f"{i.get('title')} — {price} — در {i.get('bizname')} — لینک: /b/{i.get('bizslug')}")
    except Exception:
        pass
    try:
        import features
        deals = [d for d in features.flashdeals(active_only=True)][:5]
        if deals and re.search(r"تخفیف|پیشنهاد|حراج|ارزان|deal", low):
            out.append("## پیشنهادهای فعال امروز (/deals)")
            for d in deals:
                out.append(f"{d.get('title')} — {d.get('bizname') or ''} — {d.get('descr') or ''}"[:160])
    except Exception:
        pass
    try:
        if re.search(r"رویداد|برنامه|جشن|نمایشگاه|کنسرت|همایش|event", low):
            evs = db.cityevents(upcoming_only=True, limit=5)
            if evs:
                out.append("## رویدادهای پیشِ رو (/events)")
                for e in evs:
                    out.append(f"{e.get('title')} — {e.get('date') or e.get('starts') or ''} — {e.get('place') or ''}"[:160])
    except Exception:
        pass
    try:
        if re.search(r"دسته|صنف|چه\s*چیزهایی|چی\s*دارید|چه\s*کسب|همهٔ?\s*(مغازه|کسب)", low):
            cats = [c for c in db.categories(top_only=True) if c.get("total") or c.get("count")][:25]
            if cats:
                out.append("## دسته‌های اصلی سایت با تعداد کسب‌وکار")
                out.append("، ".join(f"{c['name']} ({c.get('total') or c.get('count')})" for c in cats))
    except Exception:
        pass
    return out


def _mentioned_business_pack(text, history):
    """If the user names a business we know (or asked about one in the last turns),
    include its full public card so follow-up questions («ساعت کارش؟ تلفنش؟») work."""
    texts = [text] + [h.get("text", "") for h in (history or [])[-4:]]
    low = db.normalize_fa(" ".join(texts))
    out = []
    try:
        rows = db._rows("SELECT id,name,slug FROM businesses WHERE status='published'")
        found = [r for r in rows if len(r["name"]) >= 3 and db.normalize_fa(r["name"]) in low][:2]
        for r in found:
            b = db.business(bid=r["id"]) or {}
            if not b: continue
            hours = b.get("hours") or {}
            if isinstance(hours, str):
                try: hours = json.loads(hours)
                except Exception: hours = {}
            hrs = "; ".join(f"{d}: " + ",".join("-".join(x) for x in v) for d, v in hours.items() if v) if isinstance(hours, dict) else ""
            its = db.items(biz_id=b["id"], only_available=True)[:8]
            out.append(f"## جزئیات کسب‌وکار «{b['name']}» (/b/{b['slug']})")
            out.append(f"دسته: {b.get('cat_slug')} | نشانی: {b.get('address') or '—'} | محله: {b.get('area') or '—'} | شهر: {b.get('city') or '—'}")
            out.append(f"الان: {'باز' if db.is_open_now(b) else 'بسته'} | ساعت کاری: {hrs or 'ثبت نشده'}")
            out.append(f"تلفن: {(b.get('phone') if b.get('phone_public') else 'عمومی نیست — از دکمهٔ پیام در صفحه استفاده کنید')}")
            out.append(f"امتیاز: {b.get('rating') or '—'} ({b.get('nreviews') or 0} نظر) | تأییدشده: {'بله' if b.get('verified') else 'خیر'} | نوبت‌دهی: {'دارد' if b.get('booking_on') else 'ندارد'}")
            if b.get("descr"): out.append("معرفی: " + str(b["descr"])[:300])
            if its: out.append("کاتالوگ: " + "؛ ".join(f"{i['title']} {int(i['price']):,} تومان" if i.get('price') else i['title'] for i in its))
    except Exception:
        pass
    return out


def _user_pack(ctx):
    cust, owner = ctx.get("customer"), ctx.get("owner")
    lines = []
    if not (cust or owner):
        return ["کاربر وارد نشده است (مهمان)."]
    if cust:
        lines.append(f"کاربر وارد شده: {cust.get('name') or 'بدون نام'} (مشتری).")
        try:
            import features
            for r in features.customer_order_summaries(cust["id"], 5):
                lines.append(f"سفارش #{r['id']} از {r['bizname']} — {r.get('status_label') or r.get('status')} — مبلغ {r.get('total')} تومان — لینک: /me/orders")
            for r in db.customer_booking_summaries(cust["id"], 5):
                lines.append(f"نوبت {r['bizname']} {r['date']} {r['time']} — {r.get('status_label') or r.get('status')} — لینک: /me")
            favs = db._rows("SELECT b.name,b.slug FROM favorites f JOIN businesses b ON b.id=f.biz_id WHERE f.customer_id=? AND b.status='published' ORDER BY f.id DESC LIMIT 5", (cust["id"],))
            if favs: lines.append("علاقه‌مندی‌ها: " + "، ".join(f"{r['name']} (/b/{r['slug']})" for r in favs))
        except Exception:
            pass
    o = owner
    if not o and cust and cust.get("phone"):
        try: o = db.owner_by_phone(cust["phone"], create=False)
        except Exception: o = None
    if o:
        try:
            import features
            bizs = db.businesses_of(o["id"])[:5]
            if bizs: lines.append("نقش: دکان‌دار (صاحب کسب‌وکار).")
            for b in bizs:
                sub = db.subscription_of(b["id"])
                plan = db.plan(slug=(sub or {}).get("plan_slug")) if sub else None
                n_items = db._one("SELECT COUNT(*) n FROM items WHERE biz_id=? AND available=1", (b["id"],))["n"]
                n_img = len(b.get("images") or [])
                n_rev = db._one("SELECT COUNT(*) n FROM reviews WHERE biz_id=? AND status='approved'", (b["id"],))["n"]
                miss = [x for x, ok in (("توضیح معرفی", bool(b.get("descr"))), ("ساعت کاری", bool(b.get("hours"))), ("عکس", n_img > 0),
                                        ("کاتالوگ/قیمت", n_items > 0), ("موقعیت روی نقشه", bool(b.get("lat"))), ("نشانی", bool(b.get("address")))) if not ok]
                lines.append(f"کسب‌وکار «{b['name']}» (/b/{b['slug']}) — وضعیت انتشار: {b.get('status')} — پلن: {(plan or {}).get('name') or 'پایه (رایگان)'} — "
                             f"{n_img} عکس، {n_items} محصول/خدمت، {n_rev} نظر منتشرشده، امتیاز {b.get('rating') or '—'}، نوبت‌دهی {'روشن' if b.get('booking_on') else 'خاموش'}، "
                             f"تأییدشده: {'بله' if b.get('verified') else 'خیر'}" + (f" — موارد ناقص پروفایل: {'، '.join(miss)}" if miss else " — پروفایل کامل است"))
            if bizs:
                for r in features.owner_order_summaries(o["id"], 5):
                    lines.append(f"سفارش دکان #{r['id']} — {r.get('status_label') or r['status']} — {r.get('total')} تومان — از {r['bizname']} — مدیریت: /my/orders")
                try:
                    for r in features.owner_chat_summaries(o["id"], 5):
                        lines.append(f"گفت‌وگوی مشتری: {str(r.get('subject') or r.get('last') or '')[:60]} — {'بی‌پاسخ' if r.get('unread') else 'خوانده‌شده'} — /my/chats")
                except Exception:
                    pass
                lines.append("مسیرهای دکان‌دار: /my داشبورد، /my/businesses ویرایش/گالری/کاتالوگ/ساعت، /my/orders سفارش‌ها، /my/bookings نوبت‌ها، /my/chats گفت‌وگوها، "
                             "/my/reviews نظرات و پاسخ، /my/questions پرسش‌ها، /my/stories استوری، /my/offers پیشنهاد قیمت، /my/broadcast فراخوان، /my/plan اشتراک، /my/tickets پشتیبانی.")
        except Exception:
            pass
    return lines or ["کاربر وارد شده است."]


def build_context(text, q, ctx, history=None):
    biz, cats, tried = _search_pack(text, q)
    plans = [f"{p['name']} — {'رایگان' if int(p.get('price') or 0)==0 else str(p.get('price'))+' تومان / '+str(p.get('months') or 12)+' ماه'}"
             + (f" — {p.get('tagline')}" if p.get('tagline') else "") + (" — امکانات: " + "، ".join(p.get("perk_list") or [])[:200] if p.get("perk_list") else "")
             for p in db.plans()]
    pages = []
    for slug in ("about", "rules"):
        try:
            pg = db.get_page(slug)
            if pg and pg.get("body"):
                pages.append(f"صفحهٔ {pg.get('title') or slug}: " + re.sub(r"<[^>]+>", " ", pg["body"])[:500])
        except Exception:
            pass
    parts = ["## اطلاعات سایت", *_site_facts(), "## راهنمای کارها", *[f"{a}: {b}" for a, b in KNOWLEDGE],
             "## پلن‌ها (/pricing)", *plans]
    if pages: parts += ["## صفحات", *pages]
    parts += [f"## نتیجهٔ جست‌وجوی زنده برای {tried}", *(biz or ["هیچ کسب‌وکاری برای این عبارت‌ها ثبت نشده است."])]
    if cats: parts += ["## دسته‌های مرتبط", *cats]
    parts += _mentioned_business_pack(text, history)
    parts += _extra_pack(text)
    try:
        n_biz = db._one("SELECT COUNT(*) n FROM businesses WHERE status='published'")["n"]
        n_cat = len([c for c in db.categories() if c.get("total") or c.get("count")])
        parts += ["## آمار زندهٔ سایت", f"{n_biz} کسب‌وکار منتشرشده در {n_cat} دسته"]
    except Exception:
        pass
    parts += ["## دربارهٔ همین کاربر", *_user_pack(ctx)]
    return "\n".join(parts)[:14000]


def parse_answer_json(content):
    s = str(content or "").strip()
    s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.I | re.S).strip()
    m = re.search(r"\{.*\}", s, re.S)
    if not m: return None
    try: obj = json.loads(m.group(0))
    except ValueError: return None
    if not isinstance(obj, dict): return None
    ans = _norm(obj.get("answer") or "")
    if not ans: return None
    links = []
    for l in (obj.get("links") or [])[:5]:
        if isinstance(l, dict) and isinstance(l.get("href"), str) and re.fullmatch(r"/[A-Za-z0-9_\-/?=&%.\u0600-\u06FF]*", l["href"]):
            links.append((_norm(l.get("label") or l["href"])[:40], l["href"][:120]))
    intent = str(obj.get("intent") or "").strip().lower()
    return {"answer": ans[:1200], "links": links, "scope": obj.get("scope") is not False,
            "intent": intent if intent in INTENTS else "unknown"}


def generate(text, ctx, history=None, hint=("unknown", "")):
    """Grounded free-form answer from the model. Returns (parsed|None, tokens, calls)."""
    c = config()
    attempts = []
    if c["base_url"] and c["api_key"]:
        attempts.append((c["base_url"], c["api_key"], c["model"]))
    if c["fb_base_url"] and c["fb_api_key"] and c["fb_model"]:
        attempts.append((c["fb_base_url"], c["fb_api_key"], c["fb_model"]))
    if not attempts:
        return None, 0, 0
    context = build_context(text, hint[1], ctx, history)
    msgs = [{"role": "system", "content": ANSWER_PROMPT + "\n\n# داده‌های سایت (تنها منبع مجاز)\n" + context}]
    for h in (history or [])[-6:]:
        msgs.append({"role": "assistant" if h.get("role") == "assistant" else "user", "content": _norm(h.get("text"))[:400]})
    msgs.append({"role": "user", "content": _norm(text)[:400]})
    calls = 0
    for base, key, model in attempts:
        calls += 1
        try:
            content, tokens = _chat(base, key, model, msgs, c["timeout"], max_tokens=700)
            parsed = parse_answer_json(content)
            if parsed:
                return parsed, tokens, calls
            _record_error("bad-json:" + model)
        except urllib.error.HTTPError as e:
            _record_error(f"http-{e.code}:{model}")
        except Exception as e:
            _record_error(type(e).__name__ + ":" + model)
    return None, 0, calls


# ------------------------------------------------------------------ answers
def _fa(n):
    return str(n).translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))


def _price(v):
    try:
        v = int(v)
    except (TypeError, ValueError):
        return ""
    return "رایگان" if v == 0 else _fa(f"{v:,}") + " تومان"


def _search_answer(q, ctx):
    q = _norm(q)[:60]
    if len(db.normalize_fa(q)) < 2:
        return {"text": "چه چیزی را جست‌وجو کنم؟ مثلاً «داروخانه شبانه‌روزی» یا «کافه».",
                "links": [("جست‌وجو در سایت", "/businesses")]}
    rows = db.search_business_summaries(q, 5)
    if not rows:
        return {"text": f"برای «{q}» کسب‌وکاری پیدا نکردم. عبارت دیگری امتحان کنید یا در فهرست بگردید.",
                "links": [("فهرست کسب‌وکارها", "/businesses?q=" + urllib.parse.quote(q))]}
    lines = [f"🔍 {_fa(len(rows))} نتیجه برای «{q}»:"]
    links = []
    for r in rows:
        tag = " ✅" if r.get("verified") else ""
        addr = (r.get("address") or "").strip()
        lines.append(f"• {r['name']}{tag}" + (f" — {addr[:50]}" if addr else ""))
        links.append((r["name"][:28], f"/b/{r['slug']}"))
    links.append(("همهٔ نتایج", "/businesses?q=" + urllib.parse.quote(q)))
    return {"text": "\n".join(lines), "links": links[:6]}


def _orders_answer(ctx):
    cust = ctx.get("customer")
    if not cust:
        return {"text": "برای دیدن سفارش‌ها باید وارد حساب شوید.", "links": [("ورود", "/login?next=/me/orders")]}
    import features
    rows = features.customer_order_summaries(cust["id"], 5)
    if not rows:
        return {"text": "هنوز سفارشی ثبت نکرده‌اید. از صفحهٔ کسب‌وکارهایی که کاتالوگ دارند می‌توانید سفارش دهید.",
                "links": [("محصولات", "/catalog")]}
    lines = ["📦 سفارش‌های اخیر شما:"]
    for r in rows:
        lines.append(f"• #{_fa(r['id'])} — {r['bizname']} — {r.get('status_label') or r.get('status')} — {_price(r.get('total'))}")
    return {"text": "\n".join(lines), "links": [("همهٔ سفارش‌ها", "/me/orders")]}


def _bookings_answer(ctx):
    cust = ctx.get("customer")
    if not cust:
        return {"text": "برای دیدن نوبت‌ها باید وارد حساب شوید.", "links": [("ورود", "/login?next=/me")]}
    rows = db.customer_booking_summaries(cust["id"], 5)
    if not rows:
        return {"text": "نوبتی ثبت نشده است. کسب‌وکارهایی که نوبت‌دهی دارند دکمهٔ «رزرو» دارند.",
                "links": [("کسب‌وکارها", "/businesses")]}
    lines = ["📅 نوبت‌های اخیر شما:"]
    for r in rows:
        lines.append(f"• {r['bizname']} — {r['date']} {r['time']} — {r.get('status_label') or r.get('status')}")
    return {"text": "\n".join(lines), "links": [("حساب من", "/me")]}


def _favorites_answer(ctx):
    cust = ctx.get("customer")
    if not cust:
        return {"text": "علاقه‌مندی‌ها پس از ورود در دسترس است.", "links": [("ورود", "/login?next=/me/favorites")]}
    rows = db._rows("SELECT b.name, b.slug FROM favorites f JOIN businesses b ON b.id=f.biz_id "
                    "WHERE f.customer_id=? AND b.status='published' ORDER BY f.id DESC LIMIT 5", (cust["id"],))
    if not rows:
        return {"text": "هنوز چیزی ذخیره نکرده‌اید. روی قلب کنار هر کسب‌وکار بزنید.", "links": [("کسب‌وکارها", "/businesses")]}
    return {"text": "❤️ ذخیره‌شده‌های شما: " + "، ".join(r["name"] for r in rows),
            "links": [(r["name"][:28], f"/b/{r['slug']}") for r in rows[:3]] + [("علاقه‌مندی‌ها", "/me/favorites")]}


def _plans_answer():
    rows = db.plans()
    lines = ["💳 پلن‌های دست گیر:"]
    for p in rows:
        months = p.get("months") or 12
        lines.append(f"• {p['name']} — {_price(p.get('price'))}" + ("" if int(p.get('price') or 0) == 0 else f" / {_fa(months)} ماه")
                     + (f" — {p['tagline']}" if p.get("tagline") else ""))
    lines.append("ثبت کسب‌وکار همیشه رایگان است.")
    return {"text": "\n".join(lines), "links": [("تعرفه‌ها", "/pricing"), ("ثبت رایگان", "/register-business")]}


def _near_answer(ctx):
    if ctx.get("channel") in ("bale", "soroush"):
        return {"text": "📍 برای دیدن کسب‌وکارهای بازِ نزدیک، موقعیت مکانی خود را همین‌جا ارسال کنید (گیرهٔ پیوست ← موقعیت). موقعیت فقط برای همین جست‌وجو استفاده و ذخیره نمی‌شود.",
                "links": [("نزدیک من در سایت", "/nearby")]}
    return {"text": "📍 صفحهٔ «نزدیک من» با اجازهٔ موقعیت، کسب‌وکارهای باز اطراف شما را با فاصله نشان می‌دهد.",
            "links": [("نزدیک من", "/nearby"), ("نقشه", "/map")]}


def _faq_answer(text, reply=""):
    if reply:
        return {"text": reply, "links": [("راهنمای کامل", "/contact")]}
    low = _norm(text).lower()
    best = None
    for q, a in KNOWLEDGE:
        words = [w for w in re.split(r"[\s،؟?]+", q) if len(w) > 2]
        score = sum(1 for w in words if w in low)
        if score and (best is None or score > best[0]):
            best = (score, a)
    if best:
        return {"text": best[1], "links": [("راهنما", "/contact")]}
    return _help_answer()


def _help_answer():
    return {"text": ("من دستیار دست گیر هستم و فقط دربارهٔ همین سایت کمک می‌کنم:\n"
                     "• جست‌وجوی مغازه و خدمات (مثلاً «داروخانه شبانه‌روزی»)\n"
                     "• کسب‌وکارهای نزدیک شما\n• ثبت یا تصاحب کسب‌وکار\n"
                     "• سفارش‌ها و نوبت‌های شما\n• پلن‌ها و تعرفه‌ها\n• پشتیبانی تیکتی"),
            "links": [("جست‌وجو", "/businesses"), ("نزدیک من", "/nearby"), ("ثبت کسب‌وکار", "/register-business")]}


def _off_topic_answer():
    return {"text": "این دستیار فقط برای کارهای دست گیر است (جست‌وجوی کسب‌وکار، نزدیک من، ثبت کسب‌وکار، سفارش‌ها، نوبت‌ها، تعرفه‌ها و پشتیبانی). دربارهٔ موضوعات دیگر نمی‌توانم کمک کنم.",
            "links": [("راهنما", "/contact")]}


def compose(intent, q, text, ctx, reply=""):
    """Turn a (validated) intent into the final answer. Pure read paths."""
    if intent == "search":
        return _search_answer(q or text, ctx)
    if intent == "near":
        out = _near_answer(ctx)
        if q:
            out["links"].insert(0, (f"«{q}» نزدیک من", "/nearby?q=" + urllib.parse.quote(q)))
        return out
    if intent == "orders":
        return _orders_answer(ctx)
    if intent == "bookings":
        return _bookings_answer(ctx)
    if intent == "favorites":
        return _favorites_answer(ctx)
    if intent == "plans":
        return _plans_answer()
    if intent == "register":
        return {"text": "➕ ثبت کسب‌وکار رایگان است و چند دقیقه طول می‌کشد: نام، دسته، نشانی و ساعت کاری. پس از تأیید مدیر منتشر می‌شود.",
                "links": [("شروع ثبت", "/register-business"), ("تعرفه‌ها", "/pricing")]}
    if intent == "claim":
        return {"text": "اگر کسب‌وکارتان از قبل در سایت هست، وارد شوید و از «تصاحب کسب‌وکار» درخواست دهید؛ با یکی‌بودن شماره فوراً وصل می‌شود.",
                "links": [("تصاحب کسب‌وکار", "/my/claim")]}
    if intent == "support":
        target = "/my/tickets" if (ctx.get("owner") or ctx.get("customer")) else "/login?next=/my/tickets"
        return {"text": "🛟 پشتیبانی فقط از مسیر تیکت انجام می‌شود تا پاسخ و وضعیت رسیدگی را در حساب خود ببینید.",
                "links": [("ثبت تیکت", target)]}
    if intent == "login":
        if ctx.get("customer") or ctx.get("owner"):
            return {"text": "شما وارد حساب هستید.", "links": [("حساب من", "/me")]}
        return {"text": "ورود با شمارهٔ موبایل و کد پیامکی انجام می‌شود؛ رمز لازم نیست.", "links": [("ورود", "/login")]}
    if intent == "owner":
        return {"text": "🏪 پنل کسب‌وکار: سفارش‌ها، نوبت‌ها، گالری، کاتالوگ و آمار در «کسب‌وکارهای من».",
                "links": [("پنل کسب‌وکار", "/my"), ("ثبت کسب‌وکار جدید", "/register-business")]}
    if intent == "account":
        return {"text": "حساب شما: سفارش‌ها، نوبت‌ها، علاقه‌مندی‌ها و اتصال به بله/سروش در «حساب من».",
                "links": [("حساب من", "/me")]}
    if intent == "greeting":
        return {"text": "سلام! من دستیار دست گیر هستم. دنبال چه کسب‌وکار یا خدمتی هستید؟",
                "links": [("نزدیک من", "/nearby"), ("ثبت کسب‌وکار", "/register-business")]}
    if intent == "faq":
        return _faq_answer(text, reply)
    if intent == "off_topic":
        return _off_topic_answer()
    return _help_answer()


# ------------------------------------------------------------------ entry
def answer(text, ctx, history=None):
    """Main entry for every channel.

    ctx = {"channel": web|bale|soroush, "user_key": str, "customer": dict|None,
           "owner": dict|None}
    Returns {"ok", "text", "links", "intent", "source", "remaining", "quota", "tier"}
    or {"ok": False, "error": "disabled"|"quota"|"cap"|"empty", "text": ...}.
    """
    text = _norm(text)[:400]
    user_key = ctx.get("user_key") or "anon"
    tier = ctx.get("tier") or tier_of(ctx.get("customer"), ctx.get("owner"))
    quota = quota_for(tier)
    if not enabled():
        return {"ok": False, "error": "disabled", "text": "دستیار هوشمند فعلاً غیرفعال است.", "tier": tier,
                "quota": quota, "remaining": 0}
    if not text:
        return {"ok": False, "error": "empty", "text": "پیامی ننوشتید.", "tier": tier, "tier_label": TIER_LABEL.get(tier, ""), "quota": quota,
                "remaining": remaining(user_key, tier)}
    used = usage_today(user_key)
    if used >= quota:
        return {"ok": False, "error": "quota", "tier": tier, "tier_label": TIER_LABEL.get(tier, ""), "quota": quota, "remaining": 0,
                "text": (f"سهمیهٔ امروز شما ({_fa(quota)} پیام، {TIER_LABEL.get(tier, '')}) تمام شد. فردا دوباره در خدمتم؛ "
                         + ("با اشتراک حرفه‌ای یا ویژه سهمیهٔ بیشتری دارید." if tier == "free" else "ممنون از همراهی شما."))}
    if global_today() >= global_cap():
        return {"ok": False, "error": "cap", "tier": tier, "tier_label": TIER_LABEL.get(tier, ""), "quota": quota, "remaining": max(0, quota - used),
                "text": "ظرفیت روزانهٔ دستیار پر شده است؛ لطفاً از منوها و جست‌وجوی سایت استفاده کنید."}

    intent, q = rule_intent(text)
    source, reply, tokens, calls = "rule", "", 0, 0
    # v213.1: with a model configured, the model WRITES the answer itself,
    # grounded in a live context pack (site facts, search hits for the user's
    # words, plans, pages, the user's own orders). Rules only pre-extract a
    # search query and serve as the offline fallback.
    if configured():
        gen, tokens, calls = generate(text, ctx, history, (intent or "unknown", q))
        if gen:
            out_intent = gen["intent"] if gen["scope"] else "off_topic"
            try:
                _count(user_key, ctx.get("channel") or "web", calls, tokens, out_intent)
            except Exception:
                pass
            return {"ok": True, "text": gen["answer"], "links": gen["links"], "intent": out_intent,
                    "source": "llm", "tier": tier, "tier_label": TIER_LABEL.get(tier, ""), "quota": quota,
                    "remaining": max(0, quota - used - 1)}
    # Offline / model failed → rule-based fallback (never silent).
    if intent is None:
        # No model available: a short noun phrase is most likely a search;
        # a question is answered from the knowledge list or refused politely.
        asks = re.search(r"[?؟]|چیست|چیه|چطور|چگونه|بگو|بنویس|توضیح", text)
        intent, source = (("unknown" if asks else "search") if len(text) <= 60 else "unknown"), "rule-fallback"
    elif calls:
        source = "rule-fallback"
    out = compose(intent, q, text, ctx, reply if source == "llm" else "")
    try:
        _count(user_key, ctx.get("channel") or "web", calls, tokens, intent)
    except Exception:
        pass
    return {"ok": True, "text": out["text"], "links": out.get("links") or [], "intent": intent,
            "source": source, "tier": tier, "tier_label": TIER_LABEL.get(tier, ""), "quota": quota,
            "remaining": max(0, quota - used - 1)}


# ------------------------------------------------------------------ bots
_BOT_HISTORY = {}
_BOT_HISTORY_LOCK = threading.Lock()


def _bot_history(key, user_text=None, bot_text=None):
    with _BOT_HISTORY_LOCK:
        h = _BOT_HISTORY.get(key) or []
        if user_text is not None:
            h.append({"role": "user", "text": user_text})
        if bot_text is not None:
            h.append({"role": "assistant", "text": bot_text})
        h = h[-6:]
        _BOT_HISTORY[key] = h
        if len(_BOT_HISTORY) > 5000:
            _BOT_HISTORY.clear()
        return list(h)


def bot_reply(platform, platform_user_id, chat_id, text, send, customer=None, owner=None, callback_prefix="dg198:"):
    """Free text in Bale/Soroush → assistant. Always consumes non-empty text.
    Links become inline URL buttons; «near» adds the location hint."""
    text = _norm(text)
    if not text:
        return False
    key = f"{platform}:{platform_user_id}"
    ctx = {"channel": platform, "user_key": (f"cust:{customer['id']}" if customer else key),
           "customer": customer, "owner": owner}
    hist = _bot_history(key)
    res = answer(text, ctx, hist)
    body = res["text"]
    rows = []
    for label, href in (res.get("links") or [])[:4]:
        url = href if href.startswith("http") else SITE + href
        rows.append([{"text": "🌐 " + label, "url": url}])
    if res.get("intent") == "register" and customer:
        rows.insert(0, [{"text": "➕ ثبت همین‌جا در بات", "callback_data": callback_prefix + "reg_start"}])
    if res.get("ok") and res.get("remaining") is not None:
        body += f"\n\n— دستیار دست گیر · {_fa(res['remaining'])} پیام دیگر امروز"
    rows.append([{"text": "🏠 منوی اصلی", "callback_data": callback_prefix + "menu"}])
    _bot_history(key, user_text=text, bot_text=res["text"])
    send(chat_id, body, {"inline_keyboard": rows})
    return True
