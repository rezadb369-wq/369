#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
=============================================================================
  دست گیر — اجراکنندهٔ سایت
  Daastgir — application runner
=============================================================================

  ▸ مخصوص Pydroid 3 (اندروید) و همچنین هر کامپیوتری با پایتون ۳
  ▸ هیچ کتابخانهٔ اضافه‌ای لازم نیست (فقط پایتون استاندارد)

  روش استفاده در Pydroid 3:
    ۱) فایل زیپ را در حافظهٔ گوشی از حالت فشرده خارج کنید.
    ۲) در Pydroid 3 همین فایل (run.py) را باز کنید.
    ۳) دکمهٔ ▶ (اجرا) را بزنید.
    ۴) روی «لینک پنل مالک» که پایین چاپ می‌شود بزنید.
    ۵) برای توقف، دکمهٔ ⏹ (استاپ) را بزنید.

=============================================================================
"""

import os
import sys
import time
import socket
import threading
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "server"))
sys.path.insert(0, os.path.join(HERE, "tools"))

# Moved off 8000 deliberately. The early prototype also served on 8000, and a
# browser keys cookies, localStorage, the service worker and its cache by
# ORIGIN — "127.0.0.1:8000" — not by which program answers there. So the old
# prototype's saved shell and stale session kept bleeding into the new site on
# the same phone, which is exactly what made it look like nothing had changed.
# A different port is a different origin, so the two can never collide again.
DEFAULT_PORT = 8080


def line(ch="=", n=64):
    print(ch * n)


def banner(text):
    print()
    line()
    print("  " + text)
    line()


def find_free_port(start=DEFAULT_PORT, tries=25):
    for i in range(tries):
        port = start + i
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("0.0.0.0", port))
                return port
            except OSError:
                continue
    return None


def lan_ip():
    """Best-effort LAN address so the site can be opened from another device."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return None


def preflight():
    problems = []
    site = os.path.join(HERE, "site")
    if not os.path.isdir(site):
        problems.append("پوشهٔ «site» پیدا نشد.")
        return problems
    for rel in ("assets/css/tokens.css", "assets/css/main.css", "assets/css/pages.css",
                "assets/js/app.js", "assets/js/map.js",
                "assets/fonts/Vazirmatn-Variable.woff2"):
        if not os.path.isfile(os.path.join(site, rel)):
            problems.append("فایل ضروری پیدا نشد: " + rel)
    # v75: category art is split into lazy-loaded WebP files. Requiring the old
    # 2.1MB all-in-one sprite would undo the main first-load speed improvement.
    cats = os.path.join(site, "assets", "img", "cats")
    if not os.path.isfile(os.path.join(cats, "business.webp")):
        problems.append("فایل‌های WebP دسته‌بندی پیدا نشد.")
    if not os.path.isdir(os.path.join(HERE, "server")):
        problems.append("پوشهٔ «server» پیدا نشد.")
    return problems


def main():
    banner("دست گیر — راه‌اندازی سایت")

    # ---- v116-perf: raise the process file-descriptor ceiling.
    # Default soft limit (often 1024) is exhausted under real load: every
    # keep-alive socket + every SQLite connection is an fd, and once it
    # runs out even db.connect() fails with «unable to open database
    # file» — measured: 77 500s at 200 concurrent clients. Android/Pydroid
    # honours setrlimit too. Best-effort: if it fails, carry on.
    try:
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        target = min(hard, 65536) if hard != resource.RLIM_INFINITY else 65536
        if soft < target:
            resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))
    except Exception:
        pass

    problems = preflight()
    if problems:
        print("\n  ✕ اجرا ممکن نیست:\n")
        for p in problems:
            print("    - " + p)
        print("\n  مطمئن شوید کل محتویات زیپ استخراج شده و run.py کنار")
        print("  پوشه‌های «site» و «server» قرار دارد.\n")
        try:
            input("  برای بستن، Enter را بزنید…")
        except EOFError:
            pass
        return 1

    import db
    import app as webapp

    db.init()

    port = None
    if "--port" in sys.argv:
        try:
            port = int(sys.argv[sys.argv.index("--port") + 1])
        except Exception:
            pass
    elif os.environ.get("PORT"):
        try:
            port = int(os.environ["PORT"])
        except Exception:
            pass

    if port is None:
        port = find_free_port()

    if port is None:
        print("\n  ✕ هیچ پورت آزادی پیدا نشد. برنامه‌های دیگر را ببندید.")
        return 1

    settings = db.get_settings()
    token = db.owner_token()
    stats = db.stats()

    base = f"http://127.0.0.1:{port}"
    owner_url = f"{base}/panel?key={token}"
    ip = lan_ip()

    print()
    print(f"  ✓ پایگاه داده آماده است  ({stats['categories']} دسته، "
          f"{stats['businesses']} کسب‌وکار)")
    print("  ✓ نقشه و فونت وزیرمتن به‌صورت محلی موجود است")
    print("  ✓ سرور بدون نیاز به نصب هیچ کتابخانه‌ای اجرا می‌شود")

    banner("سرور در حال اجراست")
    print()
    print("  ┌── سایت اصلی ─────────────────────────────────────────────")
    print(f"  │  {base}")
    print("  └──────────────────────────────────────────────────────────")
    print()
    print("  ╔══════════════════════════════════════════════════════════")
    print("  ║  ★★★  لینک پنل مالک  —  روی این بزنید  ★★★")
    print("  ╠══════════════════════════════════════════════════════════")
    print(f"  ║  {owner_url}")
    print("  ╚══════════════════════════════════════════════════════════")
    print()
    print("  در این پنل می‌توانید همه‌چیز را تغییر دهید:")
    print("    • افزودن، ویرایش و حذف کسب‌وکارها")
    print("    • ساخت و تغییر دسته‌بندی‌ها و آیکون‌ها")
    print("    • رنگ‌ها، متن‌ها و ظاهر کل سایت")
    print("    • نقشه، تخفیف‌ها، اخبار، نوبت‌ها و نظرات")
    print("    • پشتیبان‌گیری و بازیابی داده‌ها")
    print()
    print("  هر تغییری بلافاصله روی سایت اصلی اعمال می‌شود.")
    print()
    if ip:
        print(f"  ▸ از گوشی/رایانهٔ دیگر روی همین وای‌فای:  http://{ip}:{port}")
        print()
    print("  برای توقف: در Pydroid دکمهٔ ⏹ ، در کامپیوتر Ctrl+C")
    line("-")
    print()

    def open_browser():
        time.sleep(1.5)
        if not os.environ.get("RENDER") and not os.environ.get("PORT"):
            try:
                webbrowser.open(owner_url)
            except Exception:
                pass

    threading.Thread(target=open_browser, daemon=True).start()

    httpd = webapp.make_server(port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n\n  سرور متوقف شد. خدانگهدار!\n")
        httpd.shutdown()
    return 0


if __name__ == "__main__":
    sys.exit(main())
