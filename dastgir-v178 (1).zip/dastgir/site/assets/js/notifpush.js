/* دست گیر — v152 web push (Google/FCM, Chrome)
   ==================================================================
   Drives the "اعلان روی گوشی" card rendered on /my/notif-settings and
   /me/notif-settings (server: ui.notif_push_card). Loaded only on those
   two pages via extra_js.

   Rules (docs/NOTIFICATIONS.md §5):
     • never asks for permission on first load — only on the button click
     • when activation is impossible it says so briefly, without technical explanation
     • in-site notifications are the source of truth; this is an extra layer
   ================================================================== */
(function () {
  var card = document.getElementById('push-card');
  if (!card) return;
  var role = card.getAttribute('data-push-role') || 'cust';
  var statusEl = document.getElementById('push-status');
  var btnOn = document.getElementById('push-enable');
  var btnOff = document.getElementById('push-disable');
  var busy = false;

  function faDigits(n) {
    try { return Number(n).toLocaleString('fa-IR'); } catch (_) { return String(n); }
  }
  function setStatus(kind, text) {
    statusEl.className = 'alert alert-' + kind + ' mb-md';
    statusEl.innerHTML = '<span>' + text + '</span>';
  }
  function setBusy(on) {
    busy = on;
    if (btnOn) btnOn.disabled = on;
    if (btnOff) btnOff.disabled = on;
  }
  function urlB64ToU8(b64) {
    var pad = b64.replace(/=+$/, '');
    var raw = atob(pad.replace(/-/g, '+').replace(/_/g, '/'));
    var arr = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
    return arr;
  }
  function fetchCfg() {
    return fetch('/api/push/config', { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .catch(function () { return null; });
  }
  function postForm(url, body) {
    return fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body
    }).then(function (r) { return r.json(); });
  }

  function refresh() {
    if (busy) return;
    if (!window.isSecureContext) {
      setStatus('warn', 'اعلان گوشی اینجا در دسترس نیست.');
      return;
    }
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      setStatus('warn', 'اعلان گوشی اینجا در دسترس نیست.');
      return;
    }
    fetchCfg().then(function (c) {
      if (!c || !c.ok) {
        setStatus('err', 'فعلاً در دسترس نیست؛ کمی بعد دوباره امتحان کنید.');
        return;
      }
      if (!c.configured) {
        setStatus('info', 'اعلان گوشی هنوز فعال نشده است.');
        return;
      }
      if (!Notification || !Notification.requestPermission) return;
      if (Notification.permission === 'denied') {
        setStatus('warn', 'اجازهٔ اعلان خاموش است؛ از تنظیمات مرورگر می‌توانید روشنش کنید.');
        return;
      }
      navigator.serviceWorker.register('/sw.js').then(function (reg) {
        return reg.pushManager.getSubscription();
      }).then(function (sub) {
        if (sub) {
          btnOff.style.display = '';
          btnOn.style.display = 'none';
          setStatus('ok', 'اعلان گوشی برای این مرورگر <b>فعال</b> است؛ '
            + 'رویدادها هم‌زمان روی نوار بالای گوشی می‌آیند.');
        } else if (Notification.permission === 'granted') {
          btnOn.style.display = '';
          btnOff.style.display = 'none';
          setStatus('info', 'اجازه داده شده؛ برای دریافت روی گوشی، دکمهٔ فعال‌سازی را بزنید.');
        } else {
          btnOn.style.display = '';
          btnOff.style.display = 'none';
          setStatus('info', 'با زدن دکمه، مرورگر اجازه می‌پرسد — اجازه بدهید تا '
            + 'اعلان‌ها روی نوار بالای گوشی بیایند.');
        }
      }).catch(function (err) {
        setStatus('err', 'فعال‌سازی ممکن نشد؛ کمی بعد دوباره امتحان کنید.');
      });
    });
  }

  btnOn.addEventListener('click', function () {
    if (busy) return;
    setBusy(true);
    btnOn.style.display = 'none';
    setStatus('info', 'در حال فعال‌سازی…');
    Notification.requestPermission().then(function (perm) {
      if (perm !== 'granted') {
        setBusy(false);
        setStatus('warn', 'اجازهٔ اعلان خاموش است؛ از تنظیمات مرورگر می‌توانید روشنش کنید.');
        refresh();
        return;
      }
      fetchCfg().then(function (c) {
        if (!c || !c.ok || !c.configured || !c.vapid) {
          setBusy(false);
          setStatus('err', 'فعال‌سازی ممکن نشد؛ کمی بعد دوباره امتحان کنید.');
          return;
        }
        navigator.serviceWorker.register('/sw.js').then(function (reg) {
          return reg.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlB64ToU8(c.vapid)
          });
        }).then(function (sub) {
          return postForm('/api/push/subscribe',
            'role=' + encodeURIComponent(role) + '&sub=' +
            encodeURIComponent(JSON.stringify(sub)));
        }).then(function (j) {
          setBusy(false);
          if (j && j.ok) {
            setStatus('ok', 'عالی! اعلان‌ها از این پس هم‌زمان روی نوار بالای گوشی می‌آیند.');
            refresh();
          } else {
            setStatus('err', (j && j.error) || 'ثبت اشتراک ممکن نشد.');
            refresh();
          }
        }).catch(function (err) {
          setBusy(false);
          setStatus('err', 'فعال‌سازی ممکن نشد؛ دوباره تلاش کنید.');
        });
      });
    }).catch(function () {
      setBusy(false);
      setStatus('err', 'درخواست اجازه اجرا نشد؛ دوباره تلاش کنید.');
    });
  });

  btnOff.addEventListener('click', function () {
    if (busy) return;
    setBusy(true);
    navigator.serviceWorker.register('/sw.js').then(function (reg) {
      return reg.pushManager.getSubscription();
    }).then(function (sub) {
      if (!sub) return null;
      return postForm('/api/push/unsubscribe',
        'role=' + encodeURIComponent(role) + '&sub=' +
        encodeURIComponent(JSON.stringify(sub))).then(function () {
        return sub.unsubscribe();
      });
    }).then(function () {
      setBusy(false);
      setStatus('info', 'اعلان گوشی برای این مرورگر خاموش شد. اعلان داخل سایت همچنان فعال است.');
      refresh();
    }).catch(function () {
      setBusy(false);
      refresh();
    });
  });

  refresh();
})();
