/* دست گیر — v142 unread-badge poll for the header notification bell
   ==================================================================
   Loaded on every signed-in page (ui.page adds it when a bell exists).
   Polls /api/unread-count every 45 s (skipped while the tab is hidden)
   and keeps the red dot in sync. No dot markup exists until unread > 0;
   this script creates/removes it, so no CSS work was needed.
   ================================================================== */
(function () {
  var bell = document.querySelector('a[aria-label="اعلان‌ها"]');
  if (!bell) return;

  function faNum(n) {
    if (n >= 100) return '۹۹+';
    try { return Number(n).toLocaleString('fa-IR'); } catch (_) { return String(n); }
  }

  function render(n) {
    var dot = bell.querySelector('.fav-dot');
    if (n > 0) {
      if (!dot) {
        dot = document.createElement('span');
        dot.className = 'fav-dot';
        bell.appendChild(dot);
      }
      dot.textContent = faNum(n);
    } else if (dot) {
      dot.remove();
    }
  }

  function tick() {
    if (document.hidden) return;
    fetch('/api/unread-count', { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (j) { if (j && j.ok) render(j.n || 0); })
      .catch(function () { /* offline / transient — next tick retries */ });
  }

  setInterval(tick, 45000);
  tick();
})();
