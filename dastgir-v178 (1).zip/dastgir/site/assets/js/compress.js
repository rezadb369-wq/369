/* ==========================================================================
   Bazarche v139 — in-browser media compressor (image + video) + real upload
   progress for every form marked data-compress (the story composer).

   Runs on the device BEFORE a byte is uploaded, so the site stays
   dependency-free (no external/WASM library) and uploads stay light.

   Owner rules implemented here:
     1. EVERY photo and video is re-encoded (compressed) on publish — even
        when the result is not smaller, compression is never skipped;
     2. «در حال فشردهسازی…» is shown while it runs;
     3. EVERY video (any length — not only >30s) opens the SAME mobile-first
        trim panel right after picking:
          · two draggable handles (start/end) with a 44px touch target,
          · a filled window that slides as a whole,
          · tap the track to preview any moment,
          · − / + fine-tune to one tenth of a second,
          · «پخش نمونهٔ انتخابشده» verifies the exact [start,end] slice;
        Default selection: whole clip for ≤30s videos, 0→30 for longer ones.
     4. The trim panel never auto-compresses — the video is compressed ONLY
        when the user presses the form's publish button. One identical flow
        for short and long clips: press «انتشار استوری» → compress → upload.
     5. only stories accept video (chat and the rest stay image-only);
     6. setting the time (drags, −/+) stops a running sample instantly so
        the timer never "runs on its own" (v138 regression);
     7. picking a new file invalidates any in-flight encode (job token), so
        the form state always matches the latest choice;
     8. the final network upload runs over XHR so the shared UpBar
        (spinning ring + percentage + «در حال پردازش روی سرور…») is visible
        for stories exactly like gallery/chat uploads.
   ========================================================================== */

const IMG_EDGE = 1600;          // longest side for photos
const IMG_Q    = 0.82;          // JPEG quality (visually lossless)
const VID_EDGE = 720;           // longest side for story video
const VID_BITRATE = 1_200_000;  // ~1.2 Mbps target
const VID_MAX_S = 30;           // hard story limit: 30 seconds

const size = (b) => b > 1048576 ? (b / 1048576).toFixed(1) + ' مگابایت'
                                : Math.max(1, Math.round(b / 1024)) + ' کیلوبایت';
const isVideo = (f) => Boolean(f) && (/^video\//.test(f.type || '') || /\.(mp4|mov|m4v|webm)$/i.test(f.name || ''));

/* 0:00.0 – minute/second with one decimal, Latin digits inside .nums */
const fmtT = (x) => {
  const t = Math.max(0, Number(x) || 0);
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  return (m ? m + ':' : '0:') + s.toFixed(1).padStart(4, '0');
};
const clamp = (v, a, b) => Math.min(Math.max(v, a), b);

function loadImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('bad image')); };
    img.src = url;
  });
}

function videoMeta(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const v = document.createElement('video');
    v.preload = 'metadata'; v.muted = true; v.playsInline = true; v.src = url;
    v.onloadedmetadata = () => { URL.revokeObjectURL(url); resolve({ duration: v.duration || 0, w: v.videoWidth, h: v.videoHeight }); };
    v.onerror = () => { URL.revokeObjectURL(url); reject(new Error('bad video')); };
  });
}

/* ---- image: canvas resize + re-encode to JPEG (ALWAYS) ---- */
async function compressImage(file) {
  let img;
  try { img = await loadImage(file); } catch (_) { return null; }
  const scale = Math.min(1, IMG_EDGE / Math.max(img.width, img.height));
  const w = Math.round(img.width * scale);
  const h = Math.round(img.height * scale);
  const canvas = document.createElement('canvas');
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingQuality = 'high';
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h);   // flatten transparency
  ctx.drawImage(img, 0, 0, w, h);
  const blob = await new Promise(r => canvas.toBlob(r, 'image/jpeg', IMG_Q));
  if (!blob) return null;
  const name = (file.name || 'image').replace(/\.[a-z0-9]+$/i, '') + '.jpg';
  return { blob, name, kind: 'image', url: canvas.toDataURL('image/jpeg', 0.6),
           before: file.size, after: blob.size };
}

/* ---- video: trim [start,end] then re-encode (canvas.captureStream + MediaRecorder) ---- */
async function compressVideo(file, start = 0, end = Infinity, onProgress) {
  if (typeof MediaRecorder === 'undefined' || !HTMLCanvasElement.prototype.captureStream) return null;
  const url = URL.createObjectURL(file);
  const v = document.createElement('video');
  v.muted = true; v.playsInline = true; v.preload = 'auto'; v.src = url;
  try {
    await new Promise((res, rej) => { v.onloadedmetadata = res; v.onerror = () => rej(new Error('v')); });
    const dur = v.duration || 0;
    const s = Math.max(0, Math.min(start, dur));
    const e = Math.min(end == null ? dur : end, dur);
    const span = Math.max(0.2, e - s);
    if (!dur || !v.videoWidth) throw new Error('no video track');
    const scale = Math.min(1, VID_EDGE / Math.max(v.videoWidth, v.videoHeight));
    const w = Math.round(v.videoWidth * scale), h = Math.round(v.videoHeight * scale);
    const canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d');
    const mixed = new MediaStream(canvas.captureStream(30).getVideoTracks());
    try {
      const src = v.captureStream ? v.captureStream() : (v.mozCaptureStream && v.mozCaptureStream());
      if (src) src.getAudioTracks().forEach(t => mixed.addTrack(t));
    } catch (_) { /* video-only fallback */ }
    const mime = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus') ? 'video/webm;codecs=vp9,opus'
               : MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus') ? 'video/webm;codecs=vp8,opus'
               : MediaRecorder.isTypeSupported('video/webm') ? 'video/webm' : '';
    if (!mime) throw new Error('no webm');
    const rec = new MediaRecorder(mixed, { mimeType: mime, videoBitsPerSecond: VID_BITRATE, audioBitsPerSecond: 96000 });
    const chunks = []; rec.ondataavailable = ev => ev.data && ev.data.size && chunks.push(ev.data);
    const stopped = new Promise(res => { rec.onstop = res; });
    v.currentTime = s;
    await new Promise(res => { v.onseeked = res; setTimeout(res, 800); });
    rec.start(200);
    await v.play();
    const draw = () => {
      ctx.drawImage(v, 0, 0, w, h);
      onProgress && onProgress(Math.min(0.98, (v.currentTime - s) / span));
      if (v.currentTime < e && !v.ended) requestAnimationFrame(draw);
    };
    draw();
    await new Promise(res => {
      const t = setInterval(() => { if (v.currentTime >= e || v.ended) { clearInterval(t); res(); } }, 80);
      setTimeout(() => { clearInterval(t); res(); }, (span + 2) * 1000);
    });
    v.pause(); rec.stop(); await stopped;
    URL.revokeObjectURL(url);
    const blob = new Blob(chunks, { type: 'video/webm' });
    if (!blob.size) return null;
    const name = (file.name || 'story').replace(/\.[a-z0-9]+$/i, '') + '.webm';
    return { blob, name, kind: 'video', url: URL.createObjectURL(blob),
             before: file.size, after: blob.size, duration: span };
  } catch (_) {
    URL.revokeObjectURL(url);
    return null;
  }
}

async function compress(file, opts = {}) {
  const { start = 0, end = Infinity, onProgress } = opts;
  if (isVideo(file)) {
    const r = await compressVideo(file, start, end, onProgress);
    const span = (end == null || end === Infinity) ? 0 : Math.max(0, end - start);
    return r || { blob: file, name: file.name, kind: 'video',
                  url: URL.createObjectURL(file), before: file.size, after: file.size,
                  original: true, duration: span };
  }
  const r = await compressImage(file);
  return r || { blob: file, name: file.name, kind: 'image',
                url: URL.createObjectURL(file), before: file.size, after: file.size, original: true };
}

window.BazarcheCompress = { compress, compressImage, compressVideo, isVideo, videoMeta, size, VID_MAX_S };

/* ==========================================================================
   The composer — attached to any form marked data-compress.
   ========================================================================== */
function initForm(form) {
  if (form.dataset.czInit) return;   // idempotent: never bind a form twice
  form.dataset.czInit = '1';
  const input = form.querySelector('input[data-compress-input]') || form.querySelector('input[type=file]');
  if (!input) return;
  const submit = form.querySelector('[type=submit]');

  /* state */
  const st = { dur: 0, s: 0, e: 0, playing: false, drag: null };
  let srcFile = null;          // ORIGINAL picked file (trim/publish always run from it)
  let lastKind = '';           // 'image' | 'video'
  let isCompressedReady = false;   // compressed bytes already swapped into input.files
  let uploading = false;           // XHR upload in flight
  let busy = false;                // compression in flight
  let jobTok = 0;                  // invalidates stale encodes
  let trimUrl = '';                // blob URL handed to the trim <video>
  const MIN_GAP = 0.2;         // seconds — keep the two handles apart
  const maxLen = () => Math.min(st.dur || VID_MAX_S, VID_MAX_S);

  /* ui */
  const ui = document.createElement('div');
  ui.className = 'cz';
  ui.innerHTML = `
    <p class="cz-status" data-cz-status hidden></p>
    <div class="cz-trim" data-cz-trim hidden>
      <p class="cz-trim-msg"></p>
      <div class="cz-video-wrap">
        <video class="cz-trim-video" data-cz-trim-video muted playsinline preload="metadata"></video>
        <button type="button" class="cz-video-play" data-cz-video-play aria-label="پخش نمونه">&#9654;</button>
      </div>
      <div class="cz-scrub" dir="ltr" data-cz-scrub>
        <div class="cz-track" data-cz-track>
          <div class="cz-line" aria-hidden="true"></div>
          <div class="cz-range" data-cz-range aria-hidden="true"></div>
          <button type="button" class="cz-h" data-cz-h="start" aria-label="انتخاب زمان شروع — بکشید"></button>
          <button type="button" class="cz-h" data-cz-h="end" aria-label="انتخاب زمان پایان — بکشید"></button>
        </div>
        <div class="cz-times" aria-hidden="true">
          <span class="nums" data-cz-start>0:00.0</span>
          <span class="nums cz-dur" data-cz-dur>0:30.0</span>
          <span class="nums" data-cz-end>0:30.0</span>
        </div>
      </div>
      <div class="cz-sidebar">
        <div class="cz-side">
          <button type="button" class="cz-step" data-cz-step="start" data-dir="-1" aria-label="کم کردن زمان شروع">−</button>
          <span class="cz-side-box"><span class="cz-side-label">شروع</span><span class="cz-val nums" data-cz-val="start">0:00.0</span></span>
          <button type="button" class="cz-step" data-cz-step="start" data-dir="1" aria-label="زیاد کردن زمان شروع">+</button>
        </div>
        <div class="cz-side">
          <button type="button" class="cz-step" data-cz-step="end" data-dir="-1" aria-label="کم کردن زمان پایان">−</button>
          <span class="cz-side-box"><span class="cz-side-label">پایان</span><span class="cz-val nums" data-cz-val="end">0:30.0</span></span>
          <button type="button" class="cz-step" data-cz-step="end" data-dir="1" aria-label="زیاد کردن زمان پایان">+</button>
        </div>
      </div>
      <p class="cz-trim-hint">دستگیره‌ها را بکشید یا − / + را بزنید تا بازهٔ دلخواه بیاید؛ گرفتنِ روی بخش پررنگ، کل پنجره را جابه‌جا می‌کند. پس از انتخاب، همان دکمهٔ «انتشار استوری» را بزنید — ویدیو خودکار فشرده و ارسال می‌شود.</p>
      <div class="cz-sample">
        <button type="button" class="btn btn-ghost btn-sm cz-play" data-cz-play>▶ پخش نمونهٔ انتخاب‌شده</button>
      </div>
      <div class="cz-trim-actions">
        <button type="button" class="btn btn-ghost btn-sm" data-cz-trim-cancel>لغو و انتخاب فایل دیگر</button>
      </div>
    </div>
    <div class="cz-preview" data-cz-preview hidden>
      <div class="cz-media" data-cz-media></div>
      <div class="cz-meta">
        <span class="cz-size" data-cz-size></span>
        <button type="button" class="btn btn-ghost btn-sm" data-cz-cancel>لغو و انتخاب دوباره</button>
      </div>
    </div>`;
  (input.closest('label') || input).after(ui);

  const statusEl   = ui.querySelector('[data-cz-status]');
  const trimEl     = ui.querySelector('[data-cz-trim]');
  const prevEl     = ui.querySelector('[data-cz-preview]');
  const mediaEl    = ui.querySelector('[data-cz-media]');
  const sizeEl     = ui.querySelector('[data-cz-size]');
  const cancelEl   = ui.querySelector('[data-cz-cancel]');
  const trimVideo  = ui.querySelector('[data-cz-trim-video]');
  const trimCancel = ui.querySelector('[data-cz-trim-cancel]');
  const playBtn    = ui.querySelector('[data-cz-play]');
  const bigPlay    = ui.querySelector('[data-cz-video-play]');
  const track      = ui.querySelector('[data-cz-track]');
  const rangeEl    = ui.querySelector('[data-cz-range]');
  const startOut   = ui.querySelector('[data-cz-start]');
  const endOut     = ui.querySelector('[data-cz-end]');
  const durOut     = ui.querySelector('[data-cz-dur]');
  const startVal   = ui.querySelector('[data-cz-val="start"]');
  const endVal     = ui.querySelector('[data-cz-val="end"]');
  const handles    = { start: ui.querySelector('[data-cz-h="start"]'),
                       end: ui.querySelector('[data-cz-h="end"]') };

  const setStatus = (t) => { statusEl.textContent = t || ''; statusEl.hidden = !t; };
  const setBusy = (on) => {
    busy = on;
    if (submit) submit.disabled = on || !input.files || !input.files.length;
    ui.classList.toggle('is-busy', on);
  };
  const setTrimSrc = (file) => {
    if (trimUrl) { try { URL.revokeObjectURL(trimUrl); } catch (_) {} trimUrl = ''; }
    if (file) { trimUrl = URL.createObjectURL(file); trimVideo.src = trimUrl; }
    else trimVideo.removeAttribute('src');
  };

  const paint = () => {
    if (st.dur <= 0) return;
    const pS = (st.s / st.dur) * 100;
    const pE = (st.e / st.dur) * 100;
    handles.start.style.left = pS + '%';
    handles.end.style.left = pE + '%';
    rangeEl.style.left = pS + '%';
    rangeEl.style.width = Math.max(0, pE - pS) + '%';
    startOut.textContent = startVal.textContent = fmtT(st.s);
    endOut.textContent = endVal.textContent = fmtT(st.e);
    durOut.textContent = fmtT(st.e - st.s);
    trimEl.dataset.s = st.s.toFixed(1);
    trimEl.dataset.e = st.e.toFixed(1);
    trimEl.dataset.dur = st.dur.toFixed(1);
  };

  /* movement rules: never wider than 30s, never below MIN_GAP, and pulling
     a handle past its limit slides/drags the window instead of jumping. */
  const moveStart = (ns) => {
    if (st.dur <= 0) return;
    const lo = Math.max(0, st.e - maxLen());
    const hi = Math.min(st.dur, st.e - MIN_GAP);
    st.s = clamp(ns, lo, hi);
  };
  const moveEnd = (ne) => {
    if (st.dur <= 0) return;
    const lo = Math.max(0, st.s + MIN_GAP);
    const hi = Math.min(st.dur, st.s + maxLen());
    st.e = clamp(ne, lo, hi);
  };
  const slideWin = (ns) => {
    if (st.dur <= 0) return;
    const len = st.e - st.s;
    const s2 = clamp(ns, 0, Math.max(0, st.dur - len));
    st.s = s2; st.e = s2 + len;
  };
  const nudge = (which, delta) => {
    if (st.dur <= 0) return;
    if (st.playing) stopSample(true);   // editing time while it plays feels like
                                        // the timer "runs on its own" — stop it first
    if (which === 'start') moveStart(st.s + delta); else moveEnd(st.e + delta);
    paint();
  };
  const timeFromX = (clientX) => {
    const r = track.getBoundingClientRect();
    if (r.width <= 0) return st.s;
    return clamp((clientX - r.left) / r.width, 0, 1) * st.dur;
  };
  const seekPreview = (t) => {
    if (!st.playing) trimVideo.currentTime = clamp(t, 0, st.dur);
  };

  /* ----- pointer dragging (mouse + touch, pointer events) -------------- */
  const onDown = (ev) => {
    if (st.dur <= 0) return;
    if (st.playing) stopSample(true);   // touching the track stops a running sample
    const hEl = ev.target.closest('[data-cz-h]');
    if (hEl) st.drag = { mode: hEl.dataset.czH, sx: ev.clientX, s0: st.s, e0: st.e, el: hEl };
    else if (ev.target.closest('[data-cz-range]')) st.drag = { mode: 'win', sx: ev.clientX, s0: st.s, e0: st.e };
    else { seekPreview(timeFromX(ev.clientX)); return; }
    ev.preventDefault();
    st.drag.el && st.drag.el.classList.add('is-drag');
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
  };
  const onMove = (ev) => {
    if (!st.drag) return;
    const w = track.getBoundingClientRect().width || 1;
    const dt = ((ev.clientX - st.drag.sx) / w) * st.dur;
    if (st.drag.mode === 'start') moveStart(st.drag.s0 + dt);
    else if (st.drag.mode === 'end') moveEnd(st.drag.e0 + dt);
    else slideWin(st.drag.s0 + dt);
    if (st.playing) stopSample(false);
    paint();
  };
  const onUp = () => {
    if (st.drag) { st.drag.el && st.drag.el.classList.remove('is-drag'); st.drag = null; }
    window.removeEventListener('pointermove', onMove);
    window.removeEventListener('pointerup', onUp);
    window.removeEventListener('pointercancel', onUp);
  };
  track.addEventListener('pointerdown', onDown);

  /* ----- fine − / + steppers: tap = 0.1s, hold = continuous -----------
     Bug fixed (v148): the release handler only cancelled the repeat timer
     when `held` had already flipped, so a SHORT tap left the 380ms hold
     timer armed -- it fired 380ms after the tap, started the 120ms repeat
     loop and the time then advanced on its own forever (and every repeat
     call silenced the sample player). Now release always cancels; a flag
     tells the trailing click whether the gesture was a real hold (so it
     adds no extra nudge) or a tap (one 0.1s step). */
  const bindStepper = (btn) => {
    const which = btn.dataset.czStep;
    const dir = Number(btn.dataset.dir) || 1;
    let holdTimer = null, repTimer = null, holdFired = false;
    const stop = () => { if (holdTimer) { clearTimeout(holdTimer); holdTimer = null; }
                         if (repTimer) { clearInterval(repTimer); repTimer = null; } };
    btn.addEventListener('pointerdown', (ev) => {
      ev.preventDefault(); stop(); holdFired = false;
      holdTimer = setTimeout(() => {
        holdFired = true;
        repTimer = setInterval(() => nudge(which, 0.1 * dir), 120);
      }, 380);
    });
    ['pointerup', 'pointerleave', 'pointercancel'].forEach((evName) =>
      btn.addEventListener(evName, stop));
    btn.addEventListener('click', (ev) => {
      ev.preventDefault();
      if (holdFired) { holdFired = false; return; }
      nudge(which, 0.1 * dir);
    });
    btn.addEventListener('contextmenu', (ev) => ev.preventDefault());
  };
  ui.querySelectorAll('[data-cz-step]').forEach(bindStepper);

  /* ----- «پخش نمونهٔ انتخابشده» — plays exactly [start,end] ----------- */
  const syncPlayUI = () => {
    playBtn.textContent = st.playing ? '⏸ توقف نمونه' : '▶ پخش نمونه';
    playBtn.classList.toggle('is-on', st.playing);
    if (bigPlay) { bigPlay.innerHTML = st.playing ? '❚❚' : '&#9654;'; bigPlay.classList.toggle('is-on', st.playing); }
  };
  const stopSample = (resetTime) => {
    st.playing = false;
    syncPlayUI();
    trimVideo.pause();
    if (resetTime) trimVideo.currentTime = st.s;
  };
  const togglePlay = () => {
    if (st.playing) { stopSample(true); return; }
    if (st.e - st.s < MIN_GAP) return;
    trimVideo.currentTime = st.s;
    st.playing = true;
    syncPlayUI();
    trimVideo.play().catch(() => stopSample(true));
  };
  trimVideo.addEventListener('timeupdate', () => {
    if (st.playing && trimVideo.currentTime >= st.e) { stopSample(true); }
  });
  trimVideo.addEventListener('ended', () => stopSample(true));
  trimVideo.addEventListener('click', (ev) => { ev.preventDefault(); togglePlay(); });
  if (bigPlay) bigPlay.addEventListener('click', (ev) => { ev.preventDefault(); ev.stopPropagation(); togglePlay(); });
  playBtn.addEventListener('click', togglePlay);

  /* ----- resets -------------------------------------------------------- */
  const clearTrimPreview = () => { setTrimSrc(null); stopSample(true); };
  const reset = () => {
    if (window.UpBar) window.UpBar.hide();
    input.value = '';
    srcFile = null; lastKind = '';
    isCompressedReady = false; uploading = false;
    prevEl.hidden = true; trimEl.hidden = true; mediaEl.innerHTML = '';
    trimEl.dataset.s = trimEl.dataset.e = trimEl.dataset.dur = '';
    clearTrimPreview(); setBusy(false); setStatus('');
  };
  const resetSoft = () => {                 // cancel → back to picker
    if (window.UpBar) window.UpBar.hide();
    input.value = '';
    srcFile = null; lastKind = '';
    isCompressedReady = false;
    prevEl.hidden = true; trimEl.hidden = true; mediaEl.innerHTML = '';
    clearTrimPreview(); setBusy(false);
    setStatus('لغو شد — فایلی انتخاب نشده.');
  };
  cancelEl.addEventListener('click', reset);
  trimCancel.addEventListener('click', resetSoft);

  /* ----- compression (device-side, always re-encodes) ------------------ */
  /* Returns true when ready bytes are swapped into input.files. */
  async function runCompress(file, start, end, needsTrim, withBar) {
    const video = isVideo(file);
    const tok = ++jobTok;
    isCompressedReady = false;
    uploading = false;
    setBusy(true);
    const label = video ? 'در حال فشرده‌سازی ویدیو…' : 'در حال فشرده‌سازی تصویر…';
    setStatus(label);
    if (withBar && window.UpBar) window.UpBar.show(label);
    try {
      const r = await compress(file, { start, end, onProgress: (p) => {
        if (tok !== jobTok) return;
        const pct = Math.round(p * 100);
        setStatus(label + ' ' + pct + '٪');
        if (withBar && window.UpBar) window.UpBar.set(pct);
      } });
      if (tok !== jobTok) return false;      // a newer choice superseded this job
      if (!r) throw new Error('compress failed');
      // Honest fallback: a device without MediaRecorder/captureStream can
      // never trim — never silently upload the untouched long clip labelled
      // with a shorter duration. Say so and stop.
      if (needsTrim && r.original && r.kind === 'video') {
        setStatus('این مرورگر برش ویدیو را پشتیبانی نمی‌کند. مرورگر را به‌روزرسانی کنید یا ویدیو را بدون برش بفرستید.');
        setBusy(false);
        return false;
      }
      const dt = new DataTransfer();
      dt.items.add(new File([r.blob], r.name, { type: r.blob.type || (r.kind === 'video' ? 'video/webm' : 'image/jpeg') }));
      input.files = dt.files;                // swap in the compressed bytes

      let durField = form.querySelector('input[name="duration"]');
      if (!durField) {
        durField = document.createElement('input');
        durField.type = 'hidden'; durField.name = 'duration'; form.appendChild(durField);
      }
      durField.value = r.kind === 'video' ? String(Math.round((r.duration || 0) * 10) / 10) : '0';

      mediaEl.innerHTML = r.kind === 'video'
        ? `<video src="${r.url}" muted playsinline controls preload="metadata"></video>`
        : `<img src="${r.url}" alt="پیش‌نمایش">`;
      sizeEl.textContent = r.original
        ? `فشرده‌سازی در مرورگر ممکن نشد (${size(r.after)})`
        : `${size(r.before)} ← ${size(r.after)}`;
      trimEl.hidden = true;
      prevEl.hidden = false;
      isCompressedReady = true;
      jobTok++;                              // silence any straggler progress frame
      setBusy(false);
      setStatus('فشرده شد و آمادهٔ انتشار است.');
      return true;
    } catch (_) {
      setStatus('فشرده‌سازی ناموفق بود. فایل دیگری انتخاب کنید.');
      if (withBar && window.UpBar) window.UpBar.error('فشرده‌سازی ناموفق بود');
      setBusy(false);
      return false;
    }
  }

  /* ----- the trim panel (every video — short AND long) ----------------- */
  function showTrim(file, meta) {
    st.dur = Math.max(0.1, meta.duration);
    const wholeCap = Math.min(st.dur, VID_MAX_S);
    st.s = 0;
    st.e = wholeCap;
    setTrimSrc(file);
    const whole = st.dur <= VID_MAX_S + 0.05;
    ui.querySelector('.cz-trim-msg').textContent = whole
      ? `ویدیوی شما ${Math.round(st.dur)} ثانیه است — کل آن انتخاب شده. اگر می‌خواهید کوتاه‌ترش کنید، دستگیره‌ها را بکشید و بعد «انتشار استوری» را بزنید.`
      : `این ویدیو ${Math.round(st.dur)} ثانیه است. استوری‌ها حداکثر ${VID_MAX_S} ثانیه‌اند — بازهٔ دلخواه را انتخاب کنید:`;
    trimEl.hidden = false;
    isCompressedReady = false;               // publish compresses from the ORIGINAL file
    setBusy(false);                          // publish button is live — one press does all
    setStatus('');
    paint();
  }

  /* ----- file picked ------------------------------------------------ */
  input.addEventListener('change', async () => {
    const f = input.files && input.files[0];
    if (!f) { reset(); return; }
    jobTok++;                                // any earlier encode is now stale
    srcFile = f;
    clearTrimPreview();
    prevEl.hidden = true; trimEl.hidden = true;
    isCompressedReady = false; uploading = false;
    setBusy(true);                           // brief: no file-ready until we know the type
    if (isVideo(f)) {
      let meta;
      try { meta = await videoMeta(f); } catch (_) {
        setStatus('ویدیو خوانده نشد. فرمت دیگری امتحان کنید.'); setBusy(false); return;
      }
      lastKind = 'video';
      setBusy(false);
      showTrim(f, meta);                     // one identical composer for every video
      return;
    }
    if (!/^image\//.test(f.type || '') && !/\.(jpe?g|png|webp|gif|heic|heif)$/i.test(f.name || '')) {
      setStatus('فقط عکس یا فیلم معتبر.'); setBusy(false); return;
    }
    lastKind = 'image';
    runCompress(f, 0, Infinity, false, false); // silent preview for a freshly picked image
  });

  /* ----- publish: ONE press → compress (if needed) → upload with UpBar - */
  async function uploadReadyBlob() {
    if (!input.files || !input.files.length) return;
    uploading = true;
    setBusy(true);
    const fd = new FormData(form);
    const xhr = new XMLHttpRequest();
    const action = form.getAttribute('action') || form.action;
    xhr.open('POST', action, true);
    xhr.upload.addEventListener('progress', (ev) => {
      if (ev.lengthComputable && window.UpBar) window.UpBar.set((ev.loaded / ev.total) * 100);
    });
    xhr.addEventListener('load', () => {
      uploading = false;
      if (xhr.status >= 200 && xhr.status < 400) {
        const dest = xhr.responseURL || action;
        if (window.UpBar) {
          window.UpBar.done('ارسال شد');
          setTimeout(() => { location.href = dest; }, 400);
        } else {
          location.href = dest;
        }
      } else {
        if (window.UpBar) window.UpBar.error('آپلود ناموفق بود (' + xhr.status + ')');
        setStatus('آپلود ناموفق بود. دوباره تلاش کنید.');
        setBusy(false);
      }
    });
    xhr.addEventListener('error', () => {
      uploading = false;
      if (window.UpBar) window.UpBar.error('خطای شبکه — دوباره تلاش کنید.');
      setStatus('ارسال انجام نشد. اینترنت را بررسی کنید.');
      setBusy(false);
    });
    xhr.addEventListener('abort', () => { uploading = false; setBusy(false); });
    if (window.UpBar) window.UpBar.show('در حال آپلود استوری…');
    setStatus('در حال ارسال به سرور…');
    xhr.send(fd);
  }

  form.addEventListener('submit', (e) => {
    if (!input.files || !input.files.length) return;   // untouched → native required
    e.preventDefault();
    if (busy || uploading) return;
    if (lastKind === 'video') {
      if (!srcFile) { setStatus('فایل ویدیو آماده نیست — دوباره انتخاب کنید.'); return; }
      if (st.dur <= 0) { setStatus('لطفاً کمی صبر کنید تا ویدیو بارگذاری شود…'); return; }
      if (st.e - st.s < MIN_GAP) { setStatus('بازهٔ انتخاب‌شده خیلی کوتاه است.'); return; }
      stopSample(true);
      const windowIsWhole = (st.s <= 0.05) && (st.e >= st.dur - 0.05) && (st.dur <= VID_MAX_S + 0.05);
      setStatus('در حال فشرده‌سازی ویدیو…');
      runCompress(srcFile, st.s, st.e, !windowIsWhole, true)
        .then(ok => { if (ok) uploadReadyBlob(); });
      return;
    }
    if (isCompressedReady) { uploadReadyBlob(); return; }
    // image still compressing → finish it, then upload
    const f = input.files && input.files[0];
    if (!f) return;
    runCompress(f, 0, Infinity, false, true).then(ok => { if (ok) uploadReadyBlob(); });
  });
}

/* ---- anonymised story view stats (owner panel) ---- */
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-story-stats]');
  if (!btn) return;
  const id = btn.dataset.storyStats;
  const panel = document.querySelector(`[data-story-stats-panel="${id}"]`);
  if (!panel) return;
  if (!panel.hidden) { panel.hidden = true; return; }
  panel.hidden = false;
  panel.innerHTML = '<span class="text-muted">در حال بارگذاری…</span>';
  try {
    const r = await fetch(`/my/story/${id}/views`, { headers: { Accept: 'application/json' } });
    const j = await r.json();
    if (!j.ok) throw new Error('forbidden');
    const days = (j.per_day || []).map(d =>
      `<li><span class="nums">${d.day}</span><span class="nums">${d.n} بازدیدکننده</span></li>`).join('');
    panel.innerHTML = `
      <div class="story-stats-head"><strong class="nums">${j.total}</strong> بازدیدکنندهٔ واقعی
        <span class="text-muted">· ۲۴ ساعت اخیر: <span class="nums">${j.last24h}</span></span></div>
      <p class="text-sm text-muted">هر بازدیدکننده یک‌بار شمرده می‌شود؛ رفرش دوباره شمرده نمی‌شود و اطلاعات هویتی هم ذخیره نمی‌شود.</p>
      <ul class="story-stats-days">${days || '<li class="text-muted">هنوز بازدیدی ثبت نشده.</li>'}</ul>`;
  } catch (_) {
    panel.innerHTML = '<span class="text-muted">آمار در دسترس نیست.</span>';
  }
});

function boot() { document.querySelectorAll('form[data-compress]').forEach(initForm); }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
