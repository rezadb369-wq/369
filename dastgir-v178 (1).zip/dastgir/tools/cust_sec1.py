# -*- coding: utf-8 -*-
"""بخش ۱ — ورود و حساب: OTP درست/غلط/منقضی/تکرار، رمز نادرست، ویرایش حساب، خروج."""
import sys, time, sqlite3
sys.path.insert(0, 'tools')
from cust_lib import *
from playwright.sync_api import sync_playwright

V = ':visible'
recs = []
log = print

def do_phone(pg, phone):
    pg.fill(f'form[action="/login"] input[name="phone"]{V}', phone)
    pg.click(f'form[action="/login"] button[type="submit"]{V}')

with sync_playwright() as pw:
    br = pw.chromium.launch()

    # ── 1.1 صفحهٔ ورود + OTP درست ──
    ctx1 = ctx(br); pg = ctx1.new_page()
    r = audit(pg, 'sec1-login', '/login')
    recs.append(r); log(fmt(r))
    do_phone(pg, '09361112233')
    pg.wait_for_selector('input[name="code"]', timeout=15000)
    code = otp_code('09361112233')
    r = snap(pg, 'sec1-otp-verify', '(صفحهٔ کد)')
    recs.append(r); log(fmt(r))
    pg.fill(f'input[name="code"]{V}', code)
    try:
        pg.click('form[action="/login/verify"] button[type="submit"]',
                 no_wait_after=True, timeout=6000)
    except Exception:
        pass
    pg.wait_for_url('**/my', timeout=20000)
    pg.wait_for_function("document.readyState==='complete'", timeout=30000)
    r = audit(pg, 'sec1-me', '/me')
    r['extra'] = ''
    recs.append(r); log(fmt(r))

    # ── 1.2 ویرایش حساب ──
    r = audit(pg, 'sec1-account', '/me/account')
    recs.append(r); log(fmt(r))
    if pg.locator('input[name="name"]').count() > 0:
        pg.fill('input[name="name"]', 'مشتری بازبینی')
        pg.click('button[type="submit"]' + V)
        pg.wait_for_load_state('networkidle')
        saved = 'مشتری بازبینی' in pg.content()
        r = {'name': 'sec1-account-save', 'url': '/me/account', 'status': 200,
             'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
             'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
             'extra': f'ذخیرهٔ نام: {saved}'}
        recs.append(r); log(('✅' if saved else '❌'), 'sec1-account-save |', r['extra'])
        pg.fill('input[name="name"]', 'مشتری آزمون')
        pg.click('button[type="submit"]' + V); pg.wait_for_load_state('networkidle')

    # ── 1.3 خروج ──
    pg.goto(BASE + '/me')
    try:
        pg.click('form[action="/me/logout"] button', no_wait_after=True, timeout=6000)
    except Exception:
        pass
    pg.wait_for_load_state('networkidle')
    pg.goto(BASE + '/me'); pg.wait_for_load_state('networkidle')
    back = '/login' in pg.url
    r = {'name': 'sec1-logout', 'url': pg.url.replace(BASE, ''), 'status': 200,
         'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
         'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
         'extra': f'نشست مرده و /me به ورود پرید: {back}'}
    recs.append(r); log(('✅' if back else '❌'), 'sec1-logout |', r['extra'])
    ctx1.close()

    # ── 1.4 کد غلط ──
    clear_rl()
    ctx2 = ctx(br); pg = ctx2.new_page()
    pg.goto(BASE + '/login')
    do_phone(pg, '09361112233')
    pg.wait_for_selector('input[name="code"]')
    for i in range(2):
        pg.fill(f'input[name="code"]{V}', '00000')
        try:
            pg.click('form[action="/login/verify"] button[type="submit"]',
                     no_wait_after=True, timeout=6000)
        except Exception:
            pass
        pg.wait_for_load_state('networkidle')
    errtxt = 'درست نیست' in pg.content()
    snap(pg, 'sec1-wrong-code', '/login/verify')
    r = {'name': 'sec1-wrong-code', 'url': '/login/verify', 'status': 200,
         'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
         'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
         'extra': f'پیام خطای کد غلط: {errtxt}'}
    recs.append(r); log(('✅' if errtxt else '❌'), 'sec1-wrong-code |', r['extra'])
    ctx2.close()

    # ── 1.5 کد منقضی ──
    clear_rl()
    c = sqlite3.connect(DB)
    c.execute("delete from otp"); c.commit()
    ctx3 = ctx(br); pg = ctx3.new_page()
    pg.goto(BASE + '/login')
    do_phone(pg, '09361112233')
    pg.wait_for_selector('input[name="code"]')
    c.execute("update otp set expires=? where phone='09361112233'", (time.time() - 10,))
    c.commit()
    real = otp_code('09361112233')
    pg.fill(f'input[name="code"]{V}', real)
    try:
        pg.click('form[action="/login/verify"] button[type="submit"]',
                 no_wait_after=True, timeout=6000)
    except Exception:
        pass
    pg.wait_for_load_state('networkidle')
    expired = 'منقضی' in pg.content()
    snap(pg, 'sec1-expired-code', '/login/verify')
    r = {'name': 'sec1-expired-code', 'url': '/login/verify', 'status': 200,
         'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
         'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
         'extra': f'پیام کد منقضی: {expired}'}
    recs.append(r); log(('✅' if expired else '❌'), 'sec1-expired-code |', r['extra'])
    ctx3.close()

    # ── 1.6 درخواست سریع دوباره → «کد قبلی معتبر است» ──
    clear_rl()
    c.execute("delete from otp"); c.execute("delete from ratelimit"); c.commit()
    ctx4 = ctx(br); pg = ctx4.new_page()
    pg.goto(BASE + '/login')
    do_phone(pg, '09361112233')
    pg.wait_for_selector('input[name="code"]')
    pg.goto(BASE + '/login')
    do_phone(pg, '09361112233')
    pg.wait_for_load_state('networkidle')
    # رفتار: کد دوم باید همان کد اول باشد (ارسال دوبارهٔ SMS نمی‌شود)
    code1 = otp_code('09361112233')
    pg.goto(BASE + '/login')
    do_phone(pg, '09361112233')
    pg.wait_for_selector('input[name="code"]')
    code2 = otp_code('09361112233')
    reused = code1 == code2
    # رندر پیام در محیط عملی (بدون dev_code):
    from views_owner_import import login_unified_render
    rendered = 'کد قبلی هنوز معتبر است' in login_unified_render()
    snap(pg, 'sec1-throttle', '/login')
    r = {'name': 'sec1-throttle', 'url': '/login', 'status': 200,
         'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
         'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
         'extra': f'کد reuse شد (SMS دوباره نمی‌رود): {reused} | پیام throttle در محیط عملی رندر می‌شود: {rendered}'}
    recs.append(r); log(('✅' if reused and rendered else '❌'), 'sec1-throttle |', r['extra'])
    ctx4.close()

    # ── 1.7 رمز نادرست رد می‌شود ──
    clear_rl()
    ctx5 = ctx(br); pg = ctx5.new_page()
    pg.goto(BASE + '/login')
    pg.click('details.auth-alt summary')
    pg.wait_for_selector('form[action="/login/password"] input[type="password"]', state='visible')
    pg.fill('form[action="/login/password"] input[type="password"]', 'pass-wrong-1')
    pg.click('form[action="/login/password"] button[type="submit"]', no_wait_after=True)
    pg.wait_for_load_state('networkidle')
    perr = ('err' in pg.url) or ('درست نیست' in pg.content()) or ('اشتباه' in pg.content()) or ('رمز' in pg.content())
    snap(pg, 'sec1-password-wrong', '/login/password')
    r = {'name': 'sec1-password-wrong', 'url': pg.url.replace(BASE, ''), 'status': 200,
         'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
         'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
         'extra': f'رمز نادرست رد شد: {perr}'}
    recs.append(r); log(('✅' if perr else '❌'), 'sec1-password-wrong |', r['extra'])
    ctx5.close()
    br.close()

save(recs, '1-ورود')
reds = [r for r in recs if str(r.get('extra', '')).endswith('False')]
print(f"\n── بخش ۱: {len(recs)} سنج | قرمز: {len(reds)}")
