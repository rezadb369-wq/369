# -*- coding: utf-8 -*-
"""بخش ۲ — خانه و ناوبری: بنرها، منوی پایین، جست‌وجو، شب/روز، عرض‌های 320/412."""
import sys, time, re
sys.path.insert(0, 'tools')
from cust_lib import *
from playwright.sync_api import sync_playwright

recs = []
log = print

with sync_playwright() as pw:
    br = pw.chromium.launch()
    cc = ctx(br); pg = cc.new_page()

    # ── 2.1 خانه ──
    r = audit(pg, 'sec2-home', '/')
    recs.append(r); log(fmt(r))
    body = pg.content()

    # ── 2.2 بنرها: همهٔ بنرهای خانه + کلیک اولی ──
    banners = pg.evaluate("""() => [...document.querySelectorAll('a')]
        .filter(a => (a.className+' '+(a.closest('section')?.className||'')).match(/banner|hero|slide/i))
        .filter(a => a.offsetWidth>0 && a.offsetHeight>0)
        .map(a => ({href: a.getAttribute('href'), txt: (a.innerText||'').trim().slice(0,30), w: a.offsetWidth}))""")
    log("بنرهای خانه:", banners)
    if banners:
        b0 = banners[0]
        href0 = b0['href'] or ''
        if href0.startswith('/'):
            pg.evaluate(f"location.href='{href0}'")
            pg.wait_for_url(f'**{href0}**' if len(href0) > 1 else '**/', timeout=15000)
            pg.wait_for_load_state('networkidle')
            dest_ok = pg.url.replace(BASE, '') == href0 or pg.url.replace(BASE, '').startswith(href0)
            pg.goto(BASE + '/')
            r = {'name': 'sec2-banner-click', 'url': href0, 'status': 200,
                 'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
                 'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
                 'extra': f'کلیک بنر → مقصد درست ({href0}): {dest_ok}'}
            recs.append(r); log(('✅' if dest_ok else '❌'), 'sec2-banner-click |', r['extra'])

    # ── 2.3 منوی پایین (mnav): ۵ مقصد ──
    nav = pg.evaluate("""() => [...document.querySelectorAll('.bottom-nav a')]
        .map(a => ({href: a.getAttribute('href'), txt: (a.innerText||a.getAttribute('aria-label')||'').trim().slice(0,14), h: a.offsetHeight}))""")
    log("منوی پایین:", nav)
    bad_nav = [n for n in nav if n['h'] < 44]
    all_ok = True
    for n in nav:
        href = n['href'] or ''
        if not href.startswith('/'):
            continue
        pg.goto(BASE + href)
        pg.wait_for_load_state('networkidle')
        st = pg.evaluate("document.body.innerText.length")
        if st < 100:
            all_ok = False
            log("  ❌ مقصد خالی:", href)
    r = {'name': 'sec2-mnav', 'url': '(۵ مقصد)', 'status': 200,
         'console_errors': [], 'overflow_px': 0, 'touch': {'block': len(bad_nav)},
         'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
         'extra': f'{len(nav)} مقصد، همگی با محتوا: {all_ok} | لمس‌کوچک: {len(bad_nav)}'}
    recs.append(r); log(('✅' if all_ok and not bad_nav else '❌'), 'sec2-mnav |', r['extra'])

    # ── 2.4 جست‌وجوی سراسری از خانه ──
    pg.goto(BASE + '/')
    sform = pg.locator('form[action="/businesses"]').count()
    if sform:
        pg.fill('form[action="/businesses"] input[name="q"]', 'آزمون')
        pg.click('form[action="/businesses"] button[type="submit"]', no_wait_after=True)
        pg.wait_for_load_state('networkidle')
        found = 'آزمون' in pg.content()
        snap(pg, 'sec2-search', pg.url.replace(BASE, ''))
        r = {'name': 'sec2-search', 'url': pg.url.replace(BASE, ''), 'status': 200,
             'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
             'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
             'extra': f'جست‌وجو نتیجه داد: {found}'}
        recs.append(r); log(('✅' if found else '❌'), 'sec2-search |', r['extra'])
    else:
        r = {'name': 'sec2-search', 'url': '/', 'status': 200, 'console_errors': [],
             'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
             'broken_images': [], 'ms': 0, 'extra': 'فرم جست‌وجو در خانه نیست (جست‌وجو از /businesses)'}
        recs.append(r); log('ℹ️ sec2-search |', r['extra'])

    # ── 2.5 شب/روز ──
    pg.goto(BASE + '/')
    theme_btn = pg.locator('button.theme-toggle').first
    has = theme_btn.count() > 0
    if has:
        html_before = pg.evaluate("document.documentElement.getAttribute('data-theme')")
        theme_btn.click()
        pg.wait_for_timeout(400)
        html_after = pg.evaluate("document.documentElement.getAttribute('data-theme')")
        pg.reload()
        pg.wait_for_load_state('networkidle')
        after_reload = pg.evaluate("document.documentElement.getAttribute('data-theme')")
        switched = html_after != html_before
        persisted = after_reload == html_after
        snap(pg, 'sec2-night', '/')
        r = {'name': 'sec2-theme', 'url': '/', 'status': 200, 'console_errors': [],
             'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
             'broken_images': [], 'ms': 0,
             'extra': f'تغییر تم: {switched} | ماندگاری پس از reload: {persisted}'}
        recs.append(r); log(('✅' if switched and persisted else '❌'), 'sec2-theme |', r['extra'])
        theme_btn.click(); pg.wait_for_timeout(300)   # برگردان به روز
    else:
        log("ℹ️ دکمهٔ تم با سلکتورهای رایج پیدا نشد — از کوکی بررسی می‌کنم")
        r = {'name': 'sec2-theme', 'url': '/', 'status': 200, 'console_errors': [],
             'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
             'broken_images': [], 'ms': 0, 'extra': 'کنترل تم یافت نشد'}
        recs.append(r)

    # ── 2.6 عرض‌های 320 و 412 روی خانه/دکان/کالا ──
    for w, tag in ((320, '320'), (412, '412')):
        pg.set_viewport_size({'width': w, 'height': 740})
        ovf = {}
        for p, nm in (('/', 'خانه'), ('/b/dkan-azmvn-malk-yk', 'دکان'), ('/item/336', 'کالا')):
            pg.goto(BASE + p)
            pg.wait_for_load_state('networkidle')
            ov = pg.evaluate("document.documentElement.scrollWidth-document.documentElement.clientWidth")
            ovf[nm] = ov
        r = {'name': f'sec2-width-{tag}', 'url': f'(عرض {w})', 'status': 200,
             'console_errors': [], 'overflow_px': max(ovf.values()),
             'touch': {'block': 0}, 'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
             'extra': f'سرریزها: {ovf}'}
        recs.append(r)
        log(('✅' if max(ovf.values()) <= 0 else '❌'), f'sec2-width-{tag} |', r['extra'])
    pg.set_viewport_size({'width': 360, 'height': 740})
    cc.close(); br.close()

save(recs, '2-خانه')
reds = [r for r in recs if str(r.get('extra', '')).find('False') >= 0 or r['overflow_px'] > 0]
print(f"\n── بخش ۲: {len(recs)} سنج | قرمز: {len(reds)}")
