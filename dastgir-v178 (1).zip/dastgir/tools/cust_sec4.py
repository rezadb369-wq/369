# -*- coding: utf-8 -*-
"""بخش ۴ — صفحهٔ دکان: تلفن=شمارهٔ ورود دکاندار، دنبال/علاقه، استوری، پرسش‌وپاسخ، نوبت، اشتراک."""
import sys, sqlite3
sys.path.insert(0, 'tools')
from cust_lib import *
from playwright.sync_api import sync_playwright

recs = []
log = print
SLUG = '/b/dkan-azmvn-malk-yk'
OWNER_PHONE = '09352223344'

with sync_playwright() as pw:
    br = pw.chromium.launch()

    # ── مهمان ──
    g = ctx(br); pg = g.new_page()
    r = audit(pg, 'sec4-shop', SLUG)
    recs.append(r); log(fmt(r))
    body = pg.inner_text('body')
    html = pg.content()

    tel = pg.evaluate("""()=>[...document.querySelectorAll('a[href^="tel:"]')].map(a=>a.getAttribute('href'))""")
    tel_ok = any(OWNER_PHONE in t for t in tel)
    r = {'name': 'sec4-tel', 'url': SLUG, 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0,
         'extra': f'لینک تلفن: {tel} | شمارهٔ دکاندار است: {tel_ok}'}
    recs.append(r); log(('✅' if tel_ok else '❌'), 'sec4-tel |', r['extra'])

    has_qa = 'پارکینگ دارید؟' in body and 'پارکینگ هست' in body
    r = {'name': 'sec4-qa', 'url': SLUG, 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0, 'extra': f'پرسش‌وپاسخ منتشرشده دیده می‌شود: {has_qa}'}
    recs.append(r); log(('✅' if has_qa else '❌'), 'sec4-qa |', r['extra'])

    has_hours = 'ساعت کاری' in body or 'ساعات' in body
    r = {'name': 'sec4-hours', 'url': SLUG, 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0, 'extra': f'ساعات کاری: {has_hours}'}
    recs.append(r); log(('✅' if has_hours else '❌'), 'sec4-hours |', r['extra'])

    # کالاها: تخفیف‌دار با قیمت خط‌خورده
    has_disc = 'کالای تخفیف‌دار' in body
    strike = pg.evaluate("""()=>{const el=[...document.querySelectorAll('*')].find(e=>/کالای تخفیف‌دار/.test(e.textContent||''));
       if(!el) return null; const card=el.closest('a,article,div[class*=card],li')||el;
       return {old: /old|strike|line-through/i.test(card.innerHTML) || card.innerHTML.includes('خط'), txt: card.innerText.replace(/\\n/g,' | ').slice(0,80)}}""")
    r = {'name': 'sec4-discount', 'url': SLUG, 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0,
         'extra': f'کالای تخفیف‌دار: {has_disc} | قیمت خط‌خورده: {strike}'}
    recs.append(r); log(('✅' if has_disc else '❌'), 'sec4-discount |', r['extra'])

    # نوبت‌دهی فعال دیده می‌شود؟
    has_book = ('نوبت' in body) and ('رزرو' in body or 'گرفتن نوبت' in body or 'book' in html)
    r = {'name': 'sec4-booking-ui', 'url': SLUG, 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0, 'extra': f'بخش نوبت‌دهی: {has_book}'}
    recs.append(r); log(('✅' if has_book else '❌'), 'sec4-booking-ui |', r['extra'])

    # دکمهٔ دنبال‌کردن برای مهمان → ورود
    pg.goto(BASE + SLUG); pg.wait_for_load_state('networkidle')
    fb = pg.locator('button:has-text("دنبال"), a:has-text("دنبال")').first
    if fb.count() > 0:
        fb.click(no_wait_after=True)
        try:
            pg.wait_for_url('**/login**', timeout=10000)
        except Exception:
            pass
        went_login = '/login' in pg.url or 'me/login' in pg.url
        r = {'name': 'sec4-follow-guest', 'url': pg.url.replace(BASE, ''), 'status': 200,
             'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
             'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
             'extra': f'مهمان → صفحهٔ ورود: {went_login}'}
        recs.append(r); log(('✅' if went_login else '❌'), 'sec4-follow-guest |', r['extra'])
    else:
        log("ℹ️ دکمهٔ دنبال‌کردن پیدا نشد")
        r = {'name': 'sec4-follow-guest', 'url': SLUG, 'status': 200, 'console_errors': [],
             'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
             'broken_images': [], 'ms': 0, 'extra': 'دکمهٔ دنبال یافت نشد'}
        recs.append(r)
    g.close()

    # ── مشتری واردشده ──
    import time as _t
    c = sqlite3.connect(DB)
    c.execute("delete from otp"); c.execute("delete from ratelimit"); c.commit()
    u = ctx(br); pg = u.new_page()
    pg.goto(BASE + '/login')
    pg.fill('form[action="/login"] input[name="phone"]', '09361112233')
    pg.click('form[action="/login"] button[type="submit"]', no_wait_after=True)
    pg.wait_for_selector('input[name="code"]')
    pg.fill('input[name="code"]', otp_code('09361112233'))
    try:
        pg.click('form[action="/login/verify"] button[type="submit"]', no_wait_after=True, timeout=6000)
    except Exception:
        pass
    pg.wait_for_url('**/my', timeout=20000)

    pg.goto(BASE + SLUG); pg.wait_for_load_state('networkidle')
    fb = pg.locator('button:has-text("دنبال"), a:has-text("دنبال")').first
    txt_before = fb.inner_text()
    fb.click(no_wait_after=True)
    pg.wait_for_load_state('networkidle'); pg.wait_for_timeout(600)
    txt_after = pg.locator('button:has-text("دنبال"), a:has-text("دنبال"), button:has-text("دنبال‌شده"), button:has-text("لغو دنبال")').first.inner_text()
    r = {'name': 'sec4-follow-cust', 'url': SLUG, 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0,
         'extra': f'دنبال‌کردن: «{txt_before.strip()[:12]}» → «{txt_after.strip()[:16]}»'}
    recs.append(r); log('✅/❌ sec4-follow-cust |', r['extra'])

    # علاقه‌مندی
    fav = pg.locator('button:has-text("علاقه"), [data-fav], button[class*=fav]').first
    if fav.count() > 0:
        fav.click(no_wait_after=True)
        pg.wait_for_load_state('networkidle'); pg.wait_for_timeout(600)
        on = pg.evaluate("""()=>{const e=[...document.querySelectorAll('[data-fav],button[class*=fav]')][0];
          return e? (e.className + '|' + e.innerText.slice(0,14)) : '-'}""")
        r = {'name': 'sec4-fav', 'url': SLUG, 'status': 200, 'console_errors': [],
             'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
             'broken_images': [], 'ms': 0, 'extra': f'علاقه‌مندی: {on}'}
        recs.append(r); log('✅/❌ sec4-fav |', r['extra'])
    else:
        log('ℹ️ دکمهٔ علاقه‌مندی با سلکتور رایج یافت نشد')

    # استوری دکان (حلقهٔ اینستاگرامی)
    ring = pg.evaluate("()=>!!document.querySelector('[data-stories-bar], .story-ring, [class*=story]')")
    r = {'name': 'sec4-story', 'url': SLUG, 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0, 'extra': f'عنصر استوری دکان: {ring}'}
    recs.append(r); log(('✅' if ring else '❌'), 'sec4-story |', r['extra'])
    u.close()
    br.close()

save(recs, '4-دکان')
reds = [r for r in recs if 'False' in str(r.get('extra', ''))]
print(f"\n── بخش ۴: {len(recs)} سنج | قرمز: {len(reds)}")
