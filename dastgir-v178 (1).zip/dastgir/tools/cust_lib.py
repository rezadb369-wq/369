# -*- coding: utf-8 -*-
"""کمک‌ساز بازبینی مشتری — playwright موبایل + ۴ سنج یکسان."""
import json, os, re, sqlite3, time
from playwright.sync_api import sync_playwright

BASE = 'http://127.0.0.1:8080'
ROOT = '/home/user/work/dastgir'
SHOTS = f'{ROOT}/shots-customer'
RES = f'{ROOT}/qa/customer-journey.json'
DB = f'{ROOT}/data/bazarche.db'
os.makedirs(SHOTS, exist_ok=True)

TOUCH_JS = """() => {
  let small=0, smallVis=0, samples=[];
  const els=document.querySelectorAll('a,button,input,select,textarea,[role="button"]');
  for (const el of els){
    const r=el.getBoundingClientRect();
    if(r.width<=0||r.height<=0) continue;
    if(r.height>=44&&r.width>=44) continue;
    const st=getComputedStyle(el);
    const inline = st.display==='inline' || st.display==='inline' && el.closest('p');
    small++;
    if(!(st.display.startsWith('inline'))) {
      smallVis++;
      if(samples.length<3) samples.push((el.textContent||el.name||el.tagName).trim().slice(0,24)+' h='+Math.round(r.height));
    }
  }
  return {total:small, block:smallVis, samples};
}"""

TEXT_JS = """() => {
  let small=0, samples=[];
  const walk=document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
  let el;
  while(el=walk.nextNode()){
    if(el.children.length) continue;
    const t=(el.textContent||'').trim();
    if(!t) continue;
    const st=getComputedStyle(el);
    if(st.display==='none'||st.visibility==='hidden') continue;
    const fs=parseFloat(st.fontSize);
    if(fs<12){ small++; if(samples.length<3) samples.push(t.slice(0,28)+'@'+fs+'px'); }
  }
  return {count:small, samples};
}"""


def otp_code(phone):
    r = sqlite3.connect(DB).execute(
        "select code from otp where phone=? order by rowid desc limit 1",
        (phone,)).fetchone()
    return r[0] if r else None


def clear_rl(con=None):
    c = sqlite3.connect(DB)
    c.execute("delete from ratelimit")
    c.commit()


def ctx(browser):
    return browser.new_context(
        viewport={'width': 360, 'height': 740}, device_scale_factor=2,
        is_mobile=True, has_touch=True, locale='fa-IR',
        user_agent='Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36')


def audit(pg, name, url, shot=True, settle=8000):
    """یک صفحه را با ۴ سنج می‌سنجد؛ rec برمی‌گرداند."""
    errs = []
    pg.on('console', lambda m: errs.append('console: ' + m.text[:150]) if m.type == 'error' else None)
    pg.on('pageerror', lambda e: errs.append('pageerror: ' + str(e)[:150]))
    t0 = time.time()
    resp = pg.goto(BASE + url, wait_until='load', timeout=30000)
    try:
        pg.wait_for_load_state('networkidle', timeout=settle)
    except Exception:
        pass
    ms = int((time.time() - t0) * 1000)
    overflow = pg.evaluate("document.documentElement.scrollWidth-document.documentElement.clientWidth")
    touch = pg.evaluate(TOUCH_JS)
    small = pg.evaluate(TEXT_JS)
    broken = pg.evaluate("""() => [...document.images]
        .filter(i => i.complete && i.naturalWidth===0 && !i.src.startsWith('data:'))
        .map(i => i.src.slice(-60))""")
    if shot:
        pg.screenshot(path=f'{SHOTS}/{name}.png', full_page=True)
    return {'name': name, 'url': url, 'status': resp.status if resp else None,
            'ms': ms, 'console_errors': errs, 'overflow_px': overflow,
            'touch': touch, 'small_text': small, 'broken_images': broken}


def snap(pg, name, url_label, ms=0):
    """سنجش صفحهٔ *فعلی* بدون ناوبری تازه."""
    overflow = pg.evaluate("document.documentElement.scrollWidth-document.documentElement.clientWidth")
    touch = pg.evaluate(TOUCH_JS)
    small = pg.evaluate(TEXT_JS)
    broken = pg.evaluate("""() => [...document.images]
        .filter(i => i.complete && i.naturalWidth===0 && !i.src.startsWith('data:'))
        .map(i => i.src.slice(-60))""")
    pg.screenshot(path=f'{SHOTS}/{name}.png')
    return {'name': name, 'url': url_label, 'status': 200, 'ms': ms,
            'console_errors': [], 'overflow_px': overflow,
            'touch': touch, 'small_text': small, 'broken_images': broken}


def save(recs, tag):
    """پیوست نتیجه‌ها به JSON مرکزی."""
    data = []
    if os.path.exists(RES):
        data = json.load(open(RES))
    for r in recs:
        r['section'] = tag
        data.append(r)
    json.dump(data, open(RES, 'w'), ensure_ascii=False, indent=1)


def fmt(rec):
    flag = '✅' if (rec['status'] in (200, 301, 302, 303) and not rec['console_errors']
                   and rec['overflow_px'] <= 0 and rec['broken_images'] == []) else '⚠️'
    return (f"{flag} {rec['name']} [{rec['status']}] {rec['ms']}ms "
            f"ovf={rec['overflow_px']} touch!={rec['touch']['block']} "
            f"font!={rec['small_text']['count']} img!={len(rec['broken_images'])} "
            f"js!={len(rec['console_errors'])}")
