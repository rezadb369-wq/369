#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
بکاپ‌گیر امن و سازگار برای «دست گیر»
===================================

یک اسنپ‌شات **سازگار (consistent)** از پایگاه داده می‌گیرد — بدون توقف سرور —
با استفاده از API رسمیِ پشتیبان‌گیری SQLite (متد backup). برخلاف «cp» روی فایل
.bdb که در حالت WAL ممکن است تراکنش‌های تازه را جا بیندازد، این روش همیشه یک
نسخهٔ سالم و کامل می‌دهد.

خروجی: یک فایل zip با ساختاری که دقیقاً آینهٔ پوشهٔ برنامه است، تا بازیابی
فقط با یک «unzip روی پوشهٔ برنامه» انجام شود:

    backup-YYYYMMDD-HHMMSS.zip
    ├── manifest.json            ← شناسنامه: تعداد جدول‌ها، حجم‌ها، sha256
    ├── data/bazarche.db         ← اسنپ‌شات سالم پایگاه داده
    ├── data/chat-files/…        ← تصاویر گفت‌وگوها
    └── site/assets/img/uploads/… ← عکس‌ها و ویدیوهای کسب‌وکارها

کاربردها:
  - بکاپ شبانه (cron / systemd timer)
  - اسنپ‌شات پیش از آپدیت (در tools/deploy.sh)
  - تأیید سلامت یک بکاپ:  python3 tools/backup.py --verify backup.zip

خروجی‌ها (کد خروج):
  0 = موفق   2 = دیتابیس پیدا نشد   3 = بکاپ ناسالم (integrity_check رد شد)
  4 = خطای ساخت zip   5 = خطای چرخش/حذف قدیمی‌ها
"""

import argparse
import datetime
import hashlib
import json
import os
import re
import shutil
import sqlite3
import sys
import tempfile
import zipfile

import cloudsend   # ارسال به تلگرام / S3 (فقط کتابخانهٔ استاندارد)

APP_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATA_DIR = os.environ.get("BZ_DATA_DIR") or os.path.join(APP_ROOT, "data")
DB_PATH = os.path.join(DATA_DIR, "bazarche.db")
UPLOAD_DIR = os.path.join(APP_ROOT, "site", "assets", "img", "uploads")
CHAT_DIR = os.path.join(DATA_DIR, "chat-files")

STAMP_RE = re.compile(r"^backup-(\d{8})-(\d{6})\.zip$")


# ----------------------------------------------------------------------------
def log(msg, quiet=False):
    if not quiet:
        print(msg)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def table_counts(db_path):
    """-> {table_name: row_count} از روی خودِ کپیِ بکاپ (نه دیتابیس زنده)."""
    con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=15)
    try:
        names = [r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        out = {}
        for t in names:
            try:
                out[t] = con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
            except sqlite3.Error:
                out[t] = -1
        return out
    finally:
        con.close()


def verify_db(path):
    """-> (ok: bool, detail: str). integrity_check باید دقیقاً «ok» برگرداند."""
    if not os.path.isfile(path):
        return False, "file missing"
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=15)
        try:
            full = con.execute("PRAGMA integrity_check").fetchone()[0]
            quick = con.execute("PRAGMA quick_check").fetchone()[0]
        finally:
            con.close()
    except sqlite3.Error as e:
        return False, f"open/check failed: {e}"
    if str(full) != "ok" or str(quick) != "ok":
        return False, f"integrity={full!r} quick={quick!r}"
    return True, "ok"


def make_snapshot(dest_root, want_json=False):
    """گرفتن اسنپ‌شات سازگار در dest_root (مسیر موقت)."""
    os.makedirs(dest_root, exist_ok=True)

    # 1) اسنپ‌شات امن از پایگاه داده (بدون توقف سرور)
    src = sqlite3.connect(DB_PATH, timeout=15)
    dst_path = os.path.join(dest_root, "data", "bazarche.db")
    os.makedirs(os.path.dirname(dst_path), exist_ok=True)
    try:
        dst = sqlite3.connect(dst_path)
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()

    ok, detail = verify_db(dst_path)
    if not ok:
        raise RuntimeError(f"backup is corrupt ({detail}) — nothing was kept")

    # 2) تصاویر گفت‌وگو و عکس‌های کسب‌وکار
    uploads_files = []
    chat_files = []
    if os.path.isdir(UPLOAD_DIR):
        d = os.path.join(dest_root, "site", "assets", "img", "uploads")
        os.makedirs(d, exist_ok=True)
        for name in sorted(os.listdir(UPLOAD_DIR)):
            full = os.path.join(UPLOAD_DIR, name)
            if os.path.isfile(full) and name != ".gitkeep":
                shutil.copy2(full, os.path.join(d, name))
                uploads_files.append({"name": name, "bytes": os.path.getsize(full)})
    if os.path.isdir(CHAT_DIR):
        d = os.path.join(dest_root, "data", "chat-files")
        os.makedirs(d, exist_ok=True)
        for name in sorted(os.listdir(CHAT_DIR)):
            full = os.path.join(CHAT_DIR, name)
            if os.path.isfile(full):
                shutil.copy2(full, os.path.join(d, name))
                chat_files.append({"name": name, "bytes": os.path.getsize(full)})

    # 3) شناسنامه
    db_bytes = os.path.getsize(dst_path)
    manifest = {
        "app": "dastgir",
        "created": datetime.datetime.now().isoformat(timespec="seconds"),
        "backup_version": 1,
        "db": {
            "bytes": db_bytes,
            "sha256": sha256_file(dst_path),
            "tables": table_counts(dst_path),
        },
        "uploads": {"files": len(uploads_files),
                    "bytes": sum(x["bytes"] for x in uploads_files),
                    "list": uploads_files},
        "chat_files": {"files": len(chat_files),
                       "bytes": sum(x["bytes"] for x in chat_files),
                       "list": chat_files},
        "source": {"data_dir": DATA_DIR, "db_path": DB_PATH},
    }
    if want_json:
        manifest["json_export"] = os.path.basename(make_json_export(dest_root))

    with open(os.path.join(dest_root, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=1)
    return manifest


def _jsonable(v):
    """bytes (BLOB) → متن base64 تا JSON بتواند همهٔ جدول‌ها را نگه دارد."""
    if isinstance(v, bytes):
        import base64
        return {"__b64": base64.b64encode(v).decode("ascii")}
    return v


def make_json_export(dest_root):
    """خروجی JSON همهٔ جدول‌ها (برای جابه‌جایی بین نسخه‌ها)."""
    con = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True, timeout=15)
    con.row_factory = sqlite3.Row
    try:
        names = [r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        out = {"_meta": {"exported": datetime.datetime.now().isoformat(),
                         "kind": "full-tables"}}
        for t in names:
            try:
                out[t] = [{k: _jsonable(v) for k, v in dict(r).items()}
                          for r in con.execute(f'SELECT * FROM "{t}"')]
            except sqlite3.Error:
                out[t] = []
    finally:
        con.close()
    p = os.path.join(dest_root, "backup.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    return p


def zip_snapshot(src_root, out_zip):
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for dirpath, _dirs, files in os.walk(src_root):
            for f in files:
                full = os.path.join(dirpath, f)
                rel = os.path.relpath(full, src_root)
                z.write(full, rel)
    return out_zip


def rotate(backup_dir, keep_daily, keep_weekly, keep_monthly):
    """گردش نسخه‌ها: روزانهٔ تازه + هفتگی + ماهانه. مازاد حذف می‌شود."""
    items = []
    for name in os.listdir(backup_dir):
        m = STAMP_RE.match(name)
        if not m:
            continue
        try:
            dt = datetime.datetime.strptime(m.group(1) + m.group(2),
                                            "%Y%m%d%H%M%S")
        except ValueError:
            continue
        items.append((dt, os.path.join(backup_dir, name)))
    items.sort(key=lambda x: x[0], reverse=True)   # جدید → قدیم

    keep = set()
    weekly_seen, monthly_seen = set(), set()
    for i, (dt, path) in enumerate(items):
        if i < keep_daily:                         # روزانهٔ تازه
            keep.add(path)
            continue
        wk = (dt.isocalendar().year, dt.isocalendar().week)
        if wk not in weekly_seen and len(weekly_seen) < keep_weekly:
            weekly_seen.add(wk)
            keep.add(path)
            continue
        mo = (dt.year, dt.month)
        if mo not in monthly_seen and len(monthly_seen) < keep_monthly:
            monthly_seen.add(mo)
            keep.add(path)
            continue
        # بقیه حذف
        try:
            os.unlink(path)
        except OSError:
            pass
    return len(items) - len(keep)


def run_backup(args):
    if not os.path.isfile(DB_PATH):
        print(f"✗ دیتابیس پیدا نشد: {DB_PATH}", file=sys.stderr)
        return 2

    os.makedirs(args.dir, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    out_zip = os.path.join(args.dir, f"backup-{stamp}.zip")

    tmp = tempfile.mkdtemp(prefix="bkp-", dir=args.dir)
    try:
        man = make_snapshot(tmp, want_json=args.json)
        zip_snapshot(tmp, out_zip)
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        if os.path.exists(out_zip):
            os.unlink(out_zip)
        print(f"✗ بکاپ ناموفق: {e}", file=sys.stderr)
        return 4
    shutil.rmtree(tmp, ignore_errors=True)

    deleted = 0
    if not args.no_rotate:
        try:
            deleted = rotate(args.dir, args.keep_daily,
                             args.keep_weekly, args.keep_monthly)
        except Exception as e:
            print(f"⚠ خطای چرخش نسخه‌ها: {e}", file=sys.stderr)

    # از این‌جا به بعد فایل بکاپ روی دیسک است؛ اجازهٔ خواندن را تنگ می‌کنیم
    # (داخلش دادهٔ شخصی کاربران است).
    try:
        os.chmod(out_zip, 0o600)
    except OSError:
        pass

    # ---------- آپلود به فضای ابری (بهترین تلاش؛ شکست، بکاپ محلی را لغو نمی‌کند)
    cloud_report = ""
    if getattr(args, "telegram", False):
        token, chat = cloudsend.read_telegram_settings(DB_PATH)
        caption = (f"🗂 بکاپ {os.path.basename(out_zip)}\n"
                   f"دیتابیس {man['db']['bytes']} بایت · "
                   f"{len(man['db']['tables'])} جدول · "
                   f"عکس‌ها {man['uploads']['files']} · چت {man['chat_files']['files']}")
        ok, detail = cloudsend.telegram_send_file(token, chat, out_zip,
                                                  caption=caption)
        cloud_report += f" telegram={'ok' if ok else 'FAIL'} "
        log(f"  تلگرام: {'✓ ارسال شد' if ok else '✗ ' + detail}", args.quiet)
    if getattr(args, "s3", False):
        cfg = cloudsend._s3_env()
        if not cfg:
            log("  S3: پیکربندی نشده (BZ_S3_ENDPOINT/BUCKET/ACCESS/SECRET) "
                "— رد شد", args.quiet)
            cloud_report += " s3=skipped"
        else:
            endpoint, region, bucket, access, secret = cfg
            prefix = os.environ.get("BZ_S3_PREFIX", "").strip().strip("/")
            key = (prefix + "/" if prefix else "") + os.path.basename(out_zip)
            ok, detail = cloudsend.s3_put(endpoint, region, bucket, key,
                                          out_zip, access, secret)
            cloud_report += f" s3={'ok' if ok else 'FAIL'} "
            log(f"  S3: {'✓ آپلود شد' if ok else '✗ ' + detail}", args.quiet)

    with open(os.path.join(args.dir, "backup.log"), "a", encoding="utf-8") as f:
        f.write(f"{stamp} ok {os.path.basename(out_zip)} "
                f"db={man['db']['bytes']}B tables={len(man['db']['tables'])} "
                f"uploads={man['uploads']['files']} chat={man['chat_files']['files']} "
                f"deleted={deleted}{cloud_report}\n")

    log(f"✓ بکاپ ساخته شد: {out_zip}", args.quiet)
    log(f"  دیتابیس: {man['db']['bytes']} بایت، {len(man['db']['tables'])} جدول، "
        f"sha256={man['db']['sha256'][:16]}…", args.quiet)
    log(f"  عکس‌ها: {man['uploads']['files']} فایل · چت: "
        f"{man['chat_files']['files']} فایل · حذف قدیمی: {deleted}", args.quiet)
    return 0


def run_verify(args):
    zpath = args.verify
    if not os.path.isfile(zpath):
        print(f"✗ فایل نیست: {zpath}", file=sys.stderr)
        return 1
    tmp = tempfile.mkdtemp(prefix="bkv-")
    try:
        with zipfile.ZipFile(zpath) as z:
            z.extractall(tmp)
        mpath = os.path.join(tmp, "manifest.json")
        if not os.path.isfile(mpath):
            print("✗ فایل zip، بکاپِ دست گیر نیست (manifest.json ندارد).",
                  file=sys.stderr)
            return 1
        with open(mpath, encoding="utf-8") as f:
            man = json.load(f)
        dbp = os.path.join(tmp, "data", "bazarche.db")
        ok, detail = verify_db(dbp)
        sha = sha256_file(dbp) if os.path.isfile(dbp) else ""
        match = sha == man["db"]["sha256"]
        print(f"  دیتابیس: integrity={detail}")
        print(f"  sha256: {'✓ مطابق شناسنامه' if match else '✗ ناهماهنگ!'}")
        print(f"  جدول‌ها: {len(man['db']['tables'])} · عکس‌ها: "
              f"{man['uploads']['files']} · چت: {man['chat_files']['files']}")
        print(f"  زمان بکاپ: {man['created']}")
        if ok and match:
            print("✓ بکاپ سالم است و قابل بازیابی.")
            return 0
        print("✗ بکاپ مشکل دارد و نباید به آن اعتماد کرد.", file=sys.stderr)
        return 3
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    ap = argparse.ArgumentParser(description="بکاپ امن دست گیر (بدون توقف سرور)")
    ap.add_argument("--dir", default="/var/backups/bazarche",
                    help="پوشهٔ مقصد بکاپ‌ها")
    ap.add_argument("--json", action="store_true",
                    help="خروجی JSON هم کنار دیتابیس بگذارد")
    ap.add_argument("--no-rotate", action="store_true",
                    help="نسخه‌های قدیمی حذف نشوند")
    ap.add_argument("--keep-daily", type=int, default=14)
    ap.add_argument("--keep-weekly", type=int, default=8)
    ap.add_argument("--keep-monthly", type=int, default=12)
    ap.add_argument("--verify", metavar="ZIP",
                    help="بررسی سلامت یک فایل بکاپ")
    ap.add_argument("--telegram", action="store_true",
                    help="بعد از ساخت بکاپ، فایل را به تلگرام بفرستد")
    ap.add_argument("--s3", action="store_true",
                    help="بعد از ساخت بکاپ، فایل را به S3-سازگار بفرستد")
    ap.add_argument("--telegram-test", action="store_true",
                    help="فقط توکن تلگرام را بیازماید (getMe)")
    ap.add_argument("--s3-test", action="store_true",
                    help="فقط تنظیمات S3 را بیازماید (نوشتن و پاک کردن شیء تست)")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    if args.telegram_test:
        token, chat = cloudsend.read_telegram_settings(DB_PATH)
        ok, detail = cloudsend.telegram_get_me(token)
        print("تلگرام: " + ("✓ " if ok else "✗ ") + detail)
        return 0 if ok else 3
    if args.s3_test:
        cfg = cloudsend._s3_env()
        if not cfg:
            print("✗ تنظیمات S3 کامل نیست — این متغیرها را بگذارید: "
                  "BZ_S3_ENDPOINT, BZ_S3_BUCKET, BZ_S3_ACCESS, BZ_S3_SECRET "
                  "(اختیاری: BZ_S3_REGION)", file=sys.stderr)
            return 3
        ok, detail = cloudsend.s3_test(*cfg)
        print("S3: " + ("✓ " if ok else "✗ ") + detail)
        return 0 if ok else 3

    if args.verify:
        return run_verify(args)
    return run_backup(args)


if __name__ == "__main__":
    sys.exit(main())
