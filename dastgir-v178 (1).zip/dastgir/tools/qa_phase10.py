#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۱۰ — درآمد: پلن‌ها و تعرفه · کلید قابلیت‌ها · اشتراک‌ها · تبلیغات.
تغییر قیمت و اثر بر مشترکین فعال، سهمیه‌ها، منقضی‌شدن، slot/weight بنر.
هر تست اثر واقعی را در پایگاه/صفحه بررسی می‌کند و تمیزکاری برمی‌گرداند."""
import re, sys, json, sqlite3, time, datetime, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []
A_BIZ = 214
SHOP_PHONE = "09352223344"
ADMIN_PHONE = "09131110011"

def q(sql, args=()):
    c = sqlite3.connect(DB); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None):
    h = {}
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data, doseq=True).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(BASE + path, data=body, headers=h)
    try:
        r = op.open(req, timeout=25)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def clear_rl():
    q("delete from ratelimit")

def login(phone, admin=False):
    clear_rl()
    op = sess()
    go(op, "/login")
    go(op, "/login", {"phone": phone})
    go(op, "/login/verify", {"phone": phone, "code": otp_code(phone)})
    if admin:
        go(op, "/panel?key=" + DBM.owner_token())
    return op

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

created = {"plans": [], "subs": [], "ads": [], "uploads": [], "settings": {}}

# ─────────────────── T1 پلن‌ها ───────────────────
def t1():
    print("── T1 پلن‌ها و تعرفه")
    op = login(ADMIN_PHONE, admin=True)
    st, b, _ = go(op, "/panel/plans")
    check("T1.1", "صفحهٔ پلن‌ها 200", st == 200)
    # ساخت + بی‌نام
    st, b, url = go(op, "/panel/plan/new", {"name": "", "price": "100000", "months": "12"})
    check("T1.2", "پلن بی‌نام رد", "الزامی" in urllib.parse.unquote(url), url)
    st, b, url = go(op, "/panel/plan/new", {"name": "پلن آزمون۱۰", "tagline": "آزمون فاز ۱۰",
                    "price": "120000", "months": "12", "featured_slots": "1",
                    "max_items": "30", "max_photos": "10", "perks": "هرچه", "badge_slug": "", "active": "1"})
    row = q("select id,slug,months,price from plans where name='پلن آزمون۱۰'")
    ok = len(row) == 1 and row[0][2] == 12
    pid = row[0][0] if row else 0
    created["plans"].append(pid)
    check("T1.3", "ساخت پلن ۱۲ماهه", "ساخته" in urllib.parse.unquote(url) and ok, str(row))
    # ویرایش قیمت — مشترک فعال نباید عوض شود (سهمیه از پلن در لحظهٔ فعال‌سازی می‌آید)
    st, b, url = go(op, f"/panel/plan/{pid}", {"name": "پلن آزمون۱۰", "tagline": "بروز",
                    "price": "240000", "months": "12", "featured_slots": "2",
                    "max_items": "60", "max_photos": "12", "perks": "هرچه", "badge_slug": "", "action": "save", "active": "1"})
    cur = q("select price,featured_slots,max_items from plans where id=?", (pid,))[0]
    check("T1.4", "ویرایش پلن (قیمت/سهمیه)", tuple(cur) == (240000, 2, 60), str(cur))
    # وحشی (رفع v172)
    st, b, url = go(op, "/panel/plan/999999", {"name": "هک", "action": "save"})
    st2, b2, url2 = go(op, "/panel/plan/999999", {"action": "delete"})
    check("T1.5", "وحشی پلن → «نیست» ×2", "نیست" in urllib.parse.unquote(url)
          and "نیست" in urllib.parse.unquote(url2), f"{url} {url2}")
    # حذف پلن بدون مشترک
    q("insert into plans(slug,name,months,price,active) values('azmun-bedun','پلن بی‌مشترک',12,1000,1)")
    pid2 = q("select id from plans where slug='azmun-bedun'")[0][0]
    created["plans"].append(pid2)
    st, b, url = go(op, f"/panel/plan/{pid2}", {"action": "delete"})
    check("T1.6", "حذف پلن بی‌مشترک", "حذف شد" in urllib.parse.unquote(url)
          and not q("select * from plans where id=?", (pid2,)))
    created["plans"].remove(pid2)

# ─────────────────── T2 اشتراک‌ها ───────────────────
def t2():
    print("── T2 اشتراک‌ها (چرخهٔ کامل، months، وحشی)")
    plan_slug = q("select slug from plans where name='پلن آزمون۱۰'")[0][0]
    op = login(ADMIN_PHONE, admin=True)
    # 2.1 ثبت دستی پلن پولی → pending + months پلن
    st, b, url = go(op, "/panel/subscription/new", {"biz_id": str(A_BIZ),
                    "plan_slug": plan_slug, "ref": "REF-TEST-1"})
    row = q("select id,status,months,amount from subscriptions where biz_id=214 order by id desc limit 1")
    ok = len(row) == 1 and row[0][1] == "pending" and row[0][2] == 12 and row[0][3] == 240000
    sid = row[0][0] if row else 0
    created["subs"].append(sid)
    check("T2.1", "ثبت دستی پولی → pending + مبلغ تناسبی", ok, str(row))
    # 2.2 months override 3 → مبلغ یک‌چهارم (رفع ابهام قرارداد: فقط 1/3/6/12)
    st, b, url = go(op, "/panel/subscription/new", {"biz_id": str(A_BIZ),
                    "plan_slug": plan_slug, "ref": "REF-3M", "months": "3"})
    row = q("select id,status,months,amount from subscriptions where ref='REF-3M'")
    ok = len(row) == 1 and row[0][2] == 3 and row[0][3] == 60000
    sid3 = row[0][0] if row else 0
    created["subs"].append(sid3)
    check("T2.2", "months=3 → مبلغ تناسبی ۶۰هزار", ok, str(row))
    # months بیرون whitelist → months پلن
    st, b, url = go(op, "/panel/subscription/new", {"biz_id": str(A_BIZ),
                    "plan_slug": plan_slug, "ref": "REF-7M", "months": "7"})
    row = q("select months from subscriptions where ref='REF-7M'")
    ok = len(row) == 1 and row[0][0] == 12
    created["subs"].append(q("select id from subscriptions where ref='REF-7M'")[0][0])
    check("T2.3", "months=7 (بیرون 1/3/6/12) → months پلن", ok, str(row))
    # 2.4 biz وحشی → «الزامی» نه 500 (رفع v172)
    st, b, url = go(op, "/panel/subscription/new", {"biz_id": "999999", "plan_slug": plan_slug})
    check("T2.4", "biz وحشی → پیام تمیز", "الزامی" in urllib.parse.unquote(url)
          and not q("select * from subscriptions where biz_id=999999"), url)
    # پلن ناموجود → err نه ok جعل (رفع v172)
    st, b, url = go(op, "/panel/subscription/new", {"biz_id": str(A_BIZ), "plan_slug": "nabud"})
    check("T2.5", "پلن ناموجود → err «یافت نشد»", "یافت نشد" in urllib.parse.unquote(url), url)
    # 2.6 فعال‌سازی + استک روی باقیمانده
    st, b, url = go(op, f"/panel/subscription/{sid}", {"action": "activate", "months": "6"})
    row = q("select status,months,expires,starts from subscriptions where id=?", (sid,))[0]
    exp = datetime.date.fromisoformat(row[2])
    days = (exp - datetime.date.fromisoformat(row[3])).days
    check("T2.6", "فعال‌سازی ۶ماهه (۱۸۰روز)", row[0] == "active" and row[1] == 6 and days == 180, f"{row} days={days}")
    st, b, url = go(op, f"/panel/subscription/{sid3}", {"action": "activate", "months": "3"})
    row = q("select status,expires from subscriptions where id=?", (sid3,))[0]
    check("T2.7", "فعال‌سازی دوم روی باقیمانده استک می‌شود",
          row[0] == "active" and row[1] > datetime.date.today().isoformat()[:10], str(row))
    # 2.8 وحشی (رفع v172) ×4
    outs = []
    for act in ("activate", "cancel", "reject", "delete"):
        st, b, url = go(op, f"/panel/subscription/999999", {"action": act, "months": "1"})
        outs.append(urllib.parse.unquote(url))
    check("T2.8", "وحشی اشتراک ×4 → «نیست»", all("نیست" in u for u in outs), str(outs))
    # 2.9 لغو واقعی → دسترسی‌ها برگردد (revoke) — با items سقف بسنجیم؟ سبک: وضعیت
    st, b, url = go(op, f"/panel/subscription/{sid}", {"action": "cancel"})
    check("T2.9", "لغو اشتراک", "لغو" in urllib.parse.unquote(url)
          and q("select status from subscriptions where id=?", (sid,))[0][0] == "cancelled")
    # 2.10 منقضی‌شده is_live نمی‌شود
    q("update subscriptions set status='active', expires='2020-01-01' where id=?", (sid,))
    live = [s["id"] for s in DBM.subscriptions() if s.get("is_live")]
    check("T2.10", "منقضی در فهرست زنده نیست", sid not in live)
    # 2.11 دکاندار 403
    sop = login(SHOP_PHONE)
    g1 = go(sop, "/panel/subscriptions")[0]
    g2 = go(sop, "/panel/subscription/new", {"biz_id": str(A_BIZ), "plan_slug": plan_slug})[0]
    g3 = go(sop, f"/panel/subscription/{sid3}", {"action": "cancel"})[0]
    check("T2.11", "دکاندار 403×3", (g1, g2, g3) == (403, 403, 403), str((g1, g2, g3)))

# ─────────────────── T3 کلید قابلیت‌ها ───────────────────
def t3():
    print("── T3 کلید قابلیت‌ها (۲۵ کلید — حادثهٔ POST جزئی)")
    op = login(ADMIN_PHONE, admin=True)
    st, b, _ = go(op, "/panel/features")
    check("T3.1", "صفحهٔ قابلیت‌ها 200", st == 200)
    keys = [k for _t, items in __import__("views_panel2", fromlist=["SITE_FEATURES"]).SITE_FEATURES for k, *_ in items]
    before = dict(q("select key,value from settings where key in (%s)" % ",".join("?" * len(keys)), keys))
    check("T3.2", "کلیدها در پایگاه همگی حاضر", len(before) == len(keys) and len(keys) >= 20,
          f"n={len(before)}/{len(keys)}")
    # POST جزئی (فقط یک کلید) → بقیه باید خاموش شوند (طراحی: کل‌وضعیت از فرم می‌آید)
    st, b, url = go(op, "/panel/features", [("qa_enabled", "1")])
    after = dict(q("select key,value from settings where key in (%s)" % ",".join("?" * len(keys)), keys))
    n_on = sum(1 for k in keys if after.get(k) == "1")
    check("T3.3", "POST جزئی → فقط همان روشن، بقیه خاموش (طراحی مستند)",
          n_on == 1 and after.get("qa_enabled") == "1", f"n_on={n_on}")
    # پیامد خاموشی: همه خاموش (POST خالی) → ثبت پرسش بی‌اثر
    st, b, url = go(op, "/panel/features", [])
    st, b, url = go(sess(), "/b/dkan-azmvn-malk-yk/ask-question",
                    {"asker": "آزمون خاموشی", "body": "پرسشی در حالت خاموشی قابلیت برای آزمون."})
    n = q("select count(*) from questions where asker='آزمون خاموشی'")[0][0]
    check("T3.4", "qa_enabled=0 → ثبت پرسش بی‌اثر", n == 0, f"n={n}")
    # بازگردانی همه به قبل (حادثهٔ features: هرگز جزئی نفرستادیم — کل ۲۵)
    st, b, url = go(op, "/panel/features", [(k, before[k]) for k in keys if before[k] == "1"])
    after2 = dict(q("select key,value from settings where key in (%s)" % ",".join("?" * len(keys)), keys))
    check("T3.5", "بازگردانی کامل → همه به حالت قبل", after2 == before,
          str([k for k in keys if after2.get(k) != before.get(k)]))
    # وحشی flag اضافه در POST کامل → نادیده (keys whitelist)
    st, b, url = go(op, "/panel/features", [(k, before[k]) for k in keys if before[k] == "1"]
                    + [("hax_flag", "1")])
    check("T3.6", "کلید ناشناس در پایگاه ثبت نمی‌شود",
          q("select count(*) from settings where key='hax_flag'")[0][0] == 0)

def mp(body_fields, file_field=None, fname="x.png", blob=b""):
    """multipart بدنهٔ ساده برای POST مسیرهای multipart."""
    bnd = "----qa10boundary"
    out = b""
    for k, v in body_fields:
        out += f"--{bnd}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode()
    if file_field:
        out += (f"--{bnd}\r\nContent-Disposition: form-data; name=\"{file_field}\"; "
                f"filename=\"{fname}\"\r\nContent-Type: image/png\r\n\r\n").encode() + blob + b"\r\n"
    out += f"--{bnd}--\r\n".encode()
    return out, f"multipart/form-data; boundary={bnd}"

def mp_post(op, path, fields, file_field=None, blob=b""):
    body, ctype = mp(fields, file_field, blob=blob)
    req = urllib.request.Request(BASE + path, data=body, headers={"Content-Type": ctype})
    try:
        r = op.open(req, timeout=25)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

# ─────────────────── T4 تبلیغات ───────────────────
def t4():
    print("── T4 تبلیغات (slot/weight، آمار، وحشی)")
    op = login(ADMIN_PHONE, admin=True)
    st, b, _ = go(op, "/panel/ads")
    check("T4.1", "صفحهٔ بنرها 200", st == 200)
    # ساخت multipart: بی‌عنوان → err روی آدرس سالم (#28)؛ سپس معتبر
    st, b, url = mp_post(op, "/panel/ad/new", [("title", ""), ("body", ""), ("slot", "home")])
    check("T4.2", "بی‌عنوان → err روی آدرس سالم (#28)",
          "/panel/ads?err=" in url and "الزامی" in urllib.parse.unquote(url), url)
    png = bytes.fromhex("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000a49444154789c6360000002000154a24f5f0000000049454e44ae426082")
    st, b, url = mp_post(op, "/panel/ad/new", [("title", "بنر آزمون۱۰"), ("body", "متن بنر"),
                    ("url", "/businesses"), ("slot", "home"), ("biz_id", ""),
                    ("starts", ""), ("ends", ""), ("weight", "3"), ("active", "1")],
                    file_field="image", blob=png)
    check("T4.2b", "ساخت بنر با تصویر → آدرس سالم",
          "/panel/ads?ok=" in url and "ساخته شد" in urllib.parse.unquote(url)
          and q("select count(*) from ads where title='بنر آزمون۱۰'")[0][0] == 1, url)
    aid = q("select id from ads where title='بنر آزمون۱۰'")[0][0]
    created["ads"].append(aid)
    created["uploads"] += [r[0] for r in q("select image from ads where id=?", (aid,)) if r[0]]
    # وزن در انتخاب بنر: بنر دوم وزن۱ — سه‌برابر بودن شانس (آماری ساده: ≥55 از 100)
    DBM.save_ad({"title": "بنر سبک آزمون", "body": "", "url": "/", "slot": "home",
                 "biz_id": "", "starts": "", "ends": "", "weight": 1, "image": "", "active": 1})
    aid2 = q("select id from ads where title='بنر سبک آزمون'")[0][0]
    created["ads"].append(aid2)
    picks = [DBM.pick_ad("home") for _ in range(100)] if hasattr(DBM, "pick_ad") else []
    if picks:
        heavy = sum(1 for a in picks if a and a["id"] == aid)
        light = sum(1 for a in picks if a and a["id"] == aid2)
        # v175: صحنه ممکن است بنرهای دیگرِ خانه (مثل بنر بذر) داشته باشد —
        # سهم مطلق صحنه‌محور است؛ نسبتِ وزن‌ها صحنه‌مستقل: ۳ به 1 → >2.2 محضوم
        check("T4.3", "weight=3 شانس بیشتری دارد (نسبت ≥2.2 به 1)",
              light > 0 and heavy * 10 > light * 22,
              f"heavy={heavy}/100 light={light}/100")
    else:
        check("T4.3", "pick_ad نیست — وزن فقط ذخیره", q("select weight from ads where id=?", (aid,))[0][0] == 3)
    # آمار: reset
    q("update ads set views=5, clicks=2 where id=?", (aid,))
    st, b, url = go(op, f"/panel/ad/{aid}", {"action": "reset"})
    cur = q("select views,clicks from ads where id=?", (aid,))[0]
    check("T4.4", "صفرکردن آمار", "صفر شد" in urllib.parse.unquote(url) and tuple(cur) == (0, 0), str(cur))
    # toggle
    st, b, url = go(op, f"/panel/ad/{aid}", {"action": "toggle"})
    check("T4.5", "خاموش/روشن بنر", "تغییر کرد" in urllib.parse.unquote(url))
    # وحشی ×3 (رفع v172)
    outs = []
    for act in ("delete", "reset", "toggle"):
        st, b, url = go(op, f"/panel/ad/999999", {"action": act})
        outs.append(urllib.parse.unquote(url))
    check("T4.6", "وحشی بنر ×3 → «نیست»", all("نیست" in u for u in outs), str(outs))
    # حذف واقعی
    st, b, url = go(op, f"/panel/ad/{aid2}", {"action": "delete"})
    check("T4.7", "حذف بنر", "حذف شد" in urllib.parse.unquote(url)
          and not q("select * from ads where id=?", (aid2,)))
    created["ads"].remove(aid2)
    # دکاندار 403
    sop = login(SHOP_PHONE)
    g1 = go(sop, "/panel/ads")[0]
    g2 = go(sop, f"/panel/ad/{aid}", {"action": "delete"})[0]
    check("T4.8", "دکاندار 403×2", (g1, g2) == (403, 403), str((g1, g2)))

def main():
    try:
        t1()
        t2()
        t3()
        t4()
    finally:
        for sid in created["subs"]:
            q("delete from subscriptions where id=?", (sid,))
        for pid in created["plans"]:
            q("delete from plans where id=?", (pid,))
        for aid in created["ads"]:
            q("delete from ads where id=?", (aid,))
        for img in created["uploads"]:
            try:
                import os
                fp = "site/" + img
                if os.path.exists(fp):
                    os.remove(fp)
            except Exception:
                pass
        # احتیاط دوم — الگوهای دقیق
        q("delete from subscriptions where biz_id=214 and plan_slug like 'azmun%'")
        q("delete from plans where slug like 'azmun%' or name like '%آزمون%'")
        q("delete from ads where title like '%آزمون%'")
        q("delete from questions where asker='آزمون خاموشی'")
        q("delete from settings where key='hax_flag'")
        q("delete from ratelimit"); q("delete from otp")
        q("delete from owner_notifications")
    json.dump(RESULTS, open("qa/phase10-results.json", "w"), ensure_ascii=False, indent=1)
    fails = [r for r in RESULTS if not r["ok"]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(fails)} | قرمز: {len(fails)}")
    for r in fails:
        print("  ❌", r["id"], r["name"], "—", r["detail"])
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
