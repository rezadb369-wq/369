# -*- coding: utf-8 -*-
"""QA شمارش واقعی بازدید (v177) — هر بازدیدکننده یک‌بار، نه هر رفرش.
V1 استوری: تکرار همان بیننده no-op · V2 بینندهٔ تازه شمرده می‌شود
V3 صفحهٔ دکان: همان bz_cid در روز فقط یک‌بار · V4 بازدیدکنندهٔ دوم شمرده می‌شود
V5 روز بعد همان بیننده دوباره شمرده می‌شود (کلید روز) · V6 کالا یکتا
V7 مهاجرت بایگانی (legacy_views / views_reset_v177) · V8 سری روزانه با شمارنده هم‌قدم
اجرا: python3 tools/qa_views.py   (سرور روی 8080)
"""
import sys, sqlite3, time, uuid, urllib.request, json

BASE = "http://127.0.0.1:8080"
DB = "data/bazarche.db"
BIZ = 214
RESULTS = []

def q(sql, args=()):
    c = sqlite3.connect(DB)
    r = c.execute(sql, args).fetchall()
    c.commit()
    c.close()
    return r

def check(tid, desc, cond, detail=""):
    RESULTS.append((tid, desc, bool(cond), detail))
    print(("  ✅" if cond else "  ❌") + f" [{tid}] {desc}" + (f" — {detail}" if (detail and not cond) else ""))

UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"

def get(path, cid=None):
    req = urllib.request.Request(BASE + path)
    req.add_header("User-Agent", UA)
    if cid:
        req.add_header("Cookie", f"bz_cid={cid}")
    else:
        req.add_header("Cookie", "bz_cid=")
    try:
        r = urllib.request.urlopen(req, timeout=20)
        return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()

def post_view(sid, cid):
    req = urllib.request.Request(BASE + f"/api/stories/{sid}/view", data=b"", method="POST")
    req.add_header("User-Agent", UA)
    req.add_header("Cookie", f"bz_cid={cid}")
    try:
        r = urllib.request.urlopen(req, timeout=20)
        return r.status
    except urllib.error.HTTPError as e:
        return e.code

def main():
    # بیننده‌های یکتای این ران + پاک‌سازی جامانده‌های ران‌های قبل (تست تکرارپذیر)
    VA, VB, VC = (uuid.uuid4().hex[:16] for _ in range(3))
    q("delete from page_viewers where (entity='biz' and eid=?) or (entity='item' and eid=336)", (BIZ,))

    sid = q("insert into stories(biz_id,image,kind,caption,created,expires,duration) "
            "values(?,?,?,?,datetime('now'),datetime('now','+1 day'),5) "
            "returning id", (BIZ, "/assets/img/uploads/qa-photo.webp", "image", "qa-views", ))[0][0]
    v0 = q("select count(*) from story_views where story_id=?", (sid,))[0][0]
    post_view(sid, VA)
    post_view(sid, VA)          # رفرش همان بیننده
    post_view(sid, VA)
    v1 = q("select count(*) from story_views where story_id=?", (sid,))[0][0]
    check("V1.1", "سه بار بازدیدِ همان بیننده = یک ردیف", v1 == v0 + 1, f"v0={v0} v1={v1}")
    post_view(sid, VB)
    v2 = q("select count(*) from story_views where story_id=?", (sid,))[0][0]
    check("V1.2", "بینندهٔ تازه شمرده شد", v2 == v1 + 1, f"v2={v2}")

    print("── V3/V4 صفحهٔ دکان: یکتا در روز")
    w0 = q("select views from businesses where id=?", (BIZ,))[0][0]
    get(f"/b/dkan-azmvn-malk-yk", VA)
    get(f"/b/dkan-azmvn-malk-yk", VA)     # دوبار در همان روز
    get(f"/b/dkan-azmvn-malk-yk", VA)
    w1 = q("select views from businesses where id=?", (BIZ,))[0][0]
    check("V3.1", "سه بار لود با همان مرورگر = یک بازدید", w1 == w0 + 1, f"w0={w0} w1={w1}")
    get(f"/b/dkan-azmvn-malk-yk", VB)
    w2 = q("select views from businesses where id=?", (BIZ,))[0][0]
    check("V4.1", "مرورگر دوم شمرده شد", w2 == w1 + 1, f"w2={w2}")

    print("── V5 روز بعد: همان بیننده دوباره شمرده می‌شود")
    q("update page_viewers set day='2026-01-01' where entity='biz' and eid=? and viewer=?", (BIZ, VA))
    get(f"/b/dkan-azmvn-malk-yk", VA)
    w3 = q("select views from businesses where id=?", (BIZ,))[0][0]
    check("V5.1", "روز جدید = بازدید تازه", w3 == w2 + 1, f"w3={w3}")

    print("── V6 کالا: یکتا در روز")
    i0 = q("select views from items where id=336")[0][0]
    get("/item/336", VC)
    get("/item/336", VC)
    i1 = q("select views from items where id=336")[0][0]
    check("V6.1", "دوبار لود کالا = یک بازدید", i1 == i0 + 1, f"i0={i0} i1={i1}")

    print("── V7 مهاجرت بایگانی")
    flag = q("select value from settings where key='views_reset_v177'")
    cols = {r[1] for r in q("pragma table_info(businesses)")}
    check("V7.1", "کلید یک‌بارهٔ ریست ثبت شد", bool(flag))
    check("V7.2", "ستون legacy_views روی businesses", "legacy_views" in cols)
    check("V7.3", "جدول بایگانی استوری موجود است",
          bool(q("select 1 from sqlite_master where name='story_views_legacy'"))
          or bool([r for r in q("pragma index_list(story_views)") if r[2]]))

    print("── V8 سری روزانهٔ events با شمارنده هم‌قدم")
    ev = q("select n from events where biz_id=? and kind='view' and day=date('now')", (BIZ,))
    delta = w3 - w0
    check("V8.1", "events امروز ≥ بازدیدهای یکتای امروز این آزمون",
          bool(ev) and ev[0][0] >= delta, f"events={ev[0][0] if ev else 0} delta={delta}")

    # ── تمیزکاری
    q("delete from stories where id=?", (sid,))
    q("delete from story_views where story_id=?", (sid,))
    q("delete from page_viewers where viewer in (?,?,?)", (VA, VB, VC))
    red = [r for r in RESULTS if not r[2]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(red)} | قرمز: {len(red)}")
    return 1 if red else 0

if __name__ == "__main__":
    sys.exit(main())
