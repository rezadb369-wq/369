#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۱۴ — سیستم (۴): سطل بازیافت · تنظیمات سایت · پشتیبان‌گیری · دادهٔ نمونه.
بازیابی واقعی از سطل، معنای فیلدهای ماسه‌شدهٔ تنظیمات، سلامت پشتیبان (zip/manifest/db)
و چرخهٔ کامل دادهٔ نمونه با پاک‌سازی دقیق."""
import re, sys, os, io, json, sqlite3, time, zipfile, hashlib, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []
ADMIN_PHONE = "09131110011"
SHOP_PHONE = "09352223344"
TAG = "نمونه‌آزمایشی"

def q(sql, args=()):
    """نوشتن/خواندن با بسته‌شدنِ امن و تلاشِ مجدد — قفلِ گذرای WAL دور خزشِ
    seed/پاک‌سازی گاه تا ~۲۰ ثانیه می‌ماند؛ باتری باید صبور باشد نه شکننده."""
    import time as _t
    last = None
    for attempt in range(6):
        c = sqlite3.connect(DB, timeout=20)
        try:
            r = c.execute(sql, args).fetchall(); c.commit(); return r
        except sqlite3.OperationalError as e:
            if "locked" not in str(e) and "busy" not in str(e):
                raise
            last = e; _t.sleep(3 + attempt * 2)
        finally:
            c.close()   # حتی هنگام خطا — اتصالِ باز با تراکنشِ نوشتن، خودِ باتری را قفل می‌کند
    raise last

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None):
    h = {}
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data, doseq=True).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(BASE + path, data=body, headers=h)
    try:
        r = op.open(req, timeout=60)
        return r.status, r.read(), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read(), e.geturl()

def got(op, path, data=None):
    st, raw, url = go(op, path, data)
    return st, raw.decode("utf-8", "replace"), url

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def clear_rl():
    q("delete from ratelimit")

def login(phone, admin=False):
    clear_rl()
    op = sess()
    go(op, "/login")
    go(op, "/login", {"phone": phone})
    go(op, "/login/verify", {"phone": phone, "code": otp_code(phone)})
    if admin:
        go(op, "/panel?key=" + DBM.owner_token())
    return op

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

created = {"reviews": [], "trash": [], "settings_back": {}, "biz_before": None}

# ─────────────────── T1 سطل بازیافت ───────────────────
def t1():
    print("── T1 سطل بازیافت (فهرست، بازیابی، وحشی)")
    op = login(ADMIN_PHONE, admin=True)
    st, b, _ = got(op, "/panel/trash")
    check("T1.1", "صفحهٔ بازیابی فایل‌ها 200 با عنوان (v177: تغییر نام)",
          st == 200 and "بازیابی فایل‌ها" in b)
    # نظر آزمونی بساز و از پنل حذف کن → سطل
    DBM.add_review(214, "مشتری آزمون", 4, "نظر سطل فاز ۱۴ — پس از آزمون حذف می‌شود.",
                   auto_approve=True)
    rid = q("select id from reviews where biz_id=214 and author='مشتری آزمون' "
            "order by id desc limit 1")[0][0]
    created["reviews"].append(rid)
    st, b, url = got(op, f"/panel/review/{rid}", {"action": "delete"})
    in_trash = q("select id from trash where entity='review' and ref_id=?", (rid,))
    created["trash"] += [r[0] for r in in_trash]
    check("T1.2", "حذف نظر → ردیف سطل ساخته شد", in_trash, f"{url} trash={in_trash}")
    # در صفحهٔ بازیابی فایل‌ها با برچسب «نظر» و مهلت ۳۰ روز (v177)
    st, b, _ = got(op, "/panel/trash")
    check("T1.3", "نظر در بازیابی فایل‌ها + برچسب و مهلت ۳۰روزه",
          "مشتری آزمون" in b and "نظر" in b and "۳۰ روز" in b)
    # بازیابی واقعی
    tid = in_trash[0][0]
    st, b, url = got(op, f"/panel/trash/{tid}/restore", {})
    back = q("select id from reviews where id=?", (rid,))
    gone = q("select id from trash where id=?", (tid,))
    check("T1.4", "بازیابی: نظر برگشت و ردیف سطل پاک شد",
          "بازیابی شد" in urllib.parse.unquote(url) and back and not gone,
          f"url={url}")
    created["trash"].remove(tid)
    # #35: بازیابی وحشی → پیام صادقانه، نه «موفقیت» جعلی
    st, b, url = got(op, "/panel/trash/999999/restore", {})
    check("T1.5", "#35 وحشی → «بازیابی ممکن نیست»",
          "بازیابی ممکن نیست" in urllib.parse.unquote(url), url)
    # دکاندار
    sop = login(SHOP_PHONE)
    g1 = got(sop, "/panel/trash")[0]
    g2 = got(sop, "/panel/trash/999999/restore", {})[0]
    check("T1.6", "دکاندار 403×2", (g1, g2) == (403, 403), str((g1, g2)))

# ─────────────────── T2 تنظیمات سایت ───────────────────
def t2():
    print("── T2 تنظیمات سایت (ذخیره، ماسهٔ کلیدها، پاک‌سازی کلید، FCM نامعتبر)")
    op = login(ADMIN_PHONE, admin=True)
    # ثبت وضعیت قبلی برای بازگردانی
    for k in ("site_name", "tagline", "sms_key", "tg_token", "gmaps_key",
              "ga_measurement_id", "fcm_service_json", "fcm_vapid_pub"):
        created["settings_back"][k] = (q("select value from settings where key=?", (k,)) or [("",)])[0][0]
    st, b, _ = got(op, "/panel/settings")
    check("T2.1", "صفحهٔ تنظیمات 200", st == 200 and "تنظیمات" in b)
    # ذخیرهٔ فیلد ساده
    cur_name = created["settings_back"]["site_name"] or "بازارچهٔ نجف‌آباد"
    st, b, url = got(op, "/panel/settings", {"site_name": cur_name, "tagline": "پیش‌نمایش آزاد کسب‌وکارهای شهر"})
    name_now = (q("select value from settings where key='site_name'")[0][0])
    check("T2.2", "ذخیرهٔ فیلد ساده → ok", "تنظیمات ذخیره شد" in urllib.parse.unquote(url)
          and name_now == cur_name, f"url={url} name={name_now!r}")
    # کلید ماسه‌شده: مقدار در HTML نیست؛ POST خالی مقدار را نگه می‌دارد
    q("insert or replace into settings(key,value) values('sms_key','qa-secret-123')")
    st, b, _ = got(op, "/panel/settings")
    masked = "qa-secret-123" not in b
    got(op, "/panel/settings", {"site_name": cur_name, "sms_key": ""})
    kept = (q("select value from settings where key='sms_key'")[0][0]) == "qa-secret-123"
    check("T2.3", "ماسهٔ کلید: در HTML نیست و POST خالی نگه می‌دارد", masked and kept,
          f"masked={masked} kept={kept}")
    # پاک‌سازی صریح با چک‌باکس
    got(op, "/panel/settings", {"site_name": cur_name, "clear_keys": "1"})
    cleared = (q("select value from settings where key='sms_key'")[0][0]) == ""
    check("T2.4", "clear_keys=1 → کلید پاک شد", cleared)
    # FCM نامعتبر → رد صادقانه
    st, b, url = got(op, "/panel/settings", {"site_name": cur_name,
                                             "fcm_service_json": "{بد"})
    check("T2.5", "JSON نامعتبر FCM → err", "err=" in url or "نامعتبر" in urllib.parse.unquote(url), url)
    # دکاندار
    sop = login(SHOP_PHONE)
    g1 = got(sop, "/panel/settings")[0]
    g2 = got(sop, "/panel/settings", {"site_name": "هک"})[0]
    check("T2.6", "دکاندار 403×2", (g1, g2) == (403, 403), str((g1, g2)))
    safe = (q("select value from settings where key='site_name'")[0][0]) == cur_name
    check("T2.7", "ذخیرهٔ دکاندار بی‌اثر ماند", safe)

# ─────────────────── T3 پشتیبان‌گیری ───────────────────
def t3():
    print("── T3 پشتیبان‌گیری (JSON، ZIP کامل با manifest، اسنپ‌شات db، ورود نامعتبر)")
    op = login(ADMIN_PHONE, admin=True)
    st, b, _ = got(op, "/panel/backup")
    check("T3.1", "صفحهٔ پشتیبان 200", st == 200 and "پشتیبان" in b)
    q("delete from settings where key='last_backup_at'")
    # خروجی JSON
    st, raw, url = go(op, "/panel/backup/export")
    try:
        data = json.loads(raw.decode("utf-8"))
        ok_json = "businesses" in data and "settings" in data
    except Exception as e:
        data, ok_json = None, False
    stamp = (q("select value from settings where key='last_backup_at'")[0][0])
    check("T3.2", "خروجی JSON سالم + last_backup_at ثبت شد", ok_json and stamp, f"stamp={stamp!r}")
    # ZIP کامل + manifest sha256
    st, raw, url = go(op, "/panel/backup/full")
    ok_zip = False
    try:
        z = zipfile.ZipFile(io.BytesIO(raw))
        names = z.namelist()
        bj = z.read("backup.json")
        man = json.loads(z.read("manifest.json").decode("utf-8"))
        ok_zip = ("backup.json" in names and "manifest.json" in names
                  and man.get("sha256_backup_json") ==
                  hashlib.sha256(bj).hexdigest()
                  and any(n.startswith("uploads/") for n in names))
    except Exception as e:
        ok_zip = False
    check("T3.3", "ZIP کامل: manifest sha256 درست + آپلودها داخل",
          st == 200 and ok_zip, f"st={st}")
    # اسنپ‌شات db
    st, raw, url = go(op, "/panel/backup/db")
    ok_db = raw[:16] == b"SQLite format 3\x00"
    if ok_db:
        tmp = "/tmp/qa14-snapshot.db"
        open(tmp, "wb").write(raw)
        c = sqlite3.connect(tmp)
        ok_db = c.execute("select count(*) from businesses").fetchone()[0] > 0
        c.close(); os.remove(tmp)
    check("T3.4", "اسنپ‌شات db: جادوی SQLite و داده داخل", st == 200 and ok_db, f"st={st}")
    # ورود نامعتبر → رد؛ پایگاه دست‌نخورده
    n_biz = q("select count(*) from businesses")[0][0]
    st, b, url = got(op, "/panel/backup/import", {"payload": "{بد"})
    n_after = q("select count(*) from businesses")[0][0]
    check("T3.5", "ورود نامعتبر → «فایل معتبر نیست» و پایگاه سالم",
          "فایل معتبر نیست" in urllib.parse.unquote(url) and n_after == n_biz, url)
    # دکاندار
    sop = login(SHOP_PHONE)
    g1 = go(sop, "/panel/backup/export")[0]
    g2 = got(sop, "/panel/backup/import", {"payload": "{}"})[0]
    check("T3.6", "دکاندار 403×2", (g1, g2) == (403, 403), str((g1, g2)))
    n_last = q("select count(*) from businesses")[0][0]
    check("T3.7", "import دکاندار بی‌اثر ماند", n_last == n_biz)

# ─────────────────── T4 دادهٔ نمونه ───────────────────
def t4():
    print("── T4 دادهٔ نمونه (seed کامل، دوباره‌کاری، پاک‌سازی دقیق)")
    op = login(ADMIN_PHONE, admin=True)
    # v177-ادامه: ملاک «دست‌نخوردگی» = دکان‌های غیر-دمو (پاک‌ساز مجاز است
    # نمونه‌آزمایشی‌ها را بخورد؛ دنیای دمو را scene دوباره می‌سازد)
    created["biz_before"] = q("select count(*) from businesses "
                              "where tags not like '%نمونه‌آزمایشی%'")[0][0]
    st, b, _ = got(op, "/panel/demo")
    check("T4.1", "صفحهٔ دادهٔ نمونه 200", st == 200 and "دادهٔ نمونهٔ آزمایشی" in b)
    # seed
    st, b, url = got(op, "/panel/demo", {"action": "seed"})
    tagged = q("select count(*) from businesses where tags like ?", (f"%{TAG}%",))[0][0]
    check("T4.2", "seed → دقیقاً ۱۰ کسب‌وکار نمونه",
          "دادهٔ نمونه ساخته شد" in urllib.parse.unquote(url) and tagged == 10,
          f"tagged={tagged} url={url[:80]}")
    check("T4.3", "هر ۱۰ نمونه منتشر و slug یکتا",
          q("select count(*) from businesses where tags like ? and status='published'", (f"%{TAG}%",))[0][0] == 10
          and q("select count(distinct slug) from businesses where tags like ?", (f"%{TAG}%",))[0][0] == 10)
    # اثرهای جانبی: نظر/پرسش/کاتالوگ/استوری/رویداد/بنر/مقاله/اشتراک
    demo_ids = [r[0] for r in q("select id from businesses where tags like ?", (f"%{TAG}%",))]
    n_rev = q("select count(*) from reviews where biz_id in (%s)" % ",".join("?"*10), demo_ids)[0][0]
    n_item = q("select count(*) from items where biz_id in (%s)" % ",".join("?"*10), demo_ids)[0][0]
    n_story = q("select count(*) from stories where biz_id in (%s)" % ",".join("?"*10), demo_ids)[0][0]
    n_ev = q("select count(*) from cityevents where descr like ?", (f"%{TAG}%",))[0][0]
    n_ad = q("select count(*) from ads where body like ?", (f"%{TAG}%",))[0][0]
    n_sub = q("select count(*) from subscriptions where biz_id=?", (demo_ids[0],))[0][0]
    check("T4.4", "نظر/کاتالوگ/استوری/رویداد/بنر/اشتراک ساخته شد",
          n_rev >= 10 and n_item >= 10 and n_story == 5 and n_ev == 1 and n_ad == 1 and n_sub == 1,
          f"rev={n_rev} item={n_item} story={n_story} ev={n_ev} ad={n_ad} sub={n_sub}")
    # صفحهٔ عمومی سالم با دادهٔ نمونه
    st, b, _ = got(sess(), "/businesses")
    check("T4.5", "فهرست عمومی با نمونه‌ها 200", st == 200 and "کبابی برادران حیدری" in b)
    # دوباره‌کاری: seed دوم → باز هم دقیقاً ۱۰ (انبارش نمی‌شود)
    got(op, "/panel/demo", {"action": "seed"})
    tagged2 = q("select count(*) from businesses where tags like ?", (f"%{TAG}%",))[0][0]
    check("T4.6", "seed دوم → باز هم دقیقاً ۱۰ (بدون انبارش)", tagged2 == 10, f"tagged={tagged2}")
    # پاک‌سازی دقیق
    st, b, url = got(op, "/panel/demo", {"action": "clear"})
    tagged3 = q("select count(*) from businesses where tags like ?", (f"%{TAG}%",))[0][0]
    n_ev2 = q("select count(*) from cityevents where descr like ?", (f"%{TAG}%",))[0][0]
    n_ad2 = q("select count(*) from ads where body like ?", (f"%{TAG}%",))[0][0]
    left_rev = q("select count(*) from reviews where biz_id in (select id from businesses where tags like ?)", (f"%{TAG}%",))[0][0]
    check("T4.7", "clear → همهٔ نمونه‌ها پاک، ردپا صفر",
          "پاک شد" in urllib.parse.unquote(url) and tagged3 == 0 and n_ev2 == 0
          and n_ad2 == 0 and left_rev == 0,
          f"tagged={tagged3} ev={n_ev2} ad={n_ad2} rev={left_rev}")
    n_after = q("select count(*) from businesses "
                "where tags not like '%نمونه‌آزمایشی%'")[0][0]
    check("T4.8", "کسب‌وکارهای واقعی (غیر-دمو) دست‌نخورده",
          n_after == created["biz_before"], f"{created['biz_before']}→{n_after}")
    # دکاندار
    sop = login(SHOP_PHONE)
    g1 = got(sop, "/panel/demo")[0]
    g2 = got(sop, "/panel/demo", {"action": "seed"})[0]
    check("T4.9", "دکاندار 403×2", (g1, g2) == (403, 403), str((g1, g2)))
    tagged4 = q("select count(*) from businesses where tags like ?", (f"%{TAG}%",))[0][0]
    check("T4.10", "seed دکاندار بی‌اثر ماند", tagged4 == 0, f"tagged={tagged4}")

def main():
    try:
        t1(); t2(); t3(); t4()
    finally:
        for rid in created["reviews"]:
            q("delete from review_scores where review_id=?", (rid,))
            q("delete from reviews where id=?", (rid,))
            q("delete from trash where entity='review' and ref_id=?", (rid,))
        for k, v in created["settings_back"].items():
            if v == "" and k not in ("site_name", "tagline"):
                q("delete from settings where key=?", (k,))
            else:
                q("insert or replace into settings(key,value) values(?,?)", (k, v))
        q("delete from events where biz_id not in (select id from businesses)")
        q("delete from price_history where item_id not in (select id from items)")
        q("delete from searches")
        # اگر باتری وسط T4 مرد، نمونهٔ نیمه‌کاره را با برچسب دقیق پاک کن —
        # همه از راه q() (هر گزاره کامیت می‌شود)؛ اتصالِ دوم با تراکنشِ
        # باز، خودِ باتری را در INSERT بعدی قفل می‌کرد (درس همین دور).
        for (bid,) in q("select id from businesses where tags like ?", (f"%{TAG}%",)):
            q("delete from businesses where id=?", (bid,))
        q("delete from cityevents where descr like ?", (f"%{TAG}%",))
        q("delete from ads where body like ?", (f"%{TAG}%",))
        q("delete from posts where excerpt like ?", (f"%{TAG}%",))
        # #37: بنر بذر id=8 ذاتاً تگ «نمونه‌آزمایشی» دارد — هر clear نابودش
        # می‌کند؛ اگر نیست، دقیقاً با همان شکل seed_demo بازسازی شود.
        if not q("select id from ads where id=8"):
            q("INSERT INTO ads(id,title,body,url,slot,active,weight,views,clicks) "
              "VALUES(8,'کسب‌وکار خود را ویژه کنید',?,'/pricing','home','1','1',0,0)",
              (f"با پلن حرفه‌ای بالای فهرست دیده شوید. {TAG}",))
    green = sum(1 for r in RESULTS if r["ok"])
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {green} | قرمز: {len(RESULTS)-green}")
    import os
    os.makedirs("qa", exist_ok=True)
    with open("qa/phase14-results.json", "w", encoding="utf-8") as f:
        json.dump(RESULTS, f, ensure_ascii=False, indent=1)
    sys.exit(0 if green == len(RESULTS) else 1)

if __name__ == "__main__":
    main()
