# -*- coding: utf-8 -*-
"""
v158 — قفل ایستای سه کار:
  ۱) ردیف استاندارد سوییچ تنظیم اعلان‌ها (عنوان/توضیح دو سطر، سوییچ انتهای ردیف)
  ۲) قفل شمارهٔ تلفن دکان = شمارهٔ ورود (readonly در دو فرم + اجبار سرور)
  ۳) ویجت امتیاز شش‌ستاره: کادر خط‌دار، برچسب فارسی بالای کادر/کنار معیار، توپُر
    python3 tools/test_v158.py
"""
import re
import sys

ok_n = bad_n = 0
FAILS = []
def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")

VO = open("server/views_owner.py", encoding="utf-8").read()
VC = open("server/views_customer.py", encoding="utf-8").read()
VP = open("server/views_public.py", encoding="utf-8").read()
VP2 = open("server/views_public2.py", encoding="utf-8").read()
APP = open("server/app.py", encoding="utf-8").read()
DB = open("server/db.py", encoding="utf-8").read()
LAY = open("tools/layout.py", encoding="utf-8").read()
MCSS = open("site/assets/css/main.css", encoding="utf-8").read()
PCSS = open("site/assets/css/pages.css", encoding="utf-8").read()
MSCSS = open("site/assets/css/mobile-standard.css", encoding="utf-8").read()
AJS = open("site/assets/js/app.js", encoding="utf-8").read()
QJS = open("site/assets/js/qa.js", encoding="utf-8").read()
SW = open("site/sw.js", encoding="utf-8").read()
UI = open("server/ui.py", encoding="utf-8").read()

def head(t):
    print(f"\n\033[1m── {t}\033[0m")

def main():
    head("۱) ردیف سوییچ استاندارد")
    for name, src in (("مالک", VO), ("مشتری", VC)):
        check(f"{name}: markup switch-row (عنوان+توضیح+track در انتها)",
              'class="switch-row"' in src and 'sw-copy' in src
              and '<span class="track" aria-hidden="true"></span></label>' in src)
        check(f"{name}: بدون الگوی کهنه (— توضیح در همان سطر)",
              '<small class="text-muted"> — ' not in src)
    check("CSS: چیدمان ردیف (flex + کپی دو سطری)",
          ".switch-row {" in PCSS and ".switch-row .sw-copy {" in PCSS
          and "flex-direction: column" in PCSS)
    check("CSS: حالت روشن با ~ (ساختار تازه)",
          ".switch-row input:checked ~ .track" in MCSS)
    check("CSS: track مشترک بین .switch و .switch-row",
          ".switch .track, .switch-row .track {" in MCSS)
    check("CSS: دکمهٔ هیرو در موبایل له نمی‌شود (v157 باقی می‌ماند)",
          ".page-hero.notifications-hero { flex-wrap: wrap; }" in MSCSS)

    head("۲) قفل شمارهٔ تلفن")
    check("فرم ویرایش: value=شمارهٔ ورود + readonly + راهنما",
          'value="{esc(owner[\'phone\'])}" readonly' in VO
          and "با شمارهٔ ورود شما یکسان است" in VO)
    check("هندلر ویرایش: اجبار data.phone = me.phone",
          'data["phone"] = me["phone"]' in APP)
    check("فرم ثبت: readonly برای واردشده + راهنمای جایگزین",
          '{\'readonly\' if me else \'\'}' in VP.replace('"', '\'')
          or '"readonly" if me else ""' in VP)
    check("هندلر ثبت: phone = شمارهٔ حساب برای واردشده",
          "_sub_me = self.current_owner()" in APP and 'phone = _sub_me["phone"]' in APP)

    head("۳) ویجت شش‌ستاره")
    check("تکی: کادر + برچسب بالا + شش دکمه",
          '<div class="rating-box">' in VP and 'data-rating-label' in VP
          and "range(1, 7)" in VP)
    check("برچسب‌های فارسی شش‌گانه در سربرگ",
          'RATING_LABELS = ("خیلی بد", "بد", "متوسط", "خوب", "خیلی خوب", "عالی")' in VP)
    check("چندمعیاره: کادر + جای برچسب سطح + شش دکمه",
          'crit-input rating-box rating-box-wide' in VP2
          and 'data-crit-lvl' in VP2 and "range(1, 7)" in VP2)
    check("JS تکی: RATING_LABELS + به‌روزرسانی برچسب",
          "RATING_LABELS" in AJS and "data-rating-label" in AJS
          and "یک ستاره انتخاب کنید" in AJS)
    check("JS معیار: CRIT_LABELS + برچسب سطح سطر",
          "CRIT_LABELS" in QJS and "data-crit-lvl" in QJS)
    check("CSS: کادر خط‌دار + برچسب + ستارهٔ توپُر",
          ".rating-box {" in PCSS and ".rating-label {" in PCSS
          and '.crit-stars button[aria-pressed="true"] svg { fill: currentColor; }' in PCSS)
    check("CSS: معیار در صفحهٔ باریک دو سطر می‌شود",
          "@media (max-width: 420px)" in PCSS and "grid-template-columns: 1fr" in PCSS)
    check("سرور: سقف ۶ برای امتیاز و معیارها",
          "max(0, min(6, rv))" in APP and "max(1, min(6, int(v)))" in APP)
    check("نمایش stars() شش‌تایی با «از ۶»",
          "range(1, 7)" in LAY and "از ۶" in LAY)
    check("schema.org bestRating=6", '"bestRating": 6' in DB and '"bestRating": 5' not in DB)
    check("نشان برترین: آستانهٔ ۵٫۴ (۹۰٪ شش‌ستاره)",
          'r["r"] >= 5.4' in DB and "۵٫۴ از ۶" in DB)

    head("بامپ نسخه")
    ver = open("VERSION.txt", encoding="utf-8").readline().strip()
    check(f"sw.js → bazarche-v{ver}", f"bazarche-v{ver}" in SW)
    for pat in ("main.css?v158", "pages.css?v158", "app.js?v158"):
        check(f"ui.py → {pat}", pat in UI)
    check("views_public → qa.js?v158", "qa.js?v158" in VP)

    print(f"\n\033[1mنتیجه: {ok_n} موفق / {bad_n} ناموفق\033[0m")
    if FAILS:
        print("شکست‌ها:")
        for f in FAILS:
            print("  -", f)
    return 1 if bad_n else 0

if __name__ == "__main__":
    sys.exit(main())
