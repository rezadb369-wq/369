# -*- coding: utf-8 -*-
"""QA تاریخچهٔ استوری‌ها (v177) — صفحهٔ عمومی /b/{slug}/stories + بخش تاریخچهٔ دکاندار.
A1 لینک تاریخچه روی صفحهٔ دکان · A2 صفحهٔ آرشیو 200 با کارت‌ها
A3 نشان فعال/بایگانی · A4 منقضی از /api/stories حذف ولی در آرشیو هست
A5 منقضی در جدول می‌ماند (بدون پاک‌سازی) · A6 جداسازی دکان‌ها
A7 اسلاگ ناشناس/دکان مخفی = 404 · A8 بخش تاریخچه در /my/stories
A9 آمار بازدید واقعی استوری منقضی · A10 حذف استوری منقضی
A11 پخش کارت آرشیو با ویوِر + شمارش یکتا (playwright)
A12 قانون لمس: کارت آرشیو ≥44px در 360px
اجرا: python3 tools/qa_story_archive.py   (سرور روی 8080)
"""
import sys, time, sqlite3, urllib.request, urllib.parse, http.cookiejar

BASE = "http://127.0.0.1:8080"
DB = "data/bazarche.db"
BIZ, SLUG = 214, "dkan-azmvn-malk-yk"
PHONE = "09352223344"          # دکاندار A
IMG = "/assets/img/uploads/qa-photo.webp"
RESULTS = []

def q(sql, args=()):
    c = sqlite3.connect(DB)
    r = c.execute(sql, args).fetchall()
    c.commit()
    c.close()
    return r

def check(tid, desc, cond, detail=""):
    RESULTS.append((tid, bool(cond)))
    print(("  ✅" if cond else "  ❌") + f" [{tid}] {desc}" + (f" — {detail}" if (detail and not cond) else ""))

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None, headers=None):
    h = dict(headers or {})
    if data is not None and "Content-Type" not in h and not isinstance(data, (bytes, str)):
        data = urllib.parse.urlencode(data, doseq=True).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(BASE + path, data=data, headers=h)
    req.add_header("User-Agent", "Mozilla/5.0 (Linux; Android 13) Chrome/120 Mobile")
    try:
        r = op.open(req, timeout=25)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def login_owner():
    op = sess()
    q("delete from ratelimit where bucket like 'otp%'")
    go(op, "/me/login")
    go(op, "/me/login", {"phone": PHONE})
    go(op, "/me/login/verify", {"phone": PHONE, "code": otp_code(PHONE)})
    return op

def main():
    print("── صحنه: استوری فعال + منقضی برای دکان ۲۱۴")
    q("delete from stories where caption like 'qa-arch%'")
    q("delete from story_views where story_id in (select id from stories where caption like 'qa-arch%')")
    q("insert into stories(biz_id,image,kind,caption,created,expires,duration) "
      "values(?,?,?,?,datetime('now'),?,5)", (BIZ, IMG, "image", "qa-arch-live", time.time() + 86400))
    q("insert into stories(biz_id,image,kind,caption,created,expires,duration) "
      "values(?,?,?,?,datetime('now','-2 days'),?,5)", (BIZ, IMG, "image", "qa-arch-old", time.time() - 3600))
    sid_old = q("select id from stories where caption='qa-arch-old'")[0][0]

    print("── A1/A2 صفحهٔ عمومی آرشیو")
    op = sess()
    st, b, _ = go(op, f"/b/{SLUG}")
    check("A1.1", "صفحهٔ دکان لینک «تاریخچه» دارد", 'href="/b/%s/stories"' % SLUG in b)
    st, b, _ = go(op, f"/b/{SLUG}/stories")
    check("A2.1", "آرشیو 200", st == 200, f"st={st}")
    check("A2.2", "کارت آرشیو رندر شد", "arch-card" in b and "data-arch-group" in b)
    check("A2.3", "لینک بازگشت به دکان", f"/b/{SLUG}\"" in b)
    check("A2.4", "ویوِر استوری لود می‌شود", "stories.js?v177" in b)

    print("── A3/A4/A5 فعال/منقضی")
    check("A3.1", "نشان «فعال» برای استوری زنده", "فعال" in b and "qa-arch-live" in b)
    check("A3.2", "نشان «بایگانی» برای منقضی", "بایگانی" in b and "qa-arch-old" in b)
    st, api, _ = go(op, "/api/stories")
    import json as _j
    caps = [s["caption"] for s in _j.loads(api).get("stories", [])]
    check("A4.1", "منقضی در نوار فعال نیست", "qa-arch-old" not in caps and "qa-arch-live" in caps, str(caps))
    row = q("select id from stories where id=?", (sid_old,))
    check("A5.1", "منقضی در جدول ماند (بدون پاک‌سازی)", bool(row))

    print("── A6/A7 جداسازی و 404")
    q("insert into stories(biz_id,image,kind,caption,created,expires,duration) "
      "values(215,?,\"image\",\"qa-arch-other\",datetime('now'),?,5)", (IMG, time.time() + 3600))
    st, b2, _ = go(op, "/b/dkan-azmvn-malk-dv/stories")
    check("A6.1", "آرشیو دکان دیگر استوری دکان ۲۱۴ را نشان نمی‌دهد",
          "qa-arch-old" not in b2 and "qa-arch-other" in b2)
    st, _, _ = go(op, "/b/nashenas-xyz/stories")
    check("A7.1", "اسلاگ ناشناس = 404", st == 404, f"st={st}")
    q("insert into businesses(id,slug,name,status,cat_slug) values(250,'qa-arch-hidden','مخفی آزمون','hidden','food')")
    st, _, _ = go(op, "/b/qa-arch-hidden/stories")
    check("A7.2", "دکان مخفی = 404", st == 404, f"st={st}")
    q("delete from businesses where id=250")

    print("── A8/A9 پنل دکاندار")
    own = login_owner()
    st, my, _ = go(own, "/my/stories")
    check("A8.1", "بخش «تاریخچهٔ استوری‌ها» هست", "تاریخچهٔ استوری‌ها" in my)
    check("A8.2", "استوری منقضی در تاریخچه با شمارنده", "qa-arch-old" in my)
    check("A8.3", "لینک تاریخچهٔ عمومی در پنل", f"/b/{SLUG}/stories" in my)
    st, js, _ = go(own, f"/my/story/{sid_old}/views")
    import json as _j2
    d = _j2.loads(js)
    check("A9.1", "آمار بازدید واقعی منقضی = ok", d.get("ok") is True and "total" in d, js[:80])

    print("── A11 پخش کارت آرشیو + شمارش یکتا")
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        br = pw.chromium.launch()
        ctx = br.new_context(viewport={"width": 360, "height": 740})
        pg = ctx.new_page()
        pg.goto(BASE + f"/b/{SLUG}/stories", wait_until="networkidle")
        card = pg.locator('[data-arch-group*="qa-arch-old"]').first
        box = card.bounding_box()
        check("A12.1", "کارت آرشیو ≥44px (360px)", box and min(box["width"], box["height"]) >= 44,
              str(box))
        pg.locator(".story-viewer, body").first.wait_for(state="attached")
        card.click()
        pg.wait_for_timeout(1500)
        n1 = q("select count(*) from story_views where story_id=?", (sid_old,))[0][0]
        viewer = pg.locator(".story-viewer").count()
        check("A11.1", "کلیک کارت → ویوِر باز شد", viewer == 1)
        check("A11.2", "یک بازدید ثبت شد", n1 == 1, f"n={n1}")
        pg.screenshot(path="shots-brand/archive-e2e.png")
        pg.keyboard.press("Escape")
        pg.wait_for_timeout(300)
        pg.reload(wait_until="networkidle")
        pg.locator('[data-arch-group*="qa-arch-old"]').first.click()
        pg.wait_for_timeout(1500)
        n2 = q("select count(*) from story_views where story_id=?", (sid_old,))[0][0]
        check("A11.3", "بازبینی همان مرورگر شمارنده را بالا نمی‌برد", n1 == n2, f"n1={n1} n2={n2}")
        br.close()

    print("── A10 حذف استوری منقضی")
    st, _, url = go(own, f"/my/story/{sid_old}/delete", {})
    row = q("select id from stories where id=?", (sid_old,))
    check("A10.1", "حذف منقضی انجام شد", not row and st in (200, 302, 303), f"st={st} url={url}")
    trash = q("select 1 from trash where entity='story' and ref_id=?", (sid_old,))
    check("A10.2", "حذف دستی به سطل رفت (v105 سر جایش)", bool(trash))

    # ── تمیزکاری
    ids = [r[0] for r in q("select id from stories where caption like 'qa-arch%'")]
    for i in ids:
        q("delete from story_views where story_id=?", (i,))
        q("delete from trash where entity='story' and ref_id=?", (i,))
    q("delete from stories where caption like 'qa-arch%'")
    q("delete from otp")
    red = [r for r in RESULTS if not r[1]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(red)} | قرمز: {len(red)}")
    return 1 if red else 0

if __name__ == "__main__":
    sys.exit(main())
