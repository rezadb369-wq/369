# -*- coding: utf-8 -*-
"""سنجهٔ زندهٔ کامل §6: هر ۴ حالت پین در دو زوم + «موقعیت من» با مجوز ژئولوکیشن."""
from playwright.sync_api import sync_playwright
BZ = "http://127.0.0.1:8080"
def rects(pg):
    return pg.evaluate("""() => {
      const r = (s) => { const el = document.querySelector(s); if (!el) return null;
        const b = el.getBoundingClientRect(); return [+b.width.toFixed(1), +b.height.toFixed(1)]; };
      const ps = getComputedStyle(document.querySelector('[data-map-canvas]')).getPropertyValue('--pin-scale');
      return { ps: ps.trim(), dot: r('.bz-pin .bz-dot'), drop: r('.bz-pin-active .bz-pin-drop'),
               me: r('.bz-me .bz-me-dot') };
    }""")
with sync_playwright() as p:
    br = p.chromium.launch()
    ctx = br.new_context(viewport={"width": 390, "height": 844}, locale="fa")
    ctx.grant_permissions(["geolocation"], origin=BZ)
    ctx.set_geolocation({"longitude": 51.3670, "latitude": 32.6340})
    pg = ctx.new_page()
    pg.goto(BZ + "/map", wait_until="domcontentloaded")
    pg.wait_for_selector(".leaflet-container", timeout=15000)
    pg.wait_for_timeout(1200)
    print("z14 نقطه  :", rects(pg))
    # پین فعال
    pg.eval_on_selector(".bz-pin", "el => el.dispatchEvent(new MouseEvent('click', {bubbles: true}))")
    pg.wait_for_timeout(700)
    print("z14 فعال :", rects(pg))
    # موقعیت من
    pg.eval_on_selector("[data-map-me]", "el => el.click()")
    pg.wait_for_timeout(1500)
    print("z14 من   :", rects(pg))
    for _ in range(2):
        pg.eval_on_selector(".leaflet-control-zoom-in", "el => el.click()")
        pg.wait_for_timeout(450)
    print("z16 نقطه/فعال/من:", rects(pg))
    br.close()
