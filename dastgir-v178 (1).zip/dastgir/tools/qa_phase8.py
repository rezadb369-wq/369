#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۸ — تعامل مشتری (۲): نوبت‌ها · پیام‌ها · هشدار جست‌وجو.
هر تست اثر واقعی را در پایگاه/صفحه بررسی می‌کند و تمیزکاری برمی‌گرداند."""
import re, sys, json, sqlite3, time, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []
A_SLUG = "dkan-azmvn-malk-yk"
A_BIZ = 214
SHOP_PHONE = "09352223344"
ADMIN_PHONE = "09131110011"

def q(sql, args=()):
    c = sqlite3.connect(DB); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None):
    h = {}
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data, doseq=True).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(BASE + path, data=body, headers=h)
    try:
        r = op.open(req, timeout=25)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def clear_rl():
    q("delete from ratelimit")

def login(phone, admin=False):
    clear_rl()
    op = sess()
    go(op, "/login")
    go(op, "/login", {"phone": phone})
    go(op, "/login/verify", {"phone": phone, "code": otp_code(phone)})
    if admin:
        go(op, "/panel?key=" + DBM.owner_token())
    return op

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

created = {"bookings": [], "messages": [], "alerts": [], "biz": []}

# ─────────────────── T1 نوبت‌ها ───────────────────
def t1():
    print("── T1 نوبت‌ها (رزرو عمومی، وضعیت‌ها، مرزها)")
    # صحنه: دکان نوبت می‌پذیرد + مالک متصل است (اعلان به مالک؛ پایان دور NULL/0)
    q("update businesses set booking_on=1, owner_id=2 where id=?", (A_BIZ,))
    # 1.1 رزرو معتبر مشتری ناشناس → ردیف + اعلان مالک
    n0 = q("select count(*) from owner_notifications where kind='order' and link='/my/bookings' and text like '%نوبت%'")[0][0]
    st, b, url = go(sess(), f"/b/{A_SLUG}/book", {
        "name": "نوبت‌گیر آزمون", "phone": "09361112233",
        "date": "2026-09-10", "time": "10:30", "note": "بعدازظهر زنگ بزنید."})
    row = q("select id,biz_id,name,phone,date,status from bookings where name='نوبت‌گیر آزمون'")
    ok = len(row) == 1 and row[0][1] == A_BIZ and row[0][5] == "new"
    kid = row[0][0] if row else 0
    created["bookings"].append(kid)
    n1 = q("select count(*) from owner_notifications where kind='order' and link='/my/bookings' and text like '%نوبت%'")[0][0]
    check("T1.1", "رزرو معتبر → ردیف new + اعلان دکاندار", ok and n1 == n0 + 1, f"{row} notif {n0}→{n1}")
    # 1.2 (رفع v171/#25) خالی/بی‌شماره رد می‌شود
    st, b, url = go(sess(), f"/b/{A_SLUG}/book", {"name": "", "phone": "", "date": "", "time": ""})
    n2 = q("select count(*) from bookings where name=''")[0][0]
    check("T1.2", "رزرو خالی رد با پیام روشن",
          "کامل و درست" in urllib.parse.unquote(url) and n2 == 0, f"{url} n={n2}")
    st, b, url = go(sess(), f"/b/{A_SLUG}/book", {
        "name": "بی‌شمارهٔ آزمون", "phone": "12345", "date": "2026-09-10"})
    n3 = q("select count(*) from bookings where name='بی‌شمارهٔ آزمون'")[0][0]
    check("T1.3", "شمارهٔ بی‌اعتبار رد", "کامل و درست" in urllib.parse.unquote(url) and n3 == 0, f"n={n3}")
    # 1.4 (رفع v171/#25) دکانِ نوبت‌خاموش نوبت نمی‌گیرد
    st, b, url = go(sess(), f"/b/{A_SLUG}/book", {
        "name": "خاموش آزمون", "phone": "09361112233", "date": "2026-09-11"})
    created["bookings"].append(q("select id from bookings where name='خاموش آزمون'")[0][0])
    q("update businesses set booking_on=0 where id=?", (A_BIZ,))
    time.sleep(5.2)
    st, b, url = go(sess(), f"/b/{A_SLUG}/book", {
        "name": "خاموش دوم", "phone": "09361112233", "date": "2026-09-11"})
    n4 = q("select count(*) from bookings where name='خاموش دوم'")[0][0]
    check("T1.4", "نوبت‌خاموش: POST رد («نوبت نمی‌پذیرد»)",
          "نوبت نمی‌پذیرد" in urllib.parse.unquote(url) and n4 == 0, f"{url} n={n4}")
    q("update businesses set booking_on=1 where id=?", (A_BIZ,))
    time.sleep(5.2)
    # 1.5 نرخ‌سنج (پیش‌فرض ۸/۶۰۰)
    clear_rl()
    last = None
    for i in range(11):
        st, b, url = go(sess(), f"/b/{A_SLUG}/book", {
            "name": f"سیلاب {i}", "phone": "09361112233", "date": "2026-09-12"})
        last = url
    created["bookings"] += [r[0] for r in q("select id from bookings where name like 'سیلاب %'")]
    n5 = q("select count(*) from bookings where name like 'سیلاب %'")[0][0]
    check("T1.5", "نرخ‌سنج: بیش از سقف رد می‌شود",
          "زیاد است" in urllib.parse.unquote(last) and n5 < 11, f"n={n5} {last}")
    # 1.6 وضعیت‌ها توسط دکاندار (whitelist رفع v171)
    q("update businesses set owner_id=2 where id=?", (A_BIZ,))
    sop = login(SHOP_PHONE)
    for s_ in ("confirmed", "done", "cancelled"):
        st, b, url = go(sop, f"/my/booking/{kid}", {"status": s_})
        cur = q("select status from bookings where id=?", (kid,))[0][0]
        if s_ != "cancelled":
            check(f"T1.6-{s_}", f"وضعیت {s_} پذیرفته شد", cur == s_ and "به‌روزرسانی" in urllib.parse.unquote(url), f"{cur}")
    # 1.7 وضعیت جعلی رد
    st, b, url = go(sop, f"/my/booking/{kid}", {"status": "bogus"})
    cur = q("select status from bookings where id=?", (kid,))[0][0]
    check("T1.7", "وضعیت جعلی → «معتبر نیست»", "معتبر نیست" in urllib.parse.unquote(url), url)
    # 1.8 وحشی دکاندار
    st, b, url = go(sop, "/my/booking/999999", {"status": "done"})
    check("T1.8", "وحشی دکاندار → «نیست»", "نیست" in urllib.parse.unquote(url), url)
    # 1.9 مرز: نوبت دکان دیگر
    q("insert into bookings(biz_id,name,phone,date,time,note) "
      "values(215,'بیگانهٔ نوبت','09361112233','2026-09-12','09:00','آزمون مرز')")
    kid_b = q("select id from bookings where name='بیگانهٔ نوبت'")[0][0]
    created["bookings"].append(kid_b)
    st, b, url = go(sop, f"/my/booking/{kid_b}", {"status": "done"})
    cur = q("select status from bookings where id=?", (kid_b,))[0][0]
    check("T1.9", "نوبت دکان دیگر لمس نمی‌شود", "نیست" in urllib.parse.unquote(url) and cur == "new", f"{url} {cur}")
    # 1.10 پنل: وحشی + وضعیت جعلی
    op = login(ADMIN_PHONE, admin=True)
    st, b, url = go(op, "/panel/booking/999999", {"status": "done"})
    check("T1.10", "وحشی پنل نوبت → «نیست»", "نیست" in urllib.parse.unquote(url), url)
    st, b, url = go(op, f"/panel/booking/{kid}", {"status": "zzz"})
    check("T1.11", "پنل: وضعیت جعلی → «معتبر نیست»", "معتبر نیست" in urllib.parse.unquote(url), url)
    st, b, url = go(op, f"/panel/booking/{kid}", {"status": "confirmed"})
    check("T1.12", "پنل: وضعیت معتبر ذخیره",
          q("select status from bookings where id=?", (kid,))[0][0] == "confirmed")
    # 1.13 دکاندار صفحهٔ نوبت‌ها 200
    st, b, _ = go(sop, "/my/bookings")
    check("T1.13", "صفحهٔ نوبت‌های دکاندار 200", st == 200)
    q("update businesses set owner_id=NULL where id=?", (A_BIZ,))

# ─────────────────── T2 پیام‌ها ───────────────────
def t2():
    print("── T2 پیام‌ها (صندوق قدیمی؛ پشتیبانی = تیکت)")
    op = login(ADMIN_PHONE, admin=True)
    # 2.1 GET /contact = صفحهٔ «پشتیبانی فقط تیکت» با CTA تیکت (سیاست ایستاده)
    st, b, url = go(sess(), "/contact")
    check("T2.1", "/contact صفحهٔ فقط‌تیکت با CTA تیکت",
          st == 200 and "فقط با تیکت" in b and "/my/tickets" in b, f"st={st}")
    st, b, url = go(sess(), "/contact", {"name": "مهمان", "body": "سلام"})
    check("T2.2", "POST /contact هم → تیکت‌ها", "/my/tickets" in url or "/login" in url, url)
    # 2.2 پیام قدیمی: خواندن/حذف
    q("insert into messages(name,email,subject,body,kind,meta) "
      "values('پیام قدیمی آزمون','old@test.local','موضوع آزمون','متن پیام قدیمی برای آزمون فاز ۸.','contact','{}')")
    mid = q("select id from messages where name='پیام قدیمی آزمون'")[0][0]
    created["messages"].append(mid)
    st, b, _ = go(op, "/panel/messages")
    check("T2.3", "پنل پیام‌ها 200 و پیام دیده می‌شود", st == 200 and "پیام قدیمی آزمون" in b)
    st, b, url = go(op, f"/panel/message/{mid}", {"action": "read"})
    check("T2.4", "خوانده‌شده", "علامت‌گذاری" in urllib.parse.unquote(url)
          and q("select status from messages where id=?", (mid,))[0][0] == "read")
    st, b, url = go(op, f"/panel/message/{mid}", {"action": "delete"})
    check("T2.5", "حذف پیام", "حذف" in urllib.parse.unquote(url)
          and not q("select * from messages where id=?", (mid,)))
    created["messages"].remove(mid)
    # 2.3 وحشی (رفع v171)
    st, b, url = go(op, "/panel/message/999999", {"action": "read"})
    check("T2.6", "وحشی پیام → «نیست»", "نیست" in urllib.parse.unquote(url), url)

# ─────────────────── T3 هشدار جست‌وجو ───────────────────
def t3():
    print("── T3 هشدار جست‌وجو")
    # 3.1 ثبت معتبر + تکراری + شمارهٔ غلط
    st, b, _ = go(sess(), "/alert", {"phone": "09361112233", "term": "کبابی", "cat": "", "back": "/businesses"})
    row = q("select id,active,sent from alerts where term='کبابی' order by id desc limit 1")
    ok = len(row) == 1 and row[0][1] == 1
    aid = row[0][0] if row else 0
    created["alerts"].append(aid)
    check("T3.1", "ثبت هشدار معتبر", ok, str(row))
    st, b, url = go(sess(), "/alert", {"phone": "09361112233", "term": "کبابی", "cat": "", "back": "/businesses"})
    check("T3.2", "تکراری → پیام «قبلاً ثبت شده»", "قبلاً" in urllib.parse.unquote(url), url)
    st, b, url = go(sess(), "/alert", {"phone": "123", "term": "هیچ", "cat": "", "back": "/businesses"})
    check("T3.3", "شمارهٔ غلط رد", "معتبر نیست" in urllib.parse.unquote(url), url)
    # 3.2 بازگردانی back به داخل (v116 پابرجا)
    st, b, url = go(sess(), "/alert", {"phone": "09361112233", "term": "یگانهٔ تست", "cat": "", "back": "//evil.example"})
    created["alerts"].append(q("select id from alerts where term='یگانهٔ تست'")[0][0])
    check("T3.4", "back خارجی → /businesses نرمال", "/businesses?ok=" in url and "evil" not in url, url)
    # 3.3 تطبیق هشدار با دکان تازه (واحد — mark_alert_sent)
    q("insert into businesses(slug,name,cat_slug,status,created) "
      "values('azmoon-tase-v171','کبابی یگانهٔ آزمون ۱۷۱','kbaby','published',datetime('now'))")
    bid = q("select id from businesses where slug='azmoon-tase-v171'")[0][0]
    created["biz"].append(bid)
    m = DBM.matching_alerts(dict(q("select * from businesses where id=?", (bid,))[0]
                                 ) if False else DBM._one("SELECT * FROM businesses WHERE id=?", (bid,)))
    names = [a["term"] for a in m]
    if names:
        DBM.mark_alert_sent(m[0]["id"])
    sent = q("select sent from alerts where term='کبابی'")[0][0]
    check("T3.5", "matching_alerts: هشدارِ هم‌خوان یافت و علامت خورد",
          "کبابی" in names and sent == 1, f"{names} sent={sent}")
    # 3.4 پنل: خاموش/روشن + وحشی (رفع v171)
    op = login(ADMIN_PHONE, admin=True)
    st, b, _ = go(op, "/panel/alerts")
    check("T3.6", "پنل هشدارها 200", st == 200)
    st, b, url = go(op, f"/panel/alert/{aid}", {"action": "toggle"})
    check("T3.7", "خاموش/روشن", "تغییر کرد" in urllib.parse.unquote(url)
          and q("select active from alerts where id=?", (aid,))[0][0] == 0)
    st, b, url = go(op, "/panel/alert/999999", {"action": "toggle"})
    check("T3.8", "وحشی هشدار → «نیست»", "نیست" in urllib.parse.unquote(url), url)
    st, b, url = go(op, f"/panel/alert/{aid}", {"action": "delete"})
    check("T3.9", "حذف هشدار", "حذف" in urllib.parse.unquote(url)
          and not q("select * from alerts where id=?", (aid,)))
    created["alerts"].remove(aid)

def main():
    try:
        t1()
        t2()
        t3()
    finally:
        for kid in created["bookings"]:
            q("delete from bookings where id=?", (kid,))
        for mid in created["messages"]:
            q("delete from messages where id=?", (mid,))
        for aid in created["alerts"]:
            q("delete from alerts where id=?", (aid,))
        for bid in created["biz"]:
            q("delete from businesses where id=?", (bid,))
        # احتیاط دوم — الگوهای دقیق آزمون
        q("delete from bookings where name like '%آزمون%' or name like 'سیلاب %'")
        q("delete from messages where name like '%آزمون%'")
        q("delete from alerts where term in ('کبابی','یگانهٔ تست','هیچ')")
        q("delete from businesses where slug='azmoon-tase-v171'")
        q("delete from owner_notifications where link='/my/bookings' and text like '%نوبت%'")
        q("update businesses set booking_on=0, owner_id=NULL where id in (214,215,216)")
    json.dump(RESULTS, open("qa/phase8-results.json", "w"), ensure_ascii=False, indent=1)
    fails = [r for r in RESULTS if not r["ok"]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(fails)} | قرمز: {len(fails)}")
    for r in fails:
        print("  ❌", r["id"], r["name"], "—", r["detail"])
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
