# -*- coding: utf-8 -*-
"""QA فرم سریع «موجود شد خبرم کن» در چت (v177).
F1 صفحهٔ چت: فرم با چیپ‌های کالا + استپر تعداد + یادداشت
F2 ارسال کامل: ردیف درخواست (item/qty/note/source=chat) + کارت در رشتهٔ چت
F3 تکرار درخواست بازِ همان کالا → err (یکتا سر جایش)
F4 پنل فراخوان دکاندار: عنوان کالا + تعداد + یادداشت
F5 سنجاق qty (0→1، 500→99) و بریدن note بلند
F6 E2E مرورگر: چیپ + استپر + ارسال → ریدایرکت ok و کارت در صفحه
اجرا: python3 tools/qa_stock_fast.py   (سرور روی 8080)
"""
import sys, json, sqlite3, time, urllib.request, urllib.parse, http.cookiejar

BASE = "http://127.0.0.1:8080"
DB = "data/bazarche.db"
BIZ, SLUG = 214, "dkan-azmvn-malk-yk"
C_PHONE, O_PHONE = "09361112233", "09352223344"
RESULTS = []

def q(sql, args=()):
    c = sqlite3.connect(DB)
    r = c.execute(sql, args).fetchall()
    c.commit()
    c.close()
    return r

def check(tid, desc, cond, detail=""):
    RESULTS.append((tid, bool(cond)))
    print(("  ✅" if cond else "  ❌") + f" [{tid}] {desc}" + (f" — {detail}" if (detail and not cond) else ""))

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None, headers=None):
    h = dict(headers or {})
    if data is not None and "Content-Type" not in h and not isinstance(data, (bytes, str)):
        data = urllib.parse.urlencode(data, doseq=True).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(BASE + path, data=data, headers=h)
    req.add_header("User-Agent", "Mozilla/5.0 (Linux; Android 13) Chrome/120 Mobile")
    try:
        r = op.open(req, timeout=25)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def login(phone):
    op = sess()
    q("delete from ratelimit where bucket like 'otp%'")
    go(op, "/me/login"); go(op, "/me/login", {"phone": phone})
    go(op, "/me/login/verify", {"phone": phone, "code": otp_code(phone)})
    return op

def cleanup():
    q("delete from stock_requests where biz_id=? and source='chat'", (BIZ,))
    q("delete from chat_messages where body like '🔔 درخواست موجودی%'")
    q("delete from otp")

def main():
    cleanup()
    print("── صحنه: گفتگوی مشتری ۱۷ با دکان ۲۱۴ + کالای ناموجود")
    q("insert into items(biz_id,kind,title,descr,price,price_type,available) "
      "values(?,?,?,?,?,?,0)", (BIZ, "product", "qa-oos-item", "", 5000, "fixed"))
    iid_oos = q("select max(id) from items")[0][0]
    th = q("select id from chat_threads where customer_id=17 and biz_id=?", (BIZ,))
    if th:
        tid = th[0][0]
    else:
        q("insert into chat_threads(biz_id,customer_id,status,created,last_activity) "
          "values(?,?,'open',datetime('now'),datetime('now'))", (BIZ, 17))
        tid = q("select max(id) from chat_threads")[0][0]

    print("── F1 صفحهٔ چت مشتری")
    cust = login(C_PHONE)
    st, pg, _ = go(cust, f"/me/chat/{tid}")
    check("F1.1", "فرم سریع هست", 'id="stock-quick"' in pg)
    check("F1.2", "چیپ کالای ناموجود با نشان «ناموجود»",
          f'value="{iid_oos}"' in pg and "ناموجود</small>" in pg)
    check("F1.3", "استپر تعداد + فیلد یادداشت", "data-qty-step" in pg and 'name="note"' in pg)
    check("F1.4", "دکمهٔ تکرار مخفی تا زمانی که آخرینی هست", 'id="stock-repeat" hidden' in pg)

    print("── F2 ارسال کامل")
    st, _, url = go(cust, f"/me/chat/{tid}/notify-me",
                    {"item_id": iid_oos, "qty": "3", "note": "سایز بزرگ لطفاً"})
    row = q("select item_id, qty, note, source, status from stock_requests "
            "where biz_id=? and customer_id=17 order by id desc limit 1", (BIZ,))
    check("F2.1", "ردیف درخواست با کالا/تعداد/یادداشت/chat",
          bool(row) and row[0][0] == iid_oos and row[0][1] == 3
          and row[0][2] == "سایز بزرگ لطفاً" and row[0][3] == "chat" and row[0][4] == "open",
          str(row))
    check("F2.2", "ریدایرکت ok", "ok=" in url, url)
    card = q("select body from chat_messages where thread_id=? and body like '🔔%' "
             "order by id desc limit 1", (tid,))
    check("F2.3", "کارت در رشتهٔ چت: کالا + تعداد + یادداشت",
          bool(card) and "qa-oos-item" in card[0][0] and "تعداد: ۳" in card[0][0]
          and "سایز بزرگ" in card[0][0], str(card)[:120])

    print("── F3 یکتایی")
    st, _, url = go(cust, f"/me/chat/{tid}/notify-me",
                    {"item_id": iid_oos, "qty": "1", "note": ""})
    check("F3.1", "تکرار باز → err و ردیف تازه نمی‌سازد",
          "err=" in url and q("select count(*) from stock_requests where biz_id=? and customer_id=17",
                              (BIZ,))[0][0] == 1, url)

    print("── F4 پنل فراخوان دکاندار")
    own = login(O_PHONE)
    st, br, _ = go(own, "/my/broadcast")
    check("F4.1", "عنوان کالا + تعداد + یادداشت در فراخوان",
          "qa-oos-item" in br and "تعداد:" in br and "سایز بزرگ لطفاً" in br)

    print("── F5 سنجاق مقدارها")
    q("delete from stock_requests where biz_id=? and customer_id=17", (BIZ,))
    go(cust, f"/me/chat/{tid}/notify-me", {"item_id": iid_oos, "qty": "0", "note": "x" * 300})
    row = q("select qty, length(note) from stock_requests where biz_id=? and customer_id=17",
            (BIZ,))[-1]
    check("F5.1", "qty=0 → 1 و note ≤140", row[0] == 1 and row[1] <= 140, str(row))
    q("delete from stock_requests where biz_id=? and customer_id=17", (BIZ,))
    go(cust, f"/me/chat/{tid}/notify-me", {"item_id": iid_oos, "qty": "500", "note": ""})
    row = q("select qty from stock_requests where biz_id=? and customer_id=17", (BIZ,))[-1]
    check("F5.2", "qty=500 → 99", row[0] == 99, str(row))
    q("delete from stock_requests where biz_id=? and customer_id=17", (BIZ,))

    print("── F6 E2E مرورگر")
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        br = pw.chromium.launch()
        ctx = br.new_context(viewport={"width": 360, "height": 740})
        jar = [h for h in cust.handlers if isinstance(h, urllib.request.HTTPCookieProcessor)][0].cookiejar
        for ck in jar:
            ctx.add_cookies([{"name": ck.name, "value": ck.value,
                              "domain": "127.0.0.1", "path": ck.path or "/"}])
        pg = ctx.new_page()
        pg.goto(BASE + f"/me/chat/{tid}", wait_until="networkidle")
        pg.locator(f'.stock-chip input[value="{iid_oos}"]').check()
        pg.locator('[data-qty-step="1"]').click()
        pg.locator('[data-qty-step="1"]').click()
        pg.fill("#stock-note", "تا جمعه لازم دارم")
        qty_val = pg.locator("#stock-qty").input_value()
        check("F6.1", "استپر کار می‌کند (۱→۳)", qty_val == "3", qty_val)
        pg.locator("#stock-quick button[type=submit]").click()
        pg.wait_for_load_state("networkidle")
        check("F6.2", "بازگشت با ok", "ok=" in pg.url, pg.url)
        body_txt = pg.locator("body").inner_text()
        check("F6.3", "کارت درخواست در صفحهٔ چت دیده می‌شود",
              "درخواست موجودی" in body_txt and "تا جمعه لازم دارم" in body_txt)
        pg.screenshot(path="shots-brand/stock-fast.png")
        br.close()

    cleanup()
    q("delete from items where id=?", (iid_oos,))
    red = [r for r in RESULTS if not r[1]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(red)} | قرمز: {len(red)}")
    return 1 if red else 0

if __name__ == "__main__":
    sys.exit(main())
