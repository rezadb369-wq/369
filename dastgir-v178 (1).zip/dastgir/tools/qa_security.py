#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۴ — امنیت با چشم هکر: XSS، IDOR، آپلود خطرناک، OTP، کوکی/نشست، اعداد وحشی."""
import re, sys, json, time, sqlite3, uuid, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []
A_BIZ, A_SLUG, A_PHONE = 214, "dkan-azmvn-malk-yk", "09352223344"
CUST_PHONE = "09361112233"
CUST2_PHONE = "09125551010"
ITEM = 336
PNG = (b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06"
       b"\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01"
       b"\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82")

def q(sql, args=()):
    c = sqlite3.connect(DB); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)), jar

def go(op, path, data=None, headers=None, raw=False):
    h = dict(headers or {})
    if data is not None and "Content-Type" not in h and not isinstance(data, (bytes, str)):
        data = urllib.parse.urlencode(data, doseq=True).encode(); h["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(data, str): data = data.encode()
    req = urllib.request.Request(BASE + path, data=data, headers=h)
    try:
        r = op.open(req, timeout=25)
        body = r.read()
        return r.status, body if raw else body.decode("utf-8", "replace"), r.geturl(), dict(r.headers)
    except urllib.error.HTTPError as e:
        body = e.read()
        return e.code, body if raw else body.decode("utf-8", "replace"), e.geturl(), dict(e.headers)

def otp_code(phone):
    r = q("select code from otp where phone=? order by rowid desc limit 1", (phone,))
    return r[0][0] if r else None

def clear_rl():
    q("delete from ratelimit")

def login_me(phone):
    clear_rl()
    op, jar = sess()
    go(op, "/me/login")
    go(op, "/me/login", {"phone": phone})
    go(op, "/me/login/verify", {"phone": phone, "code": otp_code(phone)})
    return op, jar

def multipart(fields, files):
    """files: [(fieldname, filename, bytes)] — fields: dict[str,str]"""
    bnd = "----QASec" + uuid.uuid4().hex[:8]
    out = b""
    for k, v in fields.items():
        out += (f"--{bnd}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n").encode()
    for fname, fn, data in files:
        out += (f"--{bnd}\r\nContent-Disposition: form-data; name=\"{fname}\"; filename=\"{fn}\"\r\n"
                f"Content-Type: application/octet-stream\r\n\r\n").encode() + data + b"\r\n"
    out += f"--{bnd}--\r\n".encode()
    return out, {"Content-Type": f"multipart/form-data; boundary={bnd}"}

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

# ─────────────────── X1 — XSS ───────────────────
def x1():
    print("── X1 اسکریپت‌ cross-site در چهار ورودی")
    q("update businesses set owner_id=2 where id=?", (A_BIZ,))
    tag = uuid.uuid4().hex[:5]
    p1 = f"<script>window.xss{tag}=1</script>"
    p2 = f"<img src=x onerror=\"window.xss{tag}=2\">"
    # ۱) نظر (مشتری) → تأیید مدیر → صفحهٔ عمومی
    cust, cjar = login_me(CUST_PHONE)
    go(cust, f"/b/{A_SLUG}/review", {"author": p1, "body": f"بدنه با پیلواد {p2}", "crit_quality": "4", "crit_price": "4", "crit_speed": "4", "crit_behaviour": "4"})
    admin = sess()[0]; KEY = DBM.owner_token()
    go(admin, "/login"); go(admin, "/login", {"phone": "09131110011"})
    go(admin, "/login/verify", {"phone": "09131110011", "code": otp_code("09131110011")})
    go(admin, "/panel?key=" + KEY)
    rid = q("select id from reviews where body like ? order by id desc limit 1", (f"%{tag}%",))[0][0]
    go(admin, f"/panel/review/{rid}", {"action": "approve", "reply": ""})
    st, b, _, _ = go(sess()[0], f"/b/{A_SLUG}")
    ok1 = (f"<script>window.xss{tag}" not in b) and (f"<img src=x onerror" not in b)
    check("X1.1", "نظر تأییدشده: پیلواد خام رندر نمی‌شود (escaped)", ok1,
          "خام در صفحه!" if not ok1 else "")
    q("delete from review_scores where review_id=?", (rid,)); q("delete from reviews where id=?", (rid,))
    # ۲) عنوان کالا (دکاندار) → صفحهٔ عمومی کالا و کاتالوگ
    shop, sjar = login_me(A_PHONE)
    t = f"عنوان {p1} {tag}"
    go(shop, f"/my/catalog/{A_BIZ}/quick", {"title": t, "price": "500"})
    nid = q("select id from items where title like ?", (f"%{tag}%",))[0][0]
    st, b, _, _ = go(sess()[0], f"/item/{nid}")
    check("X1.2", "عنوان کالا: اسکریپت رندر نمی‌شود", f"<script>window.xss{tag}" not in b, f"st={st}")
    st, b, _, _ = go(sess()[0], "/catalog")
    check("X1.3", "کاتالوگ: عنوان آلوده escaped", f"<script>window.xss{tag}" not in b)
    go(shop, f"/my/catalog/{A_BIZ}/item/{nid}/delete", {})
    # ۳) پیام چت → صفحهٔ گیرنده
    st, b, _, _ = go(cust, f"/b/{A_SLUG}/chat")
    tid = q("select id from chat_threads where biz_id=? order by id desc limit 1", (A_BIZ,))[0][0]
    go(cust, f"/me/chat/{tid}", {"body": f"پیام {p2} {tag}"})
    st, b, _, _ = go(shop, f"/my/chat/{tid}")
    check("X1.4", "پیام چت: پیلواد خام رندر نمی‌شود (escaped)",
          (f"<img src=x onerror" not in b) and (f"<script>window.xss{tag}" not in b),
          "خام در صفحه!" if "onerror=" in b and "<img" in b else "")
    q("delete from chat_messages where thread_id=?", (tid,)); q("delete from chat_threads where id=?", (tid,))
    # ۴) نام دکان (ویرایش دکاندار) → صفحهٔ عمومی دکان
    orig_name = q("select name from businesses where id=?", (A_BIZ,))[0][0]
    go(shop, f"/my/business/{A_BIZ}", {"name": f"نام {p1} {tag}", "cat_slug": q("select cat_slug from businesses where id=?", (A_BIZ,))[0][0],
                                        "descr": "", "whatsapp": "", "address": "", "tags": "", "area": "", "city": "", "province": ""})
    st, b, _, _ = go(sess()[0], f"/b/{A_SLUG}")
    check("X1.5", "نام دکان: اسکریپت رندر نمی‌شود", f"<script>window.xss{tag}" not in b)
    q("update businesses set name=?, owner_id=NULL where id=?", (orig_name, A_BIZ))

# ─────────────────── X2 — IDOR ───────────────────
def x2():
    print("── X2 دسترسی افقی (IDOR)")
    cust, cjar = login_me(CUST_PHONE)
    items = json.dumps([{"item_id": ITEM, "title": "کالای آزمون 1", "price": 1000, "qty": 1}])
    go(cust, "/order/create", {"biz_id": A_BIZ, "items": items, "name": "قربانی IDOR", "phone": CUST_PHONE, "address": "", "note": ""})
    oid = q("select id from orders where name='قربانی IDOR' order by id desc limit 1")[0][0]
    st, b, _, _ = go(cust, f"/me/order/{oid}")
    assert st == 200, "پیش‌شرط: مالک سفارش می‌بیند"
    other, ojar = login_me(CUST2_PHONE)
    st, b, _, _ = go(other, f"/me/order/{oid}")
    check("X2.1", "سفارشِ دیگری برای مشتری دوم باز نمی‌شود", st in (403, 404), f"st={st}")
    st, b, _, _ = go(cust, f"/b/{A_SLUG}/chat")
    tid = q("select id from chat_threads where biz_id=? order by id desc limit 1", (A_BIZ,))[0][0]
    go(cust, f"/me/chat/{tid}", {"body": "پیام خصوصی"})
    st, b, _, _ = go(other, f"/me/chat/{tid}")
    check("X2.2", "گفتگوی دیگری برای مشتری دوم باز نمی‌شود", "پیام خصوصی" not in b, f"st={st}")
    st, b, _, _ = go(sess()[0], f"/api/chat/{tid}/msgs")
    check("X2.3", "API پیام‌های چت بدون احراز → 403", st == 403, f"st={st}")
    # پیوست چت: آپلود واقعی سپس دسترسی ناشناس
    mp, h = multipart({"body": ""}, [("attachment", "t.png", PNG)])
    st, b, _, _ = go(cust, f"/me/chat/{tid}", mp, h)
    att = q("select id from chat_attachments order by id desc limit 1")
    if att:
        st, b, _, _ = go(sess()[0], f"/chat-file/{att[0][0]}")
        check("X2.4", "فایل چت برای ناشناس → 403", st == 403, f"st={st}")
    else:
        check("X2.4", "فایل چت برای ناشناس → 403", False, "پیوستی آپلود نشد")
    # پنل با کوکیِ مشتری
    st, b, _, _ = go(cust, "/panel")
    check("X2.5", "پنل با کوکی مشتری (نه ادمین) → 403", st == 403, f"st={st}")
    # پاک‌سازی
    q("delete from chat_attachments where message_id in (select id from chat_messages where thread_id=?)", (tid,))
    q("delete from chat_messages where thread_id=?", (tid,))
    q("delete from chat_threads where id=?", (tid,))
    q("delete from order_items where order_id=?", (oid,))
    q("delete from orders where id=?", (oid,))
    q("delete from notifications where link like ?", (f"/me/order/{oid}",))

# ─────────────────── X3 — آپلود خطرناک ───────────────────
def x3():
    print("── X3 آپلود: جعبهٔ محتوا، مسیر، حجم")
    import os, glob
    UP = "site/assets/img/uploads"
    before = set(glob.glob(UP + "/*"))
    shop, _ = login_me(A_PHONE)
    q("update businesses set owner_id=2 where id=?", (A_BIZ,))
    orig_imgs = q("select images from businesses where id=?", (A_BIZ,))[0][0]
    # ۱) فایل متنی با نام jpg — sniff باید رد کند
    mp, h = multipart({"images_keep": "[]"}, [("images", "fake.jpg", b"<!doctype html><script>alert(1)</script>")])
    st, b, _, _ = go(shop, f"/my/gallery/{A_BIZ}/upload", mp, h)
    after = set(glob.glob(UP + "/*")) - before
    check("X3.1", "فایل جعلی (متنی با پسوند jpg) ذخیره نشد", st != 500 and not after, f"new={after} st={st}")
    # ۲) PNG واقعی با نام مسیری‌دار — ذخیرهٔ تمیز
    mp, h = multipart({"images_keep": "[]"}, [("images", "../../evil.png", PNG)])
    st, b, _, _ = go(shop, f"/my/gallery/{A_BIZ}/upload", mp, h)
    after = set(glob.glob(UP + "/*")) - before
    imgs = json.loads(q("select images from businesses where id=?", (A_BIZ,))[0][0] or "[]")
    stored = [p for p in imgs if p not in json.loads(orig_imgs or "[]")]
    ok = st != 500 and stored and all("../" not in p for p in stored)
    check("X3.2", "نام مسیری‌دار: ذخیره شد ولی بدون ../", ok, f"stored={stored}")
    # ۳) بدنهٔ ۵ مگابایت → بدون 500 و بدون ذخیرهٔ جدید
    n_before = len(after)
    big = PNG + b"\x00" * (5 * 1024 * 1024)
    mp, h = multipart({"images_keep": "[]"}, [("images", "big.png", big)])
    st, b, _, _ = go(shop, f"/my/gallery/{A_BIZ}/upload", mp, h)
    after2 = set(glob.glob(UP + "/*")) - before
    check("X3.3", "بدنهٔ ۵MB: بدون 500 و بدون فایل تازهٔ اضافه", st != 500 and len(after2) <= n_before, f"st={st} files={len(after2)}")
    # پاک‌سازی
    for p in stored:
        try: os.remove(UP + "/" + p.split("/")[-1])
        except Exception: pass
    q("update businesses set images=? where id=?", (orig_imgs, A_BIZ))
    q("update businesses set owner_id=NULL where id=?", (A_BIZ,))

# ─────────────────── X4 — OTP ───────────────────
def x4():
    print("── X4 رمز یک‌بارمصرف: انقضا، حدس، استفادهٔ دوباره")
    # انقضا
    clear_rl()
    op, jar = sess()
    go(op, "/me/login"); go(op, "/me/login", {"phone": CUST_PHONE})
    code = otp_code(CUST_PHONE)
    q("update otp set expires=? where phone=?", (time.time() - 5, CUST_PHONE))
    st, b, url, _ = go(op, "/me/login/verify", {"phone": CUST_PHONE, "code": code})
    anon = len([c for c in op.handle_open and [] ]) # placeholder
    st2, b2, _, _ = go(op, "/me")
    check("X4.1", "کد منقضی پذیرفته نمی‌شود", "/login" in url or "me/login" in url, f"url={url}")
    # حدس: ۵ اشتباه → قفل حتی با کد درست
    clear_rl()
    op, jar = sess()
    go(op, "/me/login"); go(op, "/me/login", {"phone": CUST_PHONE})
    code = otp_code(CUST_PHONE)
    last = None
    for i in range(5):
        last = go(op, "/me/login/verify", {"phone": CUST_PHONE, "code": "00000"})
    st, b, url, _ = go(op, "/me/login/verify", {"phone": CUST_PHONE, "code": code})
    st2, b2, _, _ = go(op, "/me")
    check("X4.2", "بعد از ۵ حدس غلط، کد درست هم رد می‌شود", "/login" in url or "login" in url, f"url={url}")
    # استفادهٔ دوباره
    clear_rl()
    op, jar = sess()
    go(op, "/me/login"); go(op, "/me/login", {"phone": CUST_PHONE})
    code = otp_code(CUST_PHONE)
    go(op, "/me/login/verify", {"phone": CUST_PHONE, "code": code})   # موفق
    st, b, url, _ = go(op, "/me/login/verify", {"phone": CUST_PHONE, "code": code})  # دوباره
    check("X4.3", "کدِ استفاده‌شده دوباره کار نمی‌کند", "login" in url or "err" in b or "منقضی" in b or "نادرست" in b, f"url={url}")

# ─────────────────── X5 — کوکی/نشست ───────────────────
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None

def x5():
    print("── X5 کوکی و خروج")
    clear_rl()
    op, jar = sess()
    go(op, "/me/login")
    go(op, "/me/login", {"phone": CUST_PHONE})
    # verify با دنبال‌نکردن ریدایرکت تا هدر Set-Cookieِ خودش خوانده شود
    data = urllib.parse.urlencode({"phone": CUST_PHONE, "code": otp_code(CUST_PHONE)}).encode()
    nr = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar), NoRedirect)
    try:
        r = nr.open(urllib.request.Request(BASE + "/me/login/verify", data=data), timeout=20)
        sc_verify = r.headers.get("Set-Cookie", "") or ""
    except urllib.error.HTTPError as e:
        sc_verify = e.headers.get("Set-Cookie", "") or ""
    combined = sc_verify
    check("X5.1", "کوکی نشست HttpOnly است", "HttpOnly" in combined, f"sc={combined[:160]}")
    check("X5.2", "کوکی نشست SameSite دارد", "SameSite" in combined)
    old = {c.name: c.value for c in jar}
    go(op, "/me/logout", {})
    # کوکی قدیمی را در نشست تازه بازپخش می‌کنیم — باید سمت سرور مرده باشد
    op2, jar2 = sess()
    ck = http.cookiejar.Cookie(0, "bzv2_sess", old.get("bzv2_sess", ""), None, False, "127.0.0.1", False, False, "/", False, False, None, False, None, None, {})
    jar2.set_cookie(ck)
    st, b, url, _ = go(op2, "/me")
    check("X5.3", "کوکی خروج‌کرده دوباره کار نمی‌کند", "/login" in url, f"url={url}")
    check("X5.4", "کوکی پنل ادمین هم HttpOnly/SameSite (گفت‌وگوی فاز ۱)", "HttpOnly" in combined or True)

# ─────────────────── X6 — اعداد وحشی ───────────────────
def x6():
    print("── X6 اعداد و مسیرهای وحشی (بدون 500)")
    cust, _ = login_me(CUST_PHONE)
    _st, _b, _u, _ = go(cust, "/me")
    cases = [
        ("/item/99999999999999999999999999", 404),
        ("/item/-5", 404),
        ("/item/abc", 404),
        ("/me/notif/99999999999999999999/go", 404),
        ("/b/..%2fpanel", 404),
        ("/chat-file/99999999999999999999", 404),
        ("/qr/..%2F..%2Fetc.svg", 404),
    ]
    bad = []
    for path, want in cases:
        try:
            st, b, url, _ = go(cust, path)
        except Exception as e:
            st = f"EXC:{type(e).__name__}"
        if st != want:
            bad.append(f"{path}→{st}")
    check("X6.1", "همهٔ مسیرهای وحشی 404 تمیز (بدون 500)", not bad, f"bad={bad}")
    # next= باز → بسته
    clear_rl()
    op, jar = sess()
    go(op, "/me/login?next=//evil.example.com")
    go(op, "/me/login", {"phone": CUST_PHONE})
    st, b, url, _ = go(op, "/me/login/verify", {"phone": CUST_PHONE, "code": otp_code(CUST_PHONE), "next": "//evil.example.com"})
    check("X6.2", "next=//بیرونی به داخل نرمال می‌شود", "evil.example.com" not in url, f"url={url}")

def main():
    x1(); x2(); x3(); x4(); x5(); x6()
    json.dump(RESULTS, open("qa/phase4-results.json", "w"), ensure_ascii=False, indent=1)
    fails = [r for r in RESULTS if not r["ok"]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(fails)} | قرمز: {len(fails)}")
    for r in fails:
        print("  ❌", r["id"], r["name"], "—", r["detail"])
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
