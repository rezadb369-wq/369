#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Remaining requested features: nav, ticket-only support, map search, product/order."""
import base64, json, os, sys, urllib.error, urllib.parse, urllib.request
HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.abspath(os.path.join(HERE,'..'))
sys.path.insert(0,os.path.join(ROOT,'server')); import db, uploads
BASE=os.environ.get('BZ','http://127.0.0.1:8080').rstrip('/'); PREFIX='v76-final-probe'
PASS=[];FAIL=[]
def check(n,c,d=''):
 (PASS if c else FAIL).append((n,d)); print(('  ✓ ' if c else '  ✗ ')+n+(f' [{d}]' if d and not c else ''))
class NR(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**k): return None
def req(path,method='GET',data=None,cookie='',headers=None):
 h={'User-Agent':'v76-audit',**(headers or {})};
 if cookie:h['Cookie']=cookie
 try:
  r=urllib.request.build_opener(NR()).open(urllib.request.Request(BASE+path,data=data,method=method,headers=h),timeout=30);return r.status,dict(r.headers),r.read()
 except urllib.error.HTTPError as e:return e.code,dict(e.headers),e.read()
def multipart(fields,file_field=None,filename='',payload=b''):
 b='----v76boundary'; parts=[]
 for k,v in fields.items():parts.append(f'--{b}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
 if file_field:parts.append(f'--{b}\r\nContent-Disposition: form-data; name="{file_field}"; filename="{filename}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()+payload+b'\r\n')
 parts.append(f'--{b}--\r\n'.encode());return b''.join(parts),{'Content-Type':f'multipart/form-data; boundary={b}'}
def clean():
 for b in db.businesses(status=None):
  if b['name'].startswith(PREFIX):db.delete_business(b['id'])
 for p in ('09129997901','09129997902','09129997903'):
  c=db.customer_by_phone(p)
  if c:db.customer_delete(c['id'])
  o=db.owner_by_phone(p)
  if o:db.delete_owner(o['id'])
def setup():
 db.init();clean();cat=db.categories()[0]['slug'];o=db.owner_by_phone('09129997901',True);c=db.customer_by_phone('09129997902',True);o2=db.owner_by_phone('09129997903',True)
 bid=db.save_business({'name':PREFIX+' shop','cat_slug':cat,'status':'published','phone':o['phone'],'owner_id':o['id'],'lat':32.634,'lng':51.366,'address':'نشانی آزمون'})
 iid=db.save_item({'biz_id':bid,'kind':'product','title':PREFIX+' product','descr':'شرح کامل محصول','price':125000,'price_type':'fixed','available':1,'spec':'رنگ=سبز؛وزن=۱ کیلو'})
 oid=db.create_order(bid,c['id'],'کاربر سفارش','', 'نشانی','',[{'item_id':iid,'title':PREFIX+' product','price':125000,'qty':2}])
 return {'o':o,'o2':o2,'c':c,'b':db.business(bid=bid),'i':db.item(iid),'oid':oid,'oc':'bzv2_sess='+db.session_new(o['id']),'o2c':'bzv2_sess='+db.session_new(o2['id']),'cc':'bzv2_cust='+db.customer_session_new(c['id']),'key':db.owner_token()}
def nav_support(f):
 print('\n══ ۱) نوار شناور و پشتیبانی فقط تیکت ══')
 _,_,home=req('/');h=home.decode();bottom=h.split('<nav class="bottom-nav"',1)[1].split('</nav>',1)[0] if '<nav class="bottom-nav"' in h else ''
 check('نوار پنج مقصد دارد و خانه فعال است',bottom.count('<a ')==5 and 'href=&quot;/&quot;' in bottom or bottom.count('<a ')==5 and 'href="/"' in bottom,str(bottom.count('<a ')))
 check('ویجت فقط تیکت است و تماس/واتساپ ندارد','تیکت پشتیبانی' in h and '/my/tickets' in h and 'wa.me' not in h.split('id="support-panel"',1)[-1] and 'tel:' not in h.split('id="support-panel"',1)[-1],'widget')
 _,_,contact=req('/contact');ct=contact.decode();check('صفحه تماس فقط به تیکت هدایت می‌کند','action="/contact"' not in ct and '/my/tickets' in ct,'contact form remains')
 from playwright.sync_api import sync_playwright
 with sync_playwright() as p:
  br=p.chromium.launch();ctx=br.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);pg=ctx.new_page();pg.goto(BASE,wait_until='networkidle');m=pg.evaluate("""()=>{let n=document.querySelector('.bottom-nav').getBoundingClientRect(),a=document.querySelector('.bottom-nav [aria-current=page]').getBoundingClientRect();return {n:[n.left,n.right,n.top,n.bottom],r:getComputedStyle(document.querySelector('.bottom-nav')).borderRadius,a:[a.width,a.height],over:document.documentElement.scrollWidth-document.documentElement.clientWidth}}""");check('نوار شیشه‌ای تمام‌عرض با هدف ۴۴px است',m['n'][0]>=0 and m['n'][1]<=390 and m['a'][1]>=44 and m['a'][0]>=44 and m['over']<=0,str(m));ctx.close();br.close()
def tickets_attach(f):
 print('\n══ ۲) پیوست امن تیکت و اتصال مدیر ══')
 cols={r['name'] for r in db.connect().execute('PRAGMA table_info(ticket_attachments)')};check('جدول پیوست تیکت وجود دارد',{'msg_id','stored_name','original_name','mime','size'}<=cols,str(cols))
 code,_,page=req('/my/tickets',cookie=f['oc']);check('فرم تیکت multipart و فایل دارد',code==200 and b'enctype="multipart/form-data"' in page and b'name="attachment"' in page,str(code))
 PNG_1PX=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==')
 body,head=multipart({'topic':'bug','subject':'مشکل پیوست آزمون','body':'شرح کامل مشکل برای مدیر'},'attachment','evidence.png',PNG_1PX)
 code,h,_=req('/my/tickets','POST',body,f['oc'],head);check('مالک تیکت همراه فایل می‌سازد',code==303,str(code));rows=db.tickets(owner_id=f['o']['id']);t=rows[0] if rows else None;check('تیکت در پنل مدیر متصل است',bool(t and t['unread_admin']),str(t))
 msgs=db.ticket_msgs(t['id']) if t else [];att=next((m.get('attachment_id') for m in msgs if m.get('attachment_id')),None);check('متادیتای عمومی فایل روی پیام است',bool(att),str(msgs))
 if att:
  own=req(f'/ticket-file/{att}',cookie=f['oc']);foreign=req(f'/ticket-file/{att}',cookie=f['o2c']);admin=req(f'/ticket-file/{att}?key={f["key"]}')
  check('فایل فقط برای صاحب و مدیر باز است',own[0]==200 and foreign[0]==403 and admin[0]==200,str((own[0],foreign[0],admin[0])))
  check('فایل تیکت cache خصوصی دارد',dict((k.lower(),v) for k,v in own[1].items()).get('cache-control')=='private, no-store',str(own[1]))
 bad,head=multipart({'topic':'bug','subject':'فایل بد','body':'متن کافی برای فایل بد'},'attachment','evil.svg',b'<svg><script>x</script></svg>');n=len(db.tickets(owner_id=f['o']['id']));code,_,_=req('/my/tickets','POST',bad,f['oc'],head);check('فایل فعال تیکت رد و تیکت جعلی ساخته نمی‌شود',code==303 and len(db.tickets(owner_id=f['o']['id']))==n,str(code))
def map_search(f):
 print('\n══ ۳) نقشه، جست‌وجوی دسته، کنترل زوم و راهنما ══')
 _,_,mp=req('/map');_,_,nr=req('/nearby');check('نقشه و نزدیک من دستهٔ جست‌وجوشونده دارند',b'data-catpick' in mp and b'data-catpick' in nr and b'catpicker.js' in mp and b'catpicker.js' in nr,'markup')
 from playwright.sync_api import sync_playwright
 with sync_playwright() as p:
  br=p.chromium.launch();ctx=br.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,geolocation={'latitude':32.634,'longitude':51.366},permissions=['geolocation']);pg=ctx.new_page();pg.goto(BASE+'/map',wait_until='networkidle');pg.wait_for_timeout(1200)
  picker=pg.locator('.catpick-btn')
  if picker.count():
   picker.click();pg.locator('.catpick-search input').fill('نانوایی');pg.wait_for_timeout(100);check('جست‌وجوی دسته در نقشه نتیجه می‌دهد',pg.locator('.catpick-item').count()>0,str(pg.locator('.catpick-item').count()));pg.locator('.catpick-close').click()
  else: check('جست‌وجوی دسته در نقشه نتیجه می‌دهد',False,'picker missing')
  row=pg.locator(f'[data-focus="{f["b"]["slug"]}"]');
  if row.count():row.click();pg.wait_for_timeout(150)
  m=pg.evaluate("""()=>{let z=document.querySelector('.leaflet-control-zoom a'),s=document.querySelector('[data-map-selected]'),l=document.querySelector('.map-legend');let zr=z?.getBoundingClientRect(),sr=s?.getBoundingClientRect(),lr=l?.getBoundingClientRect(),ps=z?getComputedStyle(z,'::before'):null;return {zoom:zr&&[zr.width,zr.height],inner:ps&&[parseFloat(ps.width)||999,parseFloat(ps.height)||999,ps.fontSize],selected:sr&&[sr.top,sr.bottom],legend:lr&&[lr.top,lr.bottom],overflow:document.documentElement.scrollWidth-document.documentElement.clientWidth}}""")
  check('زوم ظاهر کوچک ولی سطح لمس امن دارد',m['zoom'] and m['zoom'][0]>=44 and m['inner'][0]<=30,str(m))
  check('راهنما با کارت انتخابی همپوشانی ندارد',m['selected'] and m['legend'] and (m['legend'][1]<=m['selected'][0]+2 or m['selected'][1]<=m['legend'][0]+2),str(m));check('نقشه موبایل سرریز ندارد',m['overflow']<=0,str(m));ctx.close();br.close()
def products_orders(f):
 print('\n══ ۴) محصول واقعی، تعداد، رضایت تلفن و لغو سفارش ══')
 _saved_prices = db.get_settings().get('prices_enabled', '1')  # v155: hermetic
 db.set_setting('prices_enabled','1')
 code,_,html=req(f'/item/{f["i"]["id"]}');text=html.decode();check('صفحه کامل محصول باز می‌شود',code==200 and 'data-item-detail' in text and f['i']['title'] in text,str(code));check('نام فروشگاه لینک مستقیم دارد',f'/b/{f["b"]["slug"]}' in text and 'data-cart-qty' in text,'detail')
 _,_,cat=req('/catalog?q='+urllib.parse.quote(PREFIX));c=cat.decode();check('کارت و عنوان محصول به جزئیات لینک‌اند',f'/item/{f["i"]["id"]}' in c,'catalog')
 cartjs=open(os.path.join(ROOT,'site','assets','js','cart.js'),encoding='utf-8').read();check('فرم سفارش نام اجباری، تلفن اختیاری و رضایت دارد','name="name"' in cartjs and 'name="phone"' in cartjs and 'name="share_phone"' in cartjs and 'name="phone" type="tel" dir="ltr" required' not in cartjs,'cart')
 cols={r['name'] for r in db.connect().execute('PRAGMA table_info(orders)')};check('ستون‌های درخواست لغو و رضایت تلفن وجود دارند',{'share_phone','cancel_requested','cancel_reason','cancel_requested_at','cancel_decided_at'}<=cols,str(cols))
 check('تابع درخواست/تصمیم لغو وجود دارد',hasattr(db,'request_order_cancel') and hasattr(db,'decide_order_cancel'))
 if hasattr(db,'request_order_cancel'):
  direct=db.request_order_cancel(f['oid'],f['c']['id'],'اشتباه ثبت شد');check('لغو داخل زمان مستقیم است',direct.get('result')=='cancelled' and db.order(f['oid'])['status']=='cancelled',str(direct))
  oid2=db.create_order(f['b']['id'],f['c']['id'],'قدیمی','', '', '',[{'item_id':f['i']['id'],'title':f['i']['title'],'price':125000,'qty':1}]);db._run("UPDATE orders SET created=datetime('now','-2 hours') WHERE id=?",(oid2,));late=db.request_order_cancel(oid2,f['c']['id'],'دیگر نیاز ندارم');check('بعد از مهلت درخواست برای دکان‌دار می‌رود',late.get('result')=='requested' and db.order(oid2).get('cancel_requested'),str(late));dec=db.decide_order_cancel(oid2,f['o']['id'],True);check('قبول دکان‌دار سفارش را لغو می‌کند',dec and db.order(oid2)['status']=='cancelled',str(db.order(oid2)))
 _,_,own=req('/my/orders',cookie=f['oc']);_,_,adm=req('/panel/orders?key='+f['key']);check('لغو و رضایت به پنل مالک و مدیر متصل است',(b'cancel' in own.lower() or 'لغو'.encode() in own) and (b'cancel' in adm.lower() or 'لغو'.encode() in adm),'panels');db.set_setting('prices_enabled', _saved_prices)  # v155: restore
def main():
 f=setup()
 try:nav_support(f);tickets_attach(f);map_search(f);products_orders(f)
 finally:clean()
 print('\n'+'═'*60);print(f'  {len(PASS)} موفق، {len(FAIL)} ناموفق');[print('  ✗',n,d) for n,d in FAIL];print('═'*60);return 1 if FAIL else 0
if __name__=='__main__':sys.exit(main())
