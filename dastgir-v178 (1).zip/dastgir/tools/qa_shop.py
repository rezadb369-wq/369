#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۲ — دکاندار: کالا، سفارش، چت، نظر، تیکت، سهمیهٔ پلن، مرزهای مالکیت.
هر تست اثر واقعی را در پایگاه/صفحهٔ عمومی بررسی می‌کند و تمیزکاری برمی‌گرداند."""
import re, sys, json, sqlite3, uuid, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []
A_BIZ, A_SLUG, A_PHONE = 214, "dkan-azmvn-malk-yk", "09352223344"
B_BIZ, B_SLUG, B_PHONE = 215, "dkan-azmvn-malk-dv", "09134950001"
CUST_PHONE = "09361112233"

def q(sql, args=()):
    c = sqlite3.connect(DB); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None, headers=None, raw=False):
    h = dict(headers or {})
    if data is not None and "Content-Type" not in h and not isinstance(data, (bytes, str)):
        data = urllib.parse.urlencode(data, doseq=True).encode(); h["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(data, str): data = data.encode()
    req = urllib.request.Request(BASE + path, data=data, headers=h)
    try:
        r = op.open(req, timeout=25)
        body = r.read()
        return r.status, body if raw else body.decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        body = e.read()
        return e.code, body if raw else body.decode("utf-8", "replace"), e.geturl()

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def clear_rl():
    q("delete from ratelimit where bucket like 'otp%' or bucket like 'rv:%' or bucket like 'hg:%' or bucket like 'ord:%'")

def login_me(phone):
    clear_rl()
    op = sess()
    go(op, "/me/login")
    go(op, "/me/login", {"phone": phone})
    go(op, "/me/login/verify", {"phone": phone, "code": otp_code(phone)})
    return op

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

# ─────────────────── S1 دسترسی و ورود ───────────────────
def s1():
    print("── S1 دسترسی دکاندار")
    anon = sess()
    st, b, url = go(anon, "/my")
    check("S1.1", "بی‌login → /my به صفحهٔ ورود می‌فرستد", "/login?next=" in url, f"url={url} st={st}")
    op = login_me(A_PHONE)
    st, b, url = go(op, "/my")
    check("S1.2", "دکاندار وارد شد → داشبورد /my 200", st == 200, f"st={st}")
    check("S1.3", "دکانِ خودش (A) در داشبورد است", "دکانٔ آزمون مالک یک" in b)
    return op

# ─────────────────── S2 کالا + سهمیهٔ پلن ───────────────────
def s2(op):
    print("── S2 کالا: سهمیهٔ پلن (بنیان‌گذار=۱۰) + افزودن/ویرایش/حذف")
    # پاک‌سازی ران‌های قبلی همین آزمون
    q("delete from items where title like 'پرکنندهٔ سقف%' or title like 'کالای فراتر از سقف%'")
    lim = DBM.access(A_BIZ)["max_items"]
    n0 = q("select count(*) from items where biz_id=?", (A_BIZ,))[0][0]
    for i in range(n0, lim):   # پرکردن تا سقف با ردیف مستقیم (بدون محدودیت نرخ)
        q("insert into items(biz_id,kind,title,descr,price,price_type) values(?,?,?,?,?,?)",
          (A_BIZ, "product", f"پرکنندهٔ سقف {i}", "", 1000, "fixed"))
    st, b, url = go(op, f"/my/catalog/{A_BIZ}/item/new",
                    {"title": "کالای فراتر از سقف", "price": "100", "descr": "", "price_type": "fixed", "tags": ""})
    n1 = q("select count(*) from items where biz_id=?", (A_BIZ,))[0][0]
    check("S2.1", f"سقف پلن ({lim} قلم): افزودن {lim+1}اُم رد شد", n1 == lim and "سقف پلن" in b, f"lim={lim} n1={n1} url={url}")
    # ارتقای موقت به plus
    q("insert into subscriptions(biz_id,plan_slug,status,starts,expires) values(?,?,?,?,?)",
      (A_BIZ, "plus", "active", "2026-09-05", "2027-09-05"))
    tmp = "کالای دکان QA " + uuid.uuid4().hex[:4]
    st, b, url = go(op, f"/my/catalog/{A_BIZ}/item/new",
                    {"title": tmp, "price": "15000", "descr": "تست فاز۲", "price_type": "fixed", "tags": ""})
    row = q("select id from items where title=?", (tmp,))
    check("S2.2", "با پلن plus افزودن کالا انجام شد", row, f"st={st} url={url}")
    if not row: return
    nid = row[0][0]
    st, b, url = go(sess(), f"/item/{nid}")
    check("S2.3", "کالای تازه در صفحهٔ عمومی دیده می‌شود", st == 200 and tmp in b, f"st={st}")
    st, b, url = go(op, f"/my/catalog/{A_BIZ}/item/{nid}",
                    {"title": tmp + "-ویرایش", "price": "20000", "descr": "تست فاز۲", "price_type": "fixed", "tags": ""})
    now = q("select title,price from items where id=?", (nid,))[0]
    check("S2.4", "ویرایش کالا اثر کرد", now[0] == tmp + "-ویرایش" and int(now[1]) == 20000, f"now={now}")
    go(op, f"/my/catalog/{A_BIZ}/item/{nid}/delete", {})
    gone = q("select id from items where id=?", (nid,))
    check("S2.5", "حذف کالا اثر کرد", not gone)
    q("delete from subscriptions where biz_id=?", (A_BIZ,))
    q("delete from items where title like 'پرکنندهٔ سقف%'")

# ─────────────────── S3 سفارش ───────────────────
def s3():
    print("── S3 سفارش: مشتری سفارش می‌دهد، دکاندار وضعیت عوض می‌کند")
    cust = login_me(CUST_PHONE)
    items = json.dumps([{"item_id": 336, "title": "کالای آزمون 1", "price": 1000, "qty": 2}])
    st, b, url = go(cust, "/order/create",
                    {"biz_id": A_BIZ, "items": items, "name": "مشتری آزمون فاز۲",
                     "phone": CUST_PHONE, "address": "تهران", "note": ""})
    o = q("select id,status,customer_id from orders where biz_id=? and name like 'مشتری آزمون فاز۲%' order by id desc limit 1", (A_BIZ,))
    check("S3.1", "ثبت سفارش از سبد مشتری", o and "/order/ok" in url, f"url={url} o={o}")
    if not o: return None
    oid = o[0][0]
    st, b, url = go(login_me(A_PHONE), "/my/orders")
    check("S3.2", "سفارش در فهرست دکاندار است", "مشتری آزمون فاز۲" in b, f"st={st}")
    st, b, url = go(login_me(A_PHONE), f"/my/order/{oid}", {"status": "done"})
    now = q("select status from orders where id=?", (oid,))[0][0]
    check("S3.3", "تغییر وضعیت سفارش توسط دکاندار", now == "done", f"now={now}")
    notif = q("select count(*) from notifications where customer_id=? and link like ?", (o[0][2], f"/me/order/{oid}"))
    check("S3.4", "مشتری از تغییر وضعیت باخبر شد (اعلان)", notif[0][0] >= 1, f"notif={notif}")
    q("delete from order_items where order_id=?", (oid,))
    q("delete from orders where id=?", (oid,))
    q("delete from notifications where link like ?", (f"/me/order/{oid}",))
    return oid

# ─────────────────── S4 چت ───────────────────
def s4():
    print("── S4 چت: مشتری ↔ دکاندار + مرز دکان B")
    cust = login_me(CUST_PHONE)
    t0 = q("select count(*) from chat_threads")[0][0]
    st, b, url = go(cust, f"/b/{A_SLUG}/chat")
    t1 = q("select count(*) from chat_threads")[0][0]
    th = q("select id from chat_threads where biz_id=? and customer_id=(select id from customers where phone=?) order by id desc limit 1", (A_BIZ, CUST_PHONE))
    check("S4.1", "شروع/ادامهٔ گفتگو از صفحهٔ دکان (thread تازه یا موجود)", bool(th) and t1 in (t0, t0 + 1), f"t0={t0} t1={t1} th={th}")
    if not th: return
    tid = th[0][0]
    go(cust, f"/me/chat/{tid}", {"body": "سلام، این کالا موجود است؟"})
    m = q("select count(*) from chat_messages where thread_id=? and sender='customer'", (tid,))[0][0]
    check("S4.2", "پیام مشتری ثبت شد", m >= 1, f"m={m}")
    shopA = login_me(A_PHONE)
    st, b, url = go(shopA, "/my/chats")
    check("S4.3", "گفتگو در فهرست دکاندار", st == 200 and f"/my/chat/{tid}" in b, f"st={st}")
    st, b, url = go(shopA, f"/my/chat/{tid}")
    check("S4.4", "متن پیام مشتری برای دکاندار دیده می‌شود", "موجود است" in b, f"st={st}")
    go(shopA, f"/my/chat/{tid}", {"body": "بله موجود است؛ خوش آمدید."})
    r = q("select count(*) from chat_messages where thread_id=? and sender='owner' and body like 'بله موجود%'", (tid,))[0][0]
    check("S4.5", "پاسخ دکاندار ثبت شد", r == 1, f"r={r}")
    st, b, url = go(cust, f"/me/chat/{tid}")
    check("S4.6", "مشتری پاسخ را می‌بیند", "بله موجود است" in b, f"st={st}")
    shopB = login_me(B_PHONE)
    st, b, url = go(shopB, f"/my/chat/{tid}")
    check("S4.7", "مرز: دکان B به گفتگوی دکان A دسترسی ندارد", "موجود است" not in b, f"st={st} url={url}")
    n0 = q("select count(*) from chat_messages where thread_id=?", (tid,))[0][0]
    go(shopB, f"/my/chat/{tid}", {"body": "پیام نفوذی"})
    n1 = q("select count(*) from chat_messages where thread_id=?", (tid,))[0][0]
    check("S4.8", "مرز: دکان B نمی‌تواند در گفتگوی A پیام بگذارد", n1 == n0, f"n0={n0} n1={n1}")
    q("delete from chat_messages where thread_id=?", (tid,))
    q("delete from chat_threads where id=?", (tid,))

# ─────────────────── S5 نظر ───────────────────
def s5():
    print("── S5 نظر: ثبت مشتری + پاسخ دکاندار + مرز")
    cust = login_me(CUST_PHONE)
    r0 = q("select count(*) from reviews")[0][0]
    go(cust, f"/b/{A_SLUG}/review", {"author": "مشتری آزمون", "body": "تجربهٔ خوبی بود، ممنون", "rating": "5"})
    row = q("select id,status,reply from reviews where biz_id=? and body like 'تجربهٔ خوبی بود، ممنون%' order by id desc limit 1", (A_BIZ,))
    check("S5.1", "نظر مشتری ثبت شد", bool(row), f"row={row}")
    if not row: return
    rid = row[0][0]
    shopA = login_me(A_PHONE)
    go(shopA, f"/my/review/{rid}", {"action": "reply", "reply": "سپاس از شما!"})
    rep = q("select reply from reviews where id=?", (rid,))[0][0]
    check("S5.2", "پاسخ دکاندار به نظر ثبت شد", rep == "سپاس از شما!", f"reply={rep!r}")
    shopB = login_me(B_PHONE)
    go(shopB, f"/my/review/{rid}", {"action": "reply", "reply": "پاسخ نفوذی"})
    rep2 = q("select reply from reviews where id=?", (rid,))[0][0]
    check("S5.3", "مرز: دکان B نتوانست به نظر دکان A پاسخ دهد", rep2 == "سپاس از شما!", f"reply={rep2!r}")
    q("delete from reviews where id=?", (rid,))

# ─────────────────── S6 تیکت پشتیبانی ───────────────────
def s6():
    print("── S6 تیکت دکاندار به پشتیبانی")
    shopA = login_me(A_PHONE)
    t0 = q("select count(*) from tickets")[0][0]
    go(shopA, "/my/tickets", {"subject": "تست تیکت فاز۲", "body": "سؤالی دربارهٔ پلن دارم", "topic": "general"})
    row = q("select id,owner_id from tickets where subject='تست تیکت فاز۲' order by id desc limit 1")
    check("S6.1", "تیکت ساخته شد", row, f"row={row}")
    if not row: return
    tid, owner_id = row[0]
    st, b, url = go(shopA, f"/my/ticket/{tid}")
    check("S6.2", "تیکت برای دکاندار باز می‌شود", st == 200, f"st={st}")
    boundary = "----QAb2"
    mp = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"body\"\r\n\r\nپاسخ پشتیبانی فاز۲\r\n--{boundary}--\r\n").encode()
    import sys as _s; _s.path.insert(0, "server")
    op_admin = sess()
    KEY = DBM.owner_token()
    go(op_admin, "/login"); go(op_admin, "/login", {"phone": "09131110011"})
    go(op_admin, "/login/verify", {"phone": "09131110011", "code": otp_code("09131110011")})
    go(op_admin, "/panel?key=" + KEY)
    go(op_admin, f"/panel/ticket/{tid}", mp, {"Content-Type": f"multipart/form-data; boundary={boundary}"})
    st, b, url = go(shopA, f"/my/ticket/{tid}")
    check("S6.3", "پاسخ پشتیبانی برای دکاندار دیده می‌شود", "پاسخ پشتیبانی فاز۲" in b, f"st={st}")
    q("delete from ticket_msgs where ticket_id=?", (tid,))
    q("delete from tickets where id=?", (tid,))

# ─────────────────── S7 مرزهای مالکیت (IDOR) ───────────────────
def s7():
    print("── S7 مرز دکان B روی دارایی‌های دکان A")
    shopB = login_me(B_PHONE)
    # B می‌خواهد در دکان A کالا بگذارد
    n0 = q("select count(*) from items where biz_id=?", (A_BIZ,))[0][0]
    st, b, url = go(shopB, f"/my/catalog/{A_BIZ}/quick", {"title": "نفوذ", "price": "1"})
    n1 = q("select count(*) from items where biz_id=?", (A_BIZ,))[0][0]
    check("S7.1", "افزودن کالا به دکانِ دیگری رد شد", n1 == n0, f"n0={n0} n1={n1} st={st}")
    # B می‌خواهد کالای A را حذف کند
    target = q("select id from items where biz_id=? limit 1", (A_BIZ,))[0][0]
    go(shopB, f"/my/catalog/{A_BIZ}/item/{target}/delete", {})
    still = q("select id from items where id=?", (target,))
    check("S7.2", "حذف کالای دکانِ دیگری رد شد", bool(still), f"target={target}")
    # B می‌خواهد ویرایشگر دکان A را باز کند
    st, b, url = go(shopB, f"/my/business/{A_BIZ}")
    check("S7.3", "بازکردن ویرایشگر دکانِ دیگری رد شد", "دکانٔ آزمون مالک یک" not in b or st in (403, 404), f"st={st}")

# ─────────────────── S8 چت با خود ───────────────────
def s8():
    print("── S8 دکان‌دار با خودش گفتگو نمی‌تواند (v150)")
    shopA = login_me(A_PHONE)   # 09352223344 هم customer است
    t0 = q("select count(*) from chat_threads")[0][0]
    st, b, url = go(shopA, f"/b/{A_SLUG}/chat")
    t1 = q("select count(*) from chat_threads")[0][0]
    check("S8.1", "گفتگوی دکاندار با دکان خودش ساخته نمی‌شود", t1 == t0, f"t0={t0} t1={t1} url={url}")

def main():
    # صحنه: مالکیت دو دکان
    q("update businesses set owner_id=2 where id=?", (A_BIZ,))
    q("update businesses set owner_id=89 where id=?", (B_BIZ,))
    try:
        op = s1()
        s2(op)
        s3()
        s4()
        s5()
        s6()
        s7()
        s8()
    finally:
        q("update businesses set owner_id=NULL where id=?", (A_BIZ,))
        q("update businesses set owner_id=NULL where id=?", (B_BIZ,))
    json.dump(RESULTS, open("qa/phase2-results.json", "w"), ensure_ascii=False, indent=1)
    fails = [r for r in RESULTS if not r["ok"]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(fails)} | قرمز: {len(fails)}")
    for r in fails:
        print("  ❌", r["id"], r["name"], "—", r["detail"])
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
