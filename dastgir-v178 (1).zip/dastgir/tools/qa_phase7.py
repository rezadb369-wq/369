#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۷ — تعامل مشتری (۱): نظرات · پرسش و پاسخ · گزارش تخلف.
مقیاس ۶ستونه، پاسخ مدیر دکان در برابر مدیر سایت، حل گزارش، گروهی.
هر تست اثر واقعی را در پایگاه/صفحهٔ عمومی بررسی می‌کند و تمیزکاری برمی‌گرداند."""
import re, sys, json, sqlite3, time, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []
A_SLUG = "dkan-azmvn-malk-yk"      # دکانٔ آزمون مالک یک (214)
A_BIZ = 214
SHOP_PHONE = "09352223344"          # حساب دکاندارِ صحنه
CUST_PHONE = "09361112233"          # حساب مشتری صحنه
ADMIN_PHONE = "09131110011"

def q(sql, args=()):
    c = sqlite3.connect(DB); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None):
    h = {}
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data, doseq=True).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(BASE + path, data=body, headers=h)
    try:
        r = op.open(req, timeout=25)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def clear_rl():
    q("delete from ratelimit")

def login(phone, admin=False):
    clear_rl()
    op = sess()
    go(op, "/login")
    go(op, "/login", {"phone": phone})
    go(op, "/login/verify", {"phone": phone, "code": otp_code(phone)})
    if admin:
        go(op, "/panel?key=" + DBM.owner_token())
    return op

def cust_login(phone):
    """ورود از دروازهٔ مشتری (همان شماره، مسیر /me/login)."""
    clear_rl()
    op = sess()
    go(op, "/me/login")
    go(op, "/me/login", {"phone": phone})
    go(op, "/me/login/verify", {"phone": phone, "code": otp_code(phone)})
    return op

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

created = {"reviews": [], "questions": [], "reports": [], "notifs": []}

# ─────────────────── T1 نظرات ───────────────────
def t1():
    print("── T1 نظرات (مقیاس ۶ستونه، پاسخ‌ها، تعدیل)")
    op = login(ADMIN_PHONE, admin=True)
    # 1.1 مهمانِ واقعی (سشن خام — سیستم تک‌حساب v69 ورود پنل را مشتری‌دار می‌کند)
    st, b, url = go(sess(), f"/b/{A_SLUG}/review", {
        "author": "مهمان آزمون", "body": "نظر مهمان برای آزمون فاز ۷ — متن دست‌کم بیست نویسه.",
        "rating": "5", "crit_quality": "6"})
    row = q("select id,rating,status from reviews where author='مهمان آزمون' order by id desc limit 1")
    ok = len(row) == 1 and row[0][1] == 0 and row[0][2] == "pending"
    created["reviews"].append(row[0][0] if row else 0)
    check("T1.1", "مهمان: امتیاز جعلی حذف شد، نظر pending", ok, str(row))
    rid_guest = row[0][0] if row else 0
    # 1.2 pending عمومی نیست؛ تأیید → عمومی
    time.sleep(5.2)
    st, b, _ = go(sess(), f"/b/{A_SLUG}")
    pub_hidden = "مهمان آزمون" not in b
    st, b, url = go(op, f"/panel/review/{rid_guest}", {"action": "approve"})
    time.sleep(5.2)
    st, b, _ = go(sess(), f"/b/{A_SLUG}")
    check("T1.2", "تعدیل: pending مخفی → تأیید → عمومی",
          pub_hidden and "مهمان آزمون" in b, f"hidden={pub_hidden}")
    # 1.3 مشتری: امتیاز ۶ستونه = میانگین معیارها + جلوگیری از امتیاز دوباره
    cop = cust_login(CUST_PHONE)
    st, b, url = go(cop, f"/b/{A_SLUG}/review", {
        "author": "مشتری آزمون۷", "body": "نظر امتیازدار مشتری صحنه برای آزمون فاز ۷.",
        "rating": "1", "crit_quality": "6", "crit_behaviour": "4"})
    row = q("select id,rating,(select count(*) from review_scores rs where rs.review_id=reviews.id) from reviews where author='مشتری آزمون۷' order by id desc limit 1")
    ok = len(row) == 1 and row[0][1] == 5 and row[0][2] == 2   # (6+4)/2=5
    rid_scored = row[0][0] if row else 0
    created["reviews"].append(rid_scored)
    check("T1.3", "مشتری: rating=میانگین معیارها (۶→۶ستونه)", ok, str(row))
    st, b, url = go(cop, f"/b/{A_SLUG}/review", {
        "author": "مشتری آزمون۷", "body": "امتیاز دوم که باید رد شود چون قبلاً امتیاز داده‌ام.",
        "rating": "6", "crit_quality": "6"})
    n2 = q("select count(*) from reviews where author='مشتری آزمون۷'")[0][0]
    check("T1.4", "امتیاز دوبارهٔ همان مشتری رد", n2 == 1, f"n={n2}")
    # 1.5 دکاندار روی دکان خودش رد
    sop = login(SHOP_PHONE)
    st, b, url = go(sop, f"/b/{A_SLUG}/review", {
        "author": "صاحب دکان", "body": "تلاش برای دادن نظر به دکان خودم برای آزمون.",
        "rating": "6", "crit_quality": "6"})
    n3 = q("select count(*) from reviews where author='صاحب دکان'")[0][0]
    check("T1.5", "نظر دکاندار به دکان خودش رد", n3 == 0, f"n={n3}")
    # 1.6 کلمپ بازه: مهمانِ واقعی با مقادیر وحشی → بی‌ستاره
    st, b, url = go(sess(), f"/b/{A_SLUG}/review", {
        "author": "کلمپ آزمون", "body": "آزمون کلمپ بازهٔ امتیاز با مقادیر خارج از بازه.",
        "crit_quality": "99", "rating": "9"})
    row = q("select id,rating,(select max(score) from review_scores rs where rs.review_id=reviews.id) from reviews where author='کلمپ آزمون' order by id desc limit 1")
    ok = len(row) == 1 and row[0][1] == 0 and (row[0][2] in (0, None))
    created["reviews"].append(row[0][0] if row else 0)
    check("T1.6", "کلمپ: مهمانِ مقادیر وحشی → بی‌ستاره سالم", ok, str(row))
    # 1.7 پاسخ دکاندار → عمومی
    st, b, url = go(sop, "/my/review/%d" % rid_guest, {"reply": "سپاس از نظر شما؛ منتظر دیدار مجددیم."})
    time.sleep(5.2)
    st, b, _ = go(sess(), f"/b/{A_SLUG}")
    check("T1.7", "پاسخ دکاندار ثبت و عمومی شد",
          "پاسخ ثبت" in urllib.parse.unquote(url) and "منتظر دیدار مجددیم" in b, url)
    # 1.8 پاسخ وحشی دکاندار → پیام صادقانه (رفع v171)
    st, b, url = go(sop, "/my/review/999999", {"reply": "هک"})
    check("T1.8", "پاسخ وحشی دکاندار → «نیست» نه جعل موفقیت",
          "نیست" in urllib.parse.unquote(url), url)
    # 1.9 پاسخ ادمین به نظر pending + approve همزمان؛ وحشی → «نیست»
    row = q("insert into reviews(biz_id,author,rating,body,status,created) "
            "values(214,'صبرکنندهٔ آزمون',0,'نظر در انتظار برای آزمون پاسخ ادمین فاز ۷.','pending',datetime('now','localtime'))")
    rid_wait = q("select id from reviews where author='صبرکنندهٔ آزمون'")[0][0]
    created["reviews"].append(rid_wait)
    st, b, url = go(op, f"/panel/review/{rid_wait}", {"reply": "پاسخ رسمی مدیریت سایت برای آزمون."})
    row = q("select status,reply from reviews where id=?", (rid_wait,))
    check("T1.9", "پاسخ ادمین: reply + تأیید همزمان",
          row and row[0][0] == "approved" and "رسمی مدیریت" in row[0][1], str(row))
    st, b, url = go(op, "/panel/review/999999", {"action": "approve"})
    check("T1.10", "وحشی پنل نظر → «نیست»", "نیست" in urllib.parse.unquote(url), url)
    # 1.11 XSS
    st, b, url = go(op, f"/b/{A_SLUG}/review", {
        "author": "<img src=x onerror=alert(1)>ایکس‌اس‌اس",
        "body": "متن نظر با پیلواد برای آزمون escape در فاز ۷ — کافی برای حد."})
    row = q("select id from reviews where body like '%پیلواد%' order by id desc limit 1")
    rid_x = row[0][0] if row else 0
    created["reviews"].append(rid_x)
    st, b, url = go(op, f"/panel/review/{rid_x}", {"action": "approve"})
    time.sleep(5.2)
    st, b, _ = go(sess(), f"/b/{A_SLUG}")
    raw_tag = "<img src=x" in b
    esc_seen = "&lt;img" in b
    check("T1.11", "XSS نظر: عمومی escaped، تگ خام صفر", esc_seen and not raw_tag,
          f"esc={esc_seen} raw={raw_tag}")
    # 1.12 bulk: ۳ نظر ساخت → approve/reject/delete
    for i in range(3):
        q("insert into reviews(biz_id,author,rating,body,status,created) "
          "values(214,'گروهی آزمون',0,'نظر گروهی %d برای آزمون bulk فاز ۷.','pending',datetime('now','localtime'))" % i)
    ids = [r[0] for r in q("select id from reviews where author='گروهی آزمون'")]
    created["reviews"] += ids
    st, b, url = go(op, "/panel/reviews/bulk",
                    [("ids", str(i)) for i in ids] + [("action", "approve")])
    n_ap = q("select count(*) from reviews where author='گروهی آزمون' and status='approved'")[0][0]
    check("T1.13", "گروهی: تأیید ۳ نظر", "3 نظر تأیید" in urllib.parse.unquote(url) and n_ap == 3,
          f"n={n_ap} url={url}")
    st, b, url = go(op, "/panel/reviews/bulk",
                    [("ids", str(i)) for i in ids] + [("action", "delete")])
    n_left = q("select count(*) from reviews where author='گروهی آزمون'")[0][0]
    check("T1.14", "گروهی: حذف ۳ نظر (شمارش صادقانه)", "3 نظر حذف" in urllib.parse.unquote(url) and n_left == 0, f"n={n_left}")
    # 1.15 حذف واقعی → سطل زباله دارد
    st, b, url = go(op, f"/panel/review/{rid_x}", {"action": "delete"})
    in_trash = q("select count(*) from trash where entity='review' and ref_id=?", (rid_x,))[0][0]
    check("T1.15", "حذف نظر → سطل زباله", "حذف" in urllib.parse.unquote(url) and in_trash == 1)
    created["reviews"].remove(rid_x)

# ─────────────────── T2 پرسش و پاسخ ───────────────────
def t2():
    print("── T2 پرسش و پاسخ")
    op = login(ADMIN_PHONE, admin=True)
    # 2.1 اعتبارسنجی + moderated → pending
    st, b, url = go(op, f"/b/{A_SLUG}/ask-question", {"asker": "س", "body": "کوتاه"})
    n0 = q("select count(*) from questions where biz_id=214")[0][0]
    check("T2.1", "پرسش کوتاه رد", n0 == 0 and "کامل" in urllib.parse.unquote(url), url)
    st, b, url = go(op, f"/b/{A_SLUG}/ask-question", {
        "asker": "پرسندهٔ آزمون", "body": "آیا پارکینگ نزدیک دکان دارید؟ پرسش آزمون فاز ۷."})
    row = q("select id,status from questions where asker='پرسندهٔ آزمون' order by id desc limit 1")
    ok = len(row) == 1 and row[0][1] == "pending"
    qid = row[0][0] if row else 0
    created["questions"].append(qid)
    check("T2.2", "پرسش معتبر → pending (تعدیل‌شده)", ok, str(row))
    # عمومی مخفی تا publish
    time.sleep(5.2)
    st, b, _ = go(sess(), f"/b/{A_SLUG}")
    hidden = "پارکینگ نزدیک" not in b
    st, b, url = go(op, f"/panel/question/{qid}", {"action": "publish"})
    time.sleep(5.2)
    st, b, _ = go(sess(), f"/b/{A_SLUG}")
    check("T2.3", "pending مخفی → publish → عمومی",
          hidden and "پارکینگ نزدیک" in b, f"hidden={hidden}")
    # 2.4 پاسخ ادمین + پاسخ خالی
    st, b, url = go(op, f"/panel/question/{qid}", {"answer": ""})
    check("T2.4", "پاسخ خالی ادمین رد", "خالی" in urllib.parse.unquote(url), url)
    st, b, url = go(op, f"/panel/question/{qid}", {"answer": "بله، پارکینگ عمومی خیابان بعدی است."})
    row = q("select status,answered_by from questions where id=?", (qid,))
    check("T2.5", "پاسخ ادمین → published/admin",
          row and row[0][0] == "published" and row[0][1] == "admin", str(row))
    # 2.5 پاسخ دکاندار روی پرسش تازه
    q("insert into questions(biz_id,asker,body,status,created) "
      "values(214,'پرسندهٔ دوم','ساعت باز شدن مغ... دکان در روز تعطیل چگونه است؟','published',datetime('now','localtime'))")
    qid2 = q("select id from questions where asker='پرسندهٔ دوم'")[0][0]
    created["questions"].append(qid2)
    sop = login(SHOP_PHONE)
    st, b, url = go(sop, f"/my/question/{qid2}", {"answer": "روزهای تعطیل از ساعت ۱۰ صبح."})
    row = q("select status,answered_by,answer from questions where id=?", (qid2,))
    check("T2.6", "پاسخ دکاندار → published/owner",
          row and row[0][0] == "published" and row[0][1] == "owner" and "۱۰ صبح" in row[0][2], str(row))
    # 2.6 پرسش دکان دیگر → 403
    q("insert into questions(biz_id,215,asker,body,status,created) "
      "values(215,'بیگانه','پرسشی دربارهٔ دکان دیگر برای آزمون مرز دسترسی.','published',datetime('now','localtime'))") if False else None
    q("insert into questions(biz_id,asker,body,status,created) "
      "values(215,'بیگانه','پرسشی دربارهٔ دکان دیگر برای آزمون مرز دسترسی.','published',datetime('now','localtime'))")
    qid3 = q("select id from questions where asker='بیگانه'")[0][0]
    created["questions"].append(qid3)
    st, b, url = go(sop, f"/my/question/{qid3}", {"answer": "هک"})
    check("T2.7", "پاسخ دکاندار به دکان دیگر → 403", st == 403, f"st={st}")
    # 2.7 وحشی پنل
    st, b, url = go(op, "/panel/question/999999", {"answer": "هرچی"})
    check("T2.8", "وحشی پنل پرسش → «نیست»", "نیست" in urllib.parse.unquote(url), url)
    # 2.8 qa_moderated=0 → انتشار بی‌واسطه
    q("update settings set value='0' where key='qa_moderated'")
    DBM.setting_invalidate() if hasattr(DBM, "setting_invalidate") else None
    time.sleep(5.2)
    st, b, url = go(op, f"/b/{A_SLUG}/ask-question", {
        "asker": "بی‌واسطهٔ آزمون", "body": "پرسشی که باید بدون تعدیل منتشر شود، آزمون فاز ۷."})
    row = q("select status from questions where asker='بی‌واسطهٔ آزمون' order by id desc limit 1")
    created["questions"].append(row[0] and q("select id from questions where asker='بی‌واسطهٔ آزمون' order by id desc limit 1")[0][0])
    check("T2.9", "qa_moderated=0 → انتشار بی‌واسطه", row and row[0][0] == "published", str(row))
    q("update settings set value='1' where key='qa_moderated'")
    time.sleep(5.2)
    # 2.9 helpful + وحشی api
    st, b, _ = go(sess(), "/api/question-helpful", {"id": str(qid)})
    n1 = q("select helpful from questions where id=?", (qid,))[0][0]
    check("T2.10", "رأی مفید +۱", st == 200 and n1 == 1, f"n={n1}")
    st, b, _ = go(sess(), "/api/question-helpful", {"id": "999999"})
    n2 = q("select helpful from questions where id=999999")
    check("T2.11", "رأی وحشی بی‌اثر (no-op)", st in (200, 400) and not n2, f"st={st}")
    # 2.10 XSS پرسش
    st, b, url = go(op, f"/b/{A_SLUG}/ask-question", {
        "asker": "<svg onload=alert(2)>پرسنده",
        "body": "پرسش پیلواد برای آزمون escape بخش پرسش‌وپاسخ در فاز ۷."})
    row = q("select id,status from questions where body like '%پرسش پیلواد%' order by id desc limit 1")
    qid_x = row[0][0] if row else 0
    created["questions"].append(qid_x)
    if row and row[0][1] == "pending":
        go(op, f"/panel/question/{qid_x}", {"action": "publish"})
    time.sleep(5.2)
    st, b, _ = go(sess(), f"/b/{A_SLUG}")
    check("T2.12", "XSS پرسش: escaped، تگ خام صفر",
          "&lt;svg" in b and "<svg onload" not in b, None)
    # 2.11 حذف
    st, b, url = go(op, f"/panel/question/{qid_x}", {"action": "delete"})
    check("T2.13", "حذف پرسش", "حذف" in urllib.parse.unquote(url)
          and not q("select * from questions where id=?", (qid_x,)))
    created["questions"].remove(qid_x)

# ─────────────────── T3 گزارش تخلف ───────────────────
def t3():
    print("── T3 گزارش تخلف")
    op = login(ADMIN_PHONE, admin=True)
    # 3.1 گزارش معتبر
    st, b, url = go(op, f"/b/{A_SLUG}/report", {
        "reason": "wrong", "body": "شمارهٔ تلفن در آزمون عوض شده است.",
        "reporter": "گزارشگر آزمون"})
    row = q("select id,status,reason from reports where reporter='گزارشگر آزمون' order by id desc limit 1")
    ok = len(row) == 1 and row[0][1] == "open" and row[0][2] == "wrong"
    rid = row[0][0] if row else 0
    created["reports"].append(rid)
    check("T3.1", "گزارش معتبر → open/wrong", ok, str(row))
    # 3.2 reason جعلی → other (رفع v171)
    st, b, url = go(op, f"/b/{A_SLUG}/report", {
        "reason": "bogus", "body": "تلاش برای تزریق دلیل دلخواه در آزمون فاز ۷.",
        "reporter": "جعل‌کنندهٔ دلیل"})
    row = q("select reason from reports where reporter='جعل‌کنندهٔ دلیل'")
    created["reports"].append(row and q("select id from reports where reporter='جعل‌کنندهٔ دلیل'")[0][0])
    check("T3.2", "reason جعلی → other", row and row[0][0] == "other", str(row))
    # 3.3 resolve / dismiss
    st, b, url = go(op, f"/panel/report/{rid}", {"action": "resolve", "note": "تماس گرفته شد؛ اصلاح شد."})
    row = q("select status,note from reports where id=?", (rid,))
    check("T3.3", "حل گزارش + یادداشت", row and row[0][0] == "resolved" and "اصلاح شد" in row[0][1], str(row))
    # 3.4 bulk dismiss
    q("insert into reports(kind,target_id,biz_id,reason,body,reporter) "
      "values('business',214,214,'spam','گزارش گروهی یک آزمون فاز ۷.','گروهی رپ')")
    q("insert into reports(kind,target_id,biz_id,reason,body,reporter) "
      "values('business',214,214,'spam','گزارش گروهی دو آزمون فاز ۷.','گروهی رپ')")
    ids = [r[0] for r in q("select id from reports where reporter='گروهی رپ'")]
    created["reports"] += ids
    st, b, url = go(op, "/panel/reports/bulk",
                    [("ids", str(i)) for i in ids] + [("action", "dismiss"), ("note", "")])
    n_d = q("select count(*) from reports where reporter='گروهی رپ' and status='dismissed'")[0][0]
    check("T3.4", "گروهی: بی‌موضع‌سازی 2 گزارش", "2 گزارش" in urllib.parse.unquote(url) and n_d == 2, f"n={n_d}")
    # 3.5 وحشی تک + در bulk شمرده نمی‌شود
    st, b, url = go(op, "/panel/report/999999", {"action": "resolve"})
    st2, b2, url2 = go(op, "/panel/reports/bulk", [("ids", "999999"), ("action", "resolve")])
    check("T3.5", "وحشی گزارش → «نیست» / bulk شمارش ۰",
          "نیست" in urllib.parse.unquote(url) and "0 گزارش" in urllib.parse.unquote(url2), f"{url} {url2}")
    # 3.6 دکاندار 403 ×3
    sop = login(SHOP_PHONE)
    g1 = go(sop, "/panel/reports")[0]
    g2 = go(sop, f"/panel/report/{rid}", {"action": "resolve"})[0]
    g3 = go(sop, "/panel/reports/bulk", [("ids", str(rid)), ("action", "delete")])[0]
    check("T3.6", "دکاندار 403×3", (g1, g2, g3) == (403, 403, 403), str((g1, g2, g3)))
    # 3.7 حذف → سطل
    st, b, url = go(op, f"/panel/report/{rid}", {"action": "delete"})
    in_trash = q("select count(*) from trash where entity='report' and ref_id=?", (rid,))[0][0]
    check("T3.7", "حذف گزارش → سطل زباله", "حذف" in urllib.parse.unquote(url) and in_trash == 1)
    created["reports"].remove(rid)

def main():
    try:
        t1()
        t2()
        t3()
    finally:
        for rid in created["reviews"]:
            q("delete from review_scores where review_id=?", (rid,))
            q("delete from reviews where id=?", (rid,))
        for qid in created["questions"]:
            q("delete from questions where id=?", (qid,))
        for rid in created["reports"]:
            q("delete from reports where id=?", (rid,))
        # احتیاط دوم — پاک‌سازی الگویی دقیق عناوین آزمون
        q("delete from review_scores where review_id in (select id from reviews where author like '%آزمون%')")
        q("delete from reviews where author like '%آزمون%' or author like '%ایکس‌اس‌اس%'")
        q("delete from questions where asker like '%آزمون%' or asker='بیگانه' or body like '%آزمون%'")
        q("delete from reports where reporter like '%آزمون%' or reporter='گروهی رپ' or reporter='جعل‌کنندهٔ دلیل'")
    json.dump(RESULTS, open("qa/phase7-results.json", "w"), ensure_ascii=False, indent=1)
    fails = [r for r in RESULTS if not r["ok"]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(fails)} | قرمز: {len(fails)}")
    for r in fails:
        print("  ❌", r["id"], r["name"], "—", r["detail"])
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
