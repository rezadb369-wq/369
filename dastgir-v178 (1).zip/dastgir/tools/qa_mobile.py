#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۵ — موبایل و کارایی: پروفایل لمس/فونت/اسکرول، آفلاین، وزن، سئو."""
import re, sys, json, sqlite3, uuid, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []
A_BIZ, A_SLUG = 216, "kbaby-bradran-hydry"

def q(sql, args=()):
    c = sqlite3.connect(DB); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

def fetch(p, headers=None):
    req = urllib.request.Request(BASE + p, headers=headers or {})
    try:
        r = urllib.request.urlopen(req, timeout=20)
        return r.status, r.read(), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read(), dict(e.headers)

# ─────────────── M1 موبایل (playwright) ───────────────
def m1():
    print("── M1 پروفایل موبایل 320/412")
    # صحنه: دکان ۲۰۴ و کالا ۳۳۶ عکس واقعی می‌گیرند (برای og:image و گالری)
    import shutil, os
    src = "site/assets/img/cats/accountant.webp"
    if not os.path.exists(src):
        src = "site/assets/img/cats/food.webp"
    shutil.copy(src, "site/assets/img/uploads/qa-photo.webp")
    q("update businesses set images=? where id=?", ('["/assets/img/uploads/qa-photo.webp"]', A_BIZ))
    q("update items set image=? where id=336", ("/assets/img/uploads/qa-photo.webp",))
    from playwright.sync_api import sync_playwright
    pages = [("/", "خانه"), ("/catalog", "کاتالوگ"), ("/item/336", "کالا"), ("/cart", "سبد"),
             (f"/b/{A_SLUG}", "دکان"), ("/me/login", "ورود"), ("/pricing", "تعرفه"), ("/map", "نقشه")]
    hscroll, tiny_text, story_chips = [], [], []
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        for w in (320, 412):
            pg = b.new_page(viewport={"width": w, "height": 850})
            for path, name in pages:
                pg.goto(BASE + path, wait_until="networkidle")
                r = pg.evaluate("""() => {
                  const out = {h: document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
                               small: [], chips: 0};
                  for (const el of document.querySelectorAll('p, span, div, a, button, label, td, th, li')) {
                    if (el.children.length) continue;
                    const t = (el.textContent || '').trim();
                    if (!t) continue;
                    if (parseFloat(getComputedStyle(el).fontSize) < 12) out.small.push(t.slice(0, 20));
                  }
                  for (const el of document.querySelectorAll('.story-chip')) {
                    const r = el.getBoundingClientRect();
                    if (r.width && r.height && r.height < 44) out.chips++;
                  }
                  return out;
                }""")
                if r["h"]: hscroll.append(f"{name}@{w}")
                if r["small"]: tiny_text += [f"{name}@{w}: {r['small'][:2]}"]
                if r["chips"]: story_chips.append(f"{name}@{w}: {r['chips']}")
                pg.screenshot(path=f"qa/shots/{name}-{w}.png")
            pg.close()
        # آفلاین
        ctx = b.new_context(viewport={"width": 360, "height": 800})
        pg = ctx.new_page()
        pg.goto(BASE + "/", wait_until="networkidle")
        pg.wait_for_timeout(1500)
        swc = pg.evaluate("navigator.serviceWorker.controller ? 'controlled' : 'none'")
        ctx.set_offline(True)
        pg.goto(BASE + "/cart", wait_until="load", timeout=15000)
        offline_title = pg.title()
        offline_ok = "اتصال برقرار نیست" in offline_title
        ctx.set_offline(False)
        ctx.close()
        b.close()
    check("M1.1", "هیچ اسکرول افقی در ۸ صفحه × ۲ عرض", not hscroll, f"{hscroll[:4]}")
    check("M1.2", "هیچ متنی زیر ۱۲px", not tiny_text, f"{tiny_text[:4]}")
    check("M1.3", "سرویس‌ورکر کنترل‌گر شد", swc == "controlled", swc)
    check("M1.4", "آفلاین: صفحهٔ آفلاین اختصاصی فارسی می‌آید", offline_ok, offline_title[:40])
    return story_chips

# ─────────────── M2 لمس: استوری‌چیپ (باگ ۱۰) ───────────────
def m2():
    print("── M2 هدف لمس: چیپ استوری زیر ۴۴px (رفع بازسازی)")
    st, b, _ = fetch("/")
    css = fetch("/assets/css/main.css")[1].decode()
    m = re.search(r"\.story-chip \{[^}]*min-height:\s*(\d+)px", css)
    val = int(m.group(1)) if m else None
    check("M2.1", "min-height چیپ استوری ≥ 44px", val is not None and val >= 44, f"min-height={val}")
    m2 = re.search(r"\.story-chip \{[^}]*padding:([^;]+);", css)
    check("M2.2", "padding چیپ هم برای ارتفاع لمسی اصلاح شد", m2 and "10px" in m2.group(1), m2.group(1) if m2 else "-")

# ─────────────── M3 وزن و فشرده‌سازی ───────────────
def m3():
    print("── M3 وزن و فشرده‌سازی")
    tot = 0
    for p in ("/", "/catalog", "/pricing"):
        st, raw, hdr = fetch(p, {"Accept-Encoding": "gzip"})
        enc = hdr.get("Content-Encoding", "")
        tot += len(raw)
        if p == "/":
            check("M3.1", "HTML خانه با gzip می‌آید", enc == "gzip", f"enc={enc}")
    check("M3.2", "جمع HTML ۳ صفحهٔ اصلی < 400KB", tot < 400 * 1024, f"{tot/1024:.0f}KB")
    st, raw, hdr = fetch("/assets/css/main.css", {"Accept-Encoding": "gzip"})
    check("M3.3", "CSS ثابت هم فشرده می‌شود", hdr.get("Content-Encoding") == "gzip", hdr.get("Content-Encoding"))
    st, raw, hdr = fetch("/assets/fonts/Vazirmatn-Variable.woff2")
    check("M3.4", "فونت متغیر محلی (بدون CDN خارجی)", st == 200, f"st={st}")

# ─────────────── M4 سئو پایه ───────────────
def m4():
    print("── M4 سئو پایه")
    st, b, _ = fetch(f"/b/{A_SLUG}")
    h = b.decode()
    check("M4.1", "کامنونیکال روی صفحهٔ دکان", 'rel="canonical"' in h)
    check("M4.2", "og:image وقتی دکان عکس دارد", 'property="og:image"' in h)
    check("M4.3", "robots noindex روی صفحات خصوصی نیست", 'name="robots" content="noindex' not in h)
    st, b, _ = fetch("/panel")
    h2 = b.decode()
    check("M4.4", "پنل noindex دارد (نباید در گوگل بیاید)", "noindex" in h2)
    st, b, _ = fetch("/sitemap.xml")
    check("M4.5", "sitemap.xml سالم", st == 200 and b.startswith(b"<?xml"))
    st, b, _ = fetch("/robots.txt")
    check("M4.6", "robots.txt مسیرهای خصوصی را می‌بندد", st == 200 and b"Disallow: /panel" in b and b"Disallow: /me" in b)

def main():
    story_chips = m1()
    m2()
    m3()
    m4()
    # پاک‌سازی صحنه (پایگاه توسعه محلی؛ روی سرور اثری ندارد)
    q("update businesses set images='[]' where id=?", (A_BIZ,))
    q("update items set image='' where id=336")
    json.dump(RESULTS, open("qa/phase5-results.json", "w"), ensure_ascii=False, indent=1)
    fails = [r for r in RESULTS if not r["ok"]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(fails)} | قرمز: {len(fails)}")
    for r in fails:
        print("  ❌", r["id"], r["name"], "—", r["detail"])
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
