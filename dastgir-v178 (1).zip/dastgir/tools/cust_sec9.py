# -*- coding: utf-8 -*-
"""بخش ۹ (نسخهٔ ۲) — نظر(+مادریت ادمین)، مفید، پرسش→پاسخ، نوبت→تأیید، چت متن+عکس دوطرفه."""
import sys, sqlite3, time
sys.path.insert(0, 'tools')
from cust_lib import *
sys.path.insert(0, 'server')
import db as dbm
from playwright.sync_api import sync_playwright
from PIL import Image

recs = []
log = print
SLUG = 'dkan-azmvn-malk-yk'
OWNER_PHONE = '09352223344'
CUST_PHONE = '09361112233'
CACHE = 6.0          # مکث کش صفحه (۵٫۲s) + حاشیه


def login(br, phone):
    c = sqlite3.connect(DB)
    c.execute("delete from otp"); c.execute("delete from ratelimit"); c.commit()
    u = ctx(br); pg = u.new_page()
    pg.on('dialog', lambda d: d.accept())
    pg.goto(BASE + '/login')
    pg.fill('form[action="/login"] input[name="phone"]', phone)
    pg.click('form[action="/login"] button[type="submit"]', no_wait_after=True)
    pg.wait_for_selector('input[name="code"]')
    pg.fill('input[name="code"]', otp_code(phone))
    try:
        pg.click('form[action="/login/verify"] button[type="submit"]', no_wait_after=True, timeout=6000)
    except Exception:
        pass
    try:
        pg.wait_for_url('**/my', timeout=8000)
    except Exception:
        try:
            pg.evaluate("document.querySelector('form[action=\\'/login/verify\\']').submit()")
        except Exception:
            pass
        pg.wait_for_url('**/my', timeout=20000)
    return u, pg


def rec(name, url, ok, extra, shot=None, pgx=None):
    if shot and pgx:
        try:
            pgx.screenshot(path=f'{SHOTS}/{shot}.png', full_page=True, timeout=12000)
        except Exception:
            try:
                pgx.screenshot(path=f'{SHOTS}/{shot}.png', timeout=12000)
            except Exception:
                pass
    r = {'name': name, 'url': url, 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0, 'extra': extra}
    recs.append(r); log(('✅' if ok else '❌'), name, '|', extra)


with sync_playwright() as pw:
    br = pw.chromium.launch()
    uc, pgc = login(br, CUST_PHONE)                 # مشتری
    uo, pgo = login(br, OWNER_PHONE)                # دکاندار
    ua = ctx(br); pga = ua.new_page()               # ادمین
    pga.on('dialog', lambda d: d.accept())
    pga.goto(BASE + '/panel?key=' + dbm.owner_token())
    pga.wait_for_load_state('networkidle')

    # ── 9.1 نظر با عکس → pending → تأیید ادمین → عمومی ──
    png = '/tmp/review-shot.png'
    Image.new('RGB', (400, 300), (200, 90, 40)).save(png)
    pgc.goto(f'{BASE}/b/{SLUG}'); pgc.wait_for_load_state('networkidle')
    f = pgc.locator('form[action*="/review"]')
    f.locator('input[name="author"]').fill('مشتری آزمون')
    f.locator('textarea[name="body"]').fill('کالای باکیفیت، برخورد خوب — بازبینی مشتری.')
    f.locator('input[name="review_image"]').set_input_files(png)
    f.locator('button[type="submit"]').click(no_wait_after=True)
    try:
        pgc.wait_for_url(f'**/b/{SLUG}**', timeout=10000)
    except Exception:
        pass
    rid = sqlite3.connect(DB).execute(
        "select id from reviews where biz_id=214 order by id desc limit 1").fetchone()[0]
    st_r = sqlite3.connect(DB).execute("select status,image from reviews where id=?", (rid,)).fetchone()
    pga.goto(f'{BASE}/panel/reviews'); pga.wait_for_load_state('networkidle')
    pga.click(f'form[action="/panel/review/{rid}"] button:has-text("تأیید")', no_wait_after=True)
    try:
        pga.wait_for_load_state('networkidle', timeout=8000)
    except Exception:
        pass
    time.sleep(CACHE)
    pgc.reload(); pgc.wait_for_load_state('networkidle'); pgc.wait_for_timeout(500)
    shown = 'برخورد خوب' in pgc.inner_text('body')
    rec('sec9-review', f'/b/{SLUG}', st_r[0] == 'pending' and bool(st_r[1]) and shown,
        f'ثبت با عکس (status اولیه={st_r[0]}, عکس={bool(st_r[1])}) → تأیید ادمین → عمومی: {shown}',
        'sec9-review', pgc)

    # ── 9.2 مفید بود (روی دکمهٔ نظر اول) ──
    import re as _re
    hb = pgc.locator('button:has-text("مفید بود")').first
    txt0 = hb.inner_text()
    m0 = _re.search(r'(\d+)', txt0)
    before_b = int(m0.group(1)) if m0 else -1
    clicked = hb.count() > 0
    hb.click(no_wait_after=True)
    pgc.wait_for_timeout(1500)
    txt1 = pgc.locator('button:has-text("مفید بود")').first.inner_text()
    m1 = _re.search(r'(\d+)', txt1)
    after_b = int(m1.group(1)) if m1 else -1
    rec('sec9-helpful', f'/b/{SLUG}', clicked and after_b == before_b + 1,
        f'کلیک مفید بود → شمارندهٔ دکمه: {before_b} → {after_b} (کلیک={clicked})')

    # ── 9.3 پرسش از UI → پاسخ دکاندار → انتشار ──
    pgc.goto(f'{BASE}/b/{SLUG}'); pgc.wait_for_load_state('networkidle')
    fq = pgc.locator('form[action*="/ask-question"]')
    fq.locator('input[name="asker"]').fill('مشتری آزمون')
    fq.locator('textarea[name="body"]').fill('ساعت باز شدن مغازه چند است؟')
    fq.locator('button[type="submit"]').click(no_wait_after=True)
    try:
        pgc.wait_for_load_state('networkidle', timeout=8000)
    except Exception:
        pass
    qrow = sqlite3.connect(DB).execute(
        "select id from questions where body like 'ساعت باز شدن%' order by id desc limit 1").fetchone()
    qid = qrow[0] if qrow else None
    pgo.goto(f'{BASE}/my/questions'); pgo.wait_for_load_state('networkidle')
    seen = qid and ('ساعت باز شدن' in pgo.inner_text('body'))
    pgo.screenshot(path=f'{SHOTS}/sec9-question-owner.png', full_page=True)
    ok_q = False
    if qid and seen:
        pgo.fill(f'form[action="/my/question/{qid}"] textarea[name="answer"]', 'از ساعت ۹ صبح.')
        pgo.click(f'form[action="/my/question/{qid}"] button[type="submit"]', no_wait_after=True)
        try:
            pgo.wait_for_load_state('networkidle', timeout=8000)
        except Exception:
            pass
        time.sleep(CACHE)
        pgc.goto(f'{BASE}/b/{SLUG}'); pgc.wait_for_load_state('networkidle')
        published = 'از ساعت ۹ صبح' in pgc.inner_text('body')
        st = sqlite3.connect(DB).execute("select status from questions where id=?", (qid,)).fetchone()[0]
        ok_q = published and st == 'published'
        rec('sec9-ask-answer', f'/b/{SLUG}', ok_q,
            f'پرسش {qid} → پاسخ دکاندار → منتشر: {published} (status={st})', 'sec9-qa-published', pgc)
    else:
        rec('sec9-ask-answer', '/my/questions', False, f'پرسش دیده نشد (qid={qid}, owner_seen={seen})')

    # ── 9.4 نوبت از UI → تأیید دکاندار ──
    pgc.goto(f'{BASE}/b/{SLUG}'); pgc.wait_for_load_state('networkidle')
    fb = pgc.locator('form[action*="/book"]')
    fb.locator('input[name="name"]').fill('مشتری آزمون')
    fb.locator('input[name="phone"]').fill(CUST_PHONE)
    fb.locator('input:not([name]):not([type=hidden])').first.fill('1405/09/24')
    fb.locator('input[name="date"]').evaluate("e=>e.value='1405/09/24'")
    fb.locator('input[name="time"]').fill('10:30')
    fb.locator('button[type="submit"]').click(no_wait_after=True)
    try:
        pgc.wait_for_url(f'**/b/{SLUG}**', timeout=10000)
    except Exception:
        pass
    pgc.wait_for_timeout(500)
    brow = sqlite3.connect(DB).execute(
        "select id,status from bookings where biz_id=214 order by id desc limit 1").fetchone()
    bid = brow[0] if brow else None
    pgo.goto(f'{BASE}/my/bookings'); pgo.wait_for_load_state('networkidle')
    seen_b = bool(bid) and pgo.locator(f'form[action="/my/booking/{bid}"]').count() > 0
    if bid and seen_b:
        pgo.click(f'form[action="/my/booking/{bid}"] button[value="confirmed"]', no_wait_after=True)
        try:
            pgo.wait_for_load_state('networkidle', timeout=8000)
        except Exception:
            pass
        if sqlite3.connect(DB).execute(
                "select status from bookings where id=?", (bid,)).fetchone()[0] != 'confirmed':
            try:
                pgo.evaluate(f"document.querySelector('form[action=\'/my/booking/{bid}\'] button[value=\'confirmed\']').click()")
            except Exception:
                pass
            pgo.wait_for_timeout(1000)
    st_b = sqlite3.connect(DB).execute("select status from bookings where id=?", (bid,)).fetchone()[0] if bid else '?'
    rec('sec9-booking', '/my/bookings', bool(bid) and seen_b and st_b == 'confirmed',
        f'نوبت {bid} گرفته شد (فهرست دکاندار: {seen_b}) → تأیید شد (status={st_b})',
        'sec9-booking-owner', pgo)

    # ── 9.5 چت: متن + عکس، دوطرفه ──
    pgc.goto(f'{BASE}/b/{SLUG}/chat')
    try:
        pgc.wait_for_url('**/me/chat/**', timeout=10000)
    except Exception:
        pass
    tid = pgc.url.rstrip('/').rsplit('/', 1)[-1]
    fc = pgc.locator(f'form[action="/me/chat/{tid}"]')
    fc.locator('textarea[name="body"],input[name="body"]').first.fill('سلام، کالای آزمون ۱ موجود است؟')
    img_in = fc.locator('input[type="file"]')
    if img_in.count() > 0:
        img_in.set_input_files(png)
    fc.locator('button[type="submit"]').click(no_wait_after=True)
    try:
        pgc.wait_for_url(f'**/me/chat/{tid}**', timeout=10000)
    except Exception:
        pass
    pgc.wait_for_timeout(600)
    sent_ok = 'موجود است' in pgc.inner_text('body')
    rec('sec9-chat-send', f'/me/chat/{tid}', sent_ok, f'پیام+عکس مشتری ارسال و نمایش: {sent_ok}',
        'sec9-chat-cust', pgc)

    pgo.goto(f'{BASE}/my/chats'); pgo.wait_for_load_state('networkidle')
    thr = pgo.locator(f'a[href="/my/chat/{tid}"]').first
    if thr.count() == 0:
        thr = pgo.locator(f'a[href*="{tid}"]').first
    opened = thr.count() > 0
    if opened:
        thr.click()
        try:
            pgo.wait_for_load_state('networkidle', timeout=8000)
        except Exception:
            pass
    has_img_o = opened and pgo.evaluate("()=>!!document.querySelector('img[src*=\"/chat-file/\"]')")
    fo = pgo.locator(f'form[action="/my/chat/{tid}"]')
    if fo.count() > 0:
        fo.locator('textarea[name="body"],input[name="body"]').first.fill('بله، موجود است. تشریف بیاورید.')
        fo.locator('button[type="submit"]').click(no_wait_after=True)
        try:
            pgo.wait_for_url(f'**/my/chat/{tid}**', timeout=10000)
        except Exception:
            pass
        if not sqlite3.connect(DB).execute(
                "select 1 from chat_messages where thread_id=? and body like 'بله، موجود%'",
                (tid,)).fetchone():
            try:
                pgo.evaluate(f"document.querySelector('form[action=\'/my/chat/{tid}\']').submit()")
            except Exception:
                pass
            pgo.wait_for_timeout(1000)
    owner_msg = sqlite3.connect(DB).execute(
        "select count(*) from chat_messages where thread_id=? and sender='owner'",
        (tid,)).fetchone()[0]
    pgc.reload(); pgc.wait_for_load_state('networkidle'); pgc.wait_for_timeout(800)
    got_reply = 'تشریف بیاورید' in pgc.inner_text('body')
    img_seen = pgc.evaluate("()=>!!document.querySelector('img[src*=\"/chat-file/\"]')")
    pgo.screenshot(path=f'{SHOTS}/sec9-chat-owner.png', full_page=True)
    rec('sec9-chat-reply', f'/my/chat/{tid}', owner_msg > 0 and got_reply and has_img_o and img_seen,
        f'پیام دکاندار در DB: {owner_msg} | نمایش نزد مشتری: {got_reply} | عکس نزد دکاندار: {has_img_o} | عکس نزد مشتری: {img_seen}')

    uc.close(); uo.close(); ua.close(); br.close()

save(recs, '9-تعامل')
print(f"\n── بخش ۹: {len(recs)} سنج | قرمز: {len([r for r in recs if 'False' in str(r.get('extra',''))])}")
