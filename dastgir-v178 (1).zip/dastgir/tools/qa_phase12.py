#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۱۲ — سیستم (۲): مدیریت فایل‌ها · مشتری‌ها · دنبال‌کننده‌ها · اعلان همگانی.
حجم/نوع فایل، مسیرخارج، مسدودی مشتری و پیامدهایش، نرخ اعلان.
هر تست اثر واقعی را در پایگاه/صفحه بررسی می‌کند و تمیزکاری برمی‌گرداند."""
import re, sys, json, sqlite3, time, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []
ADMIN_PHONE = "09131110011"
SHOP_PHONE = "09352223344"
CUST_PHONE = "09361112233"   # مشتری صحنه

def q(sql, args=()):
    """نوشتن/خواندن با بسته‌شدنِ امن و تلاشِ مجدد — قفلِ گذرای WAL دور خزشِ
    seed/پاک‌سازی گاه تا ~۲۰ ثانیه می‌ماند؛ باتری باید صبور باشد نه شکننده."""
    import time as _t
    last = None
    for attempt in range(6):
        c = sqlite3.connect(DB, timeout=20)
        try:
            r = c.execute(sql, args).fetchall(); c.commit(); return r
        except sqlite3.OperationalError as e:
            if "locked" not in str(e) and "busy" not in str(e):
                raise
            last = e; _t.sleep(3 + attempt * 2)
        finally:
            c.close()   # حتی هنگام خطا — اتصالِ باز با تراکنشِ نوشتن، خودِ باتری را قفل می‌کند
    raise last

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None):
    h = {}
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data, doseq=True).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(BASE + path, data=body, headers=h)
    try:
        r = op.open(req, timeout=25)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def clear_rl():
    q("delete from ratelimit")

def login(phone, admin=False):
    clear_rl()
    op = sess()
    go(op, "/login")
    go(op, "/login", {"phone": phone})
    go(op, "/login/verify", {"phone": phone, "code": otp_code(phone)})
    if admin:
        go(op, "/panel?key=" + DBM.owner_token())
    return op

def cust_login(phone):
    clear_rl()
    op = sess()
    go(op, "/me/login")
    go(op, "/me/login", {"phone": phone})
    go(op, "/me/login/verify", {"phone": phone, "code": otp_code(phone)})
    return op

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

created = {"customers": [], "uploads": [], "notifs": [], "follows": []}

# ─────────────────── T1 مدیریت فایل‌ها ───────────────────
def t1():
    print("── T1 مدیریت فایل‌ها (رسانه، gc، حذف، مسیرخارج)")
    op = login(ADMIN_PHONE, admin=True)
    st, b, _ = go(op, "/panel/media")
    check("T1.1", "صفحهٔ رسانه 200", st == 200)
    # فایل آزمونی بساز (رسانهٔ واقعی از save_image) — png یک‌پیکسلی
    import uploads as UP
    png = bytes.fromhex("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000a49444154789c6360000002000154a24f5f0000000049454e44ae426082")
    path_, err = UP.save_image(png, "qa12")
    created["uploads"].append(path_)
    check("T1.2", "ذخیرهٔ فایل آزمونی", bool(path_) and not err, f"{path_} {err}")
    # فایل در فهرست رسانه دیده شود
    st, b, _ = go(op, "/panel/media")
    check("T1.3", "فایل آزمونی در فهرست رسانه", path_ in b)
    # حذف با مسیرخارج → رد صادقانه (بدون حذف واقعی بیرون)
    st, b, url = go(op, "/panel/media/delete", {"path": "/assets/img/uploads/../../server/db.py"})
    st2, b2, url2 = go(op, "/panel/media/delete", {"path": "http://evil/x.png"})
    import os
    db_safe = os.path.exists("server/db.py")
    check("T1.4", "مسیرخارج ×2 → «یافت نشد» و بی‌خطر",
          "یافت نشد" in urllib.parse.unquote(url) and "یافت نشد" in urllib.parse.unquote(url2)
          and db_safe, f"{url} db={db_safe}")
    # حذف واقعی فایل آزمونی
    st, b, url = go(op, "/panel/media/delete", {"path": path_})
    import os
    check("T1.5", "حذف واقعی", "حذف شد" in urllib.parse.unquote(url)
          and not os.path.exists("site/" + path_))
    created["uploads"].remove(path_)
    # gc: گزارش واقعی و بی‌خطر
    n_files = len(os.listdir("site/assets/img/uploads"))
    st, b, url = go(op, "/panel/media/gc", {})
    check("T1.6", "gc اجرا شد با گزارش", "پاک شد" in urllib.parse.unquote(url))
    # دکاندار 403
    sop = login(SHOP_PHONE)
    g1 = go(sop, "/panel/media")[0]
    g2 = go(sop, "/panel/media/delete", {"path": "/assets/img/uploads/qa-photo.webp"})[0]
    g3 = go(sop, "/panel/media/gc", {})[0]
    check("T1.7", "دکاندار 403×3", (g1, g2, g3) == (403, 403, 403), str((g1, g2, g3)))
    check("T1.8", "فایل صحنه پس از تلاش دکاندار سالم",
          os.path.exists("site/assets/img/uploads/qa-photo.webp"))

# ─────────────────── T2 مشتری‌ها ───────────────────
def t2():
    print("── T2 مشتری‌ها (مسدودی و پیامدها، حذف کامل، وحشی)")
    op = login(ADMIN_PHONE, admin=True)
    # مشتری موقت بساز
    q("insert into customers(id,phone,name,status) values(555,'09360001122','مشتری آزمون۱۲','active')")
    created["customers"].append(555)
    q("insert into follows(customer_id,biz_id) values(555,214)")
    created["follows"].append((555, 214))
    q("insert into points(customer_id,amount) values(555,7)")
    cop = cust_login("09360001122")
    st, b, _ = go(cop, "/me")
    check("T2.1", "مشتری موقت وارد شد", st == 200 and ("حساب" in b or "من" in b), f"st={st}")
    # مسدودی → سشن می‌میرد
    st, b, url = go(op, "/panel/customer/555", {"action": "block"})
    sess_alive = DBM.customer_session_get(q(
        "select token from customer_sessions where customer_id=555 limit 1")[0][0]) if q(
        "select count(*) from customer_sessions where customer_id=555")[0][0] else None
    st2, b2, _ = go(cop, "/me")
    check("T2.2", "مسدودی: وضعیت + سشن کشته شد", "مسدود" in urllib.parse.unquote(url)
          and sess_alive is None and st2 in (200, 303)
          and ("ورود" in b2 or "حساب" not in b2), f"{url} sess={sess_alive} st={st2}")
    # مسدود سفارش ثبت نمی‌کند (current_customer=None)
    st, b, url = go(cop, "/order/create", {"name": "مسدود", "phone": "09360001122",
                    "address": "آدرس", "items": json.dumps([
                        {"item_id": 336, "title": "کالای آزمون 1", "price": 1000, "qty": 1}])})
    check("T2.3", "مسدود سفارش ثبت نمی‌کند", "ثبت نشد" in urllib.parse.unquote(url) or "orders" not in url, url)
    # unblock → دوباره وارد می‌شود
    st, b, url = go(op, "/panel/customer/555", {"action": "unblock"})
    cop = cust_login("09360001122")
    st, b, _ = go(cop, "/me")
    check("T2.4", "آزادی → ورود دوباره کار می‌کند", st == 200)
    # وحشی ×2 (رفع v173)
    st, b, url = go(op, "/panel/customer/999999", {"action": "block"})
    st2, b2, url2 = go(op, "/panel/customer/999999/delete", {})
    check("T2.5", "وحشی مشتری ×2 → «نیست»", "نیست" in urllib.parse.unquote(url)
          and "نیست" in urllib.parse.unquote(url2), f"{url} {url2}")
    # حذف کامل: رد تازه با همهٔ پیوندها
    q("insert into customers(id,phone,name,status) values(556,'09360002233','حذف‌شدنی','active')")
    created["customers"].append(556)
    q("insert into follows(customer_id,biz_id) values(556,215)")
    created["follows"].append((556, 215))
    q("insert into points(customer_id,amount) values(556,3)")
    q("insert into notifications(customer_id,kind,text,link) values(556,'info','اعلان آزمون','')")
    q("insert into customer_sessions(token,customer_id,expires) values('tok556',556,9999999999)")
    st, b, url = go(op, "/panel/customer/556/delete", {})
    left = {
        "cust": q("select count(*) from customers where id=556")[0][0],
        "follow": q("select count(*) from follows where customer_id=556")[0][0],
        "points": q("select count(*) from points where customer_id=556")[0][0],
        "notif": q("select count(*) from notifications where customer_id=556")[0][0],
        "sess": q("select count(*) from customer_sessions where customer_id=556")[0][0],
    }
    check("T2.6", "حذف مشتری = همهٔ رد پا پاک", "حذف شد" in urllib.parse.unquote(url)
          and not any(left.values()), str(left))
    created["customers"].remove(556)
    created["follows"].remove((556, 215))
    # دکاندار 403
    sop = login(SHOP_PHONE)
    g1 = go(sop, "/panel/customers")[0]
    g2 = go(sop, "/panel/customer/555", {"action": "block"})[0]
    g3 = go(sop, "/panel/customer/555/delete", {})[0]
    check("T2.7", "دکاندار 403×3", (g1, g2, g3) == (403, 403, 403), str((g1, g2, g3)))

# ─────────────────── T3 دنبال‌کننده‌ها ───────────────────
def t3():
    print("── T3 دنبال‌کننده‌ها")
    n0 = q("select count(*) from follows where biz_id=214 and customer_id=17")[0][0]
    if n0:
        q("delete from follows where biz_id=214 and customer_id=17")
    cop = cust_login(CUST_PHONE)
    cid = q("select id from customers where phone=?", (CUST_PHONE,))[0][0]
    # روشن → شمارش +۱
    st, b, _ = go(cop, "/api/follow", {"biz_id": "214"})
    on1 = q("select count(*) from follows where biz_id=214 and customer_id=?", (cid,))[0][0]
    created["follows"].append((cid, 214))
    st2, b2, _ = go(cop, "/api/follow", {"biz_id": "214"})   # خاموش
    on2 = q("select count(*) from follows where biz_id=214 and customer_id=?", (cid,))[0][0]
    check("T3.1", "toggle: روشن→خاموش (DB واقعی)", on1 == 1 and on2 == 0, f"{on1}→{on2}")
    # دکان وحشی → 404
    st, b, _ = go(cop, "/api/follow", {"biz_id": "999999"})
    check("T3.2", "دکان وحشی → 404", st == 404, f"st={st}")
    # ناشناس → 403
    st, b, _ = go(sess(), "/api/follow", {"biz_id": "214"})
    check("T3.3", "ناشناس → 403", st == 403, f"st={st}")
    # فلگ خاموش → 403
    q("update settings set value='0' where key='follow_enabled'")
    time.sleep(5.2)
    st, b, _ = go(cop, "/api/follow", {"biz_id": "214"})
    q("update settings set value='1' where key='follow_enabled'")
    time.sleep(5.2)
    check("T3.4", "follow_enabled=0 → 403", st == 403, f"st={st}")
    # صفحهٔ پنل دنبال‌کننده‌ها
    op = login(ADMIN_PHONE, admin=True)
    st, b, _ = go(op, "/panel/follows")
    check("T3.5", "پنل دنبال‌کننده‌ها 200", st == 200)
    # صفحهٔ مشتری «دنبال‌شده‌ها»
    go(cop, "/api/follow", {"biz_id": "214"})
    created["follows"].append((cid, 214))
    st, b, _ = go(cop, "/me/following")
    check("T3.6", "/me/following دکان دنبال‌شده را دارد", st == 200 and "دکانٔ آزمون مالک یک" in b)

# ─────────────────── T4 اعلان همگانی ───────────────────
def t4():
    print("── T4 اعلان همگانی (broadcast)")
    op = login(ADMIN_PHONE, admin=True)
    # متن خالی
    st, b, url = go(op, "/panel/broadcast", {"text": ""})
    check("T4.1", "متن خالی رد", "الزامی" in urllib.parse.unquote(url), url)
    # ارسال به همهٔ فعال‌ها؛ مسدود می‌گیرد؟
    q("update customers set status='blocked' where id=555") if q(
        "select count(*) from customers where id=555")[0][0] else None
    n_active = q("select count(*) from customers where status='active'")[0][0]
    n0 = q("select count(*) from notifications")[0][0]
    st, b, url = go(op, "/panel/broadcast", {"text": "پیام همگانی آزمون فاز ۱۲ — اطلاع‌رسانی.",
                    "link": "/businesses"})
    n1 = q("select count(*) from notifications")[0][0]
    n_blocked_got = q("select count(*) from notifications nt join customers c on c.id=nt.customer_id "
                      "where c.status='blocked' and nt.text like '%همگانی آزمون%'")[0][0]
    created["notifs"].append("همگانی آزمون")
    check("T4.2", "ارسال به همهٔ فعال‌ها (نه مسدودها)",
          "ارسال شد" in urllib.parse.unquote(url) and n1 - n0 == n_active and n_blocked_got == 0,
          f"sent={n1-n0} فعال={n_active} مسدودگرفت={n_blocked_got}")
    # لینک خارجی → پاک می‌شود (گارد startswith /)
    st, b, url = go(op, "/panel/broadcast", {"text": "پیام دوم همگانی آزمون فاز ۱۲.",
                    "link": "https://evil.example"})
    lnk = q("select link from notifications where text like '%پیام دوم همگانی%' limit 1")
    created["notifs"].append("پیام دوم همگانی")
    check("T4.3", "لینک خارجی رد می‌شود", lnk and lnk[0][0] == "", str(lnk))
    # XSS متن اعلان — رندر در /me/notifications escaped؟
    st, b, url = go(op, "/panel/broadcast", {"text": "پیلواد <img src=x onerror=alert(6)> آزمون فاز ۱۲.",
                    "link": ""})
    created["notifs"].append("پیلواد")
    cop = cust_login(CUST_PHONE)
    st, b, _ = go(cop, "/me/notifications")
    check("T4.4", "متن اعلان escaped",
          "&lt;img" in b and "<img src=x onerror" not in b, None)
    # دکاندار 403
    sop = login(SHOP_PHONE)
    g1 = go(sop, "/panel/broadcast")[0]
    g2 = go(sop, "/panel/broadcast", {"text": "هک"})[0]
    check("T4.5", "دکاندار 403×2", (g1, g2) == (403, 403), str((g1, g2)))

def main():
    try:
        t1()
        t2()
        t3()
        t4()
    finally:
        for cid in created["customers"]:
            try:
                DBM.customer_delete(cid)
            except Exception:
                pass
        for f in created["follows"]:
            q("delete from follows where customer_id=? and biz_id=?", f)
        for img in created["uploads"]:
            try:
                import os
                fp = "site/" + img
                if os.path.exists(fp):
                    os.remove(fp)
            except Exception:
                pass
        for pat in created["notifs"]:
            q("delete from notifications where text like ?", ("%"+pat+"%",))
        q("delete from customers where id in (555,556)")
        q("delete from follows where customer_id in (555,556) or biz_id in (214,215) and customer_id=17")
        q("delete from points where customer_id in (555,556)")
        q("delete from notifications where text like '%آزمون فاز ۱۲%' or text like '%همگانی آزمون%'")
        q("update customers set status='active'")
        q("update settings set value='1' where key='follow_enabled'")
        q("delete from ratelimit"); q("delete from otp")
    json.dump(RESULTS, open("qa/phase12-results.json", "w"), ensure_ascii=False, indent=1)
    fails = [r for r in RESULTS if not r["ok"]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(fails)} | قرمز: {len(fails)}")
    for r in fails:
        print("  ❌", r["id"], r["name"], "—", r["detail"])
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
