# -*- coding: utf-8 -*-
"""رندر مستقل صفحهٔ کد ورود برای اثبات نمایش پیام throttle در محیط عملی."""
import sys
sys.path.insert(0, 'server')
import views_owner as O

def login_unified_render():
    s = {'title': 'بازارچه', 'reg_open': '1'}
    html = O.login_unified(s, 'code', '09361112233',
                           note='کد قبلی هنوز معتبر است (۱۲۰ ثانیه).',
                           dev_code='', nxt='')
    return html
