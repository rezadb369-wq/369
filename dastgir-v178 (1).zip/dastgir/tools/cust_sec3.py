# -*- coding: utf-8 -*-
"""بخش ۳ — کشف: کاتالوگ/دسته‌ها/شهرها + فیلترهای ترکیبی + صفحه‌بندی + حالت خالی."""
import sys, time, urllib.parse
sys.path.insert(0, 'tools')
from cust_lib import *
from playwright.sync_api import sync_playwright

recs = []
log = print

def bodycount(pg):
    """شمار کسب‌وکارهای اعلام‌شده در سرصفحهٔ نتایج."""
    t = pg.inner_text('body')
    import re
    m = re.search(r'(\d+) کسب', t)
    return int(m.group(1)) if m else None

with sync_playwright() as pw:
    br = pw.chromium.launch()
    cc = ctx(br); pg = cc.new_page()

    for p, nm in (('/catalog', 'sec3-catalog'), ('/categories', 'sec3-categories'), ('/cities', 'sec3-cities')):
        r = audit(pg, nm, p)
        recs.append(r); log(fmt(r))

    # کلیک یک شهر → صفحهٔ نتایج
    pg.goto(BASE + '/cities')
    pg.wait_for_load_state('networkidle')
    city = pg.locator('a[href^="/businesses?city="]').first
    chref = city.get_attribute('href')
    cname = urllib.parse.unquote(chref.split('city=')[1])
    pg.goto(BASE + chref)
    pg.wait_for_load_state('networkidle')
    n = bodycount(pg)
    r = audit(pg, 'sec3-city', chref)
    r['extra'] = f'شهر «{cname}» → شمار اعلامی: {n}'
    recs.append(r); log(fmt(r), '|', r['extra'])

    # فیلترهای /businesses
    tests = [
        ('sec3-q', '/businesses?q=' + urllib.parse.quote('آزمون'), 'جست‌وجوی «آزمون»'),
        ('sec3-cat', '/businesses?cat=food', 'دستهٔ خوراک'),
        ('sec3-newest', '/businesses?sort=newest', 'مرتب‌سازی جدیدترین'),
        ('sec3-combo', '/businesses?q=' + urllib.parse.quote('آزمون') + '&cat=food', 'ترکیبی q+cat'),
        ('sec3-page2', '/businesses?page=2', 'صفحهٔ ۲'),
        ('sec3-empty', '/businesses?q=' + urllib.parse.quote('zzzنبودzzz'), 'نتیجهٔ خالی'),
    ]
    for nm, p, lbl in tests:
        r = audit(pg, nm, p)
        empty_state = ('یافت نشد' in pg.inner_text('body')) or ('نتیجه‌ای نبود' in pg.inner_text('body'))
        n = bodycount(pg)
        if 'empty' in nm:
            r['extra'] = f'حالت خالی پیام دارد: {empty_state}'
        else:
            r['extra'] = f'{lbl} → شمار اعلامی: {n}'
        recs.append(r); log(fmt(r), '|', r['extra'])

    # فیلتر شهر از داخل /businesses (چیپ‌های شهر)
    pg.goto(BASE + '/businesses')
    pg.wait_for_load_state('networkidle')
    citylinks = pg.evaluate("()=>[...document.querySelectorAll('a[href*=\"city=\"]')].length")
    r = {'name': 'sec3-citylinks', 'url': '/businesses', 'status': 200,
         'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
         'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
         'extra': f'لینک شهر در /businesses: {citylinks}'}
    recs.append(r); log('ℹ️ sec3-citylinks |', r['extra'])

    cc.close(); br.close()

save(recs, '3-کشف')
reds = [r for r in recs if 'False' in str(r.get('extra', '')) or r['status'] != 200 or r['overflow_px'] > 0 or r['broken_images']]
print(f"\n── بخش ۳: {len(recs)} سنج | قرمز: {len(reds)}")
