# -*- coding: utf-8 -*-
"""
v142 — fcm.py web-push layer, hermetic suite (no network, no live data).

Covers:
  · PKCS#8 + PKCS#1 private-key parsing
  · RS256 signing — cross-verified against OpenSSL when it is installed
  · JWT compact shape
  · service-JSON validation + config gating
  · OAuth2 access-token exchange (mocked HTTP) + caching + failure
  · HTTP v1 message send (mocked HTTP): success / dead token / HTTP error
  · push_for end-to-end with real DB rows and mocked HTTP, incl. pruning

    python3 tools/test_fcm_v142.py
"""
import os
import sys
import json
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


# ------------------------------------------------------------------ hermetic DB
def setup_db():
    import db
    db.DB_PATH = os.path.join(tempfile.mkdtemp(prefix="bzfcm"), "t.db")
    db.init()
    return db


def svc_json(keyfile):
    pem = open(os.path.join(HERE, "fixtures", keyfile), encoding="utf-8").read()
    return json.dumps({
        "type": "service_account",
        "project_id": "test-fire-proj",
        "private_key": pem,
        "client_email": "push@test-fire-proj.iam.gserviceaccount.com",
        "token_uri": "https://oauth2.googleapis.com/token",
    })


# ------------------------------------------------------------------ HTTP mocks
class MockHTTP:
    def __init__(self):
        self.form_calls = []      # (url, fields)
        self.json_calls = []      # (url, payload, headers)
        self.form_resp = (200, b'{"access_token":"AT-123","expires_in":3600}', None)
        self.json_resp = (200, {"ok": True}, None)
        self.pruned = []

    def post_form(self, url, fields):
        self.form_calls.append((url, fields))
        return self.form_resp

    def post_json(self, url, payload, headers):
        self.json_calls.append((url, payload, headers))
        return self.json_resp


def main():
    import fcm
    db = setup_db()

    head("پارس کلید و امضای RS256")
    n1, e1, d1 = fcm.parse_rsa_private(
        open(os.path.join(HERE, "fixtures", "rsa_test.pem"), encoding="utf-8").read())
    n2, e2, d2 = fcm.parse_rsa_private(
        open(os.path.join(HERE, "fixtures", "rsa_test_pkcs8.pem"), encoding="utf-8").read())
    check("پارس PKCS#8 (دو رمزنگاری یک کلید) یکسان است",
          (n1, e1, d1) == (n2, e2, d2) and n1.bit_length() == 2048)
    n3, e3, d3 = fcm.parse_rsa_private(
        open(os.path.join(HERE, "fixtures", "rsa_test_pkcs1.pem"), encoding="utf-8").read())
    check("پارس PKCS#1 سنتی هم کار می‌کند", n3.bit_length() == 2048 and n3 != n1)
    import hashlib
    dig = hashlib.sha256("پرداخت ۱۲۳ تومان".encode("utf-8")).digest()
    sig = fcm._rsa_sign(n1, d1, dig)
    k = (n1.bit_length() + 7) // 8
    em = pow(int.from_bytes(sig, "big"), e1, n1).to_bytes(k, "big")
    t = fcm._SHA256_DIGESTINFO + dig
    check("امضای PKCS#1 v1.5 با جبر عمومی درست از آب درمی‌آید",
          em == b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t)
    import subprocess
    if subprocess.run(["which", "openssl"], capture_output=True).returncode == 0:
        open("/tmp/_m.bin", "wb").write("پرداخت ۱۲۳ تومان".encode("utf-8"))
        open("/tmp/_s.bin", "wb").write(sig)
        subprocess.run(["openssl", "rsa", "-in",
                        os.path.join(HERE, "fixtures", "rsa_test.pem"),
                        "-pubout", "-out", "/tmp/_p.pub"],
                       capture_output=True)
        r = subprocess.run(["openssl", "dgst", "-sha256", "-verify", "/tmp/_p.pub",
                            "-signature", "/tmp/_s.bin", "/tmp/_m.bin"],
                           capture_output=True, text=True)
        check("تأیید متقاطع امضا با OpenSSL", r.returncode == 0,
              r.stderr.strip()[:120])
    else:
        print("  (openssl یافت نشد — تأیید متقاطع رد شد؛ جبر عمومی بالا معتبر است)")

    jwt = fcm.jwt_rs256({"iss": "a@b", "scope": "s", "aud": "https://t",
                         "iat": 1, "exp": 2}, open(
            os.path.join(HERE, "fixtures", "rsa_test.pem"), encoding="utf-8").read())
    parts = jwt.split(".")
    check("JWT ساختار فشردهٔ ۳-بخشی دارد و header درست است",
          len(parts) == 3 and json.loads(fcm.b64u_dec(parts[0]))["alg"] == "RS256")
    check("b64u رفت‌وبرگشت", fcm.b64u(b"ab") == "YWI"
          and fcm.b64u_dec("YWI") == b"ab")

    head("اعتبارسنجی و دروازهٔ تنظیم")
    ok, err = fcm.validate_service_json("")
    check("خالی = بدون خطا", ok and err == "")
    ok, err = fcm.validate_service_json("{not json")
    check("JSON خراب رد می‌شود", not ok and "معتبر نیست" in err)
    ok, err = fcm.validate_service_json("[1,2]")
    check("غیر-شیء رد می‌شود", not ok)
    ok, err = fcm.validate_service_json(
        json.dumps({"project_id": "p"}))
    check("فیلدهای ناقص رد می‌شوند (client_email/private_key کم است)",
          not ok and "client_email" in err and "private_key" in err)
    ok, err = fcm.validate_service_json(svc_json("rsa_test_pkcs8.pem"))
    check("JSON کامل پذیرفته می‌شود", ok and err == "")
    check("بدون کلید: پیکربندی‌نشده است",
          fcm.configured({"fcm_service_json": "", "fcm_vapid_pub": ""}) is False)
    check("با کلید+VAPID: پیکربندی شده",
          fcm.configured({"fcm_service_json": svc_json("rsa_test_pkcs8.pem"),
                          "fcm_vapid_pub": "BEl"}) is True)
    cfg = db.get_settings()
    db.set_settings({"fcm_service_json": svc_json("rsa_test_pkcs8.pem"),
                     "fcm_vapid_pub": "BE-1zz"})
    check("load_service از تنظیمات واقعی می‌خواند",
          fcm.load_service() and fcm.load_service()["project_id"] == "test-fire-proj")
    db.set_settings({"fcm_service_json": cfg.get("fcm_service_json") or "",
                     "fcm_vapid_pub": cfg.get("fcm_vapid_pub") or ""})

    head("توکن OAuth2 (HTTP شبیه‌سازی‌شده)")
    svc = json.loads(svc_json("rsa_test_pkcs8.pem"))
    m = MockHTTP()
    old_form, old_json = fcm._post_form, fcm._post_json
    try:
        fcm._post_form, fcm._post_json = m.post_form, m.post_json
        fcm._TOKEN_CACHE.update({"token": None, "until": 0.0})
        tok, err = fcm.access_token(svc)
        check("توکن از پاسخ OAuth2 گرفته می‌شود", tok == "AT-123" and not err, err)
        assert m.form_calls and m.form_calls[0][1]["grant_type"] == \
            "urn:ietf:params:oauth:grant-type:jwt-bearer"
        check("assertion JWT در grant_type ارسال می‌شود", True)
        tok2, _ = fcm.access_token(svc)
        check("توکن تا انقضا کش می‌شود (درخواست دوم نمی‌زند)",
              tok2 == "AT-123" and len(m.form_calls) == 1, f"calls={len(m.form_calls)}")
        fcm._TOKEN_CACHE["until"] = 0.0
        m.form_resp = (400, b'{"error":"invalid_grant"}', None)
        tok3, err3 = fcm.access_token(svc)
        check("خطای OAuth2 بدون کرش گزارش می‌شود",
              tok3 is None and err3 and "HTTP 400" in err3, str(err3))

        head("ارسال HTTP v1 (شبیه‌سازی‌شده)")
        fcm._TOKEN_CACHE.update({"token": "AT-123", "until": 0.0})
        m.form_resp = (200, b'{"access_token":"AT-123","expires_in":3600}', None)
        m.json_resp = (200, {"name": "projects/test-fire-proj/messages/1"}, None)
        ok_s, dt = fcm.send("TOK-X", "دست گیر", "پیام بدنه", "/my/plan",
                            svc=svc, atoken="AT-123")
        check("ارسال موفق", ok_s and dt == "sent", dt)
        url, payload, hdrs = m.json_calls[-1]
        check("نشانی درست پروژه در URL",
              url == "https://fcm.googleapis.com/v1/projects/test-fire-proj/messages:send")
        check("بدنهٔ message دارای token/notification/data است",
              payload["message"]["token"] == "TOK-X"
              and payload["message"]["notification"]["body"] == "پیام بدنه"
              and payload["message"]["data"]["url"] == "/my/plan")
        check("Bearer Authorization ارسال می‌شود",
              hdrs.get("Authorization") == "Bearer AT-123")
        m.json_resp = (404, {"error": {"message": "Requested entity was not found."}}, None)
        ok_g, dt_g = fcm.send("TOK-DEAD", "دست گیر", "ب", "", svc=svc, atoken="AT-123")
        check("توکن مرده = وضعیت gone برای جارو", not ok_g and dt_g == "gone", dt_g)
        m.json_resp = (400, {"error": {"message": "InvalidMessage"}}, None)
        ok_h, dt_h = fcm.send("TOK-X", "دست گیر", "ب", "", svc=svc, atoken="AT-123")
        check("خطای HTTP دیگر بدون کرش گزارش می‌شود",
              not ok_h and dt_h == "HTTP 400", dt_h)

        head("push_for سرتاسری با DB واقعی (شبیه‌سازی‌شده)")
        db.set_settings({"fcm_service_json": svc_json("rsa_test_pkcs8.pem"),
                         "fcm_vapid_pub": "BE-1zz"})
        db._run("INSERT INTO customers(phone,name) VALUES(?,?)", ("09121110000", "ت"))
        cid = db._one("SELECT id FROM customers WHERE phone='09121110000'")["id"]
        db.push_sub_save("cust", cid, {
            "endpoint": "https://fcm.googleapis.com/fcm/send/REAL-TOK-1",
            "keys": {"p256dh": "x", "auth": "y"}})
        db.push_sub_save("cust", cid, {
            "endpoint": "https://fcm.googleapis.com/fcm/send/REAL-TOK-2",
            "keys": {"p256dh": "x", "auth": "y"}})
        m.form_calls.clear(); m.json_calls.clear()
        m.json_resp = (200, {"name": "m1"}, None)
        r_ok, r_msg = fcm.push_for("cust", cid, "بدنهٔ تست سرتاسری", "/b/slug")
        check("push_for برای هر دو اشتراک ارسال می‌کند",
              r_ok and len(m.json_calls) == 2
              and m.json_calls[0][1]["message"]["token"] == "REAL-TOK-1"
              and m.json_calls[1][1]["message"]["token"] == "REAL-TOK-2",
              f"calls={len(m.json_calls)} {r_msg}")
        m.json_resp = (404, {"error": {"message": "UNREGISTERED"}}, None)
        r2, _ = fcm.push_for("cust", cid, "ب", "")
        check("توکن‌های مرده در push_for جارو می‌شوند",
              not r2 and len(db.push_tokens("cust", cid)) == 0,
              f"rows={len(db.push_tokens('cust', cid))}")
        db.set_settings({"fcm_service_json": "", "fcm_vapid_pub": ""})
        r3, msg3 = fcm.push_for("cust", cid, "ب", "")
        check("بدون تنظیم = خاموش بی‌خطا با دلیل صادقانه",
              r3 is False and msg3 == "unconfigured", msg3)
        db.set_settings({"fcm_service_json": svc_json("rsa_test_pkcs8.pem"),
                         "fcm_vapid_pub": "BE-1zz"})
        r4, msg4 = fcm.push_for("cust", cid + 999, "ب", "")
        check("بدون اشتراک = ارسال نمی‌شود (no subscription)",
              r4 is False and msg4 == "no subscription", msg4)
        db.set_settings({"fcm_service_json": "", "fcm_vapid_pub": ""})
    finally:
        fcm._post_form, fcm._post_json = old_form, old_json
        fcm._TOKEN_CACHE.update({"token": None, "until": 0.0})

    print("\n" + ("=" * 52))
    print(f"نتیجه: {ok_n} موفق / {bad_n} ناموفق")
    if FAILS:
        print("شکست‌ها:")
        for f in FAILS:
            print("  -", f)
        sys.exit(1)
    print("همه سبز ✅")


if __name__ == "__main__":
    main()
