# -*- coding: utf-8 -*-
"""بخش ۵ — کالا و خرید: افزودن به سبد، ثبت سفارش، پیگیری، لغو (مستقیم/درخواستی)، خبرم‌کن."""
import sys, sqlite3, time, json
sys.path.insert(0, 'tools')
from cust_lib import *
from playwright.sync_api import sync_playwright

recs = []
log = print

def login_cust(br, phone='09361112233'):
    c = sqlite3.connect(DB)
    c.execute("delete from otp"); c.execute("delete from ratelimit"); c.commit()
    u = ctx(br); pg = u.new_page()
    pg.on('dialog', lambda d: d.accept())
    pg.goto(BASE + '/login')
    pg.fill('form[action="/login"] input[name="phone"]', phone)
    pg.click('form[action="/login"] button[type="submit"]', no_wait_after=True)
    pg.wait_for_selector('input[name="code"]')
    pg.fill('input[name="code"]', otp_code(phone))
    try:
        pg.click('form[action="/login/verify"] button[type="submit"]', no_wait_after=True, timeout=6000)
    except Exception:
        pass
    pg.wait_for_url('**/my', timeout=20000)
    return u, pg

with sync_playwright() as pw:
    br = pw.chromium.launch()
    u, pg = login_cust(br)

    # ── 5.1 صفحهٔ کالای موجود ──
    r = audit(pg, 'sec5-item', '/item/336')
    recs.append(r); log(fmt(r))

    # ── 5.2 افزودن به سبد ×۲ ──
    pg.click('button:has-text("افزودن به سبد")', no_wait_after=True)
    pg.wait_for_timeout(800)
    pg.goto(BASE + '/item/336'); pg.wait_for_load_state('networkidle')
    pg.click('button:has-text("افزودن به سبد")', no_wait_after=True)
    pg.wait_for_timeout(800)
    badge = pg.evaluate("""()=>{const b=document.querySelector('[data-cart-count],.cart-count,[class*=badge][class*=cart]');
      return b? b.innerText.trim() : document.cookie.includes('cart')? 'cookie' : '?'}""")
    log("شمار سبد پس از دو بار افزودن:", badge)

    # ── 5.3 سبد ──
    r = audit(pg, 'sec5-cart', '/cart')
    cart_txt = pg.inner_text('body')
    r['extra'] = f'کالا در سبد: {"کالای آزمون 1" in cart_txt} | شمار: {badge}'
    recs.append(r); log(fmt(r), '|', r['extra'])

    # ── 5.4 سقف تعداد: 999 باید به 99 محدود شود (بدون کرش) ──
    pg.evaluate("""()=>{const i=document.querySelector('input[name="items"]');
      if(i){const a=JSON.parse(i.value); a[0].qty=999; i.value=JSON.stringify(a);} }""")
    pg.fill('form[action="/order/create"] input[name="name"]', 'مشتری آزمون')
    pg.fill('form[action="/order/create"] input[name="phone"]', '09361112233')
    pg.click('form[action="/order/create"] button[type="submit"]', no_wait_after=True)
    try:
        pg.wait_for_url('**/order/ok**', timeout=15000)
    except Exception:
        pass
    pg.wait_for_timeout(500)
    cc2 = sqlite3.connect(DB)
    row = cc2.execute("select qty from order_items order by id desc limit 1").fetchone()
    clamped = bool(row) and row[0] <= 99
    cap_ok_url = '/order/ok' in pg.url
    r = {'name': 'sec5-cap', 'url': pg.url.replace(BASE, ''), 'status': 200,
         'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
         'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
         'extra': f'۹۹۹ → {row[0] if row else "?"} محدود شد: {clamped} | رسید: {cap_ok_url}'}
    recs.append(r); log(('✅' if clamped and cap_ok_url else '❌'), 'sec5-cap |', r['extra'])
    # برگرد به سبد برای سفارش اصلی
    pg.goto(BASE + '/cart')
    try:
        pg.wait_for_load_state('networkidle', timeout=10000)
    except Exception:
        pass

    # ── 5.5 سفارش واقعی ──
    pg.goto(BASE + '/cart')
    try:
        pg.wait_for_load_state('networkidle', timeout=10000)
    except Exception:
        pass
    pg.fill('form[action="/order/create"] input[name="name"]', 'مشتری آزمون')
    pg.fill('form[action="/order/create"] input[name="phone"]', '09361112233')
    pg.click('form[action="/order/create"] button[type="submit"]', no_wait_after=True)
    try:
        pg.wait_for_url('**/order/ok**', timeout=15000)
    except Exception:
        pass
    order_url = pg.url
    ok_page = '/order/ok' in order_url
    r = audit(pg, 'sec5-order-ok', order_url.replace(BASE, ''))
    r['extra'] = f'رسید سفارش: {ok_page} | {order_url.replace(BASE, "")}'
    recs.append(r); log(('✅' if ok_page else '❌'), 'sec5-order-ok |', r['extra'])
    import re as _re
    m = _re.search(r'id=(\d+)', order_url)
    oid = int(m.group(1)) if m else None
    log("شناسهٔ سفارش:", oid)

    # ── 5.6 پیگیری در /me/orders ──
    r = audit(pg, 'sec5-orders', '/me/orders')
    listed = 'کالای آزمون 1' in pg.inner_text('body') or 'دکانٔ آزمون' in pg.inner_text('body')
    r['extra'] = f'سفارش در فهرست: {listed}'
    recs.append(r); log(fmt(r), '|', r['extra'])

    # ── 5.7 لغو مستقیم سفارش تازه (<۳۰دقیقه) ──
    if oid:
        pg.goto(BASE + f'/me/order/{oid}'); pg.wait_for_load_state('networkidle')
        pg.screenshot(path=f'{SHOTS}/sec5-order-detail.png')
        cancel_btn = pg.locator('button:has-text("لغو"), a:has-text("لغو")').first
        has_cancel = cancel_btn.count() > 0
        if has_cancel:
            cancel_btn.click(no_wait_after=True)
            try:
                pg.wait_for_url('**?ok=**', timeout=10000)
            except Exception:
                pass
            pg.wait_for_timeout(700)
            st_now = sqlite3.connect(DB).execute(
                "select status,cancel_requested from orders where id=?", (oid,)).fetchone()
            direct = st_now == ('cancelled', 0)
            r = {'name': 'sec5-cancel-direct', 'url': pg.url.replace(BASE, ''), 'status': 200,
                 'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
                 'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
                 'extra': f'لغو مستقیم سفارش تازه: {direct} | DB: {st_now}'}
            recs.append(r); log(('✅' if direct else '❌'), 'sec5-cancel-direct |', r['extra'])

        # ── 5.8 سفارش کهنه → لغو به‌صورت درخواست ──
        # سفارش تازهٔ دوم برای سناریوی «کهنه»
        pg.goto(BASE + '/item/336'); pg.wait_for_load_state('networkidle')
        pg.click('button:has-text("افزودن به سبد")', no_wait_after=True)
        pg.wait_for_timeout(600)
        pg.goto(BASE + '/cart')
        try:
            pg.wait_for_load_state('networkidle', timeout=10000)
        except Exception:
            pass
        pg.fill('form[action="/order/create"] input[name="name"]', 'مشتری آزمون')
        pg.fill('form[action="/order/create"] input[name="phone"]', '09361112233')
        pg.click('form[action="/order/create"] button[type="submit"]', no_wait_after=True)
        try:
            pg.wait_for_url('**/order/ok**', timeout=15000)
        except Exception:
            pass
        import re as _re2
        m2 = _re2.search(r'id=(\d+)', pg.url)
        oid2 = int(m2.group(1)) if m2 else None
        c = sqlite3.connect(DB)
        c.execute("update orders set created=datetime('now','-2 hours') where id=?", (oid2,))
        c.commit()
        pg.goto(BASE + f'/me/order/{oid2}'); pg.wait_for_load_state('networkidle')
        cb = pg.locator('button:has-text("لغو")').first
        if cb.count() > 0:
            cb.click(no_wait_after=True)
            try:
                pg.wait_for_url('**?ok=**', timeout=10000)
            except Exception:
                pass
            pg.wait_for_timeout(700)
            st2 = sqlite3.connect(DB).execute(
                "select status,cancel_requested from orders where id=?", (oid2,)).fetchone()
            reqd = bool(st2) and st2[1] == 1 and st2[0] != 'cancelled'
            r = {'name': 'sec5-cancel-request', 'url': pg.url.replace(BASE, ''), 'status': 200,
                 'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
                 'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
                 'extra': f'سفارش کهنه → درخواست لغو برای دکاندار: {reqd} | DB: {st2}'}
            recs.append(r); log(('✅' if reqd else '❌'), 'sec5-cancel-request |', r['extra'])

    # ── 5.9 کالای ناموجود: خبرم‌کن ──
    r = audit(pg, 'sec5-item-out', '/item/2101')
    no_buy = pg.locator('button:has-text("افزودن به سبد")').count() == 0
    r['extra'] = f'بدون دکمهٔ خرید: {no_buy}'
    recs.append(r); log(fmt(r), '|', r['extra'])
    notify = pg.locator('button:has-text("خبرم"), a:has-text("خبرم")').first
    if notify.count() > 0:
        notify.click()
        pg.wait_for_load_state('networkidle'); pg.wait_for_timeout(600)
        sent = pg.evaluate("""()=>{const t=document.querySelector('.toast,[class*=toast],[role=alert]');
          return t? t.innerText.slice(0,60) : ''}""")
        r = {'name': 'sec5-notify-me', 'url': '/item/2101', 'status': 200,
             'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
             'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
             'extra': f'کلیک خبرم‌کن: توست=«{sent.strip()[:40]}»'}
        recs.append(r); log('✅/❌ sec5-notify-me |', r['extra'])

    u.close(); br.close()

# ثبت شد؟
c = sqlite3.connect(DB)
n = c.execute("select count(*) from stock_requests where item_id=2101").fetchone()[0]
log("ردیف‌های stock_requests برای ۲۱۰۱:", n)

save(recs, '5-خرید')
reds = [r for r in recs if 'False' in str(r.get('extra', ''))]
print(f"\n── بخش ۵: {len(recs)} سنج | قرمز: {len(reds)}")
