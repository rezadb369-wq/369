#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۹ — صاحبان و اعتماد: صاحبان کسب‌وکار · درخواست تصاحب · تأیید تغییرات · نشان‌ها.
چرخهٔ کامل تصاحب/رد، صف تغییرات روشن/خاموش، نشان خودکار، اعلان‌ها.
هر تست اثر واقعی را در پایگاه/صفحه بررسی می‌کند و تمیزکاری برمی‌گرداند."""
import re, sys, json, sqlite3, time, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []
A_BIZ = 214
A_SLUG = "dkan-azmvn-malk-yk"
SHOP_PHONE = "09352223344"     # حساب دکاندار صحنه (id=2)
ADMIN_PHONE = "09131110011"

def q(sql, args=()):
    c = sqlite3.connect(DB); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None):
    h = {}
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data, doseq=True).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(BASE + path, data=body, headers=h)
    try:
        r = op.open(req, timeout=25)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def clear_rl():
    q("delete from ratelimit")

def login(phone, admin=False):
    clear_rl()
    op = sess()
    go(op, "/login")
    go(op, "/login", {"phone": phone})
    go(op, "/login/verify", {"phone": phone, "code": otp_code(phone)})
    if admin:
        go(op, "/panel?key=" + DBM.owner_token())
    return op

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

created = {"owners": [], "claims": [], "edits": [], "badges": [], "notifs": []}

# ─────────────────── T1 صاحبان کسب‌وکار ───────────────────
def t1():
    print("── T1 صاحبان (فهرست، مسدود/آزاد، حذف بی‌دکان)")
    op = login(ADMIN_PHONE, admin=True)
    st, b, _ = go(op, "/panel/owners")
    check("T1.1", "فهرست صاحبان 200", st == 200)
    # مسدود/آزاد واقعی (حساب دکاندار 2) — پایان دور active
    st, b, url = go(op, "/panel/owner/2", {"status": "blocked"})
    cur = q("select status from owners where id=2")[0][0]
    check("T1.2", "مسدودسازی حساب", "تغییر کرد" in urllib.parse.unquote(url) and cur == "blocked", f"{cur}")
    # ورود حساب مسدود: سشن صادر نمی‌شود → پنل خودش باز نمی‌شود
    sop = login(SHOP_PHONE)
    st, b, _ = go(sop, "/my")
    dash = st == 200 and ("کسب‌وکارهای من" in b or "داشبورد" in b or "دکان‌های من" in b)
    check("T1.3", "حساب مسدود وارد پنل خودش نمی‌شود", not dash, f"st={st}")
    st, b, url = go(op, "/panel/owner/2", {"status": "active"})
    check("T1.4", "آزادسازی", q("select status from owners where id=2")[0][0] == "active")
    # وضعیت جعلی (رفع v172)
    st, b, url = go(op, "/panel/owner/2", {"status": "hacked"})
    check("T1.5", "وضعیت جعلی → «معتبر نیست»", "معتبر نیست" in urllib.parse.unquote(url)
          and q("select status from owners where id=2")[0][0] == "active", url)
    # وحشی (رفع v172)
    st, b, url = go(op, "/panel/owner/999999", {"status": "active"})
    st2, b2, url2 = go(op, "/panel/owner/999999", {"action": "delete", "status": "x"})
    check("T1.6", "وحشی صاحب → «نیست» ×2", "نیست" in urllib.parse.unquote(url)
          and "نیست" in urllib.parse.unquote(url2), f"{url} {url2}")
    # حذف حساب موقت بی‌دکان (بدون دست زدن به پایه‌ها)
    q("insert into owners(id,phone,status) values(777,'09127776666','active')")
    created["owners"].append(777)
    st, b, url = go(op, "/panel/owner/777", {"action": "delete", "status": "x"})
    check("T1.7", "حذف حساب بی‌دکان", "حذف شد" in urllib.parse.unquote(url)
          and not q("select * from owners where id=777"))
    created["owners"].remove(777)

# ─────────────────── T2 درخواست تصاحب ───────────────────
def t2():
    print("── T2 تصاحب (چرخهٔ کامل، دِدوپ، رقبا، وحشی)")
    op = login(ADMIN_PHONE, admin=True)
    sop = login(SHOP_PHONE)
    # دکان 215 بی‌مالک است → چرخهٔ کامل روی آن (پایان دور NULL)
    st, b, url = go(sop, "/my/claim", {"biz_id": "215", "note": "این دکان مال من است؛ مدارک آماده است."})
    row = q("select id,status from claims where biz_id=215 and owner_id=2")
    ok = len(row) == 1 and row[0][1] == "pending"
    cid = row[0][0] if row else 0
    created["claims"].append(cid)
    check("T2.1", "ثبت درخواست تصاحب → pending", ok, str(row))
    # دِدوپ
    st, b, url = go(sop, "/my/claim", {"biz_id": "215", "note": "تکراری"})
    check("T2.2", "درخواست تکراری رد با پیام", "قبلاً ثبت شده" in urllib.parse.unquote(url), url)
    # دکانِ صاحب‌دار رد (صحنه: مالک موقت 86 روی 216 — پایان دور NULL)
    q("update businesses set owner_id=86 where id=216")
    st, b, url = go(sop, "/my/claim", {"biz_id": "216", "note": "صاحب‌دار"})
    n = q("select count(*) from claims where biz_id=216")[0][0]
    check("T2.3", "دکان صاحب‌دار رد", "تأیید شده" in urllib.parse.unquote(url) and n == 0, f"{url} n={n}")
    q("update businesses set owner_id=NULL where id=216")
    # دکانِ ناموجود → پیام تمیز نه 500 (رفع v172/#29)
    st, b, url = go(sop, "/my/claim", {"biz_id": "999999"})
    check("T2.4", "شناسهٔ وحشی → «در سایت نیست»", st == 200
          and "در سایت نیست" in urllib.parse.unquote(url), f"st={st} {url}")
    # رقیب: مشتری صحنه هم درخواست بدهد؛ تأییدِ یکی بقیه را rejected کند
    q("insert into owners(id,phone,status) values(778,'09127778888','active')")
    created["owners"].append(778)
    q("insert into claims(biz_id,owner_id,note,status) values(215,778,'رقیب','pending')")
    cid2 = q("select id from claims where biz_id=215 and owner_id=778")[0][0]
    created["claims"].append(cid2)
    n0 = q("select count(*) from owner_notifications where owner_id=2 and text like '%تأیید شد%'")[0][0]
    st, b, url = go(op, f"/panel/claim/{cid}", {"action": "approve"})
    owner_now = q("select owner_id from businesses where id=215")[0][0]
    st1 = q("select status from claims where id=?", (cid,))[0][0]
    st2_ = q("select status from claims where id=?", (cid2,))[0][0]
    n1 = q("select count(*) from owner_notifications where owner_id=2 and text like '%تأیید شد%'")[0][0]
    check("T2.5", "تأیید: مالک شد + رقیب rejected + اعلان",
          owner_now == 2 and st1 == "approved" and st2_ == "rejected" and n1 == n0 + 1,
          f"owner={owner_now} {st1}/{st2_} notif {n0}→{n1}")
    st, b, url = go(op, "/panel/claims")
    check("T2.6", "صف تصاحب‌ها 200", st == 200)
    # رد واقعی (درخواست تازه روی 215 که الان صاحب‌دار است — claim_add رد می‌کند؛ پس مستقیم ردیف بساز)
    q("insert into claims(biz_id,owner_id,note,status) values(216,778,'ردی آزمون','pending')")
    cid3 = q("select id from claims where biz_id=216 and owner_id=778")[0][0]
    created["claims"].append(cid3)
    n0r = q("select count(*) from owner_notifications where owner_id=778 and text like '%رد شد%'")[0][0]
    st, b, url = go(op, f"/panel/claim/{cid3}", {"action": "reject"})
    st3 = q("select status from claims where id=?", (cid3,))[0][0]
    n1r = q("select count(*) from owner_notifications where owner_id=778 and text like '%رد شد%'")[0][0]
    check("T2.7", "رد: وضعیت + اعلان رد", st3 == "rejected" and n1r == n0r + 1, f"{st3} {n0r}→{n1r}")
    # وحشی پنل (رفع v172)
    st, b, url = go(op, "/panel/claim/999999", {"action": "approve"})
    check("T2.8", "وحشی تصاحب → «نیست»", "نیست" in urllib.parse.unquote(url), url)
    # دکاندار 403
    g1 = go(sop, "/panel/claims")[0]
    g2 = go(sop, f"/panel/claim/{cid}", {"action": "approve"})[0]
    check("T2.9", "دکاندار 403×2", (g1, g2) == (403, 403), str((g1, g2)))

# ─────────────────── T3 تأیید تغییرات ───────────────────
def t3():
    print("── T3 صف تأیید تغییرات (روشن/خاموش)")
    op = login(ADMIN_PHONE, admin=True)
    sop = login(SHOP_PHONE)
    # 3.1 خاموش → ذخیرهٔ مستقیم
    q("update settings set value='0' where key='edit_approval'")
    time.sleep(5.2)
    st, b, url = go(sop, f"/my/business/{A_BIZ}", {"name": "دکانٔ آزمون مالک یک",
        "cat_slug": "restaurant", "descr": "توصیف مستقیم — ویرایش بی‌صف.", "phone": "09352223344",
        "address": "خیابان آزمون", "tags": "", "hours": "{}"})
    n0 = q("select count(*) from edits")[0][0]
    cur = q("select descr from businesses where id=214")[0][0]
    check("T3.1", "صف خاموش: ذخیرهٔ مستقیم", "ذخیره شد" in urllib.parse.unquote(url)
          and cur == "توصیف مستقیم — ویرایش بی‌صف." and q("select count(*) from edits")[0][0] == n0,
          f"{cur}")
    # 3.2 روشن → صف؛ چیزی عوض نمی‌شود
    q("update settings set value='1' where key='edit_approval'")
    time.sleep(5.2)
    st, b, url = go(sop, f"/my/business/{A_BIZ}", {"name": "دکانٔ آزمون مالک یک",
        "cat_slug": "restaurant", "descr": "پیشنهاد صف‌شده برای آزمون فاز ۹.", "phone": "09352223344",
        "address": "خیابان آزمون", "tags": "", "hours": "{}"})
    row = q("select id,status,biz_id from edits where status='pending' order by id desc limit 1")
    ok = len(row) == 1 and row[0][2] == A_BIZ
    eid = row[0][0] if row else 0
    created["edits"].append(eid)
    cur = q("select descr from businesses where id=214")[0][0]
    check("T3.2", "صف روشن: ردیف pending + دکان دست‌نخورده",
          "برای بررسی مدیر" in urllib.parse.unquote(url) and ok
          and cur == "توصیف مستقیم — ویرایش بی‌صف.", f"{url} {cur}")
    # ارسال دوبارهٔ همان تغییر (طراحی فعلی: صف در برابر وضعیت فعلی مقایسه می‌کند
    # و ردیف تازه می‌سازد — پیام صادقانه است؛ دِدوپِ صف رد شد، فقط صادق بودن می‌سنجیم)
    st, b, url = go(sop, f"/my/business/{A_BIZ}", {"name": "دکانٔ آزمون مالک یک",
        "cat_slug": "restaurant", "descr": "پیشنهاد صف‌شده برای آزمون فاز ۹.", "phone": "09352223344",
        "address": "خیابان آزمون", "tags": "", "hours": "{}"})
    msg = urllib.parse.unquote(url)
    ok2 = ("برای بررسی مدیر" in msg) or ("تغییری نسبت به قبل نبود" in msg)
    check("T3.3", "ارسال تکراری: پیام صادقانه، بدون اعمال خاموش",
          ok2 and q("select descr from businesses where id=214")[0][0]
          == "توصیف مستقیم — ویرایش بی‌صف.", url)
    # 3.4 رد → دکان همان
    st, b, url = go(op, f"/panel/edit/{eid}", {"action": "reject"})
    st_ = q("select status from edits where id=?", (eid,))[0][0]
    cur = q("select descr from businesses where id=214")[0][0]
    check("T3.4", "رد پیشنهاد", "رد شد" in urllib.parse.unquote(url) and st_ == "rejected"
          and cur == "توصیف مستقیم — ویرایش بی‌صف.", f"{st_} {cur}")
    # 3.5 تأیید → اعمال واقعی
    q("insert into edits(biz_id,owner_id,payload,status,created) "
      "values(214,2,?,'pending',datetime('now','localtime'))",
      (json.dumps({"descr": "توصیف تأییدشده از صف."}, ensure_ascii=False),))
    eid2 = q("select id from edits where status='pending' order by id desc limit 1")[0][0]
    created["edits"].append(eid2)
    st, b, url = go(op, f"/panel/edit/{eid2}", {"action": "approve"})
    cur = q("select descr from businesses where id=214")[0][0]
    st2_ = q("select status from edits where id=?", (eid2,))[0][0]
    check("T3.5", "تأیید → اعمال واقعی روی دکان", "اعمال شد" in urllib.parse.unquote(url)
          and cur == "توصیف تأییدشده از صف." and st2_ == "approved", f"{cur} {st2_}")
    # 3.6 وحشی + خاموش‌کردن دوباره (بازگردانی صحنه)
    st, b, url = go(op, "/panel/edit/999999", {"action": "approve"})
    check("T3.7", "وحشی صف تغییرات → «نیست»", "نیست" in urllib.parse.unquote(url), url)
    st, b, _ = go(op, "/panel/edits")
    check("T3.8", "صف 200", st == 200)
    q("update settings set value='0' where key='edit_approval'")
    time.sleep(5.2)

# ─────────────────── T4 نشان‌ها ───────────────────
def t4():
    print("── T4 نشان‌ها (ساخت، اتصال، خودکار، وحشی)")
    op = login(ADMIN_PHONE, admin=True)
    # 4.1 ساخت + بی‌عنوان
    st, b, url = go(op, "/panel/badge/new", {"name": "", "icon": "award"})
    check("T4.1", "بی‌عنوان رد", "الزامی" in urllib.parse.unquote(url), url)
    st, b, url = go(op, "/panel/badge/new", {"name": "نشان آزمون۹", "icon": "award",
                    "color": "#059669", "descr": "توضیح نشان آزمون", "active": "1"})
    row = q("select id,slug from badges where name='نشان آزمون۹'")
    ok = len(row) == 1
    bid = row[0][0] if row else 0
    created["badges"].append(bid)
    check("T4.2", "ساخت نشان", "ساخته" in urllib.parse.unquote(url) and ok, url)
    # 4.2 ویرایش + خاموش/روشن
    st, b, url = go(op, f"/panel/badge/{bid}", {"name": "نشان آزمون۹", "icon": "award",
                    "color": "#b45309", "descr": "بروزشده", "sort": "2", "action": "save", "active": "1"})
    cur = q("select color,sort from badges where id=?", (bid,))[0]
    check("T4.3", "ویرایش نشان", cur[0] == "#b45309" and str(cur[1]) == "2", str(cur))
    st, b, url = go(op, f"/panel/badge/{bid}", {"action": "toggle"})
    check("T4.4", "خاموش/روشن", q("select active from badges where id=?", (bid,))[0][0] == 0)
    # 4.3 اتصال به دکان + عمومی
    st, b, url = go(op, "/panel/badges/grant", {"biz_id": str(A_BIZ), "badge_ids": str(bid)})
    n = q("select count(*) from biz_badges where biz_id=? and badge_id=?", (A_BIZ, bid))[0][0]
    check("T4.5", "اتصال نشان به دکان", "1 نشان" in urllib.parse.unquote(url) and n == 1, f"{url} n={n}")
    time.sleep(5.2)
    st, b, _ = go(sess(), f"/b/{A_SLUG}")
    check("T4.6", "نشان در صفحهٔ عمومی (حتی خاموش؟ — فقط فعال‌ها)",
          ("نشان آزمون۹" in b) == False, None)  # خاموش است → نباید دیده شود
    st, b, url = go(op, f"/panel/badge/{bid}", {"action": "toggle"})
    time.sleep(5.2)
    st, b, _ = go(sess(), f"/b/{A_SLUG}")
    check("T4.7", "روشن شد → در عمومی دیده", "نشان آزمون۹" in b)
    # 4.4 grant وحشی (رفع v172)
    st, b, url = go(op, "/panel/badges/grant", {"biz_id": "999999", "badge_ids": str(bid)})
    check("T4.8", "grant وحشی → «مشخص نیست»", "مشخص نیست" in urllib.parse.unquote(url), url)
    # 4.5 وحشی نشان (رفع v172)
    for act in ("toggle", "delete"):
        st, b, url = go(op, f"/panel/badge/999999", {"action": act})
        if "نیست" not in urllib.parse.unquote(url): break
    check("T4.9", "وحشی نشان → «نیست»", "نیست" in urllib.parse.unquote(url), url)
    st, b, url = go(op, "/panel/badge/999999", {"name": "هک", "action": "save"})
    check("T4.10", "وحشی ذخیرهٔ نشان → «نیست»", "نیست" in urllib.parse.unquote(url), url)
    # 4.6 نشان خودکار (بدون واجد شرایط → صفر تغییر، بدون خطا)
    st, b, url = go(op, "/panel/badges/auto", {})
    check("T4.11", "نشان خودکار اجرا شد (گزارش تغییر)", "نشان «برترین امتیاز»" in urllib.parse.unquote(url), url)
    # 4.7 حذف → biz_badges پاک
    st, b, url = go(op, f"/panel/badge/{bid}", {"action": "delete"})
    check("T4.12", "حذف نشان + عدم ردیف یتیم",
          "حذف شد" in urllib.parse.unquote(url)
          and q("select count(*) from biz_badges where badge_id=?", (bid,))[0][0] == 0)
    created["badges"].remove(bid)
    # 4.8 دکاندار 403
    sop = login(SHOP_PHONE)
    g1 = go(sop, "/panel/badges")[0]
    g2 = go(sop, "/panel/badge/new", {"name": "هک"})[0]
    g3 = go(sop, "/panel/badges/grant", {"biz_id": str(A_BIZ), "badge_ids": "1"})[0]
    check("T4.13", "دکاندار 403×3", (g1, g2, g3) == (403, 403, 403), str((g1, g2, g3)))

def main():
    try:
        t1()
        t2()
        t3()
        t4()
    finally:
        for oid in created["owners"]:
            q("delete from owners where id=?", (oid,))
        for cid in created["claims"]:
            q("delete from claims where id=?", (cid,))
        for eid in created["edits"]:
            q("delete from edits where id=?", (eid,))
        for bid in created["badges"]:
            q("delete from biz_badges where badge_id=?", (bid,))
            q("delete from badges where id=?", (bid,))
        # احتیاط دوم
        q("delete from claims where note like '%آزمون%' or note='رقیب' or note='ردی آزمون'")
        q("delete from edits where payload like '%آزمون%' or payload like '%صف%'")
        q("delete from biz_badges where biz_id=214 and badge_id in (select id from badges where name like '%آزمون%')")
        q("delete from badges where name like '%آزمون%'")
        q("delete from owners where id in (777,778)")
        q("update businesses set owner_id=NULL where id in (214,215,216)")
        q("update businesses set descr='' where id=214")
        q("delete from owner_notifications")
        q("update settings set value='0' where key='edit_approval'")
        q("delete from ratelimit"); q("delete from otp")
    json.dump(RESULTS, open("qa/phase9-results.json", "w"), ensure_ascii=False, indent=1)
    fails = [r for r in RESULTS if not r["ok"]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(fails)} | قرمز: {len(fails)}")
    for r in fails:
        print("  ❌", r["id"], r["name"], "—", r["detail"])
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
