# -*- coding: utf-8 -*-
"""سازندهٔ صحنهٔ آزمون استاندارد (شناسه‌های قطعی که باتری‌ها انتظار دارند).
Idempotent — هر بار اجرا شود، صحنه سالم و یکسان می‌ماند:
  owners 1(مدیر 09131110011) / 2(A 09352223344) / 89(B 09134950001)
  customer 17 (09361112233)
  businesses 214(dkan-azmvn-malk-yk, owner2) / 215(dkan-azmvn-malk-dv, owner89)
  item 336 روی 214 (available=1)
اجرا: python3 tools/scene_v177.py
"""
import sqlite3, sys, time

DB = "data/bazarche.db"

def q(sql, args=()):
    c = sqlite3.connect(DB)
    r = c.execute(sql, args).fetchall()
    c.commit()
    c.close()
    return r

def upsert_owner(oid, phone):
    if q("select 1 from owners where id=?", (oid,)):
        q("update owners set phone=? where id=?", (phone, oid))
    else:
        q("insert into owners(id,phone,name,created) values(?,?,?,datetime('now'))",
          (oid, phone, "مالک آزمون"))

def upsert_customer(cid, phone):
    if q("select 1 from customers where id=?", (cid,)):
        q("update customers set phone=? where id=?", (phone, cid))
    else:
        q("insert into customers(id,phone,name,created) values(?,?,?,datetime('now'))",
          (cid, phone, "مشتری آزمون"))

def upsert_biz(bid, slug, name, owner_id):
    row = q("select id from businesses where id=?", (bid,))
    if row:
        q("""update businesses set slug=?, name=?, owner_id=?, status='published',
             cat_slug=coalesce(nullif(cat_slug,''),'food'), phone=?,
             address=coalesce(nullif(address,''),'آدرس آزمون، نجف‌آباد') where id=?""",
          (slug, name, owner_id, phone_of(owner_id), bid))
    else:
        q("""insert into businesses(id,slug,name,cat_slug,descr,phone,address,city,province,
             status,owner_id,hours,tags,images,created)
             values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'))""",
          (bid, slug, name, "food", "دکان آزمون برای باتری‌های QA",
           phone_of(owner_id), "آدرس آزمون، نجف‌آباد", "نجف‌آباد", "اصفهان",
           "published", owner_id, "{}", "[]", "[]"))

def phone_of(oid):
    return q("select phone from owners where id=?", (oid,))[0][0]

def upsert_item(iid, biz_id, title, price):
    if q("select 1 from items where id=?", (iid,)):
        q("update items set biz_id=?, title=?, price=?, available=1 where id=?",
          (biz_id, title, price, iid))
    else:
        q("""insert into items(id,biz_id,kind,title,descr,price,price_type,available)
             values(?,?,?,?,?,?,?,1)""",
          (iid, biz_id, "product", title, "کالای آزمون باتری‌ها", price, "fixed"))

if __name__ == "__main__":
    # ── زیرلایهٔ دکان‌های دمو: اگر دنیای دمو (تگ‌دار) پراکنده/حذف شده،
    # بازسازی تمیز — باتری‌های امنیتی/پنل ممکن است دکان‌ها را خورده باشند.
    demo_n = q("select count(*) from businesses where tags like '%نمونه‌آزمایشی%'")[0][0]
    if demo_n < 5:
        keep = "214,215"
        for t in ("reviews", "questions", "items", "chat_threads", "orders",
                  "follows", "favorites", "stories", "subscriptions"):
            try:
                q(f"delete from {t} where biz_id in "
                  f"(select id from businesses where tags like '%نمونه‌آزمایشی%' and id not in ({keep}))")
            except Exception:
                pass
        q(f"delete from businesses where tags like '%نمونه‌آزمایشی%' and id not in ({keep})")
        sys.path.insert(0, "tools")
        import seed_demo
        seed_demo.seed()
        print(f"  دکان‌های دمو بازسازی شد (قبلاً {demo_n} مانده بود)")
    upsert_owner(1, "09131110011")
    upsert_owner(2, "09352223344")
    upsert_owner(89, "09134950001")
    upsert_customer(17, "09361112233")
    upsert_biz(214, "dkan-azmvn-malk-yk", "دکانٔ آزمون مالک یک", 2)
    # M4.2 دکان A باید عکس داشته باشد (فایل واقعیِ بذر qa-photo.webp)
    q("update businesses set images='[\"/assets/img/uploads/qa-photo.webp\"]' where id=214")
    upsert_biz(215, "dkan-azmvn-malk-dv", "دکانٔ آزمون مالک دو", 89)
    # دکان ۲۱۶ = kbaby (qa_mobile) — اگر بذرِ دمو آن را در id دیگری ساخت، جابه‌جا شود
    row = q("select id from businesses where slug='kbaby-bradran-hydry' and id!=216")
    if row and not q("select 1 from businesses where id=216"):
        old = row[0][0]
        for t, col in (("items", "biz_id"), ("reviews", "biz_id"), ("orders", "biz_id"),
                       ("order_items", "biz_id"), ("chat_threads", "biz_id"), ("stories", "biz_id"),
                       ("follows", "biz_id"), ("favorites", "biz_id"), ("subscriptions", "biz_id"),
                       ("alerts", "biz_id"), ("questions", "biz_id"), ("claims", "biz_id")):
            try:
                q(f"update {t} set {col}=216 where {col}=?", (old,))
            except Exception:
                pass
        q("update businesses set id=216 where id=?", (old,))
    upsert_item(336, 214, "کالای آزمون 1", 1000)
    # بذر تیکت پشتیبانی (qa_panel T7 تیکتِ موجود می‌خواهد؛ در DB کهنه از دور
    #‌های قبل مانده بود — اکنون بخشی از صحنهٔ قطعی است)
    if not q("select 1 from tickets where subject='qa-seed-ticket'"):
        q("""insert into tickets(owner_id,biz_id,name,phone,subject,topic,status,priority,
             token,unread_admin,unread_user,created,updated)
             values(1,NULL,'مشتری آزمون','09361112233','qa-seed-ticket','other','open','normal',
             'qa-seed-token',1,0,datetime('now'),datetime('now'))""")
        q("insert into ticket_msgs(ticket_id,side,body,created) "
          "values((select max(id) from tickets),'user','سلام؛ بذر آزمون تیکت.',datetime('now'))")
    # بذر نظر (qa_panel T6 «آخرین نظر» می‌خواهد) — قانون §6.2: customer_id=NULL
    if not q("select 1 from reviews where biz_id=214 and author='مشتری آزمون'"):
        q("""insert into reviews(biz_id,author,rating,body,status,customer_id,created)
             values(214,'مشتری آزمون',5,'بذر آزمون برای qa_panel','approved',NULL,datetime('now'))""")
    # تنظیماتِ لازمِ صحنه (قطعی)
    for k, v in (("chat_enabled", "1"), ("stories_enabled", "1"), ("prices_enabled", "1"),
                 ("orders_enabled", "1"), ("reg_open", "1"), ("edit_approval", "0"),
                 ("reviews_moderated", "1"), ("follow_enabled", "1")):
        q("insert into settings(key,value) values(?,?) "
          "on conflict(key) do update set value=excluded.value", (k, v))
    # بازسازی FTS چون مستقیم در businesses نوشتیم
    q("update settings set value='1' where key='fts_dirty'")
    sys.path.insert(0, "server")
    import db as DBM
    try:
        DBM.fts_rebuild()
    except Exception:
        DBM._run("DELETE FROM businesses_fts")
        for b in DBM._rows("SELECT id,name,descr,tags,address FROM businesses"):
            DBM._run("INSERT INTO businesses_fts(rowid,name,descr,tags,address) VALUES(?,?,?,?,?)",
                     (b["id"], b["name"], b["descr"] or "", b["tags"] or "", b["address"] or ""))
    DBM._run("DELETE FROM otp")
    DBM._run("DELETE FROM ratelimit")
    DBM._run("DELETE FROM searches")
    print("صحنهٔ آزمون ✔  biz:", q("select id,slug,owner_id from businesses where id in (214,215)"),
          "| item336:", q("select id,available from items where id=336"),
          "| fts:', ", q("select count(*) from businesses_fts")[0][0], "ردیف")
