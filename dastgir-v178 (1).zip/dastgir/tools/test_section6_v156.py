# -*- coding: utf-8 -*-
"""
v156 نقشه (بخش ۶) — قفل ایستای هر دو موتور + CSS + بامپ‌ها:
  · فرمول مقیاس یکسان: min(1.1, max(0.42, 0.87^(z-14))) — گوگل و Leaflet
  · گوگل: _bzBase=6.5، stroke>=14?4:3، floor 2.5
  · Leaflet: نقطهٔ 14px در قاب لمس 30×30 (anchor 15,15 popup -14)
  · پین فعال: anchor 38 / popup -42، drop 26px + قاب 2px
  · «موقعیت من»: 13px (google scale 7.5) با مقیاس زوم
  · CSS: قواعد --pin-scale برای bz-dot / bz-pin-wrap / bz-me-dot
  · بامپ: mappage.js→map.js?v156، سه view→mappage.js?v156، ui.py→pages.css?v156
    sw.js→bazarche-v156 (نگهبان نسخه)
    python3 tools/test_section6_v156.py
"""
import re
import sys

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


MAP = open("site/assets/js/map.js", encoding="utf-8").read()
MPG = open("site/assets/js/mappage.js", encoding="utf-8").read()
CSS = open("site/assets/css/pages.css", encoding="utf-8").read()
SW = open("site/sw.js", encoding="utf-8").read()
UI = open("server/ui.py", encoding="utf-8").read()


def main():
    head("فرمول مقیاس — هر دو موتور")
    f = r"Math\.min\(1\.1, Math\.max\(0\.42, Math\.pow\(0\.87, z - 14\)\)\)"
    n = len(re.findall(f, MAP))
    check("فرمول v156 دو بار (گوگل+OSM)", n == 2, f"شمار={n}")
    check("گوگل: floor 2.5", "Math.max(2.5," in MAP)
    check("گوگل: _bzBase نقطه=6.5", MAP.count("m._bzBase = 6.5;") >= 2)
    check("گوگل: stroke سنگین فقط برای نقطهٔ درشت", "m._bzBase >= 14 ? 4 : 3" in MAP)
    check("OSM: متغیر --pin-scale روی کانتینر", "--pin-scale" in MAP)
    check("OSM: گوش‌دادن به zoom و zoomend",
          "map.on('zoom', pinScale)" in MAP and "map.on('zoomend', pinScale)" in MAP)

    head("اندازه‌ها در mappage.js")
    check("«موقعیت من» 13px", 'width:13px;height:13px' in MPG)
    check("anchor نقطهٔ من 6.5", "iconSize: [13, 13], iconAnchor: [6.5, 6.5]" in MPG)
    check("گوگل: scale 7.5", "scale: 7.5" in MPG)
    check("کلاس bz-me-dot", 'class="bz-me-dot"' in MPG)

    head("اندازه‌ها در map.js (OSM)")
    check("نقطهٔ 14px در قاب 30×30",
          "width:14px;height:14px" in MAP and "iconSize: [30, 30], iconAnchor: [15, 15]" in MAP)
    check("پین فعال: anchor 38 / popup -42",
          "iconSize: [0, 0], iconAnchor: [0, 38], popupAnchor: [0, -42]" in MAP)

    head("CSS")
    for sel in (".bz-pin .bz-dot", ".bz-pin-active .bz-pin-wrap", ".bz-me .bz-me-dot"):
        check(f"مقیاس زوم برای {sel}",
              re.search(re.escape(sel) + r" \{[^}]*--pin-scale", CSS) is not None)
    check("drop = 26px", "width: 26px; height: 26px; border-radius: 50% 50% 50% 0" in CSS)
    check("img کالای داخل drop = 17px", ".bz-pin-drop img { width: 17px; height: 17px" in CSS)

    head("بامپ نسخه‌ها")
    check("mappage.js → map.js?v156", "'./map.js?v156'" in MPG)
    for path in ("server/views_owner.py", "server/views_panel.py", "server/views_public.py"):
        body = open(path, encoding="utf-8").read()
        check(f"{path.split('/')[-1]} → mappage.js?v156", "mappage.js?v156" in body)
    ver = open("VERSION.txt", encoding="utf-8").readline().strip()
    check(f"sw.js → bazarche-v{ver}", f"bazarche-v{ver}" in SW)
    # فقط فایل‌های تغییرکردهٔ هر انتشار بامپ می‌خورند (قرارداد):
    # mobile-standard آخرین‌بار در v157، pages.css در v158 تغییر کرد.
    check("ui.py → mobile-standard.css?v157", "mobile-standard.css?v157" in UI)
    check("ui.py → pages.css?v158", "pages.css?v158" in UI)
    check("بدون ?v کهنه در sw.js", not re.search(r"\?v1[0-5][0-9]", SW))

    head("بخش ۱ — بدهی موبایل اعلان‌ها (v157)")
    MSD = open("site/assets/css/mobile-standard.css", encoding="utf-8").read()
    check("هیرو اعلان‌ها در موبایل wrap می‌شود",
          ".page-hero.notifications-hero { flex-wrap: wrap; }" in MSD)
    check("توضیح هیرو زیر ردیف عنوان", "flex: 1 1 100%; order: 3;" in MSD)
    check("دکمهٔ هیرو له نمی‌شود", ".page-hero.notifications-hero .btn { flex: none; }" in MSD)

    print(f"\n\033[1mنتیجه: {ok_n} موفق / {bad_n} ناموفق\033[0m")
    if FAILS:
        print("شکست‌ها:")
        for x in FAILS:
            print("  -", x)
    return 1 if bad_n else 0


if __name__ == "__main__":
    sys.exit(main())
