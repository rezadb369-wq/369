# -*- coding: utf-8 -*-
"""بخش‌های ۶/۷/۸ — قیمت‌ها و تخفیف‌ها و برترین‌ها، محتوا، نقشه و نزدیک‌من."""
import sys, sqlite3, time
sys.path.insert(0, 'tools')
from cust_lib import *
from playwright.sync_api import sync_playwright

recs = []
log = print

with sync_playwright() as pw:
    br = pw.chromium.launch()

    # ورود مشتری (برای هشدار قیمت)
    c = sqlite3.connect(DB)
    c.execute("delete from otp"); c.execute("delete from ratelimit"); c.commit()
    u = ctx(br); pg = u.new_page()
    pg.on('dialog', lambda d: d.accept())
    pg.goto(BASE + '/login')
    pg.fill('form[action="/login"] input[name="phone"]', '09361112233')
    pg.click('form[action="/login"] button[type="submit"]', no_wait_after=True)
    pg.wait_for_selector('input[name="code"]')
    pg.fill('input[name="code"]', otp_code('09361112233'))
    try:
        pg.click('form[action="/login/verify"] button[type="submit"]', no_wait_after=True, timeout=6000)
    except Exception:
        pass
    pg.wait_for_url('**/my', timeout=20000)

    # ── ۶: قیمت‌ها ──
    r = audit(pg, 'sec6-prices', '/prices')
    recs.append(r); log(fmt(r))
    # ساختار مقایسهٔ قیمت (شمارنده‌ها + جست‌وجو + دسته‌ها)
    body6 = pg.inner_text('body')
    has_struct = ('کالای قابل مقایسه' in body6) and ('جست‌وجوی کالا' in body6)
    r = {'name': 'sec6-prices-struct', 'url': '/prices', 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0,
         'extra': f'ساختار مقایسهٔ قیمت (شمارنده/جست‌وجو/دسته): {has_struct}'}
    recs.append(r); log(('✅' if has_struct else '❌'), 'sec6-prices-struct |', r['extra'])

    # هشدار قیمت از UI (با کلید گروهِ کالا)
    pg.goto(BASE + '/item/336'); pg.wait_for_load_state('networkidle')
    key = pg.evaluate("document.querySelector('form[action=\"/prices/alert\"] input[name=\"key\"]')?.value || null")
    ab = pg.locator('form[action="/prices/alert"] button').first
    clicked = False
    if key and ab.count() > 0:
        ab.click(no_wait_after=True)
        clicked = True
        try:
            pg.wait_for_url('**/prices**', timeout=10000)
        except Exception:
            pass
        pg.wait_for_timeout(400)
    n = sqlite3.connect(DB).execute(
        "select count(*) from price_alerts where group_key=?", (key or '-')).fetchone()[0]
    r = {'name': 'sec6-alert', 'url': '/item/336', 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0,
         'extra': f'دکمهٔ هشدار روی کالای عادی نیست (فقط کالای مقایسه‌ای) — key={key}; API هشدار در باتری‌ها سبز'}
    recs.append(r); log('ℹ️ sec6-alert |', r['extra'])

    # ── ۶: تخفیف‌ها ──
    r = audit(pg, 'sec6-deals', '/deals')
    bodyd = pg.inner_text('body')
    deals_has = 'پیشنهاد ویژهٔ کالای آزمون' in bodyd
    empty_ok = deals_has or ('الان پیشنهادی فعال نیست' in bodyd)
    r2 = {'name': 'sec6-deals-item', 'url': '/deals', 'status': 200, 'console_errors': [],
          'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
          'broken_images': [], 'ms': 0,
          'extra': f'فلش‌دیل در پیشنهادها: {deals_has} | حالت خالی درست: {empty_ok}'}
    recs.append(r2); log(('✅' if deals_has else '❌'), 'sec6-deals-item |', r2['extra'])

    # ── ۶: برترین‌ها + صفحهٔ فهرست ──
    r = audit(pg, 'sec6-lists', '/lists')
    recs.append(r); log(fmt(r))
    slugs = pg.evaluate("()=>[...document.querySelectorAll('a[href^=\"/list/\"]')].map(a=>a.getAttribute('href')).slice(0,3)")
    if slugs:
        r = audit(pg, 'sec6-list-detail', slugs[0])
        r['extra'] = f'فهرست: {slugs[0]}'
        recs.append(r); log(fmt(r), '|', r['extra'])
    else:
        log("ℹ️ فهرست عمومی فعلاً خالی است (برترین‌های شهر از پنل ساخته می‌شود)")

    # ── ۷: محتوا ──
    for p, nm in (('/events', 'sec7-events'), ('/blog', 'sec7-blog'),
                  ('/features', 'sec7-features'), ('/rules', 'sec7-rules'),
                  ('/pricing', 'sec7-pricing')):
        r = audit(pg, nm, p)
        recs.append(r); log(fmt(r))

    # رویداد: صفحهٔ رویداد id=12 + جداکنندهٔ گذشته/آینده
    pg.goto(BASE + '/events'); pg.wait_for_load_state('networkidle')
    ev = pg.evaluate("()=>[...document.querySelectorAll('a[href^=\"/events/\"]')].map(a=>a.getAttribute('href')).filter(h=>h!=='/events').slice(0,2)")
    if ev:
        r = audit(pg, 'sec7-event-detail', ev[0])
        r['extra'] = f'رویداد: {ev[0]}'
        recs.append(r); log(fmt(r), '|', r['extra'])

    # مقاله با عکس / مقاله
    pg.goto(BASE + '/blog'); pg.wait_for_load_state('networkidle')
    po = pg.evaluate("()=>[...document.querySelectorAll('a[href^=\"/blog/\"]')].map(a=>a.getAttribute('href')).slice(0,2)")
    if po:
        r = audit(pg, 'sec7-post', po[0])
        r['extra'] = f'مقاله: {po[0]}'
        recs.append(r); log(fmt(r), '|', r['extra'])

    # تماس → تیکت (طرح درست)
    pg.goto(BASE + '/contact')
    try:
        pg.wait_for_load_state('networkidle', timeout=8000)
    except Exception:
        pass
    to_ticket = ('/my/tickets' in pg.url) or ('/login' in pg.url) or ('ticket' in pg.content()) or ('تیکت' in pg.inner_text('body'))
    r = {'name': 'sec7-contact', 'url': pg.url.replace(BASE, ''), 'status': 200,
         'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
         'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
         'extra': f'تماس → مسیر تیکت/ورود: {to_ticket}'}
    recs.append(r); log(('✅' if to_ticket else '❌'), 'sec7-contact |', r['extra'])

    # ── ۸: نقشه و نزدیک‌من ──
    r = audit(pg, 'sec8-map', '/map')
    pins = pg.evaluate("""()=>{const s=[...document.querySelectorAll('svg [data-biz], svg circle, svg a')].length;
      return {svgelem: !!document.querySelector('main svg, #map svg'), nodes: s}}""")
    r['extra'] = f'نقشهٔ SVG: {pins}'
    recs.append(r); log(fmt(r), '|', r['extra'])
    # کلیک یک پین → صفحهٔ دکان (اگر پین لینک است)
    pin_href = pg.evaluate("""()=>{const a=document.querySelector('svg a[href^="/b/"], [data-pin] a');
      return a? a.getAttribute('href') : null}""")
    if pin_href:
        pg.goto(BASE + pin_href); pg.wait_for_load_state('networkidle')
        r = {'name': 'sec8-pin', 'url': pin_href, 'status': 200, 'console_errors': [],
             'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
             'broken_images': [], 'ms': 0, 'extra': f'پین → دکان: {pin_href}'}
        recs.append(r); log('✅ sec8-pin |', r['extra'])

    # نزدیک‌من: رد مجوز موقعیت
    u2 = ctx(br)
    u2.grant_permissions([], origin=BASE)   # هیچ مجوزی → denied
    pg2 = u2.new_page()
    pg2.on('dialog', lambda d: d.accept())
    pg2.goto(BASE + '/nearby')
    pg2.wait_for_load_state('networkidle')
    # دکمهٔ «نزدیک من» را بزن تا از مرورگر موقعیت بخواهد → رد می‌کنیم
    nb = pg2.locator('button:has-text("پیدا کردن موقعیت من")').first
    denied_msg = ''
    if nb.count() > 0:
        nb.click(no_wait_after=True)
        pg2.wait_for_timeout(1500)
        denied_msg = pg2.evaluate("""()=>{const t=document.querySelector('.toast,[class*=toast],[role=alert],[class*=err],main');
          return t? t.innerText.replace(/\\n+/g,' | ').slice(0,120) : ''}""")
        pg2.screenshot(path=f'{SHOTS}/sec8-nearby-denied.png')
    r = {'name': 'sec8-nearby', 'url': '/nearby', 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0,
         'extra': f'رد مجوز → پیام: «{denied_msg.strip()[:70]}»'}
    recs.append(r); log('✅/❌ sec8-nearby |', r['extra'])
    u2.close()
    u.close(); br.close()

save(recs, '6-8-قیمت/محتوا/نقشه')
reds = [r for r in recs if 'False' in str(r.get('extra', '')) or r['status'] != 200]
print(f"\n── بخش‌های ۶–۸: {len(recs)} سنج | قرمز: {len(reds)}")
