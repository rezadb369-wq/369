# -*- coding: utf-8 -*-
"""QA «بازیابی فایل‌ها» (v177) — تغییر نام سطل + پیش‌نمایش تصویری بدون بازیابی.
R1 نام تازه در منو/صفحهٔ دکاندار · R2 نام تازه در پنل مدیر
R3 پیش‌نمایش عکس کالا/استوری/نظر حذف‌شده · R4 لایت‌باکس E2E
R5 بازیابی کار می‌کند و عکس سر جایش است · R6 GC عکس سطل/استوری/نظر را پاک نمی‌کند
R7 بدون بازیابی، فایل در بخش دیده می‌شود (متن قانون)
اجرا: python3 tools/qa_file_recovery.py   (سرور روی 8080)
"""
import sys, json, sqlite3, time, urllib.request, urllib.parse, http.cookiejar

BASE = "http://127.0.0.1:8080"
DB = "data/bazarche.db"
BIZ, SLUG = 214, "dkan-azmvn-malk-yk"
PHONE = "09352223344"
IMG = "/assets/img/uploads/qa-photo.webp"
RESULTS = []

def q(sql, args=()):
    c = sqlite3.connect(DB)
    r = c.execute(sql, args).fetchall()
    c.commit()
    c.close()
    return r

def check(tid, desc, cond, detail=""):
    RESULTS.append((tid, bool(cond)))
    print(("  ✅" if cond else "  ❌") + f" [{tid}] {desc}" + (f" — {detail}" if (detail and not cond) else ""))

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None, headers=None):
    h = dict(headers or {})
    if data is not None and "Content-Type" not in h and not isinstance(data, (bytes, str)):
        data = urllib.parse.urlencode(data, doseq=True).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(BASE + path, data=data, headers=h)
    req.add_header("User-Agent", "Mozilla/5.0 (Linux; Android 13) Chrome/120 Mobile")
    try:
        r = op.open(req, timeout=25)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

def owner_token():
    sys.path.insert(0, "server")
    import db as DBM
    return DBM.owner_token()

def main():
    print("── صحنه: حذف کالا + استوری + نظرِ عکس‌دار")
    q("delete from trash where entity in ('item','story','review') and biz_id=?", (BIZ,))
    # کالای عکس‌دار حذف شود
    q("insert into items(biz_id,kind,title,descr,price,price_type,image,available) "
      "values(?,?,?,?,?,?,?,0)", (BIZ, "product", "qa-bin-item", "", 1000, "fixed", IMG))
    iid = q("select max(id) from items")[0][0]
    # payload واقعی شبیه delete_item بسازیم (dict کامل)
    row = q("select * from items where id=?", (iid,))
    cols = [x[1] for x in q("pragma table_info(items)")]
    payload = dict(zip(cols, row[0]))
    q("insert into trash(entity,ref_id,biz_id,title,payload,deleted_at) values('item',?,?,?,?,?)",
      (iid, BIZ, "qa-bin-item", json.dumps(payload, ensure_ascii=False, default=str), time.time()))
    q("delete from items where id=?", (iid,))
    # استوری حذف شود
    q("insert into stories(biz_id,image,kind,caption,created,expires,duration) "
      "values(?,?,?,?,datetime('now'),?,5)", (BIZ, IMG, "image", "qa-bin-story", time.time() + 86400))
    sid = q("select max(id) from stories")[0][0]
    srow = q("select * from stories where id=?", (sid,))
    scols = [x[1] for x in q("pragma table_info(stories)")]
    q("insert into trash(entity,ref_id,biz_id,title,payload,deleted_at) values('story',?,?,?,?,?)",
      (sid, BIZ, "qa-bin-story", json.dumps(dict(zip(scols, srow[0])), ensure_ascii=False, default=str), time.time()))
    q("delete from stories where id=?", (sid,))
    # نظر عکس‌دار حذف شود
    q("insert into reviews(biz_id,author,rating,body,image,status,customer_id,created) "
      "values(?,?,?,?,?,'approved',NULL,datetime('now'))", (BIZ, "qa-bin-reviewer", 5, "qa-bin-review", IMG))
    rid = q("select max(id) from reviews")[0][0]
    rrow = q("select * from reviews where id=?", (rid,))
    rcols = [x[1] for x in q("pragma table_info(reviews)")]
    q("insert into trash(entity,ref_id,biz_id,title,payload,deleted_at) values('review',?,?,?,?,?)",
      (rid, BIZ, "qa-bin-review", json.dumps(dict(zip(rcols, rrow[0])), ensure_ascii=False, default=str), time.time()))
    q("delete from reviews where id=?", (rid,))

    print("── R1/R3 پنل دکاندار")
    op = sess()
    q("delete from ratelimit where bucket like 'otp%'")
    go(op, "/me/login"); go(op, "/me/login", {"phone": PHONE})
    go(op, "/me/login/verify", {"phone": PHONE, "code": q(
        "select code from otp where phone=? order by rowid desc limit 1", (PHONE,))[0][0]})
    st, my, _ = go(op, "/my/trash")
    check("R1.1", "منوی پنل «بازیابی فایل‌ها» دارد و «سطل بازیافت» نیست",
          "بازیابی فایل‌ها" in my and "سطل بازیافت" not in my)
    check("R1.2", "عنوان صفحه = بازیابی فایل‌ها", "بازیابی فایل‌ها</h2>" in my)
    check("R3.1", "سه پیش‌نمایش (کالا/استوری/نظر) رندر شد", my.count("trash-thumb") >= 3,
          f"n={my.count('trash-thumb')}")
    check("R3.2", "سه thumbnail با مسیر عکس واقعی", my.count(f'data-zi-lb="{IMG}"') >= 3)
    check("R3.3", "لایت‌باکس در صفحه هست", "zi-lightbox" in my and "data-zi-lb" in my)
    check("R7.1", "متن قانون: دیدن بدون بازیابی", "بدون" in my or "همین‌جا" in my)

    print("── R2 پنل مدیر")
    tok = owner_token()
    admin = sess()
    go(admin, "/panel?key=" + tok)   # گیتِ پنل با کلید در URL (رویهٔ qa_panel)
    st, pn, _ = go(admin, "/panel/trash")
    check("R2.1", "پنل: «بازیابی فایل‌ها (سراسری)»", "بازیابی فایل‌ها (سراسری)" in pn)
    check("R2.2", "پیش‌نمایش در پنل سراسری", "trash-thumb" in pn)
    check("R2.3", "سطل بازیافت در پنل منفی است", "سطل بازیافت" not in pn)

    print("── R4 لایت‌باکس E2E")
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        br = pw.chromium.launch()
        ctx = br.new_context(viewport={"width": 360, "height": 740})
        # انتقال نشست دکاندار از urllib به مرورگر
        jar = [h for h in op.handlers if isinstance(h, urllib.request.HTTPCookieProcessor)][0].cookiejar
        for ck in jar:
            ctx.add_cookies([{"name": ck.name, "value": ck.value,
                              "domain": "127.0.0.1", "path": ck.path or "/"}])
        pg = ctx.new_page()
        pg.goto(BASE + "/my/trash", wait_until="networkidle")
        pg.locator(".trash-thumb[data-zi-lb]").first.click()
        pg.wait_for_timeout(400)
        vis = pg.locator(".zi-lightbox").is_hidden()
        check("R4.1", "کلیک بندانگشتی → لایت‌باکس باز شد", not vis)
        pg.screenshot(path="shots-brand/recovery-lightbox.png")
        pg.keyboard.press("Escape"); pg.wait_for_timeout(300)
        check("R4.2", "Escape لایت‌باکس را بست", pg.locator(".zi-lightbox").is_hidden())
        # لمس بندانگشتی
        tb = pg.locator(".trash-thumb").first.bounding_box()
        check("R4.3", "بندانگشتی ≥44px", min(tb["width"], tb["height"]) >= 44, str(tb))
        br.close()

    print("── R5 بازیابی")
    tid_row = q("select id from trash where entity='item' and ref_id=?", (iid,))[0][0]
    st, _, url = go(op, f"/my/trash/{tid_row}/restore", {})
    back = q("select id, image from items where id=?", (iid,))
    check("R5.1", "کالا برگشت و عکسش هست", bool(back) and back[0][1] == IMG)
    q("delete from trash where ref_id=? and entity='item'", (iid,))

    print("── R8 مهلت استاندارد ۳۰ روزه (v177-ادامه)")
    sys.path.insert(0, "server")
    import db as DBM
    keep = DBM.TRASH_RETENTION["item"]
    check("R8.1", "مهلت کالا/نظر/استوری = ۳۰ روز",
          keep == 30 * 86400 and DBM.TRASH_RETENTION["review"] == 30 * 86400
          and DBM.TRASH_RETENTION["story"] == 30 * 86400, str(DBM.TRASH_RETENTION))
    trow = q("select deleted_at from trash where entity='item' limit 1")
    if trow:
        left = DBM.trash_left_seconds(dict(trow[0], entity="item",
                                           deleted_at=trow[0][0]))
        check("R8.2", "ماندهٔ مهلت ~۳۰ روز (>۲۹)", left > 29 * 86400, f"left={left//86400}d")

    print("── R6 GC عکس سطل را پاک نمی‌کند")
    sys.path.insert(0, "server")
    import db as DBM
    refs = DBM.all_upload_refs()
    check("R6.1", "عکس داخل سطل در refs هست", IMG in refs)
    sid2 = q("insert into stories(biz_id,image,kind,created,expires,duration) "
             "values(?,?,?,?,?,0) returning id", (BIZ, IMG, "image", time.time(), time.time() + 3600))[0][0]
    refs = DBM.all_upload_refs()
    check("R6.2", "عکس استوری زنده در refs هست", IMG in refs)
    q("delete from stories where id=?", (sid2,))
    q("insert into reviews(biz_id,author,rating,body,image,status,customer_id,created) "
      "values(?,?,?,?,?,'approved',NULL,datetime('now'))", (BIZ, "gc-probe", 5, "gc-probe", IMG))
    rid2 = q("select max(id) from reviews")[0][0]
    refs = DBM.all_upload_refs()
    check("R6.3", "عکس نظر زنده در refs هست", IMG in refs)
    q("delete from reviews where id=?", (rid2,))

    # ── تمیزکاری
    q("delete from trash where biz_id=? and entity in ('item','story','review')", (BIZ,))
    q("delete from otp")
    red = [r for r in RESULTS if not r[1]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(red)} | قرمز: {len(red)}")
    return 1 if red else 0

if __name__ == "__main__":
    sys.exit(main())
