#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۳ — مشتری: خانه/جست‌وجو، صفحهٔ کالا، سبد و ماندگاری، ثبت سفارش،
«خبرم کن»، زنگوله، نظر ۶ستونه، مرزهای سبد و نرخ‌سنجی."""
import re, sys, json, sqlite3, uuid, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []
A_BIZ, A_SLUG, A_PHONE = 214, "dkan-azmvn-malk-yk", "09352223344"
CUST_PHONE = "09361112233"
ITEM = 336   # کالای آزمون 1 — 1000 تومان، biz 144

def q(sql, args=()):
    c = sqlite3.connect(DB); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None, headers=None, raw=False):
    h = dict(headers or {})
    if data is not None and "Content-Type" not in h and not isinstance(data, (bytes, str)):
        data = urllib.parse.urlencode(data, doseq=True).encode(); h["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(data, str): data = data.encode()
    req = urllib.request.Request(BASE + path, data=data, headers=h)
    try:
        r = op.open(req, timeout=25)
        body = r.read()
        return r.status, body if raw else body.decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        body = e.read()
        return e.code, body if raw else body.decode("utf-8", "replace"), e.geturl()

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def clear_rl():
    q("delete from ratelimit where bucket like 'otp%' or bucket like 'rv:%' or bucket like 'ord:%'")

def login_cust(phone=CUST_PHONE):
    clear_rl()
    op = sess()
    go(op, "/me/login")
    go(op, "/me/login", {"phone": phone})
    go(op, "/me/login/verify", {"phone": phone, "code": otp_code(phone)})
    return op

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

# ─────────────────── C1 خانه و کشف ───────────────────
def c1():
    print("── C1 خانه، جست‌وجو، دسته‌ها")
    op = sess()
    st, b, _ = go(op, "/")
    check("C1.1", "خانه 200 و عنوان اصلی دارد", st == 200 and "hero" in b, f"st={st}")
    st, b, _ = go(op, "/categories")
    check("C1.2", "صفحهٔ دسته‌ها 200", st == 200)
    st, b, _ = go(op, "/api/search?q=" + urllib.parse.quote("آزمون"))
    check("C1.3", "جست‌وجو دکانِ آزمونی را می‌دهد (طراحی: دکان+دسته)", "dkan-azmvn" in b, f"st={st} body={b[:100]}")
    st, b, _ = go(op, "/catalog?q=" + urllib.parse.quote("کالای آزمون"))
    check("C1.3b", "کشف کالا از کاتالوگ با q=", "کالای آزمون" in b, f"st={st}")
    st, b, _ = go(op, f"/b/{A_SLUG}")
    check("C1.4", "صفحهٔ دکان 200 و کالایش دیده می‌شود", st == 200 and "کالای آزمون 1" in b, f"st={st}")

# ─────────────────── C2 صفحهٔ کالا ───────────────────
def c2():
    print("── C2 صفحهٔ کالا")
    op = sess()
    st, b, _ = go(op, f"/item/{ITEM}")
    ok_basic = st == 200 and "کالای آزمون 1" in b
    has_add = ("cart" in b.lower()) or ("سبد" in b)
    check("C2.1", "صفحهٔ کالا 200 با عنوان", ok_basic, f"st={st}")
    check("C2.2", "دکمهٔ افزودن به سبد هست", has_add)
    st, b, _ = go(op, "/item/99999999")
    check("C2.3", "کالای ناموجود → 404 تمیز", st == 404, f"got {st}")

# ─────────────────── C3 سبد و ماندگاری ───────────────────
def c3():
    print("── C3 سبد: کلید، ماندگاری، مرز biz")
    cust = login_cust()
    st, b, _ = go(cust, "/cart")
    check("C3.1", "صفحهٔ سبد 200", st == 200, f"st={st}")
    st, js, _ = go(sess(), "/assets/js/cart.js")
    check("C3.2", "cart.js لود می‌شود و KEY=bazarche_cart_v1 دارد", st == 200 and "bazarche_cart_v1" in js, f"st={st}")
    check("C3.3", "cart.js از سبد/کاتالوگ لینک شده", "cart.js" in b or "cart.js" in js)

# ─────────────────── C4 ثبت سفارش ───────────────────
def c4():
    print("── C4 ثبت سفارش تا صفحهٔ موفقیت")
    cust = login_cust()
    items = json.dumps([{"item_id": ITEM, "title": "کالای آزمون 1", "price": 1000, "qty": 2}])
    st, b, url = go(cust, "/order/create",
                    {"biz_id": A_BIZ, "items": items, "name": "خریدار فاز۳",
                     "phone": CUST_PHONE, "address": "نجف‌آباد", "note": "تست"})
    ok_url = "/order/ok?id=" in url
    o = q("select id from orders where biz_id=? and name='خریدار فاز۳' order by id desc limit 1", (A_BIZ,))
    check("C4.1", "سفارش ثبت شد → /order/ok?id=N", ok_url and o, f"url={url} o={o}")
    if not o: return
    oid = o[0][0]
    st, b, _ = go(cust, f"/order/ok?id={oid}")
    check("C4.2", "صفحهٔ موفقیت سفارش 200 و شماره دارد", st == 200 and str(oid) in b, f"st={st}")
    # رقیم‌گذاری مجدد از کاتالوگ: قیمت واقعی از پایگاه
    oi = q("select price, qty from order_items where order_id=?", (oid,))
    check("C4.3", "ردیف سفارش با قیمت کاتالوگ (1000×2)", oi and int(oi[0][0]) == 1000 and int(oi[0][1]) == 2, f"oi={oi}")
    # سفارش تکراری: همان سبد دوباره — confirm_dup مسیر مالک است؛ اینجا نباید خطا بدهد
    st, b, url2 = go(cust, "/order/create",
                     {"biz_id": A_BIZ, "items": items, "name": "خریدار فاز۳",
                      "phone": CUST_PHONE, "address": "نجف‌آباد", "note": ""})
    check("C4.4", "سفارش دوم هم بی‌خطا ثبت می‌شود (dedupe سطح مالک)", "/order/ok?id=" in url2, f"url={url2}")
    ids = [r[0] for r in q("select id from orders where biz_id=? and name='خریدار فاز۳' order by id", (A_BIZ,))]
    for i in ids:
        q("delete from order_items where order_id=?", (i,))
        q("delete from orders where id=?", (i,))
        q("delete from notifications where link like ?", (f"/me/order/{i}",))

# ─────────────────── C5 خبرم کن ───────────────────
def c5():
    print("── C5 «موجود شد خبرم کن»")
    cust = login_cust()
    q("delete from stock_requests where customer_id=(select id from customers where phone=?) and item_id=?", (CUST_PHONE, ITEM))
    st, b, url = go(cust, f"/item/{ITEM}/notify-me", {})
    row = q("select id, status from stock_requests where customer_id=(select id from customers where phone=?) and item_id=?", (CUST_PHONE, ITEM))
    check("C5.1", "درخواست خبرم‌کن ثبت شد", row, f"url={url} row={row}")
    st, b, _ = go(cust, f"/item/{ITEM}")
    check("C5.2", "بعد از ثبت، صفحهٔ کالا پیام تأیید/وضعیت دارد", st == 200)
    q("delete from stock_requests where customer_id=(select id from customers where phone=?) and item_id=?", (CUST_PHONE, ITEM))

# ─────────────────── C6 زنگوله و اعلان ───────────────────
def c6():
    print("── C6 زنگوله: اعلان سفارش برای مشتری")
    cust = login_cust()
    # یک اعلان آزمایشی مستقیم در جدول — مانند اعلان واقعی وضعیت سفارش
    q("insert into notifications(customer_id,kind,text,link,read,created) values(?,?,?,?,0,datetime('now'))",
      (q("select id from customers where phone=?", (CUST_PHONE,))[0][0], "order", "آزمون زنگوله فاز۳", "/me/orders"))
    n = q("select count(*) from notifications where customer_id=(select id from customers where phone=?) and read=0", (CUST_PHONE,))[0][0]
    check("C6.1", "اعلان نخوانده ثبت شد", n >= 1, f"n={n}")
    st, b, _ = go(cust, "/api/unread-count")
    check("C6.2", "شمارندهٔ نخوانده API عدد می‌دهد", re.search(r'"(?:count|n|unread)"\s*:\s*[1-9]', b), f"body={b[:80]}")
    st, b, _ = go(cust, "/me/notifications")
    check("C6.3", "اعلان در صفحهٔ زنگوله دیده می‌شود", "آزمون زنگوله فاز۳" in b, f"st={st}")
    nid = q("select id from notifications where text='آزمون زنگوله فاز۳' order by id desc limit 1")[0][0]
    st, b, url = go(cust, f"/me/notif/{nid}/go")
    rd = q("select read from notifications where id=?", (nid,))[0][0]
    check("C6.4", "کلیک اعلان = خوانده‌شدن + پرش به مقصد", rd == 1 and "/me/orders" in url, f"read={rd} url={url}")
    q("delete from notifications where text='آزمون زنگوله فاز۳'")

# ─────────────────── C7 نظر ۶ستونه ───────────────────
def c7():
    print("── C7 نظر: ستارهٔ ۶تایی + ثبت + نمایش")
    cust = login_cust()
    st, b, _ = go(cust, f"/b/{A_SLUG}")
    has6 = 'aria-pressed="false"' in b and "data-rating-input" in b
    check("C7.1", "کادر امتیاز ۶ستونه در فرم هست (multicriteria off)", has6 or "rating" in b, f"has6={has6}")
    q("delete from reviews where body like 'نظر آزمونی فاز سه%'")
    # مسیر واقعی UI با multicriteria=1: امتیاز از crit_* (کادر ۶ستونه با برچسب بالا — v157)
    st, b, url = go(cust, f"/b/{A_SLUG}/review",
                    {"author": "خریدار فاز۳", "body": "نظر آزمونی فاز سه — کیفیت خوب",
                     "crit_quality": "6", "crit_price": "5", "crit_speed": "5", "crit_behaviour": "6"})
    row = q("select id,author,status from reviews where biz_id=? and body like 'نظر آزمونی فاز سه%' order by id desc limit 1", (A_BIZ,))
    check("C7.2", "نظر ثبت شد (ملایم‌گذاری: pending)", row and row[0][2] == "pending", f"row={row}")
    if row:
        rid = row[0][0]
        sc = q("select criterion,score from review_scores where review_id=? order by criterion", (rid,))
        check("C7.3", "امتیازهای ۶گانهٔ معیارها ذخیره شد", len(sc) == 4 and sc[0][1] == 6, f"sc={sc}")
        st, b, _ = go(sess(), f"/b/{A_SLUG}")
        check("C7.4", "نظر pending هنوز عمومی نیست (مدارک درست)", "نظر آزمونی فاز سه" not in b)
        # تأیید از پنل مدیر — همان مسیر واقعی
        admin = sess()
        KEY = DBM.owner_token()
        go(admin, "/login"); go(admin, "/login", {"phone": "09131110011"})
        go(admin, "/login/verify", {"phone": "09131110011", "code": otp_code("09131110011")})
        go(admin, "/panel?key=" + KEY)
        go(admin, f"/panel/review/{rid}", {"action": "approve", "reply": ""})
        st, b, _ = go(sess(), f"/b/{A_SLUG}")
        check("C7.5", "بعد از تأیید مدیر، نظر عمومی شد", "نظر آزمونی فاز سه" in b, f"st={st}")
        q("delete from review_scores where review_id=?", (rid,))
        q("delete from reviews where id=?", (rid,))

# ─────────────────── C8 نرخ‌سنجی سفارش ───────────────────
def c8():
    print("── C8 نرخ‌سنجی: بیش از ۱۰ سفارش در پنجره رد می‌شود")
    cust = login_cust()
    items = json.dumps([{"item_id": ITEM, "title": "کالای آزمون 1", "price": 1000, "qty": 1}])
    codes = []
    for i in range(12):
        st, b, url = go(cust, "/order/create",
                        {"biz_id": A_BIZ, "items": items, "name": "نرخ‌سنجی",
                         "phone": "", "address": "", "note": ""})
        codes.append(st)
    ids = [r[0] for r in q("select id from orders where biz_id=? and name='نرخ‌سنجی'", (A_BIZ,))]
    rejected = len(codes) - len(ids)   # redirect به cart?err = سفارش ثبت‌نشده
    check("C8.1", "حداقل یک سفارشِ فراتر از سقف رد شد", rejected >= 1 or len(ids) < 12, f"ثبت‌شده={len(ids)} از 12")
    for i in ids:
        q("delete from order_items where order_id=?", (i,))
        q("delete from orders where id=?", (i,))
        q("delete from notifications where link like ?", (f"/me/order/{i}",))
    clear_rl()

def c9():
    """v176 قفل رفع: رأی «مفید بود» یک‌تاست — تکرار همان رأی‌دهنده شمارنده را بالا نمی‌برد."""
    print("── C9 رأی مفید یک‌تا (v176) ──")
    q("delete from review_votes")
    rid = q("insert into reviews(biz_id,author,rating,body,status) values(?,?,?,?,?)",
            (A_BIZ, "رأی‌آزمون", 0, "نظر آزمون رأی v176", "approved"))
    rid = q("select max(id) from reviews")[0][0]
    h0 = q("select helpful from reviews where id=?", (rid,))[0][0]
    cust = login_cust()
    st, b, _ = go(cust, "/api/review-helpful", {"id": rid})
    j1 = json.loads(b)
    st, b, _ = go(cust, "/api/review-helpful", {"id": rid})
    j2 = json.loads(b)
    h_db = q("select helpful from reviews where id=?", (rid,))[0][0]
    check("C9.1", "رأی اول +۱ و رأی دوم همان مشتری no-op", j1["ok"] and j2["ok"]
          and j1["helpful"] == h0 + 1 and j2["helpful"] == j1["helpful"] and h_db == j1["helpful"],
          f"h0={h0} j1={j1} j2={j2} db={h_db}")
    # رأی‌دهندهٔ دوم (مشتری دیگر — ساختهٔ موقت) → +۱ مجاز
    cid2 = q("select id from customers where phone='09361112234'")
    if not cid2:
        cust2 = login_cust("09361112234")
        cid2 = q("select id from customers where phone='09361112234'")
    cust2 = login_cust("09361112234")
    st, b, _ = go(cust2, "/api/review-helpful", {"id": rid})
    j3 = json.loads(b)
    check("C9.2", "رأی مشتری دوم +۱", j3["ok"] and j3["helpful"] == j2["helpful"] + 1, f"j3={j3}")
    # مهمان (کلاینت تازه) → +۱؛ تکرار مهمان → no-op
    an1, an2 = sess(), sess()
    st, b, _ = go(an1, "/api/review-helpful", {"id": rid})
    j4 = json.loads(b)
    st, b, _ = go(an2, "/api/review-helpful", {"id": rid})
    j5 = json.loads(b)
    check("C9.3", "رأی مهمان از یک کلاینت فقط یک‌بار", j4["ok"] and j5["ok"]
          and j5["helpful"] == j4["helpful"], f"j4={j4} j5={j5}")
    nv = q("select count(*) from review_votes where review_id=?", (rid,))[0][0]
    check("C9.4", "ردیف رأی‌ها با شمارنده می‌خواند", nv == q("select helpful from reviews where id=?", (rid,))[0][0],
          f"votes={nv}")
    q("delete from review_votes where review_id=?", (rid,))
    q("delete from reviews where id=?", (rid,))
    q("delete from customer_sessions where customer_id=?", (cid2[0][0],))
    q("delete from customers where id=?", (cid2[0][0],))


def c10():
    """v176 قفل رفع: سقف تعداد ۹۹ با اعلان صریح روی رسید سفارش."""
    print("── C10 اعلان سقف ۹۹ (v176) ──")
    clear_rl()
    cust = login_cust()
    items = json.dumps([{"item_id": ITEM, "title": "کالای آزمون 1", "price": 1000, "qty": 999}])
    st, b, url = go(cust, "/order/create", {"biz_id": A_BIZ, "items": items,
                    "name": "مشتری آزمون", "phone": CUST_PHONE})
    ok = "/order/ok" in url and "cap=1" in url
    check("C10.1", "تعداد ۹۹۹ → رسید با پرچم cap", ok, f"url={url[-40:]}")
    oid = url.split("id=")[-1].split("&")[0]
    st, b, _ = go(cust, f"/order/ok?id={oid}&cap=1")
    check("C10.2", "پیام «حداکثر ۹۹» روی رسید", "حداکثر تعداد هر کالا" in b, "")
    st, b, _ = go(cust, f"/order/ok?id={oid}")
    check("C10.3", "بدون cap پیام نیست", "حداکثر تعداد هر کالا" not in b, "")
    qq = q("select qty from order_items where order_id=?", (oid,))
    check("C10.4", "qty در پایگاه ≤۹۹", bool(qq) and qq[0][0] <= 99, f"qty={qq[0][0] if qq else '?'}")
    q("delete from order_items where order_id=?", (oid,))
    q("delete from orders where id=?", (oid,))
    q("delete from notifications where link like ?", (f"/me/order/{oid}",))
    clear_rl()


def main():
    c1(); c2(); c3(); c4(); c5(); c6(); c7(); c8(); c9(); c10()
    json.dump(RESULTS, open("qa/phase3-results.json", "w"), ensure_ascii=False, indent=1)
    fails = [r for r in RESULTS if not r["ok"]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(fails)} | قرمز: {len(fails)}")
    for r in fails:
        print("  ❌", r["id"], r["name"], "—", r["detail"])
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
