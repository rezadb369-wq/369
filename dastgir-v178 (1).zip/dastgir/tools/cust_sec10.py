# -*- coding: utf-8 -*-
"""بخش ۱۰ (نسخهٔ ۲) — زنگوله و اعلان‌ها + علاقه‌مندی/دنبال‌شده (بذر idempotent سمت سرور)."""
import sys, sqlite3, re
sys.path.insert(0, 'tools')
from cust_lib import *
from playwright.sync_api import sync_playwright

recs = []
log = print


def login(br, phone):
    c = sqlite3.connect(DB)
    c.execute("delete from otp"); c.execute("delete from ratelimit"); c.commit()
    u = ctx(br); pg = u.new_page()
    pg.on('dialog', lambda d: d.accept())
    pg.goto(BASE + '/login')
    pg.fill('form[action="/login"] input[name="phone"]', phone)
    pg.click('form[action="/login"] button[type="submit"]', no_wait_after=True)
    pg.wait_for_selector('input[name="code"]')
    pg.fill('input[name="code"]', otp_code(phone))
    try:
        pg.click('form[action="/login/verify"] button[type="submit"]', no_wait_after=True, timeout=6000)
    except Exception:
        pass
    try:
        pg.wait_for_url('**/my', timeout=8000)
    except Exception:
        try:
            pg.evaluate("document.querySelector('form[action=\\'/login/verify\\']').submit()")
        except Exception:
            pass
        pg.wait_for_url('**/my', timeout=20000)
    return u, pg


# ── بذر idempotent: پاک‌سازی رابطه‌ها، بعد ثبت تازه (روشن قطعی) ──
import urllib.request, urllib.parse
import http.cookiejar as hcj
c0 = sqlite3.connect(DB)
c0.execute("delete from favorites where customer_id=17")
c0.execute("delete from follows where customer_id=17")
c0.commit()
oo = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(hcj.CookieJar()))
def srv(p, d=None):
    b = urllib.parse.urlencode(d, encoding='utf-8').encode() if d is not None else None
    h = {'Content-Type': 'application/x-www-form-urlencoded'} if b else {}
    return oo.open(urllib.request.Request(BASE + p, data=b, headers=h), timeout=25).read().decode('utf-8', 'replace')
srv('/login'); srv('/login', {'phone': '09361112233'})
code0 = c0.execute("select code from otp order by rowid desc limit 1").fetchone()[0]
srv('/login/verify', {'phone': '09361112233', 'code': code0})
srv('/api/follow', {'biz_id': 214})
srv('/api/favorite', {'biz_id': 215})
assert c0.execute("select count(*) from favorites where customer_id=17").fetchone()[0] == 1
assert c0.execute("select count(*) from follows where customer_id=17").fetchone()[0] == 1

with sync_playwright() as pw:
    br = pw.chromium.launch()
    u, pg = login(br, '09361112233')

    # ── 10.1 صفحهٔ اعلان‌ها ──
    r = audit(pg, 'sec10-notifs', '/me/notifications')
    body = pg.inner_text('body')
    has_reply = 'پاسخ داد' in body
    has_chat = ('گفت' in body) or ('پیام' in body)
    r['extra'] = f'اعلان پاسخ پرسش: {has_reply} | اعلان پیام: {has_chat}'
    recs.append(r); log(fmt(r), '|', r['extra'])

    n = sqlite3.connect(DB).execute(
        "select count(*) from notifications where customer_id=17").fetchone()[0]
    rows = sqlite3.connect(DB).execute(
        "select kind,read from notifications where customer_id=17 order by id desc limit 5").fetchall()
    r = {'name': 'sec10-notif-rows', 'url': '/me/notifications', 'status': 200,
         'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
         'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
         'extra': f'ردیف‌های اعلان مشتری ۱۷: {n} | ۵ تای آخر: {rows}'}
    recs.append(r); log('ℹ️ sec10-notif-rows |', r['extra'])

    # ── 10.2 زنگوله در /me (لینک با عنوان اعلان‌ها + عدد) ──
    pg.goto(BASE + '/me'); pg.wait_for_load_state('networkidle')
    badge = pg.evaluate("""()=>{const a=document.querySelector('a[title="اعلان‌ها"]');
      return a? {txt:(a.innerText||'').trim().replace(/\\s+/g,'/'), href:a.getAttribute('href'), vis:!!a.offsetWidth} : null}""")
    r = {'name': 'sec10-badge', 'url': '/me', 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0,
         'extra': f'زنگولهٔ اعلان در سربرگ: {badge}'}
    recs.append(r); log('ℹ️ sec10-badge |', r['extra'])

    # ── 10.3 علاقه‌مندی‌ها ──
    r = audit(pg, 'sec10-favs', '/me/favorites')
    fav_ok = 'دکانٔ آزمون مالک دو' in pg.inner_text('body')
    r['extra'] = f'علاقه‌مندی ۲۱۵ در فهرست: {fav_ok}'
    recs.append(r); log(fmt(r), '|', r['extra'])

    # ── 10.4 دنبال‌شده‌ها ──
    r = audit(pg, 'sec10-following', '/me/following')
    fol_ok = 'دکانٔ آزمون مالک یک' in pg.inner_text('body')
    r['extra'] = f'دکان A در دنبال‌شده‌ها: {fol_ok}'
    recs.append(r); log(fmt(r), '|', r['extra'])

    # ── 10.5 گفت‌وگوها ──
    r = audit(pg, 'sec10-chats', '/me/chats')
    body = pg.inner_text('body')
    r['extra'] = f'فهرست گفت‌وگوها رشته دارد: {("گفت" in body) or ("دکان" in body)}'
    recs.append(r); log(fmt(r), '|', r['extra'])

    u.close(); br.close()

save(recs, '10-اعلان')
reds = [r for r in recs if 'False' in str(r.get('extra', ''))]
print(f"\n── بخش ۱۰: {len(recs)} سنج | قرمز: {len(reds)}")
