#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v75 section 4: price visibility, city-news nav, hero/performance."""

import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "server"))
import db  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
PREFIX = "v75-section4-probe"
OWNER_PHONE = "09129997801"
CUSTOMER_PHONE = "09129997802"
PASS, FAIL = [], []


def check(label, condition, detail=""):
    if condition:
        PASS.append(label); print("  ✓", label)
    else:
        FAIL.append((label, detail)); print("  ✗", label, f"[{detail}]" if detail else "")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs): return None


def request(path, cookie=""):
    headers = {"User-Agent": "bazarche-v75-test"}
    if cookie: headers["Cookie"] = cookie
    req = urllib.request.Request(BASE + path, headers=headers)
    try:
        res = urllib.request.build_opener(NoRedirect()).open(req, timeout=30)
        return res.status, dict(res.headers), res.read().decode("utf-8", "ignore")
    except urllib.error.HTTPError as exc:
        return exc.code, dict(exc.headers), exc.read().decode("utf-8", "ignore")


def cleanup():
    for business in db.businesses(status=None):
        if business["name"].startswith(PREFIX): db.delete_business(business["id"])
    for phone in (OWNER_PHONE, CUSTOMER_PHONE):
        customer = db.customer_by_phone(phone)
        if customer: db.customer_delete(customer["id"])
        owner = db.owner_by_phone(phone)
        if owner: db.delete_owner(owner["id"])


def setup():
    db.init(); cleanup()
    category = db.categories(only_active=True)[0]
    owner = db.owner_by_phone(OWNER_PHONE, create=True)
    customer = db.customer_by_phone(CUSTOMER_PHONE, create=True)
    db.customer_set_profile(customer["id"], "کاربر", "قیمت")
    bid = db.save_business({
        "name": PREFIX + "-shop", "cat_slug": category["slug"], "status": "published",
        "phone": OWNER_PHONE, "owner_id": owner["id"], "city": "نجف‌آباد",
        "address": "نشانی آزمون قیمت",
    })
    bid2 = db.save_business({
        "name": PREFIX + "-shop-two", "cat_slug": category["slug"], "status": "published",
        "phone": "03142610075", "city": "نجف‌آباد", "address": "نشانی دوم",
    })
    item_title = PREFIX + " محصول ثابت"
    iid = db.save_item({
        "biz_id": bid, "kind": "product", "title": item_title,
        "descr": "محصول آزمایشی برای کنترل نمایش عمومی", "price": 875000,
        "old_price": 950000, "price_type": "fixed", "available": 1,
        "haggle": 1, "floor_price": 800000,
    })
    db.save_item({
        "biz_id": bid2, "kind": "product", "title": item_title,
        "price": 920000, "price_type": "fixed", "available": 1,
    })
    order_id = db.create_order(
        bid, customer["id"], "کاربر قیمت", CUSTOMER_PHONE, "نشانی", "",
        [{"item_id": iid, "title": item_title, "price": 875000, "qty": 2}])
    return {
        "owner": owner, "customer": customer, "business": db.business(bid=bid),
        "business2": db.business(bid=bid2), "item": db.item(iid), "order_id": order_id,
        "owner_cookie": "bzv2_sess=" + db.session_new(owner["id"]),
        "customer_cookie": "bzv2_cust=" + db.customer_session_new(customer["id"]),
    }


def task_prices_off(fx):
    print("\n══ ۱) خاموشی کامل قیمت در سایت عمومی ══")
    # v154: تصمیم کاربر معکوس شد — پیش‌فرض کد اکنون «روشن» است؛ خاموشی حالتِ
    # اختیاریِ مدیر است و همان رفتار v75 را دارد (این بخش همان حالت را می‌آزماید).
    check("پیش‌فرض کد برای قیمت‌ها روشن است (تصمیم v154)",
          db.DEFAULT_SETTINGS.get("prices_enabled") == "1",
          repr(db.DEFAULT_SETTINGS.get("prices_enabled")))
    db.set_setting("prices_enabled", "0")
    slug = fx["business"]["slug"]
    q = urllib.parse.quote(PREFIX)

    prices_code, _, prices_html = request("/prices")
    catalog_code, _, catalog = request("/catalog?q=" + q)
    biz_code, _, business = request("/b/" + slug)
    home_code, _, home = request("/")
    feature_code, _, features = request("/features")
    sitemap_code, _, sitemap = request("/sitemap.xml")
    customer_code, _, customer_orders = request("/me/orders", fx["customer_cookie"])
    order_code, _, order = request(f"/me/order/{fx['order_id']}", fx["customer_cookie"])
    owner_code, _, owner_catalog = request(
        f"/my/catalog/{fx['business']['id']}", fx["owner_cookie"])
    admin_code, _, admin_features = request(
        "/panel/features?key=" + urllib.parse.quote(db.owner_token()))

    check("مسیر مقایسهٔ قیمت هنگام خاموشی 404 است", prices_code == 404, str(prices_code))
    check("کاتالوگ عمومی هیچ مبلغ/تخفیف/سبد/چانه‌زنی نشان نمی‌دهد",
          catalog_code == 200 and 'item-price' not in catalog and 'data-add-cart' not in catalog
          and '/haggle/' not in catalog and 'تومان' not in catalog and '٪ تخفیف' not in catalog,
          "public catalog still exposes price UI")
    check("صفحهٔ دکان قیمت و فضای وابسته را کامل حذف می‌کند",
          biz_code == 200 and 'item-price' not in business and 'price-context' not in business
          and 'data-add-cart' not in business and '/haggle/' not in business
          and 'تومان' not in business,
          "business page still exposes price UI")
    check("سفارش‌های قبلی مشتری مبلغ را نشان نمی‌دهند",
          customer_code == 200 and order_code == 200 and 'تومان' not in customer_orders
          and 'تومان' not in order and '875' not in order,
          "customer order leaked money")
    check("مدیریت دکان همچنان قیمت را برای ویرایش می‌بیند",
          owner_code == 200 and 'قیمت' in owner_catalog and fx["item"]["price_text"] in owner_catalog,
          "owner management lost price data")
    check("کلید اجازهٔ قیمت در پنل مدیر وجود دارد",
          admin_code == 200 and 'name="prices_enabled"' in admin_features
          and 'نمایش قیمت' in admin_features,
          "admin price switch missing")
    check("منوی عمومی و صفحهٔ امکانات لینک قیمت ندارند",
          home_code == 200 and feature_code == 200 and 'href="/prices"' not in home
          and 'href="/prices"' not in features,
          "public price link still visible")
    check("sitemap هنگام خاموشی قیمت مسیر /prices ندارد",
          sitemap_code == 200 and '/prices' not in sitemap, sitemap[:200])

    # Inspect ONLY the fixed bottom nav: top nav may show /prices when re-enabled later.
    bottom = home.split('<nav class="bottom-nav"', 1)[1].split('</nav>', 1)[0] if '<nav class="bottom-nav"' in home else ""
    check("نوار پایین پنل دکان را جایگزین قیمت‌ها کرده است",
          'href="/my"' in bottom and 'پنل دکان' in bottom and '/prices' not in bottom,
          bottom[:500])


def task_cart_off(fx):
    print("\n══ ۲) سبد و سفارش در حالت قیمت خاموش ══")
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        for width in (360, 390, 412):
            context = browser.new_context(viewport={"width": width, "height": 844},
                                          locale="fa-IR", is_mobile=True, has_touch=True,
                                          service_workers="block")
            cart = [{
                "id": str(fx["item"]["id"]), "biz": str(fx["business"]["id"]),
                "bizname": fx["business"]["name"], "title": fx["item"]["title"],
                "price": 875000, "qty": 2,
            }]
            context.add_init_script(
                "localStorage.setItem('bazarche_cart_v1', " + json.dumps(json.dumps(cart)) + ")")
            page = context.new_page(); errors = []
            page.on("pageerror", lambda error: errors.append(str(error)))
            page.goto(BASE + "/cart", wait_until="networkidle"); page.wait_for_timeout(180)
            html = page.locator("#cart-root").inner_text()
            metrics = page.evaluate("""()=>({overflow:document.documentElement.scrollWidth-document.documentElement.clientWidth,
              form:!!document.querySelector('#cart-root form[action="/order/create"]'),
              disabled:!!document.querySelector('[data-price-disabled-cart]')})""")
            check(f"{width}px: سبد مبلغ و جمع را پنهان می‌کند",
                  "875" not in html and "تومان" not in html and "مجموع" not in html, html[:300])
            check(f"{width}px: ثبت سفارش بدون نمایش قیمت مسدود و توضیح داده می‌شود",
                  not metrics["form"] and metrics["disabled"], str(metrics))
            check(f"{width}px: سبد خاموش سرریز/خطای JavaScript ندارد",
                  metrics["overflow"] <= 0 and not errors, str((metrics, errors)))
            context.close()
        browser.close()


def task_prices_on(fx):
    print("\n══ ۳) بازگشت قیمت فقط با اجازهٔ مدیر ══")
    _saved = db.get_settings().get("prices_enabled", "1")   # v155: hermetic
    db.set_setting("prices_enabled", "1")
    q = urllib.parse.quote(PREFIX)
    slug = fx["business"]["slug"]
    prices_code, _, prices = request("/prices?q=" + q)
    catalog_code, _, catalog = request("/catalog?q=" + q)
    biz_code, _, business = request("/b/" + slug)
    home_code, _, home = request("/")
    check("مسیر قیمت پس از اجازهٔ مدیر بازمی‌گردد",
          prices_code == 200 and 'مقایسهٔ قیمت' in prices and 'تومان' in prices,
          str(prices_code))
    check("مبلغ و اقدام خرید/پیشنهاد کاتالوگ دوباره برمی‌گردند",
          catalog_code == 200 and 'item-price' in catalog and 'تومان' in catalog
          and ('data-add-cart' in catalog or '/haggle/' in catalog),
          "catalog price UI did not return")
    check("صفحهٔ دکان دوباره قیمت را نشان می‌دهد",
          biz_code == 200 and 'item-price' in business and 'تومان' in business,
          "business price UI did not return")
    check("لینک بالای سایت با روشن‌شدن قابلیت برمی‌گردد",
          home_code == 200 and 'href="/prices"' in home,
          "top price navigation did not return")
    bottom = home.split('<nav class="bottom-nav"', 1)[1].split('</nav>', 1)[0]
    check("نوار پایین حتی با روشن‌شدن قیمت، پنل دکان می‌ماند",
          'href="/my"' in bottom and '/prices' not in bottom, bottom[:400])
    db.set_setting("prices_enabled", _saved)   # v155: restore (قبلاً صفرِ ثابت می‌گذاشت)


def task_video_and_performance():
    print("\n══ ۴) حذف فیلم و بودجهٔ سرعت/کیفیت ══")
    video = os.path.join(ROOT, "site", "assets", "video", "hero.mp4")
    poster = os.path.join(ROOT, "site", "assets", "img", "hero-bazaar.webp")
    hero_js = os.path.join(ROOT, "site", "assets", "js", "hero.js")
    check("فایل فیلم پس‌زمینه حذف شده", not os.path.exists(video), video)
    check("پوستر و اسکریپت مخصوص فیلم نیز حذف شده‌اند",
          not os.path.exists(poster) and not os.path.exists(hero_js),
          str((os.path.exists(poster), os.path.exists(hero_js))))
    code, _, home = request("/")
    check("HTML خانه هیچ video/hero.mp4/hero.js ندارد",
          code == 200 and '<video' not in home and 'hero.mp4' not in home and '/hero.js' not in home,
          "video reference remains")
    check("جای فیلم با پس‌زمینهٔ CSS سبک حفظ شده",
          'class="hero-visual is-static"' in home,
          "lightweight hero visual missing")

    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        for width in (390, 1440):
            context = browser.new_context(viewport={"width": width, "height": 900},
                                          is_mobile=width < 500, has_touch=width < 500,
                                          service_workers="block")
            page = context.new_page(); errors = []
            page.on("pageerror", lambda error: errors.append(str(error)))
            page.goto(BASE + "/", wait_until="networkidle"); page.wait_for_timeout(500)
            perf = page.evaluate("""()=>{const rs=performance.getEntriesByType('resource');return {
              count:rs.length, encoded:rs.reduce((n,r)=>n+r.encodedBodySize,0),
              urls:rs.map(r=>r.name), overflow:document.documentElement.scrollWidth-document.documentElement.clientWidth,
              heroH:document.querySelector('.h-hero')?.getBoundingClientRect().height||0};}""")
            check(f"{width}px: فیلم، پوستر، hero.js و sprite سنگین در بار اول دانلود نمی‌شوند",
                  not any(('hero.mp4' in u or 'hero-bazaar.webp' in u or '/hero.js' in u
                           or 'sprite.webp' in u) for u in perf["urls"]),
                  str([u for u in perf["urls"] if 'hero' in u or 'sprite' in u]))
            check(f"{width}px: بودجهٔ اولیهٔ صفحه کمتر از ۱٫۲MB است",
                  perf["encoded"] < 1_200_000, str(perf["encoded"]))
            check(f"{width}px: هیرو باکیفیت، قابل‌دیدن و بدون سرریز/خطاست",
                  perf["heroH"] >= 300 and perf["overflow"] <= 0 and not errors,
                  str((perf, errors)))
            context.close()
        browser.close()


def main():
    original = db.get_settings().get("prices_enabled")
    fx = setup()
    try:
        task_prices_off(fx)
        task_cart_off(fx)
        task_prices_on(fx)
        task_video_and_performance()
    finally:
        db.set_setting("prices_enabled", original if original is not None else "0")
        cleanup()
    print("\n" + "═" * 62)
    print(f"  {len(PASS)} موفق، {len(FAIL)} ناموفق")
    for label, detail in FAIL: print("   ✗", label, detail)
    print("═" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
