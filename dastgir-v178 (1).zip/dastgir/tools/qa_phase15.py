#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۱۵ — تلفیق نهایی: رفع کاندیدهای باز + ارتقاهای پذیرفته‌شده.
#40 سبد دستکاری‌شده (item_id وحشی → FK 500 و چسبیدن به کالای دکان دیگر)،
ارتقای دِدوپ صف تغییرات، رگرسیون قیمتی F-012، و حکم مستند رأی helpful."""
import re, sys, json, sqlite3, time, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []
ADMIN_PHONE = "09131110011"
SHOP_PHONE = "09352223344"
CUST_PHONE = "09361112233"

def q(sql, args=()):
    """نوشتن/خواندن با بسته‌شدنِ امن و تلاشِ مجدد — درس فاز ۱۳/۱۴."""
    last = None
    for attempt in range(6):
        c = sqlite3.connect(DB, timeout=20)
        try:
            r = c.execute(sql, args).fetchall(); c.commit(); return r
        except sqlite3.OperationalError as e:
            if "locked" not in str(e) and "busy" not in str(e):
                raise
            last = e; time.sleep(3 + attempt * 2)
        finally:
            c.close()
    raise last

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None):
    h = {}
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data, doseq=True).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(BASE + path, data=body, headers=h)
    try:
        r = op.open(req, timeout=40)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def login(phone, admin=False):
    q("delete from ratelimit")
    op = sess()
    go(op, "/login")
    go(op, "/login", {"phone": phone})
    go(op, "/login/verify", {"phone": phone, "code": otp_code(phone)})
    if admin:
        go(op, "/panel?key=" + DBM.owner_token())
    return op

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

created = {"orders": [], "items": [], "edits": [], "reviews": [], "settings": {}}

def snap(*keys):
    for k in keys:
        r = q("select value from settings where key=?", (k,))
        created["settings"][k] = r[0][0] if r else None
    # نام دکان 214 هم بخشی از صحنهٔ پایهٔ باتری‌هاست — دست‌خوردنی و بازگردانی‌شدنی
    created["biz214_name"] = q("select name from businesses where id=214")[0][0]

# ─────────────────── T1 سفارش با سبد دستکاری‌شده (#40) ───────────────────
def t1():
    print("── T1 سفارش: item_id وحشی، کالای دکانِ دیگر، رگرسیون F-012")
    cust = login(CUST_PHONE)
    # ردیف وحشی: item_id ناموجود — قبلاً FOREIGN KEY → 500
    cart = json.dumps([{"item_id": 999999999, "title": "ردیف وحشی", "price": 5000, "qty": 2}],
                      ensure_ascii=False)
    st, b, url = go(cust, "/order/create",
                    {"biz_id": 214, "items": cart, "name": "مشتری آزمون",
                     "phone": CUST_PHONE})
    oid = None
    m = re.search(r"order/ok\?id=(\d+)", url)
    if m:
        oid = int(m.group(1)); created["orders"].append(oid)
    check("T1.1", "#40 سبد وحشی → ثبت سالم (نه 500)، به /order/ok",
          st == 200 and oid is not None, f"st={st} url={url[:60]}")
    if oid:
        row = q("select item_id,title,price,qty from order_items where order_id=?", (oid,))
        tot = q("select total from orders where id=?", (oid,))[0][0]
        check("T1.2", "ردیف وحشی: item_id=NULL و جمع درست",
              row and row[0][0] is None and row[0][2] == 5000 and row[0][3] == 2 and tot == 10000,
              f"row={row} total={tot}")
    # کالای واقعی دکانِ دیگر — نباید به سفارش 214 بچسبد (باتری خودش می‌سازد)
    iid_other = DBM.save_item({"biz_id": 215, "kind": "product",
                               "title": "کالای آزمون دکان دیگر فاز ۱۵",
                               "price": "60000", "price_type": "fixed",
                               "available": 1})
    created["items"].append(iid_other)
    cart2 = json.dumps([{"item_id": iid_other, "title": "کالای دکان دیگر", "price": 777, "qty": 1}],
                       ensure_ascii=False)
    st, b, url = go(cust, "/order/create",
                    {"biz_id": 214, "items": cart2, "name": "مشتری آزمون", "phone": CUST_PHONE})
    m = re.search(r"order/ok\?id=(\d+)", url)
    oid2 = int(m.group(1)) if m else None
    if oid2: created["orders"].append(oid2)
    row = q("select item_id,title,price from order_items where order_id=?", (oid2 or 0,))
    check("T1.3", "کالای دکان دیگر: به ردیف آزاد (item_id=NULL) تبدیل شد",
          oid2 is not None and row and row[0][0] is None and row[0][2] == 777,
          f"other={iid_other} row={row}")
    # رگرسیون F-012 — کالای واقعیِ همین دکان با قیمت جعلی صفر → قیمت از پایگاه
    real = q("select id,title,price from items where biz_id=214 order by id limit 1")
    if real:
        cart3 = json.dumps([{"item_id": real[0][0], "title": "جعلی", "price": 0, "qty": 1}],
                           ensure_ascii=False)
        st, b, url = go(cust, "/order/create",
                        {"biz_id": 214, "items": cart3, "name": "مشتری آزمون", "phone": CUST_PHONE})
        m = re.search(r"order/ok\?id=(\d+)", url)
        oid3 = int(m.group(1)) if m else None
        if oid3: created["orders"].append(oid3)
        row = q("select item_id,title,price from order_items where order_id=?", (oid3 or 0,))
        check("T1.4", "F-012 برقرار: کالای واقعی از پایگاه قیمت‌خوری (item_id و قیمت درست)",
              oid3 is not None and row and row[0][0] == real[0][0]
              and row[0][1] == real[0][1] and row[0][2] == real[0][2],
              f"real={real[0]} row={row}")
    else:
        check("T1.4", "F-012 (کالایی برای 214 نبود)", False)
    # جریان عادی — بدون item_id (ردیف آزاد قانونی)
    cart4 = json.dumps([{"title": "چیدمان اختصاصی مجلس", "price": 250000, "qty": 1}],
                       ensure_ascii=False)
    st, b, url = go(cust, "/order/create",
                    {"biz_id": 214, "items": cart4, "name": "مشتری آزمون", "phone": CUST_PHONE})
    m = re.search(r"order/ok\?id=(\d+)", url)
    oid4 = int(m.group(1)) if m else None
    if oid4: created["orders"].append(oid4)
    check("T1.5", "جریان عادی ردیف آزاد سالم", st == 200 and oid4 is not None, f"url={url[:60]}")

# ─────────────────── T2 دِدوپ صف تغییرات (ارتقا) ───────────────────
def t2():
    print("── T2 صف تغییرات: ارسال تکراری = ردیف تازه نه")
    snap("edit_approval")
    q("update settings set value='1' where key='edit_approval'")
    q("update businesses set owner_id=2 where id=214")
    created["edits"].extend(r[0] for r in q(
        "select id from edits where biz_id=214 and status='pending'"))
    q("delete from edits where biz_id=214 and status='pending'")
    created["edits"] = []
    descr_new = "توضیح آزمون دِدوپ فاز ۱۵ — پس از آزمون بازمی‌گردد."
    op = login(SHOP_PHONE)
    st1, b1, u1 = go(op, "/my/business/214", {"descr": descr_new, "name": "کبابی نمونهٔ صحنهٔ نوبت"})
    e1 = q("select id from edits where biz_id=214 and status='pending' order by id desc limit 1")
    eid = e1[0][0] if e1 else None
    if eid: created["edits"].append(eid)
    check("T2.1", "ارسال نخست → صف با یک ردیف pending",
          "بررسی مدیر ثبت شد" in urllib.parse.unquote(u1) and eid is not None, u1[:70])
    # ارسال دومِ همان
    st2, b2, u2 = go(op, "/my/business/214", {"descr": descr_new, "name": "کبابی نمونهٔ صحنهٔ نوبت"})
    n_pending = q("select count(*) from edits where biz_id=214 and status='pending'")[0][0]
    check("T2.2", "ارسال تکراری همان → دِدوپ (باز هم یک ردیف، نه دو)",
          n_pending == 1, f"n={n_pending} url={u2[:70]}")
    # تغییر متفاوت → ردیف دوم
    st3, b3, u3 = go(op, "/my/business/214", {"descr": "دیگرِ آزمون دِدوپ — پاک می‌شود.",
                                              "name": "کبابی نمونهٔ صحنهٔ نوبت"})
    n2 = q("select count(*) from edits where biz_id=214 and status='pending'")[0][0]
    check("T2.3", "تغییر متفاوت → ردیف تازه", n2 == 2, f"n={n2}")
    created["edits"] = [r[0] for r in q("select id from edits where biz_id=214 and status='pending'")]
    # تأیید ردیف اول از پنل → اعمال واقعی
    adm = login(ADMIN_PHONE, admin=True)
    st4, b4, u4 = go(adm, f"/panel/edit/{created['edits'][0]}", {"action": "approve"})
    descr_now = q("select descr from businesses where id=214")[0][0]
    st_row = q("select status from edits where id=?", (created["edits"][0],))[0][0]
    check("T2.4", "تأیید مدیر → اعمال واقعی + وضعیت ردیف",
          "اعمال شد" in urllib.parse.unquote(u4) and descr_new in descr_now
          and st_row in ("applied", "approved"), f"u={u4[:60]} status={st_row}")
    # و ارسال دوبارهٔ همان مقدار → diff خالی، ردیف جدید نه
    st5, b5, u5 = go(op, "/my/business/214", {"descr": descr_now, "name": "کبابی نمونهٔ صحنهٔ نوبت"})
    n3 = q("select count(*) from edits where biz_id=214 and status='pending'")[0][0]
    check("T2.5", "ارسال بی‌تغییر → «تغییری نبود» و ردیفی نه",
          "تغییری نسبت به قبل نبود" in urllib.parse.unquote(u5) and n3 == 1,
          f"n={n3} url={u5[:70]}")

# ─────────────────── T3 رأی helpful — v176: دِدوپ یک‌رأی (لغو حکم v175 با فرمان کاربر) ───────────────────
def t3():
    print("── T3 رأی helpful یک‌تا (v176): تکرار همان رأی‌دهنده no-op، نرخ‌سنج سر جای خودش ──")
    DBM.add_review(214, "مشتری آزمون", 5, "نظر آزمون helpful فاز ۱۵ — حذف می‌شود.",
                   auto_approve=True)
    rid = q("select id from reviews where biz_id=214 and author='مشتری آزمون' "
            "order by id desc limit 1")[0][0]
    created["reviews"].append(rid)
    q("delete from review_votes where review_id=?", (rid,))
    op = sess()
    s1, b1, _ = go(op, "/api/review-helpful", {"id": rid})
    s2, b2, _ = go(op, "/api/review-helpful", {"id": rid})
    import json as _j
    j1, j2 = _j.loads(b1), _j.loads(b2)
    n = q("select helpful from reviews where id=?", (rid,))[0][0]
    check("T3.1", "رأی دوبارهٔ همان کلاینت no-op — شمارنده +۱ می‌ماند (دِدوپ v176)",
          (s1, s2) == (200, 200) and j1["helpful"] == 1 and j2["helpful"] == 1 and n == 1,
          f"j1={j1} j2={j2} n={n}")
    # نرخ‌سنج ۴۰تایی هنوز سرجاست (سقف آسایشِ سوءاستفاده)
    clear = q("delete from ratelimit")
    codes = [go(sess(), "/api/review-helpful", {"id": rid})[0] for _ in range(42)]
    check("T3.2", "نرخ‌سنج rh: در موج ۴۲تایی حداقل یک 429", 429 in codes,
          f"tail={codes[-6:]}")
    q("delete from review_votes where review_id=?", (rid,))

def cleanup():
    for oid in created["orders"]:
        q("delete from orders where id=?", (oid,))     # order_items با CASCADE
    for iid in created["items"]:
        q("delete from items where id=?", (iid,))
    for eid in created["edits"]:
        q("delete from edits where id=?", (eid,))
    for rid in created["reviews"]:
        q("delete from review_scores where review_id=?", (rid,))
        q("delete from reviews where id=?", (rid,))
    for k, v in created["settings"].items():
        if v is None:
            q("delete from settings where key=?", (k,))
        else:
            q("insert or replace into settings(key,value) values(?,?)", (k, v))
    q("update businesses set owner_id=NULL, descr='' where id=214")
    if created.get("biz214_name"):
        q("update businesses set name=? where id=214", (created["biz214_name"],))
    q("delete from notifications where text like '%آزمون%'")
    q("delete from owner_notifications where text like '%آزمون%'")
    q("delete from ratelimit"); q("delete from otp")

def main():
    try:
        t1(); t2(); t3()
    finally:
        cleanup()
    green = sum(1 for r in RESULTS if r["ok"])
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {green} | قرمز: {len(RESULTS)-green}")
    import os
    os.makedirs("qa", exist_ok=True)
    with open("qa/phase15-results.json", "w", encoding="utf-8") as f:
        json.dump(RESULTS, f, ensure_ascii=False, indent=1)
    sys.exit(0 if green == len(RESULTS) else 1)

if __name__ == "__main__":
    main()
