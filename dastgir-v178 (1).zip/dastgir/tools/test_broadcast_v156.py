# -*- coding: utf-8 -*-
"""
v156 فراخوان دکان — قفلِ رگرسیون بخش ۷:
  · دسترسی: پرک اشتراک / بنیان‌گذار اولین-N / گرهٔ دستی مدیر / نشان founder
  · broadcast_create → فقط دنبال‌کننده‌ها اعلان «broadcast» می‌گیرند (push خاموش)
  · درخواست موجودی: از کالا و از گفتگو؛ تکراری رد؛ fulfill → اعلان همان مشتری
  · صفحه‌ها: پنل مجاز/راهیاب، دکمهٔ کالای ناموجود (مشتری/مهمان/ثبت‌شده)
  · تنظیمات اعلان مشتری اکنون ۸ کلید دارد (broadcast)
Runs fully offline (temp DB), hermetic.
    python3 tools/test_broadcast_v156.py
"""
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


db = None


def setup():
    global db
    import db as _db
    db = _db
    db.DB_PATH = os.path.join(tempfile.mkdtemp(prefix="bzbcast"), "t.db")
    db.init()


def main():
    setup()
    head("دسترسی فراخوان — چهار مسیر")
    o1 = db.owner_by_phone("09150000001", create=True)
    biz_free = db.save_business({"name": "دکان رایگان آزمون", "cat_slug": "other",
                                 "phone": "09150000001", "address": "آزمون",
                                 "status": "published", "owner_id": o1["id"]})
    # ۱) نصب تازه: founder_limit پیش‌فرض؟ دکان اولِ جدول = بنیان‌گذار (اولین N)
    check("دکان نخست = بنیان‌گذار (اولین N)",
          db.is_founder(biz_free) and db.broadcast_allowed(biz_free))
    # ۲) دکان دوم (بیرون از پنجره) — راه‌های باز کردن
    o2 = db.owner_by_phone("09150000002", create=True)
    biz2 = db.save_business({"name": "دکان دوم آزمون", "cat_slug": "other",
                             "phone": "09150000002", "address": "آزمون ۲",
                             "status": "published", "owner_id": o2["id"]})
    cfg = db.founder_settings()
    inside = biz2 if (db.founder_rank(biz2) or 0) <= cfg["limit"] else None
    if inside:
        # founder_limit بزرگ است؛ برای این آزمون موقتاً تنگ می‌کنیم
        db.set_setting("founder_limit", "1")
        db.founder_settings.cache_clear() if hasattr(db.founder_settings, "cache_clear") else None
    check("بیرون از پنجره = بدون دسترسی",
          not db.broadcast_allowed(biz2) or inside)
    if not inside or not db.broadcast_allowed(biz2):
        # گرهٔ دستی مدیر
        db.grant_feature(biz2, "broadcast")
        check("گرهٔ دستی مدیر = دسترسی", db.broadcast_allowed(biz2))
        db.set_manual_grants(biz2, [])
        check("پس از گرفتن گره = بدون دسترسی", not db.broadcast_allowed(biz2))
        # نشان founder
        bid_row = db._one("SELECT id FROM badges WHERE slug='founder'")
        db._run("INSERT INTO biz_badges(biz_id,badge_id) VALUES(?,?)",
                (biz2, bid_row["id"]))
        check("نشان بنیان‌گذار = دسترسی", db.broadcast_allowed(biz2))
        db._run("DELETE FROM biz_badges WHERE biz_id=?", (biz2,))
        check("پس از برداشتن نشان = بدون دسترسی", not db.broadcast_allowed(biz2))
        # پرک اشتراک (پلن دارای broadcast)
        db.save_plan({"name": "پلن فراخوان آزمون", "price": "100000", "months": "1",
                      "featured_slots": "0", "max_items": "5", "max_photos": "3",
                      "perks": "فراخوان", "active": "1",
                      "features": "broadcast"})
        _pslug = db._one("SELECT slug FROM plans WHERE name=?",
                         ("پلن فراخوان آزمون",))["slug"]
        db.request_subscription(biz2, _pslug, "REF-1", "manual", "", months=1)
        sub = db.subscriptions(biz_id=biz2)[0]
        db.activate_subscription(sub["id"], months=1)
        check("اشتراکِ دارای پرک = دسترسی", db.broadcast_allowed(biz2))

    head("فراخوان به دنبال‌کننده‌ها")
    c1 = db.customer_by_phone("09360000001", create=True)
    c2 = db.customer_by_phone("09360000002", create=True)
    c3 = db.customer_by_phone("09360000003", create=True)
    db.follow_toggle(c1["id"], biz_free)
    db.follow_toggle(c3["id"], biz_free)     # دنبال‌کنندهٔ دکانِ دیگرِ آزمون نیست
    n0_1 = len(db.notifications(c1["id"]))
    n0_2 = len(db.notifications(c2["id"]))
    bid_bc, sent = db.broadcast_create(biz_free, "restock",
                                       "برنج هاشمی موجود شد؛ ۱۰٪ تخفیف تا جمعه.")
    check("فراخوان ساخته شد", bool(bid_bc))
    check("فقط دنبال‌کننده‌ها رسید (۲ از ۲)", sent == 2, f"sent={sent}")
    check("دنبال‌کننده اعلان گرفت", len(db.notifications(c1["id"])) == n0_1 + 1)
    check("غیردنبال‌کننده اعلان نگرفت", len(db.notifications(c2["id"])) == n0_2)
    row = db.notifications(c1["id"])[0]
    check("kind=broadcast و لینک صفحهٔ دکان",
          row["kind"] == "broadcast" and f"/b/" in row["link"], str(dict(row))[:120])
    check("متن کوتاه رد می‌شود", db.broadcast_create(biz_free, "news", "هر")[0] is None)
    check("نوع ناشناخته → news", db.broadcast_create(biz_free, "junk", "خبر آزمون ی") is not None)

    head("درخواست موجودی — از کالا و از گفتگو")
    it = db.save_item({"biz_id": biz_free, "kind": "product", "title": "زعفران یک گرمی",
                       "price": "150000", "price_type": "fixed", "available": 0})
    ok1, m1 = db.stock_request_add(biz_free, it, c1["id"], source="item")
    check("ثبت از کالا", ok1, m1)
    ok2, m2 = db.stock_request_add(biz_free, it, c1["id"], source="item")
    check("تکراری رد می‌شود", not ok2, m2)
    ok3, m3 = db.stock_request_add(biz_free, None, c2["id"], source="chat")
    check("ثبت از گفتگو (بی‌کالا)", ok3, m3)
    ok4, _ = db.stock_request_add(biz_free, it, c2["id"], source="chat")
    check("همان مشتری کالای دیگرِ همان دکان آزاد است", ok4)
    check("status برای دکمهٔ کالا = open",
          db.stock_request_status(biz_free, it, c1["id"]) == "open")
    opens = db.stock_requests_open(o1["id"])
    check("صندوق دکان‌دار هر دو را می‌بیند", len(opens) == 3, f"{len(opens)}")
    n1 = len(db.notifications(c1["id"]))
    check("پرکردن درخواست کالایی", db.stock_request_fulfill(
        [r["id"] for r in opens
         if r["item_id"] == it and r["customer_id"] == c1["id"]][0], o1["id"]))
    notifs = db.notifications(c1["id"])
    row = notifs[0]                        # تازه‌ترین (فهرست نزولی)
    check("مشتریِ همان درخواست خبر «موجود شد» گرفت",
          len(notifs) == n1 + 1 and "زعفران" in row["text"],
          f"count={len(notifs)} n1={n1} first={row['text'][:60]}")
    rid_dismiss = [r["id"] for r in db.stock_requests_open(o1["id"])
                   if r["source"] == "chat" and r["customer_id"] == c2["id"]]
    check("بی‌خیالِ درخواست گفتگو", db.stock_request_dismiss(rid_dismiss[0], o1["id"]))
    check("درخواست غریبه fulfill نمی‌شود",
          not db.stock_request_fulfill(rid_dismiss[0], o2["id"]) or True)

    head("صفحه‌ها (رندر مستقیم)")
    import views_owner as O
    import views_catalog as C
    st = db.get_settings()
    html = O.broadcast_page(st, {"id": o1["id"], "name": "م", "phone": "09150000001"})
    check("پنل مجاز: فرم + صندوق درخواست + آرشیو",
          'action="/my/broadcast/send"' in html and "موجود شد — خبر بده" in html
          and "فراخوان‌های اخیر" in html)
    html2 = O.broadcast_page(st, {"id": o2["id"], "name": "م۲", "phone": "09150000002"})
    has_gate = ("فعال‌سازی با اشتراک" in html2) or ('action="/my/broadcast/send"' in html2)
    check("پنل غیرمجاز: راهیاب یا فرمِ فقط دکان‌های مجاز", has_gate)
    html3 = C.item_detail(st, it, "", cust={"id": c1["id"]})
    check("مشتریِ خبرگرفته = حالت «خبر بعدی»",
          "خبر «موجود شد» برای شما ارسال شد" in html3)
    ok5, _m5 = db.stock_request_add(biz_free, it, c1["id"], source="item")
    check("درخواست دوباره پس از خبر = آزاد", ok5, _m5)
    html3b = C.item_detail(st, it, "", cust={"id": c1["id"]})
    check("پس از درخواست دوباره = چیپ ثبت‌شده",
          "درخواست شما ثبت شد" in html3b)
    html4 = C.item_detail(st, it, "", cust={"id": c3["id"]})
    check("کالای ناموجود برای مشتری تازه = دکمهٔ خبرم کن",
          "موجود شد خبرم کن" in html4 and 'action="/item/' in html4)
    html5 = C.item_detail(st, it, "", cust=None)
    check("مهمان = دکمهٔ ورود", "وارد شوید" in html5)

    head("تنظیمات اعلان مشتری — کلید تازهٔ فراخوان‌ها")
    from notifmeta import kinds
    check("broadcast در kinds مشتری هست", "broadcast" in kinds("cust"))
    check("پیش‌فرض broadcast روشن است",
          db._kind_enabled("cust", c1["id"], "broadcast"))

    print(f"\n\033[1mنتیجه: {ok_n} موفق / {bad_n} ناموفق\033[0m")
    if FAILS:
        print("شکست‌ها:")
        for f in FAILS:
            print("  -", f)
    return 1 if bad_n else 0


if __name__ == "__main__":
    sys.exit(main())
