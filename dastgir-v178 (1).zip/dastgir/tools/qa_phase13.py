#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۱۳ — سیستم (۳): گزارش فعالیت‌ها · ترافیک و سپر · آمار بازدید.
فیلتر/خروجی audit، مسدودی و برداشتن مسدودی سپر، ثبت بازدید واقعی و خروجی CSV.
هر تست اثر واقعی را در پایگاه/صفحه بررسی می‌کند و تمیزکاری برمی‌گرداند."""
import re, sys, json, sqlite3, time, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []
ADMIN_PHONE = "09131110011"
SHOP_PHONE = "09352223344"

def q(sql, args=()):
    """نوشتن/خواندن با بسته‌شدنِ امن و تلاشِ مجدد — قفلِ گذرای WAL دور خزشِ
    seed/پاک‌سازی گاه تا ~۲۰ ثانیه می‌ماند؛ باتری باید صبور باشد نه شکننده."""
    import time as _t
    last = None
    for attempt in range(6):
        c = sqlite3.connect(DB, timeout=20)
        try:
            r = c.execute(sql, args).fetchall(); c.commit(); return r
        except sqlite3.OperationalError as e:
            if "locked" not in str(e) and "busy" not in str(e):
                raise
            last = e; _t.sleep(3 + attempt * 2)
        finally:
            c.close()   # حتی هنگام خطا — اتصالِ باز با تراکنشِ نوشتن، خودِ باتری را قفل می‌کند
    raise last

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None, headers=None):
    h = dict(headers or {})
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data, doseq=True).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(BASE + path, data=body, headers=h)
    try:
        r = op.open(req, timeout=25)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def clear_rl():
    q("delete from ratelimit")

def login(phone, admin=False):
    clear_rl()
    op = sess()
    go(op, "/login")
    go(op, "/login", {"phone": phone})
    go(op, "/login/verify", {"phone": phone, "code": otp_code(phone)})
    if admin:
        go(op, "/panel?key=" + DBM.owner_token())
    return op

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

created = {"audit_rows": []}

# ─────────────────── T1 گزارش فعالیت‌ها (audit) ───────────────────
def t1():
    print("── T1 گزارش فعالیت‌ها (فیلتر، خروجی CSV، صفحه‌بندی)")
    op = login(ADMIN_PHONE, admin=True)
    st, b, _ = go(op, "/panel/audit")
    check("T1.1", "صفحهٔ audit 200 با عنوان", st == 200 and "گزارش فعالیت‌ها" in b)
    # یک کنش واقعی ثبت‌شده: ذخیرهٔ «کلید قابلیت‌ها» با همان مقادیر فعلی
    # (بی‌اثر بر وضعیت ولی در audit ثبت می‌شود — demo.clear بی‌ضرر نیست!)
    # کلیدها = کامل whitelist پنل (شامل ۴ کلید بی‌پسوند؛ وگرنه خاموش می‌شدند)
    sys.path.insert(0, "server")
    import views_panel2 as _P2
    keys = [k for _t, items in _P2.SITE_FEATURES for k, *_ in items]
    cur = {k: (q("select value from settings where key=?", (k,))[0][0] or "0")
           for k in keys}
    st, b, url = go(op, "/panel/features", cur)
    n = q("select count(*) from audit where action='features.save'")[0][0]
    check("T1.2", "کنش واقعی در جدول audit ثبت شد", st == 200 and n >= 1, f"n={n} url={url[:60]}")
    created["audit_rows"].append("features.save")
    # ردیف در صفحه دیده شود (بالای فهرست)
    st, b, _ = go(op, "/panel/audit")
    check("T1.3", "ردیف تازه در صفحهٔ audit", "features.save" in b)
    # فیلتر action — فقط ردیف‌های features.save (صفحهٔ ۱ سطر ۵۰ می‌دهد)
    n_all = q("select count(*) from audit where action='features.save'")[0][0]
    st, b, _ = go(op, "/panel/audit?action=features.save")
    check("T1.4", "فیلتر action فقط همان رویداد",
          st == 200 and b.count("<code>") == min(n_all, 50),
          f"n={n_all} tags={b.count('<code>')}")
    # فیلتر جست‌وجوی جزئیات — detail قالبِ «N/M on» است
    st, b, _ = go(op, "/panel/audit?detail=on")
    check("T1.5", "فیلتر جزئیات (N/M on)", "features.save" in b and "on" in b)
    # فیلتر روز — features.save امروز است پس در ۷ روز می‌آید
    st, b, _ = go(op, "/panel/audit?days=7")
    check("T1.6", "فیلتر ۷ روز شامل ردیف امروز", "features.save" in b)
    # خروجی CSV با همان فیلتر
    st, b, _ = go(op, "/panel/audit/export?action=features.save")
    check("T1.7", "خروجی CSV فیلتری (BOM + ستون‌ها + ردیف)",
          st == 200 and b.startswith("\ufeff") and "id,action,detail,created" in b
          and "features.save" in b, f"st={st}")
    # صفحه‌بندی وحشی — 200 بدون کرش
    st, b, _ = go(op, "/panel/audit?page=999")
    check("T1.8", "صفحهٔ دور (page=999) بدون کرش", st == 200)
    # دکاندار
    sop = login(SHOP_PHONE)
    g1 = go(sop, "/panel/audit")[0]
    g2 = go(sop, "/panel/audit/export")[0]
    check("T1.9", "دکاندار 403×2", (g1, g2) == (403, 403), str((g1, g2)))

# ─────────────────── T2 ترافیک و سپر ───────────────────
def t2():
    print("── T2 ترافیک و سپر (اسکنر، مسدودی، برداشتن مسدودی)")
    op = login(ADMIN_PHONE, admin=True)
    st, b, _ = go(op, "/panel/traffic")
    check("T2.1", "صفحهٔ ترافیک 200 با کاشی‌ها", st == 200 and "سپر ضد-اسپم" in b
          and "کل درخواست‌ها" in b)
    # شبیه‌سازی اسکنر دورستد: 3 ضربهٔ /.env با XFF → مسدودی ۳۰ دقیقه‌ای
    # (شناسهٔ تازه در هر اجرا — ضربه‌ها ۶۰ ثانیه در حافظه می‌مانند)
    ident = f"10.99.{77 + int(time.time()) % 20}.{5 + int(time.time()) % 40}"
    codes = []
    for _ in range(3):
        st_, b_, _u = go(sess(), "/.env", headers={"X-Forwarded-For": ident})
        codes.append(st_)
    st_hit, b_hit, _u = go(sess(), "/", headers={"X-Forwarded-For": ident})
    check("T2.2", "۳ ضربهٔ اسکنر → مسدودی (درخواست بعدی 403)",
          codes == [404, 404, 404] and st_hit == 403, f"scan={codes} hit={st_hit}")
    # مسدود در گزارش زنده دیده شود (جدول مسدودها + رویداد /.env)
    st, b, _ = go(op, "/panel/traffic")
    check("T2.3", "مسدود در گزارش + رویداد اسکنر",
          ident in b and "/.env" in b, "")
    # برداشتن مسدودی
    st, b, url = go(op, "/panel/traffic/unblock", {"ident": ident})
    st_after, _b2, _u2 = go(sess(), "/", headers={"X-Forwarded-For": ident})
    check("T2.4", "برداشتن مسدودی واقعی بود (بعدش 200)",
          "مسدودی برداشته شد" in urllib.parse.unquote(url) and st_after == 200,
          f"after={st_after}")
    n_log = q("select count(*) from audit where action='shield.unblock' and detail like ?",
              (f"%{ident}%",))[0][0]
    check("T2.5", "برداشتن مسدودی در audit ثبت شد", n_log >= 1)
    # #36: برداشتن مسدودیِ ناموجود → پیام صادقانه، نه «موفقیت» جعلی
    st, b, url = go(op, "/panel/traffic/unblock", {"ident": "10.99.77.99"})
    check("T2.6", "#36 وحشی → «در حال حاضر مسدود نیست»",
          "مسدود نیست" in urllib.parse.unquote(url), url)
    # دکاندار
    sop = login(SHOP_PHONE)
    g1 = go(sop, "/panel/traffic")[0]
    g2 = go(sop, "/panel/traffic/unblock", {"ident": ident})[0]
    check("T2.7", "دکاندار 403×2", (g1, g2) == (403, 403), str((g1, g2)))

# ─────────────────── T3 آمار بازدید ───────────────────
def t3():
    print("── T3 آمار بازدید (ثبت واقعی، بات، خروجی CSV)")
    op = login(ADMIN_PHONE, admin=True)
    st, b, _ = go(op, "/panel/analytics")
    check("T3.1", "صفحهٔ آمار 200 با کاشی‌ها و نمودار",
          st == 200 and "آمار بازدید" in b and "بازدید ۲۴ ساعت" in b)
    # بازدید واقعی: GET تازهٔ خانه با UA مرورگری → یک سطر visits واقعی (bot=0)
    UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36"
    before = q("select count(*) from visits where bot=0")[0][0]
    go(sess(), "/", headers={"User-Agent": UA})
    time.sleep(0.3)
    after = q("select count(*) from visits where bot=0")[0][0]
    check("T3.2", "GET خانه → سطر بازدید واقعی ثبت شد", after == before + 1,
          f"{before}→{after}")
    last = q("select path,kind,dev,bot from visits order by id desc limit 1")[0]
    check("T3.3", "سطر تازه: مسیر/نوع/دستگاه + bot=0",
          last[0] == "/" and last[1] == "home" and last[2] == "mobile" and last[3] == 0,
          str(tuple(last)))
    # بازدیدکنندهٔ واقعی در جدول صفحه‌های پربازدید آمده باشد
    st, b, _ = go(op, "/panel/analytics")
    check("T3.4", "جدول پربازدیدها رندر شد", "صفحه‌های پربازدید" in b and "<table" in b)
    # خروجی CSV (متغیر جدا — b صفحهٔ آمار باید برای T3.6 سالم بماند)
    st, csv_raw, _ = go(op, "/panel/analytics/export")
    check("T3.5", "خروجی CSV بازدیدها (سرستون + سطر)",
          st == 200 and "ts_utc,path,kind" in csv_raw, f"st={st}")
    # هر دو نشان (واقعی از بازدید تازهٔ ما، بات از خزنده‌ها) رندر شده‌اند
    check("T3.6", "نشان واقعی/بات هر دو در جدول آخرین بازدیدها",
          "واقعی" in b and "بات" in b)
    # دکاندار
    sop = login(SHOP_PHONE)
    g1 = go(sop, "/panel/analytics")[0]
    g2 = go(sop, "/panel/analytics/export")[0]
    check("T3.7", "دکاندار 403×2", (g1, g2) == (403, 403), str((g1, g2)))

def main():
    t1(); t2(); t3()
    green = sum(1 for r in RESULTS if r["ok"])
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {green} | قرمز: {len(RESULTS)-green}")
    import os
    os.makedirs("qa", exist_ok=True)
    with open("qa/phase13-results.json", "w", encoding="utf-8") as f:
        json.dump(RESULTS, f, ensure_ascii=False, indent=1)
    sys.exit(0 if green == len(RESULTS) else 1)

if __name__ == "__main__":
    main()
