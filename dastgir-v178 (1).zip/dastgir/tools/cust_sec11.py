# -*- coding: utf-8 -*-
"""بخش ۱۱ — حساب و داده: /me/account، خروجی داده (CSV)، PWA: manifest + سرویس‌ورکر + آفلاین."""
import sys, sqlite3, json, time
sys.path.insert(0, 'tools')
from cust_lib import *
from playwright.sync_api import sync_playwright

recs = []
log = print


def login(br, phone):
    c = sqlite3.connect(DB)
    c.execute("delete from otp"); c.execute("delete from ratelimit"); c.commit()
    u = ctx(br); pg = u.new_page()
    pg.on('dialog', lambda d: d.accept())
    pg.goto(BASE + '/login')
    pg.fill('form[action="/login"] input[name="phone"]', phone)
    pg.click('form[action="/login"] button[type="submit"]', no_wait_after=True)
    pg.wait_for_selector('input[name="code"]')
    pg.fill('input[name="code"]', otp_code(phone))
    try:
        pg.click('form[action="/login/verify"] button[type="submit"]', no_wait_after=True, timeout=6000)
    except Exception:
        pass
    try:
        pg.wait_for_url('**/my', timeout=8000)
    except Exception:
        try:
            pg.evaluate("document.querySelector('form[action=\\'/login/verify\\']').submit()")
        except Exception:
            pass
        pg.wait_for_url('**/my', timeout=20000)
    return u, pg


with sync_playwright() as pw:
    br = pw.chromium.launch()
    u, pg = login(br, '09361112233')

    # ── 11.1 حساب ──
    r = audit(pg, 'sec11-account', '/me/account')
    recs.append(r); log(fmt(r))

    # ── 11.2 خروجی داده ──
    with pg.expect_download(timeout=15000) as dl_info:
        pg.evaluate("location.href='/me/export'")
    dl = dl_info.value
    path = f'/tmp/export-{dl.suggested_filename}'
    dl.save_as(path)
    import os
    size = os.path.getsize(path)
    head = open(path, encoding='utf-8', errors='replace').read(400)
    csv_ok = size > 100 and (',' in head or '\ufeff' in head)
    r = {'name': 'sec11-export', 'url': '/me/export', 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0,
         'extra': f'خروجی داده: {dl.suggested_filename} ({size} بایت) CSV سالم: {csv_ok}'}
    recs.append(r); log(('✅' if csv_ok else '❌'), 'sec11-export |', r['extra'])

    # ── 11.3 manifest ──
    resp = u.request.get(BASE + '/manifest.webmanifest')
    man = resp.json() if resp.status == 200 else {}
    pwa_ok = bool(man.get('name') or man.get('short_name')) and bool(man.get('icons'))
    r = {'name': 'sec11-manifest', 'url': '/manifest.webmanifest', 'status': resp.status,
         'console_errors': [], 'overflow_px': 0, 'touch': {'block': 0},
         'small_text': {'count': 0}, 'broken_images': [], 'ms': 0,
         'extra': f'manifest: name={man.get("name","?")!r} آیکون‌ها={len(man.get("icons",[]))} سالم: {pwa_ok}'}
    recs.append(r); log(('✅' if pwa_ok else '❌'), 'sec11-manifest |', r['extra'])

    # ── 11.4 سرویس‌ورکر + نسخه ──
    pg.goto(BASE + '/sw.js')
    sw = pg.content()
    sw_ok = 'bazarche-v175' in sw or 'v175' in sw
    r = {'name': 'sec11-sw', 'url': '/sw.js', 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0,
         'extra': f'sw.js نسخهٔ v175: {sw_ok}'}
    recs.append(r); log(('✅' if sw_ok else '❌'), 'sec11-sw |', r['extra'])

    # ثبت واقعی SW در مرورگر + یک reload تا صفحه تحت کنترل SW برود
    pg.goto(BASE + '/'); pg.wait_for_load_state('networkidle')
    reg = None
    try:
        reg = pg.evaluate("navigator.serviceWorker.register('/sw.js').then(r=>!!r).catch(e=>String(e).slice(0,60))")
        pg.wait_for_timeout(2500)
        reg = pg.evaluate("navigator.serviceWorker.ready.then(r=>!!r.active).catch(e=>String(e).slice(0,60))")
        pg.reload(); pg.wait_for_load_state('networkidle'); pg.wait_for_timeout(800)
    except Exception as e:
        reg = f'خطا: {e}'[:60]
    r = {'name': 'sec11-sw-register', 'url': '/', 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0, 'extra': f'ثبت سرویس‌ورکر فعال: {reg}'}
    recs.append(r); log('ℹ️/✅ sec11-sw-register |', r['extra'])

    # ── 11.5 آفلاین: باز کردن صفحهٔ کش‌شده بدون شبکه ──
    offline_ok = None
    try:
        u.set_offline(True)
        try:
            pg.goto(BASE + '/', wait_until='domcontentloaded', timeout=20000)
            pg.wait_for_timeout(1200)
            _t = pg.inner_text('body')
            cached = ('دست گیر' in _t) and len(_t) > 100
            shell = 'اتصال اینترنت برقرار نیست' in _t
            offline_ok = cached or shell
            offline_ok = f'{"کش کامل" if cached else "صفحهٔ آفلاین اختصاصی"}' if offline_ok else f'متن: {_t[:60]!r}'
        except Exception as e:
            offline_ok = f'خطای ناوبری: {str(e)[:70]}'
        pg.screenshot(path=f'{SHOTS}/sec11-offline.png')
    except Exception as e:
        offline_ok = f'خطا: {str(e)[:60]}'
    finally:
        u.set_offline(False)
    r = {'name': 'sec11-offline', 'url': '/ (آفلاین)', 'status': 200, 'console_errors': [],
         'overflow_px': 0, 'touch': {'block': 0}, 'small_text': {'count': 0},
         'broken_images': [], 'ms': 0, 'extra': f'صفحهٔ خانه در حالت آفلاین رندر شد: {offline_ok}'}
    recs.append(r); log(('✅' if offline_ok is True else '⚠️'), 'sec11-offline |', r['extra'])

    u.close(); br.close()

save(recs, '11-حساب/PWA')
reds = [r for r in recs if 'False' in str(r.get('extra', ''))]
print(f"\n── بخش ۱۱: {len(recs)} سنج | قرمز: {len(reds)}")
