#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""سازندهٔ لوگوی «دست گیر» — نشانِ دو دستِ به‌هم‌رسیده، تک‌رنگِ رسمی.

فرمان کاربر (v178، بخش ۲): لوکس و رسمی · نقش‌مایهٔ دو دست که به هم می‌رسند
(دست‌گیری و یاری) · تک‌رنگ مشکی/ذغالی + آبی برند · نشان + واژه‌نگاشت «دست گیر»
با فونت هندسی مدرن · قلمرو فقط فایل‌های لوگو.

رنگ‌ها همه از tokens.css گرفته شده‌اند و هیچ رنگ تازه‌ای اضافه نمی‌شود:
  INK    = gray-900   #0f172a   (جوهر زغالی)
  BRAND  = brand-700  #0b6059   (آبی/فیروزهٔ برند)
  BRAND3/4 = برای زمینهٔ تیره (کنتراست لازم روی ذغال و روی کاشی برند)
بدون گرادیان رنگی، بدون درخشش، بدون بافت و بدون شیشه (قانون ۷).

خروجی‌ها:
  site/assets/img/logo.svg            — نشان برای زمینهٔ روشن
  site/assets/img/logo-mark.svg       — نشان برای کاشی برندِ هدر (نوک‌سفید)
  site/assets/img/favicon.svg         — کاشی ذغالیِ تخت + نشان
  site/assets/img/logo-lockup.svg     — نشان + واژه‌نگاشت «دست گیر» (RTL)
  site/assets/img/icons/app-192.png   — آیکون PWA و apple-touch-icon
  site/assets/img/icons/app-512.png
  site/assets/img/icons/maskable-512.png — تمام‌صفحه با محتوای داخل ناحیهٔ امن

واژه‌نگاشت از خودِ فونت سایت ساخته می‌شود (Vazirmatn Variable، وزن ۶۰۰):
HarfBuzz متن «دست گیر» را شکل می‌دهد و fontTools خروجی را به مسیرِ برداری
تبدیل می‌کند؛ پس فایل به هیچ فونتی وابسته نیست و در چاپ هم همان است.

نیازمندی ساخت آیکون/پیش‌نمایش:  pip install cairosvg fonttools uharfbuzz brotli
اجرا:  python3 tools/build_logo.py            (خروجی‌ها + پیش‌نمایش در /tmp)
"""

import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
IMG = os.path.join(ROOT, "site", "assets", "img")
ICONS = os.path.join(IMG, "icons")
FONT = os.path.join(ROOT, "site", "assets", "fonts", "Vazirmatn-Variable.woff2")
TTF = "/tmp/Vazirmatn-600.ttf"
PREVIEW = "/tmp/logo-preview"

# ── پالت (از tokens.css) ────────────────────────────────────────────────
INK = "#0f172a"        # gray-900: جوهر زغالی
BRAND = "#0b6059"      # brand-700: آبی/فیروزهٔ برند
BRAND3 = "#5eead4"     # brand-300: برای کاشی برندِ هدر
BRAND4 = "#2dd4bf"     # brand-400: برای کاشی ذغالیِ آیکون
WHITE = "#ffffff"
TILE_DARK = "#0f172a"  # همان جوهر؛ کاشی تخت آیکون

# ── هندسهٔ نشان (شبکهٔ ۶۴×۶۴، قرینه دربارهٔ x=32) ─────────────────────
# هر دست از چهار جزء هم‌رنگ ساخته می‌شود تا در همهٔ اندازه‌ها «دست» بماند:
#   ۱) کف دست: شکل پُر (مچ باریک‌تر، بند انگشتان پهن‌تر، گوشه‌های گرد)
#   ۲) چهار انگشت: خط‌های ضخیم با نوک گرد که از داخل کف بیرون می‌زنند
#      (در اندازهٔ کوچک در هم می‌آمیزند و یک دستکشِ لبه‌دار می‌سازند)
#   ۳) شست: خط ضخیم با نوک گرد که از لبهٔ داخل به سمت دستِ دیگر می‌رود؛
#      نوک دو شست در مرکز به هم می‌رسد (لحظهٔ دست‌گیری)
#   ۴) سرآستین: نوار رنگی روی مچ (رنگ برند؛ جزئیات رسمی)
# دو کف دست با یک کانال فضای منفی از هم جدا می‌مانند.
CX = 32.0
MIRROR = 'translate(64 0) scale(-1 1)'
FINGER_W = 3.05
THUMB_W = 4.9
CUFF_W = 3.2

# کف دست: کوتاه و باریک‌تر تا انگشتان بلند، تناسلِ رسمی بدهند
PALM = ("M16.9 47.6 C16.3 43.4 15.8 37.6 16.0 32.4 Q16.1 29.9 18.6 29.9 "
        "L26.2 29.9 Q28.7 29.9 28.5 32.6 C28.3 37.6 27.7 43.4 26.9 47.6 "
        "Q21.9 49.8 16.9 47.6 Z")
# انگشتان بلندتر؛ دو انگشت میانی بلندتر از کناری‌ها (دست طبیعی)
FINGERS = [((17.3, 30.4), (16.7, 20.1)),
           ((20.3, 29.9), (20.2, 17.6)),
           ((23.3, 29.9), (23.6, 18.1)),
           ((26.1, 30.4), (26.8, 20.4))]
# شست: از بالای لبهٔ داخل، مورب به بالا و مرکز؛ پلِ دست‌دادن زیر خط انگشتان
THUMB = ((27.0, 34.6), (33.4, 29.2))
CUFF = ((16.2, 42.9), (27.6, 42.6))
TILT_DEG = -3.5
TILT_AT = (22.2, 39.0)


def _line(a, b, w, color, cap="round"):
    (x0, y0), (x1, y1) = a, b
    return (f'<path d="M{x0:.2f} {y0:.2f} L{x1:.2f} {y1:.2f}" fill="none" '
            f'stroke="{color}" stroke-width="{w}" stroke-linecap="{cap}"/>')


def mark_svg(hand_color, cuff_color, finger_w=FINGER_W, thumb_w=THUMB_W,
             cuff_w=CUFF_W):
    """گروهِ نشان (بدون پس‌زمینه) برای viewBox 0 0 64 64."""
    one = (f'<path d="{PALM}" fill="{hand_color}"/>'
           + "".join(_line(a, b, finger_w, hand_color) for a, b in FINGERS)
           + _line(*THUMB, thumb_w, hand_color)
           + _line(*CUFF, cuff_w, cuff_color))
    tilted = (f'<g transform="rotate({TILT_DEG} {TILT_AT[0]} {TILT_AT[1]})">'
              f'{one}</g>')
    return f'{tilted}<g transform="{MIRROR}">{tilted}</g>'


def svg(doc_inner, size=64, viewBox="0 0 64 64", label="نشان دست گیر"):
    dim = f'width="{size}" height="{size}" ' if size else ""
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{viewBox}" '
        f'{dim}role="img" aria-label="{label}">'
        f'{doc_inner}</svg>'
    )


# ── واژه‌نگاشت «دست گیر» از خودِ فونت سایت ──────────────────────────────
def wordmark_paths(text="دست گیر", weight=600):
    """(path_data, bbox, advance_total) در واحدِ فونت، y به بالا."""
    from fontTools.ttLib import TTFont
    from fontTools.varLib.instancer import instantiateVariableFont
    from fontTools.pens.svgPathPen import SVGPathPen
    from fontTools.pens.boundsPen import BoundsPen
    import uharfbuzz

    if not os.path.exists(TTF):
        f0 = TTFont(FONT)
        instantiateVariableFont(f0, {"wght": weight}, inplace=True)
        f0.flavor = None
        f0.save(TTF)
    f = TTFont(TTF)
    upem = f["head"].unitsPerEm
    blob = uharfbuzz.Blob.from_file_path(TTF)
    font = uharfbuzz.Font(uharfbuzz.Face(blob))
    font.scale = (upem, upem)
    buf = uharfbuzz.Buffer()
    buf.add_str(text)
    buf.guess_segment_properties()
    uharfbuzz.shape(font, buf)

    gset = f.getGlyphSet()
    parts, x = [], 0.0
    bb = [1e9, 1e9, -1e9, -1e9]
    for info, pos in zip(buf.glyph_infos, buf.glyph_positions):
        name = f.getGlyphName(info.codepoint)
        gx = x + pos.x_offset
        gy = pos.y_offset
        x += pos.x_advance
        pen = SVGPathPen(gset)
        gset[name].draw(pen)
        d = pen.getCommands()
        if not d:
            continue
        bounds = BoundsPen(gset)
        gset[name].draw(bounds)
        if bounds.bounds:
            x0, y0, x1, y1 = bounds.bounds
            bb = [min(bb[0], gx + x0), min(bb[1], gy + y0),
                  max(bb[2], gx + x1), max(bb[3], gy + y1)]
        parts.append((gx, gy, d))
    return parts, bb, x, upem


def wordmark_svg(scale, dx, dy, color):
    """مسیرِ واژه‌نگاشت را در دستگاه مختصاتِ مقصد می‌نشاند (y معکوس)."""
    parts, bb, _adv, _upem = wordmark_paths()
    out = []
    for gx, gy, d in parts:
        out.append(
            f'<path transform="translate({dx + gx * scale:.3f} {dy - gy * scale:.3f}) '
            f'scale({scale:.6f} {-scale:.6f})" d="{d}" fill="{color}"/>'
        )
    w = (bb[2] - bb[0]) * scale
    h = (bb[3] - bb[1]) * scale
    return "".join(out), w, h, bb


def build_lockup(mark_color=INK, cuff_color=BRAND, text_color=INK,
                 mark_size=58, text_h=31.0, gapmw=12, pad=4, weight=700):
    """قفل‌نمایش RTL: نشان سمت راست (آغاز خوانش)، واژهٔ «دست گیر» سمت چپ."""
    parts, bb, _adv, upem = wordmark_paths(weight=weight)
    scale = text_h / (bb[3] - bb[1])
    text_w = (bb[2] - bb[0]) * scale
    W = pad + text_w + gapmw + mark_size + pad
    H = mark_size + 2 * pad
    text_x = pad - bb[0] * scale
    text_y = pad + mark_size / 2 + ((bb[3] + bb[1]) / 2) * scale
    text_paths, w, h, _ = wordmark_svg(scale, text_x, text_y, text_color)
    mark_x = pad + text_w + gapmw
    inner = (f'<g transform="translate({mark_x:.2f} {pad}) '
             f'scale({mark_size / 64:.4f})">{mark_svg(mark_color, cuff_color)}</g>'
             f'{text_paths}')
    return (svg(inner, size=None, viewBox=f"0 0 {W:.2f} {H:.2f}",
                label="دست گیر"), W, H)


# ── نوشتن فایل‌ها ───────────────────────────────────────────────────────
def write(path, text):
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    print(f"  ✓ {os.path.relpath(path, ROOT)}  ({len(text.encode('utf-8'))} بایت)")


def build_svgs():
    print("ساخت SVGها:")
    # ۱) زمینهٔ روشن: دست‌ها جوهر، سرآستین برند
    write(os.path.join(IMG, "logo.svg"),
          svg(mark_svg(INK, BRAND)))
    # ۲) کاشی برندِ هدر (گرادیان brand-600→brand-800 در CSS): نوک‌سفید
    write(os.path.join(IMG, "logo-mark.svg"),
          svg(mark_svg(WHITE, BRAND3)))
    # ۳) فاویکون/آیکون: کاشی ذغالیِ تخت (بدون گرادیان) + نشان سفید + سرآستین brand-400
    tile = f'<rect width="64" height="64" rx="14" fill="{TILE_DARK}"/>'
    write(os.path.join(IMG, "favicon.svg"), svg(tile + mark_svg(WHITE, BRAND4)))
    # ۴) قفل‌نمایش
    lock, W, H = build_lockup()
    write(os.path.join(IMG, "logo-lockup.svg"), lock)
    return lock


def build_pngs():
    import cairosvg
    os.makedirs(ICONS, exist_ok=True)
    print("ساخت آیکون‌های PNG:")
    tile = f'<rect width="64" height="64" fill="{TILE_DARK}"/>'
    # آیکون «any»: کاشی با گوشهٔ گرد (اندروید/iOS خودش گرد می‌کند، ولی لبهٔ
    # تمیز می‌ماند). محتوا ۸۶٪ تا داخلِ کامل جا شود.
    def icon_src(corner, scale, bleed=False):
        pad = (64 - 64 * scale) / 2
        g = (f'<g transform="translate({pad:.2f} {pad:.2f}) scale({scale})">'
             f'{mark_svg(WHITE, BRAND4)}</g>')
        rect = (f'<rect width="64" height="64" rx="{corner}" fill="{TILE_DARK}"/>'
                if not bleed else f'<rect width="64" height="64" fill="{TILE_DARK}"/>')
        return svg(rect + g)

    jobs = [
        ("app-192.png", icon_src(14, 0.86), 192),
        ("app-512.png", icon_src(14, 0.86), 512),
        # maskable: تمام‌صفحه + محتوا در ۶۲٪ (ناحیهٔ امنِ دایرهٔ ۸۰٪)
        ("maskable-512.png", icon_src(0, 0.62, bleed=True), 512),
    ]
    for name, src, size in jobs:
        out = os.path.join(ICONS, name)
        cairosvg.svg2png(bytestring=src.encode("utf-8"), write_to=out,
                         output_width=size, output_height=size)
        print(f"  ✓ site/assets/img/icons/{name}  ({os.path.getsize(out)} بایت، {size}×{size})")


def build_previews():
    """شیتِ تماس برای داوری چشمی: اندازه‌های واقعی روی روشن و تیره."""
    import cairosvg
    from PIL import Image
    import io
    os.makedirs(PREVIEW, exist_ok=True)
    sizes = [512, 192, 96, 64, 40, 26, 23, 16]
    variants = {
        "on-light": (svg(mark_svg(INK, BRAND)), "#ffffff"),
        "on-tile": (svg(mark_svg(WHITE, BRAND3)), "#0f766e"),
        "on-dark": (svg(mark_svg(WHITE, BRAND4)), TILE_DARK),
        "favicon": (open(os.path.join(IMG, "favicon.svg"), encoding="utf-8").read(), "#ffffff"),
    }
    made = []
    for vname, (src, bg) in variants.items():
        for s in sizes:
            png = cairosvg.svg2png(bytestring=src.encode("utf-8"),
                                   output_width=s, output_height=s,
                                   background_color=bg)
            p = os.path.join(PREVIEW, f"{vname}-{s}.png")
            open(p, "wb").write(png)
            made.append((p, s, bg))
    # یک شیتِ تماس
    cols, rows = len(sizes), len(variants)
    cell = 132
    sheet = Image.new("RGB", (cols * cell + 20, rows * cell + 20), "#ffffff")
    from PIL import ImageDraw
    dr = ImageDraw.Draw(sheet)
    for r, (vname, (_src, bg)) in enumerate(variants.items()):
        for c, s in enumerate(sizes):
            im = Image.open(os.path.join(PREVIEW, f"{vname}-{s}.png")).convert("RGBA")
            box = Image.new("RGBA", (cell - 12, cell - 12), bg)
            im.thumbnail((cell - 20, cell - 20), Image.LANCZOS)
            box.paste(im, ((box.width - im.width) // 2, (box.height - im.height) // 2), im)
            sheet.paste(box, (10 + c * cell + 6, 10 + r * cell + 6), box)
            dr.text((12 + c * cell, 4 + r * cell), f"{s}px", fill="#333333")
        dr.text((cols * cell - 60, 6 + r * cell + cell // 2), vname, fill="#333333")
    sheet_path = os.path.join(PREVIEW, "contact-sheet.png")
    sheet.save(sheet_path)
    # قفل‌نمایش هم روی زمینهٔ روشن/تیره
    for tag, bg, kw in (("light", "#ffffff", {}),
                        ("dark", TILE_DARK, dict(mark_color=WHITE,
                                                 cuff_color=BRAND3,
                                                 text_color=WHITE))):
        lock, _W, _H = build_lockup(**kw)
        p = os.path.join(PREVIEW, f"lockup-{tag}.png")
        cairosvg.svg2png(bytestring=lock.encode("utf-8"), write_to=p,
                         output_width=1040, background_color=bg)
    print(f"  ✓ پیش‌نمایش‌ها: {sheet_path} + {PREVIEW}/lockup-{{light,dark}}.png")
    return sheet_path


def main():
    build_svgs()
    build_pngs()
    build_previews()
    print("تمام.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
