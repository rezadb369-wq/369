#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run every current capability suite and write a transparent feature matrix."""
import datetime, json, os, re, subprocess, sys
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'));BASE=os.environ.get('BZ','http://127.0.0.1:8080')
SUITES=[
 'test_all.py','test_actions.py','test_v3.py','test_v3_owner.py','test_gates.py','test_haggle.py','test_tickets.py','test_prices.py','test_open.py','test_admin_extras.py','test_discovery.py','test_isolation.py','test_onboarding.py','test_v68.py','test_v69.py','test_context.py','test_section1.py','test_chat_v73.py','test_favorites_v74.py','test_section4_v75.py','test_remaining_v76.py','test_appearance.py','test_browser.py','test_open_parity.py','audit.py','mobile_audit.py','contrast_audit.py','verify.py','walkthrough_e2e.py']
CAPS=[
 ('ورود و نشست همهٔ نقش‌ها',['test_all.py','test_context.py','test_v69.py'],'فرم واقعی، OTP، کوکی و خروج'),
 ('ثبت/تأیید/ویرایش کسب‌وکار',['test_all.py','test_actions.py','test_onboarding.py'],'SQLite + پنل مدیر/مالک'),
 ('دسته‌بندی، جست‌وجو و شهرها',['test_all.py','test_discovery.py','test_section1.py'],'۱۷۳ دسته، پیشنهاد زنده و فیلتر'),
 ('نقشه و نزدیک من',['test_remaining_v76.py','test_browser.py','mobile_audit.py'],'موقعیت، جست‌وجوی دسته، راهنما و زوم'),
 ('علاقه‌مندی، دنبال‌کردن و اعلان',['test_favorites_v74.py','test_admin_extras.py'],'مهمان/حساب/SQLite/پنل'),
 ('محصول، صفحهٔ محصول و سبد',['test_v3.py','test_remaining_v76.py','test_section4_v75.py'],'جزئیات، تعداد، قیمت روشن/خاموش'),
 ('سفارش و لغو دومرحله‌ای',['test_remaining_v76.py','walkthrough_e2e.py'],'مشتری→مالک→مدیر و رضایت تلفن'),
 ('چت و فایل خصوصی',['test_chat_v73.py','walkthrough_e2e.py'],'مشتری/مالک/مدیر، IDOR و پیوست'),
 ('پشتیبانی تیکتی و پیوست',['test_tickets.py','test_remaining_v76.py'],'تنها کانال پشتیبانی + پنل مدیر'),
 ('نظر، رأی مفید و پاسخ',['test_v3.py','test_actions.py'],'ثبت، تعدیل و پاسخ مالک/مدیر'),
 ('نوبت‌دهی',['test_all.py','test_v3_owner.py'],'ثبت مشتری و عملیات مالک/مدیر'),
 ('پرسش و پاسخ',['test_v3.py','test_v3_owner.py'],'ثبت، تأیید، پاسخ و جداسازی'),
 ('استوری و رسانه',['test_admin_extras.py','test_v3_owner.py'],'آپلود، نمایش و حذف'),
 ('برترین‌ها و پیشنهاد روز',['test_admin_extras.py','test_v3.py'],'ساخت/نمایش/کلید قابلیت'),
 ('قیمت، تاریخچه و چانه‌زنی',['test_prices.py','test_v68.py','test_haggle.py','test_section4_v75.py'],'محاسبه واقعی + کنترل مدیر'),
 ('پلن، اشتراک و قفل‌ها',['test_gates.py','test_v3.py','test_admin_extras.py'],'گیت واقعی سمت سرور و پنل'),
 ('گزارش تخلف و تصاحب',['test_v3.py','test_all.py'],'ثبت عمومی و تصمیم مدیر'),
 ('مدیریت مشتری و اعلان همگانی',['test_admin_extras.py'],'مسدودسازی، حذف و broadcast'),
 ('پشتیبان‌گیری و بازیابی',['test_all.py','test_chat_v73.py','test_tickets.py'],'JSON/ZIP و فایل‌های خصوصی'),
 ('امنیت و جداسازی نقش‌ها',['test_all.py','test_gates.py','test_chat_v73.py','test_remaining_v76.py'],'IDOR/XSS/upload/rate/access'),
 ('موبایل، دسترس‌پذیری و کنسول',['test_browser.py','mobile_audit.py','test_appearance.py','contrast_audit.py'],'۳۶۰ تا ۱۹۲۰ و تعامل واقعی'),
 ('سرعت، کش و PWA',['test_section4_v75.py','test_isolation.py','verify.py'],'بدون ویدیو/sprite و بودجهٔ بار اول'),
 ('کنترل‌های بی‌عمل',['audit.py','walkthrough_e2e.py'],'POST واقعی + بازخوانی DB'),
]
def main():
 logdir=os.path.join(ROOT,'audit-v76');os.makedirs(logdir,exist_ok=True);results={}
 for name in SUITES:
  print('>>>',name,flush=True)
  env=dict(os.environ,BZ=BASE,PYTHONPATH=os.path.join(ROOT,'server'))
  p=subprocess.run([sys.executable,os.path.join(ROOT,'tools',name)],cwd=ROOT,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=900)
  open(os.path.join(logdir,name+'.log'),'w',encoding='utf-8').write(p.stdout)
  results[name]={'ok':p.returncode==0,'code':p.returncode,'tail':'\n'.join(p.stdout.splitlines()[-8:])}
  print(' PASS' if p.returncode==0 else ' FAIL',flush=True)
 lines=['# ماتریس نهایی قابلیت‌های دست گیر','',f'تاریخ اجرا: {datetime.datetime.now().isoformat(timespec="seconds")}','',f'نتیجه مجموعه‌ها: **{sum(x["ok"] for x in results.values())} موفق از {len(results)}**','', '| قابلیت | نتیجه | شواهد آزمون واقعی | اتصال |','|---|---:|---|---|']
 for cap,suites,conn in CAPS:
  ok=all(results.get(s,{}).get('ok') for s in suites); lines.append(f'| {cap} | {"✅" if ok else "❌"} | {", ".join(suites)} | {conn} |')
 failed=[n for n,r in results.items() if not r['ok']]
 lines+=['','## حقیقت اجرا',f'- مجموعه‌های ناموفق: {", ".join(failed) if failed else "هیچ‌کدام"}.','- هر مجموعه عملیات واقعی HTTP/مرورگر/SQLite را اجرا می‌کند؛ صرف وجود دکمه معیار قبولی نیست.','- لاگ کامل هر مجموعه در `audit-v76/` ذخیره شده است.']
 open(os.path.join(ROOT,'CAPABILITY-MATRIX-v76.md'),'w',encoding='utf-8').write('\n'.join(lines)+'\n')
 open(os.path.join(logdir,'results.json'),'w').write(json.dumps(results,ensure_ascii=False,indent=2))
 print(f'RESULT {sum(x["ok"] for x in results.values())}/{len(results)}')
 return 1 if failed else 0
if __name__=='__main__':sys.exit(main())
