#!/usr/bin/env bash
# ============================================================================
#  آپدیت امنِ «دست گیر» — v2 (با بازگشت خودکار و سلامت‌سنجی)
#  ---------------------------------------------------------------------------
#  ۱) از کد فعلی اسنپ‌شات می‌گیرد (برای بازگشت)
#  ۲) از داده‌ها اسنپ‌شاتِ سازگار می‌گیرد (بدون توقف سرور، با tools/backup.py)
#  ۳) نسخهٔ جدید را روی کد فعلی باز می‌کند (data دست نمی‌خورد)
#  ۴) سرویس را بالا می‌آورد و سلامت آن را چک می‌کند
#  ۵) اگر سایت بالا نیامد → خودکار به نسخهٔ قبل برمی‌گردد
#
#  استفاده (روی سرور، با root یا sudo):
#      sudo bash tools/deploy.sh /root/dastgir-v134.zip
# ============================================================================
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/bazarche}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/bazarche}"
SERVICE="${SERVICE:-bazarche}"
HEALTH_URL="${HEALTH_URL:-http://127.0.0.1:8080/}"
HEALTH_TRIES="${HEALTH_TRIES:-12}"
HEALTH_SLEEP="${HEALTH_SLEEP:-5}"

ZIP="${1:-}"
if [[ -z "$ZIP" || ! -f "$ZIP" ]]; then
  echo "✗ فایل زیپ نسخهٔ جدید را مشخص کنید:" >&2
  echo "    sudo bash tools/deploy.sh /root/dastgir-v134.zip" >&2
  exit 1
fi
[[ "$(id -u)" -eq 0 ]] || { echo "✗ با sudo اجرا کنید." >&2; exit 1; }
command -v unzip >/dev/null 2>&1 || { apt-get update -qq && apt-get install -y -qq unzip; }

STAMP="$(date +%Y%m%d-%H%M%S)"
BK="$BACKUP_DIR/deploy-$STAMP"
mkdir -p "$BK"

rollback() {
  echo ""
  echo "⚠ سلامت‌سنجی ناموفق بود — بازگشت خودکار به نسخهٔ قبل …"
  systemctl stop "$SERVICE" 2>/dev/null || true
  if [[ -f "$BK/code.tar.gz" ]]; then
    tar xzf "$BK/code.tar.gz" -C "$APP_DIR"
    echo "  ✓ کد به نسخهٔ قبل برگشت"
  fi
  local snap
  snap="$(ls -t "$BK"/snapshot/backup-*.zip 2>/dev/null | head -1 || true)"
  if [[ -n "$snap" ]]; then
    unzip -oq "$snap" -d "$APP_DIR"
    echo "  ✓ داده‌ها به نسخهٔ قبل برگشت"
  fi
  chown -R www-data:www-data "$APP_DIR"
  systemctl start "$SERVICE" 2>/dev/null || true
  echo "✗ آپدیت لغو شد. سایت روی نسخهٔ قبلی است. بکاپ کامل: $BK"
  return 1
}

echo "→ ۱) اسنپ‌شات از کد فعلی (برای بازگشت)"
tar czf "$BK/code.tar.gz" -C "$APP_DIR" \
  --exclude=data --exclude='./data' \
  --exclude='site/assets/img/uploads' \
  --exclude='*.db' --exclude='*.db-wal' --exclude='*.db-shm' .

echo "→ ۲) اسنپ‌شات سازگار از داده‌ها (بدون توقف سرور)"
mkdir -p "$BK/snapshot"
if python3 "$APP_DIR/tools/backup.py" --dir "$BK/snapshot" --no-rotate --quiet; then
  echo "  ✓ بکاپ سازگار از دیتابیس + عکس‌ها گرفته شد"
else
  echo "  ⚠ backup.py در دسترس نبود؛ روش جایگزین: توقف کوتاه + کپی کامل data"
  systemctl stop "$SERVICE" 2>/dev/null || true
  cp -a "$APP_DIR/data" "$BK/data"
  systemctl start "$SERVICE" 2>/dev/null || true
fi

echo "→ ۳) باز کردن نسخهٔ جدید (فقط کد؛ data دست نمی‌خورد)"
unzip -oq "$ZIP" -d "$APP_DIR"

echo "→ ۴) اصلاح مالکیت"
chown -R www-data:www-data "$APP_DIR"

echo "→ ۵) راه‌اندازی و سلامت‌سنجی"
systemctl restart "$SERVICE" 2>/dev/null || systemctl start "$SERVICE" 2>/dev/null || true

healthy=0
for i in $(seq 1 "$HEALTH_TRIES"); do
  sleep "$HEALTH_SLEEP"
  if curl -fsS --max-time 8 "$HEALTH_URL" 2>/dev/null | grep -q "<title>"; then
    healthy=1
    break
  fi
  echo "  … تلاش $i/$HEALTH_TRIES"
done

if [[ "$healthy" -ne 1 ]]; then
  rollback
  exit 1
fi

echo ""
echo "✓ آپدیت تمام شد و سایت سالم است."
echo "  بکاپ این آپدیت (کد + داده): $BK"
echo ""
echo "  🔙 برای بازگشت دستی به قبل:"
echo "      systemctl stop $SERVICE"
echo "      tar xzf $BK/code.tar.gz -C $APP_DIR"
echo "      unzip -oq $(ls -t "$BK"/snapshot/backup-*.zip 2>/dev/null | head -1) -d $APP_DIR"
echo "      chown -R www-data:www-data $APP_DIR"
echo "      systemctl start $SERVICE"
