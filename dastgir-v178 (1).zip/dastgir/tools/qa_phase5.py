#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۵ — برترین‌های شهر · پیشنهادهای روز (فلش‌سیل) · استوری‌ها.
بازاثبات رد پای یافتهٔ ۱۵ (اعتبارسنجی سمت‌سرور تاریخ پایان) + گاردهای v170
(شناسهٔ وحشی لیست/سیل، biz_id وحشی) + انقضا/مرتب‌سازی/نوع auto/حذف.
هر تست اثر واقعی را در پایگاه/صفحهٔ عمومی بررسی می‌کند و تمیزکاری برمی‌گرداند."""
import re, sys, json, sqlite3, time, datetime, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM
import features

DB = "data/bazarche.db"
RESULTS = []
A_BIZ, A_PHONE = 214, "09352223344"     # دکانٔ آزمون مالک یک
ADMIN_PHONE = "09131110011"             # حساب مدیر

def q(sql, args=()):
    c = sqlite3.connect(DB); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None):
    h = {}
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data, doseq=True).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(BASE + path, data=body, headers=h)
    try:
        r = op.open(req, timeout=25)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def clear_rl():
    q("delete from ratelimit")

def login_admin():
    clear_rl()
    op = sess()
    go(op, "/login")
    go(op, "/login", {"phone": ADMIN_PHONE})
    go(op, "/login/verify", {"phone": ADMIN_PHONE, "code": otp_code(ADMIN_PHONE)})
    go(op, "/panel?key=" + DBM.owner_token())
    return op

def login_shop():
    clear_rl()
    op = sess()
    go(op, "/login")
    go(op, "/login", {"phone": A_PHONE})
    go(op, "/login/verify", {"phone": A_PHONE, "code": otp_code(A_PHONE)})
    return op

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

created = {"toplists": [], "flashdeals": [], "stories": []}

# ─────────────────── T1 برترین‌های شهر ───────────────────
def t1():
    print("── T1 برترین‌های شهر (toplists)")
    op = login_admin()
    # ساخت دستی
    st, b, url = go(op, "/panel/list/new", {"title": "برترین‌های آزمون فاز۵",
                                            "descr": "لیست آزمونی", "kind": "manual", "limit_n": "10"})
    row = q("select id,slug from toplists where title='برترین‌های آزمون فاز۵'")
    check("T1.1", "ساخت لیست دستی", "ساخته" in urllib.parse.unquote(url) and len(row) == 1, url)
    tid, tslug = row[0]
    created["toplists"].append(tid)
    # ویرایش با آیتم‌ها + فعال
    st, b, url = go(op, f"/panel/list/{tid}", {"title": "برترین‌های آزمون فاز۵",
                    "descr": "لیست آزمونی", "kind": "manual", "limit_n": "10",
                    "items": [str(A_BIZ), "215"], "active": "1"})
    items = json.loads(q("select items from toplists where id=?", (tid,))[0][0])
    active = q("select active from toplists where id=?", (tid,))[0][0]
    check("T1.2", "ذخیرهٔ ویرایش + آیتم‌ها/فعال", "ذخیره" in urllib.parse.unquote(url)
          and items == [A_BIZ, 215] and active == 1, f"items={items} active={active}")
    # رتبه‌بندی خوانش
    t = features.toplist(tid=tid)
    rows = features.toplist_businesses(t)
    check("T1.3", "رتبه‌ها ۱و۲ و فقط منتشرشده", [r["id"] for r in rows] == [A_BIZ, 215]
          and [r["rank"] for r in rows] == [1, 2], str([r["id"] for r in rows]))
    # نوع auto (زنده محاسبه می‌شود)
    st, b, url = go(op, "/panel/list/new", {"title": "برترین‌های خودکار آزمون",
                    "descr": "", "kind": "auto_rating", "limit_n": "3"})
    row2 = q("select id from toplists where title='برترین‌های خودکار آزمون'")
    tid2 = row2[0][0]; created["toplists"].append(tid2)
    rows2 = features.toplist_businesses(features.toplist(tid=tid2))
    rs = [r["rating"] for r in rows2 if r["rating"] is not None]
    sorted_ok = rs == sorted(rs, reverse=True)
    check("T1.4", "auto_rating زنده و مرتب (بی‌نمره‌ها آخر)",
          len(rows2) >= 1 and rows2[0]["rank"] == 1 and sorted_ok
          and all(rows2[i]["rating"] is None or rows2[i]["rating"] >= (rows2[i+1]["rating"] or 0)
                  for i in range(len(rows2)-1)), f"n={len(rows2)} ratings={rs}")
    # عمومی: /lists و /list/{slug}
    time.sleep(5.2)  # کش ۵ثانیه‌ای صفحه
    st, b, _ = go(op, "/lists")
    st2, b2, _ = go(sess(), f"/list/{tslug}")
    check("T1.5", "عمومی /lists و /list/{slug}", st == 200 and "برترین‌های آزمون فاز۵" in b
          and st2 == 200 and "دکانٔ آزمون مالک یک" in b2, f"{st}/{st2}")
    # وحشی: ذخیره/حذف شناسهٔ ناموجود — باید پیام روشن بدهد نه جعل موفقیت
    st, b, url = go(op, "/panel/list/999999", {"title": "یاوچی", "descr": "", "kind": "manual", "limit_n": "10"})
    st2, b2, url2 = go(op, "/panel/list/999999/delete", {})
    ghost = q("select * from toplists where title like '%یاوچی%'")
    check("T1.6", "وحشی لیست → پیام «نیست» و بدون رکورد",
          "نیست" in urllib.parse.unquote(url) and "نیست" in urllib.parse.unquote(url2)
          and not ghost, f"{url} {url2}")
    # بی‌عنوان
    st, b, url = go(op, "/panel/list/new", {"title": "", "descr": "", "kind": "manual", "limit_n": "10"})
    check("T1.7", "بی‌عنوان رد", "عنوان" in urllib.parse.unquote(url))
    # دکاندار 403×4
    sop = login_shop()
    g1 = go(sop, "/panel/lists")[0]
    g2 = go(sop, "/panel/list/new", {"title": "هک", "descr": "", "kind": "manual"})[0]
    g3 = go(sop, f"/panel/list/{tid}", {"title": "هک", "descr": "", "kind": "manual"})[0]
    g4 = go(sop, f"/panel/list/{tid}/delete", {})[0]
    check("T1.8", "دکاندار 403×4", (g1, g2, g3, g4) == (403, 403, 403, 403), str((g1, g2, g3, g4)))

# ─────────────────── T2 پیشنهادهای روز (فلش‌سیل) ───────────────────
def t2():
    print("── T2 فلش‌سیل (پیشنهادهای روز)")
    op = login_admin()
    now = datetime.datetime.now()
    ends_ok = (now + datetime.timedelta(hours=2)).strftime("%Y-%m-%d %H:%M")
    # #15 — اعتبارسنجی سمت‌سرور تاریخ پایان (پابرجا؟)
    st, b, url = go(op, "/panel/deal/new", {"biz_id": str(A_BIZ), "title": "سیل آزمون",
                    "descr": "", "percent": "30", "ends": "1404/06/22"})
    st2, b2, url2 = go(op, "/panel/deal/new", {"biz_id": str(A_BIZ), "title": "سیل آزمون",
                       "descr": "", "percent": "30", "ends": ""})
    check("T2.1", "#15 پابرجا: تاریخ جلالی/خالی سمت‌سرور رد",
          "معتبر نیست" in urllib.parse.unquote(url) and "معتبر نیست" in urllib.parse.unquote(url2))
    # biz_id وحشی (#22) — قبلاً FK → 500
    st, b, url = go(op, "/panel/deal/new", {"biz_id": "999999", "title": "سیل وحشی",
                    "descr": "", "percent": "30", "ends": ends_ok})
    st2, b2, url2 = go(op, "/panel/deal/new", {"biz_id": "0", "title": "سیل وحشی",
                       "descr": "", "percent": "30", "ends": ends_ok})
    ghost = q("select * from flashdeals where title like '%وحشی%'")
    check("T2.2", "#22: biz_id وحشی/صفر → پیام خطا، نه 500",
          "معتبر نیست" in urllib.parse.unquote(url) and "معتبر نیست" in urllib.parse.unquote(url2)
          and not ghost, f"{url} {url2}")
    # ساخت معتبر + نمایش عمومی
    st, b, url = go(op, "/panel/deal/new", {"biz_id": str(A_BIZ), "title": "سیل آزمون فاز۵",
                    "descr": "تخفیف آزمونی", "percent": "25", "ends": ends_ok})
    row = q("select id from flashdeals where title='سیل آزمون فاز۵'")
    check("T2.3", "ساخت سیل معتبر", "ساخته" in urllib.parse.unquote(url) and len(row) == 1, url)
    did = row[0][0]; created["flashdeals"].append(did)
    time.sleep(5.2)  # کش ۵ثانیه‌ای
    st, b, _ = go(sess(), "/deals")
    check("T2.4", "عمومی /deals سیل زنده را نشان می‌دهد", st == 200 and "سیل آزمون فاز۵" in b)
    # منقضی: مستقیم در پایگاه — نباید در عمومی بیاید؛ در پنل (همه) دیده شود
    q("insert into flashdeals(biz_id,title,descr,percent,starts,ends,active,created) "
      "values(?,'سیل منقضی آزمون','قدیمی',40,'','2020-01-01 00:00',1,datetime('now'))", (A_BIZ,))
    exp_id = q("select id from flashdeals where title='سیل منقضی آزمون'")[0][0]
    created["flashdeals"].append(exp_id)
    time.sleep(5.2)
    st, b, _ = go(sess(), "/deals")
    st2, b2, _ = go(op, "/panel/deals")
    check("T2.5", "منقضی از عمومی پنهان / در پنل دیده", "سیل منقضی آزمون" not in b
          and st2 == 200 and "سیل منقضی آزمون" in b2)
    # حذف وحشی → پیام روشن (v170)
    st, b, url = go(op, "/panel/deal/999999/delete", {})
    check("T2.6", "وحشی حذف سیل → «نیست»", "نیست" in urllib.parse.unquote(url))
    # حذف واقعی
    st, b, url = go(op, f"/panel/deal/{did}/delete", {})
    check("T2.7", "حذف واقعی سیل", "حذف" in urllib.parse.unquote(url)
          and not q("select * from flashdeals where id=?", (did,)))
    created["flashdeals"].remove(did)
    # دکاندار 403
    sop = login_shop()
    g1 = go(sop, "/panel/deals")[0]
    g2 = go(sop, "/panel/deal/new", {"biz_id": str(A_BIZ), "title": "هک", "descr": "",
            "percent": "10", "ends": ends_ok})[0]
    check("T2.8", "دکاندار 403×2", (g1, g2) == (403, 403), str((g1, g2)))

# ─────────────────── T3 استوری‌ها ───────────────────
def t3():
    print("── T3 استوری‌های ۲۴ساعته")
    op = login_admin()
    # زنده + منقضی مستقیم در پایگاه (آپلود HTTP در qa_mobile پوشش داده می‌شود)
    q("insert into stories(biz_id,image,kind,caption,created,expires,duration) "
      "values(?,'assets/img/uploads/qa-photo.webp','image','آزمون فاز۵',datetime('now'),?,0)",
      (A_BIZ, time.time() + 3600))
    sid_live = q("select id from stories where caption='آزمون فاز۵'")[0][0]
    created["stories"].append(sid_live)
    q("insert into stories(biz_id,image,kind,caption,created,expires,duration) "
      "values(?,'assets/img/uploads/qa-photo.webp','image','منقضی فاز۵',datetime('now'),?,0)",
      (A_BIZ, time.time() - 10))
    sid_exp = q("select id from stories where caption='منقضی فاز۵'")[0][0]
    created["stories"].append(sid_exp)
    act = features.stories_active()
    ids = {r["id"] for r in act}
    check("T3.1", "زنده دیده می‌شود، منقضی پنهان", sid_live in ids and sid_exp not in ids,
          f"live={sid_live in ids} exp={sid_exp in ids}")
    ring = features.stories_active_ids()
    check("T3.2", "حلقهٔ دکان زنده (stories_active_ids)", A_BIZ in ring)
    st, b, _ = go(sess(), "/api/stories")
    check("T3.3", "API عمومی استوری 200 + زنده در فهرست", st == 200 and str(sid_live) in b)
    # پنل مدیر + حذف واقعی
    st, b, _ = go(op, "/panel/stories")
    check("T3.4", "پنل استوری‌ها 200 و زنده در فهرست", st == 200 and "آزمون فاز۵" in b)
    st, b, url = go(op, f"/panel/story/{sid_live}/delete", {})
    check("T3.5", "حذف استوری از پنل", "حذف" in urllib.parse.unquote(url)
          and not q("select * from stories where id=?", (sid_live,)))
    created["stories"].remove(sid_live)
    # حذف وحشی → هیچ، بی‌خطر (no-op بی‌پیام در /panel؟ — چک وضعیت)
    st, b, url = go(op, "/panel/story/999999/delete", {})
    check("T3.6", "وحشی حذف استوری بی‌خطر", st in (200, 303) and
          not q("select * from stories where id=999999"))
    # دکاندار: فقط استوریِ دکان خودش — استوری دکان 215 نباید در فهرست حذفِ او باشد
    q("insert into stories(biz_id,image,kind,caption,created,expires,duration) "
      "values(215,'x.webp','image','مالک‌دو',datetime('now'),?,0)", (time.time() + 3600,))
    sid_b = q("select id from stories where caption='مالک‌دو'")[0][0]
    created["stories"].append(sid_b)
    sop = login_shop()
    st, b, url = go(sop, f"/my/story/{sid_b}/delete", {})
    still = q("select * from stories where id=?", (sid_b,))
    check("T3.7", "دکاندار استوری دکان دیگر را حذف نمی‌کند", len(still) == 1)

def main():
    try:
        t1()
        t2()
        t3()
    finally:
        # تمیزکاری کامل — صحنه به حالت قبل
        for tid in created["toplists"]:
            q("delete from toplists where id=?", (tid,))
        for did in created["flashdeals"]:
            q("delete from flashdeals where id=?", (did,))
        for sid in created["stories"]:
            q("delete from stories where id=?", (sid,))
        q("delete from toplists where title like '%آزمون%' or title like '%یاوچی%'")
        q("delete from flashdeals where title like '%آزمون%' or title like '%وحشی%' or title like '%منقضی%'")
        q("delete from stories where caption like '%فاز۵%' or caption='مالک‌دو'")
    json.dump(RESULTS, open("qa/phase5-results.json", "w"), ensure_ascii=False, indent=1)
    fails = [r for r in RESULTS if not r["ok"]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(fails)} | قرمز: {len(fails)}")
    for r in fails:
        print("  ❌", r["id"], r["name"], "—", r["detail"])
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
