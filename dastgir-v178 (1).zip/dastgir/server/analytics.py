"""v114: real-visit analytics — stdlib only, Pydroid-safe.

Every public page view is recorded as ONE row in `visits` with the real
identity of the visitor:

  * IP address (XFF only honoured from loopback, same rule as the shield)
  * User-Agent + a coarse device class (mobile | tablet | desktop | bot)
  * `bz_cid` — a first-party visitor cookie (random, 2 years): this is what
    makes "unique visitors" mean separate real people rather than requests
  * `bz_sid` — a rolling 30-minute session id
  * Referer, path, page kind and the entity ids (business/item/story)

Bots and crawlers (Googlebot, GPTBot, curl, scanners, ...) are still recorded
— with bot=1 — so the panel can show the true picture, but they never touch
the public counters and never count as "real visitors".

This module is also the SINGLE place that increments the public counters
(businesses.views + events, items.views); the old call inside the business
view was removed in v114 so a page can never be counted twice, and bots can
never inflate a shop's number.

GA4 (Google's cookies: _ga, _ga_<id>) is NOT handled here — that lives in the
optional gtag snippet injected by ui.py when the owner pastes a measurement
id. This module is the self-hosted, always-on layer that needs no account.
"""

import re
import secrets
import time
import urllib.parse

import db
import geoip

# ---------------------------------------------------------------- identities
CID_COOKIE = "bz_cid"          # visitor: one real browser = one id
SID_COOKIE = "bz_sid"          # session: rolling 30 minutes
CID_RE = re.compile(r"^[a-f0-9]{16}$")
SESSION_SECS = 30 * 60

# Anything that is not a human in a browser. Deliberately wide: for the
# "real people" numbers it is better to miss an exotic browser than to let a
# crawler family pollute a shop's visit counter.
BOT_RE = re.compile(
    r"(bot\b|bots\b|crawl|spider|slurp|curl/|wget|python-requests|python-urllib|"
    r"httpx|scrapy|go-http-client|java/|libwww|aiohttp|okhttp|axios|"
    r"headless|phantomjs|selenium|puppeteer|playwright|lighthouse|"
    r"monitor|checker|scan|feedfetcher|rss|preview|proxy|"
    r"whatsapp|telegrambot|discordbot|slackbot|facebookexternalhit|"
    r"linkedinbot|twitterbot|pinterest|embedly|outbrain|quora|"
    r"googlebot|bingbot|yandex|duckduckgo|baidu|ahrefs|semrush|mj12bot|"
    r"dotbot|petalbot|bytespider|gptbot|chatgpt|ccbot|perplexity|claude|"
    r"anthropic|applebot|amazonbot|omgili|sogou|exabot)", re.I)

# Also honour the shield's malicious-tool list so a sqlmap sweep never shows
# up as a "visitor" either.
try:
    from shield import BAD_UA_RE as _BAD_UA_RE
except Exception:                                   # pragma: no cover
    _BAD_UA_RE = None


def _is_bot(ua):
    if not ua:
        return True                                # no UA = not a browser
    if BOT_RE.search(ua):
        return True
    return bool(_BAD_UA_RE and _BAD_UA_RE.search(ua))


def _device(ua, bot):
    if bot:
        return "bot"
    u = (ua or "").lower()
    if "ipad" in u or "tablet" in u:
        return "tablet"
    if ("mobi" in u or "android" in u or "iphone" in u or "ipod" in u
            or "windows phone" in u):
        return "mobile"
    return "desktop"


# ---------------------------------------------------------------- page kinds
# Whitelist on purpose: anything not listed (panel, login, chat, api, static
# assets, 404s) is simply not a content page view.
_PAGE_ROUTES = (
    (re.compile(r"^/$"),                                "home",     None),
    (re.compile(r"^/businesses$"),                      "listing",  None),
    (re.compile(r"^/b/([A-Za-z0-9_-]+)$"),              "business", "slug"),
    (re.compile(r"^/item/(\d+)$"),                      "item",     "id"),
    (re.compile(r"^/blog$"),                            "blog",     None),
    (re.compile(r"^/blog/([A-Za-z0-9_-]+)$"),           "blogpost", "slug"),
    (re.compile(r"^/map$"),                             "map",      None),
    (re.compile(r"^/prices$"),                          "prices",   None),
    (re.compile(r"^/haggle/(\d+)$"),                    "haggle",   "id"),
    (re.compile(r"^/contact$"),                         "contact",  None),
)

KIND_FA = {"home": "صفحهٔ اول", "listing": "فهرست کسب‌وکارها",
           "business": "صفحهٔ کسب‌وکار", "item": "کالا", "blog": "بلاگ",
           "blogpost": "مطلب بلاگ", "map": "نقشه", "prices": "قیمت‌ها",
           "haggle": "چانه", "contact": "تماس", "story": "استوری"}


def classify(path):
    """(kind, entity) for a public page path, or None when not content."""
    for rx, kind, ent in _PAGE_ROUTES:
        m = rx.match(path)
        if m:
            return kind, (m.group(1) if ent else None)
    return None


# ---------------------------------------------------------------- identities
def client_ip(h):
    """Real client IP: the direct peer, or XFF only when the peer is
    loopback (same trust rule as the shield — a remote client cannot lie
    its way into somebody else's bucket)."""
    peer = (h.client_address[0] or "").split(":")[0]
    if peer in ("127.0.0.1", "::1", "localhost"):
        fwd = h.headers.get("X-Forwarded-For", "")
        if fwd:
            first = fwd.split(",")[0].strip()
            if first:
                return first
    return peer


def ensure_cid(h):
    c = (h.cookies().get(CID_COOKIE) or "").strip()
    if CID_RE.match(c):
        return c
    c = secrets.token_hex(8)
    h.set_cookie(CID_COOKIE, c, days=730)          # 2 years
    return c


def ensure_sid(h):
    """Rolling session: same id while requests keep coming within 30
    minutes; the fresh-start timestamp is carried inside the cookie so no
    server-side session table is needed."""
    raw = (h.cookies().get(SID_COOKIE) or "").strip()
    m = re.match(r"^([a-f0-9]{16})\.(\d{10})$", raw)
    if m and time.time() - int(m.group(2)) < SESSION_SECS:
        return raw
    fresh = f"{secrets.token_hex(8)}.{int(time.time())}"
    h.set_cookie(SID_COOKIE, fresh, days=1)        # expiry enforced above
    return fresh


# ---------------------------------------------------------------- recording
def _insert(ts, path, kind, biz_id, item_id, story_id,
            ip, ua, dev, cid, sid, ref, bot, prov="", city="", utm=""):
    db._run(
        "INSERT INTO visits(ts,path,kind,biz_id,item_id,story_id,ip,ua,dev,"
        "cid,sid,ref,bot,prov,city,utm) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (ts, path[:200], kind, biz_id, item_id, story_id,
         ip[:45], (ua or "")[:300], dev, cid, sid, (ref or "")[:300], bot,
         prov[:40], city[:60], utm[:120]))


def _utm_of(h):
    """'source|medium|campaign' from ?utm_* — '' when the visit is organic."""
    try:
        q = urllib.parse.parse_qs(urllib.parse.urlsplit(h.path).query)
        parts = [(q.get("utm_source") or [""])[0],
                 (q.get("utm_medium") or [""])[0],
                 (q.get("utm_campaign") or [""])[0]]
        parts = [p[:40] for p in parts if p]
        return "|".join(parts)
    except Exception:
        return ""


def track_page(h):
    """Hook called from Handler.send() for every 200 text/html response.
    Never raises — analytics must not be able to break a page."""
    try:
        if getattr(h, "command", "") == "HEAD":
            return
        path = urllib.parse.urlsplit(h.path).path
        # v177: کوکی بازدیدکننده روی «هر» صفحهٔ HTML سنجاق می‌شود — نه فقط
        # مسیرهای دسته‌بندی‌شده. صفحهٔ /b/{slug}/stories دسته‌بندی نمی‌شود و
        # اگر کوکی این‌جا ست نشود، هر POST بازدیدِ استوری یک شناسهٔ تازه
        # می‌گیرد و یکتاسازی می‌شکند (درس همین نسخه).
        cid = ensure_cid(h)
        hit = classify(path)
        if not hit:
            return
        kind, ent = hit
        ua = h.headers.get("User-Agent") or ""
        bot = 1 if _is_bot(ua) else 0
        sid = ensure_sid(h)
        ip = client_ip(h)
        ref = h.headers.get("Referer") or ""
        biz_id = item_id = None
        if kind == "business":
            b = db.business(slug=ent)
            if not b:
                return
            biz_id = b["id"]
            if not bot:
                db.bump_views(biz_id, cid)         # v177: unique viewer/day
        elif kind == "item":
            item_id = int(ent)
            if not bot and db._one("SELECT 1 FROM items WHERE id=?",
                                   (item_id,)):
                db.count_item_view(item_id, cid)   # v177: unique viewer/day
        prov, city = geoip.lookup(ip)             # v115: offline, IR only
        _insert(time.time(), path, kind, biz_id, item_id, None,
                ip, ua, _device(ua, bot), cid, sid, ref, bot,
                prov, city, _utm_of(h))
    except Exception:
        pass


def track_story(h, story_id):
    """Full-identity story view (v114). The anonymous story_views counter
    stays for the owner's chart; this row adds WHO watched (IP + visitor
    cookie + device) so the panel can tell real people from bots."""
    try:
        ua = h.headers.get("User-Agent") or ""
        bot = 1 if _is_bot(ua) else 0
        ip = client_ip(h)
        prov, city = geoip.lookup(ip)
        row = db._one("SELECT biz_id FROM stories WHERE id=?", (story_id,))
        _insert(time.time(), f"/api/stories/{story_id}/view", "story",
                (row["biz_id"] if row else None), None, story_id,
                ip, ua, _device(ua, bot),
                ensure_cid(h), ensure_sid(h),
                h.headers.get("Referer") or "", bot, prov, city)
    except Exception:
        pass


# ---------------------------------------------------------------- reporting
def _all(sql, args=()):
    return db._rows(sql, args)


def _one(sql, args=()):
    return db._one(sql, args)


def overview(days_chart=14):
    """Everything the panel's analytics page needs, in one dict."""
    now = time.time()
    d0 = now - 86400                       # last 24h
    d7 = now - 7 * 86400
    d30 = now - 30 * 86400

    def pv_uv(since):
        r = _one("SELECT COUNT(*) pv, COUNT(DISTINCT cid) uv FROM visits "
                 "WHERE ts>=? AND bot=0", (since,))
        return (r["pv"] or 0, r["uv"] or 0)

    out = {}
    out["pv24"], out["uv24"] = pv_uv(d0)
    out["pv7"], out["uv7"] = pv_uv(d7)
    out["pv30"], out["uv30"] = pv_uv(d30)
    out["bots24"] = (_one("SELECT COUNT(*) n FROM visits WHERE ts>=? AND bot=1",
                          (d0,)) or {}).get("n", 0)
    out["sessions24"] = (_one("SELECT COUNT(DISTINCT sid) n FROM visits "
                              "WHERE ts>=? AND bot=0", (d0,)) or {}).get("n", 0)

    # 14-day series for the sparkline (zero-filled client-side is fine, but
    # filling here keeps the SQL simple and the chart honest).
    series = []
    for i in range(days_chart - 1, -1, -1):
        a = now - (i + 1) * 86400
        b = now - i * 86400
        r = _one("SELECT COUNT(*) n FROM visits WHERE ts>=? AND ts<? AND bot=0",
                 (a, b))
        series.append((int(a // 86400), r["n"] or 0))
    out["series"] = series

    out["top_pages"] = _all(
        "SELECT path, kind, COUNT(*) n, COUNT(DISTINCT cid) uv FROM visits "
        "WHERE ts>=? AND bot=0 GROUP BY path ORDER BY n DESC LIMIT 10", (d7,))
    out["top_biz"] = _all(
        "SELECT v.biz_id, b.name, b.slug, COUNT(*) n, COUNT(DISTINCT v.cid) uv "
        "FROM visits v JOIN businesses b ON b.id=v.biz_id "
        "WHERE v.ts>=? AND v.bot=0 AND v.kind='business' "
        "GROUP BY v.biz_id ORDER BY n DESC LIMIT 10", (d7,))
    out["top_stories"] = _all(
        "SELECT v.story_id, COUNT(*) n, COUNT(DISTINCT v.cid) uv "
        "FROM visits v WHERE v.ts>=? AND v.bot=0 AND v.kind='story' "
        "GROUP BY v.story_id ORDER BY n DESC LIMIT 10", (d7,))
    out["devices"] = _all(
        "SELECT dev, COUNT(*) n FROM visits WHERE ts>=? AND bot=0 "
        "GROUP BY dev ORDER BY n DESC", (d7,))

    # Referrers: reduce to host names so ?utm noise does not fragment rows.
    refs = {}
    for r in _all("SELECT ref FROM visits WHERE ts>=? AND bot=0 AND ref!='' "
                  "LIMIT 2000", (d7,)):
        host = urllib.parse.urlsplit(r["ref"]).netloc or r["ref"][:40]
        refs[host] = refs.get(host, 0) + 1
    out["referrers"] = sorted(refs.items(), key=lambda kv: -kv[1])[:10]

    out["recent"] = _all(
        "SELECT ts, path, kind, ip, dev, cid, bot FROM visits "
        "ORDER BY id DESC LIMIT 25")

    # ---- v115 additions
    out["online"] = (_one("SELECT COUNT(DISTINCT cid) n FROM visits "
                          "WHERE ts>=? AND bot=0",
                          (now - 300,)) or {}).get("n", 0)   # last 5 minutes
    out["top_cities"] = _all(
        "SELECT prov, city, COUNT(*) n, COUNT(DISTINCT cid) uv FROM visits "
        "WHERE ts>=? AND bot=0 AND city!='' GROUP BY city "
        "ORDER BY n DESC LIMIT 10", (d7,))
    out["campaigns"] = _all(
        "SELECT utm, COUNT(*) n, COUNT(DISTINCT cid) uv FROM visits "
        "WHERE ts>=? AND bot=0 AND utm!='' GROUP BY utm "
        "ORDER BY n DESC LIMIT 10", (d30,))
    # 7×24 heat grid: weekday (Sat=0 .. Fri=6, Persian week) × hour
    # NOTE: SQLite wants the offset as '+03:30' — '+3:30' silently yields NULL.
    heat = [[0] * 24 for _ in range(7)]
    for r in _all("SELECT strftime('%w', ts, 'unixepoch', '+03:30') wd, "
                  "strftime('%H', ts, 'unixepoch', '+03:30') hh, COUNT(*) n "
                  "FROM visits WHERE bot=0 GROUP BY wd, hh"):
        if r["wd"] is None or r["hh"] is None:
            continue
        wd = (int(r["wd"]) + 1) % 7                 # sqlite Sun=0 -> Persian Sat=0
        heat[wd][int(r["hh"])] = r["n"]
    out["heat"] = heat
    return out
