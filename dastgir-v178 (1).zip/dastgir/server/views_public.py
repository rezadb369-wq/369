# -*- coding: utf-8 -*-
"""Public-facing views rendered from the database."""

import json
import os
import time
from urllib.parse import urlencode as _urlencode, quote as _quote
import db
from ui import (icon, stars, fa, fa_group, esc, page, biz_card, stat_card, cat_icon,
                section_head, breadcrumb, empty_state, flash, cat_options,
                open_badge, open_line, call_bar, json_embed, OWNER_PERKS,
                ctx_owner as ui_ctx_owner, ctx_customer as ui_ctx_customer)
from ui import jdate, jdatetime, jdatetime_ts
import views_public2 as V2

MAP_JS = ('<script type="module" src="/assets/js/catpicker.js?v109"></script>'
          '<script type="module" src="/assets/js/mappage.js?v156"></script>')

# Documentary photos for category tiles (v49). One warm, hands-at-work image
# per trade, stored as WebP. The helper falls back to '' when a photo is
# missing, so a tile silently keeps its icon instead of breaking.
CAT_IMG = "/assets/img/cats"
_CAT_IMG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "..", "site", "assets", "img", "cats")


def cat_photo(slug):
    """Public path of a category's documentary photo, or '' if absent."""
    if not slug or not os.path.isfile(os.path.join(_CAT_IMG_DIR, slug + ".webp")):
        return ""
    return f"{CAT_IMG}/{slug}.webp"

# Homepage «امکانات سایت» band — what a visitor should meet FIRST.
# (icon, title, desc, link, enabled_key). enabled_key None = always shown.
FEATURE_CARDS = [
    ("image",   "استوری کسب‌وکارها", "عکس و ویدیوی ۲۴ ساعته از دکان‌ها", "/businesses", "stories_enabled"),
    ("message", "گفت‌وگوی مستقیم",   "چت بی‌واسطه با دکان‌دار",           "/features",   "chat_enabled"),
    ("cart",    "سبد خرید و سفارش",  "سفارش آنلاین از کاتالوگ",             "/cart",       "orders_enabled"),
    ("trophy",  "برترین‌های شهر",    "رتبه‌بندی بهترین‌های هر صنف",         "/lists",      "lists_enabled"),
    ("zap",     "پیشنهاد روز",       "تخفیف لحظه‌ای با شمارش معکوس",        "/deals",      "deals_enabled"),
    ("map",     "همهٔ شهرهای ایران", "۳۵۳ شهر، یک دست گیرِ سراسری",         "/cities",     None),
    ("bell",    "دنبال‌کردن و اعلان","تازه‌های دکان‌های محبوبتان",         "/features",   "follow_enabled"),
]

# Billing-period toggle on the pricing page (monthly / 3 / 6 / 12). Default
# view is yearly (matches the server-rendered price); selecting a shorter
# period recomputes each plan's price from its monthly rate client-side and
# appends &months=N to the subscribe link.
BILL_JS = r'''<script>
(function(){
  var grid=document.querySelector('[data-price-grid]'); if(!grid) return;
  var FA='۰۱۲۳۴۵۶۷۸۹';
  var fa=function(n){return String(n).replace(/\d/g,function(d){return FA[+d];});};
  var faG=function(n){return fa(Number(n).toLocaleString('en-US')).replace(/,/g,'٬');};
  function label(p){return p===1?'تومان / ماه':p===3?'تومان / ۳ ماه':p===6?'تومان / ۶ ماه':'تومان / سالانه';}
  function set(period){
    grid.querySelectorAll('.price-card[data-monthly]').forEach(function(c){
      var base=parseInt(c.dataset.price,10)||0, pm=parseInt(c.dataset.months,10)||0;
      if(!base||!pm) return;
      var n=c.querySelector('.price-amount .n'); if(n) n.textContent=faG(Math.round(base*period/pm));
      var u=c.querySelector('.price-amount .u'); if(u) u.textContent=label(period);
      var a=c.querySelector('a[href^="/subscribe"]'); if(a){ a.setAttribute('href', a.getAttribute('href').split('&months=')[0]+'&months='+period); }
    });
  }
  document.querySelectorAll('[data-bill-toggle] [data-period]').forEach(function(b){
    b.addEventListener('click', function(){
      document.querySelectorAll('[data-bill-toggle] [data-period]').forEach(function(x){x.classList.remove('is-active');x.setAttribute('aria-pressed','false');});
      b.classList.add('is-active'); b.setAttribute('aria-pressed','true');
      set(parseInt(b.dataset.period,10));
    });
  });
})();
</script>'''


def _cat_icons():
    return {c["slug"]: c["icon"] for c in db.categories(only_active=False)}


# ------------------------------------------------------------------ categories
def categories_page(s, token=""):
    """Browse ALL trades — every group and subcategory with its documentary
    photo (v49). This is where the 173 hands-at-work images actually surface:
    a real directory index, not a hidden accordion."""
    cats = db.category_tree()
    n_parents = len(cats)
    n_children = sum(len(c.get("children") or []) for c in cats)

    def _sub_card(k, i):
        photo = cat_photo(k["slug"])
        if photo:
            thumb = (f'<img src="{esc(photo)}" alt="" loading="lazy" decoding="async">')
        else:
            thumb = cat_icon(k["icon"], 34)
        return (f'<a class="catcard reveal" href="/businesses?cat={esc(k["slug"])}" '
                f'data-delay="{i * 20}" data-subcat-name="{esc(k["name"])}">'
                f'<span class="catcard-thumb">{thumb}</span>'
                f'<span class="catcard-name">{esc(k["name"])}</span>'
                + (f'<span class="catcard-n nums">{fa(k["count"])}</span>' if k["count"] else "")
                + '</a>')

    sections = []
    nav_chips = []
    for gi, c in enumerate(cats):
        kids = c.get("children") or []
        gphoto = cat_photo(c["slug"])
        gthumb = (f'<img src="{esc(gphoto)}" alt="" loading="lazy" decoding="async">'
                  if gphoto else cat_icon(c["icon"], 30))
        cards = "".join(_sub_card(k, i) for i, k in enumerate(kids))
        _grp_search = " ".join([c["name"], c.get("blurb") or ""] + [k["name"] for k in kids])
        
        nav_chips.append(
            f'<a class="chip" href="#cg-{esc(c["slug"])}" data-cat-nav="{esc(c["slug"])}">'
            f'{cat_icon(c["icon"], 16)}<span>{esc(c["name"])}</span></a>'
        )

        sections.append(f'''<section class="catgroup reveal" id="cg-{esc(c['slug'])}" data-delay="{gi * 30}" data-catgroup-search="{esc(_grp_search)}">
  <div class="catgroup-head">
    <span class="catgroup-photo">{gthumb}</span>
    <div class="catgroup-meta">
      <h2 class="catgroup-title">{esc(c["name"])}</h2>
      <p class="catgroup-blurb">{esc(c["blurb"])}</p>
    </div>
    <a class="catgroup-all" href="/businesses?cat={esc(c["slug"])}">
      {icon("arrow-left")}<span>{fa(c["total"])} کسب‌وکار</span></a>
  </div>
  <div class="catcard-grid">{cards}</div>
</section>''')

    nav_bar = f'''<nav class="cats-nav-bar mb-lg" aria-label="پرش سریع به گروه‌های شغلی">
  <div class="cats-nav-scroll">
    <a class="chip is-active" href="#all" data-cat-nav="all">{icon("layers")}<span>همهٔ {fa(n_parents)} گروه</span></a>
    {"".join(nav_chips)}
  </div>
</nav>'''

    body = f'''
<div class="container-wide">
  {breadcrumb(("دسته‌بندی‌ها", "/categories"))}
  <header class="page-hero">
    <span class="eyebrow">{icon("layers")}<span>راهنمای اصناف ایران</span></span>
    <h1>همهٔ {fa(n_parents + n_children)} دستهٔ تخصصی</h1>
    <p>{fa(n_parents)} گروه اصلی و {fa(n_children)} صنف تخصصی — روی هر صنف بزنید تا
       کسب‌وکارهای همان رسته را ببینید.</p>
  </header>
</div>
<section class="section-sm"><div class="container-wide">
  <div class="cats-search-wrap card glass card-pad mb-lg" data-cats-searchbox>
    <div class="search-wrap">
      {icon("search", cls="search-icon")}
      <label class="sr-only" for="cats-filter">جست‌وجوی دسته</label>
      <input class="input" id="cats-filter" type="search" data-cats-filter
             placeholder="جست‌وجوی صنف یا رسته شغلی… مثلاً نانوایی، رستوران، آرایشگاه، پوشاک"
             autocomplete="off">
    </div>
    <p class="text-center text-sm text-muted mt-md" data-cats-empty hidden>
      دسته‌ای با این نام یافت نشد — عبارت دیگری را امتحان کنید.
    </p>
  </div>
  {nav_bar}
  <div class="cats-groups-wrap" data-cats-wrap>
    {"".join(sections)}
  </div>
</div></section>'''
    return page(s, "دسته‌بندی‌ها", body, "/categories", token=token, cats=cats)


# ------------------------------------------------------------------ home
def home(s, token=""):
    cats = db.category_tree()
    ci = _cat_icons()
    # Only shops that actually hold the `homepage` feature earn this strip.
    featured = db.annotate_open(db.homepage_businesses(limit=3))
    newest = db.annotate_open(db.businesses(order="newest", limit=3))
    deals = db.flashdeals(active_only=True)[:4] if s.get("deals_enabled") == "1" else []
    st = db.stats()
    n_parents = len(cats)
    n_children = sum(len(c.get("children") or []) for c in cats)

    # The front page shows ONLY the 4 most important groups (by live business
    # count) — the visitor sees a clean page, not 22 tiles. Everything else
    # stays one tap away behind «مشاهدهٔ همهٔ دسته‌ها». (Homepage declutter.)
    _sorted_cats = sorted(cats, key=lambda c: -(c.get("total") or 0))
    _top_cats, _rest_cats = _sorted_cats[:8], _sorted_cats[8:]

    def _cat_card(c, i):
        """v120: کارت تصویریِ بزرگ دسته روی صفحهٔ اصلی — هنرِ نئونی + نام + شمار
        (به سبک دسته‌های دیوار). فیلتر زندهٔ دسته (app.js) روی data-cat-search
        کار می‌کند و با این کارت‌ها هم سازگار است؛ زیرشاخه‌ها در /categories
        و /businesses می‌مانند."""
        kids = c.get("children") or []
        _search = " ".join([c["name"], c.get("blurb") or ""]
                           + [k["name"] for k in kids])
        return (f'<a class="h-catcard reveal" data-delay="{i*30}" '
                f'aria-label="{esc(c["name"])}" '
                f'data-cat-search="{esc(_search)}" '
                f'href="/businesses?cat={esc(c["slug"])}">'
                f'<span class="h-catcard-ic" aria-hidden="true">{cat_icon(c["icon"], 46)}</span>'
                f'<span class="h-catcard-name">{esc(c["name"])}</span>'
                f'<span class="h-catcard-nums">{fa(c["total"])} کسب‌وکار</span></a>')

    cat_tiles = "".join(_cat_card(c, i) for i, c in enumerate(_top_cats))
    rest_tiles = "".join(_cat_card(c, i) for i, c in enumerate(_rest_cats))

    if featured:
        feat_html = f'<div class="grid grid-3">' + "".join(
            biz_card(b, ci, i * 60) for i, b in enumerate(featured)) + '</div>'
    else:
        feat_html = empty_state("store", "هنوز کسب‌وکاری ثبت نشده",
            "اولین کسب‌وکار شهر را شما ثبت کنید — رایگان و کمتر از پنج دقیقه.",
            f'<a class="btn btn-primary mt-lg" href="/submit">{icon("plus")}<span>ثبت کسب‌وکار</span></a>')

    new_html = ""
    if newest:
        new_html = f'''<section class="section"><div class="container-wide">
          <div class="between mb-xl">{section_head("تازه‌ها", "به‌تازگی به شهر اضافه شدند",
            "جدیدترین کسب‌وکارهایی که به دست گیر پیوسته‌اند.", eyebrow_icon="zap")}
            <a class="btn btn-outline hide-mobile" href="/businesses?sort=newest">{icon("arrow-left")}<span>همه</span></a></div>
          <div class="grid grid-3">{"".join(biz_card(b, ci, i*60) for i, b in enumerate(newest))}</div>
        </div></section>'''

    offers_html = ""

    # latest news
    news = db.posts(limit=3) if s.get("blog_enabled") == "1" else []
    news_html = ""
    if news:
        cards = "".join(f'''<article class="card card-hover glass card-pad reveal" data-delay="{i*60}">
          <span class="badge badge-neutral">{icon("book")}<span>خبر شهر</span></span>
          <h3 class="card-title mt-md"><a href="/blog/{esc(p['slug'])}">{esc(p['title'])}</a></h3>
          <p class="card-desc">{esc(p['excerpt'])}</p>
          <a class="btn btn-ghost btn-sm mt-md" href="/blog/{esc(p['slug'])}">
            {icon("arrow-left")}<span>ادامه</span></a></article>''' for i, p in enumerate(news))
        news_html = f'''<section class="section"><div class="container-wide">
          <div class="between mb-xl">{section_head("اخبار شهر", "تازه‌ترین خبرها", eyebrow_icon="book")}
          <a class="btn btn-outline hide-mobile" href="/blog">{icon("arrow-left")}<span>همه</span></a></div>
          <div class="grid grid-3">{cards}</div></div></section>'''

    # Telling someone who is already signed in to "sign up" is noise; swap the
    # whole block for a shortcut into their panel instead.
    _me = ui_ctx_owner()
    if _me:
        cta_eyebrow = "خوش آمدید"
        cta_title = "پنل کسب‌وکار شما آمادهٔ کار است"
        cta_text = ("محصولات، تصاویر، ساعت کاری و نظرات مشتریان را از پنل خودتان "
                    "مدیریت کنید و ببینید چند نفر شمارهٔ شما را گرفته‌اند.")
        cta_buttons = (f'<a class="btn btn-primary btn-lg" href="/my">{icon("dashboard")}'
                       f'<span>رفتن به پنل دکان</span></a>'
                       f'<a class="btn btn-glass btn-lg" href="/my/businesses">{icon("store")}'
                       f'<span>کسب‌وکارهای من</span></a>')
    else:
        cta_eyebrow = "ویژهٔ صاحبان کسب‌وکار"
        cta_title = "دکان‌دار هستید؟ پنل خودتان را داشته باشید"
        cta_text = ("با شمارهٔ موبایل وارد شوید — بدون رمز عبور. سپس محصولات، تصاویر، "
                    "ساعت کاری و نظرات مشتریان را خودتان مدیریت کنید و ببینید چند نفر "
                    "شمارهٔ شما را گرفته‌اند.")
        cta_buttons = (f'<a class="btn btn-primary btn-lg" href="/login">{icon("user")}'
                       f'<span>ورود / ثبت‌نام دکان‌داران</span></a>'
                       f'<a class="btn btn-glass btn-lg" href="/submit">{icon("plus")}'
                       f'<span>ثبت کسب‌وکار</span></a>')

    perks_html = "".join(f'''<a class="feat-card reveal" href="{esc(h)}" data-delay="{i*40}">
      <span class="icon-wrap">{icon(ic)}</span>
      <strong>{esc(title)}</strong>
      <p>{esc(desc)}</p></a>''' for i, (h, title, ic, desc) in enumerate(OWNER_PERKS))

    hero_title = esc(s.get("hero_title", "")).replace("\n", "<br>")

    # ---------- v120: صفحهٔ اصلی با هویت «سبز زنده» (نئونی) ----------
    # هیرو و سطح‌های برند سبزِ پررنگ با متن سفید؛ بقیهٔ صفحه روشن با متن تیره.
    # دسته‌ها کارت‌های تصویریِ بزرگ شدند (به سبک دیوار)؛ باند استوری، تخفیف،
    # آمار و کارت‌های کسب‌وکار سر جایشان — فقط چیدمان و ظاهر نو شد.

    # «همین حالا باز هستند» — فقط واقعاً-بازها؛ وگرنه «ویژهٔ شهر» (وعدهٔ غلط نه).
    _open = [b for b in featured
             if (b.get("open_state") or {}).get("state") in ("open", "closing")]
    hero_open_title = "همین حالا باز هستند" if _open else "کسب‌وکارهای ویژهٔ شهر"
    mini = "".join(f'''<a class="hero-mini" href="/b/{esc(b['slug'])}">
      {cat_icon(ci.get(b['cat_slug'],'store'), 40)}
      <span class="hero-mini-txt"><span class="t">{esc(b['name'])}</span>
        <span class="s">{esc(b.get('address'))[:28]}</span></span>
      {open_badge(b, compact=True)}</a>''' for b in (_open or featured)[:3])
    if not mini:
        mini = f'<p class="text-sm text-muted">{esc("پس از ثبت اولین کسب‌وکارها، این بخش به‌صورت زنده پر می‌شود.")}</p>'

    ad_home = V2.ad_block("home", s)
    ad_home_html = f'<section class="section-sm"><div class="container-wide">{ad_home}</div></section>' if ad_home else ''

    body = f"""
<section class="h-hero">
  <div class="hero-visual is-static" aria-hidden="true"></div>
  <div class="container-wide h-hero-in">
    <div class="h-hero-copy">
      <span class="h-hero-badge"><span class="dot" aria-hidden="true"></span>{icon("sparkles")}
        <span>{fa_group(st['businesses'])} کسب‌وکار فعال</span></span>
      <h1>{hero_title}</h1>
      <p class="h-hero-lead">{esc(s.get('hero_lead'))}</p>
      <form class="h-hero-search" action="/businesses" method="get" role="search" data-live-search>
        <label class="sr-only" for="hero-q">جست‌وجوی کسب‌وکار</label>
        <span class="search-wrap">{icon("search", cls="search-icon")}
          <input class="input" id="hero-q" name="q" type="search"
                 placeholder="نام کسب‌وکار، صنف یا محله…" autocomplete="off"
                 aria-autocomplete="list" aria-controls="hero-sugg">
          <div class="live-sugg" id="hero-sugg" hidden></div></span>
        <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
      </form>
      <div class="h-hero-cta">
        <a class="btn btn-accent btn-lg" href="/submit">{icon("plus")}<span>{esc(s.get('hero_cta'))}</span></a>
        <a class="btn btn-glass btn-lg" href="/map">{icon("map")}<span>نقشهٔ شهر</span></a>
      </div>
      <div class="h-hero-trust">
        <span>{icon("shield")}کسب‌وکارهای تأییدشده</span>
        <span>{icon("clock")}ساعت کاری لحظه‌ای</span>
        <span>{icon("star")}نظرات واقعی مشتریان</span>
      </div>
    </div>
    <aside class="h-open glass" aria-label="{esc(hero_open_title)}">
      <div class="h-open-head">{icon("zap")}<span>{esc(hero_open_title)}</span></div>
      <div class="h-open-list">{mini}</div>
      <a class="btn btn-glass btn-block mt-md" href="/businesses">
        {icon("grid")}<span>مشاهدهٔ همهٔ کسب‌وکارها</span></a>
    </aside>
  </div>
</section>

<section class="section-sm"><div class="container-wide">
  <div class="h-stats" data-stagger>
    {stat_card("store", st['businesses'], "کسب‌وکار ثبت‌شده")}
    {stat_card("layers", st['categories'], "دستهٔ تخصصی", delay=70)}
    {stat_card("message", st['reviews'], "نظر ثبت‌شده", delay=140)}
    {stat_card("eye", st['views'], "بازدید کل", delay=210)}
  </div>
</div></section>

{ad_home_html}

{ f'''<section class="section-sm"><div class="container-wide">
  <div class="between mb-md">
    {section_head("تازه‌ها", "استوری کسب‌وکارها", "نگاه کوتاه به امروزِ دکان‌های شهر.", eyebrow_icon="image")}
  </div>
  <div class="stories-bar" data-stories-bar><div class="sk" style="width:62px;height:62px;border-radius:50%;flex:none"></div><div class="sk" style="width:62px;height:62px;border-radius:50%;flex:none"></div><div class="sk" style="width:62px;height:62px;border-radius:50%;flex:none"></div></div>
</div></section>''' if db.stories_active() else '' }

{ f'''<section class="section-sm"><div class="container-wide">
  <div class="between mb-md">
    {section_head("تخفیف‌های لحظه‌ای", "پیشنهادهای امروز", eyebrow_icon="zap")}
    <a class="btn btn-glass" href="/deals">{icon("zap")}<span>همهٔ پیشنهادها</span></a>
  </div>
  <div class="h-deals">''' + "".join(f'''<article class="h-deal card glass card-pad reveal" data-delay="{i*50}">
    <div class="between" style="align-items:flex-start"><div>
      <span class="badge badge-accent">{icon("zap")}<span>{fa(d["percent"])}٪ تخفیف</span></span>
      <h3 class="card-title mt-sm">{esc(d["title"])}</h3></div>
      <span class="deal-countdown" data-countdown="{esc(d['ends'])}"></span></div>
    <div class="mt-md"><a class="btn btn-primary btn-sm" href="/b/{esc(d['bizslug'])}">{icon("store")}<span>{esc(d["bizname"])}</span></a></div>
  </article>''' for i, d in enumerate(deals)) + '</div></div></section>' if deals else '' }

<section class="section"><div class="container-wide">
  {section_head("دسته‌بندی‌ها",
    f"همهٔ {fa(n_parents + n_children)} دستهٔ تخصصی در ایران",
    f"{fa(n_parents)} گروه اصلی و {fa(n_children)} صنف تخصصی زیر آن‌ها — روی هر گروه بزنید تا زیرشاخه‌هایش باز شود.",
    center=True, eyebrow_icon="layers")}
  <div class="cat-search" data-cat-searchbox>
    <span class="search-wrap">{icon("search", cls="search-icon")}
      <label class="sr-only" for="cat-q">جست‌وجوی دسته</label>
      <input class="input" id="cat-q" type="search" data-cat-search-input
             placeholder="نام صنف را بنویسید… مثلاً «کباب» یا «دندان»"
             autocomplete="off">
    </span>
  </div>
  <div class="h-cat-grid" data-cat-grid>{cat_tiles}</div>
  <details class="more-cats mt-lg" {" open" if len(_rest_cats) == 0 else ""} data-cat-more>
    <summary class="btn btn-glass">
      {icon("grid")}<span>مشاهدهٔ همهٔ دسته‌ها ({fa(len(_rest_cats))} گروه دیگر)</span>
    </summary>
    <div class="h-cat-grid mt-md">{rest_tiles}</div>
  </details>
  <p class="text-center text-sm text-muted mt-lg" data-cat-empty hidden>
    دسته‌ای با این نام پیدا نشد — عبارت دیگری امتحان کنید.
  </p>
  <div class="text-center mt-xl"><a class="btn btn-ghost" href="/categories">
    {icon("layers")}<span>مرور همهٔ {fa(n_parents + n_children)} صنف تخصصی</span></a></div>
</div></section>

<section class="section"><div class="container-wide">
  <div class="between mb-xl">
    {section_head("پرمخاطب‌ترین‌ها", "کسب‌وکارهای ویژهٔ شهر",
      "پرامتیازترین کسب‌وکارهای ایران بر اساس نظر شهروندان.", eyebrow_icon="award")}
    <a class="btn btn-outline hide-mobile" href="/businesses">{icon("arrow-left")}<span>همه</span></a>
  </div>
  {feat_html}
</div></section>

<section class="section-sm" id="recent-wrap" hidden>
  <div class="container-wide">
    {section_head("بازدیدهای اخیر", "همین‌جا ادامه بدهید", eyebrow_icon="clock")}
    <div class="hscroll" id="recent-row"></div>
  </div>
</section>

{new_html}
{news_html}

<section class="section"><div class="container-wide">
  <div class="between mb-xl">
    {section_head("امکانات دکان‌داران", "با ثبت دکان چه چیزی می‌گیرید؟",
      "همهٔ ابزارهایی که برای دیده‌شدن و ارتباط با مشتریان نیاز دارید.", eyebrow_icon="zap")}
    <a class="btn btn-outline hide-mobile" href="/features">{icon("arrow-left")}<span>همهٔ امکانات</span></a>
  </div>
  <div class="grid grid-3">
    {perks_html}
  </div>
</div></section>

<section class="section"><div class="container-wide">
  <div class="owner-cta reveal">
    <div class="owner-cta-main">
      <span class="eyebrow">{icon("store")}<span>{esc(cta_eyebrow)}</span></span>
      <h2>{esc(cta_title)}</h2>
      <p>{esc(cta_text)}</p>
      <div class="cluster mt-lg">{cta_buttons}</div>
    </div>
  </div>
</div></section>

<section class="section"><div class="container-wide">
  <div class="cta-band reveal">
    <h2>کسب‌وکار شما هنوز اینجا نیست؟</h2>
    <p>همین امروز رایگان ثبت کنید و در معرض دید هزاران شهروند در سراسر ایران قرار بگیرید.</p>
    <div class="cluster">
      <a class="btn btn-accent btn-lg" href="/submit">{icon("plus")}<span>ثبت رایگان کسب‌وکار</span></a>
      <a class="btn btn-glass btn-lg" href="/pricing">{icon("tag")}<span>مشاهدهٔ تعرفه‌ها</span></a>
    </div></div></div></section>
"""
    base = (s.get("site_url") or "").strip().rstrip("/")
    if base and not base.startswith(("http://", "https://")):
        base = "https://" + base
    head_extra = ""
    if s.get("seo_schema") == "1":
        head_extra = V2.jsonld(db.jsonld_org(s, base), db.jsonld_website(s, base))
    return page(s, "خانه", body, "/", token=token, cats=cats,
                extra_head=head_extra,
                extra_js='<script type="module" src="/assets/js/countdown.js?v109"></script>')


# ------------------------------------------------------------------ list
PER_PAGE = 24


def businesses(s, q="", cat="", sort="featured", token="", pg_no=1, open_now=False, city=None, frag=False):
    cats = db.category_tree()
    ci = _cat_icons()
    # search() sorts by the raw featured column; strip the badge from any shop
    # whose promotion has lapsed so the list never advertises an expired plan.
    all_rows = db.annotate_open(
        db.apply_promotion(db.search(term=q, cat=cat, sort=sort, open_now=open_now,
                                     city=city)))
    total = len(all_rows)
    pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    pg_no = max(1, min(pg_no, pages))
    rows = all_rows[(pg_no - 1) * PER_PAGE: pg_no * PER_PAGE]
    cur = db.category(cat) if cat else None

    path = db.category_path(cat) if cat else []
    branch = path[0]["slug"] if path else ""

    def _n(v):
        return f'<small class="chip-n nums">{fa(v)}</small>' if v else ""

    # v150: category chips appear only on the UNFILTERED list (همه + the 22
    # groups).  Once a category is chosen the fold holds just real filters
    # (sort, open-now) -- no category chips at all: the label says "فیلتر"
    # and switching category is done via breadcrumb/banner/back, not here.
    if not cat:
        chips = (f'<a class="chip is-active" href="/businesses">'
                 f'{icon("grid")}<span>همه</span></a>')
        for c in cats:
            chips += (f'<a class="chip" href="/businesses?cat={esc(c["slug"])}">'
                      f'{cat_icon(c["icon"], 16)}'
                      f'<span>{esc(c["name"])}</span>{_n(c["total"])}</a>')
    else:
        chips = ""

    banner = ""
    if cur:
        if len(path) > 1:
            crumb = (f'<a class="badge badge-neutral" href="/businesses?cat={esc(path[0]["slug"])}">'
                     f'{icon("arrow-left")}<span>{esc(path[0]["name"])}</span></a>')
        else:
            crumb = (f'<a class="badge badge-neutral" href="/categories">'
                     f'{icon("layers")}<span>همهٔ دسته‌ها</span></a>')
        banner = f'''<div class="cat-banner reveal">
          {cat_icon(cur['icon'], 128, "art")}
          <div>{crumb}
            <h1 class="mt-sm">{esc(cur['name'])}</h1><p>{esc(cur['blurb'])}</p>
            <div class="cluster mt-md"><span class="badge badge-info">{icon("store")}
              <span>{fa(total)} کسب‌وکار</span></span></div></div></div>'''

    pager = ""
    if pages > 1:
        def plink(n):
            p = {"q": q, "cat": cat, "sort": sort, "page": n}
            return "/businesses?" + _urlencode({k: v for k, v in p.items() if v})
        nums = ""
        for n in range(1, pages + 1):
            if n == 1 or n == pages or abs(n - pg_no) <= 2:
                nums += (f'<span class="pg-cur">{fa(n)}</span>' if n == pg_no
                         else f'<a href="{plink(n)}">{fa(n)}</a>')
            elif abs(n - pg_no) == 3:
                nums += '<span class="pg-gap">…</span>'
        pager = f'''<nav class="pager" aria-label="صفحه‌بندی">
          {f'<a href="{plink(pg_no-1)}">{icon("chevron-right")}<span>قبلی</span></a>' if pg_no > 1 else ""}
          {nums}
          {f'<a href="{plink(pg_no+1)}"><span>بعدی</span>{icon("chevron-left")}</a>' if pg_no < pages else ""}
        </nav>'''

    if rows:
        grid = ('<div class="grid grid-3" data-dir-grid>' +
                "".join(biz_card(b, ci, (i % 6) * 55) for i, b in enumerate(rows)) +
                '</div>' + pager)
        empty = ""
    else:
        grid = '<div class="grid grid-3" data-dir-grid hidden></div>'
        empty = empty_state("search", "کسب‌وکاری یافت نشد",
            "با این فیلترها نتیجه‌ای نبود. عبارت جست‌وجو یا دسته را تغییر دهید." if (q or cat)
            else "هنوز کسب‌وکاری در این بخش ثبت نشده است.",
            f'<a class="btn btn-primary mt-lg" href="/businesses">{icon("refresh")}<span>نمایش همه</span></a>')

    opts = "".join(f'<option value="{v}"{" selected" if sort==v else ""}>{t}</option>'
                   for v, t in [("featured","ویژه‌ها اول"),("rating","بیشترین امتیاز"),
                                ("newest","جدیدترین"),("name","حروف الفبا"),("views","پربازدیدترین")])

    # v120: بخش نتایج یکپارچه — هم در صفحهٔ کامل و هم در حالت frag (جستجوی
    # زندهٔ سمت کلاینت) دقیقاً همین یک قطعه رندر میشود؛ هیچ دوگانهای نیست.
    ad_dir = V2.ad_block("directory", s)
    ad_dir_html = f'<div class="mb-lg">{ad_dir}</div>' if ad_dir else ''

    results_html = f'''<div class="dir-meta">
      <span><strong class="nums" data-dir-count>{fa(total)}</strong> کسب‌وکار
        {f'· صفحهٔ {fa(pg_no)} از {fa(pages)}' if pages > 1 else ''}</span>
      <span>{icon("info")} ساعت کاری به‌صورت زنده محاسبه می‌شود</span>
    </div>
    {ad_dir_html}
    {grid}
    <div data-dir-empty {"hidden" if rows else ""}>{empty}</div>'''

    if frag:
        return results_html

    body = f'''
<div class="container-wide">
  {breadcrumb(("کسب‌وکارها", "/businesses")) if not cur else breadcrumb(("کسب‌وکارها", "/businesses"), (cur["name"], None))}
  {banner or f"""<header class="page-hero dir-hero">
    <h1>{esc(cur["name"]) if cur else ("کسب‌وکارهای " + esc(city) if city else "کسب‌وکارهای ایران")}</h1>
    <p>{fa(len(rows))} کسب‌وکار در {fa(len(cats))} دستهٔ تخصصی.
       جست‌وجو کنید و بهترین گزینه را پیدا کنید.</p></header>"""}
</div>
<section class="section-sm" data-directory>
  <div class="container-wide">
    <form class="dir-toolbar" method="get" action="/businesses" data-live-search>
      <input type="hidden" name="cat" value="{esc(cat)}">
      <div class="dir-row">
        <span class="search-wrap">{icon("search", cls="search-icon")}
          <label class="sr-only" for="dq">جست‌وجو</label>
          <input class="input" id="dq" name="q" type="search" value="{esc(q)}"
                 data-dir-search placeholder="نام، دسته، محله یا خدمت…" autocomplete="off"
                 aria-autocomplete="list">
          <div class="live-sugg" hidden></div></span>
        <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
      </div>
      <!-- city filter (Divar-style): shows the active city + quick change -->
      <div class="dir-citybar">
        <a class="chip city-chip{" is-active" if city else ""}" href="/cities">
          {icon("pin")}<span>{esc(city) if city else "همهٔ شهرها"}</span>
        </a>
        {f'<a class="chip" href="/businesses?q={esc(q)}&cat={esc(cat)}">{icon("x")}<span>حذف فیلتر شهر</span></a>' if city else ''}
      </div>

      <!-- Sort, "open now" and the 22 category chips are secondary: you
           reach for them AFTER seeing results, not before. Keeping them
           permanently expanded pushed the first shop to y=858 on a 360px
           screen -- a whole screen of furniture before the answer. Desktop
           CSS (>=861px) forces the body visible anyway; on a phone the fold
           stays closed until the user asks for it -- v146 no auto-open, so
           landing on a category no longer lands on a wall of chips. -->
      <details class="dir-filters" data-dir-filters>
        <summary>
          {icon("filter")}<span>{"فیلتر" if cat else "فیلتر و دسته‌بندی"}</span>
          {f'<span class="filter-count nums">{fa(sum([bool(cat), bool(open_now), sort != "featured"]))}</span>'
             if (cat or open_now or sort != "featured") else ''}
        </summary>
        <div class="dir-filters-body">
          <div class="dir-row">
            <label class="sr-only" for="dsort">مرتب‌سازی</label>
            <select class="select" id="dsort" name="sort" data-dir-sort
                    >{opts}</select>
            <label class="check"><input type="checkbox" name="open" value="1"
              data-dir-open{" checked" if open_now else ""}><span>فقط باز</span></label>
          </div>
          {f'<div class="dir-chips" data-chips>{chips}</div>'
             f'<button class="chips-more" type="button" data-chips-more aria-expanded="false" hidden>'
             f'{icon("chevron-down")}<span>همهٔ دسته‌ها</span></button>' if chips else ''}
        </div>
      </details>
    </form>
    <div class="between" style="gap:8px;margin-top:10px">
      <div class="saved-chips" id="saved-chips" hidden></div>
      <button class="btn btn-glass btn-sm" type="button" id="save-search" data-save-search
              aria-label="ذخیرهٔ این جست‌وجو" style="flex:none">{icon("bookmark")}<span>ذخیرهٔ جست‌وجو</span></button>
    </div>
    <div data-dir-results>{results_html}</div>
  </div>
</section>'''
    title = cur["name"] if cur else "کسب‌وکارها"
    return page(s, title, body, "/businesses", token=token, cats=cats)


# ------------------------------------------------------------------ detail
def business(s, slug, token="", q=None, cust=None):
    b = db.business(slug=slug)
    if not b:
        return None
    q = q or {}
    msg = ""
    if q.get("ok"):
        msg = flash("ok", q["ok"][0])
    elif q.get("err"):
        msg = flash("err", q["err"][0])
    elif q.get("booked"):
        msg = flash("ok", "درخواست نوبت شما ثبت شد. به‌زودی تماس می‌گیریم.")
    cats = db.category_tree()
    ci = _cat_icons()
    # v114: view counting moved to server/analytics.py (the send() hook) so
    # bots/crawlers can no longer inflate a shop's counter and every view is
    # recorded with the real visitor's IP + visitor cookie.
    cat = db.category(b["cat_slug"]) or {"name": b["cat_slug"], "icon": "store"}
    revs = db.reviews(biz_id=b["id"], status="approved")

    badges = ""
    if b["featured"]:
        badges += f'<span class="badge badge-featured">{icon("sparkles")}<span>ویژه</span></span>'
    if b["verified"]:
        badges += f'<span class="badge badge-info">{icon("shield")}<span>تأییدشده</span></span>'
    # follow button (Instagram-style) — visible to everyone, requires login to act
    if s.get("follow_enabled") == "1":
        _nfollow = db.follow_count(b["id"])
        _customer = ui_ctx_customer()
        _follow_on = bool(_customer and db.follow_state(_customer["id"], b["id"]))
        badges += (f'<button class="badge follow-btn{" is-on" if _follow_on else ""}" '
                   f'type="button" data-follow data-biz="{b["id"]}" '
                   f'aria-pressed="{str(_follow_on).lower()}">{icon("heart")}'
                   f'<span>{"دنبال می‌کنید" if _follow_on else "دنبال کردن"}</span>'
                   f'<small class="nums" data-follow-count>({fa(_nfollow)})</small></button>')
    # the shop's own stories, right in the header (Instagram-style ring)
    if s.get("stories_enabled") == "1" and b.get("has_story"):
        _ns = len(db.stories_for_biz(b["id"]))
        badges += (f'<button class="badge story-btn" type="button" data-story-biz="{esc(slug)}">'
                   f'{icon("image")}<span>استوری</span>'
                   f'<small class="nums">({fa(_ns)})</small></button>')
    # v177: پيوند «تاریخچه» — همهٔ استوری‌های گذشته و حالا، با هر تاریخ
    if s.get("stories_enabled") == "1" and db.stories_for_biz(b["id"], active_only=False):
        badges += (f'<a class="badge story-btn" href="/b/{esc(slug)}/stories">'
                   f'{icon("clock")}<span>تاریخچه</span></a>')
    tags = "".join(f'<span class="badge badge-neutral">{esc(t)}</span>' for t in b["tag_list"])

    def _rev_html(r):
        _st = (f'{stars(r["rating"])}<span class="nums">{fa(round(r["rating"], 1))}</span>'
               if (r.get("rating") or 0) > 0
               else '<span class="text-xs text-muted">نظر بدون امتیاز</span>')
        _img = f'<img class="review-img" src="{esc(r["image"])}" alt="عکس نظر" loading="lazy">' if r.get("image") else ''
        _rep = (f'<div class="review-reply"><strong>{icon("store")}پاسخ {esc(b["name"])}</strong>{esc(r["reply"])}</div>'
                if r["reply"] else '')
        return f'''<article class="review">
      <div class="review-head"><span class="avatar" aria-hidden="true">{esc(r["author"][:1])}</span>
        <div><strong>{esc(r["author"])}</strong>
          <div class="card-meta" style="margin-top:3px">{_st}</div></div></div>
      <p class="review-body">{esc(r["body"])}</p>
      {_img}
      {_rep}
      <button class="review-helpful" type="button" data-helpful data-id="{r["id"]}" aria-pressed="false">
        {icon("heart")}<span class="nums">{fa(r.get("helpful") or 0)}</span><span>مفید بود</span></button>
    </article>'''
    rv = "".join(_rev_html(r) for r in revs)
    if not rv:
        rv = f'<p class="text-sm text-muted">{esc("هنوز نظری ثبت نشده. اولین نفر باشید!")}</p>'

    DAYS = [("sat","شنبه"),("sun","یک‌شنبه"),("mon","دوشنبه"),("tue","سه‌شنبه"),
            ("wed","چهارشنبه"),("thu","پنج‌شنبه"),("fri","جمعه")]
    hm = b["hours_map"]
    hours_rows = ""
    today_key = db.DAY_KEYS[db.iran_now().weekday()]
    for k, label in DAYS:
        v = hm.get(k)
        if not v:
            txt = "تعطیل"
        else:
            # Persian digits here too — a row of Latin numerals in an
            # otherwise Persian table reads as a rendering fault.
            txt = " و ".join(f"{fa(a)}–{fa(z)}" for a, z in v)
        # mark today's row so the eye lands on the line that matters
        cls = ' class="is-today"' if k == today_key else ''
        hours_rows += (f'<tr{cls}><td class="d">{label}'
                       + ('<span class="today-tag">امروز</span>' if k == today_key else '')
                       + f'</td><td class="h">{esc(txt)}</td></tr>')

    dist = ""
    if b["lat"] and b["lng"]:
        dist = f'''<a class="btn btn-glass btn-block mt-md"
          data-track="route" data-slug="{esc(slug)}"
          href="https://www.google.com/maps/dir/?api=1&destination={b['lat']},{b['lng']}"
          target="_blank" rel="noopener">{icon("compass")}<span>مسیریابی</span></a>'''

    map_block = f'''<div class="map-stage" data-map-wrap data-map="pending" style="min-height:230px;border-radius:var(--radius-md)">
        <div data-map-canvas data-lat="{b['lat'] or ''}" data-lng="{b['lng'] or ''}"
             data-title="{esc(b['name'])}" style="position:absolute;inset:0"></div>
      </div>''' if (b["lat"] and b["lng"]) else \
      f'<p class="text-sm text-muted">{esc("موقعیت روی نقشه ثبت نشده است.")}</p>'

    booking = ""
    if b["booking_on"] and s.get("booking_enabled") == "1":
        booking = f'''<div class="card glass card-pad reveal" id="booking">
      <h3 class="card-title mb-md">{icon("calendar")} رزرو نوبت آنلاین</h3>
      <form method="post" action="/b/{esc(slug)}/book" data-validate>
      <span style="position:absolute;left:-9999px;top:-9999px;height:0;overflow:hidden" aria-hidden="true">
        <label for="hp">وب‌سایت</label><input id="hp" type="text" name="website_hp" tabindex="-1" autocomplete="off"></span>

        <div class="field"><label class="field-label" for="bk-name">نام و نام خانوادگی<span class="req">*</span></label>
          <input class="input" id="bk-name" name="name" required minlength="3"></div>
        <div class="field"><label class="field-label" for="bk-phone">شمارهٔ تماس<span class="req">*</span></label>
          <input class="input" id="bk-phone" name="phone" type="tel" required pattern="0[0-9]{{10}}"
                 placeholder="09123456789" data-msg-pattern="شمارهٔ موبایل باید ۱۱ رقم و با ۰۹ شروع شود."></div>
        <div class="grid grid-2" style="gap:0 var(--space-md)">
          <div class="field"><label class="field-label" for="bk-date">تاریخ (شمسی)<span class="req">*</span></label>
            <span class="jd jd-has-ico" data-jd>
              <input class="input nums" id="bk-date" type="text" required
                     placeholder="۱۴۰۴/۰۶/۲۲" autocomplete="off" inputmode="numeric"
                     aria-label="تاریخ نوبت (شمسی)">
              <input type="hidden" name="date" data-jd-target>
              <span class="jd-ico" aria-hidden="true">{icon("calendar")}</span>
            </span>
          </div>
          <div class="field"><label class="field-label" for="bk-time">ساعت<span class="req">*</span></label>
            <input class="input" id="bk-time" name="time" type="time" required></div>
        </div>
        <div class="field"><label class="field-label" for="bk-note">توضیحات</label>
          <textarea class="textarea" id="bk-note" name="note" style="min-height:80px"></textarea></div>
        <button class="btn btn-primary btn-block" type="submit">{icon("check")}<span>ثبت درخواست نوبت</span></button>
      </form></div>'''

    socials = ""
    for key, ic, label in (("instagram","instagram","اینستاگرام"),
                           ("telegram","telegram","تلگرام"),("website","globe","وب‌سایت")):
        if b.get(key):
            socials += f'<a class="btn btn-glass btn-sm" href="{esc(b[key])}" target="_blank" rel="noopener">{icon(ic)}<span>{label}</span></a>'

    import views_catalog as _C
    prices_on = s.get("prices_enabled") == "1"
    catalog_html = (_C.catalog_section(b, prices_on=prices_on)
                    if s.get("catalog_enabled") == "1" else "")
    # where this shop's prices sit against the rest of town
    price_ctx = V2.price_context_block(b["id"]) if prices_on else ""

    # ---- v3 blocks
    badge_html = V2.badge_strip(b["id"])
    # v158: مقیاس شش‌ستاره‌ای — برچسب هر ستاره بالای کادر امتیاز می‌نشیند
    RATING_LABELS = ("خیلی بد", "بد", "متوسط", "خوب", "خیلی خوب", "عالی")
    # v151: criteria are facility-based (V2.criteria_block) and stars are
    # only offered to a signed-in non-owner; guests write text-only reviews.
    _rev_owner_ph = db.business_owner_phone(b["id"])
    _rev_owner = bool(cust and _rev_owner_ph and cust.get("phone") == _rev_owner_ph)
    _rev_in = bool(cust and not _rev_owner)
    _rev_name = esc((cust.get("name") or "").strip()) if _rev_in else ""
    _live_box = ('<div class="live-score" data-live-score hidden role="status" aria-live="polite">'
                 '<span class="field-hint">امتیاز شما: <strong data-live-val>&ndash;</strong></span></div>')
    crit_html = V2.criteria_block(b["id"]) if s.get("multicriteria") == "1" else ""
    if _rev_in and s.get("multicriteria") == "1":
        crit_inputs = V2.criteria_inputs(b["id"]) + _live_box
    elif _rev_in:
        _stars6 = "".join(f'<button type="button" data-v="{i}" aria-pressed="false" '
                          f'aria-label="{fa(i)} از ۶">{icon("star")}</button>'
                          for i in range(1, 7))
        crit_inputs = (f'<div class="field"><span class="field-label">امتیاز شما</span>'
                       f'<div class="rating-box">'
                       f'<div class="rating-label" data-rating-label>یک ستاره انتخاب کنید</div>'
                       f'<div class="rating-input" data-rating-input>'
                       f'<input type="hidden" name="rating" value="">{_stars6}</div></div></div>'
                       + _live_box)
    else:
        crit_inputs = ""
    qa_html = V2.qa_block(s, b)
    report_html = V2.report_block(s, b)
    ad_html = V2.ad_block("business", s)
    sub = db.subscription_of(b["id"])
    plan_badge = ""
    if sub and sub.get("planname"):
        p_ = db.plan(slug=sub["plan_slug"])
        if p_ and p_["price"] > 0:
            plan_badge = (f'<span class="badge badge-featured">{icon("award")}'
                          f'<span>عضو {esc(sub["planname"])}</span></span>')

    ld = ""
    if s.get("seo_schema") == "1":
        # Absolute URLs in structured data: Google rejects relative URLs, so
        # use site_url when configured (the same rule as the og:image below).
        base = (s.get("site_url") or "").strip().rstrip("/")
        if base and not base.startswith(("http://", "https://")):
            base = "https://" + base
        # E-Commerce SEO: each catalogue item on the page becomes a Product
        # entity so its price/availability can surface in rich results.
        prod = [db.jsonld_product(it, b, base)
                for it in db.items(biz_id=b["id"], only_available=False)
                if it.get("kind") in ("product", "custom")][:20]
        ld = V2.jsonld(
            db.jsonld_business(b, base),
            db.jsonld_breadcrumb([("خانه", "/"), ("کسب‌وکارها", "/businesses"),
                                  (cat["name"], f"/businesses?cat={b['cat_slug']}"),
                                  (b["name"], f"/b/{b['slug']}")], base),
            db.jsonld_faq(db.questions(biz_id=b["id"], status="published")),
            *prod)

    # real photographs replace the placeholder icon once the owner uploads any
    photos = b["images"]
    if photos:
        hero_art = (f'<img class="art photo" src="{esc(photos[0])}" '
                    f'alt="{esc(b["name"])}" width="160" height="160">')
        thumbs = "".join(
            f'<button type="button" data-gallery-thumb aria-current="{str(i==0).lower()}" '
            f'aria-label="تصویر {fa(i+1)}">'
            f'<img src="{esc(src)}" alt="نمای {fa(i+1)} از {esc(b["name"])}" loading="lazy">'
            f'</button>' for i, src in enumerate(photos))
        gallery_html = f'''<section class="card glass card-pad reveal" data-gallery>
        <h2 class="card-title mb-lg">{icon("image")} گالری تصاویر</h2>
        <div class="gallery-main photo">
          <img data-gallery-main src="{esc(photos[0])}" alt="{esc(b["name"])}"></div>
        {f'<div class="gallery-thumbs">{thumbs}</div>' if len(photos) > 1 else ''}
      </section>'''
    else:
        hero_art = cat_icon(cat['icon'], 128, 'art')
        gallery_html = ""
    n_items = db.items_count(b["id"])
    # v150: the owner must not be offered a chat with their own shop.
    _own = bool(cust and b.get("owner_id") and
                db.business_owner_phone(b["id"]) == (cust.get("phone") or ""))
    ask_btn = ("" if _own else
               f'<a class="btn btn-glass" href="/b/{esc(slug)}/chat">{icon("message")}<span>گفتگو با دکان‌دار</span></a>'
               if s.get("chat_enabled") == "1" else "")

    body = f'''
<div class="container-wide">
  {breadcrumb(("کسب‌وکارها","/businesses"), (cat["name"], f"/businesses?cat={b['cat_slug']}"), (b["name"], None))}
  {msg}
  <div class="biz-hero reveal{" has-cover" if b.get("cover") else ""}"
       {f'style="--cover:url({b["cover"]})"' if b.get("cover") else ''}>
    {hero_art}
    <div style="flex:1;min-width:min(100%,280px)">
      <div class="cluster">{badges}{plan_badge}
        {open_badge(b)}</div>
      <h1 class="mt-sm">{esc(b['name'])}</h1>
      <div class="card-meta">
        {f'{stars(b["rating"])}<strong class="nums">{fa(round(b["rating"], 1))}</strong><span>از {fa(b.get("nrated") or 0)} امتیاز</span>'
           if (b.get("nrated") or 0) else '<span class="text-sm text-muted">هنوز امتیازی ثبت نشده</span>'}
        <span aria-hidden="true">·</span><span>{esc(cat['name'])}</span>
        <span aria-hidden="true">·</span>{icon("eye")}<span>{fa_group(b['views'])} بازدید</span></div>
      <p class="sub">{esc(b['descr'])}</p>
      <div class="cluster mt-md">{tags}</div>
      {badge_html}
    </div>
    <div class="cluster" style="flex-direction:column;align-items:stretch;min-width:min(100%,200px)">
      {f'<a class="btn btn-primary" href="tel:{esc(b["phone"])}" data-track="phone" data-slug="{esc(slug)}">{icon("phone")}<span>تماس</span></a>' if b['phone'] else ''}
      {f'<a class="btn btn-accent" href="https://wa.me/{esc(b["whatsapp"])}" rel="noopener" target="_blank" data-track="whatsapp" data-slug="{esc(slug)}">{icon("whatsapp")}<span>واتساپ</span></a>' if b['whatsapp'] else ''}
      <button class="btn btn-glass favorite-action" type="button" data-fav="{esc(slug)}"
              data-fav-name="{esc(b['name'])}" aria-pressed="false"
              aria-label="علاقه‌مندی: {esc(b['name'])}">
        {icon("heart")}<span data-fav-label>علاقه‌مندی</span></button>
      {ask_btn}
      <!-- The three things a person on a phone actually does with a shop's
           details once they have found it. Measured before building: none
           of the three existed, so every one of them was a manual chore. -->
      <div class="quick-acts">
        {f"""<button class="qa-btn" type="button" data-copy-phone="{esc(b["phone"])}">
          {icon("copy")}<span>کپی شماره</span></button>""" if b["phone"] else ""}
        <button class="qa-btn" type="button" data-share="{esc(b['name'])}"
          data-track="share" data-slug="{esc(slug)}">
          {icon("share")}<span>ارسال برای دوست</span></button>
        <a class="qa-btn" href="/vcard/{esc(slug)}"
          data-track="save" data-slug="{esc(slug)}">
          {icon("user")}<span>ذخیره در مخاطبین</span></a>
      </div>
    </div>
  </div>

  <div class="biz-layout">
    <div>
      {gallery_html}

      <section class="card glass card-pad{" mt-lg" if photos else ""} reveal">
        <h2 class="card-title mb-lg">{icon("info")} دربارهٔ این کسب‌وکار</h2>
        <p class="text-muted text-sm">{esc(b['descr'])}</p>
        <div class="grid grid-2 mt-lg">
          <div class="info-row">{icon("pin")}<span class="k">نشانی</span><span class="v">{esc(b['address'])}</span></div>
          <div class="info-row">{icon("phone")}<span class="k">تلفن</span><span class="v nums">{esc(b['phone'])}</span></div>
          <div class="info-row">{icon("layers")}<span class="k">دسته</span><span class="v">{esc(cat['name'])}</span></div>
          <div class="info-row">{icon("calendar")}<span class="k">ثبت</span><span class="v">{esc(jdate(b['created']))}</span></div>
        </div>
        {f'<div class="cluster mt-lg">{socials}</div>' if socials else ''}
      </section>

      {catalog_html}

      {ad_html}

      <section class="card glass card-pad mt-lg reveal">
        <h2 class="card-title mb-lg">{icon("star")} نظرات مشتریان</h2>
        {crit_html}
        {rv}
        <hr class="divider">
        <h3 class="card-title mb-lg">{icon("edit")} نظر خود را بنویسید</h3>
        {'' if _rev_owner else f'''<p class="guest-note" role="note">برای ثبت <b>امتیاز</b> ابتدا <b>وارد شوید</b> — نظرِ بدون ستاره هم پذیرفته است و پس از بررسی منتشر می‌شود.</p>''' if not _rev_in else ''}
        {f'''<form method="post" action="/b/{esc(slug)}/review" enctype="multipart/form-data" data-validate>
        <span style="position:absolute;left:-9999px;top:-9999px;height:0;overflow:hidden" aria-hidden="true">
        <label for="hp">وب‌سایت</label><input id="hp" type="text" name="website_hp" tabindex="-1" autocomplete="off"></span>

        {crit_inputs}
        <div class="field"><label class="field-label" for="rv-name">نام شما<span class="req">*</span></label>
          <input class="input" id="rv-name" name="author" value="{_rev_name}" required minlength="3" maxlength="60"></div>
        <div class="field"><label class="field-label" for="rv-text">متن نظر<span class="req">*</span></label>
          <textarea class="textarea" id="rv-text" name="body" required minlength="12" maxlength="1500"></textarea>
          <p class="field-hint">نظر شما پس از بررسی منتشر می‌شود.</p></div>
        <div class="field"><label class="field-label" for="rv-img">عکس (اختیاری)</label>
          <input class="input" id="rv-img" type="file" name="review_image" accept="image/*" capture="environment">
          <p class="field-hint">یک عکس از محصول یا تجربه‌تان.</p></div>
        <button class="btn btn-primary" type="submit">{icon("send")}<span>ثبت نظر</span></button>
        </form>''' if not _rev_owner else '<p class="text-sm text-muted">این کسب‌وکار متعلق به شماست؛ برای نظر دادن باید از حساب دیگری وارد شوید. پاسخ به نظرها از بخش «نظرات» در مدیریت کسب‌وکار در دسترس است.</p>'}
      </section>

      {price_ctx}
      {qa_html}
      {report_html}
    </div>

    <aside class="biz-aside">
      <div class="card glass card-pad reveal">
        <h3 class="card-title mb-md">{icon("clock")} ساعت کاری</h3>
        {open_line(b)}
        <table class="hours-table"><tbody>{hours_rows}</tbody></table>
      </div>
      {booking}
      <div class="card glass card-pad reveal">
        <h3 class="card-title mb-md">{icon("map")} موقعیت روی نقشه</h3>
        {map_block}
        <p class="text-xs text-muted mt-md">{esc(b['address'])}</p>
        {dist}
      </div>
    </aside>
  </div>
</div>
{ld}'''
    extra = (MAP_JS
             + '<script type="module" src="/assets/js/qa.js?v158"></script>'
             + '<script type="module" src="/assets/js/social.js?v109"></script>')
    # social share image: when the link is shared on Telegram/WhatsApp the
    # shop's own photo shows instead of a bare title
    og = ""
    img = (b.get("images") or [""])[0]
    if img:
        base = (s.get("site_url") or "").strip().rstrip("/")
        if base and not base.startswith(("http://", "https://")):
            base = "https://" + base
        src = f"{base}{img}" if base else img
        og = (f'<meta property="og:image" content="{esc(src)}">\n'
              f'<meta name="twitter:card" content="summary_large_image">\n')
    # v145: the Jalali date picker (booking form) loads only when it is used
    if booking:
        extra += ('<script type="module" src="/assets/js/jdatepicker.js?v145"></script>')
        og += '<link rel="stylesheet" href="/assets/css/jdatepicker.css?v145">\n'
    return page(s, b["name"], body, "/businesses", desc=b["descr"],
                token=token, cats=cats, extra_js=extra, extra_head=og,
                body_class=f'biz-page has-callbar" data-biz-slug="{esc(slug)}')


# ------------------------------------------------------------- story archive
def biz_stories(s, slug, token=""):
    """v177: صفحهٔ عمومی «تاریخچهٔ استوری‌ها» — همهٔ استوری‌های گذشته و حالا
    یک دکان با تاریخ شمسی؛ هم مشتری می‌بیند هم دکاندار. پخش با همان ویوِر
    استوری سایت (stories.js) و شمارش بازدیدِ واقعیِ یکتا همان مسیر است."""
    b = db.business(slug=slug)
    if not b or b["status"] != "published" or s.get("stories_enabled") != "1":
        return None
    rows = db.stories_for_biz(b["id"], active_only=False)
    _now = time.time()

    def _exp(r):
        try:
            return float(r["expires"] or 0)
        except (TypeError, ValueError):
            return 0.0
    items = [{"id": r["id"], "image": r["image"], "kind": r.get("kind") or "image",
              "caption": r.get("caption") or "", "duration": r.get("duration") or 0}
             for r in rows]

    def _attr(start):
        # هر کارت همان گروه کامل را باز می‌کند ولی از استوریِ خودش شروع می‌شود
        g = {"name": b["name"], "slug": b["slug"],
             "items": items[start:] + items[:start]}
        return esc(json.dumps(g, ensure_ascii=False)).replace("'", "&#39;")

    cards = "".join(f'''<button class="arch-card" type="button" data-arch-group="{_attr(i)}">
      <span class="arch-thumb"><img src="{esc(r["image"])}" alt="" loading="lazy" decoding="async">{"<span class='story-vid-tag' aria-hidden='true'>▶</span>" if r.get("kind") == "video" else ""}</span>
      <span class="arch-meta">
        <strong class="nums">{esc(jdatetime(r["created"]))}</strong>
        <small class="{'arch-live' if _exp(r) >= _now else 'arch-old'}">{"فعال" if _exp(r) >= _now else "بایگانی"}</small>
        {("<span class='arch-cap'>" + esc(r["caption"]) + "</span>") if r.get("caption") else ""}
      </span></button>''' for i, r in enumerate(rows))
    if not cards:
        cards = empty_state("image", "هنوز استوری‌ای ثبت نشده",
                            "استوری‌های این کسب‌وکار پس از انتشار، همین‌جا بایگانی می‌شوند.")

    body = f'''<div class="container">
  <nav style="margin-bottom:var(--space-md)"><a class="btn btn-ghost btn-sm" href="/b/{esc(slug)}">← بازگشت به {esc(b["name"])}</a></nav>
  <header class="page-hero"><span class="eyebrow">{icon("clock")}<span>تاریخچهٔ استوری‌ها</span></span>
    <h1>استوری‌های {esc(b["name"])}</h1>
    <p>همهٔ استوری‌های گذشته و حالا — برای پخش، روی هر کدام بزنید.</p></header>
  <div class="arch-grid">{cards}</div>
</div>'''
    return page(s, f"تاریخچهٔ استوری‌های {b['name']}", body, "/businesses",
                desc=f"آرشیو کامل استوری‌های {b['name']} با تاریخ.",
                token=token, body_class='biz-page has-callbar" data-biz-slug="' + esc(slug),
                extra_js='<script type="module" src="/assets/js/stories.js?v177"></script>')


# ------------------------------------------------------------------ map page

def map_page(s, token=""):
    cats = db.category_tree()
    ci = _cat_icons()
    rows = [b for b in db.businesses() if b["lat"] and b["lng"]]
    # Everything the selection card needs, so picking a pin on the map shows
    # the whole business at once instead of just its name. Computed here
    # rather than fetched later: 10-2000 shops is a few KB of JSON, and a
    # per-click request on a patchy mobile connection would feel broken.
    rows = db.annotate_open(rows)
    payload = [{"slug": b["slug"], "name": b["name"], "lat": b["lat"], "lng": b["lng"],
                "cat": b["cat_slug"], "featured": b["featured"],
                "address": b["address"], "icon": ci.get(b["cat_slug"], "store"),
                "phone": b.get("phone") or "", "whatsapp": b.get("whatsapp") or "",
                "catname": (db.category(b["cat_slug"]) or {}).get("name", ""),
                "rating": round(b.get("rating") or 0, 1),
                "nreviews": b.get("nreviews") or 0,
                "verified": bool(b.get("verified")),
                "open": b["open_state"]["state"],
                "openlabel": b["open_state"]["label"],
                "opendetail": b["open_state"]["detail"],
                "descr": (b.get("descr") or "")[:110]}
               for b in rows]

    items = "".join(f'''<button class="map-item" type="button" data-focus="{esc(b['slug'])}"
       data-map-item data-cat="{esc(b['cat_slug'])}" data-name="{esc(b['name'])}">
      <span class="map-item-dot" aria-hidden="true">{cat_icon(ci.get(b['cat_slug'], 'store'), 22)}</span>
      <span style="flex:1;text-align:start"><span class="t">{esc(b['name'])}</span>
        <span class="s">{esc(b['address'])}</span></span>{icon("chevron-left")}</button>'''
      for b in rows) or f'<p class="text-sm text-muted">{esc("هنوز کسب‌وکاری با موقعیت نقشه ثبت نشده است.")}</p>'

    cat_opts = cat_options(cats, blank="همهٔ دسته‌ها", group_selectable=False)

    body = f'''
<div class="container-wide">
  {breadcrumb(("نقشهٔ شهر", None))}
  <header class="page-hero map-hero"><h1>نقشه و جست‌وجوی کسب‌وکارهای ایران</h1>
    <p>جست‌وجو کنید، موقعیت خود را بدهید تا نزدیک‌ترین‌ها اول بیایند، و روی هر نتیجه
      بزنید تا روی نقشه نشان داده شود.</p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div class="map-search card glass card-pad">
    <div class="dir-row">
      <span class="search-wrap" style="flex:1">{icon("search", cls="search-icon")}
        <label class="sr-only" for="mq">جست‌وجوی کسب‌وکار</label>
        <input class="input" id="mq" type="search" data-map-search autocomplete="off"
               placeholder="نام، دسته، محله یا خدمت…" aria-autocomplete="list">
        <div class="live-sugg" data-map-sugg hidden></div></span>
      <span class="text-xs text-muted" data-map-geo-status>اجازهٔ موقعیت، نزدیک‌ترین‌ها را اول می‌آورد</span>
    </div>
    <div class="map-chips" role="group" aria-label="مرتب‌سازی">
      <button class="chip is-active" type="button" data-map-sort="default">{icon("grid")}<span>همه</span></button>
      <button class="chip" type="button" data-map-sort="nearest">{icon("compass")}<span>نزدیک‌ترین</span></button>
      <button class="chip" type="button" data-map-sort="rating">{icon("star")}<span>بالاترین امتیاز</span></button>
      <button class="chip" type="button" data-map-sort="open">{icon("clock")}<span>همین حالا باز</span></button>
      <span class="select-chip">
        <label class="sr-only" for="map-cat">دسته</label>
        <select class="select" id="map-cat" data-map-cat data-catpick>{cat_opts}</select>
      </span>
    </div>
  </div>
  <div class="map-layout">
    <aside class="card glass card-pad">
      <h2 class="card-title mb-md">{icon("list")} کسب‌وکارهای روی نقشه
        <span class="badge badge-neutral" data-map-count>{fa(len(rows))}</span></h2>
      <div class="map-list mt-md" data-map-list>{items}</div>
    </aside>
    <div class="map-stage" data-map-wrap data-map="pending">
      <div data-map-canvas data-multi style="position:absolute;inset:0"></div>
      <div class="map-stage-head">
        <div class="map-head-title">{icon("map")}<span>نقشهٔ دکان‌ها</span></div>
        <button type="button" class="map-me" data-map-me>
          {icon("compass")}<span>نزدیک من</span>
        </button>
      </div>
      <div class="map-selected" data-map-selected hidden></div>
      <div class="map-legend">{icon("info")}<span data-map-status>در حال بارگذاری…</span></div>
    </div>
  </div>
</div></section>
<script id="map-data" type="application/json">{json_embed(payload)}</script>'''
    return page(s, "نقشهٔ شهر", body, "/map", token=token, cats=cats, extra_js=MAP_JS)


# ------------------------------------------------------------------ blog
def blog(s, token=""):
    cats = db.category_tree()
    rows = db.posts()
    if rows:
        cards = "".join(f'''<article class="card card-hover glass card-pad reveal" data-delay="{i*50}">
          <span class="badge badge-neutral">{icon("book")}<span>{esc(jdate(p['created']))}</span></span>
          <h2 class="card-title mt-md"><a href="/blog/{esc(p['slug'])}">{esc(p['title'])}</a></h2>
          <p class="card-desc">{esc(p['excerpt'])}</p>
          <a class="btn btn-ghost btn-sm mt-md" href="/blog/{esc(p['slug'])}">
            {icon("arrow-left")}<span>ادامهٔ مطلب</span></a></article>''' for i, p in enumerate(rows))
        content = f'<div class="grid grid-3">{cards}</div>'
    else:
        content = empty_state("book", "هنوز مطلبی منتشر نشده",
                              "به‌زودی اخبار و مقالات مرتبط با کسب‌وکارهای شهر اینجا منتشر می‌شود.")
    body = f'''
<div class="container-wide">{breadcrumb(("اخبار شهر", None))}
  <header class="page-hero"><span class="eyebrow">{icon("book")}<span>وبلاگ</span></span>
    <h1>اخبار و مقالات شهر</h1><p>تازه‌ترین خبرها، معرفی کسب‌وکارها و راهنماهای خرید در ایران.</p></header>
</div>
<section class="section-sm"><div class="container-wide">{content}</div></section>'''
    return page(s, "اخبار شهر", body, "/blog", token=token, cats=cats)


def blog_post(s, slug, token=""):
    p = db.post(slug)
    if not p:
        return None
    cats = db.category_tree()
    paras = "".join(f"<p>{esc(x)}</p>" for x in (p["body"] or "").split("\n") if x.strip())
    body = f'''
<div class="container-wide">{breadcrumb(("اخبار شهر","/blog"), (p["title"], None))}
  <header class="page-hero"><h1>{esc(p['title'])}</h1>
    <p>{esc(p['excerpt'])}</p>
    <div class="cluster mt-md"><span class="badge badge-neutral">{icon("calendar")}
      <span>{esc(jdate(p['created']))}</span></span></div></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div class="card glass card-pad prose reveal" style="max-width:none">{paras}</div>
  <div class="text-center mt-xl"><a class="btn btn-glass" href="/blog">
    {icon("arrow-left")}<span>بازگشت به فهرست</span></a></div>
</div></section>'''
    return page(s, p["title"], body, "/blog", desc=p["excerpt"], token=token, cats=cats)


# ------------------------------------------------------------------ favorites
def favorites(s, token=""):
    cats = db.category_tree()
    body = f'''
<div class="container-wide">{breadcrumb(("علاقه‌مندی‌ها", None))}
  <header class="page-hero"><span class="eyebrow">{icon("heart")}<span>ذخیره‌شده‌ها</span></span>
    <h1>علاقه‌مندی‌های من</h1>
    <p>کسب‌وکارهایی که ذخیره کرده‌اید. این فهرست روی همین دستگاه نگهداری می‌شود.</p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div id="fav-list" class="grid grid-3"></div>
  <div id="fav-empty">{empty_state("heart", "هنوز چیزی ذخیره نکرده‌اید",
      "روی نشان قلب در کارت هر کسب‌وکار بزنید تا اینجا ذخیره شود.",
      f'<a class="btn btn-primary mt-lg" href="/businesses">{icon("grid")}<span>مرور کسب‌وکارها</span></a>')}</div>
</div></section>
<script type="module" src="/assets/js/favorites.js?v109"></script>'''
    return page(s, "علاقه‌مندی‌ها", body, "", token=token, cats=cats)


# ------------------------------------------------------------------ simple
def pricing(s, token="", q=None):
    """Real plans from the database — what the admin edits in /panel/plans is
    exactly what a visitor sees here, and choosing one creates a real
    subscription request the admin has to approve."""
    q = q or {}
    cats = db.category_tree()
    msg = ""
    if q.get("ok"):
        msg = flash("ok", q["ok"][0])
    elif q.get("err"):
        msg = flash("err", q["err"][0])

    rows = db.plans()
    if not rows:
        cards = empty_state("wallet", "هنوز پلنی تعریف نشده",
                            "مدیر سایت پلن‌های اشتراک را از پنل تعریف می‌کند.")
    else:
        # the middle plan is highlighted; with two plans the paid one is
        pop_idx = 1 if len(rows) >= 3 else (len(rows) - 1 if len(rows) > 1 else -1)
        bill_toggle = (
            '<div class="bill-toggle" data-bill-toggle role="tablist" aria-label="دورهٔ پرداخت">'
            '<button type="button" data-period="1">ماهیانه</button>'
            '<button type="button" data-period="3">۳ ماهه</button>'
            '<button type="button" data-period="6">۶ ماهه</button>'
            '<button type="button" data-period="12" class="is-active" aria-pressed="true">سالیانه</button>'
            '</div>'
        )
        cards = ""
        for i, p in enumerate(rows):
            amt = "رایگان" if p["price"] == 0 else fa_group(p["price"])
            unit = None if p["price"] == 0 else (
                "تومان / سالانه" if p["months"] >= 12 else f"تومان / {fa(p['months'])} ماه")
            feats = "".join(
                f'<div class="price-feat yes">{icon("check-circle")}<span>{esc(t)}</span></div>'
                for t in p["perk_list"])
            extra = (f'<div class="price-feat yes">{icon("check-circle")}'
                     f'<span>تا {fa(p["max_items"])} محصول یا خدمت</span></div>'
                     f'<div class="price-feat yes">{icon("check-circle")}'
                     f'<span>تا {fa(p["max_photos"])} تصویر در گالری</span></div>')
            pop = (i == pop_idx)
            cta = (f'<a class="btn {"btn-primary" if pop else "btn-glass"} btn-block" '
                   f'href="/submit">{icon("plus")}<span>ثبت رایگان کسب‌وکار</span></a>'
                   if p["price"] == 0 else
                   f'<a class="btn {"btn-primary" if pop else "btn-glass"} btn-block" '
                   f'href="/subscribe?plan={esc(p["slug"])}">{icon("zap")}'
                   f'<span>انتخاب پلن {esc(p["name"])}</span></a>')
            cards += f'''<div class="price-card tilt reveal-3d{" popular" if pop else ""}" data-tilt="5" data-monthly="{int(p["price"] // p["months"]) if (p["months"] and p["price"]) else 0}" data-price="{p["price"]}" data-months="{p["months"]}">
              <span class="sheen" aria-hidden="true"></span><div class="layer-1">
              <div class="price-name">{esc(p["name"])}</div>
              <div class="price-desc">{esc(p.get("tagline") or (p["perk_list"] or [""])[0])}</div>
              <div class="price-amount"><span class="n nums">{amt}</span>
                {f'<span class="u">{unit}</span>' if unit else ''}</div>
              <div class="price-feats">{feats}{extra}</div>
              {cta}
              </div></div>'''
        cards = bill_toggle + f'<div class="price-grid" data-price-grid>{cards}</div>' + BILL_JS

    # --- comparison table: every plan side by side in one glance ---
    cmp_rows = ""
    if rows:
        def _cell(v, strong=False):
            cls = ' class="nums"' if strong else ''
            return f"<td{cls}>{v}</td>"
        cmp_head = "".join(f"<th>{esc(p['name'])}</th>" for p in rows)
        cmp_rows += ("<tr><th>قیمت</th>"
                     + "".join(_cell("رایگان" if p["price"] == 0 else f"{fa_group(p['price'])} تومان", strong=True)
                               for p in rows) + "</tr>")
        cmp_rows += ("<tr><th>مدت اشتراک</th>"
                     + "".join(_cell("نامحدود" if p["price"] == 0 else f"{fa(p['months'])} ماه") for p in rows) + "</tr>")
        cmp_rows += ("<tr><th>جایگاه ویژه در فهرست</th>"
                     + "".join(_cell(f"{fa(p['featured_slots'])} جایگاه" if p["featured_slots"] else "—") for p in rows) + "</tr>")
        cmp_rows += ("<tr><th>محصول یا خدمت</th>"
                     + "".join(_cell(f"تا {fa(p['max_items'])}") for p in rows) + "</tr>")
        cmp_rows += ("<tr><th>تصویر در گالری</th>"
                     + "".join(_cell(f"تا {fa(p['max_photos'])}") for p in rows) + "</tr>")
        cmp_rows += ("<tr><th>امکانات ویژه</th>"
                     + "".join(_cell(" · ".join(p["perk_list"][:5]) if p["perk_list"] else "—") for p in rows) + "</tr>")
    cmp_table = (f'<div class="card glass card-pad"><div class="table-scroll">'
                 f'<table class="compare-table"><thead><tr><th>مقایسه</th>{cmp_head}</tr></thead>'
                 f'<tbody>{cmp_rows}</tbody></table></div>'
                 f'<p class="text-xs text-muted mt-md">جدول مقایسهٔ سریع — برای جزئیات کامل، کارت همان پلن را ببینید.</p></div>'
                 if rows else "")

    pay_note = ""
    if s.get("pay_method") == "zarinpal" and s.get("zarinpal_merchant"):
        pay_note = ("پرداخت از طریق درگاه امن زرین‌پال انجام می‌شود.")
    elif s.get("pay_card"):
        pay_note = (f'پرداخت کارت‌به‌کارت به شمارهٔ {s.get("pay_card")}'
                    f'{" به نام " + s.get("pay_card_name") if s.get("pay_card_name") else ""}'
                    ' و سپس ثبت کد پیگیری در فرم انتخاب پلن.')
    else:
        pay_note = "برای هماهنگی پرداخت، پس از انتخاب پلن با شما تماس گرفته می‌شود."

    FAQ = [("ثبت کسب‌وکار چقدر طول می‌کشد؟",
            "پس از تکمیل فرم، حداکثر تا ۲۴ ساعت کاری بررسی و تأیید می‌شود."),
           ("آیا ثبت هزینه دارد؟",
            "خیر، پلن پایه کاملاً رایگان و بدون محدودیت زمانی است."),
           ("پرداخت چگونه انجام می‌شود؟", pay_note),
           ("بعد از پرداخت چه اتفاقی می‌افتد؟",
            "درخواست شما برای مدیر ارسال می‌شود؛ پس از تأیید پرداخت، پلن بلافاصله "
            "فعال می‌شود و کسب‌وکارتان نشان و جایگاه ویژه می‌گیرد."),
           ("اگر اشتراکم تمام شود چه می‌شود؟",
            "کسب‌وکار شما حذف نمی‌شود؛ فقط امتیازهای پلن (جایگاه ویژه و نشان) "
            "برداشته می‌شود و می‌توانید هر زمان تمدید کنید."),
           ("چطور اطلاعاتم را ویرایش کنم؟",
            "با شمارهٔ موبایل وارد پنل دکان‌داران شوید و از «کسب‌وکارهای من» ویرایش کنید.")]
    faq = "".join(f'''<div class="accordion-item">
      <button class="accordion-trigger" type="button" aria-expanded="false" aria-controls="fq{i}">
        <span>{esc(qq)}</span>{icon("chevron-down")}</button>
      <div class="accordion-panel" id="fq{i}" hidden>{esc(a)}</div></div>'''
      for i, (qq, a) in enumerate(FAQ))

    body = f'''
<div class="container-wide">{breadcrumb(("تعرفه‌ها", None))}
  {msg}
  <header class="page-hero text-center"><span class="eyebrow">{icon("tag")}<span>تعرفه‌های اشتراک</span></span>
    <h1>از رایگان شروع کنید؛ هر وقت دلتان خواست رشد دهید</h1>
    <p style="margin-inline:auto">ثبت اولیه همیشه رایگان و بدون محدودیت زمانی است. هر زمان خواستید ارتقا دهید یا برگردید — همه‌چیز با یک ضربه است و کسب‌وکارتان هیچ‌وقت حذف نمی‌شود.</p></header>
</div>
<section class="section-sm"><div class="container-wide">{cards}</div></section>
{f'<section class="section-sm"><div class="container-wide">{section_head("مقایسهٔ پلن‌ها", "یک نگاه، تصمیم راحت‌تر", center=True, eyebrow_icon="table")}{cmp_table}</div></section>' if cmp_table else ''}
<section class="section"><div class="container-wide" style="max-width:860px">
  {section_head("پرسش‌های متداول","سؤالی دارید؟", center=True, eyebrow_icon="help")}
  <div class="card glass card-pad">{faq}</div></div></section>'''
    return page(s, "تعرفه‌ها", body, "/pricing", token=token, cats=cats)


def _card_digits(v):
    """Only the digits of a card/account number — strips dashes/spaces and
    maps Persian/Arabic numerals. v140."""
    _m = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
    return "".join(c for c in (v or "").translate(_m) if c.isdigit())


def _card_fmt(v):
    """Pretty 4-4-4-4 grouping when the value is a 16-digit card number."""
    d = _card_digits(v)
    return "-".join(d[i:i + 4] for i in range(0, len(d), 4)) if len(d) == 16 else (v or "")


def subscribe(s, plan_slug, me=None, token="", q=None):
    """The page a shopkeeper lands on after picking a paid plan."""
    q = q or {}
    cats = db.category_tree()
    p = db.plan(slug=plan_slug)
    if not p:
        return None

    msg = ""
    if q.get("err"):
        msg = flash("err", q["err"][0])

    # Support period selection from the pricing toggle (1/3/6/12). The chosen
    # period is ALSO kept through the login redirect, so it never silently
    # snaps back to the plan's own (yearly) length after signing in.
    raw_months = q.get("months", [""])[0] if q else ""
    try:
        req_months = int(raw_months) if raw_months else p["months"]
    except Exception:
        req_months = p["months"]
    req_months = req_months if req_months in (1, 3, 6, 12) else (p["months"] or 12)

    # v136: exact proration — price × period ÷ plan months, rounded. A 3-month
    # pick on a 12-month plan is an exact quarter, never a few toman off.
    _base = p.get("price") or 0
    _pm = p.get("months") or 0
    calc_price = int(_base * req_months / _pm + 0.5) if (_base and _pm) else _base

    # v136: a visible period picker on the subscribe page itself, so the user's
    # choice is explicit and cannot be lost anywhere in the redirect chain.
    period_ctl = ""
    if p["price"] > 0:
        _pbtns = "".join(
            f'<button type="button" data-period="{pr}" class="{"is-active" if pr == req_months else ""}" '
            f'aria-pressed="{"true" if pr == req_months else "false"}">{_plbl}</button>'
            for pr, _plbl in ((1, "ماهیانه"), (3, "۳ ماهه"), (6, "۶ ماهه"), (12, "سالیانه")))
        period_ctl = f'''<div class="field"><label class="field-label">مدت اشتراک</label>
      <div class="bill-toggle" data-sub-period data-price="{p["price"]}" data-months="{p["months"]}">{_pbtns}</div>
      <p class="field-hint">مبلغ به‌تناسب مدت انتخابی محاسبه می‌شود.</p></div>'''
        _period_script = r'''<script>
(function(){
  var box=document.querySelector('[data-sub-period]'); if(!box) return;
  var base=parseInt(box.dataset.price,10)||0, pm=parseInt(box.dataset.months,10)||0;
  if(!base||!pm) return;
  var FA='۰۱۲۳۴۵۶۷۸۹';
  var fa=function(n){return String(n).replace(/\d/g,function(d){return FA[+d];});};
  var faG=function(n){return fa(Number(n).toLocaleString('en-US')).replace(/,/g,'٬');};
  function price(p){return Math.round(base*p/pm);}
  function label(p){return p===1?'تومان / ماه':p===3?'تومان / ۳ ماه':p===6?'تومان / ۶ ماه':'تومان / سالانه';}
  function set(p){
    box.querySelectorAll('[data-period]').forEach(function(b){var on=parseInt(b.dataset.period,10)===p;b.classList.toggle('is-active',on);b.setAttribute('aria-pressed',String(on));});
    var hi=document.querySelector('input[name="months"]'); if(hi) hi.value=p;
    var n=document.querySelector('[data-sub-amount] .n'); if(n) n.textContent=faG(price(p));
    var u=document.querySelector('[data-sub-amount] .u'); if(u) u.textContent=label(p);
    document.querySelectorAll('[data-sub-pay]').forEach(function(x){x.textContent=faG(price(p));});
    var pl=document.querySelector('[data-sub-period-label]'); if(pl) pl.textContent=(p===1?'یک ماه':fa(p)+' ماه');
  }
  box.querySelectorAll('[data-period]').forEach(function(b){b.addEventListener('click',function(){set(parseInt(b.dataset.period,10));});});
})();
</script>'''
    else:
        _period_script = ""

    # the period must survive the login round-trip: encode the FULL target
    # (plan + months) into `next`, not just the bare /subscribe path.
    login_next = _quote(f"/subscribe?plan={p['slug']}&months={req_months}")

    if not me:
        inner = f'''<div class="alert alert-info mb-lg">{icon("info")}
      <span>برای خرید پلن باید وارد حساب خود شوید. ورود با شمارهٔ موبایل و بدون رمز است.</span></div>
    <a class="btn btn-primary btn-lg btn-block" href="/login?next={login_next}">
      {icon("user")}<span>ورود / ثبت‌نام صاحبان کسب‌وکار</span></a>'''
    else:
        mine = db.businesses_of(me["id"])
        if not mine:
            inner = f'''<div class="alert alert-warn mb-lg">{icon("alert")}
        <span>هنوز کسب‌وکاری به حساب شما متصل نیست. اول کسب‌وکارتان را ثبت یا تصاحب کنید.</span></div>
      <a class="btn btn-primary btn-block" href="/submit">{icon("plus")}<span>ثبت کسب‌وکار</span></a>
      <a class="btn btn-glass btn-block mt-md" href="/my/claim">{icon("shield")}<span>تصاحب کسب‌وکار موجود</span></a>'''
        else:
            opts = "".join(f'<option value="{b["id"]}">{esc(b["name"])}</option>' for b in mine)
            if s.get("pay_method") == "zarinpal" and s.get("zarinpal_merchant"):
                pay_box = (f'<div class="alert alert-info mb-lg">{icon("credit-card")}'
                           f'<span>پس از ثبت درخواست، به درگاه امن زرین‌پال هدایت می‌شوید.</span></div>')
            elif s.get("pay_card"):
                _pcard_disp = _card_fmt(s.get("pay_card"))
                _pcard_dig = _card_digits(s.get("pay_card"))
                _pcard_name = (s.get("pay_card_name") or "").strip()
                _pbank = (s.get("pay_bank") or "").strip()
                pay_box = f'''<div class="card glass card-pad mb-lg pay-box">
            <div class="pay-head">{icon("credit-card")}<div><h3 class="card-title" style="margin:0">پرداخت کارت‌به‌کارت</h3>
              <p class="pay-sub">مبلغ <strong class="nums" data-sub-pay>{fa_group(calc_price)}</strong> تومان برای پلن {esc(p["name"])}</p></div></div>
            <ol class="pay-steps">
              <li><span>۱</span><div>از اپلیکیشن بانک یا خودپرداز، مبلغ را به کارتِ زیر <strong>کارت‌به‌کارت</strong> کنید.</div></li>
              <li><span>۲</span><div>در فرم پایین، <strong>کد رهگیری</strong> تراکنش و <strong>تصویر فیش</strong> را ثبت کنید؛ بدون هر دوی اینها درخواست پذیرفته نمی‌شود.</div></li>
              <li><span>۳</span><div>دکمهٔ «پرداخت کردم» را بزنید؛ پس از تأیید مدیر، پلن فعال می‌شود.</div></li>
            </ol>
            <div class="pay-card-box">
              <div class="pay-card-label">{icon("wallet")}<span>واریز به این کارت</span></div>
              <div class="pay-card-line">
                <span class="v nums pay-card-no" dir="ltr">{esc(_pcard_disp)}</span>
                <button type="button" class="btn btn-glass btn-sm copy-card" data-copy="{esc(_pcard_dig)}"
                        aria-label="کپی شمارهٔ کارت">{icon("copy")}<span>کپی</span></button>
              </div>
              <div class="pay-card-meta">
                {f'<span>{icon("user")} {esc(_pcard_name)}</span>' if _pcard_name else ''}
                {f'<span>{icon("bank")} {esc(_pbank)}</span>' if _pbank else ''}
              </div>
            </div>
          </div>'''
            else:
                # v154: کارت ثبت‌نشده — خریدار باید مقصد واریز را بداند؛
                # گیتِ کد رهگیری/فیش همچنان روی همین فرم فعال می‌ماند.
                pay_box = (f'<div class="alert alert-info mb-lg">{icon("wallet")}'
                           f'<span>پرداخت کارت‌به‌کارت است؛ شمارهٔ کارت مقصد را از طریق '
                           f'<a href="/my/tickets">تیکت پشتیبانی</a> بگیرید و پس از واریز، '
                           f'کد رهگیری و تصویر فیش را در فرم پایین ثبت کنید.</span></div>')

                                    # v154: کد رهگیری و تصویر فیش «همیشه» الزامی‌اند — قبلاً گیت فقط وقتی
            # روشن بود که مدیر شمارهٔ کارت را ثبت کرده باشد؛ در نصبِ بدون کارت،
            # دکمهٔ «پرداخت کردم» با فرمِ خالی قابل زدن بود (بازخورد کاربر).
            ref_label = 'کد پیگیری تراکنش<span class="req">*</span>'
            ref_attr = ' required minlength="4"'
            rc_label = 'تصویر فیش واریز<span class="req">*</span>'
            rc_attr = ' required accept="image/*"'
            rc_hint = ('تصویر رسید یا صفحهٔ موفقِ تراکنش را با دوربین بگیرید یا از فایل‌ها انتخاب کنید — '
                       'بدون هر دو، دکمهٔ ثبت خاموش می‌ماند.')
            pay_gate = r'''<script>
      (function(){var f=document.querySelector('form[action="/subscribe"]');if(!f)return;
        var r=document.getElementById('sb-r'), rc=document.getElementById('sb-rc'),
            go=document.getElementById('sb-go'), msg=document.getElementById('sb-pay-msg');
        if(!r||!rc||!go)return;
        function okNow(){return r.value.trim().length>=4 && rc.files && rc.files.length>0;}
        function upd(){var ok=okNow();
          go.disabled=!ok; go.setAttribute('aria-disabled', ok?'false':'true');
          if(msg) msg.hidden=ok;}
        r.addEventListener('input',upd);
        rc.addEventListener('change',upd);
        rc.addEventListener('input',upd);
        f.addEventListener('submit',function(e){if(!okNow()){e.preventDefault();upd();}});
        upd();})();
      </script>'''

            inner = f'''{pay_box}
      <form method="post" action="/subscribe" data-validate enctype="multipart/form-data">
        <input type="hidden" name="plan" value="{esc(p["slug"])}">
        <input type="hidden" name="months" value="{req_months}">
        {period_ctl}
        <div class="field"><label class="field-label" for="sb-b">کسب‌وکار<span class="req">*</span></label>
          <select class="select" id="sb-b" name="biz_id" required>{opts}</select></div>
        <div class="field"><label class="field-label" for="sb-r">{ref_label}</label>
          <input class="input nums" id="sb-r" name="ref" dir="ltr"{ref_attr}
                 placeholder="مثلاً ۵۹۸۴۳۱۲ (یا ۱۶ رقم انتهای رسید)"></div>
        <div class="field"><label class="field-label" for="sb-rc">{rc_label}</label>
          <input class="input" id="sb-rc" type="file" name="receipt"{rc_attr}>
          <p class="field-hint">{rc_hint}</p></div>
        <div class="field"><label class="field-label" for="sb-n">توضیح</label>
          <textarea class="textarea" id="sb-n" name="note" style="min-height:80px"
            placeholder="اختیاری"></textarea></div>
        <div class="pay-cta">
          <button class="btn btn-primary btn-lg btn-block" type="submit" id="sb-go"
            disabled>{icon("check-circle")}<span>پرداخت کردم — ثبت درخواست پلن {esc(p["name"])}</span></button>
          <p class="field-hint text-center" id="sb-pay-msg" role="status">
            برای فعال‌شدن دکمه، کد رهگیری را وارد کنید و تصویر فیش را انتخاب کنید.</p>
          <p class="field-hint text-center">پس از ثبت، فیش و کد رهگیری برای مدیر ارسال و درخواست بررسی می‌شود.</p>
        </div>
      </form>
      <script>
      (function(){{var b=document.querySelector('.copy-card');if(!b)return;
        function done(){{var o=b.querySelector('span');if(o){{var old=o.textContent;o.textContent='کپی شد ✓';b.classList.add('is-copied');setTimeout(function(){{o.textContent=old;b.classList.remove('is-copied');}},1800);}}}}
        function fb(){{var t=document.createElement('textarea');t.value=b.getAttribute('data-copy')||'';t.setAttribute('readonly','');t.style.cssText='position:fixed;opacity:0';document.body.appendChild(t);t.select();try{{document.execCommand('copy');done();}}catch(e){{}}document.body.removeChild(t);}}
        b.addEventListener('click',function(){{var txt=b.getAttribute('data-copy')||'';if(!txt)return;if(navigator.clipboard&&navigator.clipboard.writeText){{navigator.clipboard.writeText(txt).then(done,fb);}}else fb();}});
      }})();
      </script>
      {pay_gate}'''
    perks = "".join(f'<div class="price-feat yes">{icon("check-circle")}<span>{esc(t)}</span></div>'
                    for t in p["perk_list"])
    period_label = "یک ماه" if req_months == 1 else f"{fa(req_months)} ماه"
    _sub_amount = "رایگان" if p["price"] == 0 else fa_group(calc_price)
    body = f'''
<div class="container-wide">{breadcrumb(("تعرفه‌ها", "/pricing"), (p["name"], None))}
  {msg}
  <header class="page-hero"><span class="eyebrow">{icon("wallet")}<span>خرید اشتراک</span></span>
    <h1>پلن {esc(p["name"])}</h1>
    <p><strong class="nums" data-sub-amount><span class="n">{_sub_amount}</span> تومان</strong>
       <span class="text-muted">برای</span> <span data-sub-period-label>{period_label}</span></p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div class="subscribe-grid">
    <div class="card glass card-pad">{inner}</div>
    <div class="card glass card-pad">
      <h2 class="card-title mb-lg">{icon("sparkles")} این پلن چه می‌دهد</h2>
      <div class="price-feats">{perks}
        <div class="price-feat yes">{icon("check-circle")}<span>تا {fa(p["max_items"])} محصول یا خدمت</span></div>
        <div class="price-feat yes">{icon("check-circle")}<span>تا {fa(p["max_photos"])} تصویر در گالری</span></div>
      </div>
    </div>
  </div>
</div></section>{_period_script}'''
    return page(s, f"خرید پلن {p['name']}", body, "/pricing", token=token, cats=cats)


def contact(s, token="", sent=False):
    cats = db.category_tree()
    target = "/my/tickets" if ui_ctx_owner() else "/login?next=/my/tickets"
    body = f'''<div class="container-wide">{breadcrumb(("پشتیبانی", None))}
  <header class="page-hero"><span class="eyebrow">{icon("shield")}<span>پشتیبانی قابل پیگیری</span></span>
    <h1>ارتباط با پشتیبانی فقط با تیکت</h1>
    <p>هر درخواست شماره، وضعیت و تاریخچه دارد؛ پاسخ مدیر را در همان تیکت ادامه می‌دهید.</p></header>
</div><section class="section-sm"><div class="container">
  <div class="card glass card-pad center"><span class="stat-icon">{icon("message")}</span>
    <h2 class="card-title mt-md">یک مسیر، بدون گم‌شدن پیام</h2>
    <p class="text-muted mt-sm">موضوع و توضیح را بنویسید و در صورت نیاز فایل پیوست کنید.</p>
    <a class="btn btn-primary btn-lg mt-lg" href="{esc(target)}">{icon("send")}<span>ثبت یا پیگیری تیکت</span></a>
    <p class="text-xs text-muted mt-md">برای حفاظت از سابقه و فایل‌ها، ورود به حساب لازم است.</p>
  </div></div></section>'''
    return page(s, "پشتیبانی تیکتی", body, "/contact", token=token, cats=cats)


def static_page(s, slug, token=""):
    cats = db.category_tree()
    p = db.get_page(slug)
    paras = "".join(f"<p>{esc(x)}</p>" for x in (p["body"] or "").split("\n") if x.strip())
    body = f'''
<div class="container-wide">{breadcrumb((p["title"], None))}
  <header class="page-hero"><h1>{esc(p['title'])}</h1></header></div>
<section class="section-sm"><div class="container-wide">
  <div class="card glass card-pad prose reveal" style="max-width:none">{paras}</div>
</div></section>'''
    return page(s, p["title"], body, "", token=token, cats=cats)


def submit(s, token="", sent=False, dups=None, form=None, me=None):
    cats = db.category_tree()
    if s.get("reg_open") != "1":
        body = f'''<div class="container-wide"><section class="section">
          {empty_state("lock","ثبت‌نام موقتاً بسته است",
            "در حال حاضر امکان ثبت کسب‌وکار جدید وجود ندارد. لطفاً بعداً مراجعه کنید.")}
        </section></div>'''
        return page(s, "ثبت کسب‌وکار", body, "", token=token, cats=cats)

    if sent:
        body = f'''<div class="container-wide"><section class="section">
          {empty_state("check-circle","درخواست شما ثبت شد",
            "کسب‌وکار شما پس از بررسی و تأیید مدیر روی سایت منتشر می‌شود. "
            "برای پیگیری و مدیریت، با همین شمارهٔ موبایل وارد شوید.",
            f"""<div class="cluster mt-lg" style="justify-content:center">
              <a class="btn btn-primary" href="/login">{icon("user")}<span>ورود و پیگیری</span></a>
              <a class="btn btn-glass" href="/">{icon("store")}<span>بازگشت به خانه</span></a>
            </div>""")}
        </section></div>'''
        return page(s, "ثبت کسب‌وکار", body, "", token=token, cats=cats)

    g = lambda k: esc((form or {}).get(k, [""])[0] if form else "")

    # Opening hours, same field names the edit page posts, so one handler
    # serves both.
    #
    # Default is OPEN 09:00–21:00 on the six working days and closed on Friday
    # — the common Iranian shop week. Ticking "تعطیل" on all seven by default
    # was safe but hostile: it made the shopkeeper uncheck seven boxes to
    # describe an ordinary week. He can still leave the whole section alone
    # and the block is simply skipped, because the fields only reach the
    # database when the form is actually submitted with them.
    SUBMIT_DAYS = [("sat", "شنبه"), ("sun", "یک‌شنبه"), ("mon", "دوشنبه"),
                   ("tue", "سه‌شنبه"), ("wed", "چهارشنبه"),
                   ("thu", "پنج‌شنبه"), ("fri", "جمعه")]
    hours_rows = ""
    for _k, _label in SUBMIT_DAYS:
        _o = g(f"h_{_k}_open") or "09:00"
        _c = g(f"h_{_k}_close") or "21:00"
        # Friday off by default; everything else open. On a redisplay after a
        # validation error, honour exactly what the shopkeeper had ticked.
        _closed = " checked" if (g(f"h_{_k}_closed") if form else _k == "fri") else ""
        hours_rows += f'''<div class="hours-row">
          <span class="text-sm fw-700">{_label}</span>
          <input class="input" type="time" name="h_{_k}_open" value="{_o}" aria-label="شروع {_label}">
          <input class="input" type="time" name="h_{_k}_close" value="{_c}" aria-label="پایان {_label}">
          <label class="check"><input type="checkbox" name="h_{_k}_closed"{_closed}><span>تعطیل</span></label>
        </div>'''

    # Group the 140+ trades under their parent so the picker stays readable.
    # A parent with children is only a heading — you file a shop under a
    # specific trade, not under "food". Parents with no children stay
    # selectable so nothing becomes unreachable.
    opts = cat_options(cats, selected=g("cat_slug"))

    # server-side duplicate block (JS-off fallback / final guard)
    dup_block = ""
    if dups:
        rows = "".join(f'''<div class="dup-row">
          <div><strong>{esc(d["name"])}</strong>
            <div class="text-xs text-muted">{esc(d["address"] or "بدون نشانی")}
              {" · " + esc({"published":"منتشرشده","pending":"در انتظار تأیید"}.get(d["status"], d["status"]))}</div>
            <div class="text-xs" style="color:var(--color-destructive);margin-top:3px">{esc(d["reason"])}</div>
          </div>
          <div class="cluster">
            {f'<a class="btn btn-glass btn-sm" href="/b/{esc(d["slug"])}">{icon("eye")}<span>مشاهده</span></a>' if d["status"] == "published" else ""}
            {"" if d["claimed"] else f'<a class="btn btn-primary btn-sm" href="/login">{icon("shield")}<span>این مال من است</span></a>'}
          </div></div>''' for d in dups)
        dup_block = f'''<div class="card glass card-pad mb-lg dup-box">
          <h2 class="card-title mb-md">{icon("alert")} این اطلاعات با ثبتِ پیشین هم‌خوانی دارد</h2>
          <p class="text-sm text-muted mb-md">برای جلوگیری از ثبت تکراری، موارد زیر پیدا شد.
            اگر یکی از این‌ها مال شماست، به‌جای ثبت دوباره وارد شوید و آن را تصاحب کنید.</p>
          <p class="text-sm text-muted mb-lg">توجه فرمایید که این بررسی تنها به نام محدود نمی‌شود؛
            <strong>شمارهٔ تماس و نشانی نیز بررسی می‌شوند</strong> — بنابراین اگر شمارهٔ تماسِ
            کسب‌وکار پیش‌تر ثبت شده باشد، تغییر نام مانع نمایش این پیام نخواهد شد.</p>
          {rows}
          <div class="alert alert-info mt-md" role="note">{icon("help")}
            <span>احتراماً؛ چنانچه کسب‌وکاری با نامی مشابه نام کسب‌وکار شما از قبل در «دست گیر»
              ثبت شده و این ثبت متعلق به شماست، خواهشمند است موضوع را از طریق
              <a href="/my/tickets" style="font-weight:800">تیکت پشتیبانی</a> مطرح فرمایید؛
              کارشناسان ما بررسی و پیگیری می‌کنند و پاسخ در همین بخش به شما اعلام می‌شود.</span></div>
          <hr class="divider">
          <label class="check"><input type="checkbox" form="submit-form" name="confirm_dup" value="1">
            <span>این‌ها کسب‌وکار من نیستند؛ مورد جدیدی ثبت می‌کنم.</span></label>
        </div>'''

    logged = ""
    if me:
        logged = f'''<div class="alert alert-success mb-lg">{icon("check-circle")}
          <span>با شمارهٔ <strong class="nums">{esc(me["phone"])}</strong> وارد شده‌اید —
            این کسب‌وکار مستقیم به پنل شما اضافه می‌شود.</span></div>'''
    else:
        logged = f'''<div class="alert alert-info mb-lg">{icon("info")}
          <span>اگر <a href="/login" style="color:var(--color-primary);font-weight:700">اول وارد شوید</a>،
            کسب‌وکار مستقیم به پنل شما وصل می‌شود و می‌توانید خودتان مدیریتش کنید.</span></div>'''

    body = f'''
<div class="container-wide">
  {breadcrumb(("ثبت کسب‌وکار", None))}
  <header class="page-hero"><span class="eyebrow">{icon("plus")}<span>رایگان</span></span>
    <h1>ثبت کسب‌وکار در دست گیر</h1>
    <p>فقط سه چیز لازم است: نام، دسته و شمارهٔ تلفن. پس از تأیید مدیر،
       کسب‌وکار شما روی سایت و نقشه نمایش داده می‌شود.</p></header>
</div>
<section class="section-sm"><div class="container-wide" style="max-width:760px">
  {logged}
  {dup_block}
  <div class="card glass card-pad">
    <form id="submit-form" method="post" action="/submit" data-validate data-dupcheck>
    <span style="position:absolute;left:-9999px;top:-9999px;height:0;overflow:hidden" aria-hidden="true">
        <label for="hp">وب‌سایت</label><input id="hp" type="text" name="website_hp" tabindex="-1" autocomplete="off"></span>

      <div class="grid grid-2" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="sb-name">نام کسب‌وکار<span class="req">*</span></label>
          <input class="input" id="sb-name" name="name" required minlength="2" maxlength="100"
                 value="{g('name')}" data-dup="name" autocomplete="organization">
          <div class="dup-hint" data-dup-for="name" hidden></div></div>
        <div class="field"><label class="field-label" for="sb-cat">دسته<span class="req">*</span></label>
          <select class="select" id="sb-cat" name="cat_slug" required data-catpick>
            <option value="">انتخاب کنید…</option>{opts}</select>
          <p class="field-hint">شغلتان را بنویسید تا پیدا شود — بین
            {fa(165)} دسته می‌گردد.</p></div>
      </div>
      <div class="field"><label class="field-label" for="sb-phone">تلفن<span class="req">*</span></label>
        <input class="input nums" id="sb-phone" name="phone" type="tel" required dir="ltr"
               inputmode="tel" autocomplete="tel"
               value="{esc(me['phone']) if me else esc(g('phone'))}"{"readonly" if me else ""}
               data-dup="phone">
        <div class="dup-hint" data-dup-for="phone" hidden></div>
        <p class="field-hint">{"شمارهٔ تلفن دکان با شمارهٔ ورود شما یکسان است و قابل تغییر نیست." if me else "با همین شماره وارد می‌شوید و کسب‌وکار را مدیریت می‌کنید."}</p></div>

      <!-- Three required fields is the point: the shopkeeper is standing in
           his shop with a customer waiting, and every extra required field
           measurably costs a registration. But he asked to be able to finish
           the WHOLE profile in one sitting rather than register and then go
           hunting for an edit screen — so everything the edit page offers is
           here too, optional, one tap away, and open already if he has
           started filling it in. -->
      <details class="more-fields"{" open" if any(g(k) for k in ("descr","whatsapp","address","tags","instagram","telegram","website","hours")) else ""}>
        <summary>
          {icon("plus")}<span>نمایش بیشتر اطلاعات (اختیاری)</span>
          <small>توضیح، نشانی، ساعت کاری، شبکه‌های اجتماعی — همین حالا کامل کنید</small>
        </summary>
        <div class="more-fields-body">
          <div class="field"><label class="field-label" for="sb-desc">توضیح کوتاه</label>
            <textarea class="textarea" id="sb-desc" name="descr" maxlength="2000"
              placeholder="در چند جمله بنویسید چه خدمتی ارائه می‌دهید…">{g('descr')}</textarea></div>
          <div class="field"><label class="field-label" for="sb-addr">نشانی</label>
            <input class="input" id="sb-addr" name="address" maxlength="300"
                   value="{g('address')}" data-dup="address" autocomplete="street-address">
            <div class="dup-hint" data-dup-for="address" hidden></div></div>
          <div class="field"><label class="field-label" for="sb-area">محله</label>
            <input class="input" id="sb-area" name="area" maxlength="100"
                   value="{g('area')}" placeholder="مثلاً امیرآباد، گلدشت، مرکز شهر">
            <p class="field-hint">کسب‌وکارها با محله، بهتر پیدا می‌شوند.</p></div>
          <div class="grid grid-2" style="align-items:start">
            <div class="field"><label class="field-label" for="sb-prov">استان</label>
              <select class="select" id="sb-prov" name="province">
                <option value="">انتخاب استان</option>
                {"".join(f'<option value="{esc(p)}"{" selected" if g("province")==p else ""}>{esc(p)}</option>' for p in db.provinces())}
              </select></div>
            <div class="field"><label class="field-label" for="sb-city">شهر</label>
              <select class="select" id="sb-city" name="city">
                <option value="">انتخاب شهر</option>
              </select></div>
          </div>
          <script>
            var prov = document.getElementById('sb-prov');
            var citySel = document.getElementById('sb-city');
            var allCities = {json_embed({p: [c["name"] for c in db.cities_in(p)] for p in db.provinces()})};
            var curProv = {json_embed(g('province'))}, curCity = {json_embed(g('city'))};
            function fillCities() {{
              var list = allCities[prov.value] || [];
              citySel.innerHTML = '<option value="">انتخاب شهر</option>' +
                list.map(function(c){{ return '<option value="' + c + '"' + (c===curCity?' selected':'') + '>' + c + '</option>'; }}).join('');
            }}
            prov.addEventListener('change', function(){{ fillCities(); }});
            if (curProv && allCities[curProv]) {{ prov.value = curProv; fillCities(); }}
          </script>
          <div class="field"><label class="field-label" for="sb-wa">واتساپ</label>
            <input class="input nums" id="sb-wa" name="whatsapp" type="tel" dir="ltr"
                   inputmode="tel" value="{g('whatsapp')}" placeholder="989123456789"></div>

          <fieldset class="sub-fields">
            <legend>{icon("clock")}<span>ساعت کاری</span></legend>
            <p class="field-hint mb-sm">اگر پر کنید، مشتری روی سایت می‌بیند
               «الان باز است» یا «بسته است». خالی بگذارید یعنی نامشخص.</p>
            {hours_rows}
          </fieldset>

          <fieldset class="sub-fields">
            <legend>{icon("send")}<span>شبکه‌های اجتماعی و سایت</span></legend>
            <div class="field"><label class="field-label" for="sb-ig">اینستاگرام</label>
              <input class="input" id="sb-ig" name="instagram" dir="ltr"
                     value="{g('instagram')}" placeholder="username یا نشانی کامل"></div>
            <div class="field"><label class="field-label" for="sb-tg">تلگرام</label>
              <input class="input" id="sb-tg" name="telegram" dir="ltr"
                     value="{g('telegram')}" placeholder="username یا نشانی کامل"></div>
            <div class="field" style="margin-bottom:0">
              <label class="field-label" for="sb-web">وب‌سایت</label>
              <input class="input" id="sb-web" name="website" type="url" dir="ltr"
                     value="{g('website')}" placeholder="https://example.ir"></div>
          </fieldset>

          <fieldset class="sub-fields">
            <legend>{icon("map")}<span>موقعیت روی نقشه</span></legend>
            <p class="field-hint mb-sm">اگر مختصات را بگذارید، کسب‌وکار شما روی
               نقشهٔ شهر پین می‌گیرد و مشتری با یک لمس مسیریابی می‌کند.</p>
            <div class="map-stage" data-map-wrap data-map="pending" style="min-height:240px;border-radius:var(--radius-md);margin-bottom:var(--space-md)">
              <div data-map-canvas data-pick data-lat="{g('lat') or s.get('map_lat','32.6340')}"
                   data-lng="{g('lng') or s.get('map_lng','51.3670')}" style="position:absolute;inset:0"></div>
              <div class="map-legend">{icon("info")}<span data-map-status>بارگذاری…</span></div>
            </div>
            <div class="grid grid-2" style="gap:0 var(--space-md)">
              <div class="field"><label class="field-label" for="sb-lat">عرض جغرافیایی</label>
                <input class="input nums" id="sb-lat" name="lat" dir="ltr"
                       inputmode="decimal" value="{g('lat')}" placeholder="32.6340"></div>
              <div class="field"><label class="field-label" for="sb-lng">طول جغرافیایی</label>
                <input class="input nums" id="sb-lng" name="lng" dir="ltr"
                       inputmode="decimal" value="{g('lng')}" placeholder="51.3660"></div>
            </div>
            <button class="btn btn-glass btn-sm" type="button" data-geo-fill aria-label="دریافت موقعیت فعلی من">
              {icon("compass")}<span>گرفتن موقعیت فعلی من</span></button>
            <p class="field-hint" data-geo-msg hidden></p>
          </fieldset>

          <div class="field" style="margin-bottom:0"><label class="field-label" for="sb-tags">برچسب‌ها</label>
            <input class="input" id="sb-tags" name="tags" value="{g('tags')}" maxlength="200" placeholder="با ویرگول جدا کنید">
            <p class="field-hint">مثال: کباب کوبیده، بیرون‌بر، پارکینگ</p></div>
        </div>
      </details>

      <label class="check mb-lg"><input type="checkbox" required>
        <span><a href="/rules" style="color:var(--color-primary)">قوانین</a> را می‌پذیرم.</span></label>
      <button class="btn btn-primary btn-lg btn-block" type="submit">
        {icon("send")}<span>ثبت رایگان کسب‌وکار</span></button>
      <p class="text-xs text-muted text-center mt-md">{icon("clock")}
        کمتر از یک دقیقه — بقیهٔ اطلاعات را بعداً از پنل خودتان اضافه کنید.</p>
    </form></div>
</div></section>
<script type="module" src="/assets/js/dupcheck.js?v155"></script>
<script type="module" src="/assets/js/catpicker.js?v109"></script>
<script type="module" src="/assets/js/mappage.js?v156"></script>'''
    return page(s, "ثبت کسب‌وکار", body, "", token=token, cats=cats)


def not_found(s, token=""):
    body = f'''<div class="container-wide"><section class="section">
      {empty_state("search","صفحه پیدا نشد",
        "نشانی واردشده وجود ندارد یا حذف شده است.",
        f'<a class="btn btn-primary mt-lg" href="/">{icon("store")}<span>بازگشت به خانه</span></a>')}
    </section></div>'''
    return page(s, "صفحه پیدا نشد", body, "", token=token, cats=db.category_tree())
