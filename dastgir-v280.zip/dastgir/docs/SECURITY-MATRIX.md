# 🧮 ماتریس پوشش امنیت/اسپم — v274 (پیوست برنامهٔ SECURITY-SPAM-PLAN)
> تولید: پارس مکانیکی `server/app.py` (۳۲۶ شرط مسیر؛ ۱۵۶ POST) + بازبینی دستی گروه‌ها.
> قانون: هر سطر یا «سیاست» می‌گیرد یا «معاف با دلیل». سطر بی‌تصمیم ممنوع — و از v275 به بعد
> `tools/test_coverage_guard.py` همین ماتریس را به assert تبدیل می‌کند.

## A) مهمان (عمومی)
| مسیر | امروز | تصمیم |
|---|---|---|
| `/login` , `/login/verify` , `/login/password` | از v186 با ۴۰۴ بسته (ورود فقط پیام‌رسان) | ✅ v277: قفل `loginlock` + سطل هش‌شدهٔ per-شماره + `logindiv` (defence in depth) + پین G18 |
| `/subscribe` | `sb:6` ✔ | POLICY |
| `/contact` | ریدایرکت به تیکت ✔ | معاف (بدون نوشتن) |
| `/submit` | 303 به ویزارد ✔ | معاف |
| `/prices/alert` (فراخوان قیمت) | `pricealert` always ✔ | ✅ toggle per-مشتری؛ «خبرم کن» v278 dedup ۲۴ساعته (`stockdup`) |
| `/api/check-duplicate` | بدون سطل = ابزار enumeration | **POLICY + پاسخ مبهم (G27)** |
| `/offer/<code>` | بدون سطل = حدس کد | **POLICY always + قفل (G28)** |
| ویزارد `/register-business/*` | `regweb` + `regip` + `regsub` ✔ | ✅ v278: per-IP + cooldown + رویداد neardup |
| وب‌هوک بله/سروش/ادمین | `*-hook:180` ✔ | ✅ v277: secret غلط => strike؛ ۶ ضربه/۱۰دق => بلاک IP (۴۰۳) |
| `/api/stories/<id>/view` | بدون سطل | **POLICY خواندنی `view:` (G14)** |
| `/businesses?q` | فقط سپر سراسری | **POLICY خواندنی `search:` (G16)** |
| `/api/chat/<tid>/msgs` | بدون سطل | **POLICY خواندنی `msgpoll:` (G26)** |

## B) مشتری (نشست customer)
| مسیر | امروز | تصمیم |
|---|---|---|
| چت `POST /me/chat/<tid>` | `chat:customer:60/600` ✔ | POLICY + محتوایی (فاز۲) |
| `/me/chat/<tid>/notify-me` | بدون سطل | **POLICY (G11)** |
| `/api/favorite` , `/api/follow` | بدون سطل | **POLICY (G12)** |
| `/api/push/subscribe|unsubscribe` | بدون سطل | **POLICY (G13)** |
| تیکت نو `/my/tickets` | `tk:10` + `ticketnew` ✔ | ✅ v276: honeypot + content_gate + spam_flag |
| پاسخ تیکت `/my/ticket/<id>` | `ticketreply` ✔ (v275) | ✅ |
| نظر/پرسش/رأی | `rv/qa/rh/qh` ✔ | ✅ v276: دِدوپ `question_votes` + content_gate + spam_flag |
| سفارش/نوبت | `ord/bk` ✔ | POLICY (ثبت) |
| `/me/name|profile|notif-settings|logout` | خود-پیکربندی | POLICY سبک (ضد چرخش) |
| لغو سفارش `/me/order/<id>/cancel` | تک‌پرچم ✔ | POLICY سبک |

## C) دکاندار (نشست owner)
| مسیر | امروز | تصمیم |
|---|---|---|
| چرخهٔ کسب `/my/business/<id>/*` | `ownerbiz:20/60` ✔ | POLICY |
| **وضعیت سفارش** `/my/order/<id>` | بدون سطل + اعلان به مشتری | **POLICY always (G22)** |
| پاسخ/لغو تیکت، review/question/booking moderate | بدون سطل | **POLICY per-owner** |
| `/my/story/add` , gallery upload , item save | `storyadd/upload/itemsave` ✔ | ✅ v278 += عنوان تکراری => `spam_flag` (نگه‌بررسی، درگاه itemdup) |
| `/my/claim` | `claim:5/3600` ✔ (v275) | ✅ پین v278 |
| broadcast fulfill/dismiss | بدون سطل | POLICY سبک |
| broadcast سفارشی | `bcast:10/3600` ✔ | POLICY |

## D) مدیر `/panel/*` (~۹۷ مسیر)
معاف با دلیل: دسترسی حداکثری مدیر (RULES §۳) + گیت کلید + `apl`. **استثناهای سخت‌سازی:**
`/panel/backup/import`، `/panel/media/gc|delete`، `/panel/demo`، `/panel/trash/*/restore` → سطل سبک always (نشست دزدیده‌شده).
`/panel/spam` تازه (فاز۵) = UI همین ماتریس.

## E) نقشهٔ تقویت (user-trigger → ارسال برون‌سو) — ۴۱ callsite
| محرک کاربر | ارسال | سطل امروز | تصمیم |
|---|---|---|---|
| چت/تیکت/نظر/سفارش/نوبت | اعلان مالک (بله/سروش) | ✔ chat/tk/rv/ord/bk | POLICY |
| stock «خبرم کن» | اعلان مالک | **✘** | **always (G11)** |
| وضعیت سفارش (owner) | اعلان مشتری | **✘** | **always (G22)** |
| درخواست لغو >۳۰د | sms مالک | تک‌پرچم ✔ | POLICY سبک |
| broadcast مدیر | همه | bcast ✔ | معاف مدیر |
جمع بقیهٔ ۴۱ در فاز۱ با جدول ممیزی کامل و پین در coverage-guard.

## F) انبارهای رشدکننده و هرس
| انبار | هرس امروز | تصمیم |
|---|---|---|
| `ratelimit` | ۷روز ✔ | += سقف سطر (G24) |
| `site_chats.log` | **✘** | **چرخش/هرس (G20)** |
| otp/sessions/ai_threads/ai_cache | ✔ | سالم؛ بدون اقدام (هرس در maintenance) |
| `spam_events/spam_bans` (نو) | — | سقف ذاتی در طراحی |
| uploads/chat-files | GC ✔ | += بایت روزانه (G21) |
| code-deploys.log / backup index | ۶۰/۴۰۰ ✔ | سالم؛ بدون اقدام (سقف ذاتی) |
