# -*- coding: utf-8 -*-
"""
Feature subsystems — customers, chat, orders, areas, server favourites,
top lists, flash deals, stories, follows, notifications, and
admin moderation (v28→v34).

Split out of db.py (which was a 5500-line god-file) so the core data layer
stays focused on schema/settings/CRUD, while each feature group lives here.

Design contract:
  • Every function talks to the database through db.connect / db._run /
    db._rows / db._one — the single SQLite layer (standard library only,
    Pydroid-compatible).
  • No HTML here; views_*.py handle presentation. app.py handles routing.
  • `import db` is safe at import time because db.py imports this module
    ONLY at its very end, after the core functions are already defined.
"""
import json
import re
import time
import secrets
import hashlib
import datetime
import db

# ==========================================================================
#  CUSTOMERS  ·  CHAT  ·  ORDERS  ·  AREAS  ·  SERVER FAVORITES   (v28)
# ==========================================================================
CUSTOMER_OTP_TTL = 180
CUSTOMER_SESSION_TTL = 60 * 60 * 24 * 30


# ---------------------------------------------------------------- customers
def customer_by_phone(phone, create=False):
    phone = db.norm_phone(phone)
    con = db.connect()
    r = con.execute("SELECT * FROM customers WHERE phone=?", (phone,)).fetchone()
    if not r and create:
        con.execute("INSERT INTO customers(phone) VALUES(?)", (phone,))
        con.commit()
        r = con.execute("SELECT * FROM customers WHERE phone=?", (phone,)).fetchone()
    con.close()
    return dict(r) if r else None


def customer_by_id(cid):
    con = db.connect()
    r = con.execute("SELECT * FROM customers WHERE id=?", (cid,)).fetchone()
    con.close()
    return dict(r) if r else None


# ---- username + password credentials (v57) — mirror of the owner versions
def customer_by_username(username):
    username = (username or "").strip()
    if not username:
        return None
    con = db.connect()
    r = con.execute("SELECT * FROM customers WHERE username=? AND username<>''",
                    (username,)).fetchone()
    con.close()
    return dict(r) if r else None


def customer_has_password(cid):
    con = db.connect()
    r = con.execute("SELECT pass_hash FROM customers WHERE id=?", (cid,)).fetchone()
    con.close()
    return bool(r and (r["pass_hash"] or "").strip())


def customer_check_password(cid, password):
    con = db.connect()
    r = con.execute("SELECT pass_hash FROM customers WHERE id=?", (cid,)).fetchone()
    con.close()
    return db.verify_password(password, r["pass_hash"] if r else "")


def customer_set_credentials(cid, username, password):
    """(ok, msg). Sets or updates a customer's username+password."""
    username = (username or "").strip()
    if not db.valid_username(username):
        return False, "نام کاربری باید ۳ تا ۲۴ نویسه (حروف، عدد، _ . -) و بدون فاصله باشد."
    if db._username_taken("customers", username, cid):
        return False, "این نام کاربری قبلاً گرفته شده است."
    if not password or len(password) < 6:
        return False, "رمز عبور باید دست‌کم ۶ نویسه باشد."
    con = db.connect()
    con.execute("UPDATE customers SET username=?, pass_hash=? WHERE id=?",
                (username, db.hash_password(password), cid))
    con.commit()
    con.close()
    return True, "نام کاربری و رمز عبور ذخیره شد."



def customer_otp_issue(phone):
    """Same table as owner OTP — one code per phone regardless of role."""
    phone = db.norm_phone(phone)
    now = time.time()
    con = db.connect()
    con.execute("DELETE FROM otp WHERE expires < ?", (now,))
    row = con.execute("SELECT * FROM otp WHERE phone=?", (phone,)).fetchone()
    if row:
        con.close()
        return row["code"], int(row["expires"] - now), True
    code = "".join(secrets.choice("0123456789") for _ in range(5))
    con.execute("INSERT INTO otp(phone,code,tries,expires) VALUES(?,?,0,?)",
                (phone, code, now + CUSTOMER_OTP_TTL))
    con.commit()
    con.close()
    return code, CUSTOMER_OTP_TTL, False


def customer_session_new(cid):
    tok = secrets.token_urlsafe(24)
    con = db.connect()
    con.execute("DELETE FROM customer_sessions WHERE expires < ?", (time.time(),))
    con.execute("INSERT INTO customer_sessions(token,customer_id,expires) VALUES(?,?,?)",
                (tok, cid, time.time() + CUSTOMER_SESSION_TTL))
    con.execute("UPDATE customers SET last_login=datetime('now') WHERE id=?", (cid,))
    con.commit()
    con.close()
    return tok


def customer_session_get(token):
    if not token:
        return None
    con = db.connect()
    r = con.execute(
        "SELECT c.* FROM customer_sessions s JOIN customers c ON c.id=s.customer_id "
        "WHERE s.token=? AND s.expires > ?", (token, time.time())).fetchone()
    con.close()
    if not r:
        return None
    d = dict(r)
    # a blocked customer's session must stop working immediately
    return None if d.get("status") == "blocked" else d


def customer_session_kill(token):
    if not token:
        return
    con = db.connect()
    con.execute("DELETE FROM customer_sessions WHERE token=?", (token,))
    con.commit()
    con.close()


def customer_set_name(cid, name):
    customer_set_profile(cid, name, None)


def customer_set_profile(cid, name, family=None):
    """Save the customer's display name (required) and family name (optional)."""
    name = (str(name or "")).strip()[:60]
    family = (str(family or "")).strip()[:60]
    con = db.connect()
    if family:
        con.execute("UPDATE customers SET name=?, family=? WHERE id=?",
                    (name, family, cid))
    else:
        con.execute("UPDATE customers SET name=? WHERE id=?", (name, cid))
    con.commit()
    con.close()


def customer_has_name(cid):
    """True once the customer has set their (required) first name."""
    con = db.connect()
    r = con.execute("SELECT name FROM customers WHERE id=?", (cid,)).fetchone()
    con.close()
    return bool(r and (r["name"] or "").strip())


# ---------------------------------------------------------------- chat
_CHAT_ROLES = {"customer", "owner", "admin"}
_CHAT_READ_COL = {
    "customer": "customer_read_to",
    "owner": "owner_read_to",
    "admin": "admin_read_to",
}


def chat_start(biz_id, customer_id, subject=""):
    """Open (or reuse) the active thread between a customer and a business."""
    con = db.connect()
    r = con.execute(
        "SELECT * FROM chat_threads WHERE biz_id=? AND customer_id=? AND status='open'",
        (biz_id, customer_id)).fetchone()
    if r:
        con.close()
        return r["id"]
    con.execute("INSERT INTO chat_threads(biz_id,customer_id,subject,status,last_activity) "
                "VALUES(?,?,?,'open',?)", (biz_id, customer_id, str(subject or "")[:150],
                                            time.time()))
    con.commit()
    tid = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
    con.close()
    return tid


def chat_send(thread_id, sender, body, attachment=None):
    """Insert one text and/or attachment message atomically; return message id.

    `attachment` is metadata produced by uploads.save_chat_file(). The private
    `full_path` rollback helper is intentionally ignored by the data layer.
    """
    if sender not in _CHAT_ROLES:
        return None
    text = str(body or "").strip()[:2000]
    if not text and not attachment:
        return None
    con = db.connect()
    try:
        if not con.execute("SELECT 1 FROM chat_threads WHERE id=?", (thread_id,)).fetchone():
            return None
        con.execute("INSERT INTO chat_messages(thread_id,sender,body) VALUES(?,?,?)",
                    (thread_id, sender, text))
        mid = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
        if attachment:
            required = ("stored_name", "original_name", "mime", "size", "kind")
            if not all(attachment.get(k) not in (None, "") for k in required):
                con.rollback()
                return None
            con.execute(
                "INSERT INTO chat_attachments(message_id,stored_name,original_name,mime,size,kind) "
                "VALUES(?,?,?,?,?,?)",
                (mid, str(attachment["stored_name"]), str(attachment["original_name"])[:120],
                 str(attachment["mime"])[:80], int(attachment["size"]),
                 str(attachment["kind"])[:20]))
        read_col = _CHAT_READ_COL[sender]
        con.execute(
            f"UPDATE chat_threads SET last_activity=?, status='open', "
            f"{read_col}=CASE WHEN {read_col}<? THEN ? ELSE {read_col} END WHERE id=?",
            (time.time(), mid, mid, thread_id))
        con.commit()
        if sender == "customer":
            trow = con.execute("SELECT biz_id FROM chat_threads WHERE id=?", (thread_id,)).fetchone()
            if trow:
                db._owner_notify_biz(trow["biz_id"], "chat",
                                     "💬 پیام تازه‌ای از مشتری در گفتگو دریافت شد.",
                                     f"/my/chat/{thread_id}")
        return int(mid)
    except Exception:
        con.rollback()
        return None
    finally:
        con.close()


def chat_thread(tid):
    con = db.connect()
    r = con.execute("SELECT * FROM chat_threads WHERE id=?", (tid,)).fetchone()
    con.close()
    return dict(r) if r else None


def chat_messages(tid, after=0):
    """Public message shape. Private stored_name is never selected here."""
    return db._rows(
        "SELECT m.*, a.id attachment_id, a.original_name file_name, "
        "a.mime file_type, a.size file_size, a.kind file_kind "
        "FROM chat_messages m LEFT JOIN chat_attachments a ON a.message_id=m.id "
        "WHERE m.thread_id=? AND m.id>? ORDER BY m.id",
        (tid, max(0, int(after or 0))))


def chat_attachment(aid):
    """Internal metadata for an authenticated controller; includes disk name."""
    return db._one(
        "SELECT a.*, m.thread_id, t.biz_id, t.customer_id "
        "FROM chat_attachments a "
        "JOIN chat_messages m ON m.id=a.message_id "
        "JOIN chat_threads t ON t.id=m.thread_id WHERE a.id=?", (aid,))


def chat_attachment_names():
    names = [r["stored_name"] for r in db._rows("SELECT stored_name FROM chat_attachments")]
    try:
        names += db.ticket_attachment_names()
    except Exception:
        pass
    return names


def chat_mark_read(tid, role):
    col = _CHAT_READ_COL.get(role)
    if not col:
        return False
    con = db.connect()
    try:
        row = con.execute("SELECT COALESCE(MAX(id),0) n FROM chat_messages WHERE thread_id=?",
                          (tid,)).fetchone()
        con.execute(f"UPDATE chat_threads SET {col}=? WHERE id=?", (int(row["n"]), tid))
        con.commit()
        return True
    finally:
        con.close()


def chat_unread_count(tid, role):
    col = _CHAT_READ_COL.get(role)
    if not col:
        return 0
    r = db._one(
        f"SELECT COUNT(*) c FROM chat_messages m JOIN chat_threads t ON t.id=m.thread_id "
        f"WHERE m.thread_id=? AND m.id>COALESCE(t.{col},0) AND m.sender<>?",
        (tid, role))
    return int(r["c"] or 0) if r else 0


def _thread_rows(where="", params=(), viewer_role="admin", include_phone=False, limit=None):
    """One grouped query: participant + last message + attachment + unread."""
    role = viewer_role if viewer_role in _CHAT_ROLES else "admin"
    read_col = _CHAT_READ_COL[role]
    phone_sql = "c.phone" if include_phone else "''"
    q = ("SELECT t.*, b.name bizname, b.slug bizslug, c.name custname, "
         f"{phone_sql} custphone, "
         "lm.id last_id, lm.sender last_sender, lm.body last_body, lm.created last_created, "
         "la.id last_attachment_id, la.original_name last_file_name, "
         "la.kind last_file_kind, la.mime last_file_type, la.size last_file_size, "
         "(SELECT COUNT(*) FROM chat_messages cm WHERE cm.thread_id=t.id) n_msgs, "
         f"(SELECT COUNT(*) FROM chat_messages um WHERE um.thread_id=t.id "
         f"AND um.id>COALESCE(t.{read_col},0) AND um.sender<>?) unread "
         "FROM chat_threads t JOIN businesses b ON b.id=t.biz_id "
         "LEFT JOIN customers c ON c.id=t.customer_id "
         "LEFT JOIN chat_messages lm ON lm.id=(SELECT MAX(mx.id) FROM chat_messages mx "
         "WHERE mx.thread_id=t.id) "
         "LEFT JOIN chat_attachments la ON la.message_id=lm.id "
         + (" " + where if where else "") + " ORDER BY t.last_activity DESC")
    values=[role]+list(params)
    if limit is not None:
        q+=" LIMIT ?";values.append(max(1,min(int(limit),100)))
    rows = db._rows(q, values)
    for row in rows:
        row["last"] = ({
            "id": row.pop("last_id"),
            "sender": row.pop("last_sender"),
            "body": row.pop("last_body") or "",
            "created": row.pop("last_created") or "",
            "attachment_id": row.pop("last_attachment_id"),
            "file_name": row.pop("last_file_name"),
            "file_kind": row.pop("last_file_kind"),
            "file_type": row.pop("last_file_type"),
            "file_size": row.pop("last_file_size"),
        } if row.get("last_id") else None)
        row["unread"] = int(row.get("unread") or 0)
        row["n_msgs"] = int(row.get("n_msgs") or 0)
    return rows


def chat_threads_for_owner(owner_id):
    """Every conversation belonging to one shopkeeper; customer phone hidden."""
    con = db.connect()
    biz_ids = [r["id"] for r in con.execute(
        "SELECT id FROM businesses WHERE owner_id=?", (owner_id,))]
    con.close()
    if not biz_ids:
        return []
    marks = ",".join("?" * len(biz_ids))
    return _thread_rows(f"WHERE t.biz_id IN ({marks})", biz_ids, "owner", False)


def chat_threads_all(term="", status="", page=None, per=50):
    """Admin control-center query with safe search and status filtering."""
    clauses, params = [], []
    term = str(term or "").strip()[:120]
    if term:
        like = f"%{term}%"
        clauses.append("(b.name LIKE ? OR c.name LIKE ? OR c.phone LIKE ? OR t.subject LIKE ?)")
        params.extend([like, like, like, like])
    if status in ("open", "closed"):
        clauses.append("t.status=?")
        params.append(status)
    where = "WHERE " + " AND ".join(clauses) if clauses else ""
    rows = _thread_rows(where, params, "admin", True)
    if page is not None:                   # v117/M3
        return db._page_slice(rows, page, per)
    return rows


def chat_threads_for_customer(customer_id):
    return _thread_rows("WHERE t.customer_id=?", (customer_id,), "customer", True)


def customer_chat_summaries(customer_id, limit=5):
    """Bounded customer inbox projection for linked messengers."""
    if not customer_id:return []
    return _thread_rows("WHERE t.customer_id=?",(int(customer_id),),"customer",False,max(1,min(int(limit or 5),10)))


def customer_chat_detail(customer_id, thread_id, limit=6):
    if not customer_id:return None
    thread=db._one("SELECT t.id,t.biz_id,t.customer_id,t.subject,t.status,t.last_activity,"
                   "b.name bizname,b.slug bizslug FROM chat_threads t JOIN businesses b ON b.id=t.biz_id "
                   "WHERE t.id=? AND t.customer_id=?",(int(thread_id),int(customer_id)))
    if not thread:return None
    rows=db._rows("SELECT m.id,m.sender,m.body,m.created,a.id attachment_id,"
                  "a.original_name file_name,a.kind file_kind,a.size file_size "
                  "FROM chat_messages m LEFT JOIN chat_attachments a ON a.message_id=m.id "
                  "WHERE m.thread_id=? ORDER BY m.id DESC LIMIT ?",(int(thread_id),max(1,min(int(limit or 6),12))))
    thread["messages"]=list(reversed(rows));thread["unread"]=chat_unread_count(thread_id,"customer")
    return thread


def customer_chat_reply_prepare(customer_id,thread_id,body):
    """Create a short-lived, one-use confirmation bound to customer+thread."""
    text=str(body or "").strip()[:240]
    if not customer_id or not text:return ""
    if not db._one("SELECT 1 FROM chat_threads WHERE id=? AND customer_id=? AND status='open'",(int(thread_id),int(customer_id))):return ""
    token=secrets.token_urlsafe(9);token_hash=hashlib.sha256(token.encode()).hexdigest()
    db._run("DELETE FROM bot_confirmations WHERE expires<? OR used=1",(time.time(),))
    db._run("INSERT INTO bot_confirmations(token,customer_id,action,target_id,value,expires) VALUES(?,?,'chat_reply',?,?,?)",
            (token_hash,int(customer_id),int(thread_id),text,time.time()+300))
    return token


def customer_chat_reply_confirmed(customer_id,token):
    """Consume confirmation and insert exactly one reply in one transaction."""
    if not customer_id or not re.fullmatch(r"[A-Za-z0-9_-]{8,24}",str(token or "")):return None
    token_hash=hashlib.sha256(str(token).encode()).hexdigest();con=db.connect()
    try:
        con.execute("BEGIN IMMEDIATE")
        claim=con.execute("SELECT target_id,value FROM bot_confirmations WHERE token=? AND customer_id=? AND action='chat_reply' AND used=0 AND expires>=?",
                          (token_hash,int(customer_id),time.time())).fetchone()
        if not claim:con.rollback();return None
        thread=con.execute("SELECT id,biz_id FROM chat_threads WHERE id=? AND customer_id=? AND status='open'",
                           (int(claim["target_id"]),int(customer_id))).fetchone()
        if not thread:con.rollback();return None
        changed=con.execute("UPDATE bot_confirmations SET used=1 WHERE token=? AND used=0",(token_hash,)).rowcount
        if changed!=1:con.rollback();return None
        con.execute("INSERT INTO chat_messages(thread_id,sender,body) VALUES(?,'customer',?)",(int(thread["id"]),claim["value"]))
        mid=int(con.execute("SELECT last_insert_rowid() i").fetchone()["i"])
        con.execute("UPDATE chat_threads SET last_activity=?,customer_read_to=CASE WHEN customer_read_to<? THEN ? ELSE customer_read_to END WHERE id=? AND customer_id=?",
                    (time.time(),mid,mid,int(thread["id"]),int(customer_id)))
        con.commit();biz_id=int(thread["biz_id"]);thread_id=int(thread["id"])
    except Exception:
        con.rollback();return None
    finally:con.close()
    db._owner_notify_biz(biz_id,"chat","💬 پیام تازه‌ای از مشتری در گفتگو دریافت شد.",f"/my/chat/{thread_id}")
    db.log("chat.bot-reply",f"thread={thread_id} customer={int(customer_id)}")
    return {"id":mid,"thread_id":thread_id}


def _g2j_date(gy,gm,gd):
    gdm=[0,31,59,90,120,151,181,212,243,273,304,334];gy2=gy+1 if gm>2 else gy
    days=355666+365*gy+(gy2+3)//4-(gy2+99)//100+(gy2+399)//400+gd+gdm[gm-1]
    jy=-1595+33*(days//12053);days%=12053;jy+=4*(days//1461);days%=1461
    if days>365:jy+=(days-1)//365;days=(days-1)%365
    return (jy,1+days//31,1+days%31) if days<186 else (jy,7+(days-186)//30,1+(days-186)%30)


def owner_bot_summary(owner_id):
    """Small all-in-one daily owner projection for bot dashboard."""
    biz_ids=[r["id"] for r in db._rows("SELECT id FROM businesses WHERE owner_id=?",(int(owner_id),))]
    if not biz_ids:return {"businesses":0,"new_orders":0,"today_bookings":0,"unread_chats":0,"open_stock":0,"assistant_events":0,"open_cancels":0}
    marks=",".join("?"*len(biz_ids));now=db.iran_now();jy,jm,jd=_g2j_date(now.year,now.month,now.day)
    g=now.strftime("%Y/%m/%d");j=f"{jy:04d}/{jm:02d}/{jd:02d}"
    # v231: _norm_anydate also zero-pads — the old inline fold missed raw
    # web dates like 1405-6-19 (never equal to the padded today), while
    # still matching Gregorian-stored dates (v206 pin).
    dates=[_norm_anydate(r["date"]) for r in db._rows(f"SELECT date FROM bookings WHERE biz_id IN ({marks}) AND status IN ('new','confirmed') ORDER BY id DESC LIMIT 500",biz_ids)]
    try:
        import assistant as _assist
        _ad=_assist.digest_counts(owner_id)
    except Exception:
        _ad={"tool_events":0,"open_cancels":0}
    return {"businesses":len(biz_ids),
      "new_orders":int(db._one(f"SELECT COUNT(*) c FROM orders WHERE status='new' AND biz_id IN ({marks})",biz_ids)["c"]),
      "today_bookings":sum(x in (g,j) for x in dates),
      "unread_chats":chat_unread_owner(owner_id),
      "open_stock":int(db._one(f"SELECT COUNT(*) c FROM stock_requests WHERE status='open' AND biz_id IN ({marks})",biz_ids)["c"]),
      "assistant_events":int(_ad.get("tool_events",0)),
      "open_cancels":int(_ad.get("open_cancels",0))}


def send_owner_daily_summaries(day=None):
    """Idempotent daily owner digest; timer may safely run more than once."""
    day=str(day or db.iran_now().date().isoformat())[:10];sent=0
    owners=db._rows("SELECT DISTINCT o.id FROM owners o JOIN businesses b ON b.owner_id=o.id WHERE o.status!='blocked'")
    for owner in owners:
        oid=int(owner["id"]);con=db.connect()
        try:
            con.execute("BEGIN IMMEDIATE");cur=con.execute("INSERT OR IGNORE INTO owner_daily_summaries(owner_id,day,sent_at) VALUES(?,?,?)",(oid,day,time.time()));con.commit()
        finally:con.close()
        if cur.rowcount!=1:continue
        s=owner_bot_summary(oid);text=(f"📊 خلاصهٔ روزانهٔ کسب‌وکار\nسفارش جدید: {s['new_orders']} · نوبت امروز: {s['today_bookings']} · پیام خوانده‌نشده: {s['unread_chats']} · درخواست موجودی: {s['open_stock']} · دستیار (۲۴ساعت): {s['assistant_events']} · درخواست لغو باز: {s['open_cancels']}")
        if db.owner_notify(oid,"summary",text,"/my",push=False):sent+=1
    return sent


def owner_order_summaries(owner_id,limit=5):
    rows=db._rows("SELECT o.id,o.status,o.total,o.created,o.name,b.name bizname FROM orders o JOIN businesses b ON b.id=o.biz_id WHERE b.owner_id=? ORDER BY o.id DESC LIMIT ?",(int(owner_id),max(1,min(int(limit or 5),10))))
    for r in rows:r["status_label"]=ORDER_LABELS.get(r["status"],("",r["status"]))[1]
    return rows


def owner_order_detail(owner_id,order_id):
    row=db._one("SELECT o.id,o.status,o.total,o.created,o.name,b.name bizname FROM orders o JOIN businesses b ON b.id=o.biz_id WHERE o.id=? AND b.owner_id=?",(int(order_id),int(owner_id)))
    if not row:return None
    row["status_label"]=ORDER_LABELS.get(row["status"],("",row["status"]))[1];row["items"]=db._rows("SELECT title,qty,price FROM order_items WHERE order_id=? ORDER BY id LIMIT 30",(int(order_id),));return row


def owner_today_bookings(owner_id,limit=8):
    now=db.iran_now();jy,jm,jd=_g2j_date(now.year,now.month,now.day);keys={now.strftime("%Y/%m/%d"),f"{jy:04d}/{jm:02d}/{jd:02d}"}
    rows=db._rows("SELECT k.id,k.date,k.time,k.status,k.name,b.name bizname FROM bookings k JOIN businesses b ON b.id=k.biz_id WHERE b.owner_id=? AND k.status IN ('new','confirmed') ORDER BY k.time,k.id LIMIT 500",(int(owner_id),));out=[]
    for r in rows:
        d=str(r["date"] or "").translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹","0123456789")).replace("-","/")
        if d in keys:r["status_label"]=db.BOOKING_LABELS.get(r["status"],r["status"]);out.append(r)
    return out[:max(1,min(int(limit or 8),12))]


def owner_chat_summaries(owner_id,limit=5):
    if not owner_id:return []
    biz_ids=[r["id"] for r in db._rows("SELECT id FROM businesses WHERE owner_id=?",(int(owner_id),))]
    if not biz_ids:return []
    marks=",".join("?"*len(biz_ids));return _thread_rows(f"WHERE t.biz_id IN ({marks})",biz_ids,"owner",False,max(1,min(int(limit or 5),10)))


def owner_chat_detail(owner_id,thread_id,limit=6):
    row=db._one("SELECT t.id,t.status,t.subject,b.name bizname,c.name custname FROM chat_threads t JOIN businesses b ON b.id=t.biz_id LEFT JOIN customers c ON c.id=t.customer_id WHERE t.id=? AND b.owner_id=?",(int(thread_id),int(owner_id)))
    if not row:return None
    msgs=db._rows("SELECT m.id,m.sender,m.body,m.created,a.id attachment_id,a.original_name file_name,a.kind file_kind FROM chat_messages m LEFT JOIN chat_attachments a ON a.message_id=m.id WHERE m.thread_id=? ORDER BY m.id DESC LIMIT ?",(int(thread_id),max(1,min(int(limit or 6),12))));row["messages"]=list(reversed(msgs));row["unread"]=chat_unread_count(thread_id,"owner");return row


_OWNER_ACTION_VALUES={"order_status":{"confirmed","ready","done"},"booking_status":{"confirmed","done"},"stock_fulfill":{"yes"},"broadcast":{"news"}}


def owner_bot_action_prepare(owner_id,action,target_id,value):
    if action not in _OWNER_ACTION_VALUES or value not in _OWNER_ACTION_VALUES[action]:return ""
    owner_id,target_id=int(owner_id),int(target_id)
    if action=="order_status":
        row=db._one("SELECT o.status FROM orders o JOIN businesses b ON b.id=o.biz_id WHERE o.id=? AND b.owner_id=?",(target_id,owner_id));ok=row if row and {"new":"confirmed","confirmed":"ready","ready":"done"}.get(row["status"])==value else None
    elif action=="booking_status":
        br=db._one("SELECT k.biz_id,k.status FROM bookings k JOIN businesses b ON b.id=k.biz_id WHERE k.id=? AND b.owner_id=?",(target_id,owner_id));ok=br if br and {"new":"confirmed","confirmed":"done"}.get(br["status"])==value and db.can(br["biz_id"],"booking") else None
    elif action=="stock_fulfill":ok=db._one("SELECT 1 FROM stock_requests sr JOIN businesses b ON b.id=sr.biz_id WHERE sr.id=? AND sr.status='open' AND b.owner_id=?",(target_id,owner_id))
    else:ok=db._one("SELECT 1 FROM businesses WHERE id=? AND owner_id=?",(target_id,owner_id)) if db.broadcast_allowed(target_id) else None
    if not ok:return ""
    token=secrets.token_urlsafe(9);token_hash=hashlib.sha256(token.encode()).hexdigest();db._run("DELETE FROM owner_bot_confirmations WHERE expires<? OR used=1",(time.time(),));db._run("INSERT INTO owner_bot_confirmations(token,owner_id,action,target_id,value,expires) VALUES(?,?,?,?,?,?)",(token_hash,owner_id,action,target_id,value,time.time()+300));return token


def owner_bot_action_confirm(owner_id,token):
    if not re.fullmatch(r"[A-Za-z0-9_-]{8,24}",str(token or "")):return None
    token_hash=hashlib.sha256(str(token).encode()).hexdigest();con=db.connect();post=None
    try:
        con.execute("BEGIN IMMEDIATE");cl=con.execute("SELECT action,target_id,value FROM owner_bot_confirmations WHERE token=? AND owner_id=? AND used=0 AND expires>=?",(token_hash,int(owner_id),time.time())).fetchone()
        if not cl:con.rollback();return None
        action,target,value=cl["action"],int(cl["target_id"]),cl["value"]
        if action=="order_status":
            row=con.execute("SELECT o.status,o.customer_id FROM orders o JOIN businesses b ON b.id=o.biz_id WHERE o.id=? AND b.owner_id=?",(target,int(owner_id))).fetchone();allowed={"new":"confirmed","confirmed":"ready","ready":"done"}
            if not row or allowed.get(row["status"])!=value:con.rollback();return None
            con.execute("UPDATE orders SET status=? WHERE id=?",(value,target));post=(action,row["customer_id"],target,value)
        elif action=="booking_status":
            row=con.execute("SELECT k.status,k.customer_id,k.date,k.time,k.biz_id FROM bookings k JOIN businesses b ON b.id=k.biz_id WHERE k.id=? AND b.owner_id=?",(target,int(owner_id))).fetchone();allowed={"new":"confirmed","confirmed":"done"}
            if not row or allowed.get(row["status"])!=value or not db.can(row["biz_id"],"booking"):con.rollback();return None
            con.execute("UPDATE bookings SET status=? WHERE id=?",(value,target));post=(action,dict(row),target,value)
        elif action=="stock_fulfill":
            row=con.execute("SELECT sr.customer_id,sr.item_id,i.title item_title,b.name biz_name,b.slug biz_slug FROM stock_requests sr JOIN businesses b ON b.id=sr.biz_id LEFT JOIN items i ON i.id=sr.item_id WHERE sr.id=? AND sr.status='open' AND b.owner_id=?",(target,int(owner_id))).fetchone()
            if not row:con.rollback();return None
            con.execute("UPDATE stock_requests SET status='fulfilled',fulfilled=datetime('now') WHERE id=? AND status='open'",(target,));post=(action,dict(row),target,value)
        elif action=="broadcast":
            row=con.execute("SELECT id,name FROM businesses WHERE id=? AND owner_id=?",(target,int(owner_id))).fetchone()
            if not row:con.rollback();return None
            post=(action,dict(row),target,value)
        else:con.rollback();return None
        if con.execute("UPDATE owner_bot_confirmations SET used=1 WHERE token=? AND used=0",(token_hash,)).rowcount!=1:con.rollback();return None
        con.commit()
    except Exception:con.rollback();return None
    finally:con.close()
    if action=="order_status" and post[1]:
        label=ORDER_LABELS[value][1];db.notify_customer(post[1],"order",f"وضعیت سفارش #{target} به «{label}» تغییر کرد.",f"/me/order/{target}")
    elif action=="booking_status" and post[1].get("customer_id"):
        r=post[1];b=db.business(bid=r["biz_id"]) or {};db.notify_customer(r["customer_id"],"booking",f"وضعیت نوبت شما در «{b.get('name','کسب‌وکار')}» برای {r['date']} ساعت {r['time']} به «{db.BOOKING_LABELS[value]}» تغییر کرد.",f"/b/{b.get('slug','')}")
    elif action=="stock_fulfill":
        r=post[1];link=f"/item/{r['item_id']}" if r["item_id"] else f"/b/{r['biz_slug']}";db.notify_customer(r["customer_id"],"broadcast",f"«{r['item_title'] or 'کالای موردنظر شما'}» در «{r['biz_name']}» موجود شد.",link,push=False)
    elif action=="broadcast":
        if not db.broadcast_allowed(target) or not db.rate_ok(f"bot-broadcast:{owner_id}:{target}",limit=3,window=3600,always=True):return {"action":action,"ok":False,"error":"rate_or_access"}
        bid,sent=db.broadcast_create(target,"news",f"خبرهای تازهٔ «{post[1]['name']}» را در دست گیر ببینید.");return {"action":action,"ok":bool(bid),"recipients":sent}
    db.log(f"bot.owner.{action}",f"owner={owner_id} target={target} value={value}");return {"action":action,"ok":True,"target_id":target,"value":value}


def chat_unread_owner(owner_id):
    """Number of threads that currently need the shopkeeper's attention."""
    return sum(1 for t in chat_threads_for_owner(owner_id) if t.get("unread"))


def chat_unread_customer(customer_id):
    """Total unread messages across one customer's conversations.

    Used for the bottom-nav badge so a signed-in customer can see, at a
    glance, that a shopkeeper replied -- and tap straight back into it.
    """
    return sum(int(t.get("unread") or 0)
               for t in chat_threads_for_customer(customer_id))


CHAT_RETENTION_DAYS = 7


def expired_chat_attachments(max_age_days=CHAT_RETENTION_DAYS):
    """Chat attachments older than the retention window.

    Deliberately sender-agnostic: an image is purged once it passes the age
    limit whether the CUSTOMER or the SHOPKEEPER sent it, so neither side of
    the conversation is kept on the server longer than the other.
    """
    con = db.connect()
    rows = con.execute(
        "SELECT id, stored_name, size FROM chat_attachments "
        "WHERE created < datetime('now', ?)",
        (f"-{int(max_age_days)} days",)).fetchall()
    con.close()
    return [dict(r) for r in rows]


def delete_chat_attachments(ids):
    """Remove attachment rows by id; returns how many rows were deleted."""
    ids = [int(i) for i in (ids or [])]
    if not ids:
        return 0
    con = db.connect()
    marks = ",".join("?" * len(ids))
    cur = con.execute(f"DELETE FROM chat_attachments WHERE id IN ({marks})", ids)
    con.commit()
    n = cur.rowcount
    con.close()
    return n


def chat_set_status(tid, status):
    if status not in ("open", "closed"):
        return False
    con = db.connect()
    cur = con.execute("UPDATE chat_threads SET status=? WHERE id=?", (status, tid))
    con.commit()
    con.close()
    return cur.rowcount > 0


def db_chat_msg_ids(tid):
    con = db.connect()
    n = con.execute("SELECT COUNT(*) c FROM chat_messages WHERE thread_id=?",
                    (tid,)).fetchone()["c"]
    con.close()
    return n


# ---------------------------------------------------------------- orders
ORDER_STATUS = ["new", "confirmed", "ready", "done", "cancelled"]
ORDER_LABELS = {
    "new": ("badge-warn", "جدید"),
    "confirmed": ("badge-info", "تأیید شد"),
    "ready": ("badge-open", "آمادهٔ تحویل"),
    "done": ("badge-neutral", "تحویل شد"),
    "cancelled": ("badge-closed", "لغو شد"),
}


def price_items_from_catalog(biz_id, items):
    """Server-side price integrity for orders (audit F-012).

    The cart JSON is client-supplied, so a crafted POST could reference a
    real catalogue item with a forged price of 0. Whenever an entry points
    at a real item of THIS business, the catalogue's own title/price wins
    and the client's numbers are discarded. Free-text entries (no item_id,
    or an id belonging to another business) keep the sent values — those are
    the custom rows the order flow has always allowed."""
    con = db.connect()
    try:
        for i in items:
            iid = i.get("item_id")
            if not iid:
                continue
            r = con.execute(
                "SELECT title, price FROM items WHERE id=? AND biz_id=?",
                (iid, biz_id)).fetchone()
            if r:
                i["title"] = (r["title"] or i.get("title") or "")[:150]
                i["price"] = int(r["price"] or 0)
            else:
                # v175/#40: an item_id that is NOT a real item of THIS business
                # must never reach order_items — a non-existent id died inside
                # INSERT with FOREIGN KEY (500), and another shop's real id
                # silently pointed this order's row at a foreign catalogue
                # item. Both are now demoted to the free-text custom row the
                # flow always allowed (title/price as sent, item_id NULL).
                i["item_id"] = None
    finally:
        con.close()
    return items


def create_order(biz_id, customer_id, name, phone, address, note, items, share_phone=False):
    """items: [{item_id, title, price, qty}] -> order id."""
    def _safe_int(v, d=0):
        try:
            return int(v)
        except (TypeError, ValueError):
            return d
    total = sum(max(0, _safe_int(i.get("price"), 0)) * max(1, min(99, _safe_int(i.get("qty"), 1)))
                for i in items)
    con = db.connect()
    con.execute("INSERT INTO orders(biz_id,customer_id,name,phone,address,note,total,status,share_phone) "
                "VALUES(?,?,?,?,?,?,?,'new',?)",
                (biz_id, customer_id, str(name)[:100], db.norm_phone(phone),
                 str(address)[:300], str(note)[:500], total, 1 if share_phone else 0))
    oid = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
    for i in items:
        con.execute("INSERT INTO order_items(order_id,item_id,title,price,qty) "
                    "VALUES(?,?,?,?,?)",
                    (oid, i.get("item_id"), str(i.get("title", ""))[:150],
                     max(0, _safe_int(i.get("price"), 0)),
                     max(1, min(99, _safe_int(i.get("qty"), 1)))))
    con.commit()
    con.close()
    db._owner_notify_biz(biz_id, "order", "📦 سفارش جدیدی برای کسب‌وکار شما ثبت شد.",
                         "/my/orders")
    return oid


def order(oid):
    con = db.connect()
    r = con.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone()
    con.close()
    return dict(r) if r else None


def order_items(oid):
    con = db.connect()
    rows = [dict(r) for r in con.execute(
        "SELECT * FROM order_items WHERE order_id=? ORDER BY id", (oid,))]
    con.close()
    return rows


def orders_for_owner(owner_id):
    con = db.connect()
    rows = [dict(r) for r in con.execute(
        "SELECT o.id FROM orders o JOIN businesses b ON b.id=o.biz_id "
        "WHERE b.owner_id=? ORDER BY o.id DESC LIMIT 2000", (owner_id,))]
    con.close()
    if not rows:
        return []
    return _order_rows([r["id"] for r in rows])


def orders_all(page=None, per=50, status=None, q=None):
    """v117/M3: paginated for the admin panel — items are fetched for the
    page window only (was: 2000 orders × one items query each = N+1).
    v296: فیلتر وضعیت + جستجوی نام/تلفن/شماره برای پنل."""
    con = db.connect()
    where, params = [], []
    if status:
        where.append("status=?")
        params.append(status)
    if q:
        like = f"%{q}%"
        where.append("(name LIKE ? OR phone LIKE ? OR CAST(id AS TEXT)=?)")
        params += [like, like, q]
    wsql = (" WHERE " + " AND ".join(where)) if where else ""
    if page is not None:
        total = con.execute("SELECT COUNT(*) FROM orders" + wsql, params).fetchone()[0]
        ids = [r["id"] for r in con.execute(
            "SELECT id FROM orders" + wsql + " ORDER BY id DESC LIMIT ? OFFSET ?",
            params + [per, max(0, (int(page) - 1) * per)])]
        con.close()
        rows = _order_rows(ids)
        return {"rows": rows, "total": total,
                "pages": max(1, -(-total // per)), "page": int(page)}
    rows = [r["id"] for r in con.execute(
        "SELECT id FROM orders" + wsql + " ORDER BY id DESC LIMIT 2000", params)]
    con.close()
    return _order_rows([r for r in rows])


def order_get(oid):
    """v296: یک سفارش + اقلامش برای صفحهٔ جزئیات پنل؛ ناموجود = None."""
    rows = db._rows(
        "SELECT o.*, b.name bizname, b.slug bizslug FROM orders o "
        "JOIN businesses b ON b.id=o.biz_id WHERE o.id=?", (oid,))
    if not rows:
        return None
    o = rows[0]
    o["status_label"] = ORDER_LABELS.get(o["status"], ("", o["status"]))[1]
    o["items"] = db._rows(
        "SELECT title, price, qty FROM order_items WHERE order_id=? ORDER BY id",
        (oid,))
    return o


# ------------------------------------------------------------------ v296
# خروجی CSV عملیاتی (سفارش/نوبت/مشتری) — با فیلترهای جاری لیست‌ها.
_ORDER_STATUS_FA = {"new": "جدید", "confirmed": "تأییدشده", "ready": "آماده",
                    "done": "تحویل‌شده", "cancelled": "لغوشده"}
_BOOK_STATUS_FA = {"new": "جدید", "confirmed": "تأییدشده",
                   "done": "انجام‌شده", "cancelled": "لغو"}


def _csv_text(header, rows):
    import csv as _csv
    import io as _io
    buf = _io.StringIO()
    w = _csv.writer(buf)
    w.writerow(header)
    for r in rows:
        w.writerow(r)
    return "\ufeff" + buf.getvalue()          # BOM: نمایش درست فارسی در اکسل


def export_orders_csv(status=None, q=None):
    rows = orders_all(status=status, q=q)
    data = [(o["id"], o.get("bizname") or "", o["name"], o["phone"], o["total"],
             _ORDER_STATUS_FA.get(o["status"], o["status"]), o["created"])
            for o in rows]
    return _csv_text(["شماره", "کسب‌وکار", "مشتری", "تلفن", "مبلغ",
                      "وضعیت", "تاریخ"], data)


def export_bookings_csv(status=None, q=None):
    rows = db.bookings(status=status, q=q)
    data = [(k["name"], k["phone"], k.get("bizname") or "", k.get("date") or "",
             k.get("time") or "", _BOOK_STATUS_FA.get(k["status"], k["status"]),
             (k.get("note") or "").replace("\n", " "))
            for k in rows]
    return _csv_text(["مشتری", "تلفن", "کسب‌وکار", "تاریخ", "ساعت",
                      "وضعیت", "توضیح"], data)


def export_customers_csv(q=None):
    rows = customers_list(q=q)
    data = [(r["id"], r["phone"], r.get("name") or "",
             "فعال" if r.get("status", "active") == "active" else "مسدود",
             r["created"])
            for r in rows]
    return _csv_text(["#", "موبایل", "نام", "وضعیت", "عضویت"], data)


def _order_rows(oid_list):
    if not oid_list:
        return []
    q = ("SELECT o.*, b.name bizname, b.slug bizslug FROM orders o "
         "JOIN businesses b ON b.id=o.biz_id WHERE o.id IN (%s) "
         "ORDER BY o.id DESC" % ",".join("?" * len(oid_list)))
    rows = db._rows(q, oid_list)
    for r in rows:
        r["items"] = order_items(r["id"])
        r["status_label"] = ORDER_LABELS.get(r["status"], ("badge-neutral", r["status"]))[1]
    return rows


def orders_for_customer(customer_id):
    con = db.connect()
    ids = [r["id"] for r in con.execute(
        "SELECT id FROM orders WHERE customer_id=? ORDER BY id DESC LIMIT 500",
        (customer_id,))]
    con.close()
    return _order_rows([i for i in ids])


def customer_order_summaries(customer_id, limit=5):
    """Small, bounded projection for messenger menus; no N+1 item loading."""
    limit = max(1, min(int(limit or 5), 10))
    rows = db._rows(
        "SELECT o.id,o.total,o.status,o.created,o.cancel_requested,b.name AS bizname "
        "FROM orders o JOIN businesses b ON b.id=o.biz_id "
        "WHERE o.customer_id=? ORDER BY o.id DESC LIMIT ?",
        (int(customer_id), limit))
    for row in rows:
        row["status_label"] = ORDER_LABELS.get(
            row["status"], ("badge-neutral", row["status"]))[1]
    return rows


def customer_order_detail(customer_id, order_id):
    """Return one owned order and bounded items, never another customer's row."""
    row = db._one(
        "SELECT o.id,o.total,o.status,o.created,o.cancel_requested,o.cancel_reason,o.address,o.note,b.name AS bizname "
        "FROM orders o JOIN businesses b ON b.id=o.biz_id "
        "WHERE o.id=? AND o.customer_id=?",
        (int(order_id), int(customer_id)))
    if not row:
        return None
    out = dict(row)
    out["status_label"] = ORDER_LABELS.get(
        out["status"], ("badge-neutral", out["status"]))[1]
    out["items"] = db._rows(
        "SELECT title,price,qty FROM order_items WHERE order_id=? ORDER BY id LIMIT 30",
        (int(order_id),))
    return out


def set_order_status(oid, status):
    if status not in ORDER_STATUS:
        return False
    con = db.connect(); con.execute("UPDATE orders SET status=? WHERE id=?", (status, oid));con.commit();con.close();return True


def request_order_cancel(oid, customer_id, reason=""):
    o=order(oid)
    if not o or o.get("customer_id")!=customer_id:return {"ok":False,"error":"access"}
    if o.get("status") in ("done","cancelled"):return {"ok":False,"error":"final"}
    try: created=datetime.datetime.strptime(str(o.get("created"))[:19],"%Y-%m-%d %H:%M:%S")
    except Exception: created=datetime.datetime.utcnow()-datetime.timedelta(days=1)
    limit=max(1,int(db.get_settings().get("order_cancel_minutes","30") or 30))
    age=(datetime.datetime.utcnow()-created).total_seconds()/60
    con=db.connect()
    if age<=limit:
        con.execute("UPDATE orders SET status='cancelled',cancel_requested=0,cancel_reason=?,cancel_decided_at=datetime('now') WHERE id=?",(str(reason)[:500],oid));result="cancelled"
    else:
        con.execute("UPDATE orders SET cancel_requested=1,cancel_reason=?,cancel_requested_at=datetime('now') WHERE id=?",(str(reason)[:500],oid));result="requested"
    con.commit();con.close()
    # v224: the shopkeeper must actually hear about it — both the site UI and
    # the assistant already promise the customer the request "was sent".
    nm = str(o.get("name") or "")[:30]
    who = f" ({nm})" if nm else ""
    if result == "requested":
        db._owner_notify_biz(o["biz_id"], "order",
            f"⏳ درخواست لغو سفارش #{oid}{who} — در «سفارش‌ها» تأیید یا رد کنید.",
            "/my/orders")
        # v230: a cancel request needs a decision, and the shopkeeper may not
        # live in the inbox — page the shop's own phone once per request
        # (o is the pre-update snapshot, so a re-request stays silent).
        if not o.get("cancel_requested"):
            b = db.business(bid=o["biz_id"]) or {}
            if b.get("phone"):
                import sms
                sms.notify(db.get_settings(), db.norm_phone(b["phone"]),
                           f"درخواست لغو سفارش #{oid}{who} — در سایت تأیید یا رد کنید.")
    else:
        db._owner_notify_biz(o["biz_id"], "order",
            f"🧾 سفارش #{oid}{who} لغو شد.", "/my/orders")
    return {"ok":True,"result":result,"limit":limit}


def decide_order_cancel(oid, owner_id=None, approve=False):
    o=order(oid)
    if not o or not o.get("cancel_requested"):return False
    if owner_id is not None and not db.owns(owner_id,o["biz_id"]):return False
    con=db.connect()
    if approve:con.execute("UPDATE orders SET status='cancelled',cancel_requested=0,cancel_decided_at=datetime('now') WHERE id=?",(oid,))
    else:con.execute("UPDATE orders SET cancel_requested=0,cancel_decided_at=datetime('now') WHERE id=?",(oid,))
    con.commit();con.close()
    # v146: the customer who asked for the cancellation is told the outcome —
    # otherwise the request would just sit there with no answer.
    if o.get("customer_id") and (db.get_settings().get("notif_enabled", "1") == "1"):
        b = db.business(bid=o.get("biz_id")) or {}
        db.notify_customer(
            o["customer_id"], "order",
            f"درخواست لغو سفارش #{o['id']} «{b.get('name') or ''}» "
            + ("پذیرفته شد و سفارش لغو شد." if approve else "پذیرفته نشد؛ سفارش همچنان فعال است."),
            f"/me/order/{o['id']}")
    return True


def owner_cancel_requests(owner_id, limit=8):
    """v235: pending order-cancel requests across the owner's shops."""
    try:
        oid = int(owner_id)
    except (TypeError, ValueError):
        return []
    return db._rows(
        "SELECT o.id,o.total,o.created,o.name,o.cancel_reason,o.cancel_requested_at,b.name bizname "
        "FROM orders o JOIN businesses b ON b.id=o.biz_id "
        "WHERE b.owner_id=? AND o.cancel_requested=1 ORDER BY o.id DESC LIMIT ?",
        (oid, max(1, min(int(limit or 8), 12))))


def owner_sales_summary(owner_id):
    """v235: 7-day sales numbers for the owner bot panel. Never raises."""
    out = {"rev7": 0, "rev7_count": 0, "open_value": 0, "open_count": 0,
           "bookings7": 0, "cancel_pending": 0}
    try:
        oid = int(owner_id)
    except (TypeError, ValueError):
        return out
    try:
        biz_ids = [r["id"] for r in db._rows("SELECT id FROM businesses WHERE owner_id=?", (oid,))]
        if not biz_ids:
            return out
        marks = ",".join("?" * len(biz_ids))
        r = db._one(
            f"SELECT COUNT(*) c,COALESCE(SUM(total),0) s FROM orders "
            f"WHERE biz_id IN ({marks}) AND status='done' AND created>=datetime('now','-7 days')", biz_ids)
        out["rev7_count"], out["rev7"] = int(r["c"] or 0), int(r["s"] or 0)
        r = db._one(
            f"SELECT COUNT(*) c,COALESCE(SUM(total),0) s FROM orders "
            f"WHERE biz_id IN ({marks}) AND status IN ('new','confirmed','ready')", biz_ids)
        out["open_count"], out["open_value"] = int(r["c"] or 0), int(r["s"] or 0)
        now = db.iran_now()
        keys = set()
        for back in range(7):
            t = now + datetime.timedelta(days=back)
            jy, jm, jd = _g2j_date(t.year, t.month, t.day)
            keys.add(t.strftime("%Y/%m/%d"))
            keys.add(f"{jy:04d}/{jm:02d}/{jd:02d}")
        n = 0
        for r in db._rows(
                f"SELECT date FROM bookings WHERE biz_id IN ({marks}) AND status IN ('new','confirmed') "
                "ORDER BY id DESC LIMIT 500", biz_ids):
            if _norm_anydate(r["date"]) in keys:
                n += 1
        out["bookings7"] = n
        out["cancel_pending"] = int(db._one(
            f"SELECT COUNT(*) c FROM orders WHERE biz_id IN ({marks}) AND cancel_requested=1", biz_ids)["c"] or 0)
    except Exception:
        pass
    return out


def owner_chat_reply_prepare(owner_id, thread_id, body):
    """v235: owner mirror of customer_chat_reply_prepare. The FK column
    carries the thread's customer (0 would violate the FK); confirm()
    re-verifies thread ownership, so the token can't cross shops."""
    text = str(body or "").strip()[:240]
    try:
        oid, tid = int(owner_id), int(thread_id)
    except (TypeError, ValueError):
        return ""
    if not text:
        return ""
    th = db._one("SELECT t.id,t.customer_id FROM chat_threads t JOIN businesses b ON b.id=t.biz_id "
                 "WHERE t.id=? AND b.owner_id=? AND t.status='open'", (tid, oid))
    if not th or not th["customer_id"]:
        return ""
    token = secrets.token_urlsafe(9)
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    db._run("DELETE FROM bot_confirmations WHERE expires<? OR used=1", (time.time(),))
    db._run("INSERT INTO bot_confirmations(token,customer_id,action,target_id,value,expires) VALUES(?,?,'owner_chat_reply',?,?,?)",
            (token_hash, int(th["customer_id"]), tid, text, time.time() + 300))
    return token


def owner_chat_reply_confirmed(owner_id, token):
    """v235: consume an owner reply confirmation; mirror of the customer one."""
    try:
        oid = int(owner_id)
    except (TypeError, ValueError):
        return None
    if not re.fullmatch(r"[A-Za-z0-9_-]{8,24}", str(token or "")):
        return None
    token_hash = hashlib.sha256(str(token).encode()).hexdigest()
    con = db.connect()
    try:
        con.execute("BEGIN IMMEDIATE")
        claim = con.execute("SELECT target_id,value,customer_id FROM bot_confirmations WHERE token=? AND action='owner_chat_reply' AND used=0 AND expires>=?",
                            (token_hash, time.time())).fetchone()
        if not claim:
            con.rollback(); return None
        thread = con.execute("SELECT t.id,t.biz_id,t.customer_id FROM chat_threads t JOIN businesses b ON b.id=t.biz_id "
                             "WHERE t.id=? AND b.owner_id=? AND t.status='open'",
                             (int(claim["target_id"]), oid)).fetchone()
        if not thread:
            con.rollback(); return None
        changed = con.execute("UPDATE bot_confirmations SET used=1 WHERE token=? AND used=0", (token_hash,)).rowcount
        if changed != 1:
            con.rollback(); return None
        con.execute("INSERT INTO chat_messages(thread_id,sender,body) VALUES(?,'owner',?)",
                    (int(thread["id"]), claim["value"]))
        mid = int(con.execute("SELECT last_insert_rowid() i").fetchone()["i"])
        con.execute("UPDATE chat_threads SET last_activity=?,owner_read_to=CASE WHEN owner_read_to<? THEN ? ELSE owner_read_to END WHERE id=?",
                    (time.time(), mid, mid, int(thread["id"])))
        con.commit()
        thread_id, cid = int(thread["id"]), thread["customer_id"]
    except Exception:
        con.rollback(); return None
    finally:
        con.close()
    if cid:
        db.notify_customer(cid, "chat", "💬 پاسخ تازه‌ای از کسب‌وکار در گفتگو دریافت شد.", f"/me/chat/{thread_id}")
    db.log("chat.owner-bot-reply", f"thread={thread_id} owner={oid}")
    return {"id": mid, "thread_id": thread_id}


def _norm_bdate(ds):
    """v229: coerce a stored booking date to zero-padded 'YYYY/MM/DD' or ''.
    Web bookings store the raw form value (1405-6-19, Persian digits…); the
    assistant path is already normalized — this folds every variant."""
    try:
        s = db.translit(str(ds or "")).strip().replace("-", "/").replace(".", "/").replace(" ", "")
        m = re.match(r"^((?:13|14)\d\d)/(0?[1-9]|1[0-2])/(0?[1-9]|[12]\d|3[01])$", s)
        if not m:
            return ""
        return f"{int(m.group(1)):04d}/{int(m.group(2)):02d}/{int(m.group(3)):02d}"
    except Exception:
        return ""


def _norm_anydate(ds):
    """v231: _norm_bdate, but a Gregorian Y/M/D is folded too. The owner
    dashboard counts Gregorian-stored bookings as today (v206 pin); the
    booking form itself is Jalali-labelled, so reminders stay Jalali-only."""
    j = _norm_bdate(ds)
    if j:
        return j
    try:
        s = db.translit(str(ds or "")).strip().replace("-", "/").replace(".", "/").replace(" ", "")
        m = re.match(r"^(\d{4})/(0?[1-9]|1[0-2])/(0?[1-9]|[12]\d|3[01])$", s)
        if not m:
            return ""
        return f"{int(m.group(1)):04d}/{int(m.group(2)):02d}/{int(m.group(3)):02d}"
    except Exception:
        return ""


def booking_reminders():
    """v229: remind customers of tomorrow's bookings (Iran time). One inbox
    line per booking per date via notify_customer (prefs/push/messenger
    aware); a muted customer is retried — not marked — so unmuting delivers.
    Runs from the hourly sweep; never raises so a reminder can never 500
    a page view. Returns the number of reminders sent."""
    sent = 0
    try:
        t = db.iran_now().date() + datetime.timedelta(days=1)
        jy, jm, jd = _g2j_date(t.year, t.month, t.day)
        tomorrow = f"{jy:04d}/{jm:02d}/{jd:02d}"
        rows = db._rows(
            "SELECT k.*, b.name bizname, b.slug bizslug FROM bookings k "
            "JOIN businesses b ON b.id=k.biz_id "
            "WHERE k.status IN ('new','confirmed') AND k.customer_id IS NOT NULL")
        for r in rows:
            if _norm_bdate(r.get("date")) != tomorrow:
                continue
            if (r.get("reminded") or "") == tomorrow:
                continue
            ok = db.notify_customer(
                r["customer_id"], "booking",
                f"⏰ یادآوری: نوبت فردای شما در «{r['bizname']}» — {tomorrow} ساعت {r['time']}",
                f"/b/{r['bizslug']}" if r.get("bizslug") else "/me")
            if ok:
                db._run("UPDATE bookings SET reminded=? WHERE id=?", (tomorrow, r["id"]))
                sent += 1
    except Exception:
        pass
    return sent


# ---------------------------------------------------------------- areas
def areas():
    """Distinct neighbourhood names from published businesses, with counts."""
    con = db.connect()
    rows = [dict(r) for r in con.execute(
        "SELECT area, COUNT(*) c FROM businesses "
        "WHERE status='published' AND COALESCE(area,'')<>'' "
        "GROUP BY area ORDER BY c DESC, area")]
    con.close()
    return rows


def businesses_in_area(area, limit=None):
    con = db.connect()
    q = ("SELECT b.*, (SELECT AVG(rating) FROM reviews WHERE biz_id=b.id AND status='approved' AND rating>0) rating, "
         "(SELECT COUNT(*) FROM reviews WHERE biz_id=b.id AND status='approved') nreviews "
         "FROM businesses b WHERE b.status='published' AND b.area=? "
         "ORDER BY b.featured DESC, rating DESC NULLS LAST, b.id DESC")
    p = [area]
    if limit:
        q += " LIMIT ?"; p.append(int(limit))
    rows = [db._biz_row(r) for r in con.execute(q, p)]
    con.close()
    return annotate_stories(rows)


# ---------------------------------------------------------------- server favorites
def fav_list(customer_id):
    if not customer_id:
        return []
    con = db.connect()
    rows = [r["biz_id"] for r in con.execute(
        "SELECT biz_id FROM favorites WHERE customer_id=? ORDER BY id DESC",
        (customer_id,))]
    con.close()
    return rows


def fav_slugs(customer_id):
    """The canonical browser-facing favourite set for a signed-in customer."""
    if not customer_id:
        return []
    return [r["slug"] for r in db._rows(
        "SELECT b.slug FROM favorites f JOIN businesses b ON b.id=f.biz_id "
        "WHERE f.customer_id=? AND b.status='published' ORDER BY f.id DESC",
        (customer_id,))]


def favorite_summaries(customer_id, limit=10):
    if not customer_id: return []
    return db._rows(
        "SELECT b.id,b.slug,b.name,b.address,b.phone,b.lat,b.lng,b.verified "
        "FROM favorites f JOIN businesses b ON b.id=f.biz_id "
        "WHERE f.customer_id=? AND b.status='published' ORDER BY f.id DESC LIMIT ?",
        (int(customer_id), max(1,min(int(limit or 10),20))))


def favorite_add(customer_id, biz_id):
    if not customer_id: return False
    row=db._one("SELECT 1 FROM businesses WHERE id=? AND status='published'",(int(biz_id),))
    if not row:return False
    db._run("INSERT OR IGNORE INTO favorites(customer_id,biz_id) VALUES(?,?)",
            (int(customer_id),int(biz_id)))
    return True


def favorite_remove(customer_id, biz_id):
    if not customer_id:return False
    con=db.connect();cur=con.execute("DELETE FROM favorites WHERE customer_id=? AND biz_id=?",
                                    (int(customer_id),int(biz_id)));con.commit();con.close()
    return cur.rowcount==1


def fav_state(customer_id, biz_id):
    if not customer_id or not biz_id:
        return False
    return bool(db._one("SELECT 1 FROM favorites WHERE customer_id=? AND biz_id=?",
                        (customer_id, biz_id)))


def fav_toggle(customer_id, biz_id):
    if not customer_id:
        return False
    con = db.connect()
    r = con.execute("SELECT 1 FROM favorites WHERE customer_id=? AND biz_id=?",
                    (customer_id, biz_id)).fetchone()
    if r:
        con.execute("DELETE FROM favorites WHERE customer_id=? AND biz_id=?",
                    (customer_id, biz_id))
        on = False
    else:
        con.execute("INSERT INTO favorites(customer_id,biz_id) VALUES(?,?)",
                    (customer_id, biz_id))
        on = True
    con.commit()
    con.close()
    return on


def fav_merge(customer_id, values):
    """Adopt the device-local favorites after sign-in. `values` may contain
    business ids OR slugs (the device stores slugs)."""
    if not customer_id:
        return 0
    con = db.connect()
    n = 0
    for b in (values or []):
        bid = None
        try:
            bid = int(b)
            if not con.execute("SELECT 1 FROM businesses WHERE id=?", (bid,)).fetchone():
                bid = None
        except (TypeError, ValueError):
            bid = None
        if bid is None:
            r = con.execute("SELECT id FROM businesses WHERE slug=?",
                            (str(b).strip(),)).fetchone()
            bid = r["id"] if r else None
        if bid is None:
            continue
        if not con.execute("SELECT 1 FROM favorites WHERE customer_id=? AND biz_id=?",
                           (customer_id, bid)).fetchone():
            con.execute("INSERT INTO favorites(customer_id,biz_id) VALUES(?,?)",
                        (customer_id, bid))
            n += 1
    con.commit()
    con.close()
    return n


# ==========================================================================
#  ADMIN PANEL SUPPORT  (v29): audit log, customers, areas
# ==========================================================================
def _like_esc(s):
    """v228: escape LIKE metacharacters so filter input matches literally."""
    return str(s or "").replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def audit_log(limit=120, action="", detail="", days=0):
    """v117/M5: filterable audit log (action prefix, detail substring, horizon).
    v228: LIKE metacharacters are escaped, not stripped — filtering for
    'assistant_tool' (or any underscore input) finally matches."""
    where, p = [], []
    if action:
        where.append("action LIKE ? ESCAPE '\\'"); p.append(_like_esc(action) + "%")
    if detail:
        where.append("detail LIKE ? ESCAPE '\\'"); p.append("%" + _like_esc(detail) + "%")
    if days and days > 0:
        where.append("created >= datetime('now', ?)"); p.append(f"-{int(days)} days")
    w = ("WHERE " + " AND ".join(where)) if where else ""
    p.append(int(limit))
    return db._rows(f"SELECT * FROM audit {w} ORDER BY id DESC LIMIT ?", p)


def audit_actions():
    """Distinct action names — powers the filter dropdown."""
    return [r["action"] for r in db._rows(
        "SELECT DISTINCT action FROM audit ORDER BY action")]


def customers_list(page=None, per=50, q=None):
    """Every customer account with live counts, for the admin panel.
    v296: جستجوی نام/تلفن."""
    sql = "SELECT * FROM customers"
    params = []
    if q:
        like = f"%{q}%"
        sql += " WHERE phone LIKE ? OR name LIKE ?"
        params += [like, like]
    sql += " ORDER BY id DESC"
    if page is not None:                   # v117/M3 (also kills the 3×N+1)
        con = db.connect()
        out = db._page_result(con, sql, params, page, per)
        rows = out["rows"]
        for r in rows:
            r["n_orders"] = con.execute(
                "SELECT COUNT(*) c FROM orders WHERE customer_id=?", (r["id"],)).fetchone()["c"]
            r["n_chats"] = con.execute(
                "SELECT COUNT(*) c FROM chat_threads WHERE customer_id=?", (r["id"],)).fetchone()["c"]
            r["n_favs"] = con.execute(
                "SELECT COUNT(*) c FROM favorites WHERE customer_id=?", (r["id"],)).fetchone()["c"]
        con.close()
        return out
    rows = db._rows(sql, params)
    con = db.connect()
    for r in rows:
        r["n_orders"] = con.execute(
            "SELECT COUNT(*) c FROM orders WHERE customer_id=?", (r["id"],)).fetchone()["c"]
        r["n_chats"] = con.execute(
            "SELECT COUNT(*) c FROM chat_threads WHERE customer_id=?", (r["id"],)).fetchone()["c"]
        r["n_favs"] = con.execute(
            "SELECT COUNT(*) c FROM favorites WHERE customer_id=?", (r["id"],)).fetchone()["c"]
    con.close()
    return rows


def rename_area(old, new):
    """Rename a neighbourhood everywhere it is used. -> count updated."""
    if not old or not new or old == new:
        return 0
    con = db.connect()
    con.execute("UPDATE businesses SET area=? WHERE area=?", (new, old))
    con.commit()
    n = con.execute("SELECT COUNT(*) c FROM businesses WHERE area=?", (new,)).fetchone()["c"]
    con.close()
    return n


def customer_counts():
    con = db.connect()
    out = {
        "customers": con.execute("SELECT COUNT(*) c FROM customers").fetchone()["c"],
        "orders": con.execute("SELECT COUNT(*) c FROM orders").fetchone()["c"],
        "chats": con.execute("SELECT COUNT(*) c FROM chat_threads").fetchone()["c"],
        "messages": con.execute("SELECT COUNT(*) c FROM messages WHERE status='new'").fetchone()["c"],
    }
    con.close()
    return out


# ==========================================================================
#  TOP LISTS  (v31) — "برترین‌های شهر"
# ==========================================================================
TOP_AUTO = {
    "auto_rating":  ("ORDER BY rating DESC NULLS LAST, nreviews DESC, id DESC"),
    "auto_views":   ("ORDER BY views DESC, id DESC"),
    "auto_featured": ("ORDER BY featured DESC, rating DESC NULLS LAST, id DESC"),
    "auto_new":     ("ORDER BY id DESC"),
}


def toplists(active_only=True):
    q = "SELECT * FROM toplists"
    if active_only:
        q += " WHERE active=1"
    q += " ORDER BY sort, id"
    return db._rows(q)


def toplist(slug=None, tid=None):
    if slug:
        r = db._one("SELECT * FROM toplists WHERE slug=?", (slug,))
    else:
        r = db._one("SELECT * FROM toplists WHERE id=?", (tid,))
    return r


def toplist_businesses(t, limit=None):
    """The ranked businesses of a list. Auto kinds are computed live; manual
    lists read their saved id list. Returns rows in rank order (1-based)."""
    if t.get("kind") in TOP_AUTO:
        rows = db._rows(
            "SELECT b.*, (SELECT AVG(rating) FROM reviews WHERE biz_id=b.id AND status='approved' AND rating>0) rating, "
            "(SELECT COUNT(*) FROM reviews WHERE biz_id=b.id AND status='approved') nreviews "
            "FROM businesses b WHERE b.status='published' " + TOP_AUTO[t["kind"]])
    else:
        try:
            ids = [int(x) for x in json.loads(t.get("items") or "[]")]
        except (TypeError, ValueError):
            ids = []
        rows = []
        for bid in ids:
            r = db._one("SELECT b.*, (SELECT AVG(rating) FROM reviews WHERE biz_id=b.id AND status='approved' AND rating>0) rating, "
                     "(SELECT COUNT(*) FROM reviews WHERE biz_id=b.id AND status='approved') nreviews "
                     "FROM businesses b WHERE b.id=? AND b.status='published'", (bid,))
            if r:
                rows.append(r)
    n = int(limit or t.get("limit_n") or 10)
    rows = [db._biz_row(r) for r in rows[:n]]
    for i, r in enumerate(rows):
        r["rank"] = i + 1
    return rows


def save_toplist(data, tid=None):
    con = db.connect()
    if "items" in data and not isinstance(data["items"], str):
        data["items"] = json.dumps(data["items"], ensure_ascii=False)
    if tid:
        sets = ", ".join(f"{k}=?" for k in data)
        con.execute(f"UPDATE toplists SET {sets} WHERE id=?", list(data.values()) + [tid])
    else:
        data.setdefault("slug", db.unique_slug("toplists", db.slugify(data.get("title", "لیست"))))
        cols = ", ".join(data)
        con.execute(f"INSERT INTO toplists({cols}) VALUES({','.join('?' * len(data))})",
                    list(data.values()))
        tid = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
    con.commit()
    con.close()
    return tid


def delete_toplist(tid):
    db._run("DELETE FROM toplists WHERE id=?", (tid,))


# ==========================================================================
#  FLASH DEALS  (v31) — "پیشنهاد روز / فلش‌سیل"
# ==========================================================================
def flashdeals(active_only=True):
    # v170/#23: مقایسه باید هم‌قالب باشد — از rafع #15 (v165) تاریخ‌ها با
    # فاصله ذخیره می‌شدند ولی now با isoformat («T») ساخته می‌شد؛ نتیجه:
    # سیلِ «همین امروز» هرگز در /deals دیده نمی‌شد. حالا هر دو سمت فاصله‌ای‌اند.
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    q = "SELECT f.*, b.name bizname, b.slug bizslug FROM flashdeals f JOIN businesses b ON b.id=f.biz_id WHERE 1=1"
    p = []
    if active_only:
        q += " AND f.active=1 AND (f.starts='' OR replace(f.starts,'T',' ')<=?) AND replace(f.ends,'T',' ')>=?"
        p += [now, now]
    q += " ORDER BY f.ends, f.id DESC"
    return db._rows(q, p)


def save_flashdeal(data, did=None):
    # v170/#23: قالب یکنواخت «YYYY-MM-DD HH:MM:SS» (فاصله، نه T) برای مقایسهٔ
    # درست پنجرهٔ زنده — ورودی ویجت تقویم ممکن است Tدار یا بی‌ثانیه باشد.
    for k in ("starts", "ends"):
        v = (data.get(k) or "").strip().replace("T", " ")
        if re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$", v):
            v += ":00"
        data[k] = v
    if did:
        con = db.connect()
        sets = ", ".join(f"{k}=?" for k in data)
        con.execute(f"UPDATE flashdeals SET {sets} WHERE id=?", list(data.values()) + [did])
        con.commit()
        con.close()
        return did
    return db._run(
        "INSERT INTO flashdeals(biz_id,title,descr,percent,starts,ends,active) "
        "VALUES(?,?,?,?,?,?,?)",
        (data.get("biz_id"), data.get("title", ""), data.get("descr", ""),
         int(data.get("percent") or 0), data.get("starts", ""), data.get("ends", ""),
         int(data.get("active", 1) or 1)))


def delete_flashdeal(did):
    db._run("DELETE FROM flashdeals WHERE id=?", (did,))


# ==========================================================================
#  STORIES  (v31) — 24-hour shop stories
# ==========================================================================
STORY_TTL = 24 * 3600


def stories_active_ids():
    """The set of business ids that currently have a live story — used to draw
    an Instagram-style ring on their cards and pages without a query per card."""
    con = db.connect()
    rows = con.execute("SELECT DISTINCT biz_id FROM stories WHERE expires>=?",
                       (time.time(),)).fetchall()
    con.close()
    return {r["biz_id"] for r in rows}


def annotate_stories(rows):
    """Mark `has_story` on every business row in one pass (one query total)."""
    ids = stories_active_ids()
    for r in rows:
        r["has_story"] = r.get("id") in ids
    return rows


def stories_add(biz_id, image, caption="", kind="image", duration=0):
    return db._run("INSERT INTO stories(biz_id,image,kind,caption,created,expires,duration) "
                "VALUES(?,?,?,?,datetime('now'),?,?)",
                (biz_id, image, kind if kind == "video" else "image",
                 caption[:200], time.time() + STORY_TTL, float(duration or 0)))


def stories_active():
    """Stories grouped by business, newest first, only unexpired and published.

    v177 تغییر رفتار: استوری منقضی دیگر پاک نمی‌شود — در همان جدول می‌ماند و
    «تاریخچه» می‌شود (صفحهٔ عمومی /b/{slug}/stories + بخش تاریخچهٔ دکاندار).
    نسخهٔ قبلی هر ردیف منقضی را به سطل بازیافت منتقل و حذف می‌کرد که تاریخچهٔ
    پایدار را غیرممکن می‌کرد؛ حذفِ دستی همان قبل به سطل می‌رود.
    """
    return db._rows(
        "SELECT s.*, b.name bizname, b.slug bizslug FROM stories s "
        "JOIN businesses b ON b.id=s.biz_id WHERE s.expires>=? AND b.status='published' "
        "ORDER BY s.id DESC LIMIT 200", (time.time(),))


def stories_for_owner(owner_id):
    biz_ids = [b["id"] for b in db.businesses_of(owner_id)]
    if not biz_ids:
        return []
    return db._rows(
        "SELECT s.*, b.name bizname, b.slug bizslug FROM stories s JOIN businesses b ON b.id=s.biz_id "
        "WHERE s.biz_id IN (%s) ORDER BY s.id DESC LIMIT 100" % ",".join("?" * len(biz_ids)),
        biz_ids)


def stories_for_biz(biz_id, active_only=True):
    q = "SELECT * FROM stories WHERE biz_id=?"
    p = [biz_id]
    if active_only:
        q += " AND expires>=?"
        p.append(time.time())
    q += " ORDER BY id DESC LIMIT 50"
    return db._rows(q, p)


def story_delete(sid):
    # v105: soft-delete — snapshot to the 7-day recycle bin, then remove live row
    row = db._one("SELECT * FROM stories WHERE id=?", (sid,))
    if row:
        db.trash_put("story", sid, row["biz_id"], row["caption"] or "", dict(row))
    return db._run("DELETE FROM stories WHERE id=?", (sid,))


# ---- v177: real story view tracking — one view per viewer (bz_cid) ----
def story_view_add(story_id, viewer=""):
    """Record one view; duplicates from the same viewer are a no-op.
    Stores only the story id + the random visitor cookie (bz_cid) — no
    customer id, no phone, no IP (data-minimisation, v100 stance kept)."""
    viewer = (viewer or "").strip() or "anon"
    return db._run("INSERT OR IGNORE INTO story_views(story_id, viewer, ts) "
                   "VALUES(?,?,?)", (int(story_id), viewer, time.time()))


def story_view_counts(story_ids):
    """{story_id: total_views} for a list of ids, in one query."""
    ids = [int(i) for i in (story_ids or []) if i]
    if not ids:
        return {}
    rows = db._rows(
        "SELECT story_id, COUNT(*) n FROM story_views WHERE story_id IN (%s) "
        "GROUP BY story_id" % ",".join("?" * len(ids)), ids)
    return {r["story_id"]: r["n"] for r in rows}


def story_view_stats(story_id):
    """Aggregate-only stats for one story: total, last-24h rate, and a
    per-day breakdown. Never returns who viewed — only how many."""
    sid = int(story_id)
    now = time.time()
    total = db._one("SELECT COUNT(*) n FROM story_views WHERE story_id=?", (sid,))
    last24 = db._one("SELECT COUNT(*) n FROM story_views WHERE story_id=? AND ts>=?",
                     (sid, now - 86400))
    per_day = db._rows(
        "SELECT date(ts, 'unixepoch') d, COUNT(*) n FROM story_views "
        "WHERE story_id=? GROUP BY d ORDER BY d DESC LIMIT 14", (sid,))
    return {"total": (total or {}).get("n", 0),
            "last24h": (last24 or {}).get("n", 0),
            "per_day": [{"day": r["d"], "n": r["n"]} for r in per_day]}


# ==========================================================================
#  FOLLOW + NOTIFICATIONS  (v32 — Instagram-style)
# ==========================================================================
def follow_state(customer_id, biz_id):
    if not customer_id:
        return False
    r = db._one("SELECT 1 FROM follows WHERE customer_id=? AND biz_id=?",
             (customer_id, biz_id))
    return bool(r)


def follow_toggle(customer_id, biz_id):
    if not customer_id:
        return False
    con = db.connect()
    r = con.execute("SELECT 1 FROM follows WHERE customer_id=? AND biz_id=?",
                    (customer_id, biz_id)).fetchone()
    if r:
        con.execute("DELETE FROM follows WHERE customer_id=? AND biz_id=?",
                    (customer_id, biz_id))
        on = False
    else:
        con.execute("INSERT INTO follows(customer_id,biz_id) VALUES(?,?)",
                    (customer_id, biz_id))
        on = True
    con.commit()
    con.close()
    return on


def follow_count(biz_id):
    r = db._one("SELECT COUNT(*) c FROM follows WHERE biz_id=?", (biz_id,))
    return int(r["c"]) if r else 0


def following_ids(customer_id):
    if not customer_id:
        return []
    con = db.connect()
    rows = [r["biz_id"] for r in con.execute(
        "SELECT biz_id FROM follows WHERE customer_id=? ORDER BY id DESC", (customer_id,))]
    con.close()
    return rows


def notify(customer_id, kind, text, link=""):
    """Push an in-app notification to a customer (v142 core: prefs + trim)."""
    return db.notify_customer(customer_id, kind, str(text)[:200], str(link)[:200])


def notifications(customer_id, unread_only=False, limit=100):
    q = "SELECT * FROM notifications WHERE customer_id=?"
    p = [customer_id]
    if unread_only:
        q += " AND read=0"
    q += " ORDER BY id DESC LIMIT ?"
    p.append(int(limit))
    return db._rows(q, p)


def notifications_unread(customer_id):
    if not customer_id:
        return 0
    r = db._one("SELECT COUNT(*) c FROM notifications WHERE customer_id=? AND read=0",
             (customer_id,))
    return int(r["c"]) if r else 0


def notifications_mark_read(customer_id):
    db._run("UPDATE notifications SET read=1 WHERE customer_id=?", (customer_id,))


# helpful votes on reviews (Instagram-style like)
# v176: one vote per visitor. The UNIQUE(review_id, voter) insert is the gate:
# a repeat vote inserts nothing (rowcount 0) and never touches the counter —
# it just returns the current number. voter="" (legacy/tests) still counts.
def review_helpful(rid, voter=""):
    con = db.connect()
    try:
        if voter:
            cur = con.execute(
                "INSERT OR IGNORE INTO review_votes(review_id,voter,created) VALUES(?,?,?)",
                (rid, voter, time.time()))
            con.commit()
            if cur.rowcount == 0:
                r = con.execute("SELECT helpful FROM reviews WHERE id=?", (rid,)).fetchone()
                return int(r[0] or 0) if r else 0
        con.execute("UPDATE reviews SET helpful=COALESCE(helpful,0)+1 WHERE id=?", (rid,))
        con.commit()
        r = con.execute("SELECT helpful FROM reviews WHERE id=?", (rid,)).fetchone()
        return int(r[0] or 0) if r else 0
    finally:
        con.close()


# ==========================================================================
#  ADMIN MODERATION  (v34): block/delete customers, broadcast, follows
# ==========================================================================
def customer_set_status(cid, status):
    if status not in ("active", "blocked"):
        return False
    db._run("UPDATE customers SET status=? WHERE id=?", (status, cid))
    if status == "blocked":
        db._run("DELETE FROM customer_sessions WHERE customer_id=?", (cid,))
    return True


def customer_delete(cid):
    """Delete a customer and every trace (orders, chats, favs, follows,
    notifications, points, redemptions, sessions)."""
    con = db.connect()
    con.execute("DELETE FROM customer_sessions WHERE customer_id=?", (cid,))
    con.execute("DELETE FROM notifications WHERE customer_id=?", (cid,))
    con.execute("DELETE FROM favorites WHERE customer_id=?", (cid,))
    con.execute("DELETE FROM follows WHERE customer_id=?", (cid,))
    con.execute("DELETE FROM points WHERE customer_id=?", (cid,))
    con.execute("DELETE FROM redemptions WHERE customer_id=?", (cid,))
    con.execute("DELETE FROM chat_messages WHERE thread_id IN "
                "(SELECT id FROM chat_threads WHERE customer_id=?)", (cid,))
    con.execute("DELETE FROM chat_threads WHERE customer_id=?", (cid,))
    # v212: live-receipt rows hold the messenger chat_id → purge with the account.
    con.execute("DELETE FROM order_receipts WHERE order_id IN (SELECT id FROM orders WHERE customer_id=?)", (cid,))
    con.execute("UPDATE orders SET customer_id=NULL WHERE customer_id=?", (cid,))
    # v221: assistant transcripts (cross-channel thread shared by web + bots).
    con.execute("DELETE FROM ai_threads WHERE tkey=?", (f"cust:{cid}",))
    con.execute("DELETE FROM customers WHERE id=?", (cid,))
    con.commit()
    con.close()


def notify_all(kind, text, link=""):
    """Broadcast a notification to every active customer account."""
    con = db.connect()
    ids = [r["id"] for r in con.execute("SELECT id FROM customers WHERE status='active'")]
    con.close()
    sent = 0
    for cid in ids:
        if db.notify_customer(cid, kind, str(text)[:200], str(link)[:200]):
            sent += 1
    return sent


def top_followed(limit=30):
    return db._rows(
        "SELECT b.id, b.name, b.slug, COUNT(f.id) n FROM businesses b "
        "LEFT JOIN follows f ON f.biz_id=b.id "
        "WHERE b.status='published' GROUP BY b.id ORDER BY n DESC, b.id LIMIT ?",
        (int(limit),))

__all__ = [
    "annotate_stories",
    "areas",
    "audit_actions",
    "audit_log",
    "businesses_in_area",
    "chat_attachment",
    "chat_attachment_names",
    "chat_mark_read",
    "chat_messages",
    "chat_send",
    "chat_set_status",
    "chat_start",
    "chat_thread",
    "chat_unread_count",
    "chat_threads_all",
    "chat_threads_for_customer",
    "customer_chat_summaries",
    "customer_chat_detail",
    "customer_chat_reply_prepare",
    "customer_chat_reply_confirmed",
    "owner_bot_summary",
    "send_owner_daily_summaries",
    "owner_order_summaries",
    "owner_order_detail",
    "owner_today_bookings",
    "owner_chat_summaries",
    "owner_chat_detail",
    "owner_bot_action_prepare",
    "owner_bot_action_confirm",
    "chat_threads_for_owner",
    "chat_unread_owner",
    "chat_unread_customer",
    "expired_chat_attachments",
    "delete_chat_attachments",
    "CHAT_RETENTION_DAYS",
    "create_order",
    "request_order_cancel",
    "decide_order_cancel",
    "owner_cancel_requests",
    "owner_sales_summary",
    "owner_chat_reply_prepare",
    "owner_chat_reply_confirmed",
    "customer_by_id",
    "customer_by_phone",
    "customer_by_username",
    "customer_check_password",
    "customer_has_password",
    "customer_has_name",
    "customer_set_credentials",
    "customer_set_profile",
    "customer_counts",
    "customer_delete",
    "customer_otp_issue",
    "customer_session_get",
    "customer_session_kill",
    "customer_session_new",
    "customer_set_name",
    "customer_set_status",
    "customers_list",
    "db_chat_msg_ids",
    "delete_flashdeal",
    "delete_toplist",
    "fav_list",
    "favorite_summaries",
    "favorite_add",
    "favorite_remove",
    "fav_merge",
    "fav_slugs",
    "fav_state",
    "fav_toggle",
    "flashdeals",
    "follow_count",
    "follow_state",
    "follow_toggle",
    "following_ids",
    "notifications",
    "notifications_mark_read",
    "notifications_unread",
    "notify",
    "notify_all",
    "order",
    "order_items",
    "orders_all",
    "orders_for_customer",
    "customer_order_summaries",
    "customer_order_detail",
    "orders_for_owner",
    "rename_area",
    "review_helpful",
    "save_flashdeal",
    "save_toplist",
    "set_order_status",
    "stories_active",
    "stories_active_ids",
    "stories_add",
    "stories_for_biz",
    "stories_for_owner",
    "story_delete",
    "story_view_add",
    "story_view_counts",
    "story_view_stats",
    "top_followed",
    "toplist",
    "toplist_businesses",
    "toplists",
    "order_get",
    "export_orders_csv",
    "export_bookings_csv",
    "export_customers_csv",
    "ORDER_LABELS",
    "ORDER_STATUS",
    "CUSTOMER_OTP_TTL",
    "CUSTOMER_SESSION_TTL",
    "TOP_AUTO",
    "STORY_TTL",
]
