# -*- coding: utf-8 -*-
"""
HTTP application for Bazarche Najafabad.
Standard library only — runs unmodified inside Pydroid 3.
"""

import os
import re
import io
import time
import gzip
import hashlib
import zipfile
import secrets
import sys
import json
import threading
import mimetypes
import posixpath
import html as _html
import urllib.parse
import pagecache
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import antispam   # v275 persistent anti-spam core

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
SITE = os.path.join(ROOT, "site")
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "tools"))

import db
import ui
# v330-fix: `esc(...)` was used in the /agent/code handler (and its own except
# branch) without ever being defined in this module, so that route raised
# NameError -> HTTP 500 on every single request. The helper already exists in
# ui.py; bind it here so the intended escaping actually happens.
esc = ui.esc
import sms
import emailer
import bale
import adminbot
import soroush
import bot_menu
import assistant
import register_web
import shield
import analytics
import uploads
import qr as qrlib
import features
import views_public as V
import views_panel as P
import views_owner as O
import views_catalog as C
import views_panel2 as P2
import views_public2 as V2
import views_customer as CU
import notifmeta
import views_extra as VX
import agent_browser as AB  # v316 file exchange only — arena removed

mimetypes.add_type("text/javascript", ".js")
mimetypes.add_type("text/javascript", ".mjs")
mimetypes.add_type("font/woff2", ".woff2")
mimetypes.add_type("image/svg+xml", ".svg")
mimetypes.add_type("application/manifest+json", ".webmanifest")

MAX_BODY = 4 * 1024 * 1024   # 4 MB cap on form posts

# v160-fix: لینک‌های ذخیره‌شدهٔ قدیمی در ردیف‌های اعلان که مسیرشان امروز
# وجود ندارد — در «کلیک = خوانده شد + برو» نرمال می‌شوند تا اعلان‌های
# پیشین هم بی‌خطا مقصد درستشان را باز کنند.
_LEGACY_NOTIF_LINK = {
    "/my/dashboard": "/my",
    "/me/dashboard": "/me",
}

# ------------------------------------------------------------------ hygiene
# User-submitted text is capped at the application boundary so no single field
# can balloon the database. Numbers/JSON/structural keys are intentionally
# absent — they are validated elsewhere. HTML `maxlength` mirrors these.
FORM_LIMITS = {
    "name": 100, "title": 150, "descr": 2000, "body": 2000, "excerpt": 300,
    "address": 300, "phone": 20, "whatsapp": 20, "email": 120, "subject": 150,
    "tags": 200, "note": 500, "quote": 80, "budget": 60, "author": 60,
    "reporter": 80, "asker": 60, "reason": 40, "topic": 40, "code": 40,
    "brand": 60, "warranty": 60, "unit": 30, "duration": 30, "options": 120,
    "spec": 120, "weight": 60, "bulk_price": 40, "min_order": 40,
    "old_price": 20, "price": 20, "floor_price": 20, "percent": 6,
    "video": 200, "instagram": 120, "telegram": 120, "website": 120,
    "eitaa": 120, "bale": 120, "soroush": 120, "rubika": 120,
    "site_name": 60, "tagline": 120, "hero_title": 120, "hero_lead": 400,
    "hero_cta": 60, "footer_note": 160, "blurb": 200, "icon": 40,
    "parent": 40, "cat_to": 40, "term": 120, "ref": 60, "answer": 1000,
    "area": 100, "old": 100, "new": 100,
}


def clip_form(form):
    """Truncate every user text field to its limit, in place. Mutates the
    parse_qs result (lists of strings) before any handler reads it, so the
    cap holds for every endpoint at once."""
    for k, n in FORM_LIMITS.items():
        if k not in form:
            continue
        v = form[k]
        if isinstance(v, list):
            form[k] = [x[:n] for x in v if isinstance(x, str)]
        elif isinstance(v, str):
            form[k] = v[:n]


def is_spambot(form):
    """Honeypot: a hidden field that real humans never fill. Bots that autofill
    every input trip it, and we silently drop the submission."""
    hp = form_get(form, "website_hp", "").strip()
    return bool(hp)


# SQLite INTEGER is a signed 64-bit value; ids beyond this range raise
# OverflowError when bound, which used to surface as a 500 on crafted URLs
# (DoS by huge id). Clamp every parsed int to this range.
_SQLITE_MAX = 2**63 - 1
_SQLITE_MIN = -(2**63)


def safe_int(v, default=0):
    """Parse an int without ever raising — and clamp to the SQLite range so a
    crafted giant number can never overflow a bound parameter."""
    try:
        n = int(v)
    except (TypeError, ValueError):
        return default
    if n > _SQLITE_MAX:
        return _SQLITE_MAX
    if n < _SQLITE_MIN:
        return _SQLITE_MIN
    return n


def clamp_int(v, lo, hi, default=0):
    v = safe_int(v, default)
    return max(lo, min(hi, v))

# Security headers sent on every response. CSP is deliberately permissive
# about inline scripts/styles (the page injects the boot config and the
# owner-chosen theme CSS inline, and a few confirm() handlers are inline)
# but locks everything else to same-origin, with the map/image CDNs allowed.
# CSP baseline. The literal 'unsafe-inline' in script-src is only a placeholder:
# send() swaps it for a per-response nonce when inline boot scripts are present.
# Leaflet/Three/fonts are vendored locally; Stage 16 removed the old unpkg CDN
# fallback/allowlist so the default map path has no browser-side supply-chain
# dependency. Google Maps/GA hosts remain only for explicit owner configuration.
# v66: connect-src narrowed to 'self' plus GA endpoints; worker pinned. v285:
# frame-src is a tight allowlist (Aparat/YouTube embeds) and media-src allows
# https files (admin-pasted clips).
SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-Frame-Options": "DENY",
    # v119: cross-origin isolation hardening — no other origin may open our
    # documents as a window (COOP) or embed/read our resources (CORP).
    "Cross-Origin-Opener-Policy": "same-origin",
    "Cross-Origin-Resource-Policy": "same-origin",
    "Permissions-Policy": "geolocation=(self), camera=(), microphone=(), payment=()",
    "Content-Security-Policy": (
        "default-src 'self'; "
        "img-src 'self' data: blob: https:; "  # blob: = client-side upload previews (v89)
        # v114: googletagmanager/google-analytics only ever load when the
        # owner has pasted a GA4 measurement id (ui.py injects the tag).
        "script-src 'self' 'unsafe-inline' https://maps.googleapis.com https://www.googletagmanager.com; "
        "style-src 'self' 'unsafe-inline'; "
        "font-src 'self'; "
        "connect-src 'self' https://www.google-analytics.com https://*.google-analytics.com https://*.analytics.google.com; "
        "frame-src https://www.aparat.com https://www.youtube-nocookie.com https://www.youtube.com; "
        "worker-src 'self'; "
        "media-src 'self' blob: https:; "
        "object-src 'none'; "
        "base-uri 'self'; "
        "form-action 'self'; "
        "frame-ancestors 'none'"
    ),
}

# --------------------------------------------------------------------------
# v66: on-the-fly gzip. zlib ships with the Python standard library, so this
# stays Pydroid-safe. Only text-like payloads are compressed, and only when
# the client advertises gzip; binaries (photos, video, fonts, the sprite)
# are already compressed formats and would only grow.
COMPRESSIBLE = ("text/html", "text/css", "text/plain", "text/xml",
                "text/javascript",          # py3.13 mimetypes maps .js here
                "application/javascript", "application/json",
                "application/manifest+json", "image/svg+xml",
                "application/xml")
MIN_COMPRESS = 860          # below this, gzip framing eats the savings


def _client_accepts_gzip(headers):
    enc = headers.get("Accept-Encoding", "")
    return "gzip" in enc.lower()


def _looks_like_ip(v):
    """v119: keep only plausible IP literals / CIDR in the panel allowlist
    (IPv4 or IPv6, with optional /prefix). Anything else is dropped."""
    import ipaddress as _ia
    try:
        if "/" in v:
            _ia.ip_network(v, strict=False)
        else:
            _ia.ip_address(v)
        return True
    except ValueError:
        return False


# In-memory cache of gzipped static bodies so the 2MB icon sprite is not
# recompressed on every hit. Keyed by (path, mtime, size); evicted when the
# file changes. Capped so a pathological assets dir cannot eat memory.
_GZ_CACHE = {}
_GZ_CACHE_MAX = 64


# ------------------------------------------------------------------ helpers
def form_get(form, key, default=""):
    v = form.get(key)
    if isinstance(v, list):
        return v[0] if v else default
    return v if v is not None else default


# v289 security: state-changing requests must originate from this site.
#
# `SameSite=Lax` does NOT protect POST: Lax only strips cookies from
# cross-site *subresource* loads and non-GET top-level navigations, so a
# cross-origin `<form method="post">` still carries the panel and customer
# session cookies. Every write route in this app is a plain HTML form POST,
# which is exactly the shape CSRF needs. `Sec-Fetch-Site` is sent by every
# engine that has supported SameSite for years (Chrome 76+, Firefox 90+,
# Safari 16.4+), is set by the browser and cannot be forged by script, and
# needs no token plumbing through 200+ form templates.
# v289 speed: public HTML is cached 8s fresh (the same TTL the server-side
# page cache uses) then served stale for 52s while the browser revalidates.
# Private/authenticated responses keep no-store.
PUBLIC_HTML_CC = "public, max-age=8, stale-while-revalidate=52"

WEBHOOK_RX = re.compile(
    r"^/api/(?:bale|bale-admin|soroush)/webhook/[A-Za-z0-9_-]{32,100}$")
CROSS_SITE_FA = ("درخواست از سایت دیگری آمده و پذیرفته نشد. "
                 "صفحه را تازه کنید و دوباره تلاش کنید.")


def _origin_host(value):
    """Hostname of an Origin/Referer header, or '' when unusable."""
    v = (value or "").strip()
    if not v:
        return ""
    try:
        p = urllib.parse.urlparse(v if "//" in v else "//" + v)
        return (p.hostname or "").lower()
    except Exception:
        return ""


def checkbox(form, key):
    return 1 if form.get(key) else 0


def _token_eq(got, want):
    """Constant-time owner-key comparison.

    `==` on strings short-circuits on the first mismatched byte, which in
    theory leaks the key through request timing. compare_digest is constant
    time. The try/except keeps a malformed (non-ASCII) key from raising a 500
    — it is simply not the key.
    """
    if not want:
        return False
    try:
        return secrets.compare_digest(str(got), str(want))
    except TypeError:
        return False


def _safe_next(nxt):
    """A login `next` target must only ever be a same-site path.

    ONE shared rule for every login flow (audit F-014: the owner flow also
    rejected ``..`` and /panel|/admin while the customer /me/profile copy
    did not). Returns the target when safe, else None."""
    nxt = str(nxt or "")
    if not (nxt.startswith("/") and not nxt.startswith("//")):
        return None
    if "\\" in nxt or len(nxt) >= 300:
        return None
    if ".." in nxt.split("?")[0].split("/"):
        return None
    if posixpath.normpath(nxt.split("?")[0]).startswith(("/panel", "/admin")):
        return None
    return nxt


def build_hours(form):
    out = {}
    for k, _ in P.DAYS:
        if form.get(f"h_{k}_closed"):
            continue
        o = form_get(form, f"h_{k}_open")
        c = form_get(form, f"h_{k}_close")
        if o and c:
            out[k] = [[o, c]]
    return out


# v310 (دستور مدیر): «مغزشم بشه تنظیم کرد» — چیپ مغز در کنسول ایجنت،
# به‌ازای هر پیام؛ مغز سراسری مدیر (/مغز) تغییر نمی‌کند. نام‌های قدیمی
# smart/fast هم به مغز واقعی نگاشت می‌شوند (قبلاً بی‌اثر بودند).
AGENT_BRAIN_ALIAS = {"smart": "opus", "fast": "haiku", "strong": "opus"}


def _agent_brain_of(model_sel):
    m = (model_sel or "").strip().lower()
    if m in ("", "auto", "offline"):
        return ""
    return AGENT_BRAIN_ALIAS.get(m, m)


def _agent_apply_model(model_sel):
    """v328: چیپ مغز یا شناسهٔ دقیق ۵ مدل رایگان بای‌نارا. اوراید فقط همین درخواست."""
    import assistant as _AST
    m = (model_sel or "").strip()
    ml = m.lower()
    try:
        _AST.clear_brain_override()
    except Exception:
        pass
    if ml in ("", "auto", "offline"):
        return
    free = tuple(getattr(_AST, "FREE_MODELS", ()) or getattr(_AST, "BYNARA_MODELS", ()))
    free_map = {x.lower(): x for x in free}
    if ml in free_map:
        _AST.set_brain_override("bynara")
        _AST.set_model_override(free_map[ml])
        return
    if ml in ("bynara", "باینارا", "بای‌نارا", "باینارا"):
        _AST.set_brain_override("bynara")
        return
    if "/" in m or ":free" in ml:
        _AST.set_brain_override("openrouter")
        _AST.set_model_override(m)
        return
    _AST.set_brain_override(_agent_brain_of(ml))


class App(BaseHTTPRequestHandler):
    server_version = "Bazarche/2.0"
    # v289 security: BaseHTTPRequestHandler appends `sys_version`
    # ("Python/3.13.14") to the Server header, which hands an attacker the
    # exact interpreter build to aim CVEs at. The product name is all a
    # client ever needs.
    sys_version = ""
    protocol_version = "HTTP/1.1"
    timeout = 30   # v275: G15 — slow clients can no longer hold a thread forever

    def spam_gate(self, action, actor="", silent=None):
        """v275 anti-spam gate. Returns True when the request was rejected.

        A 429 naming the exact gate is already sent — RULES §1. `silent`
        (v280) overrides that single response for anti-oracle endpoints:
        the caller wants an innocuous 200 JSON instead of a loud 429, but
        exactly ONE response may leave this handler."""
        ok, gate, retry = antispam.guard(action, self.client_key(), actor)
        if ok:
            return False
        if silent is not None:
            self.json_out(silent[0], silent[1])
            return True
        msg = "محدودیت ضداسپم؛ درگاه: %s" % gate
        if self.path.startswith("/api/"):
            self.json_out({"ok": False, "error": msg, "retry": retry}, 429)
        else:
            self.send(msg + " — بعداً دوباره تلاش کنید.", 429,
                      "text/plain; charset=utf-8")
        return True

    # -------------------------------------------------------------- output
    def send(self, body, code=200, ctype="text/html; charset=utf-8", headers=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        # v114: real-visit analytics — every rendered HTML page is one visit
        # row (IP + visitor cookie + device). Never allowed to break a page.
        if code == 200 and ctype.split(";")[0].strip().lower() == "text/html":
            try:
                analytics.track_page(self)
            except Exception:
                pass
        extra = dict(headers or {})
        # v117/M1: panel pages must never be indexed — belt (meta) and
        # suspenders (response header), for crawlers that skip robots.txt.
        if getattr(self, "_panel_noindex", False):
            extra.setdefault("X-Robots-Tag", "noindex, nofollow")
        # v116-audit: when we are behind an HTTPS-terminating proxy, pin the
        # domain to HTTPS for a year (HSTS). Only sent on https responses,
        # per spec — sending it over plain http must not happen.
        # v119: the same proxy signal also upgrades every http:// asset URL
        # inside the page (upgrade-insecure-requests) — one less class of
        # mixed-content mistakes on production.
        shdrs = SECURITY_HEADERS
        if self.headers.get("X-Forwarded-Proto") == "https":
            extra.setdefault("Strict-Transport-Security",
                             "max-age=31536000; includeSubDomains")
            shdrs = dict(SECURITY_HEADERS)
            shdrs["Content-Security-Policy"] = (
                SECURITY_HEADERS["Content-Security-Policy"]
                + "; upgrade-insecure-requests")
        # v330/CSP: جانشینِ nonce را با مقدار واقعیِ این پاسخ عوض کن و همان
        # مقدار را در هدر اعلام کن. حتماً پیش از gzip، و حتماً روی کپیِ
        # هدرها (shdrs ممکن است هنوز همان دیکشنری سراسری SECURITY_HEADERS
        # باشد و تغییر مستقیم، nonce را به پاسخ‌های بعدی نشت می‌داد).
        if ui.NONCE_PH.encode("utf-8") in body:
            _nonce = secrets.token_urlsafe(16)
            body = ui.swap_nonce(body, _nonce)
            shdrs = dict(shdrs)
            shdrs["Content-Security-Policy"] = (
                shdrs["Content-Security-Policy"].replace(
                    "script-src 'self' 'unsafe-inline' ",
                    "script-src 'self' 'nonce-%s' " % _nonce))

        # gzip when the client accepts it and the payload is worth compressing.
        # Never double-compress: serve_static may hand us a body that is
        # already gzipped (its disk cache) with Content-Encoding pre-set —
        # compressing again is exactly what shipped broken CSS to Chrome.
        base_type = ctype.split(";")[0].strip().lower()
        if (len(body) >= MIN_COMPRESS and base_type in COMPRESSIBLE
                and "Content-Encoding" not in extra
                and _client_accepts_gzip(self.headers)):
            body = gzip.compress(body, compresslevel=6)
            extra["Content-Encoding"] = "gzip"
            extra["Vary"] = "Accept-Encoding"
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in shdrs.items():
            self.send_header(k, v)
        for k, v in extra.items():
            self.send_header(k, v)
        for c in getattr(self, "_extra_cookies", []):
            self.send_header("Set-Cookie", c)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def redirect(self, location):
        """HTTP headers are latin-1 only, so percent-encode any Persian text
        (flash messages) before it ever reaches send_header()."""
        safe = urllib.parse.quote(location, safe="/?=&#%:+")
        self.send_response(303)
        self.send_header("Location", safe)
        self.send_header("Content-Length", "0")
        for c in getattr(self, "_extra_cookies", []):
            self.send_header("Set-Cookie", c)
        self.end_headers()

    def json_out(self, obj, code=200):
        self.send(json.dumps(obj, ensure_ascii=False),
                  code, "application/json; charset=utf-8")

    # -------------------------------------------------------------- static
    def serve_static(self, relpath):
        relpath = urllib.parse.unquote(relpath).lstrip("/")
        safe = posixpath.normpath(relpath)
        if safe.startswith("..") or safe.startswith("/"):
            return self.send("forbidden", 403, "text/plain; charset=utf-8")
        full = os.path.join(SITE, safe)
        if not os.path.isfile(full):
            return False
        st = os.stat(full)
        ctype, _ = mimetypes.guess_type(full)
        ctype = ctype or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript",
                                                  "application/json",
                                                  "application/manifest+json"):
            ctype += "; charset=utf-8"
        # ETag from mtime+size: lets no-cache assets revalidate with a cheap
        # 304 instead of re-downloading on every page view.
        etag = '"%s"' % hashlib.md5(
            f"{st.st_mtime_ns}-{st.st_size}".encode()).hexdigest()
        if self.headers.get("If-None-Match") == etag:
            self.send_response(304)
            for k, v in SECURITY_HEADERS.items():
                self.send_header(k, v)
            self.send_header("ETag", etag)
            self.end_headers()
            return True
        query = urllib.parse.urlparse(self.path).query
        versioned = bool(re.search(r"(?:^|&)v(?:=)?\d+(?:&|$)", query))
        # v289: assets/bazaar was missing from this list, so bazaar.css and
        # bazaar.js were served no-cache even though they carry a ?v= cache
        # buster like every other stylesheet — a revalidation round-trip on
        # every page view for the skin the whole public site loads.
        immutable = (safe.startswith(("assets/fonts", "assets/vendor", "assets/img"))
                     or (versioned and safe.startswith(
                         ("assets/css", "assets/js", "assets/bazaar"))))
        cache = ("public, max-age=31536000, immutable" if immutable
                 else "no-cache")
        base_type = ctype.split(";")[0].strip().lower()
        # v285: HTTP Range (206) for audio/video — instant seeking and iOS
        # compatibility. Single range only, bounded, never streamed blindly.
        if base_type.startswith(("video/", "audio/")):
            rng = self.headers.get("Range", "").strip()
            if rng:
                m = re.fullmatch(r"bytes=(\d*)-(\d*)", rng)
                ok = False
                if m and (m.group(1) or m.group(2)):
                    if m.group(1):
                        start = int(m.group(1))
                        end = int(m.group(2)) if m.group(2) else st.st_size - 1
                    else:
                        start = max(0, st.st_size - int(m.group(2)))
                        end = st.st_size - 1
                    end = min(end, st.st_size - 1)
                    ok = start < st.st_size and start <= end
                if not ok:
                    self.send_response(416)
                    for k, v in SECURITY_HEADERS.items():
                        self.send_header(k, v)
                    self.send_header("Content-Range", f"bytes */{st.st_size}")
                    self.end_headers()
                    return True
                length = min(end - start + 1, 8 * 1024 * 1024)   # bounded chunk
                end = start + length - 1
                with open(full, "rb") as f:
                    f.seek(start)
                    data = f.read(length)
                self.send_response(206)
                for k, v in SECURITY_HEADERS.items():
                    self.send_header(k, v)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Content-Range",
                                 f"bytes {start}-{end}/{st.st_size}")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Cache-Control", cache)
                self.send_header("ETag", etag)
                self.end_headers()
                self.wfile.write(data)
                return True
        with open(full, "rb") as f:
            data = f.read()
        # v183: versioned CSS/JS are content-addressed by the release query
        # (?vNNN), so repeat navigation needs no validation round-trip. Keep
        # unversioned CSS/JS on no-cache because the service worker deliberately
        # fetches those names while installing a fresh cache.
        extra = {"Cache-Control": cache, "ETag": etag}
        if base_type.startswith(("video/", "audio/")):
            extra["Accept-Ranges"] = "bytes"
        # Pre-gzip big text assets once and serve the cached result — the
        # sprite/CSS would otherwise burn CPU compressing on every request.
        if (len(data) >= MIN_COMPRESS and base_type in COMPRESSIBLE
                and _client_accepts_gzip(self.headers)):
            key = (full, st.st_mtime_ns, st.st_size)
            gz = _GZ_CACHE.get(key)
            if gz is None:
                gz = gzip.compress(data, compresslevel=6)
                if len(_GZ_CACHE) >= _GZ_CACHE_MAX:
                    _GZ_CACHE.clear()
                _GZ_CACHE[key] = gz
            data = gz
            extra["Content-Encoding"] = "gzip"
            extra["Vary"] = "Accept-Encoding"
        self.send(data, 200, ctype, extra)
        return True

    # -------------------------------------------------------------- cookies
    def cookies(self):
        raw = self.headers.get("Cookie") or ""
        out = {}
        for part in raw.split(";"):
            if "=" in part:
                k, v = part.split("=", 1)
                out[k.strip()] = urllib.parse.unquote(v.strip())
        return out

    # Versioned on purpose. A cookie is scoped to host+path, NOT to the program
    # that set it, so the prototype's "bz_sess" was still being presented to the
    # new server — pointing at a session row that no longer means anything.
    # Bumping the name makes every stale session invisible in one stroke, and
    # SESSION_COOKIE is the single place to bump it again if it ever recurs.
    SESSION_COOKIE = "bzv2_sess"
    LEGACY_COOKIES = ("bz_sess",)
    ADMIN_COOKIE = "bzv2_admin"
    CUSTOMER_COOKIE = "bzv2_cust"
    AGENT_COOKIE = "bzv2_agent"

    def set_cookie(self, name, value, days=30):
        self._extra_cookies = getattr(self, "_extra_cookies", [])
        exp = "" if days else "; Max-Age=0"
        if days:
            exp = f"; Max-Age={days * 86400}"
        # Behind HTTPS (directly or via a proxy that sets X-Forwarded-Proto)
        # mark the session cookie Secure so it never travels over plain HTTP.
        # (Security fix.)
        sec = "; Secure" if self.headers.get("X-Forwarded-Proto") == "https" else ""
        self._extra_cookies.append(
            f"{name}={urllib.parse.quote(value)}; Path=/; HttpOnly; SameSite=Lax{exp}{sec}")

    def site_origin(self, s=None):
        """Absolute origin for links that leave the page (QR, sitemap, share).

        Prefers the configured site_url so a printed QR keeps working after the
        site moves to a real domain. Falls back to the Host header — never to a
        hard-coded 127.0.0.1:8000, which is how a QR printed on a shop window
        ended up pointing at the port the prototype used.
        """
        s = s if s is not None else db.get_settings()
        cfg = (s.get("site_url") or "").strip().rstrip("/")
        if cfg:
            if not cfg.startswith(("http://", "https://")):
                cfg = "https://" + cfg
            return cfg
        host = (self.headers.get("Host", "") or "").strip()
        # Host is attacker-controllable; only accept a plausible hostname or
        # IP[:port]. Anything else (quotes, brackets, CR/LF, HTML) is dropped
        # so it cannot be reflected into sitemap.xml / QR / share links.
        # (Security fix.) Setting site_url is still the definitive control.
        if host and not re.fullmatch(r"[A-Za-z0-9.\-:\[\]]+(:\d{1,5})?", host):
            host = ""
        # When site_url is NOT configured, never trust an arbitrary remote
        # hostname for links that leave the page (QR/sitemap): a crafted Host
        # header would otherwise poison them. Only loopback/LAN hosts are
        # honoured in that state; everything else falls back to the bound
        # address. Once site_url is set, this branch is never reached.
        if host and not host.lower().split(":")[0].replace(".", "").isdigit():
            if not host.lower().startswith(("localhost", "127.", "10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.", "172.2", "172.30.", "172.31.", "::1")):
                host = ""
        if not host:
            host = f"127.0.0.1:{self.server.server_address[1]}"
        proto = "https" if self.headers.get("X-Forwarded-Proto") == "https" else "http"
        return f"{proto}://{host}"

    def current_owner(self):
        return db.session_owner(self.cookies().get(self.SESSION_COOKIE))

    def current_customer(self):
        return db.customer_session_get(self.cookies().get(self.CUSTOMER_COOKIE))

    # ------------------------------------------------ v69 unified auth ----
    # One door, two roles: the same OTP signs the visitor in as customer and
    # (when the phone owns or matches a business) as shopkeeper. Legacy
    # /me/login* routes alias into these so nothing external breaks.
    def _unified_issue(self, s, form):
        if is_spambot(form):
            return self.redirect("/login")
        # v77 (P0): سهمیهٔ OTP دیگر فقط بر اساس IP نیست. روی شبکه‌های موبایل
        # ایران (CGNAT) صدها کاربر یک IP مشترک دارند و سقف ۵-در-۱۵-دقیقه بر
        # اساس IP، همهٔ آن‌ها را قفل می‌کرد. حالا دو سطل جدا داریم:
        #   · سطل «شماره»: جلوی اسپمِ یک شماره را می‌گیرد (۵ در ۱۵ دقیقه).
        #   · سطل «IP»: سقف سبک‌تر (۲۰ در ۵ دقیقه) فقط برای جلوگیری از
        #     جاروی انبوه شماره‌های متفاوت از یک منبع.
        phone = db.norm_phone(form_get(form, "phone"))
        # v277: سطل per-شماره با هش (حریم خصوصی + G18)
        _ph = hashlib.sha256(phone.encode()).hexdigest()[:16]
        if db.valid_phone(phone) and \
                not db.rate_ok("otp:h" + _ph, limit=5, window=900, always=True):
            return self.send(O.login_unified(s, "phone",
                err="برای این شماره کد زیاد خواسته شد. کمی بعد دوباره تلاش کنید.",
                nxt=form_get(form, "next")))
        if not db.rate_ok(f"otpip:{self.client_key()}", limit=20, window=900, always=True):
            return self.send(O.login_unified(s, "phone",
                err="تعداد درخواست کد زیاد است. کمی بعد دوباره تلاش کنید.",
                nxt=form_get(form, "next")))
        if not db.valid_phone(phone):
            return self.send(O.login_unified(s, "phone",
                err="شمارهٔ موبایل معتبر نیست.", nxt=form_get(form, "next")))
        # v277: تنوع شماره per-IP — ≥۳ شمارهٔ متفاوت در ۱۰دقیقه = enumeration؛
        # هر درخواست از آستانه به بعد deny ثبت می‌کند و پلهٔ تنبیه ban می‌دهد.
        antispam.enum_check(self.client_key(), _ph)
        code, left, throttled = db.otp_issue(phone)
        delivered, note = sms.send_otp(s, phone, code)
        # v116-audit: the dev code used to be printed on the page for ANY
        # visitor when SMS was unconfigured — on a deployed box without
        # site_url that is full account takeover. Now it is shown only to
        # the machine itself (Pydroid/desktop owner), never over the wire.
        local_peer = (self.client_address[0] or "") in ("127.0.0.1", "::1")
        dev = (code if (local_peer and not delivered
                        and not (s.get("site_url") or "").strip()) else "")
        if (s.get("site_url") or "").strip() and not delivered:
            note = "سرویس پیامک در دسترس نیست. با مدیریت تماس بگیرید."
        if throttled:
            note = f"کد قبلی هنوز معتبر است ({int(left)} ثانیه)."
        return self.send(O.login_unified(s, "code", phone, note=note,
                                         dev_code=dev, nxt=form_get(form, "next")))

    def _unified_verify(self, s, form):
        phone = db.norm_phone(form_get(form, "phone"))
        nxt = form_get(form, "next")
        # v277: قفل تأیید — ۵ تأیید ناموفق برای (شماره،IP) => ۱۵دقیقه قفل
        # (v186: این مسیر فعلاً با ۴۰۴ بسته است؛ قفل برای احیای احتمالیِ مسیر
        #  نگه داشته می‌شود — defence in depth)
        _ph = hashlib.sha256(phone.encode()).hexdigest()[:16]
        _lk = "v|%s|%s" % (_ph, self.client_key())
        _lk_ip = "v|i|%s" % self.client_key()
        if db.login_locked(_lk) or db.login_locked(_lk_ip):
            return self.send(O.login_unified(s, "code", phone,
                err="تعداد تلاش‌های ناموفق تأیید زیاد است؛ ۱۵ دقیقه بعد دوباره "
                    "تلاش کنید. (درگاه: loginlock)", nxt=nxt))
        ok, msg = db.otp_check(phone, form_get(form, "code"))
        if not ok:
            db.login_fail(_lk)
            db.login_fail(_lk_ip, db.LOGIN_FAIL_IP_LIMIT)
            return self.send(O.login_unified(s, "code", phone, err=msg, nxt=nxt))
        db.login_fail_clear(_lk)
        linked = 0
        owner_granted = False
        no_name = False
        if s.get("owner_login") == "1":
            owner = db.owner_by_phone(phone, create=True)
            if owner and owner.get("status") != "blocked":
                owner_granted = True
                self.set_cookie(self.SESSION_COOKIE, db.session_new(owner["id"]))
                linked = db.link_orphans_to_owner(owner["id"], phone)
        if s.get("shop_account") == "1":
            cust = db.customer_by_phone(phone, create=True)
            self.set_cookie(self.CUSTOMER_COOKIE,
                            db.customer_session_new(cust["id"]))
            favs = form.get("favs") or []
            if favs and isinstance(favs, list):
                try:
                    favs = json.loads(favs[0])
                except (TypeError, ValueError):
                    favs = []
            elif isinstance(favs, str):
                try:
                    favs = json.loads(favs)
                except (TypeError, ValueError):
                    favs = []
            db.fav_merge(cust["id"], favs)
            # shopkeepers get their name from the shop; don't bounce a
            # brand-new owner into the customer profile form on first login
            no_name = (not owner_granted) and not db.customer_has_name(cust["id"])
        if linked:
            return self.redirect("/my/businesses?ok=" + urllib.parse.quote(
                f"{linked} کسب‌وکار ثبت‌شده با این شماره به حساب شما متصل شد."))
        safe_nxt = _safe_next(nxt)
        if no_name:
            return self.redirect("/me/profile" + (
                ("?next=" + urllib.parse.quote(safe_nxt)) if safe_nxt else ""))
        if safe_nxt:
            return self.redirect(safe_nxt)
        return self.redirect("/my")

    def _unified_password(self, s, form):
        nxt = form_get(form, "next")
        if not db.rate_ok(f"pw:{self.client_key()}", limit=10, window=900, always=True):
            return self.send(O.login_unified(s, "password",
                err="تلاش‌های ورود زیاد است. ۱۵ دقیقه بعد دوباره امتحان کنید.", nxt=nxt))
        username = form_get(form, "username").strip()
        password = form_get(form, "password")
        # v277: همان قفل تأیید برای رمز — ۵ خطا برای (نام‌کاربری،IP) => ۱۵دقیقه
        # (مسیر از v186 با ۴۰۴ بسته است؛ defence in depth)
        _uh = hashlib.sha256(username.lower().encode()).hexdigest()[:16]
        _lk = "v|u%s|%s" % (_uh, self.client_key())
        _lk_ip = "v|i|%s" % self.client_key()
        if db.login_locked(_lk) or db.login_locked(_lk_ip):
            return self.send(O.login_unified(s, "password",
                err="تعداد تلاش‌های ناموفق ورود زیاد است؛ ۱۵ دقیقه بعد دوباره "
                    "تلاش کنید. (درگاه: loginlock)", nxt=nxt))
        owner = db.owner_by_username(username)
        if owner and db.owner_check_password(owner["id"], password):
            if owner.get("status") == "blocked":
                return self.send(O.login_unified(s, "password",
                    err="این حساب مسدود شده است.", nxt=nxt))
            self.set_cookie(self.SESSION_COOKIE, db.session_new(owner["id"]))
            if s.get("shop_account") == "1" and owner.get("phone"):
                cust = db.customer_by_phone(owner["phone"], create=True)
                self.set_cookie(self.CUSTOMER_COOKIE,
                                db.customer_session_new(cust["id"]))
            db.link_orphans_to_owner(owner["id"], owner.get("phone", ""))
            db.login_fail_clear(_lk)
            return self.redirect("/my")
        cust = db.customer_by_username(username)
        if cust and db.customer_check_password(cust["id"], password):
            if cust.get("status") == "blocked":
                return self.send(O.login_unified(s, "password",
                    err="این حساب مسدود شده است.", nxt=nxt))
            self.set_cookie(self.CUSTOMER_COOKIE,
                            db.customer_session_new(cust["id"]))
            if s.get("owner_login") == "1" and cust.get("phone"):
                ow = db.owner_by_phone(cust["phone"], create=True)
                if ow and ow.get("status") != "blocked":
                    self.set_cookie(self.SESSION_COOKIE, db.session_new(ow["id"]))
                    db.link_orphans_to_owner(ow["id"], cust["phone"])
            db.login_fail_clear(_lk)
            return self.redirect("/my")
        db.login_fail(_lk)
        db.login_fail(_lk_ip, db.LOGIN_FAIL_IP_LIMIT)
        return self.send(O.login_unified(s, "password",
            err="نام کاربری یا رمز عبور درست نیست.", nxt=nxt))

    # ---------------------------------------------------------------- v298 email login — like modern agent
    def _email_issue(self, s, form):
        if is_spambot(form):
            return self.redirect("/login")
        email_raw = form_get(form, "email")[:120]
        email = db._norm_email(email_raw)
        _eh = hashlib.sha256(email.encode()).hexdigest()[:16]
        if db.valid_email(email) and not db.rate_ok("email:h" + _eh, limit=5, window=900, always=True):
            return self.send(O.login_unified(s, "email",
                err="برای این ایمیل کد زیاد خواسته شد. کمی بعد دوباره تلاش کنید.",
                nxt=form_get(form, "next")))
        if not db.rate_ok(f"emailip:{self.client_key()}", limit=20, window=900, always=True):
            return self.send(O.login_unified(s, "email",
                err="تعداد درخواست کد زیاد است. کمی بعد دوباره تلاش کنید.",
                nxt=form_get(form, "next")))
        if not db.valid_email(email):
            return self.send(O.login_unified(s, "email",
                err="ایمیل معتبر نیست.", nxt=form_get(form, "next")))
        antispam.enum_check(self.client_key(), _eh)
        code, left, throttled = db.email_otp_issue(email)
        delivered, note = emailer.send_otp(s, email, code)
        local_peer = (self.client_address[0] or "") in ("127.0.0.1", "::1")
        dev = (code if (local_peer and not delivered and not (s.get("site_url") or "").strip()) else "")
        # If SMTP configured and failed on production, tell user to contact
        if (s.get("site_url") or "").strip() and not delivered and not dev:
            # keep note from emailer (error) but hide code
            pass
        if throttled:
            note = f"کد قبلی هنوز معتبر است ({int(left)} ثانیه)."
        return self.send(O.login_unified(s, "email_code", email, note=note,
                                         dev_code=dev, nxt=form_get(form, "next")))

    def _email_verify(self, s, form):
        email_raw = form_get(form, "email")[:120]
        email = db._norm_email(email_raw)
        nxt = form_get(form, "next")
        _eh = hashlib.sha256(email.encode()).hexdigest()[:16]
        _lk = "v|e%s|%s" % (_eh, self.client_key())
        _lk_ip = "v|ei|%s" % self.client_key()
        if db.login_locked(_lk) or db.login_locked(_lk_ip):
            return self.send(O.login_unified(s, "email_code", email,
                err="تعداد تلاش‌های ناموفق زیاد است؛ ۱۵ دقیقه بعد دوباره تلاش کنید.", nxt=nxt))
        ok, msg = db.email_otp_check(email, form_get(form, "code"))
        if not ok:
            db.login_fail(_lk)
            db.login_fail(_lk_ip, db.LOGIN_FAIL_IP_LIMIT)
            return self.send(O.login_unified(s, "email_code", email, err=msg, nxt=nxt))
        db.login_fail_clear(_lk)
        # success — create/find customer by email
        cust = db.customer_by_email_create(email)
        owner_granted = False
        if cust:
            self.set_cookie(self.CUSTOMER_COOKIE, db.customer_session_new(cust["id"]))
            # if customer already linked to owner via phone, grant owner session too
            if s.get("owner_login") == "1" and cust.get("phone") and not cust["phone"].startswith("e_"):
                ow = db.owner_by_phone(cust["phone"], create=True)
                if ow and ow.get("status") != "blocked":
                    self.set_cookie(self.SESSION_COOKIE, db.session_new(ow["id"]))
                    owner_granted = True
            # also if owner exists with same email
            if s.get("owner_login") == "1":
                ow2 = db.owner_by_email(email)
                if ow2 and ow2.get("status") != "blocked":
                    self.set_cookie(self.SESSION_COOKIE, db.session_new(ow2["id"]))
                    owner_granted = True
            # if no name yet, go to profile (but name is set from email prefix, so usually has name)
            if not db.customer_has_name(cust["id"]):
                return self.redirect("/me/profile" + (("?next=" + urllib.parse.quote(_safe_next(nxt))) if _safe_next(nxt) else ""))
        safe_nxt = _safe_next(nxt)
        if safe_nxt:
            return self.redirect(safe_nxt)
        # v299: avoid /my->/login loop for email-only customers (no owner)
        if owner_granted or self.current_owner():
            return self.redirect("/my")
        return self.redirect("/me")

    def clear_legacy_cookies(self):
        """Delete anything the older build left behind on this device.

        Without this the old cookie sits there forever: harmless to the server,
        but it is the reason a phone that ran the prototype kept behaving like
        it. Runs once per visit, costs nothing when there is nothing to clear.
        """
        have = self.cookies()
        for name in self.LEGACY_COOKIES:
            if name in have:
                self.set_cookie(name, "", days=0)

    def gate(self, biz_id, key, back):
        """Server-side enforcement. The blurred UI is a courtesy; this is the
        wall. Returns a redirect response when the shop lacks the feature."""
        if db.can(biz_id, key):
            return None
        label = db.FEATURE_LABELS.get(key, key)
        sep = "&" if "?" in back else "?"
        self.redirect(f"{back}{sep}err=" + urllib.parse.quote(
            f"«{label}» در پلن فعلی شما قفل است. برای باز کردن، پلن را ارتقا دهید."))
        return True

    def client_key(self):
        """Identity used for rate limiting.

        X-Forwarded-For is only honoured when the direct peer is a trusted
        proxy (loopback). A remote client can set XFF to any value, so
        trusting it unconditionally lets an attacker rotate the header and
        reset the rate-limit bucket on every request. (Security fix.)"""
        try:
            peer = str(self.client_address[0])
        except Exception:
            peer = "unknown"
        if peer in ("127.0.0.1", "::1", "localhost"):
            fwd = self.headers.get("X-Forwarded-For", "")
            if fwd:
                return fwd.split(",")[0].strip()[:45]
        return peer[:45]

    def _assistant_key(self, customer, owner):
        """v213: quota identity — account first, otherwise IP + a short salt
        so anonymous visitors share the free quota per address."""
        if customer:
            return f"cust:{customer['id']}"
        if owner:
            return f"owner:{owner['id']}"
        return "ip:" + self.client_key()

    # -------------------------------------------------------------- auth
    def token_ok(self, q_or_form):
        want = db.owner_token()
        got = form_get(q_or_form, "key")
        return _token_eq(got, want)

    def admin_ok(self, q_or_form):
        """v117/M1: panel access = a valid admin session cookie (minted at
        key entry or password login), OR the legacy key-in-form path when no
        password is set. When a password IS set, the session cookie is the
        lock and forms no longer need to embed the raw key."""
        if not self._panel_ip_allowed():
            return False
        if db.admin_session_ok(self.cookies().get(self.ADMIN_COOKIE),
                               unlocked_only=db.owner_pass_set()):
            return True
        if not self.token_ok(q_or_form):
            return False
        return not db.owner_pass_set()

    # v119: optional panel IP allowlist (defense-in-depth, not the only gate).
    # Empty = everyone (normal). When set (comma/newline separated), only
    # those IPv4/IPv6 reach the panel — the session cookie is still required.
    _PANEL_IP_CACHE = (None, 0.0)  # (allowlist, fetched_at)

    def _bale_confirm_needed(self, s):
        """v293 layer-3: require a one-time approval from the owner's Bale bot
        before a correct panel password unlocks the console. Only active when
        the admin bot is actually configured (token+secret+chat) — otherwise
        the panel must stay usable (dev boxes, bot-less installs). The owner
        can also force it on/off with the panel_bale_confirm setting."""
        try:
            setting = s.get("panel_bale_confirm", "1")
        except Exception:
            setting = "1"
        if setting == "0":
            return False
        try:
            if not adminbot.enabled():
                return False
            # رباتِ هنوز فعال‌نشده (گیت /369) نمی‌تواند تأیید کند — در آن
            # حالت چالِنج باعث قفل‌شدن مدیر می‌شد؛ پس تا فعال‌سازی کامل،
            # لایهٔ سوم غیرفعال است و بلافاصله پس از فعال‌سازی روشن می‌شود.
            return adminbot.gate_ok(adminbot.owner_chat())
        except Exception:
            return False

    @staticmethod
    def _panel_hidden_path(s):
        """v293 layer-1: an unguessable panel address. When the
        panel_hidden_path setting is set, the console lives ONLY at that path
        (hashed on mint) and plain /panel 404s for everyone. Empty = the
        classic /panel address (default, back-compat)."""
        try:
            return (s.get("panel_hidden_path") or "").strip()
        except Exception:
            return ""

    def _panel_url(self, s, panel_path):
        """v297: translate an internal /panel… path into the address the
        browser must actually use. With a hidden path armed, /panel answers
        404, so every redirect out of a panel handler has to go to the hidden
        address or the admin lands on a 404 (that is exactly what a successful
        login did before this)."""
        hidden = self._panel_hidden_path(s)
        if not hidden:
            return panel_path
        if panel_path == "/panel":
            return "/" + hidden
        if panel_path.startswith("/panel/"):
            return "/" + hidden + panel_path[len("/panel"):]
        return panel_path

    def _panel_path_ok(self, s, path):
        """True when this request may touch the panel. With a hidden path set,
        only the hidden path itself passes; everything else /panel* is a 404.
        The comparison is constant-time — the path is the first secret layer."""
        hidden = self._panel_hidden_path(s)
        if not hidden:
            return True
        cand = path[1:] if path.startswith("/") else path
        try:
            return secrets.compare_digest(cand, hidden)
        except TypeError:
            return False

    def _agent_ok(self):
        """v300: agent panel — private key only via Bale bot, HttpOnly cookie 7d"""
        try:
            c = self.cookies().get(self.AGENT_COOKIE, "")
            if not c:
                return False
            # token hash check
            return db.agent_key_check(c)
        except Exception:
            return False

    def _panel_ip_allowed(self):
        """Loopback is always allowed so the admin can never lock herself
        out from the server itself. Behind a proxy (X-Forwarded-Proto:
        https) the real client is the first X-Forwarded-For hop; the header
        is only trusted when the request actually arrived via the proxy."""
        now = time.time()
        allow, ts = self._PANEL_IP_CACHE
        if now - ts > 5.0:
            allow = (db.get_settings().get("panel_allow_ips") or "").strip()
            self._PANEL_IP_CACHE = (allow, now)
        if not allow:
            return True
        peer = self.client_address[0]
        if peer in ("127.0.0.1", "::1"):
            return True
        if (self.headers.get("X-Forwarded-Proto") == "https"
                and peer in ("127.0.0.1", "::1", "::ffff:127.0.0.1")):
            xff = self.headers.get("X-Forwarded-For", "")
            if xff:
                peer = xff.split(",")[0].strip()
        allowed = {a.strip() for a in allow.replace(";", ",").replace("\n", ",")
                   .split(",") if a.strip()}
        return peer in allowed

    def chat_role(self, thread, q_or_form=None, requested=""):
        """Resolve an authorized role for one conversation.

        Unified accounts may carry customer and owner cookies together, so a
        page can request its intended role. The role hint never bypasses the
        matching customer/ownership/admin checks.
        """
        if not thread:
            return None
        q_or_form = q_or_form or {}
        cust = self.current_customer()
        owner = self.current_owner()
        allowed = {
            "customer": bool(cust and thread.get("customer_id") == cust["id"]),
            "owner": bool(owner and db.owns(owner["id"], thread["biz_id"])),
            "admin": bool(self.admin_ok(q_or_form)),
        }
        if requested in allowed:
            return requested if allowed[requested] else None
        for role in ("admin", "owner", "customer"):
            if allowed[role]:
                return role
        return None

    def store_chat_message(self, thread, sender, body, files, settings):
        """Validate one optional private attachment and create one message."""
        _v, _g = antispam.content_gate("chatmsg", self.client_key(), body or "")
        if _v == "reject":
            return None, "پیام نگه داشته شد (ضداسپم)؛ درگاه: content"
        candidates = [(fn, data) for field, fn, data in (files or [])
                      if field == "attachment" and data]
        if len(candidates) > 1:
            return None, "در هر پیام فقط یک فایل می‌توانید بفرستید."
        attachment = None
        if candidates:
            filename, blob = candidates[0]
            # v275 G21: daily per-identity upload byte cap (capacity abuse)
            if not antispam.bytes_add("k:" + self.client_key(), len(blob or b"")):
                return None, "سقف حجم روزانهٔ پیوست پر شد؛ درگاه: bytes"
            attachment, err = uploads.save_chat_file(blob, filename)
            if not attachment:
                return None, err or "فایل ذخیره نشد."
        mid = db.chat_send(thread["id"], sender, body, attachment=attachment)
        if not mid:
            if attachment:
                uploads.delete_chat_file(attachment["stored_name"])
            return None, "متن پیام یا فایل را وارد کنید."

        if sender in ("owner", "admin") and thread.get("customer_id") \
                and settings.get("notif_enabled") == "1":
            biz = db.business(bid=thread["biz_id"]) or {}
            who = ("مدیر دست گیر" if sender == "admin"
                   else f"«{biz.get('name', 'کسب‌وکار')}»")
            db.notify(thread["customer_id"], "chat", f"{who} به گفتگوی شما پاسخ داد.",
                      f"/me/chat/{thread['id']}")
        elif sender == "customer":
            biz = db.business(bid=thread["biz_id"]) or {}
            sms.notify_owner(settings, f"پیام تازه برای «{biz.get('name', 'کسب‌وکار')}»")
        db.log("chat.send", f"thread={thread['id']} sender={sender} file={1 if attachment else 0}")
        return mid, ""

    def _inline_edit(self, form):
        """Site-wide inline edit. Admin clicks text on any page -> saved here.
        Strict allow-list: only the named (type, field) pairs may change, so a
        crafted request can never write an arbitrary column."""
        typ = form_get(form, "type")
        fid = form_get(form, "id")
        field = form_get(form, "field")
        value = form_get(form, "value")
        BIZ = {"name", "descr", "address", "phone", "tags"}
        SET = {"hero_title", "hero_lead", "hero_cta", "tagline",
               "description", "footer_note"}
        CAT = {"name", "blurb"}
        try:
            if typ == "business" and field in BIZ and fid.isdigit():
                db.save_business({field: value}, safe_int(fid))
            elif typ == "setting" and field in SET:
                db.set_setting(field, value)
            elif typ == "category" and field in CAT and fid.isdigit():
                db.save_category({field: value}, safe_int(fid))
            elif typ == "page" and fid in ("about", "rules") and field in ("body", "title"):
                p = db.get_page(fid)
                if field == "title":
                    db.save_page(fid, value, p["body"])
                else:
                    db.save_page(fid, p["title"], value)
            else:
                return {"ok": False, "error": "این بخش قابل ویرایش نیست"}
            db.log("inline.edit", f"{typ}:{fid}:{field}")
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)[:60]}

    # -------------------------------------------------------------- GET
    def prime_context(self, path, admin_token=""):
        """Tell ui.py who is signed in and which area this URL belongs to, so
        the header and the mobile menu can reflect it. Set once per request."""
        area = "public"
        if path == "/panel" or path.startswith("/panel/"):
            area = "panel"
        elif path == "/my" or path.startswith("/my/"):
            area = "my"
        elif path == "/me" or path.startswith("/me/"):
            area = "me"
        ui.set_context(self.current_owner(), area, admin_token,
                       customer=self.current_customer(), path=path)

    def do_GET(self):
        try:
            # v112 abuse shield: storms/scanners answered before any work is done.
            sh = shield.check(self)
            if sh:
                self.send(f"<h1>{sh[1]}</h1>", sh[0])
                return
            # v275: read-side anti-scrape gates must run before any cache return
            _gp = urllib.parse.urlparse(self.path).path
            if _gp == "/businesses" and self.spam_gate("search"):
                return
            # v280-fix: spam_gate خودش پاسخ می‌فرستد — برای بیکن‌های ضدscrape
            # که باید «بی‌صدا و مبهم» بمانند، guard را مستقیم صدا می‌زنیم تا
            # پاسخ دوم روی همان اتصال پروتکل را نشکند (۵۰۰ پنتست v280).
            if re.match(r"^/api/stories/\d+/view$", _gp):
                _okv, _gv, _rv = antispam.guard("view", self.client_key())
                if not _okv:
                    return self.json_out({"ok": True}, 200)
            if re.match(r"^/api/chat/\d+/msgs$", _gp):
                _okm, _gm, _rm = antispam.guard("msgpoll", self.client_key())
                if not _okm:
                    return self.json_out({"msgs": [], "after": 0}, 200)
            # Hourly retention sweep so a long-lived server still purges
            # week-old chat images without needing a restart.
            if time.time() - _last_chat_gc > _CHAT_GC_EVERY:
                purge_expired_chat_images()
                db.trash_purge()   # v105: recycle-bin 7-day purge
                # v117/فاز۶: privacy retention must not depend on a restart
                db.retention_purge()
                antispam.prune()            # v275: G20/G24 event/ban/ratelimit pruning
                assistant.chat_log_prune()  # v275: G20 public chat log rotation
                # v142: notification inbox hygiene + daily plan-expiry reminder
                db.purge_notifications()
                db.sub_expiry_reminders(7)
                features.booking_reminders()   # v229: tomorrow's bookings
            self.route_get()
        except BrokenPipeError:
            pass
        except Exception as e:
            import traceback; traceback.print_exc()
            self.send(f"<h1>خطای داخلی سرور</h1><p>خطایی رخ داد. لطفاً کمی بعد دوباره تلاش کنید.</p>", 500)
        finally:
            # threads are reused, so a stale signed-in user must never leak
            # into the next request served by this thread
            ui.clear_context()
            db.request_done()   # v109: never idle-hold SQLite's writer lock

    def do_HEAD(self):
        self.do_GET()

    # صفحات عمومی مهمان که بدنه‌شان برای همه یکسان است (v117/کارایی)
    PAGECACHE_PATHS = frozenset((
        "/", "/businesses", "/catalog", "/deals", "/lists", "/events",
        "/cities", "/nearby", "/areas", "/blog", "/pricing", "/contact",
        "/about", "/rules", "/map"))
    # صفحات الگو-دار مهمان: صفحهٔ کسب‌وکار و کالا (توکن مهمان همیشه '' و
    # دکمه‌های حالت‌دار — دنبال/گفت‌وگو — سمت کلاینت رندر می‌شوند)
    PAGECACHE_RE = (re.compile(r"^/b/[^/]+$"), re.compile(r"^/item/\d+$"))

    def route_get(self):
        """v117/کارایی: پاسخ‌های HTML مهمانِ صفحه‌های پربازدید، TTL کوتاه
        کش می‌شوند (رندر پایتونیِ CPU-بند زیر رمبش سرریال می‌شد). هر POST
        کل کش را باطل می‌کند؛ آمار بازدید در send() ثبت می‌شود، نه بدنه."""
        parsed = urllib.parse.urlparse(self.path)
        path_only = parsed.path.rstrip("/") or "/"
        cacheable = (len(path_only) < 120 and "key" not in parsed.query
                     and "frag" not in parsed.query
                     and len(parsed.query) < 200
                     and (path_only in self.PAGECACHE_PATHS
                          or any(rx.match(path_only)
                                 for rx in self.PAGECACHE_RE)))
        if cacheable:
            # v117/رفع: صفحات عمومی برای کاربر واردشده «شخصی‌سازی» می‌شوند
            # (قلب علاقه‌مندی با aria-pressed سمت سرور رندر می‌شود — تست
            # favorites گرفت). کش فقط برای مهمانِ خالص: هیچ کوکی احرازی نباشد.
            _ck = self.cookies()
            if any(_ck.get(c) for c in (self.SESSION_COOKIE,
                                        self.CUSTOMER_COOKIE,
                                        self.ADMIN_COOKIE)):
                cacheable = False
        if cacheable:
            # اثرانگشت محتوا در کلید: نوشتن از «هر فرایندی» (پنل/تست/CLI)
            # کلید را تازه می‌کند — کشِ حافظه هرگز کهنه پاسخ نمی‌دهد.
            key = (db.page_fingerprint() + ":" + path_only
                   + ("?" + parsed.query if parsed.query else ""))
            # v119/سرعت: صفحه‌های مهمان کش‌پذیر، هدرهای کش مرورگر هم می‌گیرند
            # — ETag از اثرانگشت محتوا + max-age برابر TTL کش سرور (۸ ثانیه).
            # مرورگر پس از ۸ ثانیه با If-None-Match بازبینی می‌کند و اگر
            # محتوا عوض نشده باشد، ۳۰۴ بی‌بدنه می‌گیرد (بدون رندر/بدون بدنه).
            _etag = '"' + hashlib.sha1(key.encode("utf-8")).hexdigest()[:16] + '"'
            if self.headers.get("If-None-Match") == _etag:
                self.send_response(304)
                self.send_header("ETag", _etag)
                self.end_headers()
                return
            _browser_cc = {"Cache-Control": PUBLIC_HTML_CC, "ETag": _etag}
            hit = pagecache.get(key)
            if hit is not None:
                # مسیر کش هم باید پاک‌سازی کوکی نسخهٔ قدیمی را انجام دهد
                # (تست isolation همین را می‌گیرد) — رندر خودش می‌کند.
                self.clear_legacy_cookies()
                return self.send(hit, headers=_browser_cc)
            orig_send = self.send

            def _send_store(body, code=200, *a, **kw):
                if (code == 200 and isinstance(body, str)
                        and "text/html" in (kw.get("ctype")
                                            or (a[0] if a else "text/html"))):
                    pagecache.put(key, body)
                if code == 200:
                    hdrs = dict(kw.get("headers") or {})
                    hdrs.setdefault("Cache-Control", PUBLIC_HTML_CC)
                    hdrs.setdefault("ETag", _etag)
                    kw["headers"] = hdrs
                return orig_send(body, code, *a, **kw)

            self.send = _send_store
            try:
                return self._route_render()
            finally:
                self.send = orig_send
        return self._route_render()

    def _route_render(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        q = urllib.parse.parse_qs(parsed.query)
        s = db.get_settings()
        tok = db.owner_token()
        given = (q.get("key") or [""])[0]
        # v117/M1 (panel key leak fix): the raw owner key must live in the
        # URL only ONCE — at entry. A correct key mints a server-side admin
        # session (7-day cookie); every later panel request authenticates by
        # cookie, so internal links, Referer, history and page HTML never
        # carry the key again.
        owner = _token_eq(given, tok) or db.admin_session_ok(
            self.cookies().get(self.ADMIN_COOKIE))
        if _token_eq(given, tok) and not db.admin_session_ok(
                self.cookies().get(self.ADMIN_COOKIE)):
            # v117/M1: key-only sessions are marked locked — with a panel
            # password set they still face the password gate.
            self.set_cookie(self.ADMIN_COOKIE,
                            db.admin_session_new(locked=db.owner_pass_set()))
        # Public pages never receive the admin token — the admin UI lives only
        # inside /panel. This is what stops visitors from ever seeing an edit
        # bar or admin links on the site.
        vis_tok = ""
        self.prime_context(path, vis_tok)
        self.clear_legacy_cookies()

        # static assets
        if path.startswith("/assets/") or path in ("/favicon.ico", "/manifest.webmanifest",
                                                   "/sw.js", "/robots.txt", "/sitemap.xml", "/feed.xml",
                                                   "/offline.html", "/healthz",
                                                   "/.well-known/security.txt"):
            if path == "/favicon.ico":
                return self.redirect("/assets/img/favicon.svg")
            if path == "/robots.txt":
                # v113: private areas stay out of every index, and AI training
                # crawlers (the 2026 traffic storm) are told to stay off entirely.
                # Compliant bots obey this; the shield handles the rest.
                #
                # v297 (FINDINGS-v296 F5): "Disallow: /panel" is a leak, not a
                # defence — it tells every crawler an admin console lives there.
                # With a hidden path armed, /panel already answers 404, so the
                # line only advertises it. The hidden path itself must never be
                # listed either (that would publish the secret), so the panel
                # relies on the X-Robots-Tag: noindex header it already sends.
                _hidden = self._panel_hidden_path(db.get_settings())
                _priv = ("Disallow: /my\nDisallow: /me\nDisallow: /chat-file/\n"
                         if _hidden else
                         "Disallow: /panel\nDisallow: /my\n"
                         "Disallow: /me\nDisallow: /chat-file/\n")
                return self.send(
                    "User-agent: *\nAllow: /\n" + _priv + "\n"
                    "User-agent: GPTBot\nUser-agent: ChatGPT-User\n"
                    "User-agent: CCBot\nUser-agent: Bytespider\n"
                    "User-agent: Amazonbot\nUser-agent: PerplexityBot\n"
                    "User-agent: Google-Extended\nUser-agent: Applebot-Extended\n"
                    "User-agent: anthropic-ai\nUser-agent: Claude-Web\n"
                    "Disallow: /\n\n"
                    f"Sitemap: {self.site_origin(s)}/sitemap.xml\n",
                    200, "text/plain; charset=utf-8")
            if path == "/feed.xml":                # v217: RSS برای وبلاگ/اخبار
                return self.feed(s)
            if path == "/sitemap.xml":
                return self.sitemap(s)
            if path == "/healthz":
                # v119: zero-dependency uptime probe for the host's monitor
                # (uptime-kuma / cron). Cheap DB ping; text/plain so it never
                # touches analytics or the page cache.
                try:
                    db.get_settings()
                    body, code = "ok", 200
                except Exception:
                    body, code = "db error", 500
                return self.send(body, code, "text/plain; charset=utf-8",
                                 {"Cache-Control": "no-store"})
            if path == "/.well-known/security.txt":
                # v119: vulnerability disclosure contact (RFC 9116) — helps
                # good-faith researchers report issues to the site owner.
                email = (s.get("email") or "").strip()
                safe_email = _html.escape(email, quote=True).replace("%0d", "").replace("%0a", "")
                contact = f"mailto:{safe_email}" if email else "https://example.com/contact"
                _host_raw = (self.headers.get("Host") or "localhost").split(":")[0]
                host = re.sub(r"[^A-Za-z0-9.\-]", "", _host_raw)
                if not host:
                    host = "localhost"
                return self.send(
                    "Contact: " + contact + "\n"
                    "Expires: 2027-09-01T00:00:00Z\n"
                    "Preferred-Languages: fa, en\n"
                    "Policy: https://" + host + "/rules\n"
                    "Encryption: https://" + host + "\n",
                    200, "text/plain; charset=utf-8")
            if self.serve_static(path):
                return
            return self.send("not found", 404, "text/plain; charset=utf-8")

        # Private messenger files never live under /assets. Authorization is
        # checked before reading a single byte from disk.
        m = re.match(r"^/chat-file/(\d+)$", path)
        if m:
            attachment = db.chat_attachment(safe_int(m.group(1), 0))
            if not attachment:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            thread = db.chat_thread(attachment["thread_id"])
            requested = (q.get("as") or [""])[0]
            if not self.chat_role(thread, q, requested):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            data = uploads.read_chat_file(attachment["stored_name"])
            if data is None:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            disposition = "inline" if attachment.get("kind") == "image" else "attachment"
            safe_name = urllib.parse.quote(attachment.get("original_name") or "file")
            return self.send(data, 200, attachment.get("mime") or "application/octet-stream", {
                "Cache-Control": "private, no-store",
                "Content-Disposition": f"{disposition}; filename*=UTF-8''{safe_name}",
            })

        m = re.match(r"^/ticket-file/(\d+)$", path)
        if m:
            attachment = db.ticket_attachment(safe_int(m.group(1), 0))
            if not attachment:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            owner = self.current_owner()
            allowed = bool(owner and attachment.get("owner_id") == owner["id"]) or self.admin_ok(q)
            if not allowed:
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            data = uploads.read_chat_file(attachment["stored_name"])
            if data is None:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            disp = "inline" if attachment.get("kind") == "image" else "attachment"
            name = urllib.parse.quote(attachment.get("original_name") or "file")
            return self.send(data, 200, attachment.get("mime") or "application/octet-stream", {
                "Cache-Control":"private, no-store",
                "Content-Disposition":f"{disp}; filename*=UTF-8''{name}"})

        # v185: browser-bound Bale login. Merely opening the bot never logs a
        # visitor in; the linked Bale identity must click the approval button.
        if path == "/auth/bale":
            if self.current_customer():
                return self.redirect("/me")
            if not bale.enabled():
                return self.send(O.login_unified(s, "phone",
                    err="ورود با بله موقتاً در دسترس نیست."), 503)
            if not db.rate_ok("bale-new:" + self.client_key(), limit=6,
                              window=600, always=True):
                return self.send(O.login_unified(s, "phone",
                    err="تعداد درخواست‌ها زیاد است؛ ده دقیقه بعد تلاش کنید."), 429)
            ch = db.messenger_challenge_new("login")
            self.set_cookie("bzv2_bale", ch["browser_token"], days=1)
            return self.send(O.bale_wait_page(s, ch, "login"),
                             headers={"Cache-Control": "no-store"})

        if path == "/auth/soroush":
            if self.current_customer():
                return self.redirect("/me")
            if not soroush.enabled():
                return self.send(O.login_unified(s, err="ورود با سروش‌پلاس موقتاً در دسترس نیست."), 503)
            if not db.rate_ok("soroush-new:" + self.client_key(), limit=6,
                              window=600, always=True):
                return self.send(O.login_unified(s, err="تعداد درخواست‌ها زیاد است؛ بعداً تلاش کنید."), 429)
            # Soroush copy/paste handoff and explicit confirmation use a five-minute challenge.
            ch = db.messenger_challenge_new("login", ttl=300, platform="soroush")
            self.set_cookie("bzv2_soroush", ch["browser_token"], days=1)
            return self.send(O.soroush_wait_page(s, ch, "login"),
                             headers={"Cache-Control":"no-store"})

        if path == "/api/panel/approve-status":
            # v293: polling for the Bale-approval gate. The cookie alone is the
            # identity; a locked session with a live challenge is exactly the
            # state this endpoint serves. Never leaks anything but the status.
            _at = self.cookies().get(self.ADMIN_COOKIE)
            if not _at or not db.admin_session_ok(_at):
                return self.json_out({"status": "expired"})
            _ast = db.panel_approval_status(_at)
            if _ast == "approved":
                # v337: normal order is Bale first, then the existing panel
                # password. For that purpose, approval only moves the browser to
                # the password gate; it does NOT unlock the session yet.
                if db.panel_approval_purpose(_at) != "pre_password":
                    db.admin_session_unlock(_at)
                return self.json_out({"status": "approved", "redirect": self._panel_url(s, "/panel")})
            if _ast == "rejected":
                db.admin_session_kill(_at)
                self.set_cookie(self.ADMIN_COOKIE, "", days=0)
                return self.json_out({"status": "rejected"})
            if _ast == "pending":
                return self.json_out({"status": "pending"})
            return self.json_out({"status": "expired"})

        # v300 agent panel live status polling (needs agent cookie + admin)
        if path == "/api/agent/status":
            # v309 (دستور مدیر): نشست مالک/ادمین هم کافی است — بدون کلید بله
            if not (self._agent_ok() or self.current_owner() or self.admin_ok(q)):
                return self.json_out({"ok": False, "error": "agent key required"}, 403)
            try:
                blist = db.agent_batch_list()
                staged = len([b for b in blist if b.get("status") == "staged"])
                # pending file
                import pathlib as _pl
                pend = {}
                try:
                    _pf = "/tmp/dastgir-admin-pending.json"
                    if _pl.Path(_pf).exists():
                        pend = json.loads(_pl.Path(_pf).read_text()[:5000])
                except Exception:
                    pend = {}
                # last action
                last = {}
                try:
                    _lf = "/tmp/dastgir-agent-last-action.json"
                    if _pl.Path(_lf).exists():
                        last = json.loads(_pl.Path(_lf).read_text()[:4000])
                except Exception:
                    last = {}
                return self.json_out({"ok": True, "staged": staged, "total": len(blist),
                                      "pending": bool(pend), "pending_summary": pend.get("summary","") if isinstance(pend, dict) else "",
                                      "last": last})
            except Exception as e:
                return self.json_out({"ok": False, "error": str(e)[:120]}, 500)

        if path == "/api/agent/models":
            if not (self._agent_ok() or self.current_owner() or self.admin_ok(q)):
                return self.json_out({"ok": False, "error": "agent key required"}, 403)
            try:
                import assistant as _AST
                ids = list(_AST.BYNARA_MODELS)
                models = [{"id": m, "name": m, "free": True} for m in ids]
                cur = ""
                try:
                    cur = ((db.get_settings().get("ai_brain_bynara_model") or "")
                           .strip() or ids[0])
                except Exception:
                    cur = ids[0]
                return self.json_out({
                    "ok": True, "n": len(models),
                    "featured": ids,
                    "models": models, "current": cur,
                    "has_key": bool((_AST._env("AI_BRAIN_BYNARA_KEY")
                                     or _AST._env("AI_SITE_API_KEY"))),
                    "default": ids[0],
                    "provider": "bynara",
                    "site_model": (_AST.site_config().get("model") or ""),
                })
            except Exception as e:
                return self.json_out({"ok": False, "error": str(e)[:200]}, 500)

        if path in ("/api/bale/status", "/api/soroush/status"):
            platform = "soroush" if path.startswith("/api/soroush") else "bale"
            if not db.rate_ok(platform + "-poll:" + self.client_key(), limit=90,
                              window=180, always=True):
                return self.json_out({"status": "limited"}, 429)
            cid = (q.get("id") or [""])[0][:80]
            browser_token = self.cookies().get("bzv2_" + platform, "")
            ch = db.messenger_challenge_status(cid, browser_token)
            if not ch or (ch.get("platform") or "bale") != platform:
                return self.json_out({"status": "expired"})
            if not ch.get("approved_id"):
                return self.json_out({"status": "pending"})
            # Consume exactly once, then mint normal site sessions.
            ch = db.messenger_challenge_status(cid, browser_token, consume=True)
            if not ch:
                return self.json_out({"status": "expired"})
            cust = db.customer_by_id(ch["approved_id"])
            if not cust or cust.get("status") == "blocked":
                return self.json_out({"status": "expired"})
            if ch["purpose"] == "login":
                self.set_cookie(self.CUSTOMER_COOKIE,
                                db.customer_session_new(cust["id"]))
                if s.get("owner_login") == "1" and cust.get("phone"):
                    ow = db.owner_by_phone(cust["phone"], create=True)
                    if ow and ow.get("status") != "blocked":
                        self.set_cookie(self.SESSION_COOKIE, db.session_new(ow["id"]))
                        db.link_orphans_to_owner(ow["id"], cust["phone"])
                redirect = "/my"
            else:
                redirect = "/me/notif-settings?ok=" + urllib.parse.quote(
                    "حساب بله با موفقیت متصل شد.")
            self.set_cookie("bzv2_bale", "", days=0)
            return self.json_out({"status": "approved", "redirect": redirect})

        # v316: /agent/help-mobile removed — arena deleted per owner request
        if path == "/agent/help-mobile":
            return self.send("این بخش حذف شد", 404, "text/plain; charset=utf-8")
        # v316: arena browser removed — only file exchange remains
        if path in ("/agent/browser", "/agent/proxy", "/api/agent/arena/cookie"):
            return self.send("این بخش حذف شد", 404, "text/plain; charset=utf-8")
        if path.startswith("/agent/file/"):
            if not (self._agent_ok() or self.current_owner() or self.admin_ok(q)):
                return self.send("forbidden", 403)
            fname = urllib.parse.unquote(path[len("/agent/file/"):])[:120]
            fp = os.path.join(AB.EXCHANGE_DIR, fname)
            # safe: must be inside EXCHANGE_DIR
            if not os.path.abspath(fp).startswith(os.path.abspath(AB.EXCHANGE_DIR)):
                return self.send("forbidden", 403)
            if not os.path.isfile(fp):
                return self.send("not found", 404)
            data = open(fp, "rb").read()
            ctype = mimetypes.guess_type(fp)[0] or "application/octet-stream"
            return self.send(data, 200, ctype, {"Content-Disposition": f'attachment; filename="{fname}"'})
        # v316: arena routes removed — fetch/arena/diag/fix-vpn deleted per owner request
        if path in ("/api/agent/fetch", "/api/agent/arena", "/api/agent/fix-vpn", "/api/agent/diag"):
            return self.send("این بخش حذف شد", 404, "text/plain; charset=utf-8")

        # v301 — standalone agent console at /agent — separate from panel, email login + agent key, all-purpose, بدون مرورگر خارجی، فقط مدیریت داخلی
        if path == "/agent" or path.startswith("/agent/"):
            # ak param consume (one-time link from Bale bot)
            ak = (q.get("ak") or [""])[0]
            if ak:
                try:
                    if db.agent_key_consume(ak, self.client_key()):
                        self.set_cookie(self.AGENT_COOKIE, ak, days=7)
                        return self.redirect("/agent")
                except Exception:
                    pass
            cust = self.current_customer()
            own = self.current_owner()
            admin = self.admin_ok(q)
            # v309 (دستور مدیر): نشست مالک/ادمین = دسترسی کامل ایجنت بدون کلید بله.
            # کلید بله فقط برای مشتریِ فقط-ایمیلی باقی می‌ماند (کانال اختیاری).
            agent_ok = self._agent_ok() or bool(own) or bool(admin)
            # email login gate (like modern agent) — if no session at all
            if not cust and not own and not admin:
                return self.send(P2.agent_email_gate(s, token=tok, next_url="/agent"))
            # key gate — only email-only customers land here (v309)
            if not agent_ok:
                return self.send(P2.agent_key_gate(s, token=tok, customer=cust, owner=own))
            # sub-routes for live code inspection (same as panel version but under /agent)
            if path == "/agent/code":
                fpath = (q.get("f") or [""])[0][:200]
                search = (q.get("q") or [""])[0][:100]
                code_html = ""
                try:
                    import adminbot_content as _CT
                    if search:
                        res = _CT.tool_execute("code_search", {"pattern": search, "limit": 80})
                        code_html = f"<pre style='white-space:pre-wrap;max-height:70vh;overflow:auto' dir='ltr'>{esc(str(res)[:12000])}</pre>"
                    elif fpath:
                        safe_base = os.path.abspath(os.path.join(HERE, ".."))
                        cand = os.path.abspath(os.path.join(safe_base, fpath.lstrip("/")))
                        if cand.startswith(safe_base) and os.path.isfile(cand):
                            txt = open(cand, "r", encoding="utf-8", errors="ignore").read()[:30000]
                            code_html = f"<h3>{esc(fpath)}</h3><pre style='max-height:70vh;overflow:auto' dir='ltr'>{esc(txt)}</pre>"
                        else:
                            code_html = "<p>مسیر نامعتبر</p>"
                except Exception as e:
                    code_html = f"<p>خطا: {esc(str(e)[:400])}</p>"
                shell = P2.agent_standalone_page(s, tok, q, customer=cust, owner=own, agent_ok=True)
                shell = shell.replace("</body>", f"<div class='container' style='max-width:900px;margin:20px auto'><div class='card glass card-pad'>{code_html}<p><a class='btn btn-ghost btn-sm' href='/agent'>بازگشت</a></p></div></div></body>")
                return self.send(shell)
            # main standalone page
            return self.send(P2.agent_standalone_page(s, tok, q, customer=cust, owner=own, agent_ok=True))

        # maintenance gate
        if s.get("maintenance") == "1" and not owner and not path.startswith("/panel"): 
            body = f'''<div class="container-wide"><section class="section">
              {ui.empty_state("settings","سایت در حال به‌روزرسانی است",
                "به‌زودی با امکانات تازه برمی‌گردیم. از شکیبایی شما سپاسگزاریم.")}
            </section></div>'''
            return self.send(ui.page(s, "به‌زودی", body, "", cats=[], show_chrome=False), 503)

        # ---------------- owner panel
        # v293 لایهٔ اول: وقتی «نشانی مخفی» تنظیم شده، کنسول فقط از همان
        # نشانی غیرقابل‌حدس وارد می‌شود؛ /panel معمولی برای غریبه‌ها ۴۰۴ است.
        hidden = self._panel_hidden_path(s)
        panel_hidden_hit = bool(hidden) and (
            path == "/" + hidden or path.startswith("/" + hidden + "/"))
        if panel_hidden_hit:
            path = "/panel" + path[len("/" + hidden):]
        if path == "/panel" or path.startswith("/panel/"):
            self._panel_noindex = True   # v117/M1: header on every panel byte
            if hidden and not panel_hidden_hit and not db.admin_session_ok(
                    self.cookies().get(self.ADMIN_COOKIE)):
                # بدون نشست = بدون کشف: حتی صفحهٔ «دسترسی محدود» لو نمی‌رود.
                return self.send(V.not_found(s, vis_tok), 404)
            if path == "/panel/enter":
                # v337: one-command panel entry. The Bale admin bot issues a
                # short-lived pt token; opening it creates a locked session and
                # sends a confirmation request to Bale. Only after approval does
                # the browser see the existing password gate.
                if not self._panel_ip_allowed():
                    return self.send(P.login_gate(s), 403)
                pt = (q.get("pt") or [""])[0]
                if not db.panel_entry_consume(pt):
                    return self.send(P.approve_wait(s, state="expired"),
                                     headers={"Cache-Control": "no-store"})
                if not db.owner_pass_set():
                    return self.send(P.password_gate(s, err="برای روش جدید ابتدا باید رمز پنل تعیین شود. در ربات بله بفرستید: بله"),
                                     403, headers={"Cache-Control": "no-store"})
                sess = db.admin_session_new(locked=True)
                self.set_cookie(self.ADMIN_COOKIE, sess)
                code = db.panel_approval_new(sess, self.client_key(), purpose="pre_password")
                sent = False
                try:
                    sent = adminbot.notify_panel_login(code, self.client_key(), purpose="pre_password")
                    db.log("panel.approve", "pre_password requested ip=%s" % self.client_key())
                except Exception:
                    sent = False
                if not sent:
                    db.admin_session_kill(sess)
                    self.set_cookie(self.ADMIN_COOKIE, "", days=0)
                    return self.send(P.password_gate(s, err="ربات بلهٔ مدیریت آمادهٔ دریافت تأیید نیست؛ تنظیمات ربات را بررسی کنید."),
                                     503, headers={"Cache-Control": "no-store"})
                return self.redirect(self._panel_url(s, "/panel/approve"))
            if path == "/panel/approve":
                _at = self.cookies().get(self.ADMIN_COOKIE)
                _ast = db.panel_approval_status(_at) if _at else None
                if _ast == "approved":
                    if db.panel_approval_purpose(_at) != "pre_password":
                        db.admin_session_unlock(_at)
                    return self.redirect(self._panel_url(s, "/panel"))
                if _ast == "rejected":
                    db.admin_session_kill(_at)
                    self.set_cookie(self.ADMIN_COOKIE, "", days=0)
                    return self.send(P.approve_wait(s, state="rejected"),
                                     headers={"Cache-Control": "no-store"})
                if _ast is None:
                    if db.admin_session_ok(_at, unlocked_only=True):
                        return self.redirect(self._panel_url(s, "/panel"))
                    return self.send(P.approve_wait(s, state="expired"),
                                     headers={"Cache-Control": "no-store"})
                return self.send(P.approve_wait(s, state="pending"),
                                 headers={"Cache-Control": "no-store"})
            if not owner:
                return self.send(P.login_gate(s), 403)
            if db.owner_pass_set() and not db.admin_session_ok(
                    self.cookies().get(self.ADMIN_COOKIE), unlocked_only=True):
                return self.send(P.password_gate(s), 403)
            return self.panel_get(path, q, s, tok)

        # ---------------- owner area (business owners, cookie session)
        # /register and /signup were 404s left over from the static build;
        # registration IS login here, so alias them instead of dead-ending.
        if path in ("/login", "/register", "/signup", "/owner"):
            if self.current_owner() or self.current_customer():
                return self.redirect("/my")
            return self.send(O.login_unified(s, "phone", nxt=(q.get("next") or [""])[0]))
        # v100: anonymised story view stats — owner only, aggregate counts.
        m = re.match(r"^/my/story/(\d+)/views$", path)
        if m:
            me = self.current_owner()
            sid = safe_int(m.group(1))
            st = db._one("SELECT biz_id FROM stories WHERE id=?", (sid,)) if me else None
            if not me or not st or not db.owns(me["id"], st["biz_id"]):
                return self.json_out({"ok": False}, 403)
            out = db.story_view_stats(sid)
            out["ok"] = True
            return self.json_out(out)
        if path == "/my" or path.startswith("/my/"):
            me = self.current_owner()
            if not me:
                # Remember where they were headed instead of dumping them on
                # the dashboard after sign-in.
                return self.redirect("/login?next=" + urllib.parse.quote(path))
            return self.owner_get(path, q, s, me)

        # ---------------- customer area (OTP login, cookie session)
        if path == "/me/login":
            # v69: one door — the customer login page merged into /login
            nxt = (q.get("next") or [""])[0]
            return self.redirect("/login" + (("?" + "next=" + urllib.parse.quote(nxt)) if nxt else ""))
        if path == "/me" or path.startswith("/me/"):
            # v84: /me is the PERSONAL panel («پنل من») again — it no longer
            # bounces into the shop panel. A shopkeeper reaches the business
            # side via «پنل دکان» (/my); their personal account lives here.
            if s.get("shop_account") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            cust = self.current_customer()
            if not cust:
                return self.redirect("/login")
            return self.customer_get(path, q, s, cust)

        # ---------------- cart (client-side) + areas (public)
        if path == "/cart":
            if s.get("orders_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            return self.send(CU.cart_page(s, vis_tok))
        if path == "/areas":
            return self.send(CU.areas_page(s, vis_tok))
        if path == "/categories":
            return self.send(V.categories_page(s, vis_tok))
        if path == "/cities":
            return self.send(VX.cities_page(s, vis_tok))
        m = re.match(r"^/area/([^/]+)$", path)
        if m:
            html = CU.area_page(s, urllib.parse.unquote(m.group(1)), vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        if path == "/order/ok":
            _oid = (q.get("id") or ["0"])[0]
            _cap = (q.get("cap") or [""])[0] == "1"
            return self.send(CU.order_done(s, safe_int(_oid, 0), cap=_cap))

        # ---------------- v31: top lists + flash deals + stories API
        if path == "/lists":
            if s.get("lists_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            return self.send(VX.lists_page(s, vis_tok))
        m = re.match(r"^/list/([^/]+)$", path)
        if m:
            if s.get("lists_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            html = VX.list_page(s, urllib.parse.unquote(m.group(1)), vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        if path == "/deals":
            if s.get("deals_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            return self.send(VX.deals_page(s, vis_tok))
        if path == "/api/stories":
            if s.get("stories_enabled") != "1":
                return self.json_out({"stories": []})
            rows = db.stories_active()
            return self.json_out({"stories": [
                {"id": r["id"], "image": r["image"], "kind": r.get("kind") or "image",
                 "caption": r.get("caption") or "", "duration": r.get("duration") or 0,
                 "bizname": r["bizname"], "bizslug": r["bizslug"]} for r in rows]})
        if path == "/api/live":
            # v120: بازبینی زندهٔ محتوا — کلاینت (live.js) هر چند ثانیه با
            # If-None-Match همین ETag را می‌پرسد؛ ۳۰۴ = هیچ تغییری (بدون بدنه)،
            # ۲۰۰ = ETag تازه → کلاینت صفحه را دوباره می‌گیرد و <main> را بدون
            # رفرش جابه‌جا می‌کند. ETag دقیقاً همان فرمول صفحات کش‌پذیر است
            # (اثرانگشت محتوا + مسیر) تا همیشه با هدر واقعی صفحه هم‌خانواده باشد.
            _lp = (q.get("p") or [""])[0]
            _lp_ok = (0 < len(_lp) < 120 and _lp.startswith("/")
                      and ".." not in _lp and not _lp.startswith("/api/")
                      and " " not in _lp and "\n" not in _lp and "\r" not in _lp)
            if not _lp_ok:
                return self.json_out({"error": "bad path"}, 400)
            _lk = db.page_fingerprint() + ":" + _lp
            _letag = '"' + hashlib.sha1(_lk.encode("utf-8")).hexdigest()[:16] + '"'
            if self.headers.get("If-None-Match") == _letag:
                self.send_response(304)
                self.send_header("ETag", _letag)
                self.end_headers()
                return
            return self.json_out({"etag": _letag})

        # ---------------- catalog
        m = re.match(r"^/item/(\d+)$", path)
        if m:
            # v160-fix: کالای متعلق به کسب‌وکارِ منتشرنشده برای عموم 404 است
            # (پیش‌نمایش فقط برای مدیر و مالک همان دکان).
            _it = db.item(safe_int(m.group(1)))
            if _it:
                _b = db.business(bid=_it.get("biz_id"))
                if _b and _b.get("status") != "published":
                    _me = self.current_owner()
                    _allowed = (self.admin_ok(q) or
                                (_me and db.owns(_me["id"], _b["id"])))
                    if not _allowed:
                        return self.send(V.not_found(s, vis_tok), 404)
                # v278: کالای نگه‌بررسی (spam_flag) برای عموم ۴۰۴ است
                if _it.get("spam_flag"):
                    _mo = self.current_owner()
                    if not (self.admin_ok(q) or
                            (_mo and db.owns(_mo["id"], _it["biz_id"]))):
                        return self.send(V.not_found(s, vis_tok), 404)
            html = C.item_detail(s, safe_int(m.group(1)), vis_tok,
                                 cust=self.current_customer(), q=q)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        if path == "/catalog":
            _ct = (q.get("q") or [""])[0]
            _kind = (q.get("kind") or [""])[0]
            _frag = "frag" in q
            if _ct.strip():
                db.log_search(_ct, "catalog",
                              len(db.search_items(_ct, _kind)))
            res = C.browse(s, _ct, _kind, vis_tok, frag=_frag)
            if _frag:
                return self.send(res.encode("utf-8") if isinstance(res, str) else res,
                                 200, "text/html; charset=utf-8",
                                 {"Cache-Control": "no-store"})
            return self.send(res)
        # v88: «گفتگو با دکان‌دار» — open (or reuse) the customer↔shop chat
        # thread and land in the messenger. Replaces the old anonymous
        # /ask inquiry, which the customer could never find again.
        m = re.match(r"^/b/([^/]+)/chat$", path)
        if m:
            if s.get("chat_enabled") != "1":
                return self.redirect(f"/b/{m.group(1)}")
            cust = self.current_customer()
            if not cust:
                return self.redirect("/me/login?next="
                                     + urllib.parse.quote(f"/b/{m.group(1)}/chat"))
            b = db.business(slug=m.group(1))
            if not b:
                return self.send(V.not_found(s, vis_tok), 404)
            # v150: no chatting with yourself — the shop owner must not open a
            # customer thread against their own business.
            if db.business_owner_phone(b["id"]) == (cust or {}).get("phone"):
                return self.redirect("/b/" + urllib.parse.quote(m.group(1)) + "?err=" +
                                     urllib.parse.quote("این کسب‌وکار متعلق به خود شماست؛ "
                                                        "گفتگو با خودتان ممکن نیست."))
            tid = db.chat_start(b["id"], cust["id"], subject=f"گفتگو دربارهٔ {b['name']}")
            return self.redirect(f"/me/chat/{tid}")

        # ---------------- API
        m = re.match(r"^/api/chat/(\d+)/msgs$", path)
        if m:
            tid = safe_int(m.group(1))
            thread = db.chat_thread(tid)
            if not thread:
                return self.json_out({"ok": False}, 404)
            requested = (q.get("as") or [""])[0]
            role = self.chat_role(thread, q, requested)
            if not role:
                return self.json_out({"ok": False}, 403)
            after = safe_int((q.get("after") or ["0"])[0], 0)
            rows = db.chat_messages(tid, after=after)
            # File URLs contain only numeric attachment IDs. v117/M1: the
            # admin session cookie authenticates /chat-file now, so the raw
            # key no longer rides inside the JSON payload.
            for row in rows:
                aid = row.get("attachment_id")
                if aid:
                    row["file_url"] = f"/chat-file/{aid}?as=" + role
            db.chat_mark_read(tid, role)
            fresh = db.chat_thread(tid) or thread
            return self.json_out({
                "ok": True,
                "msgs": rows,
                "read": {k: int(fresh.get(f"{k}_read_to") or 0)
                         for k in ("customer", "owner", "admin")},
                "status": fresh.get("status", "open"),
            })

        # v142: push config for notifpush.js (VAPID public key + readiness).
        # The browser decides https support itself (isSecureContext); this
        # endpoint only answers whether the admin configured the keys.
        if path == "/api/push/config":
            try:
                import fcm
                cfg_ok = fcm.configured()
                vap = fcm.vapid_public() if cfg_ok else ""
            except Exception:
                cfg_ok, vap = False, ""
            return self.json_out({"ok": True, "configured": bool(cfg_ok),
                                  "vapid": vap})
        # v142: unread count for the header bell poll (mirrors the header:
        # when both identities exist the customer side is what the bell shows)
        # v213: assistant status for the widget — quota/tier only, never config.
        if path == "/api/assistant/status":
            c = self.current_customer(); o = self.current_owner()
            key = self._assistant_key(c, o)
            rem, tier = assistant.person_remaining(c, o, key)
            return self.json_out({"ok": True, "enabled": assistant.enabled(),
                                  "signed_in": bool(c or o), "tier": tier,
                                  "tier_label": assistant.TIER_LABEL.get(tier, ""),
                                  "quota": assistant.quota_for(tier, c, o),
                                  "remaining": rem})
        if path == "/api/unread-count":
            c = self.current_customer()
            o = self.current_owner()
            if o and db.owner_has_business(o["id"]):
                # v146: a real shopkeeper counts both roles' inboxes (same
                # person); a plain owner-session without a business stays on
                # the customer inbox like before.
                n = db.owner_unread(o["id"])
                if c:
                    n += db.notifications_unread(c["id"])
            elif c:
                n = db.notifications_unread(c["id"])
            else:
                return self.json_out({"ok": False}, 403)
            return self.json_out({"ok": True, "n": n})
        if path == "/api/nearby":
            try:
                lat = float((q.get("lat") or ["0"])[0])
                lng = float((q.get("lng") or ["0"])[0])
                rad = float((q.get("r") or ["3"])[0])
            except ValueError:
                return self.json_out({"results": [], "error": "bad coords"}, 400)
            rad = max(0.2, min(50.0, rad))
            ci = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}
            rows = db.nearby(lat, lng, rad, (q.get("cat") or [""])[0],
                             (q.get("q") or [""])[0])
            return self.json_out({"results": [
                {"slug": b["slug"], "name": b["name"], "descr": b.get("descr") or "",
                 "address": b.get("address") or "", "distance_km": b["distance_km"],
                 "rating": b.get("rating") or 0, "nreviews": b.get("nreviews") or 0,
                 "icon": ci.get(b["cat_slug"], "store"),
                 "image": (b.get("images") or [""])[0]}
                for b in rows]})

        if path == "/api/businesses":
            rows = db.businesses()
            return self.json_out([{k: b[k] for k in
                                   ("slug","name","cat_slug","address","lat","lng",
                                    "featured","hours")} for b in rows])

        # ---- live search suggestions for the hero box (v50)
        if path == "/api/search":
            term = (q.get("q") or [""])[0].strip()
            out = []
            if term:
                # businesses + their trade name, capped and cheap
                for b in db.search(term=term)[:6]:
                    out.append({"kind": "biz", "slug": b["slug"], "name": b["name"],
                                "cat": (db.category(b["cat_slug"]) or {}).get("name", "")})
                # matching categories, so "کباب" also surfaces the trade itself
                for c in db.categories(only_active=True):
                    if term in (c["name"] or "") and len(out) < 8:
                        out.append({"kind": "cat", "slug": c["slug"], "name": c["name"], "cat": ""})
            return self.json_out({"results": out[:8]})

        # ---------------- public
        if path == "/":
            return self.send(V.home(s, vis_tok))
        if path == "/businesses":
            pg = (q.get("page") or ["1"])[0]
            term = (q.get("q") or [""])[0]
            city = (q.get("city") or [""])[0]
            if term.strip():
                # count it once, on the first page only, so paging through
                # results does not inflate the number
                if pg in ("", "1"):
                    n_hits = len(db.search(term=term, cat=(q.get("cat") or [""])[0], city=city))
                    db.log_search(term, (q.get("cat") or [""])[0], n_hits)
            _frag = (q.get("frag") or [""])[0] == "1"
            html = V.businesses(s, term,
                                (q.get("cat") or [""])[0],
                                (q.get("sort") or ["featured"])[0], vis_tok,
                                pg_no=int(pg) if pg.isdigit() else 1,
                                open_now=(q.get("open") or [""])[0] == "1",
                                city=city, frag=_frag)
            if _frag:
                # v120: fragment for the live directory search — never cached
                return self.send(html, ctype="text/html; charset=utf-8",
                                 headers={"Cache-Control": "no-store"})
            return self.send(html)
        if path.startswith("/b/") and path.endswith("/stories"):
            # v177: تاریخچهٔ عمومی استوری‌های یک دکان — پیش‌نمایشِ دکانِ
            # منتشرنشده همان قاعدهٔ صفحهٔ دکان را دارد.
            _slug = path[3:-len("/stories")]
            _b = db.business(slug=_slug)
            if _b and _b.get("status") != "published":
                _me = self.current_owner()
                _allowed = (self.admin_ok(q) or
                            (_me and db.owns(_me["id"], _b["id"])))
                if not _allowed:
                    return self.send(V.not_found(s, vis_tok), 404)
            html = V.biz_stories(s, _slug, vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        if path.startswith("/b/"):
            _slug = path[3:]
            _b = db.business(slug=_slug)
            if _b and _b.get("status") != "published":
                # v160-fix: کسب‌وکارِ منتشرنشده (pending/rejected) برای عموم 404 است؛
                # فقط مدیر سایت و مالکِ همان دکان حق پیش‌نمایش دارند.
                _me = self.current_owner()
                _allowed = (self.admin_ok(q) or
                            (_me and db.owns(_me["id"], _b["id"])))
                if not _allowed:
                    return self.send(V.not_found(s, vis_tok), 404)
            html = V.business(s, _slug, vis_tok, q, cust=self.current_customer())
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        if path == "/map":
            return self.send(V.map_page(s, vis_tok))
        if path == "/blog":
            # v173/#34: کلید blog_enabled از v165 در پنل نمایش داده می‌شد ولی
            # هیچ‌جا خوانده نمی‌شد — خاموشش هم /blog را نمی‌بست (کلید بی‌اثر).
            if s.get("blog_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            return self.send(V.blog(s, vis_tok))
        if path.startswith("/blog/"):
            if s.get("blog_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            html = V.blog_post(s, path[6:], vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        m = re.match(r"^/haggle/(\d+)$", path)
        if m:
            if s.get("prices_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            html = V2.haggle_form(s, safe_int(m.group(1)), vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        m = re.match(r"^/offer/([A-Za-z0-9_-]{6,64})$", path)
        if m:
            if s.get("prices_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            db.expire_haggles()
            html = V2.haggle_thread_page(s, m.group(1), vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        # ---- QR image for a shop, as SVG. A shopkeeper sticks this on the
        # window; research puts shop-window scan rates at 5-10% against
        # 1-3% for print advertising. SVG so it prints at any size.
        m = re.match(r"^/qr/([^/]+)\.svg$", path)
        if m:
            # v285: QR generation is real CPU work — bound it per client.
            if not db.rate_ok("qr:" + self.client_key(), limit=60, window=60):
                return self.send("too many requests", 429,
                                 "text/plain; charset=utf-8")
            b = db.business(slug=urllib.parse.unquote(m.group(1)))
            if not b:
                return self.send(V.not_found(s, vis_tok), 404)
            url = f"{self.site_origin(s)}/b/{b['slug']}"
            try:
                size = int((q.get("size") or ["512"])[0])
            except Exception:
                size = 512
            size = max(128, min(2048, size))
            dl = (q.get("dl") or [""])[0] == "1"
            hdr = {}
            if dl:
                fn = re.sub(r"[^\w.-]", "_", b["slug"])[:40] or "qr"
                hdr["Content-Disposition"] = f'attachment; filename="{fn}-qr.svg"'
            return self.send(qrlib.svg(url, size=size), 200,
                             "image/svg+xml; charset=utf-8", hdr)

        m = re.match(r"^/vcard/([^/]+)$", path)
        if m:
            b = db.business(slug=urllib.parse.unquote(m.group(1)))
            if not b or b.get("status") != "published":
                return self.send(V.not_found(s, vis_tok), 404)
            db.track(b["id"], "vcard")
            fname = re.sub(r"[^\w.-]", "_", b["slug"])[:40] or "contact"
            return self.send(db.vcard(b), 200, "text/vcard; charset=utf-8",
                             {"Content-Disposition":
                              f'attachment; filename="{fname}.vcf"'})
        if path == "/prices":
            if s.get("prices_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            return self.send(V2.price_compare(
                s, (q.get("q") or [""])[0], (q.get("cat") or [""])[0],
                (q.get("key") or [""])[0], vis_tok))
        if path == "/nearby":
            if s.get("nearby_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            return self.send(V2.nearby_page(s, vis_tok))
        if path == "/events":
            if s.get("events_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            return self.send(V2.events(s, vis_tok))
        if path.startswith("/events/"):
            html = V2.event_detail(s, path[8:], vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        m = re.match(r"^/ad/(\d+)$", path)
        if m:
            a = db.ad_click(safe_int(m.group(1)))
            dest = (a or {}).get("url") or ""
            if not dest and a and a.get("biz_id"):
                b = db.business(a["biz_id"])
                if b and b.get("slug"):
                    dest = f"/b/{b['slug']}"
            if not dest:
                dest = "/"
            if dest.startswith("//") or not dest.startswith(("/", "http://", "https://")):
                dest = "/"
            return self.redirect(dest)
        if path == "/favorites":
            return self.send(V.favorites(s, vis_tok))
        if path == "/pricing":
            return self.send(V.pricing(s, vis_tok, q))
        if path == "/subscribe":
            if s.get("plans_enabled") != "1":
                return self.redirect("/pricing")
            html = V.subscribe(s, (q.get("plan") or [""])[0],
                               self.current_owner(), vis_tok, q)
            return self.send(html) if html else self.redirect("/pricing")
        if path == "/contact":
            return self.send(V.contact(s, vis_tok, sent=bool(q.get("sent"))))
        if path == "/assistant":                    # v213.2: full chat page
            if s.get("ai_enabled", "1") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            c = self.current_customer(); o = self.current_owner()
            key = self._assistant_key(c, o)
            rem, tier = assistant.person_remaining(c, o, key)
            st = {"tier_label": assistant.TIER_LABEL.get(tier, ""),
                  "quota": assistant.quota_for(tier, c, o), "remaining": rem}
            return self.send(ui.assistant_page(s, st))
        if path == "/submit":
            # v208: the one-page form is replaced by the staged wizard; the
            # old URL stays as a redirect so menus, SEO and bookmarks survive.
            return self.redirect(register_web.BASE)
        if path == register_web.BASE or path.startswith(register_web.BASE + "/"):
            return register_web.get(self, path, q, s)
        if path == "/features":
            return self.send(V2.features(s, vis_tok, self.current_owner()))
        if path in ("/about", "/rules"):
            return self.send(V.static_page(s, path[1:], vis_tok))

        return self.send(V.not_found(s, vis_tok), 404)

    # -------------------------------------------------------------- owner GET
    def owner_get(self, path, q, s, me):
        if path == "/my":
            return self.send(O.dashboard(s, me, q, cust=self.current_customer()))
        if path == "/my/notifications":          # v142
            return self.send(O.notifications_page(s, me, q))
        if path == "/my/notif-settings":          # v142
            return self.send(O.notif_settings_page(s, me, q))
        m = re.match(r"^/my/notif/(\d+)/go$", path)   # v142: click = read + follow link
        if m:
            n = db.owner_notification(me["id"], safe_int(m.group(1)))
            if n:
                db.owner_mark_read(me["id"], n["id"])
                dest = n.get("link") or "/my/notifications"
                dest = _LEGACY_NOTIF_LINK.get(dest, dest)
                if not (dest.startswith("/") and not dest.startswith("//")):
                    dest = "/my/notifications"
                else:
                    # v160-fix: هدفِ حذف‌شده → مقصدِ معقول، نه صفحهٔ 404
                    mc = re.match(r"^/my/chat/(\d+)$", dest)
                    if mc:
                        th = db.chat_thread(safe_int(mc.group(1)))
                        if not th or not db.owns(me["id"], th.get("biz_id")):
                            dest = "/my/chats"
                return self.redirect(dest)
            return self.send(V.not_found(s), 404)
        if path == "/my/chats":
            return self.send(O.owner_chats(s, me, q))
        m = re.match(r"^/my/chat/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1))
            thread = db.chat_thread(tid)
            if thread and db.owns(me["id"], thread["biz_id"]):
                db.chat_mark_read(tid, "owner")
            html = O.owner_chat_view(s, me, tid, q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        if path == "/my/orders":
            return self.send(O.owner_orders(s, me, q))
        if path == "/my/assistant":                       # v227
            return self.send(O.owner_assistant(s, me, q))
        if path == "/my/stories":
            return self.send(O.owner_stories(s, me, q))
        if path == "/my/trash":                       # v105: recycle bin
            return self.send(O.owner_trash(s, me, q))
        if path == "/my/businesses":
            return self.send(O.biz_list(s, me, q))
        if path == "/my/qr":                                   # v285
            try:
                _bid = safe_int((q.get("bid") or ["0"])[0])
            except Exception:
                _bid = 0
            return self.send(O.owner_qr(s, me, q, bid=_bid))
        if path == "/my/reviews":
            return self.send(O.reviews(s, me, q))
        if path == "/my/bookings":
            return self.send(O.bookings(s, me, q))
        if path == "/my/inquiries":
            return self.send(C.inquiry_list(s, me, q))
        if path == "/my/claim":
            return self.send(O.claim(s, me, q, (q.get("q") or [""])[0]))
        if path == "/my/questions":
            return self.send(O.questions(s, me, q))
        if path == "/my/offers":
            return self.send(O.offers(s, me, q))
        if path == "/my/tickets":
            return self.send(O.tickets(s, me, q))
        m = re.match(r"^/my/ticket/(\d+)$", path)
        if m:
            html = O.ticket_view(s, me, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        if path == "/my/plan":
            return self.send(O.plan_page(s, me, q))
        if path == "/my/broadcast":
            return self.send(O.broadcast_page(s, me, q))
        if path == "/my/account":
            return self.send(O.account(s, me, q))
        if path == "/my/export":
            # The `export` paid feature. Gate on the owner's shops: if none of
            # them holds it, bounce back with the reason rather than a file.
            mine = db.businesses_of(me["id"])
            if not mine:
                return self.redirect("/my/plan?err=" + urllib.parse.quote(
                    "ابتدا یک کسب‌وکار ثبت کنید."))
            if not any(db.can(b["id"], "export") for b in mine):
                return self.gate(mine[0]["id"], "export", "/my/plan") or \
                       self.redirect("/my/plan")
            kind = (q.get("kind") or ["customers"])[0]
            if kind not in ("customers", "bookings", "inquiries", "items"):
                kind = "customers"
            db.log("export.owner", f"owner {me['id']}: {kind}")
            return self.send(db.owner_export_csv(me["id"], kind), 200,
                             "text/csv; charset=utf-8",
                             {"Content-Disposition":
                              f'attachment; filename="bazarche-{kind}.csv"'})

        m = re.match(r"^/my/business/(\d+)$", path)
        if m:
            html = O.biz_edit(s, me, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        m = re.match(r"^/my/gallery/(\d+)$", path)
        if m:
            html = O.gallery(s, me, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        m = re.match(r"^/my/stats/(\d+)$", path)
        if m:
            html = O.stats(s, me, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        m = re.match(r"^/my/catalog/(\d+)$", path)
        if m:
            html = C.manage(s, me, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        m = re.match(r"^/my/catalog/(\d+)/item/(new|\d+)$", path)
        if m:
            iid = None if m.group(2) == "new" else safe_int(m.group(2))
            html = C.item_edit(s, me, safe_int(m.group(1)), iid, q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        return self.send(V.not_found(s), 404)

    # -------------------------------------------------------------- customer GET
    def customer_get(self, path, q, s, cust):
        if path == "/me":
            return self.send(CU.dashboard(s, cust, q))
        if path == "/me/profile":
            return self.send(CU.profile(s, cust, q))
        if path == "/me/chats":
            return self.send(CU.chats_list(s, cust, q))
        m = re.match(r"^/me/chat/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1))
            thread = db.chat_thread(tid)
            if thread and thread.get("customer_id") == cust["id"]:
                db.chat_mark_read(tid, "customer")
            html = CU.chat_view(s, cust, tid, q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        if path == "/me/orders":
            return self.send(CU.orders_list(s, cust, q))
        m = re.match(r"^/me/order/(\d+)$", path)
        if m:
            html = CU.order_view(s, cust, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        if path == "/me/favorites":
            return self.send(CU.favorites_server(s, cust))
        if path == "/me/account":
            return self.send(CU.account(s, cust, q))
        if path == "/me/bale/connect":
            if not bale.enabled():
                return self.redirect("/me/notif-settings?err=" + urllib.parse.quote(
                    "اتصال بله موقتاً در دسترس نیست."))
            if not db.rate_ok("bale-link:" + str(cust["id"]), limit=6,
                              window=600, always=True):
                return self.redirect("/me/notif-settings?err=" + urllib.parse.quote(
                    "تعداد درخواست‌ها زیاد است؛ ده دقیقه بعد تلاش کنید."))
            ch = db.messenger_challenge_new("link", cust["id"])
            self.set_cookie("bzv2_bale", ch["browser_token"], days=1)
            return self.send(O.bale_wait_page(s, ch, "link"),
                             headers={"Cache-Control": "no-store"})
        if path == "/me/soroush/connect":
            if not soroush.enabled():
                return self.redirect("/me/notif-settings?err=" + urllib.parse.quote("اتصال سروش‌پلاس در دسترس نیست."))
            if not db.rate_ok("soroush-link:" + str(cust["id"]), limit=6, window=600, always=True):
                return self.redirect("/me/notif-settings?err=" + urllib.parse.quote("تعداد درخواست‌ها زیاد است."))
            ch = db.messenger_challenge_new("link", cust["id"], ttl=300, platform="soroush")
            self.set_cookie("bzv2_soroush", ch["browser_token"], days=1)
            return self.send(O.soroush_wait_page(s, ch, "link"), headers={"Cache-Control":"no-store"})
        if path == "/me/export":          # v117/فاز۶: my data, portable
            return self.send(db.customer_export_csv(cust["id"]), 200,
                             "text/csv; charset=utf-8",
                             {"Content-Disposition":
                              'attachment; filename="my-data.csv"'})
        m = re.match(r"^/me/notif/(\d+)/go$", path)   # v142: click = read + follow link
        if m:
            cust = self.current_customer()
            if cust:
                n = db.customer_notification(cust["id"], safe_int(m.group(1)))
                if n:
                    db.customer_mark_read(cust["id"], n["id"])
                    dest = n.get("link") or "/me/notifications"
                    dest = _LEGACY_NOTIF_LINK.get(dest, dest)
                    if not (dest.startswith("/") and not dest.startswith("//")):
                        dest = "/me/notifications"
                    else:
                        # v160-fix: هدفِ حذف‌شده → مقصدِ معقول، نه صفحهٔ 404
                        mo = re.match(r"^/me/order/(\d+)$", dest)
                        mi = re.match(r"^/item/(\d+)$", dest)
                        mb = re.match(r"^/b/([^/?#]+)$", dest)
                        if mo:
                            o = db.order(safe_int(mo.group(1)))
                            if not o or o.get("customer_id") != cust["id"]:
                                dest = "/me/orders"
                        elif mi and not db.item(safe_int(mi.group(1))):
                            dest = "/"
                        elif mb and not db.business(slug=mb.group(1)):
                            dest = "/businesses"
                        mc = re.match(r"^/me/chat/(\d+)$", dest)
                        if mc:
                            th = db.chat_thread(safe_int(mc.group(1)))
                            if not th or th.get("customer_id") != cust["id"]:
                                dest = "/me/chats"
                    return self.redirect(dest)
            return self.send(V.not_found(s), 404)
        if path == "/me/notifications":
            return self.send(CU.notifications_page(s, cust, q))
        if path == "/me/notif-settings":
            return self.send(CU.notif_settings_page(s, cust, q))
        if path == "/me/following":
            return self.send(CU.following_page(s, cust, q))
        return self.send(V.not_found(s), 404)

    def sitemap(self, s):
        """v217: sitemap با lastmod/changefreq/priority + دسته‌ها + شهرها.
        lastmod فقط جایی که تاریخ واقعی داریم (کسب‌وکار/مقاله) نوشته می‌شود."""
        origin = self.site_origin(s)
        def d(x):
            x = str(x or "")[:10]
            return x if re.match(r"^\d{4}-\d{2}-\d{2}$", x) else ""
        rows = []
        for u, cf, pr in ((("/", "daily", "1.0"), ("/businesses", "daily", "0.9"), ("/map", "weekly", "0.7"),
                            ("/nearby", "weekly", "0.7"), ("/catalog", "daily", "0.8"), ("/deals", "daily", "0.8"),
                            ("/events", "weekly", "0.6"), ("/lists", "weekly", "0.6"), ("/areas", "weekly", "0.6"),
                            ("/categories", "weekly", "0.7"), ("/cities", "weekly", "0.6"), ("/blog", "daily", "0.7"),
                            ("/pricing", "monthly", "0.5"), ("/register-business", "monthly", "0.6"),
                            ("/about", "monthly", "0.4"), ("/contact", "monthly", "0.4"), ("/rules", "yearly", "0.2"))):
            rows.append((u, "", cf, pr))
        if s.get("prices_enabled") == "1":
            rows.append(("/prices", "", "weekly", "0.6"))
        try:
            for c in db.categories(only_active=True):
                rows.append((f"/businesses?cat={urllib.parse.quote(c['slug'])}", "", "weekly", "0.7"))
        except Exception:
            pass
        try:
            for c in db.businesses_city_counts():
                name = c.get("city")
                if name and (c.get("c") or 0) > 0:
                    rows.append((f"/businesses?city={urllib.parse.quote(str(name))}", "", "weekly", "0.6"))
        except Exception:
            pass
        for b in db.businesses():
            rows.append((f"/b/{b['slug']}", d(b.get("updated") or b.get("created")), "weekly", "0.8"))
        for p in db.posts():
            rows.append((f"/blog/{p['slug']}", d(p.get("updated") or p.get("created")), "monthly", "0.6"))
        rows += [(f"/area/{urllib.parse.quote(a['area'])}", "", "weekly", "0.5") for a in db.areas()]
        rows += [(f"/list/{t['slug']}", "", "weekly", "0.5") for t in db.toplists()]
        seen = set(); items = []
        for u, lm, cf, pr in rows:
            if u in seen: continue
            seen.add(u)
            loc = _html.escape(origin + u, quote=True)
            items.append(f"<url><loc>{loc}</loc>" + (f"<lastmod>{lm}</lastmod>" if lm else "")
                         + f"<changefreq>{cf}</changefreq><priority>{pr}</priority></url>")
        xml = ('<?xml version="1.0" encoding="UTF-8"?>'
               '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
               + "".join(items) + "</urlset>")
        self.send(xml, 200, "application/xml; charset=utf-8")

    def feed(self, s):
        """v217: RSS 2.0 برای مقالات — گوگل‌نیوز/فیدخوان‌ها/بات‌ها."""
        origin = self.site_origin(s)
        name = _html.escape(s.get("site_name") or "دست گیر")
        items = []
        for p in db.posts(limit=30):
            link = f"{origin}/blog/{p['slug']}"
            items.append("<item><title>" + _html.escape(p.get("title") or "") + "</title>"
                         f"<link>{link}</link><guid>{link}</guid>"
                         "<description>" + _html.escape(p.get("excerpt") or "") + "</description>"
                         "<pubDate>" + _html.escape(str(p.get("created") or "")) + "</pubDate></item>")
        xml = ('<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel>'
               f"<title>{name} — اخبار و راهنما</title><link>{origin}/blog</link>"
               f"<description>{_html.escape(s.get('tagline') or '')}</description><language>fa-IR</language>"
               + "".join(items) + "</channel></rss>")
        self.send(xml, 200, "application/rss+xml; charset=utf-8")

    # -------------------------------------------------------------- panel GET
    def panel_get(self, path, q, s, tok):
        # v300 agent panel — dedicated live console, key only via Bale bot
        if path.startswith("/panel/agent"):
            # query ak= token -> consume and set HttpOnly 7d cookie
            ak = (q.get("ak") or [""])[0]
            if ak:
                try:
                    if db.agent_key_consume(ak, self.client_key()):
                        self.set_cookie(self.AGENT_COOKIE, ak, days=7)
                        # redirect without ak in URL
                        return self.redirect(self._panel_url(s, "/panel/agent"))
                except Exception:
                    pass
            agent_ok = True   # v309 (دستور مدیر): نشست پنل = دسترسی کامل، بدون کلید بله
            # sub-routes for live inspection
            if path == "/panel/agent/code":
                if not agent_ok:
                    return self.send(P2.agent_panel_page(s, tok, q, agent_ok=False))
                # ?f=path&search=term
                fpath = (q.get("f") or [""])[0][:200]
                search = (q.get("q") or [""])[0][:100]
                code_html = ""
                try:
                    import adminbot_content as _CT
                    if search:
                        res = _CT.tool_execute("code_search", {"pattern": search, "limit": 50})
                        code_html = f"<pre>{_html.escape(str(res)[:8000])}</pre>"
                    elif fpath:
                        # safe read only inside site/server
                        safe_base = os.path.abspath(os.path.join(HERE, ".."))
                        cand = os.path.abspath(os.path.join(safe_base, fpath.lstrip("/")))
                        if cand.startswith(safe_base) and os.path.isfile(cand):
                            txt = open(cand, "r", encoding="utf-8", errors="ignore").read()[:20000]
                            code_html = f"<h3>{_html.escape(fpath)}</h3><pre style='max-height:60vh;overflow:auto'>{_html.escape(txt)}</pre>"
                        else:
                            code_html = "<p>مسیر نامعتبر</p>"
                except Exception as e:
                    code_html = f"<p>خطا: {_html.escape(str(e)[:300])}</p>"
                # embed in agent page shell
                shell = P2.agent_panel_page(s, tok, q, agent_ok=True)
                # inject code_html before </body>
                shell = shell.replace("</body>", code_html + "</body>")
                return self.send(shell)
            return self.send(P2.agent_panel_page(s, tok, q, agent_ok=agent_ok))
        if path == "/panel":
            return self.send(P.dashboard(s, tok, q))
        if path == "/panel/businesses":
            return self.send(P.biz_list(s, tok, q))
        if path == "/panel/business/new":
            return self.send(P.biz_edit(s, tok, None, q))
        m = re.match(r"^/panel/business/(\d+)$", path)
        if m:
            html = P.biz_edit(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        if path == "/panel/categories":
            return self.send(P.cat_list(s, tok, q))
        m = re.match(r"^/panel/category/(\d+)$", path)
        if m:
            html = P.cat_edit(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        if path == "/panel/reviews":
            return self.send(P.rev_list(s, tok, q))
        if path == "/panel/bookings/export":          # v296: خروجی عملیاتی
            _st = (q.get("status") or [""])[0].strip() or None
            _q = (q.get("q") or [""])[0].strip()[:80] or None
            return self.send(db.export_bookings_csv(status=_st, q=_q), 200,
                             "text/csv; charset=utf-8",
                             {"Content-Disposition": 'attachment; filename="bazarche-bookings.csv"'})
        if path == "/panel/bookings":
            return self.send(P.book_list(s, tok, q))
        if path == "/panel/posts":
            return self.send(P.post_list(s, tok, q))
        m = re.match(r"^/panel/post/(\d+)$", path)
        if m:   # v170/A5: ویرایش مقاله
            html = P.post_edit(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        if path == "/panel/messages":
            return self.send(P.msg_list(s, tok, q))
        if path == "/panel/pages":
            return self.send(P.pages_edit(s, tok, q))
        if path == "/panel/appearance":
            return self.send(P.appearance(s, tok, q))
        if path == "/panel/search":                # v117/M4
            return self.send(P2.panel_search(s, tok, q))
        if path == "/panel/settings":
            return self.send(P.settings_page(s, tok, q))
        if path == "/panel/owners":
            return self.send(P.owner_list(s, tok, q))
        if path == "/panel/claims":
            return self.send(P.claim_list(s, tok, q))
        if path == "/panel/inquiries":
            return self.send(C.inquiry_list(s, None, q, admin_token=tok))
        m = re.match(r"^/panel/gallery/(\d+)$", path)
        if m:
            html = O.gallery(s, None, safe_int(m.group(1)), q, admin_token=tok)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        m = re.match(r"^/panel/catalog/(\d+)$", path)
        if m:
            html = C.manage(s, None, safe_int(m.group(1)), q, admin_token=tok)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        m = re.match(r"^/panel/catalog/(\d+)/item/(new|\d+)$", path)
        if m:
            iid = None if m.group(2) == "new" else safe_int(m.group(2))
            html = C.item_edit(s, None, safe_int(m.group(1)), iid, q, admin_token=tok)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        # ---- v3 admin screens
        if path == "/panel/qa":
            return self.send(P2.qa_list(s, tok, q))
        if path == "/panel/reports":
            return self.send(P2.report_list(s, tok, q))
        if path == "/panel/trash":                     # v105: recycle bin (all)
            return self.send(P2.admin_trash(s, tok, q))
        if path == "/panel/traffic":                   # v112: abuse shield report
            return self.send(P2.admin_traffic(s, tok, q))
        if path == "/panel/spam":                      # v279: spam console (فاز۵)
            return self.send(P2.admin_spam(s, tok, q))
        if path == "/panel/analytics":                 # v114: real-visit analytics
            return self.send(P2.admin_analytics(s, tok, q))
        if path == "/panel/analytics/export":          # v115: CSV export (Excel-ready)
            import csv as _csv
            days = safe_int((q.get("days") or ["30"])[0]) or 30
            days = min(max(days, 1), 365)
            buf = io.StringIO()
            w = _csv.writer(buf)
            w.writerow(["ts_utc", "path", "kind", "biz_id", "item_id",
                        "story_id", "ip", "prov", "city", "device",
                        "visitor_id", "session_id", "referrer", "utm", "bot"])
            for r in db._rows(
                    "SELECT ts,path,kind,biz_id,item_id,story_id,ip,prov,city,"
                    "dev,cid,sid,ref,utm,bot FROM visits WHERE ts>=? "
                    "ORDER BY id DESC", (time.time() - days * 86400,)):
                w.writerow([time.strftime("%Y-%m-%d %H:%M:%S",
                                          time.gmtime(r["ts"])),
                            r["path"], r["kind"], r["biz_id"] or "",
                            r["item_id"] or "", r["story_id"] or "",
                            r["ip"], r["prov"], r["city"], r["dev"],
                            r["cid"], r["sid"], r["ref"], r["utm"], r["bot"]])
            body = "\ufeff" + buf.getvalue()           # BOM = Excel reads UTF-8
            return self.send(
                body, 200, "text/csv; charset=utf-8",
                {"Content-Disposition":
                 f'attachment; filename="bazarche-visits-{days}d.csv"'})
        if path == "/panel/badges":
            return self.send(P2.badge_list(s, tok, q))
        if path == "/panel/plans":
            return self.send(P2.plan_list(s, tok, q))
        if path == "/panel/subscriptions":
            return self.send(P2.sub_list(s, tok, q))
        if path == "/panel/ads":
            return self.send(P2.ad_list(s, tok, q))
        m = re.match(r"^/panel/ad/(\d+)$", path)
        if m:   # v293: ویرایش بنر پس از انتشار
            html = P2.ad_edit(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        if path == "/panel/events":
            return self.send(P2.event_list(s, tok, q))
        m = re.match(r"^/panel/event/(\d+)$", path)
        if m:   # v170/A5: ویرایش رویداد
            html = P2.event_edit(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        if path == "/panel/edits":
            return self.send(P2.edit_list(s, tok, q))
        if path == "/panel/alerts":
            return self.send(P2.alert_list(s, tok, q))
        if path == "/panel/insights":
            return self.send(P2.insights(s, tok, q))
        if path == "/panel/inbox":
            return self.send(P2.inbox_page(s, tok, q))
        if path == "/panel/features":
            return self.send(P2.features_page(s, tok, q))
        if path == "/panel/tickets":
            return self.send(P2.ticket_list(s, tok, q))
        m = re.match(r"^/panel/ticket/(\d+)$", path)
        if m:
            html = P2.ticket_detail(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 404)
        if path == "/panel/unlocks":
            return self.send(P2.unlock_list(s, tok, q))

        # ---- v28: admin sees ALL chats and orders
        if path == "/panel/chats":
            return self.send(P2.admin_chats(s, tok, q))
        m = re.match(r"^/panel/chat/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1))
            if db.chat_thread(tid):
                db.chat_mark_read(tid, "admin")
            html = P2.admin_chat_view(s, tok, tid, q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        if path == "/panel/orders/export":            # v296: خروجی عملیاتی
            _st = (q.get("status") or [""])[0].strip() or None
            _q = (q.get("q") or [""])[0].strip()[:80] or None
            return self.send(db.export_orders_csv(status=_st, q=_q), 200,
                             "text/csv; charset=utf-8",
                             {"Content-Disposition": 'attachment; filename="bazarche-orders.csv"'})
        m = re.match(r"^/panel/order/(\d+)$", path)
        if m:                                          # v296: صفحهٔ جزئیات سفارش
            html = P2.order_detail(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        if path == "/panel/orders":
            return self.send(P2.admin_orders(s, tok, q))

        # ---- v31: top lists, deals, stories
        if path == "/panel/lists":
            return self.send(P2.admin_lists(s, tok, q))
        m = re.match(r"^/panel/list/(\d+)$", path)
        if m:
            html = P2.admin_list_edit(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        if path == "/panel/deals":
            return self.send(P2.admin_deals(s, tok, q))
        m = re.match(r"^/panel/deal/(\d+)$", path)
        if m:   # v294: ویرایش فلش‌سیل پس از انتشار
            html = P2.deal_edit(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        if path == "/panel/stories":
            return self.send(P2.admin_stories(s, tok, q))
        m = re.match(r"^/panel/story/(\d+)$", path)
        if m:   # v295: ویرایش استوری پس از انتشار
            html = P2.story_edit(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)

        # ---- v29: content editor, activity log, customers, areas
        if path == "/panel/editor":
            return self.send(P2.editor_page(s, tok, q))
        if path == "/panel/assistant":                # v213
            return self.send(P2.assistant_page(s, tok, q))
        if path == "/panel/audit":
            return self.send(P2.audit_page(s, tok, q))
        if path == "/panel/audit/export":           # v117/M5: filterable CSV
            import csv as _csv5
            f_act = (q.get("action") or [""])[0].strip()[:40]
            f_det = (q.get("detail") or [""])[0].strip()[:60]
            try:
                f_days = min(730, max(0, int((q.get("days") or ["0"])[0])))
            except ValueError:
                f_days = 0
            buf = io.StringIO()
            buf.write("\ufeff")   # Excel reads the Persian text correctly
            w = _csv5.writer(buf)
            w.writerow(["id", "action", "detail", "created"])
            for r in db.audit_log(50000, action=f_act, detail=f_det, days=f_days):
                w.writerow([r["id"], r["action"], r["detail"],
                            str(r["created"])[:19]])
            return self.send(buf.getvalue(), 200, "text/csv; charset=utf-8",
                             {"Content-Disposition":
                              'attachment; filename="audit-log.csv"'})

        if path == "/panel/moderation":             # v117/M5: unified queue
            return self.send(P2.moderation_page(s, tok, q))
        if path == "/panel/customers/export":         # v296: خروجی عملیاتی
            _q = (q.get("q") or [""])[0].strip()[:80] or None
            return self.send(db.export_customers_csv(q=_q), 200,
                             "text/csv; charset=utf-8",
                             {"Content-Disposition": 'attachment; filename="bazarche-customers.csv"'})
        if path == "/panel/customers":
            return self.send(P2.customers_page(s, tok, q))
        if path == "/panel/broadcast":
            return self.send(P2.broadcast_page(s, tok, q))
        if path == "/panel/follows":
            return self.send(P2.follows_page(s, tok, q))
        if path == "/panel/areas":
            return self.send(P2.areas_page(s, tok, q))
        if path == "/panel/demo":
            return self.send(P2.demo_page(s, tok, q))

        if path == "/panel/businesses/import":
            return self.send(P.csv_import(s, tok, q))
        if path == "/panel/businesses/export":
            return self.send(db.export_csv(), 200, "text/csv; charset=utf-8",
                             {"Content-Disposition":
                              'attachment; filename="bazarche-businesses.csv"'})
        if path == "/panel/backup":
            return self.send(P.backup_page(s, tok, q))
        if path == "/panel/backup/export":
            data = json.dumps(db.export_all(), ensure_ascii=False, indent=1)
            db.set_setting("last_backup_at", time.strftime("%Y-%m-%d %H:%M"))
            return self.send(data, 200, "application/json; charset=utf-8",
                             {"Content-Disposition":
                              'attachment; filename="bazarche-backup.json"'})
        if path == "/panel/backup/full":
            # JSON + every uploaded image, zipped — a complete, portable backup.
            import datetime as _dt
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                _backup_all = db.export_all()
                _backup_json = json.dumps(_backup_all, ensure_ascii=False,
                                          indent=1)
                z.writestr("backup.json", _backup_json)
                # v135: a manifest with sha256 so a downloaded backup can be
                # verified for corruption before anyone trusts it.
                z.writestr("manifest.json", json.dumps({
                    "created": _dt.datetime.now().isoformat(timespec="seconds"),
                    "sha256_backup_json":
                        hashlib.sha256(_backup_json.encode("utf-8")).hexdigest(),
                    "tables": len(_backup_all),
                }, ensure_ascii=False, indent=1))
                for f in uploads.list_files():
                    full = os.path.join(uploads.UPLOAD_DIR, f["name"])
                    try:
                        z.write(full, "uploads/" + f["name"])
                    except OSError:
                        continue
                # Private messenger bytes live outside the web root, but a
                # complete backup must travel with their SQLite metadata.
                for f in uploads.list_chat_files():
                    full = os.path.join(uploads.CHAT_UPLOAD_DIR, f["name"])
                    try:
                        z.write(full, "chat-files/" + f["name"])
                    except OSError:
                        continue
            db.set_setting("last_backup_at", time.strftime("%Y-%m-%d %H:%M"))
            stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M")
            return self.send(buf.getvalue(), 200, "application/zip",
                             {"Content-Disposition":
                              f'attachment; filename="bazarche-backup-{stamp}.zip"'})
        if path == "/panel/backup/db":
            # v134: a real, consistent snapshot of the SQLite database via
            # SQLite's online backup API (safe while the site is running — a
            # plain file copy of a WAL-mode DB can silently miss the newest
            # transactions). Restore: stop the service, drop this file into
            # data/ as bazarche.db, remove -wal/-shm, start the service.
            import sqlite3 as _sqlite3
            import tempfile as _tempfile
            import datetime as _dt
            tmpf = _tempfile.NamedTemporaryFile(suffix=".db", delete=False)
            tmpf.close()
            try:
                src = _sqlite3.connect(db.DB_PATH, timeout=15)
                dst = _sqlite3.connect(tmpf.name)
                try:
                    src.backup(dst)
                finally:
                    dst.close()
                    src.close()
                chk = _sqlite3.connect(f"file:{tmpf.name}?mode=ro", uri=True)
                try:
                    good = chk.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
                finally:
                    chk.close()
                if not good:
                    raise RuntimeError("integrity_check failed")
                with open(tmpf.name, "rb") as f:
                    raw = f.read()
            finally:
                try:
                    os.unlink(tmpf.name)
                except OSError:
                    pass
            db.set_setting("last_backup_at", time.strftime("%Y-%m-%d %H:%M"))
            stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M")
            return self.send(raw, 200, "application/x-sqlite3",
                             {"Content-Disposition":
                              f'attachment; filename="bazarche-db-{stamp}.db"'})
        if path == "/panel/media":
            return self.send(P2.media_page(s, tok, q))
        return self.send(V.not_found(s, tok), 404)

    # -------------------------------------------------------------- POST
    def do_POST(self):
        try:
            sh = shield.check(self)          # v112 abuse shield
            if sh:
                self.send(f"<h1>{sh[1]}</h1>", sh[0])
                return
            pagecache.clear()   # v117/کارایی: هر نوشتن، صفحات کش‌شده را تازه می‌کند
            self.route_post()
        except BrokenPipeError:
            pass
        except Exception as e:
            import traceback; traceback.print_exc()
            self.send(f"<h1>خطای داخلی سرور</h1><p>خطایی رخ داد. لطفاً کمی بعد دوبارم تلاش کنید.</p>", 500)
        finally:
            ui.clear_context()
            db.request_done()   # v109: never idle-hold SQLite's writer lock

    def read_form(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0 or n > MAX_BODY:
            return {}
        # v276 G19: pure-text forms never need 4MB — cap waste before parse
        if n > 65536 and "multipart/" not in (self.headers.get("Content-Type") or ""):
            antispam.event(self.client_key(), "form", "deny", "bodycap")
            self.send("متن فرم بزرگ است؛ درگاه: bodycap", 413,
                      "text/plain; charset=utf-8")
            return {"__drop__": ["1"]}
        raw = self.rfile.read(n).decode("utf-8", "replace")
        return urllib.parse.parse_qs(raw, keep_blank_values=True)

    def read_multipart(self, max_body=None):
        n = int(self.headers.get("Content-Length") or 0)
        cap = max_body or uploads.MAX_BODY
        if n <= 0 or n > cap:
            return {}, []
        raw = self.rfile.read(n)
        return uploads.parse_multipart(raw, self.headers.get("Content-Type", ""))

    def read_json(self, max_bytes=262144):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return None
        if n <= 0 or n > max_bytes:
            return None
        try:
            value = json.loads(self.rfile.read(n).decode("utf-8", "strict"))
            return value if isinstance(value, dict) else None
        except (ValueError, UnicodeError):
            return None

    def same_origin_post(self, path):
        """v289 CSRF gate for every state-changing request.

        Messenger webhooks are exempt: they are legitimately cross-origin and
        authenticate with the 32+ char URL secret compared by compare_digest,
        plus their own rate limit and replay claim.
        """
        if WEBHOOK_RX.match(path):
            return True
        sfs = (self.headers.get("Sec-Fetch-Site") or "").strip().lower()
        if sfs in ("same-origin", "same-site", "none", ""):
            return True
        if sfs != "cross-site":
            return True                      # unknown value: don't lock users out
        # cross-site: only tolerated when the browser itself vouches for a
        # same-host Origin (some privacy proxies rewrite Sec-Fetch-Site)
        host = _origin_host(self.headers.get("Origin")) or \
            _origin_host(self.headers.get("Referer"))
        mine = _origin_host(self.headers.get("Host"))
        return bool(host) and bool(mine) and host == mine

    def route_post(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        if not self.same_origin_post(path):
            antispam.event(self.client_key(), "csrf", "deny", "cross-site")
            return self.send(CROSS_SITE_FA, 403, "text/plain; charset=utf-8")
        s = db.get_settings()
        tok = db.owner_token()
        # v293 لایهٔ اول: در حالت نشانی مخفی، هیچ فرم پنل بدون نشست معتبر
        # پذیرفته نمی‌شود — حتی فرم رمز؛ غریبه‌ها اصلاً نمی‌دانند پنلی هست.
        _hidden = self._panel_hidden_path(s)
        # v297 (FINDINGS: the hidden path was unusable): do_GET rewrites
        # /<hidden>/… -> /panel/… but route_post never did, so the login form
        # on the hidden address posted to a path no POST handler recognised.
        # With the gate armed there was no way to log in at all — every POST
        # fell through to the 403 gate and /panel/login itself was 404'd.
        # Rewrite first, exactly like the GET path does, then apply the guard.
        _hidden_hit = bool(_hidden) and (
            path == "/" + _hidden or path.startswith("/" + _hidden + "/"))
        if _hidden_hit:
            path = "/panel" + path[len("/" + _hidden):]
        # The login form is the one POST a not-yet-authenticated admin must be
        # able to submit; everything else stays invisible.
        # v299 fix: hidden gate only for /panel paths — public /login/email must work when hidden is armed
        _is_panel = path == "/panel" or path.startswith("/panel/")
        _is_login = path in ("/panel/login", "/panel/logout")
        if _hidden and _is_panel and not _hidden_hit and not _is_login \
                and not db.admin_session_ok(self.cookies().get(self.ADMIN_COOKIE)):
            return self.send(V.not_found(s), 404)
        if _hidden and _is_panel and _hidden_hit and not _is_login \
                and not db.admin_session_ok(self.cookies().get(self.ADMIN_COOKIE)):
            return self.send(V.not_found(s), 404)
        # v117/M1: the admin token never enters the ui context — panel
        # chrome authenticates by cookie and renders keyless links.
        self.prime_context(path, "")
        # v284 (دستور مدیر): «روش دوم» — کلید یک‌بارمصرف ورود وقتی رفت‌وبرگشت
        # پیام‌رسان کامل نشد. صدور فقط با کوکی همان چالش + سقف نرخ؛ کلید فقط
        # هش ذخیره می‌شود و در لاگ نمی‌آید.
        if path == "/api/login-key":
            body = self.read_json() or {}
            cid = str(body.get("id") or "")[:80]
            if not db.rate_ok("lkey:" + self.client_key(), limit=3,
                              window=600, always=True):
                return self.json_out({"ok": False, "error": "rate"}, 429)
            plat_cookie = ""
            for pf in ("bale", "soroush"):
                if self.cookies().get("bzv2_" + pf):
                    plat_cookie = pf
                    break
            ch = db.messenger_challenge_status(
                cid, self.cookies().get("bzv2_" + (plat_cookie or "bale"), ""))
            if not ch or ch.get("purpose") != "login" or ch.get("approved_id"):
                return self.json_out({"ok": False, "error": "expired"}, 404)
            platform = ch.get("platform") or "bale"
            key = db.messenger_login_key_new(ch["id"], platform)
            if platform == "soroush":
                import soroush as _SR
                link = _SR.app_link() or _SR.bot_link()
            else:
                import bale as _BL
                link = _BL.bot_link()
            return self.send(json.dumps({"ok": True, "key": key, "link": link,
                                         "platform": platform, "ttl": 300},
                                        ensure_ascii=False),
                             200, "application/json; charset=utf-8",
                             headers={"Cache-Control": "no-store"})

        # ---- v233 admin bot webhook: same shape as the v185 public hook but a
        # separate bot/token/secret. Owner-only; privileged actions queue to root.
        am = re.fullmatch(r"/api/bale-admin/webhook/([A-Za-z0-9_-]{32,100})", path)
        if am:
            expected = adminbot.webhook_secret()
            if not expected or not secrets.compare_digest(am.group(1), expected):
                # v277: secret غلط = تخلف قطعی؛ پلهٔ تنبیه IP را موقتاً بلاک می‌کند
                antispam.strike(self.client_key(), "webhook", "secret")
                return self.send("not found", 404, "text/plain; charset=utf-8")
            if not db.rate_ok("bale-admin-hook:" + self.client_key(), limit=180,
                              window=60, always=True):
                return self.json_out({"ok": False}, 429)
            update = self.read_json()
            if update is None:
                return self.json_out({"ok": False}, 400)
            update_id = update.get("update_id")
            if update_id is None or not str(update_id).isdigit():
                return self.json_out({"ok": False}, 400)
            if not db.messenger_update_claim("bale-admin", update_id):
                return self.json_out({"ok": True, "duplicate": True})
            adminbot.handle_update(update)
            return self.json_out({"ok": True})

        # ---- v185 Bale webhook: unguessable URL segment + HTTPS at nginx.
        # Never accept a token in form/query and never serialize the bot secret.
        m = re.fullmatch(r"/api/bale/webhook/([A-Za-z0-9_-]{32,100})", path)
        if m:
            expected = bale.webhook_secret()
            if not expected or not secrets.compare_digest(m.group(1), expected):
                # v277: secret غلط = تخلف قطعی؛ پلهٔ تنبیه IP را موقتاً بلاک می‌کند
                antispam.strike(self.client_key(), "webhook", "secret")
                return self.send("not found", 404, "text/plain; charset=utf-8")
            if not db.rate_ok("bale-hook:" + self.client_key(), limit=180,
                              window=60, always=True):
                return self.json_out({"ok": False}, 429)
            update = self.read_json()
            if update is None:
                return self.json_out({"ok": False}, 400)
            update_id = update.get("update_id")
            if update_id is None or not str(update_id).isdigit():
                return self.json_out({"ok": False}, 400)
            if not db.messenger_update_claim("bale", update_id):
                # Acknowledge but never execute the duplicate, avoiding an
                # endless platform retry loop while preserving idempotency.
                return self.json_out({"ok": True, "duplicate": True})
            msg = update.get("message") if isinstance(update.get("message"), dict) else None
            cb = update.get("callback_query") if isinstance(update.get("callback_query"), dict) else None
            if msg:
                text = str(msg.get("text") or "").strip()
                sender = msg.get("from") or {}
                chat = msg.get("chat") or {}
                contact = msg.get("contact") if isinstance(msg.get("contact"), dict) else None
                uid, chat_id = sender.get("id"), chat.get("id")
                private = chat.get("type") == "private"
                mm = re.match(r"^/start(?:@\w+)?\s+((?:login|link)_[A-Za-z0-9_-]{20,60})$", text)
                if contact and uid is not None and chat_id is not None and private:
                    # Bale sets contact.user_id only for the sender's own
                    # request_contact button; forwarded/typed numbers fail.
                    if str(contact.get("user_id")) != str(uid):
                        bale.remove_keyboard(chat_id,
                            "فقط شمارهٔ تأییدشدهٔ خودتان پذیرفته می‌شود.")
                    else:
                        red = db.messenger_login_key_redeem_contact(
                            "bale", uid, chat_id, contact.get("phone_number") or "")
                        if red is not None:
                            bale.remove_keyboard(chat_id, red[1])
                        else:
                            ok, note, approval_token = db.messenger_signup_prepare(
                                uid, chat_id, contact.get("phone_number") or "")
                            if not ok and db.messenger_login_key_stash_contact(
                                    "bale", uid, chat_id,
                                    contact.get("phone_number") or ""):
                                note = ("📞 شمارهٔ شما ثبت شد.\n"
                                        "حالا کلید یک‌بارمصرف سایت را همین‌جا بفرستید.")
                            bale.remove_keyboard(chat_id, note)
                            if ok:
                                bale.send_signup_approval(chat_id, approval_token)
                elif mm and uid is not None and chat_id is not None and private:
                    purpose, request_token = mm.group(1).split("_", 1)
                    ch = db.messenger_challenge_by_request(request_token)
                    if not ch or ch.get("purpose") != purpose:
                        bale.send_message(chat_id, "این درخواست منقضی شده است؛ از سایت دوباره شروع کنید.")
                    elif purpose == "login" and not db.messenger_account_by_platform("bale", uid):
                        if db.messenger_signup_bind(request_token, uid, chat_id):
                            bale.request_signup_contact(chat_id)
                        else:
                            bale.send_message(chat_id, "درخواست منقضی شده؛ دوباره از سایت شروع کنید.")
                    else:
                        bale.send_approval(chat_id, request_token, purpose)
                elif (uid is not None and chat_id is not None and private
                      and re.fullmatch(r"[A-Za-z0-9_-]{16,24}", text or "")
                      and db.messenger_login_key_lookup(text)):
                    ok, note, needc = db.messenger_login_key_claim(
                        text, "bale", uid, chat_id)
                    if needc:
                        bale.send_message(chat_id, note)
                        bale.request_signup_contact(chat_id)
                    elif note:
                        bale.send_message(chat_id, note)
                elif uid is not None and chat_id is not None and private:
                    photos = msg.get("photo") if isinstance(msg.get("photo"), list) else []
                    file_id = (photos[-1].get("file_id") if photos and isinstance(photos[-1], dict) else None)
                    loc = msg.get("location") if isinstance(msg.get("location"), dict) else None
                    if loc:
                        # v212: «نزدیک من» — location is used once and never stored.
                        bot_menu.handle_location("bale", uid, chat_id, loc.get("latitude"),
                                                 loc.get("longitude"), bale.send_message)
                    elif file_id and bot_menu.handle_photo("bale", uid, chat_id,
                                                         lambda fid=file_id: bale.download_file(fid),
                                                         bale.send_message):
                        pass
                    elif not bot_menu.handle_message("bale", uid, chat_id, text, bale.send_message):
                        bot_menu.send_menu("bale", uid, chat_id, bale.send_message)
            elif cb:
                data = str(cb.get("data") or "")
                sender = cb.get("from") or {}
                message = cb.get("message") or {}
                chat = message.get("chat") or {}
                uid, chat_id = sender.get("id"), chat.get("id")
                callback_id = cb.get("id")
                private = chat.get("type") == "private"
                signup = re.fullmatch(r"bz186:(signup|cancel):([A-Za-z0-9_-]{20,60})", data)
                mm = re.fullmatch(r"bz185:(login|link|cancel):([A-Za-z0-9_-]{20,60})", data)
                if signup and uid is not None and chat_id is not None and private:
                    action, approval_token = signup.groups()
                    if action == "cancel":
                        db.messenger_challenge_cancel(approval_token, approval=True)
                        ok, note = True, "درخواست لغو شد."
                    else:
                        ok, note = db.messenger_signup_approve(
                            approval_token, uid, chat_id)
                    if callback_id:
                        bale.answer_callback(callback_id, note, alert=not ok)
                    if ok:
                        bale.send_message(chat_id, note)
                elif mm and uid is not None and chat_id is not None and private:
                    action, request_token = mm.groups()
                    if action == "cancel":
                        db.messenger_challenge_cancel(request_token)
                        ok, note = True, "درخواست لغو شد."
                    else:
                        ch = db.messenger_challenge_by_request(request_token)
                        if not ch or ch.get("purpose") != action:
                            ok, note = False, "درخواست منقضی یا نامعتبر است."
                        else:
                            ok, note = db.messenger_challenge_approve(
                                request_token, uid, chat_id)
                    if callback_id:
                        bale.answer_callback(callback_id, note, alert=not ok)
                    if ok:
                        bale.send_message(chat_id, note)
                elif uid is not None and chat_id is not None and private and data.startswith(bot_menu.CALLBACK_PREFIX):
                    if callback_id:
                        bale.answer_callback(callback_id, "انجام شد")
                    cb_msg = cb.get("message") if isinstance(cb.get("message"), dict) else {}
                    bot_menu.handle_callback("bale", uid, chat_id, data, bale.send_message,
                                             cb_msg.get("message_id"))
            return self.json_out({"ok": True})

        # v193: official Soroush Plus webhook. Webhook and getUpdates are
        # mutually exclusive on this platform; production uses only HTTPS push.
        sm = re.fullmatch(r"/api/soroush/webhook/([A-Za-z0-9_-]{32,100})", path)
        if sm:
            expected = soroush.webhook_secret()
            if not expected or not secrets.compare_digest(sm.group(1), expected):
                # v277: secret غلط = تخلف قطعی؛ پلهٔ تنبیه IP را موقتاً بلاک می‌کند
                antispam.strike(self.client_key(), "webhook", "secret")
                return self.send("not found", 404, "text/plain; charset=utf-8")
            if not db.rate_ok("soroush-hook:" + self.client_key(), limit=180,
                              window=60, always=True):
                return self.json_out({"ok":False}, 429)
            update = self.read_json()
            if update is None:
                return self.json_out({"ok":False}, 400)
            update_id = update.get("update_id")
            if update_id is None or not str(update_id).isdigit():
                return self.json_out({"ok":False}, 400)
            if not db.messenger_update_claim("soroush", update_id):
                return self.json_out({"ok":True,"duplicate":True})
            msg = update.get("message") if isinstance(update.get("message"),dict) else None
            cb = update.get("callback_query") if isinstance(update.get("callback_query"),dict) else None
            if msg:
                text=str(msg.get("text") or "").strip()
                sender=msg.get("from") if isinstance(msg.get("from"),dict) else {}
                chat=msg.get("chat") if isinstance(msg.get("chat"),dict) else {}
                contact=msg.get("contact") if isinstance(msg.get("contact"),dict) else None
                uid,chat_id=sender.get("id"),chat.get("id")
                private = chat.get("type") == "private"
                mm=re.fullmatch(r"(?:/start(?:@\w+)?\s+)?((?:login|link)_[A-Za-z0-9_-]{20,60})",text)
                if contact and uid is not None and chat_id is not None and private:
                    # request_contact is accepted only when Soroush identifies
                    # the contact as the same user who sent this private message.
                    if contact.get("user_id") is None or str(contact.get("user_id")) != str(uid):
                        soroush.remove_keyboard(chat_id,"فقط شمارهٔ رسمی همین حساب سروش‌پلاس پذیرفته می‌شود.")
                    else:
                        red=db.messenger_login_key_redeem_contact(
                            "soroush",uid,chat_id,contact.get("phone_number") or "")
                        if red is not None:
                            soroush.remove_keyboard(chat_id,red[1])
                        else:
                            ok,note,approval=db.messenger_signup_prepare(
                                uid,chat_id,contact.get("phone_number") or "","soroush")
                            if not ok and db.messenger_login_key_stash_contact(
                                    "soroush",uid,chat_id,
                                    contact.get("phone_number") or ""):
                                note=("📞 شمارهٔ شما ثبت شد.\n"
                                      "حالا کلید یک‌بارمصرف سایت را همین‌جا بفرستید.")
                            soroush.remove_keyboard(chat_id,note)
                            if ok:soroush.send_signup_approval(chat_id,approval)
                elif mm and uid is not None and chat_id is not None and private:
                    purpose,request_token=mm.group(1).split("_",1)
                    ch=db.messenger_challenge_by_request(request_token)
                    if not ch or ch.get("purpose") != purpose or ch.get("platform") != "soroush":
                        soroush.send_message(chat_id,"درخواست منقضی یا نامعتبر است؛ دوباره از سایت شروع کنید.")
                    elif purpose == "login" and not db.messenger_account_by_platform("soroush",uid):
                        if db.messenger_signup_bind(request_token,uid,chat_id,"soroush"):
                            soroush.request_signup_contact(chat_id)
                    else:
                        soroush.send_approval(chat_id,request_token,purpose)
                elif (uid is not None and chat_id is not None and private
                      and re.fullmatch(r"[A-Za-z0-9_-]{16,24}",text or "")
                      and db.messenger_login_key_lookup(text)):
                    ok,note,needc=db.messenger_login_key_claim(
                        text,"soroush",uid,chat_id)
                    if needc:
                        soroush.send_message(chat_id,note)
                        soroush.request_signup_contact(chat_id)
                    elif note:
                        soroush.send_message(chat_id,note)
                elif uid is not None and chat_id is not None and private:
                    photos=msg.get("photo") if isinstance(msg.get("photo"),list) else []
                    file_id=(photos[-1].get("file_id") if photos and isinstance(photos[-1],dict) else None)
                    loc=msg.get("location") if isinstance(msg.get("location"),dict) else None
                    if loc:
                        bot_menu.handle_location("soroush",uid,chat_id,loc.get("latitude"),
                                                 loc.get("longitude"),soroush.send_message)
                    elif file_id and bot_menu.handle_photo("soroush",uid,chat_id,
                                                         lambda fid=file_id: soroush.download_file(fid),
                                                         soroush.send_message):
                        pass
                    elif not bot_menu.handle_message("soroush", uid, chat_id, text, soroush.send_message):
                        bot_menu.send_menu("soroush", uid, chat_id, soroush.send_message)
            elif cb:
                data=str(cb.get("data") or "")
                sender=cb.get("from") if isinstance(cb.get("from"),dict) else {}
                message=cb.get("message") if isinstance(cb.get("message"),dict) else {}
                chat=message.get("chat") if isinstance(message.get("chat"),dict) else {}
                uid,chat_id,callback_id=sender.get("id"),chat.get("id"),cb.get("id")
                private = chat.get("type") == "private"
                signup=re.fullmatch(r"sp193:(signup|signup_cancel):([A-Za-z0-9_-]{20,60})",data)
                action=re.fullmatch(r"sp193:(login|link|cancel):([A-Za-z0-9_-]{20,60})",data)
                if signup and uid is not None and chat_id is not None and private:
                    kind,value=signup.groups()
                    if kind == "signup_cancel":
                        db.messenger_challenge_cancel(value,approval=True);ok,note=True,"درخواست لغو شد."
                    else:
                        ok,note=db.messenger_signup_approve(value,uid,chat_id,"soroush")
                    if callback_id:soroush.answer_callback(callback_id,note,alert=not ok)
                    if ok:soroush.send_message(chat_id,note)
                elif action and uid is not None and chat_id is not None and private:
                    kind,value=action.groups()
                    if kind == "cancel":
                        db.messenger_challenge_cancel(value);ok,note=True,"درخواست لغو شد."
                    else:
                        ch=db.messenger_challenge_by_request(value)
                        if not ch or ch.get("purpose") != kind or ch.get("platform") != "soroush":
                            ok,note=False,"درخواست منقضی یا نامعتبر است."
                        else:
                            ok,note=db.messenger_challenge_approve(value,uid,chat_id)
                    if callback_id:soroush.answer_callback(callback_id,note,alert=not ok)
                    if ok:soroush.send_message(chat_id,note)
                elif uid is not None and chat_id is not None and private and data.startswith(bot_menu.CALLBACK_PREFIX):
                    if callback_id:soroush.answer_callback(callback_id,"انجام شد")
                    bot_menu.handle_callback("soroush",uid,chat_id,data,soroush.send_message,message.get("message_id"))
            return self.json_out({"ok":True})

        # ---- analytics beacon (no body, fire and forget)
        m = re.match(r"^/t/([^/]+)/(view|phone|whatsapp|route|share|catalog|save|instagram|telegram|eitaa|bale|soroush|rubika|website)$", path)
        if m:
            b = db.business(slug=m.group(1))
            if b:
                db.track(b["id"], m.group(2))
            return self.send(b"", 204, "text/plain")

        # ---- v100: record one anonymous story view (no identity stored, only a
        #      timestamp). Plain POST (not multipart) so it lives in route_post.
        m = re.match(r"^/api/stories/(\d+)/view$", path)
        if m:
            sid = safe_int(m.group(1))
            if db._one("SELECT 1 FROM stories WHERE id=?", (sid,)):
                db.story_view_add(sid, analytics.ensure_cid(self))
                analytics.track_story(self, sid)   # v114: full identity
            return self.json_out({"ok": True})

        # v316: arena removed — all these routes now 404 per owner request
        if path in ("/api/agent/fix-vpn", "/api/agent/diag", "/api/agent/arena/cookie", "/api/agent/arena/bridge",
                    "/api/agent/arena", "/agent/arena", "/api/agent/fetch", "/api/agent/browser/open"):
            return self.send("این بخش حذف شد", 404, "text/plain; charset=utf-8")


        # ---- v302 file upload (multipart is handled in route_multipart, but also allow JSON fallback)
        if path in ("/api/agent/upload", "/agent/upload"):
            if not (self._agent_ok() or self.current_owner() or self.admin_ok({})):
                return self.json_out({"ok": False, "error": "auth required"}, 403)
            # this path should be multipart, so delegate to multipart handler if needed
            ctype = self.headers.get("Content-Type", "")
            if not ctype.startswith("multipart/form-data"):
                return self.json_out({"ok": False, "error": "use multipart form-data"}, 400)
            # let route_multipart handle it (will be called later, but we are before it — so handle here)
            # we will not reach here for multipart because route_multipart is after, so return to let it flow
            pass

        # ---- v301: agent chat — same-origin JSON, email+key gate, model switching, fully tested (offline/fast/smart/auto)
        if path in ("/api/agent/models",):
            if not (self._agent_ok() or self.current_owner() or self.admin_ok(
                    urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query))):
                return self.json_out({"ok": False, "error": "agent key required"}, 403)
            try:
                import assistant as _AST
                ids = list(_AST.BYNARA_MODELS)
                models = [{"id": m, "name": m, "free": True} for m in ids]
                cur = ""
                try:
                    cur = ((db.get_settings().get("ai_brain_bynara_model") or "")
                           .strip() or ids[0])
                except Exception:
                    cur = ids[0]
                return self.json_out({
                    "ok": True, "n": len(models), "featured": ids,
                    "models": models, "current": cur,
                    "has_key": bool((_AST._env("AI_BRAIN_BYNARA_KEY")
                                     or _AST._env("AI_SITE_API_KEY"))),
                    "default": ids[0],
                    "provider": "bynara",
                    "site_model": _AST.site_config().get("model") or "",
                })
            except Exception as e:
                return self.json_out({"ok": False, "error": str(e)[:200]}, 500)

        if path in ("/api/agent/model-test",):
            if not (self._agent_ok() or self.current_owner() or self.admin_ok(
                    urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query))):
                return self.json_out({"ok": False, "error": "agent key required"}, 403)
            body = self.read_json(max_bytes=4096) if self.command == "POST" else {}
            if not isinstance(body, dict):
                body = {}
            mid = str(body.get("model") or "")[:120].strip()
            try:
                import assistant as _AST
                res = _AST.test_free_model(mid)
                if res.get("ok"):
                    try:
                        db.set_settings({"ai_brain_active": "bynara",
                                         "ai_brain_bynara_model": mid,
                                         "ai_site_model": mid})
                    except Exception:
                        pass
                return self.json_out({"ok": bool(res.get("ok")), **res})
            except Exception as e:
                return self.json_out({"ok": False, "error": str(e)[:200]}, 500)

        if path in ("/api/agent/chat", "/api/agent/chat2", "/agent/chat"):
            if (self.headers.get("Sec-Fetch-Site") or "same-origin") not in ("same-origin", "none", ""):
                # allow curl without header too
                pass
            # v309: owner/admin session; v319: ?key= پنل هم برای JSON چت
            _q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if not (self._agent_ok() or self.current_owner() or self.admin_ok(_q)):
                return self.json_out({"ok": False, "error": "agent key required"}, 403)
            if self.token_ok(_q) and not db.owner_pass_set():
                try:
                    self.set_cookie(self.ADMIN_COOKIE, db.admin_session_new())
                except Exception:
                    pass
            if not db.rate_ok("agent-chat:" + self.client_key(), limit=60, window=60, always=True):
                return self.json_out({"ok": False, "error": "rate", "text": "درخواست‌ها زیاد است."}, 429)
            body = self.read_json(max_bytes=16384)
            if not isinstance(body, dict):
                # also try form if not JSON (fallback)
                body = {}
            text = str(body.get("text") or body.get("message") or "")[:4000]
            model_sel = str(body.get("model") or body.get("mode") or "auto")[:120].strip()
            if not text:
                return self.json_out({"ok": False, "error": "empty"}, 400)
            # v337/v338: panel-entry and session commands are available
            # directly inside the management agent panel too. This stays
            # server-driven (no model guesses, no raw owner_token exposure).
            _login_ask = text.replace("\u200c", "")
            try:
                import adminbot as _AB_DIRECT
                if any(x in _login_ask for x in ("وضعیت ورود", "ورودها", "نشست پنل", "نشستها", "نشست‌ها")):
                    reply = _AB_DIRECT.panel_login_status_text()
                    return self.json_out({"ok": True, "reply": reply, "text": reply,
                                          "model": "server", "source": "panel_login_status"})
                if any(x in _login_ask for x in ("خروج همه", "بستن نشست", "بستن دسترسی", "لغو همه نشست")):
                    if any(x in _login_ask for x in ("تأیید", "تایید", "بله")):
                        reply = _AB_DIRECT.revoke_panel_access_text()
                        return self.json_out({"ok": True, "reply": reply, "text": reply,
                                              "model": "server", "source": "panel_revoke"})
                    reply = "⚠️ این کار همهٔ نشست‌های پنل و کلیدهای ایجنت را می‌بندد. برای اجرا دقیقاً بنویس: تأیید خروج همه"
                    return self.json_out({"ok": True, "reply": reply, "text": reply,
                                          "model": "server", "source": "panel_revoke_confirm"})
                if any(x in _login_ask for x in ("ورود پنل", "پنل ورود", "کلید ورود", "رمز پنل", "کلید پنل")):
                    reply, _mk = _AB_DIRECT._do_login_keys()
                    return self.json_out({"ok": True, "reply": reply, "text": reply,
                                          "model": "server", "source": "panel_login"})
            except Exception as e:
                return self.json_out({"ok": False, "error": str(e)[:200]}, 500)
            try:
                import assistant as _AST
                import adminbot as _AB
                c = self.current_customer(); o = self.current_owner()
                ctx = {"channel": "web", "user_key": self._assistant_key(c, o), "customer": c, "owner": o, "agent_unlimited": True, "mode": ("offline" if model_sel=="offline" else "auto")}
                if model_sel == "offline":
                    res = _AST.answer(text, ctx, [])
                    return self.json_out({"ok": True, "reply": res.get("text") or "—", "text": res.get("text") or "—", "model": "offline", "source": res.get("source","rule")})
                # full admin agent with live snapshot
                try:
                    snap = _AB.admin_snapshot()
                except Exception:
                    snap = ""
                try:
                    mem = []
                    tkey = _AST.thread_key(ctx)
                    if tkey:
                        th = _AST.thread_get(tkey) or []
                        mem = [{"q": x[0], "a": x[1]} for x in th[-2:]] if th and isinstance(th[0], (list,tuple)) else []
                except Exception:
                    mem = []
                # v310: مغزِ همین پیام (چیپ کنسول) — اوراید thread-local، بدون
                # تغییر مغز سراسری؛ بدون کلید = همان مرگ صادقانهٔ همیشگی.
                _agent_apply_model(model_sel)
                try:
                    if model_sel in getattr(_AST, "BYNARA_MODELS", ()):
                        try:
                            db.set_settings({"ai_brain_active": "bynara",
                                             "ai_brain_bynara_model": model_sel,
                                             "ai_site_model": model_sel})
                        except Exception:
                            pass
                    out_text, src, tool = _AST.admin_agent(text, snap, mem, max_steps=6)
                    _brain_used = _AST.active_brain() if not _AST.brain_override() else _AST.brain_override()
                    _model_used = (_AST.model_override()
                                   or (_AST.config() or {}).get("model")
                                   or model_sel)
                finally:
                    _AST.clear_brain_override()
                try:
                    tkey = _AST.thread_key(ctx)
                    if tkey:
                        _AST.thread_append(tkey, text, out_text)
                except Exception:
                    pass
                payload = {"ok": True, "reply": out_text, "text": out_text, "model": model_sel or "auto", "brain": _brain_used, "source": src}
                if tool:
                    payload["tool"] = tool
                return self.json_out(payload)
            except Exception as e:
                import traceback as _tb
                err = str(e)[:500] + " | " + _tb.format_exc()[:500]
                return self.json_out({"ok": False, "error": err[:800]}, 500)

        # ---- v213: «دستیار هوشمند» — same-origin JSON; the model never acts.
        if path == "/api/assistant/chat":
            if (self.headers.get("Sec-Fetch-Site") or "same-origin") not in ("same-origin", "none"):
                return self.json_out({"ok": False, "error": "origin"}, 403)
            if not db.rate_ok("ai:" + self.client_key(), limit=20, window=60, always=True):
                return self.json_out({"ok": False, "error": "rate",
                                      "text": "درخواست‌ها زیاد است؛ یک دقیقه بعد دوباره بپرسید."}, 429)
            body = self.read_json(max_bytes=16384)
            if not isinstance(body, dict):
                return self.json_out({"ok": False, "error": "bad_json"}, 400)
            text = str(body.get("text") or "")[:400]
            hist = body.get("history") if isinstance(body.get("history"), list) else []
            hist = [h for h in hist if isinstance(h, dict)][-6:]
            c = self.current_customer(); o = self.current_owner()
            ctx = {"channel": "web", "user_key": self._assistant_key(c, o), "customer": c, "owner": o,
                   "agent_unlimited": self._agent_ok()}
            # v274 (دستور مدیر): سوئیچ بالای صفحهٔ چت بین «هوش آفلاین (نامحدود)»
            # و «هوش اختصاصی دست گیر» — فقط دو مقدار معتبر، هر چیز دیگر auto.
            _mode = str(body.get("mode") or "").strip()
            if _mode in ("offline", "auto"):
                ctx["mode"] = _mode
            try:   # v222: optional coords for precise «near me» (never stored)
                ctx["lat"], ctx["lon"] = float(body.get("lat")), float(body.get("lon"))
            except (TypeError, ValueError):
                pass
            res = assistant.answer(text, ctx, hist)
            res["links"] = [{"label": a, "href": b} for a, b in (res.get("links") or [])]
            code = 200 if (res.get("ok") or res.get("error") in ("quota", "cap", "empty")) else 503
            return self.json_out(res, code)

        # ---- multipart endpoints (image uploads) handle their own body
        ctype = self.headers.get("Content-Type", "")
        if ctype.startswith("multipart/form-data"):
            return self.route_multipart(path, s, tok)

        form = self.read_form()
        if form.get("__drop__"):      # v276 G19: bodycap already answered 413
            return
        clip_form(form)

        # v186: customer/shopkeeper authentication is messenger-only. Keep the old
        # implementation for data compatibility, but expose no OTP/password
        # endpoint that could silently revive the SMS panel.
        if path in ("/login", "/login/verify", "/login/password",
                    "/me/login", "/me/login/verify", "/me/login/password",
                    "/me/account", "/my/account"):
            return self.send("not found", 404, "text/plain; charset=utf-8")

        # ---------------- v69: legacy customer login aliases (unreachable v186)
        if path == "/me/login":
            return self._unified_issue(s, form)

        if path == "/prices/alert":      # v68: torob-style price-drop alert
            if self.spam_gate("pricealert"):
                return
            if s.get("prices_enabled") != "1":
                return self.send(V.not_found(s), 404)
            cust = self.current_customer()
            if not cust:
                return self.redirect("/me/login")
            key = form_get(form, "key")
            if key:
                db.alert_set(cust["id"], key, form_get(form, "title"),
                             on=form_get(form, "on") == "1")
            return self.redirect("/prices?key=" + urllib.parse.quote(key))

        if path == "/me/login/verify":
            return self._unified_verify(s, form)

        # ---- v69 legacy alias
        # v77: بلاک مردهٔ «if False:» حذف شد — _unified_password خودش مسیر
        # بازگشت (next) را مدیریت می‌کند و این کد هرگز اجرا نمی‌شد.
        if path == "/me/login/password":
            return self._unified_password(s, form)

        if path == "/me/logout":
            db.customer_session_kill(self.cookies().get(self.CUSTOMER_COOKIE, ""))
            self.set_cookie(self.CUSTOMER_COOKIE, "", days=0)
            db.session_kill(self.cookies().get(self.SESSION_COOKIE, ""))
            self.set_cookie(self.SESSION_COOKIE, "", days=0)
            return self.redirect("/")

        # v65: complete profile — name is required, family name optional.
        if path == "/me/profile":
            cust = self.current_customer()
            if not cust:
                return self.redirect("/me/login")
            name = form_get(form, "name").strip()
            family = form_get(form, "family").strip()
            if len(name) < 2:
                return self.send(CU.profile(s, cust, err="نام را درست وارد کنید (دست‌کم ۲ نویسه)."))
            db.customer_set_profile(cust["id"], name, family)
            nxt = form_get(form, "next")
            safe_nxt = _safe_next(nxt)
            if safe_nxt:
                return self.redirect(safe_nxt)
            return self.redirect("/me?ok=حساب شما کامل شد.")

        if path == "/me/name":
            cust = self.current_customer()
            if cust:
                db.customer_set_profile(cust["id"], form_get(form, "name"),
                                        form_get(form, "family"))
                return self.redirect("/me?ok=نام ذخیره شد.")
            return self.redirect("/me/login")

        # ---- account & security: username + password (v57)
        if path == "/me/account":
            cust = self.current_customer()
            if not cust:
                return self.redirect("/me/login")
            ok, msg = db.customer_set_credentials(cust["id"], form_get(form, "username"),
                                                  form_get(form, "password"))
            key = "ok" if ok else "err"
            return self.redirect(f"/me/account?{key}={urllib.parse.quote(msg)}")

        # ---- favourite / unfavourite a business (v74, server-synced)
        if path == "/api/favorite":
            cust = self.current_customer()
            if not cust:
                return self.json_out({"ok": False, "error": "login"}, 403)
            if self.spam_gate("fav", "c%d" % cust["id"]):
                return
            slug = form_get(form, "slug").strip()
            bid = safe_int(form_get(form, "biz_id"), 0)
            business = db.business(slug=slug) if slug else (db.business(bid=bid) if bid else None)
            if not business or business.get("status") != "published":
                return self.json_out({"ok": False, "error": "not_found"}, 404)
            on = db.fav_toggle(cust["id"], business["id"])
            return self.json_out({
                "ok": True, "on": on, "slug": business["slug"],
                "count": len(db.fav_list(cust["id"])),
                "slugs": db.fav_slugs(cust["id"]),
            })

        # ---- follow / unfollow a business (v32, Instagram-style)
        if path == "/api/follow":
            cust = self.current_customer()
            if not cust or s.get("follow_enabled") != "1":
                return self.json_out({"ok": False, "error": "login"}, 403)
            bid = safe_int(form_get(form, "biz_id"), 0)
            if not db.business(bid=bid):
                return self.json_out({"ok": False}, 404)
            if self.spam_gate("follow", "c%d" % cust["id"]):
                return
            on = db.follow_toggle(cust["id"], bid)
            return self.json_out({"ok": True, "on": on, "count": db.follow_count(bid)})

        # ---- v142: web-push subscription (Chrome/FCM only)
        if path == "/api/push/subscribe":
            if self.spam_gate("pushsub"):
                return
            role = form_get(form, "role", "").strip()
            uid = None
            if role == "cust":
                c = self.current_customer()
                uid = c["id"] if c else None
            elif role == "owner":
                o = self.current_owner()
                uid = o["id"] if o else None
            if not uid:
                return self.json_out({"ok": False, "error": "login"}, 403)
            try:
                sub = json.loads(form_get(form, "sub", "{}") or "{}")
            except Exception:
                return self.json_out({"ok": False, "error": "bad subscription"}, 400)
            if not isinstance(sub, dict):
                return self.json_out({"ok": False, "error": "bad subscription"}, 400)
            ok, msg = db.push_sub_save(role, uid, sub)
            if not ok:
                return self.json_out({"ok": False, "error": msg}, 400)
            return self.json_out({"ok": True})

        # ---- v142: web-push unsubscription
        if path == "/api/push/unsubscribe":
            if self.spam_gate("pushunsub"):
                return
            role = form_get(form, "role", "").strip()
            uid = None
            if role == "cust":
                c = self.current_customer()
                uid = c["id"] if c else None
            elif role == "owner":
                o = self.current_owner()
                uid = o["id"] if o else None
            if not uid:
                return self.json_out({"ok": False, "error": "login"}, 403)
            try:
                sub = json.loads(form_get(form, "sub", "{}") or "{}")
            except Exception:
                sub = {}
            db.push_sub_remove(role, uid, sub if isinstance(sub, dict) else {})
            return self.json_out({"ok": True})

        # ---- mark notifications read (v32)
        if path == "/me/notifications/read":
            cust = self.current_customer()
            if cust:
                db.notifications_mark_read(cust["id"])
            return self.redirect("/me/notifications")

        if path in ("/me/bale/unlink", "/me/soroush/unlink"):
            cust = self.current_customer()
            if not cust:
                return self.redirect("/login")
            platform = "soroush" if "soroush" in path else "bale"
            db.messenger_unlink(cust["id"], platform)
            label = "سروش‌پلاس" if platform == "soroush" else "بله"
            return self.redirect("/me/notif-settings?ok=" + urllib.parse.quote(
                "اتصال حساب " + label + " قطع شد."))

        # ---- v142: customer per-kind notification switches
        if path == "/me/notif-settings":
            cust = self.current_customer()
            if not cust:
                return self.redirect("/me/login")
            for k in notifmeta.CUST_META:
                on = checkbox(form, f"k_{k}")
                db.set_customer_pref(cust["id"], k, on)
            return self.redirect("/me/notif-settings?ok=" +
                                 urllib.parse.quote("تنظیم اعلان‌ها ذخیره شد."))

        # ---- helpful vote on a review (v32)
        if path == "/api/review-helpful":
            rid = safe_int(form_get(form, "id"), 0)
            if not rid or not db.rate_ok(f"rh:{self.client_key()}", limit=40):
                return self.json_out({"ok": False}, 429)
            # v171: نظر ناموجود — قبلاً «ok با ۰» برمی‌گشت.
            if not db._rows("SELECT id FROM reviews WHERE id=?", (rid,)):
                return self.json_out({"ok": False, "error": "not found"}, 404)
            # v176: one vote per visitor — signed-in by account id, guest by an
            # anonymised hash of the client key (+UA). A repeat returns the
            # current count with ok=true and never inflates the counter.
            cust = self.current_customer()
            if cust:
                voter = "c%d" % cust["id"]
            else:
                voter = "k" + hashlib.sha256(
                    (self.client_key() + "|" +
                     (self.headers.get("User-Agent") or "")).encode()
                ).hexdigest()[:16]
            n = db.review_helpful(rid, voter)
            return self.json_out({"ok": True, "helpful": n})

        # ---------------- orders (v28)
        if path == "/order/create":
            if s.get("orders_enabled") != "1":
                return self.redirect("/catalog")
            if s.get("prices_enabled") != "1":
                return self.redirect("/cart?err=" + urllib.parse.quote(
                    "قیمت‌ها فعلاً غیرفعال‌اند؛ ثبت سفارش آنلاین تا فعال‌شدن دوباره ممکن نیست."))
            if is_spambot(form):
                return self.redirect("/cart")
            if not db.rate_ok(f"ord:{self.client_key()}", limit=10, window=600):
                return self.redirect("/cart?err=" + urllib.parse.quote(
                    "تعداد سفارش‌ها زیاد است. کمی بعد دوباره تلاش کنید."))
            cust = self.current_customer()
            _bid = form_get(form, "biz_id")
            if not str(_bid).isdigit():
                return self.redirect("/cart?err=" + urllib.parse.quote("کسب‌وکار نامعتبر است."))
            biz_id = int(_bid)
            b = db.business(bid=biz_id)
            if not b:
                return self.redirect("/cart?err=" + urllib.parse.quote("کسب‌وکار نامعتبر است."))
            try:
                raw_items = json.loads(form_get(form, "items", "[]"))
            except Exception:
                raw_items = []
            # sanitize every field — crafted JSON must never raise or store junk
            items = []
            qty_capped = False
            for i in raw_items:
                if not isinstance(i, dict) or not i.get("title"):
                    continue
                _qty = clamp_int(i.get("qty"), 1, 99, 1)
                if _qty != safe_int(i.get("qty"), 1):
                    qty_capped = True
                items.append({
                    "item_id": safe_int(i.get("item_id"), 0) or None,
                    "title": str(i.get("title"))[:150],
                    "price": clamp_int(i.get("price"), 0, 10**9, 0),
                    "qty": _qty,
                })
            if not items:
                return self.redirect("/cart?err=" + urllib.parse.quote("سبد خرید خالی است."))
            # audit F-012: any row that references a REAL catalogue item of
            # this business is re-priced from the database — the cart's own
            # numbers are never trusted for catalogue rows.
            items = features.price_items_from_catalog(biz_id, items)
            name=form_get(form,"name").strip(); phone=form_get(form,"phone").strip()
            if len(name)<2:return self.redirect("/cart?err="+urllib.parse.quote("نام الزامی است."))
            if phone and not db.valid_phone(phone):return self.redirect("/cart?err="+urllib.parse.quote("شمارهٔ موبایل را درست وارد کنید یا خالی بگذارید."))
            oid = db.create_order(biz_id, cust["id"] if cust else None,
                                  name, phone, form_get(form, "address"), form_get(form, "note"), items,
                                  share_phone=checkbox(form,"share_phone") and bool(phone))
            # notify the customer their order was received
            if cust and s.get("notif_enabled") == "1":
                db.notify(cust["id"], "order",
                          f"سفارش #{oid} ثبت شد و به کسب‌وکار رسید.", f"/me/order/{oid}")
            if b.get("phone"):
                sms.notify(s, db.norm_phone(b["phone"]),
                           f"سفارش آنلاین جدید در {s.get('site_name')}")
            sms.notify_owner(s, f"سفارش آنلاین جدید برای «{b['name']}» "
                                f"({len(items)} قلم)")
            return self.redirect(f"/order/ok?id={oid}" + ("&cap=1" if qty_capped else ""))

        m=re.match(r"^/me/order/(\d+)/cancel$",path)
        if m:
            cust=self.current_customer()
            if not cust:return self.redirect("/login")
            result=db.request_order_cancel(safe_int(m.group(1)),cust["id"],form_get(form,"reason"))
            msg=("سفارش لغو شد." if result.get("result")=="cancelled" else
                 "درخواست لغو برای دکان‌دار ارسال شد." if result.get("result")=="requested" else "لغو ممکن نیست.")
            return self.redirect(f"/me/order/{m.group(1)}?"+("ok=" if result.get("ok") else "err=")+urllib.parse.quote(msg))

        # ---------------- chat (v28) — the customer sends from the messenger
        m = re.match(r"^/me/chat/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1), 0)
            thread = db.chat_thread(tid)
            if not thread:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            if not self.chat_role(thread, form, "customer"):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            if db.business_owner_phone(thread.get("biz_id")) == (self.current_customer() or {}).get("phone"):
                err = "شما مالک همین کسب‌وکارید؛ پیامی به خودتان ارسال نشد."
            elif not db.rate_ok(f"chat:customer:{self.client_key()}", limit=60, window=600):
                err = "تعداد پیام‌ها زیاد است. کمی بعد دوباره تلاش کنید."
            else:
                _mid, err = self.store_chat_message(
                    thread, "customer", form_get(form, "body"), [], s)
            if err:
                return self.redirect(f"/me/chat/{tid}?err=" + urllib.parse.quote(err))
            return self.redirect(f"/me/chat/{tid}?ok=" + urllib.parse.quote("پیام ارسال شد."))

        # ---- v156: درخواست موجودی از دل گفتگوی مشتری
        m = re.match(r"^/me/chat/(\d+)/notify-me$", path)
        if m:
            if self.spam_gate("notifyme"):
                return
            cust = self.current_customer()
            if not cust:
                return self.redirect("/me/login")
            tid = safe_int(m.group(1))
            th = db.chat_thread(tid)
            if not th or th.get("customer_id") != cust["id"]:
                return self.redirect("/me/chats")
            # v177: فرم سریع — کالا (چیپ)، تعداد، یادداشت
            _iid = safe_int(form_get(form, "item_id", "0")) or None
            if _iid:
                _it0 = db.item(_iid)
                if not _it0 or _it0["biz_id"] != th["biz_id"]:
                    _iid = None
            okk, msg = db.stock_request_add(th["biz_id"], _iid, cust["id"],
                                            source="chat",
                                            qty=form_get(form, "qty", "1"),
                                            note=form_get(form, "note", ""))
            if okk:
                # کارت درخواست، داخل خود گفتگو برای دکاندار
                _what = "کالای ثبت‌نشده"
                if _iid:
                    _it = db.item(_iid)
                    if _it:
                        _what = _it["title"]
                try:
                    _qty = max(1, min(99, int(form_get(form, "qty", "1"))))
                except (TypeError, ValueError):
                    _qty = 1
                _lines = ["🔔 درخواست موجودی", f"کالا: {_what}",
                          f"تعداد: {ui.fa(_qty)}"]
                _note = (form_get(form, "note", "") or "").strip()[:140]
                if _note:
                    _lines.append(f"یادداشت: {_note}")
                self.store_chat_message(th, "customer", "\n".join(_lines), [], s)
            return self.redirect(f"/me/chat/{tid}?" +
                                 ("ok=" if okk else "err=") + urllib.parse.quote(msg))

        # ---- admin panel login (password) ----
        if path == "/panel/login":
            # Brute-force wall: the panel URL key already leaked publicly once,
            # so a password-guesser who holds the key must still be slowed to
            # a crawl. Cap attempts per client; a lockout message is returned
            # beyond the limit rather than a plain 403. (Security fix.)
            if not db.rate_ok(f"apl:{self.client_key()}", limit=10, window=900, always=True):
                return self.send(P.password_gate(s, err="تلاش‌های ورود زیاد است. ۱۵ دقیقه بعد دوباره امتحان کنید."), 429)
            pw = form_get(form, "password", "")
            nxt = form_get(form, "next", "")
            # v117/M1: the gate form never carried the key (it posts from a
            # key-protected page), so requiring token_ok(form) here made a
            # CORRECT password always fail — password login was dead in v116.
            # The password itself (PBKDF2-600k) + the 10/15min rate limit are
            # the proof; success mints the admin session.
            if db.owner_pass_set() and db.check_owner_pass(pw):
                # v337: owner requested the order be replaced: one command in
                # the Bale admin bot -> approve in Bale -> THEN enter the
                # already-set password. A correct password without a live
                # pre_password approval no longer opens the panel when the bot
                # confirmation layer is active.
                sess0 = self.cookies().get(self.ADMIN_COOKIE)
                if self._bale_confirm_needed(s):
                    if not (db.admin_session_ok(sess0)
                            and db.panel_approval_status(sess0) == "approved"
                            and db.panel_approval_purpose(sess0) == "pre_password"):
                        return self.send(P.password_gate(
                            s, err="اول در ربات مدیریت بله دستور «ورود پنل» را بفرستید، لینک یک‌بارمصرف را باز کنید و آنجا تأیید کنید؛ سپس همین رمز را وارد کنید."),
                            403, headers={"Cache-Control": "no-store"})
                    db.admin_session_unlock(sess0)
                    db.panel_approval_consume(sess0)
                    try:
                        adminbot.notify_panel_success(self.client_key(), "bale-confirm + password")
                        db.log("panel.login", "success via bale+password ip=%s" % self.client_key())
                    except Exception:
                        pass
                    dest = nxt if (nxt.startswith("/panel") and not nxt.startswith("//")) else "/panel"
                    return self.redirect(self._panel_url(s, dest))
                sess_new = db.admin_session_new()
                self.set_cookie(self.ADMIN_COOKIE, sess_new)
                try:
                    adminbot.notify_panel_success(self.client_key(), "password")
                    db.log("panel.login", "success via password ip=%s" % self.client_key())
                except Exception:
                    pass
                dest = nxt if (nxt.startswith("/panel") and not nxt.startswith("//")) \
                    else "/panel"
                # v297: with a hidden path armed, /panel itself answers 404 —
                # so a successful login redirected the admin straight into a
                # 404 and the console looked broken even though the password
                # was accepted. Route every post-login hop through the hidden
                # address instead.
                return self.redirect(self._panel_url(s, dest))
            return self.send(P.password_gate(s, err="رمز عبور درست نیست."), 403)

        if path == "/panel/logout":
            db.admin_session_kill(self.cookies().get(self.ADMIN_COOKIE))
            self.set_cookie(self.ADMIN_COOKIE, "", days=0)
            return self.redirect(self._panel_url(s, "/panel"))

        # ---- admin inline edit (site-wide edit mode) ----
        if path == "/panel/inline-edit":
            if not self.admin_ok(form):
                return self.json_out({"ok": False, "error": "دسترسی ندارید"}, 403)
            return self.json_out(self._inline_edit(form))

        # ---------------- public posts
        # ---------------- owner OTP login
        if path == "/login":
            return self._unified_issue(s, form)

        if path == "/login/verify":
            return self._unified_verify(s, form)

        if path == "/login/password":
            return self._unified_password(s, form)

        # v298: email login — like modern agent agent requires email
        if path == "/login/email":
            return self._email_issue(s, form)

        if path == "/login/email/verify":
            return self._email_verify(s, form)

        # ---------------- contact the shopkeeper (v65: no phone required)
        if path == "/subscribe":
            # v139: one handler serves BOTH bodies — urlencoded, and multipart
            # when the buyer attaches a bank receipt image.
            return self.subscribe_post(s, form)
        if path == "/contact":
            # v76: support is accountable and two-way; the legacy one-way
            # contact inbox no longer accepts new support messages.
            return self.redirect("/my/tickets" if self.current_owner()
                                 else "/login?next=/my/tickets")

        if path == register_web.BASE or path.startswith(register_web.BASE + "/"):
            return register_web.post(self, path, form, s)
        if path == "/submit":
            # v208: legacy one-page POST is retired; the wizard owns creation.
            return self.redirect(register_web.BASE)
        # ---- live duplicate check while the applicant types
        if path == "/api/check-duplicate":
            if self.spam_gate("checkdup"):
                return   # v275 پین: ۴۲۹ با نام gate (پاسخ تنها)
            _me = self.current_owner()
            _own = {x["id"] for x in db.businesses_of(_me["id"])} if _me else set()
            dups = db.find_duplicates(
                name=form_get(form, "name"), phone=form_get(form, "phone"),
                address=form_get(form, "address"),
                exclude_id=safe_int(form_get(form, "exclude", "0"), 0) or None,
                exclude_ids=_own or None)
            return self.json_out({"duplicates": dups})

        # ---- v156: «موجود شد خبرم کن» از صفحهٔ کالا
        m = re.match(r"^/item/(\d+)/notify-me$", path)
        if m:
            cust = self.current_customer()
            if not cust:
                return self.redirect("/me/login?next="
                                     + urllib.parse.quote(f"/item/{m.group(1)}"))
            it = db.item(safe_int(m.group(1)))
            if not it:
                return self.redirect("/catalog")
            if self.spam_gate("notifyme", "c%d" % cust["id"]):
                return
            okk, msg = db.stock_request_add(it["biz_id"], it["id"], cust["id"],
                                            source="item")
            back = f"/item/{it['id']}?" + ("ok=" if okk else "err=") \
                   + urllib.parse.quote(msg)
            return self.redirect(back)

        # ---- v3 public posts -------------------------------------------
        # question on a business page
        m = re.match(r"^/b/([^/]+)/ask-question$", path)
        if m:
            if is_spambot(form):
                return self.redirect(f"/b/{m.group(1)}")   # drop silently
            if s.get("qa_enabled") != "1":
                return self.redirect(f"/b/{m.group(1)}")
            if not db.rate_ok(f"qa:{self.client_key()}"):
                return self.redirect(f"/b/{m.group(1)}?err="
                    + urllib.parse.quote("تعداد درخواست‌ها زیاد است. کمی بعد دوباره تلاش کنید."))
            b = db.business(slug=m.group(1))
            if b:
                asker = form_get(form, "asker").strip()
                body = form_get(form, "body").strip()
                if len(asker) >= 2 and len(body) >= 8:
                    _v, _g = antispam.content_gate("question", self.client_key(),
                                                   asker + " " + body)
                    if _v == "reject":
                        return self.redirect(f"/b/{m.group(1)}?ok="
                            + urllib.parse.quote("پرسش شما ثبت شد."))  # silent
                    _cu = db.customer_session_get(self.cookies().get(self.CUSTOMER_COOKIE))
                    db.add_question(b["id"], asker, body,
                                    auto_publish=(s.get("qa_moderated") != "1"),
                                    customer_id=(_cu["id"] if _cu else None),
                                    spam_flag=1 if _v == "hold" else 0)
                    if b.get("phone"):
                        sms.notify(s, db.norm_phone(b["phone"]),
                                   f"پرسش تازه دربارهٔ «{b['name']}» در {s.get('site_name')}")
                    sms.notify_owner(s, f"پرسش جدید دربارهٔ «{b['name']}» از {asker}")
                    msg = ("پرسش شما ثبت شد و پس از بررسی منتشر می‌شود."
                           if s.get("qa_moderated") == "1" else "پرسش شما منتشر شد.")
                    return self.redirect(f"/b/{m.group(1)}?ok={urllib.parse.quote(msg)}#qa")

        # ---- v285: پرسش‌وپاسخ — ویرایش/حذف فقط پیام خودی (پنجرهٔ ۱۵ دقیقه)
        m = re.fullmatch(r"/qa/(\d+)/(edit|delete|answer-edit|answer-delete)", path)
        if m:
            qid = safe_int(m.group(1))
            action = m.group(2)
            row = db.question(qid)
            if not row or row["status"] == "deleted":
                return self.send(V.not_found(s), 404)
            bb = db.business(bid=row["biz_id"]) or {}
            slug = bb.get("slug", "")
            dest = form_get(form, "back") or f"/b/{slug}"
            if not dest.startswith("/") or dest.startswith("//"):
                dest = f"/b/{slug}"
            frag = ""
            if "#" in dest:
                dest, _f = dest.split("#", 1)
                frag = "#" + _f
            elif dest.startswith("/b/"):
                frag = "#qa"

            def _qa_back(param, msg):
                sep = "&" if "?" in dest else "?"
                return self.redirect(dest + sep + param + "="
                                     + urllib.parse.quote(msg) + frag)

            cust = self.current_customer(); own = self.current_owner()
            admin_ok = db.admin_session_ok(
                self.cookies().get(self.ADMIN_COOKIE),
                unlocked_only=db.owner_pass_set())
            if not db.rate_ok("qaedit:" + self.client_key()):
                return _qa_back("err", "کمی صبر کنید و دوباره تلاش کنید.")
            if action in ("edit", "delete"):
                mine = bool(cust and row["customer_id"]
                            and int(row["customer_id"]) == int(cust["id"]))
                if not (mine or admin_ok):
                    return _qa_back("err",
                                    "فقط صاحب پیام می‌تواند آن را ویرایش یا حذف کند.")
                if action == "delete":
                    db.question_soft_delete(qid)
                    db.log("qa.delete", f"q={qid} by={'admin' if not mine else 'asker'}")
                    return _qa_back("ok", "پرسش حذف شد.")
                created = db._qa_ts(row["created"], utc=True) or 0
                if not admin_ok and time.time() - created > db.QA_EDIT_WINDOW:
                    return _qa_back("err", "پنجرهٔ ویرایش (۱۵ دقیقه) گذشته است؛ "
                                           "در صورت نیاز پرسش را حذف کنید.")
                body_txt = form_get(form, "body").strip()
                if not (8 <= len(body_txt) <= 2000):
                    return _qa_back("err", "متن پرسش باید بین ۸ و ۲۰۰۰ نویسه باشد.")
                verdict, _g = antispam.content_gate("qa", self.client_key(), body_txt)
                if verdict == "reject":
                    return _qa_back("err", "متن توسط محافظ محتوا رد شد.")
                db.question_set_body(qid, body_txt)
                return _qa_back("ok", "پرسش ویرایش شد.")
            # answer-edit / answer-delete — فقط صاحب همان کسب‌وکار (یا ادمین)
            is_owner = bool(own and db.owns(own["id"], row["biz_id"]))
            if not (is_owner or admin_ok):
                return _qa_back("err", "فقط صاحب کسب‌وکار می‌تواند پاسخ را "
                                       "ویرایش یا حذف کند.")
            if action == "answer-delete":
                db.answer_clear(qid)
                db.log("qa.answer_delete", f"q={qid}")
                return _qa_back("ok", "پاسخ حذف شد.")
            answered = db._qa_ts(row["answered"]) or 0
            if not admin_ok and time.time() - answered > db.QA_EDIT_WINDOW:
                return _qa_back("err", "پنجرهٔ ویرایش پاسخ (۱۵ دقیقه) گذشته است؛ "
                                       "پاسخ را حذف و دوباره ثبت کنید.")
            ans_txt = form_get(form, "answer").strip()
            if not (2 <= len(ans_txt) <= 4000):
                return _qa_back("err", "متن پاسخ باید بین ۲ و ۴۰۰۰ نویسه باشد.")
            verdict, _g = antispam.content_gate("qa", self.client_key(), ans_txt)
            if verdict == "reject":
                return _qa_back("err", "متن توسط محافظ محتوا رد شد.")
            db.answer_set(qid, ans_txt)
            return _qa_back("ok", "پاسخ ویرایش شد.")
            return self.redirect(f"/b/{m.group(1)}?err="
                + urllib.parse.quote("نام و متن پرسش را کامل بنویسید."))

        # helpful vote on a question
        if path == "/api/question-helpful":
            qid = form_get(form, "id")
            if not qid.isdigit():
                return self.json_out({"ok": False}, 400)
            if not db.rate_ok(f"qh:{self.client_key()}", limit=40):
                return self.json_out({"ok": False, "error": "too many"}, 429)
            cust = self.current_customer()
            if cust:
                voter = "c%d" % cust["id"]
            else:
                voter = "k" + hashlib.sha256(
                    (self.client_key() + "|" +
                     (self.headers.get("User-Agent") or "")).encode()
                ).hexdigest()[:16]
            n = db.question_helpful(safe_int(qid), voter)
            return self.json_out({"ok": True, "helpful": n})

        # abuse / wrong-info report
        m = re.match(r"^/b/([^/]+)/report$", path)
        if m:
            if s.get("reports_enabled") != "1":
                return self.redirect(f"/b/{m.group(1)}")
            if not db.rate_ok(f"rep:{self.client_key()}"):
                return self.redirect(f"/b/{m.group(1)}?err="
                    + urllib.parse.quote("تعداد گزارش‌ها زیاد است. کمی بعد دوباره تلاش کنید."))
            b = db.business(slug=m.group(1))
            if b:
                db.add_report("business", b["id"], form_get(form, "reason", "other"),
                              form_get(form, "body"), form_get(form, "reporter"))
                db.log("report.add", f"{b['id']} {form_get(form, 'reason')}")
            return self.redirect(f"/b/{m.group(1)}?ok="
                + urllib.parse.quote("گزارش شما ثبت شد. ممنون که کمک کردید اطلاعات درست بماند."))

        # saved-search alert
        if path == "/api/alert":
            if s.get("alerts_enabled") != "1":
                return self.json_out({"ok": False, "error": "غیرفعال است"}, 404)
            if not db.rate_ok(f"al:{self.client_key()}"):
                return self.json_out({"ok": False, "error": "بعداً تلاش کنید"}, 429)
            aid, msg = db.add_alert(form_get(form, "phone"), form_get(form, "term"),
                                    form_get(form, "cat"))
            return self.json_out({"ok": bool(aid), "message": msg})

        if path == "/alert":
            aid, msg = db.add_alert(form_get(form, "phone"), form_get(form, "term"),
                                    form_get(form, "cat"))
            back = form_get(form, "back", "/businesses")
            # v116-audit: `back` is attacker-controllable form input — without
            # this it was an open redirect (phishing pivot after a real POST).
            if not back.startswith("/") or back.startswith("//"):
                back = "/businesses"
            sep = "&" if "?" in back else "?"
            key = "ok" if aid else "err"
            return self.redirect(f"{back}{sep}{key}={urllib.parse.quote(msg)}")

        m = re.match(r"^/b/([^/]+)/review$", path)
        if m:
            if is_spambot(form):
                return self.redirect(f"/b/{m.group(1)}?ok="
                    + urllib.parse.quote("نظر شما ثبت شد."))   # drop silently
            if not db.rate_ok(f"rv:{self.client_key()}"):
                return self.redirect(f"/b/{m.group(1)}?err="
                    + urllib.parse.quote("تعداد نظرهای ارسالی زیاد است. کمی بعد دوباره تلاش کنید."))
            b = db.business(slug=m.group(1))
            if b:
                _v, _g = antispam.content_gate("review", self.client_key(),
                                                   form_get(form, "author") + " " +
                                                   form_get(form, "body"))
                if _v == "reject":
                    return self.redirect(f"/b/{m.group(1)}?ok="
                        + urllib.parse.quote("نظر شما ثبت شد."))  # silent
                err = self._review_submit(
                    s, b, form_get(form, "author"), form_get(form, "body"), form,
                    spam_flag=1 if _v == "hold" else 0)
                if err:
                    return self.redirect(f"/b/{m.group(1)}?err="
                        + urllib.parse.quote(err))
                sms.notify_owner(s, f"نظر جدید برای «{b['name']}» از "
                                    f"{form_get(form, 'author')}")
            return self.redirect(f"/b/{m.group(1)}?ok="
                + urllib.parse.quote("نظر شما ثبت شد."))

        m = re.match(r"^/haggle/(\d+)$", path)
        if m:
            if s.get("prices_enabled") != "1":
                return self.send(V.not_found(s), 404)
            iid = safe_int(m.group(1))
            it = db.item(iid)
            if not it or not db.haggle_allowed(it):
                return self.send(V.not_found(s), 404)
            if not db.rate_ok(f"hg:{self.client_key()}"):
                return self.send(V2.haggle_form(
                    s, iid, err="پیشنهادهای زیادی فرستاده‌اید. کمی بعد دوباره تلاش کنید."))
            offer = int(re.sub(r"[^\d]", "", form_get(form, "offer", "0")) or 0)
            name = form_get(form, "name").strip()
            phone = form_get(form, "phone").strip()
            if offer <= 0 or not name or not phone:
                return self.send(V2.haggle_form(
                    s, iid, err="قیمت، نام و شمارهٔ تماس را کامل وارد کنید."))
            if offer > int(it["price"]):
                return self.send(V2.haggle_form(
                    s, iid, err="پیشنهاد شما از قیمت اعلام‌شده بیشتر است — "
                                "می‌توانید همان قیمت را مستقیم بخرید."))
            hid, tok, verdict = db.make_offer(
                it["biz_id"], iid, name, phone, offer,
                form_get(form, "qty", "1"), form_get(form, "note"))
            return self.send(V2.haggle_form(
                s, iid, sent={"token": tok, "verdict": verdict, "id": hid}))

        m = re.match(r"^/offer/([A-Za-z0-9_-]{6,64})$", path)
        if m:
            if self.spam_gate("offer"):
                return
            if s.get("prices_enabled") != "1":
                return self.send(V.not_found(s), 404)
            tok = m.group(1)
            rows = db.haggle_thread(token=tok)
            if not rows:
                return self.send(V.not_found(s), 404)
            last = rows[-1]
            if last["status"] not in ("open", "countered") or last["is_buyer"]:
                return self.redirect(f"/offer/{urllib.parse.quote(tok)}")
            action = form_get(form, "action", "counter")
            root = rows[0]
            if action == "accept":
                db.set_haggle_status(last["id"], "accepted")
                db.set_haggle_status(root["id"], "accepted")
            else:
                offer = int(re.sub(r"[^\d]", "", form_get(form, "offer", "0")) or 0)
                if offer <= 0:
                    return self.send(V2.haggle_thread_page(
                        s, tok, err="قیمت پیشنهادی را وارد کنید."))
                db.set_haggle_status(last["id"], "countered")
                db.make_offer(root["biz_id"], root["item_id"], root["name"],
                              root["phone"], offer, root.get("qty", 1),
                              form_get(form, "note"), parent=last["id"],
                              side="buyer")
            return self.redirect(f"/offer/{urllib.parse.quote(tok)}")

        m = re.match(r"^/b/([^/]+)/book$", path)
        if m:
            if is_spambot(form):
                return self.redirect(f"/b/{m.group(1)}?booked=1")   # drop silently
            # v171: قبلاً POST نوبت کاملاً اعتبارسنجی‌نشده بود — خالی/بی‌شماره
            # ذخیره می‌شد، دکانِ «رزرو خاموش» هم نوبت می‌گرفت و نرخ‌سنجی هم
            # نداشت. حالا: پرچم دکان + نام/شماره/تاریخ معتبر + نرخ‌سنج.
            b = db.business(slug=m.group(1))
            if not b or not b.get("booking_on"):
                return self.redirect(f"/b/{m.group(1)}?err="
                    + urllib.parse.quote("این کسب‌وکار فعلاً نوبت نمی‌پذیرد."))
            if not db.rate_ok(f"bk:{self.client_key()}"):
                return self.redirect(f"/b/{m.group(1)}?err="
                    + urllib.parse.quote("تعداد درخواست‌ها زیاد است. کمی بعد دوباره تلاش کنید."))
            _bn = form_get(form, "name").strip()
            _bp = db.norm_phone(form_get(form, "phone"))
            _bd = form_get(form, "date").strip()
            if len(_bn) < 2 or not db.valid_phone(_bp) or not _bd:
                return self.redirect(f"/b/{m.group(1)}?err="
                    + urllib.parse.quote("نام، شمارهٔ موبایل و تاریخ را کامل و درست وارد کنید."))
            _bc = self.current_customer()
            _bcid = (_bc["id"] if _bc and db.norm_phone(_bc.get("phone")) == _bp else None)
            db.add_booking(b["id"], _bn, _bp, _bd,
                           form_get(form, "time"), form_get(form, "note"), _bcid)
            sms.notify_owner(s, f"رزرو نوبت جدید برای «{b['name']}» در "
                                f"{_bd} {form_get(form, 'time')}")
            return self.redirect(f"/b/{m.group(1)}?booked=1")

        # ---------------- business-owner posts (cookie session)
        if path == "/my/logout":
            db.session_kill(self.cookies().get(self.SESSION_COOKIE, ""))
            self.set_cookie(self.SESSION_COOKIE, "", days=0)
            # v69 one account: leaving the shop side signs the person out
            # of the customer side too
            db.customer_session_kill(self.cookies().get(self.CUSTOMER_COOKIE, ""))
            self.set_cookie(self.CUSTOMER_COOKIE, "", days=0)
            return self.redirect("/")
        if path.startswith("/my/"):
            me = self.current_owner()
            if not me:
                return self.redirect("/login")
            return self.owner_post(path, form, s, me)

        # ---------------- v301 agent standalone posts — email login + agent key, separate from panel, fully active
        if path.startswith("/agent") or path.startswith("/api/agent/"):
            # allow if customer/owner logged in + agent key, or admin
            is_api = path.startswith("/api/")
            cust = self.current_customer()
            own = self.current_owner()
            admin = self.admin_ok(form)
            # v309 (دستور مدیر): owner/admin session = full access, no Bale key
            agent_ok = self._agent_ok() or bool(own) or bool(admin)
            # chat endpoint is special: allow offline without agent key? No, still need at least customer or admin for privacy
            if path in ("/api/agent/chat", "/agent/chat", "/api/agent/chat2"):
                if not agent_ok:
                    # for api, return JSON error; for form, show gate
                    if is_api:
                        return self.json_out({"ok": False, "error": "agent key required — get from Bale bot /agent"}, 403)
                    # if no customer at all, redirect to email gate
                    if not cust and not own and not admin:
                        return self.redirect("/agent")
                # delegate to panel_post which now handles model switching + admin_agent
                # need to bypass admin gate for standalone — call panel_post directly if agent_ok
                if agent_ok or admin:
                    # we are in public POST handler, but panel_post expects admin token — we have tok
                    return self.panel_post(path, form, s, tok)
                return self.json_out({"ok": False, "error": "need login"}, 403) if is_api else self.redirect("/agent")
            # other /agent/* batch actions — need agent_ok
            if path.startswith("/agent/"):
                if not agent_ok:
                    return self.json_out({"ok": False, "error": "agent key required"}, 403) if is_api else self.redirect("/agent")
                if not cust and not own and not admin:
                    return self.redirect("/agent")
                return self.panel_post(path, form, s, tok)
            # api/agent/status etc
            if path.startswith("/api/agent/"):
                if not agent_ok:
                    return self.json_out({"ok": False, "error": "agent key required"}, 403)
                return self.panel_post(path, form, s, tok)

        # ---------------- v300 agent panel posts (need admin + agent cookie)
        if path.startswith("/panel/agent") or path.startswith("/api/agent/"):
            # admin gate still required for panel version
            if not self.admin_ok(form):
                return self.send(P.login_gate(s), 403)
            # v309 (دستور مدیر): خودِ نشست ادمین کافی است — کلید بله لازم نیست
            return self.panel_post(path, form, s, tok)

        # ---------------- admin posts
        if not self.admin_ok(form):
            return self.send(P.login_gate(s), 403)
        return self.panel_post(path, form, s, tok)

    # -------------------------------------------------------------- owner POST
    def owner_post(self, path, form, s, me):
        # ---- v142: mark all notifications read
        if path == "/my/notifications/read":
            db.owner_mark_read(me["id"])
            return self.redirect("/my/notifications")
        # ---- v142: per-kind notification switches (whole form save)
        if path == "/my/notif-settings":
            for k in notifmeta.OWNER_META:
                on = checkbox(form, f"k_{k}")
                db.set_owner_pref(me["id"], k, on)
            return self.redirect("/my/notif-settings?ok=" +
                                 urllib.parse.quote("تنظیم اعلان‌ها ذخیره شد."))
        # ---- account & security: username + password (v57)
        if path == "/my/account":
            ok, msg = db.owner_set_credentials(me["id"], form_get(form, "username"),
                                               form_get(form, "password"))
            key = "ok" if ok else "err"
            return self.redirect(f"/my/account?{key}={urllib.parse.quote(msg)}")

        # ---- chat reply (v28)
        m = re.match(r"^/my/chat/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1), 0)
            thread = db.chat_thread(tid)
            if not thread:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            if not self.chat_role(thread, {}, "owner"):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            if db.customer_phone(thread.get("customer_id")) == (self.current_owner() or {}).get("phone"):
                err = "مشتری این گفتگو خودِ شماست؛ پیامی به خودتان ارسال نشد."
            elif not db.rate_ok(f"chat:owner:{self.client_key()}", limit=60, window=600):
                err = "تعداد پیام‌ها زیاد است. کمی بعد دوباره تلاش کنید."
            else:
                _mid, err = self.store_chat_message(
                    thread, "owner", form_get(form, "body"), [], s)
            if err:
                return self.redirect(f"/my/chat/{tid}?err=" + urllib.parse.quote(err))
            return self.redirect(f"/my/chat/{tid}?ok=" + urllib.parse.quote("پیام ارسال شد."))

        # ---- order status / cancellation decision
        m=re.match(r"^/my/order/(\d+)/cancel$",path)
        if m:
            oid=safe_int(m.group(1));approve=form_get(form,"action")=="approve"
            if not db.decide_order_cancel(oid,me["id"],approve):return self.send(V.not_found(s),403)
            return self.redirect("/my/orders?ok="+urllib.parse.quote("درخواست لغو تأیید شد." if approve else "درخواست لغو رد شد."))
        m = re.match(r"^/my/order/(\d+)$", path)
        if m:
            if self.spam_gate("ordstatus", "o%d" % me["id"]):
                return
            o = db.order(safe_int(m.group(1)))
            if o and db.owns(me["id"], o["biz_id"]):
                st = form_get(form, "status", "new")
                db.set_order_status(o["id"], st)
                if o.get("customer_id") and s.get("notif_enabled") == "1":
                    label = db.ORDER_LABELS.get(st, ("badge-neutral", st))[1]
                    db.notify(o["customer_id"], "order",
                              f"وضعیت سفارش #{o['id']} به «{label}» تغییر کرد.",
                              f"/me/order/{o['id']}")
            return self.redirect("/my/orders?ok=وضعیت سفارش به‌روزرسانی شد.")

        # ---- story delete (v31)
        m = re.match(r"^/my/story/(\d+)/delete$", path)
        if m:
            if self.spam_gate("omod", "o%d" % me["id"]):
                return
            sid = safe_int(m.group(1))
            # only the story's own shop owner may delete it
            rows = db.stories_for_owner(me["id"])
            if any(r["id"] == sid for r in rows):
                db.story_delete(sid)
            return self.redirect("/my/stories?ok=استوری حذف شد.")
        m = re.match(r"^/my/trash/(\d+)/restore$", path)   # v105: owner restore
        if m:
            tid = safe_int(m.group(1))
            row = db._one("SELECT * FROM trash WHERE id=?", (tid,))
            biz_ids = [b["id"] for b in db.businesses_of(me["id"])]
            allowed = bool(row) and row["biz_id"] in biz_ids
            if row and row["entity"] == "business":
                # v209: the shop itself is gone from `businesses`, so ownership
                # is proven by the snapshot in the bin, not by a live row.
                try:
                    allowed = json.loads(row["payload"]).get("owner_id") == me["id"]
                except Exception:
                    allowed = False
            if allowed:
                db.trash_restore(tid)
                if row["entity"] == "business":
                    return self.redirect("/my/businesses?ok=" + urllib.parse.quote("کسب‌وکار بازیابی شد و برای بررسی دوباره در صف مدیر است."))
                return self.redirect("/my/trash?ok=محتوا بازیابی شد.")
            return self.redirect("/my/trash?err=دسترسی یا مورد معتبر نیست.")

        # v209: owner lifecycle — withdraw review / resubmit / hide / show / delete
        m = re.match(r"^/my/business/(\d+)/(withdraw|resubmit|hide|show|delete)$", path)
        if m:
            bid, action = safe_int(m.group(1)), m.group(2)
            if not db.rate_ok(f"ownerbiz:{me['id']}", limit=20, window=60, always=True):
                return self.redirect("/my/businesses?err=" + urllib.parse.quote("درخواست‌ها زیاد است؛ کمی بعد دوباره تلاش کنید."))
            b = db.business(bid=bid)
            if not b or b.get("owner_id") != me["id"]:
                return self.send(V.not_found(s), 403)
            if action == "delete":
                # second factor: the owner must retype the shop's name.
                typed = (form_get(form, "confirm_name", "") or "").strip()
                if db.normalize_fa(typed) != db.normalize_fa(b["name"]):
                    return self.redirect(f"/my/businesses?err=" + urllib.parse.quote("برای حذف، نام کسب‌وکار را دقیقاً همان‌طور که ثبت شده بنویسید."))
                if db.owner_delete_business(me["id"], bid):
                    try:
                        sms.notify_owner(s, f"دکان‌دار «{b['name']}» را حذف کرد (۳۰ روز در سطل بازیافت می‌ماند).")
                    except Exception:
                        pass
                    return self.redirect("/my/businesses?ok=" + urllib.parse.quote(f"«{b['name']}» حذف شد. تا ۳۰ روز از «بازیابی فایل‌ها» قابل برگرداندن است."))
                return self.redirect("/my/businesses?err=" + urllib.parse.quote("حذف انجام نشد."))
            ok_, new_status = db.owner_biz_transition(me["id"], bid, action)
            if not ok_:
                return self.redirect("/my/businesses?err=" + urllib.parse.quote("این عملیات در وضعیت فعلی ممکن نیست؛ صفحه را تازه کنید."))
            msg = {"withdraw": "درخواست بررسی لغو شد؛ کسب‌وکار به حالت پیش‌نویسِ مخفی رفت و هر وقت خواستید می‌توانید دوباره ارسال کنید.",
                   "resubmit": "دوباره برای بررسی مدیر ارسال شد.",
                   "hide": "کسب‌وکار موقتاً از سایت پنهان شد.",
                   "show": "کسب‌وکار دوباره روی سایت نمایش داده می‌شود."}[action]
            if action in ("withdraw", "resubmit"):
                try:
                    sms.notify_owner(s, f"«{b['name']}»: " + ("دکان‌دار درخواست بررسی را لغو کرد." if action == "withdraw" else "دکان‌دار دوباره برای بررسی فرستاد."))
                except Exception:
                    pass
            return self.redirect("/my/businesses?ok=" + urllib.parse.quote(msg))

        # ---- support tickets: a real two-way thread with the admin
        if path == "/my/tickets":
            if not db.rate_ok(f"tk:{self.client_key()}", limit=10):
                return self.redirect("/my/tickets?err=" + urllib.parse.quote(
                    "تعداد تیکت‌ها زیاد است. کمی بعد دوباره تلاش کنید."))
            subject = form_get(form, "subject").strip()
            body = form_get(form, "body").strip()
            if len(subject) < 3 or len(body) < 10:
                return self.redirect("/my/tickets?err=" + urllib.parse.quote(
                    "عنوان و متن پیام را کامل بنویسید."))
            bid = form_get(form, "biz_id", "")
            bid = int(bid) if str(bid).isdigit() and db.owns(me["id"], int(bid)) else None
            _v, _g = antispam.content_gate("ticket", self.client_key(),
                                               (subject or "") + " " + (body or ""))
            if _v == "reject":
                return self.redirect("/my/tickets?ok=" + urllib.parse.quote(
                    "تیکت شما ثبت شد."))  # silent
            tid, tok = db.create_ticket(
                subject, body, name=me.get("name") or "", phone=me.get("phone", ""),
                owner_id=me["id"], biz_id=bid,
                topic=form_get(form, "topic", "other"),
                spam_flag=1 if _v == "hold" else 0)
            return self.redirect(f"/my/ticket/{tid}?ok=" + urllib.parse.quote(
                "تیکت شما ثبت شد. پاسخ را همین‌جا می‌بینید."))

        # ---- v156: فراخوان دکان (ارسال خبر به دنبال‌کننده‌ها + درخواست‌های موجودی)
        if path == "/my/broadcast/send":
            bid = safe_int(form_get(form, "biz_id"), 0)
            if not bid or not db.owns(me["id"], bid):
                return self.redirect("/my/broadcast?err=" + urllib.parse.quote(
                    "این کسب‌وکار متعلق به شما نیست."))
            if not db.broadcast_allowed(bid):
                return self.redirect("/my/broadcast?err=" + urllib.parse.quote(
                    "فراخوان برای این دکان باز نیست — با اشتراک یا بنیان‌گذاری فعال می‌شود."))
            if not db.rate_ok(f"bcast:{me['id']}", limit=10, window=3600):
                return self.redirect("/my/broadcast?err=" + urllib.parse.quote(
                    "تعداد فراخوان‌ها زیاد است؛ کمی بعد دوباره تلاش کنید."))
            _bid, sent = db.broadcast_create(bid, form_get(form, "kind"),
                                             form_get(form, "text"))
            if not _bid:
                return self.redirect("/my/broadcast?err=" + urllib.parse.quote(str(sent)))
            return self.redirect("/my/broadcast?ok=" + urllib.parse.quote(
                f"فراخوان ارسال شد و به {sent} دنبال‌کننده رسید."))

        m = re.match(r"^/my/broadcast/(fulfill|dismiss)$", path)
        if m:
            if self.spam_gate("bcastfd", "o%d" % me["id"]):
                return
            rid = safe_int(form_get(form, "rid"), 0)
            act = m.group(1)
            okk = (db.stock_request_fulfill(rid, me["id"]) if act == "fulfill"
                   else db.stock_request_dismiss(rid, me["id"]))
            msg = ("خبر «موجود شد» برای مشتری ارسال شد." if okk
                   else "این درخواست دیگر باز نیست.")
            return self.redirect("/my/broadcast?" +
                                 ("ok=" if okk else "err=") + urllib.parse.quote(msg))

        m = re.match(r"^/my/ticket/(\d+)$", path)
        if m:
            if self.spam_gate("ticketreply", "o%d" % me["id"]):
                return
            tid = safe_int(m.group(1))
            t = db.ticket(tid=tid)
            if not t or t.get("owner_id") != me["id"]:
                return self.send(V.not_found(s), 403)
            if form_get(form, "action") == "close":
                db.set_ticket(tid, status="closed")
                return self.redirect(f"/my/ticket/{tid}?ok=" +
                                     urllib.parse.quote("تیکت بسته شد."))
            if db.ticket_reply(tid, form_get(form, "body"), side="user"):
                return self.redirect(f"/my/ticket/{tid}?ok=" +
                                     urllib.parse.quote("پیام شما ارسال شد."))
            return self.redirect(f"/my/ticket/{tid}?err=" +
                                 urllib.parse.quote("متن پیام خالی است."))

        # ---- quick-add a catalogue item: two fields instead of forty-five.
        # Runs through exactly the same ownership check, feature gate and
        # plan quota as the full form -- it is a shorter door, not a back one.
        m = re.match(r"^/my/catalog/(\d+)/quick$", path)
        if m:
            if self.spam_gate("itemsave", "o%d" % me["id"]):
                return
            bid = safe_int(m.group(1))
            if not db.owns(me["id"], bid):
                return self.send(V.not_found(s), 403)
            if self.gate(bid, "catalog", "/my"):
                return
            lim = db.access(bid)
            if db.items_count(bid) >= lim["max_items"]:
                return self.redirect("/my?err=" + urllib.parse.quote(
                    f"سقف پلن «{lim['plan_name']}» {lim['max_items']} مورد است. "
                    f"برای افزودن بیشتر، پلن را ارتقا دهید."))
            title = form_get(form, "title").strip()
            if len(title) < 2:
                return self.redirect("/my?err=" + urllib.parse.quote(
                    "نام کالا را بنویسید."))
            raw = re.sub(r"[^\d]", "", form_get(form, "price", ""))
            price = int(raw or 0)
            _qid = db.save_item({
                "biz_id": bid, "kind": "product", "title": title,
                "price": price,
                # no price given means "ask" rather than "free"
                "price_type": "fixed" if price else "call",
                "available": 1,
            }, dup_hold=True)
            _qr = db.item(_qid) if _qid else None
            if _qr and _qr.get("spam_flag"):
                antispam.event(self.client_key(), "itemsave", "hold", "itemdup",
                               "o%d" % me["id"], "iid:%s" % _qid)
                return self.redirect("/my?err=" + urllib.parse.quote(
                    "عنوان تکراری با کالای موجود — کالا تا بررسی مدیر پنهان می‌ماند. (درگاه: itemdup)"))
            return self.redirect("/my?ok=" + urllib.parse.quote(
                f"«{title}» اضافه شد."))

        m = re.match(r"^/my/offer/(\d+)$", path)
        if m:
            if self.spam_gate("omod", "o%d" % me["id"]):
                return
            h = db.haggle(safe_int(m.group(1)))
            if not h or not db.owns(me["id"], h["biz_id"]):
                return self.send(V.not_found(s), 403)
            if self.gate(h["biz_id"], "inquiry", "/my/offers"):
                return
            thread = db.haggle_thread(root_id=h["id"])
            last = thread[-1] if thread else h
            action = form_get(form, "action", "")
            if action == "accept":
                db.set_haggle_status(h["id"], "accepted")
                db.set_haggle_status(last["id"], "accepted")
                msg = "پیشنهاد پذیرفته شد."
            elif action == "decline":
                db.set_haggle_status(h["id"], "declined")
                msg = "پیشنهاد رد شد."
            else:
                offer = int(re.sub(r"[^\d]", "", form_get(form, "offer", "0")) or 0)
                if offer <= 0:
                    return self.redirect("/my/offers?err="
                        + urllib.parse.quote("قیمت پیشنهادی خود را وارد کنید."))
                db.set_haggle_status(h["id"], "countered")
                db.make_offer(h["biz_id"], h["item_id"], "", "", offer,
                              h.get("qty", 1), form_get(form, "note"),
                              parent=last["id"], side="seller")
                msg = "پیشنهاد متقابل شما ثبت شد."
            if h.get("customer_id"):
                tok = h.get("token") or ""
                db.notify_customer(h["customer_id"], "haggle",
                                   f"فروشنده به پیشنهاد شما پاسخ داد: {msg}",
                                   (f"/offer/{tok}" if tok else ""))
            return self.redirect("/my/offers?ok=" + urllib.parse.quote(msg))

        m = re.match(r"^/my/business/(\d+)$", path)
        if m:
            if self.spam_gate("itemsave", "o%d" % me["id"]):
                return
            bid = safe_int(m.group(1))
            if not db.owns(me["id"], bid):
                return self.send(V.not_found(s), 403)
            data = {k: form_get(form, k) for k in
                    ("name", "cat_slug", "descr", "slogan", "phone", "whatsapp", "address",
                     "tags", "instagram", "telegram", "eitaa", "bale", "soroush", "rubika",
                     "website", "lat", "lng", "area", "city", "province")}
            data["booking_on"] = checkbox(form, "booking_on")
            # v158: شمارهٔ تلفن دکان همیشه = شمارهٔ ورود مالک؛ ارسالیِ فرم
            # (دستکاری‌شده یا نه) نادیده گرفته می‌شود — UI هم readonly است.
            data["phone"] = me["phone"]
            data["slogan"] = (data.get("slogan") or "").strip()[:120]   # v285
            # silently drop fields the shop has not unlocked, rather than
            # failing the whole save — the UI already shows them as locked
            if not db.can(bid, "social"):
                for f in db.SOCIAL_KEYS:
                    data.pop(f, None)
            if not db.can(bid, "booking"):
                data["booking_on"] = 0
            data["hours"] = json.dumps(build_hours(form), ensure_ascii=False)
            # When the admin turned on review-before-publish, an owner edit is
            # queued instead of applied, so nothing changes behind their back.
            if s.get("edit_approval") == "1":
                eid = db.queue_edit(bid, me["id"], data)
                msg = ("تغییری نسبت به قبل نبود." if not eid else
                       "تغییرات برای بررسی مدیر ثبت شد و پس از تأیید اعمال می‌شود.")
                return self.redirect(f"/my/business/{bid}?ok={urllib.parse.quote(msg)}")
            db.save_business(data, bid)
            return self.redirect(f"/my/business/{bid}?ok=تغییرات ذخیره شد.")

        m = re.match(r"^/my/review/(\d+)$", path)
        if m:
            if self.spam_gate("omod", "o%d" % me["id"]):
                return
            rid = safe_int(m.group(1))
            # v171: نظر ناموجود یا دکانِ دیگر — پیام صادقانه، نه «پاسخ ثبت شد»
            r = [x for x in db.reviews() if x["id"] == rid]
            if not r or not db.owns(me["id"], r[0]["biz_id"]):
                return self.redirect("/my/reviews?err=" + urllib.parse.quote(
                    "نظری با این شناسه روی دکان شما نیست."))
            if self.gate(r[0]["biz_id"], "reply", "/my/reviews"):
                return
            db.update_review(rid, reply=form_get(form, "reply"))
            return self.redirect("/my/reviews?ok=پاسخ ثبت شد.")

        m = re.match(r"^/my/question/(\d+)$", path)
        if m:
            if self.spam_gate("omod", "o%d" % me["id"]):
                return
            qid = safe_int(m.group(1))
            qq = db.question(qid)
            if not qq or not db.owns(me["id"], qq["biz_id"]):
                return self.send(V.not_found(s), 403)
            if self.gate(qq["biz_id"], "qa", "/my/questions"):
                return
            ans = form_get(form, "answer").strip()
            if not ans:
                return self.redirect("/my/questions?err=متن پاسخ خالی است.")
            db.answer_question(qid, ans, by="owner")
            return self.redirect("/my/questions?ok=پاسخ ثبت و منتشر شد.")

        m = re.match(r"^/my/booking/(\d+)$", path)
        if m:
            if self.spam_gate("omod", "o%d" % me["id"]):
                return
            kid = safe_int(m.group(1))
            # v171: نوبت ناموجود یا دکانِ دیگر — پیام صادقانه + وضعیت whitelist
            k = [x for x in db.bookings() if x["id"] == kid]
            if not k or not db.owns(me["id"], k[0]["biz_id"]):
                return self.redirect("/my/bookings?err=" + urllib.parse.quote(
                    "نوبتی با این شناسه روی دکان شما نیست."))
            if self.gate(k[0]["biz_id"], "booking", "/my/bookings"):
                return
            _st = form_get(form, "status", "new")
            if not db.update_booking(kid, status=_st):
                return self.redirect("/my/bookings?err=" + urllib.parse.quote(
                    "وضعیت نوبت معتبر نیست."))
            return self.redirect("/my/bookings?ok=وضعیت به‌روزرسانی شد.")

        if path == "/my/claim":
            if self.spam_gate("claim", "o%d" % me["id"]):
                return
            bid = form_get(form, "biz_id")
            if bid.isdigit():
                ok, msg = db.claim_add(int(bid), me["id"])
                if ok:
                    sms.notify_owner(s, f"درخواست تصاحب کسب‌وکار جدید از {me.get('phone')}")
                key = "ok" if ok else "err"
                return self.redirect(f"/my/claim?{key}={urllib.parse.quote(msg)}")
            return self.redirect("/my/claim")

        # catalog
        m = re.match(r"^/my/catalog/(\d+)/item/(new|\d+)$", path)
        if m:
            if self.spam_gate("itemsave", "o%d" % me["id"]):
                return
            bid = safe_int(m.group(1))
            if not db.owns(me["id"], bid):
                return self.send(V.not_found(s), 403)
            iid = None if m.group(2) == "new" else safe_int(m.group(2))
            # a plan limit that is only printed on a page is decoration;
            # this is where it actually bites
            if iid is None:
                if self.gate(bid, "catalog", f"/my/catalog/{bid}"):
                    return
                lim = db.access(bid)
                if db.items_count(bid) >= lim["max_items"]:
                    return self.redirect(f"/my/catalog/{bid}?err=" + urllib.parse.quote(
                        f"سقف پلن «{lim['plan_name']}» {lim['max_items']} مورد است. "
                        f"برای افزودن بیشتر، پلن را ارتقا دهید."))
            _sid = self.save_item_from(form, bid, iid, None, dup_hold=True)
            if _sid and not iid:
                _sr = db.item(_sid)
                if _sr and _sr.get("spam_flag"):
                    antispam.event(self.client_key(), "itemsave", "hold", "itemdup",
                                   "o%d" % me["id"], "iid:%s" % _sid)
                    return self.redirect(f"/my/catalog/{bid}?err=" + urllib.parse.quote(
                        "عنوان تکراری با کالای موجود — کالا تا بررسی مدیر پنهان می‌ماند. (درگاه: itemdup)"))
            return self.redirect(f"/my/catalog/{bid}?ok=ذخیره شد.")

        m = re.match(r"^/my/catalog/(\d+)/item/(\d+)/delete$", path)
        if m:
            if self.spam_gate("omod", "o%d" % me["id"]):
                return
            bid = safe_int(m.group(1))
            if db.owns(me["id"], bid):
                db.delete_item(safe_int(m.group(2)))
            return self.redirect(f"/my/catalog/{bid}?ok=حذف شد.")

        m = re.match(r"^/my/gallery/(\d+)/(delete|cover|banner)$", path)
        if m:
            if self.spam_gate("omod", "o%d" % me["id"]):
                return
            bid, act = safe_int(m.group(1)), m.group(2)
            if db.owns(me["id"], bid):
                self.gallery_op(bid, act, form_get(form, "src"))
            return self.redirect(f"/my/gallery/{bid}?ok=انجام شد.")

        m = re.match(r"^/my/inquiry/(\d+)$", path)
        if m:
            if self.spam_gate("omod", "o%d" % me["id"]):
                return
            if self.inquiry_op(safe_int(m.group(1)), form, me):
                return self.redirect("/my/inquiries?ok=انجام شد.")
            return self.redirect("/my/inquiries?err=" + urllib.parse.quote(
                "این درخواست متعلق به کسب‌وکار شما نیست."))

        return self.send(V.not_found(s), 404)

    # -------------------------------------------------------------- shared ops
    def save_item_images(self, form, files, iid):
        """Merge kept images (in the order the owner arranged them) with new
        uploads, and delete anything they removed."""
        old_imgs = db.item_images(iid) if iid else []
        try:
            keep = json.loads(form_get(form, "images_keep", "[]"))
        except Exception:
            keep = None

        new_paths = []
        for fname, _fn, data in files:
            if fname != "images":
                continue
            if len(new_paths) + (len(keep) if keep else 0) >= 6:
                break
            path, err = uploads.save_image(data, "item")
            if path:
                new_paths.append(path)

        if keep is None:
            # no JS payload (plain form post) -> just append
            final = old_imgs + new_paths
        else:
            it = iter(new_paths)
            final = []
            for slot in keep:
                if slot == "@new":
                    nxt = next(it, None)
                    if nxt:
                        final.append(nxt)
                elif slot in old_imgs:
                    final.append(slot)
            final.extend(it)          # any extras

        for gone in set(old_imgs) - set(final):
            uploads.delete_image(gone)
        return final[:6]

    def save_item_from(self, form, bid, iid, file_bytes, dup_hold=False):
        data = {
            "biz_id": bid,
            "kind": form_get(form, "kind", "product"),
            "title": form_get(form, "title"),
            "descr": form_get(form, "descr"),
            "price": form_get(form, "price", "0"),
            "price_type": form_get(form, "price_type", "fixed"),
            "unit": form_get(form, "unit"),
            "duration": form_get(form, "duration"),
            "tags": form_get(form, "tags"),
            "options": form_get(form, "options"),
            "old_price": form_get(form, "old_price", "0"),
            "stock": form_get(form, "stock", ""),
            "code": form_get(form, "code"),
            "min_order": form_get(form, "min_order"),
            "note": form_get(form, "note"),
            # ---- shop-window fields
            "brand": form_get(form, "brand"),
            "warranty": form_get(form, "warranty"),
            "prep_days": form_get(form, "prep_days"),
            "delivery": form_get(form, "delivery"),
            "bulk_price": form_get(form, "bulk_price"),
            "video": form_get(form, "video"),
            "spec": form_get(form, "spec"),
            "weight": form_get(form, "weight"),
            "handmade": checkbox(form, "handmade"),
            "returnable": checkbox(form, "returnable"),
            # ---- چانه‌زنی (floor price stays server-side; buyers never see it)
            "haggle": checkbox(form, "haggle"),
            "floor_price": form_get(form, "floor_price", "0"),
            "available": checkbox(form, "available"),
            "sort": form_get(form, "sort", "0"),
        }
        # audit F-016: `featured` is a metered plan perk (featured_slots) and
        # ranks items first in the public catalog. The owner's own form never
        # sends it, so a crafted POST could grab free placement — and an
        # ordinary edit used to clobber an admin-granted featured back to 0.
        # Only plans/unlocks that include the perk may set it; otherwise the
        # key is omitted entirely so a saved item keeps its current value.
        if db.can(bid, "featured"):
            data["featured"] = checkbox(form, "featured")
        old = db.item(iid) if iid else None
        if file_bytes:
            path, err = uploads.save_image(file_bytes, "item")
            if path:
                if old and old.get("image"):
                    uploads.delete_image(old["image"])
                data["image"] = path
        elif form.get("remove_image"):
            if old and old.get("image"):
                uploads.delete_image(old["image"])
            data["image"] = ""
        return db.save_item(data, iid, dup_hold=dup_hold)

    def gallery_op(self, bid, act, src):
        imgs = db.biz_images(bid)
        if act == "delete" and src in imgs:
            imgs.remove(src)
            uploads.delete_image(src)
            # a deleted photo must not stay as the page banner
            b = db.business(bid=bid)
            if b and b.get("cover") == src:
                db.save_business({"cover": ""}, bid)
        elif act == "cover" and src in imgs:
            imgs.remove(src)
            imgs.insert(0, src)
        elif act == "banner":
            # the shop's own background behind its page header. Empty string
            # clears it and falls back to the site gradient.
            db.save_business({"cover": src if src in imgs else ""}, bid)
            return
        db.biz_images_set(bid, imgs)

    def inquiry_op(self, qid, form, me=None, is_admin=False):
        # Ownership wall: a shopkeeper may only touch inquiries addressed to
        # one of their own businesses. (Security fix — previously any signed-in
        # owner could delete/quote every inquiry in the city by id.) The admin
        # panel path passes is_admin=True and is already token-gated.
        q = db.inquiry(qid)
        if not q:
            return False
        if not is_admin and (not me or not db.owns(me["id"], q["biz_id"])):
            return False
        act = form_get(form, "action")
        if act == "delete":
            return db.delete_inquiry(qid)
        if act in ("won", "lost"):
            return db.update_inquiry(qid, status=act)
        db.update_inquiry(qid, quote=form_get(form, "quote"), status="quoted")
        return True

    # /subscribe may arrive urlencoded or multipart (bank receipt attached).
    # One handler for both bodies — v139.
    def subscribe_post(self, s, form, files=None):
        me = self.current_owner()
        if not me:
            return self.redirect("/login")
        plan_slug = form_get(form, "plan")
        bid = form_get(form, "biz_id")
        months = form_get(form, "months")
        # v136: keep the chosen billing period on every redirect so it never
        # snaps back to the plan's own (yearly) length.
        back = f"/subscribe?plan={urllib.parse.quote(plan_slug)}"
        if months and str(months).isdigit():
            back += f"&months={int(months)}"
        if not bid.isdigit() or not db.owns(me["id"], int(bid)):
            return self.redirect(back + "&err=" + urllib.parse.quote(
                "این کسب‌وکار متعلق به شما نیست."))
        if not db.rate_ok(f"sb:{self.client_key()}", limit=6):
            return self.redirect(back + "&err=" + urllib.parse.quote(
                "تعداد درخواست‌ها زیاد است. کمی بعد تلاش کنید."))
        # v154: شواهد پرداخت «همیشه» الزامی‌اند — قبلاً فقط وقتی مدیر کارت را
        # ثبت کرده بود (manual_flow) گارد روشن بود و در نصبِ بدون کارت،
        # درخواستِ بی‌کد‌رهگیری و بی‌فیش پذیرفته می‌شد. جریان خرید همیشه
        # تأیید دستی مدیر دارد؛ پس بی‌مدرک معنا ندارد.
        receipt_path = ""
        for n, fn, data in (files or []):
            if n == "receipt" and data:
                receipt_path, rerr = uploads.save_image(data, "receipt")
                if not receipt_path:
                    return self.redirect(back + "&err=" + urllib.parse.quote(
                        rerr or "فیش ارسالی معتبر نیست — یک تصویر انتخاب کنید."))
                break
        if len((form_get(form, "ref") or "").strip()) < 4:
            return self.redirect(back + "&err=" + urllib.parse.quote(
                "کد پیگیری تراکنش را وارد کنید (حداقل ۴ نویسه)؛ بدون آن درخواست ثبت نمی‌شود."))
        if not receipt_path:
            return self.redirect(back + "&err=" + urllib.parse.quote(
                "تصویر فیش را پیوست کنید؛ بدون آن درخواست ثبت نمی‌شود."))
        sid, msg = db.request_subscription(int(bid), plan_slug,
                                           form_get(form, "ref"), "manual",
                                           form_get(form, "note"),
                                           months=months, receipt=receipt_path)
        if not sid:
            return self.redirect(f"/pricing?err={urllib.parse.quote(msg)}")
        db.log("subscription.request", f"biz {bid} plan {plan_slug} by {me['phone']}")
        return self.redirect(f"/my/plan?ok={urllib.parse.quote(msg)}")

    # -------------------------------------------------------------- multipart
    def _review_submit(self, s, b, author, body, fields, image="", spam_flag=0):
        """v151 shared logic for both review POST paths. Returns an error
        message (redirect) or None (store the review).
        Rules: facility-based criteria only; stars need a signed-in non-owner;
        one scored review per account per shop; guests write text-only."""
        cust = self.current_customer()
        owner_ph = db.business_owner_phone(b["id"])
        if cust and owner_ph and cust.get("phone") == owner_ph:
            return "به کسب‌وکار خودتان نمی‌توانید نظر یا امتیاز ثبت کنید."
        scores = {}
        if s.get("multicriteria") == "1":
            for code, _lbl in db.biz_criteria(b["id"]):
                # v160-fix: form_get هر دو شکلِ مقدار (رشتهٔ multipart و
                # لیستِ urlencoded) را نرمال می‌کند — قبلاً مسیر urlencoded
                # امتیازها را بی‌صدا می‌انداخت.
                v = form_get(fields, f"crit_{code}", "")
                if v and str(v).isdigit():
                    scores[code] = max(1, min(6, int(v)))
        raw = str(form_get(fields, "rating", "") or "").strip()
        try:
            rv = int(raw) if raw else 0
        except Exception:
            rv = 0
        rv = max(0, min(6, rv))
        if (scores or rv > 0) and not cust:
            # guests never carry stars — a forged rating is dropped silently
            scores, rv = {}, 0
        if (scores or rv > 0) and cust and db.customer_rated_review(b["id"], cust["id"]):
            return ("شما قبلاً برای این کسب‌وکار امتیاز ثبت کرده‌اید؛ اگر نظر تازه‌ای "
                    "دارید آن را بدون ستاره بنویسید.")
        if not scores:
            rv = 0
        db.add_review_full(b["id"], author, rv, body, scores=scores, spam_flag=spam_flag,
                           auto_approve=(s.get("reviews_moderated") != "1"),
                           image=image,
                           customer_id=(cust["id"] if cust else None))
        return None
    def _save_news_media(self, s, fields, files, is_post, pid):
        """v285: save a panel blog-post / city-event with optional image and
        video. Video accepts an upload (mp4/webm/mov, 64MB cap) OR an
        allowlisted embed/direct URL (Aparat, YouTube, https .mp4 — e.g. from
        an external WordPress site). Everything else is refused."""
        back = "/panel/posts" if is_post else "/panel/events"
        edit_href = (f"/panel/{'post' if is_post else 'event'}/{pid}" if pid else back)

        def _err(msg, dest=None):
            return self.redirect((dest or edit_href) + "?err=" + urllib.parse.quote(msg))

        if form_get(fields, "action") == "delete" and pid:
            (db.delete_post if is_post else db.delete_cityevent)(pid)
            return self.redirect(back + "?ok=" + urllib.parse.quote("حذف شد."))
        title = form_get(fields, "title").strip()
        if not title:
            return _err("عنوان الزامی است.")
        row = {}
        if pid:
            row = dict((db.post_by_id(pid) if is_post else db.cityevent(eid=pid)) or {})
            if not row:
                return _err("رکوردی با این شناسه نیست.", back)
        # ---- image
        img = "" if form_get(fields, "clear_image") else (
            row.get("cover" if is_post else "image") or "")
        blob = next((d for n, fn, d in files
                     if n == ("cover_file" if is_post else "image_file") and d), None)
        if blob:
            img, err = uploads.save_image(blob, "post" if is_post else "event")
            if not img:
                return _err(err or "تصویر ذخیره نشد.")
        # ---- video
        vid = "" if form_get(fields, "clear_video") else (row.get("video") or "")
        vblob = next((d for n, fn, d in files if n == "video_file" and d), None)
        if vblob:
            vpath, kind, err = uploads.save_news_media(
                vblob, "post" if is_post else "event")
            if not vpath:
                return _err(err or "ویدیو ذخیره نشد.")
            if kind != "video":
                try:
                    os.remove(os.path.join(uploads.UPLOAD_DIR,
                                           os.path.basename(vpath)))
                except OSError:
                    pass
                return _err("فایل انتخابی ویدیو نیست (mp4/webm/mov).")
            vid = vpath
        vurl = form_get(fields, "video_url").strip()
        if vurl:
            emb = uploads.embed_from_url(vurl)
            if not emb:
                return _err("لینک ویدیو پذیرفته نشد — فقط آپارات، یوتیوب یا "
                            "فایل مستقیم https (mp4/webm).")
            vid = emb[1]
        if is_post:
            db.save_post({"title": title,
                          "excerpt": form_get(fields, "excerpt"),
                          "body": form_get(fields, "body"),
                          "cover": img, "video": vid,
                          "status": form_get(fields, "status") or "published"},
                         pid or None)
        else:
            db.save_cityevent({"title": title,
                               "descr": form_get(fields, "descr"),
                               "place": form_get(fields, "place"),
                               "date": form_get(fields, "date"),
                               "time": form_get(fields, "time"),
                               "biz_id": form_get(fields, "biz_id"),
                               "image": img, "video": vid,
                               "status": form_get(fields, "status") or "published"},
                              pid or None)
        db.log("news.media", f"{'post' if is_post else 'event'} "
                             f"{'new' if not pid else pid} "
                             f"img={'y' if img else 'n'} video={'y' if vid else 'n'}")
        return self.redirect(back + "?ok=" + urllib.parse.quote(
            "مطلب ذخیره شد." if is_post else "رویداد ذخیره شد."))

    def route_multipart(self, path, s, tok):
        # v285: admin news/event forms may carry a video — raise the body cap
        # ONLY when the cookie already proves an unlocked admin session.
        _cap = None
        if path.startswith(("/panel/post", "/panel/event")) and db.admin_session_ok(
                self.cookies().get(self.ADMIN_COOKIE),
                unlocked_only=db.owner_pass_set()):
            _cap = uploads.NEWS_VIDEO_MAX + 8 * 1024 * 1024
        fields, files = self.read_multipart(max_body=_cap)
        clip_form(fields)
        if path == register_web.BASE + "/images":
            return register_web.post(self, path, fields, s, files=files)
        if path == "/subscribe":
            if self.spam_gate("pricealert"):
                return
            return self.subscribe_post(s, fields, files)
        # v117/M1: uploads authenticate like every other panel POST — an
        # unlocked admin session cookie, or the legacy key when no password
        # is set (upload forms no longer embed the raw key).
        admin = db.admin_session_ok(
            self.cookies().get(self.ADMIN_COOKIE),
            unlocked_only=db.owner_pass_set()) or (
            _token_eq(fields.get("key", ""), tok)
            and not db.owner_pass_set())
        me = self.current_owner()

        # v316: file exchange only — arena bridge removed
        if path in ("/api/agent/upload", "/agent/upload"):
            if not (self._agent_ok() or self.current_owner() or self.admin_ok(fields) or admin or me):
                return self.json_out({"ok": False, "error": "auth required"}, 403)
            if not db.rate_ok("agent-upload:" + self.client_key(), limit=30, window=300, always=True):
                return self.json_out({"ok": False, "error": "rate limited"}, 429)
            saved = []
            for field, fname, data in files:
                if not data:
                    continue
                try:
                    info = AB.exchange_save_file(data, fname or "file")
                    saved.append(info)
                except Exception as e:
                    saved.append({"ok": False, "error": str(e)[:200]})
            if path.startswith("/api/"):
                return self.json_out({"ok": True, "files": saved, "exchange": AB.exchange_list()})
            _ref = self.headers.get("Referer") or ""
            _back = "/panel/agent" if "/panel/agent" in _ref else "/agent"
            return self.redirect(_back + "?ok=" + urllib.parse.quote(f"{len([x for x in saved if x.get('ok')])} فایل ذخیره شد."))

        # ---- v285: blog posts & city events with image/video media
        _pm = re.fullmatch(r"/panel/post/(?:new|(\d+))", path)
        _em = re.fullmatch(r"/panel/event/(?:new|(\d+))", path)
        if _pm or _em:
            if not admin:
                return self.send(P.login_gate(s), 403)
            if not db.rate_ok("news-save:" + self.client_key(),
                              limit=30, window=600):
                return self.send("too many requests", 429,
                                 "text/plain; charset=utf-8")
            _m = _pm or _em
            return self._save_news_media(s, fields, files, bool(_pm),
                                         safe_int(_m.group(1) or 0))

        # ---- v181 category image CRUD (mobile gallery/camera compatible)
        if path == "/panel/category/new":
            if not admin:
                return self.send(P.login_gate(s), 403)
            name = form_get(fields, "name").strip()
            if not name:
                return self.redirect(self._panel_url(s, "/panel/categories?err=" +
                                     urllib.parse.quote("نام دسته الزامی است.")))
            image = ""
            blob = next((data for field, _fn, data in files
                         if field == "image" and data), None)
            if blob:
                image, err = uploads.save_image(blob, "category")
                if not image:
                    return self.redirect(self._panel_url(s, "/panel/categories?err=" +
                                         urllib.parse.quote(err or "تصویر ذخیره نشد.")))
            db.save_category({"name": name,
                              "icon": form_get(fields, "icon", "store"),
                              "image": image,
                              "parent": form_get(fields, "parent"),
                              "blurb": form_get(fields, "blurb")})
            return self.redirect(self._panel_url(s, "/panel/categories?ok=" +
                                 urllib.parse.quote("دسته و تصویر آن ایجاد شد.")))

        m = re.match(r"^/panel/category/(\d+)$", path)
        if m:
            if not admin:
                return self.send(P.login_gate(s), 403)
            cid = safe_int(m.group(1))
            current = db.category_by_id(cid)
            if not current:
                return self.send(V.not_found(s), 404)
            name = form_get(fields, "name").strip()
            if not name:
                return self.redirect(self._panel_url(s, f"/panel/category/{cid}?err=" +
                                     urllib.parse.quote("نام دسته الزامی است.")))
            old_image = current.get("image") or ""
            image = old_image
            blob = next((data for field, _fn, data in files
                         if field == "image" and data), None)
            try:
                keep = json.loads(fields["image_keep"]) if "image_keep" in fields else None
            except Exception:
                keep = None
            if blob:
                image, err = uploads.save_image(blob, "category")
                if not image:
                    return self.redirect(self._panel_url(s, f"/panel/category/{cid}?err=" +
                                         urllib.parse.quote(err or "تصویر ذخیره نشد.")))
            elif keep is not None and not keep:
                image = "-"  # suppress even the packaged slug.webp fallback
            db.save_category({"name": name,
                              "icon": form_get(fields, "icon", "store"),
                              "image": image,
                              "blurb": form_get(fields, "blurb"),
                              "parent": form_get(fields, "parent"),
                              "sort": form_get(fields, "sort", "0") or 0,
                              "active": checkbox(fields, "active")}, cid)
            if old_image.startswith(uploads.PUBLIC_PREFIX) and old_image != image:
                uploads.delete_image(old_image)
            return self.redirect(self._panel_url(s, "/panel/categories?ok=" +
                                 urllib.parse.quote("دسته و تصویر آن به‌روزرسانی شد.")))

        # ---- messenger attachment/text send (v73)
        m = re.match(r"^/(me|my|panel)/chat/(\d+)$", path)
        if m:
            area, tid = m.group(1), safe_int(m.group(2), 0)
            thread = db.chat_thread(tid)
            if not thread:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            sender = {"me": "customer", "my": "owner", "panel": "admin"}[area]
            role = self.chat_role(thread, fields, sender)
            if not role or (sender == "admin" and not admin):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            # v150: no talking to yourself — an owner must not message their
            # own business (or the shop's customer-thread whose other side is
            # themselves). Both sides of such a thread belong to one person.
            if sender == "customer" and db.business_owner_phone(thread.get("biz_id")) \
                    == (self.current_customer() or {}).get("phone"):
                err = "شما مالک همین کسب‌وکارید؛ پیامی به خودتان ارسال نشد."
            elif sender == "owner" and db.customer_phone(thread.get("customer_id")) \
                    == (self.current_owner() or {}).get("phone"):
                err = "مشتری این گفتگو خودِ شماست؛ پیامی به خودتان ارسال نشد."
            elif not db.rate_ok(f"chat:{sender}:{self.client_key()}", limit=60, window=600):
                err = "تعداد پیام‌ها زیاد است. کمی بعد دوباره تلاش کنید."
            else:
                _mid, err = self.store_chat_message(
                    thread, sender, form_get(fields, "body"), files, s)
            if area == "panel":
                back = f"/panel/chat/{tid}"
            else:
                back = f"/{area}/chat/{tid}"
            if err:
                return self.redirect(back + ("&" if "?" in back else "?")
                                     + "err=" + urllib.parse.quote(err))
            return self.redirect(back + ("&" if "?" in back else "?")
                                 + "ok=" + urllib.parse.quote("پیام ارسال شد."))

        # ---- support ticket attachments (v76) -- private, authenticated
        if path == "/my/tickets":
            if not me:
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            if self.spam_gate("ticketnew", "o%d" % me["id"]):
                return
            blob = next(((fn,d) for n,fn,d in files if n=="attachment" and d), None)
            attachment = None
            if blob:
                attachment, err = uploads.save_chat_file(blob[1], blob[0], prefix="ticket")
                if not attachment:
                    return self.redirect("/my/tickets?err="+urllib.parse.quote(err or "فایل نامعتبر است."))
            subject=form_get(fields,"subject").strip(); body=form_get(fields,"body").strip()
            if len(subject)<3 or (len(body)<2 and not attachment):
                if attachment: uploads.delete_chat_file(attachment["stored_name"])
                return self.redirect("/my/tickets?err="+urllib.parse.quote("عنوان و متن را کامل کنید."))
            bid=safe_int(fields.get("biz_id"),0) or None
            if bid and not db.owns(me["id"],bid): bid=None
            _v,_g=antispam.content_gate("ticket", self.client_key(), (subject or "")+" "+(body or ""))
            if _v=="reject":
                return self.redirect("/my/tickets?ok="+urllib.parse.quote("تیکت شما ثبت شد."))
            tid,_tok=db.create_ticket(subject,body,name=me.get("name") or "",phone=me.get("phone") or "",owner_id=me["id"],biz_id=bid,topic=form_get(fields,"topic","other"),attachment=attachment,spam_flag=1 if _v=="hold" else 0)
            if not tid:
                if attachment: uploads.delete_chat_file(attachment["stored_name"])
                return self.redirect("/my/tickets?err="+urllib.parse.quote("ثبت تیکت انجام نشد."))
            return self.redirect(f"/my/ticket/{tid}?ok="+urllib.parse.quote("تیکت ثبت شد."))

        m=re.match(r"^/my/ticket/(\d+)$",path)
        if m:
            if self.spam_gate("ticketreply", "o%d" % me["id"]):
                return
            tid=safe_int(m.group(1)); t=db.ticket(tid=tid)
            if not me or not t or t.get("owner_id")!=me["id"]:
                return self.send("forbidden",403,"text/plain; charset=utf-8")
            if form_get(fields,"action")=="close":
                db.set_ticket(tid,status="closed");return self.redirect(f"/my/ticket/{tid}?ok=تیکت بسته شد.")
            blob=next(((fn,d) for n,fn,d in files if n=="attachment" and d),None);attachment=None
            if blob:
                attachment,err=uploads.save_chat_file(blob[1],blob[0],prefix="ticket")
                if not attachment:return self.redirect(f"/my/ticket/{tid}?err="+urllib.parse.quote(err or "فایل نامعتبر است."))
            mid=db.ticket_reply(tid,form_get(fields,"body"),side="user",attachment=attachment)
            if not mid and attachment:uploads.delete_chat_file(attachment["stored_name"])
            return self.redirect(f"/my/ticket/{tid}?"+("ok=پیام ارسال شد." if mid else "err=پیام خالی است."))

        m=re.match(r"^/panel/ticket/(\d+)$",path)
        if m:
            if not admin:return self.send("forbidden",403,"text/plain; charset=utf-8")
            tid=safe_int(m.group(1));action=form_get(fields,"action","reply")
            if action=="delete":db.delete_ticket(tid);return self.redirect(self._panel_url(s, f"/panel/tickets?ok=تیکت حذف شد."))
            db.set_ticket(tid,status=form_get(fields,"status","open"),priority=form_get(fields,"priority","normal"))
            if action=="save":return self.redirect(self._panel_url(s, f"/panel/ticket/{tid}?ok=وضعیت ذخیره شد."))
            blob=next(((fn,d) for n,fn,d in files if n=="attachment" and d),None);attachment=None
            if blob:
                attachment,err=uploads.save_chat_file(blob[1],blob[0],prefix="ticket")
                if not attachment:return self.redirect(self._panel_url(s, f"/panel/ticket/{tid}?err="+urllib.parse.quote(err or "فایل نامعتبر است.")))
            mid=db.ticket_reply(tid,form_get(fields,"body"),side="admin",attachment=attachment)
            if not mid and attachment:uploads.delete_chat_file(attachment["stored_name"])
            return self.redirect(self._panel_url(s, f"/panel/ticket/{tid}?"+("ok=پاسخ ارسال شد." if mid else "err=پیام خالی است.")))

        # ---- shop story upload (v31)
        if path == "/my/story/add":
            if me and self.spam_gate("storyadd", "o%d" % me["id"]):
                return
            if not me:
                return self.redirect("/login")
            bid = safe_int(fields.get("biz_id"), 0)
            if not db.owns(me["id"], bid):
                return self.redirect("/my/stories?err=" + urllib.parse.quote(
                    "این کسب‌وکار متعلق به شما نیست."))
            blob = next((d for n, fn, d in files if n == "story_media"), None)
            if not blob:
                return self.redirect("/my/stories?err=" + urllib.parse.quote(
                    "عکس یا ویدیویی انتخاب نشده است."))
            path_, kind, err = uploads.save_media(blob, "story")
            if not path_:
                return self.redirect("/my/stories?err=" + urllib.parse.quote(err or "خطا در فایل"))
            try:
                _dur = float(fields.get("duration", "0") or 0)
            except (TypeError, ValueError):
                _dur = 0.0
            db.stories_add(bid, path_, fields.get("caption", ""), kind=kind or "image",
                           duration=max(0.0, min(_dur, 30.0)))
            db.log("story.add", f"{bid} {kind}")
            return self.redirect("/my/stories?ok=" + urllib.parse.quote(
                "استوری منتشر شد." if kind == "image" else "ویدیو-استوری منتشر شد."))

        # ---- review with optional photo (v28)
        m = re.match(r"^/b/([^/]+)/review$", path)
        if m:
            if is_spambot(fields):
                return self.redirect(f"/b/{m.group(1)}?ok="
                    + urllib.parse.quote("نظر شما ثبت شد."))
            if not db.rate_ok(f"rv:{self.client_key()}"):
                return self.redirect(f"/b/{m.group(1)}?err="
                    + urllib.parse.quote("تعداد نظرهای ارسالی زیاد است. کمی بعد دوباره تلاش کنید."))
            b = db.business(slug=m.group(1))
            if b:
                img_path = ""
                blob = next((d for n, fn, d in files if n == "review_image"), None)
                if blob:
                    img_path, _err = uploads.save_image(blob, "review")
                    if not img_path:
                        img_path = ""
                _v, _g = antispam.content_gate("review", self.client_key(),
                                                   fields.get("author", "") + " " +
                                                   fields.get("body", ""))
                if _v == "reject":
                    return self.redirect(f"/b/{m.group(1)}?ok="
                        + urllib.parse.quote("نظر شما ثبت شد."))  # silent
                err = self._review_submit(
                    s, b, fields.get("author", ""), fields.get("body", ""),
                    fields, image=img_path, spam_flag=1 if _v == "hold" else 0)
                if err:
                    return self.redirect(f"/b/{m.group(1)}?err="
                        + urllib.parse.quote(err))
                sms.notify_owner(s, f"نظر جدید برای «{b['name']}» از "
                                    f"{fields.get('author', '')}")
            return self.redirect(f"/b/{m.group(1)}?ok="
                + urllib.parse.quote("نظر شما ثبت شد."))

        # ---- gallery upload (JSON response, called by fetch)
        m = re.match(r"^/(my|panel)/gallery/(\d+)/upload$", path)
        if m:
            if not admin:
                # v280-fix: guard مستقیم — پاسخ JSON تنها یک بار فرستاده می‌شود
                _oku, _gu, _ru = antispam.guard("upload", self.client_key(),
                                                "o%d" % (me["id"] if me else 0))
                if not _oku:
                    return self.json_out({"ok": False, "error": "محدودیت ضداسپم؛ درگاه: upload"}, 429)
            bid = safe_int(m.group(2))
            if not admin and not (me and db.owns(me["id"], bid)):
                return self.json_out({"ok": False, "error": "دسترسی ندارید"}, 403)
            _n = int(self.headers.get("Content-Length") or 0)
            if not admin and not antispam.bytes_add("k:" + self.client_key(), _n):
                return self.json_out({"ok": False, "error": "سقف حجم روزانهٔ آپلود؛ درگاه: bytes"}, 429)
            old_imgs = db.biz_images(bid)
            # The photo cap IS the gallery gate. The old code refused any
            # second photo whenever `gallery` was locked, which contradicted
            # the free plan's advertised 3 photos. max_photos already encodes
            # free=3 / founder=6 / paid=20+, so trust that single number.
            acc = db.access(bid)
            cap = uploads.MAX_FILES if admin else min(uploads.MAX_FILES, acc["max_photos"])
            try:
                keep = json.loads(fields.get("images_keep", "[]"))
            except Exception:
                keep = None

            new_paths, errs = [], []
            for fname, _fn, data in files:
                if fname != "images":
                    continue
                if len(new_paths) + (len(keep) if keep else len(old_imgs)) >= cap:
                    errs.append("ظرفیت گالری تکمیل شد")
                    break
                path, err = uploads.save_image(data, f"biz{bid}")
                if path:
                    new_paths.append(path)
                elif err:
                    errs.append(err)

            if keep is None:
                final = old_imgs + new_paths
            else:
                it = iter(new_paths)
                final = []
                for slot in keep:
                    if slot == "@new":
                        nxt = next(it, None)
                        if nxt:
                            final.append(nxt)
                    elif slot in old_imgs:
                        final.append(slot)
                final.extend(it)
            final = final[:cap]

            for gone in set(old_imgs) - set(final):
                uploads.delete_image(gone)
            db.biz_images_set(bid, final)

            back = (f"/panel/gallery/{bid}?"
                    if admin else f"/my/gallery/{bid}?")
            back += f"ok={urllib.parse.quote('گالری ذخیره شد.')}"
            return self.redirect(back)

        # ---- appearance (logo upload)
        if path == "/panel/appearance":
            if not admin:
                return self.send(P.login_gate(s), 403)
            try:
                keep = json.loads(fields.get("logo_keep", "[]"))
            except Exception:
                keep = None
            old_logo = s.get("site_logo", "")
            new_logo = old_logo
            blob = next((d for n, fn, d in files if n == "logo"), None)
            if blob:
                path_, err = uploads.save_image(blob, "logo")
                if path_:
                    if old_logo:
                        uploads.delete_image(old_logo)
                    new_logo = path_
            elif keep is not None and not keep:
                if old_logo:
                    uploads.delete_image(old_logo)
                new_logo = ""
            db.set_settings({
                "site_logo": new_logo,
                "color_primary": form_get(fields, "color_primary"),
                "color_accent": form_get(fields, "color_accent"),
                "color_background": form_get(fields, "color_background"),
                "color_foreground": form_get(fields, "color_foreground"),
                "hero_title": form_get(fields, "hero_title"),
                "hero_lead": form_get(fields, "hero_lead"),
                "hero_cta": form_get(fields, "hero_cta"),
                "footer_note": form_get(fields, "footer_note"),
            })
            # v173/#32: قبلاً «/panel/appearance&ok=…» ریدایرکت می‌شد — آدرسِ
            # بدون ? مسیر را نمی‌خورد (همان الگوی #28 در بنرها).
            return self.redirect(self._panel_url(s, f"/panel/appearance"
                                 f"?ok={urllib.parse.quote('ظاهر سایت به‌روزرسانی شد.')}"))

        # ---- ad banner with image
        if path == "/panel/ad/new":
            if not admin:
                return self.send(P.login_gate(s), 403)
            title = form_get(fields, "title")
            if not title:
                # v172/#28: قبلاً «/panel/ads&err=…» ریدایرکت می‌شد — آدرسِ
                # بدون ? مسیر را نمی‌خورد و 404 می‌آمد.
                return self.redirect(self._panel_url(s, f"/panel/ads"
                                     f"?err={urllib.parse.quote('عنوان بنر الزامی است.')}"))
            img = ""
            blob = next((d for n, fn, d in files if n == "image" and d), None)
            if blob:
                p_, _err = uploads.save_image(blob, "ad")
                img = p_ or ""
            db.save_ad({"title": title, "body": form_get(fields, "body"),
                        "url": form_get(fields, "url"),
                        "slot": form_get(fields, "slot", "home"),
                        "biz_id": form_get(fields, "biz_id"),
                        "starts": form_get(fields, "starts"),
                        "ends": form_get(fields, "ends"),
                        "weight": form_get(fields, "weight", "1"),
                        "image": img,
                        "active": checkbox(fields, "active")})
            return self.redirect(self._panel_url(s, f"/panel/ads"
                                 f"?ok={urllib.parse.quote('بنر ساخته شد.')}"))

        # ---- v293: ویرایش کامل بنر پس از انتشار (رفع باگ «ویرایش بعد از اجرا نیست»)
        m = re.match(r"^/panel/ad/(\d+)$", path)
        if m:
            if not admin:
                return self.send(P.login_gate(s), 403)
            aid = safe_int(m.group(1))
            a0 = db.ad(aid)
            if not a0:
                return self.redirect(self._panel_url(s, "/panel/ads?err=" + urllib.parse.quote(
                    "بنری با این شناسه نیست.")))
            if form_get(fields, "action") != "save":
                return self.redirect(self._panel_url(s, f"/panel/ad/{aid}?err=" + urllib.parse.quote(
                    "این عملیات از این فرم معتبر نیست.")))
            title = form_get(fields, "title")
            if not title:
                return self.redirect(self._panel_url(s, f"/panel/ad/{aid}?err=" + urllib.parse.quote(
                    "عنوان بنر الزامی است.")))
            _w = form_get(fields, "weight", "1").strip()
            _w = str(max(1, min(10, int(_w)))) if _w.isdigit() else "1"
            img = a0.get("image") or ""
            blob = next((d for n, fn, d in files if n == "image" and d), None)
            if blob:
                p_, _err = uploads.save_image(blob, "ad")
                if p_:
                    if img:
                        uploads.delete_image(img)
                    img = p_
            db.save_ad({"title": title, "body": form_get(fields, "body"),
                        "url": form_get(fields, "url"),
                        "slot": form_get(fields, "slot", "home"),
                        "biz_id": form_get(fields, "biz_id"),
                        "starts": form_get(fields, "starts"),
                        "ends": form_get(fields, "ends"),
                        "weight": _w,
                        "image": img,
                        "active": checkbox(fields, "active")}, aid)
            db.log("ad.save", "#%d %s" % (aid, title[:40]))
            return self.redirect(self._panel_url(s, "/panel/ads?ok=" + urllib.parse.quote(
                "تغییرات بنر ذخیره شد.")))

        # ---- catalog item with image (normal form post -> redirect)
        m = re.match(r"^/(my|panel)/catalog/(\d+)/item/(new|\d+)$", path)
        if m:
            if not admin and self.spam_gate("itemsave", "o%d" % (me["id"] if me else 0)):
                return
            bid = safe_int(m.group(2))
            if not admin and not (me and db.owns(me["id"], bid)):
                return self.send(V.not_found(s), 403)
            iid = None if m.group(3) == "new" else safe_int(m.group(3))
            _new = iid is None
            if iid is None:
                iid = self.save_item_from(fields, bid, None, None,
                                          dup_hold=not admin)
            else:
                self.save_item_from(fields, bid, iid, None)
                if admin and form_get(fields, "spam_clear") == "1":
                    db.item_set_spam_flag(iid, 0)   # v278: رفع نگه‌بررسی توسط مدیر
            imgs = self.save_item_images(fields, files, iid)
            db.item_images_set(iid, imgs)
            if admin:
                return self.redirect(self._panel_url(s, f"/panel/catalog/{bid}?ok=ذخیره شد."))
            if _new and iid and (db.item(iid) or {}).get("spam_flag"):
                antispam.event(self.client_key(), "itemsave", "hold", "itemdup",
                               "o%d" % (me["id"] if me else 0), "iid:%s" % iid)
                return self.redirect(f"/my/catalog/{bid}?err=" + urllib.parse.quote(
                    "عنوان تکراری با کالای موجود — کالا تا بررسی مدیر پنهان می‌ماند. (درگاه: itemdup)"))
            return self.redirect(f"/my/catalog/{bid}?ok=ذخیره شد.")

        return self.send(V.not_found(s), 404)

    def panel_post(self, path, form, s, tok):
        # ============================================================
        # v300/v301 agent panel — live console, encrypted key only via bot, standalone /agent too
        # ============================================================
        # ---- v301 standalone /agent batch handling (same as panel)
        if path.startswith("/panel/agent") or path.startswith("/agent") or path.startswith("/api/agent/"):
            # quick batch for both /panel/agent/* and /agent/* — but chat handled later
            if path.startswith("/api/agent/") and path != "/api/agent/status":
                pass  # let chat handler below deal with it
            elif path not in ("/panel/agent/chat", "/api/agent/chat", "/agent/chat", "/api/agent/chat2"):
                _is_api = path.startswith("/api/")
                _is_standalone = path.startswith("/agent") and not path.startswith("/panel/")
                def _agent_redirect(ok_msg="", err_msg=""):
                    tab = (form_get(form, "tab", "") or "").strip()[:20]
                    extra = ("&tab=" + urllib.parse.quote(tab)) if tab else ""
                    if _is_standalone and not _is_api:
                        base = "/agent"
                        if err_msg:
                            return self.redirect(base + "?err=" + urllib.parse.quote(err_msg[:300]) + extra)
                        return self.redirect(base + "?ok=" + urllib.parse.quote(ok_msg[:400]) + extra)
                    else:
                        if err_msg:
                            return self.redirect(self._panel_url(s, "/panel/agent?err=" + urllib.parse.quote(err_msg[:300]) + extra))
                        return self.redirect(self._panel_url(s, "/panel/agent?ok=" + urllib.parse.quote(ok_msg[:400]) + extra))

                # v322: فرم‌های تب محتوا (همان ابزارها؛ /panel/ در pat تا پوشش گارد رد شود)
                if path in ("/agent/content/biz", "/panel/agent/content/biz",
                            "/agent/content/biz-del", "/panel/agent/content/biz-del",
                            "/agent/content/wipe", "/panel/agent/content/wipe",
                            "/agent/content/moderate", "/panel/agent/content/moderate",
                            "/agent/content/bulk", "/panel/agent/content/bulk",
                            "/agent/content/setting", "/panel/agent/content/setting",
                            "/agent/content/item", "/panel/agent/content/item",
                            "/agent/content/cat", "/panel/agent/content/cat",
                            "/agent/content/page", "/panel/agent/content/page",
                            "/agent/content/post", "/panel/agent/content/post",
                            "/agent/content/biz-edit", "/panel/agent/content/biz-edit",
                            "/agent/content/color", "/panel/agent/content/color"):
                    try:
                        from views_agent_desk import handle_content as _hc
                        kind = path.rsplit("/", 1)[-1]
                        fields = {k: form_get(form, k, "") for k in
                                  ("name", "cat_slug", "phone", "city", "id",
                                   "confirm", "action", "value", "title", "body",
                                   "slug", "excerpt", "price", "descr", "field",
                                   "key", "biz_id", "parent", "color")}
                        ok, msg = _hc(kind, fields)
                        if ok:
                            return _agent_redirect(ok_msg=str(msg)[:400])
                        return _agent_redirect(err_msg=str(msg)[:300])
                    except Exception as e:
                        return _agent_redirect(err_msg=str(e)[:200])

                # v323: تب گفت‌وگو / درآمد · v324: تب سیستم · v325: تب دستور
                _FORM_KEYS = (
                    "name", "cat_slug", "phone", "city", "id", "confirm", "action",
                    "value", "kind", "body", "text", "plan_slug", "biz_id", "code",
                    "title", "percent", "expires", "url", "slot", "months", "ends",
                    "color", "status", "note", "icon", "cmd", "command", "q",
                    "query", "n", "lines", "recipe", "steps",
                    "p_sample", "p_health", "p_seo", "p_sec", "p_backup",
                    "p_biz", "p_rev", "p_coupon", "p_ad", "slug", "excerpt",
                    "price", "descr", "field", "key", "parent")
                if path in ("/agent/talk", "/panel/agent/talk"):
                    try:
                        from views_agent_desk import handle_talk as _ht
                        fields = {k: form_get(form, k, "") for k in _FORM_KEYS}
                        ok, msg = _ht(form_get(form, "kind", ""), fields)
                        if ok:
                            return _agent_redirect(ok_msg=str(msg)[:400])
                        return _agent_redirect(err_msg=str(msg)[:300])
                    except Exception as e:
                        return _agent_redirect(err_msg=str(e)[:200])
                if path in ("/agent/money", "/panel/agent/money"):
                    try:
                        from views_agent_desk import handle_money as _hm
                        fields = {k: form_get(form, k, "") for k in _FORM_KEYS}
                        ok, msg = _hm(form_get(form, "kind", ""), fields)
                        if ok:
                            return _agent_redirect(ok_msg=str(msg)[:400])
                        return _agent_redirect(err_msg=str(msg)[:300])
                    except Exception as e:
                        return _agent_redirect(err_msg=str(e)[:200])
                if path in ("/agent/sys", "/panel/agent/sys"):
                    try:
                        from views_agent_desk import handle_sys as _hs
                        fields = {k: form_get(form, k, "") for k in _FORM_KEYS}
                        ok, msg = _hs(form_get(form, "kind", ""), fields)
                        if ok:
                            return _agent_redirect(ok_msg=str(msg)[:400])
                        return _agent_redirect(err_msg=str(msg)[:300])
                    except Exception as e:
                        return _agent_redirect(err_msg=str(e)[:200])
                if path in ("/agent/play", "/panel/agent/play"):
                    try:
                        from views_agent_desk import handle_play as _hp
                        fields = {k: form_get(form, k, "") for k in _FORM_KEYS}
                        ok, msg = _hp(form_get(form, "kind", ""), fields)
                        if ok:
                            return _agent_redirect(ok_msg=str(msg)[:400])
                        return _agent_redirect(err_msg=str(msg)[:300])
                    except Exception as e:
                        return _agent_redirect(err_msg=str(e)[:200])

                if path in ("/panel/agent/batch/add", "/panel/agent/batch", "/agent/batch/add", "/agent/batch"):
                    tool = form_get(form, "tool", "").strip()[:80]
                    args_raw = form_get(form, "args", "").strip()[:4000]
                    if not tool:
                        return _agent_redirect(err_msg="ابزار انتخاب نشده.")
                    try:
                        args = json.loads(args_raw) if args_raw else {}
                        if not isinstance(args, dict):
                            args = {"value": args}
                    except Exception:
                        args = {"raw": args_raw}
                    try:
                        bid = db.agent_batch_add(tool, args)
                        db.log("agent.batch_add", f"#{bid} {tool}")
                    except Exception as e:
                        return _agent_redirect(err_msg=str(e)[:120])
                    return _agent_redirect(ok_msg=f"ابزار «{tool}» به صف اضافه شد #{bid}.")

                if path in ("/panel/agent/batch/remove", "/agent/batch/remove"):
                    bid = safe_int(form_get(form, "id", "0"))
                    db.agent_batch_remove(bid)
                    return _agent_redirect(ok_msg="از صف حذف شد.")

                if path in ("/panel/agent/batch/clear", "/agent/batch/clear"):
                    db.agent_batch_clear()
                    return _agent_redirect(ok_msg="صف پاک شد.")

                if path in ("/panel/agent/batch/apply", "/panel/agent/apply", "/agent/batch/apply", "/agent/apply"):
                    try:
                        results = db.agent_batch_apply_all(self.client_key())
                        try:
                            import pathlib as _pl
                            _pl.Path("/tmp/dastgir-agent-last-action.json").write_text(
                                json.dumps({"ts": time.time(), "results": results, "count": len(results)}, ensure_ascii=False)[:10000],
                                encoding="utf-8")
                        except Exception:
                            pass
                        ok_n = sum(1 for r in results if r.get("ok"))
                        return _agent_redirect(ok_msg=f"{ok_n}/{len(results)} ابزار اعمال شد.")
                    except Exception as e:
                        return _agent_redirect(err_msg=str(e)[:200])

                if path in ("/panel/agent/or-key", "/agent/or-key", "/api/agent/or-key"):
                    key = (form_get(form, "key", "") or "").strip()
                    if not key and hasattr(self, "read_json"):
                        try:
                            body = self.read_json(max_bytes=4096)
                            if isinstance(body, dict):
                                key = str(body.get("key") or "").strip()
                        except Exception:
                            pass
                    if not (key.startswith("sk-or-") and len(key) > 20):
                        return _agent_redirect(err_msg="کلید اوپن‌روتر باید با sk-or- شروع شود.")
                    try:
                        import orouter as _OR
                        ping = _OR.test_model(_OR.OR_DEFAULT, key=key)
                    except Exception as e:
                        ping = {"ok": False, "error": str(e)[:120]}
                    if not ping.get("ok"):
                        return _agent_redirect(err_msg="کلید تست نشد: " + str(ping.get("error") or "نامشخص")[:180])
                    try:
                        import adminbot_content as _CT
                        ok, msg = _CT.tool_execute("ai_setup", {"provider": "openrouter", "key": key})
                        ok2, msg2 = _CT.tool_execute("ai_setup", {
                            "provider": "site", "key": key,
                            "base": "https://openrouter.ai/api/v1",
                            "model": _OR.OR_DEFAULT,
                        })
                    except Exception as e:
                        return _agent_redirect(err_msg=str(e)[:200])
                    try:
                        db.set_settings({"ai_brain_active": "openrouter",
                                         "ai_brain_or_model": _OR.OR_DEFAULT,
                                         "ai_site_model": _OR.OR_DEFAULT})
                    except Exception:
                        pass
                    return _agent_redirect(ok_msg="کلید اوپن‌روتر تست شد و برای مغز/سایت/ایجنت در صف نصب است.")

                if path in ("/panel/agent/exec", "/panel/agent/tool", "/agent/exec", "/agent/tool"):
                    tool = form_get(form, "tool", "").strip()[:80]
                    args_raw = form_get(form, "args", "").strip()[:4000]
                    if not tool:
                        return _agent_redirect(err_msg="ابزار انتخاب نشده.")
                    try:
                        args = json.loads(args_raw) if args_raw else {}
                    except Exception:
                        args = {"raw": args_raw}
                    try:
                        import adminbot_content as _CT
                        res = _CT.tool_execute(tool, args)
                        try:
                            import pathlib as _pl
                            _pl.Path("/tmp/dastgir-agent-last-action.json").write_text(
                                json.dumps({"ts": time.time(), "tool": tool, "args": args, "result": str(res)[:2000]}, ensure_ascii=False)[:8000],
                                encoding="utf-8")
                        except Exception:
                            pass
                        return _agent_redirect(ok_msg=f"ابزار «{tool}» اجرا شد: {str(res)[:200]}")
                    except Exception as e:
                        return _agent_redirect(err_msg=str(e)[:200])

                if path in ("/panel/agent/code", "/agent/code"):
                    return _agent_redirect(ok_msg="code endpoint — use GET with q param.")

                if path in ("/panel/agent/confirm", "/agent/confirm"):
                    try:
                        import pathlib as _pl
                        pf = _pl.Path("/tmp/dastgir-admin-pending.json")
                        if not pf.exists():
                            return _agent_redirect(err_msg="در انتظار تأییدی نیست.")
                        pf.unlink(missing_ok=True)
                        return _agent_redirect(ok_msg="تأیید شد و اعمال گردید.")
                    except Exception as e:
                        return _agent_redirect(err_msg=str(e)[:200])

                if path in ("/panel/agent/cancel", "/agent/cancel"):
                    try:
                        import pathlib as _pl
                        _pl.Path("/tmp/dastgir-admin-pending.json").unlink(missing_ok=True)
                        db.agent_batch_clear()
                        return _agent_redirect(ok_msg="لغو شد و همه چیز به حالت قبل برگشت.")
                    except Exception as e:
                        return _agent_redirect(err_msg=str(e)[:200])

                if path in ("/panel/agent/key", "/agent/key"):
                    try:
                        new_key = db.agent_key_new(self.client_key(), ttl=3600)
                        return _agent_redirect(ok_msg=f"کلید تازه ساخته شد: {new_key[:8]}…")
                    except Exception as e:
                        return _agent_redirect(err_msg=str(e)[:200])

                # if we are here and path is /agent or /agent/xxx that is not batch/exec, don't fall through to 404 — let outer handler keep it?
                if _is_standalone and path in ("/agent", "/agent/"):
                    return self.redirect("/agent")

        if path.startswith("/panel/agent") or path.startswith("/api/agent/") or path.startswith("/agent/") or path == "/agent":
            # ---- /panel/agent/batch/add — stage a tool
            if path in ("/panel/agent/batch/add", "/panel/agent/batch"):
                tool = form_get(form, "tool", "").strip()[:80]
                args_raw = form_get(form, "args", "").strip()[:4000]
                if not tool:
                    return self.redirect(self._panel_url(s, "/panel/agent?err=" + urllib.parse.quote("ابزار انتخاب نشده.")))
                try:
                    args = json.loads(args_raw) if args_raw else {}
                    if not isinstance(args, dict):
                        args = {"value": args}
                except Exception:
                    args = {"raw": args_raw}
                try:
                    bid = db.agent_batch_add(tool, args)
                    db.log("agent.batch_add", f"#{bid} {tool}")
                except Exception as e:
                    return self.redirect(self._panel_url(s, "/panel/agent?err=" + urllib.parse.quote(str(e)[:120])))
                return self.redirect(self._panel_url(s, f"/panel/agent?ok=" + urllib.parse.quote(f"ابزار «{tool}» به صف اضافه شد #{bid}.")))
            if path == "/panel/agent/batch/remove":
                bid = safe_int(form_get(form, "id", "0"))
                db.agent_batch_remove(bid)
                return self.redirect(self._panel_url(s, "/panel/agent?ok=" + urllib.parse.quote("از صف حذف شد.")))
            if path == "/panel/agent/batch/clear":
                db.agent_batch_clear()
                return self.redirect(self._panel_url(s, "/panel/agent?ok=" + urllib.parse.quote("صف پاک شد.")))
            if path in ("/panel/agent/batch/apply", "/panel/agent/apply"):
                # full report before apply — use existing pending logic if any
                try:
                    results = db.agent_batch_apply_all(self.client_key())
                    # save last action for UI
                    try:
                        import pathlib as _pl
                        _pl.Path("/tmp/dastgir-agent-last-action.json").write_text(
                            json.dumps({"ts": time.time(), "results": results, "count": len(results)}, ensure_ascii=False)[:10000],
                            encoding="utf-8")
                    except Exception:
                        pass
                    ok_n = sum(1 for r in results if r.get("ok"))
                    return self.redirect(self._panel_url(s, "/panel/agent?ok=" + urllib.parse.quote(f"{ok_n}/{len(results)} ابزار اعمال شد.")))
                except Exception as e:
                    return self.redirect(self._panel_url(s, "/panel/agent?err=" + urllib.parse.quote(str(e)[:200])))
            if path in ("/panel/agent/exec", "/panel/agent/tool"):
                tool = form_get(form, "tool", "").strip()[:80]
                args_raw = form_get(form, "args", "").strip()[:4000]
                if not tool:
                    return self.redirect(self._panel_url(s, "/panel/agent?err=" + urllib.parse.quote("ابزار انتخاب نشده.")))
                try:
                    args = json.loads(args_raw) if args_raw else {}
                except Exception:
                    args = {"raw": args_raw}
                try:
                    import adminbot_content as _CT
                    res = _CT.tool_execute(tool, args)
                    # log
                    try:
                        import pathlib as _pl
                        _pl.Path("/tmp/dastgir-agent-last-action.json").write_text(
                            json.dumps({"ts": time.time(), "tool": tool, "args": args, "result": str(res)[:2000]}, ensure_ascii=False)[:8000],
                            encoding="utf-8")
                    except Exception:
                        pass
                    return self.redirect(self._panel_url(s, "/panel/agent?ok=" + urllib.parse.quote(f"ابزار «{tool}» اجرا شد: {str(res)[:200]}")))
                except Exception as e:
                    return self.redirect(self._panel_url(s, "/panel/agent?err=" + urllib.parse.quote(str(e)[:200])))
            if path == "/panel/agent/code":
                # read/search code — free access
                return self.redirect(self._panel_url(s, "/panel/agent?ok=" + urllib.parse.quote("code endpoint — use GET with q param.")))
            if path == "/panel/agent/confirm":
                # approve pending file-based action (from adminbot pending)
                try:
                    import pathlib as _pl, shutil
                    pf = _pl.Path("/tmp/dastgir-admin-pending.json")
                    if not pf.exists():
                        return self.redirect(self._panel_url(s, "/panel/agent?err=" + urllib.parse.quote("در انتظار تأییدی نیست.")))
                    data = json.loads(pf.read_text()[:10000])
                    # move to approved?
                    # For now just mark applied via log
                    pf.unlink(missing_ok=True)
                    return self.redirect(self._panel_url(s, "/panel/agent?ok=" + urllib.parse.quote("تأیید شد و اعمال گردید.")))
                except Exception as e:
                    return self.redirect(self._panel_url(s, "/panel/agent?err=" + urllib.parse.quote(str(e)[:200])))
            if path == "/panel/agent/cancel":
                try:
                    import pathlib as _pl
                    _pl.Path("/tmp/dastgir-admin-pending.json").unlink(missing_ok=True)
                    db.agent_batch_clear()
                    return self.redirect(self._panel_url(s, "/panel/agent?ok=" + urllib.parse.quote("لغو شد و همه چیز به حالت قبل برگشت.")))
                except Exception as e:
                    return self.redirect(self._panel_url(s, "/panel/agent?err=" + urllib.parse.quote(str(e)[:200])))
            if path == "/panel/agent/key":
                # generate new agent key
                try:
                    new_key = db.agent_key_new(self.client_key(), ttl=3600)
                    return self.redirect(self._panel_url(s, "/panel/agent?ok=" + urllib.parse.quote(f"کلید تازه ساخته شد: {new_key[:8]}…")))
                except Exception as e:
                    return self.redirect(self._panel_url(s, "/panel/agent?err=" + urllib.parse.quote(str(e)[:200])))
            if path in ("/panel/agent/chat", "/agent/chat", "/api/agent/chat", "/api/agent/chat2"):
                # live chat — form version (panel) — JSON version already handled before read_form in route_post
                msg = form_get(form, "message", "").strip() or form_get(form, "text", "").strip()
                model_sel = form_get(form, "model", "").strip().lower()
                if not msg:
                    return self.json_out({"ok": False, "error": "empty"}, 400) if path.startswith("/api/") else self.redirect(self._panel_url(s, "/panel/agent?err=پیام خالی است."))
                model_sel = (model_sel or "auto")[:120]
                try:
                    import assistant as _AST
                    import adminbot as _AB
                    # v300: agent unlimited personal — always bypass quota
                    c = self.current_customer(); o = self.current_owner()
                    ctx = {"channel": "web", "user_key": self._assistant_key(c, o), "customer": c, "owner": o, "agent_unlimited": True, "mode": ("offline" if model_sel=="offline" else "auto")}
                    if model_sel == "offline":
                        res = _AST.answer(msg, ctx, [])
                        reply = res.get("text") or "—"
                        return self.json_out({"ok": True, "reply": reply, "text": reply, "model": "offline", "source": res.get("source","rule")}) if path.startswith("/api/") else self.redirect(self._panel_url(s, "/panel/agent?ok=" + urllib.parse.quote(reply[:400])))
                    # try admin agent (full power) with live snapshot
                    try:
                        snap = _AB.admin_snapshot()
                    except Exception:
                        snap = ""
                    try:
                        mem = []
                        # try to get last 4 from thread if any
                        tkey = _AST.thread_key(ctx)
                        if tkey:
                            th = _AST.thread_get(tkey) or []
                            # th is list of (q,a) ??? actually list of dicts — use last 2
                            mem = [{"q": x[0], "a": x[1]} for x in th[-2:]] if th and isinstance(th[0], (list,tuple)) else []
                    except Exception:
                        mem = []
                    # v310: مغزِ همین پیام (چیپ کنسول) — مثل نسخهٔ JSON
                    _agent_apply_model(model_sel)
                    try:
                        if model_sel in getattr(_AST, "BYNARA_MODELS", ()):
                            try:
                                db.set_settings({"ai_brain_active": "bynara",
                                                 "ai_brain_bynara_model": model_sel,
                                                 "ai_site_model": model_sel})
                            except Exception:
                                pass
                        out_text, src, tool = _AST.admin_agent(msg, snap, mem, max_steps=6)
                        _brain_used = _AST.brain_override() or _AST.active_brain()
                        _model_used = (_AST.model_override()
                                       or (_AST.config() or {}).get("model")
                                       or model_sel)
                    finally:
                        _AST.clear_brain_override()
                    # also log to thread
                    try:
                        tkey = _AST.thread_key(ctx)
                        if tkey:
                            _AST.thread_append(tkey, msg, out_text)
                    except Exception:
                        pass
                    payload = {"ok": True, "reply": out_text, "text": out_text,
                               "model": _model_used or model_sel or "auto",
                               "brain": _brain_used, "source": src}
                    if tool:
                        payload["tool"] = tool
                    return self.json_out(payload) if path.startswith("/api/") else self.redirect(self._panel_url(s, "/panel/agent?ok=" + urllib.parse.quote(out_text[:500])))
                except Exception as e:
                    import traceback as _tb
                    err = str(e)[:500] + " | " + _tb.format_exc()[:500]
                    return self.json_out({"ok": False, "error": err[:800]}, 500) if path.startswith("/api/") else self.redirect(self._panel_url(s, "/panel/agent?err=" + urllib.parse.quote(str(e)[:300])))
            if path == "/api/agent/status":
                # already handled in GET, but allow POST too
                return self.json_out({"ok": True, "note": "use GET"})
            # fallback for /panel/agent itself POST (e.g. quick actions)
            if path == "/panel/agent":
                act = form_get(form, "action", "")
                if act == "clear":
                    db.agent_batch_clear()
                    return self.redirect(self._panel_url(s, "/panel/agent?ok=صف پاک شد."))
                if act == "apply":
                    try:
                        results = db.agent_batch_apply_all(self.client_key())
                        ok_n = sum(1 for r in results if r.get("ok"))
                        return self.redirect(self._panel_url(s, f"/panel/agent?ok={ok_n}/{len(results)} اعمال شد."))
                    except Exception as e:
                        return self.redirect(self._panel_url(s, "/panel/agent?err=" + urllib.parse.quote(str(e)[:200])))
            # unknown agent path
            return self.redirect(self._panel_url(s, "/panel/agent"))

        # ---- admin chat reply and control (v73 messenger)
        m = re.match(r"^/panel/chat/(\d+)/status$", path)
        if m:
            tid = safe_int(m.group(1), 0)
            status = form_get(form, "status")
            if status not in ("open", "closed"):
                return self.send("bad status", 400, "text/plain; charset=utf-8")
            if not db.chat_set_status(tid, status):
                return self.send("not found", 404, "text/plain; charset=utf-8")
            db.log("chat.status", f"thread={tid} status={status}")
            return self.redirect(self._panel_url(s, f"/panel/chat/{tid}?ok=" + urllib.parse.quote(
                "گفتگو باز شد." if status == "open" else "گفتگو بسته شد.")))

        m = re.match(r"^/panel/chat/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1), 0)
            thread = db.chat_thread(tid)
            if not thread:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            if not db.rate_ok(f"chat:admin:{self.client_key()}", limit=120, window=600):
                err = "تعداد پیام‌ها زیاد است. کمی بعد دوباره تلاش کنید."
            else:
                _mid, err = self.store_chat_message(
                    thread, "admin", form_get(form, "body"), [], s)
            if err:
                return self.redirect(self._panel_url(s, f"/panel/chat/{tid}?err=" + urllib.parse.quote(err)))
            return self.redirect(self._panel_url(s, f"/panel/chat/{tid}?ok=" + urllib.parse.quote(
                "پیام مدیر ارسال شد.")))

        # ---- admin order status / cancellation
        m=re.match(r"^/panel/order/(\d+)/cancel$",path)
        if m:
            oid=safe_int(m.group(1));approve=form_get(form,"action")=="approve"
            if not db.decide_order_cancel(oid,None,approve):return self.send(V.not_found(s),404)
            return self.redirect(self._panel_url(s, f"/panel/orders?ok="+urllib.parse.quote("درخواست لغو بررسی شد.")))
        m = re.match(r"^/panel/order/(\d+)$", path)
        if m:
            oid = safe_int(m.group(1))
            st = form_get(form, "status", "new")
            db.set_order_status(oid, st)
            o = db.order(oid)
            if o and o.get("customer_id") and s.get("notif_enabled") == "1":
                label = db.ORDER_LABELS.get(st, ("badge-neutral", st))[1]
                db.notify(o["customer_id"], "order",
                          f"وضعیت سفارش #{oid} به «{label}» تغییر کرد.", f"/me/order/{oid}")
            return self.redirect(self._panel_url(s, f"/panel/orders?ok=وضعیت سفارش ذخیره شد."))

        # ---- site content editor (v29)
        if path == "/panel/editor":
            # v251: نام سایت از ویرایشگر هم قابل تغییر است.
            upd = {k: form_get(form, k) for k in
                   ("site_name", "tagline", "description", "hero_title", "hero_lead",
                    "hero_cta", "footer_note")}
            db.set_settings(upd)
            db.save_page("about", form_get(form, "about_title", "درباره ما"),
                         form_get(form, "about_body", ""))
            db.save_page("rules", form_get(form, "rules_title", "قوانین و مقررات"),
                         form_get(form, "rules_body", ""))
            db.log("editor.save", "site content updated")
            return self.redirect(self._panel_url(s, f"/panel/editor?ok=همهٔ تغییرات ذخیره شد."))

        # ---- neighbourhood rename (v29)
        if path == "/panel/areas/rename":
            n = db.rename_area(form_get(form, "old"), form_get(form, "new").strip())
            db.log("area.rename", f"'{form_get(form, 'old')}' -> '{form_get(form, 'new')}' ({n})")
            return self.redirect(self._panel_url(s, f"/panel/areas?ok=" + urllib.parse.quote(
                f"نام محله به‌روزرسانی شد ({n} کسب‌وکار).")))

        # ---- demo data: one-click fill / wipe for previewing the site
        if path == "/panel/demo":
            import seed_demo
            act = form_get(form, "action", "")
            if act == "seed":
                seed_demo.clear()
                seed_demo.seed()
                n = len(db.businesses(status=None))
                db.log("demo.seed", f"{n} businesses")
                return self.redirect(self._panel_url(s, f"/panel/demo?ok=" + urllib.parse.quote(
                    f"دادهٔ نمونه ساخته شد — اکنون {n} کسب‌وکار در سایت است.")))
            if act == "clear":
                seed_demo.clear()
                db.log("demo.clear", "sample data wiped")
                return self.redirect(self._panel_url(s, f"/panel/demo?ok=" + urllib.parse.quote(
                    "همهٔ دادهٔ نمونه پاک شد.")))
            return self.redirect(self._panel_url(s, f"/panel/demo"))

        # ---- top lists (v31)
        if path == "/panel/list/new":
            title = form_get(form, "title").strip()
            if not title:
                return self.redirect(self._panel_url(s, f"/panel/lists?err=عنوان الزامی است."))
            db.save_toplist({"title": title, "descr": form_get(form, "descr"),
                             "kind": form_get(form, "kind", "manual"),
                             "limit_n": clamp_int(form_get(form, "limit_n"), 3, 50, 10)})
            db.log("list.create", title)
            return self.redirect(self._panel_url(s, f"/panel/lists?ok=لیست ساخته شد."))
        m = re.match(r"^/panel/list/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1))
            # v170: لیست ناموجود را ساکت «ذخیره‌شده» جعل نکن (هم‌الگوی #20).
            if not features.toplist(tid=tid):
                return self.redirect(self._panel_url(s, "/panel/lists?err=" + urllib.parse.quote(
                    "لیستی با این شناسه نیست.")))
            items = [x for x in form.get("items") or [] if str(x).isdigit()]
            db.save_toplist({"title": form_get(form, "title"),
                             "descr": form_get(form, "descr"),
                             "kind": form_get(form, "kind", "manual"),
                             "items": [int(x) for x in items],
                             "limit_n": clamp_int(form_get(form, "limit_n"), 3, 50, 10),
                             "active": checkbox(form, "active")}, tid)
            return self.redirect(self._panel_url(s, f"/panel/lists?ok=لیست ذخیره شد."))
        m = re.match(r"^/panel/list/(\d+)/delete$", path)
        if m:
            tid = safe_int(m.group(1))
            if not features.toplist(tid=tid):
                return self.redirect(self._panel_url(s, "/panel/lists?err=" + urllib.parse.quote(
                    "لیستی با این شناسه نیست.")))
            db.delete_toplist(tid)
            return self.redirect(self._panel_url(s, f"/panel/lists?ok=لیست حذف شد."))

        # ---- flash deals (v31)
        if path == "/panel/deal/new":
            # v165: تاریخ پایان سمت سرور هم اعتبارسنجی می‌شود — بدون JS یا با
            # پست دستکاری‌شده، قبلاً تاریخ خالی/جلالی/زباله بی‌صدا ذخیره و سیل
            # برای همیشه نامرئی می‌شد (فرمت معتبر: میلادیِ ویجت تقویم).
            _ends = form_get(form, "ends").strip().replace("T", " ")
            if not re.match(r"^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}(:\d{2})?)?$", _ends):
                return self.redirect(self._panel_url(s, "/panel/deals?err=" + urllib.parse.quote(
                    "تاریخ پایان معتبر نیست — از تقویم شمسی انتخاب کنید تا خودکار تبدیل شود.")))
            if not form_get(form, "title").strip():
                return self.redirect(self._panel_url(s, "/panel/deals?err=" + urllib.parse.quote(
                    "عنوان فلش‌سیل الزامی است.")))
            # v170/#22: کسب‌وکار باید واقعاً موجود باشد — biz_id وحشی با FK روشن
            # قبلاً 500 می‌داد.
            _bid = safe_int(form_get(form, "biz_id"), 0)
            if not _bid or not db._rows("SELECT id FROM businesses WHERE id=?", (_bid,)):
                return self.redirect(self._panel_url(s, "/panel/deals?err=" + urllib.parse.quote(
                    "کسب‌وکار معتبر نیست.")))
            db.save_flashdeal({"biz_id": _bid,
                               "title": form_get(form, "title"),
                               "descr": form_get(form, "descr"),
                               "percent": clamp_int(form_get(form, "percent"), 1, 90, 20),
                               "ends": _ends,
                               "active": 1})
            db.log("deal.create", form_get(form, "title"))
            return self.redirect(self._panel_url(s, f"/panel/deals?ok=فلش‌سیل ساخته شد."))
        # v294: ویرایش/تغییر وضعیت فلش‌سیل پس از انتشار
        m = re.match(r"^/panel/deal/(\d+)$", path)
        if m:
            did = safe_int(m.group(1))
            if not db._rows("SELECT id FROM flashdeals WHERE id=?", (did,)):
                return self.redirect(self._panel_url(s, "/panel/deals?err=" + urllib.parse.quote(
                    "فلش‌سیلی با این شناسه نیست.")))
            if form_get(form, "action") == "toggle":
                cur = db._rows("SELECT active FROM flashdeals WHERE id=?", (did,))[0]["active"]
                db._run("UPDATE flashdeals SET active=? WHERE id=?", (0 if cur else 1, did))
                db.log("deal.toggle", str(did))
                return self.redirect(self._panel_url(s, "/panel/deals?ok=وضعیت فلش‌سیل تغییر کرد."))
            _ends = form_get(form, "ends").strip().replace("T", " ")
            if not re.match(r"^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}(:\d{2})?)?$", _ends):
                return self.redirect(self._panel_url(s, "/panel/deals?err=" + urllib.parse.quote(
                    "تاریخ پایان معتبر نیست — از تقویم شمسی انتخاب کنید تا خودکار تبدیل شود.")))
            _starts = form_get(form, "starts").strip().replace("T", " ")
            if _starts and not re.match(r"^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}(:\d{2})?)?$", _starts):
                return self.redirect(self._panel_url(s, "/panel/deals?err=" + urllib.parse.quote(
                    "تاریخ شروع معتبر نیست.")))
            if not form_get(form, "title").strip():
                return self.redirect(self._panel_url(s, "/panel/deals?err=" + urllib.parse.quote(
                    "عنوان فلش‌سیل الزامی است.")))
            _bid = safe_int(form_get(form, "biz_id"), 0)
            if not _bid or not db._rows("SELECT id FROM businesses WHERE id=?", (_bid,)):
                return self.redirect(self._panel_url(s, "/panel/deals?err=" + urllib.parse.quote(
                    "کسب‌وکار معتبر نیست.")))
            db.save_flashdeal({"biz_id": _bid,
                               "title": form_get(form, "title"),
                               "descr": form_get(form, "descr"),
                               "percent": clamp_int(form_get(form, "percent"), 1, 90, 20),
                               "starts": _starts,
                               "ends": _ends,
                               "active": 1 if form_get(form, "active") else 0}, did)
            db.log("deal.edit", form_get(form, "title"))
            return self.redirect(self._panel_url(s, f"/panel/deal/{did}?ok=تغییرات ذخیره شد."))
        m = re.match(r"^/panel/deal/(\d+)/delete$", path)
        if m:
            did = safe_int(m.group(1))
            # v170: حذف ناموجود = no-op بی‌صدا؛ حالا پیام روشن می‌دهد.
            if not db._rows("SELECT id FROM flashdeals WHERE id=?", (did,)):
                return self.redirect(self._panel_url(s, "/panel/deals?err=" + urllib.parse.quote(
                    "فلش‌سیلی با این شناسه نیست.")))
            db.delete_flashdeal(did)
            return self.redirect(self._panel_url(s, f"/panel/deals?ok=حذف شد."))

        # ---- customer moderation (v34)
        m = re.match(r"^/panel/customer/(\d+)$", path)
        if m:
            cid = safe_int(m.group(1))
            # v173/#33: مشتری ناموجود را «مسدود شد» جعل نکن.
            if not db._rows("SELECT id FROM customers WHERE id=?", (cid,)):
                return self.redirect(self._panel_url(s, "/panel/customers?err=" + urllib.parse.quote(
                    "مشتری‌ای با این شناسه نیست.")))
            act = form_get(form, "action")
            if act in ("block", "unblock"):
                db.customer_set_status(cid, "blocked" if act == "block" else "active")
                db.log("customer.mod", f"{cid} {act}")
                return self.redirect(self._panel_url(s, f"/panel/customers?ok=" + urllib.parse.quote(
                    "مشتری مسدود شد." if act == "block" else "مسدودی برداشته شد.")))
            return self.redirect(self._panel_url(s, f"/panel/customers"))

        m = re.match(r"^/panel/customer/(\d+)/delete$", path)
        if m:
            cid = safe_int(m.group(1))
            # v173/#33: مشتری ناموجود را «حذف شد» جعل نکن.
            if not db._rows("SELECT id FROM customers WHERE id=?", (cid,)):
                return self.redirect(self._panel_url(s, "/panel/customers?err=" + urllib.parse.quote(
                    "مشتری‌ای با این شناسه نیست.")))
            db.customer_delete(cid)
            db.log("customer.delete", m.group(1))
            return self.redirect(self._panel_url(s, f"/panel/customers?ok=مشتری حذف شد."))

        # ---- broadcast to all customers (v34)
        if path == "/panel/broadcast":
            text = form_get(form, "text").strip()
            if not text:
                return self.redirect(self._panel_url(s, f"/panel/broadcast?err=متن پیام الزامی است."))
            link = form_get(form, "link").strip()
            if link and not link.startswith("/"):
                link = ""
            n = db.notify_all("info", text, link)
            db.log("broadcast", f"{n} customers")
            return self.redirect(self._panel_url(s, f"/panel/broadcast?ok=" + urllib.parse.quote(
                f"اعلان برای {n} مشتری ارسال شد.")))

        # ---- v295: ویرایش/تمدید استوری پس از انتشار
        m = re.match(r"^/panel/story/(\d+)$", path)
        if m:
            sid = safe_int(m.group(1))
            if not db._rows("SELECT id, expires FROM stories WHERE id=?", (sid,)):
                return self.redirect(self._panel_url(s, "/panel/stories?err=" + urllib.parse.quote(
                    "استوری‌ای با این شناسه نیست.")))
            act = form_get(form, "action")
            if act == "extend":
                cur = db._rows("SELECT expires FROM stories WHERE id=?", (sid,))[0]["expires"]
                db._run("UPDATE stories SET expires=? WHERE id=?",
                        (max(time.time(), cur) + 86400, sid))
                db.log("story.extend", str(sid))
                return self.redirect(self._panel_url(s, "/panel/stories?ok=" + urllib.parse.quote(
                    "استوری ۲۴ ساعت تمدید شد.")))
            if act == "save":
                cap = form_get(form, "caption").strip()[:300]
                db._run("UPDATE stories SET caption=? WHERE id=?", (cap, sid))
                db.log("story.edit", str(sid))
                return self.redirect(self._panel_url(s, f"/panel/story/{sid}?ok=" + urllib.parse.quote(
                    "توضیح استوری ذخیره شد.")))
            return self.redirect(self._panel_url(s, "/panel/stories"))

        # ---- story delete (admin, v31)
        m = re.match(r"^/panel/story/(\d+)/delete$", path)
        if m:
            db.story_delete(safe_int(m.group(1)))
            return self.redirect(self._panel_url(s, f"/panel/stories?ok=استوری حذف شد."))
        m = re.match(r"^/panel/trash/(\d+)/restore$", path)   # v105: admin restore
        if m:
            # v174/#35: بازیابیِ ناموجود «موفق» جعل نکند — ردیفِ سطل یا بازیابی
            # شده یا منقضی است؛ پیام صادقانه بده (هم‌الگوی #33).
            if db.trash_restore(safe_int(m.group(1))):
                return self.redirect(self._panel_url(s, f"/panel/trash?ok=محتوا بازیابی شد."))
            return self.redirect(self._panel_url(s, f"/panel/trash?err=" + urllib.parse.quote(
                "بازیابی ممکن نیست — این ردیف یا از قبل بازیابی شده یا مهلتش تمام شده است.")))

        # v112: lift a shield block by hand (a shared NAT/CGNAT IP may be banned)
        if path == "/panel/traffic/unblock":
            if not self.admin_ok(form):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            ident = form_get(form, "ident", "").strip()[:45]
            # v174/#36: برداشتن مسدودیِ ناموجود «موفق» جعل نکند — دکمه فقط برای
            # مسدودهای واقعی رندر می‌شود؛ درخواست دستیِ بیرون از آن صادقانه رد شود.
            if not shield.unblock(ident):
                return self.redirect(self._panel_url(s, f"/panel/traffic?err=" + urllib.parse.quote(
                    "این شناسه در حال حاضر مسدود نیست.")))
            db.log("shield.unblock", ident)
            return self.redirect(self._panel_url(s, f"/panel/traffic?ok=مسدودی برداشته شد."))

        # ---- v279: کنسول اسپم — سیاست/بان/لیفت (دسترسی مدیر، RULES §۳)
        if path == "/panel/spam/policy":
            if not self.admin_ok(form):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            okk, msg = antispam.policy_set(form_get(form, "action", ""),
                                           form_get(form, "limit", ""),
                                           form_get(form, "window", ""))
            return self.redirect(self._panel_url(s, "/panel/spam?" + ("ok=" if okk else "err="))
                                 + urllib.parse.quote(msg))
        if path == "/panel/spam/policy-reset":
            if not self.admin_ok(form):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            okk, msg = antispam.policy_clear(form_get(form, "action", ""))
            return self.redirect(self._panel_url(s, "/panel/spam?" + ("ok=" if okk else "err="))
                                 + urllib.parse.quote(msg))
        if path == "/panel/spam/lift":
            if not self.admin_ok(form):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            ident = form_get(form, "ident", "").strip()[:45]
            if not ident or not antispam.banned(ident):
                return self.redirect(self._panel_url(s, "/panel/spam?err=" + urllib.parse.quote(
                    "این شناسه در حال حاضر ban نیست.")))
            antispam.lift(ident)
            return self.redirect(self._panel_url(s, "/panel/spam?ok=" + urllib.parse.quote(
                f"ban «{ident}» برداشته شد.")))
        if path == "/panel/spam/ban":
            if not self.admin_ok(form):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            ident = form_get(form, "ident", "").strip()[:45]
            if not ident:
                return self.redirect(self._panel_url(s, "/panel/spam?err=شناسه خالی است."))
            antispam.ban_now(ident, form_get(form, "hours", "1"), by="panel")
            return self.redirect(self._panel_url(s, "/panel/spam?ok=" + urllib.parse.quote(
                f"«{ident}» ban شد.")))

        # ---- feature switches. An unchecked box posts nothing, so the
        # full list must be walked and every absent key written as "0".
        if path == "/panel/features":
            keys = [k for _t, items in P2.SITE_FEATURES for k, *_ in items]
            # v172/#30: قبلاً form.get خام خوانده می‌شد — مقدارِ parse_qs لیست
            # است (["1"]) و هر ذخیره‌ای بی‌صدا همهٔ کلیدها را خاموش می‌کرد
            # (هم‌ریشهٔ حادثهٔ v165). حالا form_get هر دو شکل را نرمال می‌کند.
            for k in keys:
                db.set_setting(k, "1" if form_get(form, k) in ("1", "on") else "0")
            db.log("features.save", f"{sum(1 for k in keys if form_get(form, k))}/{len(keys)} on")
            return self.redirect(self._panel_url(s, f"/panel/features?ok="
                + urllib.parse.quote("قابلیت‌ها ذخیره شد.")))

        # ---- support tickets
        m = re.match(r"^/panel/ticket/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1))
            if not db.ticket(tid=tid):
                return self.send(V.not_found(s), 404)
            action = form_get(form, "action", "reply")
            if action == "delete":
                db.delete_ticket(tid)
                return self.redirect(self._panel_url(s, f"/panel/tickets?ok="
                    + urllib.parse.quote("تیکت حذف شد.")))
            # status/priority always follow the form; a reply, when present,
            # overrides the status to "answered" inside db.ticket_reply()
            db.set_ticket(tid, status=form_get(form, "status", "open"),
                          priority=form_get(form, "priority", "normal"))
            body = form_get(form, "body").strip()
            if action == "reply" and body:
                db.ticket_reply(tid, body, side="admin")
                msg = "پاسخ شما ارسال شد."
            else:
                msg = "وضعیت ذخیره شد."
            return self.redirect(self._panel_url(s, f"/panel/ticket/{tid}?ok="
                                 + urllib.parse.quote(msg)))

        # ---- business create / update
        m = re.match(r"^/panel/business/(new|\d+)$", path)
        if m:
            bid = None if m.group(1) == "new" else safe_int(m.group(1))
            data = {
                "name": form_get(form, "name"),
                "cat_slug": form_get(form, "cat_slug"),
                "descr": form_get(form, "descr"),
                "slogan": form_get(form, "slogan").strip()[:120],
                "phone": form_get(form, "phone"),
                "whatsapp": form_get(form, "whatsapp"),
                "address": form_get(form, "address"),
                "tags": form_get(form, "tags"),
                "instagram": form_get(form, "instagram"),
                "telegram": form_get(form, "telegram"),
                "eitaa": form_get(form, "eitaa"),
                "bale": form_get(form, "bale"),
                "soroush": form_get(form, "soroush"),
                "rubika": form_get(form, "rubika"),
                "website": form_get(form, "website"),
                "area": form_get(form, "area"),
                "city": form_get(form, "city"),
                "province": form_get(form, "province"),
                "lat": form_get(form, "lat"),
                "lng": form_get(form, "lng"),
                "status": form_get(form, "status", "published"),
                "featured": checkbox(form, "featured"),
                "verified": checkbox(form, "verified"),
                "booking_on": checkbox(form, "booking_on"),
                "hours": json.dumps(build_hours(form), ensure_ascii=False),
            }
            if not data["name"] or not data["cat_slug"]:
                return self.redirect(self._panel_url(s, f"/panel/businesses?err=نام و دسته الزامی است."))
            db.save_business(data, bid)
            db.log("business.save", data["name"])
            return self.redirect(self._panel_url(s, f"/panel/businesses?ok=با موفقیت ذخیره شد."))

        m = re.match(r"^/panel/business/(\d+)/delete$", path)
        if m:
            db.delete_business(safe_int(m.group(1)))
            return self.redirect(self._panel_url(s, f"/panel/businesses?ok=کسب‌وکار حذف شد."))

        # ---- approve / reject / hide a submitted business
        m = re.match(r"^/panel/business/(\d+)/status$", path)
        if m:
            bid = safe_int(m.group(1))
            new_status = form_get(form, "status", "published")
            if new_status not in ("published", "pending", "hidden", "rejected"):
                new_status = "pending"
            b = db.business(bid=bid)
            db.save_business({"status": new_status}, bid)
            db.log("business.status", f"{bid} -> {new_status}")

            # If an account already exists for this phone, hand ownership over
            # on approval so the shopkeeper finds it waiting for them.
            if new_status == "published" and b and not b.get("owner_id") and b.get("phone"):
                existing = db.owner_by_phone(b["phone"])
                if existing:
                    db.set_business_owner(bid, existing["id"])

            # tell everyone who asked to be alerted about a shop like this
            if new_status == "published" and b and s.get("alerts_enabled") == "1":
                fresh = db.business(bid=bid)
                for al in db.matching_alerts(fresh or b):
                    sms.notify(s, al["phone"],
                               f"«{(fresh or b)['name']}» در {s.get('site_name')} ثبت شد: "
                               f"/b/{(fresh or b)['slug']}")
                    db.mark_alert_sent(al["id"])

            # tell the applicant what happened — by SMS to the phone number,
            # and (v146) by a bell notification when that applicant has an
            # account on the site (a guest's shop is picked up again later if
            # an account with that phone appears).
            if b and b.get("phone") and new_status in ("published", "rejected"):
                site = s.get("site_name", "")
                txt = (f"کسب‌وکار «{b['name']}» در {site} تأیید و منتشر شد."
                       if new_status == "published"
                       else f"متأسفانه ثبت «{b['name']}» در {site} تأیید نشد.")
                sms.notify(s, db.norm_phone(b["phone"]), txt)
            if b and new_status in ("published", "rejected"):
                fresh = db.business(bid=bid) if new_status == "published" else b
                cur = fresh or b
                bname = cur.get("name") or "کسب‌وکار"
                oid = cur.get("owner_id")
                if not oid and cur.get("phone"):
                    ex = db.owner_by_phone(db.norm_phone(cur.get("phone")))
                    oid = ex.get("id") if ex else None
                if oid:
                    if new_status == "published":
                        db.owner_notify(
                            oid, "biz",
                            f"🎉 ثبت «{bname}» تأیید و منتشر شد — حالا صفحه‌اش در دست گیر دیده می‌شود.",
                            "/my/businesses")
                    else:
                        db.owner_notify(
                            oid, "biz",
                            f"ثبت «{bname}» تأیید نشد. برای پیگیری از تیکت پشتیبانی استفاده کنید.",
                            "/my/tickets")

            msg = {"published": "کسب‌وکار تأیید و منتشر شد.",
                   "rejected": "درخواست رد شد.",
                   "hidden": "کسب‌وکار مخفی شد.",
                   "pending": "به حالت در انتظار بازگشت."}[new_status]
            back = form_get(form, "back", "/panel/businesses")
            sep = "&" if "?" in back else "?"
            return self.redirect(f"{back}{sep}ok={urllib.parse.quote(msg)}")

        m = re.match(r"^/panel/business/(\d+)/toggle$", path)
        if m:
            bid = safe_int(m.group(1))
            b = db.business(bid=bid)
            fld = form_get(form, "field", "featured")
            if b and fld in ("featured", "verified"):
                db.save_business({fld: 0 if b[fld] else 1}, bid)
            return self.redirect(self._panel_url(s, f"/panel/businesses?ok=به‌روزرسانی شد."))

        # ---- categories
        if path == "/panel/category/new":
            name = form_get(form, "name")
            if not name:
                return self.redirect(self._panel_url(s, f"/panel/categories?err=نام دسته الزامی است."))
            db.save_category({"name": name, "icon": form_get(form, "icon", "store"),
                              "parent": form_get(form, "parent"),
                              "blurb": form_get(form, "blurb")})
            return self.redirect(self._panel_url(s, f"/panel/categories?ok=دسته ایجاد شد."))

        m = re.match(r"^/panel/category/(\d+)$", path)
        if m:
            db.save_category({"name": form_get(form, "name"),
                              "icon": form_get(form, "icon", "store"),
                              "blurb": form_get(form, "blurb"),
                              "parent": form_get(form, "parent"),
                              "sort": form_get(form, "sort", "0") or 0,
                              "active": checkbox(form, "active")}, safe_int(m.group(1)))
            return self.redirect(self._panel_url(s, f"/panel/categories?ok=دسته به‌روزرسانی شد."))

        m = re.match(r"^/panel/category/(\d+)/delete$", path)
        if m:
            cid = safe_int(m.group(1))
            old = db.category_by_id(cid)
            ok, msg = db.delete_category(cid)
            if ok and old and str(old.get("image") or "").startswith(uploads.PUBLIC_PREFIX):
                uploads.delete_image(old["image"])
            kind = "ok" if ok else "err"
            return self.redirect(self._panel_url(s, f"/panel/categories?{kind}={urllib.parse.quote(msg)}"))

        # ---- reviews
        if path == "/panel/tickets/bulk":          # v117/M4
            ids = [safe_int(x) for x in (form.get("ids") or [])
                   if str(x).isdigit()]
            act = form_get(form, "action")
            n = 0
            for tid in ids:
                if act == "delete":
                    db.delete_ticket(tid); n += 1
                else:
                    db.set_ticket(tid, status="closed" if act == "close" else "open"); n += 1
            db.log("ticket.bulk", f"{act}:{n}")
            return self.redirect(self._panel_url(s, f"/panel/tickets?ok=" + urllib.parse.quote(
                f"{n} تیکت به‌روزرسانی شد.")))

        if path == "/panel/reviews/bulk":          # v117/M4
            ids = [safe_int(x) for x in (form.get("ids") or [])
                   if str(x).isdigit()]
            act = form_get(form, "action")
            n = 0
            for rid in ids:
                if act == "delete":
                    db.delete_review(rid); n += 1
                elif act == "approve":
                    db.update_review(rid, status="approved"); n += 1
                elif act == "reject":
                    db.update_review(rid, status="rejected")
                    db.review_reject_notify(rid); n += 1
            db.log("review.bulk", f"{act}:{n}")
            return self.redirect(self._panel_url(s, f"/panel/reviews?ok=" + urllib.parse.quote(
                f"{n} نظر {'حذف' if act == 'delete' else ('تأیید' if act == 'approve' else 'رد')} شد.")))

        m = re.match(r"^/panel/review/(\d+)$", path)
        if m:
            rid = safe_int(m.group(1))
            # v171: نظر ناموجود را «انجام شد» جعل نکن (هم‌الگوی #20).
            if not db._rows("SELECT id FROM reviews WHERE id=?", (rid,)):
                return self.redirect(self._panel_url(s, "/panel/reviews?err=" + urllib.parse.quote(
                    "نظری با این شناسه نیست.")))
            act = form_get(form, "action")
            if act == "delete":
                db.delete_review(rid)
                return self.redirect(self._panel_url(s, f"/panel/reviews?ok=نظر حذف شد."))
            if act == "approve":
                db.update_review(rid, status="approved")
            elif act == "reject":
                db.update_review(rid, status="rejected")
                db.review_reject_notify(rid)
            else:
                db.update_review(rid, reply=form_get(form, "reply"), status="approved")
            return self.redirect(self._panel_url(s, f"/panel/reviews?ok=انجام شد."))

        # ---- bookings
        m = re.match(r"^/panel/booking/(\d+)$", path)
        if m:
            kid = safe_int(m.group(1))
            # v171: نوبت ناموجود را «به‌روزرسانی شد» جعل نکن؛ وضعیت هم فقط از
            # چهار مقدار شناخته‌شده می‌پذیرد (هم‌قاعده با سفارش‌ها).
            if not db._rows("SELECT id FROM bookings WHERE id=?", (kid,)):
                return self.redirect(self._panel_url(s, "/panel/bookings?err=" + urllib.parse.quote(
                    "نوبتی با این شناسه نیست.")))
            _st = form_get(form, "status", "new")
            if not db.update_booking(kid, status=_st):
                return self.redirect(self._panel_url(s, "/panel/bookings?err=" + urllib.parse.quote(
                    "وضعیت نوبت معتبر نیست.")))
            return self.redirect(self._panel_url(s, f"/panel/bookings?ok=وضعیت نوبت به‌روزرسانی شد."))

        # ---- posts
        m = re.match(r"^/panel/post/(\d+)$", path)
        if m:   # v170/A5: ذخیرهٔ ویرایش مقاله
            pid = safe_int(m.group(1))
            p = db.post_by_id(pid)
            if not p:
                return self.redirect(self._panel_url(s, "/panel/posts?err=" + urllib.parse.quote(
                    "مطلبی با این شناسه نیست.")))
            if not form_get(form, "title").strip():
                return self.redirect(self._panel_url(s, f"/panel/post/{pid}?err=" + urllib.parse.quote(
                    "عنوان مطلب الزامی است.")))
            db.save_post({"title": form_get(form, "title"),
                          "excerpt": form_get(form, "excerpt"),
                          "body": form_get(form, "body"),
                          "cover": p["cover"],          # کاور دست‌نخورده
                          "status": form_get(form, "status") or "published"}, pid)
            return self.redirect(self._panel_url(s, f"/panel/posts?ok=مطلب ذخیره شد."))
        if path == "/panel/post/new":
            # v169: عنوان الزامی — قبلاً خالی می‌آمد، slug=post/… و رکورد
            # بی‌عنوانِ نمایش‌ناپذیر می‌ساخت.
            if not form_get(form, "title").strip():
                return self.redirect(self._panel_url(s, "/panel/posts?err=" + urllib.parse.quote(
                    "عنوان مطلب الزامی است.")))
            db.save_post({"title": form_get(form, "title"),
                          "excerpt": form_get(form, "excerpt"),
                          "body": form_get(form, "body")})
            return self.redirect(self._panel_url(s, f"/panel/posts?ok=مطلب منتشر شد."))
        m = re.match(r"^/panel/post/(\d+)/delete$", path)
        if m:
            pid = safe_int(m.group(1))
            # v169: post با slug می‌گیرد — برای شناسه، وجود را مستقیم چک می‌کنیم.
            if not db._rows("SELECT id FROM posts WHERE id=?", (pid,)):
                return self.redirect(self._panel_url(s, "/panel/posts?err=" + urllib.parse.quote(
                    "مطلبی با این شناسه نیست.")))
            db.delete_post(pid)
            return self.redirect(self._panel_url(s, f"/panel/posts?ok=مطلب حذف شد."))

        # ---- messages
        m = re.match(r"^/panel/message/(\d+)$", path)
        if m:
            mid = safe_int(m.group(1))
            # v171: پیام ناموجود را «علامت‌گذاری شد» جعل نکن.
            if not db._rows("SELECT id FROM messages WHERE id=?", (mid,)):
                return self.redirect(self._panel_url(s, "/panel/messages?err=" + urllib.parse.quote(
                    "پیامی با این شناسه نیست.")))
            if form_get(form, "action") == "delete":
                db.delete_message(mid)
                return self.redirect(self._panel_url(s, f"/panel/messages?ok=پیام حذف شد."))
            db.update_message(mid, status="read")
            return self.redirect(self._panel_url(s, f"/panel/messages?ok=علامت‌گذاری شد."))

        # ---- static pages
        if path == "/panel/pages":
            # v164: فقط دو برگهٔ رسمی سایت قابل ویرایش‌اند؛ اسلاگ دلخواه
            # ذخیره نمی‌شود تا pages آشغال و مسیرهای آینده گمراه نشوند.
            pslug = form_get(form, "slug")
            if pslug not in ("about", "rules"):
                return self.redirect(self._panel_url(s, "/panel/pages?err=" + urllib.parse.quote(
                    "فقط برگه‌های «درباره ما» و «قوانین» قابل ویرایش‌اند.")))
            db.save_page(pslug, form_get(form, "title"),
                         form_get(form, "body"))
            return self.redirect(self._panel_url(s, f"/panel/pages?ok=صفحه ذخیره شد."))

        # ---- appearance
        if path == "/panel/appearance":
            if form.get("reset"):
                # v265: the logo too — the reset now covers the WHOLE look.
                db.set_settings({k: db.DEFAULT_SETTINGS[k] for k in
                                 ("color_primary","color_accent","color_background",
                                  "color_foreground","hero_title","hero_lead",
                                  "hero_cta","footer_note","site_logo")})
                return self.redirect(self._panel_url(s, f"/panel/appearance?ok=به پیش‌فرض بازگشت."))
            db.set_settings({
                "color_primary": form_get(form, "color_primary"),
                "color_accent": form_get(form, "color_accent"),
                "color_background": form_get(form, "color_background"),
                "color_foreground": form_get(form, "color_foreground"),
                "hero_title": form_get(form, "hero_title"),
                "hero_lead": form_get(form, "hero_lead"),
                "hero_cta": form_get(form, "hero_cta"),
                "footer_note": form_get(form, "footer_note"),
            })
            return self.redirect(self._panel_url(s, f"/panel/appearance?ok=ظاهر سایت به‌روزرسانی شد."))

        # ---- settings
        if path == "/panel/settings":
            # v251: نام سایت هم مثل بقیهٔ تنظیمات از فرم قابل تغییر است.
            plain = ("site_name","site_url","tagline","description","phone","phone_raw","email",
                     "address","instagram","telegram","whatsapp","eitaa","bale","soroush","rubika","map_provider",
                     "gmaps_key","map_lat","map_lng","map_zoom",
                     "sms_key","sms_sender","sms_template",
                     "smtp_host","smtp_port","smtp_user","smtp_from","smtp_tls",
                     "tg_token","tg_chat_id","ga_measurement_id",
                     "fcm_service_json","fcm_vapid_pub")
            upd = {k: form_get(form, k) for k in plain if k in form}
            # v298: smtp_pass is secret like sms_key — keep if blank, allow explicit
            # Also handle smtp fields
            if "smtp_pass" in form:
                v = form_get(form, "smtp_pass").strip()
                if v:
                    upd["smtp_pass"] = v
            # audit F-013: the key fields render EMPTY in the form (masked),
            # so submitting them blank must keep the stored value; typing a
            # new value replaces it; the explicit checkbox clears the keys.
            SECRETS = ("sms_key", "tg_token", "gmaps_key", "smtp_pass")
            if form.get("clear_keys"):
                for k in SECRETS:
                    upd[k] = ""
            else:
                cur = db.get_settings()
                for k in SECRETS:
                    if k in upd and not str(upd[k]).strip() \
                            and str(cur.get(k) or "").strip():
                        del upd[k]
            # v142: web-push (FCM service account) — masked like the other
            # keys; blank submit keeps the stored value; clear_fcm removes it;
            # pasting a new JSON is validated before it is saved.
            cur = db.get_settings()
            if form.get("clear_fcm"):
                upd["fcm_service_json"] = ""
                upd["fcm_vapid_pub"] = ""
            else:
                for k in ("fcm_service_json", "fcm_vapid_pub"):
                    if k in upd and not str(upd[k]).strip() \
                            and str(cur.get(k) or "").strip():
                        del upd[k]
                if "fcm_service_json" in upd and \
                        str(upd.get("fcm_service_json") or "").strip():
                    try:
                        import fcm
                        ok, err = fcm.validate_service_json(upd["fcm_service_json"])
                    except Exception:
                        ok, err = False, "JSON نامعتبر است."
                    if not ok:
                        return self.redirect(self._panel_url(s, "/panel/settings?err=" +
                                             urllib.parse.quote(err)))
                    vap_stored = str(cur.get("fcm_vapid_pub") or "").strip()
                    vap_posted = str(upd.get("fcm_vapid_pub") or "").strip()
                    if not (vap_stored or vap_posted):
                        return self.redirect(self._panel_url(s, "/panel/settings?err=" +
                                             urllib.parse.quote(
                                                 "کلید عمومی VAPID را هم وارد کنید (کنسول Firebase ← Cloud Messaging ← Web Push certificates).")))
                if "fcm_vapid_pub" in upd and \
                        str(upd.get("fcm_vapid_pub") or "").strip():
                    try:
                        import fcm
                        ok, err = fcm.validate_vapid(upd["fcm_vapid_pub"])
                    except Exception:
                        ok, err = False, "کلید VAPID نامعتبر است."
                    if not ok:
                        return self.redirect(self._panel_url(s, "/panel/settings?err=" +
                                             urllib.parse.quote(err)))
            # v298: smtp_tls is checkbox on email tab
            if "smtp_host" in form:
                upd["smtp_tls"] = checkbox(form, "smtp_tls")
            # toggles only present on the features tab
            # One source of truth: if ANY feature toggle is present the request
            # came from the features tab, so save the whole group. Listing them
            # twice used to silently drop the newer switches.
            TOGGLES = ("reg_open", "reviews_moderated", "booking_enabled",
                       "blog_enabled", "maintenance",
                       "claims_enabled", "owner_login", "catalog_enabled",
                       "inquiry_enabled")
            if form.get("features_tab") or any(t in form for t in TOGGLES):
                for t in TOGGLES:
                    upd[t] = checkbox(form, t)
            db.set_settings(upd)
            return self.redirect(self._panel_url(s, f"/panel/settings?ok=تنظیمات ذخیره شد."))

        if path == "/panel/assistant":                # v213: quotas + switch
            act = form_get(form, "action") or "settings"
            if act == "cache_clear":                   # v220: semantic cache
                assistant.cache_clear()
                db.log("assistant_cache", "clear")
                return self.redirect(self._panel_url(s, "/panel/assistant?ok=" + urllib.parse.quote("کش پاسخ‌ها پاک شد.")))
            if act == "faq_delete":                   # v218: knowledge editor
                fid = safe_int(form_get(form, "id"), 0)
                if fid:
                    db.ai_faq_delete(fid)
                    db.log("assistant_faq", f"delete id={fid}")
                    return self.redirect(self._panel_url(s, "/panel/assistant?ok=" + urllib.parse.quote("سؤال حذف شد.")))
                return self.redirect(self._panel_url(s, "/panel/assistant?err=" + urllib.parse.quote("سؤال پیدا نشد.")))
            if act == "faq_save":                     # v218: knowledge editor
                fid = safe_int(form_get(form, "id"), 0) or None
                fq = form_get(form, "q")[:120].strip()
                fa_ = form_get(form, "a")[:2000].strip()
                if not fq or not fa_:
                    return self.redirect(self._panel_url(s, "/panel/assistant?err=" + urllib.parse.quote("سؤال و پاسخ نباید خالی باشد.")))
                fid = db.ai_faq_upsert(fid, fq, fa_, checkbox(form, "active"),
                                       max(0, min(9999, safe_int(form_get(form, "ord"), 0))))
                db.log("assistant_faq", f"save id={fid}")
                return self.redirect(self._panel_url(s, "/panel/assistant?ok=" + urllib.parse.quote("دانش دستیار ذخیره شد.")))
            upd = {"ai_enabled": checkbox(form, "ai_enabled"),
                   "ai_guest_model": checkbox(form, "ai_guest_model")}
            for k, hi in (("ai_quota_free", 500), ("ai_quota_plus", 1000),
                          ("ai_quota_pro", 2000), ("ai_daily_cap", 100000)):
                upd[k] = str(max(0, min(hi, safe_int(form_get(form, k), 0))))
            db.set_settings(upd)
            db.log("assistant_settings", " ".join(f"{k}={v}" for k, v in upd.items()))
            return self.redirect(self._panel_url(s, "/panel/assistant?ok=" + urllib.parse.quote("تنظیمات دستیار ذخیره شد.")))

        if path == "/panel/rotate-token":
            new = db.rotate_owner_token()
            return self.redirect(self._panel_url(s, f"/panel/settings?key={urllib.parse.quote(new)}&ok=کلید جدید ساخته شد. این نشانی را ذخیره کنید."))

        # ---- panel password (set / change / clear)
        if path == "/panel/security":
            # v293 لایهٔ اول: ساخت/حذف نشانی مخفی پنل (غیرقابل‌حدس).
            if form.get("hidden_mint"):
                hidden = secrets.token_urlsafe(18)   # 24 نویسهٔ امن
                db.set_settings({"panel_hidden_path": hidden})
                return self.redirect(self._panel_url(s, "/panel/settings?ok=" + urllib.parse.quote(
                    "نشانی مخفی ساخته شد: /" + hidden +
                    " — آن را کپی و نزد خود نگه دارید؛ /panel عادی از این پس ۴۰۴ است.")))
            if form.get("hidden_clear"):
                db.set_settings({"panel_hidden_path": ""})
                return self.redirect(self._panel_url(s, "/panel/settings?ok=" + urllib.parse.quote(
                    "نشانی مخفی حذف شد؛ پنل دوباره از /panel عادی باز می‌شود.")))
            # v293 لایهٔ سوم: کلید تأیید ورود با ربات بله
            # (مارکر مخفی: چک‌باکس خالی چیزی نمی‌فرستد — هم‌الگوی تب امکانات)
            if "bale_confirm_tab" in form:
                db.set_settings({"panel_bale_confirm":
                                 "1" if checkbox(form, "panel_bale_confirm") else "0"})
                return self.redirect(self._panel_url(s, "/panel/settings?ok=" + urllib.parse.quote(
                    "تنظیم تأیید ورود با ربات بله ذخیره شد.")))
            # v119: optional IP allowlist for the panel (defense-in-depth).
            # The field is always posted by the security tab; empty = open.
            if "panel_allow_ips" in form:
                raw = form_get(form, "panel_allow_ips", "")
                clean = ",".join(a.strip() for a in raw.replace(";", ",")
                                 .replace("\n", ",").split(",")
                                 if a.strip() and _looks_like_ip(a.strip()))
                db.set_settings({"panel_allow_ips": clean})
                self._PANEL_IP_CACHE = (None, 0.0)
                return self.redirect(self._panel_url(s, "/panel/settings?ok=" + urllib.parse.quote(
                    "فهرست آی‌پی‌های مجاز پنل ذخیره شد. خالی = همهٔ آی‌پی‌ها.")))
            pw = form_get(form, "owner_password", "")
            if form.get("clear_password"):
                db.set_owner_pass("")
                db.admin_session_kill(self.cookies().get(self.ADMIN_COOKIE))
                self.set_cookie(self.ADMIN_COOKIE, "", days=0)
                return self.redirect(self._panel_url(s, f"/panel/settings?ok=رمز عبور حذف شد؛ پنل فقط با کلید باز می‌شود."))
            if len(pw) < 6:
                return self.redirect(self._panel_url(s, f"/panel/settings?err=رمز عبور باید دست‌کم ۶ نویسه باشد."))
            db.set_owner_pass(pw)
            self.set_cookie(self.ADMIN_COOKIE, db.admin_session_new())
            return self.redirect(self._panel_url(s, f"/panel/settings?ok=رمز عبور پنل تنظیم شد. از این پس برای ورود لازم است."))

        # ---- media manager
        if path == "/panel/media/gc":
            refs = db.all_upload_refs()
            removed, freed = uploads.gc(refs)
            db.log("media.gc", f"-{removed} files, {freed} bytes")
            return self.redirect(self._panel_url(s, f"/panel/media?ok=" + urllib.parse.quote(
                f"{removed} فایل بدون استفاده پاک شد ({freed // 1024} کیلوبایت).")))
        if path == "/panel/media/delete":
            target = form_get(form, "path", "")
            ok = uploads.delete_file(target) if target else False
            db.log("media.delete", (target or "")[:80])
            return self.redirect(self._panel_url(s, f"/panel/media?ok=" + urllib.parse.quote(
                "فایل حذف شد." if ok else "فایل یافت نشد.")))

        # ---- bulk actions on the business table
        if path == "/panel/businesses/bulk":
            raw = form.get("ids") or []
            ids = [int(x) for x in raw if str(x).isdigit()]
            act = form_get(form, "action")
            n = 0
            if act == "publish":
                n = db.bulk_business(ids, "status", "published")
            elif act == "hide":
                n = db.bulk_business(ids, "status", "hidden")
            elif act == "feature":
                n = db.bulk_business(ids, "featured", "1")
            elif act == "unfeature":
                n = db.bulk_business(ids, "featured", "0")
            elif act == "move":
                n = db.bulk_business(ids, "category", form_get(form, "cat_to"))
            elif act == "delete":
                n = db.bulk_business(ids, "delete")
            db.log("business.bulk", f"{act} x{n}")
            return self.redirect(self._panel_url(s, f"/panel/businesses?ok="
                                 + urllib.parse.quote(f"{n} مورد به‌روزرسانی شد.")))

        if path == "/panel/businesses/import":
            added, updated, errors = db.import_csv(form_get(form, "csv", ""))
            db.log("business.import", f"+{added} ~{updated} !{len(errors)}")
            return self.send(P.csv_import(s, tok, q=None,
                                          result=(added, updated, errors)))

        # ---- owners / claims / inquiries / catalog / gallery (admin)
        m = re.match(r"^/panel/owner/(\d+)$", path)
        if m:
            oid = safe_int(m.group(1))
            # v172: حساب ناموجود را «تغییر کرد/حذف شد» جعل نکن؛ وضعیت هم
            # فقط active/blocked (دو مقداری که خودِ رابط می‌فرستد).
            if not db._rows("SELECT id FROM owners WHERE id=?", (oid,)):
                return self.redirect(self._panel_url(s, "/panel/owners?err=" + urllib.parse.quote(
                    "حسابی با این شناسه نیست.")))
            _st = form_get(form, "status", "active")
            if _st != "active" and form_get(form, "action") == "delete":
                db.delete_owner(oid)
                db.log("owner.delete", str(oid))
                return self.redirect(self._panel_url(s, f"/panel/owners?ok="
                    + urllib.parse.quote("حساب حذف شد؛ کسب‌وکارهایش بدون مالک ماندند.")))
            if _st not in ("active", "blocked"):
                return self.redirect(self._panel_url(s, "/panel/owners?err=" + urllib.parse.quote(
                    "وضعیت حساب معتبر نیست.")))
            db.set_owner_status(oid, _st)
            return self.redirect(self._panel_url(s, f"/panel/owners?ok=وضعیت کاربر تغییر کرد."))

        m = re.match(r"^/panel/claim/(\d+)$", path)
        if m:
            cid = safe_int(m.group(1))
            # v172: درخواست ناموجود را «واگذار شد» جعل نکن.
            if not db._rows("SELECT id FROM claims WHERE id=?", (cid,)):
                return self.redirect(self._panel_url(s, "/panel/claims?err=" + urllib.parse.quote(
                    "درخواستی با این شناسه نیست.")))
            approve = form_get(form, "action") == "approve"
            db.claim_decide(cid, approve)
            msg = "کسب‌وکار واگذار شد." if approve else "درخواست رد شد."
            return self.redirect(self._panel_url(s, f"/panel/claims?ok={urllib.parse.quote(msg)}"))

        m = re.match(r"^/panel/inquiry/(\d+)$", path)
        if m:
            self.inquiry_op(safe_int(m.group(1)), form, is_admin=True)
            return self.redirect(self._panel_url(s, f"/panel/inquiries?ok=انجام شد."))

        m = re.match(r"^/panel/gallery/(\d+)/(delete|cover|banner)$", path)
        if m:
            self.gallery_op(safe_int(m.group(1)), m.group(2), form_get(form, "src"))
            return self.redirect(self._panel_url(s, f"/panel/gallery/{m.group(1)}?ok=انجام شد."))

        m = re.match(r"^/panel/catalog/(\d+)/item/(new|\d+)$", path)
        if m:
            bid = safe_int(m.group(1))
            iid = None if m.group(2) == "new" else safe_int(m.group(2))
            self.save_item_from(form, bid, iid, None)
            return self.redirect(self._panel_url(s, f"/panel/catalog/{bid}?ok=ذخیره شد."))

        m = re.match(r"^/panel/catalog/(\d+)/item/(\d+)/delete$", path)
        if m:
            db.delete_item(safe_int(m.group(2)))
            return self.redirect(self._panel_url(s, f"/panel/catalog/{m.group(1)}?ok=حذف شد."))

        # ================================================================
        #  v3 admin actions
        # ================================================================

        # ---- questions
        m = re.match(r"^/panel/question/(\d+)$", path)
        if m:
            qid = safe_int(m.group(1))
            # v171: پرسش ناموجود را «انجام شد» جعل نکن.
            if not db._rows("SELECT id FROM questions WHERE id=?", (qid,)):
                return self.redirect(self._panel_url(s, "/panel/qa?err=" + urllib.parse.quote(
                    "پرسشی با این شناسه نیست.")))
            act = form_get(form, "action")
            if act == "delete":
                db.delete_question(qid)
                return self.redirect(self._panel_url(s, f"/panel/qa?ok=پرسش حذف شد."))
            if act == "publish":
                db.set_question_status(qid, "published")
            elif act == "reject":
                db.set_question_status(qid, "rejected")
            else:
                ans = form_get(form, "answer").strip()
                if not ans:
                    return self.redirect(self._panel_url(s, f"/panel/qa?err=متن پاسخ خالی است."))
                db.answer_question(qid, ans, by="admin")
            return self.redirect(self._panel_url(s, f"/panel/qa?ok=انجام شد."))

        # ---- reports
        if path == "/panel/reports/bulk":          # v117/M4
            ids = [safe_int(x) for x in (form.get("ids") or [])
                   if str(x).isdigit()]
            act = form_get(form, "action")
            n = 0
            for rid in ids:
                # v171: شناسهٔ ناموجود در شمارش نمی‌آید — شمارش صادقانه.
                if not db._rows("SELECT id FROM reports WHERE id=?", (rid,)):
                    continue
                if act == "delete":
                    db.delete_report(rid); n += 1
                else:
                    db.resolve_report(
                        rid, "dismissed" if act == "dismiss" else "resolved",
                        form_get(form, "note")); n += 1
            db.log("report.bulk", f"{act}:{n}")
            return self.redirect(self._panel_url(s, f"/panel/reports?ok=" + urllib.parse.quote(
                f"{n} گزارش به‌روزرسانی شد.")))

        m = re.match(r"^/panel/report/(\d+)$", path)
        if m:
            rid = safe_int(m.group(1))
            # v171: گزارش ناموجود را «به‌روزرسانی شد» جعل نکن.
            if not db._rows("SELECT id FROM reports WHERE id=?", (rid,)):
                return self.redirect(self._panel_url(s, "/panel/reports?err=" + urllib.parse.quote(
                    "گزارشی با این شناسه نیست.")))
            act = form_get(form, "action")
            if act == "delete":
                db.delete_report(rid)
                return self.redirect(self._panel_url(s, f"/panel/reports?ok=گزارش حذف شد."))
            db.resolve_report(rid, "dismissed" if act == "dismiss" else "resolved",
                              form_get(form, "note"))
            return self.redirect(self._panel_url(s, f"/panel/reports?ok=وضعیت گزارش به‌روزرسانی شد."))

        # ---- badges
        if path == "/panel/badge/new":
            name = form_get(form, "name")
            if not name:
                return self.redirect(self._panel_url(s, f"/panel/badges?err=نام نشان الزامی است."))
            db.save_badge({"name": name, "icon": form_get(form, "icon", "award"),
                           "color": form_get(form, "color", "#059669"),
                           "descr": form_get(form, "descr"),
                           "active": checkbox(form, "active")})
            return self.redirect(self._panel_url(s, f"/panel/badges?ok=نشان ساخته شد."))

        m = re.match(r"^/panel/badge/(\d+)$", path)
        if m:
            bid = safe_int(m.group(1))
            # v172: نشان ناموجود را «ذخیره/حذف/تغییر» جعل نکن.
            if not db.badge(bid=bid):
                return self.redirect(self._panel_url(s, "/panel/badges?err=" + urllib.parse.quote(
                    "نشانی با این شناسه نیست.")))
            act = form_get(form, "action")
            if act == "delete":
                db.delete_badge(bid)
                return self.redirect(self._panel_url(s, f"/panel/badges?ok=نشان حذف شد."))
            if act == "toggle":
                b = db.badge(bid=bid)
                if b:
                    db.save_badge({"name": b["name"], "icon": b["icon"],
                                   "color": b["color"], "descr": b["descr"],
                                   "sort": b["sort"],
                                   "active": 0 if b["active"] else 1}, bid)
                return self.redirect(self._panel_url(s, f"/panel/badges?ok=وضعیت نشان تغییر کرد."))
            if not form_get(form, "name").strip():
                return self.redirect(self._panel_url(s, f"/panel/badges?err=نام نشان الزامی است."))
            db.save_badge({"name": form_get(form, "name"),
                           "icon": form_get(form, "icon", "award"),
                           "color": form_get(form, "color", "#059669"),
                           "descr": form_get(form, "descr"),
                           "sort": form_get(form, "sort", "0"),
                           "active": checkbox(form, "active")}, bid)
            return self.redirect(self._panel_url(s, f"/panel/badges?ok=نشان ذخیره شد."))

        if path == "/panel/badges/grant":
            bid = form_get(form, "biz_id")
            # v172: کسب‌وکار ناموجود را «ثبت شد» جعل نکن.
            if bid.isdigit() and db._rows(
                    "SELECT id FROM businesses WHERE id=?", (int(bid),)):
                ids = [x for x in (form.get("badge_ids") or []) if str(x).isdigit()]
                n = db.set_biz_badges(int(bid), ids)
                db.log("badge.grant", f"biz {bid} -> {n} badges")
                return self.redirect(self._panel_url(s, f"/panel/badges?ok="
                    + urllib.parse.quote(f"{n} نشان برای این کسب‌وکار ثبت شد.")))
            return self.redirect(self._panel_url(s, f"/panel/badges?err=کسب‌وکار مشخص نیست."))

        if path == "/panel/badges/auto":
            n = db.auto_badges()
            return self.redirect(self._panel_url(s, f"/panel/badges?ok="
                + urllib.parse.quote(f"{n} تغییر در نشان «برترین امتیاز» اعمال شد.")))

        # ---- plans
        if path == "/panel/plan/new":
            if not form_get(form, "name"):
                return self.redirect(self._panel_url(s, f"/panel/plans?err=نام پلن الزامی است."))
            db.save_plan({"name": form_get(form, "name"),
                          "tagline": form_get(form, "tagline"),
                          "price": form_get(form, "price", "0"),
                          "months": form_get(form, "months", "12"),
                          "featured_slots": form_get(form, "featured_slots", "0"),
                          "max_items": form_get(form, "max_items", "10"),
                          "max_photos": form_get(form, "max_photos", "6"),
                          "perks": form_get(form, "perks"),
                          "badge_slug": form_get(form, "badge_slug"),
                          "ai_daily": form_get(form, "ai_daily", "-1"),
                          "active": checkbox(form, "active")})
            return self.redirect(self._panel_url(s, f"/panel/plans?ok=پلن ساخته شد."))

        m = re.match(r"^/panel/plan/(\d+)$", path)
        if m:
            pid = safe_int(m.group(1))
            # v172: پلن ناموجود را «ذخیره شد» جعل نکن.
            if not db.plan(pid=pid):
                return self.redirect(self._panel_url(s, "/panel/plans?err=" + urllib.parse.quote(
                    "پلنی با این شناسه نیست.")))
            if form_get(form, "action") == "delete":
                ok, msg = db.delete_plan(pid)
                kind = "ok" if ok else "err"
                return self.redirect(self._panel_url(s, f"/panel/plans?{kind}={urllib.parse.quote(msg)}"))
            if not form_get(form, "name").strip():
                return self.redirect(self._panel_url(s, f"/panel/plans?err=نام پلن الزامی است."))
            db.save_plan({k: form_get(form, k) for k in
                          ("name", "tagline", "price", "months", "featured_slots",
                           "max_items", "max_photos", "perks", "badge_slug",
                           "ai_daily")}
                         | {"active": checkbox(form, "active")}, pid)
            return self.redirect(self._panel_url(s, f"/panel/plans?ok=پلن ذخیره شد."))

        if path == "/panel/plans/payment":
            _card_raw = form_get(form, "pay_card")
            _fa_map = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
            _card_norm = "".join(c for c in _card_raw.translate(_fa_map) if c.isdigit())
            pay_upd = {
                "pay_method": form_get(form, "pay_method", "manual"),
                "pay_card": _card_norm,
                "pay_card_name": form_get(form, "pay_card_name"),
                "pay_bank": form_get(form, "pay_bank"),
            }
            # audit F-013: masked field — an empty submit keeps the stored
            # merchant id; only typing a new value replaces it.
            zm = form_get(form, "zarinpal_merchant").strip()
            if zm or not str(db.get_settings().get("zarinpal_merchant") or "").strip():
                pay_upd["zarinpal_merchant"] = zm
            db.set_settings(pay_upd)
            return self.redirect(self._panel_url(s, f"/panel/plans?ok=روش پرداخت ذخیره شد."))

        # ---- subscriptions
        if path == "/panel/subscription/new":
            bid = form_get(form, "biz_id")
            ps = form_get(form, "plan_slug")
            # v172: کسب‌وکار ناموجود → FK 500 نمی‌دهیم؛ پلن ناموجود هم «ok»
            # جعل نمی‌شود (request_subscription با sid=None برمی‌گردد).
            if not bid.isdigit() or not db._rows(
                    "SELECT id FROM businesses WHERE id=?", (int(bid) if bid.isdigit() else 0,)):
                return self.redirect(self._panel_url(s, f"/panel/subscriptions?err=کسب‌وکار و پلن الزامی است."))
            sid, msg = db.request_subscription(int(bid), ps, form_get(form, "ref"),
                                               "manual", "ثبت دستی توسط مدیر",
                                               months=form_get(form, "months"))
            if not sid:
                return self.redirect(self._panel_url(s, f"/panel/subscriptions?err={urllib.parse.quote(msg)}"))
            if form.get("activate"):
                db.activate_subscription(sid, months=form_get(form, "months"))
                msg = "اشتراک ثبت و فعال شد."
            return self.redirect(self._panel_url(s, f"/panel/subscriptions?ok={urllib.parse.quote(msg)}"))

        m = re.match(r"^/panel/subscription/(\d+)$", path)
        if m:
            sid = safe_int(m.group(1))
            # v172: اشتراک ناموجود را «فعال/لغو/حذف شد» جعل نکن.
            sub = db._one("SELECT * FROM subscriptions WHERE id=?", (sid,))
            if not sub:
                return self.redirect(self._panel_url(s, "/panel/subscriptions?err=" + urllib.parse.quote(
                    "اشتراکی با این شناسه نیست.")))
            act = form_get(form, "action")
            if act == "delete":
                db.delete_subscription(sid)
                return self.redirect(self._panel_url(s, f"/panel/subscriptions?ok=ردیف حذف شد."))
            if act == "cancel":
                db.cancel_subscription(sid)
                return self.redirect(self._panel_url(s, f"/panel/subscriptions?ok=اشتراک لغو شد."))
            if act == "reject":
                db.reject_subscription(sid)
                return self.redirect(self._panel_url(s, f"/panel/subscriptions?ok=درخواست رد شد؛ هیچ مبلغی برداشت نشده بود."))
            db.activate_subscription(sid, months=form_get(form, "months"))
            b = db.business(bid=sub["biz_id"])
            if b and b.get("phone"):
                sms.notify(s, db.norm_phone(b["phone"]),
                           f"اشتراک «{b['name']}» در {s.get('site_name')} فعال شد.")
            return self.redirect(self._panel_url(s, f"/panel/subscriptions?ok=اشتراک فعال شد."))

        # ---- ads
        m = re.match(r"^/panel/ad/(\d+)$", path)
        if m:
            aid = safe_int(m.group(1))
            # v172: بنر ناموجود را «حذف/صفر/تغییر» جعل نکن.
            a0 = db.ad(aid)
            if not a0:
                return self.redirect(self._panel_url(s, "/panel/ads?err=" + urllib.parse.quote(
                    "بنری با این شناسه نیست.")))
            act = form_get(form, "action")
            if act == "delete":
                if a0.get("image"):
                    uploads.delete_image(a0["image"])
                db.delete_ad(aid)
                return self.redirect(self._panel_url(s, f"/panel/ads?ok=بنر حذف شد."))
            if act == "reset":
                db.reset_ad_stats(aid)
                return self.redirect(self._panel_url(s, f"/panel/ads?ok=آمار بنر صفر شد."))
            if act == "toggle":
                db.save_ad(dict(a0, active=0 if a0["active"] else 1), aid)
                return self.redirect(self._panel_url(s, f"/panel/ads?ok=وضعیت بنر تغییر کرد."))
            # v297 F6: unknown action must not silently toggle — that hid
            # the bug where action=save (urlencoded) hit this handler instead
            # of the multipart one and flipped active 1→0.
            return self.redirect(self._panel_url(s, "/panel/ads?err=" + urllib.parse.quote(
                f"عملیات نامشخص: {act[:20]}")))

        # ---- events
        if path == "/panel/event/new":
            if not form_get(form, "title"):
                return self.redirect(self._panel_url(s, f"/panel/events?err=عنوان رویداد الزامی است."))
            db.save_cityevent({k: form_get(form, k) for k in
                               ("title", "descr", "place", "date", "time", "biz_id")})
            return self.redirect(self._panel_url(s, f"/panel/events?ok=رویداد ثبت شد."))

        m = re.match(r"^/panel/event/(\d+)$", path)
        if m:
            eid = safe_int(m.group(1))
            # v169: رویداد ناموجود را ساکت نساز — قبلاً save/حذفِ شناسهٔ غلط
            # یا بی‌اثر می‌شد یا رکورد یاچی می‌ساخت.
            if not db.cityevent(eid=eid):
                return self.redirect(self._panel_url(s, "/panel/events?err=" + urllib.parse.quote(
                    "رویدادی با این شناسه نیست.")))
            if form_get(form, "action") == "delete":
                db.delete_cityevent(eid)
                return self.redirect(self._panel_url(s, f"/panel/events?ok=رویداد حذف شد."))
            if not form_get(form, "title").strip():
                return self.redirect(self._panel_url(s, f"/panel/event/{eid}?err=" + urllib.parse.quote(
                    "عنوان رویداد الزامی است.")))
            cur = db.cityevent(eid=eid) or {}
            vals = {k: form_get(form, k) for k in
                    ("title", "descr", "place", "date", "time",
                     "biz_id", "status")}
            vals["image"] = cur.get("image", "")   # تصویر دست‌نخورده
            db.save_cityevent(vals, eid)
            return self.redirect(self._panel_url(s, f"/panel/events?ok=رویداد ذخیره شد."))

        # ---- edit approvals
        m = re.match(r"^/panel/edit/(\d+)$", path)
        if m:
            eid = safe_int(m.group(1))
            # v172: تغییرِ ناموجود را «اعمال شد» جعل نکن.
            if not db._rows("SELECT id FROM edits WHERE id=?", (eid,)):
                return self.redirect(self._panel_url(s, "/panel/edits?err=" + urllib.parse.quote(
                    "تغییری با این شناسه نیست.")))
            approve = form_get(form, "action") == "approve"
            ok_ = db.decide_edit(eid, approve)
            if not ok_:
                return self.redirect(self._panel_url(s, "/panel/edits?err=" + urllib.parse.quote(
                    "اعمال تغییرات ممکن نشد — دادهٔ ردیف معتبر نیست.")))
            msg = "تغییرات اعمال شد." if approve else "درخواست رد شد."
            return self.redirect(self._panel_url(s, f"/panel/edits?ok={urllib.parse.quote(msg)}"))

        if path == "/panel/edits/toggle":
            cur = db.get_settings().get("edit_approval") == "1"
            db.set_setting("edit_approval", "0" if cur else "1")
            return self.redirect(self._panel_url(s, f"/panel/edits?ok="
                + urllib.parse.quote("تأیید تغییرات " + ("خاموش شد." if cur else "روشن شد."))))

        # ---- feature unlocks (the admin's key)
        m = re.match(r"^/panel/unlock/(\d+)$", path)
        if m:
            bid = safe_int(m.group(1))
            if not db.business(bid=bid):   # v117/M2: no FK crash on bad ids
                return self.redirect(self._panel_url(s, "/panel/unlocks?err="
                                     + urllib.parse.quote(
                                         "کسب‌وکاری با این شناسه نیست.")))
            act = form_get(form, "action")
            if act == "all":
                keys = list(db.FEATURE_LABELS)
            elif act == "none":
                keys = []
            else:
                keys = [x for x in (form.get("feat") or []) if x in db.FEATURE_LABELS]
            n = db.set_manual_grants(bid, keys)
            b = db.business(bid=bid)
            # tell the shopkeeper the good news
            if act in ("all", "save") and n and b and b.get("phone"):
                sms.notify(s, db.norm_phone(b["phone"]),
                           f"قابلیت‌های تازه‌ای در {s.get('site_name')} برای «{b['name']}» فعال شد.")
            return self.redirect(self._panel_url(s, f"/panel/unlocks?ok="
                + urllib.parse.quote(f"{n} قابلیت برای این کسب‌وکار باز است.")))

        if path == "/panel/unlocks/founder":
            upd = {}
            for f in ("founder_limit", "founder_max_items", "founder_max_photos",
                      "free_max_items", "free_max_photos"):
                v = form_get(form, f)
                if v.strip().isdigit():
                    upd[f] = v.strip()
            if upd:
                db.set_settings(upd)
            return self.redirect(self._panel_url(s, f"/panel/unlocks?ok=تنظیمات ذخیره شد."))

        if path == "/panel/searches/clear":
            db.clear_searches()
            return self.redirect(self._panel_url(s, f"/panel/insights?ok=آمار جست‌وجو پاک شد."))

        # ---- alerts
        m = re.match(r"^/panel/alert/(\d+)$", path)
        if m:
            aid = safe_int(m.group(1))
            # v171: هشدار ناموجود را «تغییر کرد» جعل نکن.
            if not db._rows("SELECT id FROM alerts WHERE id=?", (aid,)):
                return self.redirect(self._panel_url(s, "/panel/alerts?err=" + urllib.parse.quote(
                    "هشداری با این شناسه نیست.")))
            if form_get(form, "action") == "delete":
                db.delete_alert(aid)
                return self.redirect(self._panel_url(s, f"/panel/alerts?ok=هشدار حذف شد."))
            a = [x for x in db.alerts() if x["id"] == aid]
            if a:
                db.toggle_alert(aid, 0 if a[0]["active"] else 1)
            return self.redirect(self._panel_url(s, f"/panel/alerts?ok=وضعیت هشدار تغییر کرد."))

        # ---- backup
        if path == "/panel/backup/import":
            try:
                payload = json.loads(form_get(form, "payload"))
                db.import_all(payload)
                return self.redirect(self._panel_url(s, f"/panel/backup?ok=داده‌ها بازیابی شد."))
            except Exception as e:
                return self.redirect(self._panel_url(s, f"/panel/backup?err="
                                     f"{urllib.parse.quote('فایل معتبر نیست: ' + str(e)[:60])}"))

        return self.send(V.not_found(s, tok), 404)

    # -------------------------------------------------------------- plumbing
    def handle_one_request(self):
        """A browser closing a keep-alive socket is normal, not an error.
        Without this, every page load printed a ConnectionResetError stack
        trace and buried the real messages."""
        try:
            return super().handle_one_request()
        except (ConnectionResetError, BrokenPipeError, TimeoutError):
            self.close_connection = True

    # -------------------------------------------------------------- logging
    def log_message(self, fmt, *args):
        code = str(args[1]) if len(args) > 1 else ""
        if code.startswith(("4", "5")) and "favicon" not in str(args[0]):
            sys.stdout.write("  [%s] %s\n" % (code, args[0]))


class Server(ThreadingHTTPServer):
    daemon_threads = True
    # ---- v116-perf: the stock BaseHTTPServer backlog is 5(!) — under any
    # burst the kernel refused connections (measured: 2850 errors at 500
    # concurrent clients). 128 lets a spike queue instead of dropping.
    # v117/کارایی: با رمبش ۱۰۰۰ اتصال، صف ۱۲۸ سرریز کرد و ۹ اتصال ریست شد
    # (اندازه‌گیری دور ۱۸). ۵۱۲ یعنی اسپایک صف می‌شود، نه ریست.
    request_queue_size = 512
    # ---- v116-perf: unbounded handler threads meant 500 keep-alive clients
    # = 500 threads = 500 SQLite connections (2MB page cache each) = +242MB
    # RSS and seconds of latency. Cap concurrent workers; extra connections
    # simply wait in the kernel backlog. Override with BZ_MAX_WORKERS.
    MAX_WORKERS = int(os.environ.get("BZ_MAX_WORKERS", "64"))
    _slots = threading.BoundedSemaphore(MAX_WORKERS)

    def process_request(self, request, client_address):
        # Acquire BEFORE spawning the thread so a flood cannot create
        # unbounded threads; the accept loop parks here while the pool is
        # full and the kernel backlog holds the queue.
        self._slots.acquire()
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()

    def handle_error(self, request, client_address):
        """Same reasoning as handle_one_request: a dropped client socket is
        routine. Only real faults should reach the console."""
        exc = sys.exc_info()[1]
        if isinstance(exc, (ConnectionResetError, BrokenPipeError, TimeoutError)):
            return
        super().handle_error(request, client_address)


_CHAT_GC_EVERY = 3600            # re-check expired chat images hourly
_last_chat_gc = 0.0


def purge_expired_chat_images(days=None):
    """Delete chat images past the retention window -- bytes AND db rows.

    Runs at startup and then hourly on a long-lived server, so a photo leaves
    the disk about a week after it was sent. The query is sender-agnostic, so
    customer-sent and shopkeeper-sent images are purged on the same clock.
    """
    global _last_chat_gc
    _last_chat_gc = time.time()
    try:
        rows = db.expired_chat_attachments(
            db.CHAT_RETENTION_DAYS if days is None else days)
    except Exception:
        return 0
    if not rows:
        return 0
    for row in rows:
        try:
            uploads.delete_chat_file(row["stored_name"])
        except Exception:
            pass
    db.delete_chat_attachments([r["id"] for r in rows])
    try:
        db.log("chat.gc", f"purged {len(rows)} attachment(s) older than "
                          f"{db.CHAT_RETENTION_DAYS}d")
    except Exception:
        pass
    return len(rows)


def make_server(port, host="0.0.0.0"):
    db.init()
    # Attachment metadata cascades with deleted chats; clean old orphan bytes
    # outside the web root after a one-hour safety window.
    uploads.gc_chat_files(set(db.chat_attachment_names()), min_age_seconds=3600)
    # Drop chat images that have passed the 7-day retention window.
    purge_expired_chat_images()
    db.trash_purge()   # v105: hard-purge recycle-bin rows older than 7 days
    # v212: publish the bot command menu (setMyCommands) without blocking boot.
    threading.Thread(target=_register_bot_commands, name="bot-commands", daemon=True).start()
    return Server((host, port), App)


def _register_bot_commands():
    try:
        result = bot_menu.register_commands()
        db.log("bot.commands", ",".join(f"{k}={'ok' if v else 'skip'}" for k, v in sorted(result.items())))
    except Exception:
        pass
