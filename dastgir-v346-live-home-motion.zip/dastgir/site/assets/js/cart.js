const KEY = 'bazarche_cart_v1';
const PRICES_ON = (window.__BAZARCHE__ || {}).pricesEnabled === true;
const read = () => { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) { return []; } };
const write = (c) => localStorage.setItem(KEY, JSON.stringify(c));
const FA = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
const fa = n => String(n).replace(/\d/g, d => FA[+d]);
const g = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
const h=s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const num=(n,min=0,max=1e15)=>(n=+n,isFinite(n)?Math.max(min,Math.min(max,Math.trunc(n))):min);

const cartCount = () => read().reduce((s, i) => s + (i.qty || 1), 0);

function updateBadge() {
  document.querySelectorAll('[data-cart-count]').forEach(el => {
    const n = cartCount();
    el.textContent = fa(n);
    el.hidden = n === 0;
  });
}

document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-add-cart]');
  if (!btn) return;
  const cart = read();
  const id = btn.dataset.id;
  const requested = Math.max(1, Math.min(99, Number(btn.closest('[data-item-detail]')?.querySelector('[data-cart-qty]')?.value || 1)));
  const existing = cart.find(i => i.id === id && i.biz === btn.dataset.biz);
  if (existing) existing.qty += requested;
  else cart.push({
    id, biz: btn.dataset.biz, bizname: btn.dataset.bizname,
    title: btn.dataset.title, price: +btn.dataset.price, qty: requested,
  });
  write(cart);
  updateBadge();
  window.Bazarche?.toast?.('«' + btn.dataset.title + '» به سبد اضافه شد.', 'ok');
});

const root = document.getElementById('cart-root');
if (root) {
  const cart = read();
  if (!cart.length) {
    root.innerHTML = `<div class="card glass card-pad" style="text-align:center">
      <p class="text-muted">سبد خرید شما خالی است.</p>
      <a class="btn btn-primary mt-md" href="/catalog">${''}مرور محصولات</a></div>`;
  } else if (!PRICES_ON) {
    const rows = cart.map((item, index) => {
      const qty = num(item.qty || 1, 1, 99);
      return `<tr>
      <td>${h(item.title)}</td>
      <td class="text-muted text-sm">${h(item.bizname || '')}</td>
      <td class="nums">${fa(qty)}</td>
      <td><button type="button" class="btn-icon" data-rm="${index}" aria-label="حذف">✕</button></td></tr>`;
    }).join('');
    root.innerHTML = `<div class="card glass card-pad" data-price-disabled-cart>
      <h2 class="card-title mb-md">اقلام ذخیره‌شده</h2>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>عنوان</th><th>کسب‌وکار</th><th>تعداد</th><th></th></tr></thead>
        <tbody>${rows}</tbody></table></div>
      <div class="alert alert-info mt-lg"><span>نمایش قیمت و ثبت سفارش آنلاین فعلاً از پنل مدیریت غیرفعال است. برای خرید، وارد صفحهٔ فروشگاه شوید و مستقیم ارتباط بگیرید.</span></div>
      <a class="btn btn-primary btn-block mt-md" href="/catalog">بازگشت به محصولات</a>
    </div>`;
    root.addEventListener('click', event => {
      const remove = event.target.closest('[data-rm]');
      if (!remove) return;
      const current = read(); current.splice(Number(remove.dataset.rm), 1);
      write(current); updateBadge(); location.reload();
    });
  } else {
    const total = cart.reduce((s, i) => s + num(i.price, 0) * num(i.qty || 1, 1, 99), 0);
    const rows = cart.map((i, idx) => {
      const price = num(i.price, 0), qty = num(i.qty || 1, 1, 99);
      return `<tr>
      <td>${h(i.title)}</td>
      <td class="text-muted text-sm">${h(i.bizname || '')}</td>
      <td class="nums">${g(price)}</td>
      <td><input type="number" min="1" max="99" value="${qty}" data-qty="${idx}" style="width:64px"></td>
      <td class="nums">${g(price * qty)}</td>
      <td><button type="button" class="btn-icon" data-rm="${idx}" aria-label="حذف">✕</button></td></tr>`;
    }).join('');
    root.innerHTML = `<div class="grid grid-2" style="align-items:start">
      <div class="card glass card-pad">
        <h2 class="card-title mb-md">اقلام سبد</h2>
        <div class="table-wrap"><table class="table">
          <thead><tr><th>عنوان</th><th>کسب‌وکار</th><th>قیمت</th><th>تعداد</th><th>جمع</th><th></th></tr></thead>
          <tbody>${rows}</tbody>
          <tfoot><tr><th colspan="4">مجموع</th><td class="nums"><strong>${g(total)}</strong></td><td></td></tr></tfoot>
        </table></div>
      </div>
      <form class="card glass card-pad" method="post" action="/order/create" data-validate>
        <h2 class="card-title mb-md">ثبت سفارش</h2>
        <input type="hidden" name="biz_id" value="${h(cart[0].biz || '')}">
        <input type="hidden" name="items" id="cart-items" value="">
        <div class="field"><label class="field-label">نام شما</label>
          <input class="input" name="name" required minlength="2" maxlength="100"></div>
        <div class="field"><label class="field-label">شمارهٔ موبایل (اختیاری)</label>
          <input class="input nums" name="phone" type="tel" dir="ltr"
                 inputmode="numeric" pattern="0[0-9]{10}" maxlength="11">
          <label class="check mt-sm"><input type="checkbox" name="share_phone" value="1"><span>شماره‌ام برای هماهنگی با دکان‌دار نمایش داده شود</span></label></div>
        <div class="field"><label class="field-label">نشانی (اختیاری)</label>
          <input class="input" name="address" maxlength="300"></div>
        <div class="field"><label class="field-label">یادداشت</label>
          <textarea class="textarea" name="note" maxlength="500" rows="2"></textarea></div>
        <button class="btn btn-primary btn-block" type="submit">ثبت سفارش</button>
        <p class="field-hint">برای پیگیری سفارش، با همین شماره وارد «حساب من» شوید.</p>
      </form>
    </div>`;

    const itemsInput = document.getElementById('cart-items');
    const sync = () => {
      itemsInput.value = JSON.stringify(read().map(i => ({
        item_id: num(i.id, 0),
        title: String(i.title || '').slice(0, 200),
        price: num(i.price, 0),
        qty: num(i.qty || 1, 1, 99),
      })));
    };
    sync();
    root.addEventListener('input', (e) => {
      const q = e.target.closest('[data-qty]');
      if (!q) return;
      const c = read();
      const idx = +q.dataset.qty;
      c[idx].qty = Math.max(1, Math.min(99, +q.value || 1));
      write(c); sync(); updateBadge();
      location.reload();
    });
    root.addEventListener('click', (e) => {
      const rm = e.target.closest('[data-rm]');
      if (!rm) return;
      const c = read();
      c.splice(+rm.dataset.rm, 1);
      write(c); updateBadge(); location.reload();
    });
  }
}

updateBadge();
