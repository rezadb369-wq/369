# FILE-MAP — نقشهٔ کامل فایل‌های سایت (هر بخش کجاست)

> **هدف:** هر کس (یا هر عامل) بخواهد چیزی را در سایت تغییر دهد یا باگی را
> عیب‌یابی کند، از این یک سند بفهمد **فایلِ آن بخش کجاست**. این سند با
> `tools/routemap.py` و `tools/build_filemap.py` تولید می‌شود.

## ۰) یک‌نگاه — درخت پوشه‌ها

```
repo-369/
├── run.py                  نقطهٔ ورود اجرا (پورت خودکار، سقف fd، systemd-ready)
│
├── server/                 ⬅ همهٔ منطق سمت سرور (پایتون خالص، stdlib-only)
│   ├── app.py              هسته: HTTP handler + مسیریابی + auth/سشن + آپلود + هدرها
│   ├── db.py               لایهٔ داده: ۸۴ جدول، CRUD، rate_ok، مهاجرت/سازگاری SCHEMA
│   ├── features.py         زیرسیستم‌های چندجدولی: چت، سفارش، تیکت، علاقه‌مندی، چانه
│   ├── ui.py               قالب صفحات: کروم، هدر/فوتر، منو، قفل‌ها، بامپ ?vNNN
│   ├── pagecache.py        کش صفحات مهمان (TTL ۸s، ابطال با هر POST)
│   ├── shield.py           سپر ضد-اسپم/حمله: rate-limit، اسکنر، UA مخرب
│   ├── analytics.py        آمار بازدید واقعی (IP/دستگاه/نشست، فیلتر بات)
│   ├── uploads.py          پارسر multipart دستی + سقف‌ها + EXIF-strip
│   ├── sms.py              کد یک‌بارمصرف (SMS/نمایش توسعه)
│   ├── qr.py               رمزگذار QR بدون کتابخانه (SVG)
│   ├── views_public.py     صفحات عمومی: خانه، فهرست، دکان، ثبت‌نام، جست‌وجو
│   ├── views_public2.py    عمومی ۲: مقایسه، نزدیک‌من، رویداد، چانه، تماس
│   ├── views_catalog.py    کاتالوگ/ویترین/کشف
│   ├── views_chat.py       چت بلادرنگ
│   ├── views_customer.py   پنل مشتری (/me)
│   ├── views_owner.py      پنل دکان‌دار (/my)
│   ├── views_panel.py      پنل مدیر بخش ۱ (کسب‌وکارها، نظرات، محتوا…)
│   ├── views_panel2.py     پنل مدیر بخش ۲ (moderation/audit/traffic/قابلیت‌ها)
│   └── views_extra.py      صفحه‌های ریز (درباره/تماس/آفلاین)
│
├── site/                   ⬅ فایل‌های سمت مرورگر
│   ├── sw.js               سرویس‌ورکر (PWA) — VERSION اینجا بامپ می‌شود
│   ├── offline.html        صفحهٔ آفلاین فارسی
│   ├── manifest.webmanifest  مانیفست PWA (نصب روی گوشی)
│   └── assets/
│       ├── css/            ۸ فایل — جدول آن‌ها در بخش ۲
│       ├── js/             ۲۵ فایل — جدول آن‌ها در بخش ۳
│       ├── fonts/          Vazirmatn (وزیرمتن)
│       ├── img/            آیکون‌ها، لوگو، هیرو (۲۲۴ فایل)
│       └── vendor/         کتابخانه‌های محلی: Leaflet و… (بدون CDN)
│
├── tools/                  ⬅ ابزارها و آزمون‌ها (جدول بخش ۵)
├── data/                   ⬅ دیتابیس + آپلودها (در زیپ تحویلی نیست)
├── docs/                   گزارش‌های ممیزی، تحقیق پنل، نقشهٔ مسیرها
└── *.md                    مستندات (HANDBOOK/READY/DEPLOY/…)
```

## ۱) «این صفحه/بخش کدام فایل است؟» — جدول بخش‌ها

| بخش سایت | مسیرها | فایل‌های منطق | فایل‌های ظاهر | فایل‌های رفتار (JS) |
|---|---|---|---|---|
| صفحهٔ اصلی | `/` | `views_public.py` | `main.css`, `pages.css` | `app.js`, `stories.js` |
| فهرست/جست‌وجو/دسته‌ها | `/businesses`, `/areas` | `views_public.py` | `pages.css` | `app.js`, `catpicker.js` |
| صفحهٔ کسب‌وکار | `/b/<slug>` | `views_public.py` | `pages.css`, `main.css` | `app.js`, `gallery.js` |
| نقشه | `/map` | `views_public2.py` | `pages.css` (`.map-*`) | `mappage.js` |
| مقایسهٔ قیمت | `/prices` | `views_public2.py` | `pages.css` | `app.js` |
| کاتالوگ/ویترین | `/catalog` | `views_catalog.py` | `pages.css` | `app.js` |
| چانه‌زنی | `/haggle/*`, `/offer/*` | `views_public2.py` | `pages.css` | `app.js` |
| ثبت کسب‌وکار | `/submit` | `views_public.py` | `pages.css` | `app.js`, `catpicker.js` |
| پنل مشتری | `/me/*` | `views_customer.py` | `pages.css` | `app.js` |
| پنل دکان‌دار | `/my/*` | `views_owner.py` | `main.css`, `pages.css` | `app.js`, `imagefield.js` |
| پنل مدیر | `/panel/*` | `views_panel.py`, `views_panel2.py` | `main.css`, `pages.css` | `panel.js` |
| چت | `/chat/*` | `views_chat.py` | `pages.css` | `chat.js` |
| ورود/OTP | `/login*`, `/alert` | `app.py` (auth) + `views_public.py` | `main.css` | `app.js` |
| API | `/api/*` | `app.py` | — | — |

## ۲) فایل‌های CSS (چه چیزی کجاست)

| فایل | اندازه (خط) | نقش |
|---|---|---|
| `jdatepicker.css` | 150 | — |
| `main.css` | 2350 | — |
| `mobile-refine.css` | 555 | — |
| `mobile-standard.css` | 155 | — |
| `pages.css` | 4831 | — |
| `theme-light.css` | 35 | — |
| `theme-night.css` | 35 | — |
| `tokens.css` | 324 | — |

- **توکن‌ها** همه در `tokens.css` (`:root` روز + `[data-theme]` شب).
- **رنگ خام در ویوها ممنوع است** (قانون معماری) — فقط توکن.
- **چیدمان موبایل:** `mobile-refine.css` و `mobile-standard.css` — هدف لمس ≥۴۴px با
  `var(--tap)`.
- **کامپوننت‌های نقشه** (نزدیک‌من/زوم/کارت انتخاب‌شده) همگی با پیشوند `.map-`
  در `pages.css`.

## ۳) فایل‌های JS (رفتار)

| فایل | خط | نقش |
|---|---|---|
| `app.js` | 2237 | — |
| `assist.js` | 249 | — |
| `bulk.js` | 53 | — |
| `cart.js` | 137 | — |
| `catpicker.js` | 198 | — |
| `chat.js` | 279 | — |
| `compress.js` | 634 | — |
| `countdown.js` | 27 | — |
| `dupcheck.js` | 142 | — |
| `favorites.js` | 64 | — |
| `imagefield.js` | 390 | — |
| `itemform.js` | 106 | — |
| `jalali.js` | 115 | — |
| `jdatepicker.js` | 260 | — |
| `live.js` | 130 | — |
| `map.js` | 329 | — |
| `mappage.js` | 507 | — |
| `nearby.js` | 210 | — |
| `notifpoll.js` | 41 | — |
| `notifpush.js` | 171 | — |
| `qa.js` | 98 | — |
| `regwizard.js` | 88 | — |
| `social.js` | 50 | — |
| `stories.js` | 253 | — |
| `upload.js` | 182 | — |

قانون: HTML سمت سرور رندر می‌شود؛ JS فقط رفتار (تعامل، OTP خودکار، بیکن آمار).

## ۴) نقشهٔ مسیرها (تولید خودکار)

# نقشهٔ مسیرها — هر URL کجاست؟

> تولید خودکار با `python3 tools/routemap.py -o docs/FILE-MAP.md` — اگر مسیر تازه‌ای اضافه شد، دوباره اجرا کنید.


## پنل مدیر (/panel)

| مسیر | فایل | خط |
|---|---|---|
| `/panel` | `server/app.py` | 993 |
| `/panel` | `server/app.py` | 1145 |
| `/panel` | `server/app.py` | 1626 |
| `/panel` | `server/app.py` | 1641 |
| `/panel` | `server/app.py` | 2440 |
| `/panel` | `server/app.py` | 2851 |
| `/panel` | `server/ui.py` | 820 |
| `/panel/` | `server/app.py` | 995 |
| `/panel/ad/(` | `server/app.py` | 2546 |
| `/panel/ad/(` | `server/app.py` | 5300 |
| `/panel/ad/(` | `server/app.py` | 6921 |
| `/panel/ad/new` | `server/app.py` | 5273 |
| `/panel/ads` | `server/app.py` | 2544 |
| `/panel/agent` | `server/app.py` | 2398 |
| `/panel/agent` | `server/app.py` | 4157 |
| `/panel/agent` | `server/app.py` | 5374 |
| `/panel/agent` | `server/app.py` | 5775 |
| `/panel/agent/batch/clear` | `server/app.py` | 5631 |
| `/panel/agent/batch/remove` | `server/app.py` | 5627 |
| `/panel/agent/cancel` | `server/app.py` | 5690 |
| `/panel/agent/code` | `server/app.py` | 2411 |
| `/panel/agent/code` | `server/app.py` | 5673 |
| `/panel/agent/confirm` | `server/app.py` | 5676 |
| `/panel/agent/key` | `server/app.py` | 5698 |
| `/panel/alert/(` | `server/app.py` | 7039 |
| `/panel/alerts` | `server/app.py` | 2558 |
| `/panel/analytics` | `server/app.py` | 2512 |
| `/panel/analytics/export` | `server/app.py` | 2514 |
| `/panel/appearance` | `server/app.py` | 2476 |
| `/panel/appearance` | `server/app.py` | 5236 |
| `/panel/appearance` | `server/app.py` | 6421 |
| `/panel/approve` | `server/app.py` | 1647 |
| `/panel/areas` | `server/app.py` | 2657 |
| `/panel/areas/rename` | `server/app.py` | 5852 |
| `/panel/assistant` | `server/app.py` | 2621 |
| `/panel/assistant` | `server/app.py` | 6526 |
| `/panel/audit` | `server/app.py` | 2623 |
| `/panel/audit/export` | `server/app.py` | 2625 |
| `/panel/backup` | `server/app.py` | 2668 |
| `/panel/backup/db` | `server/app.py` | 2712 |
| `/panel/backup/export` | `server/app.py` | 2670 |
| `/panel/backup/full` | `server/app.py` | 2676 |
| `/panel/backup/import` | `server/app.py` | 7055 |
| `/panel/badge/(` | `server/app.py` | 6775 |
| `/panel/badge/new` | `server/app.py` | 6765 |
| `/panel/badges` | `server/app.py` | 2538 |
| `/panel/badges/auto` | `server/app.py` | 6816 |
| `/panel/badges/grant` | `server/app.py` | 6804 |
| `/panel/booking/(` | `server/app.py` | 6343 |
| `/panel/bookings` | `server/app.py` | 2464 |
| `/panel/bookings/export` | `server/app.py` | 2458 |
| `/panel/broadcast` | `server/app.py` | 2653 |
| `/panel/broadcast` | `server/app.py` | 6010 |
| `/panel/business/(` | `server/app.py` | 2446 |
| `/panel/business/(` | `server/app.py` | 6181 |
| `/panel/business/(` | `server/app.py` | 6187 |
| `/panel/business/(` | `server/app.py` | 6251 |
| `/panel/business/(new|` | `server/app.py` | 6145 |
| `/panel/business/new` | `server/app.py` | 2444 |
| `/panel/businesses` | `server/app.py` | 2442 |
| `/panel/businesses/bulk` | `server/app.py` | 6620 |
| `/panel/businesses/export` | `server/app.py` | 2664 |
| `/panel/businesses/import` | `server/app.py` | 2662 |
| `/panel/businesses/import` | `server/app.py` | 6641 |
| `/panel/catalog/(` | `server/app.py` | 2492 |
| `/panel/catalog/(` | `server/app.py` | 2496 |
| `/panel/catalog/(` | `server/app.py` | 6690 |
| `/panel/catalog/(` | `server/app.py` | 6697 |
| `/panel/categories` | `server/app.py` | 2450 |
| `/panel/category/(` | `server/app.py` | 2452 |
| `/panel/category/(` | `server/app.py` | 4977 |
| `/panel/category/(` | `server/app.py` | 6270 |
| `/panel/category/(` | `server/app.py` | 6280 |
| `/panel/category/new` | `server/app.py` | 4954 |
| `/panel/category/new` | `server/app.py` | 6261 |
| `/panel/chat/(` | `server/app.py` | 2578 |
| `/panel/chat/(` | `server/app.py` | 5791 |
| `/panel/chat/(` | `server/app.py` | 5803 |
| `/panel/chats` | `server/app.py` | 2576 |
| `/panel/claim/(` | `server/app.py` | 6668 |
| `/panel/claims` | `server/app.py` | 2484 |
| `/panel/customer/(` | `server/app.py` | 5983 |
| `/panel/customer/(` | `server/app.py` | 5998 |
| `/panel/customers` | `server/app.py` | 2651 |
| `/panel/customers/export` | `server/app.py` | 2646 |
| `/panel/deal/(` | `server/app.py` | 2607 |
| `/panel/deal/(` | `server/app.py` | 5937 |
| `/panel/deal/(` | `server/app.py` | 5972 |
| `/panel/deal/new` | `server/app.py` | 5911 |
| `/panel/deals` | `server/app.py` | 2605 |
| `/panel/demo` | `server/app.py` | 2659 |
| `/panel/demo` | `server/app.py` | 5859 |
| `/panel/edit/(` | `server/app.py` | 6978 |
| `/panel/editor` | `server/app.py` | 2619 |
| `/panel/editor` | `server/app.py` | 5838 |
| `/panel/edits` | `server/app.py` | 2556 |
| `/panel/edits/toggle` | `server/app.py` | 6993 |
| `/panel/event/(` | `server/app.py` | 2552 |
| `/panel/event/(` | `server/app.py` | 6955 |
| `/panel/event/new` | `server/app.py` | 6948 |
| `/panel/events` | `server/app.py` | 2550 |
| `/panel/features` | `server/app.py` | 2564 |
| `/panel/features` | `server/app.py` | 6109 |
| `/panel/follows` | `server/app.py` | 2655 |
| `/panel/gallery/(` | `server/app.py` | 2488 |
| `/panel/gallery/(` | `server/app.py` | 6685 |
| `/panel/inbox` | `server/app.py` | 2562 |
| `/panel/inline-edit` | `server/app.py` | 3755 |
| `/panel/inquiries` | `server/app.py` | 2486 |
| `/panel/inquiry/(` | `server/app.py` | 6680 |
| `/panel/insights` | `server/app.py` | 2560 |
| `/panel/list/(` | `server/app.py` | 2601 |
| `/panel/list/(` | `server/app.py` | 5886 |
| `/panel/list/(` | `server/app.py` | 5901 |
| `/panel/list/new` | `server/app.py` | 5877 |
| `/panel/lists` | `server/app.py` | 2599 |
| `/panel/login` | `server/app.py` | 3710 |
| `/panel/logout` | `server/app.py` | 3749 |
| `/panel/media` | `server/app.py` | 2750 |
| `/panel/media/delete` | `server/app.py` | 6612 |
| `/panel/media/gc` | `server/app.py` | 6606 |
| `/panel/message/(` | `server/app.py` | 6395 |
| `/panel/messages` | `server/app.py` | 2472 |
| `/panel/moderation` | `server/app.py` | 2644 |
| `/panel/order/(` | `server/app.py` | 2591 |
| `/panel/order/(` | `server/app.py` | 5820 |
| `/panel/order/(` | `server/app.py` | 5825 |
| `/panel/orders` | `server/app.py` | 2595 |
| `/panel/orders/export` | `server/app.py` | 2585 |
| `/panel/owner/(` | `server/app.py` | 6648 |
| `/panel/owners` | `server/app.py` | 2482 |
| `/panel/pages` | `server/app.py` | 2474 |
| `/panel/pages` | `server/app.py` | 6409 |
| `/panel/plan/(` | `server/app.py` | 6838 |
| `/panel/plan/new` | `server/app.py` | 6822 |
| `/panel/plans` | `server/app.py` | 2540 |
| `/panel/plans/payment` | `server/app.py` | 6858 |
| `/panel/post/(` | `server/app.py` | 2468 |
| `/panel/post/(` | `server/app.py` | 6358 |
| `/panel/post/(` | `server/app.py` | 6384 |
| `/panel/post/new` | `server/app.py` | 6374 |
| `/panel/posts` | `server/app.py` | 2466 |
| `/panel/qa` | `server/app.py` | 2502 |
| `/panel/question/(` | `server/app.py` | 6707 |
| `/panel/report/(` | `server/app.py` | 6749 |
| `/panel/reports` | `server/app.py` | 2504 |
| `/panel/reports/bulk` | `server/app.py` | 6730 |
| `/panel/review/(` | `server/app.py` | 6322 |
| `/panel/reviews` | `server/app.py` | 2456 |
| `/panel/reviews/bulk` | `server/app.py` | 6305 |
| `/panel/rotate-token` | `server/app.py` | 6558 |
| `/panel/search` | `server/app.py` | 2478 |
| `/panel/searches/clear` | `server/app.py` | 7034 |
| `/panel/security` | `server/app.py` | 6563 |
| `/panel/settings` | `server/app.py` | 2480 |
| `/panel/settings` | `server/app.py` | 6442 |
| `/panel/spam` | `server/app.py` | 2510 |
| `/panel/spam/ban` | `server/app.py` | 6097 |
| `/panel/spam/lift` | `server/app.py` | 6087 |
| `/panel/spam/policy` | `server/app.py` | 6073 |
| `/panel/spam/policy-reset` | `server/app.py` | 6081 |
| `/panel/stories` | `server/app.py` | 2611 |
| `/panel/story/(` | `server/app.py` | 2613 |
| `/panel/story/(` | `server/app.py` | 6023 |
| `/panel/story/(` | `server/app.py` | 6046 |
| `/panel/subscription/(` | `server/app.py` | 6895 |
| `/panel/subscription/new` | `server/app.py` | 6877 |
| `/panel/subscriptions` | `server/app.py` | 2542 |
| `/panel/ticket/(` | `server/app.py` | 2568 |
| `/panel/ticket/(` | `server/app.py` | 5095 |
| `/panel/ticket/(` | `server/app.py` | 6121 |
| `/panel/tickets` | `server/app.py` | 2566 |
| `/panel/tickets/bulk` | `server/app.py` | 6291 |
| `/panel/traffic` | `server/app.py` | 2508 |
| `/panel/traffic/unblock` | `server/app.py` | 6060 |
| `/panel/trash` | `server/app.py` | 2506 |
| `/panel/trash/(` | `server/app.py` | 6050 |
| `/panel/unlock/(` | `server/app.py` | 7000 |
| `/panel/unlocks` | `server/app.py` | 2572 |
| `/panel/unlocks/founder` | `server/app.py` | 7023 |

## پنل دکان‌دار (/my)

| مسیر | فایل | خط |
|---|---|---|
| `/my` | `server/app.py` | 1147 |
| `/my` | `server/app.py` | 1690 |
| `/my` | `server/app.py` | 2125 |
| `/my/` | `server/app.py` | 4113 |
| `/my/account` | `server/app.py` | 2197 |
| `/my/account` | `server/app.py` | 4183 |
| `/my/assistant` | `server/app.py` | 2161 |
| `/my/booking/(` | `server/app.py` | 4511 |
| `/my/bookings` | `server/app.py` | 2177 |
| `/my/broadcast` | `server/app.py` | 2195 |
| `/my/broadcast/(fulfill|dismiss)$` | `server/app.py` | 4340 |
| `/my/broadcast/send` | `server/app.py` | 4322 |
| `/my/business/(` | `server/app.py` | 2218 |
| `/my/business/(` | `server/app.py` | 4262 |
| `/my/business/(` | `server/app.py` | 4446 |
| `/my/businesses` | `server/app.py` | 2167 |
| `/my/catalog/(` | `server/app.py` | 2230 |
| `/my/catalog/(` | `server/app.py` | 2234 |
| `/my/catalog/(` | `server/app.py` | 4374 |
| `/my/catalog/(` | `server/app.py` | 4542 |
| `/my/catalog/(` | `server/app.py` | 4570 |
| `/my/chat/(` | `server/app.py` | 2142 |
| `/my/chat/(` | `server/app.py` | 2151 |
| `/my/chat/(` | `server/app.py` | 4190 |
| `/my/chats` | `server/app.py` | 2149 |
| `/my/claim` | `server/app.py` | 2181 |
| `/my/claim` | `server/app.py` | 4529 |
| `/my/export` | `server/app.py` | 2199 |
| `/my/gallery/(` | `server/app.py` | 2222 |
| `/my/gallery/(` | `server/app.py` | 4579 |
| `/my/inquiries` | `server/app.py` | 2179 |
| `/my/inquiry/(` | `server/app.py` | 4588 |
| `/my/logout` | `server/app.py` | 4105 |
| `/my/notif-settings` | `server/app.py` | 2129 |
| `/my/notif-settings` | `server/app.py` | 4176 |
| `/my/notif/(` | `server/app.py` | 2131 |
| `/my/notifications` | `server/app.py` | 2127 |
| `/my/notifications/read` | `server/app.py` | 4172 |
| `/my/offer/(` | `server/app.py` | 4410 |
| `/my/offers` | `server/app.py` | 2185 |
| `/my/order/(` | `server/app.py` | 4210 |
| `/my/order/(` | `server/app.py` | 4215 |
| `/my/orders` | `server/app.py` | 2159 |
| `/my/plan` | `server/app.py` | 2193 |
| `/my/qr` | `server/app.py` | 2169 |
| `/my/question/(` | `server/app.py` | 4495 |
| `/my/questions` | `server/app.py` | 2183 |
| `/my/review/(` | `server/app.py` | 4480 |
| `/my/reviews` | `server/app.py` | 2175 |
| `/my/stats/(` | `server/app.py` | 2226 |
| `/my/stories` | `server/app.py` | 2163 |
| `/my/story/(` | `server/app.py` | 1680 |
| `/my/story/(` | `server/app.py` | 4231 |
| `/my/story/add` | `server/app.py` | 5111 |
| `/my/ticket/(` | `server/app.py` | 2189 |
| `/my/ticket/(` | `server/app.py` | 4353 |
| `/my/ticket/(` | `server/app.py` | 5078 |
| `/my/tickets` | `server/app.py` | 2187 |
| `/my/tickets` | `server/app.py` | 4297 |
| `/my/tickets` | `server/app.py` | 5052 |
| `/my/trash` | `server/app.py` | 2165 |
| `/my/trash/(` | `server/app.py` | 4241 |

## پنل مشتری (/me)

| مسیر | فایل | خط |
|---|---|---|
| `/me` | `server/app.py` | 1149 |
| `/me` | `server/app.py` | 1703 |
| `/me` | `server/app.py` | 2243 |
| `/me/account` | `server/app.py` | 2265 |
| `/me/account` | `server/app.py` | 3439 |
| `/me/bale/connect` | `server/app.py` | 2267 |
| `/me/chat/(` | `server/app.py` | 2249 |
| `/me/chat/(` | `server/app.py` | 2316 |
| `/me/chat/(` | `server/app.py` | 3648 |
| `/me/chat/(` | `server/app.py` | 3668 |
| `/me/chats` | `server/app.py` | 2247 |
| `/me/export` | `server/app.py` | 2287 |
| `/me/favorites` | `server/app.py` | 2263 |
| `/me/following` | `server/app.py` | 2327 |
| `/me/login` | `server/app.py` | 1699 |
| `/me/login` | `server/app.py` | 3381 |
| `/me/login/password` | `server/app.py` | 3404 |
| `/me/login/verify` | `server/app.py` | 3398 |
| `/me/logout` | `server/app.py` | 3407 |
| `/me/name` | `server/app.py` | 3430 |
| `/me/notif-settings` | `server/app.py` | 2325 |
| `/me/notif-settings` | `server/app.py` | 3544 |
| `/me/notif/(` | `server/app.py` | 2292 |
| `/me/notifications` | `server/app.py` | 2323 |
| `/me/notifications/read` | `server/app.py` | 3527 |
| `/me/order/(` | `server/app.py` | 2259 |
| `/me/order/(` | `server/app.py` | 2305 |
| `/me/order/(` | `server/app.py` | 3638 |
| `/me/orders` | `server/app.py` | 2257 |
| `/me/profile` | `server/app.py` | 2245 |
| `/me/profile` | `server/app.py` | 3415 |
| `/me/soroush/connect` | `server/app.py` | 2279 |

## صفحهٔ کسب‌وکار (/b)

| مسیر | فایل | خط |
|---|---|---|
| `/b/` | `server/app.py` | 1971 |
| `/b/` | `server/app.py` | 1984 |
| `/b/([^/?#]+)$` | `server/app.py` | 2307 |
| `/b/([^/]+)/ask-question$` | `server/app.py` | 3827 |
| `/b/([^/]+)/book$` | `server/app.py` | 4076 |
| `/b/([^/]+)/chat$` | `server/app.py` | 1817 |
| `/b/([^/]+)/report$` | `server/app.py` | 3955 |
| `/b/([^/]+)/review$` | `server/app.py` | 3992 |
| `/b/([^/]+)/review$` | `server/app.py` | 5138 |

## API

| مسیر | فایل | خط |
|---|---|---|
| `/api/` | `server/app.py` | 380 |
| `/api/` | `server/app.py` | 4122 |
| `/api/` | `server/app.py` | 4933 |
| `/api/` | `server/app.py` | 5379 |
| `/api/` | `server/app.py` | 5710 |
| `/api/` | `server/app.py` | 5721 |
| `/api/` | `server/app.py` | 5766 |
| `/api/` | `server/app.py` | 5770 |
| `/api/agent/` | `server/app.py` | 4151 |
| `/api/agent/` | `server/app.py` | 5376 |
| `/api/agent/models` | `server/app.py` | 1493 |
| `/api/agent/status` | `server/app.py` | 1463 |
| `/api/agent/status` | `server/app.py` | 5771 |
| `/api/alert` | `server/app.py` | 3971 |
| `/api/assistant/chat` | `server/app.py` | 3333 |
| `/api/assistant/status` | `server/app.py` | 1882 |
| `/api/businesses` | `server/app.py` | 1925 |
| `/api/chat/` | `server/app.py` | 1172 |
| `/api/chat/(` | `server/app.py` | 1838 |
| `/api/check-duplicate` | `server/app.py` | 3795 |
| `/api/favorite` | `server/app.py` | 3449 |
| `/api/follow` | `server/app.py` | 3468 |
| `/api/live` | `server/app.py` | 1757 |
| `/api/login-key` | `server/app.py` | 2865 |
| `/api/nearby` | `server/app.py` | 1906 |
| `/api/panel/approve-status` | `server/app.py` | 1443 |
| `/api/push/config` | `server/app.py` | 1870 |
| `/api/push/subscribe` | `server/app.py` | 3481 |
| `/api/push/unsubscribe` | `server/app.py` | 3506 |
| `/api/question-helpful` | `server/app.py` | 3937 |
| `/api/review-helpful` | `server/app.py` | 3555 |
| `/api/search` | `server/app.py` | 1932 |
| `/api/soroush` | `server/app.py` | 1520 |
| `/api/stories` | `server/app.py` | 1749 |
| `/api/stories/` | `server/app.py` | 1168 |
| `/api/stories/(` | `server/app.py` | 3180 |
| `/api/unread-count` | `server/app.py` | 1891 |

## فایل‌های ثابت / PWA

| مسیر | فایل | خط |
|---|---|---|
| `/assets/` | `server/app.py` | 1305 |
| `/favicon.ico` | `server/app.py` | 1309 |
| `/robots.txt` | `server/app.py` | 1311 |
| `/sitemap.xml` | `server/app.py` | 1339 |

## عمومی / متفرقه

| مسیر | فایل | خط |
|---|---|---|
| `/` | `server/adminbot.py` | 2970 |
| `/` | `server/app.py` | 1006 |
| `/` | `server/app.py` | 1638 |
| `/` | `server/app.py` | 1947 |
| `/` | `server/app.py` | 2845 |
| `/` | `server/bale.py` | 170 |
| `/` | `server/soroush.py` | 130 |
| `/#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$` | `server/views_agent_desk.py` | 193 |
| `/#[0-9a-fA-F]{6}$` | `server/adminbot_content.py` | 1124 |
| `/(` | `server/features.py` | 1099 |
| `/((?:13|14)` | `server/assistant.py` | 1973 |
| `/((?:13|14)` | `server/features.py` | 1082 |
| `/([01]?` | `server/assistant.py` | 1995 |
| `/([a-f0-9]{16})` | `server/analytics.py` | 143 |
| `/(me|my|panel)/chat/(` | `server/app.py` | 5017 |
| `/(my|panel)/catalog/(` | `server/app.py` | 5340 |
| `/(my|panel)/gallery/(` | `server/app.py` | 5172 |
| `/.well-known/security.txt` | `server/app.py` | 1352 |
| `/?(search|جست‌?وجو)` | `server/assistant.py` | 695 |
| `/ad/(` | `server/app.py` | 2076 |
| `/agent` | `server/app.py` | 1577 |
| `/agent` | `server/app.py` | 4120 |
| `/agent` | `server/app.py` | 5380 |
| `/agent` | `server/app.py` | 5608 |
| `/agent/` | `server/app.py` | 4144 |
| `/agent/code` | `server/app.py` | 1600 |
| `/agent/file/` | `server/app.py` | 1559 |
| `/agent/help-mobile` | `server/app.py` | 1554 |
| `/alert` | `server/app.py` | 3980 |
| `/area/([^/]+)$` | `server/app.py` | 1725 |
| `/areas` | `server/app.py` | 1719 |
| `/assistant` | `server/app.py` | 2101 |
| `/auth/bale` | `server/app.py` | 1414 |
| `/auth/soroush` | `server/app.py` | 1429 |
| `/blog` | `server/app.py` | 1999 |
| `/blog/` | `server/app.py` | 2005 |
| `/businesses` | `server/app.py` | 1949 |
| `/cart` | `server/app.py` | 1715 |
| `/catalog` | `server/app.py` | 1801 |
| `/categories` | `server/app.py` | 1721 |
| `/chat-file/(` | `server/app.py` | 1375 |
| `/cities` | `server/app.py` | 1723 |
| `/contact` | `server/app.py` | 2099 |
| `/contact` | `server/app.py` | 3783 |
| `/deals` | `server/app.py` | 1745 |
| `/events` | `server/app.py` | 2069 |
| `/events/` | `server/app.py` | 2073 |
| `/favorites` | `server/app.py` | 2089 |
| `/features` | `server/app.py` | 2116 |
| `/feed.xml` | `server/app.py` | 1337 |
| `/haggle/(` | `server/app.py` | 2010 |
| `/haggle/(` | `server/app.py` | 4019 |
| `/healthz` | `server/app.py` | 1341 |
| `/item/(` | `server/app.py` | 1779 |
| `/item/(` | `server/app.py` | 2306 |
| `/item/(` | `server/app.py` | 3808 |
| `/list/([^/]+)$` | `server/app.py` | 1739 |
| `/lists` | `server/app.py` | 1735 |
| `/login` | `server/app.py` | 3762 |
| `/login/email` | `server/app.py` | 3772 |
| `/login/email/verify` | `server/app.py` | 3775 |
| `/login/password` | `server/app.py` | 3768 |
| `/login/verify` | `server/app.py` | 3765 |
| `/map` | `server/app.py` | 1997 |
| `/nearby` | `server/app.py` | 2065 |
| `/offer/([A-Za-z0-9_-]{6,64})$` | `server/app.py` | 2016 |
| `/offer/([A-Za-z0-9_-]{6,64})$` | `server/app.py` | 4046 |
| `/order/create` | `server/app.py` | 3577 |
| `/order/ok` | `server/app.py` | 1729 |
| `/prices` | `server/app.py` | 2059 |
| `/prices/alert` | `server/app.py` | 3384 |
| `/pricing` | `server/app.py` | 2091 |
| `/qr/([^/]+)` | `server/app.py` | 2026 |
| `/start(?:@` | `server/app.py` | 2948 |
| `/submit` | `server/app.py` | 2110 |
| `/submit` | `server/app.py` | 3791 |
| `/subscribe` | `server/app.py` | 2093 |
| `/subscribe` | `server/app.py` | 3779 |
| `/subscribe` | `server/app.py` | 4904 |
| `/ticket-file/(` | `server/app.py` | 1394 |
| `/vcard/([^/]+)$` | `server/app.py` | 2049 |
| `/[^@` | `server/db.py` | 4409 |
| `/[a-z0-9_-]{2,30}$` | `server/adminbot_content.py` | 762 |

## ۵) ابزارها و آزمون‌ها (tools/)

| ابزار | نقش |
|---|---|
| `routemap.py` | ⭐ همین نقشهٔ مسیرها را می‌سازد (بعد از هر مسیر تازه اجرا کنید) |
| `build_filemap.py` | این سند را می‌سازد |
| `design_audit.py` | ممیزی جامع طراحی: ۹۴ صفحه × ۷ عرض، شات + متریک (tap/font/overflow/…) |
| `mobile_audit.py` | ممیزی موبایل (۴ دستگاه) |
| `contrast_audit.py` | کنتراست دو تم (AA) |
| `audit.py` | شکار کنترل‌های بی‌عمل (۴۶+ صفحه) |
| `navfit.py` | اندازه‌گیری سرریز هدر |
| `bench_load.py`, `bench_1000.py`, `bench_panel.py` | بار/کارایی (۵۰۰–۱۰۰۰ کاربر) |
| `test_*.py` (۴۰+ فایل) | باتری رگرسیون — فهرست کامل در `ARCHITECTURE.md` بخش ۷ |
| `seed_demo.py`, `reset_testdata.py` | دادهٔ نمونه / پاک‌سازی |
| `taxonomy.py`, `slice_taxonomy_icons.py` | درخت ۱۷۳ دسته و برش آیکون‌ها |
| `make_evidence*.py` | شواهد تصویری ممیزی (Playwright) |

## ۶) «برای تغییر X کجا بروم؟» — برگهٔ تقلب

| می‌خواهم… | برو به |
|---|---|
| متن/تایتل صفحه‌ای را عوض کنم | ویو همان مسیر (بخش ۱ یا جدول مسیرها) |
| رنگ/فونت/فاصله را عوض کنم | `site/assets/css/` — اول `tokens.css`، بعد `main.css`/`pages.css` |
| رفتار دکمه/فرم را عوض کنم | `site/assets/js/app.js` (یا فایل JS همان بخش) |
| مسیر جدید اضافه کنم | `server/app.py` → `route_get`/`route_post` + ویو مناسب |
| ستون/جدول جدید در دیتابیس | `server/db.py` → `SCHEMA` + `_reconcile_schema()` (مهاجرت خودکار) |
| سقف/قاعدهٔ امنیتی | `server/shield.py` + `db.rate_ok` + `SECURITY_HEADERS` در app.py |
| کش/سرعت | `server/pagecache.py` + بخش gzip/ETag در `app.py` |
| نسخهٔ assetها را بامپ کنم | `server/ui.py` (`?vNNN`) + `site/sw.js` (`VERSION`) + `tools/test_migration.py` |
| باگی در پنل مدیر | `views_panel.py` / `views_panel2.py` + `test_panel_*.py` |
| استقرار روی هاست | `DEPLOY.md` + `docs/HOSTING-v119.md` |
