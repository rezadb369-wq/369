# HANDOFF مرجع پروژهٔ «دست گیر»

آخرین به‌روزرسانی: ۲۰۲۶-۱۰-۰۴ — نسخهٔ **v330**. این فایل کارت شروع سریع چت/عامل جدید است.
(نسخهٔ زنده و جزئی‌تر: `docs/collaboration/HANDOFF.md` · وضعیت لحظه‌ای: `docs/collaboration/CURRENT-STATE.md` · دانش جاری: `docs/collaboration/KNOWLEDGE.md` · قوانین مدیر: `docs/collaboration/RULES.md` · قابلیت‌ها: `WHATS-NEW.md`.)

## ۱) منبع حقیقت و نسخه

- درخت فعال: همین پوشه (`dastgir/`)؛ نسخه در `VERSION.txt` = `330`.
- **پین‌های نسخه در عمل ۹ جاست** و ابزار رسمی آن `python3 tools/bump_version.py <نسخه>` است: `VERSION.txt` · `server/adminbot.py` (`DIAG_LATEST`) · `site/sw.js` (`bazarche-vNNN`) · `README.md` · خط اول `docs/collaboration/CURRENT-STATE.md` · `server/views_agent_desk.py` · `server/agent_cmds.py` (`/elevated`) · تیتر `docs/collaboration/HANDOFF.md` · انتظارهای `tools/test_v328.py`.
- **کش‌شکن لوگوی display هم باید با نسخه هماهنگ باشد**: `server/ui.py` از `av('/assets/img/logo-display.png')` می‌سازد و `site/sw.js` همان URL نسخه‌دار را precache می‌کند. `tools/bump_version.py` از ممیزی Stage 12 این مورد را هم همراه نسخه بالا می‌برد.
- بستهٔ تحویلی کامل ساخته می‌شود؛ `data/`، آپلودهای کاربر، کش‌ها و رازهای عملیاتی وارد زیپ نمی‌شوند. ساخت رسمی: `python3 tools/build_zip.py /path/to/dastgir-vNNN.zip`.
- منبع حقیقت بستهٔ اولیه: ریپوی `rezadb369-wq/369` و آرشیو `dastgir-v330.zip`. ادعای push/deploy ممنوع است مگر خروجی واقعی آن دیده شود.

## ۲) وضعیت قابلیت‌ها (زنده)

- v330: ممیزی کامل امنیت/سلامت/سئو/سرعت؛ سازگاری Python 3.11؛ رفع ۴۰۴ اسکریپت علاقه‌مندی؛ حذف فرم‌های مردهٔ ورود؛ یکپارچگی کش‌شکن دارایی‌ها؛ سخت‌سازی Zip Slip؛ خاموشی لاگ nginx برای URLهای webhook محرمانه.
- v329: ایجنت بومی هوش سایت داخل `assistant.py` (`site_agent` با tool calls داخلی)، بدون OpenClaw در مسیر اصلی.
- v328: پنج مدل رایگان واقعاً پاسخ‌گو از byNara؛ OpenRouter در تست‌های آن دوره ۴۰۱ می‌داد و پیش‌فرض نیست.
- فازهای پنل ایجنت سر جایشان: امروز/محتوا/دستور/سیستم/گفت‌وگو/درآمد/نوبت و هوش. نوشتن محتوا با توضیح و تأیید انجام می‌شود؛ خواندن‌ها فوری‌اند.
- چت عمومی سایت و محیط مدیر جدا هستند. چت عمومی از اسلات `AI_SITE_*` استفاده می‌کند؛ محیط مدیر/تیم از مغزهای مدیر و دسترسی‌های خودش. سوئیچ خودکار مغز ممنوع است.

## ۳) امنیت تثبیت‌شده

- رازهای عملیاتی (`BALE_*`، webhook secret، توکن‌ها و کلیدهای نصب) باید بیرون از بسته و در محیط/`/etc/dastgir-secrets.env` باشند؛ لاگ‌ها و گزارش‌ها مقدار راز را چاپ نمی‌کنند. `tools/scan_tokens.py` پیش از تحویل اجرا می‌شود.
- وب‌هوک‌ها با URL-secret و `compare_digest` محافظت می‌شوند، replay guard دارند، و در کانفیگ nginx مسیرهای `/api/(bale|bale-admin|soroush)/webhook/<secret>` با `access_log off` ثبت شده‌اند.
- مرز بات مدیر: `chat.id` در `BALE_ADMIN_CHAT` + webhook secret معتبر + در صورت تنظیم، گیت `BOT_GATE_PHONE/BOT_GATE_PASS`. دستورهای شل (`sh`/`shell_exec`) عمدی‌اند و پشت همین مرز و/یا تأیید قرار دارند.
- سه لایهٔ ضداسپم/سپر فعال است: `server/shield.py`، `server/antispam.py`، و gateهای پایگاه‌داده/محتوا. `qa_crawl.py` پس از ممیزی Stage 11 سطل‌های تستی را قبل/بعد پاک می‌کند تا باتری مشترک آلوده نشود.
- بازیابی/بازکردن آرشیو در `app.py` و `tools/backup.py` با استخراج امن انجام می‌شود؛ `tools/test_zip_safety_v330.py` مسیرهای Zip Slip را قفل می‌کند.

## ۴) استقرار (VPS)

- نصب/به‌روزرسانی رسمی: `sudo bash /opt/dastgir/deploy/update.sh <zip>` — بکاپ سازگار SQLite، stop، `rsync --delete` با حفظ `data/` و آپلودها، نصب سرویس/کرون، `apply-brain.sh`، start، سپس `healthz`.
- نصب اول: `deploy/install.sh` + `deploy/README-fa.md`. راهنمای گوشی/Termux: `docs/TERMUX-GUIDE.md`. راهنمای SSH دسکتاپ: `deploy/DEPLOY-TERMIUS-fa.md`.
- پس از نصب: `curl /healthz`، بررسی `systemctl is-active`، بررسی `sw.js` برای `bazarche-v330`، و مرور سریع مسیرهای عمومی/پنل.

## ۵) آزمون‌ها و شواهد لازم

- شمار جاری فایل‌های `tools/test_*.py` در این درخت: **۱۵۴**؛ فهرست harness کامل Stage 11: **۱۶۹** ورودی در `/home/user/suitelist.txt`.
- آخرین باتری کامل ممیزی Stage 11: `/home/user/reports/allsuites_stage11_final4.txt` با **۱۶۹ suite**، **۴۳۵۶ pass marker**، **۱۷۵ fail marker** و **۰ traceback سرور**. اختلاف با baseline Stage 8 فقط اضافه‌شدن تست Zip Slip است.
- تست‌های سریع پس از هر تغییر کد: `python3 -m compileall -q app.py server tools`، تست مرتبط مسیر، `tools/test_v328.py` برای پین‌ها، `tools/test_all.py` و تست‌های مرورگری/کارایی با سرور زنده وقتی UI/asset تغییر کرده باشد.
- قانون گزارش: «درست شد» فقط با خروجی واقعی دستور/تست گفته می‌شود. شکست محیطی (مثل نبود Playwright یا سرور خاموش) باید صریحاً جدا از شکست کد نوشته شود.

## ۶) قوانین ادامه

- قبل از هر تغییر، رفتار واقعی و فایل‌های مرتبط را بخوان؛ حدس جای تست را نمی‌گیرد.
- قابلیت بدون UI دیده‌شدنی انجام‌شده محسوب نمی‌شود.
- دادهٔ کاربر و رازها وارد زیپ یا گزارش نمی‌شوند.
- هر تحویل، حتی برای تغییر کوچک، زیپ کامل تازه + هش + `unzip -t` + smoke نصب تازه می‌خواهد.
