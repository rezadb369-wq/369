#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v330 stage-14: duplicate-check hints must not turn JSON into HTML.

/api/check-duplicate returns names/addresses/reasons copied from existing
business records. Those values may be user supplied, so dupcheck.js must escape
them before assigning to innerHTML and must not let JSON choose an arbitrary CSS
selector.
"""
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JS = ROOT / "site" / "assets" / "js" / "dupcheck.js"
text = JS.read_text(encoding="utf-8")
passes = 0
fails = 0


def ck(ok, msg):
    global passes, fails
    if ok:
        passes += 1
        print("✓", msg)
    else:
        fails += 1
        print("✗", msg)


ck("const esc = value =>" in text and "&lt;" in text and "&#39;" in text,
   "dupcheck.js defines an HTML escaper")
ck("${esc(d.name)}" in text, "duplicate business name is escaped")
ck("${esc(d.address || '')}" in text, "duplicate address is escaped")
ck("${esc(d.reason)}" in text, "duplicate reason is escaped")
ck("esc(LABEL[d.status] || d.status)" in text, "status fallback is escaped")
ck("encodeURIComponent(String(d.slug || ''))" in text,
   "slug is URL-encoded before href interpolation")
ck("allowedFields" in text and "allowedFields.has(field)" in text,
   "JSON field names are restricted to the form data-dup allowlist")
for raw in ("${d.name}", "${d.address", "${d.reason}", "/b/${d.slug}"):
    ck(raw not in text, f"raw interpolation removed: {raw}")

node = shutil.which("node")
if node:
    r = subprocess.run([node, "--check", str(JS)], text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       timeout=10)
    ck(r.returncode == 0, "dupcheck.js parses under node --check")
else:
    ck(True, "node not installed; static JS checks completed")

if fails:
    raise SystemExit(1)
print(f"OK {passes}/0")
