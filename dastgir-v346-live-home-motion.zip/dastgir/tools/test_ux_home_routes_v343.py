#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Guard v343 visible homepage route chooser.

v343 answers the request to continue with a more visible appearance change on
home: a large route chooser that surfaces existing destinations only. It must
not add routes, schema, JavaScript, or capabilities.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
PASS = FAIL = 0


def ck(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("✓ " + name)
    else:
        FAIL += 1
        print("✗ " + name + (" — " + detail if detail else ""))


def rd(rel):
    return (ROOT / rel).read_text(encoding="utf-8")

public = rd("server/views_public.py")
css = rd("site/assets/css/pages.css")

ck("homepage has a prominent route chooser after hero",
   "route_board = f'''" in public
   and "h-route-board" in public
   and "امروز دنبال چه هستید؟" in public
   and "انتخاب سریع مسیر" in public)

ck("route chooser links only to existing main destinations",
   all(x in public for x in ('href="/businesses"', 'href="/catalog"', 'href="/map"'))
   and 'href="{_owner_hub_href}"' in public
   and '_owner_hub_href = "/my" if _me else "/register-business"' in public)

ck("route cards make shop/catalog/map/owner choices visible",
   all(x in public for x in ("پیدا کردن دکان", "محصول و خدمت", "نقشه و نزدیک من", "ثبت یا مدیریت دکان", "پنل دکان من")))

ck("homepage route chooser has noticeable responsive styling",
   all(x in css for x in (".h-route-board", ".h-route-grid", ".h-route-card", ".h-route-ic", "radial-gradient", "@media (max-width: 980px)", "@media (max-width: 540px)")))

ck("route chooser uses existing CSS tokens only",
   "--info-" not in css[css.find(".h-route-section"):css.find(".ai-hero-orb")])

ck("v343 still adds no route/schema/js dependency",
   "CREATE TABLE" not in public
   and not re.search(r"if path == \"/.*(route|chooser|v343)|@route|route\(", public)
   and "<script" not in public[public.find("route_board = f'''"):public.find("hero_title =")])

print(f"\n{PASS} passed, {FAIL} failed")
raise SystemExit(1 if FAIL else 0)
