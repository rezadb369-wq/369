#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v336: main-site hamburger opens to category headers first.

v335 grouped the public drawer. v336 tightens the UX to match the requested
pattern exactly: when the menu opens it is not already expanded; visitors see
major category headers, then click one header to open only that category's
features downward.
"""
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))

import db  # noqa: E402
import ui  # noqa: E402

passes = 0
fails = 0


def ck(ok, msg):
    global passes, fails
    if ok:
        passes += 1
        print("✓", msg)
    else:
        fails += 1
        print("✗", msg)


def any_public_group_open(markup):
    return re.search(r'<details[^>]*data-public-nav-group[^>]*\sopen(?:\s|>)', markup) is not None


s = dict(db.get_settings())
s["prices_enabled"] = "1"
s["ai_enabled"] = "1"
ui.set_context(path="/")
html = ui.header(s, "/")

ck('class="mnav-groups"' in html and 'data-public-nav-group' in html,
   "public mobile menu renders accordion groups")
for title in ("کشف محلی", "خرید و قیمت", "شهر و محتوا", "دستیار و ارتباط", "میان‌برها", "حساب و دکان‌داری"):
    ck(title in html, f"public menu includes category: {title}")

ck(html.count('data-public-nav-group') >= 6,
   "public menu has multiple separate task categories")
ck(not any_public_group_open(html),
   "opening the public menu starts with category headers collapsed")
ck('data-current-group="true"' in html and 'mnav-current' in html,
   "current section is marked on its category header without expanding it")
ck('/businesses' in html and '/deals' in html and '/catalog' in html and '/events' in html and '/contact' in html,
   "existing public links remain reachable inside the grouped drawer")
ck('href="/assistant"' in html and 'class="nav-ai"' in html,
   "AI assistant remains available inside the public accordion")
ck('href="/favorites" class="favorite-link"' in html and 'href="/cart"' in html and 'href="/cities"' in html,
   "utility links moved into the shortcuts accordion instead of disappearing")

s_off = dict(s)
s_off["prices_enabled"] = "0"
s_off["ai_enabled"] = "0"
html_off = ui.header(s_off, "/businesses")
ck('href="/prices"' not in html_off, "disabled price comparison is not shown in accordion")
ck('href="/assistant"' not in html_off, "disabled assistant is not shown in accordion")
ck(not any_public_group_open(html_off),
   "optional-feature states also keep public category headers collapsed initially")

css = (ROOT / "site" / "assets" / "css" / "pages.css").read_text(encoding="utf-8")
js = (ROOT / "site" / "assets" / "js" / "app.js").read_text(encoding="utf-8")
ck('.mnav-group' in css and '.mnav-summary' in css and '.mnav-links' in css and '.mnav-current' in css,
   "accordion menu styles and current-category marker exist")
ck('resetPublicMenu' in js and 'data-public-nav-group' in js and 'summary,' in js,
   "drawer JavaScript resets stale opens and keeps focus trap usable")

# If a live server is provided (the full harness sets BZ), prove the accordion
# interaction in Chromium too: initial state collapsed, one downward section at
# a time, and a second click collapses the same section.
BASE = (os.environ.get("BZ") or "").rstrip("/")
if BASE:
    try:
        from playwright.sync_api import sync_playwright  # type: ignore
        with sync_playwright() as p:
            browser = p.chromium.launch(args=["--no-sandbox"])
            page = browser.new_page(viewport={"width": 390, "height": 844}, locale="fa-IR", is_mobile=True, has_touch=True)
            page.goto(BASE + "/", wait_until="domcontentloaded")
            page.click("[data-nav-toggle]")
            page.wait_for_selector("#mobile-nav.is-open [data-public-nav-group]")
            count = page.locator("#mobile-nav [data-public-nav-group]").count()
            ck(count >= 6, "browser sees grouped public accordion items")
            states = page.locator("#mobile-nav [data-public-nav-group]").evaluate_all("els => els.map(e => e.open)")
            ck(not any(states), "browser drawer opens with all public categories collapsed")
            page.locator("#mobile-nav .mnav-summary").nth(0).click()
            page.wait_for_timeout(150)
            states = page.locator("#mobile-nav [data-public-nav-group]").evaluate_all("els => els.map(e => e.open)")
            ck(states[0] is True and sum(1 for x in states if x) == 1,
               "clicking a main category opens only that category downward")
            page.locator("#mobile-nav .mnav-summary").nth(0).click()
            page.wait_for_timeout(150)
            states = page.locator("#mobile-nav [data-public-nav-group]").evaluate_all("els => els.map(e => e.open)")
            ck(not any(states), "clicking the open category closes it again")
            page.locator("#mobile-nav .mnav-summary").nth(0).click()
            page.locator("#mobile-nav .mnav-summary").nth(1).click()
            page.wait_for_timeout(150)
            states = page.locator("#mobile-nav [data-public-nav-group]").evaluate_all("els => els.map(e => e.open)")
            ck(states[1] is True and states[0] is False and sum(1 for x in states if x) == 1,
               "opening a different category closes the previous category")
            browser.close()
    except Exception as e:
        ck(False, "browser accordion interaction failed: " + str(e)[:120])

if fails:
    raise SystemExit(1)
print(f"OK {passes}/0")
