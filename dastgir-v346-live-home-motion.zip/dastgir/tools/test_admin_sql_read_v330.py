#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v330 stage-19: admin-copilot sql_read is genuinely read-only.

The admin assistant has a diagnostic sql_read tool. It must allow useful
inspection queries but must not become a write/DDL channel via PRAGMA, WITH, or
multiple-statement tricks.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))

import adminbot_content as CT  # noqa: E402

passes = 0
fails = 0


def ck(ok, msg):
    global passes, fails
    if ok:
        passes += 1
        print("✓", msg)
    else:
        fails += 1
        print("✗", msg)


src = (ROOT / "server" / "adminbot_content.py").read_text(encoding="utf-8")
ck("mode=ro" in src, "sql_read opens SQLite in read-only URI mode")
ck("PRAGMA query_only=ON" in src, "sql_read enables SQLite query_only")
ck("_SQL_MUTATION_RX" in src and "attach|detach" in src,
   "mutation and attach/detach keywords are blocked")
ck("_READ_PRAGMA_RX" in src and "table_info" in src and "foreign_key_list" in src,
   "only read-only diagnostic PRAGMAs are allowlisted")

ok, out = CT._exec_sql_read({"q": "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name LIMIT 1"})
ck(ok and "ردیف" in out, "plain SELECT still works")

ok, out = CT._exec_sql_read({"q": "PRAGMA table_info(businesses)"})
ck(ok and "name" in out.lower(), "read-only PRAGMA table_info still works")

for q, label in [
    ("PRAGMA foreign_keys=OFF", "state-changing PRAGMA is rejected"),
    ("WITH x AS (SELECT 1) DELETE FROM businesses", "WITH-prefixed DELETE is rejected"),
    ("SELECT 1; SELECT 2", "multiple statements are rejected"),
    ("ATTACH DATABASE '/tmp/x.db' AS x", "ATTACH is rejected"),
    ("UPDATE businesses SET name='x'", "UPDATE is rejected"),
]:
    ok, out = CT._exec_sql_read({"q": q})
    ck(not ok, label)

if fails:
    raise SystemExit(1)
print(f"OK {passes}/0")
