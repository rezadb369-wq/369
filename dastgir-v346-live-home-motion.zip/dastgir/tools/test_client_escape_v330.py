#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v330 stage-15: client-side HTML templates escape attribute contexts.

Map cards and story viewers build small HTML fragments from JSON payloads. The
payload ultimately comes from business/story records, so escaping must cover
quotes as well as angle brackets, and URL path pieces must be encoded.
"""
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
passes = 0
fails = 0


def ck(ok, msg):
    global passes, fails
    if ok:
        passes += 1
        print("✓", msg)
    else:
        fails += 1
        print("✗", msg)


def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")

m = read("site/assets/js/mappage.js")
s = read("site/assets/js/stories.js")
c = read("site/assets/js/catpicker.js")
n = read("site/assets/js/nearby.js")
cart = read("site/assets/js/cart.js")

ck("&quot;" in m and "&#39;" in m, "mappage escaper covers quotes and apostrophes")
ck("encodeURIComponent(String(rec.slug || ''))" in m,
   "map detail href uses URL-encoded slug")
ck("String(rec.phone || '').replace(/[^0-9+]/g, '')" in m,
   "map detail tel href is reduced to safe phone characters")
ck("Number.isFinite(latNum)" in m and "Number.isFinite(lngNum)" in m,
   "map directions href uses numeric lat/lng only")
ck("href=\"/b/${esc(rec.slug)}\"" not in m and "destination=${rec.lat},${rec.lng}" not in m,
   "raw map attribute interpolations were removed")

ck("&quot;" in s and "&#39;" in s, "stories escaper covers quotes and apostrophes")
ck("encodeURIComponent(String(group.slug || ''))" in s,
   "story business href uses URL-encoded slug")
ck("href=\"/b/${esc(group.slug)}\"" not in s,
   "raw story href interpolation was removed")

ck("&quot;" in c and "&#39;" in c, "catpicker escaper covers attribute quotes")
ck("current ? esc(current.t)" in c and "${esc(o.t)}" in c and "${esc(o.g)}" in c,
   "category names/groups are escaped before innerHTML")
ck("data-v=\"${esc(o.v)}\"" in c and "data-v=\"${o.v}\"" not in c,
   "category option values are escaped in data attributes")

ck("&quot;" in n and "&#39;" in n, "nearby escaper covers quotes and apostrophes")
ck("const slug = encodeURIComponent(b.slug || '')" in n and "href=\"/b/${slug}\"" in n,
   "nearby detail links use URL-encoded slugs")
ck("href=\"/b/${esc(b.slug)}\"" not in n,
   "raw nearby slug href interpolation was removed")

ck("const h=s=>" in cart and "&quot;" in cart and "&#39;" in cart,
   "cart page has full HTML/attribute escaper")
ck("${h(item.title)}" in cart and "${h(i.title)}" in cart,
   "cart item titles are escaped in both price modes")
ck("value=\"${h(cart[0].biz || '')}\"" in cart,
   "cart hidden business id is escaped before attribute insertion")
ck("num(i.price" in cart and "num(i.qty" in cart and "item_id: num(i.id" in cart,
   "cart numeric fields are normalised before rendering/submission")
ck("item.title.replace(/&/" not in cart and "(i.bizname||'').replace(/&/" not in cart,
   "old partial cart escaping was removed")

node = shutil.which("node")
if node:
    for rel in ("site/assets/js/mappage.js", "site/assets/js/stories.js", "site/assets/js/catpicker.js", "site/assets/js/nearby.js", "site/assets/js/cart.js"):
        r = subprocess.run([node, "--check", str(ROOT / rel)], text=True,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           timeout=10)
        ck(r.returncode == 0, f"{rel} parses under node --check")
else:
    ck(True, "node not installed; static JS checks completed")

if fails:
    raise SystemExit(1)
print(f"OK {passes}/0")
