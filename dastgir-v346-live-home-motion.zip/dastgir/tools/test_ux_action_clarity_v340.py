#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Guard v340 UX action clarity.

v340 is still organization-only: existing actions are labelled and grouped;
stock-notify copy points to existing notification/bot paths; no new route/schema.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
PASS = FAIL = 0


def ck(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("✓ " + name)
    else:
        FAIL += 1
        print("✗ " + name + (" — " + detail if detail else ""))


def rd(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


public = rd("server/views_public.py")
catalog = rd("server/views_catalog.py")
customer = rd("server/views_customer.py")
css = rd("site/assets/css/pages.css")

ck("business page action column has explicit quick-action heading",
   "biz-action-panel" in public and "اقدام‌های سریع" in public and "ذخیره و ارسال" in public)

ck("business action panel is styled without inline flex column",
   ".biz-action-panel" in css and "style=\"flex-direction:column;align-items:stretch" not in public)

ck("quick business actions still keep existing copy/share/vcard controls",
   all(x in public for x in ("data-copy-phone", "data-share", "/vcard/")))

ck("stock request copy points to existing notification/bot follow-up",
   "فرمان /stock" in catalog and "اعلان‌های حساب" in catalog)

ck("chat stock quick form explains owner-side queue without new UI",
   "صف موجودشدن دکان‌دار" in customer and "/me/chat/{tid}/notify-me" in customer)

ck("customer dashboard differentiates account from shop panel",
   "همهٔ بخش‌های حساب من" in customer and "جدا از پنل دکان" in customer)

ck("v340 made no new route or schema in touched view files",
   "CREATE TABLE" not in public + catalog + customer
   and not re.search(r"if path == \"/(me|my|b)/.*v340|/stock-requests|/actions\"", public + catalog + customer))

print(f"\n{PASS} passed, {FAIL} failed")
raise SystemExit(1 if FAIL else 0)
