# -*- coding: utf-8 -*-
"""v338 — مرکز کنترل ورود پنل در ربات بله و پنل ایجنت.

قفل‌ها:
  • دستور «ورودها» وضعیت نشست‌های پنل، تأییدهای بله، لینک‌های یک‌بارمصرف و
    کلیدهای ایجنت را نشان می‌دهد.
  • «خروج همه» بدون «بله» چیزی را حذف نمی‌کند؛ پس از تأیید، نشست‌های پنل،
    چالنج‌های بله، لینک‌های یک‌بارمصرف و کلیدهای ایجنت پاک می‌شوند.
  • همان قابلیت‌ها در مسیر مستقیم پنل ایجنت هم server-side وجود دارد.
"""

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / "server"
os.environ["BZ_DATA_DIR"] = tempfile.mkdtemp(prefix="dastgir-v338-sessions-")
os.environ["ADMINBOT_PENDING"] = os.path.join(tempfile.mkdtemp(prefix="dastgir-v338-pending-"), "pending.json")
os.environ["BALE_ADMIN_CHAT"] = "111"
os.environ["BALE_ADMIN_TOKEN"] = "tok"
os.environ["BALE_ADMIN_SECRET"] = "s" * 32
sys.path[:0] = [str(SERVER), str(ROOT)]

import db  # noqa: E402
import adminbot as A  # noqa: E402

G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
ok_n = bad_n = 0
FAILS = []


def ck(ok, msg, detail=""):
    global ok_n, bad_n
    if ok:
        ok_n += 1
        print("✓", msg)
    else:
        bad_n += 1
        FAILS.append(f"{msg} — {detail}")
        print("✗", msg, detail)


def counts():
    s = db.admin_session_stats()
    return {k: s.get(k, 0) for k in ("unlocked", "locked", "pending_approvals", "entry_tokens", "agent_keys")}


print(f"\n{B}\033[36mآزمون v338 مرکز کنترل ورود پنل{X}")
db.init()
db.set_owner_pass("pw338")

# Seed live access state.
s_unlocked = db.admin_session_new(locked=False)
s_locked = db.admin_session_new(locked=True)
code = db.panel_approval_new(s_locked, "1.2.3.4", purpose="pre_password")
entry, _ = db.panel_entry_new("1.2.3.4", ttl=300)
ag, _ = db.agent_key_new(ip="test", ttl=300)
db.log("panel.login", "success via bale+password ip=1.2.3.4")

st = counts()
ck(st["unlocked"] >= 1, "نشست باز شمرده می‌شود", st)
ck(st["locked"] >= 1, "نشست قفل/در انتظار شمرده می‌شود", st)
ck(st["pending_approvals"] >= 1, "تأیید بله در انتظار شمرده می‌شود", st)
ck(st["entry_tokens"] >= 1, "لینک یک‌بارمصرف زنده شمرده می‌شود", st)
ck(st["agent_keys"] >= 1, "کلید ایجنت زنده شمرده می‌شود", st)

msg = A.panel_login_status_text()
ck("وضعیت ورود پنل مدیریت" in msg and "نشست‌های باز پنل" in msg and "لینک‌های ورود یک‌بارمصرف" in msg,
   "متن وضعیت ورود کامل است")
ck("success via bale+password" in msg, "رویداد اخیر ورود نمایش داده می‌شود")

r, _ = A.handle_text("u", "111", "ورودها")
ck("وضعیت ورود پنل مدیریت" in r and "خروج همه" in r, "دستور ربات «ورودها» کار می‌کند")

r, _ = A.handle_text("u", "111", "خروج همه")
ck("بفرست: بله" in r or "بله" in r, "خروج همه اول تأیید می‌خواهد")
st2 = counts()
ck(st2["unlocked"] >= 1 and st2["entry_tokens"] >= 1 and st2["agent_keys"] >= 1,
   "قبل از بله چیزی حذف نمی‌شود", st2)

r, _ = A.handle_text("u", "111", "بله")
ck("همهٔ دسترسی‌های مدیریتی بسته شد" in r, "بله خروج همه را اجرا می‌کند")
st3 = counts()
ck(st3["unlocked"] == 0 and st3["locked"] == 0 and st3["pending_approvals"] == 0
   and st3["entry_tokens"] == 0 and st3["agent_keys"] == 0,
   "همهٔ نشست‌ها/تأییدها/لینک‌ها/کلیدهای ایجنت حذف شدند", st3)

# Source-level guard for the agent panel direct path.
app_src = (SERVER / "app.py").read_text(encoding="utf-8")
ck('source": "panel_login_status"' in app_src and 'source": "panel_revoke"' in app_src,
   "پنل ایجنت مسیر مستقیم وضعیت و خروج همه دارد")
ck("تأیید خروج همه" in app_src, "پنل ایجنت برای خروج همه تأیید صریح می‌خواهد")

help_text = A.do_help()[0]
ck("ورودها" in help_text and "خروج همه" in help_text, "راهنما دستورهای جدید را معرفی می‌کند")

if bad_n:
    print(f"\n{R}{B}نتیجه: {ok_n} قبول / {bad_n} رد{X}")
    for f in FAILS:
        print("  -", f)
    sys.exit(1)
print(f"\n{G}{B}نتیجه: همهٔ {ok_n} آزمون سبز شد.{X}")
