#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Guard v345 obvious live motion.

v344 was too subtle for the owner. v345 must make the requested motion visible:
a dedicated after-hero motion stage, large scroll-triggered counters, typing text,
and scroll reveal on mobile too — while preserving the no-new-product-capability
boundary.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
PASS = FAIL = 0

def ck(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1; print("✓ " + name)
    else:
        FAIL += 1; print("✗ " + name + (" — " + detail if detail else ""))

def rd(rel):
    return (ROOT / rel).read_text(encoding="utf-8")

public = rd("server/views_public.py")
js = rd("site/assets/js/app.js")
css = rd("site/assets/css/pages.css")

reveal_block = js[js.find("function initReveal()"):js.find("/* -------------------------------------------------------------------------\n   5. PARALLAX")]
count_block = js[js.find("function initCountUp()"):js.find("/* -------------------------------------------------------------------------\n   6b. LIVE TYPE REVEAL")]
css_v345 = css[css.find("v345 — Obvious live motion stage"):]

ck("homepage has a dedicated obvious motion stage right after hero",
   "motion_stage = f'''" in public
   and "h-motion-section" in public
   and "زنده روی اسکرول" in public
   and "وقتی پایین می‌آیید، شهر جلوی چشم زنده می‌شود" in public
   and "{motion_stage}" in public and public.find("{motion_stage}") < public.find("{route_board}"))

ck("motion stage contains large scroll-triggered counters",
   all(x in public for x in ("h-motion-stat", "data-count=\"{_motion_routes}\"", "data-count=\"{_motion_cats}\"", "data-count=\"{_motion_owner_tools}\"", "data-count=\"{_motion_groups}\"")))

ck("scroll reveal is no longer disabled on coarse/mobile pointers",
   "function initReveal()" in reveal_block
   and "IntersectionObserver" in reveal_block
   and "pointer: coarse" not in reveal_block
   and "window.matchMedia('(pointer: coarse)')" not in reveal_block)

ck("counter supports animated start/end and remains IntersectionObserver-driven",
   "dataset.countFrom" in count_block
   and "start + (target - start) * eased" in count_block
   and "IntersectionObserver" in count_block
   and "requestAnimationFrame(step)" in count_block)

ck("v345 CSS is intentionally visible, not subtle",
   all(x in css_v345 for x in (".h-motion-shell", "min-height", "v345StageSweep", "v345Scan", "v345MiniSweep", "font-size: clamp(2.4rem", "filter: blur(12px)", "translate3d(0, 54px")))

ck("reduced motion disables the new animation layer",
   "@media (prefers-reduced-motion: reduce)" in css_v345
   and all(x in css_v345 for x in (".h-motion-shell::before", ".h-motion-aurora", ".h-motion-stat::after", ".h-motion-scan span")))

ck("v345 still adds no route/schema/external runtime dependency",
   "CREATE TABLE" not in public
   and "@app.route" not in public
   and "https://" not in css_v345
   and not re.search(r"<script[^>]+src=", public[public.find("motion_stage = f'''"):public.find("route_board = f'''")], re.S))

print(f"\n{PASS} passed, {FAIL} failed")
raise SystemExit(1 if FAIL else 0)
