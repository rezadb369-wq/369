#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v332: admin panel information architecture stays organized.

The panel had grown into a long, duplicated wall of links. This guard keeps the
new workflow-based grouping and the dashboard route map from regressing.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))

import ui  # noqa: E402
import db  # noqa: E402
import views_panel  # noqa: E402

passes = 0
fails = 0


def ck(ok, msg):
    global passes, fails
    if ok:
        passes += 1
        print("✓", msg)
    else:
        fails += 1
        print("✗", msg)


groups = ui.OWNER_NAV_GROUPS
names = [g for g, _ in groups]
links = [h for _, items in groups for h, _, _ in items]

ck(names == ["ایجنت", "عملیات روزانه", "کسب‌وکار و محتوای شهر",
             "مشتری، اعتماد و کیفیت", "درآمد و بازاریابی", "تنظیمات و سیستم"],
   "admin navigation uses six standard workflow groups")
ck(len(links) == len(set(links)), "admin navigation has no duplicate destinations")
ck(groups[0][0] == "ایجنت" and [x[0] for x in groups[0][1]][:2] == ["/panel/agent", "/panel"],
   "owner contract keeps agent first with dashboard under it")
ck({"/panel/moderation", "/panel/orders", "/panel/bookings", "/panel/tickets"}.issubset(set(links)),
   "daily operations group keeps the main queues discoverable")
ck({"/panel/businesses", "/panel/categories", "/panel/stories", "/panel/posts"}.issubset(set(links)),
   "content group keeps core publishing tools discoverable")
ck({"/panel/settings", "/panel/backup", "/panel/appearance", "/panel/audit"}.issubset(set(links)),
   "system group keeps admin maintenance tools discoverable")

css = (ROOT / "site" / "assets" / "css" / "pages.css").read_text(encoding="utf-8")
ck(".panel-quick-grid" in css and ".panel-quick-section" in css and ".panel-quick-links" in css,
   "dashboard quick-map styles exist")
ck("width: 286px" in css and "grid-template-columns: minmax(0, 286px)" in css,
   "sidebar width is standardized for long Persian labels")
ck(".panel-nav-group" in css and "border: 1px solid" in css,
   "sidebar groups are visually separated")

s = db.get_settings()
html = views_panel.dashboard(s, "test-token")
ck("نقشهٔ کار پنل" in html and "عملیات روزانه" in html and "درآمد و سیستم" in html,
   "dashboard renders the organized panel route map")
ck("کارهای در انتظار بررسی مدیر" in html and "آخرین کسب‌وکارهای ثبت‌شده" in html,
   "dashboard keeps operational overview sections")

if fails:
    raise SystemExit(1)
print(f"OK {passes}/0")
