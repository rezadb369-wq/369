#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v330 stage-16: public map must not depend on unpkg/CDN Leaflet fallback."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
passes = 0
fails = 0


def ck(ok, msg):
    global passes, fails
    if ok:
        passes += 1
        print("✓", msg)
    else:
        fails += 1
        print("✗", msg)

app = (ROOT / "server" / "app.py").read_text(encoding="utf-8")
mapjs = (ROOT / "site" / "assets" / "js" / "map.js").read_text(encoding="utf-8")
sw = (ROOT / "site" / "sw.js").read_text(encoding="utf-8")

ck("https://unpkg.com" not in app, "CSP no longer allowlists unpkg")
ck("https://unpkg.com" not in mapjs and "OSM_JS_CDN" not in mapjs,
   "map.js has no unpkg Leaflet fallback")
ck("/assets/vendor/leaflet/leaflet.css" in sw and "/assets/vendor/leaflet/leaflet.js" in sw,
   "vendored Leaflet assets are pre-cached by service worker")
ck((ROOT / "site/assets/vendor/leaflet/leaflet.css").is_file()
   and (ROOT / "site/assets/vendor/leaflet/leaflet.js").is_file(),
   "vendored Leaflet files exist in release tree")
ck("script-src 'self' 'unsafe-inline' https://maps.googleapis.com https://www.googletagmanager.com" in app,
   "script-src keeps only explicit Google hosts plus nonce/self")
ck("style-src 'self' 'unsafe-inline';" in app,
   "style-src does not allow third-party stylesheets")

node = shutil.which("node")
if node:
    r = subprocess.run([node, "--check", str(ROOT / "site/assets/js/map.js")],
                       text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       timeout=10)
    ck(r.returncode == 0, "map.js parses under node --check")
else:
    ck(True, "node not installed; static checks completed")

if fails:
    raise SystemExit(1)
print(f"OK {passes}/0")
