#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Guard v339 organization-only UX consolidation.

This suite intentionally checks that v339 surfaces existing capabilities
(favorites, QR, owner queues) without adding new routes or schema.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
PASS = FAIL = 0


def ck(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("✓ " + name)
    else:
        FAIL += 1
        print("✗ " + name + (" — " + detail if detail else ""))


def rd(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


views_customer = rd("server/views_customer.py")
views_public = rd("server/views_public.py")
views_owner = rd("server/views_owner.py")
ui = rd("server/ui.py")
handoff = rd("docs/collaboration/HANDOFF.md")
research = rd("docs/collaboration/UX-ORG-RESEARCH-v339.md")

ck("research report is wired into HANDOFF",
   "UX-ORG-RESEARCH-v339.md" in handoff and "قابلیت جدید نسازیم" in handoff)

ck("customer dashboard opens synced favorites, not local guest list",
   'href="/me/favorites"' in views_customer and "مشاهدهٔ همگام‌شده" in views_customer)

ck("public favorites explains local-device vs synced account list",
   "فهرست محلی همین دستگاه" in views_public and 'href="/me/favorites"' in views_public)

ck("owner quick actions surface existing QR route",
   'href="/my/qr?bid={b0["id"]}"' in views_owner and "بارکد ویترین" in views_owner)

ck("owner dashboard has organization-only today queue hub",
   "امروز چه کاری دارید؟" in views_owner and "فقط صف‌های موجود" in views_owner
   and "No new system is created" in views_owner)

ck("today hub only links to existing owner routes",
   all(x in views_owner for x in ('"/my/chats"', '"/my/bookings"', '"/my/reviews"', '"/my/broadcast"')))

ck("bottom-nav comments match current v86 behavior",
   "Everyone else\n    # keeps «اخبار شهر»" not in ui and "v339: comment-only cleanup" in ui)

ck("research report forbids new-feature drift",
   "کدنویسی ممنوع" in research and "route جدید بدون ضرورت نساز" in research)

# Extra safety: v339 must not introduce schema or route changes in the touched files.
ck("no schema/route addition in organization-only view changes",
   "CREATE TABLE" not in views_owner + views_customer + views_public
   and not re.search(r"if path == \"/me/stock\"|if path == \"/my/today\"", views_owner + views_customer + views_public))

print(f"\n{PASS} passed, {FAIL} failed")
raise SystemExit(1 if FAIL else 0)
