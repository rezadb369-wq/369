#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Guard v342 visible UX scope cards.

After the user noted they could not see a visual difference, v342 makes the
organization-only guidance visually obvious on existing public surfaces — no
new routes, schema, or features.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
PASS = FAIL = 0


def ck(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("✓ " + name)
    else:
        FAIL += 1
        print("✗ " + name + (" — " + detail if detail else ""))


def rd(rel):
    return (ROOT / rel).read_text(encoding="utf-8")

public = rd("server/views_public.py")
catalog = rd("server/views_catalog.py")
css = rd("site/assets/css/pages.css")
ui = rd("server/ui.py")

ck("business directory has a prominent visual scope card",
   "ux-scope-card ux-scope-card-shops" in public
   and "اینجا فهرست دکان‌هاست" in public
   and "scope-pill is-current" in public
   and 'href="/catalog"' in public)

ck("catalog has a prominent visual scope card",
   "ux-scope-card ux-scope-card-catalog" in catalog
   and "اینجا ویترین محصول و خدمت است" in catalog
   and "scope-pill is-current" in catalog
   and 'href="/businesses"' in catalog)

ck("visual scope cards use noticeable card/pill styling",
   all(x in css for x in (".ux-scope-card", ".ux-scope-icon", ".ux-scope-actions", ".scope-pill", "radial-gradient", "box-shadow: var(--e2)")))

ck("visual cards remain mobile-friendly",
   "@media (max-width: 720px)" in css
   and ".scope-pill { flex: 1 1 130px; justify-content: center; }" in css)

ck("owner/customer mobile labels remain separated",
   'fourth = ("/my", "پنل دکان", "store")' in ui
   and 'last = ("/me", "حساب من", "user")' in ui)

ck("v342 still adds no route or schema",
   "CREATE TABLE" not in (public + catalog + ui)
   and not re.search(r"if path == \"/(catalog|businesses).*(scope|switch|v342)|@route|route\(", public + catalog + ui))

print(f"\n{PASS} passed, {FAIL} failed")
raise SystemExit(1 if FAIL else 0)
