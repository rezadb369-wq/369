#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Guard v344 live/luxury motion layer.

This stage deliberately adds lightweight front-end behaviour (typing reveal,
scroll-triggered counters, and restrained visual shimmer) while keeping the
product surface unchanged: no new routes, schema, product capability, or external
runtime dependency.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
PASS = FAIL = 0


def ck(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("✓ " + name)
    else:
        FAIL += 1
        print("✗ " + name + (" — " + detail if detail else ""))


def rd(rel):
    return (ROOT / rel).read_text(encoding="utf-8")

public = rd("server/views_public.py")
js = rd("site/assets/js/app.js")
css = rd("site/assets/css/pages.css")

count_block = js[js.find("function initCountUp()"):js.find("/* -------------------------------------------------------------------------\n   6b. LIVE TYPE REVEAL")]
type_block = js[js.find("function liveTextParts"):js.find("/* -------------------------------------------------------------------------\n   7. TOASTS")]
css_v344 = css[css.find("v344 — Live/Luxury motion layer"):]

ck("homepage hero and route chooser use live typing reveal",
   "<h1 class=\"kinetic-type\" data-live-type" in public
   and "data-live-text=\"{esc(s.get('hero_title', ''))}\"" in public
   and "<h2 class=\"kinetic-type\" data-live-type" in public
   and "امروز دنبال چه هستید؟" in public)

ck("route chooser gets a visible live/luxury motion surface",
   "h-route-board live-luxe-card reveal" in public
   and all(x in css_v344 for x in (".live-luxe-card::after", "hRouteGlow", ".h-route-card::after")))

ck("count-up is scroll-triggered and no longer disabled on mobile/coarse pointers",
   "function initCountUp()" in js
   and "dataset.countDone" in count_block
   and "IntersectionObserver" in count_block
   and "rootMargin: '0px 0px -10% 0px'" in count_block
   and "pointer: coarse" not in count_block)

ck("typing reveal is original lightweight JS, not an external dependency",
   all(x in type_block for x in ("function liveTextParts", "Intl.Segmenter", "replaceChildren", "setTimeout(tick"))
   and "https://" not in type_block
   and "import(" not in type_block)

ck("motion respects reduced-motion in CSS and JS",
   "prefersReduced()" in count_block
   and "prefersReduced()" in type_block
   and "@media (prefers-reduced-motion: reduce)" in css_v344
   and all(x in css_v344 for x in (".kinetic-type.is-typing::after", ".live-luxe-card::after", ".js .h-route-board .h-route-card")))

ck("visual effects stay on performant opacity/transform animations",
   all(x in css_v344 for x in ("transform:", "opacity:", "translate3d", "@keyframes hAuroraDrift", "@keyframes hSpecularSweep", "@keyframes statBreath"))
   and not re.search(r"@keyframes\s+\w+[^{}]*{[^{}]*(?:width|height|top|left|right|bottom)\s*:", css_v344, re.S))

_home_start = public.find("<section class=\"h-hero\"")
_home_end_candidates = [x for x in (public.find("\n{motion_stage}"), public.find("\n{route_board}")) if x != -1]
_home_intro = public[_home_start:(min(_home_end_candidates) if _home_end_candidates else _home_start)]
ck("v344/v345 motion adds no route, schema, or external runtime asset",
   "CREATE TABLE" not in public
   and "@app.route" not in public
   and "https://" not in css_v344
   and not re.search(r"<script[^>]+src=", _home_intro, re.S))

print(f"\n{PASS} passed, {FAIL} failed")
raise SystemExit(1 if FAIL else 0)
