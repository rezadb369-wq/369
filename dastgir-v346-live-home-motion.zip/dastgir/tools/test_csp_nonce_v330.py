#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""نگهبان ساختاری CSP nonce (v330).

چرا این تست وجود دارد
---------------------
در v330 عبارت 'unsafe-inline' از script-src حذف شد و جایش nonce نشست.
از آن لحظه به بعد، هر تگ <script> درون‌خطی که nonce نگیرد، در مرورگر
**بی‌صدا اجرا نمی‌شود**: صفحه ۲۰۰ برمی‌گردد، ظاهرش سالم است، ولی آن
قابلیت مرده است. دقیقاً همان بیماری‌ای که ممیزی v330 در شش جای دیگر پیدا
کرد (تگ‌های دارایی شکسته‌ای که هیچ تستی محتوایشان را بررسی نمی‌کرد).

پیمایش زنده نمی‌تواند این را تضمین کند، چون بسیاری از اسکریپت‌ها فقط در
حالت‌های نادر رندر می‌شوند (انتظار اتصال ربات، سطل زباله، دروازهٔ پرداخت،
صفحهٔ تأیید). پس این تست به‌جای رفتار، **سورس** را بررسی می‌کند و همین،
پوشش شاخه‌های دست‌نیافتنی را هم تضمین می‌کند.

قاعده
-----
هر <script> بدون src در server/*.py باید یکی از این‌ها باشد:
  ۱) nonce را درون‌یابی کند:  <script{nonce_attr()}>  یا  <script{ui.nonce_attr()}>
  ۲) با الحاق رشته nonce بگیرد:  '<script' + ui.nonce_attr() + '>'
  ۳) بلوک داده باشد: type="application/ld+json" یا type="application/json"
     (مرورگر اجرایشان نمی‌کند و CSP هم بررسی‌شان نمی‌کند — آزموده‌شده)
  ۴) داخل یک قطعهٔ ثابتِ پیچیده‌شده در ui.add_nonce(...) باشد

⚠ و یک قاعدهٔ منفی که به همان اندازه مهم است: nonce هرگز نباید با
پس‌پردازشِ HTML نهایی اضافه شود. آن کار به اسکریپت تزریق‌شدهٔ مهاجم هم
nonce معتبر می‌دهد و کل محافظت را بی‌اثر می‌کند.
"""
import ast
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SERVER = os.path.join(ROOT, "server")

SCRIPT_OPEN = re.compile(r'<script(?![^>]*\bsrc\s*=)([^>]*)>')
DATA_TYPES = ('application/ld+json', 'application/json')
NONCE_INLINE = ('{nonce_attr()}', '{ui.nonce_attr()}')

passed = 0
failed = 0


def check(name, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print("  ✓ %s" % name)
    else:
        failed += 1
        print("  ✗ %s  %s" % (name, detail))


def docstring_lines(src):
    """شماره‌خط همهٔ docstringها را برمی‌گرداند.

    بدون این، توضیحاتی که خودِ قاعده را شرح می‌دهند (مثل docstring تابع
    json_embed که دربارهٔ «</script><script>» هشدار می‌دهد) به‌اشتباه
    تخلف شمرده می‌شوند.
    """
    out = set()
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return out
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Module, ast.FunctionDef,
                                 ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        body = getattr(node, 'body', None)
        if not body:
            continue
        first = body[0]
        if (isinstance(first, ast.Expr)
                and isinstance(first.value, ast.Constant)
                and isinstance(first.value.value, str)):
            for n in range(first.lineno, (first.end_lineno or first.lineno) + 1):
                out.add(n)
    return out


def enclosing_add_nonce(lines, i):
    """آیا این خط داخل یک قطعهٔ ثابتِ پیچیده‌شده در ui.add_nonce(...) است؟

    به عقب نگاه می‌کنیم تا آغاز نزدیک‌ترین رشتهٔ سه‌نقل‌قولی که با
    add_nonce( باز شده باشد.
    """
    for j in range(i, max(-1, i - 400), -1):
        if 'add_nonce(' in lines[j] and ('"""' in lines[j] or "'''" in lines[j]):
            return True
        # اگر به یک def سطح‌بالا رسیدیم و هنوز add_nonce ندیدیم، بس است
        if re.match(r'^def \w+', lines[j]) and j < i:
            return False
    return False


def main():
    print("— نگهبان CSP nonce —\n")
    offenders = []
    for fn in sorted(os.listdir(SERVER)):
        if not fn.endswith('.py'):
            continue
        path = os.path.join(SERVER, fn)
        with open(path, encoding='utf-8') as fh:
            src = fh.read()
        lines = src.split('\n')
        docs = docstring_lines(src)
        for i, ln in enumerate(lines):
            stripped = ln.strip()
            if stripped.startswith('#'):
                continue
            for m in SCRIPT_OPEN.finditer(ln):
                attrs = m.group(1)
                if 'nonce' in attrs:
                    continue
                if any(d in attrs for d in DATA_TYPES):
                    continue
                if (i + 1) in docs:          # داخل docstring
                    continue
                if 'markup.replace' in ln:   # خودِ پیاده‌سازی add_nonce
                    continue
                if enclosing_add_nonce(lines, i):
                    continue
                offenders.append('%s:%d  %s' % (fn, i + 1, stripped[:70]))

    check('هیچ <script> درون‌خطیِ بدون nonce در server/*.py نیست',
          not offenders,
          '\n      ' + '\n      '.join(offenders))

    # سیاست باید nonce بگیرد، نه 'unsafe-inline'
    app = open(os.path.join(SERVER, 'app.py'), encoding='utf-8').read()
    check("script-src در هدر با nonce جایگزین می‌شود",
          "script-src 'self' 'nonce-%s' " in app)

    # قاعدهٔ منفی: نباید جایی nonce را روی HTML نهایی با regex بچسباند
    bad_post = re.search(r'sub\([^)]*nonce=', app)
    check('nonce با پس‌پردازشِ regex روی خروجی اضافه نمی‌شود',
          bad_post is None,
          'پس‌پردازش به اسکریپت مهاجم هم nonce می‌دهد')

    ui_src = open(os.path.join(SERVER, 'ui.py'), encoding='utf-8').read()
    check('جانشین nonce تصادفی و درون‌فرایندی است',
          'NONCE_PH = "cspnonceph" + secrets.token_hex(16)' in ui_src)
    check('ui.swap_nonce در لایهٔ ارسال وجود دارد', 'def swap_nonce(' in ui_src)
    check('ui.nonce_attr وجود دارد', 'def nonce_attr(' in ui_src)

    print('\nنتیجه: %d قبول، %d رد' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
