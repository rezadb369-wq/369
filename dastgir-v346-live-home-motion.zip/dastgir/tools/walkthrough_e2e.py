# -*- coding: utf-8 -*-
"""
End-to-end walkthrough — actually DRIVES the site like a human, then re-reads
the database to prove each action landed. Not the unit suite; this is the
"does the whole thing feel alive" pass: owner signs in, opens a shop, adds
goods; a customer signs in, orders, chats; a visitor reviews, asks, books,
inquires and haggles.
"""
import os, sys, re, json, time, atexit
import urllib.parse, urllib.request, http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa

BASE = os.environ.get("BZ", "http://127.0.0.1:8080")

PASS, FAIL = [], []


def ok(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(("  \u2713 " if cond else "  \u2717 ") + name + (f"  [{detail}]" if detail and not cond else ""))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def client():
    jar = http.cookiejar.CookieJar()
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar), NoRedirect())
    return jar, op


def get(op, path):
    req = urllib.request.Request(BASE + path, headers={"User-Agent": "bz-e2e"})
    try:
        r = op.open(req, timeout=20)
        return r.getcode(), r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


def post(op, path, data):
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(BASE + path, data=body, headers={
        "User-Agent": "bz-e2e",
        "Content-Type": "application/x-www-form-urlencoded"})
    try:
        r = op.open(req, timeout=20)
        return r.getcode(), r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


def extract_code(html):
    # offline OTP is echoed on-screen inside a <strong class="nums" …> tag
    # styled with letter-spacing. The code is 5 digits.
    m = re.search(r'letter-spacing:\.2em">([0-9]{4,6})<', html)
    if not m:
        m = re.search(r'class="nums"[^>]*>([0-9]{4,6})<', html)
    if not m:
        m = re.search(r'کد اینجا نمایش داده[^<]*<[^>]*>([0-9]{4,6})<', html)
    return m.group(1) if m else None


def main():
    # Price/order routes are intentionally disabled in production until the
    # administrator opts in. This E2E owns its prerequisite and restores the
    # prior state both on a normal return and on an unexpected exception.
    saved_prices = db.get_settings().get("prices_enabled", "0")
    db.set_setting("prices_enabled", "1")
    atexit.register(db.set_setting, "prices_enabled", saved_prices)

    print("\n" + "\u2550" * 60)
    # battery-order safety: if an earlier suite wiped the demo shops,
    # reseed so this E2E always has a living town to walk through
    if not db.businesses(status="published"):
        import seed_demo
        seed_demo.seed()
        print("  (data reseeded)")
    print("  \u2160) صاحب کسب‌وکار: نشست پیام‌رسانی → ویزارد ثبت → افزودن کالا")
    print("\u2550" * 60)
    jar, ow = client()
    phone = "09121234567"
    # v193+: ورود سایت فقط از راه بله/سروش است؛ نشست مالک مستقیم ساخته می‌شود.
    _own = db.owner_by_phone(phone, create=True); db.customer_by_phone(phone, create=True)
    jar.set_cookie(http.cookiejar.Cookie(0, "bzv2_sess", db.session_new(_own["id"]), None, False, "127.0.0.1", False, False,
                                         "/", True, False, None, False, None, None, {}))
    c, h = get(ow, "/my/businesses")
    ok("داشبورد کسب‌وکارهای من باز شد", c == 200, str(c))
    # v208: ثبت از ویزارد مرحله‌ای
    import re as _re, bot_register as _R
    _R.cancel(db.customer_by_phone(phone)["id"])
    RB = "/register-business"
    c, h = post(ow, RB + "/category", {"cat_slug": "cafe"}); ok("ویزارد: دسته", c == 303, str(c))
    c, h = post(ow, RB + "/identity", {"name": "کافهٔ اکسیر تست", "descr": "قهوه و دسر — دکانٔ تستی راه‌اندازی شد.",
                                        "tags": "نمونه‌آزمایشی،تست،راه‌اندازی"}); ok("ویزارد: معرفی", c == 303, str(c))
    c, h = post(ow, RB + "/location", {"province": "اصفهان", "city": "نجف‌آباد", "address": "نجف‌آباد، بلوار اصلی، پلاک ۱"}); ok("ویزارد: مکان", c == 303, str(c))
    c, h = post(ow, RB + "/contact", {"phone_public": "1"}); ok("ویزارد: تماس", c == 303, str(c))
    c, h = post(ow, RB + "/hours", {"preset": "allday"}); ok("ویزارد: ساعت", c == 303, str(c))
    c, h = post(ow, RB + "/images/done", {}); ok("ویزارد: تصاویر", c == 303, str(c))
    c, h = get(ow, RB + "/preview")
    _m = _re.search(r'name="confirm" value="([A-Za-z0-9_-]+)"', h or "")
    ok("ویزارد: پیش‌نمایش + توکن", c == 200 and bool(_m), str(c))
    c, h = post(ow, RB + "/submit", {"confirm": _m.group(1) if _m else "", "accept": "1"})
    ok("ویزارد: ثبت نهایی", c == 303, str(c))
    created = None
    for b in db.businesses(status=None):
        if b.get("name") == "کافهٔ اکسیر تست":
            created = b
    ok("دکان در دیتابیس ثبت شد", bool(created), created["slug"] if created else "none")
    if created:
        # add a catalogue item through the owner quick-add
        c, h = post(ow, f"/my/catalog/{created['id']}/quick",
                    {"title": "اسپرسو دبل", "price": "85000"})
        items = [i for i in db.items() if i.get("biz_id") == created["id"]]
        ok("کالای کاتالوگ اضافه شد", len(items) >= 1, f"{len(items)} مورد")

    print("\n" + "\u2550" * 60)
    print("  \u2161) مشتری: نشست پیام‌رسانی → سفارش → چت")
    print("\u2550" * 60)
    cjar, cu = client()
    cphone = "09121239999"
    # v193+: ورود مشتری فقط از بله/سروش؛ مسیر OTP قدیمی باید بسته باشد.
    c, h = post(cu, "/me/login", {"phone": cphone})
    ok("مسیر OTP قدیمی مشتری بسته است", c == 404, str(c))
    cust = db.customer_by_phone(cphone, create=True)
    cjar.set_cookie(http.cookiejar.Cookie(0, "bzv2_cust", db.customer_session_new(cust["id"]), None, False, "127.0.0.1", False, False,
                                          "/", True, False, None, False, None, None, {}))
    ok("مشتری در دیتابیس ساخته شد", bool(cust), str(cust["id"]) if cust else "none")
    # order against the demo restaurant
    demo = next((b for b in db.businesses(status=None)
                 if b.get("slug") == "restaurant"), None) or \
           next((b for b in db.businesses(status=None)), None)
    if demo:
        items = json.dumps([{"title": "چلوکباب کوبیده", "price": 290000, "qty": 2}])
        c, h = post(cu, "/order/create", {"biz_id": demo["id"], "name": "مشتری تست",
                                          "phone": cphone, "address": "خیابان تست",
                                          "note": "تست سفارش", "items": items})
        orders = db.orders_all() if hasattr(db, "orders_all") else []
        ok("سفارش ثبت شد", c in (303, 302), str(c))
        if cust:
            my_orders = db.orders_for_customer(cust["id"])
            ok("سفارش به حساب مشتری چسبید", len(my_orders) >= 1, f"{len(my_orders)}")
        # chat
        # v88: دکمهٔ گفتگو یک GET است که thread می‌سازد و به پیام‌رسان می‌برد
        c, h = get(cu, f"/b/{demo['slug']}/chat")
        ok("گفتگو شروع شد", c in (303, 302), str(c))

    print("\n" + "\u2550" * 60)
    print("  \u2162) بازدیدکننده: نظر، پرسش، نوبت، استعلام، چانه‌زنی، تماس")
    print("\u2550" * 60)
    _, g = client()
    if demo:
        c, h = post(g, f"/b/{demo['slug']}/review",
                    {"author": "بازدیدکننده تست", "rating": "5", "body": "عالی بود، تجربهٔ خوبی داشتم."})
        ok("نظر ثبت شد (در انتظار تأیید)", c in (303, 302), str(c))
        c, h = post(g, f"/b/{demo['slug']}/ask-question", {"asker": "علی", "body": "ساعت کاری شما چیست؟"})
        ok("پرسش ثبت شد", c in (303, 302), str(c))
        c, h = post(g, f"/b/{demo['slug']}/book", {"name": "زهرا", "phone": "09120001122",
                                                   "date": "2026-08-25", "time": "19:00", "note": ""})
        ok("نوبت رزرو شد", c in (303, 302), str(c))
        # v88: استعلام ناشناس /ask حذف شد؛ مهمان به ورود مشتری هدایت می‌شود
        c, h = get(g, f"/b/{demo['slug']}/chat")
        ok("مهمان برای گفتگو به ورود هدایت می‌شود", c in (303, 302), str(c))
    c, h = post(g, "/contact", {"name": "تست", "email": "t@t.ir", "subject": "تست تماس", "body": "پیام آزمایشی"})
    ok("فرم تماس قدیمی به ورود تیکت هدایت شد", c in (303, 302), str(c))
    # Haggle on a haggle-enabled item. The production default is deliberately
    # off; an E2E test must enable its own prerequisite and restore it instead
    # of depending on whichever setting a previous suite left behind.
    hitem = next((i for i in db.items() if i.get("haggle") and i.get("price")), None)
    if hitem:
        _haggle_before = db.get_settings().get("haggle_enabled", "0")
        db.set_setting("haggle_enabled", "1")
        try:
            c, h = post(g, f"/haggle/{hitem['id']}", {"offer": "200000", "name": "تست",
                                                      "phone": "09120005566", "qty": "1"})
            ok("پیشنهاد چانه‌زنی ثبت شد", c in (200, 303), str(c))
        finally:
            db.set_setting("haggle_enabled", _haggle_before)

    print("\n" + "\u2550" * 60)
    print("  \u2163) تأیید نهایی از روی دیتابیس")
    print("\u2550" * 60)
    s = db.stats()
    ok("کسب‌وکار منتشرشده > 0", s["businesses"] > 0, str(s["businesses"]))
    ok("نظر در سیستم ثبت شده", s["reviews"] >= 0, str(s["reviews"]))
    print("\n" + "\u2550" * 60)
    print(f"  نتیجه: {len(PASS)} موفق ، {len(FAIL)} ناموفق")
    print("\u2550" * 60)
    db.set_setting("prices_enabled", saved_prices)
    return 1 if FAIL else 0


if __name__ == "__main__":
    db.init()
    db.rate_clear()  # a scripted run posts faster than a human; clear buckets
    sys.exit(main())
