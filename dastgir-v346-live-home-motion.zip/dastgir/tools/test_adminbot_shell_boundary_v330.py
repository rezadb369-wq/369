#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v330 stage-8 guard for the intentional owner terminal (`sh ...`).

The `shell=True` calls in adminbot/adminbot_content are not accidental string
injection sinks; they are privileged owner terminal features. This test keeps
the security boundary explicit:
  * only a private owner chat may reach direct `sh ...`;
  * the optional phone/password bot gate blocks shell before activation;
  * AI-proposed `shell_exec` remains a confirm-required tool, not immediate.
"""
import os
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = Path(tempfile.mkdtemp(prefix="dg-shell-boundary-"))
DATA = TMP / "data"
DATA.mkdir(parents=True, exist_ok=True)

os.environ["BZ_DATA_DIR"] = str(DATA)
os.environ["BALE_ADMIN_SECRET"] = "s" * 40
os.environ["BALE_ADMIN_CHAT"] = "999000111"
os.environ["BALE_ADMIN_TOKEN"] = ""  # avoid any real network call in sendMessage
os.environ.pop("BOT_GATE_PHONE", None)
os.environ.pop("BOT_GATE_PHONE_HASH", None)
os.environ.pop("BOT_GATE_PASS", None)
os.environ.pop("BOT_GATE_PASS_HASH", None)
os.environ["ADMINBOT_PENDING"] = str(TMP / "pending.json")

sys.path.insert(0, str(ROOT / "server"))
import db  # noqa: E402
import adminbot as A  # noqa: E402
import adminbot_content as CT  # noqa: E402

db.init()
A.send_message = lambda *a, **kw: True
A.delete_message = lambda *a, **kw: True

fails = 0
passes = 0

def ck(ok, msg):
    global fails, passes
    if ok:
        passes += 1
        print("✓", msg)
    else:
        fails += 1
        print("✗", msg)

def upd(update_id, chat_id, text, typ="private", from_id=None, extra=None):
    msg = {
        "message_id": update_id,
        "date": 1,
        "chat": {"id": chat_id, "type": typ},
        "from": {"id": from_id if from_id is not None else chat_id, "is_bot": False},
    }
    if text is not None:
        msg["text"] = text
    if extra:
        msg.update(extra)
    return {"update_id": update_id, "message": msg}

try:
    owner = TMP / "owner.txt"
    nonowner = TMP / "nonowner.txt"
    group = TMP / "group.txt"

    A.handle_update(upd(1, 999000111, f"sh /usr/bin/id > {owner}"))
    ck(owner.exists() and "uid=" in owner.read_text(encoding="utf-8", errors="replace"),
       "positive control: private owner chat can run the intentional terminal")

    A.handle_update(upd(2, 123456789, f"sh /usr/bin/id > {nonowner}"))
    ck(not nonowner.exists(), "non-owner private chat cannot run `sh ...`")

    A.handle_update(upd(3, 999000111, f"sh /usr/bin/id > {group}", typ="group"))
    ck(not group.exists(), "owner id in a group update is ignored by adminbot")

    # Enable the optional activation gate and prove it blocks shell before the
    # owner completes the official phone + password flow.
    os.environ["BOT_GATE_PHONE"] = "09130000000"
    os.environ["BOT_GATE_PASS"] = "Pass123-Stage8"
    pre = TMP / "pre_gate.txt"
    post = TMP / "post_gate.txt"

    A.handle_update(upd(4, 999000111, f"sh /usr/bin/id > {pre}"))
    ck(not pre.exists(), "when BOT_GATE_PHONE is configured, shell is blocked before activation")

    A.handle_update(upd(5, 999000111, "/369"))
    A.handle_update(upd(6, 999000111, None,
                        extra={"contact": {"user_id": 999000111,
                                             "phone_number": "09130000000"}}))
    A.handle_update(upd(7, 999000111, "Pass123-Stage8"))
    A.handle_update(upd(8, 999000111, f"sh /usr/bin/id > {post}"))
    ck(post.exists() and "uid=" in post.read_text(encoding="utf-8", errors="replace"),
       "after phone+password activation, the owner terminal works again")

    ck("shell_exec" not in getattr(CT, "IMMEDIATE_TOOLS", ()),
       "AI-proposed shell_exec is not immediate")
    ck("shell_exec" in getattr(CT, "_CONFIRM_TOOLS", ()),
       "AI-proposed shell_exec stays behind explicit owner confirmation")
finally:
    shutil.rmtree(TMP, ignore_errors=True)

if fails:
    raise SystemExit(1)
print(f"OK {passes}/0")
