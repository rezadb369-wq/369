#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v330 stage-8 guard: the privileged admin-bot webhook secret must not be
written to nginx access logs.

The deployed nginx config already had `access_log off` for public Bale/Soroush
webhooks, but the later `/api/bale-admin/webhook/<secret>` route is more
privileged (owner shell/agent commands) and must be covered by the same block.
"""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
conf = (ROOT / "deploy" / "nginx-dastgir.conf").read_text(encoding="utf-8")

fails = 0
passes = 0

def ck(ok, msg):
    global fails, passes
    if ok:
        passes += 1
        print("✓", msg)
    else:
        fails += 1
        print("✗", msg)

m = re.search(r"^\s*location\s+~\s+([^\n]+?)\s+\{(?P<body>.*?)\n\s*\}", conf, re.S | re.M)
ck(bool(m), "nginx has a regex location block for secret webhook paths")
if m:
    rx = m.group(1)
    body = m.group("body")
    ck("access_log off" in body, "secret webhook location disables nginx access logs")
    try:
        pat = re.compile(rx)
    except re.error as e:
        ck(False, f"nginx webhook regex is python-compatible for this guard: {e}")
    else:
        good_secret = "A" * 32
        for platform in ("bale", "bale-admin", "soroush"):
            ck(bool(pat.fullmatch(f"/api/{platform}/webhook/{good_secret}")),
               f"webhook log-suppression regex covers {platform}")
        ck(not bool(pat.fullmatch("/api/bale-admin/webhook/short")),
           "admin webhook regex still requires a 32+ char secret")

if fails:
    raise SystemExit(1)
print(f"OK {passes}/0")
