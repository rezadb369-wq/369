#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Guard v346 home-wide obvious motion.

After v345 created a visible motion stage, v346 extends the same visibility to
real home stats and route cards: the actual stats row gets its own live-count
headline and oversized counter styling, and route cards reveal independently.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PASS = FAIL = 0

def ck(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1; print("✓ " + name)
    else:
        FAIL += 1; print("✗ " + name + (" — " + detail if detail else ""))

def rd(rel): return (ROOT / rel).read_text(encoding="utf-8")

public = rd("server/views_public.py")
css = rd("site/assets/css/pages.css")
js = rd("site/assets/js/app.js")
css_v346 = css[css.find("v346 — Make every home number"):]

ck("real homepage stats now have a visible live-count section",
   "h-stats-section" in public
   and "data-home-live-stats" in public
   and "شمارش زنده" in public
   and "عددهای شهر با اسکرول روشن می‌شوند" in public)

ck("real stat counters remain the existing stat_card data-count widgets",
   all(x in public for x in ("stat_card(\"store\", st['businesses']", "stat_card(\"layers\", st['categories']", "stat_card(\"message\", st['reviews']", "stat_card(\"eye\", st['views']"))
   and "data-count" in rd("server/ui.py"))

ck("route cards reveal independently, not only as a parent board",
   all(x in public for x in ("h-route-card reveal is-shops", "h-route-card reveal is-catalog", "h-route-card reveal is-map", "h-route-card reveal is-owner"))
   and all(x in css_v346 for x in ("v346RoutePop", "v346IconWake", ".h-route-board.is-in .h-route-card.reveal.is-in")))

ck("stats styling is unmistakably larger and animated",
   all(x in css_v346 for x in (".h-stats-section .stat-value", "font-size: clamp(2.6rem", "v346StatsBeam", "v346CardFlash", "min-height: clamp(150px")))

ck("v346 keeps reduced-motion safe",
   "@media (prefers-reduced-motion: reduce)" in css_v346
   and "animation: none !important" in css_v346
   and "transform: none !important" in css_v346)

ck("mobile receives compact two-column live stats",
   "@media (max-width: 540px)" in css_v346
   and "grid-template-columns: repeat(2" in css_v346
   and "font-size: clamp(2rem, 13vw" in css_v346)

ck("v346 still uses IntersectionObserver reveal/counters and no new route/schema",
   "IntersectionObserver" in js
   and "pointer: coarse" not in js[js.find("function initReveal()"):js.find("function initParallax()")]
   and "CREATE TABLE" not in public
   and "@app.route" not in public)

print(f"\n{PASS} passed, {FAIL} failed")
raise SystemExit(1 if FAIL else 0)
