#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v330 stage-11: zip extraction must be Zip-Slip safe.

Two code paths used to call ``ZipFile.extractall`` directly:
  * root ``app.py`` mobile/PaaS auto-extract bootstrap;
  * ``tools/backup.py --verify`` backup verifier.
Both may process an archive supplied by an operator, so path traversal members
must be rejected before any file is written outside the destination directory.
Stage 13 extends the guard to root deployment shell scripts, which run as root
and must validate the ZIP before invoking ``unzip``.
"""
import contextlib
import importlib.util
import io
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = Path(tempfile.mkdtemp(prefix="dg-zip-slip-"))

passes = 0
fails = 0

def ck(ok, msg):
    global passes, fails
    if ok:
        passes += 1
        print("✓", msg)
    else:
        fails += 1
        print("✗", msg)

try:
    # 1) app.py bootstrap: malicious archive must not write beside the app dir.
    appdir = TMP / "bootstrap"
    appdir.mkdir()
    shutil.copy2(ROOT / "app.py", appdir / "app.py")
    outside = TMP / "owned-by-bootstrap.txt"
    zpath = appdir / "payload.zip"
    with zipfile.ZipFile(zpath, "w") as z:
        z.writestr("../" + outside.name, "owned")
        z.writestr("server/__init__.py", "")
    spec = importlib.util.spec_from_file_location("dg_root_app_ziptest", appdir / "app.py")
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    with contextlib.redirect_stdout(io.StringIO()):
        mod.auto_extract_zip()
    ck(not outside.exists(), "app.py auto_extract_zip rejects ../ members")
    ck(not (appdir / "server" / "__init__.py").exists(),
       "app.py validates the whole archive before extracting any member")

    # 2) backup verifier: reject traversal cleanly (non-zero, no traceback, no write).
    outside2 = TMP / "owned-by-backup.txt"
    bad_backup = TMP / "bad-backup.zip"
    with zipfile.ZipFile(bad_backup, "w") as z:
        z.writestr("manifest.json", "{}")
        z.writestr("../" + outside2.name, "owned")
    r = subprocess.run([sys.executable, str(ROOT / "tools" / "backup.py"),
                        "--verify", str(bad_backup)],
                       cwd=ROOT, text=True, capture_output=True, timeout=20)
    out = (r.stdout or "") + (r.stderr or "")
    ck(r.returncode != 0, "backup verifier rejects unsafe zip")
    ck("Traceback" not in out, "backup verifier reports unsafe zip without traceback")
    ck(not outside2.exists(), "backup verifier does not write traversal member")

    # 3) Positive control: app.py still accepts a safe archive.
    gooddir = TMP / "good"
    gooddir.mkdir()
    shutil.copy2(ROOT / "app.py", gooddir / "app.py")
    with zipfile.ZipFile(gooddir / "safe.zip", "w") as z:
        z.writestr("server/__init__.py", "")
        z.writestr("site/index.keep", "ok")
    spec2 = importlib.util.spec_from_file_location("dg_root_app_ziptest_good", gooddir / "app.py")
    mod2 = importlib.util.module_from_spec(spec2)
    assert spec2.loader is not None
    spec2.loader.exec_module(mod2)
    with contextlib.redirect_stdout(io.StringIO()):
        mod2.auto_extract_zip()
    ck((gooddir / "server" / "__init__.py").exists()
       and (gooddir / "site" / "index.keep").exists(),
       "app.py still extracts a safe archive")

    # 4) Deployment scripts run as root. They must validate the operator-supplied
    # ZIP before any unzip extraction and reject traversal/symlink-like entries.
    for rel, unzip_marker in (("deploy/update.sh", "unzip -q"),
                              ("deploy/install.sh", "unzip -oq")):
        sh = (ROOT / rel).read_text(encoding="utf-8")
        guard_at = sh.find('zip_safe_check "$ZIP"')
        unzip_at = sh.find(unzip_marker)
        ck(guard_at >= 0 and unzip_at >= 0 and guard_at < unzip_at,
           f"{rel} validates ZIP before extraction")
        ck("zipfile.ZipFile" in sh and "p == \"..\"" in sh and "stat.S_ISREG" in sh,
           f"{rel} rejects traversal and non-regular ZIP entries")

    # 5) The release ZIP builder must not follow symlinks into host files.
    bz = (ROOT / "tools" / "build_zip.py").read_text(encoding="utf-8")
    ck("full.is_symlink()" in bz and "refusing non-regular file" in bz,
       "release builder refuses symlinks/non-regular files")
finally:
    shutil.rmtree(TMP, ignore_errors=True)

if fails:
    raise SystemExit(1)
print(f"OK {passes}/0")
