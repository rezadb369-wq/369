#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
آزمون نگهبان: الحاق رشته‌ایِ جامانده داخل f-string
=====================================================

چرا این فایل وجود دارد
----------------------
این دقیقاً یک کلاس باگ است که تا امروز **سه بار** در این پروژه تکرار شده:

  • ممیزی v11      — رفع شد
  • ممیزی ۲۰۲۶-۰۹  — دوباره ظاهر شد: views_public.py:1259 (favorites.js)
  • ممیزی v330     — دوباره ظاهر شد در ۶ جای دیگر:
        views_extra.py      (countdown.js)
        views_customer.py   (chat.js ، cart.js)
        views_owner.py      (chat.js)
        views_panel2.py     (chat.js  ← چتِ پنل مدیریت)
        views_catalog.py    (imagefield.js ، itemform.js)

هر بار فقط همان یک نمونه‌ای که دیده شده بود رفع شد و هیچ‌کس جست‌وجوی
سراسری نکرد؛ برای همین باگ برگشت. این آزمون همان جست‌وجوی سراسری است.

شکل باگ
--------
داخل یک f-string (مخصوصاً سه‌کوتیشنی) این نوشته می‌شود:

    body = f'''...
    <script src="' + av('/assets/js/x.js') + '"></script>'''

که الحاقِ پایتون نیست — متنِ ثابتِ داخل f-string است، پس عیناً در HTML
چاپ می‌شود، مرورگر یک src بی‌معنا می‌گیرد، ۴۰۴ می‌خورد و آن قابلیت مرده
می‌ماند. شکل درست:

    <script src="{av("/assets/js/x.js")}"></script>

چرا سوئیت‌های دیگر این را نمی‌گیرند
-----------------------------------
صفحه با کد ۲۰۰ برمی‌گردد و HTML هم «سالم» به نظر می‌رسد؛ فقط یک اسکریپت
لود نمی‌شود. هیچ‌کدام از ۱۶۴ سوئیت موجود محتوای تگ‌های <script> را
اعتبارسنجی نمی‌کرد. این آزمون با AST کار می‌کند، نه با درخواست HTTP،
پس به سرور بالا نیاز ندارد و همیشه سریع است.
"""

import ast
import os
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"

passed = failed = 0
fails = []


def ok(label, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  {G}✓{X} {label}")
    else:
        failed += 1
        fails.append(label)
        print(f"  {R}✗{X} {label}   {detail}")


# الگوی «الحاق جامانده»: کوتیشن، بعلاوه، سپس یک شناسه
CONCAT = re.compile(r"""['"]\s*\+\s*[A-Za-z_]""")
# فقط وقتی خطرناک است که در همان متن یک تگ منبع‌دار هم باشد
ASSET_TAG = re.compile(r"""<\s*(script|link|img|source|iframe)\b""", re.I)


def scan(path: pathlib.Path):
    """هر f-string را می‌گردد و متنِ ثابتش را بررسی می‌کند."""
    out = []
    try:
        src = path.read_text(encoding="utf-8")
    except Exception:
        return out
    try:
        tree = ast.parse(src)
    except SyntaxError:
        # خطای نحوی را آزمون دیگری می‌گیرد؛ اینجا رد می‌شویم
        return out
    for node in ast.walk(tree):
        if not isinstance(node, ast.JoinedStr):
            continue
        for part in node.values:
            if not isinstance(part, ast.Constant) or not isinstance(part.value, str):
                continue
            text = part.value
            for m in CONCAT.finditer(text):
                # زمینهٔ اطرافِ محل مشکوک
                around = text[max(0, m.start() - 120): m.start() + 60]
                # الحاق داخل جاوااسکریپتِ inline قانونی است
                # (مثلاً  'tab-'+id ). فقط وقتی باگ است که الحاق درست
                # بعد از یک صفتِ src/href داخل یک تگ دارایی بیاید —
                # یعنی دارد آدرس فایل می‌سازد، نه رشتهٔ جاوااسکریپت.
                before = text[max(0, m.start() - 160): m.start() + 1]
                if ASSET_TAG.search(before) and re.search(
                    r"""(src|href)\s*=\s*["'][^<>]{0,4}$""", before
                ):
                    snippet = around.replace("\n", " ").strip()[-90:]
                    out.append((node.lineno, snippet))
    return out


def main():
    print(f"\n{B}══ آزمون نگهبان: الحاق جامانده داخل f-string ══{X}\n")

    targets = sorted((ROOT / "server").glob("*.py"))
    ok("پوشهٔ server پیدا شد و فایل دارد", len(targets) > 0, f"{len(targets)} فایل")

    total_hits = 0
    dirty = []
    for p in targets:
        hits = scan(p)
        if hits:
            total_hits += len(hits)
            dirty.append((p, hits))

    print(f"\n{B}۱) پویش {len(targets)} فایل در server/{X}")
    for p, hits in dirty:
        for ln, sn in hits:
            print(f"    {R}→{X} {p.name} (f-string از خط {ln}): …{sn}…")

    ok(
        "هیچ تگ دارایی با الحاق جامانده داخل f-string نیست",
        total_hits == 0,
        f"{total_hits} مورد پیدا شد — به جای ' + av('x') + ' باید {{av(\"x\")}} نوشت",
    )

    # بررسی دوم و مستقل: هیچ فایل پایتونی نباید رشتهٔ تحت‌اللفظیِ
    # "+ av(" را در خروجیِ رندرشده داشته باشد. این یک تورِ ایمنیِ
    # ساده و متن‌محور است که حتی اگر AST چیزی را جا بیندازد می‌گیرد.
    print(f"\n{B}۲) تور ایمنی متنی{X}")
    suspicious = []
    for p in targets:
        try:
            lines = p.read_text(encoding="utf-8").split("\n")
        except Exception:
            continue
        for i, line in enumerate(lines, 1):
            s = line.strip()
            # خطی که با یک تگ شروع شود و الحاق داشته باشد، یعنی داخل
            # یک رشتهٔ چندخطی است (در کد عادی خط با <script شروع نمی‌شود)
            if s.startswith("<") and "' + " in s and "av(" in s:
                suspicious.append(f"{p.name}:{i}")
    for s in suspicious:
        print(f"    {R}→{X} {s}")
    ok("هیچ خط تگ‌آغازی با الحاق باقی نمانده", not suspicious,
       f"{len(suspicious)} خط: {', '.join(suspicious[:4])}")

    print(f"\n{B}{'=' * 58}{X}")
    if failed:
        print(f"{B}{R}  {passed} موفق، {failed} ناموفق{X}")
        for f in fails:
            print(f"    ✗ {f}")
    else:
        print(f"{B}{G}  همه موفق — {passed} آزمون، ۰ ناموفق{X}")
    print(f"{B}{'=' * 58}{X}\n")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
