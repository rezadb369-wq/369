#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v333: every admin page shows a workflow context strip.

After the v332 reorganization, admins still need local orientation inside each
workflow. This guard keeps the new context bar and sibling links alive.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))

import db  # noqa: E402
import ui  # noqa: E402
import views_panel  # noqa: E402

passes = 0
fails = 0


def ck(ok, msg):
    global passes, fails
    if ok:
        passes += 1
        print("✓", msg)
    else:
        fails += 1
        print("✗", msg)


src = (ROOT / "server" / "ui.py").read_text(encoding="utf-8")
css = (ROOT / "site" / "assets" / "css" / "pages.css").read_text(encoding="utf-8")

ck("panel-context-bar" in src and "panel-context-links" in src,
   "panel_page renders a workflow context bar")
ck("active.startswith" in src and "best =" in src,
   "context bar falls back to longest parent route for edit/detail pages")
ck("aria-label=\"موقعیت فعلی در پنل\"" in src and "aria-label=\"بخش‌های همین گروه\"" in src,
   "context bar has accessible labels")
ck(".panel-context-bar" in css and ".panel-context-link.is-active" in css,
   "context bar has visual styles and active state")
ck("overflow-x: auto" in css and ".panel-context-links" in css,
   "context sibling links stay usable on narrow screens")

s = db.get_settings()
dash = views_panel.dashboard(s, "tok")
ck("panel-context-bar" in dash and "داشبورد مدیریت" in dash and "کنسول ایجنت" in dash,
   "dashboard shows its local context and sibling agent link")

settings = ui.panel_page(s, "تنظیمات", "آزمون", "<p>ok</p>", "/panel/settings", "tok")
ck("تنظیمات و سیستم" in settings and "پشتیبان‌گیری" in settings and "گزارش فعالیت‌ها" in settings,
   "system pages show their system sibling workflow links")
ck('class="panel-context-link is-active"' in settings,
   "current section is marked active in the context strip")

biz_detail = ui.panel_page(s, "ویرایش کسب‌وکار", "آزمون", "<p>ok</p>", "/panel/businesses/123", "tok")
ck("کسب‌وکار و محتوای شهر" in biz_detail and "دسته‌بندی‌ها" in biz_detail,
   "detail/edit pages inherit the nearest parent workflow")

if fails:
    raise SystemExit(1)
print(f"OK {passes}/0")
