#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Focused public/mobile performance checks. Requires run.py."""
from __future__ import annotations
import gzip
import http.client
import os
from pathlib import Path
import sys
import urllib.parse
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
# v330-stage11: harness2 passes BZ with a non-default port. The old low-level
# HTTP checks ignored BZ and still hit 8080, so the suite depended on an
# unrelated audit server being left running.
BASE = os.environ.get("BZ") or ("http://127.0.0.1:" + os.environ.get("BZ_PORT", "8080"))
BASE = BASE.rstrip("/")
_PARSED_BASE = urllib.parse.urlparse(BASE if "://" in BASE else "http://" + BASE)
BASE_SCHEME = _PARSED_BASE.scheme or "http"
BASE_HOST = _PARSED_BASE.hostname or "127.0.0.1"
PORT = _PARSED_BASE.port or (443 if BASE_SCHEME == "https" else 80)


def check(ok, label):
    if not ok: raise AssertionError(label)
    print("✓", label)


def get(path, headers=None):
    conn_cls = http.client.HTTPSConnection if BASE_SCHEME == "https" else http.client.HTTPConnection
    c = conn_cls(BASE_HOST, PORT, timeout=15)
    c.request("GET", path, headers=headers or {})
    r = c.getresponse(); body = r.read(); h = dict(r.getheaders()); code = r.status
    c.close(); return code, h, body


def main():
    src = ROOT / "site/assets/img/logo-source.png"
    display = ROOT / "site/assets/img/logo-display.png"
    check(src.stat().st_size > display.stat().st_size * 7,
          "header logo transfer is reduced by more than 7×")

    # v285 audit (دستور مدیر: ممیزی کامل): the release marker was hardcoded to
    # v217 and went stale 63 releases ago — derive it from VERSION.txt so this
    # suite tracks every release automatically (RULES §2: pins follow latest).
    VER = (ROOT / "VERSION.txt").read_text().strip()
    for path in (f"/assets/css/pages.css?v{VER}", f"/assets/js/app.js?v{VER}"):
        code, h, compressed = get(path, {"Accept-Encoding": "gzip"})
        raw = (ROOT / ("site" + path.split("?")[0])).read_bytes()
        check(code == 200 and h.get("Content-Encoding") == "gzip" and
              len(compressed) < len(raw) * .45, f"{path} is gzip-compressed")
        check("max-age=31536000" in h.get("Cache-Control", "") and
              "immutable" in h.get("Cache-Control", ""),
              f"{path} has immutable release caching")
        etag = h.get("ETag")
        code304, _, body304 = get(path, {"If-None-Match": etag})
        check(code304 == 304 and not body304, f"{path} supports zero-body revalidation")

    code, h, _ = get("/assets/js/app.js")
    check(code == 200 and h.get("Cache-Control") == "no-cache",
          "unversioned service-worker asset remains safely revalidated")
    code, h, home_gz = get("/", {"Accept-Encoding": "gzip"})
    check(code == 200 and h.get("Content-Encoding") == "gzip" and len(home_gz) < 25_000,
          "public home HTML is compressed below 25 KB")

    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--no-sandbox"])
        for width, theme in ((1440, "light"), (390, "dark")):
            page = browser.new_page(viewport={"width": width, "height": 900})
            page.add_init_script(f"localStorage.setItem('bz-theme','{theme}')")
            errors = []; page.on("pageerror", lambda e: errors.append(str(e)))
            page.goto(BASE + "/", wait_until="networkidle")
            logo = page.locator(".brand-mark img").first
            state = logo.evaluate("""e => ({src:e.getAttribute('src'), complete:e.complete,
                nw:e.naturalWidth, nh:e.naturalHeight, w:e.getBoundingClientRect().width,
                h:e.getBoundingClientRect().height,
                overflow:document.documentElement.scrollWidth > innerWidth})""")
            check(state["src"] == f"/assets/img/logo-display.png?v{VER}" and state["complete"] and
                  state["nw"] == 192 and state["nh"] == 192 and
                  state["w"] == 38 and state["h"] == 38,
                  f"optimized logo renders unchanged at {width}px/{theme}")
            check(not state["overflow"] and not errors,
                  f"no overflow or page errors at {width}px/{theme}")
            page.close()
        browser.close()

    check(f"bazarche-v{VER}" in (ROOT / "site/sw.js").read_text(),
          f"service-worker marker matches VERSION.txt (v{VER})")
    print(f"\nهمهٔ آزمون‌های کارایی عمومی v{VER} موفق بودند.")


if __name__ == "__main__":
    main()
