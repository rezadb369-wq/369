#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""bump_version.py — ارتقای شمارهٔ نسخه در همهٔ جاهایی که باید.

چرا لازم است
------------
قانون تحویل پروژه می‌گوید نسخه در پنج جا پین می‌شود (ممیزی v330: در عمل نُه جا). دلیلش فنی است، نه
تشریفاتی: `site/sw.js` نام کشِ سرویس‌ورکر را از همین رشته می‌سازد و
`activate` هر کشی را که نامش با VERSION فرق دارد پاک می‌کند. همچنین
`ui.av()` به آدرس هر دارایی `?v<نسخه>` اضافه می‌کند.

نتیجه: اگر CSS یا JS عوض شود ولی نسخه ثابت بماند، **بازدیدکنندگان قبلی
هیچ‌وقت تغییر را نمی‌بینند** — نه از کش مرورگر و نه از کش سرویس‌ورکر.
همین اشتباه در ممیزی v330 یک‌بار پیدا شد: `bazaar.css` شکنندهٔ کش ثابت
`?v=29201` داشت و به‌همین‌دلیل صرفه‌جویی ۱۶۰ کیلوبایتی WebP هرگز به
کاربران قدیمی نرسیده بود.

استفاده
-------
    python3 tools/bump_version.py 331          # اعمال
    python3 tools/bump_version.py 331 --dry    # فقط نمایش تغییرات

پس از اجرا حتماً `tools/test_v328.py` را بگیرید؛ همان تست است که این پنج
پین را می‌سنجد؛ و «tools/test_v319.py» دو پین تازه‌کشف‌شده را.
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def rd(rel):
    with open(os.path.join(ROOT, rel), encoding='utf-8') as fh:
        return fh.read()


def wr(rel, text):
    with open(os.path.join(ROOT, rel), 'w', encoding='utf-8') as fh:
        fh.write(text)


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('-')]
    dry = '--dry' in sys.argv
    if not args or not args[0].isdigit():
        print(__doc__)
        return 2
    new = args[0]
    old = rd('VERSION.txt').strip()
    if old == new:
        print('نسخه از قبل %s است — کاری لازم نیست.' % new)
        return 0
    print('ارتقا: %s → %s%s\n' % (old, new, '  (آزمایشی)' if dry else ''))

    # (فایل، الگو، جایگزین) — همه لنگرِ دقیق دارند تا اشتباهی چیز دیگری
    # عوض نشود. تعداد تطبیق‌های انتظاری هم بررسی می‌شود.
    edits = [
        ('VERSION.txt', r'^%s\s*$' % re.escape(old), new + '\n', 1),
        ('site/sw.js', r"const VERSION = 'bazarche-v%s'" % re.escape(old),
         "const VERSION = 'bazarche-v%s'" % new, 1),
        # v330-stage12: the display logo is also pre-cached by the service worker
        # under an immutable query string. Keep it in lockstep with VERSION.txt;
        # otherwise a future release bump would still pre-cache the old ?vNNN URL.
        ('site/sw.js', r"/assets/img/logo-display\.png\?v%s" % re.escape(old),
         "/assets/img/logo-display.png?v%s" % new, 1),
        ('server/adminbot.py', r'DIAG_LATEST = "%s"' % re.escape(old),
         'DIAG_LATEST = "%s"' % new, 1),
        ('README.md', r'# دست گیر — v%s' % re.escape(old),
         '# دست گیر — v%s' % new, 1),
        ('README.md', r'\| `VERSION\.txt` \| `%s` \|' % re.escape(old),
         '| `VERSION.txt` | `%s` |' % new, 1),
        ('README.md',
         r'\| `server/adminbot\.py` → `DIAG_LATEST` \| `"%s"` \|' % re.escape(old),
         '| `server/adminbot.py` → `DIAG_LATEST` | `"%s"` |' % new, 1),
        ('server/views_agent_desk.py', r'میز کار ایجنت — v%s' % re.escape(old),
         'میز کار ایجنت — v%s' % new, None),
        # مرحلهٔ ۷ ممیزی v330: دو پین دیگر هم وجود داشت که در فهرست «پنج جا»
        # نیامده بود و هر دو واقعاً کهنه مانده بودند (`test_v319.py` خط ۷۰ و
        # ۱۳۰ همین دو را می‌سنجد و قرمز بود):
        #   • خروجی «/elevated» که مالک در ربات می‌بیند — رشتهٔ قابل‌مشاهدهٔ کاربر.
        #   • تیتر سند تحویل که توسعه‌دهندهٔ بعدی اول از همه می‌خواند.
        ('server/agent_cmds.py', r'دسترسی آزاد ایجنت v%s' % re.escape(old),
         'دسترسی آزاد ایجنت v%s' % new, 1),
        ('docs/collaboration/HANDOFF.md', r'^# HANDOFF — v%s' % re.escape(old),
         '# HANDOFF — v%s' % new, 1),
    ]

    # تست پین‌ها هم باید به‌روز شود — طبق قانون، با توضیح «دستور مدیر».
    test_edits = [
        ('tools/test_v328.py', r'ver == "%s" and A\.DIAG_LATEST == "%s"'
         % (re.escape(old), re.escape(old)),
         'ver == "%s" and A.DIAG_LATEST == "%s"' % (new, new), 1),
        ('tools/test_v328.py', r'"پین نسخه %s"' % re.escape(old),
         '"پین نسخه %s"' % new, 1),
        ('tools/test_v328.py', r'"bazarche-v%s" in sw' % re.escape(old),
         '"bazarche-v%s" in sw' % new, 1),
        ('tools/test_v328.py', r'"sw\.js v%s"' % re.escape(old),
         '"sw.js v%s"' % new, 1),
        ('tools/test_v328.py', r'"دست گیر — v%s" in readme' % re.escape(old),
         '"دست گیر — v%s" in readme' % new, 1),
        ('tools/test_v328.py', r'"README v%s"' % re.escape(old),
         '"README v%s"' % new, 1),
        ('tools/test_v328.py', r'"v%s" in cs\.splitlines\(\)\[0\]' % re.escape(old),
         '"v%s" in cs.splitlines()[0]' % new, 1),
        ('tools/test_v328.py', r'"میز کار ایجنت — v%s" in src_desk' % re.escape(old),
         '"میز کار ایجنت — v%s" in src_desk' % new, None),
        ('tools/test_v328.py', r'"عنوان v%s"' % re.escape(old),
         '"عنوان v%s"' % new, None),
    ]

    touched = {}
    problems = []

    def first_line_swap(rel):
        """فقط در خط نخست فایل نسخه را عوض می‌کند."""
        src = touched.get(rel) or rd(rel)
        lines = src.split('\n')
        if ('v' + old) not in lines[0]:
            return None
        lines[0] = lines[0].replace('v' + old, 'v' + new)
        touched[rel] = '\n'.join(lines)
        return 1

    _cs = 'docs/collaboration/CURRENT-STATE.md'
    if first_line_swap(_cs):
        print('  %-42s خط اول' % _cs)
    else:
        problems.append('%s: «v%s» در خط اول پیدا نشد' % (_cs, old))
    for rel, pat, rep, want in edits + test_edits:
        try:
            src = touched.get(rel) or rd(rel)
        except FileNotFoundError:
            problems.append('%s پیدا نشد' % rel)
            continue
        n = len(re.findall(pat, src, re.M))
        if want is not None and n != want:
            problems.append('%s: انتظار %d تطبیق برای «%s»، یافت %d'
                            % (rel, want, pat[:40], n))
            continue
        if n == 0:
            continue
        touched[rel] = re.sub(pat, rep.replace('\\', '\\\\'), src, flags=re.M)
        print('  %-42s %d تطبیق' % (rel, n))

    if problems:
        print('\n✗ متوقف شد — هیچ فایلی نوشته نشد:')
        for p in problems:
            print('   ', p)
        return 1

    if dry:
        print('\n(آزمایشی — چیزی نوشته نشد)')
        return 0

    for rel, text in touched.items():
        wr(rel, text)
    print('\n✓ %d فایل به‌روز شد.' % len(touched))
    print('حالا این‌ها را بگیرید:')
    print('   python3 tools/test_v328.py        # پین‌های نسخه (۵ پین کلاسیک)')
    print('   python3 tools/test_v319.py        # دو پین تازه: /elevated و HANDOFF')
    print('   python3 tools/test_all.py         # رگرسیون کلی')
    print('\nو دستی (ابزار عمداً متن نمی‌نویسد، چون محتوا قضاوت آدم است):')
    print('   • WHATS-NEW.md  — بخش تازهٔ نسخه (پروتکل تحویل KNOWLEDGE §۱۱)')
    print('   • docs/collaboration/CURRENT-STATE.md — «تازه‌ها در v%s»' % new)
    print('   • docs/collaboration/HANDOFF.md — «الان چیست» و «کار بعدی»')
    return 0


if __name__ == '__main__':
    sys.exit(main())
