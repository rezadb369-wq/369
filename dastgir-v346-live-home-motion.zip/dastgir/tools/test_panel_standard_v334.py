#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v334: panel list pages move toward shared layout classes.

This locks the first cleanup pass after the v332/v333 navigation work: remove a
stale unreachable business-list branch and replace the most repeated inline
layout snippets in the active business/review list pages with reusable classes.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))

import db  # noqa: E402
import views_panel  # noqa: E402

passes = 0
fails = 0


def ck(ok, msg):
    global passes, fails
    if ok:
        passes += 1
        print("✓", msg)
    else:
        fails += 1
        print("✗", msg)


src = (ROOT / "server" / "views_panel.py").read_text(encoding="utf-8")
css = (ROOT / "site" / "assets" / "css" / "pages.css").read_text(encoding="utf-8")

ck(src.count('style="') <= 60, "views_panel inline-style count is reduced and capped")
ck('style="display:inline"' not in src, "inline form display moved to .inline-form")
ck('style="display:flex;align-items:center;gap:10px"' not in src,
   "repeated object-row inline flex moved to .panel-object")
ck('style="color:var(--color-destructive)"' not in src,
   "danger color moved to .is-danger")
ck('return panel_page(s, "مدیریت کسب\u200cوکارها",\n                      "مشاهده، ویرایش، تغییر وضعیت و حذف کسب\u200cوکارهای ثبت\u200cشده.",\n                      content, "/panel/businesses", token)\n    sort = g(' not in src,
   "unreachable duplicate business-list branch was removed")

for cls in (".dir-toolbar-static", ".search-wrap-wide", ".panel-object",
            ".check-compact", ".inline-form", ".is-danger",
            ".empty-state-roomy", ".cell-select", ".textarea-short"):
    ck(cls in css, f"shared CSS helper exists: {cls}")

s = db.get_settings()
biz = views_panel.biz_list(s, "tok")
ck('dir-toolbar-static' in biz and 'search-wrap-wide' in biz,
   "business list uses standardized toolbar helper classes")
ck('panel-object' in biz and 'check-compact' in biz and 'inline-form' in biz,
   "business rows use standardized layout/action helper classes")
ck('style="display:inline"' not in biz,
   "business list no longer renders inline form display snippets")

rev = views_panel.rev_list(s, "tok")
ck('flex-1' in rev and 'mt-xxs' in rev and 'textarea-short' in rev,
   "review list uses standardized meta/reply helper classes")
ck('style="flex:1"' not in rev and 'style="margin-top:3px"' not in rev,
   "review list no longer renders repeated inline meta snippets")

if fails:
    raise SystemExit(1)
print(f"OK {passes}/0")
