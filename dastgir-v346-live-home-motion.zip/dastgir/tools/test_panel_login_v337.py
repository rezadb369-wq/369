# -*- coding: utf-8 -*-
"""
v337 — ورود پنل با دستور ربات بله + تأیید بله + رمز قبلی.

قفل‌های این سوئیت:
  • ربات مدیریت دیگر owner_token خام یا /panel?key= نمی‌فرستد؛ فقط لینک
    یک‌بارمصرف /panel/enter?pt=... می‌دهد.
  • لینک یک‌بارمصرف در دیتابیس واقعاً یک‌بارمصرف و کوتاه‌عمر است.
  • چالنج تأیید pre_password بعد از تأیید بله هنوز نشست را باز نمی‌کند؛
    بازشدن نهایی بعد از رمز قبلی پنل انجام می‌شود.
  • مسیر مخفی پنل در لینک‌های جدید رعایت می‌شود.
  • همان مسیر مستقیم در /api/agent/chat پنل ایجنت هم وجود دارد.
"""

import os
import sys
import tempfile
import re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
SERVER = os.path.join(ROOT, "server")
sys.path.insert(0, SERVER)
sys.path.insert(0, ROOT)

# وقتی خارج از سرور زنده اجرا می‌شود، دیتابیس موقت بساز.
if "BZ_DATA_DIR" not in os.environ:
    os.environ["BZ_DATA_DIR"] = tempfile.mkdtemp(prefix="dastgir-v337-login-")

import db  # noqa: E402
try:
    db.init()
except Exception:
    pass
import adminbot as A  # noqa: E402

G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  {G}✓{X} {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  {R}✗{X} {label}  {detail}")


def head(t):
    print(f"\n{B}── {t}{X}")


print(f"\n{B}\033[36mآزمون v337 ورود پنل با بله + رمز قبلی{X}")

head("توکن یک‌بارمصرف دیتابیس")
pt, exp = db.panel_entry_new("1.2.3.4", ttl=300)
check("توکن ورود ساخته می‌شود", bool(pt) and exp > 0)
check("توکن بار اول مصرف می‌شود", db.panel_entry_consume(pt))
check("توکن بار دوم رد می‌شود", not db.panel_entry_consume(pt))
check("توکن جعلی رد می‌شود", not db.panel_entry_consume("fake-token"))

head("چالنج pre_password")
sess = db.admin_session_new(locked=True)
code = db.panel_approval_new(sess, "5.6.7.8", purpose="pre_password")
check("کد ۶رقمی است", bool(re.fullmatch(r"\d{6}", code or "")), code)
check("هدف pre_password ذخیره شده", db.panel_approval_purpose(sess) == "pre_password")
check("وضعیت اولیه pending", db.panel_approval_status(sess) == "pending")
check("تأیید با کد درست پذیرفته می‌شود", db.panel_approval_decide(code, True))
check("بعد از تأیید، وضعیت approved است", db.panel_approval_status(sess) == "approved")
check("تأیید بله به‌تنهایی نشست را unlock نمی‌کند", not db.admin_session_ok(sess, unlocked_only=True))
db.admin_session_unlock(sess)
db.panel_approval_consume(sess)
check("بعد از رمز/مصرف، وضعیت consumed می‌شود", db.panel_approval_status(sess) == "consumed")
check("بعد از unlock نهایی نشست باز است", db.admin_session_ok(sess, unlocked_only=True))
db.admin_session_kill(sess)

head("خروجی مستقیم ربات مدیریت")
old = dict(os.environ)
os.environ["BALE_ADMIN_CHAT"] = "111"
os.environ["BALE_ADMIN_TOKEN"] = "t"
os.environ["BALE_ADMIN_SECRET"] = "s" * 32
s0 = db.get_settings()
restore = {k: s0.get(k) for k in ("site_url", "panel_hidden_path", "owner_token", "owner_pass_hash")}
db.set_settings({"site_url": "https://site337.test", "panel_hidden_path": "", "owner_token": "raw-owner-token-v337", "owner_pass_hash": ""})
msg, _ = A.handle_text("u", "111", "ورود پنل")
check("ربات لینک /panel/enter?pt می‌دهد", "https://site337.test/panel/enter?pt=" in msg)
check("ربات owner_token خام را نمی‌فرستد", "raw-owner-token-v337" not in msg and "/panel?key=" not in msg)
check("پیام ترتیب جدید را توضیح می‌دهد", "تأیید" in msg and "رمز" in msg and "یک‌بارمصرف" in msg)
check("بدون رمز، پیام می‌گوید رمز لازم است", "هنوز رمز پنل نداری" in msg)
db.set_owner_pass("old337")
msg2, _ = A.handle_text("u", "111", "کلید ورودم به سایت بده")
check("عبارت قدیمی هم به مسیر جدید می‌رود", "/panel/enter?pt=" in msg2 and "/panel?key=" not in msg2)
check("با رمز موجود، همان رمز قبلی خواسته می‌شود", "همان رمز قبلی" in msg2 and "تعیین شده" in msg2)
db.set_settings({"panel_hidden_path": "hidden337"})
msg3, _ = A.handle_text("u", "111", "ورود پنل")
check("نشانی مخفی در لینک رعایت می‌شود", "https://site337.test/hidden337/enter?pt=" in msg3)
for k, v in restore.items():
    db.set_setting(k, v if v is not None else "")
os.environ.clear(); os.environ.update(old)

head("دکمه‌های بله و مسیر ایجنت")
src_admin = open(os.path.join(SERVER, "adminbot.py"), encoding="utf-8").read()
src_app = open(os.path.join(SERVER, "app.py"), encoding="utf-8").read()
check("پیام تأیید بله دکمه inline دارد", "panel:approve:%s" in src_admin and "panel:reject:%s" in src_admin)
check("مسیر /panel/enter در اپلیکیشن وجود دارد", 'path == "/panel/enter"' in src_app)
check("رمز درست بدون pre_password approval رد می‌شود", "اول در ربات مدیریت بله" in src_app and "panel_approval_purpose" in src_app)
check("پنل ایجنت هم فرمان ورود پنل را مستقیم هندل می‌کند", "source\": \"panel_login" in src_app and "ورود پنل" in src_app)

print()
if bad_n:
    print(f"{R}{B}نتیجه: {ok_n} قبول / {bad_n} رد{X}")
    for f in FAILS:
        print("  -", f)
    sys.exit(1)
print(f"{G}{B}نتیجه: همهٔ {ok_n} آزمون سبز شد.{X}")
sys.exit(0)
