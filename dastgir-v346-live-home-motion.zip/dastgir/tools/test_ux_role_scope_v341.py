#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Guard v341 UX role/scope clarity.

v341 remains organization-only: directory/catalog pages explain which existing
surface the user is on, saved searches are labelled as local-browser state,
and mobile bottom navigation separates «پنل دکان» from the personal account.
No routes, schema, or new capabilities are introduced.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
PASS = FAIL = 0


def ck(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("✓ " + name)
    else:
        FAIL += 1
        print("✗ " + name + (" — " + detail if detail else ""))


def rd(rel):
    return (ROOT / rel).read_text(encoding="utf-8")


public = rd("server/views_public.py")
catalog = rd("server/views_catalog.py")
ui = rd("server/ui.py")
css = rd("site/assets/css/pages.css")
research = rd("docs/collaboration/UX-ORG-RESEARCH-v339.md")

ck("directory page clarifies it searches shops, not products",
   "اینجا فهرست دکان‌هاست" in public
   and 'href="/catalog"' in public
   and "جست‌وجوهای ذخیره‌شده فقط روی همین مرورگر" in public)

ck("catalog page clarifies it is the product/service showcase",
   "اینجا ویترین محصول و خدمت است" in catalog
   and 'href="/businesses"' in catalog
   and "برای آدرس، تماس، مسیر و صفحهٔ خود دکان" in catalog)

_scope_css = css[css.find(".ux-scope-card"):css.find("/* Category header banner */")]
ck("scope helper has shared lightweight styling",
   ".ux-scope-card" in css and ".scope-pill" in css
   and "backdrop-filter" not in _scope_css)

ck("owner mobile nav separates shop panel from personal account",
   'fourth = ("/my", "پنل دکان", "store")' in ui
   and 'last = ("/me", "حساب من", "user")' in ui
   and "blurred the owner/customer roles" in ui)

ck("v341 follows the research rule: clarify labels, do not create systems",
   "متن/برچسب" in research and "قابلیت جدید" in research)

ck("v341 made no new route/schema in touched files",
   "CREATE TABLE" not in (public + catalog + ui)
   and not re.search(r"if path == \"/(catalog|businesses).*(v341|scope)|@route|route\(", public + catalog + ui))

print(f"\n{PASS} passed, {FAIL} failed")
raise SystemExit(1 if FAIL else 0)
