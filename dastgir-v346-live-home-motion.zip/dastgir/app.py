#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Entry point for Hugging Face Spaces, Cloud PaaS, and Mobile Deployments.
Supports auto-extracting zip packages when uploaded directly from mobile devices.
"""
import os
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def _safe_extract_zip(zf, dest):
    """Extract a zip only after proving every member stays under ``dest``.

    v330-stage11: the mobile/PaaS bootstrap may unpack a user-provided zip when
    the app directory is empty. ``ZipFile.extractall`` is unsafe for archives
    with ``../`` or absolute members (Zip Slip), so validate the full member
    list before writing the first byte.
    """
    root = os.path.realpath(dest)
    prefix = root + os.sep
    checked = []
    for info in zf.infolist():
        name = (info.filename or "").replace("\\", "/")
        norm = os.path.normpath(name)
        if (not name or name.startswith("/") or os.path.isabs(norm)
                or norm == ".." or norm.startswith("../")
                or (len(norm) >= 2 and norm[1] == ":")):
            raise ValueError("unsafe zip member: " + (info.filename or ""))
        target = os.path.realpath(os.path.join(root, norm))
        if target != root and not target.startswith(prefix):
            raise ValueError("unsafe zip member: " + (info.filename or ""))
        checked.append(info)
    for info in checked:
        zf.extract(info, root)


def auto_extract_zip():
    """Auto-extracts any project zip file if running on a fresh host/Space."""
    if not os.path.isdir(os.path.join(HERE, "server")) or not os.path.isdir(os.path.join(HERE, "site")):
        for item in os.listdir(HERE):
            if item.endswith(".zip") and not item.startswith("."):
                zip_path = os.path.join(HERE, item)
                print(f"  ▸ استخراج خودکار پکیج زیپ موبایل: {item}...")
                try:
                    with zipfile.ZipFile(zip_path, "r") as zf:
                        _safe_extract_zip(zf, HERE)
                    print("  ✓ استخراج با موفقیت انجام شد.")
                    break
                except Exception as e:
                    print(f"  ✕ خطا در استخراج زیپ: {e}")

if __name__ == "__main__":
    auto_extract_zip()
    if "PORT" not in os.environ:
        os.environ["PORT"] = "7860"
    import run
    sys.exit(run.main())
