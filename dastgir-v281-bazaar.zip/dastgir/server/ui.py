# -*- coding: utf-8 -*-
"""Shared HTML chrome for the dynamic server (icons, layout, components)."""

import os, sys, json, threading, html as _html
import re as _re
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "tools"))

from layout import (icon, stars, fa, fa_group, review_score_html,
                         cat_icon, icon_sprite,
                        jdate, jdatetime, jdatetime_ts)
import db

esc = lambda s: _html.escape(str(s or ""), quote=True)


def json_embed(obj):
    """Serialize for embedding inside <script> or a single-quoted HTML
    attribute. json.dumps does NOT escape <, >, &, ' or U+2028/2029, so
    user text like "</script><script>…" could close the tag and execute.
    The unicode escapes below stay valid JSON (JSON.parse turns them back)
    but the browser no longer sees the raw characters, which keeps the
    injection inert in HTML. (Security fix — stored XSS via JSON-LD/map.)"""
    return (json.dumps(obj, ensure_ascii=False)
            .replace("<", "\\u003c").replace(">", "\\u003e")
            .replace("&", "\\u0026").replace("'", "\\u0027")
            .replace("\u2028", "\\u2028").replace("\u2029", "\\u2029"))


# ---------------------------------------------------------------- request ctx
# The header needs to know who is signed in and which area of the site we are
# in. Passing that through every one of the ~50 page() call sites would be
# noise, so the request handler stashes it here instead. ThreadingHTTPServer
# gives each request its own thread, so thread-local storage is the right fit.
_ctx = threading.local()


def set_context(owner=None, area="public", admin_token="", customer=None, path="/"):
    _ctx.owner = owner
    _ctx.area = area              # public | panel | my | me
    _ctx.admin_token = admin_token or ""
    _ctx.customer = customer
    _ctx.path = path              # v160: برای canonical/noindex سراسری


def clear_context():
    set_context(None, "public", "")


def ctx_owner():
    return getattr(_ctx, "owner", None)


def ctx_customer():
    return getattr(_ctx, "customer", None)


def ctx_area():
    return getattr(_ctx, "area", "public")


def ctx_token():
    return getattr(_ctx, "admin_token", "")


# ---------------------------------------------------------------- nav
# Measured, not guessed: at the 1440px container the header can spare
# 942px for the nav (1440 − brand 103 − actions 363 − 2×16 gap). Eleven
# links at their full labels wanted 995px and overflowed at every desktop
# width, so the two longest labels are shortened rather than dropping a
# whole section behind the hamburger. Re-measure with tools/navfit.py
# before adding a twelfth link.
PUBLIC_NAV = [
    ("/", "خانه", "store"),
    ("/businesses", "کسب‌وکارها", "grid"),
    ("/lists", "برترین‌ها", "trophy"),
    ("/deals", "پیشنهادها", "zap"),
    ("/map", "نقشه", "map"),
    ("/nearby", "نزدیک من", "compass"),
    ("/catalog", "محصولات", "shopping"),
    ("/prices", "مقایسهٔ قیمت", "chart"),
    ("/events", "رویدادها", "calendar"),
    ("/blog", "اخبار شهر", "book"),
    ("/pricing", "تعرفه‌ها", "wallet"),
    ("/my/assistant", "فعالیت دستیار", "activity"),   # v227
    ("/assistant", "دستیار هوشمند", "sparkles"),   # v215
    ("/contact", "تماس", "phone"),
]


def public_nav(s):
    """Public destinations that are actually available right now."""
    prices_on = s.get("prices_enabled") == "1"
    ai_on = s.get("ai_enabled", "1") == "1"
    return [row for row in PUBLIC_NAV if (row[0] != "/prices" or prices_on) and (row[0] != "/assistant" or ai_on)]


# Grouped so 25 screens stay findable instead of turning into a wall of links.
OWNER_NAV_GROUPS = [
    ("مرور", [
        ("/panel", "داشبورد", "dashboard"),
        ("/panel/inbox", "درخواست‌های کاسبان", "bell"),
        ("/panel/moderation", "صف تعدیل", "shield"),
        ("/panel/orders", "همهٔ سفارش‌ها", "cart"),
        ("/panel/insights", "بینش و آمار", "chart"),
        ("/panel/search", "جست‌وجوی پنل", "search"),
    ]),
    ("گفت‌وگوها", [
        ("/panel/chats", "همهٔ گفتگوها", "message"),
        ("/panel/tickets", "تیکت‌های پشتیبانی", "help"),
    ]),
    ("محتوای شهر", [
        ("/panel/businesses", "کسب‌وکارها", "store"),
        ("/panel/categories", "دسته‌بندی‌ها", "layers"),
        ("/panel/lists", "برترین‌های شهر", "trophy"),
        ("/panel/deals", "پیشنهادهای روز", "zap"),
        ("/panel/stories", "استوری‌ها", "image"),
        ("/panel/events", "رویدادهای شهر", "calendar"),
        ("/panel/posts", "اخبار و مقالات", "book"),
    ]),
    ("تعامل مشتری", [
        ("/panel/reviews", "نظرات", "message"),
        ("/panel/qa", "پرسش و پاسخ", "help"),
        ("/panel/reports", "گزارش تخلف", "alert"),
        ("/panel/bookings", "نوبت‌ها", "calendar"),
        ("/panel/messages", "پیام‌ها", "mail"),
        ("/panel/alerts", "هشدار جست‌وجو", "bell"),
    ]),
    ("صاحبان و اعتماد", [
        ("/panel/owners", "صاحبان کسب‌وکار", "users"),
        ("/panel/claims", "درخواست تصاحب", "shield"),
        ("/panel/edits", "تأیید تغییرات", "edit"),
        ("/panel/badges", "نشان‌ها", "award"),
    ]),
    ("درآمد", [
        ("/panel/plans", "پلن‌ها و تعرفه", "wallet"),
        ("/panel/unlocks", "کلید قابلیت‌ها", "lock"),
        ("/panel/subscriptions", "اشتراک‌ها", "credit-card"),
        ("/panel/ads", "تبلیغات", "zap"),
    ]),
    ("سیستم", [
        ("/panel/editor", "ویرایش محتوای سایت", "edit"),
        ("/panel/pages", "صفحات ثابت", "file"),
        ("/panel/appearance", "ظاهر و رنگ‌ها", "palette"),
        ("/panel/features", "قابلیت‌های سایت", "layers"),
        ("/panel/media", "مدیریت فایل‌ها", "image"),
        ("/panel/areas", "محله‌ها", "pin"),
        ("/panel/customers", "مشتری‌ها", "users"),
        ("/panel/follows", "دنبال‌کننده‌ها", "heart"),
        ("/panel/broadcast", "اعلان همگانی", "send"),
        ("/panel/assistant", "دستیار هوشمند", "sparkles"),   # v213
        ("/panel/audit", "گزارش فعالیت‌ها", "activity"),
        ("/panel/traffic", "ترافیک و سپر", "shield"),
        ("/panel/spam", "کنسول اسپم", "shield"),
        ("/panel/analytics", "آمار بازدید", "chart"),
        ("/panel/trash", "بازیابی فایل‌ها", "trash"),
        ("/panel/settings", "تنظیمات سایت", "settings"),
        ("/panel/backup", "پشتیبان‌گیری", "database"),
        ("/panel/demo", "دادهٔ نمونه", "sparkles"),
    ]),
]

OWNER_NAV = [item for _g, items in OWNER_NAV_GROUPS for item in items]

# The shopkeeper's own area. Defined here (not only in views_owner) so the
# mobile menu can offer it without importing that module and creating a cycle.
def _nav_visible(h):
    """Hide feature-gated nav entries. Haggling (v65) is off by default, so
    its inbox is only offered when the owner has enabled the feature."""
    if h == "/my/offers" and not db.haggle_settings().get("enabled"):
        return False
    return True


OWNER_AREA_NAV = [
    ("/my", "داشبورد", "dashboard"),
    ("/my/businesses", "کسب‌وکارهای من", "store"),
    ("/my/orders", "سفارش‌ها", "cart"),
    ("/my/chats", "گفت‌وگوها", "message"),
    ("/my/tickets", "تیکت پشتیبانی", "help"),
    ("/my/stories", "استوری‌ها", "image"),
    ("/my/broadcast", "فراخوان", "bell"),
    ("/my/trash", "بازیابی فایل‌ها", "trash"),
    ("/my/reviews", "نظرات", "message"),
    ("/my/questions", "پرسش و پاسخ", "help"),
    ("/my/bookings", "نوبت‌ها", "calendar"),
    ("/my/offers", "پیشنهادهای قیمت", "tag"),
    ("/my/plan", "اشتراک من", "wallet"),
    ("/my/claim", "تصاحب کسب‌وکار", "shield"),
    ("/my/assistant", "فعالیت دستیار", "activity"),   # v227
    ("/assistant", "دستیار هوشمند", "sparkles"),   # v215
]

# What a shopkeeper actually gets. Shown in the menu BEFORE sign-in too, so the
# features stop being invisible behind a login wall: the whole point of the
# door is that people can see what is behind it. Each row links straight to the
# page; /login bounces back there after sign-in via ?next=.
OWNER_PERKS = [
    ("/my/businesses", "صفحهٔ اختصاصی دکان", "store",
     "نام، آدرس، ساعت کار، عکس و شمارهٔ تماس — یک‌جا"),
    ("/my/qr", "بارکد QR ویترین", "grid",
     "دکانتان را انتخاب کنید، بارکد را چاپ کنید و روی شیشه بزنید"),
    ("/my/bookings", "نوبت‌دهی اینترنتی", "calendar",
     "مشتری خودش نوبت می‌گیرد؛ شما فقط پذیرایی می‌کنید"),
    ("/my/chats", "گفت‌وگو با مشتریان", "message",
     "مشتری پیام می‌دهد، شما همان‌جا پاسخ می‌دهید"),
    ("/my/reviews", "نظرات و امتیاز", "message",
     "نظرهای مشتری را ببینید و گرم پاسخ بدهید"),
    ("/my/tickets", "پشتیبانی مستقیم", "help",
     "هر جا گیر کردید، کنارتان هستیم"),
]


def cat_options(tree, selected="", blank=None, group_selectable=False):
    """<option> markup for the two-level category tree.

    With 140+ trades a flat list is unusable, so children are nested under an
    <optgroup>. A parent that has children is a heading only — a shop belongs
    to a specific trade, not to "food" — unless group_selectable is set, which
    the admin filters want so you can filter a whole branch at once.
    """
    out = ""
    if blank is not None:
        out += f'<option value="">{esc(blank)}</option>'
    for c in tree:
        kids = c.get("children") or []
        sel = ' selected' if selected == c["slug"] else ''
        if not kids:
            out += f'<option value="{esc(c["slug"])}"{sel}>{esc(c["name"])}</option>'
            continue
        if group_selectable:
            out += (f'<option value="{esc(c["slug"])}"{sel}>'
                    f'{esc(c["name"])} (همه)</option>')
        out += f'<optgroup label="{esc(c["name"])}">'
        for k in kids:
            ksel = ' selected' if selected == k["slug"] else ''
            out += f'<option value="{esc(k["slug"])}"{ksel}>{esc(k["name"])}</option>'
        out += '</optgroup>'
    return out


# ---------------------------------------------------------------- colour math
# The owner can pick the site colour from the admin panel. Everything derived
# from that choice (hover, the readable label colour ON a filled button) is
# computed here with real WCAG maths, because a hand-picked "lighter" hex is
# how the old themes ended up with faint text in one of the two modes.

_HEX3 = _re.compile(r"^#([0-9a-fA-F]{3})$")
_HEX6 = _re.compile(r"^#([0-9a-fA-F]{6})$")


def hex_rgb(value, fallback):
    """Return (r, g, b) for #rgb/#rrggbb, or `fallback` when malformed. The
    value comes from a form field, so it must be validated before it is echoed
    into a <style> block (it is also used inside an injection-free CSS context)."""
    s = str(value or "").strip()
    m = _HEX6.match(s)
    if m:
        h = m.group(1)
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    m = _HEX3.match(s)
    if m:
        h = m.group(1)
        return tuple(int(c * 2, 16) for c in h)
    return fallback


def _channel(c):
    c /= 255.0
    return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4


def rel_luminance(rgb):
    r, g, b = (_channel(c) for c in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast_ratio(rgb_a, rgb_b):
    la, lb = rel_luminance(rgb_a), rel_luminance(rgb_b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def mix_hex(rgb, target, amount):
    """Linear blend of `rgb` towards `target` (0..1). amount=0.2 = 20% lighter."""
    return "#%02x%02x%02x" % tuple(
        round(c + (t - c) * amount) for c, t in zip(rgb, target))


def on_color(rgb):
    """Pick the label colour for a button painted with `rgb`: white or ink,
    whichever clears AA (4.5:1); if neither does, whichever is closer."""
    white, ink = (255, 255, 255), (27, 31, 37)
    cw, ci = contrast_ratio(rgb, white), contrast_ratio(rgb, ink)
    if cw >= 4.5 or cw >= ci:
        return "#ffffff"
    return "#1b1f25"


# Day primary default — keep in sync with db.DEFAULTS['color_primary'].
DAY_PRIMARY_DEFAULT = (0x0b, 0x60, 0x59)
DAY_ACCENT_DEFAULT = (0xb4, 0x53, 0x09)   # زعفرانی گرم — keep in sync with db.DEFAULTS['color_accent']


_GA_ID_RE = _re.compile(r"^G-[A-Z0-9]{6,12}$")


def ga_head(s):
    """v114: optional Google Analytics 4.

    Nothing loads unless the owner pasted a valid measurement id
    (panel → settings), so an offline/Pydroid install stays fully
    self-contained and zero Google cookies are set by default. When it IS
    set, consent defaults are granted up-front — every GA cookie
    (_ga, _ga_<id>, _ga_*) works with no banner, which is what the owner
    asked for; the audience is Iran, where a consent popup is not required.
    """
    gid = (s.get("ga_measurement_id") or "").strip().upper()
    if not _GA_ID_RE.match(gid):
        return ""
    return (
        f'<script async src="https://www.googletagmanager.com/gtag/js?id={gid}"></script>'
        "<script>window.dataLayer=window.dataLayer||[];"
        "function gtag(){dataLayer.push(arguments);}"
        "gtag('js',new Date());"
        "gtag('consent','default',{'ad_storage':'granted',"
        "'ad_user_data':'granted','ad_personalization':'granted',"
        "'analytics_storage':'granted'});"
        f"gtag('config','{gid}');</script>")


def theme_css(s):
    """Owner-chosen colours, injected as DAY-theme token overrides only.

    v111 rule: the night theme keeps its own tokens (tokens.css) so a colour
    chosen for daylight can never make night text faint. The injected block is
    scoped to :root[data-theme="light"], which outranks the bare :root block in
    tokens.css regardless of load order."""
    primary = hex_rgb(s.get("color_primary"), DAY_PRIMARY_DEFAULT)
    accent = hex_rgb(s.get("color_accent"), DAY_ACCENT_DEFAULT)
    background = hex_rgb(s.get("color_background"), (0xf7, 0xf3, 0xec))
    foreground = hex_rgb(s.get("color_foreground"), (0x24, 0x1d, 0x14))
    ph = "#%02x%02x%02x" % primary
    ah = "#%02x%02x%02x" % accent
    bh = "#%02x%02x%02x" % background
    fh = "#%02x%02x%02x" % foreground
    # Derived ramp: hover is a real 14% step towards white/black depending on
    # the base lightness, never a fixed hex.
    p_hover = mix_hex(primary, (255, 255, 255) if rel_luminance(primary) < .45
                      else (0, 0, 0), .14)
    p_text = ph if contrast_ratio(primary, (255, 255, 255)) >= 4.5 \
        else mix_hex(primary, (0, 0, 0), .18)
    a_hover = mix_hex(accent, (255, 255, 255) if rel_luminance(accent) < .45
                      else (0, 0, 0), .14)
    p_rgb, a_rgb = primary, accent
    return f""":root[data-theme="light"]{{
  --color-primary:{ph};
  --color-primary-hover:{p_hover};
  --color-on-primary:{on_color(p_rgb)};
  --color-primary-text:{p_text};
  --color-accent:{ah};
  --color-accent-hover:{a_hover};
  --color-on-accent:{on_color(a_rgb)};
  --color-ring:{ph};
  --color-background:{bh};
  --color-foreground:{fh};
  --color-card-foreground:{fh};
  --story-ring-glow:rgba({p_rgb[0]},{p_rgb[1]},{p_rgb[2]},.22);
  --e-glow:0 0 0 3px rgba({p_rgb[0]},{p_rgb[1]},{p_rgb[2]},.18);
}}"""


def _aria(h, active):
    # 'aria-current="page"' built without an escaped quote so the literal can
    # live inside an f-string on Python 3.11 (no backslash in {expr}).
    return ' aria-current="page"' if h == active else ""


def header(s, active, token="", panel_counts=None):
    visible_nav = public_nav(s)
    nav = "".join(
        f'<a href="{h}"{_aria(h, active)}>{t}</a>'
        for h, t, _ in visible_nav if h != "/assistant")   # v215: desktop strip is width-measured; the live bar covers it
    mark = (f'<img class="brand-logo" src="{esc(s.get("site_logo"))}" alt="{esc(s.get("site_name"))}">'
            if s.get("site_logo") else
            f'<span class="brand-mark"><img src="/assets/img/logo-display.png?v183" alt="" width="23" height="23"></span>')
    mnav = "".join(
        f'<a href="{h}"{_aria(h, active)} data-nav-close>'
        f'{icon(i)}<span>{t}</span></a>' for h, t, i in visible_nav)
    owner_link = f'<a class="btn btn-primary btn-sm hide-mobile" href="/panel">{icon("settings")}<span>پنل مدیریت</span></a>' if token else ""

    # ---- signed-in state. Showing "ورود / ثبت‌نام" to somebody who is
    # already signed in is the single most confusing thing a header can do.
    me = ctx_owner()
    cust = ctx_customer()
    signed_in = bool(me or cust)
    if me:
        who = (me.get("name") or "").strip() or me.get("phone", "")
        auth_btn = (f'<a class="btn btn-glass btn-sm hide-mobile account-chip" href="/my" '
                    f'title="پنل شما">'
                    f'<span class="account-avatar" aria-hidden="true">{esc(who[:1])}</span>'
                    f'<span class="account-text"><small>وارد شده‌اید</small>'
                    f'<strong>{esc(who)}</strong></span></a>')
    else:
        if cust:
            who = (cust.get("name") or "").strip() or cust.get("phone", "")
            auth_btn = (f'<a class="btn btn-glass btn-sm hide-mobile account-chip" href="/me" '
                        f'title="حساب شما">'
                        f'<span class="account-avatar" aria-hidden="true">{esc(who[:1])}</span>'
                        f'<span class="account-text"><small>حساب من</small>'
                        f'<strong>{esc(who)}</strong></span></a>')
        else:
            auth_btn = (f'<a class="btn btn-glass btn-sm hide-mobile" href="/login">'
                        f'{icon("user")}<span>ورود / ثبت‌نام</span></a>')

    # ---- the cart/login slot (v58, v107): on the narrow mobile header every
    # 44px icon costs room the hamburger needs. The cart is always reachable
    # from the mobile drawer and from the desktop header, so we no longer spend
    # a scarce mobile slot on it — logged in or out. Logged-out visitors get a
    # login icon in that slot on mobile instead; desktop keeps the cart.
    cart_cls = "btn-icon hide-mobile"
    cart_btn = (f'<a class="{cart_cls}" href="/cart" aria-label="سبد خرید" title="سبد خرید">'
                f'{icon("cart")}<span class="fav-dot" data-cart-count hidden></span></a>')
    login_icon = (f'<a class="btn-icon hide-desktop" href="/login" aria-label="ورود" '
                  f'title="ورود / ثبت‌نام">{icon("user")}</a>' if not signed_in else "")

    # ---- notification bell (signed-in customers and shopkeepers)
    # v146: one person can be BOTH roles (unified login mints both sessions).
    # The bell must not silently point at only the customer inbox — a
    # shopkeeper's order/review/approval notifications live in the owner
    # inbox, so when the visitor owns a business the bell counts BOTH
    # inboxes and opens the owner page, which also lists the customer-role
    # notifications of the same person (see views_owner.notifications_page).
    notif_btn = ""
    if s.get("notif_enabled") == "1":
        if me and db.owner_has_business(me["id"]):
            unread = db.owner_unread(me["id"])
            href = "/my/notifications"
            if cust:
                unread += db.notifications_unread(cust["id"])
        elif cust:
            unread = db.notifications_unread(cust["id"])
            href = "/me/notifications"
        else:
            unread = 0
            href = ""
        if unread is not None and href:
            notif_btn = (f'<a class="btn-icon" href="{href}" aria-label="اعلان‌ها" title="اعلان‌ها">'
                         f'{icon("bell")}'
                         + (f'<span class="fav-dot">{fa(unread) if unread < 100 else "۹۹+"}</span>'
                            if unread else '')
                         + '</a>')

    # ---- the hamburger must offer the CURRENT area, not always the public
    # site. In a panel on a phone the sidebar sits far below the content, so
    # without this the menu button was effectively useless there.
    area = ctx_area()
    area_nav = ""
    if area == "panel" and token:
        groups = ""
        # panel_page already fetched this exact live snapshot for its sidebar;
        # reuse it in the mobile drawer instead of issuing the query again.
        mobile_counts = panel_counts if panel_counts is not None else _panel_counts()
        for gname, gitems in OWNER_NAV_GROUPS:
            links = ""
            for h, t, i in gitems:
                n = mobile_counts.get(h, 0)
                pill = f'<span class="nav-count nums">{fa(n)}</span>' if n else ""
                links += (f'<a href="{h}" data-nav-close>{icon(i)}'
                          f'<span>{t}</span>{pill}</a>')
            groups += (f'<span class="mnav-title">{esc(gname)}</span>{links}')
        area_nav = (f'<div class="mnav-area"><strong class="mnav-head">'
                    f'{icon("shield")}<span>پنل مدیریت</span></strong>'
                    f'{groups}</div><hr class="divider">'
                    f'<span class="mnav-title">سایت</span>')
    elif area == "my" and me:
        links = "".join(
            f'<a href="{h}" data-nav-close>{icon(i)}<span>{t}</span></a>'
            for h, t, i in OWNER_AREA_NAV if _nav_visible(h))
        area_nav = (f'<div class="mnav-area"><strong class="mnav-head">'
                    f'{icon("store")}<span>پنل کسب‌وکار من</span></strong>'
                    f'{links}</div><hr class="divider">'
                    f'<span class="mnav-title">سایت</span>')

    if me:
        who = (me.get("name") or "").strip() or me.get("phone", "")
        # Signing in used to REMOVE things from this menu: the perk list and the
        # "all features" link both lived in the else-branch, so the moment a
        # shopkeeper logged in the map of the site vanished. Nothing may get
        # smaller on sign-in — the account block replaces the sign-in button,
        # and the way to the rest of the site stays exactly where it was.
        account_block = (
            f'<a class="nav-cta" href="/my" data-nav-close>{icon("user")}'
            f'<span>{esc(who)}<small>وارد شده‌اید — پنل دکان</small></span></a>'
            f'<div class="mnav-perks">'
            f'<span class="mnav-title">میان‌برهای پنل شما</span>'
            + "".join(
                f'<a href="{h}" data-nav-close>{icon(i)}'
                f'<span>{esc(t_)}<small>{esc(d)}</small></span></a>'
                for h, t_, i, d in OWNER_PERKS)
            + f'<a class="mnav-perk-all" href="/features" data-nav-close>'
              f'{icon("grid")}<span>دیدن همهٔ امکانات سایت</span></a></div>'
            f'<form method="post" action="/my/logout">'
            f'<button class="mnav-logout" type="submit">{icon("logout")}'
            f'<span>خروج از حساب</span></button></form>')
    else:
        # Not signed in. A bare "sign in" button hides every shopkeeper feature
        # behind a door with nothing written on it, so list the perks right
        # here — each one a real link that lands on the feature after login.
        perks = "".join(
            f'<a href="/login?next={urllib.parse.quote(h)}" data-nav-close>'
            f'{icon(i)}<span>{esc(t_)}<small>{esc(d)}</small></span></a>'
            for h, t_, i, d in OWNER_PERKS)
        account_block = (
            f'<a class="nav-cta" href="/login" data-nav-close>{icon("store")}'
            f'<span>پنل دکان‌داران<small>ورود و ثبت‌نام</small></span></a>'
            f'<div class="mnav-perks">'
            f'<span class="mnav-title">با ثبت دکان چه چیزی می‌گیرید</span>'
            f'{perks}'
            f'<a class="mnav-perk-all" href="/features" data-nav-close>'
            f'{icon("grid")}<span>دیدن همهٔ امکانات سایت</span></a></div>')

    return f'''<a class="skip-link" href="#main">پرش به محتوای اصلی</a>
<header class="site-header">
  <div class="container-wide header-inner">
    <a class="brand" href="/">
      {mark}
      <span class="brand-text">{esc(s.get('site_name'))}<small>{esc(s.get('tagline'))}</small></span>
    </a>
    <nav class="main-nav" aria-label="ناوبری اصلی">{nav}</nav>
    <div class="header-actions">
      <a class="btn btn-glass btn-sm hide-mobile" href="/cities" title="انتخاب شهر">
        {icon("pin")}<span>شهر</span></a>
      <a class="btn-icon hide-mobile favorite-link" href="/favorites" data-favorites-link
         aria-label="علاقه‌مندی‌ها" title="علاقه‌مندی‌ها">
        {icon("heart")}<span class="fav-dot" data-fav-count hidden></span></a>
      {cart_btn}
      {login_icon}
      {notif_btn}
      {auth_btn}
      <a class="btn btn-accent btn-sm hide-mobile" href="/register-business">{icon("plus")}<span>ثبت کسب‌وکار</span></a>
      {owner_link}
      <button class="btn-icon nav-toggle" data-nav-toggle aria-expanded="false" aria-controls="mobile-nav"
              aria-label="باز کردن منو" type="button">{icon("menu")}</button>
    </div>
  </div>
</header>
<div class="mobile-nav" id="mobile-nav" aria-hidden="true">
  <div class="backdrop" data-nav-close></div>
  <div class="panel" role="dialog" aria-modal="true" aria-label="منوی ناوبری">
    <div class="between mb-lg"><strong>منو</strong>
      <button class="btn-icon" data-nav-close aria-label="بستن منو" type="button">{icon("x")}</button></div>
    {area_nav}
    {mnav}
    <hr class="divider">
    <a href="/assistant" class="nav-ai" data-nav-close>{icon("sparkles")}<span>گفت‌وگو با دستیار هوشمند</span><small class="nav-count">جدید</small></a>
    <a href="/favorites" class="favorite-link" data-favorites-link data-nav-close>
      {icon("heart")}<span>علاقه‌مندی‌ها</span><small class="nav-count nums" data-fav-count hidden></small></a>
    <a href="/cart" data-nav-close>{icon("cart")}<span>سبد خرید</span></a>
    <a href="/cities" data-nav-close>{icon("pin")}<span>انتخاب شهر</span></a>
    <a href="/me" data-nav-close>{icon("user")}<span>حساب من</span></a>
    {account_block}
    <a href="/register-business" data-nav-close>{icon("plus")}<span>ثبت کسب‌وکار جدید</span></a>
    <a href="/rules" data-nav-close>{icon("shield")}<span>قوانین</span></a>
  </div>
</div>'''


def social_links(s):
    """Only render an icon when there is somewhere for it to go.

    An <a href=""> reloads the current page and reads to a screen reader as a
    real link, so an unconfigured social account was shipping three dead
    controls onto all 46 pages. No URL, no link.
    """
    out = ""
    for key, ic, label in (("instagram", "instagram", "اینستاگرام"),
                           ("telegram", "telegram", "تلگرام"),
                           ("whatsapp", "whatsapp", "واتساپ"),
                           ("eitaa", "eitaa", "ایتا"), ("bale", "bale", "بله"),
                           ("soroush", "soroush", "سروش"), ("rubika", "rubika", "روبیکا")):
        url = (s.get(key) or "").strip()
        if key in db.MESSENGERS and url and not url.startswith(("http://", "https://")):
            url = db.MESSENGERS[key][0] + url.lstrip("@")
        # a bare "https://instagram.com/" with no account is not a destination
        if not url or url.rstrip("/") in ("https://instagram.com", "http://instagram.com",
                                          "https://t.me", "http://t.me",
                                          "https://wa.me", "http://wa.me"):
            continue
        out += (f'<a href="{esc(url)}" aria-label="{label}" '
                f'target="_blank" rel="noopener">{icon(ic)}</a>')
    email = (s.get("email") or "").strip()
    if email:
        out += f'<a href="mailto:{esc(email)}" aria-label="ایمیل">{icon("mail")}</a>'
    return out


def media_embed(value, title="ویدیو"):
    """v285: render a stored news/event video value — an allowlisted embed
    (Aparat/YouTube iframe) or a plain video file (uploaded/https) — as a
    luxurious, responsive player block. Empty/unknown values render nothing."""
    v = (value or "").strip()
    if not v:
        return ""
    if ("aparat.com/video/video/embed" in v
            or "youtube-nocookie.com/embed" in v
            or "youtube.com/embed" in v):
        return (f'<div class="embed-169 reveal"><iframe src="{esc(v)}" '
                f'title="{esc(title)}" loading="lazy" allowfullscreen '
                'allow="encrypted-media; fullscreen; picture-in-picture" '
                'referrerpolicy="origin" style="border:0"></iframe></div>')
    if v.startswith("/") or v.lower().startswith(("https://", "http://")):
        return (f'<video class="news-video reveal" controls preload="metadata" '
                f'playsinline src="{esc(v)}">مرورگر شما پخش ویدیو را پشتیبانی '
                'نمی‌کند.</video>')
    return ""


def footer(s, cats):
    catlinks = "".join(
        f'<li><a href="/businesses?cat={esc(c["slug"])}">{esc(c["name"])}</a></li>'
        for c in cats[:6])
    links = "".join(f'<li><a href="{h}">{t}</a></li>' for h, t, _ in public_nav(s)[1:6])
    return f'''<footer class="site-footer">
  <div class="container-wide">
    <div class="footer-grid">
      <div class="footer-col footer-about">
        <a class="brand" href="/">
          <span class="brand-mark"><img src="/assets/img/logo-display.png?v183" alt="" width="23" height="23"></span>
          <span class="brand-text">{esc(s.get('site_name'))}<small>{esc(s.get('tagline'))}</small></span>
        </a>
        <p>{esc(s.get('description'))}</p>
        <div class="social-row mt-lg">
          {social_links(s)}
        </div>
      </div>
      <div class="footer-col"><h3>دسترسی سریع</h3><ul>{links}</ul></div>
      <div class="footer-col"><h3>دسته‌های پرمخاطب</h3><ul>{catlinks or '<li><span class="text-muted">—</span></li>'}<li><a href="/categories">همهٔ ۱۷۳ دسته…</a></li></ul></div>
      <div class="footer-col"><h3>تماس با ما</h3><ul>
        <li><a href="tel:{esc(s.get('phone_raw'))}">{esc(s.get('phone'))}</a></li>
        <li><a href="mailto:{esc(s.get('email'))}">{esc(s.get('email'))}</a></li>
        <li><span class="text-muted">{esc(s.get('address'))}</span></li>
        <li><a href="/rules">قوانین و مقررات</a></li></ul></div>
    </div>
    <div class="trust-row" aria-label="نشان‌های اعتماد">
      <a referrerpolicy="origin" rel="noopener" target="_blank"
         href="https://trustseal.enamad.ir/?id=7660147&amp;Code=kuhoa5a38FhfpKwFi0facKhDHTSJncoE"><img
         referrerpolicy="origin"
         src="https://trustseal.enamad.ir/logo.aspx?id=7660147&amp;Code=kuhoa5a38FhfpKwFi0facKhDHTSJncoE"
         loading="lazy"
         alt="نشان اعتماد الکترونیکی" style="cursor:pointer"
         code="kuhoa5a38FhfpKwFi0facKhDHTSJncoE" width="80" height="80"></a>
    </div>
    <div class="footer-bottom">
      <span>© {fa(1405)} {esc(s.get('site_name'))} — همهٔ حقوق محفوظ است.</span>
      <span>{esc(s.get('footer_note'))}</span>
    </div>
  </div>
</footer>'''


def page(s, title, body, active="", desc=None, extra_head="", extra_js="",
         token="", cats=None, body_class="", show_chrome=True,
         asset_profile="public", panel_counts=None):
    cats = cats if cats is not None else []
    # v77 (SEO): متای description هرگز نباید یک placeholder خالی مثل «توضیح»
    # باشد. اگر صفحه desc اختصاصی نداشت و تنظیمات هم خالی/جاگذاری بود، از
    # نام+شعار سایت یک توضیح واقعی می‌سازیم.
    _stored = (s.get("description") or "").strip()
    _placeholder = _stored in ("", "توضیح", "توضیحات", "description")
    d = (desc or "").strip() or ("" if _placeholder else _stored) or \
        f"{s.get('site_name', 'دست گیر')} — {s.get('tagline', 'یارِ خرید و فروشِ محلی')}"
    customer = ctx_customer()
    boot = {
        "mapProvider": s.get("map_provider", "auto"),
        "gmapsKey": s.get("gmaps_key", ""),
        "mapLat": s.get("map_lat", "32.6340"),
        "mapLng": s.get("map_lng", "51.3670"),
        "mapZoom": s.get("map_zoom", "14"),
        # Signed-in favourites are server truth; guests fall back to the
        # versioned device-local set. JSON is embedded with json_embed below.
        "favoriteSignedIn": bool(customer),
        "favoriteSlugs": db.fav_slugs(customer["id"]) if customer else [],
        "pricesEnabled": s.get("prices_enabled") == "1",
    }
    chrome_top = header(s, active, token, panel_counts=panel_counts) if show_chrome else ""
    chrome_bot = footer(s, cats) if show_chrome else ""
    # v160-fix (سئو): canonical سراسری از مسیر صفحه + origin تنظیمات؛
    # صفحات خصوصی (/panel، /my، /me، /login) noindex می‌گیرند تا هرگز
    # در نتایج جست‌وجو ظاهر نشوند. مسیر از context درخواست می‌آید.
    _path = (getattr(_ctx, "path", "") or "/")
    base = (s.get("site_url") or "").strip().rstrip("/")
    if base and not base.startswith(("http://", "https://")):
        base = "https://" + base
    canonical = (base + _path) if base else _path
    _private = _path.startswith(("/panel", "/my", "/me", "/login", "/cart", "/favorites", "/assistant", "/offline"))
    noindex = ('<meta name="robots" content="noindex, nofollow">\n' if _private else
               '<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">\n')
    # v217: صفحه‌های با کوئری (?q=, ?page=, ?sort=) canonical به مسیر پایه — از
    # ایندکس‌شدن نسخه‌های تکراری جلوگیری می‌کند. og:image پیش‌فرض برای همهٔ صفحات
    # (صفحهٔ کسب‌وکار عکس خودش را در extra_head اضافه می‌کند و این بلوک را ندارد).
    og_default = ("" if "og:image" in (extra_head or "") else
                  f'<meta property="og:image" content="{esc(base)}/assets/img/og-default.png?v217">\n'
                  f'<meta property="og:image:width" content="1200">\n<meta property="og:image:height" content="630">\n'
                  f'<meta name="twitter:card" content="summary_large_image">\n')
    # v142: light 45s poll that keeps the header bell's unread badge fresh on
    # signed-in pages (/my, /me, ...). Loaded only when a bell can exist.
    _notif_poll = ""
    owner = ctx_owner()
    if (s.get("notif_enabled") == "1" and show_chrome
            and (customer or owner)):
        _notif_poll = '<script src="/assets/js/notifpoll.js?v142"></script>'
    # v184/performance: panel pages need app.js (forms, theme, icon picker), but
    # never the public cart, story viewer, or live-directory poller. Keeping the
    # same DOM/CSS while skipping those three modules removes requests and parse
    # work from every admin navigation.
    _scripts = '<script type="module" src="/assets/js/app.js?v281"></script>'
    if asset_profile != "panel":
        # v272 (ریشهٔ «سایت تغییر نکرده»): کوئری استاتیک از v232 کهنه مانده
        # بود و کش مرورگر/سرویس‌ورکر همان فایل قدیمی را برمی‌گرداند — با هر
        # تغییری در assist.js کوئری باید بامپ شود.
        _scripts += '<script type="module" src="/assets/js/assist.js?v281"></script>'   # v222: geo attach
        _scripts += ('<script type="module" src="/assets/js/cart.js?v125"></script>'
                     '<script type="module" src="/assets/js/stories.js?v177"></script>'
                     '<script type="module" src="/assets/js/live.js?v156"></script>')
    # NOTE: the site-wide inline-edit bar was removed from public pages. Editing
    # lives exclusively inside the admin panel (/panel/editor etc.), so visitors
    # never see any admin UI on the public site.
    # Presentation-only merchant design; management panel remains untouched.
    _bazaar = asset_profile != "panel" and ctx_area() != "panel" and not _path.startswith("/panel")
    _skin_attr = ' data-dg-bazaar="merchant1"' if _bazaar else ''
    _skin_head = '<link rel="stylesheet" href="/assets/bazaar/bazaar.css?v=28101">' if _bazaar else ''
    _skin_js = '<script type="module" src="/assets/bazaar/bazaar.js?v=28101"></script>' if _bazaar else ''
    if _bazaar and '<div class="container-wide h-hero-in">' in body:
        body = body.replace('<div class="hero-visual is-static" aria-hidden="true"></div>', '', 1)
        body = body.replace('<div class="container-wide h-hero-in">', '<div class="container-wide h-hero-in"><div class="b-scene" aria-hidden="true"><img src="/assets/bazaar/market.webp" width="1254" height="1254" alt="" fetchpriority="high"><div class="b-logo-stage"><img src="/assets/bazaar/logo-relief.png" width="768" height="768" alt=""></div></div>', 1)
    return f'''<!DOCTYPE html>
<html lang="fa" dir="rtl" data-theme="dark"{_skin_attr}>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<!-- v111: theme is applied BEFORE any stylesheet is parsed, so there is no
     flash of the wrong palette on load and nothing to fade at boot. The old
     value "luxury" (pre-v111 night) is normalised to "dark" on read. -->
<script>(function(){{try{{var d=document.documentElement;var t=localStorage.getItem('bz-theme');if(t==='luxury'){{t='dark';localStorage.setItem('bz-theme',t);}}if(!t){{t=matchMedia('(prefers-color-scheme: light)').matches?'light':'dark';}}d.setAttribute('data-theme',t);var m=document.createElement('meta');m.name='theme-color';m.content=t==='light'?'#f7f3ec':'#12151a';document.head.appendChild(m);}}catch(e){{}}}})();</script>
<meta name="theme-color" content="#12151a">
<title>{esc(title)} | {esc(s.get('site_name'))}</title>
<meta name="description" content="{esc(d)}">
{noindex}<link rel="canonical" href="{esc(canonical)}">
<meta property="og:title" content="{esc(title)}">
<meta property="og:description" content="{esc(d)}">
<meta property="og:type" content="website">
<meta property="og:locale" content="fa_IR">
<meta property="og:url" content="{esc(canonical)}">
<meta property="og:site_name" content="{esc(s.get('site_name'))}">
{og_default}<meta name="twitter:title" content="{esc(title)}">
<meta name="twitter:description" content="{esc(d)}">
<link rel="alternate" hreflang="fa-IR" href="{esc(canonical)}">
<link rel="alternate" hreflang="x-default" href="{esc(canonical)}">
<link rel="alternate" type="application/rss+xml" title="{esc(s.get('site_name'))} — اخبار" href="{esc(base)}/feed.xml">
<link rel="icon" href="/assets/img/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/assets/img/icons/app-192.png">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="preload" href="/assets/fonts/Vazirmatn-Variable.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="/assets/css/tokens.css?v281">
<link rel="stylesheet" href="/assets/css/main.css?v285">
<link rel="stylesheet" href="/assets/css/pages.css?v286">
<link rel="stylesheet" href="/assets/css/mobile-refine.css?v177">
<link rel="stylesheet" href="/assets/css/mobile-standard.css?v286">
<link rel="stylesheet" href="/assets/css/theme-night.css?v125">
<link rel="stylesheet" href="/assets/css/theme-light.css?v125">
<style>{theme_css(s)}</style>
{ga_head(s) if show_chrome and asset_profile != "panel" else ""}
{extra_head}
{_skin_head}
<script>window.__BAZARCHE__={json_embed(boot)};</script>
</head>
<body class="{body_class}">
<div class="spatial-bg" aria-hidden="true">
  <span class="orb orb-1"></span><span class="orb orb-2"></span><span class="orb orb-3"></span>
</div>
<div class="spatial-grain" aria-hidden="true"></div>
{icon_sprite()}
{chrome_top}
<main id="main" class="main-content">
{body}
</main>
{chrome_bot}
{bottom_nav(s, active, token) if show_chrome else ""}
{support_widget(s) if show_chrome else ""}
{assistant_widget(s) if show_chrome and asset_profile != "panel" else ""}
{_notif_poll}
{_scripts}
{extra_js}
{_skin_js}
</body>
</html>'''


# ---------------------------------------------------------------- components
def biz_card(b, cat_icons, delay=0, token=""):
    ic = cat_icons.get(b["cat_slug"], "store")
    verified_badge = f'<span class="badge badge-info badge-sm">{icon("shield")}<span>تأییدشده</span></span>' if b.get("verified") else ""
    featured_badge = f'<span class="badge badge-featured badge-sm">{icon("sparkles")}<span>ویژه</span></span>' if b.get("featured") else ""
    tags = "".join(f'<span class="badge badge-neutral">{esc(t)}</span>'
                   for t in b.get("tag_list", [])[:3])
    rating = b.get("rating") or 0
    nrev = b.get("nreviews") or 0
    nrated = b.get("nrated")
    if nrated is None:
        nrated = nrev if rating > 0 else 0
    if nrated > 0:
        rat_html = (f'{stars(rating)}<strong class="nums">{fa(round(rating,1))}</strong>'
                    f'<span>({fa(nrated)} امتیاز)</span>')
    elif nrev > 0:
        rat_html = f'<span class="text-muted text-xs">بدون امتیاز · {fa(nrev)} نظر</span>'
    else:
        rat_html = '<span class="text-muted text-xs">هنوز نظری ثبت نشده</span>'
    hours = esc(b.get("hours") or "")
    ost = b.get("open_state") or db.open_state(b)
    has_story = bool(b.get("has_story"))
    story_badge = (f'<button class="story-chip story-chip-inline" type="button" data-story-biz="{esc(b["slug"])}" '
                   f'aria-label="استوری {esc(b["name"])}">{icon("image")}<span>استوری ۲۴ساعته</span></button>'
                   if has_story else '')
    return f'''<article class="card card-hover tilt biz-card reveal-3d" data-tilt="6" data-delay="{delay}"
  data-biz data-open="{esc(ost['state'])}" data-cat="{esc(b['cat_slug'])}" data-name="{esc(b['name'])}"
  data-rating="{rating}" data-reviews="{nrev}" data-featured="{b.get('featured',0)}"
  data-hours-json="{hours}" data-slug="{esc(b['slug'])}"
  data-search="{esc(b['name'] + ' ' + (b.get('descr') or '') + ' ' + (b.get('tags') or '') + ' ' + (b.get('address') or ''))}">
  <span class="sheen" aria-hidden="true"></span>
  <div class="card-media biz-thumb{" has-photo" if b.get("images") else ""}{" story-ring" if has_story else ""}">
    {f'<img class="biz-cover" src="{esc(b["images"][0])}" alt="{esc(b["name"])}" loading="lazy" decoding="async">'
     if b.get("images") else
     f'<div class="biz-thumb-art" aria-hidden="true">{cat_icon(ic, 128)}</div>'}
    {f'<div class="media-corner-badge">{verified_badge}</div>' if verified_badge else ''}
  </div>
  <div class="card-body layer-1">
    <div class="between" style="align-items:flex-start;gap:8px">
      <div class="card-title-wrap">
        <h3 class="card-title"><a href="/b/{esc(b['slug'])}" class="stretch-link">{esc(b['name'])}</a></h3>
        <div class="card-badges-row">
          {featured_badge}
          {open_badge(b, compact=True)}
        </div>
      </div>
      <button class="fav-btn card-fav-btn" type="button" data-fav="{esc(b['slug'])}"
              data-fav-name="{esc(b['name'])}" aria-pressed="false"
              aria-label="علاقه‌مندی: {esc(b['name'])}">{icon("heart")}</button>
    </div>
    <div class="card-meta">{rat_html}{story_badge}</div>
    <p class="card-desc">{esc(b.get('descr'))}</p>
    <div class="cluster mt-sm">{tags}</div>
    <div class="card-foot">
      <span class="card-meta" style="margin:0">{icon("pin")}<span>{esc(b.get('address'))}</span></span>
      <span class="card-arrow" aria-hidden="true">{icon("chevron-left")}</span>
    </div>
  </div>
</article>'''


OPEN_CLS = {"open": "badge-open", "closing": "badge-warn",
            "closed": "badge-closed", "unknown": "badge-neutral"}
OPEN_ICON = {"open": "clock", "closing": "bell",
             "closed": "x-circle", "unknown": "clock"}


def open_badge(b, compact=False):
    """The live 'open now' pill, rendered server-side in Iran time.

    Rendering it on the server matters: a phone with a wrong timezone would
    otherwise be told a shop is open when it is shut. app.js refreshes the
    same element every minute so a page left sitting on screen stays honest.
    """
    st = b.get("open_state") or db.open_state(b)
    cls = OPEN_CLS.get(st["state"], "badge-neutral")
    text = st["label"]
    if compact and st["state"] == "closing":
        text = f"{fa(st['minutes'])} دقیقه تا بستن"
    elif compact and st["state"] == "unknown":
        text = "نامشخص"
    title = f' title="{esc(st["detail"])}"' if st.get("detail") else ""
    return (f'<span class="badge {cls}" data-open-badge '
            f'data-open-state="{esc(st["state"])}"{title}>'
            f'{icon(OPEN_ICON.get(st["state"], "clock"))}'
            f'<span>{esc(text)}</span></span>')


def open_line(b):
    """The fuller two-line version used on a business's own page."""
    st = b.get("open_state") or db.open_state(b)
    if st["state"] == "unknown":
        return ""
    cls = {"open": "is-open", "closing": "is-closing",
           "closed": "is-closed"}.get(st["state"], "")
    return (f'<div class="open-line {cls}" data-open-line '
            f'data-open-state="{esc(st["state"])}">'
            f'<span class="open-dot" aria-hidden="true"></span>'
            f'<strong>{esc(st["label"])}</strong>'
            + (f'<span class="open-detail">{esc(st["detail"])}</span>'
               if st.get("detail") else "")
            + '</div>')


def empty_state(icon_name, title, text, action=""):
    return f'''<div class="empty-state">
  <span class="icon-wrap">{icon(icon_name)}</span>
  <h3>{esc(title)}</h3><p>{esc(text)}</p>{action}
</div>'''


def password_reminder(account_url):
    """A prominent-but-polite security nudge shown right after a user signs in
    with a phone number and has no username+password yet (v58).

    Research-backed shape (Nielsen + password-onboarding patterns):
      • visible (sits at the top of the dashboard), but NOT a blocking modal —
        the user can keep using the site and act later;
      • states the BENEFIT in plain words (no SMS next time, more secure);
      • one clear CTA + a "later" link that closes it for this visit only —
        it returns on the next sign-in until a password is actually set."""
    return f'''<div class="pw-reminder" role="alert" data-pw-reminder>
  <span class="pw-reminder-ic" aria-hidden="true">{icon("shield")}</span>
  <div class="pw-reminder-body">
    <strong>حساب خود را ایمن‌تر کنید</strong>
    <p>با تعیین نام کاربری و رمز عبور، ورود بعدی شما بدون پیامک و سریع‌تر می‌شود.</p>
  </div>
  <a class="btn btn-accent btn-sm" href="{esc(account_url)}">{icon("lock")}<span>تعیین نام کاربری و رمز</span></a>
  <button class="pw-reminder-x" type="button" data-pw-close aria-label="بعداً">{icon("x")}</button>
</div>'''


def stat_card(icon_name, value, label, suffix="", delay=0, href=""):
    # v78: اگر href داده شود، کل کارت یک پیوند قابل لمس (≥۴۴px) به بخش
    # مربوطهٔ پنل است — داشبورد از «نمایش» به «ناوبری سریع» ارتقا می‌یابد.
    try:
        num = float(str(value).replace(",", "").replace("٬", ""))
        numeric = True
    except (TypeError, ValueError):
        numeric = False

    if numeric:
        inner = (f'<div class="stat-value nums" data-count="{num:g}" '
                 f'data-suffix="{esc(suffix)}">۰</div>')
    else:
        inner = f'<div class="stat-value nums">{esc(value)}{esc(suffix)}</div>'

    body = f'''<span class="sheen" aria-hidden="true"></span>
  <span class="stat-icon layer-1">{icon(icon_name)}</span>
  <div class="layer-1">
    {inner}
    <div class="stat-label">{esc(label)}</div>
  </div>'''
    if href:
        return (f'<a class="card glass stat tilt reveal stat-link" href="{esc(href)}" '
                f'data-tilt="5" data-delay="{delay}">{body}</a>')
    return f'''<div class="card glass stat tilt reveal" data-tilt="5" data-delay="{delay}">
  {body}</div>'''


def section_head(eyebrow, title, sub=None, center=False, eyebrow_icon="sparkles"):
    c = " center" if center else ""
    sb = f'<p>{esc(sub)}</p>' if sub else ""
    return f'''<div class="section-head{c} reveal">
  <span class="eyebrow">{icon(eyebrow_icon)}<span>{esc(eyebrow)}</span></span>
  <h2>{esc(title)}</h2>{sb}</div>'''


def breadcrumb(*parts):
    out = ['<nav class="breadcrumb" aria-label="مسیر صفحه"><a href="/">خانه</a>']
    for i, (label, href) in enumerate(parts):
        out.append(icon("chevron-left"))
        if href and i < len(parts) - 1:
            out.append(f'<a href="{href}">{esc(label)}</a>')
        else:
            out.append(f'<span aria-current="page">{esc(label)}</span>')
    out.append("</nav>")
    return "".join(out)


# ---------------------------------------------------------------- owner shell
def _panel_counts():
    """Return one live snapshot for all 11 navigation pills.

    v184 keeps the exact counter contract but crosses the Python/SQLite boundary
    once rather than executing eleven separate statements. panel_page then
    shares this same snapshot with both desktop and mobile navigation.
    """
    try:
        con = db.connect()
        row = con.execute("""
            SELECT
              (SELECT COUNT(*) FROM businesses WHERE status='pending') businesses,
              (SELECT COUNT(*) FROM reviews WHERE status='pending') reviews,
              (SELECT COUNT(*) FROM questions WHERE status='pending') qa,
              (SELECT COUNT(*) FROM reports WHERE status='open') reports,
              (SELECT COUNT(*) FROM claims WHERE status='pending') claims,
              (SELECT COUNT(*) FROM edits WHERE status='pending') edits,
              (SELECT COUNT(*) FROM subscriptions WHERE status='pending') subscriptions,
              (SELECT COUNT(*) FROM messages WHERE status='new') messages,
              (SELECT COUNT(*) FROM bookings WHERE status='new') bookings,
              (SELECT COUNT(*) FROM chat_threads WHERE admin_read_to <
                 (SELECT COALESCE(MAX(id),0) FROM chat_messages)) chats,
              (SELECT COUNT(*) FROM tickets WHERE status='open') tickets
        """).fetchone()
        con.close()
        return {
            "/panel/businesses": row["businesses"],
            "/panel/reviews": row["reviews"],
            "/panel/qa": row["qa"],
            "/panel/reports": row["reports"],
            "/panel/claims": row["claims"],
            "/panel/edits": row["edits"],
            "/panel/subscriptions": row["subscriptions"],
            "/panel/messages": row["messages"],
            "/panel/bookings": row["bookings"],
            "/panel/chats": row["chats"],
            "/panel/tickets": row["tickets"],
        }
    except Exception:
        return {}


# v93: global search / command palette for the admin panel. The section index
# (OWNER_NAV) is embedded as JSON and filtered client-side; typing also offers
# a "search businesses" jump. Inserted as a value so the JS braces stay literal.
CMDK_JS = r"""
(function(){
  var NAV = window.__PANEL_NAV__ || [];
  // v117/M1: panel navigation is cookie-authenticated; the palette never
  // needs (or propagates) the raw key anymore.
  var TOKEN = '';
  var root = document.querySelector('[data-cmdk-root]');
  if(!root) return;
  var input = root.querySelector('input');
  var list = root.querySelector('.cmdk-list');
  function esc(s){return String(s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function svg(i){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><use href="#i-'+i+'"/></svg>';}
  function render(){
    var term = input.value.trim();
    var rows = NAV.filter(function(n){return !term || n.t.indexOf(term)>-1;});
    var html = rows.slice(0,9).map(function(n){
      return '<a class="cmdk-item" href="'+n.h+'">'+svg(n.i)+'<span>'+esc(n.t)+'</span></a>';
    }).join('');
    if(term){
      html += '<a class="cmdk-item cmdk-action" href="/panel/businesses?q='+encodeURIComponent(term)+'">'+svg('search')+'<span>جست‌وجوی کسب‌وکار: «'+esc(term)+'»</span></a>';
    }
    list.innerHTML = html || '<div class="cmdk-empty">چیزی پیدا نشد</div>';
  }
  function open(){ root.hidden=false; input.value=''; render(); setTimeout(function(){input.focus();},0); }
  function close(){ root.hidden=true; }
  document.addEventListener('keydown', function(e){
    if((e.ctrlKey||e.metaKey) && (e.key||'').toLowerCase()==='k'){ e.preventDefault(); if(root.hidden){open();}else{close();} }
    else if(e.key==='Escape'){ close(); }
    else if(e.key==='Enter' && !root.hidden){ var f=list.querySelector('a'); if(f){ location.href=f.getAttribute('href'); } }
  });
  document.addEventListener('click', function(e){
    if(e.target.closest('[data-cmdk]')){ e.preventDefault(); open(); }
    else if(e.target===root){ close(); }
  });
  input.addEventListener('input', render);
  render();
})();
"""


PANEL_UX_JS = """
(function(){
  // v117/M4 - select-all chips: data-check-all="form:<id>"
  document.addEventListener('change', function(e){
    var t = e.target.closest('[data-check-all]');
    if(!t) return;
    var spec = t.getAttribute('data-check-all').split(':');
    if(spec[0] !== 'form') return;
    var form = document.getElementById(spec[1]);
    if(!form) return;
    var boxes = form.querySelectorAll('input[name="ids"]');
    for(var i=0;i<boxes.length;i++){ boxes[i].checked = t.querySelector('input').checked; }
  });

  // Mobile Panel Drawer open/close — the admin panel's ONE menu.
  function panelDrawerToggle(open){
    var drawer = document.getElementById('panel-drawer');
    if(!drawer) return;
    drawer.hidden = !open;
    document.body.classList.toggle('panel-drawer-open', open);
    var nt = document.querySelector('body.page-admin [data-nav-toggle]');
    if(nt) nt.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  // v134: on admin pages the header hamburger opens the SAME drawer (app.js
  // deliberately leaves it alone there — see initHeader).
  var adminToggle = document.querySelector('body.page-admin [data-nav-toggle]');
  if(adminToggle) adminToggle.setAttribute('aria-controls', 'panel-drawer');

  document.addEventListener('click', function(e){
    if(e.target.closest('[data-panel-drawer-open]')){ panelDrawerToggle(true); return; }
    if(e.target.closest('[data-panel-drawer-close]')){ panelDrawerToggle(false); return; }
    var nt = e.target.closest('[data-nav-toggle]');
    if(nt && document.body.classList.contains('page-admin')){
      var drawer = document.getElementById('panel-drawer');
      panelDrawerToggle(drawer ? drawer.hidden : false);
      return;
    }
    var drawer = document.getElementById('panel-drawer');
    if(drawer && !drawer.hidden && e.target === drawer){ panelDrawerToggle(false); }
  });

  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape'){
      var drawer = document.getElementById('panel-drawer');
      if(drawer && !drawer.hidden){ panelDrawerToggle(false); }
    }
  });

  // Category live filter in admin panel
  document.addEventListener('input', function(e){
    var inEl = e.target.closest('[data-panel-cat-search]');
    if(!inEl) return;
    var q = inEl.value.trim().toLowerCase().replace(/[\u064A]/g, '\u06CC').replace(/[\u0643]/g, '\u06A9');
    var tbl = document.querySelector('[data-panel-cat-table]');
    if(!tbl) return;
    var rows = tbl.querySelectorAll('tbody tr');
    for(var i=0; i<rows.length; i++){
      var rowText = rows[i].textContent.toLowerCase().replace(/[\u064A]/g, '\u06CC').replace(/[\u0643]/g, '\u06A9');
      rows[i].hidden = q && !rowText.includes(q);
    }
  });
  var tls = document.querySelectorAll('form.dir-toolbar');
  for(var f=0; f<tls.length; f++){
    var form = tls[f];
    if(!form.querySelector('.dir-row')) continue;
    form.setAttribute('data-foldable', '1');
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'btn btn-glass btn-sm filters-toggle';
    b.setAttribute('aria-expanded', 'false');
    b.innerHTML = '\u2699\uFE0F <span>\u0641\u06CC\u0644\u062A\u0631\u0647\u0627</span>';
    b.addEventListener('click', function(){
      var open = this.parentNode.classList.toggle('is-open');
      this.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    form.insertBefore(b, form.firstChild);
  }
})();
"""

def panel_page(s, title, subtitle, content, active, token, extra_head="", extra_js="",
               counts=None):
    # v117/M1: panel pages declare noindex at the HTML level too (the response
    # also carries X-Robots-Tag from app.send).
    extra_head = ('<meta name="robots" content="noindex, nofollow">\n'
                  + (extra_head or ""))
    counts = _panel_counts() if counts is None else counts
    groups = []
    for gname, gitems in OWNER_NAV_GROUPS:
        links = ""
        for h, t, i in gitems:
            n = counts.get(h, 0)
            pill = f'<span class="nav-count">{fa(n)}</span>' if n else ""
            cur = ' aria-current="page"' if h == active else ""
            links += (f'<a href="{h}"{cur}>'
                      f'{icon(i)}<span>{t}</span>{pill}</a>')
        groups.append(f'<div class="panel-nav-group">'
                      f'<span class="panel-nav-title">{esc(gname)}</span>{links}</div>')
    items = "".join(groups)
    # v184: db.stats() اینجا بلااستفاده بود و در هر صفحهٔ پنل ۱۵ COUNT اضافه
    # اجرا می‌کرد؛ داشبورد آمار خودش را فقط همان‌جا می‌خواند.
    todo_n = sum(counts.values())
    badge = ""
    if todo_n:
        badge = (f'<a href="/panel/moderation" class="badge badge-warn" style="text-decoration:none">{icon("bell")}'
                 f'<span>{fa(todo_n)} کار در انتظار</span></a>')
    cmdk_btn = (f'<button class="btn btn-glass btn-sm" type="button" data-cmdk '
                f'aria-haspopup="dialog">{icon("search")}<span>جست‌وجو</span>'
                f'<kbd class="cmdk-kbd">Ctrl+K</kbd></button>')
    nav_index = json_embed([{"h": h, "t": t, "i": i} for h, t, i in OWNER_NAV])

    # Mobile Quick Horizontal Bar
    mob_quick_links = [
        ("/panel", "داشبورد", "dashboard"),
        ("/panel/businesses", "کسب‌وکارها", "store"),
        ("/panel/reviews", "نظرات", "message"),
        ("/panel/orders", "سفارش‌ها", "cart"),
        ("/panel/messages", "پیام‌ها", "mail"),
        ("/panel/tickets", "تیکت‌ها", "help"),
        ("/panel/settings", "تنظیمات", "settings"),
    ]
    mob_quick_html = "".join(
        f'<a class="chip{" is-active" if h == active else ""}" href="{h}">{icon(i)}<span>{t}</span></a>'
        for h, t, i in mob_quick_links
    )

    body = f'''
<div class="container-wide panel-layout">
  <aside class="panel-side glass">
    <div class="panel-side-head">
      <span class="stat-icon">{icon("shield")}</span>
      <div><strong>پنل مدیریت دست گیر</strong><small class="text-muted">دسترسی کامل مدیر</small></div>
    </div>
    <nav class="panel-nav" aria-label="ناوبری پنل">{items}</nav>
    <hr class="divider">
    <a class="panel-nav-extra" href="/" target="_blank" rel="noopener"
       style="display:flex;align-items:center;gap:11px;padding:11px 13px;border-radius:var(--radius-md);font-size:var(--fs-sm);font-weight:600;min-height:46px;color:var(--color-primary)">
      {icon("external")}<span>مشاهدهٔ سایت اصلی</span></a>
  </aside>
  <div class="panel-main-content">
    <header class="panel-head">
      <div class="between">
        <div>
          <h1>{esc(title)}</h1>
          <p>{esc(subtitle)}</p>
        </div>
        <div class="cluster" style="align-items:center">
          <button class="btn btn-primary btn-sm show-mobile" type="button" data-panel-drawer-open aria-label="منوی بخش‌های پنل">
            {icon("menu")}<span>بخش‌های پنل</span>
          </button>
          {cmdk_btn}
          {badge}
        </div>
      </div>
      <div class="panel-mob-quick-bar show-mobile mt-sm">
        {mob_quick_html}
      </div>
    </header>
    {content}
  </div>
</div>

<div class="panel-drawer-backdrop" id="panel-drawer" hidden role="dialog" aria-modal="true" aria-label="منوی بخش‌های پنل مدیریت">
  <div class="panel-drawer-box glass">
    <div class="panel-drawer-head">
      <div style="display:flex;align-items:center;gap:10px">
        <span class="stat-icon">{icon("shield")}</span>
        <div><strong>بخش‌های پنل مدیریت</strong><small class="text-muted">انتخاب بخش دلخواه</small></div>
      </div>
      <button class="btn-icon" type="button" data-panel-drawer-close aria-label="بستن منو">{icon("x")}</button>
    </div>
    <div class="panel-drawer-body">
      <nav class="panel-nav" aria-label="ناوبری موبایل پنل">{items}</nav>
      <hr class="divider">
      <a class="btn btn-outline btn-block mt-sm" href="/" target="_blank" rel="noopener">
        {icon("external")}<span>مشاهدهٔ سایت اصلی</span>
      </a>
    </div>
  </div>
</div>

<div class="cmdk" hidden data-cmdk-root role="dialog" aria-modal="true" aria-label="جست‌وجوی سراسری پنل">
  <div class="cmdk-box">
    <input type="search" placeholder="پرش به بخش یا جست‌وجوی کسب‌وکار…" aria-label="جست‌وجو در پنل">
    <div class="cmdk-list"></div>
  </div>
</div>
<script>window.__PANEL_NAV__={nav_index};</script>
<script>{PANEL_UX_JS}</script>
<script>{CMDK_JS}</script>'''
    return page(s, title, body, active="", token=token, cats=[],
                body_class="page-panel page-admin", show_chrome=True,
                extra_head=extra_head, extra_js=extra_js,
                asset_profile="panel", panel_counts=counts)


def flash(kind, text):
    ic = {"ok": "check-circle", "err": "x-circle", "warn": "alert", "info": "info"}[kind]
    cls = {"ok": "success", "err": "error", "warn": "warn", "info": "info"}[kind]
    return f'<div class="alert alert-{cls} mb-lg">{icon(ic)}<span>{esc(text)}</span></div>'


# ==========================================================================
#  FEATURE GATE UI
#  Research is unambiguous: a locked feature that stays VISIBLE but blurred
#  converts far better than one that is hidden, because the owner can see
#  exactly what they are missing. Never hide — blur, label, and price it.
# ==========================================================================
def lock_overlay(key, compact=False):
    """The padlock layer that sits on top of a blurred feature."""
    label = db.FEATURE_LABELS.get(key, key)
    why = db.FEATURE_WHY.get(key, "")
    if compact:
        return (f'<span class="lock-chip">{icon("lock")}'
                f'<span>نیازمند ارتقا</span></span>')
    return f'''<div class="lock-veil">
  <div class="lock-card">
    <span class="lock-badge">{icon("lock")}</span>
    <strong>{esc(label)}</strong>
    <p>{esc(why)}</p>
    <a class="btn btn-primary btn-sm" href="/pricing">
      {icon("zap")}<span>باز کردن این قابلیت</span></a>
    <a class="lock-help" href="/contact">یا با پشتیبانی تماس بگیرید</a>
  </div>
</div>'''


def gated(key, biz_id, content, compact=False, hide=False):
    """Wrap a feature. If the shop has it, the content renders untouched.

    If not, the same markup renders blurred and inert behind a lock. Note the
    content is still generated — that is deliberate, so the owner sees the
    real shape of what they are buying rather than a generic placeholder.
    Anything genuinely secret must be gated server-side with db.can() as well.
    """
    if db.can(biz_id, key):
        return content
    if hide:
        return ""
    return (f'<div class="gated" data-locked="{esc(key)}">'
            f'<div class="gated-inner" aria-hidden="true" inert>{content}</div>'
            f'{lock_overlay(key, compact)}</div>')


def lock_note(key, biz_id):
    """A one-line inline notice, for places where a full veil is too heavy."""
    if db.can(biz_id, key):
        return ""
    label = db.FEATURE_LABELS.get(key, key)
    return (f'<div class="alert alert-warn mb-lg">{icon("lock")}<span>'
            f'<strong>{esc(label)}</strong> در پلن فعلی شما قفل است. '
            f'<a href="/pricing">ارتقا دهید</a> یا با پشتیبانی تماس بگیرید.'
            f'</span></div>')


def founder_ribbon():
    """Scarcity that is true: the count comes straight from the table."""
    left = db.founders_left()
    if left <= 0:
        return ""
    total = db.founder_settings()["limit"]
    return (f'<div class="founder-ribbon">{icon("award")}'
            f'<span><strong>{fa(left)} جای باقی‌مانده</strong> از '
            f'{fa(total)} عضو بنیان‌گذار — این افراد امکانات ویژه را '
            f'<strong>همیشه رایگان</strong> دارند.</span></div>')


# ==========================================================================
#  SUPPORT WIDGET
#  Appears after a delay, opens on FAQ first. Answering the common question
#  costs nothing; a human reply costs you time, so the FAQ goes first and
#  direct contact sits underneath it.
# ==========================================================================
DEFAULT_FAQ = [
    ("ثبت کسب‌وکار در دست گیر چقدر هزینه دارد؟",
     "ثبت کاملاً رایگان است و رایگان می‌ماند. اگر بعداً امکانات بیشتری خواستید، "
     "پلن‌های اختیاری هست، ولی برای دیده‌شدن لازم نیست."),
    ("چطور کسب‌وکارم را ثبت کنم؟",
     "روی «ثبت کسب‌وکار» بزنید و فرم را پر کنید. با شمارهٔ موبایل وارد می‌شوید و "
     "رمز عبور لازم نیست. پس از تأیید مدیر، صفحهٔ شما منتشر می‌شود."),
    ("کسب‌وکار من از قبل اینجا هست، چطور تحویلش بگیرم؟",
     "وارد شوید و از بخش «تصاحب کسب‌وکار» درخواست بدهید. اگر شمارهٔ ثبت‌شده با "
     "شمارهٔ شما یکی باشد، بلافاصله به حساب شما وصل می‌شود."),
    ("چطور عکس و محصولاتم را اضافه کنم؟",
     "پس از ورود، از «کسب‌وکارهای من» گالری و کاتالوگ را باز کنید. عکس‌ها را "
     "می‌توانید مستقیم از گوشی بارگذاری کنید."),
    ("اطلاعاتم را چطور ویرایش کنم؟",
     "از پنل خودتان، بخش «کسب‌وکارهای من» و بعد «ویرایش». تغییرات بلافاصله "
     "روی سایت اعمال می‌شود."),
    ("نظر منفی یا اطلاعات غلط دیدم، چه کنم؟",
     "پایین صفحهٔ هر کسب‌وکار دکمهٔ «گزارش مشکل» هست. گزارش شما مستقیم به "
     "مدیر سایت می‌رسد و رسیدگی می‌شود."),
]


# ==========================================================================
#  BOTTOM NAVIGATION  (mobile only)
#
#  Research is unambiguous: a hamburger in the TOP corner is the worst place
#  to put navigation on a phone. Roughly half of people drive a phone with
#  one thumb, and the top corners are the "ow" zone that needs a grip change.
#  A fixed bottom bar with 3-5 destinations is the pattern every app these
#  shopkeepers already use -- Instagram, Digikala, Snapp -- relies on.
#
#  Five slots, chosen from what this site is actually for: find a shop, find
#  it on a map, read city news, and manage your own listing. News permanently
#  replaces the old price slot (v75), even if the admin later enables prices.
# ==========================================================================
BOTTOM_NAV = [
    ("/",           "خانه",       "home"),
    ("/businesses", "کسب‌وکارها", "grid"),
    ("/map",        "نقشه",       "map"),
    # v83: the 4th slot is context-aware (built in bottom_nav): a shopkeeper
    # gets «پنل دکان», everyone else keeps «اخبار شهر». The 5th is personal.
]


def bottom_nav(s, active, token=""):
    """The thumb-zone navigation. Always rendered, revealed by CSS only
    below 860px, so a desktop visitor never sees it."""
    owner = ctx_owner()
    cust = ctx_customer()
    # v83: BOTH trailing slots are context-aware. A shopkeeper (an owner who
    # actually has a business) gets «پنل دکان» (all business features) in the
    # 4th slot and «پنل من» (their personal account) in the 5th. Everyone else
    # keeps «اخبار شهر» in the 4th and their own most-needed page in the 5th.
    badge = ""
    # v86: the 4th thumb-zone slot is ALWAYS «پنل دکان» now — «اخبار شهر» no
    # longer sits in the bottom nav (city news stays reachable from the
    # homepage). This also drops a per-page businesses_of() query.
    fourth = ("/my", "پنل دکان", "store")
    if token:
        last = ("/panel", "پنل", "settings")   # v117/M1: keyless
    elif owner:
        last = ("/me", "پنل من", "user")
    elif cust:
        # A signed-in customer's most-needed destination is their
        # conversations. Before this, the slot read "ورود" and the account
        # chip was hide-mobile, so the only path back to a chat was the
        # top-corner hamburger -- chats effectively vanished on a phone.
        last = ("/me/chats", "گفتگوها", "message")
        try:
            n = db.chat_unread_customer(cust["id"])
        except Exception:
            n = 0
        if n:
            badge = ('<span class="fav-dot">'
                     + (str(n) if n < 100 else "۹۹+") + '</span>')
    else:
        last = ("/login", "ورود", "user")

    items = ""
    for h, t, i in BOTTOM_NAV + [fourth, last]:
        base = h.split("?")[0]
        on = ""
        if base == active or (base != "/" and active.startswith(base)):
            on = ' aria-current="page"'
        b = badge if h == last[0] else ""
        items += ('<a href="' + esc(h) + '"' + on + '>' + icon(i)
                  + '<span>' + esc(t) + '</span>' + b + '</a>')
    return ('<nav class="bottom-nav" aria-label="ناوبری اصلی موبایل">'
            + items + '</nav>')


def nav_tiles(items, token=""):
    """Render a navigation list as tap-friendly quick tiles so a dashboard
    becomes a full hub -- the shopkeeper/admin reaches EVERY section straight
    from the panel page without ever opening the drawer menu."""
    tiles = ""
    for row in items:
        h, t, i = row[0], row[1], row[2]
        href = h    # v117/M1: cookie-authenticated panel — keyless tiles
        tiles += (f'<a class="panel-nav-tile" href="{esc(href)}">{icon(i)}'
                  f'<span>{esc(t)}</span>{icon("chevron-left")}</a>')
    return f'<div class="panel-nav-grid">{tiles}</div>'


def call_bar(b):
    """Sticky call bar removed per user specification."""
    return ""


def support_widget(s):
    """FAQ plus one accountable support channel: a trackable ticket."""
    if s.get("support_widget", "1") != "1": return ""
    try: delay = int(s.get("support_delay", "60"))
    except Exception: delay = 60
    faq = "".join(f'''<details class="sup-faq"{" open" if i == 0 else ""}>
      <summary>{esc(q)}</summary><p>{esc(a)}</p></details>''' for i,(q,a) in enumerate(DEFAULT_FAQ))
    target = "/my/tickets" if ctx_owner() else "/login?next=/my/tickets"
    return f'''<button class="sup-fab" type="button" data-sup-open aria-expanded="false"
      aria-controls="support-panel" hidden aria-label="تیکت پشتیبانی">{icon("message")}
      <span class="sup-fab-label">پشتیبانی</span><span class="sup-fab-dot" aria-hidden="true"></span></button>
<div class="sup-panel" id="support-panel" role="dialog" aria-modal="false"
     aria-label="پشتیبانی تیکتی" hidden data-sup-delay="{delay}">
  <div class="sup-head"><div><strong>{icon("shield")} پشتیبانی دست گیر</strong>
    <small>درخواست شما شماره و تاریخچهٔ قابل پیگیری دارد</small></div>
    <button class="btn-icon" type="button" data-sup-close aria-label="بستن">{icon("x")}</button></div>
  <div class="sup-body">{faq}<hr class="divider">
    <div class="ticket-only-cta"><span class="stat-icon">{icon("message")}</span>
      <div><strong>پاسخ را گم نمی‌کنید</strong><p>تیکت بسازید و پاسخ مدیر و وضعیت رسیدگی را در حساب ببینید.</p></div></div>
    <a class="btn btn-primary btn-block" href="{esc(target)}">{icon("send")}<span>ثبت و پیگیری تیکت</span></a>
    <p class="text-xs text-muted mt-sm">تماس پشتیبانی فقط از مسیر تیکت انجام می‌شود.</p>
  </div></div>'''


# ------------------------------------------------------------------ v213 assistant
ASSIST_QUICK = [
    ("search", "جست‌وجوی کسب‌وکار", "داروخانه شبانه‌روزی"),
    ("compass", "نزدیک من", "نزدیک من"),
    ("plus", "ثبت کسب‌وکار", "چطور کسب‌وکارم را ثبت کنم؟"),
    ("cart", "سفارش‌های من", "سفارش‌های من"),
    ("calendar", "نوبت‌های من", "نوبت‌های من"),
    ("wallet", "تعرفه‌ها", "تعرفه‌ها و اشتراک‌ها"),
]


def assistant_widget(s):
    """v213.2: floating LIVE BAR (not a second FAB). Sits above the bottom
    nav / beside the support button, shows a rotating live hint and opens the
    full chat page /assistant. A one-time invite bubble (assist.js) asks the
    visitor whether they want to talk to the assistant."""
    if s.get("ai_enabled", "1") != "1":
        return ""
    return f'''<a class="ai-bar" href="/assistant" data-ai-bar hidden aria-label="گفت‌وگو با دستیار هوشمند دست گیر">
  <span class="ai-bar-orb" aria-hidden="true">{icon("sparkles")}</span>
  <span class="ai-bar-text"><strong>دستیار هوشمند دست گیر</strong>
    <span class="ai-bar-live" data-ai-live>آنلاین · بپرسید: «داروخانهٔ شبانه‌روزی نزدیک من؟»</span></span>
  <span class="ai-bar-cta">{icon("chevron-left")}</span></a>
<div class="ai-invite" data-ai-invite hidden role="dialog" aria-label="دعوت به گفت‌وگو با دستیار">
  <button class="btn-icon ai-invite-x" type="button" data-ai-invite-close aria-label="بستن">{icon("x")}</button>
  <div class="ai-invite-head">{icon("sparkles")}<strong>می‌خواهید با دستیار هوشمند حرف بزنید؟</strong></div>
  <p>هرچه دربارهٔ کسب‌وکارها، محصولات، نوبت و سفارش در دست گیر بپرسید، همین‌جا جواب می‌دهم.</p>
  <div class="cluster">
    <a class="btn btn-primary btn-sm" href="/assistant">{icon("message")}<span>بله، شروع کن</span></a>
    <button class="btn btn-ghost btn-sm" type="button" data-ai-invite-close>بعداً</button>
  </div>
</div>'''


def assistant_page(s, status):
    """v215: full-screen chat — hero header, role-aware starter cards, message
    stream, sticky composer. Owners get shop-coaching starters, customers get
    shopping starters, guests get discovery starters."""
    c = ctx_customer(); o = ctx_owner()
    is_owner = bool(o and db.owner_has_business(o["id"]))
    name = (c or {}).get("name") or (o or {}).get("name") or ""
    hello = f"سلام{'، ' + esc(name) if name else ''}!"
    if is_owner:
        role = "دکان‌دار"; lead = "برای رشد دکان‌تان همراهتان هستم: سفارش‌ها، نوبت‌ها، نظرات، عکس و کاتالوگ، اشتراک و دیده‌شدن بیشتر."
        starters = [("cart", "سفارش‌های امروزم", "سفارش‌های جدید دکانم چه وضعیتی دارند؟"),
                    ("trending", "چطور بیشتر دیده شوم؟", "چطور کسب‌وکارم در دست گیر بیشتر دیده شود؟"),
                    ("image", "عکس و کاتالوگ", "چطور عکس و محصولات دکانم را کامل کنم؟"),
                    ("message", "پاسخ به نظرات", "به یک نظر منفی چطور جواب بدهم؟"),
                    ("calendar", "نوبت‌دهی", "چطور نوبت‌دهی آنلاین را برای دکانم فعال کنم؟"),
                    ("wallet", "اشتراک من", "پلن فعلی من چیست و پلن حرفه‌ای چه فرقی دارد؟")]
    elif c:
        role = "مشتری"; lead = "هر چه دربارهٔ مغازه‌ها، محصولات، نوبت و سفارش‌هایتان می‌خواهید بپرسید."
        starters = [("search", "پیدا کردن مغازه", "یک داروخانهٔ شبانه‌روزی نزدیک من پیدا کن"),
                    ("cart", "سفارش‌های من", "آخرین سفارشم در چه وضعیتی است؟"),
                    ("calendar", "نوبت‌های من", "نوبت‌های من را نشان بده"),
                    ("heart", "علاقه‌مندی‌ها", "کسب‌وکارهایی که ذخیره کرده‌ام کدام‌اند؟"),
                    ("tag", "پیشنهاد و تخفیف", "امروز چه پیشنهاد و تخفیفی هست؟"),
                    ("plus", "ثبت کسب‌وکار", "خودم مغازه دارم؛ چطور ثبتش کنم؟")]
    else:
        role = "مهمان"; lead = "راهنمای محلی شما: مغازه‌ها، خدمات، قیمت‌ها، نزدیک من و ثبت رایگان کسب‌وکار."
        starters = [("search", "پیدا کردن مغازه", "یک کافهٔ خوب که الان باز باشد"),
                    ("compass", "نزدیک من", "کسب‌وکارهای باز نزدیک من"),
                    ("shopping", "محصول و قیمت", "قیمت نان سنگک در شهر چند است؟"),
                    ("plus", "ثبت رایگان کسب‌وکار", "ثبت مغازه‌ام چقدر طول می‌کشد و چه چیزهایی لازم است؟"),
                    ("wallet", "تعرفه‌ها", "فرق پلن حرفه‌ای و ویژه چیست؟"),
                    ("help", "دست گیر چیست؟", "دست گیر چه کارهایی برای من می‌کند؟")]
    # v274: استایل لوکس سوئیچ مغز و بنر پایان سهمیه — هم‌زبان با توکن‌های سایت
    # (شیشه + گرادیان برند/زعفرانی). بیرون از f-string تا نیاز به دوبرابرکردن آکولاد نباشد.
    ai_mode_css = """<style>
.ai-mode{display:flex;gap:6px;max-width:620px;margin:2px auto;padding:6px;border-radius:999px;
  background:color-mix(in srgb, var(--color-primary) 8%, transparent);
  border:1px solid var(--glass-hairline);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px)}
.ai-mode-btn{flex:1;display:flex;align-items:center;justify-content:center;gap:10px;border:0;background:transparent;
  color:var(--color-text-muted);border-radius:999px;padding:10px 14px;font:inherit;cursor:pointer;
  transition:background .25s ease,color .25s ease,box-shadow .25s ease}
.ai-mode-btn>svg{width:17px;height:17px;flex:0 0 auto}
.ai-mode-btn span{display:flex;flex-direction:column;align-items:flex-start;line-height:1.3}
.ai-mode-btn strong{font-size:13px;font-weight:700}
.ai-mode-btn small{font-size:11px;opacity:.78}
.ai-mode-btn[aria-selected="true"]{background:linear-gradient(135deg,var(--color-primary),color-mix(in srgb,var(--color-primary) 62%,var(--color-accent)));
  color:#fff;box-shadow:0 8px 22px color-mix(in srgb,var(--color-primary) 38%,transparent)}
.ai-quotaend{max-width:620px;margin:6px auto;padding:12px 16px;border-radius:var(--radius-lg);font-size:13px;line-height:1.9;
  display:flex;gap:10px;align-items:flex-start;
  background:linear-gradient(135deg,color-mix(in srgb,var(--color-accent) 15%,transparent),transparent);
  border:1px solid color-mix(in srgb,var(--color-accent) 38%,transparent)}
.ai-quotaend>svg{width:18px;height:18px;flex:0 0 auto;color:var(--color-accent);margin-top:2px}
</style>"""
    cards = "".join(f'<button class="ai-start" type="button" data-ai-q="{esc(q)}">{icon(i)}<strong>{esc(t)}</strong><small>{esc(q)}</small></button>' for i, t, q in starters)
    body = f'''<div class="ai-page" data-ai-page>
  <header class="ai-hero">
    <span class="ai-bar-orb ai-hero-orb">{icon("sparkles")}</span>
    <div><h1>{hello} من دستیار هوشمند دست گیر هستم</h1><p>{lead}</p>
      <small class="ai-hero-meta"><span class="ai-dot"></span>آنلاین · حالت {role} · <span data-ai-quota>{esc(status.get("tier_label",""))} · {fa(status.get("remaining",0))} از {fa(status.get("quota",0))} پاسخ هوشمند امروز</span></small></div>
  </header>
  {ai_mode_css}
  <div class="ai-mode" data-ai-mode role="tablist" aria-label="انتخاب مغز پاسخ‌دهنده">
    <button type="button" class="ai-mode-btn" data-ai-mode-val="auto" role="tab" aria-selected="true">{icon("sparkles")}<span><strong>هوش اختصاصی دست گیر</strong><small>سهمیهٔ روزانه پلن شما</small></span></button>
    <button type="button" class="ai-mode-btn" data-ai-mode-val="offline" role="tab" aria-selected="false">{icon("zap")}<span><strong>هوش آفلاین</strong><small>نامحدود و رایگان</small></span></button>
  </div>
  <div class="ai-quotaend" data-ai-quotaend hidden>{icon("zap")}<span>سهمیهٔ پاسخ هوشمند امروز شما تمام شد؛ از این پس به «هوش آفلاین» (نامحدود و رایگان) متصل هستید.</span></div>
  <div class="ai-starts" data-ai-starts>{cards}</div>
  <div class="ai-log" data-ai-log aria-live="polite"></div>
  <form class="ai-composer" data-ai-form autocomplete="off">
    <label class="sr-only" for="ai-input">پیام به دستیار</label>
    <textarea class="input" id="ai-input" name="text" maxlength="400" rows="1" placeholder="بنویسید… مثلاً: نانوایی سنگکی باز نزدیک میدان" required></textarea>
    <button class="btn btn-primary ai-send" type="submit" aria-label="ارسال">{icon("send")}</button>
  </form>
  <p class="ai-foot text-xs text-muted">فقط دربارهٔ دست گیر پاسخ می‌دهم؛ هیچ کاری را به‌جای شما انجام نمی‌دهم و رمز یا اطلاعات بانکی نمی‌پرسم.</p>
</div>'''
    return page(s, "دستیار هوشمند", body, active="/assistant", body_class="page-assistant",
                desc="گفت‌وگو با دستیار هوشمند دست گیر: راهنمای مشتریان و دکان‌داران — کسب‌وکارها، محصولات، سفارش، نوبت، ثبت و رشد کسب‌وکار.")


# ------------------------------------------------------------------ v142 push card
def notif_push_card(role):
    """The "notification on your phone" card rendered on the notification
    settings pages of both roles. Server-side state is only a starting hint;
    notifpush.js?v154 reads /api/push/config and drives the buttons."""
    try:
        import fcm
        ready = fcm.configured()
    except Exception:
        ready = False
    if not ready:
        status = "اعلان گوشی هنوز فعال نشده است."
    else:
        status = "وضعیت در حال بررسی است…"
    # v154: هیچ توضیحی دربارهٔ «چرا نمی‌شود» — فقط فایده، وضعیت کوتاه، دکمه.
    return f'''<div class="card glass card-pad mb-lg" id="push-card" data-push-role="{esc(role)}">
  <h2 class="card-title mb-lg">{icon("bell")} اعلان روی گوشی</h2>
  <p class="text-sm text-muted mb-md">اعلان‌های مهم را روی گوشی هم دریافت کنید —
    حتی وقتی صفحه باز نیست.</p>
  <div class="alert alert-info mb-md" id="push-status" role="status">{icon("info")}
    <span>{esc(status)}</span></div>
  <div class="cluster">
    <button type="button" class="btn btn-primary" id="push-enable"
            style="display:none">{icon("bell")}<span>فعال‌سازی اعلان گوشی</span></button>
    <button type="button" class="btn btn-glass" id="push-disable"
            style="display:none">{icon("x")}<span>غیرفعال‌سازی</span></button>
  </div>
</div>'''
