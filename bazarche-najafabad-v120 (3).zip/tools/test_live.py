#!/usr/bin/env python3
"""v120: end-to-end test of live content updates (no manual refresh)."""
import asyncio, sys
sys.path.insert(0, "/home/user/repo-369/server")
from playwright.async_api import async_playwright
import db

def change_content():
    """Simulate an admin edit: change hero_title and touch a business name."""
    s = db.get_settings()
    cur = s.get("hero_title", "").replace("\n", " ")[:40]
    nxt = "LIVE-" + str(int(__import__("time").time()))[-6:]
    db.set_setting("hero_title", nxt)
    # a business rename also changes the fingerprint
    row = db.businesses(order="newest", limit=1)
    return cur, nxt, (row[0]["name"] if row else None)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={"width": 390, "height": 844})
        navs = []
        pg.on("framenavigated", lambda f: navs.append(f.url))
        await pg.goto("http://localhost:8080/", wait_until="networkidle")
        await pg.wait_for_timeout(2500)   # let the first poll fetch the etag

        before = await pg.evaluate("() => document.querySelector('.h-hero h1').textContent")
        print("BEFORE:", before[:60])

        cur, nxt, biz = change_content()
        print("CHANGED TO:", nxt, "| biz:", biz)

        # wait for the next poll (interval 15s) + swap
        await pg.wait_for_timeout(19000)
        after = await pg.evaluate("() => document.querySelector('.h-hero h1').textContent")
        print("AFTER :", after[:60])
        print("SWAPPED:", nxt in after)
        print("NAVIGATIONS:", len(navs), navs)
        print("HREF SAME:", await pg.evaluate("location.href"))
        # restore
        db.set_setting("hero_title", cur)
        await b.close()

asyncio.run(main())
