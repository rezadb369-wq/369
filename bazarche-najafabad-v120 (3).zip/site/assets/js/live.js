/* Bazarche — live content updates (v120)
   ==================================================================
   محتوای عمومی سایت بدون رفرش به‌روز می‌شود:
     • هر ۱۰ ثانیه (فقط وقتی تب دیده می‌شود) مسیر فعلی را با
       If-None-Match نزد سرور بازبینی می‌کند (/api/live).
     • ۳۰۴ = چیزی عوض نشده (یک درخواست تقریباً رایگان).
     • ۲۰۰ با ETag تازه = محتوا عوض شده → صفحه دوباره از شبکه گرفته
       می‌شود (no-store، سرویس‌ورکر HTML را کش نمی‌کند) و فقط <main>
       جایگزین می‌شود — بدون رفرش، بدون از دست رفتن اسکرول، بی‌صدا.
     • پینگ بین‌تبی: هر POST موفق یا submit در هر تب، تب‌های دیگر را
       فوراً به بازبینی می‌اندازد — «ثبت شد → همهٔ تب‌ها همین الان نو».
   امنیت/ادب:
     • مسیرهای خصوصی (پنل/حساب/گفت‌وگو/سبد) سواپ نمی‌شوند.
     • وقتی کاربر در حال تایپ است (اینپوت فوکوس) یا تب مخفی است،
       نه نظرسنجی انجام می‌شود نه جابه‌جایی.
     • /map و هر صفحهٔ دارای main[data-live-skip] جابه‌جا نمی‌شوند.
   ================================================================== */
const LIVE_POLL = 10000;
const SKIP_PATHS = ['/map', '/panel', '/my', '/me', '/login', '/logout',
                    '/t/', '/cart', '/order', '/subscribe', '/api'];
const PING_KEY = 'bz-live-ping';

(function () {
  const main = document.querySelector('main');
  if (main && main.hasAttribute('data-live-skip')) return;
  if (SKIP_PATHS.some(p => location.pathname === p || location.pathname.startsWith(p))) return;

  let etag = null;

  function postPing() {
    try { localStorage.setItem(PING_KEY, String(Date.now())); } catch (_) {}
  }

  /* هر POST موفقِ همین تب، تب‌های دیگر را بیدار می‌کند (رویداد storage) */
  try {
    const _fetch = window.fetch;
    window.fetch = function (input, init) {
      const method = ((init && init.method) || (input && input.method) || 'GET').toUpperCase();
      return _fetch.apply(this, arguments).then((r) => {
        if (method === 'POST' && r.ok) setTimeout(postPing, 0);
        return r;
      });
    };
    document.addEventListener('submit', (e) => {
      const m = (e.target && e.target.method || 'get').toUpperCase();
      if (m === 'POST') setTimeout(postPing, 0);
    }, true);
    window.addEventListener('storage', (e) => {
      if (e.key === PING_KEY) poll();
    });
  } catch (_) {}

  async function poll() {
    if (document.hidden) return;               // تب خواب = بدون شبکه
    try {
      const r = await fetch('/api/live?p=' + encodeURIComponent(location.pathname + location.search), {
        headers: etag ? { 'If-None-Match': etag } : {},
        cache: 'no-store'
      });
      if (r.status === 304) { etag = r.headers.get('ETag') || etag; return; }
      if (r.status !== 200) return;
      const j = await r.json();
      if (!j || !j.etag) return;
      if (j.etag === etag) return;             // همان نسخه — کاری نیست
      etag = j.etag;
      await refresh();
    } catch (_) { /* قطعی شبکه — دفعهٔ بعد */ }
  }

  async function refresh() {
    // وسط تایپ/تعامل کاربر صفحه را نچرخانیم
    const ae = document.activeElement;
    if (ae && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA' ||
               ae.isContentEditable)) return;
    try {
      const r = await fetch(location.pathname + location.search, { cache: 'no-store' });
      if (!r.ok) return;
      const html = await r.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const mOld = document.querySelector('main');
      const mNew = doc.querySelector('main');
      if (!mOld || !mNew || mOld.hasAttribute('data-live-skip')) return;
      if (mOld.innerHTML === mNew.innerHTML) return;   // هیچ تفاوتی — بی‌صدا
      const scroll = window.scrollY;
      mOld.innerHTML = mNew.innerHTML;
      window.scrollTo(0, Math.min(scroll, document.body.scrollHeight));
      window.dispatchEvent(new CustomEvent('bz:content-updated'));
    } catch (_) {}
  }

  setTimeout(poll, 1200);                        // ETag اولیه را زودتر بگیر
  setInterval(poll, LIVE_POLL);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) poll();                // برگشت به تب = بازبینی فوری
  });
})();
