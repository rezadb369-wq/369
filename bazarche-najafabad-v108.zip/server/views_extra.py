# -*- coding: utf-8 -*-
"""
Public pages for the "desirability" features (v31):
  • برترین‌های شهر (top lists)  — /lists , /list/{slug}
  • پیشنهاد روز / فلش‌سیل (flash deals)  — /deals
"""
import urllib.parse
import db
from ui import (icon, stars, fa, fa_group, esc, page, breadcrumb, empty_state,
                section_head, flash, biz_card, json_embed)


def _msg(q):
    q = q or {}
    if q.get("ok"):
        return flash("ok", q["ok"][0])
    if q.get("err"):
        return flash("err", q["err"][0])
    return ""


def _rank_badge(rank):
    if rank == 1:
        return '<span class="rank-badge rank-1">۱</span>'
    if rank == 2:
        return '<span class="rank-badge rank-2">۲</span>'
    if rank == 3:
        return '<span class="rank-badge rank-3">۳</span>'
    return f'<span class="rank-badge">{fa(rank)}</span>'


# ------------------------------------------------------------------ lists
def lists_page(s, token=""):
    cats = db.category_tree()
    rows = db.toplists(active_only=True)
    tiles = "".join(f'''<a class="cat-tile tilt reveal-3d" data-tilt="6" data-delay="{i*40}"
      href="/list/{esc(t['slug'])}">
      <span class="sheen" aria-hidden="true"></span>
      <span class="art layer-2">{icon("trophy")}</span>
      <span class="name layer-1">{esc(t["title"])}</span>
      <span class="blurb">{esc(t.get("descr") or "")}</span>
      <span class="count layer-1">{fa(len(db.toplist_businesses(t)))} کسب‌وکار</span></a>'''
        for i, t in enumerate(rows))
    body = f'''<div class="container-wide">
  {breadcrumb(("برترین‌های شهر", None))}
  <header class="page-hero">
    <span class="eyebrow">{icon("trophy")}<span>به‌انتخاب بازارچه</span></span>
    <h1>برترین‌های نجف‌آباد</h1>
    <p>بهترین کسب‌وکارهای شهر در هر زمینه — بر اساس امتیاز واقعی مشتریان و انتخاب بازارچه.</p>
  </header></div>
<section class="section-sm"><div class="container-wide">
  <div class="cat-grid">{tiles or empty_state("trophy", "هنوز لیستی ساخته نشده",
    "به‌زودی برترین‌های شهر اینجا معرفی می‌شوند.")}</div>
</div></section>'''
    return page(s, "برترین‌های شهر", body, "", token=token, cats=cats)


def list_page(s, slug, token=""):
    t = db.toplist(slug=slug)
    if not t or not t.get("active"):
        return None
    cats = db.category_tree()
    rows = db.toplist_businesses(t)
    ci = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}

    cards = "".join(f'''<div class="rank-item reveal" data-delay="{i*60}">
  {_rank_badge(r["rank"])}
  <div class="rank-card" style="flex:1">{biz_card(r, ci, 0)}</div>
</div>''' for i, r in enumerate(rows))
    body = f'''<div class="container-wide">
  {breadcrumb(("برترین‌های شهر", "/lists"), (t["title"], None))}
  <header class="page-hero"><h1>{icon("trophy")} {esc(t["title"])}</h1>
    <p>{esc(t.get("descr") or "")}</p></header></div>
<section class="section-sm"><div class="container-wide">
  <div class="rank-list">{cards or empty_state("trophy", "هنوز کسب‌وکاری در این لیست نیست",
    "به‌زودی پر می‌شود.")}</div>
</div></section>'''
    return page(s, t["title"], body, "", desc=t.get("descr"), token=token, cats=cats)


# ------------------------------------------------------------------ deals
def deals_page(s, token=""):
    cats = db.category_tree()
    rows = db.flashdeals(active_only=True)
    cards = "".join(f'''<article class="deal-card card glass card-pad reveal" data-delay="{i*50}">
  <div class="between" style="align-items:flex-start">
    <div>
      <span class="badge badge-accent">{icon("zap")}<span>{fa(d["percent"])}٪ تخفیف</span></span>
      <h3 class="card-title mt-sm">{esc(d["title"])}</h3>
      <p class="text-sm text-muted mt-sm">{esc(d.get("descr") or "")}</p>
    </div>
    <span class="deal-countdown" data-countdown="{esc(d['ends'])}" aria-label="زمان باقی‌مانده"></span>
  </div>
  <div class="between mt-md">
    <a class="btn btn-primary btn-sm" href="/b/{esc(d['bizslug'])}">{icon("store")}<span>{esc(d["bizname"])}</span></a>
    <small class="text-muted">تا <span class="nums">{esc(d["ends"][5:16])}</span></small>
  </div>
</article>''' for i, d in enumerate(rows))
    body = f'''<div class="container-wide">
  {breadcrumb(("پیشنهادهای روز", None))}
  <header class="page-hero">
    <span class="eyebrow">{icon("zap")}<span>فقط برای مدت محدود</span></span>
    <h1>پیشنهادهای روز</h1>
    <p>تخفیف‌های لحظه‌ای کسب‌وکارهای شهر — قبل از تمام‌شدن وقت، استفاده کنید.</p>
  </header></div>
<section class="section-sm"><div class="container-wide">
  <div class="grid grid-2">{cards or empty_state("zap", "الان پیشنهادی فعال نیست",
    "به‌زودی تخفیف‌های جدید می‌آید — دوباره سر بزنید.")}</div>
</div></section>
<script type="module" src="/assets/js/countdown.js?v108"></script>'''
    return page(s, "پیشنهادهای روز", body, "", token=token, cats=cats)


# ==========================================================================
#  CITIES  (v37) — nationwide: pick province → city (Divar-style)
# ==========================================================================
def cities_page(s, token=""):
    cats = db.category_tree()
    provs = db.provinces()
    tabs = "".join(f'<button class="tab" type="button" data-prov-tab="{esc(p)}" '
                   f'role="tab" aria-selected="false">{esc(p)}</button>' for p in provs)
    panels = "".join(
        f'''<div class="city-panel" data-prov-panel="{esc(p)}" hidden>
      <div class="city-grid">{"".join(
          f'<a class="city-chip" href="/businesses?city={urllib.parse.quote(c["name"])}">'
          f'<span>{esc(c["name"])}</span>'
          + ('<small class="badge badge-info">مرکز</small>' if c["is_capital"] else '')
          + '</a>' for c in db.cities_in(p))}
      </div></div>''' for p in provs)
    body = f'''<div class="container-wide">
  {breadcrumb(("انتخاب شهر", None))}
  <header class="page-hero"><h1>شهر خود را انتخاب کنید</h1>
    <p>کسب‌وکارهای سراسر ایران — استان و شهرتان را برگزینید.</p></header>
  <div class="card glass card-pad">
    <div class="city-tabs" role="tablist">{tabs}</div>
    {panels}
  </div>
</div>
<script>
  document.querySelectorAll('[data-prov-tab]').forEach(function(t){{
    t.addEventListener('click', function(){{
      document.querySelectorAll('[data-prov-tab]').forEach(function(x){{
        x.setAttribute('aria-selected','false'); x.classList.remove('is-active'); }});
      t.setAttribute('aria-selected','true'); t.classList.add('is-active');
      document.querySelectorAll('[data-prov-panel]').forEach(function(pn){{ pn.hidden = true; }});
      var pn = document.querySelector('[data-prov-panel="' + t.dataset.provTab + '"]');
      if (pn) pn.hidden = false;
    }});
  }});
  var first = document.querySelector('[data-prov-tab]');
  if (first) first.click();
</script>'''
    return page(s, "انتخاب شهر", body, "", token=token, cats=cats)
