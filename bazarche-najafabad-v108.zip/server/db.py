# -*- coding: utf-8 -*-
"""
SQLite data layer for Bazarche Najafabad.
Standard library only — no pip install needed (works inside Pydroid 3).
"""

import os
import re
import sys
import json
import sqlite3
import threading
import math
import time
import secrets
import hashlib
import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "..", "data")
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "bazarche.db")

SCHEMA = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS categories (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  slug      TEXT UNIQUE NOT NULL,
  name      TEXT NOT NULL,
  icon      TEXT NOT NULL DEFAULT 'store',
  blurb     TEXT DEFAULT '',
  sort      INTEGER DEFAULT 0,
  active    INTEGER DEFAULT 1,
  parent    TEXT DEFAULT ''          -- slug of the parent category, '' = top level
);
-- NOTE: the index on `parent` is created in init(), after the ALTER TABLE that
-- adds the column to databases made before this version. Creating it here would
-- run against the old table on those installs and abort the whole script.

CREATE TABLE IF NOT EXISTS businesses (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  slug        TEXT UNIQUE NOT NULL,
  name        TEXT NOT NULL,
  cat_slug    TEXT NOT NULL,
  descr       TEXT DEFAULT '',
  phone       TEXT DEFAULT '',
  whatsapp    TEXT DEFAULT '',
  address     TEXT DEFAULT '',
  lat         REAL,
  lng         REAL,
  hours       TEXT DEFAULT '',          -- JSON: {"sat":[["09:00","22:00"]], ...}
  tags        TEXT DEFAULT '',          -- comma separated
  images      TEXT DEFAULT '[]',        -- JSON list of asset paths
  featured    INTEGER DEFAULT 0,
  verified    INTEGER DEFAULT 0,
  status      TEXT DEFAULT 'published', -- published | pending | hidden
  views       INTEGER DEFAULT 0,
  instagram   TEXT DEFAULT '',
  telegram    TEXT DEFAULT '',
  website     TEXT DEFAULT '',
  booking_on  INTEGER DEFAULT 0,
  owner_id    INTEGER REFERENCES owners(id) ON DELETE SET NULL,
  created     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS reviews (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id   INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  author   TEXT NOT NULL,
  rating   INTEGER NOT NULL,
  body     TEXT NOT NULL,
  reply    TEXT DEFAULT '',
  image    TEXT DEFAULT '',          -- optional single photo (public path)
  status   TEXT DEFAULT 'pending',   -- pending | approved | rejected
  created  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS bookings (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id    INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name      TEXT NOT NULL,
  phone     TEXT NOT NULL,
  date      TEXT NOT NULL,
  time      TEXT NOT NULL,
  note      TEXT DEFAULT '',
  status    TEXT DEFAULT 'new',       -- new | confirmed | done | cancelled
  created   TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS coupons (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id    INTEGER REFERENCES businesses(id) ON DELETE CASCADE,
  code      TEXT NOT NULL,
  title     TEXT NOT NULL,
  percent   INTEGER DEFAULT 0,
  expires   TEXT DEFAULT '',
  active    INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS posts (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  slug      TEXT UNIQUE NOT NULL,
  title     TEXT NOT NULL,
  excerpt   TEXT DEFAULT '',
  body      TEXT DEFAULT '',
  cover     TEXT DEFAULT '',
  status    TEXT DEFAULT 'published',
  created   TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS messages (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  name      TEXT, email TEXT, subject TEXT, body TEXT,
  kind      TEXT DEFAULT 'contact',   -- contact | order
  meta      TEXT DEFAULT '{}',
  status    TEXT DEFAULT 'new',
  created   TEXT DEFAULT (datetime('now'))
);

-- ================================================================
--  TICKETS  --  a real two-way conversation with the admin
--
--  The contact form was one-way: a shopkeeper sent a message into a void
--  and had no way to see a reply or continue the thread. A ticket is the
--  same message plus (a) a status the person can watch, (b) replies from
--  both sides in order, and (c) a private token so somebody who is not
--  logged in can still follow their own thread.
-- ================================================================
CREATE TABLE IF NOT EXISTS tickets (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id  INTEGER REFERENCES owners(id) ON DELETE SET NULL,
  biz_id    INTEGER REFERENCES businesses(id) ON DELETE SET NULL,
  name      TEXT DEFAULT '',
  phone     TEXT DEFAULT '',
  subject   TEXT DEFAULT '',
  topic     TEXT DEFAULT 'other',   -- payment|unlock|bug|edit|other
  status    TEXT DEFAULT 'open',    -- open|answered|waiting|closed
  priority  TEXT DEFAULT 'normal',  -- low|normal|high
  token     TEXT DEFAULT '',
  unread_admin INTEGER DEFAULT 1,   -- badge for the admin panel
  unread_user  INTEGER DEFAULT 0,   -- badge for the shopkeeper
  created   TEXT DEFAULT (datetime('now')),
  updated   TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ticket_owner ON tickets(owner_id);
CREATE INDEX IF NOT EXISTS idx_ticket_token ON tickets(token);
CREATE INDEX IF NOT EXISTS idx_ticket_status ON tickets(status);

CREATE TABLE IF NOT EXISTS ticket_msgs (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  side      TEXT DEFAULT 'user',    -- user | admin
  body      TEXT NOT NULL,
  created   TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_tmsg_ticket ON ticket_msgs(ticket_id);

CREATE TABLE IF NOT EXISTS ticket_attachments (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  msg_id        INTEGER NOT NULL REFERENCES ticket_msgs(id) ON DELETE CASCADE,
  stored_name   TEXT NOT NULL UNIQUE,
  original_name TEXT NOT NULL,
  mime          TEXT NOT NULL,
  size          INTEGER NOT NULL,
  kind          TEXT NOT NULL,
  created       TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_tatt_msg ON ticket_attachments(msg_id);

CREATE TABLE IF NOT EXISTS pages (
  slug      TEXT PRIMARY KEY,         -- about | rules
  title     TEXT,
  body      TEXT
);

CREATE TABLE IF NOT EXISTS audit (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  action    TEXT, detail TEXT,
  created   TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS owners (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  phone      TEXT UNIQUE NOT NULL,
  name       TEXT DEFAULT '',
  username   TEXT DEFAULT '',
  pass_hash  TEXT DEFAULT '',
  status     TEXT DEFAULT 'active',      -- active | blocked
  created    TEXT DEFAULT (datetime('now')),
  last_login TEXT
);

CREATE TABLE IF NOT EXISTS customers (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  phone      TEXT UNIQUE NOT NULL,
  name       TEXT DEFAULT '',
  username   TEXT DEFAULT '',
  pass_hash  TEXT DEFAULT '',
  status     TEXT DEFAULT 'active',     -- active | blocked
  created    TEXT DEFAULT (datetime('now')),
  last_login TEXT
);

CREATE TABLE IF NOT EXISTS customer_sessions (
  token       TEXT PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  expires     REAL NOT NULL,
  created     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS chat_threads (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id           INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  customer_id      INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  subject          TEXT DEFAULT '',
  status           TEXT DEFAULT 'open',      -- open | closed
  last_activity    REAL NOT NULL,
  customer_read_to INTEGER DEFAULT 0,
  owner_read_to    INTEGER DEFAULT 0,
  admin_read_to    INTEGER DEFAULT 0,
  created          TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS chat_messages (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id INTEGER NOT NULL REFERENCES chat_threads(id) ON DELETE CASCADE,
  sender    TEXT NOT NULL,                -- customer | owner | admin
  body      TEXT NOT NULL DEFAULT '',
  created   TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS chat_attachments (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  message_id    INTEGER NOT NULL REFERENCES chat_messages(id) ON DELETE CASCADE,
  stored_name   TEXT NOT NULL UNIQUE,
  original_name TEXT NOT NULL,
  mime          TEXT NOT NULL,
  size          INTEGER NOT NULL,
  kind          TEXT NOT NULL,             -- image | file
  created       TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS orders (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id      INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  name        TEXT NOT NULL,
  phone       TEXT NOT NULL,
  address     TEXT DEFAULT '',
  note        TEXT DEFAULT '',
  total       INTEGER DEFAULT 0,
  status      TEXT DEFAULT 'new',         -- new | confirmed | ready | done | cancelled
  share_phone INTEGER DEFAULT 0,
  cancel_requested INTEGER DEFAULT 0,
  cancel_reason TEXT DEFAULT '',
  cancel_requested_at TEXT DEFAULT '',
  cancel_decided_at TEXT DEFAULT '',
  created     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS order_items (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  item_id  INTEGER REFERENCES items(id) ON DELETE SET NULL,
  title    TEXT NOT NULL,
  price    INTEGER DEFAULT 0,
  qty      INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS favorites (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  biz_id      INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS toplists (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  slug    TEXT UNIQUE NOT NULL,
  title   TEXT NOT NULL,
  descr   TEXT DEFAULT '',
  kind    TEXT DEFAULT 'manual',   -- manual | auto_rating | auto_views | auto_featured | auto_new
  items   TEXT DEFAULT '[]',       -- JSON list of biz ids (manual lists)
  limit_n INTEGER DEFAULT 10,
  sort    INTEGER DEFAULT 0,
  active  INTEGER DEFAULT 1,
  created TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS flashdeals (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id   INTEGER REFERENCES businesses(id) ON DELETE CASCADE,
  title    TEXT NOT NULL,
  descr    TEXT DEFAULT '',
  percent  INTEGER DEFAULT 0,      -- discount percentage
  starts   TEXT DEFAULT '',
  ends     TEXT NOT NULL,          -- ISO datetime; filtered by active window
  active   INTEGER DEFAULT 1,
  created  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS points (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  amount      INTEGER NOT NULL,
  reason      TEXT DEFAULT '',
  created     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS redemptions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id  INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  code         TEXT UNIQUE NOT NULL,
  percent      INTEGER DEFAULT 10,
  points_spent INTEGER DEFAULT 0,
  used         INTEGER DEFAULT 0,
  created      TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS stories (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id  INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  image   TEXT NOT NULL,
  kind    TEXT DEFAULT 'image',       -- image | video
  caption TEXT DEFAULT '',
  created TEXT DEFAULT (datetime('now')),
  expires REAL NOT NULL,
  duration REAL DEFAULT 0             -- v101: seconds, so the viewer plays the full clip
);

-- v100: anonymised story view counter. Stores ONLY the story id and a
-- timestamp — no customer id, no phone, no IP — so the owner sees aggregate
-- counts/rate while viewers stay truly anonymous (data-minimisation).
CREATE TABLE IF NOT EXISTS story_views (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  story_id INTEGER NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
  ts       REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sview_story ON story_views(story_id, ts);

-- v105: soft-delete recycle bin. When a story/item/review/report is deleted we
-- snapshot the full row here for 7 days (trackable + restorable in the panels),
-- then hard-purge. Public pages never see deleted rows because they are removed
-- from the live tables; the panels read this bin instead.
CREATE TABLE IF NOT EXISTS trash (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  entity     TEXT NOT NULL,          -- story | item | review | report
  ref_id     INTEGER NOT NULL,
  biz_id     INTEGER DEFAULT 0,
  title      TEXT DEFAULT '',
  payload    TEXT NOT NULL,          -- JSON of the full original row
  deleted_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_trash_recent ON trash(deleted_at);

CREATE TABLE IF NOT EXISTS cities (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  province TEXT NOT NULL,
  name     TEXT NOT NULL,
  is_capital INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS follows (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  biz_id      INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  created     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS notifications (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  kind        TEXT DEFAULT 'info',     -- order | chat | reply | info
  text        TEXT NOT NULL,
  link        TEXT DEFAULT '',
  read        INTEGER DEFAULT 0,
  created     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS price_history (   -- v68: torob-style price memory
  item_id  INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
  price    INTEGER NOT NULL,
  ts       REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ph_item ON price_history(item_id, ts);

CREATE TABLE IF NOT EXISTS price_alerts (    -- v68: "tell me when it's cheaper"
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  group_key   TEXT NOT NULL,
  title       TEXT DEFAULT '',
  created     TEXT DEFAULT (datetime('now')),
  UNIQUE(customer_id, group_key)
);

CREATE TABLE IF NOT EXISTS otp (
  phone   TEXT PRIMARY KEY,
  code    TEXT NOT NULL,
  tries   INTEGER DEFAULT 0,
  expires REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token    TEXT PRIMARY KEY,
  owner_id INTEGER NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
  expires  REAL NOT NULL,
  created  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS admin_sessions (
  token    TEXT PRIMARY KEY,
  expires  REAL NOT NULL,
  created  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS claims (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id   INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  owner_id INTEGER NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
  note     TEXT DEFAULT '',
  status   TEXT DEFAULT 'pending',       -- pending | approved | rejected
  created  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS events (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id  INTEGER REFERENCES businesses(id) ON DELETE CASCADE,
  kind    TEXT NOT NULL,                 -- view | phone | whatsapp | route | share
  day     TEXT NOT NULL,                 -- YYYY-MM-DD
  n       INTEGER DEFAULT 0,
  UNIQUE(biz_id, kind, day)
);

CREATE TABLE IF NOT EXISTS items (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id     INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  kind       TEXT DEFAULT 'product',   -- product | service | custom
  title      TEXT NOT NULL,
  descr      TEXT DEFAULT '',
  price      INTEGER DEFAULT 0,        -- toman; 0 when not applicable
  price_type TEXT DEFAULT 'fixed',     -- fixed | from | call | free
  unit       TEXT DEFAULT '',          -- «هر عدد», «هر متر», «هر جلسه»…
  duration   TEXT DEFAULT '',          -- services: «۴۵ دقیقه»
  image      TEXT DEFAULT '',          -- cover (kept for compatibility)
  images     TEXT DEFAULT '[]',        -- JSON list, first item is the cover
  old_price  INTEGER DEFAULT 0,        -- crossed-out "was" price
  stock      INTEGER DEFAULT -1,       -- -1 = not tracked
  code       TEXT DEFAULT '',          -- SKU / internal code
  min_order  TEXT DEFAULT '',          -- «حداقل ۲ عدد»
  options    TEXT DEFAULT '',          -- «کوچک، متوسط، بزرگ»
  note       TEXT DEFAULT '',          -- delivery / preparation note
  tags       TEXT DEFAULT '',
  available  INTEGER DEFAULT 1,
  featured   INTEGER DEFAULT 0,
  sort       INTEGER DEFAULT 0,
  created    TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS inquiries (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id   INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  item_id  INTEGER REFERENCES items(id) ON DELETE SET NULL,
  name     TEXT NOT NULL,
  phone    TEXT DEFAULT '',            -- v65: optional — customer contact is private
  body     TEXT DEFAULT '',
  budget   TEXT DEFAULT '',
  quote    TEXT DEFAULT '',
  status   TEXT DEFAULT 'new',         -- new | quoted | won | lost
  created  TEXT DEFAULT (datetime('now'))
);

-- ================================================================
--  چانه‌زنی — haggling, the way an Iranian bazaar actually works
--
--  Basalam has a "گفت‌وگو" thread; nobody has a structured OFFER with a
--  price on it that the shopkeeper accepts, refuses, or answers with a
--  counter-price. That back-and-forth is how business is really done in a
--  bazaar, and it is exactly the part every Iranian marketplace app drops.
--
--  One row per round. `parent` chains a counter-offer to the offer it
--  answers, so the whole negotiation is one readable thread and neither
--  side can quietly rewrite an earlier number.
-- ================================================================
CREATE TABLE IF NOT EXISTS haggles (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id    INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  item_id   INTEGER REFERENCES items(id) ON DELETE CASCADE,
  parent    INTEGER REFERENCES haggles(id) ON DELETE CASCADE,
  side      TEXT DEFAULT 'buyer',      -- buyer | seller
  name      TEXT DEFAULT '',
  phone     TEXT DEFAULT '',
  offer     INTEGER DEFAULT 0,         -- the price being proposed, toman
  qty       INTEGER DEFAULT 1,
  note      TEXT DEFAULT '',
  status    TEXT DEFAULT 'open',       -- open | countered | accepted | declined | expired
  token     TEXT DEFAULT '',           -- lets a buyer follow their own thread
  expires   TEXT DEFAULT '',
  created   TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_haggle_biz ON haggles(biz_id);
CREATE INDEX IF NOT EXISTS idx_haggle_item ON haggles(item_id);
CREATE INDEX IF NOT EXISTS idx_haggle_token ON haggles(token);

-- ================================================================
--  WORLD-CLASS DIRECTORY FEATURES (v3)
-- ================================================================

-- Public Q&A on a business page (Google Business Profile pattern)
CREATE TABLE IF NOT EXISTS questions (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id    INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  asker     TEXT NOT NULL,
  body      TEXT NOT NULL,
  answer    TEXT DEFAULT '',
  answered_by TEXT DEFAULT '',            -- owner | admin
  status    TEXT DEFAULT 'pending',       -- pending | published | rejected
  helpful   INTEGER DEFAULT 0,
  created   TEXT DEFAULT (datetime('now')),
  answered  TEXT
);

-- Abuse / wrong-info reports (Yelp + Google pattern)
CREATE TABLE IF NOT EXISTS reports (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  kind      TEXT NOT NULL DEFAULT 'business',  -- business | review | item | question
  target_id INTEGER NOT NULL,
  biz_id    INTEGER REFERENCES businesses(id) ON DELETE CASCADE,
  reason    TEXT NOT NULL,
  body      TEXT DEFAULT '',
  reporter  TEXT DEFAULT '',
  status    TEXT DEFAULT 'open',          -- open | resolved | dismissed
  note      TEXT DEFAULT '',
  created   TEXT DEFAULT (datetime('now'))
);

-- Custom badges the admin defines and pins onto businesses
CREATE TABLE IF NOT EXISTS badges (
  id     INTEGER PRIMARY KEY AUTOINCREMENT,
  slug   TEXT UNIQUE NOT NULL,
  name   TEXT NOT NULL,
  icon   TEXT DEFAULT 'award',
  color  TEXT DEFAULT '#059669',
  descr  TEXT DEFAULT '',
  sort   INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS biz_badges (
  biz_id   INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  badge_id INTEGER NOT NULL REFERENCES badges(id) ON DELETE CASCADE,
  granted  TEXT DEFAULT (datetime('now')),
  PRIMARY KEY (biz_id, badge_id)
);

-- Subscription plans + real subscriptions with expiry
CREATE TABLE IF NOT EXISTS plans (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  slug      TEXT UNIQUE NOT NULL,
  name      TEXT NOT NULL,
  tagline   TEXT DEFAULT '',
  price     INTEGER DEFAULT 0,            -- toman per period
  months    INTEGER DEFAULT 12,
  featured_slots INTEGER DEFAULT 0,       -- how many featured placements
  max_items INTEGER DEFAULT 10,
  max_photos INTEGER DEFAULT 6,
  perks     TEXT DEFAULT '',              -- newline separated
  features  TEXT DEFAULT '',              -- comma separated feature keys, or * for all
  badge_slug TEXT DEFAULT '',
  sort      INTEGER DEFAULT 0,
  active    INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS subscriptions (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id    INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  plan_slug TEXT NOT NULL,
  status    TEXT DEFAULT 'pending',       -- pending | active | expired | cancelled
  starts    TEXT,
  expires   TEXT,
  amount    INTEGER DEFAULT 0,
  method    TEXT DEFAULT 'manual',        -- manual | card | gateway
  ref       TEXT DEFAULT '',              -- payment reference the owner typed
  note      TEXT DEFAULT '',
  created   TEXT DEFAULT (datetime('now'))
);

-- Advertising slots with real impression/click counters
CREATE TABLE IF NOT EXISTS ads (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  title     TEXT NOT NULL,
  body      TEXT DEFAULT '',
  image     TEXT DEFAULT '',
  url       TEXT DEFAULT '',
  slot      TEXT DEFAULT 'home',          -- home | directory | business | sidebar
  biz_id    INTEGER REFERENCES businesses(id) ON DELETE SET NULL,
  starts    TEXT DEFAULT '',
  ends      TEXT DEFAULT '',
  active    INTEGER DEFAULT 1,
  weight    INTEGER DEFAULT 1,
  views     INTEGER DEFAULT 0,
  clicks    INTEGER DEFAULT 0,
  created   TEXT DEFAULT (datetime('now'))
);

-- City events (city-directory pattern)
CREATE TABLE IF NOT EXISTS cityevents (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  slug      TEXT UNIQUE NOT NULL,
  title     TEXT NOT NULL,
  descr     TEXT DEFAULT '',
  place     TEXT DEFAULT '',
  date      TEXT DEFAULT '',              -- YYYY-MM-DD
  time      TEXT DEFAULT '',
  biz_id    INTEGER REFERENCES businesses(id) ON DELETE SET NULL,
  image     TEXT DEFAULT '',
  status    TEXT DEFAULT 'published',
  created   TEXT DEFAULT (datetime('now'))
);

-- Multi-criteria review scores (Directorist / Tripadvisor pattern)
CREATE TABLE IF NOT EXISTS review_scores (
  review_id INTEGER NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
  criterion TEXT NOT NULL,                -- quality | price | speed | behaviour
  score     INTEGER NOT NULL,
  PRIMARY KEY (review_id, criterion)
);

-- Owner-requested profile edits that need admin approval
CREATE TABLE IF NOT EXISTS edits (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id   INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  owner_id INTEGER REFERENCES owners(id) ON DELETE SET NULL,
  payload  TEXT NOT NULL,                 -- JSON of changed fields
  status   TEXT DEFAULT 'pending',        -- pending | approved | rejected
  created  TEXT DEFAULT (datetime('now'))
);

-- Saved searches -> alerts when a matching business appears
CREATE TABLE IF NOT EXISTS alerts (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  phone    TEXT NOT NULL,
  term     TEXT DEFAULT '',
  cat_slug TEXT DEFAULT '',
  active   INTEGER DEFAULT 1,
  sent     INTEGER DEFAULT 0,
  created  TEXT DEFAULT (datetime('now'))
);

-- Rate limiting bucket (spam protection on every public form)
-- Features the admin unlocked by hand for one shop. This is the "key" the
-- site owner holds: a shopkeeper pays outside the site, and the admin flips
-- the switch here. Separate from plans so a manual grant survives a plan
-- change and can never be revoked by an expiry job.
CREATE TABLE IF NOT EXISTS biz_features (
  biz_id   INTEGER PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  unlocked TEXT DEFAULT '',          -- comma separated feature keys
  updated  TEXT DEFAULT (datetime('now'))
);

-- What people typed into the search box, and whether they found anything.
-- Zero-result searches are the single most useful signal a city directory
-- has: they say exactly which trade is missing from the site.
CREATE TABLE IF NOT EXISTS searches (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  term    TEXT NOT NULL,
  norm    TEXT NOT NULL,             -- normalised, for grouping
  cat     TEXT DEFAULT '',
  results INTEGER DEFAULT 0,
  day     TEXT NOT NULL,
  created TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_search_norm ON searches(norm);
CREATE INDEX IF NOT EXISTS idx_search_day ON searches(day);

CREATE TABLE IF NOT EXISTS ratelimit (
  bucket  TEXT PRIMARY KEY,
  n       INTEGER DEFAULT 0,
  window  REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_q_biz ON questions(biz_id, status);
CREATE INDEX IF NOT EXISTS idx_rep_status ON reports(status);
CREATE INDEX IF NOT EXISTS idx_sub_biz ON subscriptions(biz_id, status);
CREATE INDEX IF NOT EXISTS idx_ads_slot ON ads(slot, active);
CREATE INDEX IF NOT EXISTS idx_ev_date ON cityevents(date);
CREATE INDEX IF NOT EXISTS idx_edit_status ON edits(status);
CREATE INDEX IF NOT EXISTS idx_item_biz ON items(biz_id);
CREATE INDEX IF NOT EXISTS idx_inq_biz ON inquiries(biz_id);
CREATE INDEX IF NOT EXISTS idx_sess_owner ON sessions(owner_id);
CREATE INDEX IF NOT EXISTS idx_claim_biz ON claims(biz_id);
CREATE INDEX IF NOT EXISTS idx_ev_biz ON events(biz_id, day);
CREATE INDEX IF NOT EXISTS idx_biz_cat ON businesses(cat_slug);
CREATE INDEX IF NOT EXISTS idx_biz_status ON businesses(status);
CREATE INDEX IF NOT EXISTS idx_rev_biz ON reviews(biz_id);
CREATE INDEX IF NOT EXISTS idx_book_biz ON bookings(biz_id);
CREATE INDEX IF NOT EXISTS idx_chat_thread_activity ON chat_threads(last_activity DESC);
CREATE INDEX IF NOT EXISTS idx_chat_msg_thread ON chat_messages(thread_id, id);
CREATE INDEX IF NOT EXISTS idx_chat_att_message ON chat_attachments(message_id);
"""

# ------------------------------------------------------------------ defaults
DEFAULT_SETTINGS = {
    # Public address of the site. Empty means "work it out from the request",
    # which is right while it runs on a phone. Fill it in from the panel once
    # a real domain exists, and every QR code, sitemap entry and share link
    # switches to it at once instead of baking in 127.0.0.1.
    "site_url":      "",
    "site_name":     "بازارچه ایران",
    "tagline":       "راهنمای زندهٔ کسب‌وکارهای ایران",
    "description":   "بازارچه؛ فهرست کامل کسب‌وکارهای سراسر ایران با نقشه، ساعت کاری، نظرات واقعی و امکان سفارش آنلاین.",
    "phone":         "۰۲۱-۹۱۰۰۰۰۰۰",
    "phone_raw":     "02191000000",
    "email":         "info@bazarche.ir",
    "address":       "تهران، خیابان ولیعصر",
    "instagram":     "https://instagram.com/",
    "telegram":      "https://t.me/",
    "whatsapp":      "https://wa.me/989130000000",

    "hero_title":    "هر آنچه ایران دارد،\nیک جست‌وجو با شما فاصله دارد",
    "hero_lead":     "راهنمای زندهٔ کسب‌وکارهای سراسر ایران؛ با انتخاب شهر، ساعت کاری لحظه‌ای، نقشهٔ تعاملی، نظرات واقعی و سفارش آنلاین.",
    "hero_cta":      "ثبت رایگان کسب‌وکار",
    "footer_note":   "ساخته‌شده با دقت برای کسب‌وکارهای ایران",

    # v65: the site is a dark green theme now, so the primary colour must be a
    # LIGHT green (brand-400) to keep links, prices and active-nav labels
    # readable on the dark background. The old #047857 (brand-700) was picked
    # for the light "day" theme and is far too dark against #162019.
    # Buttons are unaffected — they use a fixed brand-500→brand-700 gradient.
    "color_primary":    "#2dd4bf",   # v66 Lapis Night: turquoise
    "color_accent":     "#fbbf24",   # v66 Lapis Night: saffron gold
    "color_background": "#faf6ef",
    "color_foreground": "#241c13",

    # map
    "map_provider":   "auto",        # auto | google | osm
    "gmaps_key":      "",
    "map_lat":        "32.6340",
    "map_lng":        "51.3670",
    "map_zoom":       "14",

    # toggles
    "reg_open":          "1",
    "reviews_moderated": "1",
    "booking_enabled":   "1",
    "blog_enabled":      "1",
    "maintenance":       "0",
    "claims_enabled":    "1",
    "catalog_enabled":   "1",
    # v75: product prices and comparison are hidden until the admin explicitly
    # enables them. Subscription-plan prices are a separate admin/business UI.
    "prices_enabled":    "0",
    "price_visibility_v75": "0",   # one-time migration marker
    "site_logo":         "",
    "inquiry_enabled":   "1",
    "owner_login":       "1",

    # SMS (Kavenegar-compatible). Empty key => codes are shown on screen instead.
    "sms_key":           "",
    "sms_sender":        "",
    "sms_template":      "",

    # Telegram notifications (optional free channel for owner alerts).
    # Create a bot with @BotFather, set tg_token, and put your numeric chat id
    # in tg_chat_id (find it via @userinfobot). Empty => disabled.
    "tg_token":          "",
    "tg_chat_id":        "",

    # Housekeeping bookmarks.
    "last_backup_at":    "",   # ISO timestamp of the last manual backup

    # ---- v3 world-class feature toggles
    "haggle_enabled":    "0",    # چانه‌زنی — خاموش به‌صورت پیش‌فرض (مدیر فعال می‌کند)
    "qa_enabled":        "1",    # public questions & answers
    "reports_enabled":   "1",    # abuse / wrong-info reporting
    "compare_enabled":   "1",    # side-by-side comparison
    "nearby_enabled":    "1",    # radius search "near me"
    "events_enabled":    "1",    # city events
    "ads_enabled":       "1",    # advertising slots
    "plans_enabled":     "1",    # real subscriptions
    "alerts_enabled":    "1",    # saved search alerts
    "multicriteria":     "1",    # multi-criteria review scores
    "edit_approval":     "0",    # owner edits need admin approval
    "qa_moderated":      "1",    # questions need approval before showing
    "seo_schema":        "1",    # JSON-LD structured data
    "ratelimit_on":      "1",    # spam protection
    "ratelimit_n":       "8",    # max submissions
    "ratelimit_win":     "600",  # per this many seconds

    # ---- floating support widget
    "support_widget":    "1",
    "support_delay":     "60",   # seconds before it appears

    # ---- founding-member window (the doorstep promise)
    "founder_limit":     "100",   # first N shops keep the generous set free
    "founder_max_items": "10",
    "founder_max_photos": "6",
    "free_max_items":    "3",     # everyone after them
    "free_max_photos":   "3",

    # ---- v31 desirability features (each toggle also lives in /panel/features)
    "lists_enabled":      "1",    # برترین‌های شهر
    "deals_enabled":      "1",    # پیشنهاد روز / فلش‌سیل
    "stories_enabled":    "1",    # استوری ۲۴ ساعته
    "shop_account":       "1",    # حساب مشتری (ورود OTP)
    "orders_enabled":     "1",    # سبد خرید و سفارش آنلاین
    "order_cancel_minutes": "30", # لغو مستقیم؛ بعدش درخواست تأیید دکان‌دار
    "chat_enabled":       "1",    # گفتگوی مشتری و دکان‌دار
    "follow_enabled":     "1",    # دنبال‌کردن کسب‌وکار
    "notif_enabled":      "1",    # مرکز اعلان‌های مشتری

    # ---- payment (manual card transfer works out of the box)
    "pay_method":        "manual",   # manual | zarinpal
    "pay_card":          "",         # card number for manual transfers
    "pay_card_name":     "",         # card holder name
    "zarinpal_merchant": "",
}

def _taxonomy_rows():
    """The two-level category tree, loaded from tools/taxonomy.py.

    Kept in its own module because it is data, not logic — you can read and
    edit the whole tree there without scrolling past SQL. Falls back to the
    original flat list if that file is ever missing, so the site still boots.
    """
    try:
        sys.path.insert(0, os.path.join(HERE, "..", "tools"))
        import taxonomy
        return taxonomy.flatten()
    except Exception:
        return [(s, n, i, b, "", k)
                for k, (s, n, i, b) in enumerate(DEFAULT_CATEGORIES)]


DEFAULT_BADGES = [
    ("verified-shop", "فروشگاه احراز‌شده", "shield",  "#059669",
     "هویت و نشانی این کسب‌وکار توسط بازارچه بررسی شده است."),
    ("top-rated",     "برترین امتیاز",      "award",   "#ea580c",
     "امتیاز بالای ۴٫۵ از ۵ با دست‌کم ۱۰ نظر تأییدشده."),
    ("fast-reply",    "پاسخ‌گوی سریع",      "zap",     "#0284c7",
     "به پیام‌های مشتریان در کمتر از یک روز پاسخ می‌دهد."),
    ("old-shop",      "قدیمی و باسابقه",    "clock",   "#7c3aed",
     "بیش از ده سال سابقهٔ فعالیت در شهر نجف‌آباد."),
    ("family",        "کسب‌وکار خانوادگی",  "users",   "#be185d",
     "توسط یک خانوادهٔ نجف‌آبادی اداره می‌شود."),
]

DEFAULT_PLANS = [
    ("free", "پایه", 0, 12, 0, 3, 3,
     "صفحهٔ اختصاصی کسب‌وکار\nنمایش روی نقشه\nدریافت نظر مشتریان\nساعت کاری زنده", "",
     "برای شروع و معرفی اولیه", ""),
    ("plus", "حرفه‌ای", 1200000, 12, 1, 60, 20,
     "همهٔ امکانات پایه\nنشان «ویژه» و بالاتر بودن در فهرست\nتا ۶۰ محصول یا خدمت\nتا ۲۰ تصویر در گالری\nآمار بازدید و تماس\nپاسخ به نظرات", "verified-shop",
     "مناسب کسب‌وکارهای فعال شهر",
     "gallery,catalog,booking,stats,reply,qa,inquiry,social,featured"),
    ("pro", "ویژهٔ بازارچه", 2900000, 12, 3, 300, 40,
     "همهٔ امکانات حرفه‌ای\nجایگاه ثابت در صفحهٔ نخست\nبنر تبلیغاتی اختصاصی\nمحصولات نامحدود عملی (۳۰۰ مورد)\nپشتیبانی مستقیم", "top-rated",
     "برای برندها و مجموعه‌های بزرگ", "*"),
]

REVIEW_CRITERIA = [
    ("quality",  "کیفیت کار"),
    ("price",    "قیمت منصفانه"),
    ("speed",    "سرعت و به‌موقع بودن"),
    ("behaviour","برخورد و راهنمایی"),
]

REPORT_REASONS = [
    ("closed",   "این کسب‌وکار تعطیل شده است"),
    ("wrong",    "اطلاعات نادرست است (تلفن، نشانی، ساعت)"),
    ("duplicate","تکراری است"),
    ("spam",     "تبلیغ یا محتوای نامناسب"),
    ("notmine",  "بدون اجازهٔ من ثبت شده"),
    ("other",    "دلیل دیگر"),
]

DEFAULT_CATEGORIES = [
    ("restaurant",    "رستوران و غذا",   "restaurant",    "غذای ایرانی، فست‌فود، بیرون‌بر و تالار پذیرایی"),
    ("cafe",          "کافه و قهوه",      "cafe",          "کافی‌شاپ، قهوهٔ تخصصی، صبحانه و دورهمی"),
    ("bakery",        "نانوایی",          "bakery",        "سنگک، بربری، تافتون و نان فانتزی"),
    ("confectionery", "شیرینی و قنادی",   "confectionery", "کیک سفارشی، شیرینی‌تر و خشک، دسر"),
    ("shopping",      "خرید و سوپرمارکت", "shopping",      "هایپرمارکت، خواربار، میوه و تره‌بار"),
    ("clothing",      "پوشاک",            "clothing",      "بوتیک زنانه و مردانه، کفش و کیف"),
    ("jewellery",     "طلا و جواهر",      "jewellery",     "طلافروشی، نقره، ساعت و بدلیجات"),
    ("medical",       "پزشکی و سلامت",    "medical",       "مطب، داروخانه، آزمایشگاه و دندان‌پزشکی"),
    ("auto",          "خودرو و تعمیرگاه", "auto",          "مکانیکی، صافکاری، لوازم یدکی و کارواش"),
    ("realestate",    "املاک",            "realestate",    "خرید، فروش، رهن و اجارهٔ ملک"),
    ("barber",        "آرایش و زیبایی",   "barber",        "سالن زیبایی، پیرایش مردانه، اسپا"),
    ("education",     "آموزش",            "education",     "آموزشگاه زبان، کنکور، هنر و موسیقی"),
    ("mobile",        "موبایل و دیجیتال", "mobile",        "گوشی، لپ‌تاپ، لوازم جانبی و تعمیرات"),
    ("gym",           "ورزش و باشگاه",    "gym",           "بدنسازی، آمادگی جسمانی، رزمی و استخر"),
    ("homeservice",   "خدمات ساختمان",    "homeservice",   "نقاشی، برق‌کاری، لوله‌کشی و کابینت"),
    ("flowers",       "گل و گیاه",        "flowers",       "گل‌فروشی، گیاه آپارتمانی و باغبانی"),
    ("photography",   "عکاسی و فیلم",     "photography",   "آتلیه، عکاسی صنعتی و فیلم‌برداری مراسم"),
]

DEFAULT_PAGES = {
    "about": ("درباره ما",
              "ما یک تیم محلی هستیم که باور داریم کسب‌وکارهای شهرمان لایق دیده‌شدن‌اند — "
              "با اطلاعات دقیق، به‌روز و قابل اعتماد.\n\n"
              "بازارچه نجف‌آباد یک مرجع واحد و راستی‌آزمایی‌شده از همهٔ کسب‌وکارهای شهر است."),
    "rules": ("قوانین و مقررات",
              "استفاده از سایت بازارچه نجف‌آباد به‌منزلهٔ پذیرش قوانین زیر است.\n\n"
              "۱. اطلاعات ثبت‌شده باید دقیق و متعلق به کسب‌وکار واقعی باشد.\n"
              "۲. نظرات باید بر تجربهٔ واقعی مشتری استوار باشد.\n"
              "۳. اطلاعات شخصی کاربران هرگز به اشخاص ثالث فروخته نمی‌شود.\n"
              "۴. بازارچه بستر معرفی است و طرف معاملهٔ بین کاربر و کسب‌وکار نیست."),
}


# ------------------------------------------------------------------ core
class _PersistentCon:
    """Wrapper that makes close() a no-op so a per-thread connection can be
    reused by every query in the request instead of being opened/closed dozens
    of times. All attribute access passes through to the real connection."""
    __slots__ = ("_c",)

    def __init__(self, con):
        self._c = con

    def close(self):  # keep the shared connection alive
        pass

    def __getattr__(self, name):
        return getattr(self._c, name)


_thread_local = threading.local()


def connect():
    """One SQLite connection per thread, reused for the whole request.

    v107 perf: the home page used to open ~67 separate connections (one per
    query), each paying the open+schema+close cost. On the phone that runs the
    server (Pydroid) that overhead is what made the site feel slow. A per-thread
    connection collapses those 67 opens into one; close() is neutralised via
    _PersistentCon so the hundreds of existing `con.close()` calls keep working.
    """
    con = getattr(_thread_local, "con", None)
    if con is None:
        con = sqlite3.connect(DB_PATH, timeout=15, check_same_thread=False)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys = ON")
        _thread_local.con = con
    return _PersistentCon(con)


def init():
    """Create schema and seed defaults. Idempotent."""
    con = connect()
    con.executescript(SCHEMA)

    cur = con.execute("SELECT COUNT(*) c FROM settings")
    if cur.fetchone()["c"] == 0:
        for k, v in DEFAULT_SETTINGS.items():
            con.execute("INSERT INTO settings(key,value) VALUES(?,?)", (k, v))
        # owner access token, generated once
        con.execute("INSERT INTO settings(key,value) VALUES(?,?)",
                    ("owner_token", secrets.token_urlsafe(16)))
        con.execute("INSERT INTO settings(key,value) VALUES(?,?)",
                    ("owner_pass_hash", ""))

    # make sure newly added defaults land in existing databases too
    have = {r["key"] for r in con.execute("SELECT key FROM settings")}
    for k, v in DEFAULT_SETTINGS.items():
        if k not in have:
            con.execute("INSERT INTO settings(key,value) VALUES(?,?)", (k, v))
    if "owner_token" not in have:
        con.execute("INSERT INTO settings(key,value) VALUES(?,?)",
                    ("owner_token", secrets.token_urlsafe(16)))

    # ---- migration: the old default primary #059669 was only ~3.5:1 as
    # text. Upgrade databases still on the untouched default to brand-700;
    # a custom colour the owner actually chose is left alone.
    cur = con.execute("SELECT value FROM settings WHERE key='color_primary'")
    row = cur.fetchone()
    if row and row["value"] == "#059669":
        con.execute("UPDATE settings SET value='#047857' WHERE key='color_primary'")

    # ---- migration v65: dark green theme needs a LIGHT primary colour. The
    # factory value from the light-theme era (#047857) is far too dark against
    # the new #162019 background; upgrade it once. A custom choice is respected.
    row = con.execute("SELECT value FROM settings WHERE key='color_primary'").fetchone()
    if row and row["value"] == "#047857":
        con.execute("UPDATE settings SET value='#34d399' WHERE key='color_primary'")

    # ---- migration v60: warm film grading. The old mint-tinted background
    # and green-black text read as cold; warm them once, but only when the
    # owner is still on the factory value (a custom choice is respected).
    _warm = (("color_background", "#f4f8f7", "#faf6ef"),
             ("color_foreground", "#0b1f1a", "#241c13"))
    for key, old, new in _warm:
        r = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        if r and r["value"] == old:
            con.execute("UPDATE settings SET value=? WHERE key=?", (new, key))

    # ---- v75 user decision: hide every public product price now. Existing
    # databases may carry prices_enabled=1 from tests/older builds, so apply
    # this once; later admin changes persist because the marker stays at 1.
    marker = con.execute(
        "SELECT value FROM settings WHERE key='price_visibility_v75'").fetchone()
    if not marker or marker["value"] != "1":
        con.execute("INSERT INTO settings(key,value) VALUES('prices_enabled','0') "
                    "ON CONFLICT(key) DO UPDATE SET value='0'")
        con.execute("INSERT INTO settings(key,value) VALUES('price_visibility_v75','1') "
                    "ON CONFLICT(key) DO UPDATE SET value='1'")

    cur = con.execute("SELECT COUNT(*) c FROM categories")
    if cur.fetchone()["c"] == 0:
        for slug, name, icon, blurb, parent, sort in _taxonomy_rows():
            con.execute(
                "INSERT INTO categories(slug,name,icon,blurb,parent,sort) "
                "VALUES(?,?,?,?,?,?)", (slug, name, icon, blurb, parent, sort))

    # ---- migrations for databases created by an earlier version
    cols = {r["name"] for r in con.execute("PRAGMA table_info(businesses)")}
    if "owner_id" not in cols:
        con.execute("ALTER TABLE businesses ADD COLUMN owner_id INTEGER REFERENCES owners(id)")
    # index only after the column is guaranteed to exist
    con.execute("CREATE INDEX IF NOT EXISTS idx_biz_owner ON businesses(owner_id)")

    pcols = {r["name"] for r in con.execute("PRAGMA table_info(plans)")}
    if pcols and "tagline" not in pcols:
        con.execute("ALTER TABLE plans ADD COLUMN tagline TEXT DEFAULT ''")

    if pcols and "features" not in pcols:
        con.execute("ALTER TABLE plans ADD COLUMN features TEXT DEFAULT ''")
        # seed sensible defaults so an upgraded install is not left with
        # every tier granting nothing
        con.execute("UPDATE plans SET features='' WHERE slug='free'")
        con.execute("UPDATE plans SET features=? WHERE slug='plus'",
                    ("gallery,catalog,booking,stats,reply,qa,inquiry,social,featured",))
        con.execute("UPDATE plans SET features='*' WHERE slug='pro'")

    ccols = {r["name"] for r in con.execute("PRAGMA table_info(categories)")}
    if ccols and "parent" not in ccols:
        con.execute("ALTER TABLE categories ADD COLUMN parent TEXT DEFAULT ''")
    con.execute("CREATE INDEX IF NOT EXISTS idx_cat_parent ON categories(parent)")

    # the shop's own banner image, shown behind its page header
    bcols2 = {r["name"] for r in con.execute("PRAGMA table_info(businesses)")}
    if "cover" not in bcols2:
        con.execute("ALTER TABLE businesses ADD COLUMN cover TEXT DEFAULT ''")
    if "area" not in bcols2:
        con.execute("ALTER TABLE businesses ADD COLUMN area TEXT DEFAULT ''")
    if "city" not in bcols2:
        con.execute("ALTER TABLE businesses ADD COLUMN city TEXT DEFAULT ''")
    if "province" not in bcols2:
        con.execute("ALTER TABLE businesses ADD COLUMN province TEXT DEFAULT ''")

    # review photo (v28) + helpful votes (v32)
    rcols = {r["name"] for r in con.execute("PRAGMA table_info(reviews)")}
    if rcols and "image" not in rcols:
        con.execute("ALTER TABLE reviews ADD COLUMN image TEXT DEFAULT ''")
    if rcols and "helpful" not in rcols:
        con.execute("ALTER TABLE reviews ADD COLUMN helpful INTEGER DEFAULT 0")

    # story media kind (v37): image | video
    scols = {r["name"] for r in con.execute("PRAGMA table_info(stories)")}
    if scols and "kind" not in scols:
        con.execute("ALTER TABLE stories ADD COLUMN kind TEXT DEFAULT 'image'")
    # story duration in seconds (v101): lets the viewer play the full clip
    if scols and "duration" not in scols:
        con.execute("ALTER TABLE stories ADD COLUMN duration REAL DEFAULT 0")

    # customer moderation (v34)
    ccols = {r["name"] for r in con.execute("PRAGMA table_info(customers)")}
    if ccols and "status" not in ccols:
        con.execute("ALTER TABLE customers ADD COLUMN status TEXT DEFAULT 'active'")

    # ---- favourites are a set, not a bag (v74). Older builds had no UNIQUE
    # constraint, so deduplicate once before creating the durable guard.
    con.execute("DELETE FROM favorites WHERE id NOT IN "
                "(SELECT MIN(id) FROM favorites GROUP BY customer_id,biz_id)")
    con.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_fav_customer_biz "
                "ON favorites(customer_id,biz_id)")

    # ---- messenger read cursors (v73). SCHEMA creates these for a fresh
    # database; guarded ALTERs upgrade every existing installation in place.
    chat_cols = {r["name"] for r in con.execute("PRAGMA table_info(chat_threads)")}
    for col in ("customer_read_to", "owner_read_to", "admin_read_to"):
        if chat_cols and col not in chat_cols:
            con.execute(f"ALTER TABLE chat_threads ADD COLUMN {col} INTEGER DEFAULT 0")

    # ---- order privacy + two-stage cancellation (v76)
    order_cols={r["name"] for r in con.execute("PRAGMA table_info(orders)")}
    for col,ddl in (("share_phone","INTEGER DEFAULT 0"),("cancel_requested","INTEGER DEFAULT 0"),
                    ("cancel_reason","TEXT DEFAULT ''"),("cancel_requested_at","TEXT DEFAULT ''"),
                    ("cancel_decided_at","TEXT DEFAULT ''")):
        if order_cols and col not in order_cols: con.execute(f"ALTER TABLE orders ADD COLUMN {col} {ddl}")

    # ---- username + password login (v57): a returning user sets a
    # username/password after OTP so they can sign in without SMS next time.
    ocols = {r["name"] for r in con.execute("PRAGMA table_info(owners)")}
    if ocols and "username" not in ocols:
        con.execute("ALTER TABLE owners ADD COLUMN username TEXT DEFAULT ''")
    if ocols and "pass_hash" not in ocols:
        con.execute("ALTER TABLE owners ADD COLUMN pass_hash TEXT DEFAULT ''")
    cc2 = {r["name"] for r in con.execute("PRAGMA table_info(customers)")}
    if cc2 and "username" not in cc2:
        con.execute("ALTER TABLE customers ADD COLUMN username TEXT DEFAULT ''")
    if cc2 and "pass_hash" not in cc2:
        con.execute("ALTER TABLE customers ADD COLUMN pass_hash TEXT DEFAULT ''")
    con.execute("CREATE INDEX IF NOT EXISTS idx_owners_username ON owners(username)")
    con.execute("CREATE INDEX IF NOT EXISTS idx_customers_username ON customers(username)")

    # ---- privacy (v65): a family/last name alongside the first name.
    # The first name is REQUIRED (site-wide), the last name is optional.
    if ocols and "family" not in ocols:
        con.execute("ALTER TABLE owners ADD COLUMN family TEXT DEFAULT ''")
    if cc2 and "family" not in cc2:
        con.execute("ALTER TABLE customers ADD COLUMN family TEXT DEFAULT ''")

    icols = {r["name"] for r in con.execute("PRAGMA table_info(items)")}
    for col, ddl in (("images", "TEXT DEFAULT '[]'"), ("old_price", "INTEGER DEFAULT 0"),
                     ("stock", "INTEGER DEFAULT -1"), ("code", "TEXT DEFAULT ''"),
                     ("min_order", "TEXT DEFAULT ''"), ("options", "TEXT DEFAULT ''"),
                     ("note", "TEXT DEFAULT ''"),
                     # ---- shop-window fields (Basalam / Torob / Digikala parity)
                     ("brand", "TEXT DEFAULT ''"),
                     ("warranty", "TEXT DEFAULT ''"),      # گارانتی / ضمانت
                     ("prep_days", "TEXT DEFAULT ''"),     # آماده‌سازی: «۲ روز کاری»
                     ("delivery", "TEXT DEFAULT ''"),      # ارسال: پیک، پست، حضوری
                     ("handmade", "INTEGER DEFAULT 0"),    # دست‌ساز — پرچم باسلام
                     ("returnable", "INTEGER DEFAULT 0"),  # مرجوعی — پرچم دیجی‌کالا
                     ("bulk_price", "TEXT DEFAULT ''"),    # قیمت عمده
                     ("video", "TEXT DEFAULT ''"),         # لینک ویدئوی کوتاه
                     ("spec", "TEXT DEFAULT ''"),          # مشخصات: «رنگ=قرمز؛ وزن=۲کیلو»
                     ("weight", "TEXT DEFAULT ''"),
                     # ---- چانه‌زنی: per-product, opt-in, with a private floor
                     ("haggle", "INTEGER DEFAULT 0"),      # آیا چانه‌زنی باز است
                     ("floor_price", "INTEGER DEFAULT 0"), # کف قیمت — فقط فروشنده
                     ("views", "INTEGER DEFAULT 0")):
        if col not in icols:
            con.execute(f"ALTER TABLE items ADD COLUMN {col} {ddl}")

    for slug, (title, body) in DEFAULT_PAGES.items():
        con.execute("INSERT OR IGNORE INTO pages(slug,title,body) VALUES(?,?,?)",
                    (slug, title, body))

    # ---- seed all Iranian provinces & cities (idempotent)
    if con.execute("SELECT COUNT(*) c FROM cities").fetchone()["c"] == 0:
        try:
            import sys as _s
            _s.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tools"))
            from cities import PROVINCES, CITIES
            for province, capital in PROVINCES:
                for cname in CITIES.get(province, [capital]):
                    con.execute("INSERT OR IGNORE INTO cities(province,name,is_capital) "
                                "VALUES(?,?,?)", (province, cname, 1 if cname == capital else 0))
        except Exception:
            pass

    # ---- v3 seeds: badges and plans (idempotent, admin can edit/delete)
    if con.execute("SELECT COUNT(*) c FROM badges").fetchone()["c"] == 0:
        for i, (slug, name, ic, color, descr) in enumerate(DEFAULT_BADGES):
            con.execute("INSERT INTO badges(slug,name,icon,color,descr,sort) "
                        "VALUES(?,?,?,?,?,?)", (slug, name, ic, color, descr, i))
    if con.execute("SELECT COUNT(*) c FROM plans").fetchone()["c"] == 0:
        for i, (slug, name, price, months, fs, mi, mp, perks, badge, tag, feats) in enumerate(DEFAULT_PLANS):
            con.execute(
                "INSERT INTO plans(slug,name,tagline,price,months,featured_slots,max_items,"
                "max_photos,perks,badge_slug,features,sort) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (slug, name, tag, price, months, fs, mi, mp, perks, badge, feats, i))

    con.commit()
    con.close()
    expire_subscriptions()
    if _fts_ensure():
        # Seed the index once per start so search is accurate even before the
        # first write. Cheap for a directory-sized table.
        try:
            _fts_rebuild()
        except Exception:
            pass
    _fts_sync_if_needed()
    maintenance()


def maintenance():
    """Opportunistic housekeeping on every server start: prune expired OTPs,
    expired sessions (owner + admin) and rate-limit buckets idle over a week.
    Cheap, idempotent, and keeps the temporary tables from growing forever."""
    now = time.time()
    con = connect()
    try:
        con.execute("DELETE FROM otp WHERE expires < ?", (now,))
        con.execute("DELETE FROM sessions WHERE expires < ?", (now,))
        con.execute("DELETE FROM admin_sessions WHERE expires < ?", (now,))
        con.execute("DELETE FROM ratelimit WHERE window < ?", (now - 7 * 86400,))
        con.commit()
    finally:
        con.close()


# ------------------------------------------------------------------ settings
def get_settings():
    con = connect()
    rows = con.execute("SELECT key,value FROM settings").fetchall()
    con.close()
    return {r["key"]: r["value"] for r in rows}


def set_setting(key, value):
    access_cache_clear()
    con = connect()
    con.execute(
        "INSERT INTO settings(key,value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))
    con.commit()
    con.close()


def set_settings(d):
    access_cache_clear()
    con = connect()
    for k, v in d.items():
        con.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v)))
    con.commit()
    con.close()


def owner_token():
    return get_settings().get("owner_token", "")


def rotate_owner_token():
    t = secrets.token_urlsafe(16)
    set_setting("owner_token", t)
    return t


# ----------------------------------------------------------------- admin auth
# The panel was reachable by token-in-URL alone, which leaks through browser
# history, screenshots and server logs. Adding an optional password means the
# URL token identifies the admin while the password (stored only as a salted
# PBKDF2 hash) is what actually unlocks the panel.
PBKDF2_ITERS = 120_000
ADMIN_SESSION_TTL = 60 * 60 * 24 * 30        # 30 days, mirrors owner sessions


def _hash_password(pw, salt_hex):
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"),
                             bytes.fromhex(salt_hex), PBKDF2_ITERS)
    return f"pbkdf2${PBKDF2_ITERS}${salt_hex}${dk.hex()}"


def set_owner_pass(pw):
    """Set (or clear, when empty) the panel password."""
    if not pw:
        set_setting("owner_pass_hash", "")
        return
    set_setting("owner_pass_hash", _hash_password(pw, secrets.token_hex(8)))


def owner_pass_set():
    return bool((get_settings().get("owner_pass_hash") or "").strip())


def check_owner_pass(pw):
    stored = (get_settings().get("owner_pass_hash") or "").strip()
    if not stored or not pw:
        return False
    try:
        _algo, iters, salt, hx = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"),
                                 bytes.fromhex(salt), int(iters))
        return secrets.compare_digest(dk.hex(), hx)
    except (ValueError, TypeError):
        return False


# ==========================================================================
#  USERNAME + PASSWORD login (v57)  —  the SMS-saving alternative
#
#  A returning owner/customer signs in with phone+OTP once, sets a username
#  and password, and thereafter signs in with those — no SMS cost. Passwords
#  are PBKDF2-salted (same 120k iterations as the panel), compared in
#  constant time, and every password attempt is rate-limited at the route.
# ==========================================================================

def hash_password(pw):
    """Salted PBKDF2-SHA256 hash: "pbkdf2$iters$salt$hex". Generic — used for
    owner and customer credentials alike."""
    return _hash_password(pw, secrets.token_hex(8))


def verify_password(pw, stored):
    """Constant-time check of a hash produced by hash_password()."""
    if not stored or not pw:
        return False
    try:
        _algo, iters, salt, hx = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"),
                                 bytes.fromhex(salt), int(iters))
        return secrets.compare_digest(dk.hex(), hx)
    except (ValueError, TypeError):
        return False


# Username: 3–24 chars, Persian/Latin letters, digits, underscore, dot or
# hyphen. No spaces — a username must be typeable and unambiguous.
_USERNAME_RE = re.compile(r"^[\u0600-\u06FF\u0621-\u064Aa-zA-Z0-9._-]{3,24}$")


def valid_username(u):
    u = (u or "").strip()
    return bool(_USERNAME_RE.match(u)) and " " not in u


def _username_taken(table, username, exclude_id=None):
    con = connect()
    q = f"SELECT 1 FROM {table} WHERE username=? AND username<>''"
    p = [username]
    if exclude_id:
        q += " AND id<>?"
        p.append(exclude_id)
    r = con.execute(q, p).fetchone()
    con.close()
    return bool(r)


def owner_set_credentials(owner_id, username, password):
    """(ok: bool, msg: str). Sets or updates an owner's username+password."""
    username = (username or "").strip()
    if not valid_username(username):
        return False, "نام کاربری باید ۳ تا ۲۴ نویسه (حروف، عدد، _ . -) و بدون فاصله باشد."
    if _username_taken("owners", username, owner_id):
        return False, "این نام کاربری قبلاً گرفته شده است."
    if not password or len(password) < 6:
        return False, "رمز عبور باید دست‌کم ۶ نویسه باشد."
    con = connect()
    con.execute("UPDATE owners SET username=?, pass_hash=? WHERE id=?",
                (username, hash_password(password), owner_id))
    con.commit()
    con.close()
    return True, "نام کاربری و رمز عبور ذخیره شد."


def owner_by_username(username):
    username = (username or "").strip()
    if not username:
        return None
    con = connect()
    r = con.execute("SELECT * FROM owners WHERE username=? AND username<>''",
                    (username,)).fetchone()
    con.close()
    return dict(r) if r else None


def owner_has_password(owner_id):
    con = connect()
    r = con.execute("SELECT pass_hash FROM owners WHERE id=?",
                    (owner_id,)).fetchone()
    con.close()
    return bool(r and (r["pass_hash"] or "").strip())


def owner_check_password(owner_id, password):
    con = connect()
    r = con.execute("SELECT pass_hash FROM owners WHERE id=?",
                    (owner_id,)).fetchone()
    con.close()
    return verify_password(password, r["pass_hash"] if r else "")


def admin_session_new():
    tok = secrets.token_urlsafe(24)
    con = connect()
    con.execute("DELETE FROM admin_sessions WHERE expires < ?", (time.time(),))
    con.execute("INSERT INTO admin_sessions(token,expires) VALUES(?,?)",
                (tok, time.time() + ADMIN_SESSION_TTL))
    con.commit()
    con.close()
    return tok


def admin_session_ok(token):
    if not token:
        return False
    con = connect()
    r = con.execute("SELECT 1 FROM admin_sessions WHERE token=? AND expires > ?",
                    (token, time.time())).fetchone()
    con.close()
    return bool(r)


def admin_session_kill(token):
    if not token:
        return
    con = connect()
    con.execute("DELETE FROM admin_sessions WHERE token=?", (token,))
    con.commit()
    con.close()


# ------------------------------------------------------------------ helpers
# Persian/Arabic -> Latin, so public URLs stay clean and SEO-friendly
_TRANS = {
    "ا":"a","آ":"a","أ":"a","إ":"e","ب":"b","پ":"p","ت":"t","ث":"s","ج":"j",
    "چ":"ch","ح":"h","خ":"kh","د":"d","ذ":"z","ر":"r","ز":"z","ژ":"zh","س":"s",
    "ش":"sh","ص":"s","ض":"z","ط":"t","ظ":"z","ع":"a","غ":"gh","ف":"f","ق":"gh",
    "ک":"k","ك":"k","گ":"g","ل":"l","م":"m","ن":"n","و":"v","ه":"h","ی":"y",
    "ي":"y","ة":"h","ؤ":"o","ئ":"y","ء":"","َ":"a","ِ":"e","ُ":"o","ّ":"","ْ":"",
    "ً":"","ٍ":"","ٌ":"","ـ":"",
    "۰":"0","۱":"1","۲":"2","۳":"3","۴":"4","۵":"5","۶":"6","۷":"7","۸":"8","۹":"9",
    "٠":"0","١":"1","٢":"2","٣":"3","٤":"4","٥":"5","٦":"6","٧":"7","٨":"8","٩":"9",
}


def translit(text):
    return "".join(_TRANS.get(ch, ch) for ch in (text or ""))


def slugify(text, fallback="item"):
    s = translit((text or "").strip().lower())
    s = re.sub(r"[\s_]+", "-", s)
    s = re.sub(r"[^a-z0-9\-]", "", s)
    s = re.sub(r"-{2,}", "-", s).strip("-")
    return s or fallback


def unique_slug(table, base):
    con = connect()
    slug, i = base, 2
    while con.execute(f"SELECT 1 FROM {table} WHERE slug=?", (slug,)).fetchone():
        slug = f"{base}-{i}"
        i += 1
    con.close()
    return slug


def log(action, detail=""):
    con = connect()
    con.execute("INSERT INTO audit(action,detail) VALUES(?,?)", (action, detail))
    con.commit()
    con.close()


# ------------------------------------------------------------------ categories
def categories(only_active=True, parent=None, top_only=False):
    """Categories with a live business count.

    `count`      businesses filed directly under this slug
    `total`      count plus everything in its children (what a parent shows)
    `children`   the child rows, already counted

    Pass parent="" for top level only, parent="food" for one branch's
    children, or top_only=True as a readable alias for the first.
    """
    con = connect()
    q = "SELECT * FROM categories"
    where, p = [], []
    if only_active:
        where.append("active=1")
    if top_only:
        parent = ""
    if parent is not None:
        where.append("COALESCE(parent,'')=?")
        p.append(parent)
    if where:
        q += " WHERE " + " AND ".join(where)
    q += " ORDER BY sort, id"
    rows = [dict(r) for r in con.execute(q, p)]

    counts = {r["cat_slug"]: r["c"] for r in con.execute(
        "SELECT cat_slug, COUNT(*) c FROM businesses "
        "WHERE status='published' GROUP BY cat_slug")}
    kids = {}
    for r in con.execute("SELECT * FROM categories WHERE COALESCE(parent,'')<>''"
                         + (" AND active=1" if only_active else "")
                         + " ORDER BY sort, id"):
        d = dict(r)
        d["count"] = counts.get(d["slug"], 0)
        d["total"] = d["count"]
        kids.setdefault(d["parent"], []).append(d)
    con.close()

    for r in rows:
        r["count"] = counts.get(r["slug"], 0)
        r["children"] = kids.get(r["slug"], [])
        r["total"] = r["count"] + sum(k["count"] for k in r["children"])
    return rows


def category_tree(only_active=True):
    """Top-level categories, each carrying its children. The shape every
    public page and the submit form want."""
    return categories(only_active=only_active, top_only=True)


def category_children(slug, only_active=True):
    return categories(only_active=only_active, parent=slug)


def category_family(slug):
    """[slug] plus every child slug — used to widen a filter so that clicking
    a parent shows the businesses filed under its children too."""
    con = connect()
    kids = [r["slug"] for r in con.execute(
        "SELECT slug FROM categories WHERE parent=?", (slug,))]
    con.close()
    return [slug] + kids


def category_path(slug):
    """[parent, child] or [top] — for breadcrumbs."""
    c = category(slug)
    if not c:
        return []
    if c.get("parent"):
        p = category(c["parent"])
        return [p, c] if p else [c]
    return [c]


def category(slug):
    con = connect()
    r = con.execute("SELECT * FROM categories WHERE slug=?", (slug,)).fetchone()
    con.close()
    return dict(r) if r else None


def category_by_id(cid):
    con = connect()
    r = con.execute("SELECT * FROM categories WHERE id=?", (cid,)).fetchone()
    con.close()
    if not r:
        return None
    d = dict(r)
    con = connect()
    d["count"] = con.execute(
        "SELECT COUNT(*) c FROM businesses WHERE cat_slug=? AND status='published'",
        (d["slug"],)).fetchone()["c"]
    con.close()
    return d


def save_category(data, cid=None):
    con = connect()
    parent = (data.get("parent") or "").strip()
    if cid:
        # a category may not be its own parent, nor a parent of its parent
        cur = con.execute("SELECT slug FROM categories WHERE id=?", (cid,)).fetchone()
        if cur and parent == cur["slug"]:
            parent = ""
        con.execute("""UPDATE categories SET name=?, icon=?, blurb=?, sort=?,
                       active=?, parent=? WHERE id=?""",
                    (data["name"], data["icon"], data.get("blurb", ""),
                     int(data.get("sort", 0)), int(data.get("active", 1)),
                     parent, cid))
    else:
        slug = data.get("slug") or slugify(data["name"], "cat")
        slug = unique_slug("categories", slug)
        con.execute("""INSERT INTO categories(slug,name,icon,blurb,sort,active,parent)
                       VALUES(?,?,?,?,?,?,?)""",
                    (slug, data["name"], data.get("icon", "store"),
                     data.get("blurb", ""), int(data.get("sort", 0)),
                     int(data.get("active", 1)), parent))
        cid = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
    con.commit()
    con.close()
    return cid


def delete_category(cid):
    con = connect()
    row = con.execute("SELECT slug FROM categories WHERE id=?", (cid,)).fetchone()
    if row:
        n = con.execute("SELECT COUNT(*) c FROM businesses WHERE cat_slug=?",
                        (row["slug"],)).fetchone()["c"]
        if n:
            con.close()
            return False, f"این دسته {n} کسب‌وکار دارد؛ ابتدا آن‌ها را جابه‌جا کنید."
        # A parent with children would orphan them into an unreachable state,
        # so refuse and say exactly what to do first.
        k = con.execute("SELECT COUNT(*) c FROM categories WHERE parent=?",
                        (row["slug"],)).fetchone()["c"]
        if k:
            con.close()
            return False, f"این دسته {k} زیردسته دارد؛ ابتدا زیردسته‌ها را حذف یا جابه‌جا کنید."
    con.execute("DELETE FROM categories WHERE id=?", (cid,))
    con.commit()
    con.close()
    return True, "حذف شد."


# ------------------------------------------------------------------ businesses
def _biz_row(r):
    d = dict(r)
    try:
        d["images"] = json.loads(d.get("images") or "[]")
    except Exception:
        d["images"] = []
    try:
        d["hours_map"] = json.loads(d.get("hours") or "{}")
    except Exception:
        d["hours_map"] = {}
    d["tag_list"] = [t.strip() for t in (d.get("tags") or "").split("،") if t.strip()] \
        or [t.strip() for t in (d.get("tags") or "").split(",") if t.strip()]
    return d


def businesses(status="published", cat=None, limit=None, order="featured", city=None):
    con = connect()
    q = "SELECT b.*, (SELECT AVG(rating) FROM reviews WHERE biz_id=b.id AND status='approved') rating, " \
        "(SELECT COUNT(*) FROM reviews WHERE biz_id=b.id AND status='approved') nreviews " \
        "FROM businesses b WHERE 1=1"
    p = []
    if status:
        q += " AND b.status=?"
        p.append(status)
    if cat:
        # clicking a parent should show everything beneath it, not an empty page
        fam = category_family(cat)
        q += " AND b.cat_slug IN (%s)" % ",".join("?" * len(fam))
        p.extend(fam)
    if city:
        q += " AND b.city=?"
        p.append(city)
    order_sql = {
        "featured": " ORDER BY b.featured DESC, rating DESC NULLS LAST, b.id DESC",
        "newest":   " ORDER BY b.id DESC",
        "rating":   " ORDER BY rating DESC NULLS LAST",
        "name":     " ORDER BY b.name",
        "views":    " ORDER BY b.views DESC",
    }.get(order, " ORDER BY b.id DESC")
    q += order_sql
    if limit:
        q += f" LIMIT {int(limit)}"
    rows = [_biz_row(r) for r in con.execute(q, p)]
    con.close()
    return annotate_stories(rows)


def business(slug=None, bid=None):
    con = connect()
    if slug:
        r = con.execute("SELECT * FROM businesses WHERE slug=?", (slug,)).fetchone()
    else:
        r = con.execute("SELECT * FROM businesses WHERE id=?", (bid,)).fetchone()
    if not r:
        con.close()
        return None
    d = _biz_row(r)
    ag = con.execute("SELECT AVG(rating) a, COUNT(*) c FROM reviews "
                     "WHERE biz_id=? AND status='approved'", (d["id"],)).fetchone()
    d["rating"] = round(ag["a"], 1) if ag["a"] else 0
    d["nreviews"] = ag["c"]
    d["has_story"] = d["id"] in stories_active_ids()
    con.close()
    return d


def save_business(data, bid=None):
    con = connect()
    fields = ("name", "cat_slug", "descr", "phone", "whatsapp", "address",
              "lat", "lng", "hours", "tags", "images", "featured", "verified",
              "status", "instagram", "telegram", "website", "booking_on",
              "owner_id", "cover", "area", "city", "province")
    vals = {}
    for f in fields:
        if f in data:
            v = data[f]
            if f in ("featured", "verified", "booking_on"):
                v = int(bool(int(v or 0)))
            if f in ("lat", "lng"):
                v = float(v) if str(v).strip() not in ("", "None") else None
            if f == "images" and not isinstance(v, str):
                v = json.dumps(v, ensure_ascii=False)
            if f == "hours" and not isinstance(v, str):
                v = json.dumps(v, ensure_ascii=False)
            vals[f] = v

    if bid:
        sets = ", ".join(f"{k}=?" for k in vals)
        con.execute(f"UPDATE businesses SET {sets} WHERE id=?",
                    list(vals.values()) + [bid])
    else:
        base = slugify(data.get("slug") or data.get("name"), "biz")
        vals["slug"] = unique_slug("businesses", base)
        cols = ", ".join(vals)
        qs = ", ".join("?" * len(vals))
        con.execute(f"INSERT INTO businesses({cols}) VALUES({qs})", list(vals.values()))
        bid = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
    con.commit()
    con.close()
    _fts_mark_dirty()
    return bid


def delete_business(bid):
    con = connect()
    con.execute("DELETE FROM businesses WHERE id=?", (bid,))
    con.commit()
    con.close()
    _fts_mark_dirty()


def all_upload_refs():
    """Every public upload path still referenced by live data (business
    galleries and covers, item images, the site logo). The orphan-file GC and
    the media manager both use this as the "still wanted" set."""
    def _paths(v):
        out = []
        if not isinstance(v, str) or not v:
            return out
        try:
            parsed = json.loads(v)
            if isinstance(parsed, list):
                return [p for p in parsed if isinstance(p, str) and p]
        except Exception:
            pass
        return [v]

    refs = set()
    con = connect()
    for r in con.execute("SELECT images, cover FROM businesses"):
        for v in (r["images"], r["cover"]):
            refs.update(_paths(v))
    for r in con.execute("SELECT image, images FROM items"):
        for v in (r["image"], r["images"]):
            refs.update(_paths(v))
    con.close()
    logo = (get_settings().get("site_logo") or "").strip()
    if logo:
        refs.add(logo)
    return refs


def bump_views(bid):
    """Count a page view in BOTH places, in one transaction.

    This used to touch only `businesses.views`, so the `events` table stayed
    empty and every chart — the owner's 30-day graph and the whole-site
    insights page — rendered as a flat zero line. The lifetime counter and the
    daily series have to move together or the numbers contradict each other.
    """
    day = datetime.date.today().isoformat()
    con = connect()
    con.execute("UPDATE businesses SET views=views+1 WHERE id=?", (bid,))
    con.execute("""INSERT INTO events(biz_id,kind,day,n) VALUES(?,'view',?,1)
                   ON CONFLICT(biz_id,kind,day) DO UPDATE SET n = n + 1""",
                (bid, day))
    con.commit()
    con.close()


# ==========================================================================
#  "OPEN NOW" — the question every customer actually has
#
#  A directory that lists a closed shop as if it were open wastes a trip.
#  Everything here is computed from the shop's own hours table, in Iran local
#  time, with no network call and no third-party service — so it keeps working
#  on a phone with no data and inside Pydroid.
#
#  Week keys match the hours editor: sat..fri. Python's weekday() is
#  Monday=0..Sunday=6, hence the lookup table below.
# ==========================================================================
DAY_KEYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]   # by weekday()
DAY_FA = {"sat": "شنبه", "sun": "یک‌شنبه", "mon": "دوشنبه", "tue": "سه‌شنبه",
          "wed": "چهارشنبه", "thu": "پنج‌شنبه", "fri": "جمعه"}

# Iran is UTC+3:30 and has not observed DST since 1401/2022, so a fixed
# offset is correct and avoids depending on the device's timezone being set.
IRAN_OFFSET_MIN = 210

_FA_TRANS = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")


def _fa(n):
    """Persian digits. db.py deliberately keeps its own tiny copy rather than
    importing the one in layout.py, which would drag the whole static-site
    module (and its data.py) into the server for the sake of ten characters."""
    return str(n).translate(_FA_TRANS)


def iran_now():
    """Current wall-clock time in Iran, independent of the device setting."""
    return datetime.datetime.now(datetime.timezone.utc) + \
        datetime.timedelta(minutes=IRAN_OFFSET_MIN)


def _hhmm(s):
    """'09:30' -> 570 minutes. Returns None when unparseable."""
    try:
        h, m = str(s).strip().split(":")[:2]
        h, m = int(h), int(m)
    except Exception:
        return None
    if not (0 <= h <= 24 and 0 <= m < 60):
        return None
    return h * 60 + m


def open_state(b, now=None):
    """What is this shop's status right now?

    Returns a dict every caller can render directly:
      state    'open' | 'closing' | 'closed' | 'unknown'
      label    a short Persian phrase
      detail   the useful extra ('تا ۲۱:۰۰', 'شنبه ۹:۰۰ باز می‌شود')
      minutes  minutes until it closes, when state is open/closing

    'unknown' is deliberate and honest: a shop that never filled in its hours
    must not be claimed to be open, nor be hidden as if it were closed.
    """
    hm = b.get("hours_map") or {}

    # A shop counts as having hours only if at least one range actually
    # parses. Hours that are present but entirely unreadable are 'unknown',
    # not 'closed' — reporting a shop shut because of a malformed field would
    # cost a real shopkeeper real customers.
    def _valid(k):
        v = hm.get(k)
        if not isinstance(v, (list, tuple)):
            return False
        return any(isinstance(r, (list, tuple)) and len(r) == 2
                   and _hhmm(r[0]) is not None and _hhmm(r[1]) is not None
                   for r in v)

    if not any(_valid(k) for k in DAY_KEYS):
        return {"state": "unknown", "label": "ساعت کاری ثبت نشده",
                "detail": "", "minutes": None}

    now = now or iran_now()
    today = DAY_KEYS[now.weekday()]
    cur = now.hour * 60 + now.minute

    # --- is it inside one of today's ranges?
    for rng in (hm.get(today) or []):
        if len(rng) != 2:
            continue
        o, c = _hhmm(rng[0]), _hhmm(rng[1])
        if o is None or c is None:
            continue
        # a range ending past midnight (e.g. 20:00–02:00) wraps to the next day
        wraps = c <= o
        inside = (o <= cur < c) if not wraps else (cur >= o or cur < c)
        if inside:
            left = (c - cur) if not wraps else ((c + 1440 - cur) % 1440)
            if left <= 60:
                return {"state": "closing",
                        "label": f"تا {_fa(left)} دقیقهٔ دیگر می‌بندد",
                        "detail": f"تا ساعت {_fa(rng[1])}", "minutes": left}
            return {"state": "open", "label": "الان باز است",
                    "detail": f"تا ساعت {_fa(rng[1])}", "minutes": left}

    # --- closed: find the next opening, looking up to a week ahead
    for step in range(0, 8):
        d = DAY_KEYS[(now.weekday() + step) % 7]
        for rng in sorted(hm.get(d) or [], key=lambda r: _hhmm(r[0]) or 0):
            if len(rng) != 2:
                continue
            o = _hhmm(rng[0])
            if o is None:
                continue
            if step == 0 and o <= cur:
                continue          # already passed today
            if step == 0:
                mins = o - cur
                if mins <= 90:
                    return {"state": "closed",
                            "label": f"تا {_fa(mins)} دقیقهٔ دیگر باز می‌شود",
                            "detail": f"ساعت {_fa(rng[0])}", "minutes": None}
                return {"state": "closed", "label": "الان بسته است",
                        "detail": f"امروز ساعت {_fa(rng[0])} باز می‌شود",
                        "minutes": None}
            when = "فردا" if step == 1 else DAY_FA.get(d, d)
            return {"state": "closed", "label": "الان بسته است",
                    "detail": f"{when} ساعت {_fa(rng[0])} باز می‌شود",
                    "minutes": None}

    return {"state": "closed", "label": "الان بسته است", "detail": "",
            "minutes": None}


def is_open_now(b, now=None):
    return open_state(b, now)["state"] in ("open", "closing")


def annotate_open(rows, now=None):
    """Stamp every row with its live status once, so templates never recompute."""
    now = now or iran_now()
    for b in rows:
        b["open_state"] = open_state(b, now)
    return rows


# ---------------------------------------------------------------- full-text
# SQLite FTS5, when the device's sqlite has it (desktop always does; some
# Android/Pydroid builds don't). When it is missing we transparently fall
# back to the in-memory filter, so search keeps working everywhere.
FTS_OK = False


def _fts_ensure():
    """Create the FTS table if possible. Returns True when usable."""
    global FTS_OK
    try:
        con = connect()
        con.execute("CREATE VIRTUAL TABLE IF NOT EXISTS businesses_fts "
                    "USING fts5(name, descr, tags, address)")
        con.commit()
        con.close()
        FTS_OK = True
    except Exception:
        FTS_OK = False
    return FTS_OK


def _fts_rebuild():
    """Repopulate the FTS index from the live businesses table."""
    con = connect()
    try:
        con.execute("DELETE FROM businesses_fts")
        for r in con.execute("SELECT id,name,descr,tags,address FROM businesses "
                             "WHERE status='published'"):
            con.execute(
                "INSERT INTO businesses_fts(rowid,name,descr,tags,address) "
                "VALUES(?,?,?,?,?)",
                (r["id"], r["name"], r["descr"] or "", r["tags"] or "",
                 r["address"] or ""))
        con.commit()
    finally:
        con.close()


def _fts_mark_dirty():
    set_setting("fts_dirty", "1")


def _fts_sync_if_needed():
    if get_settings().get("fts_dirty") != "1":
        return
    if _fts_ensure():
        try:
            _fts_rebuild()
        except Exception:
            pass
    set_setting("fts_dirty", "0")


def _fts_query(term):
    """Safe MATCH expression: every token quoted, joined with AND. Persian
    text tokenises on spaces; each token is wrapped so user input can never
    break the FTS syntax."""
    toks = [t for t in normalize_fa(term).split() if t]
    if not toks:
        return None
    quoted = " AND ".join('"' + t.replace('"', '""') + '"' for t in toks)
    con = connect()
    try:
        ids = [r["rowid"] for r in con.execute(
            "SELECT rowid FROM businesses_fts WHERE businesses_fts MATCH ?",
            (quoted,))]
    except Exception:
        ids = []
    con.close()
    return ids


def search(term="", cat="", open_now=False, sort="featured", tag="", city=None):
    rows = businesses(status="published", cat=cat or None, order=sort, city=city)
    if term:
        t = normalize_fa(term)
        if FTS_OK:
            ids = _fts_query(term)
            if ids:
                idset = set(ids)
                rows = [r for r in rows if r["id"] in idset]
            else:
                # no FTS hit — still run the substring filter as a safety net
                # for terms the tokeniser split differently (e.g. ZWNJ).
                rows = [r for r in rows
                        if t in normalize_fa(f"{r['name']} {r['descr']} {r['tags']} {r['address']}")]
        else:
            rows = [r for r in rows
                    if t in normalize_fa(f"{r['name']} {r['descr']} {r['tags']} {r['address']}")]
    if tag:
        rows = [r for r in rows if tag in (r.get("tags") or "")]
    if open_now:
        # This parameter used to be accepted and silently ignored — the filter
        # simply did not exist. Shops with no hours on file are kept, because
        # excluding them would punish a shopkeeper for a blank field rather
        # than for being closed.
        _n = iran_now()
        rows = [r for r in rows
                if open_state(r, _n)["state"] in ("open", "closing", "unknown")]
    return rows


def normalize_fa(s):
    """Fold the spelling variations Persian typists actually produce.

    The zero-width non-joiner matters most: «گل‌محمدی» and «گل محمدی» are the
    same name to a human, but as raw text one is a single token and the other
    is two, so similarity scored 0.5 and duplicate detection missed it. Treat
    the ZWNJ as a space and the two forms tokenise identically.
    """
    s = (s or "").lower()
    for a, b in (("ي", "ی"), ("ك", "ک"), ("ﻻ", "لا"),
                 ("\u200c", " "),   # ZWNJ (نیم‌فاصله)
                 ("\u200f", " "), ("\u200e", " "),   # bidi marks
                 ("\u00a0", " "),   # non-breaking space
                 ("ۀ", "ه"), ("ة", "ه"), ("أ", "ا"), ("إ", "ا"), ("آ", "ا"),
                 ("ؤ", "و"), ("ئ", "ی"), ("ء", "")):
        s = s.replace(a, b)
    s = re.sub(r"[ًٌٍَُِّْـ]", "", s)
    trans = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
    s = s.translate(trans)
    return re.sub(r"\s+", " ", s).strip()


# ------------------------------------------------------------------ reviews
def reviews(biz_id=None, status=None):
    con = connect()
    q = "SELECT r.*, b.name bizname, b.slug bizslug FROM reviews r " \
        "JOIN businesses b ON b.id=r.biz_id WHERE 1=1"
    p = []
    if biz_id:
        q += " AND r.biz_id=?"; p.append(biz_id)
    if status:
        q += " AND r.status=?"; p.append(status)
    q += " ORDER BY r.id DESC"
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()
    return rows


def add_review(biz_id, author, rating, body, auto_approve=False):
    con = connect()
    con.execute("INSERT INTO reviews(biz_id,author,rating,body,status) VALUES(?,?,?,?,?)",
                (biz_id, author, int(rating), body,
                 "approved" if auto_approve else "pending"))
    con.commit()
    con.close()


def update_review(rid, **kw):
    if not kw:
        return
    con = connect()
    sets = ", ".join(f"{k}=?" for k in kw)
    con.execute(f"UPDATE reviews SET {sets} WHERE id=?", list(kw.values()) + [rid])
    con.commit()
    con.close()


def delete_review(rid):
    row = _one("SELECT * FROM reviews WHERE id=?", (rid,))
    if row:
        trash_put("review", rid, row["biz_id"],
                  (row["author"] or "") + ": " + (row["body"] or "")[:40], dict(row))
    con = connect()
    con.execute("DELETE FROM reviews WHERE id=?", (rid,))
    con.commit()
    con.close()


# ------------------------------------------------------------------ bookings
def bookings(status=None):
    con = connect()
    q = "SELECT k.*, b.name bizname FROM bookings k JOIN businesses b ON b.id=k.biz_id"
    p = []
    if status:
        q += " WHERE k.status=?"; p.append(status)
    q += " ORDER BY k.id DESC"
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()
    return rows


def add_booking(biz_id, name, phone, date, time_, note=""):
    con = connect()
    con.execute("""INSERT INTO bookings(biz_id,name,phone,date,time,note)
                   VALUES(?,?,?,?,?,?)""", (biz_id, name, phone, date, time_, note))
    con.commit()
    con.close()


def update_booking(kid, **kw):
    con = connect()
    sets = ", ".join(f"{k}=?" for k in kw)
    con.execute(f"UPDATE bookings SET {sets} WHERE id=?", list(kw.values()) + [kid])
    con.commit()
    con.close()


# ------------------------------------------------------------------ posts
def posts(status="published", limit=None):
    con = connect()
    q = "SELECT * FROM posts"
    p = []
    if status:
        q += " WHERE status=?"; p.append(status)
    q += " ORDER BY id DESC"
    if limit:
        q += f" LIMIT {int(limit)}"
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()
    return rows


def post(slug):
    con = connect()
    r = con.execute("SELECT * FROM posts WHERE slug=?", (slug,)).fetchone()
    con.close()
    return dict(r) if r else None


def save_post(data, pid=None):
    con = connect()
    if pid:
        con.execute("""UPDATE posts SET title=?, excerpt=?, body=?, cover=?, status=?
                       WHERE id=?""",
                    (data["title"], data.get("excerpt", ""), data.get("body", ""),
                     data.get("cover", ""), data.get("status", "published"), pid))
    else:
        slug = unique_slug("posts", slugify(data.get("slug") or data["title"], "post"))
        con.execute("""INSERT INTO posts(slug,title,excerpt,body,cover,status)
                       VALUES(?,?,?,?,?,?)""",
                    (slug, data["title"], data.get("excerpt", ""),
                     data.get("body", ""), data.get("cover", ""),
                     data.get("status", "published")))
    con.commit()
    con.close()


def delete_post(pid):
    con = connect()
    con.execute("DELETE FROM posts WHERE id=?", (pid,))
    con.commit()
    con.close()


# ------------------------------------------------------------------ pages
def get_page(slug):
    con = connect()
    r = con.execute("SELECT * FROM pages WHERE slug=?", (slug,)).fetchone()
    con.close()
    return dict(r) if r else {"slug": slug, "title": "", "body": ""}


def save_page(slug, title, body):
    con = connect()
    con.execute("""INSERT INTO pages(slug,title,body) VALUES(?,?,?)
                   ON CONFLICT(slug) DO UPDATE SET title=excluded.title,
                   body=excluded.body""", (slug, title, body))
    con.commit()
    con.close()


# ------------------------------------------------------------------ messages
def messages(status=None, kind=None):
    con = connect()
    q = "SELECT * FROM messages WHERE 1=1"
    p = []
    if status:
        q += " AND status=?"; p.append(status)
    if kind:
        q += " AND kind=?"; p.append(kind)
    q += " ORDER BY id DESC"
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()
    return rows


def add_message(name, email, subject, body, kind="contact", meta=None):
    con = connect()
    con.execute("""INSERT INTO messages(name,email,subject,body,kind,meta)
                   VALUES(?,?,?,?,?,?)""",
                (name, email, subject, body, kind,
                 json.dumps(meta or {}, ensure_ascii=False)))
    con.commit()
    con.close()


def update_message(mid, **kw):
    con = connect()
    sets = ", ".join(f"{k}=?" for k in kw)
    con.execute(f"UPDATE messages SET {sets} WHERE id=?", list(kw.values()) + [mid])
    con.commit()
    con.close()


def delete_message(mid):
    con = connect()
    con.execute("DELETE FROM messages WHERE id=?", (mid,))
    con.commit()
    con.close()


# ------------------------------------------------------------------ stats
def stats():
    con = connect()
    g = lambda q, *p: con.execute(q, p).fetchone()[0]
    d = {
        "businesses": g("SELECT COUNT(*) FROM businesses WHERE status='published'"),
        "pending_biz": g("SELECT COUNT(*) FROM businesses WHERE status='pending'"),
        "categories": g("SELECT COUNT(*) FROM categories WHERE active=1"),
        "reviews": g("SELECT COUNT(*) FROM reviews WHERE status='approved'"),
        "pending_reviews": g("SELECT COUNT(*) FROM reviews WHERE status='pending'"),
        "bookings": g("SELECT COUNT(*) FROM bookings"),
        "new_bookings": g("SELECT COUNT(*) FROM bookings WHERE status='new'"),
        "messages": g("SELECT COUNT(*) FROM messages"),
        "new_messages": g("SELECT COUNT(*) FROM messages WHERE status='new'"),
        "views": g("SELECT COALESCE(SUM(views),0) FROM businesses"),
        "posts": g("SELECT COUNT(*) FROM posts"),
    }
    con.close()
    return d


def asset_weights():
    """Site storage / asset weight for the dashboard health card (v53).

    A directory owner should be able to see at a glance how heavy the site is
    — that is what drives load time on a phone, not the server. Sizes are
    returned in whole kilobytes, so the panel can render Persian numbers.
    """
    import os
    HERE = os.path.dirname(os.path.abspath(__file__))
    SITE = os.path.abspath(os.path.join(HERE, "..", "site", "assets"))

    def kb(path):
        try:
            return os.path.getsize(path) // 1024
        except OSError:
            return 0

    uploads_dir = os.path.join(SITE, "img", "uploads")
    cats_dir = os.path.join(SITE, "img", "cats")
    up_files = up_bytes = 0
    for f in os.listdir(uploads_dir):
        if f == ".gitkeep":
            continue
        p = os.path.join(uploads_dir, f)
        if os.path.isfile(p):
            up_files += 1
            up_bytes += os.path.getsize(p)
    cat_files = cat_bytes = 0
    for f in os.listdir(cats_dir):
        p = os.path.join(cats_dir, f)
        if os.path.isfile(p):
            cat_files += 1
            cat_bytes += os.path.getsize(p)
    return {
        "uploads": up_bytes // 1024,
        "upload_files": up_files,
        "cats": cat_bytes // 1024,
        "cat_files": cat_files,
        "video": 0,   # v75 removed the hero movie/poster entirely
        "sprite": 0,  # v75 replaced the all-in-one sheet with lazy WebP files
    }


# ------------------------------------------------------------------ backup
def export_all():
    con = connect()
    out = {"_meta": {"exported": datetime.datetime.now().isoformat(), "version": 1}}
    for t in ("settings", "categories", "businesses", "reviews", "bookings",
              "coupons", "posts", "messages", "pages",
              "items", "inquiries", "owners", "customers", "claims", "events",
              "chat_threads", "chat_messages", "chat_attachments",
              "tickets", "ticket_msgs", "ticket_attachments",
              "badges", "biz_badges", "plans", "subscriptions", "ads",
              "cityevents", "questions", "reports", "review_scores",
              "edits", "alerts", "biz_features"):
        out[t] = [dict(r) for r in con.execute(f"SELECT * FROM {t}")]
    con.close()
    return out


# Parents must be written before children, and wiped in reverse, or the
# foreign keys reject the restore.
_RESTORE_ORDER = ("settings", "pages", "categories", "owners", "customers", "badges",
                  "plans", "businesses", "items", "reviews", "review_scores",
                  "bookings", "coupons", "posts", "messages", "inquiries",
                  "claims", "events", "chat_threads", "chat_messages", "chat_attachments",
                  "tickets", "ticket_msgs", "ticket_attachments", "biz_badges", "subscriptions", "ads", "cityevents", "questions",
                  "reports", "edits", "alerts", "biz_features")


def import_all(payload):
    con = connect()
    con.execute("PRAGMA foreign_keys = OFF")
    try:
        for t in reversed(_RESTORE_ORDER):
            if t in payload:
                con.execute(f"DELETE FROM {t}")
        for t in _RESTORE_ORDER:
            if t not in payload:
                continue
            for row in payload[t]:
                # Only real SQL identifiers may become column names: the keys
                # come from an uploaded file, so a crafted key must never reach
                # the statement text. `t` itself is from the fixed list above.
                keys = [k for k in row.keys()
                        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", str(k))]
                if not keys:
                    continue
                cols = ", ".join(keys)
                qs = ", ".join("?" * len(keys))
                con.execute(f"INSERT OR REPLACE INTO {t}({cols}) VALUES({qs})",
                            [row[k] for k in keys])
        con.commit()
    finally:
        con.execute("PRAGMA foreign_keys = ON")
        con.close()


if __name__ == "__main__":
    init()
    print("database ready at", DB_PATH)
    print("owner token:", owner_token())


# ==========================================================================
#  OWNER ACCOUNTS  ·  OTP LOGIN  ·  SESSIONS
# ==========================================================================
import time as _time


def norm_phone(p):
    """0912 345 6789 / ۰۹۱۲... / +989... -> 09123456789"""
    p = translit(str(p or "")).strip()
    p = re.sub(r"[^\d+]", "", p)
    if p.startswith("+98"):
        p = "0" + p[3:]
    elif p.startswith("0098"):
        p = "0" + p[4:]
    elif p.startswith("98") and len(p) == 12:
        p = "0" + p[2:]
    return p


def valid_phone(p):
    p = norm_phone(p)
    return bool(re.fullmatch(r"09\d{9}", p))


def owner_by_phone(phone, create=False):
    phone = norm_phone(phone)
    con = connect()
    r = con.execute("SELECT * FROM owners WHERE phone=?", (phone,)).fetchone()
    if not r and create:
        con.execute("INSERT INTO owners(phone) VALUES(?)", (phone,))
        con.commit()
        r = con.execute("SELECT * FROM owners WHERE phone=?", (phone,)).fetchone()
    con.close()
    return dict(r) if r else None


def owner_by_id(oid):
    con = connect()
    r = con.execute("SELECT * FROM owners WHERE id=?", (oid,)).fetchone()
    con.close()
    return dict(r) if r else None


def owners():
    con = connect()
    rows = [dict(r) for r in con.execute("SELECT * FROM owners ORDER BY id DESC")]
    for o in rows:
        o["n_biz"] = con.execute("SELECT COUNT(*) c FROM businesses WHERE owner_id=?",
                                 (o["id"],)).fetchone()["c"]
    con.close()
    return rows


def delete_owner(oid):
    """Remove an account without touching their shops.

    Databases migrated from an early build have `owner_id` without an
    ON DELETE clause, so a plain DELETE trips the foreign key. Detach the
    businesses first and the operation is safe on every schema version.
    """
    con = connect()
    con.execute("UPDATE businesses SET owner_id=NULL WHERE owner_id=?", (oid,))
    con.execute("DELETE FROM claims WHERE owner_id=?", (oid,))
    con.execute("DELETE FROM sessions WHERE owner_id=?", (oid,))
    con.execute("UPDATE edits SET owner_id=NULL WHERE owner_id=?", (oid,))
    con.execute("DELETE FROM owners WHERE id=?", (oid,))
    con.commit()
    con.close()
    return True


def set_owner_status(oid, status):
    con = connect()
    con.execute("UPDATE owners SET status=? WHERE id=?", (status, oid))
    con.commit()
    con.close()


# ---------------------------------------------------------------- OTP
OTP_TTL = 180          # seconds a code stays valid
OTP_MAX_TRIES = 5


def otp_issue(phone):
    """Create (or reuse) a code. Returns (code, seconds_left, throttled)."""
    phone = norm_phone(phone)
    now = time.time()
    con = connect()
    con.execute("DELETE FROM otp WHERE expires < ?", (now,))
    row = con.execute("SELECT * FROM otp WHERE phone=?", (phone,)).fetchone()
    if row:
        # still valid -> do not send a second SMS, just report the wait
        con.close()
        return row["code"], int(row["expires"] - now), True
    code = "".join(secrets.choice("0123456789") for _ in range(5))
    con.execute("INSERT INTO otp(phone,code,tries,expires) VALUES(?,?,0,?)",
                (phone, code, now + OTP_TTL))
    con.commit()
    con.close()
    return code, OTP_TTL, False


def otp_check(phone, code):
    """-> (ok, message)"""
    phone = norm_phone(phone)
    now = time.time()
    con = connect()
    row = con.execute("SELECT * FROM otp WHERE phone=?", (phone,)).fetchone()
    if not row or row["expires"] < now:
        con.close()
        return False, "کد منقضی شده است. دوباره درخواست دهید."
    if row["tries"] >= OTP_MAX_TRIES:
        con.execute("DELETE FROM otp WHERE phone=?", (phone,))
        con.commit(); con.close()
        return False, "تعداد تلاش بیش از حد. دوباره درخواست دهید."
    if str(row["code"]) != str(code).strip():
        con.execute("UPDATE otp SET tries=tries+1 WHERE phone=?", (phone,))
        con.commit(); con.close()
        return False, "کد واردشده درست نیست."
    con.execute("DELETE FROM otp WHERE phone=?", (phone,))
    con.commit()
    con.close()
    return True, "ok"


# ---------------------------------------------------------------- sessions
SESSION_TTL = 60 * 60 * 24 * 30       # 30 days


def session_new(owner_id):
    tok = secrets.token_urlsafe(24)
    con = connect()
    con.execute("DELETE FROM sessions WHERE expires < ?", (time.time(),))
    con.execute("INSERT INTO sessions(token,owner_id,expires) VALUES(?,?,?)",
                (tok, owner_id, time.time() + SESSION_TTL))
    con.execute("UPDATE owners SET last_login=datetime('now') WHERE id=?", (owner_id,))
    con.commit()
    con.close()
    return tok


def session_owner(token):
    if not token:
        return None
    con = connect()
    r = con.execute(
        "SELECT o.* FROM sessions s JOIN owners o ON o.id=s.owner_id "
        "WHERE s.token=? AND s.expires > ?", (token, time.time())).fetchone()
    con.close()
    if not r:
        return None
    d = dict(r)
    return None if d.get("status") == "blocked" else d


def session_kill(token):
    con = connect()
    con.execute("DELETE FROM sessions WHERE token=?", (token,))
    con.commit()
    con.close()


# ==========================================================================
#  OWNERSHIP  ·  CLAIMS
# ==========================================================================
def businesses_of(owner_id):
    """Every business owned by this account — including ones still waiting
    for admin approval, so the owner can see their submission was received."""
    con = connect()
    rows = [_biz_row(r) for r in con.execute(
        "SELECT * FROM businesses WHERE owner_id=? ORDER BY id DESC", (owner_id,))]
    for b in rows:
        ag = con.execute("SELECT AVG(rating) a, COUNT(*) c FROM reviews "
                         "WHERE biz_id=? AND status='approved'", (b["id"],)).fetchone()
        b["rating"] = round(ag["a"], 1) if ag["a"] else 0
        b["nreviews"] = ag["c"]
    con.close()
    return rows


def owns(owner_id, biz_id):
    con = connect()
    r = con.execute("SELECT 1 FROM businesses WHERE id=? AND owner_id=?",
                    (biz_id, owner_id)).fetchone()
    con.close()
    return bool(r)


def set_business_owner(biz_id, owner_id):
    con = connect()
    con.execute("UPDATE businesses SET owner_id=? WHERE id=?", (owner_id, biz_id))
    con.commit()
    con.close()


def claim_add(biz_id, owner_id, note=""):
    con = connect()
    dup = con.execute("SELECT 1 FROM claims WHERE biz_id=? AND owner_id=? AND status='pending'",
                      (biz_id, owner_id)).fetchone()
    if dup:
        con.close()
        return False, "درخواست شما قبلاً ثبت شده و در حال بررسی است."
    taken = con.execute("SELECT owner_id FROM businesses WHERE id=?", (biz_id,)).fetchone()
    if taken and taken["owner_id"]:
        con.close()
        return False, "این کسب‌وکار قبلاً توسط مالک دیگری تأیید شده است."
    con.execute("INSERT INTO claims(biz_id,owner_id,note) VALUES(?,?,?)",
                (biz_id, owner_id, note))
    con.commit()
    con.close()
    return True, "درخواست شما ثبت شد و پس از بررسی اطلاع‌رسانی می‌شود."


def claims(status=None):
    con = connect()
    q = ("SELECT c.*, b.name bizname, b.slug bizslug, o.phone, o.name ownername "
         "FROM claims c JOIN businesses b ON b.id=c.biz_id "
         "JOIN owners o ON o.id=c.owner_id")
    p = []
    if status:
        q += " WHERE c.status=?"
        p.append(status)
    q += " ORDER BY c.id DESC"
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()
    return rows


def claim_decide(cid, approve):
    con = connect()
    r = con.execute("SELECT * FROM claims WHERE id=?", (cid,)).fetchone()
    if not r:
        con.close()
        return False
    if approve:
        con.execute("UPDATE businesses SET owner_id=? WHERE id=?", (r["owner_id"], r["biz_id"]))
        con.execute("UPDATE claims SET status='approved' WHERE id=?", (cid,))
        con.execute("UPDATE claims SET status='rejected' WHERE biz_id=? AND id<>? AND status='pending'",
                    (r["biz_id"], cid))
    else:
        con.execute("UPDATE claims SET status='rejected' WHERE id=?", (cid,))
    con.commit()
    con.close()
    return True


# ==========================================================================
#  ANALYTICS  (daily counters, tiny footprint)
# ==========================================================================
def track(biz_id, kind):
    if not biz_id:
        return
    day = datetime.date.today().isoformat()
    con = connect()
    con.execute("""INSERT INTO events(biz_id,kind,day,n) VALUES(?,?,?,1)
                   ON CONFLICT(biz_id,kind,day) DO UPDATE SET n = n + 1""",
                (biz_id, kind, day))
    con.commit()
    con.close()


def stats_for(biz_id, days=30):
    """Totals + a daily series ready to plot."""
    since = (datetime.date.today() - datetime.timedelta(days=days - 1)).isoformat()
    con = connect()
    tot = {r["kind"]: r["s"] for r in con.execute(
        "SELECT kind, SUM(n) s FROM events WHERE biz_id=? AND day>=? GROUP BY kind",
        (biz_id, since))}
    rows = {r["day"]: r["s"] for r in con.execute(
        "SELECT day, SUM(n) s FROM events WHERE biz_id=? AND kind='view' AND day>=? "
        "GROUP BY day", (biz_id, since))}
    con.close()
    series = []
    for i in range(days):
        d = (datetime.date.today() - datetime.timedelta(days=days - 1 - i)).isoformat()
        series.append((d, rows.get(d, 0)))
    return {
        "view": tot.get("view", 0), "phone": tot.get("phone", 0),
        "whatsapp": tot.get("whatsapp", 0), "route": tot.get("route", 0),
        "share": tot.get("share", 0), "series": series,
    }


def stats_totals(days=30):
    since = (datetime.date.today() - datetime.timedelta(days=days - 1)).isoformat()
    con = connect()
    tot = {r["kind"]: r["s"] for r in con.execute(
        "SELECT kind, SUM(n) s FROM events WHERE day>=? GROUP BY kind", (since,))}
    top = [dict(r) for r in con.execute(
        """SELECT b.name, b.slug, SUM(e.n) v FROM events e
           JOIN businesses b ON b.id=e.biz_id
           WHERE e.kind='view' AND e.day>=? GROUP BY e.biz_id
           ORDER BY v DESC LIMIT 8""", (since,))]
    con.close()
    tot["top"] = top
    return tot


# ==========================================================================
#  IMAGES
# ==========================================================================
def biz_images(biz_id):
    b = business(bid=biz_id)
    return b["images"] if b else []


def biz_images_set(biz_id, images):
    con = connect()
    con.execute("UPDATE businesses SET images=? WHERE id=?",
                (json.dumps(images, ensure_ascii=False), biz_id))
    con.commit()
    con.close()


# ==========================================================================
#  CATALOG  —  products, services, and custom/bespoke work
# ==========================================================================
KIND_LABEL = {"product": "محصول", "service": "خدمت", "custom": "کار سفارشی"}
PRICE_TYPE_LABEL = {"fixed": "قیمت ثابت", "from": "شروع از",
                    "call": "تماس بگیرید", "free": "رایگان"}


def item_price_text(it):
    """Human-readable price honouring the pricing mode."""
    pt = it.get("price_type") or "fixed"
    if pt == "call":
        return "قیمت با تماس"
    if pt == "free":
        return "رایگان"
    p = int(it.get("price") or 0)
    if p <= 0:
        return "قیمت با تماس"
    txt = fa_money(p) + " تومان"
    if it.get("unit"):
        txt += " / " + it["unit"]
    return ("از " + txt) if pt == "from" else txt


_FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹"


def fa_money(n):
    return f"{int(n):,}".replace(",", "٬").translate(
        str.maketrans("0123456789", _FA_DIGITS))


def parse_spec(raw):
    """«رنگ=قرمز؛ وزن=۲ کیلو» -> [(label, value), ...]

    Shopkeepers type this by hand on a phone, so accept both Persian and
    Latin separators and tolerate stray spaces."""
    out = []
    for part in re.split(r"[؛;\n]+", raw or ""):
        part = part.strip()
        if not part:
            continue
        if "=" in part:
            k, v = part.split("=", 1)
        elif ":" in part:
            k, v = part.split(":", 1)
        else:
            k, v = part, ""
        k, v = k.strip(), v.strip()
        if k:
            out.append((k, v))
    return out[:12]


def item_flags(d):
    """The little trust badges under a product — the thing Basalam and
    Digikala lean on hardest."""
    out = []
    if d.get("handmade"):
        out.append(("دست‌ساز", "award"))
    if d.get("returnable"):
        out.append(("قابل مرجوع", "refresh"))
    if d.get("warranty"):
        out.append((d["warranty"], "shield"))
    if d.get("prep_days"):
        out.append((f"آماده‌سازی {d['prep_days']}", "clock"))
    if d.get("delivery"):
        out.append((d["delivery"], "send"))
    return out


def bump_item_views(iid):
    _run("UPDATE items SET views=views+1 WHERE id=?", (iid,))


def _decorate_item(d):
    d["spec_list"] = parse_spec(d.get("spec"))
    d["flags"] = item_flags(d)
    """Attach everything the templates need, tolerating older rows."""
    try:
        imgs = json.loads(d.get("images") or "[]")
    except Exception:
        imgs = []
    if not imgs and d.get("image"):
        imgs = [d["image"]]
    d["image_list"] = imgs
    d["cover"] = imgs[0] if imgs else ""
    d["price_text"] = item_price_text(d)
    d["kind_label"] = KIND_LABEL.get(d.get("kind"), d.get("kind"))
    d["tag_list"] = [t.strip() for t in re.split(r"[،,]", d.get("tags") or "") if t.strip()]
    d["option_list"] = [t.strip() for t in re.split(r"[،,]", d.get("options") or "") if t.strip()]

    op = int(d.get("old_price") or 0)
    pr = int(d.get("price") or 0)
    d["has_discount"] = bool(op and pr and op > pr and d.get("price_type") in ("fixed", "from"))
    d["old_price_text"] = fa_money(op) + " تومان" if d["has_discount"] else ""
    d["discount_pct"] = round((op - pr) / op * 100) if d["has_discount"] else 0

    st = int(d.get("stock") if d.get("stock") is not None else -1)
    d["stock_tracked"] = st >= 0
    d["in_stock"] = (not d["stock_tracked"]) or st > 0
    return d


# ==========================================================================
#  LOCAL PRICE COMPARISON
#
#  Torob compares prices across national online shops. Nobody compares the
#  shops on your own street, because nobody has the data. A town directory
#  does — the same goods really are sold by several shops in one small place.
#
#  Matching is by normalised title, deliberately: shopkeepers will not type
#  barcodes or pick from a catalogue, but they do type the product name. The
#  normaliser folds Persian spelling variants, so «پنیر لیقوان» and
#  «پنیر لیقوان» with a different ZWNJ land in the same group.
#
#  Only 'product' items with a real fixed price take part. A service quoted
#  "from" or "on request" is not comparable and pretending otherwise would
#  produce a ranking that misleads.
# ==========================================================================
_PRICE_STOPWORDS = {
    "یک", "یه", "عدد", "بسته", "کیلو", "کیلویی", "گرم", "گرمی", "لیتر",
    "لیتری", "تایی", "عددی", "جعبه", "کارتن", "دانه", "کالای", "کالا",
    "محصول", "اصل", "اصلی", "درجه", "ویژه", "فروش", "قیمت", "تومان",
}


def price_key(title):
    """The grouping key two shops must agree on for a comparison to be fair.

    Filler words that shopkeepers sprinkle differently ('یک عدد', 'ویژه')
    are dropped, and the remaining words are sorted so word order does not
    split a group. Returns '' when nothing meaningful is left.
    """
    t = normalize_fa(title or "")
    t = re.sub(r"[^\w\s]", " ", t)
    words = [w for w in t.split() if w and w not in _PRICE_STOPWORDS]
    if not words:
        return ""
    return " ".join(sorted(words))


# --------------------------------------------------------------------------
#  v68: price memory + drop alerts (torob-style, stdlib-only)
# --------------------------------------------------------------------------
def _log_price(iid, price):
    con = connect()
    con.execute("INSERT INTO price_history(item_id, price, ts) VALUES(?,?,?)",
                (iid, int(price or 0), time.time()))
    # keep the trail short — 60 points is plenty for a sparkline
    con.execute("DELETE FROM price_history WHERE item_id=? AND ts NOT IN "
                "(SELECT ts FROM price_history WHERE item_id=? "
                " ORDER BY ts DESC LIMIT 60)", (iid, iid))
    con.commit()
    con.close()


def price_history(iid, n=24):
    con = connect()
    rows = con.execute("SELECT price, ts FROM price_history WHERE item_id=? "
                       "ORDER BY ts DESC LIMIT ?", (iid, n)).fetchall()
    con.close()
    return [(r["price"], r["ts"]) for r in reversed(rows)]


def price_trend(iid):
    """Percent change first->last over the stored trail; None when <2 pts."""
    h = price_history(iid)
    if len(h) < 2 or not h[0][0]:
        return None
    return round((h[-1][0] - h[0][0]) / h[0][0] * 100)


def sparkline_svg(values, w=132, h=34):
    """Dependency-free inline SVG polyline of a price trail."""
    if len(values) < 2:
        return ""
    lo, hi = min(values), max(values)
    span = (hi - lo) or 1
    pts = []
    for i, v in enumerate(values):
        x = round(i * (w - 4) / (len(values) - 1)) + 2
        y = round(h - 4 - (v - lo) * (h - 8) / span)
        pts.append(f"{x},{y}")
    col = "#2dd4bf" if values[-1] < values[0] else "#fb7185"
    return (f'<svg class="spark" viewBox="0 0 {w} {h}" width="{w}" height="{h}" '
            f'aria-hidden="true"><polyline points="{" ".join(pts)}" fill="none" '
            f'stroke="{col}" stroke-width="2" stroke-linecap="round" '
            f'stroke-linejoin="round"/></svg>')


def alert_set(customer_id, key, title="", on=True):
    con = connect()
    if on:
        con.execute("INSERT OR IGNORE INTO price_alerts(customer_id, group_key, title) "
                    "VALUES(?,?,?)", (customer_id, key, title))
    else:
        con.execute("DELETE FROM price_alerts WHERE customer_id=? AND group_key=?",
                    (customer_id, key))
    con.commit()
    con.close()


def alert_keys(customer_id):
    con = connect()
    rows = con.execute("SELECT group_key FROM price_alerts WHERE customer_id=?",
                       (customer_id,)).fetchall()
    con.close()
    return {r["group_key"] for r in rows}


def _fire_price_alerts(key, title, new_price, old_price):
    if not key:
        return
    con = connect()
    subs = con.execute("SELECT customer_id FROM price_alerts WHERE group_key=?",
                       (key,)).fetchall()
    if subs:
        drop_pct = round((old_price - new_price) / old_price * 100) if old_price else 0
        text = (f"قیمت «{title}» {_fa(drop_pct)}٪ ارزان‌تر شد: "
                f"{fa_money(new_price)} تومان")
        for s in subs:
            con.execute("INSERT INTO notifications(customer_id, kind, text, link) "
                        "VALUES(?,?,?,?)",
                        (s["customer_id"], "info", text, f"/prices?key={key}"))
        con.execute("DELETE FROM price_alerts WHERE group_key=?", (key,))
        con.commit()
    con.close()


def comparable_items(min_shops=2, cat=None, term=""):
    """Group products sold by more than one shop, cheapest first.

    Returns a list of groups:
      {key, title, n, min, max, spread, spread_pct, offers[...]}
    where each offer carries the shop, its price and how far above the
    cheapest it sits.
    """
    con = connect()
    q = ("SELECT i.*, b.name bizname, b.slug bizslug, b.cat_slug, b.status "
         "FROM items i JOIN businesses b ON b.id=i.biz_id "
         "WHERE b.status='published' AND i.available=1 AND i.kind='product' "
         "AND i.price_type='fixed' AND i.price > 0")
    p = []
    if cat:
        fam = category_family(cat)
        q += " AND b.cat_slug IN (%s)" % ",".join("?" * len(fam))
        p.extend(fam)
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()

    if term:
        t = normalize_fa(term)
        rows = [r for r in rows if t in normalize_fa(r["title"])]

    groups = {}
    for r in rows:
        k = price_key(r["title"])
        if not k:
            continue
        groups.setdefault(k, []).append(r)

    out = []
    for k, offers in groups.items():
        # one shop listing the same thing twice is not a comparison
        if len({o["biz_id"] for o in offers}) < min_shops:
            continue
        best_per_shop = {}
        for o in offers:
            cur = best_per_shop.get(o["biz_id"])
            if cur is None or o["price"] < cur["price"]:
                best_per_shop[o["biz_id"]] = o
        offers = sorted(best_per_shop.values(), key=lambda o: o["price"])

        lo = offers[0]["price"]
        hi = offers[-1]["price"]
        for o in offers:
            o["over_min"] = o["price"] - lo
            o["over_pct"] = round((o["price"] - lo) / lo * 100) if lo else 0
            o["is_cheapest"] = o["price"] == lo
            o["price_text"] = fa_money(o["price"]) + " تومان"
        out.append({
            "key": k,
            # the longest title reads best as a heading; the short ones are
            # usually abbreviations of the same thing
            "title": max((o["title"] for o in offers), key=len),
            "n": len(offers),
            "min": lo, "max": hi,
            "min_text": fa_money(lo) + " تومان",
            "max_text": fa_money(hi) + " تومان",
            "spread": hi - lo,
            "spread_text": fa_money(hi - lo) + " تومان",
            "spread_pct": round((hi - lo) / lo * 100) if lo else 0,
            "unit": offers[0].get("unit") or "",
            "offers": offers,
        })

    # biggest saving first — that is the number a shopper cares about
    out.sort(key=lambda g: (-g["spread"], -g["n"]))
    return out


def price_group(key):
    """One comparison group by its key, or None."""
    for g in comparable_items():
        if g["key"] == key:
            return g
    return None


def price_stats():
    groups = comparable_items()
    return {
        "groups": len(groups),
        "offers": sum(g["n"] for g in groups),
        "best_saving": max((g["spread"] for g in groups), default=0),
        "best_saving_text": fa_money(max((g["spread"] for g in groups),
                                         default=0)) + " تومان",
    }


def items(biz_id=None, kind=None, only_available=False):
    con = connect()
    q = ("SELECT i.*, b.name bizname, b.slug bizslug FROM items i "
         "JOIN businesses b ON b.id=i.biz_id WHERE 1=1")
    p = []
    if biz_id:
        q += " AND i.biz_id=?"; p.append(biz_id)
    if kind:
        q += " AND i.kind=?"; p.append(kind)
    if only_available:
        q += " AND i.available=1"
    q += " ORDER BY i.featured DESC, i.sort, i.id DESC"
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()
    return [_decorate_item(r) for r in rows]


# ==========================================================================
#  چانه‌زنی — structured haggling
#
#  The rules encoded here are the ones a bazaar already runs on:
#   · the shopkeeper opts in per product, and sets a private floor
#   · an offer at or above the floor can be accepted instantly, which is
#     what makes this worth a shopkeeper's time
#   · an offer below the floor is not rejected outright — it is countered,
#     because "no" ends a sale and a counter-price continues it
#   · every round is a row, so nobody can quietly change an earlier number
#   · offers expire, so a shopkeeper is not held to last month's price
# ==========================================================================
HAGGLE_TTL_HOURS = 48
HAGGLE_MAX_ROUNDS = 6


def haggle_settings():
    s = get_settings()
    def _i(k, d):
        try:
            return int(s.get(k, d))
        except Exception:
            return d
    return {
        # v65: haggling is OFF by default — the owner turns it on from the
        # panel when they actually want it. Nothing is deleted, the UI just
        # stops offering it until it is enabled again.
        "enabled": s.get("haggle_enabled", "0") == "1",
        "ttl": _i("haggle_ttl_hours", HAGGLE_TTL_HOURS),
        "max_rounds": _i("haggle_max_rounds", HAGGLE_MAX_ROUNDS),
        "min_pct": _i("haggle_min_pct", 50),   # refuse insulting lowballs
    }


def haggle_allowed(it):
    """Is this product open to offers? Needs a real price to haggle against."""
    if not it:
        return False
    if not haggle_settings()["enabled"]:
        return False
    return bool(it.get("haggle")) and it.get("price_type") == "fixed" \
        and int(it.get("price") or 0) > 0 and int(it.get("available") or 0) == 1


def _haggle_row(r):
    d = dict(r)
    d["offer_text"] = fa_money(d.get("offer") or 0) + " تومان"
    d["is_buyer"] = d.get("side") == "buyer"
    return d


def haggle_thread(token=None, root_id=None):
    """A whole negotiation, oldest first."""
    con = connect()
    if token:
        root = con.execute("SELECT * FROM haggles WHERE token=? AND parent IS NULL",
                           (token,)).fetchone()
    else:
        root = con.execute("SELECT * FROM haggles WHERE id=?", (root_id,)).fetchone()
    if not root:
        con.close()
        return []
    rows = [dict(root)]
    frontier = [root["id"]]
    seen = {root["id"]}
    while frontier:
        marks = ",".join("?" * len(frontier))
        kids = con.execute(
            f"SELECT * FROM haggles WHERE parent IN ({marks}) ORDER BY id", frontier).fetchall()
        frontier = []
        for k in kids:
            if k["id"] in seen:
                continue
            seen.add(k["id"])
            rows.append(dict(k))
            frontier.append(k["id"])
    con.close()
    rows.sort(key=lambda r: r["id"])
    return [_haggle_row(r) for r in rows]


def haggles(biz_id=None, status=None, item_id=None, roots_only=True):
    con = connect()
    q = ("SELECT h.*, b.name bizname, b.slug bizslug, i.title itemtitle, "
         "i.price itemprice, i.floor_price "
         "FROM haggles h JOIN businesses b ON b.id=h.biz_id "
         "LEFT JOIN items i ON i.id=h.item_id WHERE 1=1")
    p = []
    if biz_id:
        q += " AND h.biz_id=?"; p.append(biz_id)
    if item_id:
        q += " AND h.item_id=?"; p.append(item_id)
    if status:
        q += " AND h.status=?"; p.append(status)
    if roots_only:
        q += " AND h.parent IS NULL"
    q += " ORDER BY h.id DESC"
    rows = [_haggle_row(r) for r in con.execute(q, p)]
    con.close()
    return rows


def haggle(hid):
    con = connect()
    r = con.execute(
        "SELECT h.*, b.name bizname, b.slug bizslug, b.owner_id, "
        "i.title itemtitle, i.price itemprice, i.floor_price "
        "FROM haggles h JOIN businesses b ON b.id=h.biz_id "
        "LEFT JOIN items i ON i.id=h.item_id WHERE h.id=?", (hid,)).fetchone()
    con.close()
    return _haggle_row(r) if r else None


def expire_haggles():
    """Offers past their window stop being binding."""
    con = connect()
    con.execute("UPDATE haggles SET status='expired' "
                "WHERE status IN ('open','countered') AND expires<>'' "
                "AND expires < datetime('now')")
    n = con.total_changes
    con.commit()
    con.close()
    return n


def make_offer(biz_id, item_id, name, phone, offer, qty=1, note="",
               parent=None, side="buyer"):
    """Record one round. Returns (id, token, verdict) where verdict is what
    the system did automatically: 'accepted', 'countered' or 'pending'.

    The auto-accept is the point of the whole feature. A shopkeeper who has
    already said "I'll take 90,000 for this" should not have to be at their
    phone for the sale to happen.
    """
    cfg = haggle_settings()
    it = item(item_id) if item_id else None
    offer = int(offer or 0)

    token = secrets.token_urlsafe(12) if parent is None else ""
    if parent is not None:
        root = haggle(parent)
        while root and root.get("parent"):
            root = haggle(root["parent"])
        token = (root or {}).get("token", "")

    expires = None
    con = connect()
    cur = con.execute(
        "INSERT INTO haggles(biz_id,item_id,parent,side,name,phone,offer,qty,note,"
        "token,expires) VALUES(?,?,?,?,?,?,?,?,?,?,"
        "datetime('now', ?))",
        (biz_id, item_id or None, parent, side, name, phone, offer,
         max(1, int(qty or 1)), note, token, f"+{cfg['ttl']} hours"))
    hid = cur.lastrowid
    con.commit()
    con.close()

    verdict = "pending"
    if side == "buyer" and it:
        floor = int(it.get("floor_price") or 0)
        listed = int(it.get("price") or 0)
        if floor and offer >= floor:
            set_haggle_status(hid, "accepted")
            verdict = "accepted"
        elif floor and listed and offer < listed * cfg["min_pct"] / 100:
            # too low to be a serious offer; counter at the floor rather than
            # slam the door — a counter keeps the conversation alive
            set_haggle_status(hid, "countered")
            make_offer(biz_id, item_id, "", "", floor, qty,
                       "پیشنهاد فروشنده (خودکار): کمترین قیمت ممکن برای این کالا.",
                       parent=hid, side="seller")
            verdict = "countered"

    log("haggle.offer", f"biz {biz_id} item {item_id}: {offer} -> {verdict}")
    return hid, token, verdict


def set_haggle_status(hid, status):
    con = connect()
    con.execute("UPDATE haggles SET status=? WHERE id=?", (status, hid))
    con.commit()
    con.close()
    log("haggle.status", f"{hid}: {status}")


def haggle_stats(biz_id=None):
    con = connect()
    q = "SELECT status, COUNT(*) c FROM haggles WHERE parent IS NULL"
    p = []
    if biz_id:
        q += " AND biz_id=?"; p.append(biz_id)
    q += " GROUP BY status"
    by = {r["status"]: r["c"] for r in con.execute(q, p)}
    con.close()
    total = sum(by.values())
    won = by.get("accepted", 0)
    return {"total": total, "open": by.get("open", 0),
            "countered": by.get("countered", 0), "accepted": won,
            "declined": by.get("declined", 0), "expired": by.get("expired", 0),
            "rate": round(won / total * 100) if total else 0}


def item(iid):
    con = connect()
    r = con.execute("SELECT i.*, b.name bizname, b.slug bizslug, b.owner_id "
                    "FROM items i JOIN businesses b ON b.id=i.biz_id "
                    "WHERE i.id=?", (iid,)).fetchone()
    con.close()
    if not r:
        return None
    return _decorate_item(dict(r))


def save_item(data, iid=None):
    fields = ("biz_id", "kind", "title", "descr", "price", "price_type",
              "unit", "duration", "image", "images", "old_price", "stock",
              "code", "min_order", "options", "note",
              "brand", "warranty", "prep_days", "delivery", "handmade",
              "returnable", "bulk_price", "video", "spec", "weight",
              "haggle", "floor_price",
              "tags", "available", "featured", "sort")
    vals = {}
    for f in fields:
        if f not in data:
            continue
        v = data[f]
        if f in ("available", "featured", "handmade", "returnable", "haggle"):
            v = int(bool(int(v or 0)))
        elif f in ("price", "sort", "biz_id", "old_price", "floor_price"):
            v = int(re.sub(r"[^\d]", "", str(v) or "0") or 0)
        elif f == "stock":
            raw = str(v).strip()
            v = -1 if raw == "" else int(re.sub(r"[^\d]", "", raw) or 0)
        elif f == "images" and not isinstance(v, str):
            v = json.dumps(v, ensure_ascii=False)
        vals[f] = v
    old_price = None
    if iid:
        con = connect()
        row = con.execute("SELECT price, title FROM items WHERE id=?", (iid,)).fetchone()
        old_price = row["price"] if row else None
        title = row["title"] if row else ""
        con.close()
    con = connect()
    if iid:
        sets = ", ".join(f"{k}=?" for k in vals)
        con.execute(f"UPDATE items SET {sets} WHERE id=?", list(vals.values()) + [iid])
    else:
        cols = ", ".join(vals)
        qs = ", ".join("?" * len(vals))
        con.execute(f"INSERT INTO items({cols}) VALUES({qs})", list(vals.values()))
        iid = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
        title = vals.get("title", "")
    con.commit()
    con.close()
    # v68: price memory + drop alerts (torob-style)
    new_price = vals.get("price")
    if new_price is not None:
        if old_price is None:
            _log_price(iid, new_price)          # first sighting
        elif new_price != old_price:
            _log_price(iid, new_price)
            if new_price < old_price and title:
                _fire_price_alerts(price_key(title), title, new_price, old_price)
    return iid


def delete_item(iid):
    row = _one("SELECT * FROM items WHERE id=?", (iid,))
    if row:
        trash_put("item", iid, row["biz_id"], row["title"] or "", dict(row))
    con = connect()
    con.execute("DELETE FROM items WHERE id=?", (iid,))
    con.commit()
    con.close()


def items_count(biz_id):
    con = connect()
    n = con.execute("SELECT COUNT(*) c FROM items WHERE biz_id=?", (biz_id,)).fetchone()["c"]
    con.close()
    return n


def search_items(term="", kind=""):
    rows = items(kind=kind or None, only_available=True)
    if term:
        t = normalize_fa(term)
        rows = [r for r in rows
                if t in normalize_fa(f"{r['title']} {r['descr']} {r['tags']} {r['bizname']}")]
    return rows


# ---------------------------------------------------------------- inquiries
def inquiries(biz_id=None, status=None):
    con = connect()
    q = ("SELECT q.*, b.name bizname, b.slug bizslug, i.title itemtitle "
         "FROM inquiries q JOIN businesses b ON b.id=q.biz_id "
         "LEFT JOIN items i ON i.id=q.item_id WHERE 1=1")
    p = []
    if biz_id:
        q += " AND q.biz_id=?"; p.append(biz_id)
    if status:
        q += " AND q.status=?"; p.append(status)
    q += " ORDER BY q.id DESC"
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()
    return rows


def inquiry(qid):
    """Single inquiry row (id -> biz_id), so access checks are one lookup."""
    con = connect()
    r = con.execute("SELECT * FROM inquiries WHERE id=?", (qid,)).fetchone()
    con.close()
    return dict(r) if r else None


def add_inquiry(biz_id, name, phone="", body="", item_id=None, budget=""):
    con = connect()
    con.execute("""INSERT INTO inquiries(biz_id,item_id,name,phone,body,budget)
                   VALUES(?,?,?,?,?,?)""",
                (biz_id, item_id or None, name, phone or "", body, budget))
    con.commit()
    con.close()


def update_inquiry(qid, **kw):
    if not kw:
        return
    con = connect()
    sets = ", ".join(f"{k}=?" for k in kw)
    con.execute(f"UPDATE inquiries SET {sets} WHERE id=?", list(kw.values()) + [qid])
    con.commit()
    con.close()


def delete_inquiry(qid):
    con = connect()
    con.execute("DELETE FROM inquiries WHERE id=?", (qid,))
    con.commit()
    con.close()


def item_images(iid):
    it = item(iid)
    return it["image_list"] if it else []


def item_images_set(iid, images):
    con = connect()
    con.execute("UPDATE items SET images=?, image=? WHERE id=?",
                (json.dumps(images, ensure_ascii=False),
                 images[0] if images else "", iid))
    con.commit()
    con.close()


# ==========================================================================
#  DUPLICATE DETECTION
#  Warn the applicant *while they type* that a business already exists,
#  so the same shop is not submitted over and over.
# ==========================================================================
def _digits_only(v):
    return re.sub(r"\D", "", translit(str(v or "")))


# Words that appear in half the shop names in town. Counting them as a match
# made "نانوایی سحر" look like "نانوایی رضا", so they are ignored when there
# is anything distinctive left to compare.
_STOPWORDS = {
    "فروشگاه", "فروشگاهی", "شرکت", "گروه", "مرکز", "مجتمع", "بازار", "بازارچه",
    "شعبه", "نمایندگی", "کارگاه", "خدمات", "تولیدی", "صنایع", "بنگاه",
    "سوپر", "سوپرمارکت", "رستوران", "کافه", "قنادی", "نانوایی", "تعمیرگاه",
    "املاک", "داروخانه", "آرایشگاه", "پیرایش", "کلینیک", "مطب", "دفتر",
    "نجف", "نجفاباد", "اباد", "ایران", "اصفهان", "شهر", "و", "در", "با",
}


def _sim(a, b):
    """
    Token similarity tolerant of Persian spelling, 0..1.
    Uses the *smaller* token set as the denominator so that
    «سوپرمارکت ولیعصر شعبه دو» still matches «سوپرمارکت ولیعصر».
    """
    ta = {t for t in normalize_fa(a).split() if len(t) > 1}
    tb = {t for t in normalize_fa(b).split() if len(t) > 1}
    if not ta or not tb:
        return 0.0
    # Drop the generic words, but only while a distinctive part survives on
    # both sides — otherwise «نانوایی» vs «نانوایی» would score zero.
    sa, sb = ta - _STOPWORDS, tb - _STOPWORDS
    if sa and sb:
        ta, tb = sa, sb
    return len(ta & tb) / min(len(ta), len(tb))


def find_duplicates(name="", phone="", address="", exclude_id=None):
    """
    Return [{business, reason, field, strength}] for anything that looks like
    the same shop. `strength` is 'exact' (block) or 'maybe' (warn).
    """
    con = connect()
    rows = [_biz_row(r) for r in con.execute("SELECT * FROM businesses")]
    con.close()

    nname = normalize_fa(name)
    nphone = _digits_only(phone)
    naddr = normalize_fa(address)

    out = []
    for b in rows:
        if exclude_id and b["id"] == exclude_id:
            continue

        # Report EVERY field that matches, so the warning appears under each
        # one the applicant is typing in — not just the first hit.
        matches = []
        if nphone and len(nphone) >= 7:
            if _digits_only(b.get("phone")) == nphone:
                matches.append(("این شمارهٔ تماس قبلاً ثبت شده است.", "phone", "exact"))
            elif _digits_only(b.get("whatsapp")) == nphone:
                matches.append(("این شماره به‌عنوان واتساپ ثبت شده است.", "phone", "exact"))

        if nname:
            if normalize_fa(b["name"]) == nname:
                matches.append(("کسب‌وکاری دقیقاً با همین نام وجود دارد.", "name", "exact"))
            elif _sim(name, b["name"]) >= 0.75:
                matches.append(("نام بسیار شبیه یک کسب‌وکار ثبت‌شده است.", "name", "maybe"))

        if naddr and len(naddr) > 12 and _sim(address, b.get("address") or "") >= 0.7:
            matches.append(("نشانی بسیار شبیه یک کسب‌وکار ثبت‌شده است.", "address", "maybe"))

        for reason, field, strength in matches:
            out.append({
                "id": b["id"], "name": b["name"], "slug": b["slug"],
                "address": b.get("address") or "", "phone": b.get("phone") or "",
                "status": b["status"], "claimed": bool(b.get("owner_id")),
                "reason": reason, "field": field, "strength": strength,
            })

    out.sort(key=lambda x: 0 if x["strength"] == "exact" else 1)
    return out


def businesses_for_phone(phone):
    """Everything registered with this number — used to auto-link on login."""
    nphone = _digits_only(phone)
    if not nphone or len(nphone) < 7:
        return []
    con = connect()
    rows = [_biz_row(r) for r in con.execute("SELECT * FROM businesses")]
    con.close()
    return [b for b in rows
            if _digits_only(b.get("phone")) == nphone
            or _digits_only(b.get("whatsapp")) == nphone]


def link_orphans_to_owner(owner_id, phone):
    """
    When someone logs in, attach any unclaimed business submitted with their
    phone number. This is what makes 'I registered but see nothing' go away.
    """
    linked = 0
    con = connect()
    for b in businesses_for_phone(phone):
        if not b.get("owner_id"):
            con.execute("UPDATE businesses SET owner_id=? WHERE id=?", (owner_id, b["id"]))
            linked += 1
    con.commit()
    con.close()
    return linked


# ==========================================================================
#  ADMIN LISTING  —  search + sort + pagination
# ==========================================================================
def admin_businesses(q="", status="", cat="", page=1, per=25, sort="newest"):
    """Server-side search/filter/paging so the panel stays fast at scale."""
    con = connect()
    where, params = ["1=1"], []
    if status:
        where.append("b.status=?"); params.append(status)
    if cat:
        fam = category_family(cat)
        where.append("b.cat_slug IN (%s)" % ",".join("?" * len(fam)))
        params.extend(fam)

    sql_from = "FROM businesses b WHERE " + " AND ".join(where)
    rows = [_biz_row(r) for r in con.execute(f"SELECT b.* {sql_from}", params)]

    if q:
        t = normalize_fa(q)
        rows = [r for r in rows if t in normalize_fa(
            f"{r['name']} {r.get('descr','')} {r.get('address','')} "
            f"{r.get('phone','')} {r.get('tags','')}")]

    for r in rows:
        ag = con.execute("SELECT AVG(rating) a, COUNT(*) c FROM reviews "
                         "WHERE biz_id=? AND status='approved'", (r["id"],)).fetchone()
        r["rating"] = round(ag["a"], 1) if ag["a"] else 0
        r["nreviews"] = ag["c"]
    con.close()

    keys = {
        "newest": lambda r: -r["id"],
        "oldest": lambda r: r["id"],
        "name":   lambda r: r["name"] or "",
        "views":  lambda r: -(r["views"] or 0),
        "rating": lambda r: -(r["rating"] or 0),
    }
    rows.sort(key=keys.get(sort, keys["newest"]))

    total = len(rows)
    pages = max(1, (total + per - 1) // per)
    page = max(1, min(page, pages))
    start = (page - 1) * per
    return {"rows": rows[start:start + per], "total": total,
            "page": page, "pages": pages, "per": per}


def bulk_business(ids, action, value=""):
    """Apply one action to many businesses at once."""
    if not ids:
        return 0
    con = connect()
    marks = ",".join("?" * len(ids))
    n = 0
    if action == "status" and value in ("published", "pending", "hidden", "rejected"):
        con.execute(f"UPDATE businesses SET status=? WHERE id IN ({marks})",
                    [value] + list(ids))
        n = len(ids)
    elif action in ("featured", "verified"):
        con.execute(f"UPDATE businesses SET {action}=? WHERE id IN ({marks})",
                    [1 if value == "1" else 0] + list(ids))
        n = len(ids)
    elif action == "category" and value:
        con.execute(f"UPDATE businesses SET cat_slug=? WHERE id IN ({marks})",
                    [value] + list(ids))
        n = len(ids)
    elif action == "delete":
        con.execute(f"DELETE FROM businesses WHERE id IN ({marks})", list(ids))
        n = len(ids)
    con.commit()
    con.close()
    return n


# ---------------------------------------------------------------- CSV
CSV_COLUMNS = ["name", "cat_slug", "descr", "phone", "whatsapp", "address",
               "lat", "lng", "tags", "instagram", "telegram", "website",
               "status", "featured", "verified"]


def _csv_cell(v):
    """Neutralise spreadsheet formula injection. A cell whose first character
    makes Excel/Sheets treat it as a formula (= + - @ tab CR) is prefixed with
    a single quote so it stays inert text. (Security fix.)"""
    s = "" if v is None else str(v)
    if s and (s[0] in ("=", "+", "-", "@") or s[0] in ("\t", "\r", "\n")):
        return "'" + s
    return s


def export_csv():
    import csv, io
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(CSV_COLUMNS)
    for b in businesses(status=None, order="newest"):
        w.writerow([_csv_cell(b.get(c, "")) for c in CSV_COLUMNS])
    return "\ufeff" + buf.getvalue()          # BOM so Excel reads Persian


# ==========================================================================
#  TICKETS  --  two-way support conversations
#
#  The old contact form posted into a void: no status, no reply, no thread.
#  A shopkeeper who had paid and was waiting for a feature to be unlocked
#  had no way to ask "did you get my money?" except phoning. That is the
#  single most common real question this directory will receive, so it
#  deserves a real inbox on both sides.
# ==========================================================================
TICKET_TOPICS = [
    ("payment", "پرداخت و اشتراک"),
    ("unlock",  "باز کردن قابلیت"),
    ("edit",    "ویرایش اطلاعات کسب‌وکار"),
    ("bug",     "مشکل فنی سایت"),
    ("other",   "موضوع دیگر"),
]
TICKET_STATUS = {
    "open":     ("badge-warn",    "باز — در انتظار پاسخ"),
    "answered": ("badge-info",    "پاسخ داده شد"),
    "waiting":  ("badge-neutral", "در انتظار شما"),
    "closed":   ("badge-open",    "بسته شد"),
}
TICKET_PRIORITY = {"low": "کم", "normal": "عادی", "high": "فوری"}


def _ticket_row(r):
    d = dict(r)
    d["topic_label"] = dict(TICKET_TOPICS).get(d.get("topic"), d.get("topic"))
    cls, lbl = TICKET_STATUS.get(d.get("status"), ("badge-neutral", d.get("status")))
    d["status_cls"], d["status_label"] = cls, lbl
    d["priority_label"] = TICKET_PRIORITY.get(d.get("priority"), d.get("priority"))
    return d


def create_ticket(subject, body, name="", phone="", owner_id=None,
                  biz_id=None, topic="other", priority="normal", attachment=None):
    """Open a ticket and store its first text and/or private attachment."""
    text = (body or "").strip()
    if not text and not attachment:
        return None, None
    token = secrets.token_urlsafe(12)
    con = connect()
    try:
        cur = con.execute(
            "INSERT INTO tickets(owner_id,biz_id,name,phone,subject,topic,priority,token) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (owner_id,biz_id,name,phone,subject.strip()[:160],topic,priority,token))
        tid=cur.lastrowid
        cur=con.execute("INSERT INTO ticket_msgs(ticket_id,side,body) VALUES(?,'user',?)",(tid,text))
        mid=cur.lastrowid
        if attachment:
            con.execute("INSERT INTO ticket_attachments(msg_id,stored_name,original_name,mime,size,kind) VALUES(?,?,?,?,?,?)",
                        (mid,attachment['stored_name'],attachment['original_name'][:120],attachment['mime'],int(attachment['size']),attachment['kind']))
        con.commit()
    except Exception:
        con.rollback(); con.close(); return None,None
    con.close(); log("ticket.new",f"{tid}: {subject[:50]}"); return tid,token


def ticket(tid=None, token=None):
    con = connect()
    if token:
        r = con.execute(
            "SELECT t.*, b.name bizname, b.slug bizslug, o.phone ownerphone "
            "FROM tickets t LEFT JOIN businesses b ON b.id=t.biz_id "
            "LEFT JOIN owners o ON o.id=t.owner_id WHERE t.token=?",
            (token,)).fetchone()
    else:
        r = con.execute(
            "SELECT t.*, b.name bizname, b.slug bizslug, o.phone ownerphone "
            "FROM tickets t LEFT JOIN businesses b ON b.id=t.biz_id "
            "LEFT JOIN owners o ON o.id=t.owner_id WHERE t.id=?",
            (tid,)).fetchone()
    con.close()
    return _ticket_row(r) if r else None


def tickets(owner_id=None, status=None, topic=None, q=""):
    con = connect()
    sql = ("SELECT t.*, b.name bizname, "
           "(SELECT COUNT(*) FROM ticket_msgs WHERE ticket_id=t.id) nmsg "
           "FROM tickets t LEFT JOIN businesses b ON b.id=t.biz_id WHERE 1=1")
    p = []
    if owner_id:
        sql += " AND t.owner_id=?"; p.append(owner_id)
    if status:
        sql += " AND t.status=?"; p.append(status)
    if topic:
        sql += " AND t.topic=?"; p.append(topic)
    # open first, then most recently touched
    sql += (" ORDER BY CASE t.status WHEN 'open' THEN 0 WHEN 'waiting' THEN 1 "
            "WHEN 'answered' THEN 2 ELSE 3 END, t.updated DESC")
    rows = [_ticket_row(r) for r in con.execute(sql, p)]
    con.close()
    if q:
        nq = normalize_fa(q)
        rows = [r for r in rows
                if nq in normalize_fa(f"{r['subject']} {r.get('name','')} "
                                      f"{r.get('phone','')} {r.get('bizname') or ''}")]
    return rows


def ticket_msgs(tid):
    con=connect(); rows=[dict(r) for r in con.execute(
      "SELECT m.*,a.id attachment_id,a.original_name file_name,a.mime file_type,a.size file_size,a.kind file_kind "
      "FROM ticket_msgs m LEFT JOIN ticket_attachments a ON a.msg_id=m.id WHERE m.ticket_id=? ORDER BY m.id",(tid,))];con.close();return rows


def ticket_attachment(aid):
    con=connect();r=con.execute("SELECT a.*,m.ticket_id,t.owner_id,t.token FROM ticket_attachments a JOIN ticket_msgs m ON m.id=a.msg_id JOIN tickets t ON t.id=m.ticket_id WHERE a.id=?",(aid,)).fetchone();con.close();return dict(r) if r else None


def ticket_attachment_names():
    con=connect();rows=[r['stored_name'] for r in con.execute("SELECT stored_name FROM ticket_attachments")];con.close();return rows


def ticket_reply(tid, body, side="admin", attachment=None):
    """Add text/file; return message id. The other side receives unread."""
    text=(body or '').strip()
    if not text and not attachment:return False
    con=connect()
    try:
        cur=con.execute("INSERT INTO ticket_msgs(ticket_id,side,body) VALUES(?,?,?)",(tid,side,text));mid=cur.lastrowid
        if attachment:
            con.execute("INSERT INTO ticket_attachments(msg_id,stored_name,original_name,mime,size,kind) VALUES(?,?,?,?,?,?)",
                        (mid,attachment['stored_name'],attachment['original_name'][:120],attachment['mime'],int(attachment['size']),attachment['kind']))
        if side=='admin': con.execute("UPDATE tickets SET status='answered',unread_user=1,unread_admin=0,updated=datetime('now') WHERE id=?",(tid,))
        else: con.execute("UPDATE tickets SET status='open',unread_admin=1,unread_user=0,updated=datetime('now') WHERE id=?",(tid,))
        con.commit()
    except Exception: con.rollback();con.close();return False
    con.close();log('ticket.reply',f'{tid} by {side}');return mid


def set_ticket(tid, **kw):
    fields = {k: v for k, v in kw.items()
              if k in ("status", "priority", "topic", "unread_admin", "unread_user")}
    if not fields:
        return
    con = connect()
    sets = ", ".join(f"{k}=?" for k in fields)
    con.execute(f"UPDATE tickets SET {sets}, updated=datetime('now') WHERE id=?",
                list(fields.values()) + [tid])
    con.commit()
    con.close()


def delete_ticket(tid):
    con = connect()
    con.execute("DELETE FROM ticket_msgs WHERE ticket_id=?", (tid,))
    con.execute("DELETE FROM tickets WHERE id=?", (tid,))
    con.commit()
    con.close()
    log("ticket.delete", str(tid))


def ticket_stats():
    con = connect()
    by = {r["status"]: r["c"] for r in con.execute(
        "SELECT status, COUNT(*) c FROM tickets GROUP BY status")}
    unread = con.execute(
        "SELECT COUNT(*) c FROM tickets WHERE unread_admin=1").fetchone()["c"]
    con.close()
    return {"total": sum(by.values()), "open": by.get("open", 0),
            "answered": by.get("answered", 0), "closed": by.get("closed", 0),
            "unread": unread}


# ==========================================================================
#  INBOX  --  everything that is waiting for the admin, in one place
#
#  Approvals were spread across nine separate pages: businesses, reviews,
#  questions, claims, edits, subscriptions, reports, messages, tickets. To
#  find out whether anything needed doing you had to visit all nine. That is
#  how a pending shop sits unapproved for a week and the shopkeeper decides
#  the site is dead.
#
#  Each entry carries a direct link, so the inbox is a to-do list, not just
#  a set of counters.
# ==========================================================================
def inbox(limit_each=8):
    """-> {'total': n, 'groups': [ {key,label,icon,n,href,items[]}, ... ]}"""
    g = []

    def add(key, label, icon_name, rows, href, fmt):
        rows = list(rows)
        if not rows:
            return
        g.append({
            "key": key, "label": label, "icon": icon_name,
            "n": len(rows), "href": href,
            "items": [fmt(r) for r in rows[:limit_each]],
        })

    add("business", "کسب‌وکار در انتظار تأیید", "store",
        businesses(status="pending"), "/panel/businesses?status=pending",
        lambda b: {"title": b["name"],
                   "sub": b.get("address") or b.get("phone") or "",
                   "when": str(b.get("created") or "")[:16],
                   "href": f"/panel/business/{b['id']}"})

    add("review", "نظر در انتظار بررسی", "message",
        reviews(status="pending"), "/panel/reviews",
        lambda r: {"title": f"{r['author']}: {r['body'][:48]}",
                   "sub": r.get("bizname") or "",
                   "when": str(r.get("created") or "")[:16],
                   "href": "/panel/reviews"})

    add("question", "پرسش در انتظار انتشار", "help",
        questions(status="pending"), "/panel/qa",
        lambda q: {"title": q["body"][:56],
                   "sub": q.get("bizname") or "",
                   "when": str(q.get("created") or "")[:16],
                   "href": "/panel/qa"})

    add("claim", "درخواست تصاحب کسب‌وکار", "shield",
        claims(status="pending"), "/panel/claims",
        lambda c: {"title": c.get("bizname") or "—",
                   "sub": c.get("ownerphone") or c.get("phone") or "",
                   "when": str(c.get("created") or "")[:16],
                   "href": "/panel/claims"})

    add("edit", "ویرایش در انتظار تأیید", "edit",
        pending_edits(), "/panel/edits",
        lambda e: {"title": e.get("bizname") or "—",
                   "sub": "تغییر اطلاعات کسب‌وکار",
                   "when": str(e.get("created") or "")[:16],
                   "href": "/panel/edits"})

    add("subscription", "پرداخت در انتظار تأیید", "wallet",
        subscriptions(status="pending"), "/panel/subscriptions",
        lambda x: {"title": x.get("bizname") or "—",
                   "sub": f"{fa_money(x.get('amount') or 0)} تومان — "
                          f"{x.get('planname') or x.get('plan_slug')}",
                   "when": str(x.get("created") or "")[:16],
                   "href": "/panel/subscriptions"})

    add("ticket", "تیکت بی‌پاسخ", "message",
        [t for t in tickets() if t.get("unread_admin")], "/panel/tickets",
        lambda t: {"title": t["subject"],
                   "sub": f"{t.get('name') or ''} {t.get('phone') or ''}".strip(),
                   "when": str(t.get("updated") or "")[:16],
                   "href": f"/panel/ticket/{t['id']}"})

    add("report", "گزارش تخلف", "alert",
        [r for r in reports() if r.get("status") == "new"], "/panel/reports",
        lambda r: {"title": r.get("reason") or "گزارش",
                   "sub": r.get("bizname") or "",
                   "when": str(r.get("created") or "")[:16],
                   "href": "/panel/reports"})

    add("message", "پیام تماس خوانده‌نشده", "mail",
        messages(status="new"), "/panel/messages",
        lambda m: {"title": m.get("subject") or (m.get("body") or "")[:48],
                   "sub": f"{m.get('name') or ''} {m.get('email') or ''}".strip(),
                   "when": str(m.get("created") or "")[:16],
                   "href": "/panel/messages"})

    return {"total": sum(x["n"] for x in g), "groups": g}


def owner_badges(owner_id):
    """Unread/pending counts for one shopkeeper's sidebar.

    Written because SMS is not configured yet: sms.notify() is called in
    six places but silently does nothing without an API key, so a booking
    could sit unseen for a week. These numbers make the panel itself the
    notification channel, and they stay useful after SMS is switched on.
    """
    ids = [b["id"] for b in businesses_of(owner_id)]
    if not ids:
        return {"total": 0}
    marks = ",".join("?" * len(ids))
    con = connect()

    def one(sql, extra=()):
        r = con.execute(sql, list(ids) + list(extra)).fetchone()
        return r["c"] if r else 0

    out = {
        "bookings": one(f"SELECT COUNT(*) c FROM bookings "
                        f"WHERE biz_id IN ({marks}) AND status='new'"),
        "questions": one(f"SELECT COUNT(*) c FROM questions "
                         f"WHERE biz_id IN ({marks}) AND (answer IS NULL OR answer='')"),
        "inquiries": one(f"SELECT COUNT(*) c FROM inquiries "
                         f"WHERE biz_id IN ({marks}) AND status='new'"),
        "reviews": one(f"SELECT COUNT(*) c FROM reviews "
                       f"WHERE biz_id IN ({marks}) AND status='approved' "
                       f"AND (reply IS NULL OR reply='')"),
    }
    r = con.execute("SELECT COUNT(*) c FROM tickets WHERE owner_id=? "
                    "AND unread_user=1", (owner_id,)).fetchone()
    out["tickets"] = r["c"] if r else 0
    con.close()
    out["total"] = sum(v for k, v in out.items() if k != "total")
    return out


def vcard(b):
    """A .vcf the phone's Contacts app understands.

    "Save to contacts" is the single most useful thing a person can do with
    a shop they intend to use again, and on a phone the alternative is
    copying four fields by hand. vCard 3.0 is chosen deliberately: 4.0 is
    newer but older Android dialers still choke on it.
    """
    def esc_v(t):
        return str(t or "").replace("\\", "\\\\").replace(";", "\\;") \
                           .replace(",", "\\,").replace("\n", "\\n")

    name = esc_v(b.get("name"))
    lines = ["BEGIN:VCARD", "VERSION:3.0",
             f"N:{name};;;;", f"FN:{name}"]
    if b.get("cat_name"):
        lines.append(f"ORG:{esc_v(b['cat_name'])}")
    if b.get("phone"):
        lines.append(f"TEL;TYPE=WORK,VOICE:{esc_v(b['phone'])}")
    if b.get("whatsapp"):
        lines.append(f"TEL;TYPE=CELL:{esc_v(b['whatsapp'])}")
    if b.get("address"):
        lines.append(f"ADR;TYPE=WORK:;;{esc_v(b['address'])};نجف‌آباد;اصفهان;;ایران")
    if b.get("website"):
        lines.append(f"URL:{esc_v(b['website'])}")
    if b.get("descr"):
        lines.append(f"NOTE:{esc_v(b['descr'][:200])}")
    if b.get("lat") and b.get("lng"):
        lines.append(f"GEO:{b['lat']};{b['lng']}")
    lines += ["END:VCARD"]
    return "\r\n".join(lines) + "\r\n"


def owner_export_csv(owner_id, kind="customers"):
    """A shopkeeper's own data, in a file they can open in Excel.

    This is the `export` paid feature. Callers must have already checked
    can(biz_id, "export") — this function only assembles the rows, and it
    scopes strictly to businesses the owner actually owns so one shopkeeper
    can never export another's customer list.
    """
    import csv, io as _io
    mine = businesses_of(owner_id)
    ids = {b["id"]: b["name"] for b in mine}
    if not ids:
        return "\ufeff"

    buf = _io.StringIO()
    _w = csv.writer(buf)

    def writerow(row):
        # Every cell passes through _csv_cell so a customer name or phone
        # that starts with = + - @ cannot become a live formula in Excel.
        # (Security fix.)
        _w.writerow([_csv_cell(x) for x in row])

    w = type("_SafeCSV", (), {"writerow": staticmethod(writerow)})()

    if kind == "bookings":
        w.writerow(["کسب‌وکار", "نام مشتری", "تاریخ", "ساعت",
                    "وضعیت", "یادداشت", "ثبت"])
        for k in bookings():
            if k["biz_id"] in ids:
                w.writerow([ids[k["biz_id"]], k.get("name", ""),
                            k.get("date", ""), k.get("time", ""), k.get("status", ""),
                            k.get("note", ""), str(k.get("created", ""))[:16]])

    elif kind == "inquiries":
        w.writerow(["کسب‌وکار", "نام", "مورد", "درخواست",
                    "بودجه", "پاسخ شما", "وضعیت", "ثبت"])
        for r in inquiries():
            if r["biz_id"] in ids:
                w.writerow([ids[r["biz_id"]], r.get("name", ""),
                            r.get("itemtitle", ""), r.get("body", ""),
                            r.get("budget", ""), r.get("quote", ""),
                            r.get("status", ""), str(r.get("created", ""))[:16]])

    elif kind == "items":
        w.writerow(["کسب‌وکار", "عنوان", "نوع", "قیمت", "تخفیف", "موجود",
                    "ویژه", "برند", "گارانتی", "بازدید"])
        for b in mine:
            for it in items(biz_id=b["id"]):
                w.writerow([b["name"], it.get("title", ""), it.get("kind", ""),
                            it.get("price", "") or "", it.get("sale_price", "") or "",
                            "بله" if it.get("available") else "خیر",
                            "بله" if it.get("featured") else "خیر",
                            it.get("brand", ""), it.get("warranty", ""),
                            it.get("views", 0)])

    else:   # customers — everyone who ever reached out, de-duplicated by name.
            # (v65: phone numbers are private to the site admin and are not exported.)
        seen = {}
        for k in bookings():
            if k["biz_id"] in ids and k.get("name"):
                seen.setdefault(k["name"], [ids[k["biz_id"]],
                                            "نوبت", str(k.get("created", ""))[:10]])
        for r in inquiries():
            if r["biz_id"] in ids and r.get("name"):
                seen.setdefault(r["name"], [ids[r["biz_id"]],
                                            "پیام", str(r.get("created", ""))[:10]])
        w.writerow(["نام", "کسب‌وکار", "از طریق", "تاریخ"])
        for nm, (bn, via, dt) in seen.items():
            w.writerow([nm, bn, via, dt])

    return "\ufeff" + buf.getvalue()


def import_csv(text):
    """-> (added, updated, errors[])"""
    import csv, io
    text = text.lstrip("\ufeff")
    rdr = csv.DictReader(io.StringIO(text))
    cats = {c["slug"] for c in categories(only_active=False)}
    added = updated = 0
    errors = []
    for i, row in enumerate(rdr, start=2):
        name = (row.get("name") or "").strip()
        if not name:
            errors.append(f"سطر {i}: نام خالی است")
            continue
        cat = (row.get("cat_slug") or "").strip()
        if cat not in cats:
            errors.append(f"سطر {i}: دستهٔ «{cat}» وجود ندارد")
            continue
        data = {k: (row.get(k) or "").strip() for k in CSV_COLUMNS if k in row}
        data["name"] = name
        data["cat_slug"] = cat
        data.setdefault("status", "published")
        if data.get("status") not in ("published", "pending", "hidden", "rejected"):
            data["status"] = "published"
        for f in ("featured", "verified"):
            data[f] = 1 if str(data.get(f, "")).strip() in ("1", "بله", "true", "yes") else 0

        dup = find_duplicates(name=name, phone=data.get("phone", ""))
        exact = [d for d in dup if d["strength"] == "exact"]
        if exact:
            save_business(data, exact[0]["id"])
            updated += 1
        else:
            save_business(data)
            added += 1
    return added, updated, errors


# ==========================================================================
#  v3 — WORLD-CLASS DIRECTORY FEATURES
#  Every function here is reachable from a real page and a real panel screen.
# ==========================================================================

def _rows(sql, params=()):
    con = connect()
    out = [dict(r) for r in con.execute(sql, params)]
    con.close()
    return out


def _one(sql, params=()):
    con = connect()
    r = con.execute(sql, params).fetchone()
    con.close()
    return dict(r) if r else None


def _run(sql, params=()):
    con = connect()
    cur = con.execute(sql, params)
    rid = cur.lastrowid
    con.commit()
    con.close()
    return rid


def _upd(table, rowid, **kw):
    kw = {k: v for k, v in kw.items() if v is not None}
    if not kw:
        return 0
    con = connect()
    sets = ", ".join(f"{k}=?" for k in kw)
    cur = con.execute(f"UPDATE {table} SET {sets} WHERE id=?",
                      list(kw.values()) + [rowid])
    n = cur.rowcount
    con.commit()
    con.close()
    return n


# ------------------------------------------------------------- rate limiting
def rate_ok(bucket, limit=None, window=None):
    """Sliding bucket. Returns True when the action is allowed.
    Disabled entirely when the admin turns the switch off."""
    s = get_settings()
    if s.get("ratelimit_on") != "1":
        return True
    limit = int(limit or s.get("ratelimit_n", "8") or 8)
    window = float(window or s.get("ratelimit_win", "600") or 600)
    now = time.time()
    con = connect()
    r = con.execute("SELECT n, window FROM ratelimit WHERE bucket=?", (bucket,)).fetchone()
    if not r or now - r["window"] > window:
        con.execute("INSERT INTO ratelimit(bucket,n,window) VALUES(?,1,?) "
                    "ON CONFLICT(bucket) DO UPDATE SET n=1, window=excluded.window",
                    (bucket, now))
        con.commit(); con.close()
        return True
    if r["n"] >= limit:
        con.close()
        return False
    con.execute("UPDATE ratelimit SET n=n+1 WHERE bucket=?", (bucket,))
    con.commit(); con.close()
    return True


def rate_clear():
    _run("DELETE FROM ratelimit")


# ------------------------------------------------------------------ Q & A
def questions(biz_id=None, status=None, limit=None):
    q = ("SELECT q.*, b.name bizname, b.slug bizslug FROM questions q "
         "JOIN businesses b ON b.id=q.biz_id WHERE 1=1")
    p = []
    if biz_id:
        q += " AND q.biz_id=?"; p.append(biz_id)
    if status:
        q += " AND q.status=?"; p.append(status)
    q += " ORDER BY q.helpful DESC, q.id DESC"
    if limit:
        q += f" LIMIT {int(limit)}"
    return _rows(q, p)


def question(qid):
    return _one("SELECT q.*, b.name bizname, b.slug bizslug FROM questions q "
                "JOIN businesses b ON b.id=q.biz_id WHERE q.id=?", (qid,))


def add_question(biz_id, asker, body, auto_publish=False):
    return _run("INSERT INTO questions(biz_id,asker,body,status) VALUES(?,?,?,?)",
                (biz_id, asker.strip(), body.strip(),
                 "published" if auto_publish else "pending"))


def answer_question(qid, answer, by="owner"):
    return _upd("questions", qid, answer=answer.strip(), answered_by=by,
                status="published",
                answered=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


def set_question_status(qid, status):
    return _upd("questions", qid, status=status)


def delete_question(qid):
    return _run("DELETE FROM questions WHERE id=?", (qid,))


def question_helpful(qid):
    _run("UPDATE questions SET helpful=helpful+1 WHERE id=?", (qid,))
    r = _one("SELECT helpful FROM questions WHERE id=?", (qid,))
    return r["helpful"] if r else 0


def questions_count(biz_id=None, status=None):
    return len(questions(biz_id=biz_id, status=status))


# ------------------------------------------------------------------ reports
def reports(status=None, kind=None):
    q = ("SELECT r.*, b.name bizname, b.slug bizslug FROM reports r "
         "LEFT JOIN businesses b ON b.id=r.biz_id WHERE 1=1")
    p = []
    if status:
        q += " AND r.status=?"; p.append(status)
    if kind:
        q += " AND r.kind=?"; p.append(kind)
    q += " ORDER BY (r.status='open') DESC, r.id DESC"
    return _rows(q, p)


def add_report(kind, target_id, reason, body="", reporter="", biz_id=None):
    if kind == "business" and biz_id is None:
        biz_id = target_id
    return _run("INSERT INTO reports(kind,target_id,biz_id,reason,body,reporter) "
                "VALUES(?,?,?,?,?,?)",
                (kind, int(target_id), biz_id, reason, body.strip(), reporter.strip()))


def resolve_report(rid, status="resolved", note=""):
    return _upd("reports", rid, status=status, note=note)


def delete_report(rid):
    row = _one("SELECT * FROM reports WHERE id=?", (rid,))
    if row:
        trash_put("report", rid, row["biz_id"] or 0,
                  (row["reason"] or "") + " " + (row["body"] or "")[:40], dict(row))
    return _run("DELETE FROM reports WHERE id=?", (rid,))


# ---- v105: soft-delete recycle bin (7-day retention, trackable + restorable) ----
TRASH_DAYS = 7

def trash_put(entity, ref_id, biz_id, title, row):
    _run("INSERT INTO trash(entity,ref_id,biz_id,title,payload,deleted_at) VALUES(?,?,?,?,?,?)",
         (entity, int(ref_id), int(biz_id or 0), (title or "")[:120],
          json.dumps(row, ensure_ascii=False, default=str), time.time()))

def trash_list(entities=None, biz_ids=None):
    q = "SELECT * FROM trash WHERE deleted_at>=?"
    p = [time.time() - TRASH_DAYS * 86400]
    if entities:
        q += " AND entity IN (%s)" % ",".join("?" * len(entities)); p += list(entities)
    if biz_ids:
        q += " AND biz_id IN (%s)" % ",".join("?" * len(biz_ids)); p += list(biz_ids)
    q += " ORDER BY deleted_at DESC LIMIT 200"
    return _rows(q, p)

def trash_restore(tid):
    r = _one("SELECT * FROM trash WHERE id=?", (tid,))
    if not r:
        return False
    table = {"story": "stories", "item": "items", "review": "reviews",
             "report": "reports"}.get(r["entity"])
    if not table:
        return False
    row = json.loads(r["payload"])
    cols = list(row.keys())
    con = connect()
    con.execute("INSERT OR REPLACE INTO %s (%s) VALUES (%s)"
                % (table, ",".join(cols), ",".join("?" * len(cols))),
                [row[c] for c in cols])
    con.commit(); con.close()
    _run("DELETE FROM trash WHERE id=?", (tid,))
    return True

def trash_purge():
    _run("DELETE FROM trash WHERE deleted_at < ?", (time.time() - TRASH_DAYS * 86400,))


def reason_label(code):
    return dict(REPORT_REASONS).get(code, code)


# ------------------------------------------------------------------ badges
def badges(only_active=True):
    q = "SELECT * FROM badges"
    if only_active:
        q += " WHERE active=1"
    q += " ORDER BY sort, id"
    rows = _rows(q)
    con = connect()
    for r in rows:
        r["count"] = con.execute("SELECT COUNT(*) c FROM biz_badges WHERE badge_id=?",
                                 (r["id"],)).fetchone()["c"]
    con.close()
    return rows


def badge(bid=None, slug=None):
    if slug:
        return _one("SELECT * FROM badges WHERE slug=?", (slug,))
    return _one("SELECT * FROM badges WHERE id=?", (bid,))


def save_badge(data, bid=None):
    if bid:
        return _upd("badges", bid,
                    name=data.get("name"), icon=data.get("icon"),
                    color=data.get("color"), descr=data.get("descr"),
                    sort=int(data.get("sort") or 0),
                    active=int(bool(int(data.get("active") or 0))))
    slug = data.get("slug") or unique_slug("badges", slugify(data.get("name"), "badge"))
    return _run("INSERT INTO badges(slug,name,icon,color,descr,sort,active) "
                "VALUES(?,?,?,?,?,?,?)",
                (slug, data.get("name", ""), data.get("icon", "award"),
                 data.get("color", "#059669"), data.get("descr", ""),
                 int(data.get("sort") or 0), int(bool(int(data.get("active") or 1)))))


def delete_badge(bid):
    return _run("DELETE FROM badges WHERE id=?", (bid,))


def biz_badges(biz_id):
    return _rows("SELECT bg.* FROM biz_badges bb JOIN badges bg ON bg.id=bb.badge_id "
                 "WHERE bb.biz_id=? AND bg.active=1 ORDER BY bg.sort", (biz_id,))


def badges_map(biz_ids=None):
    """{biz_id: [badge, ...]} in one query — used by list pages."""
    con = connect()
    rows = con.execute(
        "SELECT bb.biz_id, bg.* FROM biz_badges bb JOIN badges bg ON bg.id=bb.badge_id "
        "WHERE bg.active=1 ORDER BY bg.sort").fetchall()
    con.close()
    out = {}
    for r in rows:
        d = dict(r)
        out.setdefault(d["biz_id"], []).append(d)
    if biz_ids is not None:
        ids = set(biz_ids)
        out = {k: v for k, v in out.items() if k in ids}
    return out


def grant_badge(biz_id, badge_id):
    return _run("INSERT OR IGNORE INTO biz_badges(biz_id,badge_id) VALUES(?,?)",
                (biz_id, badge_id))


def revoke_badge(biz_id, badge_id):
    return _run("DELETE FROM biz_badges WHERE biz_id=? AND badge_id=?",
                (biz_id, badge_id))


def set_biz_badges(biz_id, badge_ids):
    con = connect()
    con.execute("DELETE FROM biz_badges WHERE biz_id=?", (biz_id,))
    for b in badge_ids:
        con.execute("INSERT OR IGNORE INTO biz_badges(biz_id,badge_id) VALUES(?,?)",
                    (biz_id, int(b)))
    con.commit(); con.close()
    return len(badge_ids)


def auto_badges():
    """Grant/revoke the automatic badges from real data. Runs on demand from
    the panel so the admin can see exactly how many changed."""
    top = badge(slug="top-rated")
    changed = 0
    if not top:
        return 0
    con = connect()
    rows = con.execute(
        "SELECT b.id, (SELECT AVG(rating) FROM reviews WHERE biz_id=b.id AND status='approved') r, "
        "(SELECT COUNT(*) FROM reviews WHERE biz_id=b.id AND status='approved') n "
        "FROM businesses b").fetchall()
    for r in rows:
        deserves = bool(r["r"] and r["r"] >= 4.5 and r["n"] >= 10)
        has = con.execute("SELECT 1 FROM biz_badges WHERE biz_id=? AND badge_id=?",
                          (r["id"], top["id"])).fetchone() is not None
        if deserves and not has:
            con.execute("INSERT INTO biz_badges(biz_id,badge_id) VALUES(?,?)",
                        (r["id"], top["id"])); changed += 1
        elif has and not deserves:
            con.execute("DELETE FROM biz_badges WHERE biz_id=? AND badge_id=?",
                        (r["id"], top["id"])); changed += 1
    con.commit(); con.close()
    return changed


# ------------------------------------------------------------------ plans
def plans(only_active=True):
    q = "SELECT * FROM plans"
    if only_active:
        q += " WHERE active=1"
    q += " ORDER BY sort, price"
    rows = _rows(q)
    for r in rows:
        r["perk_list"] = [x.strip() for x in (r.get("perks") or "").split("\n") if x.strip()]
    return rows


def plan(slug=None, pid=None):
    r = _one("SELECT * FROM plans WHERE slug=?", (slug,)) if slug else \
        _one("SELECT * FROM plans WHERE id=?", (pid,))
    if r:
        r["perk_list"] = [x.strip() for x in (r.get("perks") or "").split("\n") if x.strip()]
    return r


def save_plan(data, pid=None):
    vals = dict(
        name=data.get("name", ""),
        tagline=data.get("tagline", ""),
        price=int(str(data.get("price") or 0).replace(",", "") or 0),
        months=int(data.get("months") or 12),
        featured_slots=int(data.get("featured_slots") or 0),
        max_items=int(data.get("max_items") or 10),
        max_photos=int(data.get("max_photos") or 6),
        perks=data.get("perks", ""),
        features=data.get("features", ""),
        badge_slug=data.get("badge_slug", ""),
        sort=int(data.get("sort") or 0),
        active=int(bool(int(data.get("active") or 0))))
    if pid:
        return _upd("plans", pid, **vals)
    slug = data.get("slug") or unique_slug("plans", slugify(vals["name"], "plan"))
    cols = ", ".join(["slug"] + list(vals))
    qs = ", ".join("?" * (len(vals) + 1))
    return _run(f"INSERT INTO plans({cols}) VALUES({qs})", [slug] + list(vals.values()))


def delete_plan(pid):
    p = plan(pid=pid)
    if p and subscriptions(plan_slug=p["slug"]):
        return False, "این پلن اشتراک فعال دارد و حذف نمی‌شود."
    _run("DELETE FROM plans WHERE id=?", (pid,))
    return True, "پلن حذف شد."


# --------------------------------------------------------- subscriptions
def subscriptions(status=None, biz_id=None, plan_slug=None):
    q = ("SELECT s.*, b.name bizname, b.slug bizslug, p.name planname "
         "FROM subscriptions s JOIN businesses b ON b.id=s.biz_id "
         "LEFT JOIN plans p ON p.slug=s.plan_slug WHERE 1=1")
    p = []
    if status:
        q += " AND s.status=?"; p.append(status)
    if biz_id:
        q += " AND s.biz_id=?"; p.append(biz_id)
    if plan_slug:
        q += " AND s.plan_slug=?"; p.append(plan_slug)
    q += " ORDER BY (s.status='pending') DESC, s.id DESC"
    rows = _rows(q, p)
    today = datetime.date.today().isoformat()
    for r in rows:
        r["days_left"] = None
        if r.get("expires"):
            try:
                d = (datetime.date.fromisoformat(r["expires"][:10]) -
                     datetime.date.today()).days
                r["days_left"] = d
            except Exception:
                pass
        r["is_live"] = r["status"] == "active" and (not r.get("expires") or r["expires"] >= today)
    return rows


def subscription_of(biz_id):
    """The one that matters right now."""
    live = [s for s in subscriptions(biz_id=biz_id) if s["is_live"]]
    return live[0] if live else None


def request_subscription(biz_id, plan_slug, ref="", method="manual", note="", months=None):
    p = plan(slug=plan_slug)
    if not p:
        return None, "پلن یافت نشد."
    # optional billing period override (1/3/6/12). The amount is prorated from
    # the plan's own monthly rate so a shorter period costs proportionally less.
    m = p["months"]
    if months and str(months).isdigit() and int(months) in (1, 3, 6, 12):
        m = int(months)
    monthly_rate = (p["price"] // p["months"]) if p["months"] else p["price"]
    amount = monthly_rate * m
    if p["price"] == 0:
        # free plan activates immediately
        sid = _run("INSERT INTO subscriptions(biz_id,plan_slug,status,starts,expires,"
                   "amount,method,ref,note) VALUES(?,?,'active',?,?,?,?,?,?)",
                   (biz_id, plan_slug, datetime.date.today().isoformat(),
                    (datetime.date.today() + datetime.timedelta(days=30 * m)).isoformat(),
                    0, method, ref, note))
        apply_plan(biz_id, plan_slug)
        return sid, "پلن رایگان فعال شد."
    sid = _run("INSERT INTO subscriptions(biz_id,plan_slug,status,amount,method,ref,note) "
               "VALUES(?,?,'pending',?,?,?,?)",
               (biz_id, plan_slug, amount, method, ref, note))
    return sid, "درخواست ثبت شد و پس از تأیید پرداخت فعال می‌شود."


def activate_subscription(sid, months=None):
    access_cache_clear()
    s = _one("SELECT * FROM subscriptions WHERE id=?", (sid,))
    if not s:
        return False
    p = plan(slug=s["plan_slug"])
    m = int(months or (p["months"] if p else 12))
    start = datetime.date.today()
    # stack on top of a still-running subscription instead of losing days
    live = subscription_of(s["biz_id"])
    if live and live.get("expires"):
        try:
            e = datetime.date.fromisoformat(live["expires"][:10])
            if e > start:
                start = e
        except Exception:
            pass
    end = start + datetime.timedelta(days=30 * m)
    _upd("subscriptions", sid, status="active", starts=start.isoformat(),
         expires=end.isoformat())
    apply_plan(s["biz_id"], s["plan_slug"])
    log("subscription.activate", f"{s['biz_id']} {s['plan_slug']} -> {end}")
    return True


def cancel_subscription(sid):
    access_cache_clear()
    s = _one("SELECT * FROM subscriptions WHERE id=?", (sid,))
    _upd("subscriptions", sid, status="cancelled")
    if s:
        revoke_plan(s["biz_id"], s["plan_slug"])
    return True


def delete_subscription(sid):
    return _run("DELETE FROM subscriptions WHERE id=?", (sid,))


def apply_plan(biz_id, plan_slug):
    """A paid plan really changes the listing: featured flag + badge."""
    p = plan(slug=plan_slug)
    if not p:
        return
    if p["featured_slots"] > 0:
        save_business({"featured": 1}, biz_id)
    if p.get("badge_slug"):
        bg = badge(slug=p["badge_slug"])
        if bg:
            grant_badge(biz_id, bg["id"])


def revoke_plan(biz_id, plan_slug):
    access_cache_clear()
    p = plan(slug=plan_slug)
    if not p:
        return
    if p["featured_slots"] > 0:
        save_business({"featured": 0}, biz_id)
    if p.get("badge_slug"):
        bg = badge(slug=p["badge_slug"])
        if bg:
            revoke_badge(biz_id, bg["id"])


def expire_subscriptions():
    access_cache_clear()
    """Called on boot and from the panel. Returns how many expired.

    SOFT EXPIRY: only the status flag is flipped here. The plan's features are
    NOT revoked — access() keeps them alive after expiry so a late payment
    never hides a shop's photos, catalogue or badges. Only the add-quota
    reverts, which access() derives from the live subscription."""
    today = datetime.date.today().isoformat()
    con = connect()
    rows = con.execute("SELECT * FROM subscriptions WHERE status='active' "
                       "AND expires IS NOT NULL AND expires < ?", (today,)).fetchall()
    for r in rows:
        con.execute("UPDATE subscriptions SET status='expired' WHERE id=?", (r["id"],))
    con.commit(); con.close()
    return len(rows)


def expiring_soon(days=14):
    out = []
    for s in subscriptions(status="active"):
        if s.get("days_left") is not None and 0 <= s["days_left"] <= days:
            out.append(s)
    return out


def plan_limits(biz_id):
    """What this business is allowed to do right now."""
    sub = subscription_of(biz_id)
    p = plan(slug=sub["plan_slug"]) if sub else plan(slug="free")
    if not p:
        return {"plan": "free", "name": "پایه", "max_items": 10, "max_photos": 6}
    return {"plan": p["slug"], "name": p["name"],
            "max_items": p["max_items"], "max_photos": p["max_photos"],
            "expires": sub.get("expires") if sub else None,
            "days_left": sub.get("days_left") if sub else None}


# ------------------------------------------------------------------ ads
def ads(slot=None, active_only=False):
    q = ("SELECT a.*, b.name bizname, b.slug bizslug FROM ads a "
         "LEFT JOIN businesses b ON b.id=a.biz_id WHERE 1=1")
    p = []
    if slot:
        q += " AND a.slot=?"; p.append(slot)
    if active_only:
        today = datetime.date.today().isoformat()
        q += (" AND a.active=1 AND (a.starts='' OR a.starts<=?) "
              "AND (a.ends='' OR a.ends>=?)")
        p += [today, today]
    q += " ORDER BY a.weight DESC, a.id DESC"
    rows = _rows(q, p)
    for r in rows:
        r["ctr"] = round(r["clicks"] * 100.0 / r["views"], 1) if r["views"] else 0.0
    return rows


def ad(aid):
    return _one("SELECT * FROM ads WHERE id=?", (aid,))


def pick_ad(slot):
    """Weighted pick among the live ads for a slot, and count the impression."""
    live = ads(slot=slot, active_only=True)
    if not live:
        return None
    pool = []
    for a in live:
        pool += [a] * max(1, int(a["weight"] or 1))
    chosen = pool[secrets.randbelow(len(pool))]
    _run("UPDATE ads SET views=views+1 WHERE id=?", (chosen["id"],))
    return chosen


def ad_click(aid):
    _run("UPDATE ads SET clicks=clicks+1 WHERE id=?", (aid,))
    return ad(aid)


def save_ad(data, aid=None):
    vals = dict(title=data.get("title", ""), body=data.get("body", ""),
                image=data.get("image", ""), url=data.get("url", ""),
                slot=data.get("slot", "home"),
                biz_id=(int(data["biz_id"]) if str(data.get("biz_id") or "").isdigit() else None),
                starts=data.get("starts", ""), ends=data.get("ends", ""),
                weight=int(data.get("weight") or 1),
                active=int(bool(int(data.get("active") or 0))))
    if aid:
        con = connect()
        sets = ", ".join(f"{k}=?" for k in vals)
        con.execute(f"UPDATE ads SET {sets} WHERE id=?", list(vals.values()) + [aid])
        con.commit(); con.close()
        return aid
    cols = ", ".join(vals)
    qs = ", ".join("?" * len(vals))
    return _run(f"INSERT INTO ads({cols}) VALUES({qs})", list(vals.values()))


def delete_ad(aid):
    return _run("DELETE FROM ads WHERE id=?", (aid,))


def reset_ad_stats(aid):
    return _run("UPDATE ads SET views=0, clicks=0 WHERE id=?", (aid,))


# ------------------------------------------------------------------ events
def cityevents(status="published", upcoming_only=False, limit=None):
    q = ("SELECT e.*, b.name bizname, b.slug bizslug FROM cityevents e "
         "LEFT JOIN businesses b ON b.id=e.biz_id WHERE 1=1")
    p = []
    if status:
        q += " AND e.status=?"; p.append(status)
    if upcoming_only:
        q += " AND (e.date='' OR e.date>=?)"; p.append(datetime.date.today().isoformat())
    q += " ORDER BY (e.date='') , e.date, e.id DESC"
    if limit:
        q += f" LIMIT {int(limit)}"
    rows = _rows(q, p)
    today = datetime.date.today().isoformat()
    for r in rows:
        r["past"] = bool(r.get("date")) and r["date"] < today
    return rows


def cityevent(slug=None, eid=None):
    if slug:
        return _one("SELECT e.*, b.name bizname, b.slug bizslug FROM cityevents e "
                    "LEFT JOIN businesses b ON b.id=e.biz_id WHERE e.slug=?", (slug,))
    return _one("SELECT * FROM cityevents WHERE id=?", (eid,))


def save_cityevent(data, eid=None):
    vals = dict(title=data.get("title", ""), descr=data.get("descr", ""),
                place=data.get("place", ""), date=data.get("date", ""),
                time=data.get("time", ""),
                biz_id=(int(data["biz_id"]) if str(data.get("biz_id") or "").isdigit() else None),
                image=data.get("image", ""),
                status=data.get("status", "published"))
    if eid:
        con = connect()
        sets = ", ".join(f"{k}=?" for k in vals)
        con.execute(f"UPDATE cityevents SET {sets} WHERE id=?", list(vals.values()) + [eid])
        con.commit(); con.close()
        return eid
    slug = unique_slug("cityevents", slugify(vals["title"], "event"))
    cols = ", ".join(["slug"] + list(vals))
    qs = ", ".join("?" * (len(vals) + 1))
    return _run(f"INSERT INTO cityevents({cols}) VALUES({qs})",
                [slug] + list(vals.values()))


def delete_cityevent(eid):
    return _run("DELETE FROM cityevents WHERE id=?", (eid,))


# --------------------------------------------------- multi-criteria reviews
def set_review_scores(review_id, scores):
    """scores: {criterion: 1..5}"""
    con = connect()
    con.execute("DELETE FROM review_scores WHERE review_id=?", (review_id,))
    valid = dict(REVIEW_CRITERIA)
    for k, v in (scores or {}).items():
        if k in valid:
            try:
                n = max(1, min(5, int(v)))
            except Exception:
                continue
            con.execute("INSERT INTO review_scores(review_id,criterion,score) "
                        "VALUES(?,?,?)", (review_id, k, n))
    con.commit(); con.close()


def review_scores(review_id):
    return {r["criterion"]: r["score"] for r in
            _rows("SELECT criterion,score FROM review_scores WHERE review_id=?",
                  (review_id,))}


def criteria_averages(biz_id):
    """Average per criterion across approved reviews — the Tripadvisor bars."""
    rows = _rows(
        "SELECT rs.criterion, AVG(rs.score) a, COUNT(*) n FROM review_scores rs "
        "JOIN reviews r ON r.id=rs.review_id "
        "WHERE r.biz_id=? AND r.status='approved' GROUP BY rs.criterion", (biz_id,))
    have = {r["criterion"]: (round(r["a"], 1), r["n"]) for r in rows}
    out = []
    for code, label in REVIEW_CRITERIA:
        if code in have:
            out.append({"code": code, "label": label,
                        "avg": have[code][0], "n": have[code][1]})
    return out


def add_review_full(biz_id, author, rating, body, scores=None, auto_approve=False, image=""):
    rid = _run("INSERT INTO reviews(biz_id,author,rating,body,status,image) "
               "VALUES(?,?,?,?,?,?)",
               (biz_id, author, int(rating), body,
                "approved" if auto_approve else "pending", image or ""))
    if scores:
        set_review_scores(rid, scores)
    return rid


# ----------------------------------------------------------- edit approval
def pending_edits(status="pending"):
    q = ("SELECT e.*, b.name bizname, b.slug bizslug, o.phone ownerphone "
         "FROM edits e JOIN businesses b ON b.id=e.biz_id "
         "LEFT JOIN owners o ON o.id=e.owner_id WHERE 1=1")
    p = []
    if status:
        q += " AND e.status=?"; p.append(status)
    q += " ORDER BY e.id DESC"
    rows = _rows(q, p)
    for r in rows:
        try:
            r["fields"] = json.loads(r["payload"])
        except Exception:
            r["fields"] = {}
    return rows


FIELD_LABELS = {
    "name": "نام", "cat_slug": "دسته", "descr": "توضیحات", "phone": "تلفن",
    "whatsapp": "واتساپ", "address": "نشانی", "tags": "برچسب‌ها",
    "instagram": "اینستاگرام", "telegram": "تلگرام", "website": "وب‌سایت",
    "lat": "عرض جغرافیایی", "lng": "طول جغرافیایی", "hours": "ساعت کاری",
    "booking_on": "نوبت‌دهی",
}


def queue_edit(biz_id, owner_id, data):
    changed = {}
    cur = business(bid=biz_id) or {}
    for k, v in data.items():
        if str(cur.get(k) or "") != str(v or ""):
            changed[k] = v
    if not changed:
        return None
    return _run("INSERT INTO edits(biz_id,owner_id,payload) VALUES(?,?,?)",
                (biz_id, owner_id, json.dumps(changed, ensure_ascii=False)))


def decide_edit(eid, approve):
    e = _one("SELECT * FROM edits WHERE id=?", (eid,))
    if not e:
        return False
    if approve:
        try:
            save_business(json.loads(e["payload"]), e["biz_id"])
        except Exception:
            return False
    _upd("edits", eid, status="approved" if approve else "rejected")
    return True


# ------------------------------------------------------------ saved alerts
def alerts(active_only=False):
    q = "SELECT * FROM alerts"
    if active_only:
        q += " WHERE active=1"
    q += " ORDER BY id DESC"
    return _rows(q)


def add_alert(phone, term="", cat_slug=""):
    phone = norm_phone(phone)
    if not valid_phone(phone):
        return None, "شمارهٔ موبایل معتبر نیست."
    if not term and not cat_slug:
        return None, "دست‌کم یک عبارت یا دسته لازم است."
    dup = _one("SELECT id FROM alerts WHERE phone=? AND term=? AND cat_slug=?",
               (phone, term, cat_slug))
    if dup:
        return dup["id"], "این هشدار قبلاً ثبت شده است."
    aid = _run("INSERT INTO alerts(phone,term,cat_slug) VALUES(?,?,?)",
               (phone, term, cat_slug))
    return aid, "هشدار ثبت شد. وقتی کسب‌وکار مطابقی اضافه شود پیامک می‌شود."


def delete_alert(aid):
    return _run("DELETE FROM alerts WHERE id=?", (aid,))


def toggle_alert(aid, active):
    return _upd("alerts", aid, active=int(bool(active)))


def matching_alerts(biz):
    """Who asked to be told about a business like this one?"""
    out = []
    hay = normalize_fa(f"{biz.get('name','')} {biz.get('descr','')} "
                       f"{biz.get('tags','')} {biz.get('address','')}")
    for a in alerts(active_only=True):
        if a["cat_slug"] and a["cat_slug"] != biz.get("cat_slug"):
            continue
        if a["term"] and normalize_fa(a["term"]) not in hay:
            continue
        out.append(a)
    return out


def mark_alert_sent(aid):
    return _run("UPDATE alerts SET sent=sent+1 WHERE id=?", (aid,))


# ------------------------------------------------------- geo / radius search
def haversine_km(lat1, lng1, lat2, lng2):
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = (math.sin(dp / 2) ** 2 +
         math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2)
    return 2 * R * math.asin(math.sqrt(a))


def nearby(lat, lng, radius_km=3.0, cat="", term="", limit=60):
    rows = businesses(status="published", cat=cat or None, order="featured")
    out = []
    t = normalize_fa(term) if term else ""
    for b in rows:
        if b.get("lat") is None or b.get("lng") is None:
            continue
        if t and t not in normalize_fa(f"{b['name']} {b['descr']} {b['tags']} {b['address']}"):
            continue
        d = haversine_km(float(lat), float(lng), float(b["lat"]), float(b["lng"]))
        if d <= radius_km:
            b["distance_km"] = round(d, 2)
            out.append(b)
    out.sort(key=lambda x: x["distance_km"])
    return out[:limit]


# ------------------------------------------------------------ site insights
def site_insights(days=30):
    """Whole-site analytics — the thing the panel had no screen for."""
    con = connect()
    since = (datetime.date.today() - datetime.timedelta(days=days - 1)).isoformat()
    series = {}
    for r in con.execute("SELECT day, kind, SUM(n) t FROM events WHERE day>=? "
                         "GROUP BY day, kind", (since,)):
        series.setdefault(r["day"], {})[r["kind"]] = r["t"]
    days_list = [(datetime.date.today() - datetime.timedelta(days=i)).isoformat()
                 for i in range(days - 1, -1, -1)]
    KINDS = ("view", "phone", "whatsapp", "route", "share")
    daily = [{"day": d, **{k: series.get(d, {}).get(k, 0) for k in KINDS}}
             for d in days_list]
    totals = {k: sum(x[k] for x in daily) for k in KINDS}

    top = [dict(r) for r in con.execute(
        "SELECT b.id, b.name, b.slug, COALESCE(SUM(e.n),0) t FROM businesses b "
        "LEFT JOIN events e ON e.biz_id=b.id AND e.day>=? AND e.kind='view' "
        "GROUP BY b.id ORDER BY t DESC, b.views DESC LIMIT 10", (since,))]
    cats_ = [dict(r) for r in con.execute(
        "SELECT c.name, c.slug, COUNT(b.id) n FROM categories c "
        "LEFT JOIN businesses b ON b.cat_slug=c.slug AND b.status='published' "
        "GROUP BY c.id ORDER BY n DESC LIMIT 10")]
    growth = [dict(r) for r in con.execute(
        "SELECT substr(created,1,7) m, COUNT(*) n FROM businesses "
        "GROUP BY m ORDER BY m DESC LIMIT 12")]
    con.close()

    counts = {
        "questions_open": len(questions(status="pending")),
        "reports_open": len(reports(status="open")),
        "subs_pending": len(subscriptions(status="pending")),
        "subs_active": len([s for s in subscriptions(status="active") if s["is_live"]]),
        "edits_pending": len(pending_edits()),
        "alerts": len(alerts(active_only=True)),
        "events": len(cityevents(upcoming_only=True)),
        "ads": len(ads(active_only=True)),
    }
    revenue = sum(s["amount"] for s in subscriptions(status="active"))
    return {"daily": daily, "totals": totals, "top": top, "cats": cats_,
            "growth": list(reversed(growth)), "counts": counts, "revenue": revenue,
            "days": days}


# ------------------------------------------------------------ JSON-LD / SEO
def jsonld_business(b, base_url=""):
    """Schema.org LocalBusiness so Google shows stars, hours and address.

    The directory went nationwide (31 provinces / 353 cities) in v37, so the
    locality/region come from the business's OWN city/province — never a
    hard-coded "نجف‌آباد" that would pin every shop to one town and poison
    local search. Empty values fall back to the original hometown so older
    rows without a city still produce valid schema. (Security/SEO fix.)
    """
    DAY = {"sat": "Saturday", "sun": "Sunday", "mon": "Monday", "tue": "Tuesday",
           "wed": "Wednesday", "thu": "Thursday", "fri": "Friday"}
    spec = []
    for k, ranges in (b.get("hours_map") or {}).items():
        for r in ranges:
            if len(r) == 2:
                spec.append({"@type": "OpeningHoursSpecification",
                             "dayOfWeek": DAY.get(k, k),
                             "opens": r[0], "closes": r[1]})
    locality = (b.get("city") or "").strip() or "نجف‌آباد"
    region = (b.get("province") or "").strip() or "اصفهان"
    d = {
        "@context": "https://schema.org",
        "@type": "LocalBusiness",
        "name": b.get("name"),
        "description": b.get("descr") or "",
        "url": f"{base_url}/b/{b.get('slug')}",
        "address": {"@type": "PostalAddress",
                    "streetAddress": b.get("address") or "",
                    "addressLocality": locality,
                    "addressRegion": region,
                    "addressCountry": "IR"},
    }
    if b.get("phone"):
        d["telephone"] = b["phone"]
    if b.get("lat") and b.get("lng"):
        d["geo"] = {"@type": "GeoCoordinates",
                    "latitude": b["lat"], "longitude": b["lng"]}
    if spec:
        d["openingHoursSpecification"] = spec
    if b.get("images"):
        d["image"] = [f"{base_url}{i}" if i.startswith("/") else i
                      for i in b["images"][:5]]
    if b.get("nreviews"):
        d["aggregateRating"] = {"@type": "AggregateRating",
                                "ratingValue": b.get("rating") or 0,
                                "reviewCount": b["nreviews"],
                                "bestRating": 5, "worstRating": 1}
    # Every public profile helps Google tie the entity together (Local SEO).
    # Website, Instagram and Telegram are all real signals; only present
    # ones are listed, and a bare/relative value is skipped.
    same_as = []

    def _add(v, pref):
        v = (v or "").strip()
        if not v:
            return
        if v.startswith(("http://", "https://")):
            same_as.append(v)
        elif pref:
            # '@channel' or 'channel' both become the profile URL
            same_as.append(pref + v.lstrip("@"))

    _add(b.get("website"), "https://")
    _add(b.get("instagram"), "https://instagram.com/")
    _add(b.get("telegram"), "https://t.me/")
    if same_as:
        d["sameAs"] = same_as
    return d


def jsonld_product(it, biz, base_url=""):
    """Schema.org Product for a catalogue item (E-Commerce SEO). Google uses
    Offer.price to render rich results; a call-for-price item omits the offer
    rather than advertising a wrong number."""
    if not it or it.get("kind") not in ("product", "custom"):
        return None
    d = {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": it.get("title"),
        "description": it.get("descr") or "",
        "url": f"{base_url}/b/{biz.get('slug')}",
    }
    if it.get("brand"):
        d["brand"] = {"@type": "Brand", "name": it["brand"]}
    if it.get("cover"):
        d["image"] = [f"{base_url}{it['cover']}" if it["cover"].startswith("/")
                      else it["cover"]]
    agg = it.get("rating") or it.get("avg_rating")
    if agg:
        d["aggregateRating"] = {"@type": "AggregateRating",
                                "ratingValue": agg,
                                "reviewCount": it.get("nreviews") or 1,
                                "bestRating": 5, "worstRating": 1}
    price = int(it.get("price") or 0)
    if price and it.get("price_type") in ("fixed", "from"):
        off = {"@type": "Offer",
               "price": str(price),
               "priceCurrency": "IRR",
               "availability": ("https://schema.org/InStock" if it.get("in_stock")
                                else "https://schema.org/OutOfStock"),
               "url": f"{base_url}/b/{biz.get('slug')}"}
        old = int(it.get("old_price") or 0)
        if old and old > price:
            off["priceValidUntil"] = (datetime.date.today() +
                                      datetime.timedelta(days=30)).isoformat()
        d["offers"] = off
    return d


def jsonld_website(s, base_url=""):
    """Schema.org WebSite + SearchAction sitelinks box (technical SEO)."""
    d = {"@context": "https://schema.org",
         "@type": "WebSite",
         "name": s.get("site_name"),
         "url": base_url or "/",
         "inLanguage": "fa-IR"}
    if base_url:
        d["potentialAction"] = {
            "@type": "SearchAction",
            "target": {"@type": "EntryPoint",
                       "urlTemplate": f"{base_url}/businesses?q={{search_term_string}}"},
            "query-input": "required name=search_term_string"}
    return d


def jsonld_breadcrumb(items, base_url=""):
    return {"@context": "https://schema.org", "@type": "BreadcrumbList",
            "itemListElement": [
                {"@type": "ListItem", "position": i + 1, "name": n,
                 "item": f"{base_url}{u}" if u else None}
                for i, (n, u) in enumerate(items)]}


def jsonld_org(s, base_url=""):
    return {"@context": "https://schema.org", "@type": "Organization",
            "name": s.get("site_name"), "url": base_url or "/",
            "description": s.get("description"),
            "email": s.get("email"), "telephone": s.get("phone_raw"),
            "address": {"@type": "PostalAddress",
                        "streetAddress": s.get("address"),
                        "addressLocality": "نجف‌آباد", "addressCountry": "IR"}}


def jsonld_faq(qs):
    published = [q for q in qs if q.get("answer")]
    if not published:
        return None
    return {"@context": "https://schema.org", "@type": "FAQPage",
            "mainEntity": [{"@type": "Question", "name": q["body"],
                            "acceptedAnswer": {"@type": "Answer", "text": q["answer"]}}
                           for q in published[:20]]}


def jsonld_event(e, base_url=""):
    d = {"@context": "https://schema.org", "@type": "Event",
         "name": e.get("title"), "description": e.get("descr") or "",
         "url": f"{base_url}/events/{e.get('slug')}",
         "location": {"@type": "Place", "name": e.get("place") or "نجف‌آباد",
                      "address": e.get("place") or "نجف‌آباد، اصفهان، ایران"}}
    if e.get("date"):
        d["startDate"] = f"{e['date']}T{e.get('time') or '00:00'}"
    return d


# ==========================================================================
#  SEARCH ANALYTICS  —  what the city is looking for
# ==========================================================================
def log_search(term, cat="", results=0):
    """Record a search. Zero-result terms tell you which trade to recruit."""
    term = (term or "").strip()
    if not term or len(term) > 120:
        return
    _run("INSERT INTO searches(term,norm,cat,results,day) VALUES(?,?,?,?,?)",
         (term, normalize_fa(term), cat or "",
          int(results), datetime.date.today().isoformat()))


def top_searches(days=30, limit=20, zero_only=False):
    since = (datetime.date.today() - datetime.timedelta(days=days - 1)).isoformat()
    q = ("SELECT norm, MIN(term) term, COUNT(*) n, "
         "SUM(CASE WHEN results=0 THEN 1 ELSE 0 END) zero, "
         "MAX(results) best "
         "FROM searches WHERE day>=? GROUP BY norm")
    if zero_only:
        q += " HAVING best=0"
    q += f" ORDER BY n DESC LIMIT {int(limit)}"
    return _rows(q, (since,))


def search_totals(days=30):
    since = (datetime.date.today() - datetime.timedelta(days=days - 1)).isoformat()
    r = _one("SELECT COUNT(*) total, "
             "SUM(CASE WHEN results=0 THEN 1 ELSE 0 END) zero "
             "FROM searches WHERE day>=?", (since,)) or {}
    total = r.get("total") or 0
    zero = r.get("zero") or 0
    return {"total": total, "zero": zero,
            "hit_rate": round((total - zero) * 100.0 / total, 1) if total else 0.0}


def clear_searches():
    return _run("DELETE FROM searches")


# ==========================================================================
#  FEATURE GATING  —  what a free shop gets, what stays locked
#  Research-backed: gate AFTER the aha moment, never before. Locked features
#  stay VISIBLE but blurred, because showing what is missing converts far
#  better than hiding it.
# ==========================================================================

# Every gateable capability, in the order it appears in the owner panel.
# `founder` = also unlocked for the first N shops (the founding-member promise).
FEATURES = [
    # key            label                        icon         founder  why it is worth paying for
    ("gallery",      "گالری تصاویر کامل",         "image",     True,
     "تا ۲۰ عکس از دکان، محصولات و نمونه‌کارها"),
    ("catalog",      "کاتالوگ نامحدود",           "shopping",  True,
     "همهٔ محصولات و خدمات با قیمت، تخفیف و عکس"),
    ("booking",      "نوبت‌دهی آنلاین",            "calendar",  True,
     "مشتری بدون تماس نوبت می‌گیرد؛ دفتر نوبت کاغذی حذف می‌شود"),
    ("stats",        "آمار بازدید و تماس",         "chart",     True,
     "ببینید چند نفر صفحه‌تان را دیدند و شماره‌تان را گرفتند"),
    ("reply",        "پاسخ به نظرات",              "message",   True,
     "زیر هر نظر پاسخ رسمی بگذارید"),
    ("qa",           "پاسخ به پرسش‌ها",            "help",      True,
     "به سؤال مشتریان جواب دهید و اعتماد بسازید"),
    ("inquiry",      "دریافت پیام مشتری",          "message",   True,
     "مشتری بدون نیاز به شمارهٔ تلفن پیام می‌دهد"),
    ("social",       "لینک اینستاگرام و تلگرام",   "instagram", True,
     "شبکه‌های اجتماعی‌تان روی صفحه دیده شود"),
    ("featured",     "جایگاه ویژه در فهرست",       "sparkles",  False,
     "بالای نتایج جست‌وجو، پیش از رقبا"),
    ("homepage",     "نمایش در صفحهٔ نخست",        "star",      False,
     "در بخش «کسب‌وکارهای ویژهٔ شهر» صفحهٔ اصلی"),
    ("banner",       "بنر تبلیغاتی",               "zap",       False,
     "بنر شما در صفحهٔ اصلی و فهرست‌ها نمایش داده می‌شود"),
    ("event",        "ثبت رویداد و مناسبت",        "calendar",  False,
     "حراج، افتتاحیه و جشنواره‌تان را اعلام کنید"),
    ("export",       "خروجی اکسل مشتریان",         "download",  False,
     "فهرست نوبت‌ها و درخواست‌ها را دانلود کنید"),
]

FEATURE_LABELS = {k: lbl for k, lbl, _i, _f, _w in FEATURES}
FEATURE_ICONS = {k: ic for k, _l, ic, _f, _w in FEATURES}
FEATURE_WHY = {k: why for k, _l, _i, _f, why in FEATURES}
FOUNDER_FEATURES = [k for k, _l, _i, f, _w in FEATURES if f]

# The founding-member promise: the first N shops keep the generous set for
# free, forever. Everyone after them gets the medium set.
FOUNDER_LIMIT_KEY = "founder_limit"       # how many shops count as founders
FOUNDER_ITEMS_KEY = "founder_max_items"
FOUNDER_PHOTOS_KEY = "founder_max_photos"


def founder_settings():
    s = get_settings()
    def _i(k, d):
        try:
            return int(s.get(k, d))
        except Exception:
            return d
    return {
        "limit": _i(FOUNDER_LIMIT_KEY, 100),
        "items": _i(FOUNDER_ITEMS_KEY, 10),
        "photos": _i(FOUNDER_PHOTOS_KEY, 6),
        "plain_items": _i("free_max_items", 3),
        "plain_photos": _i("free_max_photos", 3),
    }


def founder_rank(biz_id):
    """1-based position among all shops, oldest first. Used to decide who is
    inside the founding-member window. Returns None if the shop is gone."""
    r = _one("SELECT COUNT(*) n FROM businesses WHERE id <= ? ", (biz_id,))
    return r["n"] if r else None


def is_founder(biz_id):
    """The promise made on the doorstep: 'you are shop number 23, the first
    100 keep these features free forever'. Rank is by id, so it can never be
    taken away by later signups."""
    cfg = founder_settings()
    if cfg["limit"] <= 0:
        return False
    rank = founder_rank(biz_id)
    return bool(rank and rank <= cfg["limit"])


def founders_left():
    cfg = founder_settings()
    n = _one("SELECT COUNT(*) c FROM businesses")["c"]
    return max(0, cfg["limit"] - n)


def _manual_grants(biz_id):
    """Features the admin unlocked by hand for this shop — the key you hold."""
    r = _one("SELECT unlocked FROM biz_features WHERE biz_id=?", (biz_id,))
    if not r or not r["unlocked"]:
        return set()
    return {x for x in r["unlocked"].split(",") if x}


def set_manual_grants(biz_id, keys):
    access_cache_clear()
    keys = [k for k in keys if k in FEATURE_LABELS]
    _run("INSERT INTO biz_features(biz_id,unlocked) VALUES(?,?) "
         "ON CONFLICT(biz_id) DO UPDATE SET unlocked=excluded.unlocked",
         (biz_id, ",".join(keys)))
    log("feature.grant", f"{biz_id}: {','.join(keys) or '(none)'}")
    return len(keys)


def grant_feature(biz_id, key):
    access_cache_clear()
    cur = _manual_grants(biz_id)
    cur.add(key)
    return set_manual_grants(biz_id, list(cur))


def revoke_feature(biz_id, key):
    access_cache_clear()
    cur = _manual_grants(biz_id)
    cur.discard(key)
    return set_manual_grants(biz_id, list(cur))


def plan_features(plan_slug):
    """Which feature keys a plan includes. Stored as a comma list on the plan
    so you can change what each tier offers from the panel, without code."""
    p = plan(slug=plan_slug)
    if not p:
        return set()
    raw = (p.get("features") or "").strip()
    if raw == "*":
        return set(FEATURE_LABELS)
    return {x.strip() for x in raw.split(",") if x.strip()}


def latest_subscription(biz_id):
    """Most recent real subscription of any status — used for soft expiry so a
    lapsed paid plan keeps its features instead of gutting the shop overnight."""
    rows = [r for r in subscriptions(biz_id=biz_id)
            if r["status"] in ("active", "expired", "cancelled")]
    return max(rows, key=lambda r: r["id"]) if rows else None


def access_cache_clear():
    """Compatibility no-op. Global memoisation was removed: a module-level
    cache cannot see mutations made by ANOTHER process (the HTTP server and
    test/CLI runs each have their own memory), which produced stale access()
    results. apply_promotion() memoises locally instead."""
    pass


def access(biz_id):
    """The single source of truth for what one shop may do right now.

    SOFT EXPIRY: a lapsed paid plan KEEPS its features (photos, catalogue,
    badges, placement) so a late payment never wrecks a live business. Only
    the ADD-quota (max_items / max_photos) reverts to the free tier — the shop
    cannot add NEW things past the free cap, but nothing it already has is
    taken away and editing stays free. Renewing restores the full quota.

    Precedence for the feature keys (most permissive wins):
      1. a live paid subscription  — or a lapsed one, for soft expiry
      2. a manual unlock by the admin  (your key)
      3. the founding-member window    (first N shops)
      4. the plain free tier

    Results are memoised for a few seconds: a page render calls this many
    times per shop (list + gates), and the data cannot change mid-request.
    """
    cfg = founder_settings()
    sub = subscription_of(biz_id)           # live only
    latest = latest_subscription(biz_id)    # most recent, any status
    manual = _manual_grants(biz_id)
    founder = is_founder(biz_id)

    keys = set(manual)
    source = {k: "manual" for k in manual}

    if founder:
        for k in FOUNDER_FEATURES:
            keys.add(k)
            source.setdefault(k, "founder")

    # Which plan's FEATURES stay active: the live sub, or — on soft expiry —
    # the most recent paid plan that has since lapsed.
    feat_slug = None
    expired = False
    if sub:
        feat_slug = sub["plan_slug"]
    elif latest and latest["status"] == "expired":
        lp = plan(slug=latest["plan_slug"])
        if lp and lp["price"] > 0:
            feat_slug = latest["plan_slug"]
            expired = True
    if feat_slug:
        for k in plan_features(feat_slug):
            keys.add(k)
            source.setdefault(k, "plan-expired" if expired else "plan")

    # Quotas follow the LIVE subscription only. Expired -> free quotas, so the
    # shop can keep and edit everything it has but cannot add past the free cap.
    p = plan(slug=sub["plan_slug"]) if sub else None
    if p:
        max_items, max_photos = p["max_items"], p["max_photos"]
        plan_name = p["name"]
    elif founder:
        max_items, max_photos = cfg["items"], cfg["photos"]
        plan_name = "بنیان‌گذار"
    else:
        max_items, max_photos = cfg["plain_items"], cfg["plain_photos"]
        plan_name = "پایه (رایگان)"

    result = {
        "keys": keys,
        "source": source,
        "founder": founder,
        "rank": founder_rank(biz_id),
        "plan": (p or {}).get("slug", "free"),
        "plan_name": plan_name,
        "paid": bool(p and p.get("price")),
        "expired": expired,
        "expires": sub.get("expires") if sub else (latest.get("expires") if latest else None),
        "days_left": sub.get("days_left") if sub else (latest.get("days_left") if latest else None),
        "max_items": max_items,
        "max_photos": max_photos,
    }
    return result


def can(biz_id, key):
    """Server-side check. Never trust the UI — every gated route calls this."""
    return key in access(biz_id)["keys"]


def locked_features(biz_id):
    a = access(biz_id)
    return [k for k, _l, _i, _f, _w in FEATURES if k not in a["keys"]]


# --------------------------------------------------------------------------
#  Applying the gate to placement features
#
#  `featured` (top of listings), `homepage` (front-page strip) and `banner`
#  are things the admin flips on a business, but they are also things people
#  pay for. Both must be true at once: the admin said yes AND the shop holds
#  the feature. Enforcing it here rather than in each template means a lapsed
#  subscription silently stops the promotion everywhere, with no stale flag
#  left behind in the businesses table to clean up.
# --------------------------------------------------------------------------
def is_promoted(b, key="featured"):
    """Does this business row genuinely get the placement `key` right now?"""
    if not b or not b.get("id"):
        return False
    if key == "featured" and not b.get("featured"):
        return False
    return can(b["id"], key)


def apply_promotion(rows):
    """Strip the `featured` flag from any row that no longer pays for it, and
    stamp `on_homepage` so callers do not each re-query access().

    One access() call per row (was two), and access() itself is TTL-cached,
    so listing 500 shops costs ~1 query per shop instead of ~10. (Perf fix.)"""
    local = {}
    for b in rows:
        acc = local.get(b["id"]) or access(b["id"])
        local[b["id"]] = acc
        keys = acc["keys"]
        if b.get("featured") and "featured" not in keys:
            b["featured"] = 0
        b["on_homepage"] = "homepage" in keys
    return rows


def homepage_businesses(limit=6):
    """The front-page strip. Only shops holding `homepage` may appear; if too
    few qualify, the remainder is filled with the best-rated shops so the
    section is never a sad half-empty row on a young directory."""
    rows = apply_promotion(businesses(status="published", order="featured"))
    picked = [b for b in rows if b.get("on_homepage")][:limit]
    if len(picked) < limit:
        have = {b["id"] for b in picked}
        for b in rows:
            if b["id"] not in have:
                picked.append(b)
                if len(picked) >= limit:
                    break
    return picked[:limit]

# ==========================================================================
#  FEATURES — customers, chat, orders, areas, favourites, toplists, deals,
#  stories, follows, notifications, moderation  (v28→v34)
#  Moved to server/features.py (architecture: keep this file a focused data
#  layer). Re-exported here so every existing `db.<name>` call site still
#  works unchanged.
# ==========================================================================
from features import *  # noqa: F401,F403


# ==========================================================================
#  CITIES  (v37 — nationwide: all Iranian provinces & cities)
# ==========================================================================
def provinces():
    return [r["province"] for r in _rows(
        "SELECT province FROM cities GROUP BY province ORDER BY province")]


def cities_in(province):
    return _rows("SELECT * FROM cities WHERE province=? ORDER BY is_capital DESC, name",
                 (province,))


def city_province(city):
    r = _one("SELECT province FROM cities WHERE name=?", (city,))
    return r["province"] if r else ""


def cities_all():
    return _rows("SELECT * FROM cities ORDER BY province, is_capital DESC, name")


def businesses_city_counts():
    return _rows(
        "SELECT COALESCE(city,'') city, COUNT(*) c FROM businesses "
        "WHERE status='published' GROUP BY city ORDER BY c DESC")
