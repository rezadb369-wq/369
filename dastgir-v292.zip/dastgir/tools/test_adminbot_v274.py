#!/usr/bin/env python3
# دستور مدیر: پین انتشار با v281 هماهنگ شد؛ رفتار محصول تغییر نکرده است.
# -*- coding: utf-8 -*-
"""v274 (دستور مدیر — ریشه در اسکرین‌شات بله): کلید لخت دیگر در تاریخچهٔ چت
نمی‌ماند.

در اسکرین‌شات، مالک کلید GLM را به‌صورت حبابِ لخت در چت فرستاده بود و همان‌جا
مانده بود. حالا:
1) adminbot.delete_message() یک حذف best-effort (deleteMessage) است که هرگز
   raise نمی‌کند.
2) handle_update هر پیامِ حاوی کلید (الگوی _REDACT_RX) را بلافاصله بعد از مصرف
   حذف می‌کند و تأیید «حذف شد» را به پاسخ می‌چسبد؛ خودِ کلید در پاسخ redact است.
3) پیامِ بدون کلید دست‌نخورده می‌ماند (حذفی رخ نمی‌دهد).
4) پین نسخهٔ ۲۷۴ در پنج جای قرارداد.
"""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v274-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '111,222'
for k in ('AI_BASE_URL', 'AI_API_KEY', 'AI_MODEL', 'AI_MODEL_SMART',
          'AI_SITE_BASE_URL', 'AI_SITE_API_KEY', 'AI_SITE_MODEL'):
    os.environ.pop(k, None)
sys.path.insert(0, str(ROOT / 'server'))

import db  # noqa: E402
import adminbot as A  # noqa: E402

db.init()
n = 0


def ck(ok, label):
    global n
    assert ok, label
    n += 1
    print('  ✓', label)


CALLS = []
def fake_call(method, payload):
    CALLS.append((method, dict(payload)))
    return {"ok": True}
A._call = fake_call

KEY = "aa-" + "Z" * 30   # یک کلید لخت نمونه

# ---- 1. delete_message: best-effort, never raises ----
ck(A.delete_message("111", 555) is True, 'delete_message returns True on ok')
ck(any(m == "deleteMessage" and p.get("message_id") == 555 and p.get("chat_id") == 111
       for m, p in CALLS), 'deleteMessage issued with chat+message id')
A._call = lambda m, p: {"ok": False}
ck(A.delete_message("111", 1) is False, 'delete_message False when platform says no')
A._call = lambda m, p: (_ for _ in ()).throw(RuntimeError('net down'))
try:
    ok = A.delete_message("111", 2)
    ck(ok is False, 'delete_message swallows network errors (never raises)')
except Exception:
    ck(False, 'delete_message must never raise')
A._call = fake_call
CALLS.clear()

# ---- 2. handle_update: a raw-key bubble is purged + confirmed, key redacted ----
update = {"message": {"message_id": 777,
                      "text": KEY,
                      "chat": {"id": 111, "type": "private"},
                      "from": {"id": 999}}}
A.handle_update(update)
del_calls = [(m, p) for m, p in CALLS if m == "deleteMessage"]
send_calls = [(m, p) for m, p in CALLS if m == "sendMessage"]
ck(any(p.get("message_id") == 777 for _, p in del_calls),
   'the incoming raw-key message is deleted')
ck(send_calls, 'a reply was sent')
reply = send_calls[-1][1].get("text", "")
ck("حذف شد" in reply, 'reply confirms the key message was deleted')
ck(KEY not in reply, 'the raw key never appears verbatim in the reply')

# ---- 3. a normal message is NOT deleted ----
CALLS.clear()
A.handle_update({"message": {"message_id": 778, "text": "سلام",
                             "chat": {"id": 111, "type": "private"},
                             "from": {"id": 999}}})
ck(not any(m == "deleteMessage" for m, _ in CALLS),
   'non-key message left untouched (no deleteMessage)')

# ---- 4. version pins (5-way) ----
ver = (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip()
sw = (ROOT / 'site' / 'sw.js').read_text(encoding='utf-8')
rd = (ROOT / 'README.md').read_text(encoding='utf-8')
cs = (ROOT / 'docs' / 'collaboration' / 'CURRENT-STATE.md').read_text(encoding='utf-8')
# v289 (دستور مدیر، RULES §۲): پین نسخه از روی VERSION.txt خوانده می‌شود.
# پیش از این عدد ۲۸۱ سخت‌کد بود و از v282 به بعد همیشه قرمز می‌شد؛
# خودِ ناملموس (هماهنگی ۵ نقطه + کش‌شکن) همان‌طور تست می‌ماند.
ck(ver == A.DIAG_LATEST and ('bazarche-v' + ver) in sw and
   any(('دست گیر — v' + ver) in ln for ln in rd.splitlines()[:20]) and
   ('v' + ver) in cs.splitlines()[0],
   'version pins: VERSION.txt + DIAG_LATEST + sw.js + README + CURRENT-STATE = ' + ver)
ck(('assist.js?v' + ver) in (ROOT / 'server' / 'ui.py').read_text(encoding='utf-8'),
   'ui.py serves the chat script with ?v274 (cache-bust)')

print(f"\n  {n} checks passed — adminbot v274 key-purge OK")
