#!/usr/bin/env python3
# دستور مدیر: پین انتشار با v281 هماهنگ شد؛ رفتار محصول تغییر نکرده است.
# -*- coding: utf-8 -*-
"""v271: گزینه‌های دیده‌شدنی بات مدیر + تایمر ۱۰ دقیقهٔ صفحهٔ چت.

اعتراض مدیر (۲۰۲۶-۰۹-۱۲): «تو ربات بله اصلا گزینه‌ای برای سوئیچ کردن
[هوش سایت] اضافه نشده» + «توکن تمام مدل‌ها … برا تک به تکشون گزینه باشه
تو ربات بله» + «صفحهٔ چت تایمر ده دقیقه‌ای نداره» + «مطمئن هستی گزارش
چت‌ها ذخیره میشه و فایلش را از ربات بله بگیرم؟»

Pins:
1)  صفحه‌کلید اصلی: «هوش سایت»/«کلیدها»/«چت‌ها» دیده می‌شوند (v280: ۱۰ ردیف با «اسپم»).
2)  «هوش سایت» → پنل + SITE_KEYBOARD؛ ضربه روی دکمهٔ مدل = سوئیچ با تست
    زنده (۴۰۴ = رد صادقانه، مدل قبلی سر جایش) و بازگشت صفحه‌کلید اصلی.
3)  «کلیدها» → وضعیت ۶ کلید + KEY_KEYBOARD؛ «کلید اپوس/سونت/هایکو/اوپن/
    GLM/سایت» → pending و کلید لخت بعدی دقیقاً در اسلات همان مغز
    (job.provider/slot) — بقیهٔ اسلات‌ها دست‌نخورده. «نه» لغو؛ «بله»
    هنگام انتظار کلید هرگز ری‌استارت صف نمی‌کند.
4)  تایمر صفحهٔ چت: assist.js ساعت ۱۰ دقیقهٔ دیده‌شدنی دارد (MEM_MS=600000)
    که با هر تبادل ریست و با انقضا تاریخچهٔ کلاینت پاک می‌شود.
5)  پایان‌به‌پایان HTTP: POST /api/assistant/chat → ۲۰۰ و همان تبادل در
    data/site_chats.log ثبت می‌شود؛ «چت‌ها» همان فایل را می‌فرستد.
6)  brain.env نُه‌خطی + انحصار هش کلید سایت · پین پنج‌جانبهٔ ۲۷۱.
"""
import hashlib
import http.server
import json
import os
import re
import sys
import tempfile
import threading
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# v289: deploy/brain.env carries the live AI keys and is stripped from any
# shared artifact on purpose (RULES: secrets never leave the box). When the
# file is absent this suite cannot test the brain, so it reports a named
# environmental skip with exit 78 (EX_CONFIG) instead of a red that looks like
# a code fault. Put the real brain.env back and it runs for real.
_BRAIN = ROOT / "deploy" / "brain.env"
if not _BRAIN.is_file():
    print("SKIP  deploy/brain.env موجود نیست — این سوئیت مغز AI را تست می‌کند و")
    print("      کلیدها عمداً از بستهٔ اشتراکی حذف شده‌اند. فایل را برگردانید")
    print("      تا واقعی اجرا شود. (خروجی ۷۸ = EX_CONFIG، نه شکست کد)")
    raise SystemExit(78)


TMP = tempfile.mkdtemp(prefix='adm-v271-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'https://api.example.invalid/v1'
os.environ['AI_API_KEY'] = 'test-legacy-key-not-real'
os.environ['AI_MODEL'] = 'fake-lite'
os.environ['AI_BRAIN_OPUS_KEY'] = 'aa-opus' + 'o' * 40
os.environ['AI_BRAIN_SONNET_KEY'] = 'aa-sonnet' + 's' * 38
os.environ['AI_SITE_BASE_URL'] = 'https://site.example.invalid/v1'
os.environ['AI_SITE_API_KEY'] = 'aa-sitekey0000000000000000000000'
os.environ['AI_SITE_MODEL'] = 'glm-5.3-flash'
sys.path.insert(0, str(ROOT / 'server'))
import db, adminbot as A, assistant as AI   # noqa: E402

n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)
CALLS = []
def fake_chat(base, key, model, msgs, timeout, max_tokens=220):
    CALLS.append((base, key, model))
    return ('{"answer":"باشه","links":[],"scope":true,"intent":"faq"}', 7)
AI._chat = fake_chat

# ================= 1. keyboards are visible =================
K = A.KEYBOARD['keyboard']
# دستور مدیر v280 (فاز۵): ردیف «اسپم» (کنسول ضداسپم) اضافه شد => ۱۰ ردیف.
ck(len(K) == 10 and ['هوش سایت', 'کلیدها'] in K and ['چت‌ها'] in K and ['اسپم'] in K,
   'main keyboard shows «هوش سایت», «کلیدها», «چت‌ها» + «اسپم» (10 rows)')
ck([r for r in A.SITE_KEYBOARD['keyboard']][0] == ['glm-5.3-flash', 'glm-5.3'],
   'site keyboard offers the documented AvalAI model ids')
ck(len(A.KEY_KEYBOARD['keyboard']) == 4 and
   ['کلید اپوس', 'کلید سونت'] in A.KEY_KEYBOARD['keyboard'],
   'key keyboard: one button per brain')

# ================= 2. «هوش سایت» panel + one-tap model switch =================
r, kb = t('هوش سایت')
ck('هوش عمومی سایت' in r and 'glm-5.3-flash' in r and kb == A.SITE_KEYBOARD,
   '«هوش سایت» opens the site-AI panel with the site keyboard')
db.set_settings({'ai_site_model': ''})
r, kb = t('glm-5.3')
ck(db.get_settings().get('ai_site_model') == 'glm-5.3' and kb == A.KEYBOARD,
   'tapping «glm-5.3» live-tests then switches, restoring the main keyboard')
# 404 → honest refusal, previous model stays
def chat_404(base, key, model, msgs, timeout, max_tokens=220):
    raise urllib.error.HTTPError(base, 404, 'not found', {}, None)
_real_chat = AI._chat
AI._chat = chat_404
r, kb = t('مدل سایت glm-9.9-nope')
ck('عوض نشد' in r and db.get_settings().get('ai_site_model') == 'glm-5.3',
   'a dead model id is refused honestly — the previous model stays')
AI._chat = _real_chat
r, kb = t('glm-5.3-flash')
ck(db.get_settings().get('ai_site_model') == 'glm-5.3-flash',
   'tapping «glm-5.3-flash» switches the site model back')

# ================= 3. «کلیدها» — per-model token replacement =================
r, kb = t('کلیدها')
ck(kb == A.KEY_KEYBOARD and r.count('✅') >= 3 and 'هوش سایت' in r,
   '«کلیدها» lists the six key slots with their status')
r, kb = t('کلید اپوس')
pend = json.loads(Path(A.pending_path()).read_text(encoding='utf-8'))
ck('کلید تازهٔ «اپوس»' in r and pend.get('action') == 'key_for'
   and pend.get('target') == 'اپوس',
   '«کلید اپوس» arms the key_for pending state')
r, kb = t('بله')
ck('کلید را لخت بفرست' in r,
   'a stray «بله» while waiting for a key NEVER queues a restart')
import glob as _g2
def ai_jobs():
    out = []
    for p in sorted(_g2.glob(os.path.join(TMP, '**', '*.json'), recursive=True)):
        try:
            j = json.loads(Path(p).read_text(encoding='utf-8'))
        except Exception:
            continue
        if isinstance(j, dict) and j.get('kind') == 'ai_key':
            out.append(j)
    return out
NEW_OPUS = 'aa-' + 'N' * 44
t('کلید اپوس')      # re-arm: the «بله» probe consumed the pending state
r, kb = t(NEW_OPUS)
jk = ai_jobs()
ck(bool(jk) and jk[-1].get('provider') == 'muse' and jk[-1].get('slot') == 'opus'
   and jk[-1].get('key') == NEW_OPUS,
   'the bare key landed in the OPUS slot (provider=muse, slot=opus)')
ck(not any(j.get('slot') in ('sonnet', 'haiku') for j in jk),
   'no other claude slot was touched')
r, kb = t('کلید سایت')
NEW_SITE = 'aa-' + 'S' * 44
r, kb = t(NEW_SITE)
jk = ai_jobs()
ck(jk[-1].get('provider') == 'site' and jk[-1].get('key') == NEW_SITE
   and jk[-1].get('model') == 'glm-5.3-flash',
   '«کلید سایت» + bare aa- key queues the site slot (default model kept)')
# «نه» cancels
t('کلید GLM')   # دستور مدیر v273: کیرا کلا حذف شد
r, kb = t('نه')
pend = json.loads(Path(A.pending_path()).read_text(encoding='utf-8')) \
    if Path(A.pending_path()).exists() else {}
ck('لغو' in r and pend.get('action') != 'key_for',
   '«نه» cancels the pending key state')
# direct command form
r, kb = t('/کلید هایکو aa-' + 'H' * 44)
jk = ai_jobs()
ck(jk[-1].get('slot') == 'haiku',
   '/کلید هایکو aa-… installs into the haiku slot directly')

# ================= 4. the visible 10-minute timer on the chat page =================
js = (ROOT / 'site' / 'assets' / 'js' / 'assist.js').read_text(encoding='utf-8')
ck('MEM_MS = 600000' in js and 'memReset()' in js and 'حافظهٔ چت' in js,
   'assist.js has the visible 10-minute memory clock (600000 ms)')
ck(js.count('memReset()') >= 2 and 'history.length = 0' in js,
   'the clock restarts on every exchange and clears client history on expiry')
ck(AI.THREAD_TTL == 600,
   'server-side thread TTL matches the visible timer (600 s)')

# ================= 5. end-to-end: web chat → log file → «چت‌ها» =================
import app as APPMOD   # noqa: E402
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), APPMOD.App)
port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
try:
    req = urllib.request.Request(
        f'http://127.0.0.1:{port}/api/assistant/chat',
        data=json.dumps({'text': 'سلام دستگیر', 'history': []}).encode(),
        headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        body = json.loads(resp.read().decode())
        code = resp.status
finally:
    srv.shutdown()
ck(code == 200 and body.get('ok') and (body.get('text') or '').strip(),
   'POST /api/assistant/chat answers 200 through the real HTTP stack')
ck(body.get('source') in ('rule', 'rule-fallback', 'cache', 'llm'),
   'the guest exchange is served (v259 gate: guests get rules/cache, not tokens)')
log_txt = Path(AI.CHAT_LOG).read_text(encoding='utf-8')
ck('سلام دستگیر' in log_txt,
   'the very same web exchange was written to data/site_chats.log')
DOCS = []
A.send_document = lambda cid, path, caption='': DOCS.append((str(cid), path, caption)) or True
r = A.handle_text('u1', CHAT, 'چت‌ها')[0]
sent = Path(DOCS[-1][1]).read_text(encoding='utf-8')
ck(len(DOCS) == 1 and 'سلام دستگیر' in sent and 'ارسال شد' in r,
   '«چت‌ها» delivers exactly that file to the owner from the Bale bot')

# ================= 6. brain.env + version pins =================
be = (ROOT / 'deploy' / 'brain.env').read_text(encoding='utf-8')
_ai = [ln for ln in be.splitlines() if ln.startswith('AI_')]
_vals = dict(ln.partition('=')[::2] for ln in _ai)
ck(len(_ai) == 9 and 'AI_SITE_MODEL=glm-5.3-flash' in _ai,
   'brain.env still ships the 9-line store (site = glm-5.3-flash)')
_site_sha = hashlib.sha256(_vals['AI_SITE_API_KEY'].encode()).hexdigest()
_rx = re.compile(r'aa-[A-Za-z0-9]{30,}')
where = set()
for p in ROOT.rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts or '.git' in p.parts:
        continue
    try:
        txt = p.read_text(encoding='utf-8', errors='ignore')
    except OSError:
        continue
    for m in _rx.findall(txt):
        if hashlib.sha256(m.encode()).hexdigest() == _site_sha:
            where.add(str(p.relative_to(ROOT)))
ck(where == {'deploy/brain.env'},
   'the live site key exists ONLY in deploy/brain.env (hash-pinned)')
ver = (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip()
sw = (ROOT / 'site' / 'sw.js').read_text(encoding='utf-8')
rd = (ROOT / 'README.md').read_text(encoding='utf-8')
cs = (ROOT / 'docs' / 'collaboration' / 'CURRENT-STATE.md').read_text(encoding='utf-8')
# دستور مدیر v280: پین به آخرین انتشار بامپ شد.
ck(ver == '281' and A.DIAG_LATEST == '281' and 'bazarche-v281' in sw and
   any('دست گیر — v281' in ln for ln in rd.splitlines()[:20]) and
   'v281' in cs.splitlines()[0],
   'version pins: VERSION.txt + DIAG_LATEST + sw.js + README + CURRENT-STATE')

print(f'\n✅ test_adminbot_v271: {n}/{n} checks green')
