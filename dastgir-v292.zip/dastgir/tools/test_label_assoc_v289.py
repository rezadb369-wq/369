#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
test_label_assoc_v289.py — «برچسب فیلدهای پنل به کنترلشان وصل است»

چرا این تست وجود دارد
-----------------------
پانزده فرم پنل این‌طور رندر می‌شدند:

    <div class="field"><label class="field-label">نام</label><input …></div>

<label> بدون for و کنترل بدون id یعنی هیچ ارتباط برنامه‌ای بین این دو نیست؛
صفحه‌خوان فقط «کادر ویرایش» می‌گوید و هیچ نامی announcing نمی‌کند. در ممیزی
v289 دقیقاً ۱۰۷ کنترل بی‌نام فقط در /panel/assistant شمرده شد.

چرا «تودرتو» نه
---------------
راه‌حل بدیهی این است که </label> را به بعد از کنترل ببریم تا کنترل نوهٔ
label شود. این راه در Chromium اندازه‌گیری شد و رد شد: پارسر HTML وقتی داخل
<textarea> باشد، «</label>» را تگ حساب نمی‌کند؛ در نتیجه مقدار فیلد دقیقاً
رشتهٔ «</label>» می‌شد — یعنی خرابی مرئی. for/id هیچ لبهٔ پارسری ندارد.

این تست هم تابع را واحد‌آزمون می‌کند و هم صفحهٔ زندهٔ پنل را.
"""
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "server"))

BZ = os.environ.get("BZ", "http://127.0.0.1:8080")
ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  ✓ {label}")
    else:
        bad_n += 1
        FAILS.append(label)
        print(f"  ✗ {label} — {detail}")


def head(t):
    print(f"\n══ {t} " + "═" * max(0, 56 - len(t)))


from label_assoc import associate_field_labels as xf   # noqa: E402

# ---------------------------------------------------------------- 1. unit
head("۱) تبدیل، روی نمونه‌های لبه‌ای")

CASES = {
    "input ساده": ('<div class="field"><label class="field-label">عنوان</label>'
                   '<input class="input" name="t"></div>', True),
    "textarea": ('<div class="field"><label class="field-label">پاسخ</label>'
                 '<textarea name="a">متن</textarea></div>', True),
    "select": ('<div class="field"><label class="field-label">نوع</label>'
               '<select name="k"><option>۱</option></select></div>', True),
    "خودبستهٔ />": ('<div class="field"><label class="field-label">چک</label>'
                    '<input type="checkbox" name="k" /></div>', True),
    "کنترل از قبل id دارد": ('<div class="field"><label class="field-label">رنگ</label>'
                             '<input id="col" name="c"></div>', True),
    "label از قبل for دارد": ('<div class="field"><label class="field-label" for="x">نام</label>'
                              '<input id="x" name="n"></div>', False),
    # v289: a control nested in inline <span> wrappers IS reachable — that is
    # the Jalali date picker on /panel/deals, and it used to stay unnamed.
    "کنترل داخل span (تقویم شمسی)": (
        '<div class="field"><label class="field-label">پایان</label>'
        '<span class="jd"><span class="jd-ctrl"><input name="d"></span></span></div>', True),
    "کنترل داخل div (قابل‌دسترس نیست)": (
        '<div class="field"><label class="field-label">تاریخ</label>'
        '<div class="cal"><input name="d"></div></div>', False),
    "div تودرتو": ('<div class="field"><label class="field-label">ک</label>'
                   '<div class="wrap"><input name="w"></div></div>', False),
}
for name, (src, should_change) in CASES.items():
    out = xf(src)
    check(f"{name}: changed={should_change}", (out != src) is should_change,
          f"got changed={out != src}")
    check(f"{name}: تگ‌ها متوازن", out.count("<label ") == out.count("</label>"),
          f"open={out.count('<label ')} close={out.count('</label>')}")
    check(f"{name}: هیچ </label> داخل مقدار نشت نکرده",
          "</label>" not in out.split("<textarea", 1)[-1].split(">", 1)[-1].split("</textarea>", 1)[0]
          if "<textarea" in out else True)

# self-closing must stay self-closing — a stray "/" made malformed markup once
sc = xf(CASES["خودبستهٔ />"][0])
check("خودبسته: '/ id=' تولید نمی‌شود (مارک‌آپ سالم)", "/ id=" not in sc, sc[:120])
check("خودبسته: id قبل از '/>' نشست", 'id="fld-چک" />' in sc, sc[:120])

# duplicate label text must not collide on the same page
dup = ('<div class="field"><label class="field-label">سؤال</label><input name="q"></div>'
       '<div class="field"><label class="field-label">سؤال</label><input name="q"></div>')
out = xf(dup)
ids = [p.split('id="', 1)[1].split('"', 1)[0] for p in out.split("<input")[1:]]
check("id تکراری ساخته نمی‌شود", len(set(ids)) == len(ids), str(ids))
check("id از متن برچسب ساخته می‌شود (خوانا در DOM)",
      all(i.startswith("fld-") for i in ids), str(ids))

# ---------------------------------------------------------------- 2. live
head("۲) صفحهٔ زندهٔ پنل")
try:
    sys.path.insert(0, os.path.join(ROOT, "server"))
    os.environ.setdefault("BZ_DATA_DIR", "/tmp/bzdata")
    import db
    key = db.owner_token()
except Exception as e:                                       # pragma: no cover
    key = None
    print(f"  ! کلید مالک خوانده نشد ({e}) — بخش زنده رد می‌شود")

# The live half needs the key that the RUNNING server holds. When this suite's
# BZ_DATA_DIR is a different database from the server's (the isolated runner
# seeds a throwaway DB per suite), the key will not match and every panel page
# answers 403. That is a harness mismatch, not a product fault, so probe first
# and skip the live half by name instead of reporting five false failures.
if key:
    try:
        urllib.request.urlopen(f"{BZ}/panel?key={key}", timeout=25).read()
        live_ok = True
    except Exception as e:
        live_ok = False
        print(f"  ! پنل زنده با این کلید باز نشد ({e}) — BZ_DATA_DIR این سوئیت")
        print("    با دیتابیس سرورِ در حال اجرا یکی نیست. نیمهٔ زنده رد می‌شود؛")
        print("    نیمهٔ واحد‌آزمون بالا مستقل از سرور معتبر است.")
else:
    live_ok = False

if key and live_ok:
    for path in ("/panel/assistant", "/panel/settings", "/panel/deals",
                 "/panel/categories", "/panel/alerts"):
        try:
            html = urllib.request.urlopen(f"{BZ}{path}?key={key}", timeout=25).read().decode("utf-8")
        except Exception as e:
            check(f"{path}: صفحه باز شد", False, str(e))
            continue
        # every field-label must carry a for= pointing at an id that exists
        import re
        labels = re.findall(r'<label class="field-label"([^>]*)>', html)
        fors = [m.group(1) for m in
                (re.search(r'for="([^"]+)"', a) for a in labels) if m]
        ids = set(re.findall(r'\bid="([^"]+)"', html))
        dangling = [f for f in fors if f not in ids]
        bare = len(labels) - len(fors)
        check(f"{path}: هیچ برچسب .field-label بی‌for نمانده", bare == 0, f"{bare} بی‌for از {len(labels)}")
        check(f"{path}: هیچ for معلقی نیست", not dangling, str(dangling[:4]))
        check(f"{path}: رشتهٔ '</label>' داخل هیچ textarea نیست",
              "</label>" not in "".join(re.findall(r"<textarea[^>]*>([\s\S]*?)</textarea>", html)))

print("\n" + "═" * 60)
if FAILS:
    print(f"✗ {bad_n} ناموفق، {ok_n} موفق")
    for f in FAILS:
        print("   -", f)
    sys.exit(1)
print(f"✓ همهٔ {ok_n} بررسی سبز — برچسب فیلدها به کنترلشان وصل است")
