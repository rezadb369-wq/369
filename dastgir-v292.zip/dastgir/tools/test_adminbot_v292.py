#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v292 — رفع باگ زندهٔ مدیر: «/کلید glm aa-…» رد می‌شد و یک دقیقه بعد
پیام «⚠️ بخشی از تغییرات کد اعمال نشد …» از کدگارد می‌آمد.

ریشهٔ بازتولیدشده (قبل از رفع):
  deploy/codeguard.sh، بخش ai_key — گیت اعتبارسنجی این بود:
      if not base or not re.fullmatch(KEY_RX, key):  ← رد با «invalid shape»
  و base فقط در دو شاخه پر می‌شد:
      prov in ("gemini","groq","astra","muse","openrouter")  و  ("openai","site")
  «glm» در هیچ‌کدام نبود ⇒ base = "" ⇒ not base همیشه True ⇒ هر کلید GLM
  (حتی کاملاً سالم) با «ai_key: invalid shape» رد می‌شد ⇒ failed=['ai_key']
  ⇒ rc=1 ⇒ همان اعلان هشدار برای مدیر. کلید سالم بود؛ کد رد می‌کرد.

قراردادی که این تست قفل می‌کند:
  * job «ai_key / provider=glm» با کلید aa- توسط کدگارد نصب می‌شود
    (اسلات AI_BRAIN_GLM_KEY، base پیش‌فرض AvalAI، مدل glm-5.3-flash).
  * اسلات قدیمی کیرا پاک می‌شود؛ بقیهٔ اسلات‌های AI_BRAIN_* دست‌نخورده‌اند.
  * کلید بی‌شکل، کلید کوتاه و provider ناشناس همچنان رد می‌شوند
    (گیت شل نشده — خطا هم دقیق و جداگانه گزارش می‌شود).
  * سمت بات: «/کلید glm aa-…» صف می‌شود، کلید هیچ‌جا چاپ نمی‌شود.
  * کلید aa- با - یا _ هم پذیرفته می‌شود (کلیدهای واقعی AvalAI).
  * اعلان موفقیت («مغز هوش مصنوعی جدید وصل شد»)، نه هشدار شکست.
"""
import os
import json
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v292-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
import sys                                                        # noqa: E402
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db                                                         # noqa: E402
import adminbot as A                                              # noqa: E402
import assistant as AI                                            # noqa: E402
import adminbot_code as CODE                                      # noqa: E402
import adminbot_content as CT                                     # noqa: E402

n = 0


def ck(ok, label):
    global n
    assert ok, label
    n += 1
    print('  ✓', label)


A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
AI._chat = lambda *a, **k: ('{"reply":"باشه","tool":null}', 5)
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text, chat=CHAT: A.handle_text('u1', chat, text)[0]

GLM_KEY = 'aa-' + 'GLMKEY' * 8          # همان شکل توکن واقعی مدیر، ساختگی
assert len(GLM_KEY) == 51


def jobs():
    d = os.path.join(TMP, 'code-jobs')
    return [json.load(open(os.path.join(d, x), encoding='utf-8'))
            for x in sorted(os.listdir(d))] if os.path.isdir(d) else []


# ================= 1. سمت بات: /کلید glm با کلید aa-
r = t('/کلید glm ' + GLM_KEY)
ck('صف' in r, 'v292: /کلید glm صف می‌شود (پیام موفقیت صف)')
ck(GLM_KEY not in r, 'کلید هیچ‌وقت در پاسخ چاپ نمی‌شود')
_j = [x for x in jobs() if x.get('provider') == 'glm']
ck(_j and _j[-1]['kind'] == 'ai_key' and _j[-1]['key'] == GLM_KEY,
   'job درست صف شد: kind=ai_key، provider=glm، کلید دقیق')

# ================= 2. کلیدهای واقعی aa- می‌توانند - و _ داشته باشند
DASH_KEY = 'aa-abc-def_ghi-jkl-mno-pqr-stu-vwx-yz1'
ck(bool(CODE._KEY_RX['glm'].match(DASH_KEY)) and
   bool(CODE._KEY_RX['muse'].match(DASH_KEY)),
   'v292: کلید aa- با - و _ پذیرفته می‌شود (muse + glm)')
ck(CT._ai_setup_reason({'provider': 'glm', 'key': DASH_KEY}) == '',
   'precheck همان کلید را معتبر می‌داند')
r = t('/کلید glm ' + DASH_KEY)
ck('صف' in r and any(j.get('key') == DASH_KEY for j in jobs()),
   'کلید -دار از مسیر بات تا صف می‌رود')

# ================= 3. کدگارد واقعی: نصب کلید GLM (باگی که گزارش شد)
G = Path(tempfile.mkdtemp(prefix='cg292-'))
APP = G / 'app'
(APP / 'data' / 'code-jobs').mkdir(parents=True)
(APP / 'data' / 'code-backups').mkdir(parents=True)
(APP / 'site').mkdir(parents=True)
(APP / 'site' / 'sw.js').write_text(
    "const VERSION = 'bazarche-v292-merchant1';\n", encoding='utf-8')
SEC = G / 'secrets.env'
SEC.write_text('AI_BRAIN_OPUS_KEY=' + 'aa-' + 'o' * 40 + '\n'
               'AI_BRAIN_GLM_KEY=' + 'aa-' + 'old' + 'o' * 40 + '\n'
               'AI_BRAIN_KIRA_KEY=' + 'kira_' + 'k' * 40 + '\n'
               'AI_BRAIN_OR_KEY=' + 'sk-or-v1-' + 'r' * 40 + '\n',
               encoding='utf-8')


def stub(name, body):
    s = G / name
    s.write_text('#!/usr/bin/env bash\n' + body, encoding='utf-8')
    s.chmod(0o755)
    return str(s)


SYSCTL = stub('systemctl', 'true')
NOTIFY = stub('notify', 'echo "$1" >> "$NLOG"')
CURL_OK = stub('curl-ok', 'exit 0')


def run_guard(job, tag, secrets=SEC):
    _ = secrets
    (APP / 'data' / 'code-jobs' / f'{tag}.json').write_text(
        json.dumps(job, ensure_ascii=False), encoding='utf-8')
    return subprocess.run(
        ['bash', str(ROOT / 'deploy' / 'codeguard.sh')],
        env=dict(os.environ, DASTGIR_APP=str(APP), DASTGIR_SYSTEMCTL=SYSCTL,
                 DASTGIR_CURL=CURL_OK, DASTGIR_NOTIFY=NOTIFY,
                 DASTGIR_CODEGUARD_LOG=str(G / f'{tag}.log'),
                 DASTGIR_SECRETS=str(secrets),
                 DASTGIR_HEALTHZ='http://stub/healthz',
                 NLOG=str(G / f'{tag}.notify'), SLOG=str(G / f'{tag}.slog')),
        capture_output=True, timeout=120)


run_guard({'kind': 'ai_key', 'provider': 'glm', 'key': GLM_KEY}, 'glm')
_env = SEC.read_text(encoding='utf-8')
_log = (G / 'glm.log').read_text(encoding='utf-8')
_note = (G / 'glm.notify').read_text(encoding='utf-8')
ck('AI_BRAIN_GLM_KEY=' + GLM_KEY in _env,
   'v292: کلید GLM واقعاً در اسلات AI_BRAIN_GLM_KEY نشست (باگ رفع شد)')
ck('invalid shape' not in _log and 'failed: []' in _log,
   'دیگر «ai_key: invalid shape» نمی‌دهد؛ failed خالی است')
ck('AI_BRAIN_KIRA_KEY' not in _env, 'v273: اسلات کیرا پاک می‌شود')
ck(('AI_BRAIN_OPUS_KEY=aa-' + 'o' * 40) in _env and
   ('AI_BRAIN_OR_KEY=sk-or-v1-' + 'r' * 40) in _env,
   'بقیهٔ اسلات‌های AI_BRAIN_* دست‌نخورده ماندند')
ck('مغز هوش مصنوعی جدید' in _note and 'اعمال نشد' not in _note,
   'اعلان موفقیت به مدیر رفت (نه هشدار شکست)')
ck('AI_BRAIN_GLM_KEY' in _env and _env.count('AI_BRAIN_GLM_KEY') == 1,
   'هیچ خط تکراری GLM در secrets نمی‌ماند')

# ================= 4. گیت همچنان سخت است (خطاهای واقعی رد می‌شوند)
SEC.write_text('', encoding='utf-8')
run_guard({'kind': 'ai_key', 'provider': 'glm', 'key': 'aa-short'}, 'short')
ck(SEC.read_text(encoding='utf-8') == '' and
   'invalid shape' in (G / 'short.log').read_text(encoding='utf-8'),
   'کلید کوتاه همچنان رد می‌شود (گیت شل نشد)')
run_guard({'kind': 'ai_key', 'provider': 'gemini',
           'key': 'AIza' + '.' * 40}, 'dots')
ck(SEC.read_text(encoding='utf-8') == '',
   'کلید با کاراکتر غیرمجاز همچنان رد می‌شود')
run_guard({'kind': 'ai_key', 'provider': 'unknownprov', 'key': GLM_KEY}, 'unk')
_ulog = (G / 'unk.log').read_text(encoding='utf-8')
ck(SEC.read_text(encoding='utf-8') == '' and
   'missing base for unknownprov' in _ulog,
   'v292: provider ناشناس حالا پیام دقیق «missing base for …» می‌گیرد '
   '(قبلاً گمراه‌کننده «invalid shape» بود)')

# ================= 5. رگرسیون مسیرهای دیگر: site و muse سالم بمانند
run_guard({'kind': 'ai_key', 'provider': 'site', 'key': GLM_KEY}, 'site')
ck(('AI_SITE_API_KEY=' + GLM_KEY) in SEC.read_text(encoding='utf-8'),
   'رگرسیون: مسیر هوش سایت هنوز کار می‌کند')
SEC.write_text('', encoding='utf-8')
run_guard({'kind': 'ai_key', 'provider': 'muse', 'slot': 'opus',
           'key': GLM_KEY}, 'muse')
ck(('AI_BRAIN_OPUS_KEY=' + GLM_KEY) in SEC.read_text(encoding='utf-8'),
   'رگرسیون: مسیر کلاد (اسلاتی) هنوز کار می‌کند')

# ================= 6. ایستا: منبع باگ در کدگارد واقعاً درست شده است
guard = (ROOT / 'deploy' / 'codeguard.sh').read_text(encoding='utf-8')
ck('"glm": ("https://api.avalai.ir/v1", "glm-5.3-flash")' in guard,
   'کدگارد برای glm هم base/model پیش‌فرض دارد (علت ریشه‌ای رفع شد)')
ck('aa-[A-Za-z0-9_\\-]{20,120}' in guard,
   'regex کدگارد کلیدهای aa- را صریح می‌شناسد')
ck('if not base:' in guard and 'missing base for' in guard,
   'دو شرط از هم جدا شدند تا پیام خطا دقیق باشد')

print(f'v292 GLM key install fix: {n} checks green')
