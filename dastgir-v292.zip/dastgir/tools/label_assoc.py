#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""The one place the panel-form label-association rule lives, so it can be
unit-tested without booting the server. Imported by server/ui.py.

Why it exists: fifteen panel forms render

    <div class="field"><label class="field-label">نام</label><input …></div>

A <label> with no `for` and a control with no `id` are not programmatically
associated, so a screen reader announces an unnamed edit box — 107 of them on
/panel/assistant alone.

Why `for`/`id` and not nesting: the obvious fix is to move the label's closing
tag after the control so the control becomes its descendant. That was tried and
measured in Chromium, and it fails: the HTML parser does not treat `</label>`
as a tag once it is inside a <textarea>, so the control's VALUE became the
literal string "</label>" — visible corruption, exactly the class of bug this
task is meant to remove. Explicit `for`/`id` has no parser edge cases, works
for input/select/textarea alike, and is what the accessible-name algorithm
reads first.
"""
import re

_ATTR = r"""(?:\s+[^\s"'>/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s"'>`=]+))?)"""

# a .field-label with no `for=`, followed by its control as the next element
_FIELD_LABEL = re.compile(
    r'(<label class="field-label")'                                 # 1 open tag
    r'>'                                                            #
    r'((?:(?!</?label\b)[\s\S])*?)'                                 # 2 its text
    r'</label>'
    r'(\s*)'                                                        # 3 space
    r'(<(?:input|select|textarea)' + _ATTR + r'*\s*/?>)'            # 4 control
)

_ID = re.compile(r"""\sid\s*=\s*(?:"([^"]*)"|'([^']*)'|[^\s"'>`=]+)""")

# The Jalali date picker wraps its input in two spans
# (`<span class="jd"><span class="jd-ctrl"><input …>`), so "control is the
# label's next element" does not reach it. Inline wrappers are transparent for
# labelling purposes, so the rule also accepts a control nested inside spans —
# bounded to three levels, never crossing a <div>, a <label> or another field.
_SPANS = r"(?:\s*<span\b[^>]*>){0,3}\s*"

_FIELD_LABEL_NESTED = re.compile(
    r'(<label class="field-label")'
    r'>'
    r'((?:(?!</?label\b)[\s\S])*?)'
    r'</label>'
    r'(\s*(?:<span\b[^>]*>\s*){1,3})'                          # 3 wrappers
    # NOTE: no `</span>` in the match — closing the wrappers would require
    # balancing them, and an unmatched `</span>` would land in the output. The
    # injected id sits inside the innermost span, which is all `for=` needs.
    r'(<(?:input|select|textarea)' + _ATTR + r'*\s*/?>)'          # 4 control
)


def associate_field_labels(html):
    """Give every unassociated .field-label a `for` pointing at the control
    that follows it, adding an `id` to that control when it has none.

    Ids are generated from the label's own text (slugified) with a counter, so
    they are stable across renders, readable in the DOM, and unique on the
    page. Controls that already carry an id keep it. Labels that already have
    a `for=` never match and are left alone.
    """
    used = set(m.group(0) for m in re.finditer(r'\bid="[^"]+"', html))
    counter = [0]

    def repl(m):
        open_tag, text, space, control = m.group(1), m.group(2), m.group(3), m.group(4)
        have = _ID.search(control)
        if have:
            cid = have.group(1) or have.group(2) or ""
        else:
            slug = re.sub(r"[^\w\u0600-\u06FF]+", "-", text.strip()).strip("-")[:24] or "fld"
            cid = f"fld-{slug}"
            while f'id="{cid}"' in used:
                counter[0] += 1
                cid = f"fld-{slug}-{counter[0]}"
            used.add(f'id="{cid}"')
            # insert the id before the tag's own terminator; a self-closing
            # "/>" must stay self-closing, otherwise the markup is malformed
            if control.endswith("/>"):
                control = control[:-2].rstrip() + f' id="{cid}" />'
            elif control.endswith(">"):
                control = control[:-1].rstrip() + f' id="{cid}">'
        return f'{open_tag} for="{cid}">{text}</label>{space}{control}'

    html = _FIELD_LABEL.sub(repl, html)
    # second pass: the same rule, reaching through inline <span> wrappers.
    # `used` is shared, so an id minted in pass one is never reissued here.
    return _FIELD_LABEL_NESTED.sub(repl, html)


def associate_one(snippet):
    """Apply the rule to a single fragment. Exposed so the regression test can
    assert on the date-picker shape without booting the server."""
    return associate_field_labels(snippet)
