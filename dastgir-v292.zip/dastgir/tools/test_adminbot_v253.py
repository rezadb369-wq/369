#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v253: کلید هوش مصنوعی داخل بسته — نصب یعنی نصب کلید.

Owner's order (2026-09-10): «من که برات کلیدو فرستادم خب داخل کد قرار بده
دیگه». deploy/brain.env ships the brain (base/key/model/timeout);
deploy/apply-brain.sh applies it to the secrets file during update.sh —
every old AI_* line is wiped (owner's earlier «قبلی حذف» order), other
lines (bot tokens) are preserved, and a stamp makes it idempotent so a
later /کلید change via the bot can never be clobbered by a re-install of
the same zip.
"""
import os, sys, json, subprocess, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

# v289: deploy/brain.env carries the live AI keys and is stripped from any
# shared artifact on purpose (RULES: secrets never leave the box). When the
# file is absent this suite cannot test the brain, so it reports a named
# environmental skip with exit 78 (EX_CONFIG) instead of a red that looks like
# a code fault. Put the real brain.env back and it runs for real.
_BRAIN = ROOT / "deploy" / "brain.env"
if not _BRAIN.is_file():
    print("SKIP  deploy/brain.env موجود نیست — این سوئیت مغز AI را تست می‌کند و")
    print("      کلیدها عمداً از بستهٔ اشتراکی حذف شده‌اند. فایل را برگردانید")
    print("      تا واقعی اجرا شود. (خروجی ۷۸ = EX_CONFIG، نه شکست کد)")
    raise SystemExit(78)


TMP = tempfile.mkdtemp(prefix='adm-v253-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
AI._chat = lambda *a, **k: ('{"reply":"باشه","tool":null}', 5)
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]

AB = ROOT / 'deploy' / 'apply-brain.sh'
BR = ROOT / 'deploy' / 'brain.env'

# ================= 1. brain.env exists; shipped CONTENT is pinned only by
# the LATEST suite (v256: keyless by owner order) — older suites test mechanics.
ck(BR.is_file(), 'deploy/brain.env exists in the package')

# local fixture for the apply-brain mechanics
GOOD = ('AI_BASE_URL=https://api.avalai.ir/v1\nAI_API_KEY=testkey123\n'
        'AI_MODEL=gpt-6-astra\nAI_TIMEOUT=40\n')

# ================= 2. apply: old brain wiped, other secrets kept
W = Path(TMP)
(W / 'app' / 'deploy').mkdir(parents=True)
(W / 'app' / 'deploy' / 'brain.env').write_text(GOOD, encoding='utf-8')
SEC = W / 'secrets.env'
SEC.write_text('AI_BASE_URL=https://old/v1\nAI_API_KEY=oldkey\n'
               'AI_MODEL=gemini-2.5-flash-lite\n'
               'BALE_ADMIN_TOKEN=keepme\nAI_FALLBACK_API_KEY=oldfb\n',
               encoding='utf-8')
r = subprocess.run(['bash', str(AB)], capture_output=True, text=True,
                   env=dict(os.environ, DASTGIR_APP=str(W / 'app'),
                            DASTGIR_SECRETS=str(SEC)), timeout=30)
out = SEC.read_text(encoding='utf-8')
ck(r.returncode == 0 and 'مغز هوش مصنوعی' in r.stdout, 'apply reports success')
ck('AI_API_KEY=oldkey' not in out and 'AI_FALLBACK_API_KEY' not in out
   and 'gemini-2.5-flash-lite' not in out,
   'old brain + fallback fully wiped')
ck('BALE_ADMIN_TOKEN=keepme' in out, 'bot token untouched')
ck('AI_BASE_URL=https://api.avalai.ir/v1' in out and 'gpt-6-astra' in out
   and 'AI_TIMEOUT=40' in out, 'new brain installed verbatim')
ck(out.index('AI_BASE_URL') > out.index('BALE_ADMIN_TOKEN'),
   'AI lines appended after the preserved secrets')

# ================= 3. idempotent: same zip re-installed → no clobber
subprocess.run(['bash', str(AB)], capture_output=True, text=True,
               env=dict(os.environ, DASTGIR_APP=str(W / 'app'),
                        DASTGIR_SECRETS=str(SEC)), timeout=30)
ck(SEC.read_text(encoding='utf-8') == out, 're-apply is a no-op (stamp)')
ck((W / 'secrets.env.brain-stamp').is_file(), 'stamp file written')

# ================= 4. a LATER bot-side key change survives a re-install
SEC.write_text(out.replace('gpt-6-astra', 'my-own-model'), encoding='utf-8')
subprocess.run(['bash', str(AB)], capture_output=True, text=True,
               env=dict(os.environ, DASTGIR_APP=str(W / 'app'),
                        DASTGIR_SECRETS=str(SEC)), timeout=30)
ck('my-own-model' in SEC.read_text(encoding='utf-8'),
   'same-zip re-install does NOT clobber a newer bot-side change')

# ================= 5. a NEW brain.env (next version) does apply
(W / 'app' / 'deploy' / 'brain.env').write_text(
    GOOD.replace('AI_TIMEOUT=40', 'AI_TIMEOUT=45'), encoding='utf-8')
r = subprocess.run(['bash', str(AB)], capture_output=True, text=True,
                   env=dict(os.environ, DASTGIR_APP=str(W / 'app'),
                            DASTGIR_SECRETS=str(SEC)), timeout=30)
ck('AI_TIMEOUT=45' in SEC.read_text(encoding='utf-8'),
   'a changed brain.env applies (new key shipments work)')

# ================= 6. missing brain.env → silent no-op (future zips)
(W / 'app' / 'deploy' / 'brain.env').unlink()
r = subprocess.run(['bash', str(AB)], capture_output=True, text=True,
                   env=dict(os.environ, DASTGIR_APP=str(W / 'app'),
                            DASTGIR_SECRETS=str(SEC)), timeout=30)
ck(r.returncode == 0 and r.stdout == '', 'no brain.env → silent exit 0')

# ================= 7. update.sh calls the applier (wiring)
ups = (ROOT / 'deploy' / 'update.sh').read_text(encoding='utf-8')
ck('apply-brain.sh' in ups and 'brain.env' in ups,
   'update.sh wires apply-brain.sh before starting the service')

# ================= 8. the bot can never read the baked key (deploy/ is DENY)
nm, _ = CT.parse_tool_call({"name": "code_read",
                            "args": {"path": "deploy/brain.env"}})
ck(nm is None and 'قفل' in CT.reject_reason({"name": "code_read",
                                             "args": {"path": "deploy/brain.env"}}),
   'deploy/ stays fenced from the bot lane — the key is never model-readable')
nm, _ = CT.parse_tool_call({"name": "code_edit",
                            "args": {"path": "deploy/brain.env",
                                     "old": "x", "new": "y"}})
ck(nm is None, 'deploy/brain.env not writable via the bot either')

# ================= 9. version pins
ver = (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip()
ck(ver == A.DIAG_LATEST, f'DIAG_LATEST ({A.DIAG_LATEST}) == VERSION.txt ({ver})')
r = t('تشخیص')
ck('به‌روز' in r and 'قدیمی‌تر' not in r, 'تشخیص line 1 reports به‌روز')

print(f'v253 baked brain: {n} checks green')
