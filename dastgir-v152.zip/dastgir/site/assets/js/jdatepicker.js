/* ==========================================================================
   Bazarche — Jalali date picker (v145)
   Replaces every <input type="date"> with a Persian solar Hijri calendar.
   Storage stays Gregorian: the visible field shows «۱۴۰۴/۰۶/۲۲», the hidden
   <input name="…"> next to it receives 'YYYY-MM-DD' right before submit —
   so the server-side code (filters, sorting, countdowns) never changes.

   Markup expected (server templates):
     <span class="jd" data-jd [data-jd-time]>
       <input type="text" class="input nums" placeholder="۱۴۰۴/۰۶/۲۲" required? …>
       <input type="time" …>            ← only when data-jd-time (flash deals: date + hour)
       <input type="hidden" name="…">   ← Gregorian target, filled on submit
     </span>
   ========================================================================== */
import { g2j, j2g, jParse, jText, jToday, jMonthLen, jWeekday, JD_MONTHS } from './jalali.js';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

const WEEK = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

function pad2(n) { return String(n).padStart(2, '0'); }

/* Gregorian [gy,gm,gd] -> 'YYYY-MM-DD' for the hidden input. */
function toGreg(v) { return `${v[0]}-${pad2(v[1])}-${pad2(v[2])}`; }

const CAL_SVG = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/></svg>';
const NAV_SVG = (dir) => dir === 'prev'
  ? '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>'
  : '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 6-6 6 6 6"/></svg>';

function buildPop(wrap) {
  const pop = document.createElement('div');
  pop.className = 'jd-pop';
  pop.hidden = true;
  pop.innerHTML = `
    <div class="jd-head">
      <button type="button" class="jd-nav" data-jd-prev aria-label="ماه قبل">${NAV_SVG('prev')}</button>
      <div class="jd-title"><span data-jd-month></span><span data-jd-year class="nums"></span></div>
      <button type="button" class="jd-nav" data-jd-next aria-label="ماه بعد">${NAV_SVG('next')}</button>
    </div>
    <div class="jd-week">${WEEK.map((w, i) => `<span class="${i === 6 ? 'jd-fri' : ''}">${w}</span>`).join('')}</div>
    <div class="jd-grid" data-jd-grid></div>
    <div class="jd-foot">
      <button type="button" class="jd-ok" data-jd-today>امروز</button>
      <button type="button" class="jd-clear" data-jd-clear>پاک‌کردن</button>
    </div>`;
  wrap.appendChild(pop);
  return pop;
}

function renderMonth(wrap, state) {
  const grid = $('[data-jd-grid]', wrap);
  const [jy, jm] = state.view;
  $('[data-jd-month]', wrap).textContent = JD_MONTHS[jm - 1];
  const yearEl = $('[data-jd-year]', wrap);
  yearEl.textContent = String(jy).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d]);
  grid.innerHTML = '';
  const g = j2g(jy, jm, 1);
  if (!g) return;
  const start = jWeekday(g[0], g[1], g[2]);
  const len = jMonthLen(jy, jm);
  const [ty, tm, td] = jToday();

  for (let i = 0; i < start; i++) grid.appendChild(document.createElement('span'));
  for (let d = 1; d <= len; d++) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'jd-day nums';
    b.textContent = String(d).replace(/\d/g, (x) => '۰۱۲۳۴۵۶۷۸۹'[+x]);
    if (jy === ty && jm === tm && d === td) b.classList.add('is-today');
    if (state.sel && state.sel[0] === jy && state.sel[1] === jm && state.sel[2] === d) b.classList.add('is-sel');
    b.addEventListener('click', () => {
      state.sel = [jy, jm, d];
      const gd = j2g(jy, jm, d);
      state.input.value = jText(jy, jm, d);
      if (state.target) state.target.value = gd ? toGreg(gd) : '';
      state.hadValid = true;
      wrap.querySelector('.jd-pop').hidden = true;
      state.input.classList.remove('is-invalid');
      const err = $('.jd-err', wrap);
      if (err) err.remove();
    });
    grid.appendChild(b);
  }
}

function setView(wrap, state, jy, jm) {
  state.view = [jy, jm];
  renderMonth(wrap, state);
}

function openPop(wrap, state) {
  const pop = $('.jd-pop', wrap);
  if (!pop) return;
  // month shown = the selected date if any, otherwise today
  const parsed = state.input.value ? jParse(state.input.value) : null;
  const base = parsed || state.sel || jToday();
  state.view = [base[0], base[1]];
  renderMonth(wrap, state);
  pop.hidden = false;
}

function initPicker(wrap) {
  if (wrap.dataset.jdReady === '1') return;
  wrap.dataset.jdReady = '1';

  const input = $('input[type="text"]', wrap) || $('input:not([type="hidden"]):not([type="time"])', wrap);
  const timeIn = $('input[type="time"]', wrap);
  const target = $('input[data-jd-target]', wrap) || $('input[type="hidden"]', wrap);
  if (!input) return;

  const state = {
    input, target: target || null, timeIn,
    view: null, sel: null, hadValid: false,
  };

  // seed from an existing Gregorian value (server-rendered edit states)
  const seed = target && target.value ? jParse(target.value) : null;
  if (seed && !input.value) {
    input.value = jText(seed[0], seed[1], seed[2]);
    state.sel = seed;
    state.hadValid = true;
  }
  // seed from a typed Jalali value → sync the hidden field at once
  const typed = input.value ? jParse(input.value) : null;
  if (typed && target) {
    const g = j2g(typed[0], typed[1], typed[2]);
    target.value = g ? toGreg(g) : '';
    state.sel = typed; state.hadValid = true;
  }

  const pop = buildPop(wrap);
  $('[data-jd-prev]', wrap).addEventListener('click', () => {
    let [jy, jm] = state.view || state.sel || jToday();
    jm -= 1; if (jm < 1) { jm = 12; jy -= 1; }
    setView(wrap, state, jy, jm);
  });
  $('[data-jd-next]', wrap).addEventListener('click', () => {
    let [jy, jm] = state.view || state.sel || jToday();
    jm += 1; if (jm > 12) { jm = 1; jy += 1; }
    setView(wrap, state, jy, jm);
  });
  $('[data-jd-today]', wrap).addEventListener('click', () => {
    const [jy, jm, jd] = jToday();
    state.sel = [jy, jm, jd];
    const g = j2g(jy, jm, jd);
    input.value = jText(jy, jm, jd);
    if (target) target.value = g ? toGreg(g) : '';
    state.hadValid = true;
    pop.hidden = true;
  });
  $('[data-jd-clear]', wrap).addEventListener('click', () => {
    input.value = '';
    if (target) target.value = '';
    state.sel = null; state.hadValid = false;
    pop.hidden = true;
  });

  // keyboard/click affordance
  input.addEventListener('focus', () => openPop(wrap, state));
  // typing by hand closes the calendar (the popup would cover later fields)
  input.addEventListener('input', () => { pop.hidden = true; });
  pop.addEventListener('mousedown', (e) => e.preventDefault()); // keep focus
  document.addEventListener('click', (e) => {
    if (pop.hidden) return;
    if (!wrap.contains(e.target)) pop.hidden = true;
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') pop.hidden = true;
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openPop(wrap, state); }
  });

  // typing validates on blur; the popup closes too (clicks inside the popup
  // never blur the field thanks to the mousedown guard, so this is safe)
  input.addEventListener('blur', () => {
    pop.hidden = true;
    const v = input.value.trim();
    if (!v) { input.classList.remove('is-invalid'); return; }
    const parsed = jParse(v);
    if (parsed) {
      input.value = jText(parsed[0], parsed[1], parsed[2]);
      input.classList.remove('is-invalid');
      if (target) { const g = j2g(parsed[0], parsed[1], parsed[2]); target.value = g ? toGreg(g) : ''; }
      state.sel = parsed; state.hadValid = true;
    } else {
      input.classList.add('is-invalid');
    }
  });
}

function markErr(wrap, text) {
  let err = $('.jd-err', wrap);
  if (!err) {
    err = document.createElement('p');
    err.className = 'jd-err';
    wrap.appendChild(err);
  }
  err.textContent = text;
}

/* ---- form submit: copy Jalali → Gregorian into the hidden field(s) ---- */
function syncForm(form) {
  let bad = null;
  $$('.jd', form).forEach((wrap) => {
    const input = $('input[type="text"]', wrap);
    const timeIn = $('input[type="time"]', wrap);
    const target = $('input[data-jd-target]', wrap) || $('input[type="hidden"]', wrap);
    if (!input || !target) return;
    const v = input.value.trim();
    const required = input.hasAttribute('required');
    const parsed = v ? jParse(v) : null;

    if (!v) {
      target.value = '';
      if (required) bad = bad || { wrap, msg: 'تاریخ را وارد کنید یا از تقویم انتخاب کنید.' };
      return;
    }
    if (!parsed) {
      target.value = '';
      bad = bad || { wrap, msg: 'تاریخ خوانده نشد — نمونهٔ درست: ۱۴۰۴/۰۶/۲۲' };
      return;
    }
    const g = j2g(parsed[0], parsed[1], parsed[2]);
    if (!g) { bad = bad || { wrap, msg: 'تاریخ معتبر نیست.' }; return; }
    let gv = toGreg(g);
    if (timeIn) {
      const tv = timeIn.value || '';
      if (/^\d{2}:\d{2}$/.test(tv)) gv += ' ' + tv;
    }
    target.value = gv;
  });
  if (bad) {
    bad.wrap.scrollIntoView({ block: 'center', behavior: 'smooth' });
    markErr(bad.wrap, bad.msg);
    const inp = $('input[type="text"]', bad.wrap);
    if (inp) { inp.classList.add('is-invalid'); inp.focus(); }
  }
  return !bad;
}

function boot() {
  $$('.jd').forEach(initPicker);
}

document.addEventListener('submit', (e) => {
  const form = e.target;
  if (!form || !$('.jd', form)) return;
  if (!syncForm(form)) {
    e.preventDefault();
    e.stopImmediatePropagation();
  }
}, true); // capture: runs before the app's own validators

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else boot();

// v145: live.js swaps <main> on public pages — re-init any pickers there.
window.addEventListener('bz:content-updated', boot);
