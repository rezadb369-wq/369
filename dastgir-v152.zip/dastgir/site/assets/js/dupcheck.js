/* ==========================================================================
   Live duplicate detection on the submit form.

   As the applicant fills in the name, phone or address we ask the server
   whether that shop already exists, and show the warning right under the
   field they are typing in — so nobody re-registers the same business.
   ========================================================================== */

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

const ICON = {
  warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 10v4M12 17h.01"/></svg>',
  info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>',
};

const LABEL = {
  published: 'منتشرشده',
  pending: 'در انتظار تأیید',
  hidden: 'مخفی',
  rejected: 'رد شده',
};

function boot() {
  const form = $('form[data-dupcheck]');
  if (!form) return;

  const fields = $$('[data-dup]', form);
  if (!fields.length) return;

  let timer = null;
  let lastKey = '';

  const render = (dups) => {
    // clear every hint first
    $$('.dup-hint', form).forEach(h => { h.hidden = true; h.innerHTML = ''; });
    if (!dups.length) {
      form.dataset.dupState = 'clean';
      return;
    }

    form.dataset.dupState = dups.some(d => d.strength === 'exact') ? 'exact' : 'maybe';

    // group by which field triggered the match
    const byField = {};
    dups.forEach(d => { (byField[d.field] ||= []).push(d); });

    Object.entries(byField).forEach(([field, list]) => {
      const box = $(`.dup-hint[data-dup-for="${field}"]`, form);
      if (!box) return;
      const exact = list.some(d => d.strength === 'exact');
      box.className = 'dup-hint ' + (exact ? 'is-exact' : 'is-maybe');
      box.innerHTML = `
        <div class="dup-hint-head">
          ${exact ? ICON.warn : ICON.info}
          <strong>${exact ? 'این مورد قبلاً ثبت شده' : 'شبیه یک ثبت موجود است'}</strong>
        </div>
        ${list.slice(0, 3).map(d => `
          <div class="dup-hint-row">
            <span class="dup-hint-name">${d.name}</span>
            <span class="dup-hint-meta">${d.address || ''} ${d.status ? '· ' + (LABEL[d.status] || d.status) : ''}</span>
            <span class="dup-hint-why">${d.reason}</span>
            <span class="dup-hint-act">
              ${d.status === 'published'
                ? `<a href="/b/${d.slug}" target="_blank" rel="noopener">مشاهده</a>` : ''}
              ${!d.claimed ? `<a href="/login">این مال من است ←</a>` : ''}
            </span>
          </div>`).join('')}
        <div class="dup-hint-foot">
          چنانچه این نتیجه با کسب‌وکار شما مغایرت دارد، از طریق
          <a href="/my/tickets" target="_blank" rel="noopener">تیکت پشتیبانی</a> اقدام فرمایید.
        </div>`;
      box.hidden = false;
    });
  };

  const check = async () => {
    const body = new URLSearchParams();
    fields.forEach(f => body.append(f.dataset.dup, f.value.trim()));

    // skip pointless calls
    const key = body.toString();
    if (key === lastKey) return;
    if (![...body.values()].some(v => v.length >= 3)) { render([]); return; }
    lastKey = key;

    try {
      const res = await fetch('/api/check-duplicate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
      });
      if (!res.ok) return;
      const data = await res.json();
      render(data.duplicates || []);
    } catch (e) { /* offline: silently skip */ }
  };

  fields.forEach(f => {
    f.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(check, 450);
    });
    f.addEventListener('blur', () => { clearTimeout(timer); check(); });
  });

  // one last confirmation before sending an exact duplicate
  form.addEventListener('submit', (e) => {
    if (form.dataset.dupState !== 'exact') return;
    if (form.querySelector('[name="confirm_dup"]:checked')) return;
    const ok = window.confirm(
      'به نظر می‌رسد این کسب‌وکار قبلاً ثبت شده است.\n\n' +
      'اگر مال شماست، بهتر است وارد شوید و آن را تصاحب کنید.\n' +
      'برای ثبت به‌هرحال، تأیید کنید.');
    if (!ok) e.preventDefault();
  });

  if (fields.some(f => f.value.trim().length >= 3)) check();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else { boot(); }
