/* Bazarche v73 — accessible messenger polling, composer and attachments. */
// v145: live day dividers show the Jalali date («۱۴۰۵/۰۶/۱۳»), not Gregorian.
import { jdateFa } from './jalali.js';

const room = document.querySelector('[data-chat-room]');

if (room) {
  const tid = room.dataset.thread;
  const me = room.dataset.me || 'customer';
  const api = room.dataset.api || `/api/chat/${tid}/msgs?as=${encodeURIComponent(me)}`;
  let lastId = Number.parseInt(room.dataset.last || '0', 10) || 0;
  const newButton = document.querySelector('[data-chat-new]');
  const threadState = document.querySelector('[data-thread-status]');

  const roleLabel = { customer: 'مشتری', owner: 'دکان‌دار', admin: 'مدیر دستگیر' };
  // Telegram-style day dividers: one chip whenever the calendar day changes.
  const faDigits = (value) => String(value).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
  const dayOf = (message) => String(message.created || '').slice(0, 10);
  let lastDay = (() => {
    const chips = room.querySelectorAll('.chat-date[data-date]');
    return chips.length ? chips[chips.length - 1].dataset.date : '';
  })();
  function dateNode(day) {
    const wrap = document.createElement('div');
    wrap.className = 'chat-date'; wrap.dataset.date = day; // stays Gregorian (grouping)
    const span = document.createElement('span'); span.textContent = jdateFa(day);
    wrap.appendChild(span);
    return wrap;
  }
  const nearBottom = () => room.scrollHeight - room.scrollTop - room.clientHeight < 90;
  const scrollBottom = (smooth = false) => {
    room.scrollTo({ top: room.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
    if (newButton) newButton.hidden = true;
  };
  requestAnimationFrame(() => scrollBottom(false));

  const sizeLabel = (value) => {
    const n = Number(value) || 0;
    if (n >= 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} مگابایت`;
    return `${Math.max(1, Math.round(n / 1024))} کیلوبایت`;
  };

  function attachmentNode(message) {
    if (!message.attachment_id || !message.file_url) return null;
    if (message.file_kind === 'image') {
      const link = document.createElement('a');
      link.className = 'msg-image'; link.href = message.file_url;
      link.target = '_blank'; link.rel = 'noopener';
      link.setAttribute('aria-label', `باز کردن تصویر ${message.file_name || ''}`);
      const image = document.createElement('img');
      image.src = message.file_url; image.alt = `پیوست تصویری: ${message.file_name || 'تصویر'}`;
      image.loading = 'lazy'; image.decoding = 'async';
      const caption = document.createElement('span');
      caption.textContent = message.file_name || 'تصویر';
      link.append(image, caption);
      return link;
    }
    const link = document.createElement('a');
    link.className = 'msg-file'; link.href = message.file_url; link.setAttribute('download', '');
    const fileIcon = document.createElement('span'); fileIcon.className = 'msg-file-icon';
    fileIcon.textContent = '↓'; fileIcon.setAttribute('aria-hidden', 'true');
    const meta = document.createElement('span');
    const strong = document.createElement('strong'); strong.textContent = message.file_name || 'فایل';
    const small = document.createElement('small'); small.textContent = sizeLabel(message.file_size);
    meta.append(strong, small);
    const arrow = document.createElement('span'); arrow.textContent = '↓'; arrow.setAttribute('aria-hidden', 'true');
    link.append(fileIcon, meta, arrow);
    return link;
  }

  function messageNode(message) {
    const sender = message.sender || 'customer';
    const article = document.createElement('article');
    article.className = `msg ${sender === me ? 'me' : (sender === 'admin' ? 'admin' : 'them')}`;
    article.dataset.msgId = String(message.id || 0); article.dataset.sender = sender;

    const label = document.createElement('div'); label.className = 'msg-label';
    label.textContent = roleLabel[sender] || sender;
    const bubble = document.createElement('div'); bubble.className = 'msg-bubble';
    if (message.body) {
      const text = document.createElement('div'); text.className = 'msg-text';
      text.textContent = message.body; bubble.appendChild(text);
    }
    const attachment = attachmentNode(message);
    if (attachment) bubble.appendChild(attachment);

    const meta = document.createElement('div'); meta.className = 'msg-meta';
    const time = document.createElement('time');
    time.textContent = String(message.created || '').slice(5, 16);
    const delivery = document.createElement('span');
    delivery.className = 'msg-ticks'; delivery.dataset.delivery = '';
    if (sender === me) delivery.textContent = '✓';
    meta.append(time, delivery);
    article.append(label, bubble, meta);
    return article;
  }

  function updateRead(read = {}) {
    let peer = 0;
    if (me === 'customer') peer = Math.max(read.owner || 0, read.admin || 0);
    else if (me === 'owner') peer = Math.max(read.customer || 0, read.admin || 0);
    else peer = Math.max(read.customer || 0, read.owner || 0);
    room.querySelectorAll(`.msg.me[data-msg-id]`).forEach(message => {
      const label = message.querySelector('[data-delivery]');
      if (label) label.textContent = Number(message.dataset.msgId) <= peer ? '✓✓' : '✓';
    });
  }

  function updateState(status) {
    if (!threadState || !status) return;
    threadState.classList.toggle('is-open', status === 'open');
    threadState.classList.toggle('is-closed', status === 'closed');
    threadState.textContent = status === 'open' ? 'گفتگو باز است' : 'گفتگو بسته است';
  }

  async function poll() {
    if (document.hidden) return;
    try {
      const url = new URL(api, location.origin);
      url.searchParams.set('after', String(lastId));
      const response = await fetch(url, { headers: { Accept: 'application/json' } });
      if (!response.ok) return;
      const data = await response.json();
      if (!data.ok) return;
      const shouldFollow = nearBottom();
      let added = 0;
      for (const message of data.msgs || []) {
        if (Number(message.id) <= lastId) continue;
        lastId = Number(message.id);
        const day = dayOf(message);
        if (day && day !== lastDay) { room.appendChild(dateNode(day)); lastDay = day; }
        room.appendChild(messageNode(message)); added += 1;
      }
      updateRead(data.read || {}); updateState(data.status);
      if (added && shouldFollow) scrollBottom(true);
      else if (added && newButton) newButton.hidden = false;
    } catch (_) {
      // Offline is recoverable: the next interval retries without breaking UI.
    }
  }

  window.setInterval(poll, 3000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) poll(); });
  newButton?.addEventListener('click', () => scrollBottom(true));

  const form = document.querySelector('[data-chat-form]');
  const composer = document.querySelector('[data-chat-compose]');
  const file = document.querySelector('[data-chat-file]');
  const preview = document.querySelector('[data-attach-preview]');
  const previewName = document.querySelector('[data-attach-name]');
  const previewSize = document.querySelector('[data-attach-size]');
  const removeFile = document.querySelector('[data-attach-remove]');
  const status = document.querySelector('[data-chat-status]');
  const send = document.querySelector('[data-chat-send]');
  const MAX_FILE = 8 * 1024 * 1024;
  // In-browser downscale (Pillow is unavailable in Pydroid): a picked photo is
  // redrawn to a canvas at IMG_EDGE and re-exported as JPEG BEFORE upload, so
  // chat images stay small and the site stays fast on mobile data. The server
  // additionally trims metadata as a no-JS safety net.
  const IMG_EDGE = 1280;
  const IMG_QUALITY = 0.8;
  let shrinking = null;   // in-flight downscale promise, awaited on submit

  const setStatus = (text) => { if (status) status.textContent = text; };
  const clearFile = () => {
    if (file) file.value = '';
    if (preview) preview.hidden = true;
    if (previewName) previewName.textContent = '';
    if (previewSize) previewSize.textContent = '';
  };
  const grow = () => {
    if (!composer) return;
    composer.style.height = 'auto';
    composer.style.height = `${Math.min(composer.scrollHeight, 120)}px`;
  };
  const isImage = (f) => Boolean(f) && /^image\//.test(f.type || '');

  function loadImage(f) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(f);
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('bad image')); };
      img.src = url;
    });
  }

  // Resolve to a smaller JPEG File, or null when the image cannot be decoded.
  async function shrinkImage(f) {
    let img;
    try { img = await loadImage(f); } catch (_) { return null; }
    const scale = Math.min(1, IMG_EDGE / Math.max(img.width, img.height));
    const w = Math.round(img.width * scale);
    const h = Math.round(img.height * scale);
    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d');
    ctx.imageSmoothingQuality = 'high';
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h);   // flatten transparency
    ctx.drawImage(img, 0, 0, w, h);
    const blob = await new Promise(r => canvas.toBlob(r, 'image/jpeg', IMG_QUALITY));
    if (!blob) return null;
    // v100: ALWAYS send the re-encoded JPEG — compression is never skipped,
    // even on the rare image where re-encoding is not smaller.
    const name = (f.name || 'image').replace(/\.[a-z0-9]+$/i, '') + '.jpg';
    return new File([blob], name, { type: 'image/jpeg' });
  }

  const setPreview = (f) => {
    if (previewName) previewName.textContent = f.name;
    if (previewSize) previewSize.textContent = sizeLabel(f.size);
    if (preview) preview.hidden = false;
  };

  composer?.addEventListener('input', grow);
  composer?.addEventListener('keydown', event => {
    if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
      event.preventDefault(); form?.requestSubmit();
    }
  });
  file?.addEventListener('change', () => {
    shrinking = null;
    const selected = file.files?.[0];
    if (!selected) { clearFile(); return; }
    if (!isImage(selected)) {
      clearFile(); setStatus('فقط عکس می‌توانید بفرستید.'); return;
    }
    if (selected.size > MAX_FILE) {
      clearFile(); setStatus('حجم فایل بیشتر از ۸ مگابایت است.'); return;
    }
    setPreview(selected);
    setStatus('در حال فشرده‌سازی تصویر…');
    shrinking = shrinkImage(selected).then(smaller => {
      shrinking = null;
      if (!smaller || !file.files?.[0]) return;
      try {
        const dt = new DataTransfer();
        dt.items.add(smaller);
        file.files = dt.files;          // swap in the compressed bytes
        setPreview(smaller);
        setStatus(`تصویر فشرده شد (${sizeLabel(smaller.size)}). آمادهٔ ارسال.`);
      } catch (_) { setStatus(`تصویر ${selected.name} آمادهٔ ارسال است.`); }
    }).catch(() => { shrinking = null; });
  });
  removeFile?.addEventListener('click', () => { clearFile(); shrinking = null; setStatus('فایل حذف شد.'); });
  form?.addEventListener('submit', event => {
    const hasText = Boolean(composer?.value.trim());
    const hasFile = Boolean(file?.files?.length);
    if (!hasText && !hasFile) {
      event.preventDefault(); setStatus('متن پیام یا فایل را وارد کنید.'); composer?.focus(); return;
    }
    // Wait for an in-flight downscale so the compressed bytes are what posts.
    if (shrinking) {
      event.preventDefault();
      setStatus('در حال فشرده‌سازی تصویر…');
      Promise.resolve(shrinking).then(() => form.requestSubmit());
      return;
    }
    // v89: a photo goes up over XHR so the shared bar shows a real percentage;
    // a text-only message keeps the plain (faster) full-page post.
    if (hasFile && window.uploadWithProgress) {
      event.preventDefault();
      form.setAttribute('aria-busy', 'true');
      if (send) send.disabled = true;
      window.uploadWithProgress(form, new FormData(form), 'در حال ارسال عکس…')
        .then(url => { window.UpBar.set(100); location.href = url; })
        .catch(() => {
          window.UpBar.error();
          form.removeAttribute('aria-busy');
          if (send) send.disabled = false;
          setStatus('ارسال ناموفق بود.');
        });
      return;
    }
    form.setAttribute('aria-busy', 'true');
    if (send) send.disabled = true;
    setStatus(hasFile ? 'در حال ارسال پیام و فایل…' : 'در حال ارسال پیام…');
  });
}
