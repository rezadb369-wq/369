/* ==========================================================================
   Q&A helpers: "this was helpful" counter (real POST, real column)
   and the multi-criteria star pickers on the review form.
   ========================================================================== */
const FA = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
const fa = (n) => String(n).replace(/\d/g, d => FA[+d]);
const VOTED = 'bazarche.qavotes';

const voted = () => {
  try { return JSON.parse(localStorage.getItem(VOTED) || '[]'); }
  catch (e) { return []; }
};

function markVoted(id) {
  const v = voted();
  if (!v.includes(id)) { v.push(id); }
  try { localStorage.setItem(VOTED, JSON.stringify(v)); } catch (e) {}
}

function initHelpful() {
  const already = voted();
  document.querySelectorAll('[data-helpful]').forEach(btn => {
    const id = btn.dataset.helpful;
    if (already.includes(id)) {
      btn.setAttribute('aria-pressed', 'true');
      btn.disabled = true;
    }
    btn.addEventListener('click', async () => {
      if (btn.disabled) return;
      btn.disabled = true;
      try {
        const res = await fetch('/api/question-helpful', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'id=' + encodeURIComponent(id)
        });
        const data = await res.json();
        const n = btn.querySelector('[data-helpful-n]');
        if (n && typeof data.helpful === 'number') n.textContent = fa(data.helpful);
        btn.setAttribute('aria-pressed', 'true');
        markVoted(id);
        window.Bazarche?.toast('ممنون از بازخورد شما.', 'ok');
      } catch (e) {
        btn.disabled = false;
        window.Bazarche?.toast('ثبت نشد. دوباره تلاش کنید.', 'err');
      }
    });
  });
}

function initCriteria() {
  document.querySelectorAll('[data-crit-input] .row').forEach(row => {
    const input = row.querySelector('input[type="hidden"]');
    const stars = Array.from(row.querySelectorAll('button'));
    const paint = (v) => stars.forEach((s, i) => s.setAttribute('aria-pressed', String(i < v)));
    stars.forEach((s, i) => {
      s.addEventListener('click', () => { if (input) input.value = i + 1; paint(i + 1); liveScore(); });
      s.addEventListener('mouseenter', () => paint(i + 1));
      s.addEventListener('focus', () => paint(i + 1));
    });
    row.addEventListener('mouseleave', () => paint(parseInt(input?.value || '0', 10)));
    paint(parseInt(input?.value || '0', 10));
  });
}

/* v151: live overall score = mean of the criteria the reviewer actually
   starred (the server stores exactly this). No stars -> no score shown. */
function liveScore() {
  const box = document.querySelector('[data-live-score]');
  if (!box) return;
  const rows = [...document.querySelectorAll('[data-crit-input] .row')];
  const vals = rows
    .map(r => parseInt((r.querySelector('input[type="hidden"]') || {}).value || '0', 10))
    .filter(v => v > 0);
  if (!vals.length) { box.hidden = true; return; }
  const mean = Math.round((vals.reduce((a, b) => a + b, 0) / vals.length) * 10) / 10;
  box.hidden = false;
  const el = box.querySelector('[data-live-val]');
  if (el) el.textContent = faN(Number.isInteger(mean) ? mean : mean.toFixed(1));
}

const FA_N = '۰۱۲۳۴۵۶۷۸۹';
function faN(n) { return String(n).replace(/[0-9]/g, d => FA_N[+d]).replace('.', '٫'); }

function boot() { initHelpful(); initCriteria(); liveScore(); }

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}
