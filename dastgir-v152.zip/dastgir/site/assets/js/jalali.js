/* ==========================================================================
   Bazarche — Jalali (Persian solar) calendar, shared core
   v145: the site's user-facing calendar is solar Hijri. This module is the
   JS twin of tools/layout.py (same classic g_d_m algorithm, same constants)
   so both sides of the wire always agree. Used by:
     • jdatepicker.js  — the Jalali date-picker popup replacing <input type=date>
     • chat.js         — live day dividers («۱۴۰۵/۰۶/۱۳») for new messages
   ========================================================================== */

const JD_G_D_M = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

export const JD_MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد',
  'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];

const JD_FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';

const faDigits = (s) => String(s).replace(/\d/g, (d) => JD_FA_DIGITS[+d]);
const enDigits = (s) => String(s).replace(/[۰-۹]/g, (d) => String(JD_FA_DIGITS.indexOf(d)));

/* Gregorian y/m/d -> [jy, jm, jd]. Literal translation of layout.g2j. */
export function g2j(gy, gm, gd) {
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days = 355666 + 365 * gy
    + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100)
    + Math.floor((gy2 + 399) / 400) + gd + JD_G_D_M[gm - 1];
  let jy = -1595 + 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let jm, jd;
  if (days < 186) { jm = 1 + Math.floor(days / 31); jd = 1 + (days % 31); }
  else { jm = 7 + Math.floor((days - 186) / 30); jd = 1 + ((days - 186) % 30); }
  return [jy, jm, jd];
}

/* Jalali y/m/d -> [gy, gm, gd]. Exact inverse of g2j by binary search over
   real Gregorian days: g2j is strictly monotonic, and Nowruz of (j)y always
   falls in March of gregorian ≈ jy+621 — a small window (Mar jy+620 →
   Jun jy+624) brackets any valid Jalali date, so ~24 g2j calls suffice.
   No month-alignment assumption, hence correct for every date. */
export function j2g(jy, jm, jd) {
  const target = jy * 10000 + jm * 100 + jd;
  const lo = Date.UTC(jy + 620, 2, 1) / 86400000;   // Mar 1
  const hi = Date.UTC(jy + 624, 5, 1) / 86400000;   // Jun 1
  let a = Math.floor(lo), z = Math.floor(hi);
  if (g2jAt(a) > target || g2jAt(z) < target) return null;
  while (a < z) {
    const mid = Math.floor((a + z) / 2);
    if (g2jAt(mid) < target) a = mid + 1;
    else z = mid;
  }
  if (g2jAt(a) !== target) return null;
  const dt = new Date(a * 86400000);
  return [dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate()];

  function g2jAt(dayNum) {
    const dt = new Date(dayNum * 86400000);
    const j = g2j(dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate());
    return j[0] * 10000 + j[1] * 100 + j[2];
  }
}

/* Days in a Jalali month (Esfand = 29 or 30 depending on the leap year). */
export function jMonthLen(jy, jm) {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  const probe = j2g(jy, 12, 30);        // Esfand 30 exists iff leap
  return probe && g2j(probe[0], probe[1], probe[2])[2] === 30 ? 30 : 29;
}

/* Weekday index of a Gregorian date: 0 = Saturday … 6 = Friday (Iran). */
export function jWeekday(gy, gm, gd) {
  return (new Date(Date.UTC(gy, gm - 1, gd)).getUTCDay() + 1) % 7;
}

/* 'YYYY-MM-DD…' (or ''/null) -> Persian '۱۴۰۵/۰۶/۱۳' ('' for empty).
   Same contract as layout.jdate, for client-side live content. */
export function jdateFa(v) {
  if (v == null) return '';
  const s = enDigits(String(v)).trim();
  if (!s) return '';
  const d = s.slice(0, 10).split(' ')[0].split('T')[0];
  const m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(d);
  if (!m) return String(v);
  const [jy, jm, jd] = g2j(+m[1], +m[2], +m[3]);
  return `${faDigits(jy)}/${faDigits(String(jm).padStart(2, '0'))}/${faDigits(String(jd).padStart(2, '0'))}`;
}

/* Parse a user-typed Persian date '۱۴۰۴/۰۶/۲۲' (or latin '1404-6-22') to
   [jy, jm, jd]; null when not a valid calendar date. */
export function jParse(v) {
  if (v == null) return null;
  const s = enDigits(String(v)).trim().replace(/[.\-]/g, '/');
  const m = /^(\d{1,4})\/(\d{1,2})\/(\d{1,2})$/.exec(s);
  if (!m) return null;
  const jy = +m[1], jm = +m[2], jd = +m[3];
  if (jy < 1100 || jy > 1600 || jm < 1 || jm > 12 || jd < 1) return null;
  if (jd > jMonthLen(jy, jm)) return null;
  return [jy, jm, jd];
}

/* [jy, jm, jd] -> '۱۴۰۴/۰۶/۲۲' display text. */
export function jText(jy, jm, jd) {
  return `${faDigits(jy)}/${faDigits(String(jm).padStart(2, '0'))}/${faDigits(String(jd).padStart(2, '0'))}`;
}

/* today as [jy, jm, jd] in the user's local timezone */
export function jToday() {
  const n = new Date();
  return g2j(n.getFullYear(), n.getMonth() + 1, n.getDate());
}
