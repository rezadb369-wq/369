# -*- coding: utf-8 -*-
"""
v142 notification core & event hooks — direct-DB suite on a THROWAWAY database.

Covers:
  · owner notifications for: subscription request/activate/reject/expire/reminder,
    claim approve, edit approve/reject, new review/question, new booking/inquiry,
    new haggle offer, admin ticket reply
  · customer notifications for: shop reply on review / answer on question
  · per-kind prefs suppress and re-enable for both roles
  · follow kind is OFF by default for customers
  · inbox hygiene: read >60 days removed, inbox trimmed to 200 newest

Runs fully offline (temp DB), hermetic: server/data untouched.
    python3 tools/test_notif_v142.py
"""

import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


# ---- hermetic DB before ANY db call (documented trap) ----
db = None


def setup():
    global db
    import db as _db
    db = _db
    db.DB_PATH = os.path.join(tempfile.mkdtemp(prefix="bznotif"), "t.db")
    db.init()


def mk_owner(phone):
    return db.owner_by_phone(phone, create=True)


def mk_biz(owner_id, name, slug, phone):
    bid = db.save_business({
        "name": name, "slug": slug, "cat_slug": "restaurant",
        "phone": phone, "status": "published", "owner_id": owner_id,
        "city": "تهران", "province": "تهران",
    })
    return bid


def mk_customer(phone, name="مشتری"):
    db._run("INSERT INTO customers(phone,name) VALUES(?,?)", (phone, name))
    return db._one("SELECT id FROM customers WHERE phone=?", (phone,))["id"]


def onotifs(oid):
    return db.owner_notifications(oid)


def cnotifs(cid):
    return db._rows("SELECT * FROM notifications WHERE customer_id=? ORDER BY id DESC", (cid,))


def main():
    head("زیرساخت و آماده‌سازی")
    setup()
    o1 = mk_owner("09120000001")
    o2 = mk_owner("09120000002")
    b1 = mk_biz(o1["id"], "کبابی آزمون", "test-kabab-notif", "03130000001")
    b2 = mk_biz(o2["id"], "کافه آزمون", "test-cafe-notif", "03130000002")
    c1 = mk_customer("09120000003", "خریدار آزمون")
    check("owner/business/customer ساخته شد", bool(o1 and b1 and o2 and b2 and c1))

    head("تعرفه: درخواست / فعال‌سازی / رد / انقضا / یادآوری")
    paid = next((p for p in db.plans() if int(p.get("price") or 0) > 0), None)
    if not paid:
        paid = db.plans()[0]
    # request (pending)
    sid, msg = db.request_subscription(b1, paid["slug"], method="card")
    check("درخواست تعرفه ثبت شد", sid and "تأیید" in msg, str(msg))
    ns = [n for n in onotifs(o1["id"]) if n["kind"] == "sub"]
    check("اعلان «درخواست تعرفه» برای مالک", any("درخواست تعرفه" in n["text"] for n in ns),
          str([n["text"] for n in ns]))
    # activate
    db.activate_subscription(sid)
    ns = onotifs(o1["id"])
    check("اعلان «تعرفه فعال شد»", any("فعال شد" in n["text"] for n in ns),
          str([n["text"] for n in ns]))
    # reject
    sid2, _ = db.request_subscription(b1, paid["slug"], method="card")
    db.reject_subscription(sid2)
    ns = onotifs(o1["id"])
    check("اعلان «رد درخواست»", any("رد شد" in n["text"] for n in ns))
    # expiry (flip a sub to yesterday, then sweep)
    db.activate_subscription(sid2)
    db._run("UPDATE subscriptions SET expires=? WHERE id=?", ("2000-01-01", sid2))
    n_exp = db.expire_subscriptions()
    ns = onotifs(o1["id"])
    check("انقضا شناسایی شد و اعلان «تمام شد» رفت", n_exp >= 1 and any("تمام شد" in n["text"] for n in ns))
    # reminder within 7 days, once per day
    sid3, _ = db.request_subscription(b1, paid["slug"], method="card")
    db.activate_subscription(sid3)
    import datetime
    soon = (datetime.date.today() + datetime.timedelta(days=3)).isoformat()
    db._run("UPDATE subscriptions SET expires=? WHERE id=?", (soon, sid3))
    r1 = db.sub_expiry_reminders(7)
    r2 = db.sub_expiry_reminders(7)
    ns = onotifs(o1["id"])
    check("یادآوری ۷ روزه ارسال شد", r1 >= 1 and any(n["text"].startswith("⏳") for n in ns))
    check("یادآوری در همان روز تکرار نمی‌شود", r2 == 0, f"r2={r2}")
    # o2 (کافه) نباید هیچ اعلان sub گرفته باشد
    check("مالک دیگر اعلان ناخواسته نگرفت", len([n for n in onotifs(o2["id"]) if n["kind"] == "sub"]) == 0)

    head("کسب‌وکار: ادعا / ویرایش")
    db._run("INSERT INTO claims(biz_id,owner_id,note,status) VALUES(?,?,?,'pending')",
            (b1, o1["id"], "این دکان من است"))
    cid_claim = db._one("SELECT id FROM claims WHERE biz_id=? AND owner_id=?",
                        (b1, o1["id"]))["id"]
    db.claim_decide(cid_claim, True)
    ns = onotifs(o1["id"])
    check("اعلان «ادعا تأیید شد»", any("ادعای مالکیت" in n["text"] and "تأیید" in n["text"] for n in ns))
    db._run("INSERT INTO claims(biz_id,owner_id,note,status) VALUES(?,?,?,'pending')",
            (b2, o2["id"], "مالکیت"))
    cid2 = db._one("SELECT id FROM claims WHERE biz_id=? AND owner_id=?",
                   (b2, o2["id"]))["id"]
    db.claim_decide(cid2, False)
    ns2 = onotifs(o2["id"])
    check("اعلان «ادعا رد شد»", any("رد شد" in n["text"] for n in ns2))
    import json as _json
    db._run("INSERT INTO edits(biz_id,owner_id,payload,status) VALUES(?,?,?,'pending')",
            (b1, o1["id"], _json.dumps({"name": "کبابی آزمون۲"}, ensure_ascii=False)))
    eid = db._one("SELECT id FROM edits WHERE biz_id=? ORDER BY id DESC", (b1,))["id"]
    db.decide_edit(eid, True)
    ns = onotifs(o1["id"])
    check("اعلان «ویرایش تأیید شد»", any("ویرایش" in n["text"] or "تغییرات" in n["text"] and "تأیید" in n["text"] for n in ns))

    head("نظر و پرسش (مالک + پاسخ به مشتری)")
    rid = db.add_review_full(b1, "علی", 5, "کیفیت عالی", customer_id=c1)
    ns = onotifs(o1["id"])
    check("اعلان «نظر تازه» برای مالک", any("نظر تازه" in n["text"] for n in ns))
    db.update_review(rid, reply="ممنون از شما")
    cn = cnotifs(c1)
    check("اعلان «پاسخ به نظر من» برای مشتری", any(n["kind"] == "reply" and "پاسخ داد" in n["text"] for n in cn),
          str([n["text"] for n in cn]))
    qid = db.add_question(b1, "سارا", "ساعت کاری شما چیست؟ لطفاً پاسخ دهید", customer_id=c1)
    ns = onotifs(o1["id"])
    check("اعلان «پرسش تازه» برای مالک", any("پرسش تازه" in n["text"] for n in ns))
    db.answer_question(qid, "از ۹ تا ۲۱")
    cn = cnotifs(c1)
    check("اعلان «پاسخ به پرسش من» برای مشتری", any(n["kind"] == "reply" and "پرسش" in n["text"] for n in cn))

    head("نوبت / استعلام / چانه / تیکت")
    db.add_booking(b1, "رضا", "09120000004", "2026-09-10", "10:00")
    ns = onotifs(o1["id"])
    check("اعلان «نوبت تازه»", any("نوبت تازه" in n["text"] for n in ns))
    db.add_inquiry(b1, "مریم", "09120000005", "قیمت کباب؟")
    ns = onotifs(o1["id"])
    check("اعلان «درخواست قیمت»", any("درخواست قیمت" in n["text"] for n in ns))
    iid = db.save_item({"biz_id": b1, "kind": "product", "title": "کباب برگ", "price": 200000})
    hid, tok, verdict = db.make_offer(b1, iid, "خریدار", "09120000006", 150000)
    ns = onotifs(o1["id"])
    check("اعلان «پیشنهاد چانه» برای مالک", verdict == "pending" and any("چانه" in n["text"] for n in ns),
          f"verdict={verdict}")
    db._run("INSERT INTO tickets(owner_id,biz_id,subject,status) VALUES(?,?,?,'open')",
            (o1["id"], b1, "مشکل پرداخت"))
    tid = db._one("SELECT id FROM tickets WHERE owner_id=? ORDER BY id DESC", (o1["id"],))["id"]
    db.ticket_reply(tid, "فیش را دوباره بفرستید", side="admin")
    ns = onotifs(o1["id"])
    check("اعلان «پاسخ پشتیبانی»", any(n["kind"] == "ticket" for n in ns))

    head("ترجیحات (خاموش/روشن) + پیش‌فرض دنبال‌کردن")
    db.set_owner_pref(o1["id"], "sub", 0)
    sid4, _ = db.request_subscription(b1, paid["slug"], method="card")
    db.activate_subscription(sid4)
    before = len(onotifs(o1["id"]))
    db.activate_subscription(sid4)  # re-activate same → duplicate attempt
    after = len(onotifs(o1["id"]))
    check("خاموش‌کردن دستهٔ sub از ساخت اعلان جلوگیری کرد", before == after, f"{before}/{after}")
    db.set_owner_pref(o1["id"], "sub", 1)
    db._run("INSERT INTO claims(biz_id,owner_id,note,status) VALUES(?,?,?,'pending')",
            (b2, o2["id"], "م"))
    db.set_customer_pref(c1, "reply", 0)
    rid2 = db.add_review_full(b1, "ن", 5, "بد", customer_id=c1)
    db.update_review(rid2, reply="پاسخ")
    cn_after_off = len(cnotifs(c1))
    db.set_customer_pref(c1, "reply", 1)
    db.update_review(rid2, reply="پاسخ دوم")
    cn_after_on = len(cnotifs(c1))
    check("خاموش‌کردن reply برای مشتری مؤثر بود", cn_after_on == cn_after_off + 1, f"{cn_after_off}→{cn_after_on}")
    check("دستهٔ follow برای مشتری پیش‌فرض خاموش است",
          db.notify_customer(c1, "follow", "متن") is False)

    head("بهداشت صندوق (۶۰ روز / ۲۰۰ عدد)")
    # 60-day read rows removed
    for i in range(3):
        db._run("INSERT INTO owner_notifications(owner_id,kind,text,read,created) "
                "VALUES(?,'biz','کهنه',1,datetime('now','-100 days'))", (o2["id"],))
    db.purge_notifications()
    left = db._one("SELECT COUNT(*) c FROM owner_notifications WHERE owner_id=? AND text='کهنه'",
                   (o2["id"],))["c"]
    check("اعلان‌های خواندهٔ کهنه‌تر از ۶۰ روز پاک شدند", left == 0, str(left))
    # >200 newest cap
    for i in range(230):
        db._run("INSERT INTO owner_notifications(owner_id,kind,text,read) VALUES(?,'biz',? ,1)",
                (o2["id"], f"متن {i}"))
    db.purge_notifications()
    read_rows = db._one("SELECT COUNT(*) c FROM owner_notifications WHERE owner_id=? AND read=1",
                        (o2["id"],))["c"]
    unread_rows = db._one("SELECT COUNT(*) c FROM owner_notifications WHERE owner_id=? AND read=0",
                          (o2["id"],))["c"]
    check("اعلان‌های خوانده به ۲۰۰ عدد اخیر محدود شدند", read_rows <= 200, f"read={read_rows}")
    check("اعلان خوانده‌نشده هرگز کوتاه نمی‌شود", unread_rows >= 1, f"unread={unread_rows}")

    head("رندر UI اعلان‌ها (view های دکان‌دار و مشتری)")
    import views_owner as O
    import views_customer as CU
    st = db.get_settings()
    html_o = O.notifications_page(st, {"id": o1["id"], "name": "م", "phone": "09120000001"})
    check("صفحهٔ اعلان دکان‌دار رندر شد",
          "اعلان‌های من" in html_o and "/my/notif/" in html_o and "is-unread" in html_o and "خواندن همه" in html_o,
          f"len={len(html_o)}")
    db.notify_customer(c1, "price", "هشدار قیمت آزمایشی برای تست UI", "/prices")
    html_c = CU.notifications_page(st, {"id": c1, "name": "مشتری", "phone": "09120000003"})
    check("صفحهٔ اعلان مشتری رندر شد و لینک کلیک-خواندن دارد",
          "/me/notif/" in html_c and "هشدار قیمت آزمایشی" in html_c and "is-unread" in html_c,
          f"len={len(html_c)}")
    check("صفحهٔ دکان‌دار زمان شمسی نشان می‌دهد", "۱۴۰۵" in html_o or "۱۴۰۴" in html_o, "بدون تاریخ شمسی")

    head("صفحه‌های تنظیم اعلان هر نقش (بخش ۴)")
    st = db.get_settings()
    hso = O.notif_settings_page(st, {"id": o1["id"], "name": "م", "phone": "09120000001"})
    check("صفحهٔ تنظیم دکان‌دار رندر شد (۶ کلید + کارت گوشی + اسکریپت)",
          "تنظیم اعلان" in hso and hso.count('type="checkbox"') == 6
          and hso.count('name="k_') == 6 and "push-card" in hso
          and "notifpush.js?v142" in hso,
          f"checkbox={hso.count('type=\"checkbox\"')} k={hso.count('name=\"k_')}")
    hsc = CU.notif_settings_page(st, {"id": c1, "name": "مشتری", "phone": "09120000003"})
    check("صفحهٔ تنظیم مشتری رندر شد (۷ کلید شامل دنبال‌شده‌ها)",
          hsc.count('name="k_') == 7 and "push-card" in hsc
          and "notifpush.js?v142" in hsc,
          f"k={hsc.count('name=\"k_')}")
    check("دنبال‌شده‌ها (follow) برای مشتری پیش‌فرض خاموش است",
          'name="k_follow"' in hsc and 'name="k_follow" checked' not in hsc)
    db.set_owner_pref(o1["id"], "sub", False)
    db.set_customer_pref(c1, "news", False)
    check("خاموش‌کردن دسته در prefs ثبت و اعمال شد",
          not db.kind_enabled("owner", o1["id"], "sub")
          and not db.kind_enabled("cust", c1, "news"))
    check("پس از خاموش‌کردن، تیک در رندر بعدی برداشته می‌شود",
          'name="k_sub"' in (html := O.notif_settings_page(
              st, {"id": o1["id"], "name": "م", "phone": "09120000001"}))
          and 'name="k_sub" checked' not in html)
    db.set_owner_pref(o1["id"], "sub", True)
    db.set_customer_pref(c1, "news", True)
    check("دستهٔ نامعتبر در set_owner_pref رد می‌شود",
          db.set_owner_pref(o1["id"], "bogus", True) is False)

    head("زیرساخت push گوشی و خاموشی push ماتریس (بخش ۵)")
    sub_good = {"endpoint": "https://fcm.googleapis.com/fcm/send/fT0kEn-123",
                "keys": {"p256dh": "A", "auth": "B"}}
    ok1, msg1 = db.push_sub_save("cust", c1, sub_good)
    check("ثبت اشتراک FCM معتبر", ok1 is True and msg1 == "", msg1)
    db.push_sub_save("cust", c1, sub_good)   # duplicate -> upsert not new row
    nrow = db._one("SELECT COUNT(*) c FROM push_subs WHERE role='cust' AND user_id=?",
                   (c1,))["c"]
    check("ثبت دوبارهٔ همان اشتراک ردیف تازه نمی‌سازد", nrow == 1, f"rows={nrow}")
    ok2, msg2 = db.push_sub_save("cust", c1, {
        "endpoint": "https://updates.push.services.mozilla.com/wpush/v2/X"})
    check("مرورگر غیرکروم با پیام صادقانه رد می‌شود",
          ok2 is False and "پشتیبانی نمی" in msg2, msg2)
    db.push_sub_save("owner", o1["id"], {
        "endpoint": "https://fcm.googleapis.com/fcm/send/OwN-456",
        "keys": {"p256dh": "C", "auth": "D"}})
    check("push_tokens نقش‌ها را جدا می‌بیند",
          len(db.push_tokens("owner", o1["id"])) == 1
          and len(db.push_tokens("cust", c1)) == 1)
    db.push_prune_token("fT0kEn-123")
    check("جاروی توکن مرده (prune) فقط همان توکن را حذف می‌کند",
          len(db.push_tokens("cust", c1)) == 0
          and len(db.push_tokens("owner", o1["id"])) == 1)

    # -- push=False per the approved matrix, observed at the notify seam
    _orig_maybe = db._maybe_push
    _calls = []
    db._maybe_push = lambda role, uid, text, link: _calls.append((role, uid))
    try:
        db.notify_customer(c1, "price", "قیمت تست برای push", "/prices")
        check("notify مشتری با push پیش‌فرض، لایهٔ push را صدا می‌زند",
              len(_calls) == 1 and _calls[0][0] == "cust", str(_calls))
        _calls.clear()
        db.notify_customer(c1, "price", "بی‌پیام برای گوشی", "/prices", push=False)
        check("push=False در notify مشتری، push نمی‌فرستد ولی ردیف می‌سازد",
              len(_calls) == 0 and any(
                  n["text"] == "بی‌پیام برای گوشی" for n in cnotifs(c1)),
              str(_calls))
        db._run("INSERT INTO claims(biz_id,owner_id,note,status) "
                "VALUES(?,?,?,'pending')", (b2, o2["id"], "مالکیت دوباره"))
        cid3 = db._one("SELECT id FROM claims WHERE biz_id=? AND owner_id=? "
                       "ORDER BY id DESC", (b2, o2["id"]))["id"]
        _calls.clear()
        db.claim_decide(cid3, True)
        check("تصاحب تأییدشده push می‌فرستد (ماتریس: روشن)",
              len(_calls) == 1 and _calls[0][0] == "owner", str(_calls))
        sid5, _ = db.request_subscription(b1, paid["slug"], method="card")
        _calls.clear()
        check("ثبت درخواست تعرفه push نمی‌فرستد (ماتریس: خاموش)",
              len(_calls) == 0, str(_calls))
        _calls.clear()
        db.activate_subscription(sid5)
        check("فعال‌شدن تعرفه push می‌فرستد (ماتریس: روشن)",
              len(_calls) == 1 and _calls[0][0] == "owner", str(_calls))
        import json as _json2
        db._run("INSERT INTO edits(biz_id,owner_id,payload,status) "
                "VALUES(?,?,?,'pending')",
                (b1, o1["id"], _json2.dumps({"name": "نام سوم"}, ensure_ascii=False)))
        eid3 = db._one("SELECT id FROM edits WHERE biz_id=? ORDER BY id DESC",
                       (b1,))["id"]
        _calls.clear()
        db.decide_edit(eid3, True)
        check("تأیید ویرایش دکان‌دار push نمی‌فرستد (ماتریس: خاموش)",
              len(_calls) == 0, str(_calls))
    finally:
        db._maybe_push = _orig_maybe

    # -- real swallow path: notify with push=True but no FCM config
    db.set_settings({"fcm_service_json": "", "fcm_vapid_pub": ""})
    ok_nocfg = db.notify_customer(c1, "news", "بدون تنظیم push نباید بشکند", "")
    check("نبودِ تنظیم push هرگز خطا/کرش نمی‌سازد",
          ok_nocfg is True and any(
              n["text"] == "بدون تنظیم push نباید بشکند" for n in cnotifs(c1)))

    print("\n" + ("=" * 52))
    print(f"نتیجه: {ok_n} موفق / {bad_n} ناموفق")
    if FAILS:
        print("شکست‌ها:")
        for f in FAILS:
            print("  -", f)
        sys.exit(1)
    print("همه سبز ✅")


if __name__ == "__main__":
    main()
