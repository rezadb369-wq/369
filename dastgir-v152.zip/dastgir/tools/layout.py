# -*- coding: utf-8 -*-
"""Shared layout, icon set and component helpers for Bazarche Najafabad."""

import os

from data import SITE, CATEGORIES, CAT_LABEL, CAT_ICON

# ---------------------------------------------------------------- icons
# Lucide-style stroke icons, inline SVG. No emoji anywhere (skill rule #4).
_I = {
 "trophy":'<path d="M8 21h8M12 17v4M7 4h10v4a5 5 0 0 1-10 0V4Z"/><path d="M7 6H4a2 2 0 0 0 2 5M17 6h3a2 2 0 0 1-2 5"/>',
 "activity":'<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
 "search":'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
 "map":'<path d="m9 4-6 2.5v13L9 17l6 2.5 6-2.5v-13L15 6.5 9 4Z"/><path d="M9 4v13M15 6.5v13"/>',
 "pin":'<path d="M20 10.5c0 5.5-8 11.5-8 11.5s-8-6-8-11.5a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10.5" r="3"/>',
 "star":'<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L3.2 9.5l6.1-.9L12 3Z"/>',
 "clock":'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 "phone":'<path d="M21.5 16.9v2.5a2 2 0 0 1-2.2 2 19.5 19.5 0 0 1-8.5-3 19.2 19.2 0 0 1-5.9-5.9 19.5 19.5 0 0 1-3-8.6A2 2 0 0 1 3.9 1.7h2.5a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L7.5 9.6a16 16 0 0 0 5.9 5.9l1.2-1.1a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.9 2.3Z"/>',
 "mail":'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3.5 6.5 8.5 6 8.5-6"/>',
 "user":'<circle cx="12" cy="8" r="4"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/>',
 "users":'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 5.2a3.5 3.5 0 0 1 0 5.6M18 14.5a6.5 6.5 0 0 1 3.5 5.5"/>',
 "home":'<path d="M4.5 11 12 4.5 19.5 11"/><path d="M6.5 9.8V19a1.5 1.5 0 0 0 1.5 1.5h8A1.5 1.5 0 0 0 17.5 19V9.8"/><path d="M10 20.5v-4.3a2 2 0 0 1 4 0v4.3"/>',
 "hand":'<path d="M18 11V6a2 2 0 0 0-4 0v5"/><path d="M14 10V4a2 2 0 0 0-4 0v2"/><path d="M10 10.5V6a2 2 0 0 0-4 0v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/>',
 "store":'<path d="M4 9.5V20h16V9.5"/><path d="M3 4h18l1 5.5a3 3 0 0 1-5.7 1.3 3 3 0 0 1-5.6 0 3 3 0 0 1-5.7-1.3L3 4Z"/><path d="M9.5 20v-5h5v5"/>',
 "grid":'<rect x="3" y="3" width="7.5" height="7.5" rx="1.5"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1.5"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1.5"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.5"/>',
 "shopping":'<path d="M6 8h12l1.2 11.2a1.6 1.6 0 0 1-1.6 1.8H6.4a1.6 1.6 0 0 1-1.6-1.8L6 8Z"/><path d="M9 10V6.5a3 3 0 0 1 6 0V10"/>',
 "cart":'<circle cx="9.5" cy="19.5" r="1.6"/><circle cx="17" cy="19.5" r="1.6"/><path d="M2.5 3.5h2.2l2.3 11.2h11.3l1.9-8.2H6.4"/>',
 "box":'<path d="m12 3 8.5 4.5v9L12 21l-8.5-4.5v-9L12 3Z"/><path d="m3.7 7.6 8.3 4.4 8.3-4.4M12 12v9"/>',
 "tag":'<path d="M20.5 13.5 13 21a2 2 0 0 1-2.8 0l-7-7A2 2 0 0 1 2.6 12l.4-7a2 2 0 0 1 2-1.9l7-.4a2 2 0 0 1 1.5.6l7 7a2 2 0 0 1 0 2.8Z"/><circle cx="7.5" cy="7.5" r="1.4"/>',
 "chevron-down":'<path d="m6 9 6 6 6-6"/>',
 "chevron-left":'<path d="m15 6-6 6 6 6"/>',
 "chevron-right":'<path d="m9 6 6 6-6 6"/>',
 "arrow-left":'<path d="M19 12H5"/><path d="m11 6-6 6 6 6"/>',
 "check":'<path d="M20 6 9 17l-5-5"/>',
 "check-circle":'<circle cx="12" cy="12" r="9"/><path d="m8.5 12 2.5 2.5 4.5-5"/>',
 "x":'<path d="M18 6 6 18M6 6l12 12"/>',
 "x-circle":'<circle cx="12" cy="12" r="9"/><path d="m15 9-6 6M9 9l6 6"/>',
 "menu":'<path d="M4 6h16M4 12h16M4 18h16"/>',
 "sun":'<circle cx="12" cy="12" r="4"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M19.1 4.9l-1.8 1.8M6.7 17.3l-1.8 1.8"/>',
 "moon":'<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z"/>',
 "heart":'<path d="M12 20s-7.5-4.7-7.5-9.6A4.4 4.4 0 0 1 12 7.4a4.4 4.4 0 0 1 7.5 3c0 4.9-7.5 9.6-7.5 9.6Z"/>',
 "copy":'<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/>',
 "share":'<circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="m8.2 10.8 7.6-4.3M8.2 13.2l7.6 4.3"/>',
 "image":'<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9.5" r="1.8"/><path d="m3.5 17 5-4.5 4 3.5 3-2.5 5 4"/>',
 "camera":'<path d="M4 7h3l1.5-2h7L17 7h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1Z"/><circle cx="12" cy="13" r="3.5"/>',
 "edit":'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z"/>',
 "trash":'<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>',
 "settings":'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1Z"/>',
 "dashboard":'<rect x="3" y="3" width="7.5" height="9" rx="1.5"/><rect x="13.5" y="3" width="7.5" height="5.5" rx="1.5"/><rect x="13.5" y="11.5" width="7.5" height="9.5" rx="1.5"/><rect x="3" y="15" width="7.5" height="6" rx="1.5"/>',
 "chart":'<path d="M3 3v18h18"/><path d="M7 15l3.5-4 3 2.5L20 7"/>',
 "wallet":'<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H19a1 1 0 0 1 1 1v2"/><rect x="3" y="7.5" width="18" height="12" rx="2.5"/><circle cx="16.5" cy="13.5" r="1.3"/>',
 "credit-card":'<rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 10h19"/>',
 "message":'<path d="M20 15a2 2 0 0 1-2 2H8l-4 4V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2Z"/>',
 "bell":'<path d="M18 8a6 6 0 1 0-12 0c0 6-2.5 7-2.5 7h17S18 14 18 8Z"/><path d="M13.7 19a2 2 0 0 1-3.4 0"/>',
 "bookmark":'<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2Z"/>',
 "shield":'<path d="M12 22s8-3.5 8-9.5V5.5L12 2.5 4 5.5V12.5C4 18.5 12 22 12 22Z"/><path d="m9 12 2 2 4-4"/>',
 "lock":'<rect x="4.5" y="10.5" width="15" height="10" rx="2.5"/><path d="M8 10.5V7a4 4 0 0 1 8 0v3.5"/>',
 "logout":'<path d="M9 21H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
 "download":'<path d="M12 3v12"/><path d="m7.5 11 4.5 4.5 4.5-4.5"/><path d="M4 20h16"/>',
 "upload":'<path d="M12 20V8"/><path d="m7.5 12 4.5-4.5L16.5 12"/><path d="M4 4h16"/>',
 "filter":'<path d="M3 5h18l-7 8v6l-4 2v-8L3 5Z"/>',
 "info":'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
 "alert":'<path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 10v4M12 17h.01"/>',
 "plus":'<path d="M12 5v14M5 12h14"/>',
 "eye":'<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="3"/>',
 "send":'<path d="M21 3 10.5 13.5"/><path d="M21 3l-6.5 18-4-8-8-4L21 3Z"/>',
 "whatsapp":'<path d="M3 21l1.6-4.7A8.4 8.4 0 1 1 8 20.2L3 21Z"/><path d="M8.8 8.4c.2-.5.5-.5.8-.5h.6c.2 0 .5 0 .7.6l.8 2c.1.3 0 .5-.1.7l-.5.6c-.1.2-.2.4 0 .7a7 7 0 0 0 3.1 2.7c.3.1.5.1.7-.1l.6-.7c.2-.2.4-.2.6-.1l1.9.9c.3.1.5.3.5.5v.6c0 .3-.2.7-.7 1a3 3 0 0 1-2.3.5 11 11 0 0 1-6.7-6.3 3 3 0 0 1 0-2.6Z"/>',
 "instagram":'<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" stroke="none"/>',
 "telegram":'<path d="m21 4-2.7 15.3a1 1 0 0 1-1.5.6l-4.4-3.2-2.2 2.1a.8.8 0 0 1-1.3-.4L7.6 13 3.6 11.6a.8.8 0 0 1 0-1.5L20 3.9a.8.8 0 0 1 1 .1Z"/><path d="m8 13.4 9.5-6.6-7.7 8"/>',
 "sparkles":'<path d="m12 3 1.9 4.6L18.5 9.5l-4.6 1.9L12 16l-1.9-4.6L5.5 9.5l4.6-1.9L12 3Z"/><path d="m18.5 15 .9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9.9-2.1Z"/>',
 "layers":'<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/>',
 "zap":'<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z"/>',
 "compass":'<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5.5-5.5 2 2-5.5 5.5-2Z"/>',
 "refresh":'<path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 4v5h-5"/>',
 "database":'<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
 "file":'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5Z"/><path d="M14 3v5h5"/>',
 "list":'<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>',
 "table":'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 14h18M12 4v16"/>',
 "calendar":'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
 "globe":'<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18Z"/>',
 "target":'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/>',
 "award":'<circle cx="12" cy="9" r="5.5"/><path d="m8.5 13.5-1.5 7 5-2.5 5 2.5-1.5-7"/>',
 "trending":'<path d="m3 16 5.5-5.5 3.5 3.5L21 5"/><path d="M15 5h6v6"/>',
 "palette":'<path d="M12 21a9 9 0 1 1 9-9c0 2-1.6 3-3.5 3H16a2 2 0 0 0-1.4 3.4A2 2 0 0 1 12 21Z"/><circle cx="7.5" cy="11.5" r="1.2" fill="currentColor" stroke="none"/><circle cx="10.5" cy="7.5" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="8" r="1.2" fill="currentColor" stroke="none"/>',
 "help":'<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.6 2.6 0 1 1 3.4 2.5c-.6.2-.9.8-.9 1.4v.4M12 17h.01"/>',
 "book":'<path d="M4 4.5A1.5 1.5 0 0 1 5.5 3H19v16H5.5A1.5 1.5 0 0 0 4 20.5v-16Z"/><path d="M4 20.5A1.5 1.5 0 0 1 5.5 19H19v2H5.5A1.5 1.5 0 0 1 4 20.5Z"/>',
 "briefcase":'<rect x="3" y="7.5" width="18" height="12.5" rx="2"/><path d="M8.5 7.5V6a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v1.5"/><path d="M3 12.5h18"/>',
 "smile":'<circle cx="12" cy="12" r="9"/><path d="M8.5 14a4.5 4.5 0 0 0 7 0"/><path d="M9 9.5h.01M15 9.5h.01"/>',
 "external":'<path d="M14 4h6v6"/><path d="M20 4 11 13"/><path d="M18 14v5a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 19V7.5A1.5 1.5 0 0 1 5 6h5"/>',
 "bank":'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M3 11h18"/><path d="m12 3 8 4H4l8-4Z"/><path d="M8 15h.01M12 15h.01M16 15h.01"/>',
 "hash":'<path d="M9 3 7 21"/><path d="M17 3l-2 18"/><path d="M3 9h18"/><path d="M2 15h18"/>',
}


# ==========================================================================
#  v141 — Jalali (Persian) calendar for every USER-FACING date/time.
#  Pure Python, no dependency. The classic algorithm (g_d_m table), tested
#  against known dates — the site is Iranian; UI dates are solar Hijri.
# ==========================================================================
_JAL_G_D_M = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]

def g2j(gy, gm, gd):
    """Gregorian y/m/d -> (jy, jm, jd)  [Jalali]."""
    gy2 = gy + 1 if gm > 2 else gy
    days = (355666 + 365 * gy + (gy2 + 3) // 4 - (gy2 + 99) // 100
            + (gy2 + 399) // 400 + gd + _JAL_G_D_M[gm - 1])
    jy = -1595 + 33 * (days // 12053)
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        jy += (days - 1) // 365
        days = (days - 1) % 365
    if days < 186:
        jm = 1 + days // 31
        jd = 1 + days % 31
    else:
        jm = 7 + (days - 186) // 30
        jd = 1 + (days - 186) % 30
    return jy, jm, jd

def jdate(v):
    """'YYYY-MM-DD...' (or date/None/'—') -> Persian '۱۴۰۵/۰۶/۱۳'. Pass-through
    for empty/placeholder values so callers keep their '—' fallbacks."""
    if v is None: return ""
    s = str(v).strip()
    if not s or s in ("—", "-"): return s
    d = s[:10].split(" ")[0].split("T")[0]
    try:
        y, m, dd = map(int, d.split("-"))
        jy, jm, jd = g2j(y, m, dd)
    except Exception:
        return s
    return fa(f"{jy}/{jm:02d}/{jd:02d}")

def jdatetime(v):
    """'YYYY-MM-DD HH:MM[:SS]' -> Persian date + time '۱۴۰۵/۰۶/۱۳ ۲۱:۳۰'."""
    if v is None: return ""
    s = str(v).strip()
    if not s: return s
    date_part = jdate(s)
    if not date_part: return ""
    rest = s[10:].strip()
    hm = rest[:5] if len(rest) >= 5 else rest
    if not hm: return date_part
    try:
        hh, mm = map(int, hm.split(":")[:2])
        return f"{date_part} {fa(f'{hh:02d}:{mm:02d}')}"
    except Exception:
        return date_part + (" " + fa(hm) if hm else "")

def jdatetime_ts(ts):
    """Unix timestamp -> Persian date + local time."""
    if not ts: return ""
    import time as _time
    lt = _time.localtime(int(ts))
    return jdatetime(f"{lt.tm_year}-{lt.tm_mon:02d}-{lt.tm_mday:02d} "
                     f"{lt.tm_hour:02d}:{lt.tm_min:02d}")

def icon(name, cls="", size=None):
    if name not in _I:
        raise KeyError(f"unknown icon: {name}")
    c = f' class="{cls}"' if cls else ''
    s = f' width="{size}" height="{size}"' if size else ''
    # SVG <use> against a single inline symbol sprite: the same path is
    # referenced, never re-printed. 244 inline icons (56KB) become one sprite
    # (~5KB) + 244 tiny <use> tags — a real parse/paint win on a phone. (v54)
    return (f'<svg{c}{s} viewBox="0 0 24 24" fill="none" stroke="currentColor" '
            f'stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" '
            f'aria-hidden="true" focusable="false"><use href="#i-{name}"/></svg>')


def icon_sprite():
    """One hidden <svg> defining every icon as a <symbol>, emitted once per
    page. icon() then references them by id — no repeated path markup."""
    syms = "".join(
        f'<symbol id="i-{name}" viewBox="0 0 24 24">{body}</symbol>'
        for name, body in _I.items())
    return (f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'style="position:absolute;width:0;height:0;overflow:hidden" '
            f'aria-hidden="true" focusable="false">{syms}</svg>')

def stars(rating, size=15):
    """Rating stars — never colour-only: a numeric value always accompanies it.
    v151: the aria label uses the rounded Persian figure (no raw floats like
    4.666666666666667) — 4.7 reads "۴٫۷", a whole 5 reads "۵"."""
    rating = rating or 0
    r1 = round(float(rating), 1)
    shown = int(r1) if r1.is_integer() else r1
    out = []
    for i in range(1, 6):
        fill = "var(--accent-500)" if i <= round(rating) else "var(--color-border-strong)"
        out.append(f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="{fill}" '
                   f'stroke="none" aria-hidden="true">{_I["star"]}</svg>')
    return f'<span class="stars" role="img" aria-label="امتیاز {fa(shown)} از ۵">' + "".join(out) + "</span>"


def review_score_html(rating):
    """Stars + figure for one review row; a text-only tag when the review has
    no score (v151 text reviews carry rating=0)."""
    if not rating:
        return '<span class="text-xs text-muted">بدون امتیاز</span>'
    return f'{stars(rating)}<span class="nums">{fa(round(rating, 1))}</span>'


# ---------------------------------------------------------------- digits
_FA = "۰۱۲۳۴۵۶۷۸۹"
def fa(n):
    """Persian digits, and the Persian decimal separator (٫) instead of the
    Latin dot — otherwise "4.5" reads wrong inside an RTL sentence."""
    if n is None:          # v117/F-017: never render the word "None"
        return ""
    return str(n).translate(str.maketrans("0123456789", _FA)).replace(".", "٫")

def fa_group(n):
    return fa(f"{int(n):,}".replace(",", "٬"))


# ---------------------------------------------------------------- nav
PUBLIC_NAV = [
    ("index.html", "خانه", "store"),
    ("businesses.html", "کسب‌وکارها", "grid"),
    ("map.html", "نقشهٔ شهر", "map"),
    ("pricing.html", "تعرفه‌ها", "tag"),
    ("order-site.html", "سفارش سایت", "sparkles"),
    ("about.html", "درباره ما", "info"),
    ("contact.html", "تماس", "phone"),
]

OWNER_NAV = [
    ("panel.html", "داشبورد", "dashboard"),
    ("panel-business-edit.html", "ویرایش کسب‌وکار", "edit"),
    ("panel-reviews.html", "نظرات", "message"),
    ("panel-subscription.html", "اشتراک", "credit-card"),
]

ADMIN_NAV = [
    ("admin.html", "داشبورد", "dashboard"),
    ("admin-businesses.html", "کسب‌وکارها", "store"),
    ("admin-users.html", "کاربران", "users"),
    ("admin-categories.html", "دسته‌ها", "layers"),
    ("admin-orders.html", "سفارش‌ها", "briefcase"),
    ("admin-payments.html", "پرداخت‌ها", "wallet"),
    ("admin-messages.html", "پیام‌ها", "message"),
    ("admin-reports.html", "گزارش‌ها", "chart"),
    ("admin-settings.html", "تنظیمات", "settings"),
    ("admin-backup.html", "پشتیبان‌گیری", "database"),
]


# ---------------------------------------------------------------- chrome
def _aria(h, active):
    # 'aria-current="page"' built without an escaped quote so the literal can
    # live inside an f-string on Python 3.11 (no backslash in {expr}).
    return ' aria-current="page"' if h == active else ""


def header(active):
    nav = "".join(
        f'<a href="{h}"{_aria(h, active)}>{t}</a>'
        for h, t, _ in PUBLIC_NAV
    )
    mnav = "".join(
        f'<a href="{h}"{_aria(h, active)} data-nav-close>{icon(i)}<span>{t}</span></a>'
        for h, t, i in PUBLIC_NAV
    )
    return f'''<a class="skip-link" href="#main">پرش به محتوای اصلی</a>
<header class="site-header">
  <div class="container-wide header-inner">
    <a class="brand" href="index.html">
      <span class="brand-mark">{icon("hand")}</span>
      <span class="brand-text">{SITE["name"]}<small>{SITE["tagline"]}</small></span>
    </a>
    <nav class="main-nav" aria-label="ناوبری اصلی">{nav}</nav>
    <div class="header-actions">
      <button class="btn-icon" data-theme-toggle aria-pressed="false" aria-label="تغییر پوسته" type="button">
        <span class="theme-sun">{icon("sun")}</span><span class="theme-moon">{icon("moon")}</span>
      </button>
      <a class="btn btn-glass btn-sm hide-mobile" href="login.html">{icon("user")}<span>ورود</span></a>
      <a class="btn btn-primary btn-sm hide-mobile" href="register.html">{icon("plus")}<span>ثبت کسب‌وکار</span></a>
      <button class="btn-icon nav-toggle" data-nav-toggle aria-expanded="false" aria-controls="mobile-nav"
              aria-label="باز کردن منو" type="button">{icon("menu")}</button>
    </div>
  </div>
</header>

<div class="mobile-nav" id="mobile-nav" aria-hidden="true">
  <div class="backdrop" data-nav-close></div>
  <div class="panel" role="dialog" aria-modal="true" aria-label="منوی ناوبری">
    <div class="between mb-lg">
      <strong>منو</strong>
      <button class="btn-icon" data-nav-close aria-label="بستن منو" type="button">{icon("x")}</button>
    </div>
    {mnav}
    <hr class="divider">
    <a href="login.html" data-nav-close>{icon("user")}<span>ورود به حساب</span></a>
    <a href="register.html" data-nav-close>{icon("plus")}<span>ثبت کسب‌وکار</span></a>
    <a href="rules.html" data-nav-close>{icon("shield")}<span>قوانین</span></a>
  </div>
</div>'''


def footer():
    cats = "".join(
        f'<li><a href="businesses-cat.html?cat={k}">{l}</a></li>' for k, l, *_ in CATEGORIES[:6]
    )
    links = "".join(f'<li><a href="{h}">{t}</a></li>' for h, t, _ in PUBLIC_NAV[1:6])
    return f'''<footer class="site-footer">
  <div class="container-wide">
    <div class="footer-grid">
      <div class="footer-col footer-about">
        <a class="brand" href="index.html">
          <span class="brand-mark">{icon("hand")}</span>
          <span class="brand-text">{SITE["name"]}<small>{SITE["tagline"]}</small></span>
        </a>
        <p>{SITE["desc"]}</p>
        <div class="social-row mt-lg">
          <a href="{SITE["instagram"]}" aria-label="اینستاگرام" rel="noopener">{icon("instagram")}</a>
          <a href="{SITE["telegram"]}" aria-label="تلگرام" rel="noopener">{icon("telegram")}</a>
          <a href="{SITE["whatsapp"]}" aria-label="واتساپ" rel="noopener">{icon("whatsapp")}</a>
          <a href="mailto:{SITE["email"]}" aria-label="ایمیل">{icon("mail")}</a>
        </div>
      </div>
      <div class="footer-col"><h4>دسترسی سریع</h4><ul>{links}</ul></div>
      <div class="footer-col"><h4>دسته‌های پرمخاطب</h4><ul>{cats}</ul></div>
      <div class="footer-col">
        <h4>تماس با ما</h4>
        <ul>
          <li><a href="tel:{SITE["phone_raw"]}">{SITE["phone"]}</a></li>
          <li><a href="mailto:{SITE["email"]}">{SITE["email"]}</a></li>
          <li><span class="text-muted">{SITE["address"]}</span></li>
          <li><a href="rules.html">قوانین و مقررات</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© {fa(1405)} {SITE["name"]} — همهٔ حقوق محفوظ است.</span>
      <span>ساخته‌شده با دقت برای شهر نجف‌آباد</span>
    </div>
  </div>
</footer>'''


def page(title, body, active="", desc=None, extra_head="", body_class=""):
    d = desc or SITE["desc"]
    bc = f' class="{body_class}"' if body_class else ""
    return f'''<!DOCTYPE html>
<html lang="fa" dir="rtl" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#f4f8f7">
<title>{title} | {SITE["name"]}</title>
<meta name="description" content="{d}">
<meta property="og:title" content="{title} | {SITE['name']}">
<meta property="og:description" content="{d}">
<meta property="og:type" content="website">
<meta property="og:locale" content="fa_IR">
<link rel="icon" href="assets/img/favicon.svg" type="image/svg+xml">
<link rel="preload" href="assets/fonts/Vazirmatn-Variable.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/main.css">
<link rel="stylesheet" href="assets/css/pages.css">
{extra_head}
</head>
<body{bc}>
<div class="spatial-bg" aria-hidden="true"></div>
<div class="spatial-grain" aria-hidden="true"></div>
{header(active)}
<main id="main" class="main-content">
{body}
</main>
{footer()}
<script type="module" src="assets/js/app.js"></script>
</body>
</html>'''


# ---------------------------------------------------------------- components
def breadcrumb(*parts):
    out = ['<nav class="breadcrumb" aria-label="مسیر صفحه"><a href="index.html">خانه</a>']
    for i, (label, href) in enumerate(parts):
        out.append(icon("chevron-left"))
        if href and i < len(parts) - 1:
            out.append(f'<a href="{href}">{label}</a>')
        else:
            out.append(f'<span aria-current="page">{label}</span>')
    out.append("</nav>")
    return "".join(out)


def biz_card(b, delay=0):
    (slug, name, cat, rating, reviews, hours, addr, phone,
     featured, verified, created, tags, desc) = b
    ic = CAT_ICON[cat]
    badges = ""
    if featured:
        badges += f'<span class="badge badge-featured">{icon("sparkles")}<span>ویژه</span></span>'
    if verified:
        badges += f'<span class="badge badge-info">{icon("shield")}<span>تأییدشده</span></span>'
    tag_html = "".join(f'<span class="badge badge-neutral">{t}</span>' for t in tags[:3])
    search = f"{name} {CAT_LABEL[cat]} {' '.join(tags)} {addr}"

    return f'''<article class="card card-hover tilt biz-card reveal-3d" data-tilt="6" data-delay="{delay}"
  data-biz data-cat="{cat}" data-name="{name}" data-rating="{rating}" data-reviews="{reviews}"
  data-created="{created}" data-featured="{featured}" data-hours="{hours}" data-search="{search}">
  <span class="sheen" aria-hidden="true"></span>
  <div class="card-media biz-thumb">
    <div class="biz-thumb-art" aria-hidden="true">
      {cat_icon(ic, 128)}
    </div>
    <div class="media-badges layer-2">{badges}</div>
  </div>
  <div class="card-body layer-1">
    <div class="between" style="align-items:flex-start;gap:8px">
      <h3 class="card-title"><a href="business.html?b={slug}" class="stretch-link">{name}</a></h3>
      <span class="badge" data-open-badge>{icon("clock")}<span>—</span></span>
    </div>
    <div class="card-meta">
      {stars(rating)}
      <strong class="nums">{fa(rating)}</strong>
      <span>({fa(reviews)} نظر)</span>
      <span aria-hidden="true">·</span>
      <span>{CAT_LABEL[cat]}</span>
    </div>
    <p class="card-desc">{desc}</p>
    <div class="cluster mt-md">{tag_html}</div>
    <div class="card-foot">
      <span class="card-meta" style="margin:0">{icon("pin")}<span>{addr}</span></span>
      <span class="btn btn-ghost btn-sm" aria-hidden="true">{icon("chevron-left")}</span>
    </div>
  </div>
</article>'''


def stat_card(icon_name, value, label, suffix="", delay=0):
    return f'''<div class="card glass stat tilt reveal" data-tilt="5" data-delay="{delay}">
  <span class="sheen" aria-hidden="true"></span>
  <span class="stat-icon layer-1">{icon(icon_name)}</span>
  <div class="layer-1">
    <div class="stat-value nums" data-count="{value}" data-suffix="{suffix}">۰</div>
    <div class="stat-label">{label}</div>
  </div>
</div>'''


def section_head(eyebrow, title, sub=None, center=False, eyebrow_icon="sparkles"):
    c = " center" if center else ""
    s = f'<p>{sub}</p>' if sub else ""
    return f'''<div class="section-head{c} reveal">
  <span class="eyebrow">{icon(eyebrow_icon)}<span>{eyebrow}</span></span>
  <h2>{title}</h2>{s}
</div>'''


def panel_sidebar(nav, active, title, subtitle):
    items = "".join(
        f'<a href="{h}"{_aria(h, active)}>{icon(i)}<span>{t}</span></a>'
        for h, t, i in nav
    )
    return f'''<aside class="panel-side glass">
  <div class="panel-side-head">
    <span class="stat-icon">{icon("user")}</span>
    <div><strong>{title}</strong><small class="text-muted">{subtitle}</small></div>
  </div>
  <nav class="panel-nav" aria-label="ناوبری پنل">{items}</nav>
  <hr class="divider">
  <a class="panel-logout" href="index.html">{icon("logout")}<span>خروج از حساب</span></a>
</aside>'''


# ---------------------------------------------------------------- category icons
# v75 performance: use individual, lossless WebP files with native lazy loading.
# The old 2.1MB sprite downloaded in full even when only one 20px icon was
# visible. Individual files preserve quality and the browser fetches only the
# icons that actually enter the viewport.
try:
    from icon_grid import ICON_GRID, ICON_COLS, ICON_ROWS, ICON_CELL
except Exception:
    ICON_GRID, ICON_COLS, ICON_ROWS, ICON_CELL = {"store": [0, 0]}, 1, 1, 128

_CAT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "site", "assets", "img", "cats"))
_CAT_FILES = {os.path.splitext(f)[0] for f in os.listdir(_CAT_DIR) if f.endswith(".webp")}
_ICON_FALLBACK = {
    "store": "business", "shopping": "supermarket", "briefcase": "business",
    "camera": "photography", "map": "attraction", "compass": "attraction",
    "pin": "attraction", "mosque": "attraction",
}


def cat_icon(name, size=48, cls=""):
    picked = name if name in _CAT_FILES else _ICON_FALLBACK.get(name, "business")
    if picked not in _CAT_FILES:
        picked = next(iter(_CAT_FILES), "")
    safe_cls = str(cls or "").replace('"', "")
    return (f'<img class="ic cat-icon-file {safe_cls}" '
            f'src="/assets/img/cats/{picked}.webp" width="{int(size)}" height="{int(size)}" '
            f'alt="" loading="lazy" decoding="async" aria-hidden="true">')
