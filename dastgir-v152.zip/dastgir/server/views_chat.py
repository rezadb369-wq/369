# -*- coding: utf-8 -*-
"""Shared messenger UI for customer, shopkeeper and site admin (v73)."""

import urllib.parse

from ui import esc, fa, icon, empty_state, jdate, jdatetime

ACCEPT = "image/jpeg,image/png,image/webp,image/gif"
ROLE_LABEL = {
    "customer": "مشتری",
    "owner": "دکان‌دار",
    "admin": "مدیر دستگیر",
}


def conversations_tabs(viewer, active, token="", counts=None):
    """The unified «گفت‌وگوها» hub: ONE parent panel, every conversation type
    as a sub-branch tab. Customer↔shopkeeper chats and shopkeeper↔support
    tickets live under the same roof, so nothing is scattered across the menu.

    `active` is "chats" or "tickets"; `counts` maps those keys to unread
    numbers shown as pills. A single-type viewer (customer) gets the parent
    header without a tab bar.
    """
    counts = counts or {}
    if viewer == "admin":
        tabs = [("chats", "/panel/chats", "همهٔ گفتگوها", "message"),
                ("tickets", "/panel/tickets", "تیکت‌های پشتیبانی", "help")]
        suffix = ""    # v117/M1: keyless
    elif viewer == "owner":
        tabs = [("chats", "/my/chats", "گفتگوی مشتریان", "message"),
                ("tickets", "/my/tickets", "تیکت‌های پشتیبانی", "help")]
        suffix = ""
    else:
        tabs = [("chats", "/me/chats", "گفت‌وگوهای من", "message")]
        suffix = ""
    links = ""
    for key, href, label, ic in tabs:
        on = key == active
        n = int(counts.get(key) or 0)
        pill = f'<span class="conv-n nums">{fa(n)}</span>' if n else ""
        links += (f'<a class="conv-tab{" is-on" if on else ""}" '
                  f'href="{esc(href)}{esc(suffix)}"'
                  f'{" aria-current=\"page\"" if on else ""}>'
                  f'{icon(ic)}<span>{esc(label)}</span>{pill}</a>')
    bar = f'<div class="conv-tabs">{links}</div>'
    return (f'<div class="conv-hub"><div class="conv-hub-head">{icon("message")}'
            f'<span>گفت‌وگوها</span><small>همهٔ گفت‌وگوها در یک جا</small></div>'
            f'{bar}</div>')


def _file_url(attachment_id, viewer, key=""):
    # v117/M1: /chat-file authorises admins by session cookie; the key param
    # is kept in the signature for compatibility but never embedded anymore.
    return f"/chat-file/{int(attachment_id)}?as=" + urllib.parse.quote(viewer)


def _size_label(value):
    try:
        n = max(0, int(value or 0))
    except (TypeError, ValueError):
        n = 0
    if n >= 1024 * 1024:
        return f"{fa(round(n / 1024 / 1024, 1))} مگابایت"
    return f"{fa(max(1, round(n / 1024)))} کیلوبایت"


def attachment_markup(message, viewer, key=""):
    aid = message.get("attachment_id")
    if not aid:
        return ""
    name = message.get("file_name") or "فایل"
    url = _file_url(aid, viewer, key)
    if message.get("file_kind") == "image":
        return f'''<a class="msg-image" href="{esc(url)}" target="_blank" rel="noopener"
          aria-label="باز کردن تصویر {esc(name)}">
          <img src="{esc(url)}" alt="پیوست تصویری: {esc(name)}" loading="lazy" decoding="async">
          <span>{icon("image")}<span>{esc(name)}</span></span></a>'''
    return f'''<a class="msg-file" href="{esc(url)}" download>
      <span class="msg-file-icon">{icon("file")}</span>
      <span><strong>{esc(name)}</strong><small>{_size_label(message.get("file_size"))}</small></span>
      {icon("download")}</a>'''


def _peer_read_to(thread, viewer):
    if viewer == "customer":
        return max(int(thread.get("owner_read_to") or 0),
                   int(thread.get("admin_read_to") or 0))
    if viewer == "owner":
        return max(int(thread.get("customer_read_to") or 0),
                   int(thread.get("admin_read_to") or 0))
    return max(int(thread.get("customer_read_to") or 0),
               int(thread.get("owner_read_to") or 0))


def message_markup(message, thread, viewer, key=""):
    sender = message.get("sender") or "customer"
    mine = sender == viewer
    css = "me" if mine else ("admin" if sender == "admin" else "them")
    body = (f'<div class="msg-text">{esc(message.get("body") or "")}</div>'
            if message.get("body") else "")
    attachment = attachment_markup(message, viewer, key)
    label = ROLE_LABEL.get(sender, sender)
    stamp = jdatetime(message.get("created") or "")
    ticks = ""
    if mine:
        ticks = "✓✓" if int(message.get("id") or 0) <= _peer_read_to(thread, viewer) else "✓"
    return f'''<article class="msg {css}" data-msg-id="{int(message.get('id') or 0)}"
      data-sender="{esc(sender)}">
      <div class="msg-label">{esc(label)}</div>
      <div class="msg-bubble">{body}{attachment}</div>
      <div class="msg-meta"><time>{esc(stamp)}</time><span class="msg-ticks" data-delivery>{ticks}</span></div>
    </article>'''


def _last_preview(thread):
    last = thread.get("last") or {}
    text = (last.get("body") or "").strip()
    if text:
        return text[:90]
    if last.get("file_name"):
        return "پیوست: " + last["file_name"]
    return "گفتگو تازه ساخته شده است"


def thread_list(rows, viewer, base_path, key="", empty_title="گفتگویی ندارید",
                empty_text="گفتگوی تازه‌ای هنوز ثبت نشده است."):
    items = []
    for thread in rows:
        if viewer == "customer":
            title = thread.get("bizname") or "کسب‌وکار"
            avatar = title[:1]
            sub = "گفتگو با کسب‌وکار"
        else:
            customer = thread.get("custname") or "مشتری"
            title = f"{thread.get('bizname') or 'کسب‌وکار'} — {customer}"
            avatar = customer[:1]
            sub = "مشتری" if viewer == "owner" else (thread.get("custphone") or "مشتری")
        href = f"{base_path}/{thread['id']}"
        # v117/M1: the admin panel authenticates by session cookie; the raw
        # key no longer rides on every chat thread link.
        unread = int(thread.get("unread") or 0)
        last = thread.get("last") or {}
        stamp = jdatetime(last.get("created") or thread.get("created") or "")
        state = "باز" if thread.get("status") == "open" else "بسته"
        items.append(f'''<a class="thread-row{' is-unread' if unread else ''}" href="{esc(href)}">
          <span class="thread-avatar" aria-hidden="true">{esc(avatar or "؟")}</span>
          <span class="thread-main"><span class="thread-head"><strong>{esc(title)}</strong>
            <time>{esc(stamp)}</time></span>
            <span class="thread-preview">{esc(_last_preview(thread))}</span>
            <span class="thread-foot"><small>{esc(sub)}</small>
              <small class="thread-state is-{esc(thread.get('status') or 'open')}">{state}</small></span>
          </span>
          {f'<span class="thread-unread nums" aria-label="{fa(unread)} پیام خوانده‌نشده">{fa(unread)}</span>' if unread else ''}
        </a>''')
    if not items:
        return empty_state("message", empty_title, empty_text)
    return '<div class="thread-list" data-thread-list>' + "".join(items) + '</div>'


def chat_room(thread, messages, viewer, title, subtitle, post_url, back_url,
              key="", status="open"):
    last = messages[-1]["id"] if messages else 0
    bubbles = ""
    last_day = None
    for m in messages:
        day = str(m.get("created") or "")[:10]
        if day and day != last_day:
            # v145: data-date stays Gregorian (chat.js groups by it); the
            # visible chip becomes Jalali.
            bubbles += (f'<div class="chat-date" data-date="{esc(day)}">'
                        f'<span>{esc(jdate(day))}</span></div>')
            last_day = day
        bubbles += message_markup(m, thread, viewer, key)
    if not bubbles:
        bubbles = '''<div class="chat-empty"><span aria-hidden="true">✦</span>
          <strong>شروع یک گفتگوی تازه</strong><small>پیام یا فایل خود را از پایین بفرستید.</small></div>'''
    api = f"/api/chat/{thread['id']}/msgs?as={urllib.parse.quote(viewer)}"
    # v117/M1: the admin poll authorises by session cookie — no key in URLs.
    status_label = "گفتگو باز است" if status == "open" else "گفتگو بسته است"
    notice = ('''<div class="chat-closed-note">این گفتگو بسته شده است؛ ارسال پیام تازه آن را دوباره باز می‌کند.</div>'''
              if status == "closed" else "")
    return f'''<section class="messenger" data-chat-shell>
  <header class="messenger-head">
    <a class="messenger-back" href="{esc(back_url)}" aria-label="بازگشت">{icon("chevron-right")}</a>
    <span class="messenger-avatar" aria-hidden="true">{esc((title or "؟")[:1])}</span>
    <span class="messenger-person"><strong>{esc(title)}</strong><small>{esc(subtitle)}</small></span>
    <span class="messenger-state is-{esc(status)}" data-thread-status>{esc(status_label)}</span>
  </header>
  <div class="chat-box" data-chat data-chat-room data-thread="{int(thread['id'])}"
       data-me="{esc(viewer)}" data-last="{int(last)}" data-api="{esc(api)}"
       role="log" aria-live="polite" aria-relevant="additions" aria-label="پیام‌های گفتگو">
    {bubbles}
  </div>
  <button class="chat-new" type="button" data-chat-new hidden>{icon("chevron-down")}<span>پیام جدید</span></button>
  {notice}
  <form method="post" action="{esc(post_url)}" enctype="multipart/form-data"
        class="chat-composer" data-chat-form data-chat-composer>
    {f'<input type="hidden" name="key" value="{esc(key)}">' if key else ''}
    <div class="attach-preview" data-attach-preview hidden>
      <span>{icon("upload")}<span data-attach-name></span><small data-attach-size></small></span>
      <button type="button" data-attach-remove aria-label="حذف فایل انتخابی">{icon("x")}</button>
    </div>
    <div class="composer-row">
      <input class="sr-only" type="file" name="attachment" id="chat-file-{int(thread['id'])}-{esc(viewer)}"
             accept="{ACCEPT}" data-chat-file>
      <label class="composer-icon" for="chat-file-{int(thread['id'])}-{esc(viewer)}"
             data-attach-button title="افزودن عکس" aria-label="افزودن عکس">{icon("image")}</label>
      <label class="sr-only" for="chat-body-{int(thread['id'])}-{esc(viewer)}">متن پیام</label>
      <textarea class="composer-input" id="chat-body-{int(thread['id'])}-{esc(viewer)}"
                name="body" maxlength="2000" rows="1" data-chat-compose
                placeholder="پیام خود را بنویسید…"></textarea>
      <button class="composer-send" type="submit" data-chat-send aria-label="ارسال پیام">{icon("send")}</button>
    </div>
    <div class="composer-help"><span>Enter ارسال · Shift+Enter خط جدید</span>
      <span>فقط عکس · فشرده و پس از ۷ روز از سرور حذف می‌شود · حداکثر ۸MB</span></div>
    <p class="sr-only" role="status" aria-live="polite" data-chat-status></p>
  </form>
</section>'''
