# -*- coding: utf-8 -*-
"""
v142 — Google Web Push (FCM HTTP v1), pure Python standard library.

Why this exists: the old FCM API (simple server key) was fully shut down in
June 2024; the only current path is HTTP v1 with a Firebase *service
account*: sign an RS256 JWT assertion with the account's private key, trade
it for a short-lived OAuth2 access token, then POST the message.

No third-party dependency on purpose (runs on plain CPython hosts):
  * PEM/DER parsing        — tiny ASN.1 reader below
  * RS256 (PKCS#1 v1.5)    — modular exponentiation on Python ints
  * HTTPS POST             — urllib.request

Design rules from docs/NOTIFICATIONS.md §5:
  * The in-app notification row is the SOURCE OF TRUTH. Every failure here is
    logged and swallowed; the caller already saved the row.
  * No config (empty/malformed keys) = push silently off — never an error.
  * v142 scope: Chrome/Android via FCM endpoint. Other push endpoints are
    rejected at subscribe time with an honest Persian message.
  * Keys are stored (masked) in the panel settings; this module only reads.
"""

import json
import re
import sys
import time
import base64
import hashlib
import urllib.parse
import urllib.request
import urllib.error
import threading

# ---------------------------------------------------------------- base64url
def b64u(data):
    """base64url without padding (JWT / VAPID style)."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def b64u_dec(s):
    s = str(s).strip()
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


# ---------------------------------------------------------------- minimal ASN.1 (DER)
def _der_int(der, off):
    """Read one DER INTEGER at off -> (value:int, next_off:int)."""
    if der[off] != 0x02:
        raise ValueError(f"expected INTEGER, got 0x{der[off]:02x}")
    ln, off = _der_len(der, off + 1)
    val = int.from_bytes(der[off:off + ln], "big")
    return val, off + ln


def _der_len(der, off):
    """Read a DER length at off -> (length:int, next_off:int)."""
    b = der[off]
    if b < 0x80:
        return b, off + 1
    n = b & 0x7F
    if n == 0 or n > 4 or off + 1 + n > len(der):
        raise ValueError("bad DER length")
    ln = int.from_bytes(der[off + 1:off + 1 + n], "big")
    return ln, off + 1 + n


def _der_octets(der, off):
    """Read DER OCTET STRING at off -> (payload:bytes, next_off:int)."""
    if der[off] != 0x04:
        raise ValueError(f"expected OCTET STRING, got 0x{der[off]:02x}")
    ln, off = _der_len(der, off + 1)
    return der[off:off + ln], off + ln


def _der_skip(der, off):
    """Skip one full TLV at off -> next_off."""
    tag = der[off]
    ln, off = _der_len(der, off + 1)
    return off + ln


def pem_to_der(pem):
    """Strip a PEM armor (any label) and base64-decode its body."""
    lines = [ln.strip() for ln in str(pem).splitlines() if ln.strip()]
    body = []
    for ln in lines:
        if ln.startswith("-----") and ln.endswith("-----"):
            continue
        body.append(ln)
    return base64.b64decode("".join(body))


def parse_rsa_private(pem):
    """Service-account JSON gives a PKCS#8 'PRIVATE KEY' PEM; we also accept
    the legacy PKCS#1 'RSA PRIVATE KEY' armor. Returns (n, e, d)."""
    der = pem_to_der(pem)
    if der[0] != 0x30:
        raise ValueError("not a DER SEQUENCE")
    # SEQUENCE of TLVs; first INTEGER (version) then either
    #   PKCS#1: n, e, d, ...            -> use as-is
    #   PKCS#8: algorithm SEQUENCE, OCTET STRING(PKCS#1 DER)
    off = 1
    ln, off = _der_len(der, off)
    body_end = off + ln
    if der[off] == 0x02:                       # version INTEGER
        off = _der_skip(der, off)
    if der[off] == 0x30 and off < body_end:    # PKCS#8 algorithm sequence
        off = _der_skip(der, off)
        inner, _off = _der_octets(der, off)    # nested PKCS#1 DER
        if inner and inner[0] == 0x30:
            der = inner
            off = 1
            ln, off = _der_len(der, off)
            body_end = off + ln
            if der[off] == 0x02:               # nested PKCS#1 version INTEGER
                off = _der_skip(der, off)
    vals = []
    while off < body_end and len(vals) < 3:
        val, off = _der_int(der, off)
        vals.append(val)
    if len(vals) < 3:
        raise ValueError("private key is missing n/e/d")
    return vals[0], vals[1], vals[2]           # (n, e, d)


# ---------------------------------------------------------------- RS256 (PKCS#1 v1.5 + SHA-256)
_SHA256_DIGESTINFO = bytes.fromhex(
    "3031300d060960864801650304020105000420")


def _rsa_sign(n, d, digest):
    """Sign sha256 digest with PKCS#1 v1.5 EMSA-PKCS1-v1_5."""
    k = (n.bit_length() + 7) // 8
    t = _SHA256_DIGESTINFO + digest
    if len(t) + 11 > k:
        raise ValueError("key too small for RS256")
    em = b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t
    m = int.from_bytes(em, "big")
    return pow(m, d, n).to_bytes(k, "big")


def jwt_rs256(payload, pem_private):
    """Compact JWT signed RS256 with a PEM (PKCS#8 or PKCS#1) key."""
    n, _e, d = parse_rsa_private(pem_private)
    head = b64u(json.dumps({"alg": "RS256", "typ": "JWT"},
                           separators=(",", ":")))
    body = b64u(json.dumps(payload, separators=(",", ":")))
    signing = (head + "." + body).encode("ascii")
    sig = _rsa_sign(n, d, hashlib.sha256(signing).digest())
    return signing.decode("ascii") + "." + b64u(sig)


# ---------------------------------------------------------------- config
def _settings():
    import db
    return db.get_settings()


def load_service(cfg=None):
    """Parse the stored Firebase service-account JSON.
    Returns a dict or None when missing/malformed."""
    cfg = cfg if cfg is not None else _settings()
    raw = str(cfg.get("fcm_service_json") or "").strip()
    if not raw:
        return None
    try:
        obj = json.loads(raw)
    except Exception:
        return None
    need = ("project_id", "client_email", "private_key")
    if any(not str(obj.get(k) or "").strip() for k in need):
        return None
    if not str(obj.get("token_uri") or "").startswith("https://"):
        obj["token_uri"] = "https://oauth2.googleapis.com/token"
    obj["_raw"] = raw
    return obj


def vapid_public(cfg=None):
    cfg = cfg if cfg is not None else _settings()
    return str(cfg.get("fcm_vapid_pub") or "").strip()


def configured(cfg=None):
    """True only when a service account AND a VAPID public key are stored."""
    cfg = cfg if cfg is not None else _settings()
    svc = load_service(cfg)
    return bool(svc and vapid_public(cfg))


def validate_vapid(text):
    """VAPID public keys are url-safe base64 (~65-90 bytes decoded -> the
    encoded form is around 87-90 chars, but we accept a sane range)."""
    t = str(text or "").strip()
    if not t:
        return True, ""
    if not re.fullmatch(r"[A-Za-z0-9_\-]+", t) or not (40 <= len(t) <= 200):
        return False, ("کلید عمومی VAPID معتبر نیست — باید رشتهٔ base64url کوتاه بدون نویسهٔ اضافه باشد. از کنسول Firebase (Web Push certificates) کپی کنید.")
    return True, ""


def validate_service_json(text):
    """Panel-side validation (friendly Persian errors)."""
    text = str(text or "").strip()
    if not text:
        return True, ""
    try:
        obj = json.loads(text)
    except Exception:
        return False, "فایل JSON حساب سرویس Firebase معتبر نیست — محتوا را کامل و بدون تغییر بچسبانید."
    if not isinstance(obj, dict):
        return False, "JSON باید یک شیء (با پرانتز { }) باشد."
    miss = [k for k in ("project_id", "client_email", "private_key")
            if not str(obj.get(k) or "").strip()]
    if miss:
        return False, ("فایل حساب سرویس ناقص است: فیلد «"
                       + "، ".join(miss) + "» وجود ندارد.")
    return True, ""


# ---------------------------------------------------------------- OAuth2 access token
_TOKEN_LOCK = threading.Lock()
_TOKEN_CACHE = {"token": None, "until": 0.0}


def _post_form(url, fields):
    """application/x-www-form-urlencoded POST -> (status, body_bytes, err)."""
    req = urllib.request.Request(
        url, data=urllib.parse.urlencode(fields).encode("utf-8"),
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=12) as r:
            return r.status, r.read(), None
    except urllib.error.HTTPError as e:
        return e.code, e.read(), None
    except Exception as e:
        return 0, b"", str(e)


def _post_json(url, payload, headers):
    """application/json POST -> (status, parsed_dict_or_text, err)."""
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8",
                 **headers}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=12) as r:
            return r.status, json.loads(r.read().decode("utf-8", "replace")), None
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read().decode("utf-8", "replace"))
        except Exception:
            body = {"error": {"message": f"HTTP {e.code}"}}
        return e.code, body, None
    except Exception as e:
        return 0, {"error": {"message": str(e)}}, None


def access_token(svc):
    """Short-lived OAuth2 token for firebase.messaging scope (cached)."""
    now = time.time()
    with _TOKEN_LOCK:
        if _TOKEN_CACHE["token"] and _TOKEN_CACHE["until"] > now + 30:
            return _TOKEN_CACHE["token"], None
    iat = int(now)
    assertion = jwt_rs256({
        "iss": svc["client_email"],
        "scope": "https://www.googleapis.com/auth/firebase.messaging",
        "aud": svc["token_uri"],
        "iat": iat,
        "exp": iat + 3600,
    }, svc["private_key"])
    st, body, err = _post_form(svc["token_uri"], {
        "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
        "assertion": assertion,
    })
    if st != 200:
        msg = ""
        try:
            msg = json.loads(body.decode("utf-8", "replace")).get("error_description")
        except Exception:
            msg = str(body)[:120]
        _log(f"token fail {st}: {msg}")
        return None, f"توکن OAuth2 گرفته نشد (HTTP {st})."
    obj = json.loads(body.decode("utf-8", "replace"))
    tok = obj.get("access_token")
    if not tok:
        return None, "پاسخ توکن بدون access_token بود."
    with _TOKEN_LOCK:
        _TOKEN_CACHE["token"] = tok
        _TOKEN_CACHE["until"] = now + int(obj.get("expires_in", 3600)) - 60
    return tok, None


# ---------------------------------------------------------------- send
def _fcm_send_url(project_id):
    return (f"https://fcm.googleapis.com/v1/projects/"
            f"{urllib.parse.quote(str(project_id), safe='')}/messages:send")


def send(token, title, body, url="", icon="/assets/img/icons/app-192.png",
         svc=None, atoken=None):
    """One HTTP v1 message. Returns (ok:bool, detail:str).
    detail == 'gone' means the token died and should be pruned."""
    if not svc:
        return False, "unconfigured"
    if not atoken:
        return False, "no token"
    msg = {
        "token": str(token),
        "notification": {"title": str(title)[:80], "body": str(body)[:200]},
        "data": {"url": str(url)[:200], "icon": str(icon)[:200], "v": "1"},
    }
    st, body_resp, err = _post_json(
        _fcm_send_url(svc["project_id"]),
        {"message": msg},
        {"Authorization": "Bearer " + atoken})
    if st == 200:
        return True, "sent"
    detail = str(body_resp.get("error", {}).get("message") or "")[:160]
    if st == 404 or "UNREGISTERED" in detail.upper() or "NOT_FOUND" in detail.upper():
        return False, "gone"
    _log(f"send fail {st}: {detail}")
    return False, f"HTTP {st}"


def push_for(role, user_id, text, link=""):
    """Send one notification to every push subscription of a user.
    Fully best-effort: (False, reason) without any config, never raises."""
    import db
    cfg = _settings()
    svc = load_service(cfg)
    if not svc:
        return False, "unconfigured"
    title = str(cfg.get("site_name") or "دستگیر")
    tok, err = access_token(svc)
    if not tok:
        return False, err
    rows = db.push_tokens(role, user_id)
    if not rows:
        return False, "no subscription"
    ok_any = False
    for row in rows:
        ok, detail = send(row["token"], title, text, link, svc=svc, atoken=tok)
        if ok:
            ok_any = True
        elif detail == "gone":
            db.push_prune_token(row["token"])
            _log(f"pruned dead token ({role}:{user_id})")
    return ok_any, "" if ok_any else "no push delivered"


def _log(msg):
    try:
        print(f"[push] {msg}", file=sys.stderr)
    except Exception:
        pass
