# -*- coding: utf-8 -*-
"""
v142: display metadata for notification kinds (label + icon + short
description per role). Kept OUT of the view files so the bell page, the
settings pages (section 4) and the push layer (section 5) share one source
of truth. Icons must exist in layout's sprite.
"""
OWNER_META = {
    "sub":    ("tag", "تعرفه و پرداخت", "فعال/رد شدن تعرفه، یادآوری انقضا"),
    "biz":    ("store", "کسب‌وکار", "تأیید یا رد شدن دکان، ادعای مالکیت، ویرایش"),
    "chat":   ("message", "گفتگو", "پیام تازه از مشتری در گفتگو"),
    "order":  ("cart", "سفارش و نوبت", "سفارش، رزرو نوبت و درخواست قیمت تازه"),
    "social": ("star", "نظر و پرسش", "نظر، پرسش یا پیشنهاد چانه روی دکان شما"),
    "ticket": ("alert", "پشتیبانی", "پاسخ پشتیبانی به تیکت شما"),
}
CUST_META = {
    "chat":   ("message", "گفتگو", "پاسخ دکان در گفتگو"),
    "order":  ("cart", "سفارش", "تغییر وضعیت سفارش‌های شما"),
    "reply":  ("message", "پاسخ", "پاسخ دکان به نظر یا پرسش شما"),
    "haggle": ("tag", "چانه‌زنی", "پاسخ فروشنده به پیشنهاد شما"),
    "price":  ("tag", "هشدار قیمت", "ارزان‌شدن کالاهای هشدارشده"),
    "news":   ("bell", "اطلاعیه", "پیام سراسری مدیر سایت"),
    "follow": ("heart", "دنبال‌شده‌ها", "تازه‌های دکان‌هایی که دنبال می‌کنید"),
}
FALLBACK = ("bell", "اطلاعیه", "")


def meta(role, kind):
    """(icon, label, desc) for a kind; safe for unknown kinds."""
    table = OWNER_META if role == "owner" else CUST_META
    return table.get(kind or "", FALLBACK)


def kinds(role):
    """All settable kinds for a role, in display order."""
    return list(OWNER_META if role == "owner" else CUST_META)
