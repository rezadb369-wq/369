# -*- coding: utf-8 -*-
"""Owner-only admin bot over a dedicated Bale bot (v233).

Why a second bot: the public customer bot (server/bale.py) must never mix
with server administration. This module mirrors its transport (stdlib urllib
against https://tapi.bale.ai/bot) but uses its own token/secret/owner chat:

  BALE_ADMIN_TOKEN   bot token from @BotFather (the admin bot)
  BALE_ADMIN_SECRET  unguessable webhook path segment (32+ chars)
  BALE_ADMIN_CHAT    owner chat id(s) — v259: comma-separated team chats,
                     every member answered with full access

Route: POST /api/bale-admin/webhook/<secret> (see server/app.py, v185 mirror).

Sandbox note: the bazarche systemd unit sets NoNewPrivileges + ProtectSystem,
so privileged actions (backup now, service restart) CANNOT run in-process
(no sudo, no setuid). They are written to DATA_DIR/adminbot-cmd/*.json and
executed as root by /usr/local/sbin/dastgir-admin-exec.sh (cron, every
minute). Everything else answers instantly inside the webhook request.
"""
import datetime
import glob
import gzip
import hashlib
import html
import json
import os
import secrets
from pathlib import Path   # v272: do_chats fallback reads the log tail
import random
import re
import subprocess
import threading
import time
import urllib.request

import assistant
import db
import uploads
import adminbot_content as CT   # v239: full-power content tools

API_ROOT = os.environ.get("BALE_API_ROOT", "https://tapi.bale.ai/bot").rstrip("/")
FILE_ROOT = os.environ.get("BALE_FILE_ROOT", "https://tapi.bale.ai/file/bot").rstrip("/")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PUBLIC_HEALTH = "https://daastgir.ir/healthz"
OFFSITE_LOG = "/var/log/dastgir-offsite.log"
WATCHDOG_LOG = "/var/log/dastgir-watchdog.log"
NGINX_ACCESS = "/var/log/nginx/access.log"
NGINX_ERROR = "/var/log/nginx/error.log"

KEYBOARD = {"keyboard": [
    ["وضعیت", "آمار"],
    ["دیتابیس", "سیستم"],
    ["بکاپ", "گزارش"],
    ["ریستارت", "لاگ"],
    ["تأیید", "تازه‌ها"],
    ["نگهبان", "صف"],
    ["مغز", "تشخیص"],
    # v271 (دستور مدیر): گزینه‌های دیده‌شدنی هوش سایت، کلیدهای تک‌تک
    # مدل‌ها و فایل چت‌های عمومی.
    ["هوش سایت", "کلیدها"],
    ["چت‌ها", "ترمینال"],
    ["اسپم", "ایجنت"],
], "resize_keyboard": True}

# v264: one-tap brain picker — bare «مغز» swaps the keyboard to this; any
# successful switch swaps it back to KEYBOARD.
# v273 (دستور مدیر: کیرا کلا حذف شد): مغز پنجم = GLM، ردیف سوم.
BRAIN_KEYBOARD = {"keyboard": [
    ["اپوس ۵", "سونت ۵"],
    ["هایکو ۴.۵", "اوپن‌روتر"],
    ["GLM ۵.۳"],      # v273: مغز پنجم — GLM-5.3-Flash روی AvalAI
], "resize_keyboard": True}

# v271 (دستور مدیر): صفحه‌کلید هوش عمومی سایت — سوئیچ مدل با یک ضربه
# (شناسه‌های مستند AvalAI) + تعویض کلید. هر مدل قبل از سوئیچ زنده تست
# می‌شود (do_sitemodel). «بازگشت» صفحه‌کلید اصلی را برمی‌گرداند.
SITE_KEYBOARD = {"keyboard": [
    ["glm-5.3-flash", "glm-5.3"],
    ["glm-5.2", "کلید سایت"],
    ["بازگشت"],
], "resize_keyboard": True}

# v271 (دستور مدیر: «توکن تمام مدل‌ها … برا تک به تکشون گزینه باشه»):
# هر دکمه = جایگزینی توکن همان مغز. بعد از ضربه، کلید لخت را می‌فرستید
# و در اسلات همان مغز می‌نشیند (target در pending).
KEY_KEYBOARD = {"keyboard": [
    ["کلید اپوس", "کلید سونت"],
    ["کلید هایکو", "کلید اوپن"],
    ["کلید GLM", "کلید سایت"],
    ["بازگشت"],
], "resize_keyboard": True}

_KEY_TARGETS = {"کلید اپوس": "اپوس", "کلید سونت": "سونت",
                "کلید هایکو": "هایکو", "کلید اوپن": "اوپن",
                "کلید GLM": "GLM",   # v273: کیرا کلا حذف شد
                "کلید سایت": "سایت"}

ALLOWED_QUEUE_CMDS = ("backup", "restart", "secharden")
DENIED = "⛔ این بات فقط مال مدیره."
UNKNOWN = "🤔 نفهمیدم. بفرست: راهنما"


def token():
    return os.environ.get("BALE_ADMIN_TOKEN", "").strip()


def webhook_secret():
    return os.environ.get("BALE_ADMIN_SECRET", "").strip()


def owner_chat():
    """v259: first team chat (backward-compatible single value)."""
    return (owner_chats() or [""])[0]


def owner_chats():
    """v259 (دستور مدیر: مدیرتیم): BALE_ADMIN_CHAT می‌تواند چند شناسه با
    کاما باشد — همهٔ اعضای تیم مدیر با دسترسی کامل جواب می‌گیرند."""
    raw = os.environ.get("BALE_ADMIN_CHAT", "") or ""
    out = []
    for part in raw.split(","):
        c = part.strip()
        if c and c not in out:
            out.append(c)
    return out


def is_team_chat(chat_id):
    try:
        return str(chat_id) in owner_chats()
    except Exception:
        return False


def enabled():
    return bool(token() and webhook_secret() and owner_chat())


# --------------------------------------------------------------- v293 گیت فعال‌سازی
# دستور مدیر: ربات بله قبل از هر کاری باید با شمارهٔ تلفن (۰۹۱۳...) و سپس
# رمز حساس به حروف فعال شود؛ تا فعال‌نشده «هیچ» دستوری اجرا نمی‌شود.
# شماره و رمز فقط از متغیرهای محیطی (/etc/dastgir-secrets.env) خوانده می‌شوند
# و هرگز در لاگ/چت/سند چاپ نمی‌شوند.
BOT_GATE_CMD = ("/369", "۳۶۹", "/۳۶۹", "369")
BOT_LOCKED_MSG = (
    "🔐 ربات هنوز فعال نشده است.\n"
    "برای فعال‌سازی، فرمان «/369» را بفرستید تا شمارهٔ تلفن شما بررسی شود.")


def _gate_phone():
    return (os.environ.get("BOT_GATE_PHONE") or "").strip()


def _gate_phone_hash():
    """v297: the owner's phone number is personal data and must not travel in
    a publicly downloadable zip either. When BOT_GATE_PHONE_HASH is set the
    package carries only the digest of the normalised number."""
    return (os.environ.get("BOT_GATE_PHONE_HASH") or "").strip()


def _gate_phone_ok(phone_raw):
    """Match a typed/contact phone against the configured one. Hash form is
    compared digest-to-digest so the plaintext never has to ship."""
    got = db.norm_phone(phone_raw)
    if not got:
        return False
    h = _gate_phone_hash()
    if h:
        want_h = hashlib.sha256(("gatephone:" + got).encode()).hexdigest()
        try:
            return secrets.compare_digest(want_h, h)
        except TypeError:
            return False
    want = db.norm_phone(_gate_phone())
    return bool(got and want and got == want)


def _gate_pass():
    return os.environ.get("BOT_GATE_PASS") or ""


def _gate_pass_hash():
    """v297: the shipped package must never carry the bot gate password in
    the clear (v296 shipped deploy/gate.env with it, publicly downloadable).
    When BOT_GATE_PASS_HASH is set, only the one-way hash travels in the
    artifact and the plaintext never has to. Same PBKDF2-600k the panel
    password uses, so there is one password primitive in the codebase."""
    return (os.environ.get("BOT_GATE_PASS_HASH") or "").strip()


def _gate_pass_ok(typed):
    """Verify the typed gate password against whichever form is configured.
    Hash wins when both are present — the plaintext env var stays available
    for a server that keeps it in /etc/dastgir-secrets.env."""
    if not typed:
        return False
    h = _gate_pass_hash()
    if h:
        try:
            # db.verify_password(pw, stored) — note the argument order.
            return bool(db.verify_password(typed, h))
        except Exception:
            return False
    raw = _gate_pass()
    if not raw:
        return False
    try:
        return secrets.compare_digest(typed, raw)
    except TypeError:
        return False


def gate_enabled():
    """The gate is armed when the owner configured a phone number — either
    in the clear (server-side secrets file) or as a digest (shipped zip)."""
    return bool(_gate_phone() or _gate_phone_hash())


def _gate_id(chat_id):
    return hashlib.sha256(("botgate:%s" % chat_id).encode()).hexdigest()[:16]


def gate_state(chat_id):
    """'' | phone | pass | ok — persisted in settings (survives restart)."""
    try:
        v = json.loads(db.get_settings().get("bot_gate_" + _gate_id(chat_id)) or "{}")
        return v.get("state") or ""
    except Exception:
        return ""


def _gate_set(chat_id, state):
    db.set_setting("bot_gate_" + _gate_id(chat_id), json.dumps({"state": state}))


def gate_ok(chat_id):
    if not gate_enabled():
        return True
    return gate_state(chat_id) == "ok"


def gate_handle_phone(chat_id, phone_raw):
    """Shared by typed text and Bale's official request_contact button."""
    ident = _gate_id(chat_id)
    if not db.rate_ok("botgate:phone:" + ident, limit=8, window=900, always=True):
        return "⏳ تلاش‌های فعال‌سازی زیاد است؛ ۱۵ دقیقهٔ دیگر دوباره امتحان کنید."
    if _gate_phone_ok(phone_raw):
        _gate_set(chat_id, "pass")
        return ("✅ شمارهٔ تلفن مطابقت دارد.\n"
                "حالا رمز ربات را وارد کنید (به حروف کوچک و بزرگ حساس است).")
    return "❌ شمارهٔ تلفن مطابقت ندارد. برای تلاش دوباره /369 را بفرستید."


def gate_step(chat_id, text):
    """State machine for an un-activated chat. Returns the reply text."""
    st = gate_state(chat_id)
    t = (text or "").strip()
    if st == "phone":
        # فقط متنِ رقم‌دار «تلاش شماره» است؛ فرمان‌ها و متن‌های دیگر سهمیهٔ
        # تلاش را نمی‌سوزانند و پیام قفل می‌گیرند (ریشهٔ باگ تست: /status
        # قبلاً تلاش شمارهٔ غلط حساب می‌شد و سهمیه را می‌خورد).
        digits = re.sub(r"\D", "", t)
        if len(digits) >= 4:
            return gate_handle_phone(chat_id, t)
        return BOT_LOCKED_MSG
    if st == "pass":
        ident = _gate_id(chat_id)
        if not db.rate_ok("botgate:pass:" + ident, limit=8, window=900, always=True):
            return "⏳ تلاش‌های فعال‌سازی زیاد است؛ ۱۵ دقیقهٔ دیگر دوباره امتحان کنید."
        # v297: goes through _gate_pass_ok so a shipped hash (never the
        # plaintext) can unlock the bot — see deploy/gate.env.
        ok = _gate_pass_ok(t)
        if ok:
            _gate_set(chat_id, "ok")
            try:
                db.log("bot.gate", "bot activated for chat")
            except Exception:
                pass
            return ("🎉 ربات به‌طور کامل فعال شد.\n"
                    "از این لحظه همهٔ دستورهای مدیر بدون محدودیت اجرا می‌شوند.")
        return ("❌ رمز درست نیست (حساس به حروف کوچک و بزرگ).\n"
                "رمز را دوباره بفرستید، یا برای شروع از نو /369.")
    return BOT_LOCKED_MSG


def notify_panel_login(code, ip=""):
    """v293 layer-3: ask the owner's Bale chat to confirm a panel login."""
    if not enabled():
        return False
    msg = (
        "🔐 درخواست ورود به پنل مدیریت ثبت شد.\n"
        "🌐 آی‌پی: %s\n"
        "⏱ مهلت تأیید: ۵ دقیقه.\n"
        "اگر خودتان هستید بفرستید: تأیید %s\n"
        "اگر شما نبودید بفرستید: رد %s" % (ip or "نامشخص", code, code))
    sent = False
    for cid in owner_chats():
        try:
            if send_message(cid, msg):
                sent = True
        except Exception:
            pass
    return sent


def decide_panel_approval(text):
    """«تأیید 123456» / «رد 123456» from the owner chat. Returns reply or None."""
    parts = (text or "").strip().split()
    if len(parts) != 2:
        return None
    verb, code = parts[0], parts[1]
    if verb in ("تأیید", "تایید", "قبول"):
        if db.panel_approval_decide(code, True):
            return "✅ ورود به پنل تأیید شد و کنسول باز می‌شود."
        return "⚠️ کد تأیید معتبر نیست یا مهلتش تمام شده است."
    if verb in ("رد", "نه‌تأیید"):
        if db.panel_approval_decide(code, False):
            return "🚫 ورود رد شد و نشست بسته شد. اگر شما نبودید، رمز پنل را عوض کنید."
        return "⚠️ کد تأیید معتبر نیست یا مهلتش تمام شده است."
    return None


def queue_dir():
    return os.environ.get("ADMINBOT_QUEUE") or os.path.join(db.DATA_DIR, "adminbot-cmd")


def pending_path():
    # Prod runs under systemd PrivateTmp, so a restart naturally clears a
    # half-confirmed restart -- exactly the safe behaviour we want.
    return os.environ.get("ADMINBOT_PENDING") or "/tmp/dastgir-admin-pending.json"


# ---------- transport (same shape as server/bale.py) ----------

def _call(method, payload):
    tok = token()
    if not tok:
        return {"ok": False}
    req = urllib.request.Request(
        f"{API_ROOT}{tok}/{method}",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json", "User-Agent": "Daastgir/233"},
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            out = json.loads(r.read(262144).decode("utf-8", "replace"))
            return out if isinstance(out, dict) else {"ok": False}
    except Exception:
        return {"ok": False}


def send_message(chat_id, text, reply_markup=None):
    cid = str(chat_id)
    data = {"chat_id": int(cid) if cid.isdigit() else cid, "text": str(text)[:4096]}
    if reply_markup:
        data["reply_markup"] = reply_markup
    return bool(_call("sendMessage", data).get("ok"))


def delete_message(chat_id, message_id):
    """v274 (دستور مدیر): حذف best-effort یک پیام از چت — برای پاک‌کردنِ
    پیامِ لختِ حاوی کلید بعد از مصرف. هرگز raise نمی‌کند؛ شکست یعنی
    پیام در تاریخچه مانده و پاسخ، خودِ مدیر را به حذف دستی دعوت می‌کند."""
    if message_id is None:
        return False
    try:
        cid = str(chat_id)
        return bool(_call("deleteMessage", {
            "chat_id": int(cid) if cid.isdigit() else cid,
            "message_id": message_id}).get("ok"))
    except Exception:
        return False


def send_document(chat_id, path, caption=""):
    """v270: send a file as a Bale document (multipart/form-data).
    Returns True only on an ok response. Never raises."""
    tok = token()
    if not tok or not os.path.isfile(path):
        return False
    try:
        with open(path, "rb") as f:
            blob = f.read(52428800)      # Telegram/Bale document cap: 50 MB
    except Exception:
        return False
    cid = str(chat_id)
    boundary = "----Daastgir270" + format(random.getrandbits(64), "016x")
    parts = []

    def field(name, value):
        parts.append(("--" + boundary + "\r\n"
                      'Content-Disposition: form-data; name="%s"\r\n\r\n' % name
                      + str(value) + "\r\n").encode("utf-8"))

    field("chat_id", int(cid) if cid.isdigit() else cid)
    if caption:
        field("caption", str(caption)[:1024])
    fname = os.path.basename(path)
    parts.append(("--" + boundary + "\r\n"
                  'Content-Disposition: form-data; name="document"; filename="%s"\r\n'
                  "Content-Type: application/octet-stream\r\n\r\n" % fname).encode("utf-8"))
    parts.append(blob)
    parts.append(("--" + boundary + "--\r\n").encode("utf-8"))
    req = urllib.request.Request(
        f"{API_ROOT}{tok}/sendDocument", data=b"".join(parts),
        headers={"Content-Type": "multipart/form-data; boundary=" + boundary,
                 "User-Agent": "Daastgir/270"},
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            out = json.loads(r.read(65536).decode("utf-8", "replace"))
            return bool(isinstance(out, dict) and out.get("ok"))
    except Exception:
        return False


# ---------- small helpers ----------

def _run(args, timeout=10):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout,
                           stdin=subprocess.DEVNULL)
        return (p.stdout or "").strip()
    except Exception:
        return ""


def _fetch_url(url, timeout=10):
    req = urllib.request.Request(url, headers={"User-Agent": "Daastgir/233"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(4096).decode("utf-8", "replace")


def _human(n):
    try:
        n = int(n)
    except (TypeError, ValueError):
        return "?"
    if n >= 1048576:
        return f"{n / 1048576:.1f}M"
    if n >= 1024:
        return f"{n / 1024:.0f}K"
    return f"{n}B"


def _tail(path, n=3, width=120):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()[-n:]
        return "\n".join(l[:width] for l in lines)
    except OSError:
        return ""


def _days_until(datestr):
    """Whole days from now until a `date -d`-parseable date, or None."""
    try:
        then = int(_run(["date", "-d", datestr, "+%s"], timeout=5) or 0)
    except (TypeError, ValueError):
        return None
    if then <= 0:
        return None
    return max(0, (then - int(time.time())) // 86400)


_J_MONTHS = ("", "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
             "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
_J_WEEKDAYS = ("دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه", "یکشنبه")


def fa_today():
    """v234: «چهارشنبه ۱۸ شهریور» (Tehran); Gregorian fallback, never raises."""
    try:
        now = db.iran_now().replace(tzinfo=None)
        from layout import g2j  # tools/ is on sys.path next to server/
        jy, jm, jd = g2j(now.year, now.month, now.day)
        return "%s %d %s" % (_J_WEEKDAYS[now.weekday()], jd, _J_MONTHS[jm])
    except Exception:
        return time.strftime("%F")


# ---------- getters ----------

def g_site():
    t0 = time.time()
    try:
        body = _fetch_url(PUBLIC_HEALTH)
        ms = int((time.time() - t0) * 1000)
        return f"✅ بالا ({ms}ms)" if "ok" in body else "🚨 جواب خراب"
    except Exception:
        # The webhook itself is being served, so the app is up; only the
        # public loopback check failed.
        return "✅ بالا"


# ---------------------------------------------------------------- gauge cache
# v286 audit (ممیزی کامل به دستور مدیر — فاز ۳: رندر روان‌تر):
# کارت سلامتِ داشبوردِ پنل getterهای کُند را در هر رندر sync صدا می‌زد
# (g_cert = هندشیک TLS واقعی با تایم‌اوت ۱۲ ثانیه، g_errcount = journalctl،
# g_svc = systemctl) — با شبکه/journal کُند، کلِ داشبورد ۱۲+ ثانیه بلاک
# می‌شد. این اعداد دست‌کم ساعتی یک‌بار عوض می‌شوند؛ اکنون هر مقدار با TTL
# خودش در رشتهٔ پس‌زمینه تازه می‌شود و رندر همیشه فوری آخرین مقدارِ
# شناخته‌شده را برمی‌گرداند. ربات مدیر (دستور مستقیم مدیر) همچنان از
# نسخهٔ sync استفاده می‌کند — خواندنِ بی‌محدودیت طبق قرارداد دست‌نخورده است.

_GAUGE = {}                 # name -> (fetched_at, value, thread|None)
_GAUGE_LOCK = threading.Lock()


def gauge_cached(name, fn, ttl, fallback="?", cold_wait=2.0):
    """Non-blocking cached gauge: last known value now, refresh in background.

    When nothing has ever been fetched, wait up to `cold_wait` seconds for the
    first refresh so a healthy network shows the real value on the first
    render (and v237's stubbed getters appear live); a hung network degrades
    to the fallback after the budget while the thread keeps running.
    """
    now = time.time()
    with _GAUGE_LOCK:
        ent = _GAUGE.get(name)
        if ent and ent[1] is not None and now - ent[0] < ttl:
            return ent[1]
        busy = bool(ent and ent[2] and ent[2].is_alive())
        th = None
        if not busy:
            th = threading.Thread(target=_gauge_refresh, args=(name, fn),
                                  daemon=True)
            _GAUGE[name] = (ent[0] if ent else 0.0,
                            ent[1] if ent else None, th)
            th.start()
        cold = th is not None and (not ent or ent[1] is None)
    if cold and cold_wait > 0:
        th.join(cold_wait)
        with _GAUGE_LOCK:
            ent = _GAUGE.get(name)
    return ent[1] if (ent and ent[1] is not None) else fallback


def _gauge_refresh(name, fn):
    try:
        val = fn()
    except Exception:
        val = None
    with _GAUGE_LOCK:
        ent = _GAUGE.get(name)
        keep = ent[1] if ent else None
        _GAUGE[name] = (time.time(), val if val not in (None, "") else keep,
                        None)


def g_cert_cached():
    """گواهی: انقضا ~۹۰ روز یک‌بار عوض می‌شود — TTL شش‌ساعته."""
    return gauge_cached("cert", g_cert, 6 * 3600, fallback="?")


def g_svc_cached():
    return gauge_cached("svc", g_svc, 60, fallback="?")


def g_errcount_cached():
    v = gauge_cached("errcount", g_errcount, 300, fallback=None)
    return 0 if v is None else v


def g_svc():
    return _run(["systemctl", "is-active", "bazarche"]) or "?"


def _disk_pct():
    try:
        import shutil
        u = shutil.disk_usage("/")
        return u.used * 100 // u.total
    except Exception:
        return None


def g_disk():
    pct = _disk_pct()
    return f"{pct}٪" if pct is not None else "?"


def g_ver():
    try:
        with open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8") as f:
            return f.read().strip() or "?"
    except OSError:
        return "?"


def g_up():
    try:
        with open("/proc/uptime") as f:
            secs = int(float(f.read().split()[0]))
    except (OSError, ValueError, IndexError):
        return "?"
    if secs >= 86400:
        return f"{secs // 86400} روز"
    if secs >= 3600:
        return f"{secs // 3600} ساعت"
    return f"{secs // 60} دقیقه"


def g_backup():
    # The offsite log has no timestamps (plain cron capture), so freshness
    # comes from the file mtime while success comes from the content.
    lines = _tail(OFFSITE_LOG, 5, 200).splitlines()
    stripped = [l.strip() for l in lines]
    # v236: the offsite script timestamp-prefixes every line
    # ("2026-09-09 20:40:01 OK: db=..."), so the markers are matched
    # anywhere in the line, not just at the start.
    if stripped and "FAIL" in stripped[-1]:
        return "خطا! 🚨"
    if not any("OK:" in s for s in stripped):
        return "نامشخص"
    try:
        age_min = int((time.time() - os.path.getmtime(OFFSITE_LOG)) // 60)
    except OSError:
        return "نامشخص"
    if age_min >= 60:
        return f"{age_min // 60} ساعت پیش ✅"
    return f"{age_min} دقیقه پیش ✅"


def g_cert():
    out = _run(["openssl", "s_client", "-connect", "daastgir.ir:443",
                "-servername", "daastgir.ir"], timeout=12)
    if not out:
        return "?"
    try:
        # v236: input= already feeds stdin — passing stdin=DEVNULL too
        # raises ValueError, which made this always return "?".
        p = subprocess.run(["openssl", "x509", "-noout", "-enddate"], input=out,
                           capture_output=True, text=True, timeout=10)
        end = (p.stdout or "").strip().split("=", 1)[-1]
        days = _days_until(end)
        return str(days) if days is not None else "?"
    except Exception:
        return "?"


def g_traffic():
    """(hits, uniq_ips, err5) for today, or None when the log is unreadable."""
    try:
        day = time.strftime("%d/%b/%Y")
        hits, ips, e5 = 0, set(), 0
        with open(NGINX_ACCESS, encoding="utf-8", errors="replace") as f:
            for line in f:
                if "[" + day not in line:
                    continue
                hits += 1
                parts = line.split()
                if parts:
                    ips.add(parts[0])
                if len(parts) >= 9 and parts[8].startswith("5"):
                    e5 += 1
        return hits, len(ips), e5
    except OSError:
        return None


def g_errcount():
    out = _run(["journalctl", "-u", "bazarche", "-p", "err", "--since",
                "24 hours ago", "--no-pager", "-o", "cat"])
    return sum(1 for l in out.splitlines() if l.strip()) if out else 0


def g_db():
    """(bookings, new, today, customers, week_new, businesses, items, unread, new_inq)."""
    def q(sql):
        try:
            con = db.connect()
            row = con.execute(sql).fetchone()
            con.close()
            return str(row[0])
        except Exception:
            return "?"
    return (
        q("SELECT COUNT(*) FROM bookings"),
        q("SELECT COUNT(*) FROM bookings WHERE status='new'"),
        q("SELECT COUNT(*) FROM bookings WHERE substr(created,1,10)=date('now')"),
        q("SELECT COUNT(*) FROM customers"),
        q("SELECT COUNT(*) FROM customers WHERE substr(created,1,10)>=date('now','-7 days')"),
        q("SELECT COUNT(*) FROM businesses"),
        q("SELECT COUNT(*) FROM items"),
        q("SELECT COUNT(*) FROM messages WHERE status='new'"),
        q("SELECT COUNT(*) FROM inquiries WHERE status='new'"),
    )


def g_dbsize():
    try:
        return _human(os.path.getsize(db.DB_PATH))
    except OSError:
        return "?"


# ---------- replies (pure: return text, the route sends it) ----------

def watchdog_state_path():
    return os.environ.get("ADMINBOT_WATCHDOG_STATE") or "/var/lib/dastgir-watchdog.state"


def _active_alerts():
    try:
        with open(watchdog_state_path(), encoding="utf-8") as f:
            return [l.strip() for l in f if l.strip()]
    except OSError:
        return []


def do_queue():
    try:
        files = sorted(os.listdir(queue_dir()))
    except OSError:
        files = []
    files = [f for f in files if f.endswith(".json")]
    if not files:
        return "📭 صف اجرا خالی است."
    lines = ["📭 صف اجرا:"]
    now = time.time()
    for f in files[:10]:
        try:
            age = int((now - os.path.getmtime(os.path.join(queue_dir(), f))) // 60)
        except OSError:
            age = -1
        cmd = f.rsplit("-", 2)[0]
        lines.append(f"• {cmd} ({age} دقیقه در صف)" if age >= 0 else f"• {cmd}")
    return "\n".join(lines)


def do_spam(text=""):
    """v279 (فاز۵، دستور مدیر): گزارش ضداسپم + ban/lift. فقط چت تیم —
    خود dispatcher پشت is_team_chat است."""
    import antispam
    parts = [w for w in (text or "").strip().split() if w]
    if len(parts) >= 2 and parts[1] in ("lift", "بردار"):
        ident = parts[2][:45] if len(parts) > 2 else ""
        if not ident:
            return "⚠️ شناسه را هم بنویس: اسپم lift <شناسه>"
        if not antispam.lift(ident):
            return "⚠️ این شناسه ban فعال ندارد."
        db.log("adminbot.spam", f"lift {ident}")
        return f"✅ ban «{ident}» برداشته شد."
    if len(parts) >= 2 and parts[1] in ("ban", "بلاک"):
        ident = parts[2][:45] if len(parts) > 2 else ""
        if not ident:
            return "⚠️ شناسه را هم بنویس: اسپم ban <شناسه> [ساعت]"
        hours = parts[3] if len(parts) > 3 else "1"
        antispam.ban_now(ident, hours, by="adminbot")
        return f"✅ «{ident}» برای {hours} ساعت ban شد."
    r = antispam.report()
    held = antispam.held_counts()
    bans = antispam.bans_active()
    L = ["🛡️ گزارش ضداسپم — ۲۴ ساعت اخیر"]
    if r["actions"]:
        L.append("کنش‌ها (رویداد/رد):")
        for a in r["actions"][:12]:
            L.append(f"· {a['action']} — {a['verdict']}: {a['c']}")
    else:
        L.append("· رویدادی ثبت نشده.")
    L.append(f"ban فعال: {len(bans)}" + (
        "" if not bans else " — " + "، ".join(
            f"{b['ident']} ({b['left_m']} دقیقه)" for b in bans[:5])))
    L.append("نگه‌بررسی: نظر %s · پرسش %s · تیکت %s · کالا %s" % (
        held.get("reviews", 0), held.get("questions", 0),
        held.get("tickets", 0), held.get("items", 0)))
    L.append("کنسول کامل: /panel/spam — اینجا: «اسپم ban <شناسه> [ساعت]» یا «اسپم lift <شناسه>»")
    return "\n".join(L)


def do_status():
    alerts = _active_alerts()
    extra = ("\n🔕 هشدار فعال: %s" % ", ".join(alerts)) if alerts else ""
    return ("📊 وضعیت دستگیر (v%s)\n"
            "🌐 سایت: %s\n"
            "⚙️ سرویس: %s · 💾 دیسک: %s\n"
            "💿 بکاپ: %s\n"
            "🔒 گواهی: %s روز · ⏱ %s%s" % (
                g_ver(), g_site(), g_svc(), g_disk(), g_backup(),
                g_cert(), g_up(), extra))


def do_traffic():
    t = g_traffic()
    if t is None:
        return "📈 آمار: لاگ nginx پیدا نشد"
    h, u, e = t
    return ("📈 آمار امروز\n"
            "👁 بازدید: %s · 👤 آی‌پی یکتا: %s\n"
            "🔥 خطای 5xx: %s" % (h, u, e))


def do_db():
    b, bn, bt, c, cw, bz, it, m, q = g_db()
    return ("🗄 دیتابیس (%s)\n"
            "📅 نوبت‌ها: %s کل · %s جدید · %s امروز\n"
            "👥 مشتری: %s (%s این هفته) · 🏪 کسب‌وکار: %s · 📦 آیتم: %s\n"
            "✉️ پیام خوانده‌نشده: %s · 📩 استعلام جدید: %s" % (
                g_dbsize(), b, bn, bt, c, cw, bz, it, m, q))


def do_sys():
    try:
        load = "%.2f %.2f %.2f" % os.getloadavg()
    except (OSError, AttributeError):
        load = "?"
    mem = "?"
    try:
        info = {}
        with open("/proc/meminfo") as f:
            for line in f:
                p = line.split()
                if len(p) >= 2:
                    info[p[0].rstrip(":")] = int(p[1])
        pct = (info["MemTotal"] - info["MemAvailable"]) * 100 // info["MemTotal"]
        mem = "%d٪ (%dM آزاد)" % (pct, info["MemAvailable"] // 1024)
    except (OSError, KeyError, ValueError, ZeroDivisionError):
        pass
    # v286 audit (خروجی «پرمصرف: ps 100٪» در گزارش مدیر): ستون %cpu خودِ ps
    # میانگینِ عمرِ فرایند است (cputime/elapsed) — فرایندهای کوتاهِ خودِ
    # بات (ps/du/journalctl) لحظه‌ای ۱۰۰٪ می‌نمایند. حالا سنِ فرایند (etimes)
    # هم خوانده می‌شود و نخستین فرایندِ دست‌کم ۵ ثانیه‌زنده که خودِ ابزارِ
    # اندازه‌گیری نباشد گزارش می‌شود.
    top_s = "?"
    lines = _run(["ps", "-eo", "comm,%cpu,etimes", "--sort=-%cpu"]).splitlines()
    for ln in lines[1:]:
        parts = ln.split()
        if len(parts) < 3:
            continue
        try:
            age = int(parts[-1])
        except ValueError:
            continue
        if age < 5 or parts[0] in ("ps", "top", "du", "journalctl", "sh", "bash"):
            continue
        top_s = "%s %s٪" % (parts[0], parts[1])
        break
    du = _run(["du", "-sb", os.path.join(ROOT, "site", "assets", "img", "uploads")]).split()
    ups = _human(du[0]) if du else "?"
    ssh = _run(["journalctl", "-u", "ssh", "--since", "24 hours ago",
                "--no-pager", "-o", "cat"])
    fails = sum(1 for l in ssh.splitlines() if "Failed" in l) if ssh else 0
    # v286 audit: هشدار فعال وقتی brute-force سنگین است — راهنمای سخت‌سازی
    # در deploy/SSH-HARDENING-fa.md است (fail2ban + کلید + بستن رمز).
    ssh_s = str(fails)
    if fails >= 500:
        ssh_s += " ⚠️ سنگین — راهنما: SSH-HARDENING"
    elif fails >= 100:
        ssh_s += " ⚠️"
    return ("🖥 سیستم\n"
            "📉 لود: %s · 🧠 رم: %s\n"
            "🔥 پرمصرف: %s\n"
            "🗄 دیتابیس: %s · 🖼 آپلودها: %s\n"
            "🛡 ورود ناموفق SSH: %s" % (load, mem, top_s, g_dbsize(), ups, ssh_s))


def do_errors():
    j = _run(["journalctl", "-u", "bazarche", "-p", "err", "--since",
              "24 hours ago", "--no-pager", "-o", "cat"]).splitlines()[-2:]
    j = "\n".join(l[:150] for l in j) or "ندارد ✅"
    n = ""
    try:
        day = time.strftime("%Y/%m/%d")
        with open(NGINX_ERROR, encoding="utf-8", errors="replace") as f:
            hit = [l.rstrip() for l in f if day in l][-2:]
        n = "\n".join(l[:150] for l in hit)
    except OSError:
        pass
    n = n or "ندارد ✅"
    return "⚠️ خطاها (۲۴ ساعت)\nسرویس:\n%s\nnginx:\n%s" % (j, n)


def do_log():
    l1 = _tail(OFFSITE_LOG, 3) or "خالی"
    l2 = _tail(WATCHDOG_LOG, 3) or "خالی"
    return "📋 بکاپ:\n%s\n📋 نگهبان:\n%s" % (l1, l2)


def do_chats(chat_id):
    """v270 (دستور مدیر): send the public-chat log file to the owner.
    One JSONL file (data/site_chats.log) — every public exchange appended
    by assistant.chat_log. Owner-only (dispatch is behind is_team_chat)."""
    p = assistant.CHAT_LOG
    size = os.path.getsize(p) if os.path.exists(p) else 0
    if not size:
        return "🗂 هنوز چت عمومی‌ای ثبت نشده — فایل خالی است.", None
    try:
        with open(p, "rb") as f:
            n = sum(1 for _ in f)
    except Exception:
        n = 0
    cap = ("🗂 کل چت‌های عمومی سایت — %s پیام · %s\n"
           "JSONL: when/channel/user/q/a/source/model/intent"
           % (assistant._fa(n), _human(size)))
    if send_document(chat_id, p, cap):
        return "🗂 فایل چت‌های عمومی ارسال شد — %s پیام · %s" % (assistant._fa(n), _human(size)), None
    # v272 (دستور مدیر: «فایلش را نتونستم دریافت کنم»): اگر sendDocument به
    # هر دلیلی نشد، گزارش همین‌جا به‌صورت متن می‌رسد — مدیر هرگز بی‌پاسخ نمی‌ماند.
    try:
        tail = Path(p).read_text(encoding="utf-8", errors="replace").splitlines()[-40:]
    except OSError:
        tail = []
    send_message(chat_id, "🗂 (sendDocument نشد — گزارش متنی %s پیام آخر):\n%s"
                 % (assistant._fa(len(tail)), "\n".join(tail)[:4000]))
    return ("⚠️ ارسال فایل موفق نبود؛ %s پیام آخر به‌صورت متن فرستاده شد. "
            "دوباره «چت‌ها» را بفرست تا فایل کامل برسد." % assistant._fa(len(tail))), None


def do_report():
    t = g_traffic()
    h, u, e = t if t else ("?", "?", "?")
    d = g_db()
    return ("📋 گزارش دستگیر (%s)\n"
            "🌐 سایت: %s · ⚙️ %s · 💾 %s\n"
            "💿 بکاپ: %s · 🔒 گواهی: %s روز\n"
            "📈 بازدید: %s (%s آی‌پی) · خطای 5xx: %s\n"
            "📅 نوبت جدید: %s · ✉️ پیام جدید: %s\n"
            "⚠️ خطای ۲۴ساعت: %s" % (
                fa_today(), g_site(), g_svc(), g_disk(),
                g_backup(), g_cert(), h, u, e, d[1], d[7], g_errcount()))


DIAG_LATEST = "310"   # v251: بامپ در هر نسخه، همراه VERSION.txt / sw.js / README


def do_diagnose():
    """v249: one word → the exact broken link, tested LIVE on this server.
    Numbered lines so the owner can screenshot it and we can point at the
    failing step precisely. Never prints keys."""
    import urllib.error
    L = ["🩺 تشخیص زندهٔ دستیار — " + fa_today()]
    try:
        ver = str(g_ver())
        L.append(f"۱) نسخهٔ سایت: {ver}" +
                 (" ✅ به‌روز" if ver == DIAG_LATEST
                  else f" ⚠️ قدیمی‌تر از آخرین نسخه ({DIAG_LATEST})"))
    except Exception:
        L.append("۱) نسخهٔ سایت: خوانده نشد")
    try:
        c = assistant.config()
        if c.get("base_url") and c.get("api_key"):
            model = c.get("model_smart") or c.get("model")
            host = (c.get("base_url") or "").split("//")[-1].split("/")[0]
            t0 = time.time()
            try:
                assistant._chat(c["base_url"], c["api_key"], model,
                                [{"role": "user", "content": "ping"}], 20, 5)
                st = f"✅ پاسخ داد ({time.time() - t0:.1f} ثانیه)"
            except urllib.error.HTTPError as e:
                # v260: هر کد معنای خودش را دارد؛ v261: بدنهٔ 403 را هم
                # می‌خوانیم چون «کلیدِ محدود به مدل» و «محدودیت منطقه‌ای»
                # هر دو 403 می‌دهند ولی درمانشان فرق دارد (مورد زندهٔ v260:
                # model_access_limited). کلید هرگز در بدنهٔ خطا نیست.
                _body = ""
                if e.code == 403:
                    try:
                        _body = (e.read() or b"")[:400].decode("utf-8", "replace")
                    except Exception:
                        _body = ""
                if e.code == 403 and "model_access_limited" in _body:
                    _why = " (کلید به این مدل دسترسی ندارد — مدلِ مجاز کلید یا کلید نامحدود لازم است)"
                else:
                    _why = {401: " (کلید نامعتبر؟)",
                            403: " (محدودیت منطقه‌ای)",
                            404: " (مدل/آدرس نادرست؟)"}.get(e.code, "")
                st = f"❌ HTTP {e.code}" + _why
            except Exception as e:
                st = f"❌ {type(e).__name__} (شبکه/سرویس)"
            L.append(f"۲) مغز هوش مصنوعی: {model} @ {host} — {st}")
            # v265: no automatic backup, ever (owner order) — only «مغز» switches.
            L.append("   سوئیچ خودکار: خاموش ⛔ (فقط «مغز» دستی)")
            if not c.get("brain_custom"):
                L.append("   مغز فعال: " + assistant.BRAIN_FA.get(c.get("brain"), "?") +
                         " (سوئیچ فوری: /مغز)")
            else:
                L.append("   مغز فعال: دستی — خارج از ۵تایی (/مغز برمی‌گرداند)")
            try:
                _le = assistant.last_error()
                le = str(_le.get("what") or "") if isinstance(_le, dict) else str(_le or "")
            except Exception:
                le = ""
            if le:
                L.append("   آخرین خطای ثبت‌شده: " + le[:120])
        else:
            L.append("۲) مغز هوش مصنوعی: ❌ هیچ کلیدی وصل نیست — همهٔ درخواست‌های هوشمند شکست می‌خورند")
            L.append("   راه‌حل: /کلید Muse <کلید aa-…>   یا   /کلید gemini <کلید رایگان>")
        # v269 (دستور مدیر: محیط‌ها جدا): وضعیت هوش عمومی سایت — اسلات
        # مستقل AI_SITE_* با تست زندهٔ خودش؛ بدون کلید، کاربران پاسخ
        # قاعده‌مند + کش رایگان می‌گیرند (هزینه صفر).
        try:
            sc = assistant.site_config()
            if sc.get("base_url") and sc.get("api_key"):
                _shost = (sc.get("base_url") or "").split("//")[-1].split("/")[0]
                t0 = time.time()
                try:
                    assistant._chat(sc["base_url"], sc["api_key"], sc["model"],
                                    [{"role": "user", "content": "ping"}], 20, 5)
                    _sst = f"✅ پاسخ داد ({time.time() - t0:.1f} ثانیه)"
                except urllib.error.HTTPError as e:
                    _swhy = {401: " (کلید نامعتبر؟)", 402: " (اعتبار تمام؟)",
                             403: " (محدودیت/دسترسی مدل؟)",
                             404: " (شناسهٔ مدل نادرست؟ «مدل سایت»)"}.get(e.code, "")
                    _sst = f"❌ HTTP {e.code}" + _swhy
                except Exception as e:
                    _sst = f"❌ {type(e).__name__} (شبکه/سرویس)"
                L.append(f"   هوش سایت (عمومی، جدا): {sc['model']} @ {_shost} — {_sst}")
            else:
                L.append("   هوش سایت (عمومی، جدا): ❌ کلیدی وصل نیست — "
                         "کاربران پاسخ قاعده‌مند + کش رایگان می‌گیرند "
                         "(نصب: /کلید سایت <کلید> [مدل])")
        except Exception as e:
            L.append(f"   هوش سایت (عمومی، جدا): بررسی نشد ({type(e).__name__})")
    except Exception as e:
        L.append(f"۲) مغز هوش مصنوعی: بررسی نشد ({type(e).__name__})")
    try:
        cron = os.path.exists("/etc/cron.d/dastgir-codeguard")
        L.append("۳) کرون کدگارد (اعمال‌کنندهٔ تغییرات کد): " +
                 ("✅ نصب است" if cron else
                  "❌ نصب نیست — تغییرات کد در صف می‌مانند و هرگز اعمال نمی‌شوند!"
                  " فرمان نصب کامل را همراه tee بفرست."))
    except Exception:
        L.append("۳) کرون کدگارد: بررسی نشد")
    try:
        L.append("۴) " + CT.CODE.code_status_text().replace("\n", " · ")[:320])
    except Exception:
        L.append("۴) وضعیت صف استقرار: خوانده نشد")
    try:
        L.append(f"۵) سرویس: {g_svc()} · آپتایم {g_up()}")
    except Exception:
        L.append("۵) سرویس: خوانده نشد")
    try:
        pend = _pending_read()
        L.append("۶) تأیید در انتظار: " +
                 (f"{pend.get('action')} — اگر منظورت نیست «نه» بفرست" if pend else "ندارد"))
    except Exception:
        L.append("۶) تأیید در انتظار: خوانده نشد")
    L.append("— این گزارش را کامل عکس بگیر و بفرست؛ هر خط دقیق می‌گوید کجا گیر کرده است.")
    return "\n".join(L), None


def do_help():
    # v272: «راهنما» از قبل (متن، KEYBOARD) برمی‌گرداند؛ خودِ متن دست‌نخورده.
    # کلید تازهٔ پس از هر نصب را admin_kb_ver در handle_update تضمین می‌کند.
    return _help_text()


def _help_text():
    return ("🤖 دستورات (یا دکمه‌ها):\n"
            "وضعیت · آمار · دیتابیس · سیستم · تشخیص · مغز\n"
            "بکاپ · گزارش · ریستارت · لاگ\n"
            "امنیت (گزارش زندهٔ امنیت سرور+سایت با دلیل) · "
            "سخت‌سازی (نصب fail2ban + مسدود مهاجمان با تأیید «بله»)\n"
            "خطا · صف · تأیید · تازه‌ها\n"
            "چت‌ها (فایل کل چت‌های عمومی سایت — v270)\n"
            "پنل <بخش> — خواندن هر بخش پنل (مثلاً: پنل سفارش‌ها) · پنل = فهرست بخش‌ها\n"
            "نگهبان · پیام · کاربر · قیمت · حذف\n"
            "ظاهر پیش‌فرض (بازگشت ظاهر به پیش‌فرض)\n"
            "کلید ورود (نشانی ورود پنل + ساخت رمز) · ایجنت (پنل ایجنت — ورود ایمیلی مالک کافی است؛ کلید ربات اختیاری)\n"
            "ترمینال — sh <فرمان> اجرای مستقیم مثل ترموکس (بدون هوش) · sh bg <فرمان> در پس‌زمینه\n"
            "مدل (فهرست و سوئیچ مدل‌های GLM مغز پنجم)\n"
            "مدل سایت (هوش عمومی کاربران — جدا از مغزهای شما) · /کلید سایت\n"
            "هوش سایت (سوئیچ مدل با یک ضربه) · کلیدها (توکن تک‌تک مدل‌ها)\n"
            "راهنما · سؤال آزاد (هوش مصنوعی)\n\n"
            "✏️ متن آزاد = دستیار تمام‌قد: هر تغییرِ محتوای سایت\n"
            "(متن‌ها، دسته، کسب‌وکار، محصول، نظر، مقاله، پیام همگانی…)\n"
            "را درخواست کنید؛ خودش آماده و فوراً اجرا می‌کند.\n"
            "🖼 برای عکس: اول عکس را همین‌جا بفرستید، بعد بگویید کجا\n"
            "استفاده شود (ویترین، استوری، بنر، جلد مقاله، …).\n"
            "🛠 v241: کد سایت هم در دسترس است — بگویید چه چیزی در سایت\n"
            "تغییر کند (قالب، دکمه، منطق، متن قالب، …)؛ خودش فایل را\n"
            "می‌خواند، ویرایش را آماده و فوراً اجرا می‌کند؛ با بررسی\n"
            "سلامت و برگشتِ خودکار در صورت خطا اعمال می‌شود.", KEYBOARD)


# ---------- v237: admin powers (visibility + actions) ----------

def do_bizqueue():
    rows = db._rows("SELECT id,name,phone,city FROM businesses WHERE status='pending' ORDER BY id DESC LIMIT 8")
    total = db._one("SELECT COUNT(*) c FROM businesses WHERE status='pending'")["c"]
    if not rows:
        return "📭 کسب‌وکار در انتظاری نیست."
    lines = [f"🏪 در انتظار تأیید ({total}):", ""]
    for r in rows:
        lines.append(f"#{r['id']} · {(r['name'] or '—')}\n{(r['phone'] or '—')} · {(r['city'] or '—')}")
    lines += ["", "تأیید ۱۲ = انتشار · رد ۱۲ = رد"]
    return "\n".join(lines)


def do_biz_ask(approve, bid):
    r = db._one("SELECT id,name FROM businesses WHERE id=? AND status='pending'", (bid,))
    if not r:
        return "این کسب‌وکار پیدا نشد یا قبلاً بررسی شده است."
    _pending_write(time.time() + 120, "biz_ok" if approve else "biz_no", str(bid))
    return f"«{r['name']}» {'منتشر' if approve else 'رد'} بشه؟ بفرست: بله"


def _do_biz_decide(action, target):
    try:
        bid = int(target)
    except (TypeError, ValueError):
        return "⚠️ خطای داخلی؛ دوباره بفرست.", None
    r = db._one("SELECT id,name FROM businesses WHERE id=? AND status='pending'", (bid,))
    if not r:
        return "این کسب‌وکار پیدا نشد یا قبلاً بررسی شده است.", None
    ok = action == "biz_ok"
    db.save_business({"status": "published" if ok else "rejected"}, bid=bid)
    db.log("biz.bot-" + ("approve" if ok else "reject"), f"{bid} {r['name']}")
    return (f"«{r['name']}» منتشر شد ✅" if ok else f"«{r['name']}» رد شد.", None)


def do_cast_ask(text):
    body = str(text or "").strip()
    if not body:
        return "متن پیام را هم بفرست. مثلاً: پیام سلام! فروش ویژه شروع شد."
    if len(body) > 500:
        return "متن تا ۵۰۰ نویسه باشد."
    n = db._one("SELECT COUNT(*) c FROM customers WHERE status='active'")["c"]
    _pending_write(time.time() + 120, "cast", body)
    return f"به {n} مشتری ارسال بشه؟\n\n«{body}»\n\nبفرست: بله"


def _do_cast(target):
    body = str(target or "").strip()
    if not body:
        return "متن خالی است؛ دوباره بفرست: پیام <متن>", None
    n = db.notify_all("info", body, "")
    db.log("broadcast", f"{n} customers (bot)")
    return f"اعلان برای {n} مشتری ارسال شد ✅", None


def do_fresh():
    try:
        cust24 = db._one("SELECT COUNT(*) c FROM customers WHERE created>=datetime('now','-1 day')")["c"]
        ord24 = db._one("SELECT COUNT(*) c FROM orders WHERE created>=datetime('now','-1 day')")["c"]
        book_new = db._one("SELECT COUNT(*) c FROM bookings WHERE status='new'")["c"]
        chats_open = db._one("SELECT COUNT(*) c FROM chat_threads WHERE status='open'")["c"]
        pend_biz = db._one("SELECT COUNT(*) c FROM businesses WHERE status='pending'")["c"]
    except Exception:
        return "⚠️ خطای داخلی؛ دوباره بفرست."
    return ("🆕 تازه‌ها (۲۴ ساعت)\n"
            f"👥 مشتری تازه: {cust24}\n"
            f"📦 سفارش تازه: {ord24}\n"
            f"📅 نوبت جدید (باز): {book_new}\n"
            f"💬 گفتگوی باز: {chats_open}\n"
            f"🏪 کسب‌وکار در انتظار: {pend_biz}")


def do_who(arg):
    phone = db.norm_phone(_fa2en(arg).strip())
    if not phone:
        return "شماره را هم بفرست. مثلاً: کاربر 09123456789"
    c = db._one("SELECT * FROM customers WHERE phone=?", (phone,))
    if not c:
        return "مشتری با این شماره پیدا نشد."
    o = db._one("SELECT COUNT(*) c,COALESCE(SUM(total),0) s FROM orders WHERE customer_id=?", (c["id"],))
    b = db._one("SELECT COUNT(*) c FROM bookings WHERE customer_id=?", (c["id"],))
    t = db._one("SELECT COUNT(*) c FROM chat_threads WHERE customer_id=? AND status='open'", (c["id"],))
    m = db._one("SELECT COUNT(*) c FROM messenger_accounts WHERE customer_id=?", (c["id"],))
    status = "مسدود ⛔" if c["status"] == "blocked" else "فعال ✅"
    return ("👤 پروندهٔ مشتری\n"
            f"نام: {(c['name'] or '—')}\n"
            f"شماره: {c['phone']} · {status}\n"
            f"📦 سفارش: {o['c']} (مجموع {o['s']})\n"
            f"📅 نوبت: {b['c']} · 💬 گفتگوی باز: {t['c']} · 🔗 اتصال پیام‌رسان: {m['c']}")


def do_watch():
    alerts = _active_alerts()
    try:
        qn = len([f for f in os.listdir(queue_dir()) if f.endswith(".json")])
    except OSError:
        qn = 0
    return ("🛡 نگهبان\n"
            f"هشدار فعال: {('، '.join(alerts)) if alerts else 'نیست ✅'}\n"
            f"📥 صف اجرا: {qn}\n"
            f"💿 بکاپ: {g_backup()}\n"
            f"🔒 گواهی: {g_cert()} روز · 💾 دیسک: {g_disk()}\n"
            f"🤖 هوش: {'فعال ✅' if assistant.configured() else 'پیکربندی نشده'}\n"
            f"⚠️ خطای سرویس (۲۴h): {g_errcount()} · ⏱ {g_up()}")


_UNQUEUE_FA = {"بکاپ": "backup", "بکاپ‌گیری": "backup",
               "ریستارت": "restart", "ری‌استارت": "restart",
               "سخت‌سازی": "secharden", "سخت سازی": "secharden"}


def do_unqueue(arg):
    want = _UNQUEUE_FA.get(_fa2en(arg).strip()) or _fa2en(arg).strip().lower()
    if want not in ALLOWED_QUEUE_CMDS:
        return "فقط بکاپ و ریستارت و سخت‌سازی قابل لغون. مثلاً: حذف بکاپ"
    try:
        files = os.listdir(queue_dir())
    except OSError:
        files = []
    gone = 0
    for f in files:
        if f.startswith(want + "-") and f.endswith(".json"):
            try:
                os.remove(os.path.join(queue_dir(), f))
                gone += 1
            except OSError:
                pass
    fa = {"backup": "بکاپ", "restart": "ریستارت",
          "secharden": "سخت‌سازی"}.get(want, want)   # v287
    return f"«{fa}» از صف حذف شد ✅" if gone else f"چیزی از «{fa}» تو صف نیست."


def do_prices(arg):
    v = _fa2en(arg).strip().lower()
    if v in ("روشن", "on", "1"):
        db.set_setting("prices_enabled", "1")
        db._pagecache_drop()
        return "نمایش قیمت: روشن ✅"
    if v in ("خاموش", "off", "0"):
        db.set_setting("prices_enabled", "0")
        db._pagecache_drop()
        return "نمایش قیمت: خاموش ✅"
    return "بفرست: قیمت روشن (یا: قیمت خاموش)"


# ---------- weekly deep audit (v234: continuous review) ----------

def audit_snapshot_path():
    return os.environ.get("ADMINBOT_AUDIT") or os.path.join(db.DATA_DIR, "adminbot-audit.json")


_MNUM = {"Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6,
         "Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12}


def _week_traffic():
    """(hits, err5, days_seen) for the last 7 days across rotated nginx logs."""
    cutoff = datetime.date.today() - datetime.timedelta(days=7)
    hits, e5, seen = 0, 0, set()
    paths = sorted(glob.glob("/var/log/nginx/access.log*"))[:10]
    for p in paths:
        try:
            if p.endswith(".gz"):
                f = gzip.open(p, "rt", encoding="utf-8", errors="replace")
            else:
                f = open(p, encoding="utf-8", errors="replace")
        except OSError:
            continue
        try:
            for line in f:
                m = re.search(r"\[(\d{2})/(\w{3})/(\d{4})", line)
                if not m:
                    continue
                try:
                    day = datetime.date(int(m.group(3)), _MNUM.get(m.group(2), 0), int(m.group(1)))
                except ValueError:
                    continue
                if day < cutoff:
                    continue
                hits += 1
                seen.add(day.toordinal())
                parts = line.split()
                if len(parts) >= 9 and parts[8].startswith("5"):
                    e5 += 1
        finally:
            try:
                f.close()
            except Exception:
                pass
    return hits, e5, len(seen)


def _err_patterns():
    """Top-3 normalized service error patterns over 7 days + total count."""
    out = _run(["journalctl", "-u", "bazarche", "-p", "err", "--since",
                "7 days ago", "--no-pager", "-o", "cat"], timeout=20)
    groups = {}
    for line in out.splitlines():
        key = re.sub(r"\d+", "#", line.strip())[:90]
        if key:
            groups[key] = groups.get(key, 0) + 1
    top = sorted(groups.items(), key=lambda kv: -kv[1])[:3]
    return top, sum(groups.values())


def deep_audit_text():
    now = int(time.time())
    try:
        prev = json.load(open(audit_snapshot_path(), encoding="utf-8"))
        prev = prev if isinstance(prev, dict) else {}
    except (OSError, ValueError):
        prev = {}
    pct = _disk_pct()
    try:
        db_bytes = os.path.getsize(db.DB_PATH)
    except OSError:
        db_bytes = 0
    try:
        target = audit_snapshot_path()
        if os.path.dirname(target):
            os.makedirs(os.path.dirname(target), exist_ok=True)
        json.dump({"ts": now, "disk_pct": pct, "db_bytes": db_bytes},
                  open(target, "w", encoding="utf-8"))
    except OSError:
        pass
    disk_line = "؟"
    if pct is not None:
        disk_line = f"{pct}٪"
        if isinstance(prev.get("disk_pct"), int):
            dd = pct - prev["disk_pct"]
            disk_line += f" ({dd:+} نسبت به هفته پیش)" if dd else " (بدون تغییر)"
    db_line = _human(db_bytes)
    if db_bytes and isinstance(prev.get("db_bytes"), int) and prev["db_bytes"]:
        dg = db_bytes - prev["db_bytes"]
        db_line += f" ({dg / 1048576:+.1f}M)" if abs(dg) >= 104857 else " (بدون تغییر)"
    hits, e5, days = _week_traffic()
    top, err_total = _err_patterns()
    ssh = _run(["journalctl", "-u", "ssh", "--since", "7 days ago",
                "--no-pager", "-o", "cat"], timeout=20)
    fails = sum(1 for l in ssh.splitlines() if "Failed" in l) if ssh else 0
    oks = sum(1 for l in _tail(OFFSITE_LOG, 300, 60).splitlines() if l.strip().startswith("OK:"))
    cert = g_cert()
    sug = []
    if pct is not None and pct >= 85:
        sug.append("دیسک بحرانی است؛ لاگ/بکاپ قدیمی پاک شود")
    if e5:
        sug.append(f"{e5} خطای 5xx در هفته؛ لاگ nginx بررسی شود")
    if err_total:
        sug.append(f"{err_total} خطای سرویس در هفته")
    if fails > 50:
        sug.append(f"{fails} تلاش ناموفق SSH؛ زیر نظر باشد")
    if cert.isdigit() and int(cert) < 14:
        sug.append(f"گواهی فقط {cert} روز مانده؛ تمدید شود")
    if isinstance(prev.get("db_bytes"), int) and prev["db_bytes"] and db_bytes > prev["db_bytes"] * 1.5:
        sug.append("رشد سریع دیتابیس نسبت به هفته پیش")
    if not sug:
        sug.append("همه‌چیز عادی است ✅")
    lines = [f"🩺 بررسی هفتگی دستگیر ({fa_today()})",
             f"📈 ترافیک ۷ روز: {hits} بازدید · خطای 5xx: {e5}",
             f"💾 دیسک: {disk_line} · 🗄 دیتابیس: {db_line}",
             f"💿 بکاپ موفق (لاگ فعلی): {oks} · 🔒 گواهی: {cert} روز",
             f"⚠️ خطای سرویس: {err_total} · 🛡 SSH ناموفق: {fails}"]
    for pat, cnt in top:
        lines.append(f"• {cnt}× {pat[:80]}")
    lines.append("💡 پیشنهاد: " + "؛ ".join(sug))
    return "\n".join(lines)[:3500]


def run_weekly_audit():
    """Root-cron entry: send the deep audit to the owner team. Never raises."""
    try:
        if not (token() and owner_chat()):
            return False
        ok = True
        for cid in owner_chats():
            ok = bool(send_message(cid, deep_audit_text())) and ok
        return ok
    except Exception as e:
        print("adminbot weekly audit error:", e, flush=True)
        return False


# ---------- privileged queue + restart confirm ----------

def queue_write(cmd):
    if cmd not in ALLOWED_QUEUE_CMDS:
        return False
    try:
        os.makedirs(queue_dir(), exist_ok=True)
        name = f"{cmd}-{int(time.time())}-{random.randrange(1000, 9999)}.json"
        with open(os.path.join(queue_dir(), name), "w", encoding="utf-8") as f:
            json.dump({"cmd": cmd, "ts": int(time.time())}, f)
        return True
    except OSError:
        return False


def _pending_read():
    try:
        with open(pending_path(), encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _pending_write(exp, action="restart", target=""):
    try:
        with open(pending_path(), "w", encoding="utf-8") as f:
            json.dump({"exp": exp, "action": action, "target": target}, f)
    except OSError:
        pass


def _pending_clear():
    try:
        os.remove(pending_path())
    except OSError:
        pass


def _cmd_of(text):
    w = (text or "").strip().split()
    return w[0].split("@")[0] if w else ""


_FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")


def _fa2en(text):
    return str(text or "").translate(_FA_DIGITS)


def _norm_id(arg):
    try:
        v = int(_fa2en(arg).strip())
        return v if v > 0 else None
    except (TypeError, ValueError):
        return None


def _rest(text):
    parts = str(text or "").strip().split(None, 1)
    return parts[1].strip() if len(parts) > 1 else ""


_SNAP_SECRET_RX = ("token", "secret", "pass", "key", "salt", "hash")


def _do_ai_tool(target):
    """v239: run the owner-confirmed content tool. The pending target is a
    JSON {"tool","args"} proposal; it is re-parsed (strict allow-list) and
    re-prechecked against the live DB before anything is written, so a
    stale/replayed/corrupted pending file can never mutate content."""
    try:
        d = json.loads(target or "{}")
        tool, args = d.get("name"), d.get("args")
    except (ValueError, AttributeError):
        return "⚠️ درخواست ناخوانا بود؛ دوباره بگو.", None
    if not isinstance(tool, str) or not isinstance(args, dict):
        return "⚠️ درخواست معتبر نبود؛ دوباره بگو.", None
    name, args = CT.parse_tool_call({"name": tool, "args": args})
    if not name:
        return "⚠️ درخواست معتبر نبود؛ دوباره بگو.", None
    ok, why = CT.tool_precheck(name, args)
    if not ok:
        return "⚠️ " + CT.fail_text(name, why), None
    ok, msg = CT.tool_execute(name, args)
    return (msg if ok else "⚠️ " + msg), None


def _do_agent_confirm(target):
    """v297: تایید اجرای ابزار ایجنت با گزارش کامل + ذخیره rollback + /stop"""
    try:
        d = json.loads(target or "{}")
        # support both old {name,args} and new {name,args,report,snapshot}
        tool = d.get("name") or d.get("tool")
        args = d.get("args") or {}
        snapshot = d.get("snapshot")
        report = d.get("report") or ""
        if not tool:
            # try old format where target itself is {name,args}
            tool = d.get("name")
            args = d.get("args") or {}
        if not tool:
            return "⚠️ درخواست نامعتبر — دوباره بفرست.", None
        # re-parse + re-precheck
        name, args2 = CT.parse_tool_call({"name": tool, "args": args})
        if not name:
            return "⚠️ درخواست معتبر نبود؛ دوباره بگو.", None
        ok, why = CT.tool_precheck(name, args2)
        if not ok:
            _pending_clear()
            return "⚠️ " + CT.fail_text(name, why), None
        # save rollback snapshot before execute
        if snapshot:
            try:
                CT._save_rollback(snapshot)
            except Exception:
                pass
        # execute
        ok, msg = CT.tool_execute(name, args2)
        if ok:
            # save last action for /stop
            try:
                CT._save_last_action(name, args2, msg)
            except Exception:
                pass
            _pending_clear()
            return (f"✅ اجرا شد:\n{msg}\n\nبرای بازگشت فوری: /stop"), None
        else:
            _pending_clear()
            return "⚠️ " + msg, None
    except Exception as e:
        _pending_clear()
        return f"⚠️ خطا در تایید: {e}", None


def _do_agent_cancel():
    """v297: لغو اقدام ایجنت"""
    _pending_clear()
    return "❌ اقدام لغو شد — هیچ تغییری اعمال نشد ✅", None


def _do_agent_stop():
    """v297: توقف فوری + بازگشت به حالت قبل — هم محتوا هم کد"""
    pend = _pending_read()
    if pend.get("action") == "agent_confirm":
        _pending_clear()
        return "⏹ اقدام در انتظار لغو شد — هیچ تغییری اعمال نشد ✅", None
    # try rollback last action
    try:
        import os, json as _js, glob as _glob
        # 1) محتوا: agent-rollback.json
        rb_path = os.path.join(db.DATA_DIR, "agent-rollback.json")
        if os.path.isfile(rb_path):
            data = _js.load(open(rb_path, encoding="utf-8"))
            snap = data.get("snapshot")
            if snap:
                ok, msg = CT.tool_rollback(snap)
                try:
                    os.remove(rb_path)
                except Exception:
                    pass
                if ok:
                    return f"⏹ متوقف شد و به حالت قبل برگشت:\n{msg} ✅", None
                else:
                    return f"⏹ توقف انجام شد ولی بازگشت کامل نشد:\n{msg}\n\n«تشخیص» را بفرست.", None
        # 2) کد: لغو jobهای در صف + revert آخرین بکاپ
        jobs_dir = os.path.join(db.DATA_DIR, "code-jobs")
        cancelled = 0
        try:
            for jf in _glob.glob(os.path.join(jobs_dir, "*.json")):
                try:
                    os.remove(jf)
                    cancelled += 1
                except Exception:
                    pass
        except Exception:
            pass
        if cancelled:
            return f"⏹ {cancelled} تغییر کد در صف لغو شد — هیچ‌کدام اعمال نشد ✅", None
        # 3) آخرین کد اعمال‌شده را برگردان (اگر بکاپ هست)
        try:
            import server.adminbot_code as _CODE
            # newest backup
            bk_idx = os.path.join(db.DATA_DIR, "code-backups", "index.json")
            if os.path.isfile(bk_idx):
                idx = _js.load(open(bk_idx, encoding="utf-8"))
                if idx:
                    last = sorted(idx, key=lambda x: x.get("ts",0), reverse=True)[0]
                    path = last.get("path")
                    if path:
                        ok, msg = _CODE.execute("code_revert", {"path": path})
                        if ok:
                            return f"⏹ آخرین تغییر کد برگشت داده شد:\n{msg} ✅", None
        except Exception:
            pass
        return "⏹ هیچ اقدام در انتظاری نبود و بازگشتی در دسترس نیست. «تشخیص» را بفرست تا وضعیت را ببینی.", None
    except Exception as e:
        return f"⚠️ خطا در توقف: {e}", None



def _do_appear_reset():
    """v265: owner-confirmed factory reset of the whole site appearance —
    the same 9 keys the panel reset covers (colors, logo, hero texts)."""
    try:
        db.set_settings({k: db.DEFAULT_SETTINGS[k] for k in
                         ("color_primary", "color_accent", "color_background",
                          "color_foreground", "hero_title", "hero_lead",
                          "hero_cta", "footer_note", "site_logo")})
        db.log("admin_ai_tool", "appearance reset to defaults")
        return ("✨ ظاهر سایت به پیش‌فرض برگشت ✅\n"
                "(رنگ‌ها، لوگو، متن‌های صفحهٔ اصلی)", None)
    except Exception:
        return "⚠️ نشد؛ «تشخیص» را بفرست تا علت را ببینیم.", None


def _do_agent_key(ip=""):
    """v300: پنل ایجنت کاملاً خصوصی — کلید فقط از ربات بله مدیر"""
    try:
        token, exp = db.agent_key_new(ip=ip, ttl=3600)
        base = (db.get_settings().get("site_url") or "").strip().rstrip("/")
        # link with token
        link = (base + f"/panel/agent?ak={token}") if base else f"/panel/agent?ak={token}"
        # also hidden path aware
        hidden = db.get_settings().get("panel_hidden_path") or ""
        if hidden:
            # if hidden, the agent panel is under hidden too
            link_hidden = (base + f"/{hidden}/agent?ak={token}") if base else f"/{hidden}/agent?ak={token}"
        else:
            link_hidden = link
        exp_str = time.strftime("%H:%M:%S", time.localtime(exp))
        L = [
            "🔐 پنل ایجنت — دسترسی آزاد و کامل",
            "",
            f"لینک خصوصی (۱ ساعت اعتبار، یک‌بارمصرف برای ست کردن کوکی):",
            link_hidden,
            "",
            f"انقضا: {exp_str} — پس از باز کردن، کوکی ۷ روزه می‌ماند.",
            "",
            "این پنل:",
            "• زنده همه‌چیز می‌بینی (صف ایجنت، لاگ، سلامت، بکاپ، سئو، چت‌ها)",
            "• هر ابزار را می‌تونی اجرا یا به صف دسته‌ای اضافه کنی",
            "• با یک دستور «اعمال همه» تمام تغییرات روی سایت اصلی می‌ره",
            "• استفاده نامحدود و شخصی — سهمیه هوش را دور می‌زنه (فقط تو)",
            "• کاملاً خصوصی — کلید فقط همین‌جا داده می‌شه، لاگ نمی‌شه",
            "",
            "برای ساخت کلید تازه: /agent یا ایجنت"
        ]
        db.log("agent_key", f"new key issued ip={ip}")
        return "\n".join(L), None
    except Exception as e:
        return f"⚠️ خطا در ساخت کلید ایجنت: {e}", None


def _do_login_keys():
    """v267: the owner's own panel login — served directly (no model,
    no lecture). Owner order: «دسترسی تمام» — asking for your own login
    key in your own admin chat is answered, never refused."""
    try:
        tok = db.owner_token()
    except Exception:
        tok = ""
    if not tok:
        return "⚠️ توکن ورود ساخته نشده؛ «تشخیص» را بفرست تا علت را ببینیم.", None
    try:
        base = (db.get_settings().get("site_url") or "").strip().rstrip("/")
    except Exception:
        base = ""
    url = (base + "/panel?key=" + tok) if base else ("/panel?key=" + tok)
    try:
        has_pw = db.owner_pass_set()
    except Exception:
        has_pw = False
    L = ["🔑 ورود به پنل:", url, ""]
    if has_pw:
        L.append("رمز پنل: تعیین شده ✅ — بعد از باز کردن نشانی، رمزت را هم می‌زنی.")
        L.append("اگر رمز را فراموش کردی، بفرست: بله — تا رمز تازه بسازم و همین‌جا نشان بدهم.")
    else:
        L.append("رمز پنل: نداری — همین نشانی برای ورود کافی است ✅")
        L.append("اگر رمز می‌خواهی، بفرست: بله — تا بسازم و همین‌جا نشان بدهم.")
    if not base:
        L.append("(دامنهٔ سایت در تنظیمات خالی است؛ اول نشانی بالا دامنه را بگذار.)")
    _pending_write(time.time() + 120, "login_pass", "")
    return "\n".join(L), None


def _do_login_pass_reset():
    """v267: owner-confirmed panel password (re)creation — generated here,
    hash-stored, shown once in the owner's own admin chat."""
    import secrets as _sec
    try:
        pw = _sec.token_urlsafe(12)
        db.set_owner_pass(pw)
        db.log("admin_ai_tool", "panel password (re)created from admin chat")
        return ("🔑 رمز تازهٔ پنل:\n" + pw +
                "\n\nهمین‌جا نگهش دار — دوباره نشان داده نمی‌شود.", None)
    except Exception:
        return "⚠️ نشد؛ «تشخیص» را بفرست تا علت را ببینیم.", None


def admin_snapshot():
    """Live read-only site picture for the admin copilot. Never raises;
    secret-ish settings are dropped entirely (the model must never see them)."""
    try:
        t = g_traffic()
        traffic = f"{t[0]} بازدید · {t[1]} آی‌پی یکتا · {t[2]} خطای 5xx" if t else "لاگ خوانده نشد"
    except Exception:
        traffic = "؟"
    try:
        b, bn, bt, c, cw, bz, it, m, q = g_db()
        dbline = (f"{b} نوبت ({bn} جدید) · {c} مشتری ({cw} این هفته) · {bz} کسب‌وکار · "
                  f"{it} آیتم · {m} پیام خوانده‌نشده · {q} استعلام جدید")
    except Exception:
        dbline = "؟"
    try:
        pend = db._rows("SELECT id,name,phone FROM businesses WHERE status='pending' ORDER BY id DESC LIMIT 5")
        pend_n = db._one("SELECT COUNT(*) c FROM businesses WHERE status='pending'")["c"]
        rev_n = db._one("SELECT COUNT(*) c FROM reviews WHERE status='pending'")["c"]
        clm_n = db._one("SELECT COUNT(*) c FROM claims WHERE status='pending'")["c"]
        tix_n = db._one("SELECT COUNT(*) c FROM tickets WHERE status='open'")["c"]
        inq_n = db._one("SELECT COUNT(*) c FROM inquiries WHERE status='new'")["c"]
    except Exception:
        pend, pend_n, rev_n, clm_n, tix_n, inq_n = [], "؟", "؟", "؟", "؟", "؟"
    try:
        recent = db._rows("SELECT o.id,o.total,o.status,b.name biz FROM orders o "
                          "JOIN businesses b ON b.id=o.biz_id ORDER BY o.id DESC LIMIT 5")
        cust24 = db._one("SELECT COUNT(*) c FROM customers WHERE created>=datetime('now','-1 day')")["c"]
        ord24 = db._one("SELECT COUNT(*) c FROM orders WHERE created>=datetime('now','-1 day')")["c"]
    except Exception:
        recent, cust24, ord24 = [], "؟", "؟"
    try:
        ops = {k: v for k, v in (db.get_settings() or {}).items()
               if not any(s in k.lower() for s in _SNAP_SECRET_RX)}
        first = {"site_name", "prices_enabled", "order_cancel_minutes", "panel_allow_ips"}
        ordered = sorted(ops.items(), key=lambda kv: (kv[0] not in first, kv[0]))
        opsline = " · ".join(f"{k}={v}" for k, v in ordered)[:600] or "—"
    except Exception:
        opsline = "؟"
    alerts = _active_alerts()
    lines = [
        f"نسخه {g_ver()} · سرویس {g_svc()} · آپتایم {g_up()} · دیسک {g_disk()}",
        f"بکاپ: {g_backup()} · گواهی: {g_cert()} روز · دیتابیس: {g_dbsize()}",
        f"ترافیک امروز: {traffic} · خطای سرویس ۲۴h: {g_errcount()}",
        f"دیتابیس: {dbline}",
        f"هشدار: {('، '.join(alerts)) if alerts else 'نیست'}",
        f"صف تأیید: {pend_n} کسب‌وکار · {rev_n} نظر · {clm_n} تصاحب · {tix_n} تیکت باز · {inq_n} استعلام",
    ]
    if pend:
        lines.append("در انتظار: " + " · ".join(f"#{r['id']} {r['name']}" for r in pend))
    if recent:
        lines.append("سفارش اخیر: " + " · ".join(f"#{r['id']} {(r['biz'] or '')[:20]} {r['total']} ({r['status']})" for r in recent))
    lines.append(f"۲۴ ساعت: {cust24} مشتری تازه · {ord24} سفارش تازه")
    lines.append("تنظیمات: " + opsline)
    # v239: editable content inventory so the model grounds its proposals
    lines.append(CT.content_inventory())
    # v241: the file the model last read, so its code_edit quotes real text
    try:
        lines.append(CT.CODE.code_context())
    except Exception:
        pass
    return "\n".join(lines)[:7000]


def memory_path():
    return os.environ.get("ADMINBOT_MEMORY") or "/tmp/dastgir-admin-memory.json"


def _memory_load(max_age=1800, limit=6):
    try:
        with open(memory_path(), encoding="utf-8") as f:
            items = json.load(f)
        now = time.time()
        return [m for m in items if isinstance(m, dict) and now - float(m.get("ts", 0)) < max_age][-limit:]
    except (OSError, ValueError, TypeError):
        return []


def _memory_save(q, a, limit=6):
    items = _memory_load(limit=limit - 1) + [{"q": str(q or "")[:400], "a": str(a or "")[:600], "ts": time.time()}]
    try:
        with open(memory_path(), "w", encoding="utf-8") as f:
            json.dump(items[-limit:], f, ensure_ascii=False)
    except OSError:
        pass


# v266: kira_ هرگز در چت/حافظه لو نمی‌رود.
_REDACT_RX = re.compile(r"(AIza[A-Za-z0-9_\-]{16,}|gsk_[A-Za-z0-9]{16,}|sk-[A-Za-z0-9_\-]{16,}|aa-[A-Za-z0-9]{16,}|kira_[A-Za-z0-9]{16,})")


# ── v287: «امنیت» — گزارش واقعی امنیت با عدد و دلیل، و «سخت‌سازی» ─────────
# بات www-data است (NoNewPrivileges در bazarche.service)؛ نه می‌تواند و نه
# باید sshd را مستقیم دست بزند. کار بات: هرچه خواندنی است جمع کند و با دلیل
# قضاوت کند؛ درمان واقعی از مسیر ریشه می‌رود — صف codeguard.sh (job=secharden)
# که با «سخت‌سازی» + «بله» فعال می‌شود: نصب/تنظیم/فعال‌سازی fail2ban +
# مسدودسازی مهاجمانی که همین گزارش پیدا کرده. رسید نتیجه:
# data/sec-harden-result.txt (codeguard می‌نویسد؛ بات اینجا می‌خواند).

SEC_HARDEN_RESULT = os.path.join(db.DATA_DIR, "sec-harden-result.txt")


def _sec_sshd_config():
    """تنظیمات از فایل‌های sshd. بدون ریشه sshd -T ممکن نیست — صادقانه همان
    فایل را می‌خوانیم (Include های sshd_config.d هم ضمناً)."""
    cfg = ""
    try:
        with open("/etc/ssh/sshd_config", encoding="utf-8",
                  errors="replace") as f:
            cfg = f.read()
    except OSError:
        return None
    for p in sorted(glob.glob("/etc/ssh/sshd_config.d/*.conf")):
        try:
            with open(p, encoding="utf-8", errors="replace") as f:
                cfg += "\n" + f.read()
        except OSError:
            pass
    out = {}
    for key, default in (("Port", "22"), ("PasswordAuthentication", "yes"),
                         ("PermitRootLogin", "prohibit-password"),
                         ("MaxAuthTries", "6")):
        hits = re.findall(r"(?mi)^\s*" + key + r"\s+(\S+)", cfg)
        out[key] = hits[-1] if hits else default
    return out


def do_sec():
    import collections
    L = ["🛡️ گزارش امنیت سرور و سایت — " + fa_today()]
    R = []            # «نتیجه و دلیل» — هر قضاوت با مدرک خودش
    # ۱) SSH: حملهٔ رمزکشا + ورودهای موفق (journald)
    try:
        j = _run(["journalctl", "-u", "ssh", "-u", "sshd", "--since",
                  "24 hours ago", "--no-pager", "-q"], timeout=12)
    except Exception:
        j = ""
    lines = [ln for ln in j.splitlines() if "Failed" in ln or "Accepted" in ln]
    if lines:
        fail_ips, ok_ips = [], []
        for ln in lines:
            m = re.search(r"from (\d{1,3}(?:\.\d{1,3}){3})", ln)
            ip = m.group(1) if m else ""
            if "Failed" in ln:
                fail_ips.append(ip)
            elif "Accepted" in ln:
                ok_ips.append(ip)
        fails, oks = len(fail_ips), len(ok_ips)
        top = ["%s (%s بار)" % (ip, n) for ip, n in
               collections.Counter([i for i in fail_ips if i]).most_common(5)]
        uniq_ok = sorted(set(ok_ips), key=ok_ips.count, reverse=True)[:5]
        st = ("✅ آرام" if fails < 20 else
              "⚠️ زیر حمله" if fails < 500 else "🔴 سنگین")
        L.append("۱) SSH (۲۴ ساعت): %s تلاش ناموفق · %s" % (fails, st))
        if top:
            L.append("   مهاجم اصلی: " + "، ".join(top))
        L.append("   ورود موفق: %s" % oks +
                 ((" از: " + "، ".join(uniq_ok)) if uniq_ok else ""))
        if fails >= 500:
            R.append("حملهٔ سنگین رمزکشا روی SSH در جریان است: %s تلاش ناموفق "
                     "در ۲۴ ساعت. تا fail2ban فعال نباشد مهاجم بی‌هزینه ادامه "
                     "می‌دهد و هر رمز ضعیف بالاخره حدس زده می‌شود ⇒ «سخت‌سازی» "
                     "را بفرست (fail2ban + مسدودسازی همین مهاجمان)." % fails)
        elif fails >= 20:
            R.append("تلاش ناموفق SSH دیده می‌شود (%s بار در ۲۴ ساعت) — هنوز "
                     "سنگین نیست، ولی fail2ban از همین امروز جلوی رشدش را "
                     "می‌گیرد." % fails)
        else:
            R.append("SSH آرام است (%s تلاش ناموفق در ۲۴ ساعت) — همین وضعیت "
                     "نگه داشته شود." % fails)
        if oks and fails >= 500:
            R.append("در همان بازهٔ حمله %s ورود موفق ثبت شده — IPهای بالا را "
                     "چک کن که مال خودت باشند؛ اگر ناشناس دیدی فوراً رمز را "
                     "عوض کن (لایهٔ ۲ راهنما: ورود فقط با کلید)." % oks)
    else:
        L.append("۱) SSH: ژورنال sshd در این محیط خوانده نشد — بدون گزارش "
                 "(حدس نمی‌زنم)")
        R.append("ژورنال ssh در دسترس این فرآیند نیست؛ شدت حمله قابل "
                 "اندازه‌گیری نیست. روی سرور: journalctl -u ssh --since "
                 "'24 hours ago' | grep -c Failed")
    # ۲) fail2ban — نصب/فعال + رسید آخرین سخت‌سازی
    hardened = os.path.exists(SEC_HARDEN_RESULT)
    f2b_out = ""
    for exe in ("fail2ban-client",):
        f2b_out = _run([exe, "status", "sshd"], timeout=8)
    if "Status for the jail: sshd" in f2b_out:
        tb = re.search(r"Total banned:\s*(\d+)", f2b_out)
        bl = re.search(r"Banned IP list:\s*(\S.*)", f2b_out)
        L.append("۲) fail2ban: ✅ jail فعال" +
                 (" · مسدود: %s" % tb.group(1) if tb else "") +
                 ((" · " + bl.group(1).strip()[:90])
                  if bl and bl.group(1).strip() else ""))
        R.append("fail2ban فعال است و مهاجمان را خودش مسدود می‌کند — لایهٔ ۱ "
                 "برقرار است")
    elif _run(["fail2ban-client", "--version"], timeout=5):
        L.append("۲) fail2ban: نصب است، ولی وضعیت jail با دسترسی بات خوانده "
                 "نشد (سوکت ریشه می‌خواهد)")
        R.append("fail2ban نصب است ولی فعال بودن jail sshd از اینجا تأیید نشد "
                 "— روی سرور: sudo fail2ban-client status sshd")
    else:
        L.append("۲) fail2ban: ❌ نصب نیست" +
                 (" (رسید سخت‌سازی قبلی موجود است)" if hardened else ""))
        if not hardened:
            R.append("بدون fail2ban هیچ چیز جلوی ربات‌های رمزکشا را نمی‌گیرد؛ "
                     "هر IP می‌تواند روزها پشت سر هم تلاش کند ⇒ «سخت‌سازی» را "
                     "بفرست تا codeguard (ریشه) نصب و فعال و مهاجمان فعلی را "
                     "مسدود کند")
    if hardened:
        try:
            with open(SEC_HARDEN_RESULT, encoding="utf-8",
                      errors="replace") as f:
                tail = [ln for ln in f.read().splitlines() if ln.strip()][-12:]
            L.append("   رسید آخرین سخت‌سازی:\n   " + "\n   ".join(tail))
        except OSError:
            pass
    # ۳) تنظیمات sshd (از فایل — صادقانه، نه ادعا)
    cfg = _sec_sshd_config()
    if cfg:
        L.append("۳) sshd (از فایل تنظیمات): پورت %s · PasswordAuthentication"
                 " %s · PermitRootLogin %s · MaxAuthTries %s"
                 % (cfg["Port"], cfg["PasswordAuthentication"],
                    cfg["PermitRootLogin"], cfg["MaxAuthTries"]))
        if cfg["PasswordAuthentication"].lower() == "yes":
            R.append("ورود با رمز هنوز باز است (PasswordAuthentication yes) — "
                     "بعد از اطمینان از کار کلید SSH خودت، لایهٔ ۲ راهنما را "
                     "دستی اجرا کن؛ بات این را خودکار خاموش نمی‌کند چون اگر "
                     "کلیدت کار نکند از سرور بیرون می‌مانی")
        if cfg["PermitRootLogin"].lower() == "yes":
            R.append("ورود مستقیم root با رمز مجاز است — خطرناک‌ترین تنظیم "
                     "ممکن؛ لایهٔ ۲ راهنما: PermitRootLogin prohibit-password")
    else:
        L.append("۳) sshd: فایل تنظیمات خوانده نشد")
    # ۴) فایروال + پورت‌های گوش‌دهنده
    ufw = _run(["ufw", "status"], timeout=6)
    if ufw and not ufw.lower().startswith(("error", "could not", "permission")):
        L.append("۴) فایروال: " + ufw.splitlines()[0])
    else:
        L.append("۴) فایروال: وضعیت با دسترسی بات خوانده نشد (نیاز به ریشه)")
    ss = _run(["ss", "-ltn"], timeout=6)
    if ss:
        ports = sorted({m.group(1) for m in re.finditer(
            r"(?:0\.0\.0\.0|\[?::\]?|\*):(\d+)\s", ss)}, key=int)
        if ports:
            L.append("   پورت‌های گوش‌دهنده: " + "، ".join(ports))
            odd = [p for p in ports if p not in
                   ("22", "80", "443", "8000", "8080")]
            if odd:
                R.append("پورت‌های غیرمنتظره روی همهٔ اینترفیس‌ها باز است: %s "
                         "— اگر کاربردشان را نمی‌شناسی بررسی کن"
                         % "، ".join(odd))
    # ۵) دفاع لایهٔ وب (سپر + ضداسپم + پنل) — همین فرآیند، آمار زنده
    try:
        import shield
        rep = shield.report()
        stats = rep.get("stats") or {}
        blocked = rep.get("blocked") or []
        L.append("۵) سپر سایت: %s درخواست · %s محدود · %s اسکن · %s مسدود · "
                 "%s IP مسدودِ فعال"
                 % (stats.get("total", 0), stats.get("throttled", 0),
                    stats.get("scan", 0), stats.get("blocks", 0),
                    len(blocked)))
        if blocked:
            sample = "، ".join(b[0] for b in blocked[:5])
            L.append("   نمونهٔ مسدودهای فعال: " + sample)
        if stats.get("blocks", 0) or blocked:
            R.append("سپر سایت زنده و در حال کار است: %s برخورد مسدودسازی و "
                     "%s IP فعلاً مسدود — لایهٔ وب سالم است"
                     % (stats.get("blocks", 0), len(blocked)))
        else:
            R.append("سپر سایت فعال است ولی هنوز برخوردی ثبت نشده — یا ترافیک "
                     "تمیز است یا مهاجم هنوز به لایهٔ وب نرسیده")
    except Exception:
        L.append("۵) سپر سایت: خوانده نشد")
    try:
        import antispam
        asp = antispam.stats_today()
        L.append("   ضداسپم (امروز): %s رویداد · %s رد"
                 % (asp.get("total", 0), asp.get("denies", 0)))
    except Exception:
        pass
    try:
        pw_set = str(db.get_setting("owner_pass_set") or "")
        allow = str(db.get_setting("panel_allow_ips") or "").strip()
        L.append("   پنل: رمز ورود %s" % ("✅ دارد" if pw_set else "❌ ندارد") +
                 (" · IP مجاز: " + allow[:60] if allow else " · بدون محدودیت IP"))
        if not pw_set:
            R.append("ورود پنل رمز ندارد — هر کس نشانی کلید را پیدا کند وارد "
                     "می‌شود ⇒ «کلید ورود» را بفرست و رمز بگذار")
    except Exception:
        pass
    # نتیجه و دلیل
    L.append("🔎 نتیجه و دلیل:")
    for i, r in enumerate(R, 1):
        L.append("%s) %s" % (i, r))
    L.append("عملیات: «سخت‌سازی» = نصب/فعال‌سازی fail2ban + مسدودسازی "
             "مهاجمان فعلی، توسط codeguard با دسترسی ریشه (با «بله» تأیید "
             "می‌شود و رسیدش همین‌جا قابل خواندن است). لایه‌های ۲ و ۳ دستی: "
             "SSH-HARDENING-fa.md")
    return "\n".join(L)


def _redact(s):
    """API keys never appear in replies or memory, whoever pastes them."""
    return _REDACT_RX.sub("···(کلید مخفی شد)···", str(s or ""))


_BRAIN_WORDS = {"opus", "اپوس", "sonnet", "سونت", "سانت", "haiku", "هایکو",
                "هايکو", "openrouter", "open", "اوپن", "اوپنروتر",
                "اوپن‌روتر",
                "glm", "جی‌ال‌ام"}   # v273: کیرا حذف شد؛ مغز پنجم GLM

# v264: exact full-text taps from BRAIN_KEYBOARD (fa2en-normalized).
_BRAIN_TAPS = frozenset({
    "اپوس 5", "سونت 5", "سانت 5", "هایکو 4.5", "هايکو 4.5",
    "اوپنروتر", "اوپن روتر", "اوپن‌روتر",
    "اوپن‌روتر (رایگان)",
    # v273 (دستور مدیر: کیرا کلا حذف شد): مغز پنجم = GLM 5.3 Flash.
    "GLM 5.3", "glm", "جی‌ال‌ام",
})


def _is_brain_cmd(cmd, rest):
    """v263: «/مغز …» همیشه دستور است؛ «مغز» لخت فقط وقتی دستور است که
    تنها باشد (وضعیت) یا نام مغز دنبالش باشد — وگرنه چت آزاد است
    («مغز بات را عوض کن» باید به دستیار برسد، نه خطای نام مغز)."""
    if cmd == "/مغز":
        return True
    if not (rest or "").strip():
        return True
    return rest.strip().split()[0].lower() in _BRAIN_WORDS


def do_glmmodels(raw):
    """v268→v273: /مدل — switch the 5th brain's (GLM) model. All 5 were live-tested
    ۲۰۲۶-۱۱-۱۱ (41/41 probed, free pool); bare = menu, number/id = live-test
    the target first, then switch."""
    import assistant as _AI
    try:
        cur = ((db.get_settings().get("ai_brain_glm_model")
                or db.get_settings().get("ai_brain_kira_model") or "").strip()
               or _AI.GLM_MODELS[0])
    except Exception:
        cur = _AI.GLM_MODELS[0]
    if not (raw or "").strip():
        L = ["🧠 مدل‌های مغز پنجم (GLM روی AvalAI — v273):"]
        for _i, _m in enumerate(_AI.GLM_MODELS, 1):
            L.append((("● " if _m == cur else "○ ") + f"{_i}. {_m}" +
                      (" — فعلی ✅" if _m == cur else "")))
        L.append("")
        L.append("سوئیچ: بنویس: /مدل 2  (یا شناسهٔ کامل)")
        L.append("مدل تازه اول تست زنده می‌شود؛ اگر جواب نداد عوض نمی‌شود.")
        return "\n".join(L), None
    w = (raw or "").strip().split()[0]
    mid = None
    if w.isdigit() and 1 <= int(w) <= len(_AI.GLM_MODELS):
        mid = _AI.GLM_MODELS[int(w) - 1]
    elif w in _AI.GLM_MODELS:
        mid = w
    if not mid:
        return ("عدد مدل درست نیست. /مدل را لخت بفرست تا فهرست را ببینی.", None)
    if mid == cur:
        return ("همین الان فعال است: " + mid + " ✅", None)
    import urllib.error as _ue
    base = _AI.BRAINS["glm"][0]
    key = (os.environ.get(_AI.BRAINS["glm"][1]) or "").strip()   # v273
    if not key:
        return ("کلید GLM وصل نیست؛ اول: /کلید glm <کلید>", None)
    try:
        _AI._chat(base, key, mid, [{"role": "user", "content": "ping"}], 30, 5)
    except _ue.HTTPError as e:
        return (f"⚠️ مدل {mid} جواب نداد (خطای {e.code})؛ عوض نشد — مدل قبلی سر جایش است.", None)
    except Exception:
        return (f"⚠️ مدل {mid} جواب نداد (خطای شبکه)؛ عوض نشد.", None)
    try:
        db.set_settings({"ai_brain_glm_model": mid})
    except Exception:
        return "⚠️ نشد؛ «تشخیص» را بفرست تا علت را ببینیم.", None
    return ("🧠 مدل GLM شد: " + mid + " ✅", None)


def do_sitemodel(raw):
    """v269 (دستور مدیر: هوش سایت کاملاً جدا از محیط مدیر): «مدل سایت» —
    سوئیچ مدل هوش عمومی سایت (اسلات AI_SITE_*). اول تست زنده؛ اگر جواب
    نداد، مدل قبلی سر جایش می‌ماند. هیچ ربطی به /مغز و /مدل (GLM) ندارد."""
    import assistant as _AI
    try:
        cur = ((db.get_settings().get("ai_site_model") or "").strip()
               or (os.environ.get("AI_SITE_MODEL") or "").strip()
               or _AI.SITE_DEFAULT_MODEL)
    except Exception:
        cur = _AI.SITE_DEFAULT_MODEL
    if not (raw or "").strip():
        c = _AI.site_config()
        host = (c.get("base_url") or "").split("//")[-1].split("/")[0]
        has = "✅" if c.get("api_key") else "❌ (کلیدی وصل نیست — /کلید سایت)"
        return ("🌐 هوش عمومی سایت (جدا از مغزهای شما):\n"
                f"مدل فعلی: {cur} @ {host} — کلید {has}\n\n"
                "سوئیچ: دکمهٔ مدل را بزن یا بنویس: مدل سایت <شناسهٔ مدل>\n"
                "(اول تست زنده می‌شود؛ جواب ندهد عوض نمی‌شود)\n"
                "نصب/تعویض کلید: /کلید سایت <کلید> [مدل]"), SITE_KEYBOARD   # v271
    w = (raw or "").strip().split()[0]
    if not CT.CODE._MODEL_RX.match(w):
        return ("شناسهٔ مدل معتبر نیست؛ مثال: مدل سایت glm-5.3-flash", None)
    if w == cur:
        return ("همین الان مدل سایت است: " + w + " ✅", None)
    import urllib.error as _ue
    c = _AI.site_config()
    if not c.get("api_key"):
        return ("کلید هوش سایت وصل نیست؛ اول: /کلید سایت <کلید>", None)
    try:
        _AI._chat(c["base_url"], c["api_key"], w,
                  [{"role": "user", "content": "ping"}], 30, 5)
    except _ue.HTTPError as e:
        _hint = " (۴۰۴ = این شناسه در سرویس نیست؛ شناسهٔ مستند را بفرست)" \
            if e.code == 404 else ""
        return (f"⚠️ مدل {w} جواب نداد (خطای {e.code})؛ عوض نشد — "
                "مدل قبلی سر جایش است." + _hint, None)
    except Exception:
        return (f"⚠️ مدل {w} جواب نداد (خطای شبکه)؛ عوض نشد.", None)
    try:
        db.set_settings({"ai_site_model": w})
    except Exception:
        return "⚠️ نشد؛ «تشخیص» را بفرست تا علت را ببینیم.", None
    # v271: سوئیچ موفق = برگشت به صفحه‌کلید اصلی (مثل /مغز).
    return ("🌐 مدل هوش سایت شد: " + w + " ✅ (فوری، بدون ری‌استارت)", KEYBOARD)


def do_keys_panel():
    """v271 (دستور مدیر: «توکن تمام مدل‌ها … برا تک به تکشون گزینه باشه»):
    جایگزینی توکن هر مغز با یک دکمه — وضعیت کلیدها + KEY_KEYBOARD."""
    rows = [("اپوس ۵ (کلاد)", "AI_BRAIN_OPUS_KEY"),
            ("سونت ۵ (کلاد)", "AI_BRAIN_SONNET_KEY"),
            ("هایکو ۴.۵ (کلاد)", "AI_BRAIN_HAIKU_KEY"),
            ("اوپن‌روتر (مغز چهارم)", "AI_BRAIN_OR_KEY"),
            ("GLM 5.3 Flash (مغز پنجم — AvalAI)",
             "AI_BRAIN_GLM_KEY"),
            ("هوش سایت (عمومی کاربران — جدا)", "AI_SITE_API_KEY")]
    L = ["🔑 توکن مدل‌ها — دکمهٔ هرکدام را بزن تا جایگزینش کنی:"]
    for label, envk in rows:
        has = bool((os.environ.get(envk) or "").strip())
        L.append(("✅ " if has else "❌ ") + label + ("" if has else " — کلید ندارد"))
    L.append("")
    L.append("بعد از ضربه، کلید تازه را لخت همین‌جا بفرست؛ اول زنده تست و بعد"
             " در اسلات همان مغز می‌نشیند (بقیه دست‌نخورده).")
    return "\n".join(L), KEY_KEYBOARD


def do_key_target(target):
    """v271: دکمهٔ «کلید X» — کلید لخت بعدی مستقیم در اسلات همان مغز
    می‌نشیند (pending با action=key_for، ده دقیقه اعتبار)."""
    _pending_write(time.time() + 600, action="key_for", target=target)
    hint = {"اوپن": "sk-or-v1-…",
            "GLM": "aa-… — مغز پنجم (AvalAI)",   # v273
            "سایت": "aa-… — مدل پیش‌فرض glm-5.3-flash"}.get(target, "aa-…")
    return (f"🔑 کلید تازهٔ «{target}» را همین‌جا لخت بفرست ({hint}).\n"
            "اول زنده تست می‌شود، بعد فقط در اسلات همان مغز می‌نشیند.\n"
            "لغو: «نه»"), KEY_KEYBOARD


def do_brain(raw):
    """v263→v266: /مغز — سوئیچ فوری بین ۵ مغز (بدون صف و ری‌استارت).
    لخت = وضعیت؛ با نام = تست زندهٔ مغز مقصد و سوئیچ."""
    import assistant as _AI
    raw = (raw or "").strip()
    try:
        cur = _AI.active_brain()
    except Exception:
        cur = "sonnet"
    if not raw:
        # v264: one-tap picker + honest cost hints (Opus costs the most).
        _cost = {"opus": "قوی‌ترین · پرمصرف 💰",
                 "sonnet": "تعادل قدرت و هزینه ⚖️",
                 "haiku": "سریع و ارزان ✨",
                 "openrouter": "رایگان 🆓",
                 "glm": "ارزان · مغز پنجم 💸"}   # v273
        L = ["🧠 مغزهای سایت — یکی را بزن تا جواب بعدی را همان بدهد:"]
        for b in ("opus", "sonnet", "haiku", "openrouter", "glm"):
            _has = bool((os.environ.get(_AI.BRAINS[b][1]) or "").strip())
            _line = (("● " if b == cur else "○ ") + _AI.BRAIN_FA[b] +
                     (" — فعال ✅" if b == cur else "") +
                     ("" if _has else " — کلید ندارد ❌") +
                     f" · {_cost[b]}")
            if b == "glm":
                # v268→v273: which GLM model answers now.
                try:
                    _km = ((db.get_settings().get("ai_brain_glm_model")
                            or db.get_settings().get("ai_brain_kira_model")
                            or "").strip() or _AI.GLM_MODELS[0])
                except Exception:
                    _km = _AI.GLM_MODELS[0]
                _line += f" · {_km}"
            L.append(_line)
        L.append("")
        L.append("سوئیچ: دکمه را بزن یا بنویس: /مغز اپوس | سونت | هایکو | اوپن | GLM")
        L.append("مغز تازه اول تست زنده می‌شود؛ اگر جواب نداد سوئیچ نمی‌شود.")
        return "\n".join(L), BRAIN_KEYBOARD
    w = raw.split()[0].lower()
    b = {"opus": "opus", "اپوس": "opus", "sonnet": "sonnet", "سونت": "sonnet",
         "سانت": "sonnet", "haiku": "haiku", "هایکو": "haiku", "هايکو": "haiku",
         "openrouter": "openrouter", "open": "openrouter", "اوپن": "openrouter",
         "اوپنروتر": "openrouter", "اوپن‌روتر": "openrouter",
         "glm": "glm", "جی‌ال‌ام": "glm"}.get(w)   # v273: کیرا کلا حذف شد
    if not b:
        return ("نام مغز درست نیست. یکی از این‌ها: اپوس، سونت، هایکو، اوپن، GLM\n"
                "مثال: /مغز اپوس", None)
    if b == cur:
        return ("همین الان فعال است: " + _AI.BRAIN_FA[b] + " ✅", KEYBOARD)
    name, args = CT.parse_tool_call({"name": "brain_switch", "args": {"brain": b}})
    if not name:
        return "نام مغز درست نیست؛ /مغز را لخت بفرست تا فهرست را ببینی.", None
    ok, why = CT.tool_precheck(name, args)
    if not ok:
        return "⚠️ " + CT.fail_text(name, why), None
    ok, msg = CT.tool_execute(name, args)
    return ((msg if ok else "⚠️ " + msg), KEYBOARD if ok else None)


def do_ai_key(raw):
    """v242: owner pastes a FREE provider key right in the chat:
    /کلید gemini AIza...  (or the key alone — provider auto-detected).
    Live-tests the key, then queues the root-side install + restart."""
    raw = (raw or "").strip()
    if not raw:
        brain = ""
        try:
            c = assistant.config()
            if c.get("base_url") and c.get("api_key"):
                brain = f"🧠 مغز فعلی: {c.get('model') or '—'}\n\n"
        except Exception:
            pass
        return (brain +
                "کلید را این‌طور بفرست:\n"
                "/کلید Muse <کلید aa-…>   ← کلید تازه برای مغز فعال کلاد (اپوس/سونت/هایکو)\n"
                "/کلید chatgpt <کلید>  یا  /کلید astra <کلید>   ← کلید GPT مستقیم (sk-…)\n"
                "/کلید openai <آدرس> <کلید> <مدل>   ← هر سرویس سازگار با OpenAI\n"
                "/کلید gemini <کلید>   یا   /کلید groq <کلید>   ← رایگان\n"
                "/کلید openrouter <کلید>   ← کلید اوپن‌روتر (مغز چهارم)\n"
                "/کلید glm <کلید>   ← کلید مغز پنجم GLM (پنل مدیریتی — AvalAI)\n"
                "/کلید سایت <کلید> [مدل]   ← هوش عمومی سایت (v269 — کاملاً جدا از مغزهای شما)\n\n"
                "مثال: /کلید openai https://api.avalai.ir/v1 aa-xxx claude-sonnet-5\n"
                "کلید رایگان (بدون کارت): aistudio.google.com → Get API key\n"
                "یا console.groq.com → API Keys\n"
                "یا openrouter.ai → Keys (مغز چهارم، رایگان)", None)
    parts = raw.split()
    p0 = parts[0].lower()
    args = None
    if p0 in ("سایت", "site"):
        # v269 (دستور مدیر: هوش سایت جدا): /کلید سایت <کلید> [مدل]
        # یا /کلید سایت <آدرس> <کلید> <مدل> — اسلات AI_SITE_*، بدون اثر
        # روی مغزهای مدیر.
        rest = parts[1:]
        if len(rest) == 1:
            args = {"provider": "site", "key": rest[0]}
        elif len(rest) == 2 and not rest[0].startswith("http"):
            args = {"provider": "site", "key": rest[0], "model": rest[1]}
        elif len(rest) == 3 and rest[0].startswith("http"):
            args = {"provider": "site", "base": rest[0],
                    "key": rest[1], "model": rest[2]}
        else:
            return ("/کلید سایت <کلید> [مدل]   یا   /کلید سایت <آدرس> <کلید> <مدل>\n"
                    "مثال: /کلید سایت aa-… glm-5.3-flash\n"
                    "(هوش عمومی سایت — کاملاً جدا از مغزهای شما)", None)
    elif p0 in ("opus", "اپوس", "sonnet", "سونت", "سانت", "haiku", "هایکو"):
        # v271 (دستور مدیر: توکن تک‌تک مدل‌ها): /کلید اپوس aa-… → کلید
        # همان مغز کلاد، نصب اسلاتی (بقیهٔ مغزها دست‌نخورده).
        if len(parts) < 2:
            return do_ai_key("")
        slot = {"opus": "opus", "اپوس": "opus", "sonnet": "sonnet",
                "سونت": "sonnet", "سانت": "sonnet", "haiku": "haiku",
                "هایکو": "haiku"}[p0]
        args = {"provider": "muse", "key": parts[1], "slot": slot}
    elif p0 in ("open", "اوپن", "اوپنروتر", "اوپن‌روتر"):
        # v271: alias فارسی مغز چهارم.
        if len(parts) < 2:
            return do_ai_key("")
        args = {"provider": "openrouter", "key": parts[1]}
    elif p0 in ("glm", "جی‌ال‌ام"):
        # v273 (دستور مدیر): کلید GLM مغز پنجم — فقط پنل مدیریتی.
        if len(parts) < 2:
            return do_ai_key("")
        args = {"provider": "glm", "key": parts[1]}
    elif p0 in ("gemini", "groq", "astra", "muse", "openrouter"):
        if len(parts) < 2:
            return do_ai_key("")       # named the provider but forgot the key
        args = {"provider": p0, "key": parts[1]}
    elif p0 in ("openai", "gpt", "chatgpt"):
        if len(parts) == 2 and parts[1].startswith("sk-"):
            # «/کلید chatgpt sk-…» → direct OpenAI brain (gpt-6-astra)
            args = {"provider": "astra", "key": parts[1]}
        elif len(parts) >= 4:                      # base key model
            args = {"provider": "openai", "base": parts[1],
                    "key": parts[2], "model": parts[3]}
        elif len(parts) == 3:                      # key model (base = OpenAI)
            args = {"provider": "openai",
                    "base": "https://api.openai.com/v1",
                    "key": parts[1], "model": parts[2]}
        else:
            return ("/کلید openai <آدرس سرویس> <کلید> <مدل>\n"
                    "مثال: /کلید openai https://api.example.com/v1 sk-xxx gpt-6-astra", None)
    elif raw.startswith("AIza"):
        args = {"provider": "gemini", "key": raw}
    elif raw.startswith("gsk_"):
        args = {"provider": "groq", "key": raw}
    elif raw.startswith("sk-or-v1-"):
        # v262/v265: کلید OpenRouter لخت = مغز چهارم (نه مغز اصلی astra!)
        args = {"provider": "openrouter", "key": raw}
    elif raw.startswith("sk-"):
        args = {"provider": "astra", "key": raw}
    elif raw.startswith("aa-"):
        # v250: gateway keys (AvalAI & friends) — point at the live brain's
        # base so the owner doesn't have to guess the API address.
        # v259: Claude via AvalAI is a first-class provider — bare aa- keys
        # install directly as Claude (live-tested like every other path).
        args = {"provider": "muse", "key": raw}
    else:
        return ("نام سرویس را اول بفرست: Muse / openrouter / glm / astra / openai / gemini / groq\n"
                "مثال: /کلید Muse aa-…", None)
    name, args = CT.parse_tool_call({"name": "ai_setup", "args": args})
    if not name:
        return "شکل کلید درست نیست؛ کلید تازه بساز و کامل بفرست.", None
    ok, why = CT.tool_precheck(name, args)
    if not ok:
        return "⚠️ " + CT.fail_text(name, why), None
    ok, msg = CT.tool_execute(name, args)
    return (("🔑 " + msg) if ok else "⚠️ " + msg), None


# v310 (دستور مدیر): «کدهایی که تو ترموکس می‌زدم همان را در بله بزنم و
# واقعاً کار کند — بدون نیاز به هوش». ترمینال مستقیم: فقط چت تیم (دروازهٔ
# DENIED بالای handle_text)، بدون هوش در مسیر، بدون «بله». کاربرِ سرویس
# اجرا می‌کند (sudo/systemctl ندارد)؛ خروجی redact و سقف‌دار می‌شود.
SHELL_TIMEOUT_S = 90
SHELL_OUT_CAP = 3200
_SHELL_RX = re.compile(r"^(?:/?(?:sh|shell|ترمینال))(?:[ \t]+(.*))?$", re.S)


def do_shell(text):
    """ترمینال بله — None یعنی اصلاً دستور شل نبود."""
    m = _SHELL_RX.match((text or "").strip())
    if not m:
        return None
    cmdstr = (m.group(1) or "").strip()
    if not cmdstr:
        return ("🖥️ ترمینال بله — مثل ترموکس، بدون هوش مصنوعی\n"
                "──────────\n"
                "<code>sh &lt;فرمان&gt;</code> — اجرای فوری، خروجی همین‌جا\n"
                "<code>sh bg &lt;فرمان&gt;</code> — پس‌زمینه (استقرار/فرمان طولانی)\n"
                "هر فرمان پوستهٔ تازه است (cd ماندگار نیست) — مسیر مطلق بده.\n"
                "نمونه:\n"
                "  <code>sh ls -la /opt/dastgir</code>\n"
                "  <code>sh tail -n 20 /opt/dastgir/data/site_chats.log</code>\n"
                "  <code>sh bg bash /opt/dastgir/deploy/update.sh /root/dastgir-v310.zip</code>\n"
                "کاربر: کاربرِ سرویس (بدون sudo). خروجی تا ۳۲۰۰ نویسه و redact‌شده."), None
    bg = False
    if cmdstr.lower().startswith(("bg ", "bg\t")):
        bg = True
        parts = cmdstr.split(None, 1)
        cmdstr = parts[1].strip() if len(parts) > 1 else ""
    if not cmdstr:
        return "⚠️ فرمان خالی است — بعد از sh چیزی بنویس.", None
    try:
        db.log("bot_shell", cmdstr[:200])
    except Exception:
        pass
    if bg:
        try:
            subprocess.Popen(cmdstr, shell=True, cwd=ROOT,
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL,
                             stdin=subprocess.DEVNULL,
                             start_new_session=True)
            return ("▶️ در پس‌زمینه اجرا شد (بدون انتظار):\n"
                    "<code>" + html.escape(cmdstr[:600]) + "</code>"), None
        except Exception as e:
            return "⚠️ اجرا نشد: " + str(e)[:200], None
    t0 = time.time()
    try:
        p = subprocess.run(cmdstr, shell=True, cwd=ROOT,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           stdin=subprocess.DEVNULL, timeout=SHELL_TIMEOUT_S)
        out = (p.stdout or b"").decode("utf-8", "replace")
        err = (p.stderr or b"").decode("utf-8", "replace")
        dt = time.time() - t0
        body = out
        if err.strip():
            body = (body + "\n— stderr —\n" if body.strip() else "") + err
        body = _REDACT_RX.sub("«مقدار پنهان»", body)[:SHELL_OUT_CAP]
        head = f"🖥️ کد خروج: {p.returncode} · {dt:.1f}s"
        if body.strip():
            return head + "\n<code>" + html.escape(body) + "</code>", None
        return head + "\n(خروجی خالی)", None
    except subprocess.TimeoutExpired:
        return (f"⏱️ فرمان از {SHELL_TIMEOUT_S} ثانیه گذشت و کشته شد — "
                "برای کارهای طولانی: <code>sh bg &lt;فرمان&gt;</code>"), None
    except Exception as e:
        return "⚠️ خطا در اجرا: " + str(e)[:200], None


def handle_text(uid, chat_id, text):
    """Owner command dispatcher. Returns (reply_text, reply_markup|None)."""
    try:
        if not is_team_chat(chat_id):
            return DENIED, None
        # v293: تأیید/رد ورود به پنل — حتی از دروازهٔ فعال‌سازی هم مقدم‌تر
        # نیست، ولی باید قبل از تفسیر به‌عنوان هر دستور دیگری دیده شود.
        reply = decide_panel_approval(text)
        if reply is not None:
            return reply, None
        # v293 گیت فعال‌سازی (دستور مدیر): تا شماره+رمز تأیید نشده، «هیچ»
        # دستور دیگری اجرا نمی‌شود — فقط /369 و پاسخ‌های دو مرحله.
        if gate_enabled() and not gate_ok(chat_id):
            if (text or "").strip() in BOT_GATE_CMD:
                _gate_set(chat_id, "phone")
                return ("🔐 فعال‌سازی ربات مدیر.\n"
                        "شمارهٔ موبایل ثبت‌شدهٔ مالک را بفرستید.",
                        {"keyboard": [[{"text": "ارسال شمارهٔ خودم",
                                        "request_contact": True}]],
                         "resize_keyboard": True, "one_time_keyboard": True})
            return gate_step(chat_id, text), None
        cmd = _cmd_of(text)
        # v271: بعد از ضربهٔ «کلید X»، کلید لخت بعدی مستقیم در اسلات همان
        # مغز می‌نشیند (پنجرهٔ ۱۰ دقیقه‌ای؛ «نه» لغو می‌کند).
        pend0 = _pending_read()
        if pend0.get("action") == "key_for" and pend0.get("exp", 0) > time.time():
            _k = (text or "").strip()
            # v292: کلید aa- می‌تواند - و _ داشته باشد (هم‌شکل با
            # CODE._KEY_RX و regex کدگارد) — قبلاً کلید سالمِ -دار اینجا
            # بی‌صدا رد می‌شد و در پنجرهٔ «کلید X» گم می‌شد.
            if re.fullmatch(r"aa-[A-Za-z0-9_\-]{20,120}"
                            r"|sk-[A-Za-z0-9_\-]{20,}"
                            r"|AIza[A-Za-z0-9_\-]{20,}|gsk_[A-Za-z0-9]{20,}",
                            _k):   # v273: kira_ حذف شد
                _pending_clear()
                return do_ai_key((pend0.get("target") or "") + " " + _k)
        # v297: ایجنت جدید — تایید/لغو با گزارش کامل + /stop برای بازگشت
        if cmd in ("/stop", "stop", "توقف", "/توقف"):
            return _do_agent_stop()

        # v310 (دستور مدیر): ترمینال — sh <فرمان> مستقیم، بدون هوش
        _sh = do_shell(text)
        if _sh is not None:
            return _sh

        if cmd in ("تایید", "تایید و اجرا", "تأیید", "تایید و اجرا", "confirm", "✅ تایید و اجرا", "تایید و اجرا"):
            pend = _pending_read()
            if pend.get("action") == "agent_confirm" and pend.get("exp", 0) > time.time():
                return _do_agent_confirm(pend.get("target") or "")
            # fallback to old بله flow if agent_confirm not pending
            if pend.get("exp", 0) > time.time():
                action, target = pend.get("action") or "restart", pend.get("target") or ""
                if action == "agent_confirm":
                    return _do_agent_confirm(target)
            # if no agent_confirm, try as بله
            # (continue to بله handler below)

        if cmd in ("بله", "اره", "آره"):
            pend = _pending_read()
            if pend.get("exp", 0) > time.time():
                action, target = pend.get("action") or "restart", pend.get("target") or ""
                _pending_clear()
                if action == "agent_confirm":  # v297: تایید ایجنت هم با بله کار می‌کند
                    return _do_agent_confirm(target)
                if action in ("biz_ok", "biz_no"):
                    return _do_biz_decide(action, target)
                if action == "cast":
                    return _do_cast(target)
                if action == "ai_tool":                      # v239
                    return _do_ai_tool(target)
                if action == "appear_reset":               # v265
                    return _do_appear_reset()
                if action == "login_pass":                 # v267
                    return _do_login_pass_reset()
                if action == "key_for":                    # v271
                    return ("🔑 کلید را لخت بفرست (مثلاً aa-…) — "
                            "یا «نه» برای لغو.", KEY_KEYBOARD)
                if action == "sec_harden":                 # v287
                    if queue_write("secharden"):
                        return ("⏳ سخت‌سازی تو صف ریشه رفت — codeguard حداکثر "
                                "۱ دقیقه دیگر اجرا می‌کند (fail2ban + مسدودسازی "
                                "مهاجمان فعلی) و نتیجه را خبر می‌دهد. بعدش "
                                "«امنیت» را بفرست تا با عدد و دلیل ببینی.", None)
                    return "⚠️ صف نوشتن نشد؛ دیسک رو چک کن", None
                if queue_write("restart"):
                    return "⏳ ری‌استارت تو صف اجرا رفت (حداکثر ۱ دقیقه)", None
                return "⚠️ صف نوشتن نشد؛ دیسک رو چک کن", None
            _pending_clear()
            if not pend:
                return "چیزی در انتظار تأیید نیست ✅", None
            again = {"restart": "ریستارت", "biz_ok": "تأیید", "biz_no": "رد",
                     "cast": "پیام", "ai_tool": "همان تغییر (دوباره بگو)",
                     "appear_reset": "ظاهر پیش‌فرض",
                     "login_pass": "رمز تازه",
                     "sec_harden": "سخت‌سازی",
                     "agent_confirm": "تغییر ایجنت"}.get(
                         pend.get("action") or "restart", "ریستارت")
            return f"⌛ منقضی شد. دوباره بفرست: {again}", None
        if cmd in ("خیر", "نه", "لغو"):
            pend = _pending_read()
            if pend.get("action") == "agent_confirm":
                _pending_clear()
                return _do_agent_cancel()
            _pending_clear()
            return "لغو شد ✅", None
        if cmd in ("/restart", "ریستارت", "/ریستارت", "ری‌استارت"):
            _pending_write(time.time() + 120)
            return "⚠️ سرویس ری‌استارت بشه؟ بفرست: بله", None
        # v287: سخت‌سازی SSH — تأیید مدیر، اجرای واقعی توسط codeguard (ریشه)
        if cmd in ("سخت‌سازی", "سخت سازی", "/سخت‌سازی", "hardening"):
            _pending_write(time.time() + 120, "sec_harden")
            return ("⚠️ سخت‌سازی SSH اجرا بشه؟ codeguard با دسترسی ریشه: "
                    "fail2ban نصب/فعال می‌کند، jail سخت (۳ تلاش ⇒ ۲۴ ساعت "
                    "مسدود) می‌گذارد و مهاجمان فعلی را مسدود می‌کند.\n"
                    "بفرست: بله", None)
        _pending_clear()
        if cmd in ("/status", "وضعیت", "/وضعیت"):
            return do_status(), None
        if cmd in ("اسپم", "/اسپم", "spam"):
            return do_spam(text), None
        if cmd in ("آمار", "/آمار", "/traffic"):
            return do_traffic(), None
        if cmd in ("دیتابیس", "/دیتابیس", "/db"):
            return do_db(), None
        if cmd in ("سیستم", "/سیستم", "/sys"):
            return do_sys(), None
        if cmd in ("امنیت", "/امنیت", "sec", "/sec", "ssh", "/ssh",
                   "security"):                            # v287
            return do_sec(), None
        if cmd in ("خطا", "/خطا", "/errors"):
            return do_errors(), None
        if cmd in ("/backup", "بکاپ", "/بکاپ"):
            if queue_write("backup"):
                return "⏳ بکاپ تو صف اجرا رفت (حداکثر ۱ دقیقه)", None
            return "⚠️ صف نوشتن نشد؛ دیسک رو چک کن", None
        if cmd in ("گزارش", "/گزارش", "/report"):
            return do_report(), None
        if cmd in ("/log", "لاگ", "/لاگ"):
            return do_log(), None
        # v270 (دستور مدیر): فایل کل چت‌های عمومی. _cmd_of فقط واژهٔ اول را
        # می‌گیرد، پس میان‌برهای چندواژه‌ای با متن کامل مطابقت داده می‌شوند.
        if cmd in ("چت‌ها", "چت‌های", "/چت‌ها", "/chats", "chats", "لاگ‌چت") or \
                (text or "").strip() in ("چت های سایت", "چت‌های سایت",
                                         "چت های عمومی", "چت‌های عمومی",
                                         "لاگ چت", "دریافت چت‌ها", "دریافت چت ها"):
            return do_chats(chat_id)
        if cmd in ("صف", "/صف", "/queue"):
            return do_queue(), None
        if cmd in ("تأیید", "/تأیید", "/bizqueue"):
            arg = _rest(text)
            if not arg:
                return do_bizqueue(), None
            bid = _norm_id(arg)
            if bid is None:
                return "شمارهٔ کسب‌وکار درست نیست. مثلاً: تأیید ۱۲", None
            return do_biz_ask(True, bid), None
        if cmd in ("رد", "/رد", "/reject"):
            bid = _norm_id(_rest(text))
            if bid is None:
                return "شمارهٔ کسب‌وکار درست نیست. مثلاً: رد ۱۲", None
            return do_biz_ask(False, bid), None
        if cmd in ("پیام", "/پیام", "/cast"):
            return do_cast_ask(_rest(text)), None
        if cmd in ("تازه‌ها", "تازه ها", "/تازه‌ها", "/fresh"):
            return do_fresh(), None
        if cmd in ("کاربر", "/کاربر", "/who"):
            return do_who(_rest(text)), None
        if cmd in ("نگهبان", "/نگهبان", "/watch"):
            return do_watch(), None
        if cmd in ("حذف", "/حذف", "/unqueue", "کنسل"):
            return do_unqueue(_rest(text)), None
        if cmd in ("قیمت", "/قیمت", "/prices"):
            return do_prices(_rest(text)), None
        if cmd in ("/کلید", "/key", "/کلید:"):
            return do_ai_key(_rest(text))
        # v271 (دستور مدیر): گزینه‌های دیده‌شدنی — «هوش سایت» (پنل + سوئیچ
        # مدل با یک ضربه)، «کلیدها» (توکن تک‌تک مدل‌ها)، «بازگشت» از
        # صفحه‌کلیدهای فرعی.
        _txt = _fa2en((text or "").strip())
        if _txt in ("هوش سایت", "هوش‌سایت", "سایت", "مدل سایت") or \
                cmd in ("/سایت", "/site", "هوش‌سایت"):
            return do_sitemodel("")      # پنل وضعیت + SITE_KEYBOARD
        if _txt.startswith("مدل سایت"):
            # «مدل سایت <شناسه>» — شناسه صریح، وگرنه همان پنل.
            _w = _txt.split()
            return do_sitemodel(_w[2] if len(_w) > 2 else "")
        if _txt in ("glm-5.3-flash", "glm-5.3", "glm-5.2", "glm-5.1"):
            return do_sitemodel(_txt)      # ضربه روی دکمهٔ مدل = سوئیچ با تست زنده
        if _txt == "کلیدها":
            return do_keys_panel()
        if _txt in _KEY_TARGETS:
            return do_key_target(_KEY_TARGETS[_txt])
        if _txt == "بازگشت":
            return "✅", KEYBOARD
        # v264: tapping a brain button sends its bare name — switch at once.
        if _fa2en(text.strip()) in _BRAIN_TAPS:
            return do_brain(text)
        # v265: factory-reset the whole appearance (colors, logo, hero texts).
        if _fa2en(text.strip()) in ("ظاهر پیش‌فرض", "ظاهر پيشفرض",
                                    "ریست ظاهر", "بازگشت به پیش‌فرض"):
            _pending_write(time.time() + 120, "appear_reset", "")
            return ("⚠️ ظاهر سایت به پیش‌فرض برگردد؟ (رنگ‌ها، لوگو و "
                    "متن‌های صفحهٔ اصلی)\nبفرست: بله", None)
        # v267: the owner's own panel login — substring on purpose: natural
        # phrasings («کلید ورودم به سایت بده») must reach it directly, never
        # the model (models lecture instead of serving here).
        # v300: پنل ایجنت — کلید فقط از ربات
        if _fa2en(text) in ("ایجنت", "پنل ایجنت", "کلید ایجنت", "پنل‌ایجنت") or cmd in ("/agent", "/ایجنت", "/agentkey"):
            return _do_agent_key(ip=str(chat_id))
        if "کلید ایجنت" in _fa2en(text) or "پنل ایجنت" in _fa2en(text):
            return _do_agent_key(ip=str(chat_id))
        if "کلید ورود" in _fa2en(text) or "رمز پنل" in _fa2en(text):
            return _do_login_keys()
        if cmd in ("مغز", "/مغز") and _is_brain_cmd(cmd, _rest(text)):
            return do_brain(_rest(text))
        if cmd in ("مدل", "/مدل"):                        # v268
            _r = (_rest(text) or "").strip()
            _w = _r.split()
            if _w and _w[0] in ("سایت", "site"):          # v269: هوش عمومی سایت
                return do_sitemodel(_r.split(None, 1)[1] if len(_w) > 1 else "")
            return do_glmmodels(_rest(text))
        if cmd in ("تشخیص", "/تشخیص", "عیب‌یابی", "عیب یابی", "/diagnose", "diagnose"):
            return do_diagnose()
        # v282 (دستور مدیر): «پنل» = فهرست بخش‌ها؛ «پنل <بخش> [id|عبارت]» =
        # خواندن قطعی هر بخش پنل — بدون مدل، بدون محدودیت.
        if cmd in ("پنل", "/پنل", "/panel", "panel", "بخش‌ها", "بخشها"):
            return CT.panel_read_cmd(_rest(text)), None
        if cmd in ("/help", "راهنما", "/راهنما", "/start", "شروع"):
            return do_help()
        # v238→v239: anything else goes to the admin copilot (Bale only).
        # v239: the model may PROPOSE a content tool; we validate it here.
        # v268: valid proposals execute at once (the pending file is now
        # only for direct commands: restart/reset/پیام/login-password).
        if assistant.configured():
            mem = _memory_load()
            reply, _src, tool = assistant.admin_agent(text, admin_snapshot(), mem)
            if not tool:
                # v246 autopilot: a weak model that answers without a tool
                # must never end a CODE request with a bare claim. The server
                # itself searches → reads → asks the model only for the edit.
                try:
                    if assistant.code_change_intent(text) or \
                            assistant.code_locate_intent(text):
                        ap_reply, ap_tool = assistant.autopilot(text)
                        if ap_tool:
                            reply, tool = ap_reply, ap_tool
                        elif ap_reply:
                            # keep any real evidence the model already showed
                            reply = (reply + "\n\n" + ap_reply).strip() \
                                if "🔍" in (reply or "") else ap_reply
                    elif re.search("انجام شد|اجرا شد|انجامش دادم|درستش کردم", reply or ""):
                        reply += "\n\n⚠️ توجه: هنوز هیچ تغییری اجرا نشده است."
                except Exception:
                    pass
            if tool:
                # v297 (دستور مدیر جدید): ایجنت دیگر بدون تایید اجرا نمی‌کند.
                # باید گزارش کامل بدهد + دکمه تایید/لغو + /stop برای بازگشت.
                ok, why = CT.tool_precheck(tool["name"], tool["args"])
                if not ok:
                    reply = (reply + "\n\n" + CT.fail_text(tool["name"], why)).strip()
                else:
                    # گزارش کامل + اسنپ‌شات برای rollback
                    try:
                        full_report = CT.tool_report(tool["name"], tool["args"])
                    except Exception:
                        full_report = CT.tool_describe(tool["name"], tool["args"])
                    try:
                        snap = CT.tool_snapshot(tool["name"], tool["args"])
                    except Exception:
                        snap = None
                    # ذخیره pending برای تایید
                    import json as _js
                    pending_data = {
                        "name": tool["name"],
                        "args": tool["args"],
                        "report": full_report,
                        "snapshot": snap,
                        "ts": time.time(),
                        "reply": reply,
                    }
                    _pending_write(time.time() + 300, action="agent_confirm", target=_js.dumps(pending_data, ensure_ascii=False))
                    # کیبورد تایید/لغو
                    kb = {
                        "inline_keyboard": [
                            [{"text": "✅ تایید و اجرا", "callback_data": "agent:confirm"}],
                            [{"text": "❌ لغو", "callback_data": "agent:cancel"}]
                        ]
                    }
                    # اگر reply قبلی داشت، گزارش را جدا بفرست
                    final_text = (reply + "\n\n" + full_report).strip() if reply else full_report
                    _memory_save(_redact(text), _redact(final_text))
                    return _redact(final_text), kb
            _memory_save(_redact(text), _redact(reply))
            return _redact(reply), None
        # v246: keyless but useful — locate questions still get answered
        try:
            if assistant.code_locate_intent(text):
                q = assistant.mine_query(text)
                if q:
                    _ok, msg = CT.tool_execute("code_search", {"query": q})
                    if _ok and "پیدا نشد" not in msg:
                        return msg, None
        except Exception:
            pass
        return ("🧠 مغز هوش مصنوعی هنوز وصل نیست — اما همین الان می‌شود وصلش کرد، "
                "رایگان و بدون ترمینال:\n\n"
                "۱) کلید رایگان بساز (۲ دقیقه، بدون کارت):\n"
                "   • گوگل: aistudio.google.com → Get API key\n"
                "   • گروک: console.groq.com → API Keys\n"
                "۲) همین‌جا بفرست:  /کلید gemini <کلید>\n\n"
                "خودم تستش می‌کنم و وصل می‌کنم؛ بعد هر کاری بگویی انجام می‌دهم "
                "(محتوا، عکس و حتی کد سایت).\n\n"
                "🩺 برای گزارش دقیق از وضعیت همه‌چیز، بفرست: تشخیص", None)
    except Exception as e:
        print("adminbot handle_text error:", e, flush=True)
        return "⚠️ خطای داخلی؛ دوباره بفرست.", None


def handle_update(update):
    """Webhook entry: private text/callback from the owner only."""
    try:
        # v297: inline keyboard callbacks for agent confirm/cancel/stop
        cq = update.get("callback_query")
        if isinstance(cq, dict):
            chat = ((cq.get("message") or {}).get("chat") or {})
            chat_id = chat.get("id")
            if chat_id is None:
                chat_id = (cq.get("from") or {}).get("id")
            if not is_team_chat(chat_id):
                return
            data = str(cq.get("data") or "")
            cb_id = cq.get("id") or ""
            # answer callback to remove loading
            try:
                import server.bale as _bale
                _bale.answer_callback(cb_id, "دریافت شد")
            except Exception:
                pass
            if data == "agent:confirm":
                pend = _pending_read()
                if pend.get("action") == "agent_confirm" and pend.get("exp", 0) > time.time():
                    reply, markup = _do_agent_confirm(pend.get("target") or "")
                else:
                    reply, markup = "⌛ منقضی شد — دوباره درخواست بده", None
                send_message(chat_id, _redact(reply), markup)
                return
            elif data == "agent:cancel":
                reply, markup = _do_agent_cancel()
                send_message(chat_id, _redact(reply), markup)
                return
            elif data == "agent:stop":
                reply, markup = _do_agent_stop()
                send_message(chat_id, _redact(reply), markup)
                return
            # fallback: treat callback data as text
            # (for other inline keyboards like bz185 login)
            # let it fall through to message handling? No, callback is separate.
            return

        msg = update.get("message")
        if not isinstance(msg, dict):
            return
        chat = msg.get("chat") or {}
        if chat.get("type") != "private":
            return
        chat_id = chat.get("id")
        if chat_id is None:
            return
        text = str(msg.get("text") or "")
        # v240: a photo from the owner becomes the AI's current image —
        # tools reference it as "__last__" (resolved server-side only).
        if msg.get("photo") and is_team_chat(chat_id):
            _owner_photo(chat_id, msg)
            if not text:
                return
            # a caption rides along as the actual request
        sender = msg.get("from") or {}
        # v293 گیت فعال‌سازی: دکمهٔ رسمی «ارسال شمارهٔ خودم» بله، متن نیست —
        # اینجا جداگانه مصرف می‌شود (تطبیق contact با شمارهٔ مالک).
        _gated = gate_enabled() and not gate_ok(chat_id)
        _gate_st = gate_state(chat_id) if _gated else ""
        contact = msg.get("contact")
        if _gated and _gate_st == "phone" and isinstance(contact, dict) \
                and is_team_chat(chat_id):
            if str(contact.get("user_id")) != str(sender.get("id")):
                send_message(chat_id, "فقط شمارهٔ خودتان پذیرفته می‌شود.")
                return
            reply = gate_handle_phone(chat_id, contact.get("phone_number") or "")
            send_message(chat_id, reply,
                         {"remove_keyboard": True} if "✅" in reply else None)
            return
        reply, markup = handle_text(sender.get("id"), chat_id, text)
        # v293: پیام‌های حاوی شماره/رمز فعال‌سازی از تاریخچهٔ چت حذف می‌شوند
        # تا مدرک حساس در بله باقی نماند.
        if _gated and _gate_st in ("phone", "pass"):
            try:
                delete_message(chat_id, msg.get("message_id"))
            except Exception:
                pass
        # v274 (دستور مدیر — ریشه در اسکرین‌شات بله): کلید لخت که در چت
        # تایپ می‌شد، برای همیشه به‌صورت حباب در تاریخچه می‌ماند. حالا هر
        # پیامِ حاوی کلید، بلافاصله بعد از مصرف حذف می‌شود تا محرمانه در چت
        # نماند؛ خودِ کلید هم مثل قبل در پاسخ و حافظه redact می‌شود.
        if _REDACT_RX.search(text or ""):
            if delete_message(chat_id, msg.get("message_id")):
                reply = (reply or "") + "\n🧹 پیام حاوی کلید از این گفت‌وگو حذف شد."
            else:
                reply = (reply or "") + ("\n⚠️ حذف خودکار پیام کلید ممکن نشد؛ "
                                         "همین حالا همان پیام را دستی از چت پاک کنید.")
        # v272 (ریشهٔ «ربات بله تغییرات لازم نکرده»): بله/تلگرام آخرین
        # صفحه‌کلیدی که بات فرستاده را نگه می‌دارد — بعد از هر نصب، مدیر
        # هنوز ردیف‌های قدیمی را می‌بیند. یک‌بار در هر نسخه، صفحه‌کلید
        # تازه به پاسخ بعدی سوار می‌شود.
        try:
            if (db.get_settings().get("admin_kb_ver") or "") != DIAG_LATEST:
                markup = markup or KEYBOARD
                db.set_settings({"admin_kb_ver": DIAG_LATEST})
        except Exception:
            pass
        send_message(chat_id, _redact(reply), markup)
    except Exception as e:
        print("adminbot handle_update error:", e, flush=True)


def _download_file(file_id, max_bytes=3 * 1024 * 1024 + 1):
    """v240: getFile → bounded download with the ADMIN bot's own token.
    Returns bytes or b"" (never raises). Mirrors bale.download_file."""
    if not re.fullmatch(r"[A-Za-z0-9_\-:.]{8,200}", str(file_id or "")):
        return b""
    info = _call("getFile", {"file_id": file_id})
    path = ((info.get("result") or {}).get("file_path") or "") if info.get("ok") else ""
    if not path or ".." in path or path.startswith("/"):
        return b""
    try:
        req = urllib.request.Request(f"{FILE_ROOT}{token()}/{path}",
                                     headers={"User-Agent": "Daastgir/240"})
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.read(max_bytes)
    except Exception:
        return b""


def _owner_photo(chat_id, msg):
    """Save the owner's photo as the AI's current image (15-minute TTL)."""
    try:
        photo = msg.get("photo")
        if not isinstance(photo, list) or not photo:
            return
        # Bale sends ascending sizes; take the largest.
        best = max(photo, key=lambda p: int(p.get("file_size") or 0) or 1) \
            if isinstance(photo[0], dict) else {}
        fid = str(best.get("file_id") or photo[-1].get("file_id") or "")
        data = _download_file(fid)
        if not data:
            send_message(chat_id, "⚠️ عکس دانلود نشد؛ دوباره بفرست.")
            return
        path, err = uploads.save_image(data, prefix="admin")
        if not path:
            send_message(chat_id, f"⚠️ {err or 'عکس معتبر نیست.'}")
            return
        CT.image_save(path)
        send_message(chat_id,
                     "🖼 عکس ثبت شد (۱۵ دقیقه معتبر).\nحالا بگو کجا استفاده شود؛ "
                     "مثلاً: «این عکس را ویترین دکان فلان کن» یا «استوری دکان فلان».")
    except Exception as e:
        print("adminbot photo error:", e, flush=True)
