# -*- coding: utf-8 -*-
"""
v308 external web browser + arena.ai bridge + file exchange
Fixes: "این محتوا مسدود شده است" — X-Frame-Options / CSP frame-ancestors blocks live sites in iframe.
Solution: full reverse proxy that strips X-Frame-Options, CSP, rewrites URLs to go through proxy,
injects anti-frame-busting JS, supports arena auth cookie forwarding.

Standard library only — VPN-friendly, proxy-aware.
"""

import os
import re
import json
import time
import html
import urllib.parse
import urllib.request
import urllib.error
import pathlib

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "..", "data")
ARENA_DIR = os.path.join(DATA_DIR, "arena-bridge")
os.makedirs(ARENA_DIR, exist_ok=True)

DEFAULT_ARENA_URL = "https://arena.ai/agent/01a0acde-4c14-7c72-9934-1df78579ea49"
ALLOWED_HOSTS = {
    "arena.ai",
    "www.arena.ai",
}
BLOCKED_SUBSTR = ("127.0.0.1", "localhost", "0.0.0.0", "::1", "10.", "192.168.", "172.")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

def _is_allowed_url(url: str):
    try:
        u = urllib.parse.urlparse(url)
        if u.scheme not in ("http", "https"):
            return False, "scheme must be http/https"
        host = (u.hostname or "").lower()
        if not host:
            return False, "no host"
        # block private ranges unless it's arena.ai
        if host in ALLOWED_HOSTS or host.endswith(".arena.ai"):
            return True, ""
        # block obvious SSRF
        if host.startswith("127.") or host == "localhost" or host.startswith("10.") or host.startswith("192.168."):
            return False, f"blocked private host {host}"
        # 172.16-31 private
        if host.startswith("172."):
            try:
                second = int(host.split(".")[1])
                if 16 <= second <= 31:
                    return False, f"blocked private host {host}"
            except:
                pass
        if host in ("0.0.0.0", "::1"):
            return False, "loopback blocked"
        return True, ""
    except Exception as e:
        return False, str(e)

def _proxy_env():
    for k in ("ARENA_PROXY", "HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy"):
        v = (os.environ.get(k) or "").strip()
        if v:
            return v
    return ""

def _build_opener():
    proxy = _proxy_env()
    if proxy:
        return urllib.request.build_opener(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
    return urllib.request.build_opener()

def _arena_cookie_path():
    return os.path.join(ARENA_DIR, "arena_cookie.txt")

def get_arena_cookie():
    try:
        p = _arena_cookie_path()
        if os.path.exists(p):
            txt = open(p, "r", encoding="utf-8", errors="ignore").read().strip()
            # limit 8KB
            if txt:
                return txt[:8192]
    except:
        pass
    # also env
    try:
        v = (os.environ.get("ARENA_COOKIE") or "").strip()
        if v:
            return v[:8192]
    except:
        pass
    return ""

def set_arena_cookie(cookie_str: str):
    try:
        p = _arena_cookie_path()
        open(p, "w", encoding="utf-8").write((cookie_str or "").strip()[:8192])
        return True
    except:
        return False

def fetch_raw(url: str, timeout=15, extra_headers=None):
    """Fetch any URL, return dict with body bytes, content_type, status, headers, error"""
    ok, why = _is_allowed_url(url)
    if not ok:
        return {"ok": False, "error": why, "body": b"", "content_type": "", "status": 0, "headers": {}}
    try:
        hdrs = {
            "User-Agent": UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9,fa;q=0.8",
            "Accept-Encoding": "identity",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        }
        # arena auth cookie forwarding
        arena_cookie = get_arena_cookie()
        if arena_cookie:
            # if user pasted full cookie header or just value, use as Cookie
            if "=" in arena_cookie and ";" in arena_cookie:
                hdrs["Cookie"] = arena_cookie
            elif "=" in arena_cookie:
                hdrs["Cookie"] = arena_cookie
            else:
                # raw token? still try
                hdrs["Cookie"] = arena_cookie
        if extra_headers:
            hdrs.update(extra_headers)

        req = urllib.request.Request(url, headers=hdrs)
        opener = _build_opener()
        with opener.open(req, timeout=timeout) as resp:
            ctype = resp.headers.get("Content-Type", "")
            # read up to 5MB
            body = resp.read(5_000_000)
            # collect headers for debugging
            hdict = {k.lower(): v for k, v in resp.headers.items()}
            return {
                "ok": True,
                "body": body,
                "content_type": ctype,
                "status": getattr(resp, 'status', 200),
                "headers": hdict,
                "url": url,
                "proxy_used": bool(_proxy_env()),
                "cookie_used": bool(arena_cookie),
            }
    except urllib.error.HTTPError as e:
        try:
            b = e.read(500_000)
        except:
            b = b""
        return {"ok": False, "error": f"HTTP {e.code}", "code": e.code, "body": b, "content_type": e.headers.get("Content-Type",""), "status": e.code, "headers": {k.lower():v for k,v in e.headers.items()}, "proxy_used": bool(_proxy_env())}
    except Exception as e:
        return {"ok": False, "error": str(e)[:500], "body": b"", "content_type": "", "status": 0, "headers": {}, "proxy_used": bool(_proxy_env())}

def fetch_url(url: str, timeout=15):
    """Backward compat — returns text summary for diag"""
    r = fetch_raw(url, timeout=timeout)
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error",""), "proxy_used": r.get("proxy_used", False), "code": r.get("code",0)}
    ctype = r.get("content_type","")
    body = r.get("body", b"")
    charset = "utf-8"
    if "charset=" in ctype:
        try:
            charset = ctype.split("charset=")[-1].split(";")[0].strip()
        except:
            pass
    try:
        text = body.decode(charset, errors="ignore")
    except:
        text = body.decode("utf-8", errors="ignore")
    m = re.search(r"<title[^>]*>(.*?)</title>", text, re.I | re.S)
    title = html.unescape(m.group(1).strip()) if m else url
    title = re.sub(r"\s+", " ", title)[:300]
    txt = re.sub(r"<script.*?</script>", " ", text, flags=re.I | re.S)
    txt = re.sub(r"<style.*?</style>", " ", txt, flags=re.I | re.S)
    txt = re.sub(r"<[^>]+>", " ", txt)
    txt = html.unescape(txt)
    txt = re.sub(r"\s+", " ", txt).strip()[:8000]
    return {"ok": True, "url": url, "status": r.get("status",200), "content_type": ctype, "title": title, "text": txt, "raw_len": len(body), "html": text[:200000], "proxy_used": r.get("proxy_used", False), "cookie_used": r.get("cookie_used", False)}

def _should_proxy_content_type(ctype: str):
    c = (ctype or "").lower()
    return ("text/html" in c) or ("application/xhtml" in c) or (c.strip() == "") or ("text/html" in c)

def _strip_blocking_meta(html_str: str):
    # Remove meta that blocks framing
    # <meta http-equiv="X-Frame-Options" ...>
    html_str = re.sub(r'<meta[^>]+http-equiv=["\']?x-frame-options["\']?[^>]*>', '', html_str, flags=re.I)
    # Remove CSP meta that contains frame-ancestors
    # We strip all CSP meta to be safe, because it can block inline scripts we inject
    html_str = re.sub(r'<meta[^>]+http-equiv=["\']?content-security-policy[^>]*>', '', html_str, flags=re.I)
    html_str = re.sub(r'<meta[^>]+http-equiv=["\']?content-security-policy-report-only[^>]*>', '', html_str, flags=re.I)
    return html_str

def rewrite_html(html_str: str, base_url: str):
    """Rewrite HTML to proxy all arena.ai resources and strip frame-blocking, inject anti-bust
    v308 fix: don't rewrite inside <script> tags — otherwise new URL() becomes new url(/proxy...)
    """
    try:
        parsed = urllib.parse.urlparse(base_url)
        origin = f"{parsed.scheme}://{parsed.netloc}"
        proxy_prefix = "/agent/proxy?url="

        def to_proxy_url(target):
            if not target:
                return target
            t = target.strip()
            if not t or t.startswith("#") or t.startswith("data:") or t.startswith("blob:") or t.startswith("javascript:") or t.startswith("mailto:") or t.startswith("tel:"):
                return t
            if t.startswith(proxy_prefix):
                return t
            try:
                abs_url = urllib.parse.urljoin(base_url, t)
                is_relative = not urllib.parse.urlparse(t).netloc
                abs_host = urllib.parse.urlparse(abs_url).hostname or ""
                if is_relative or abs_host.endswith("arena.ai") or abs_host == parsed.hostname:
                    return proxy_prefix + urllib.parse.quote(abs_url, safe="")
                if abs_url.startswith("https://") and len(abs_url) < 800:
                    return proxy_prefix + urllib.parse.quote(abs_url, safe="")
                return abs_url
            except:
                return t

        # Step 1: strip blocking meta
        html_str = _strip_blocking_meta(html_str)

        # Step 2: extract existing <script> blocks to avoid rewriting inside them
        scripts = []
        def script_placeholder(m):
            scripts.append(m.group(0))
            return f"__DASTGIR_SCRIPT_{len(scripts)-1}__"
        # protect scripts
        html_no_script = re.sub(r"<script[^>]*>.*?</script>", script_placeholder, html_str, flags=re.I | re.S)

        # Step 3: rewrite attributes on html without scripts
        def repl_attr(m):
            attr = m.group(1)
            quote = m.group(2)
            url = m.group(3)
            if attr.lower() == "srcset":
                parts = []
                for part in url.split(","):
                    part = part.strip()
                    if not part:
                        continue
                    segs = part.split()
                    if segs:
                        segs[0] = to_proxy_url(segs[0])
                        parts.append(" ".join(segs))
                new_url = ", ".join(parts)
                return f'{attr}={quote}{new_url}{quote}'
            else:
                new_url = to_proxy_url(url)
                return f'{attr}={quote}{new_url}{quote}'

        html_no_script = re.sub(r'(href|src|action|poster|data|srcset)\s*=\s*(["\'])(.*?)\2', repl_attr, html_no_script, flags=re.I | re.S)

        # Step 4: rewrite CSS url() — but only outside scripts (we already removed them)
        # Avoid matching inside our placeholder
        def repl_css_url(m):
            full = m.group(0)
            # skip if inside placeholder
            if "__DASTGIR_SCRIPT_" in full:
                return full
            q = m.group(1) or ""
            u = m.group(2)
            uu = u.strip().strip('"\'')
            if uu.startswith("data:") or uu.startswith("blob:") or uu.startswith("__DASTGIR_SCRIPT_"):
                return full
            new_u = to_proxy_url(uu)
            return f"url({q}{new_u}{q})"
        html_no_script = re.sub(r'url\(\s*(["\']?)(.*?)\1\s*\)', repl_css_url, html_no_script, flags=re.I)

        # Step 5: restore scripts
        for i, sc in enumerate(scripts):
            html_no_script = html_no_script.replace(f"__DASTGIR_SCRIPT_{i}__", sc)

        html_str = html_no_script

        # Step 6: inject anti-frame-busting script - minimal, does not break Next.js hydration
        anti_bust = (
            '<script>\n'
            '// dastgir v308 minimal anti-bust - safe for Next.js\n'
            '(function(){\n'
            '  try{ window.addEventListener("beforeunload", function(e){ try{e.stopImmediatePropagation();}catch(_){ } }, true); }catch(e){}\n'
            f'  console.log("[dastgir] v308 proxy active origin={origin}");\n'
            '  const PROXY = "/agent/proxy?url=";\n'
            f'  const ORIGIN = "{origin}";\n'
            '  function toProxy(url){\n'
            '    if(!url) return url;\n'
            '    let s = String(url).trim();\n'
            '    if(!s || s.startsWith("#") || s.startsWith("data:") || s.startsWith("blob:") || s.startsWith("javascript:") || s.startsWith("mailto:") || s.startsWith("tel:") || s.startsWith(PROXY)) return s;\n'
            '    try{\n'
            '      let abs = new URL(s, ORIGIN).href;\n'
            '      let h = new URL(abs).hostname || "";\n'
            '      if(h.endsWith("arena.ai") || abs.startsWith(ORIGIN) || s.startsWith("/")){\n'
            '        return PROXY + encodeURIComponent(abs);\n'
            '      }\n'
            '      if(abs.startsWith("https://")){\n'
            '        return PROXY + encodeURIComponent(abs);\n'
            '      }\n'
            '      return abs;\n'
            '    }catch(e){ return s; }\n'
            '  }\n'
            '  const _fetch = window.fetch;\n'
            '  if(_fetch){\n'
            '    window.fetch = function(input, init){\n'
            '      try{\n'
            '        if(typeof input === "string"){ input = toProxy(input); }\n'
            '        else if(input && input.url){ let nu = toProxy(input.url); if(nu !== input.url){ input = new Request(nu, input); } }\n'
            '      }catch(e){}\n'
            '      return _fetch.call(this, input, init);\n'
            '    };\n'
            '  }\n'
            '  const _open = XMLHttpRequest.prototype.open;\n'
            '  XMLHttpRequest.prototype.open = function(method, url){\n'
            '    try{ arguments[1] = toProxy(url); }catch(e){}\n'
            '    return _open.apply(this, arguments);\n'
            '  };\n'
            '})();\n'
            '</script>\n'
        )
        if re.search(r"<head[^>]*>", html_str, re.I):
            html_str = re.sub(r"(<head[^>]*>)", r"\1" + anti_bust, html_str, count=1, flags=re.I)
        else:
            html_str = anti_bust + html_str

        # Step 7: inject banner after <body>
        banner = (
            '<div id="__dastgir_banner" style="position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#111;color:#fff;padding:8px 12px;font-family:Tahoma,sans-serif;font-size:13px;display:flex;gap:10px;align-items:center;border-bottom:1px solid #333">'
            f'  <span>🔗 {html.escape(base_url[:100])}</span>'
            f'  <a href="/agent/browser?url={urllib.parse.quote(base_url)}" style="color:#8cf;text-decoration:none;background:#222;padding:4px 8px;border-radius:6px">بازگشت به پنل</a>'
            f'  <a href="{html.escape(base_url)}" target="_blank" style="color:#8cf;text-decoration:none;background:#222;padding:4px 8px;border-radius:6px">🌐 مستقیم (VPN)</a>'
            f'  <span style="margin-left:auto;opacity:.7;font-size:11px">v308 proxy • {html.escape(_proxy_env()[:30] or "بدون پراکسی")} • cookie:{"yes len="+str(len(get_arena_cookie() or "")) if get_arena_cookie() else "no"} + (" (کم! باید ۵۰۰+ باشد)" if len(get_arena_cookie() or "")>0 and len(get_arena_cookie() or "")<200 else "")</span>'
            '</div><div style="height:38px"></div>'
        )
        if re.search(r"<body[^>]*>", html_str, re.I):
            html_str = re.sub(r"(<body[^>]*>)", r"\1" + banner, html_str, count=1, flags=re.I)
        else:
            html_str = banner + html_str

        return html_str
    except Exception as e:
        return f"<!-- rewrite error: {html.escape(str(e)[:200])} -->\n" + html_str

def proxy_fetch(url: str, timeout=15):
    """Main proxy: fetch any URL, return body bytes, content_type, status, rewritten if HTML - v308 asset fix"""
    res = fetch_raw(url, timeout=timeout)
    if not res.get("ok"):
        # v308: for JS/CSS assets don't return HTML (breaks page with < in JS) - return empty
        low = url.lower()
        is_asset = any(low.endswith(ext) for ext in (".js",".css",".png",".jpg",".jpeg",".webp",".svg",".woff",".woff2",".ico",".json")) or "/_next/" in low or "/static/" in low
        if is_asset:
            ctype = "application/javascript" if (".js" in low or "_next" in low) else "text/css" if ".css" in low else "image/png" if ".png" in low else "application/octet-stream"
            return {
                "ok": False,
                "body": b"/* dastgir proxy asset fail 403 - filtered, use VPN direct */",
                "content_type": ctype,
                "status": 200,
                "headers": {},
                "error": res.get("error",""),
                "is_html": False,
                "is_fallback": False,
            }
        # Return fallback HTML explaining for pages only
        proxy_info = _proxy_env() or "بدون پراکسی (مستقیم)"
        cookie_info = "دارد" if get_arena_cookie() else "ندارد"
        safe_err = html.escape(res.get("error","unknown"))
        safe_url = html.escape(url)
        fallback = (
            '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            f'<title>خطا — {safe_url[:60]}</title>'
            '<style>body{font-family:Tahoma,sans-serif;padding:20px;background:#111;color:#eee;line-height:1.8}'
            '.card{background:#1e1e1e;border:1px solid #333;border-radius:12px;padding:16px;max-width:800px;margin:20px auto}'
            '.btn{padding:8px 14px;border-radius:8px;border:0;background:#4f46e5;color:#fff;cursor:pointer;text-decoration:none;display:inline-block;margin:4px}'
            '.btn.ghost{background:#333} code{background:#222;padding:2px 6px;border-radius:6px;direction:ltr}'
            'pre{white-space:pre-wrap;background:#222;padding:10px;border-radius:8px;max-height:40vh;overflow:auto}</style></head><body>'
            '<div class="card"><h2>⚠️ سرور نتوانست صفحه را بگیرد</h2>'
            f'<p>آدرس: <code>{safe_url}</code></p>'
            f'<p>خطا: <code>{safe_err}</code> کد:{res.get("code","")}</p>'
            f'<p>پراکسی سرور: <code>{html.escape(proxy_info[:120])}</code> کوکی آرنا: {cookie_info}</p>'
            '<p>این معمولاً یعنی:</p><ul>'
            '<li>سرور شما در ایران است و <b>arena.ai فیلتر است</b> و پراکسی ندارد</li>'
            '<li>یا <b>arena.ai نیاز به لاگین دارد</b> و کوکی شما به سرور داده نشده</li>'
            '</ul>'
            '<h3>راه‌حل فوری (تو عکس شما):</h3>'
            '<p>خطای <b>«این محتوا مسدود شده است»</b> یعنی <b>X-Frame-Options / CSP</b> جلوی iframe را گرفته. v305 این هدرها را حذف + والد frame-src self را اضافه می‌کند و URLها را بازنویسی می‌کند.</p>'
            '<ol>'
            '<li><b>اگر با VPN خودت arena.ai باز می‌شود:</b> دکمه «🌐 باز کردن مستقیم» را بزن — تو تب جدید با VPN باز میشه، بعد با بوکمارکلت محتوا را برگردون به دستگیر</li>'
            '<li><b>کوکی آرنا را به سرور بده:</b> برو arena.ai لاگین کن، تو کنسول مرورگر (F12) بزن <code>document.cookie</code> و کپی کن، تو دستگیر تو بخش «کوکی آرنا» پیست کن. بعد سرور می‌تونه به جای تو fetch کنه</li>'
            '<li><b>پراکسی روی سرور ست کن:</b> <code>export ARENA_PROXY=http://127.0.0.1:8080</code> سپس <code>sudo systemctl restart bazarche</code></li>'
            '</ol>'
            f'<p><a class="btn" href="{safe_url}" target="_blank">🌐 باز کردن مستقیم {safe_url[:50]}</a> '
            f'<a class="btn ghost" href="/agent/browser?url={urllib.parse.quote(url)}">بازگشت</a> '
            '<button class="btn ghost" onclick="tryClient()">📥 تلاش با مرورگر من (VPN)</button></p>'
            '<div id="clientBox" style="display:none;margin-top:16px"><h4>تلاش کلاینت:</h4><pre id="clientText"></pre><iframe id="clientFrame" style="width:100%;height:50vh;background:#fff;border:0;border-radius:8px"></iframe></div>'
            '</div>'
            '<script>'
            f'var targetUrl={json.dumps(url)};'
            'async function tryClient(){'
            ' var box=document.getElementById("clientBox"); box.style.display="block";'
            ' var txt=document.getElementById("clientText"); txt.textContent="در حال fetch با مرورگر شما (VPN + کوکی شما)...";'
            ' try{'
            '   var r=await fetch(targetUrl,{credentials:"include"});'
            '   var t=await r.text();'
            '   txt.textContent="وضعیت: "+r.status+" طول: "+t.length+"\\n\\n"+t.substring(0,8000);'
            '   var blob=new Blob([t],{type:"text/html"}); var u=URL.createObjectURL(blob);'
            '   document.getElementById("clientFrame").src=u;'
            ' }catch(e){ txt.textContent="خطای کلاینت: "+e+"\\nCORS جلوی خواندن را گرفته — باید از پراکسی سرور یا کوکی استفاده کنی."; }'
            '}'
            '</script></body></html>'
        )
        return {
            "ok": False,
            "body": fallback.encode("utf-8"),
            "content_type": "text/html; charset=utf-8",
            "status": 200,
            "headers": {},
            "error": res.get("error",""),
            "is_html": True,
            "is_fallback": True,
        }

    body = res.get("body", b"")
    ctype = res.get("content_type", "") or ""
    # Decide if HTML
    is_html = _should_proxy_content_type(ctype) or body.lstrip()[:15].lower().startswith(b"<!doctype") or b"<html" in body[:500].lower()
    if is_html:
        # decode
        charset = "utf-8"
        if "charset=" in ctype:
            try:
                charset = ctype.split("charset=")[-1].split(";")[0].strip()
            except:
                pass
        try:
            text = body.decode(charset, errors="ignore")
        except:
            text = body.decode("utf-8", errors="ignore")
        rewritten = rewrite_html(text, url)
        return {
            "ok": True,
            "body": rewritten.encode("utf-8"),
            "content_type": "text/html; charset=utf-8",
            "status": 200,
            "headers": res.get("headers", {}),
            "is_html": True,
        }
    else:
        # Return raw asset, but with content_type preserved
        # Strip blocking headers by not forwarding them — caller will set ALLOWALL
        return {
            "ok": True,
            "body": body,
            "content_type": ctype or "application/octet-stream",
            "status": 200,
            "headers": res.get("headers", {}),
            "is_html": False,
        }

def proxy_page(url: str):
    """Backward compat: returns HTML string"""
    r = proxy_fetch(url)
    try:
        return r["body"].decode("utf-8", errors="ignore")
    except:
        return "<html><body>binary content</body></html>"

def _bridge_path(name="latest.json"):
    return os.path.join(ARENA_DIR, name)

def bridge_load():
    try:
        p = _bridge_path()
        if os.path.exists(p):
            return json.loads(open(p, encoding="utf-8").read()[:200000] or "{}")
    except Exception:
        pass
    return {"url": DEFAULT_ARENA_URL, "messages": [], "files": [], "updated": 0, "proxy": _proxy_env(), "arena_cookie": bool(get_arena_cookie())}

def bridge_save(data):
    try:
        data["updated"] = time.time()
        data["proxy"] = _proxy_env()
        data["arena_cookie"] = bool(get_arena_cookie())
        open(_bridge_path(), "w", encoding="utf-8").write(json.dumps(data, ensure_ascii=False, indent=2)[:500000])
        hist = _bridge_path(f"history-{int(time.time())}.json")
        open(hist, "w", encoding="utf-8").write(json.dumps(data, ensure_ascii=False)[:500000])
        return True
    except Exception:
        return False

def bridge_append_message(role, text, files=None):
    d = bridge_load()
    d.setdefault("messages", []).append({
        "ts": time.time(),
        "role": role,
        "text": text[:8000],
        "files": files or []
    })
    if len(d["messages"]) > 200:
        d["messages"] = d["messages"][-200:]
    bridge_save(d)
    return d

EXCHANGE_DIR = os.path.join(DATA_DIR, "agent-exchange")
os.makedirs(EXCHANGE_DIR, exist_ok=True)

def exchange_list():
    out = []
    try:
        for fn in os.listdir(EXCHANGE_DIR):
            fp = os.path.join(EXCHANGE_DIR, fn)
            if not os.path.isfile(fp):
                continue
            st = os.stat(fp)
            out.append({"name": fn, "size": st.st_size, "mtime": st.st_mtime})
    except Exception:
        pass
    out.sort(key=lambda x: x["mtime"], reverse=True)
    return out[:100]

def exchange_save_file(data: bytes, filename: str):
    import re
    filename = re.sub(r"[^A-Za-z0-9._-]", "_", filename)[:120]
    if not filename:
        filename = f"file-{int(time.time())}.bin"
    fp = os.path.join(EXCHANGE_DIR, filename)
    base, ext = os.path.splitext(filename)
    i = 1
    while os.path.exists(fp):
        fp = os.path.join(EXCHANGE_DIR, f"{base}_{i}{ext}")
        i += 1
        if i > 20:
            break
    open(fp, "wb").write(data[:20_000_000])
    bridge_append_message("system", f"file uploaded: {os.path.basename(fp)} ({len(data)} bytes)", files=[os.path.basename(fp)])
    return {"ok": True, "name": os.path.basename(fp), "size": len(data), "path": f"/agent/file/{urllib.parse.quote(os.path.basename(fp))}"}

def browser_html(s, q):
    url = ""
    if isinstance(q, dict):
        v = q.get("url")
        if isinstance(v, list) and v:
            url = v[0]
        elif isinstance(v, str):
            url = v
    if not url:
        url = DEFAULT_ARENA_URL
    bridge = bridge_load()
    msgs = bridge.get("messages", [])[-30:]
    files = exchange_list()

    msgs_html = ""
    clean = []
    for m in msgs:
        t = (m.get("text","") or "")
        if t.strip().startswith("{") and '"proxy"' in t and '"updated"' in t:
            continue
        if len(t)>400 and t.count('"')>15 and '"role"' in t and '"files"' in t:
            continue
        clean.append(m)
    for m in clean[-20:]:
        role = m.get("role","")
        txt = html.escape(m.get("text","")[:800])
        if len(txt)<2:
            continue
        ts = time.strftime("%H:%M", time.localtime(m.get("ts",0)))
        cls = "user" if role=="user" else "arena" if role=="arena" else "sys"
        msgs_html += f'<div class="msg {cls}"><span class="ts">{ts}</span> <b>{html.escape(role)}</b>: {txt}</div>\n'
    if not msgs_html:
        msgs_html = '<div class="muted">هنوز پیامی نیست — از پایین پیام بده.</div>'

    files_html = ""
    for f in files:
        nm = html.escape(f["name"])
        sz = f["size"]
        qn = urllib.parse.quote(f["name"])
        files_html += f'<div class="file"><a href="/agent/file/{qn}" target="_blank">{nm}</a> <small>{sz}b</small></div>\n'
    if not files_html:
        files_html = '<div class="muted">فایلی نیست.</div>'

    esc_url = html.escape(url)
    proxy_src = "/agent/proxy?url="+urllib.parse.quote(url)
    def_arena_short = html.escape(DEFAULT_ARENA_URL[:60])
    proxy_env = html.escape(_proxy_env() or "بدون پراکسی (مستقیم)")
    has_cookie = bool(get_arena_cookie())
    cookie_status = "✅ دارد" if has_cookie else "❌ ندارد — برای arena.ai لاگین‌دار باید ست کنی"

    # bookmarklet for bridging from arena.ai tab
    bookmarklet_js = """javascript:(function(){var t=document.documentElement.outerHTML.slice(0,8000);var u=location.href;var c=document.cookie;var payload={text:"[from arena tab] "+u+"\\n"+t.slice(0,3000),cookie:c,url:u};var d=prompt("این را کپی کن و تو دستگیر تو بخش کوکی پیست کن:\\n\\n"+c+"\\n\\nیا بگذار اتومات بفرستم به دستگیر؟");if(d!==null){fetch('https://daastgir.ir/api/agent/arena/bridge',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}).then(r=>r.text()).then(x=>alert('فرستاده شد: '+x)).catch(e=>alert('خطا: '+e));}})();"""
    # Note: bookmarklet uses daastgir.ir hardcoded, but we will use relative in actual page via prompt

    page = (
        '<!doctype html>\n<html lang="fa" dir="rtl">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width,initial-scale=1">\n'
        f'<title>مرورگر ایجنت - {esc_url[:40]}</title>\n'
        '<style>\n'
        'body{margin:0;font-family:Tahoma,sans-serif;background:#0f0f0f;color:#eee}\n'
        '.bar{display:flex;gap:8px;padding:10px;background:#1a1a1a;border-bottom:1px solid #333;flex-wrap:wrap;align-items:center}\n'
        '.bar input{flex:1;min-width:240px;padding:8px 10px;border-radius:8px;border:1px solid #444;background:#222;color:#fff;direction:ltr}\n'
        '.btn{padding:8px 12px;border-radius:8px;border:0;background:#4f46e5;color:#fff;cursor:pointer;text-decoration:none;display:inline-block}\n'
        '.btn.ghost{background:#333}\n'
        '.layout{display:grid;grid-template-columns:1fr 360px;gap:0;height:calc(100vh - 52px)}\n'
        '@media(max-width:900px){.layout{grid-template-columns:1fr}}\n'
        '.iframe-wrap{position:relative;background:#fff;display:flex;flex-direction:column}\n'
        '.iframe-wrap iframe{width:100%;height:100%;border:0;background:#fff;flex:1}\n'
        '.side{background:#151515;border-left:1px solid #2a2a2a;display:flex;flex-direction:column;overflow:hidden}\n'
        '.side h3{margin:12px 12px 6px;font-size:14px}\n'
        '.msgs{flex:1;overflow:auto;padding:8px 12px;display:flex;flex-direction:column;gap:6px}\n'
        '.msg{padding:6px 8px;border-radius:8px;background:#222;font-size:13px;line-height:1.6}\n'
        '.msg.user{background:#1e293b}\n'
        '.msg.arena{background:#1a2e1a}\n'
        '.msg.sys{background:#2a2a1a;opacity:.8}\n'
        '.ts{opacity:.6;font-size:11px}\n'
        '.muted{opacity:.6;font-size:12px}\n'
        '.chat-box{padding:10px;border-top:1px solid #333;display:flex;gap:6px}\n'
        '.chat-box textarea{flex:1;padding:8px;border-radius:8px;border:1px solid #444;background:#222;color:#fff;min-height:44px;resize:vertical}\n'
        '.files{padding:8px 12px;max-height:180px;overflow:auto;border-top:1px solid #2a2a2a}\n'
        '.file{font-size:12px;padding:2px 0}\n'
        '.drop{border:2px dashed #444;border-radius:10px;padding:10px;margin:8px 12px;text-align:center;cursor:pointer}\n'
        '.drop.dragover{border-color:#4f46e5;background:#1e1e3a}\n'
        '.alert{padding:10px;border-radius:8px;margin:8px 12px;font-size:12px;line-height:1.7}\n'
        '.alert.warn{background:#3a2a00;border:1px solid #665500}\n'
        '.alert.ok{background:#0a2a12;border:1px solid #1a5a2a}\n'
        'code{background:#222;padding:2px 6px;border-radius:6px;direction:ltr;font-size:11px}\n'
        'input.cookie{width:100%;padding:6px 8px;border-radius:6px;border:1px solid #444;background:#222;color:#fff;direction:ltr;font-size:11px}\n'
        '</style>\n</head>\n<body>\n'
        '<div class="bar">\n'
        '  <span>🌐</span>\n'
        f'  <input id="urlInput" value="{esc_url}" placeholder="https://...">\n'
        '  <button class="btn" onclick="go()">برو</button>\n'
        '  <button class="btn ghost" onclick="openProxy()">تب جدید</button>\n'
        '  <a class="btn ghost" href="/agent" style="text-decoration:none">/agent اصلی</a>\n'
        f'  <span style="margin-left:auto;font-size:11px;opacity:.7">پراکسی: {proxy_env[:40]} | کوکی: {cookie_status[:20]}</span>\n'
        '</div>\n'
        f'<div class="alert ok">✅ v308 — فیکس کامل + راهنمای موبایل (والد CSP frame-src self) «محتوا مسدود شده» — پراکسی + صفحه والد حالا <b>X-Frame-Options</b> و <b>CSP frame-ancestors / frame-src</b> را درست می‌کند (ریشه: والد self را بلاک می‌کرد) و همه URLها را به <code>/agent/proxy?url=...</code> بازنویسی می‌کند تا سایت‌های زنده مثل arena.ai داخل iframe کار کنند. اگر arena.ai لاگین می‌خواهد، کوکی‌ات را پایین ست کن.</div>\n'
        '<div class="layout">\n'
        '  <div class="iframe-wrap">\n'
        f'    <iframe id="arenaFrame" src="{proxy_src}" allow="fullscreen; clipboard-read; clipboard-write; autoplay; camera; microphone; geolocation" referrerpolicy="no-referrer"></iframe>\n'
        '  </div>\n'
        '  <div class="side">\n'
        f'    <h3>💬 پل به آرنا — {def_arena_short}</h3>\n'
        f'    <div class="msgs" id="msgs">{msgs_html}</div>\n'
        '    <div class="chat-box">\n'
        '      <textarea id="chatText" placeholder="پیام به ایجنت خارجی arena.ai ..."></textarea>\n'
        '      <button class="btn" onclick="sendArena()">ارسال</button>\n'
        '    </div>\n'
        '    <div style="padding:8px 12px;border-top:1px solid #333">\n'
        '      <b>🍪 کوکی arena.ai (برای لاگین‌دار):</b><br>\n'
        f'      <div style="font-size:11px;opacity:.7;margin:4px 0">وضعیت: {html.escape(cookie_status)}</div>\n'
        '      <input id="cookieInput" class="cookie" placeholder="document.cookie از تب arena.ai را اینجا پیست کن">\n'
        '      <div style="display:flex;gap:6px;margin-top:6px">\n'
        '        <button class="btn ghost" onclick="saveCookie()">ذخیره کوکی</button>\n'
        '        <button class="btn ghost" onclick="clearCookie()">پاک کردن</button>\n'
        '        <button class="btn ghost" onclick="showHelp()">راهنما</button>\n'
        '      </div>\n'
        '      <div id="cookieHelp" style="display:none;font-size:11px;line-height:1.7;background:#222;padding:8px;border-radius:8px;margin-top:8px">\n'
        '        1) با VPN برو <code>https://arena.ai</code> لاگین کن<br>\n'
        '        2) F12 بزن، تب Console، بنویس <code>document.cookie</code> اینتر، کپی کن<br>\n'
        '        3) اینجا پیست کن و ذخیره بزن — حالا سرور می‌تونه به جای تو arena.ai را بگیرد<br>\n'
        '        4) دوباره «برو» بزن<br>\n'
        '        <br>بوکمارکلت (بکش به بوکمارک بار):<br>\n'
        '        <a id="bmLink" href=\'#\' style="color:#8cf">🔖 ارسال کوکی به دستگیر</a>\n'
        '      </div>\n'
        '    </div>\n'
        '    <div class="drop" id="dropZone">📁 فایل را اینجا رها کن یا کلیک کن<br><small>تبادل با ایجنت خارجی</small><input type="file" id="fileInput" hidden multiple></div>\n'
        f'    <div class="files"><b>فایل‌های تبادل:</b><br>{files_html}</div>\n'
        '    <div style="padding:8px 12px;display:flex;gap:6px;flex-wrap:wrap">\n'
        '      <button class="btn ghost" onclick="loadBridge()">🔄 تازه‌سازی</button>\n'
        '      <button class="btn ghost" onclick="clearBridge()">پاک کردن</button>\n'
        f'      <a class="btn ghost" href="{html.escape(url)}" target="_blank">🌐 مستقیم (VPN)</a>\n'
        '      <button class="btn ghost" onclick="reloadFrame()">🔄 ریلود iframe</button>\n'
        '    </div>\n'
        '  </div>\n'
        '</div>\n'
        '<script>\n'
        'function go(){\n'
        '  var u=document.getElementById("urlInput").value.trim();\n'
        '  if(!u) return;\n'
        '  if(!u.startsWith("http")) u="https://"+u;\n'
        '  document.getElementById("arenaFrame").src="/agent/proxy?url="+encodeURIComponent(u);\n'
        '  history.replaceState(null,"","/agent/browser?url="+encodeURIComponent(u));\n'
        '}\n'
        'function openProxy(){\n'
        '  var u=document.getElementById("urlInput").value.trim();\n'
        '  if(!u.startsWith("http")) u="https://"+u;\n'
        '  window.open("/agent/proxy?url="+encodeURIComponent(u),"_blank");\n'
        '}\n'
        'function reloadFrame(){ document.getElementById("arenaFrame").contentWindow.location.reload(); }\n'
        'document.getElementById("urlInput").addEventListener("keydown",function(e){if(e.key==="Enter") go();});\n'
        'async function sendArena(){\n'
        '  var t=document.getElementById("chatText").value.trim();\n'
        '  if(!t) return;\n'
        '  document.getElementById("chatText").value="";\n'
        '  var msgs=document.getElementById("msgs");\n'
        '  var d=document.createElement("div"); d.className="msg user"; d.innerHTML="<b>you</b>: "+t.replace(/</g,"&lt;"); msgs.appendChild(d); msgs.scrollTop=msgs.scrollHeight;\n'
        '  try{\n'
        '    var r=await fetch("/api/agent/arena",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:t,url:document.getElementById("urlInput").value})});\n'
        '    var j=await r.json();\n'
        '    var d2=document.createElement("div"); d2.className="msg arena"; d2.innerHTML="<b>arena</b>: "+(j.reply||j.text||JSON.stringify(j)).replace(/</g,"&lt;").substring(0,4000); msgs.appendChild(d2); msgs.scrollTop=msgs.scrollHeight;\n'
        '  }catch(e){\n'
        '    var d3=document.createElement("div"); d3.className="msg sys"; d3.textContent="خطا: "+e; msgs.appendChild(d3);\n'
        '  }\n'
        '}\n'
        'async function loadBridge(){\n'
        '  try{\n'
        '    var r=await fetch("/api/agent/arena?latest=1"); var j=await r.json();\n'
        '    var msgs=document.getElementById("msgs"); msgs.innerHTML="";\n'
        '    (j.messages||[]).slice(-30).forEach(function(m){\n'
        '      var div=document.createElement("div"); div.className="msg "+(m.role=="user"?"user":m.role=="arena"?"arena":"sys");\n'
        '      div.innerHTML="<span class=ts>"+new Date(m.ts*1000).toLocaleTimeString()+"</span> <b>"+m.role+"</b>: "+(m.text||"").replace(/</g,"&lt;");\n'
        '      msgs.appendChild(div);\n'
        '    });\n'
        '    msgs.scrollTop=msgs.scrollHeight;\n'
        '  }catch(e){}\n'
        '}\n'
        'async function clearBridge(){\n'
        '  if(!confirm("لاگ پل آرنا پاک شود؟")) return;\n'
        '  await fetch("/api/agent/arena",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:"__clear__"})});\n'
        '  loadBridge();\n'
        '}\n'
        'async function saveCookie(){\n'
        '  var c=document.getElementById("cookieInput").value.trim();\n'
        '  if(!c){ alert("کوکی خالیه"); return; }\n'
        '  try{\n'
        '    var r=await fetch("/api/agent/arena/cookie",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({cookie:c})});\n'
        '    var j=await r.json();\n'
        '    alert(j.ok?"کوکی ذخیره شد — حالا دوباره برو بزن":"خطا: "+j.error);\n'
        '    if(j.ok) location.reload();\n'
        '  }catch(e){ alert("خطا "+e); }\n'
        '}\n'
        'async function clearCookie(){\n'
        '  try{\n'
        '    var r=await fetch("/api/agent/arena/cookie",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({cookie:""})});\n'
        '    var j=await r.json();\n'
        '    alert(j.ok?"پاک شد":"خطا"); if(j.ok) location.reload();\n'
        '  }catch(e){ alert(e); }\n'
        '}\n'
        'function showHelp(){ var h=document.getElementById("cookieHelp"); h.style.display=h.style.display=="none"?"block":"none"; }\n'
        '// bookmarklet\n'
        'document.getElementById("bmLink").href="javascript:(function(){var c=document.cookie;var u=location.href;var p=prompt(\\"کوکی این سایت:\\\\n\\"+c+\\"\\\\n\\\\nآدرس دستگیرت را وارد کن (مثلا https://daastgir.ir):\\",\\"https://daastgir.ir\\");if(!p)return;fetch(p+\\"/api/agent/arena/cookie\\",{method:\\"POST\\",headers:{\\"Content-Type\\":\\"application/json\\"},body:JSON.stringify({cookie:c,url:u})}).then(r=>r.json()).then(j=>alert(j.ok?\\"کوکی به دستگیر فرستاده شد\\":\\"خطا: \\"+j.error)).catch(e=>alert(e));})();";\n'
        'var dz=document.getElementById("dropZone");\n'
        'var fi=document.getElementById("fileInput");\n'
        'dz.addEventListener("click",function(){fi.click();});\n'
        'dz.addEventListener("dragover",function(e){e.preventDefault();dz.classList.add("dragover");});\n'
        'dz.addEventListener("dragleave",function(){dz.classList.remove("dragover");});\n'
        'dz.addEventListener("drop",async function(e){\n'
        '  e.preventDefault();dz.classList.remove("dragover");\n'
        '  var files=e.dataTransfer.files;\n'
        '  await uploadFiles(files);\n'
        '});\n'
        'fi.addEventListener("change",async function(){await uploadFiles(fi.files);});\n'
        'async function uploadFiles(files){\n'
        '  if(!files||!files.length) return;\n'
        '  var fd=new FormData();\n'
        '  for(var i=0;i<files.length;i++) fd.append("file",files[i]);\n'
        '  try{\n'
        '    var r=await fetch("/api/agent/upload",{method:"POST",body:fd});\n'
        '    var j=await r.json();\n'
        '    alert(j.ok?"آپلود شد":"خطا: "+(j.error||""));\n'
        '    location.reload();\n'
        '  }catch(e){alert("خطا "+e);}\n'
        '}\n'
        '</script>\n</body>\n</html>\n'
    )
    return page
