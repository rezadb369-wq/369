# -*- coding: utf-8 -*-
"""v213 «دستیار هوشمند دست گیر» — site-scoped assistant for web + Bale + Soroush.

Design (agreed):
  * The language model NEVER acts. It only maps free text to a closed intent
    JSON ({"intent", "q", "reply"}); every answer is produced here from the
    same read-only helpers the menus already use (search summaries, order
    summaries, plans…). Writes (orders, bookings, registration) are never
    performed by the assistant — it links/hands off to the existing flows,
    which carry their own confirmation steps.
  * Provider-agnostic OpenAI-compatible endpoint. Configured ONLY by env
    (`/etc/dastgir-secrets.env`): AI_BASE_URL, AI_API_KEY, AI_MODEL,
    optional AI_MODEL_SMART, AI_FALLBACK_BASE_URL/AI_FALLBACK_API_KEY/
    AI_FALLBACK_MODEL, AI_TIMEOUT. The key is never logged, rendered or
    serialised (see `public_config`).
  * Rule-based first: obvious requests («سفارش‌های من», «ثبت کسب‌وکار», …)
    are answered with zero model calls. The model is consulted only for
    ambiguous text, and when it is missing/failing/over budget the rules
    still answer — the assistant degrades, never disappears.
  * Daily quota per person: 5 (no plan) / 20 (حرفه‌ای = plus) / 50
    (ویژهٔ دست گیر = pro), admin-adjustable in /panel/assistant, plus a
    global daily cap that bounds the monthly bill.
"""
import os, re, json, sys, time, datetime, threading, urllib.parse, urllib.request, urllib.error
import db
import adminbot_content   # v239: admin copilot content tools
import adminbot_code as CODE  # v246: autopilot lane (server-driven agent)
# v222: Jalali conversion shared with the site (same pattern as ui.py).
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(_HERE, "..", "tools"))
from layout import g2j

SITE = "https://daastgir.ir"
VERSION = 217

# ------------------------------------------------------------------ config
def _env(name, default=""):
    return (os.environ.get(name) or default).strip()


# v263 (دستور مدیر: ۴ مغز + سوئیچ /مغز): هر مغز کلید خودش را دارد —
# (base, env-slot کلید, model). شناسه‌ها کلمه‌به‌کلمهٔ مستند AvalAI.
_BRAIN_AVALAI = "https://api.avalai.ir/v1"
BRAINS = {
    "opus": (_BRAIN_AVALAI, "AI_BRAIN_OPUS_KEY", "claude-opus-5"),
    "sonnet": (_BRAIN_AVALAI, "AI_BRAIN_SONNET_KEY", "claude-sonnet-5"),
    "haiku": (_BRAIN_AVALAI, "AI_BRAIN_HAIKU_KEY", "claude-haiku-4-5"),
    "openrouter": ("https://openrouter.ai/api/v1", "AI_BRAIN_OR_KEY",
                   "nvidia/nemotron-3-ultra-550b-a55b:free"),
    # v273 (دستور مدیر: «تمام توکن‌ها از AvalAI می‌گیرم؛ کیرا کلا حذف بشه؛
    # کلید GLM فقط برای پنل مدیریتی و از بات قابل تنظیم باشه»):
    # مغز پنجم = GLM-5.3-Flash روی AvalAI با اسلات اختصاصی AI_BRAIN_GLM_KEY.
    "glm": (_BRAIN_AVALAI, "AI_BRAIN_GLM_KEY", "glm-5.3-flash"),
}
BRAIN_FA = {"opus": "اپوس ۵", "sonnet": "سونت ۵", "haiku": "هایکو ۴.۵",
            "openrouter": "اوپن‌روتر (رایگان)", "glm": "GLM ۵.۳ فلش"}
# v273: خانوادهٔ GLM روی AvalAI (شناسه‌های مستند docs.avalai.ir)؛
# سوئیچ با /مدل و تست زندهٔ قبل از سوئیچ، مثل همیشه. [0] = پیش‌فرض.
GLM_MODELS = ("glm-5.3-flash", "glm-5.3", "glm-5.2", "glm-5.1",
              "glm-5-turbo")


def active_brain():
    """v263→v266: کدام‌یک از ۵ مغز فعال است (تنظیمات سایت، پیش‌فرض sonnet).
    هر چیز غیر از ۴ نام یعنی مغز دستی (نصب خارجی با /کلید)."""
    try:
        b = (db.get_settings().get("ai_brain_active") or "sonnet").strip().lower()
    except Exception:
        b = "sonnet"
    return b if b in BRAINS else "custom"


# v310 (دستور مدیر): «بخش ایجنت مغز ایجنت بشه تغییر داد» — اوراید مغز به‌ازای
# هر درخواست (thread-local چون سرور ThreadingHTTPServer است). چیپ‌های کنسول
# ایجنت مغز همان پیام را انتخاب می‌کنند بدون اینکه مغز سراسری مدیر (/مغز)
# عوض شود؛ سوئیچ خودکار/یدک همچنان ممنوع است (فقط انتخاب صریح مدیر).
_BRAIN_TL = threading.local()


def set_brain_override(name):
    """فقط نام‌های معتبر ۵ مغز پذیرفته می‌شوند؛ بقیه یعنی «مغز فعال»."""
    try:
        n = (name or "").strip().lower()
        _BRAIN_TL.name = n if n in BRAINS else ""
    except Exception:
        pass


def clear_brain_override():
    try:
        _BRAIN_TL.name = ""
    except Exception:
        pass


def brain_override():
    try:
        return getattr(_BRAIN_TL, "name", "") or ""
    except Exception:
        return ""


def config():
    """Live snapshot. v263: اگر کلید مغز فعال در env باشد، همان مغز
    جواب می‌دهد (SMART هم همان است، چون هر مدل کلید خودش را دارد)؛
    وگرنه شکاف‌های قدیمی (نصب دستی/خارجی)."""
    timeout = max(3.0, min(40.0, float(_env("AI_TIMEOUT", "12") or 12)))
    # v310: اوراید هر-درخواست (چیپ مغز در کنسول ایجنت) بر تنظیم سراسری مقدم است
    brain = brain_override() or active_brain()
    bkey = _env(BRAINS[brain][1]) if brain in BRAINS else ""
    if brain in BRAINS and bkey:
        _bb, _, _bm = BRAINS[brain]
        if brain == "glm":
            # v268→v273: the 5th-brain model is switchable (/مدل) — any id the
            # owner picked (live-tested at switch time); default = BRAINS row.
            # تنظیم قدیمی ai_brain_kira_model هم یک‌بار خوانده می‌شود (مهاجرت).
            _bm = ((db.get_settings().get("ai_brain_glm_model")
                    or db.get_settings().get("ai_brain_kira_model")
                    or "").strip() or _bm)
        # v265 (owner order — no automatic switch, ever): the fb slots stay
        # empty, so no call site can answer from another brain. Only the
        # owner's own «مغز» changes which brain answers.
        return {
            "base_url": _bb,
            "api_key": bkey,
            "model": _bm,
            "model_smart": _bm,
            "brain": brain,
            "brain_custom": False,
            "fb_base_url": "",
            "fb_api_key": "",
            "fb_model": "",
            "timeout": timeout,
        }
    base = _env("AI_BASE_URL").rstrip("/")
    return {
        "base_url": base,
        "api_key": _env("AI_API_KEY"),
        "model": _env("AI_MODEL", "gemini-2.5-flash-lite"),
        "model_smart": _env("AI_MODEL_SMART"),
        "brain": "custom",
        "brain_custom": True,
        # v265: legacy AI_FALLBACK_* is honored no more (same owner order).
        "fb_base_url": "",
        "fb_api_key": "",
        "fb_model": "",
        "timeout": timeout,
    }


def configured():
    c = config()
    return bool(c["base_url"] and c["api_key"] and c["model"])


# v269 (دستور مدیر: «هوش مصنوعی‌های پنل من جدا باشن؛ محیطشون فقط برای منه و
# به هوش مصنوعی سایت اصلا مربوط نباشه»): هوش عمومی سایت (چت کاربران) اسلات
# مستقل خودش را دارد (AI_SITE_*) — هیچ اشتراکی با ۵ مغز مدیر (/مغز) ندارد.
# اگر کلید سایت وصل نباشد، کاربران همان پاسخ قاعده‌مند + کش رایگان را
# می‌گیرند (هزینه صفر) — هرگز از مغزهای مدیر جواب نمی‌آید.
SITE_DEFAULT_BASE = "https://api.avalai.ir/v1"
SITE_DEFAULT_MODEL = "glm-5.3-flash"   # شناسهٔ رسمی Z.AI (GLM-5.3-Flash)


def site_config():
    """v269: اسلات هوش عمومی سایت — env برای base/key، و مدل قابل سوئیچ
    بدون ری‌استارت از تنظیم ai_site_model (دستور «مدل سایت» در بات مدیر)."""
    timeout = max(3.0, min(40.0, float(_env("AI_TIMEOUT", "12") or 12)))
    try:
        model = (db.get_settings().get("ai_site_model") or "").strip()
    except Exception:
        model = ""
    model = model or _env("AI_SITE_MODEL") or SITE_DEFAULT_MODEL
    # v269: هوش سایت تک‌مدل است (مدل قوی پرمصرف = هزینه؛ لایهٔ smart فقط
    # مال محیط مدیر است) — model_smart عمداً خالی می‌ماند.
    return {"base_url": (_env("AI_SITE_BASE_URL") or SITE_DEFAULT_BASE).rstrip("/"),
            "api_key": _env("AI_SITE_API_KEY"),
            "model": model, "model_smart": "",
            "brain": "site", "timeout": timeout}


def site_configured():
    c = site_config()
    return bool(c["base_url"] and c["api_key"] and c["model"])


def site_public_config():
    """What the admin panel may show about the SITE (public) AI. Key → bool."""
    c = site_config()
    return {"base_url": c["base_url"], "model": c["model"],
            "has_key": bool(c["api_key"]), "timeout": c["timeout"]}


def public_config():
    """What the admin panel may show. The key is reduced to a boolean."""
    c = config()
    return {"base_url": c["base_url"], "model": c["model"],
            "model_smart": c["model_smart"], "has_key": bool(c["api_key"]),
            "brain": c.get("brain", "custom"),
            "fallback": bool(c["fb_base_url"] and c["fb_api_key"] and c["fb_model"]),
            "fallback_model": c["fb_model"], "timeout": c["timeout"]}


def enabled():
    s = db.get_settings()
    return s.get("ai_enabled", "1") == "1"


def is_guest(ctx):
    """v259 (دستور مدیر: توکن فقط برای پنل کاربری و مدیرتیم): مهمان یعنی
    نه مشتری واردشده و نه مالک — این‌ها مدل را صدا نمی‌زنند (هزینهٔ توکن
    صفر) و فقط پاسخ قاعده‌مند + کش رایگان می‌گیرند."""
    try:
        return not (ctx.get("customer") or ctx.get("owner"))
    except Exception:
        return True


def guest_model_allowed():
    """v259: سوییچ پنل برای مدل مهمان‌ها. پیش‌فرض بسته (دستور مدیر) ۰
    یعنی خاموش — مدیر می‌تواند از /panel/assistant روشنش کند."""
    try:
        return db.get_settings().get("ai_guest_model", "0") == "1"
    except Exception:
        return False


# ------------------------------------------------------------------ quota
PLAN_SLUG_TIER = {"plus": "plus", "pro": "pro"}     # seeded slugs (db.DEFAULT_PLANS)


def _tier_from_sub(sub):
    """v281: هر اشتراک زنده باید سطح واقعی‌اش را بدهد — هرگز «رایگان».
    اسلاگ‌های سفارشی/ناسشناخته هم با نام پلن یا قیمت/امکانات پلن نگاشت
    می‌شوند تا کاربرِ دارای اشتراک فعال، «بدون اشتراک» دیده نشود."""
    slug = (sub.get("plan_slug") or "").strip()
    if slug in PLAN_SLUG_TIER:
        return PLAN_SLUG_TIER[slug]
    blob = (slug + " " + (sub.get("planname") or "")).lower()
    if "pro" in blob or "ویژه" in blob:
        return "pro"
    if "plus" in blob or "حرفه" in blob:
        return "plus"
    try:
        p = db.plan(slug=slug) if slug else None
    except Exception:
        p = None
    if p and (int(p.get("price") or 0) > 0 or (p.get("feats") or "").strip()):
        return "plus"
    return "plus"      # اشتراک زندهٔ بدون پلن قابل شناسایی هم رایگان نیست


def _int_setting(s, key, default):
    try:
        return max(0, int(str(s.get(key, default) or default)))
    except (TypeError, ValueError):
        return default


def tier_of(customer=None, owner=None):
    """Highest live plan among the person's businesses → 'free'|'plus'|'pro'.
    Owner is derived from the customer phone when only a customer is known
    (same rule as bot_menu._owner_account)."""
    o = owner
    if not o and customer and customer.get("phone"):
        try:
            o = db.owner_by_phone(customer.get("phone") or "", create=False)
        except Exception:
            o = None
    if not o or o.get("status") == "blocked":
        return "free"
    best = "free"
    try:
        for b in db.businesses_of(o["id"]):
            sub = db.subscription_of(b["id"])
            if not sub:
                continue
            t = _tier_from_sub(sub)
            if t == "pro":
                return "pro"
            if t == "plus":
                best = "plus"
    except Exception:
        pass
    return best


TIER_LABEL = {"free": "بدون اشتراک", "plus": "اشتراک حرفه‌ای", "pro": "اشتراک ویژهٔ دست گیر"}


def plan_ai_quota(customer=None, owner=None):
    """v285: ai_daily of the person's best live plan, or -1 when no plan
    overrides the tier default."""
    o = owner
    if not o and customer and (customer.get("phone") or ""):
        try:
            o = db.owner_by_phone(customer["phone"], create=False)
        except Exception:
            o = None
    if not o:
        return -1
    best = -1
    try:
        for b in db.businesses_of(o["id"]):
            sub = db.subscription_of(b["id"])
            if not sub:
                continue
            pl = db.plan(slug=(sub.get("plan_slug") or ""))
            if not pl or pl["ai_daily"] is None:
                continue
            v = int(pl["ai_daily"])
            if v >= 0:
                best = max(best, v)
    except Exception:
        pass
    return best


def quota_for(tier, customer=None, owner=None):
    s = db.get_settings()
    base = {"free": _int_setting(s, "ai_quota_free", 5),
            "plus": _int_setting(s, "ai_quota_plus", 20),
            "pro": _int_setting(s, "ai_quota_pro", 50)}.get(tier, 5)
    pq = plan_ai_quota(customer, owner)      # v285: plan override wins
    return pq if pq >= 0 else base


def _today():
    return datetime.date.today().isoformat()


def usage_today(user_key):
    r = db._one("SELECT n FROM ai_usage WHERE day=? AND user_key=?", (_today(), user_key))
    return int(r["n"]) if r else 0


def quota_used_today(user_key):
    """v219: model-backed answers today — the only thing the quota counts."""
    try:
        r = db._one("SELECT q FROM ai_usage WHERE day=? AND user_key=?", (_today(), user_key))
    except Exception:
        return 0
    return int(r["q"]) if r else 0


def global_quota_today():
    """v219: site-wide model-backed answers today (what the daily cap gates)."""
    try:
        r = db._one("SELECT COALESCE(SUM(q),0) q FROM ai_usage WHERE day=?", (_today(),))
    except Exception:
        return 0
    return int(r["q"]) if r else 0


def global_cap():
    return _int_setting(db.get_settings(), "ai_daily_cap", 2000)


def remaining(user_key, tier):
    return max(0, quota_for(tier) - quota_used_today(user_key))


def person_used(customer=None, owner=None, user_key=None):
    """v285: مصرف واقعی «شخص» — جمع هر دو هویت او (مشتری و مالک).

    یک نفر ممکن است با هویت مشتری چت کند (کلید cust:N) و بعد در پنل
    مالک (کلید owner:M) سهمیه را ببیند؛ نمایش و اجرای سهمیه باید هر دو
    مصرف را با هم ببینند تا عدد «دقیق» باشد. ناشناس‌ها روی همان user_key
    می‌مانند."""
    keys = set()
    if customer:
        keys.add(f"cust:{customer['id']}")
    if owner:
        keys.add(f"owner:{owner['id']}")
    try:
        if owner and not customer and (owner.get("phone") or ""):
            c = db.customer_by_phone(owner["phone"], create=False)
            if c:
                keys.add(f"cust:{c['id']}")
        if customer and not owner and (customer.get("phone") or ""):
            o = db.owner_by_phone(customer["phone"], create=False)
            if o:
                keys.add(f"owner:{o['id']}")
    except Exception:
        pass
    if user_key:
        keys.add(user_key)   # v285: هر مصرفی با کلید خام همان شخص هم شمرده شود
    return sum(quota_used_today(k) for k in keys)


def person_remaining(customer=None, owner=None, user_key=None):
    tier = tier_of(customer, owner)
    quota = quota_for(tier, customer, owner)
    return max(0, quota - person_used(customer, owner, user_key)), tier


def _count(user_key, channel, llm_calls, tokens, intent, quota=0, smart=0):
    """v219: quota=1 only for model-written answers; rule answers bump n."""
    day = _today()
    con = db.connect()
    con.execute("INSERT INTO ai_usage(day,user_key,channel,n,llm_calls,tokens,q,smart_calls) VALUES(?,?,?,1,?,?,?,?) "
                "ON CONFLICT(day,user_key) DO UPDATE SET n=n+1, llm_calls=llm_calls+excluded.llm_calls, "
                "tokens=tokens+excluded.tokens, q=q+excluded.q, smart_calls=smart_calls+excluded.smart_calls, "
                "channel=excluded.channel",
                (day, user_key, channel, int(llm_calls), int(tokens), int(quota), int(smart)))
    con.execute("INSERT INTO ai_intents(day,intent,n) VALUES(?,?,1) "
                "ON CONFLICT(day,intent) DO UPDATE SET n=n+1", (day, intent[:32]))
    con.commit(); con.close()


def stats(days=30):
    """Admin projection: totals for today / 7d / N days + intent mix."""
    today = datetime.date.today()
    def since(n):
        d = (today - datetime.timedelta(days=n - 1)).isoformat()
        r = db._one("SELECT COALESCE(SUM(n),0) n, COALESCE(SUM(llm_calls),0) llm, "
                    "COALESCE(SUM(tokens),0) tok, COUNT(DISTINCT user_key) users, "
                    "COALESCE(SUM(smart_calls),0) smart "
                    "FROM ai_usage WHERE day>=?", (d,))
        return {"n": int(r["n"]), "llm": int(r["llm"]), "tokens": int(r["tok"]), "users": int(r["users"]),
                "smart": int(r["smart"])}
    d30 = (today - datetime.timedelta(days=days - 1)).isoformat()
    intents = db._rows("SELECT intent, SUM(n) n FROM ai_intents WHERE day>=? "
                       "GROUP BY intent ORDER BY n DESC LIMIT 12", (d30,))
    daily = db._rows("SELECT day, SUM(n) n, SUM(llm_calls) llm FROM ai_usage WHERE day>=? "
                     "GROUP BY day ORDER BY day DESC LIMIT 14", (d30,))
    return {"today": since(1), "week": since(7), "month": since(days),
            "intents": intents, "daily": daily}


# ------------------------------------------------------------------ knowledge
# Grounding facts the model may paraphrase. Anything outside this + live data
# is off-topic by contract.
KNOWLEDGE = [
    ("دست گیر چیست؟", "دست گیر (daastgir.ir) راهنمای محلی کسب‌وکارهای شهر است: جست‌وجوی مغازه و خدمات، کسب‌وکارهای نزدیک شما روی نقشه، محصولات و قیمت‌ها، پیشنهادهای روز، سفارش و نوبت آنلاین، رویدادهای شهر، و صفحهٔ اختصاصی برای هر کسب‌وکار. ثبت کسب‌وکار همیشه رایگان است."),
    ("جست‌وجو", "در صفحهٔ /businesses با نام کسب‌وکار، صنف، محصول یا محله جست‌وجو می‌کنید؛ فیلتر دسته، «الان باز»، مرتب‌سازی (ویژه/امتیاز/جدید) دارد. دسته‌بندی کامل در /categories."),
    ("نزدیک من", "صفحهٔ /nearby با اجازهٔ موقعیت، کسب‌وکارهای بازِ اطراف را با فاصله و مسیر نشان می‌دهد؛ نقشهٔ کامل شهر در /map. موقعیت ذخیره نمی‌شود."),
    ("صفحهٔ کسب‌وکار", "هر کسب‌وکار در /b/<slug> دارد: معرفی، نشانی و مسیر، ساعت کاری زنده (باز/بسته)، تلفن (اگر عمومی باشد)، گالری، کاتالوگ محصولات/خدمات با قیمت، نظرات و امتیاز چندمعیاره، پرسش‌وپاسخ، دکمهٔ ذخیره (قلب)، دنبال‌کردن، رزرو نوبت و سفارش (اگر فعال باشد)، و پیام به دکان‌دار."),
    ("ثبت کسب‌وکار", "رایگان است. از /register-business مرحله‌به‌مرحله: دسته ← معرفی ← مکان (استان/شهر/محله/نقشه) ← تماس ← ساعت کاری ← تا ۶ عکس ← پیش‌نمایش و تأیید. ورود به حساب فقط با بله یا سروش انجام می‌شود (دکمهٔ «ورود با …»؛ بدون رمز و بدون پیامک). پس از تأیید مدیر منتشر می‌شود (معمولاً کمتر از یک روز کاری). در بات بله/سروش هم با /register_business می‌شود."),
    ("تصاحب کسب‌وکار موجود", "اگر کسب‌وکارتان از قبل در سایت هست، وارد شوید و از /my/claim درخواست دهید؛ اگر شمارهٔ ثبت‌شده با شمارهٔ شما یکی باشد فوراً وصل می‌شود، وگرنه مدیر بررسی می‌کند."),
    ("پنل دکان‌دار", "در /my: کسب‌وکارهای من (ویرایش، گالری، کاتالوگ، ساعت کاری، پنهان/نمایش، حذف)، سفارش‌ها و تغییر وضعیت، نوبت‌ها، پیام‌ها، نظرات و پاسخ به آن‌ها، پرسش‌ها، استوری ۲۴ ساعته، پیشنهاد روز، فراخوان به دنبال‌کننده‌ها، آمار بازدید و تماس، اشتراک (/my/plan) و تیکت پشتیبانی."),
    ("سفارش آنلاین", "در کسب‌وکارهایی که کاتالوگ فعال دارند، کالا را به سبد اضافه و سفارش ثبت می‌کنید (پرداخت حضوری/کارت‌به‌کارت طبق توافق با دکان‌دار؛ سایت پول نمی‌گیرد). پیگیری در /me/orders؛ لغو مستقیم تا مدت محدود، بعد از آن با تأیید دکان‌دار. اعلان وضعیت در سایت و بات."),
    ("نوبت آنلاین", "کسب‌وکارهایی که نوبت‌دهی را روشن کرده‌اند دکمهٔ «رزرو نوبت» دارند؛ نوبت‌های شما در /me قابل مشاهده و لغو (با تأیید دوم) است."),
    ("حساب مشتری", "ورود در /login فقط با بله یا سروش (بدون رمز و بدون پیامک). در /me: سفارش‌ها، نوبت‌ها، علاقه‌مندی‌ها (/me/favorites)، دنبال‌شده‌ها، گفت‌وگو با دکان‌داران، اعلان‌ها، اتصال به بات بله/سروش، خروجی داده و حذف حساب."),
    ("پلن‌ها و تعرفه", "پلن پایه رایگان و دائمی است. «حرفه‌ای»: نشان ویژه و بالاتر بودن در فهرست، تا ۶۰ محصول و ۲۰ تصویر، آمار، پاسخ به نظرات، رزرو، پرسش‌وپاسخ. «ویژهٔ دست گیر»: همهٔ امکانات + جایگاه ثابت صفحهٔ نخست، بنر، ۳۰۰ محصول، پشتیبانی مستقیم. قیمت‌ها در /pricing؛ خرید از /my/plan با کارت‌به‌کارت و تأیید مدیر. سهمیهٔ دستیار هوشمند: پایه ۵، حرفه‌ای ۲۰، ویژه ۵۰ پیام در روز."),
    ("پیشنهاد روز و استوری", "پیشنهادهای زمان‌دار کسب‌وکارها در /deals؛ استوری‌های ۲۴ ساعته در صفحهٔ نخست و صفحهٔ هر کسب‌وکار."),
    ("مقایسهٔ قیمت", "در /prices (اگر فعال باشد) قیمت یک کالا را بین کسب‌وکارهای شهر مقایسه می‌کنید و برای کاهش قیمت هشدار می‌گیرید. محصولات همهٔ شهر در /catalog."),
    ("رویدادها و اخبار", "رویدادهای شهر در /events و اخبار/مقالات در /blog. برترین‌های شهر (فهرست‌های منتخب) در /lists."),
    ("نظرات و امتیاز", "نظر فقط با حساب کاربری؛ امتیاز چندمعیاره (کیفیت، قیمت، سرعت، برخورد، نوبت‌دهی) بر اساس امکانات هر کسب‌وکار. نظرات پیش از انتشار بررسی می‌شوند و دکان‌دار می‌تواند پاسخ دهد. گزارش تخلف در هر صفحه هست."),
    ("پشتیبانی", "پشتیبانی فقط از مسیر تیکت (/my/tickets پس از ورود) تا پاسخ گم نشود و وضعیت رسیدگی معلوم باشد. دست گیر هیچ‌وقت رمز، کد پیامکی یا اطلاعات کارت نمی‌پرسد."),
    ("بات‌های پیام‌رسان", "بات رسمی دست گیر در بله و سروش‌پلاس: از /me حساب را وصل می‌کنید؛ دستورها: /search، /near (ارسال موقعیت)، /orders، /bookings، /favorites، /notifications، /register_business، /owner و هر متن آزاد به همین دستیار می‌رسد. رسید سفارش زنده در بات به‌روز می‌شود."),
    ("حریم خصوصی", "شمارهٔ شما به کسب‌وکارها نشان داده نمی‌شود مگر خودتان در سفارش اجازه دهید؛ گفت‌وگو با دکان‌دار بدون شماره است. موقعیت مکانی فقط برای همان جست‌وجو استفاده می‌شود. خروجی و حذف کامل داده از /me/account."),
    ("اعلان‌ها", "اعلان سفارش، نوبت، پاسخ نظر و موجودشدن کالا در مرکز اعلان سایت، اعلان گوشی (وب‌پوش) و بات‌ها؛ تنظیم دسته‌ها در /me/notif-settings."),
    ("ساعت کاری", "ساعت کاری را خود دکان‌دار در پنل ثبت می‌کند و در صفحهٔ هر کسب‌وکار زنده نشان داده می‌شود (🟢 باز / 🔴 بسته بر اساس ساعت امروز). در /businesses می‌توانید فیلتر «الان باز» را روشن کنید تا فقط کسب‌وکارهای بازِ همین لحظه بیایند. اگر ساعتی ثبت نشده باشد، هیچ حدسی زده نمی‌شود."),
    ("نقشه و مسیریابی", "نقشهٔ کامل کسب‌وکارهای شهر در /map است؛ در صفحهٔ هر کسب‌وکار هم نشانی، جای دقیق روی نقشه و دکمهٔ مسیریابی هست. برای نصب روی ویترین، QR اختصاصی در /qr/<slug>.svg و کارت ویزیت دیجیتال در /vcard/<slug> ساخته می‌شود."),
    ("دسته‌بندی، شهرها و محله‌ها", "فهرست کامل صنف‌ها در /categories، شهرها در /cities و محله‌ها در /areas است. با /businesses?cat=<دسته> یا ?city=<شهر> هم می‌توانید مستقیم فیلتر کنید. صفحهٔ هر محله در /area/<نام محله> کسب‌وکارهای همان محله را نشان می‌دهد."),
    ("چانه‌زنی", "اگر دکان‌دار «چانه‌زنی» را برای کالا روشن کرده باشد، در صفحهٔ کالا دکمهٔ پیشنهاد قیمت هست؛ پیشنهاد شما در یک رشتهٔ گفت‌وگو (پذیرش / رد / پیشنهاد متقابل) جلو می‌رود. قیمت کف دستیار هیچ‌وقت به خریدار نشان داده نمی‌شود."),
    ("پرداخت", "خود سایت هیچ پولی دریافت نمی‌کند: پرداخت سفارش طبق توافق با دکان‌دار (حضوری یا کارت‌به‌کارت) انجام می‌شود. تنها پرداخت سایت، اشتراک کسب‌وکار در /my/plan است که با کارت‌به‌کارت و ثبت فیش و کد پیگیری و تأیید مدیر انجام می‌شود."),
    ("ارسال و تحویل", "شیوهٔ ارسال روی هر کالا ثبت می‌شود (پیک، پست، تحویل حضوری) و در صفحهٔ کالا دیده می‌شود. سایت خودش لجستیک ندارد؛ هماهنگی نهایی با دکان‌دار است و وضعیت سفارش در /me/orders به‌روز می‌شود."),
    ("بازگشت و ضمانت", "کالاهایی که دکان‌دار «قابل بازگشت» یا گارانتی را برایشان ثبت کرده باشد، در صفحهٔ کالا با همین برچسب‌ها نشان داده می‌شوند. شرایط بازگشت را پیش از خرید از دکان‌دار بپرسید؛ اگر اختلافی پیش آمد، از /my/tickets تیکت بزنید تا مدیر رسیدگی کند."),
    ("حذف حساب و داده‌ها", "در /me/account هم خروجی کامل داده‌هایتان را می‌گیرید و هم حذف حساب را درخواست می‌دهید. حذف کسب‌وکار توسط دکان‌دار از /my/businesses انجام می‌شود و تا ۳۰ روز در سطل بازیافت قابل برگرداندن است."),
    ("امنیت و کلاهبرداری", "دست گیر هیچ‌وقت رمز، کد ورود، اطلاعات کارت یا فیش را در چت یا تلفن نمی‌پرسد. ورود فقط با دکمهٔ رسمی بله یا سروش است. هر صفحه دکمهٔ گزارش تخلف دارد و مسیر رسمی شکایت، تیکت پشتیبانی است."),
    ("دستیار هوشمند و هوش آفلاین", "دو مغز دارید: «هوش آفلاین» نامحدود و رایگان است و از دانش خود سایت و داده‌های زنده جواب می‌دهد؛ «هوش اختصاصی دست گیر» مدل زبانی است که سهمیهٔ روزانه دارد (پایه ۵، حرفه‌ای ۲۰، ویژه ۵۰ پاسخ). از بالای صفحهٔ چت هر وقت خواستید بین این دو سوییچ کنید؛ با تمام‌شدن سهمیه، خودکار روی هوش آفلاین می‌مانید و چیزی قطع نمی‌شود."),
    ("حافظهٔ گفت‌وگو", "هر گفت‌وگو ۱۰ دقیقه روی سرور نگه داشته می‌شود تا سؤال‌های پیگیری («تلفنش؟»، «اون یکی چی؟») را با همان کسب‌وکار قبلی جواب دهم. با رفرش صفحه هم گفت‌وگو سر جایش می‌ماند و فقط بعد از پایان همان ۱۰ دقیقه پاک می‌شود."),
    ("آمار برای دکان‌دار", "در /my/stats/<شناسهٔ کسب‌وکار> بازدید صفحه، تماس‌ها، مسیرها، ذخیره‌ها و جست‌وجوهایی که به دکان رسیده را می‌بینید. آمار فقط برای مالک همان کسب‌وکار و مدیر سایت است."),
    ("فراخوان و دنبال‌کردن", "مشتری می‌تواند دکان را دنبال کند؛ دکان‌دارِ دارای اشتراک می‌تواند «فراخوان» بفرستد (خبر تازه، موجودشدن کالا) که به دنبال‌کننده‌ها می‌رسد. درخواست «موجود شد» هم از صفحهٔ کالا ثبت می‌شود."),
    ("اپ و نصب روی گوشی", "سایت نصب‌شدنی است: در مرورگر گوشی «افزودن به صفحهٔ اصلی» را بزنید تا مثل اپ باز شود. نسخهٔ آفلاین سبک هم دارد؛ هیچ اپ فروشیگاهی جداگانه‌ای لازم نیست."),
    ("قوانین محتوا", "قوانین کامل در /rules است: اطلاعات واقعی و قابل تأیید، بدون محتوای غیرقانونی یا تکراری. ثبت کسب‌وکار پیش از انتشار توسط مدیر بررسی می‌شود و موارد تخلفی پنهان یا حذف می‌شوند."),
    ("دست گیر در کدام شهرها", "دست گیر شهر-محور است: هر نصب، راهنمای کسب‌وکارهای یک شهر/منطقه است و فهرست شهرها در /cities دیده می‌شود. ثبت کسب‌وکار برای هر شهری که مدیر سایت پوشش می‌دهد رایگان است."),
]


def faqs():
    """Active (q, a) knowledge pairs from the ai_faq table (v218).

    First use seeds the table from the built-in KNOWLEDGE list above. When
    every row is muted by the admin an empty list is returned (respected);
    only a DB failure falls back to the built-in list.
    """
    try:
        rows = db.ai_faq_list(active_only=True)
        if rows:
            return [(r["q"], r["a"]) for r in rows]
        if db.ai_faq_list(active_only=False):
            return []
        db.ai_faq_seed([(q, a) for q, a in KNOWLEDGE])
        rows = db.ai_faq_list(active_only=True)
        return [(r["q"], r["a"]) for r in rows] or list(KNOWLEDGE)
    except Exception:
        return list(KNOWLEDGE)


def _knowledge_pool():
    """v274 (دستور مدیر): دانش در دسترسِ مغز آفلاین = ردیف‌های فعال (ویرایش مدیر)
    + فهرست داخلی که هنوز در جدول نیست. ردیف هم‌نامِ مدیر برنده است؛ اگر مدیر
    عمداً همهٔ ردیف‌ها را خاموش کرده باشد (faqs()==[] با جدول پُر) همان سکوت
    محترم شمرده می‌شود و چیزی تزریق نمی‌شود."""
    rows = faqs()
    if not rows:
        return rows
    have = {q.strip() for q, _ in rows}
    return rows + [(q, a) for q, a in KNOWLEDGE if q.strip() not in have]


# ------------------------------------------------------------------ v274
# «هوش آفلاین» (دستور مدیر): نامحدود و رایگان، پس باید واقعاً آموزش‌دیده باشد.
# این لایه فقط در مسیر قاعده‌مند/آفلاین مشاوره می‌شود (compose برای unknown/
# off_topic و وقتی _faq_answer جفتی پیدا نکند) — مسیر مدل و INTENTS دست‌نخورده
# می‌مانند تا رفتار هوش اختصاصی عوض نشود. ترتیب مهم است: اولین تطبیق برنده.
_OFFLINE_TOPICS = [
    ("delete_biz", r"حذف\s*(کسب|مغازه|دکان|کسب‌?وکار)|پاک\s*کردن\s*(کسب|مغازه|دکان)",
     "حذف کسب‌وکار از پنل دکان‌دار (/my/businesses) انجام می‌شود و برای اطمینان باید نام کسب‌وکار را دقیق بنویسید. تا ۳۰ روز در سطل بازیافت می‌ماند و قابل برگرداندن است.",
     [("پنل کسب‌وکار", "/my"), ("بازیابی فایل‌ها", "/my/trash")]),
    ("edit_biz", r"ویرایش|تغییر\s*(اطلاعات|نشانی|آدرس|تلفن|ساعت|عکس)|عوض\s*کردن",
     "ویرایش نام، دسته، نشانی، ساعت کاری، عکس‌ها و کاتالوگ در «کسب‌وکارهای من» است. اگر مدیر «تأیید تغییرات» را روشن کرده باشد، ویرایش شما صف می‌شود و پس از تأیید اعمال می‌شود.",
     [("کسب‌وکارهای من", "/my/businesses"), ("گالری", "/my")]),
    ("memory", r"حافظه|یادت|یادته|فراموش|ده\s*دقیقه|۱۰\s*دقیقه|رفرش|تازه\s*کردن\s*صفحه",
     "گفت‌وگوی شما ۱۰ دقیقه روی سرور می‌ماند؛ با رفرش یا بستن و بازکردن صفحه هم سر جایش است و فقط بعد از پایان همان ۱۰ دقیقه پاک می‌شود. پس از آن می‌توانید گفت‌وگوی تازه شروع کنید.",
     [("چت دستیار", "/assistant"), ("راهنما", "/contact")]),
    ("assistant", r"دستیار|هوش\s*مصنوعی|چت\s*بات|آفلاین|هوش\s*اختصاصی|سهمیه|مدل",
     "دو مغز در دسترس شماست: «هوش آفلاین» نامحدود و رایگان (از دانش سایت و داده‌های زنده) و «هوش اختصاصی دست گیر» که مدل زبانی است و سهمیهٔ روزانه دارد (پایه ۵، حرفه‌ای ۲۰، ویژه ۵۰ پاسخ). سوئیچ آن بالای همین صفحهٔ چت است؛ با تمام‌شدن سهمیه، خودکار روی هوش آفلاین می‌مانید.",
     [("چت دستیار", "/assistant"), ("تعرفه‌ها", "/pricing")]),
    ("hours", r"ساعت\s*کار|کی\s*(باز|بسته)|چند.*باز|باز\s*(هست|هستید|است|ه)|تعطیل|شبانه‌?روزی",
     "ساعت کاری هر کسب‌وکار در صفحهٔ خودش زنده نشان داده می‌شود (باز/بسته بر اساس ساعت امروز). برای دیدن فقط بازها، در جست‌وجو فیلتر «الان باز» را روشن کنید.",
     [("جست‌وجو", "/businesses"), ("نزدیک من", "/nearby")]),
    ("contact", r"شماره\s*(تماس|تلفن)|تلفن\s*(شما|پشتیبانی|سایت)|راه\s*ارتباط|ایمیل|آدرس\s*(شما|سایت|دست\s*گیر)",
     "راه‌های رسمی ارتباط با دست گیر: تیکت پشتیبانی (پس از ورود) و صفحهٔ تماس. تلفن هر کسب‌وکار هم در صفحهٔ خودش هست — اگر دکان‌دار آن را عمومی کرده باشد.",
     [("تماس با ما", "/contact"), ("تیکت پشتیبانی", "/my/tickets")]),
    ("map", r"نقشه|مسیر|نشانی|آدرس\s*دهی|لوکیشن|location|چطور\s*برسم",
     "نقشهٔ کامل شهر در /map است؛ در صفحهٔ هر کسب‌وکار هم نشانی و جای دقیق روی نقشه و دکمهٔ مسیریابی هست. «نزدیک من» با اجازهٔ موقعیت، فاصلهٔ واقعی را می‌گوید (موقعیت ذخیره نمی‌شود).",
     [("نقشه", "/map"), ("نزدیک من", "/nearby")]),
    ("haggle", r"چانه|قیمت\s*کم\s*تر|تخفیف\s*بگیر|چونه",
     "اگر دکان‌دار «چانه‌زنی» را برای کالا روشن کرده باشد، در صفحهٔ کالا دکمهٔ پیشنهاد قیمت هست؛ پیشنهاد شما پذیرفته، رد یا با پیشنهاد متقابل جواب داده می‌شود. قیمت کف هرگز نمایش داده نمی‌شود.",
     [("محصولات", "/catalog"), ("مقایسهٔ قیمت", "/prices")]),
    ("deals", r"تخفیف|حراج|پیشنهاد\s*روز|سیل|آفر|ارزون|ارزان",
     "پیشنهادهای زمان‌دار و تخفیف‌های فعال شهر در /deals جمع شده‌اند. برای کاهش قیمت یک کالای خاص هم می‌توانید در /prices هشدار بگذارید.",
     [("پیشنهادهای روز", "/deals"), ("مقایسهٔ قیمت", "/prices")]),
    ("returns", r"بازگشت|ضمانت|گارانتی|مرجوع|پس\s*دادن",
     "کالاهای «قابل بازگشت» یا دارای گارانتی در صفحهٔ کالا برچسب دارند؛ شرایط را پیش از خرید از دکان‌دار بپرسید. در صورت اختلاف، از تیکت پشتیبانی بگویید تا مدیر رسیدگی کند.",
     [("تماس با ما", "/contact"), ("تیکت پشتیبانی", "/my/tickets")]),
    ("prices", r"کاتالوگ|محصول|کالا|قیمت|موجودی|مقایسه",
     "محصولات و خدمات همهٔ کسب‌وکارها با قیمت در /catalog است و می‌توانید جست‌وجو و فیلتر کنید. مقایسهٔ قیمت یک کالا بین دکان‌های شهر در /prices انجام می‌شود.",
     [("کاتالوگ محصولات", "/catalog"), ("مقایسهٔ قیمت", "/prices")]),
    ("lists", r"برترین|بهترین|تاپ|فهرست\s*منتخب",
     "فهرست‌های منتخب و برترین‌های شهر در /lists هستند؛ بر اساس امتیاز، نظر مشتریان و انتخاب مدیر چیده می‌شوند.",
     [("برترین‌ها", "/lists"), ("جست‌وجو", "/businesses")]),
    ("news", r"اخبار|مقاله|بلاگ|خبر",
     "اخبار و راهنماهای شهر در /blog منتشر می‌شود و خوراک RSS هم دارد.",
     [("اخبار و راهنما", "/blog")]),
    ("events", r"رویداد|کنسرت|جشنواره|همایش|برنامه‌?های\s*شهر",
     "رویدادهای شهر (کنسرت، جشنواره، همایش) با مکان و تاریخ در /events ثبت می‌شوند؛ صفحهٔ هر رویداد جزئیات و کسب‌وکار مرتبط را نشان می‌دهد.",
     [("رویدادها", "/events")]),
    ("areas", r"محله|منطقه|شهرها|کدام\s*شهر|کدوم\s*شهر",
     "محله‌ها در /areas و شهرها در /cities فهرست شده‌اند؛ صفحهٔ هر محله کسب‌وکارهای همان محله را نشان می‌دهد. در جست‌وجو هم می‌توانید شهر را فیلتر کنید.",
     [("محله‌ها", "/areas"), ("شهرها", "/cities")]),
    ("privacy", r"حریم|خصوصی|داده‌?هام|حذف\s*حساب|حذف.{0,14}حساب|حساب.{0,14}حذف|اکانت|خروجی\s*داده|اطلاعاتم",
     "شمارهٔ شما به کسب‌وکارها نشان داده نمی‌شود مگر خودتان در سفارش اجازه دهید؛ گفت‌وگو با دکان‌دار بدون شماره است و موقعیت مکانی ذخیره نمی‌شود. خروجی کامل داده و حذف حساب در /me/account است.",
     [("حساب من", "/me/account"), ("قوانین", "/rules")]),
    ("bots", r"بات|ربات|بله|سروش|پیام‌?رسان",
     "بات رسمی دست گیر در بله و سروش‌پلاس است: از /me حساب را وصل می‌کنید و بعد می‌توانید جست‌وجو، «نزدیک من»، سفارش‌ها، نوبت‌ها، علاقه‌مندی‌ها و حتی ثبت کسب‌وکار را داخل پیام‌رسان انجام دهید. هر متن آزاد هم به همین دستیار می‌رسد.",
     [("اتصال به پیام‌رسان", "/me/notif-settings"), ("حساب من", "/me")]),
    ("payment", r"پرداخت|کارت\s*به\s*کارت|درگاه|شبا|فیش|تراکنش",
     "سایت برای سفارش‌ها پولی نمی‌گیرد؛ پرداخت طبق توافق با دکان‌دار (حضوری یا کارت‌به‌کارت) است. تنها پرداخت سایت، اشتراک کسب‌وکار در /my/plan است با ثبت فیش و کد پیگیری و تأیید مدیر.",
     [("سفارش‌های من", "/me/orders"), ("اشتراک کسب‌وکار", "/my/plan")]),
    ("delivery", r"ارسال|پیک|تحویل|پست|بسته\s*رسید",
     "شیوهٔ ارسال روی هر کالا ثبت می‌شود (پیک، پست، تحویل حضوری) و در صفحهٔ کالا دیده می‌شود؛ هماهنگی نهایی با دکان‌دار است. وضعیت سفارش در /me/orders به‌روز می‌شود.",
     [("سفارش‌های من", "/me/orders")]),
    ("security", r"کلاهبرداری|امنیت|رمزم|کد\s*ورود|هک|سوء?استفاده",
     "دست گیر هیچ‌وقت رمز، کد ورود یا اطلاعات کارت را در چت یا تلفن نمی‌پرسد؛ ورود فقط با دکمهٔ رسمی بله یا سروش است. موارد مشکوک را با دکمهٔ گزارش تخلف در همان صفحه یا با تیکت بگویید.",
     [("قوانین", "/rules"), ("تیکت پشتیبانی", "/my/tickets")]),
    ("stats", r"آمار|بازدید|چند\s*نفر\s*دیدن|ورودی",
     "آمار بازدید، تماس‌ها، ذخیره‌ها و جست‌وجوهایی که به دکان رسیده در «آمار» پنل دکان‌دار است و فقط مالک همان کسب‌وکار و مدیر سایت آن را می‌بینند.",
     [("پنل کسب‌وکار", "/my")]),
    ("qr", r"کیوآر|qr|کارت\s*ویزیت|vcard|ویترین",
     "برای هر کسب‌وکار QR اختصاصی (/qr/<slug>.svg، چاپ در هر اندازه) و کارت ویزیت دیجیتال (/vcard/<slug>) ساخته می‌شود؛ اسکن مستقیم به صفحهٔ همان کسب‌وکار می‌رود.",
     [("پنل کسب‌وکار", "/my")]),
    ("follow", r"دنبال|فالو|فراخوان|موجود\s*شد",
     "با دکمهٔ دنبال‌کردن در صفحهٔ کسب‌وکار، خبرهای تازه و «موجود شد» به شما می‌رسد. فهرست دنبال‌شده‌ها در /me/following است.",
     [("دنبال‌شده‌ها", "/me/following"), ("اعلان‌ها", "/me/notifications")]),
    ("app", r"اپ\b|اپلیکیشن|نصب\s*روی\s*گوشی|نصبش",
     "سایت نصب‌شدنی است: در مرورگر گوشی «افزودن به صفحهٔ اصلی» را بزنید تا مثل اپ باز شود. نسخهٔ آفلاین سبک هم دارد و به اپ فروشیگاهی نیاز نیست.",
     [("خانه", "/"), ("نزدیک من", "/nearby")]),
    ("thanks", r"^(ممنون|مرسی|تشکر|سپاس|دستت\s*درد\s*نکنه|خداحافظ|خدانگهدار|فعلاً)[\s!.،؟]*$",
     "خواهش می‌کنم 🙂 هر وقت دنبال کسب‌وکار، محصول یا خدمتی بودید، همین‌جا بپرسید.",
     [("جست‌وجو", "/businesses"), ("نزدیک من", "/nearby")]),
]


def _offline_answer(text):
    """v274 (دستور مدیر): مغز «هوش آفلاین» — پاسخ قطعی برای موضوع‌های رایج
    سایت. فقط در مسیر قاعده‌مند صدا زده می‌شود؛ None یعنی موضوعی پیدا نشد و
    همان راهنمای کلی جواب می‌دهد (هیچ‌وقت حدس یا ادعای بی‌مدرک نمی‌زند)."""
    t = _norm(text).lower()
    if not t or len(t) > 200:
        return None
    for slug, pat, body, links in _OFFLINE_TOPICS:
        try:
            if re.search(pat, t):
                return {"text": body, "links": list(links), "topic": slug}
        except re.error:
            continue
    return None


INTENTS = ("search", "near", "register", "claim", "orders", "bookings", "favorites",
           "plans", "support", "login", "owner", "account", "faq", "greeting",
           "off_topic", "unknown")

# Rule table: (intent, regex). Order matters; first match wins.
_RULES = [
    ("greeting", r"^(سلام|درود|هی|hi|hello|سلام\s*علیکم|خسته نباشید)[\s!.،؟]*$"),
    ("orders", r"سفارش|order|خرید(های)?\s*من|پیگیری\s*سفارش|سبد"),
    ("bookings", r"نوبت|رزرو|وقت\s*(گرفتن|بگیرم)|booking"),
    ("favorites", r"علاقه|ذخیره\s*شده|favorite|نشان\s*کرده"),
    ("register", r"ثبت\s*(کسب|مغازه|فروشگاه|شغل|کار)|کسب\s*و\s*کار(م)?\s*(را|رو)?\s*(ثبت|اضافه)|مغازه(م|‌ام)?\s*(را|رو)?\s*(ثبت|اضافه)|register|چطور.*ثبت"),
    ("claim", r"تصاحب|تحویل\s*(بگیرم|گرفتن)|مال\s*من|صاحبش\s*منم"),
    ("plans", r"تعرفه|پلن|اشتراک|قیمت\s*(ثبت|پلن|اشتراک)|هزینه|رایگان|حرفه‌?ای|ویژه"),
    ("support", r"پشتیبان|تیکت|شکایت|مشکل\s*دارم|گزارش|ارتباط\s*با\s*(مدیر|ما)|تماس\s*با"),
    ("login", r"ورود|لاگین|login|وارد\s*(بشم|شوم|شم)|ثبت‌?نام|رمز|کد\s*پیامک"),
    ("owner", r"پنل|کسب‌?وکار(های)?\s*من|داشبورد|مدیریت\s*مغازه|آمار\s*بازدید"),
    ("account", r"حساب\s*(من|کاربری)|پروفایل|اطلاعات\s*من|شماره‌?ام"),
    ("near", r"نزدیک|اطراف|دور\s*و\s*بر|همین\s*حوالی|نزدیکم|near|کجا\s*هست\s*نزدیک"),
    # faq only when the question is visibly about the site itself; generic
    # «X چیست» goes to the model (or the off-topic fallback).
    ("faq", r"دست\s*گیر|راهنما|help|کمک|امکانات|حریم|خصوصی|بات|بله|سروش|پیام‌?رسان|سایت|اینجا|این\s*سامانه"),
]
_NEAR_WORDS = re.compile(r"(نزدیک(?:م|\s*من|\s*ما)?|اطراف(?:م|\s*من)?|دور\s*و\s*بر(?:م)?|همین\s*حوالی|near\s*me|near)", re.U)
_SEARCH_LEAD = re.compile(
    r"^(?:لطفا|لطفاً)?\s*(?:یک|یه)?\s*(?:جست\s*و\s*جو(?:ی)?|جستجو(?:ی)?|سرچ|پیدا\s*کن|دنبال|می‌?خوام|میخوام|می‌?خواهم|کجا(?:ست)?|بگرد)\s*", re.U)
_SEARCH_TAIL = re.compile(r"\s*(?:را|رو)?\s*(?:پیدا\s*کن|می‌?خوام|میخوام|می‌?گردم|بگرد|هست\??|کجاست\??|دارید\??)\s*$", re.U)


def _norm(text):
    return re.sub(r"\s+", " ", str(text or "").replace("ي", "ی").replace("ك", "ک").strip())


def rule_intent(text):
    """Deterministic classifier. Returns (intent, query) or (None, '')."""
    t = _norm(text)
    if not t:
        return "unknown", ""
    low = t.lower()
    if len(t) > 400:
        return "off_topic", ""
    if re.match(r"^/?(search|جست‌?وجو)\b", low):
        q = re.sub(r"^/?(search|جست‌?وجو)\s*", "", t).strip()
        return ("search", q) if q else ("search", "")
    for intent, pat in _RULES:
        if re.search(pat, low):
            if intent == "near":
                rest = _strip_search(_NEAR_WORDS.sub(" ", t))
                rest = re.sub(r"\b(کجاست|کجا|هست|چی|چیه|بگو|به\s*من|برام|برای\s*من|یک|یه)\b", " ", rest)
                rest = re.sub(r"\s+", " ", rest).strip(" ؟?.،")
                return "near", (rest if 2 <= len(rest) <= 40 else "")
            return intent, ""
    # «کافه», «داروخانه شبانه‌روزی», «پیدا کن نانوایی» → search (short noun phrases)
    if _SEARCH_LEAD.match(low) or _SEARCH_TAIL.search(low):
        return "search", _strip_search(t)
    # Short noun phrases («کافه», «تعمیرگاه موبایل») are searches — but not
    # questions or imperatives («یک شعر بگو», «ترجمه کن»), which go to the model.
    if 2 <= len(t) <= 40 and len(t.split()) <= 4 and not _NOT_SEARCH.search(low):
        return "search", t
    return None, ""


_NOT_SEARCH = re.compile(
    r"[?؟]|\b(بگو|بنویس|بساز|ترجمه|توضیح|حل|بده|کن|کنید|چیست|چیه|کیه|کیست|چرا|چند|کدام|کدوم|"
    r"شعر|داستان|جوک|لطیفه|کد|برنامه|python|java|html|فوتبال|هوا|اخبار|سیاست|پزشک|دارو\s*چی)\b", re.U)


def _strip_search(t):
    q = _SEARCH_LEAD.sub("", t)
    q = _SEARCH_TAIL.sub("", q)
    return q.strip(" ؟?.،")[:60]


def system_prompt():
    """v228: legacy shim — the intent classifier (llm_intent) is gone, but the
    v218 suite pins knowledge visibility through this accessor. Live code
    reads faqs() directly. Empty knowledge still falls back to KNOWLEDGE."""
    pairs = faqs() or list(KNOWLEDGE)
    return "\n".join(f"• {q}: {a}" for q, a in pairs)


_log_lock = threading.Lock()
_last_error = {"when": 0, "what": ""}


def last_error():
    return dict(_last_error)


def _record_error(what):
    with _log_lock:
        _last_error["when"] = int(time.time())
        _last_error["what"] = str(what)[:120]


def _brain_fail_fa(err, brain):
    """v265: honest Persian sentence for a dead primary brain. No fallback
    is ever attempted (owner order) — the message names the brain, the
    reason, and the two manual remedies (switch brains / refill tokens)."""
    disp = BRAIN_FA.get(brain, "مغز دستی") if brain in BRAINS else "مغز دستی"
    e = str(err or "")
    code = ""
    if e.startswith("http-"):
        code = e[5:].split(":")[0]
    if code == "402":
        why = "اعتبار/توکنش تمام شده (۴۰۲)"
    elif code == "429":
        why = "سهمیه‌اش تمام شده (۴۲۹)"
    elif code == "401":
        why = "کلیدش نامعتبر است (۴۰۱)"
    elif code == "403":
        why = "ممنوع شد (۴۰۳)"
    elif code == "404":
        why = "مدل/آدرس نادرست (۴۰۴)"
    elif code.startswith("5"):
        why = f"خطای سرور هوش مصنوعی ({code})"
    elif code:
        why = f"خطای HTTP {code}"
    elif e.startswith("empty:"):
        why = "پاسخ خالی داد"
    elif e.startswith("bad-json:"):
        why = "پاسخ خراب داد"
    elif e:
        why = "در دسترس نیست (شبکه/سرویس)"
    else:
        why = "جواب نداد"
    return (f"«{disp}» جواب نداد ({why}). سوئیچ خودکار انجام نمی‌شود — "
            "با «مغز» یک مغز دیگر را خودت انتخاب کن، "
            "یا توکنش را با «/کلید» تازه کن.\n"
            "🩺 برای دیدن علت دقیق بفرست: تشخیص")


# v224: which provider answered last (primary/smart) — the panel shows it
# next to the last error. (v265: fallback is gone — no automatic switch.)
_last_provider = {"when": 0, "which": "", "model": ""}


def last_provider():
    return dict(_last_provider)


def _record_provider(which, model):
    with _log_lock:
        _last_provider["when"] = int(time.time())
        _last_provider["which"] = str(which or "")[:16]
        _last_provider["model"] = str(model or "")[:80]


def _chat(base_url, api_key, model, messages, timeout, max_tokens=220):
    """One OpenAI-compatible chat.completions call. Returns (content, tokens).
    Raises on transport/HTTP errors; the caller decides about fallback."""
    body = json.dumps({
        "model": model, "messages": messages, "temperature": 0,
        "max_tokens": int(max_tokens), "response_format": {"type": "json_object"},
    }).encode("utf-8")
    req = urllib.request.Request(
        base_url + "/chat/completions", data=body, method="POST",
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + api_key,
                 "User-Agent": "dastgir-assistant/214"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8", "replace"))
    content = (((data.get("choices") or [{}])[0].get("message") or {}).get("content")) or ""
    usage = data.get("usage") or {}
    tokens = int(usage.get("total_tokens") or 0)
    return content, tokens


def parse_model_json(content):
    """Tolerant parse: strips ``` fences and trailing prose; validates intent."""
    s = str(content or "").strip()
    s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.I | re.S).strip()
    m = re.search(r"\{.*\}", s, re.S)
    if not m:
        return None
    try:
        obj = json.loads(m.group(0))
    except ValueError:
        return None
    if not isinstance(obj, dict):
        return None
    intent = str(obj.get("intent") or "").strip().lower()
    if intent not in INTENTS:
        return None
    return {"intent": intent, "q": _norm(obj.get("q") or "")[:60],
            "reply": _norm(obj.get("reply") or "")[:300]}


# ------------------------------------------------------------------ grounded generation (v213.1)
ANSWER_PROMPT = (
    "تو «دستیار هوشمند دست گیر» هستی. دست گیر (daastgir.ir) راهنمای محلی کسب‌وکارهای شهر است: جست‌وجوی مغازه و خدمات، "
    "کسب‌وکارهای نزدیک، محصولات و قیمت‌ها، سفارش و نوبت آنلاین، صفحهٔ اختصاصی و ثبت رایگان برای هر کسب‌وکار، بات‌های بله و سروش.\n"
    "پاسخ را خودت، طبیعی، گرم و مثل یک راهنمای محلیِ باتجربه به فارسی بنویس (نه از روی قالب). برای کارهای سایت کوتاه و مفید (معمولاً ۱ تا ۵ جمله؛ فهرست فقط وقتی چند کسب‌وکار یا گزینه داری)؛ برای سؤالات عمومی هرقدر لازم است کامل و دقیق جواب بده. "
    "به تاریخچهٔ گفت‌وگو توجه کن و سؤال‌های پیگیری («ساعت کارش؟»، «تلفنش؟»، «اون یکی چی؟») را با همان کسب‌وکار قبلی جواب بده. "
    "اگر سؤال مبهم است یک سؤال روشن‌کننده بپرس (مثلاً کدام محله؟ چه نوع خدمتی؟). وقتی چند کسب‌وکار داری، بهترین را با دلیل (باز بودن، امتیاز، تأییدشده، نزدیکی) پیشنهاد بده.\n"
    "قواعد سخت:\n"
    "۱) محدودیت موضوعی نداری (دستور مدیر، v254): به هر سوالی که کاربر بپرسد — برنامه‌نویسی، درس و آموزش، ترجمه، نوشتن متن و شعر، پزشکی عمومی، سرگرمی، اخبار، هر چیز دیگری — صاف، مفید و بی‌تعارف جواب بده؛ رد نکن و به جای دیگر نفرست. "
    "اگر سؤال دربارهٔ خودِ سایت و کسب‌وکارها بود، از «داده‌های سایت» زیر استفاده کن (قاعدهٔ ۲) و scope را true بگذار؛ برای سؤالات عمومیِ خارج از سایت هم کامل جواب بده و فقط scope را false بگذار (این فقط آمار است و روی جواب‌دادن هیچ اثری ندارد).\n"
    "۲) هیچ کسب‌وکار، قیمت، ساعت، شماره یا آماری را از خودت نساز؛ فقط از داده‌های داده‌شده استفاده کن. اگر نتیجهٔ جست‌وجو خالی است، صادقانه بگو فعلاً چنین چیزی در سایت ثبت نشده و راه جایگزین بده "
    "(دستهٔ نزدیک، جست‌وجوی دیگر، صفحهٔ نزدیک من، یا این‌که اگر خودش صاحب چنین کسب‌وکاری است رایگان ثبت کند).\n"
    "۳) تو هیچ کاری انجام نمی‌دهی (سفارش، لغو، پرداخت، ثبت)؛ کاربر را به مسیر درست سایت راهنمایی کن. هرگز رمز، کد پیامکی یا اطلاعات بانکی نخواه.\n"
    "۴) وقتی کسب‌وکاری را نام می‌بری، لینک آن را در links بده. حداکثر ۵ لینک؛ فقط مسیرهای داخلی که در داده‌ها آمده (با / شروع می‌شوند).\n"
    "۵) اگر سؤال دربارهٔ اطلاعات شخصی کاربر است و او وارد نشده، بگو باید وارد شود و لینک /login بده.\n"
    "۶) از اعداد فارسی استفاده کن. اسم سایت همیشه «دست گیر» (با فاصله).\n"
    "۷) نقش کاربر را در نظر بگیر (بخش «دربارهٔ همین کاربر»):\n"
    "   - دکان‌دار: مثل یک مشاور کسب‌وکار محلی کمک کن — وضعیت سفارش‌ها/نوبت‌ها/پیام‌های بی‌پاسخش را از داده‌ها بگو، برای بیشتر دیده‌شدن راهکارهای عملیِ داخل سایت بده "
    "(کامل‌کردن پروفایل و ساعت کاری، عکس باکیفیت، کاتالوگ با قیمت، پاسخ به نظرات، استوری و پیشنهاد روز، فراخوان به دنبال‌کننده‌ها، QR ویترین، پلن حرفه‌ای)، "
    "متن پیشنهادی برای پاسخ به نظر مشتری یا معرفی دکان بنویس اگر خواست، و مسیر دقیق هر کار در /my را بده.\n"
    "   - مشتری: مثل یک راهنمای محلی مهربان — بهترین گزینه را با دلیل پیشنهاد بده، وضعیت سفارش/نوبتش را از داده‌ها بگو، نحوهٔ لغو/پیگیری/ذخیره/دنبال‌کردن را توضیح بده.\n"
    "   - مهمان: امکانات را معرفی کن و در جای مناسب ورود یا ثبت رایگان کسب‌وکار را پیشنهاد بده.\n"
    "۸) «امروز/فردا/این هفته» را همیشه از بخش «زمان فعلی» داده‌ها بفهم، نه از دانش قدیمی خودت؛ "
    "فاصله‌ها را از بخش «موقعیت کاربر» و فیلد فاصلهٔ هر کسب‌وکار بخوان و از خودت فاصله نساز.\n"
    "۹) ابزارها (فقط برای کاربر واردشده؛ برای مهمان هرگز): اگر کاربر صراحتاً خواست، در همین JSON یک کلید tool_call هم بگذار. "
    "favorite: {\"slug\": \"...\"} (ذخیره/حذف فوری)؛ cancel_booking و cancel_order: {\"id\": 123}؛ "
    "book (ثبت نوبت): {\"slug\": \"...\", \"date\": \"YYYY/MM/DD شمسی\", \"time\": \"HH:MM\", \"name\": \"...\"} — "
    "تاریخ را از «زمان فعلی» و حرف کاربر (امروز/فردا/...) به شمسی تبدیل کن، ساعت را ۲۴ساعته بنویس، و name را فقط اگر کاربر گفت بگذار؛ "
    "review (نظر متنی، بدون ستاره): {\"slug\": \"...\", \"body\": \"متن نظر کاربر\"} — برای امتیاز ستاره‌ای tool_call نگذار و صفحهٔ کسب‌وکار را لینک بده. "
    "شناسه/اسلاگ را فقط از همین داده‌ها بردار و هرگز نساز. "
    "فقط favorite فوری است؛ بقیه سؤال تأیید می‌خواهند و تو فقط پیشنهاد می‌دهی — اجرای نهایی با سرور است. "
    "اگر مطمئن نیستی کدام مورد، tool_call نگذار و بپرس.\n"
    "خروجی فقط JSON: {\"answer\": \"متن پاسخ\", \"links\": [{\"label\": \"...\", \"href\": \"/...\"}], \"scope\": true|false, \"tool_call\": null یا {\"name\":..., \"args\":...}, \"intent\": \"یکی از "
    + "/".join(INTENTS) + "\"}"
)


def _site_facts():
    s = db.get_settings()
    f = [f"نام سایت: دست گیر — {s.get('tagline') or ''}".strip(" —")]
    if s.get("description") and s.get("description") not in ("توضیح", "توضیحات"):
        f.append("معرفی: " + str(s.get("description"))[:300])
    for k, label in (("reg_open", "ثبت کسب‌وکار توسط کاربران باز است"), ("booking_enabled", "نوبت‌دهی آنلاین فعال است"),
                     ("orders_enabled", "سفارش آنلاین فعال است"), ("catalog_enabled", "کاتالوگ محصولات فعال است"),
                     ("prices_enabled", "مقایسهٔ قیمت فعال است"), ("chat_enabled", "گفت‌وگو با دکان‌دار فعال است")):
        if s.get(k) == "1":
            f.append(label)
    f.append("مسیرهای مهم: / خانه، /businesses فهرست و جست‌وجو (?q=)، /nearby نزدیک من، /map نقشه، /categories دسته‌ها، "
             "/catalog محصولات، /deals پیشنهادها، /events رویدادها، /blog اخبار، /pricing تعرفه‌ها، /register-business ثبت رایگان کسب‌وکار، "
             "/my/claim تصاحب کسب‌وکار موجود، /login ورود فقط با بله/سروش، /me حساب مشتری، /me/orders سفارش‌ها، /me/favorites علاقه‌مندی‌ها، "
             "/my پنل دکان‌دار، /my/plan اشتراک کسب‌وکار، /my/tickets پشتیبانی تیکتی، /contact تماس. صفحهٔ هر کسب‌وکار: /b/<slug>")
    return f


def _biz_line(r):
    parts = [r.get("name") or ""]
    if r.get("cat_slug"): parts.append("دسته: " + str(r.get("cat_name") or r["cat_slug"]))
    if r.get("address"): parts.append("نشانی: " + str(r["address"])[:70])
    if r.get("open") is True: parts.append("الان باز")
    elif r.get("open") is False: parts.append("الان بسته")
    if r.get("verified"): parts.append("تأییدشده")
    if r.get("rating"): parts.append(f"امتیاز {r['rating']} ({r.get('nreviews') or 0} نظر)")
    if r.get("phone_public") and r.get("phone"): parts.append("تلفن: " + str(r["phone"]))
    if r.get("distance_km") is not None: parts.append("فاصله: " + _dist_str(r["distance_km"]))
    return " | ".join(parts) + f" | لینک: /b/{r.get('slug')}"


def _search_pack(text, q, lat=None, lon=None):
    """Live search hits for the model. Tries the extracted query, then the raw
    text, then single significant words — so «نانوایی سنگکی» still finds bakeries.
    v222: with coords, each hit is annotated with its live distance."""
    cats = {c["slug"]: c for c in db.categories(only_active=False)}
    tried, rows = [], []
    cands = [x for x in (q, text) if x and len(db.normalize_fa(x)) >= 2]
    words = [w for w in re.split(r"[\s،,؟?]+", _norm(text)) if len(w) >= 3 and not _NOT_SEARCH.search(w)]
    for cand in cands + words[:4]:
        cand = cand[:60]
        if cand in tried: continue
        tried.append(cand)
        try:
            hits = db.search_business_summaries(cand, 6)
        except Exception:
            hits = []
        for h in hits:
            if all(h["id"] != r["id"] for r in rows):
                rows.append(h)
        if len(rows) >= 6: break
    out = []
    for r in rows[:6]:
        try:
            full = db.business(bid=r["id"]) or {}
            r["open"] = db.is_open_now(full) if full.get("hours") else None
            r["rating"] = full.get("rating"); r["nreviews"] = full.get("nreviews"); r["phone_public"] = full.get("phone_public")
            if lat is not None and full.get("lat") is not None and full.get("lng") is not None:
                r["distance_km"] = round(db.haversine_km(lat, lon, float(full["lat"]), float(full["lng"])), 2)
        except Exception:
            pass
        c = cats.get(r.get("cat_slug")); r["cat_name"] = c["name"] if c else ""
        out.append(_biz_line(r))
    # matching categories (so the model can suggest a category page)
    low = db.normalize_fa(text)
    catm = [c for c in cats.values() if c.get("active") and c.get("name") and db.normalize_fa(c["name"]) in low][:4]
    return out, [f"{c['name']} ({c.get('total') or c.get('count') or 0} کسب‌وکار) لینک: /businesses?cat={c['slug']}" for c in catm], tried


def _extra_pack(text):
    """Products/prices, deals, upcoming events and category list relevant to the words."""
    out = []
    low = db.normalize_fa(text)
    words = [w for w in re.split(r"[\s،,؟?]+", low) if len(w) >= 3 and not _NOT_SEARCH.search(w)]
    try:
        items = db.items(only_available=True)
        hits = [i for i in items if any(w in db.normalize_fa(f"{i.get('title')} {i.get('descr') or ''}") for w in words)][:8]
        if hits:
            out.append("## محصولات/خدمات مرتبط (کاتالوگ زنده)")
            for i in hits:
                price = f"{int(i['price']):,} تومان" if i.get("price") else "قیمت توافقی"
                out.append(f"{i.get('title')} — {price} — در {i.get('bizname')} — لینک: /b/{i.get('bizslug')}")
    except Exception:
        pass
    try:
        import features
        deals = [d for d in features.flashdeals(active_only=True)][:5]
        if deals and re.search(r"تخفیف|پیشنهاد|حراج|ارزان|deal", low):
            out.append("## پیشنهادهای فعال امروز (/deals)")
            for d in deals:
                out.append(f"{d.get('title')} — {d.get('bizname') or ''} — {d.get('descr') or ''}"[:160])
    except Exception:
        pass
    try:
        if re.search(r"رویداد|برنامه|جشن|نمایشگاه|کنسرت|همایش|event", low):
            evs = db.cityevents(upcoming_only=True, limit=5)
            if evs:
                out.append("## رویدادهای پیشِ رو (/events)")
                for e in evs:
                    out.append(f"{e.get('title')} — {e.get('date') or e.get('starts') or ''} — {e.get('place') or ''}"[:160])
    except Exception:
        pass
    try:
        if re.search(r"دسته|صنف|چه\s*چیزهایی|چی\s*دارید|چه\s*کسب|همهٔ?\s*(مغازه|کسب)", low):
            cats = [c for c in db.categories(top_only=True) if c.get("total") or c.get("count")][:25]
            if cats:
                out.append("## دسته‌های اصلی سایت با تعداد کسب‌وکار")
                out.append("، ".join(f"{c['name']} ({c.get('total') or c.get('count')})" for c in cats))
    except Exception:
        pass
    return out


def _mentioned_business_pack(text, history):
    """If the user names a business we know (or asked about one in the last turns),
    include its full public card so follow-up questions («ساعت کارش؟ تلفنش؟») work."""
    texts = [text] + [h.get("text", "") for h in (history or [])[-4:]]
    low = db.normalize_fa(" ".join(texts))
    out = []
    try:
        rows = db._rows("SELECT id,name,slug FROM businesses WHERE status='published'")
        found = [r for r in rows if len(r["name"]) >= 3 and db.normalize_fa(r["name"]) in low][:2]
        for r in found:
            b = db.business(bid=r["id"]) or {}
            if not b: continue
            hours = b.get("hours") or {}
            if isinstance(hours, str):
                try: hours = json.loads(hours)
                except Exception: hours = {}
            hrs = "; ".join(f"{d}: " + ",".join("-".join(x) for x in v) for d, v in hours.items() if v) if isinstance(hours, dict) else ""
            its = db.items(biz_id=b["id"], only_available=True)[:8]
            out.append(f"## جزئیات کسب‌وکار «{b['name']}» (/b/{b['slug']})")
            out.append(f"دسته: {b.get('cat_slug')} | نشانی: {b.get('address') or '—'} | محله: {b.get('area') or '—'} | شهر: {b.get('city') or '—'}")
            out.append(f"الان: {'باز' if db.is_open_now(b) else 'بسته'} | ساعت کاری: {hrs or 'ثبت نشده'}")
            out.append(f"تلفن: {(b.get('phone') if b.get('phone_public') else 'عمومی نیست — از دکمهٔ پیام در صفحه استفاده کنید')}")
            out.append(f"امتیاز: {b.get('rating') or '—'} ({b.get('nreviews') or 0} نظر) | تأییدشده: {'بله' if b.get('verified') else 'خیر'} | نوبت‌دهی: {'دارد' if b.get('booking_on') else 'ندارد'}")
            if b.get("descr"): out.append("معرفی: " + str(b["descr"])[:300])
            if its: out.append("کاتالوگ: " + "؛ ".join(f"{i['title']} {int(i['price']):,} تومان" if i.get('price') else i['title'] for i in its))
    except Exception:
        pass
    return out


def _user_pack(ctx):
    cust, owner = ctx.get("customer"), ctx.get("owner")
    lines = []
    if not (cust or owner):
        return ["کاربر وارد نشده است (مهمان)."]
    if cust:
        lines.append(f"کاربر وارد شده: {cust.get('name') or 'بدون نام'} (مشتری).")
        try:
            import features
            for r in features.customer_order_summaries(cust["id"], 5):
                lines.append(f"سفارش #{r['id']} از {r['bizname']} — {r.get('status_label') or r.get('status')} — مبلغ {r.get('total')} تومان — لینک: /me/orders")
            for r in db.customer_booking_summaries(cust["id"], 5):
                lines.append(f"نوبت #{r['id']} {r['bizname']} {r['date']} {r['time']} — {r.get('status_label') or r.get('status')} — لینک: /me")
            favs = db._rows("SELECT b.name,b.slug FROM favorites f JOIN businesses b ON b.id=f.biz_id WHERE f.customer_id=? AND b.status='published' ORDER BY f.id DESC LIMIT 5", (cust["id"],))
            if favs: lines.append("علاقه‌مندی‌ها: " + "، ".join(f"{r['name']} (/b/{r['slug']})" for r in favs))
        except Exception:
            pass
    o = owner
    if not o and cust and cust.get("phone"):
        try: o = db.owner_by_phone(cust["phone"], create=False)
        except Exception: o = None
    if o:
        try:
            import features
            bizs = db.businesses_of(o["id"])[:5]
            if bizs: lines.append("نقش: دکان‌دار (صاحب کسب‌وکار).")
            for b in bizs:
                sub = db.subscription_of(b["id"])
                plan = db.plan(slug=(sub or {}).get("plan_slug")) if sub else None
                n_items = db._one("SELECT COUNT(*) n FROM items WHERE biz_id=? AND available=1", (b["id"],))["n"]
                n_img = len(b.get("images") or [])
                n_rev = db._one("SELECT COUNT(*) n FROM reviews WHERE biz_id=? AND status='approved'", (b["id"],))["n"]
                miss = [x for x, ok in (("توضیح معرفی", bool(b.get("descr"))), ("ساعت کاری", bool(b.get("hours"))), ("عکس", n_img > 0),
                                        ("کاتالوگ/قیمت", n_items > 0), ("موقعیت روی نقشه", bool(b.get("lat"))), ("نشانی", bool(b.get("address")))) if not ok]
                lines.append(f"کسب‌وکار «{b['name']}» (/b/{b['slug']}) — وضعیت انتشار: {b.get('status')} — پلن: {(plan or {}).get('name') or 'پایه (رایگان)'} — "
                             f"{n_img} عکس، {n_items} محصول/خدمت، {n_rev} نظر منتشرشده، امتیاز {b.get('rating') or '—'}، نوبت‌دهی {'روشن' if b.get('booking_on') else 'خاموش'}، "
                             f"تأییدشده: {'بله' if b.get('verified') else 'خیر'}" + (f" — موارد ناقص پروفایل: {'، '.join(miss)}" if miss else " — پروفایل کامل است"))
            if bizs:
                for r in features.owner_order_summaries(o["id"], 5):
                    lines.append(f"سفارش دکان #{r['id']} — {r.get('status_label') or r['status']} — {r.get('total')} تومان — از {r['bizname']} — مدیریت: /my/orders")
                try:
                    for r in features.owner_chat_summaries(o["id"], 5):
                        lines.append(f"گفت‌وگوی مشتری: {str(r.get('subject') or r.get('last') or '')[:60]} — {'بی‌پاسخ' if r.get('unread') else 'خوانده‌شده'} — /my/chats")
                except Exception:
                    pass
                lines.append("مسیرهای دکان‌دار: /my داشبورد، /my/businesses ویرایش/گالری/کاتالوگ/ساعت، /my/orders سفارش‌ها، /my/bookings نوبت‌ها، /my/chats گفت‌وگوها، "
                             "/my/reviews نظرات و پاسخ، /my/questions پرسش‌ها، /my/stories استوری، /my/offers پیشنهاد قیمت، /my/broadcast فراخوان، /my/plan اشتراک، /my/tickets پشتیبانی.")
        except Exception:
            pass
    return lines or ["کاربر وارد شده است."]


# ------------------------------------------------------------------ time & place (v222)
_J_MONTHS = ("", "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
             "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
_J_WEEKDAYS = ("دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه", "یکشنبه")


def _now_tehran():
    try:
        return db.iran_now().replace(tzinfo=None)
    except Exception:
        return datetime.datetime.now()


def time_block(now=None):
    """«امروز» برای مدل: روز هفته + تاریخ شمسی + ساعت تهران. Never raises."""
    try:
        now = now or _now_tehran()
        jy, jm, jd = g2j(now.year, now.month, now.day)
        return (f"امروز {_J_WEEKDAYS[now.weekday()]} {jd} {_J_MONTHS[jm]} {jy}، "
                f"ساعت {now.hour:02d}:{now.minute:02d} به وقت تهران "
                f"({now.year:04d}-{now.month:02d}-{now.day:02d}).")
    except Exception:
        return ""


def _coords(ctx):
    """Validated (lat, lon) from ctx, or None. Coords are request-scoped:
    they are never written to threads, cache, usage or logs."""
    try:
        lat = float(ctx.get("lat"))
        lon = float(ctx.get("lon"))
    except (TypeError, ValueError):
        return None
    if not (-90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0):
        return None
    return (lat, lon)


def _dist_str(km):
    try:
        km = float(km)
    except (TypeError, ValueError):
        return ""
    if km < 1:
        return f"{_fa(int(round(km * 1000)))} متر"
    return f"{_fa(f'{km:.1f}')} کیلومتر"


def build_context(text, q, ctx, history=None):
    latlon = _coords(ctx or {})
    biz, cats, tried = _search_pack(text, q, *(latlon or (None, None)))
    plans = [f"{p['name']} — {'رایگان' if int(p.get('price') or 0)==0 else str(p.get('price'))+' تومان / '+str(p.get('months') or 12)+' ماه'}"
             + (f" — {p.get('tagline')}" if p.get('tagline') else "") + (" — امکانات: " + "، ".join(p.get("perk_list") or [])[:200] if p.get("perk_list") else "")
             for p in db.plans()]
    pages = []
    for slug in ("about", "rules"):
        try:
            pg = db.get_page(slug)
            if pg and pg.get("body"):
                pages.append(f"صفحهٔ {pg.get('title') or slug}: " + re.sub(r"<[^>]+>", " ", pg["body"])[:500])
        except Exception:
            pass
    parts = ["## اطلاعات سایت", *_site_facts()]
    tb = time_block()   # v222: ground «امروز/فردا» for the model
    if tb:
        parts += ["## زمان فعلی", tb]
    if latlon:
        parts += ["## موقعیت کاربر",
                  f"عرض جغرافیایی {latlon[0]:.4f}، طول {latlon[1]:.4f} — فاصله‌ها نسبت به همین نقطه."]
    parts += ["## راهنمای کارها", *[f"{a}: {b}" for a, b in faqs()],
              "## پلن‌ها (/pricing)", *plans]
    if pages: parts += ["## صفحات", *pages]
    parts += [f"## نتیجهٔ جست‌وجوی زنده برای {tried}", *(biz or ["هیچ کسب‌وکاری برای این عبارت‌ها ثبت نشده است."])]
    if cats: parts += ["## دسته‌های مرتبط", *cats]
    parts += _mentioned_business_pack(text, history)
    parts += _extra_pack(text)
    try:
        n_biz = db._one("SELECT COUNT(*) n FROM businesses WHERE status='published'")["n"]
        n_cat = len([c for c in db.categories() if c.get("total") or c.get("count")])
        parts += ["## آمار زندهٔ سایت", f"{n_biz} کسب‌وکار منتشرشده در {n_cat} دسته"]
    except Exception:
        pass
    parts += ["## دربارهٔ همین کاربر", *_user_pack(ctx)]
    return "\n".join(parts)[:14000]


def parse_answer_json(content):
    s = str(content or "").strip()
    s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.I | re.S).strip()
    m = re.search(r"\{.*\}", s, re.S)
    if not m: return None
    try: obj = json.loads(m.group(0))
    except ValueError: return None
    if not isinstance(obj, dict): return None
    ans = _norm(obj.get("answer") or "")
    if not ans: return None
    links = []
    for l in (obj.get("links") or [])[:5]:
        if isinstance(l, dict) and isinstance(l.get("href"), str) and re.fullmatch(r"/[A-Za-z0-9_\-/?=&%.\u0600-\u06FF]*", l["href"]):
            links.append((_norm(l.get("label") or l["href"])[:40], l["href"][:120]))
    intent = str(obj.get("intent") or "").strip().lower()
    tname, targs = parse_tool_call(obj.get("tool_call"))   # v223: strict; junk → None
    return {"answer": ans[:1200], "links": links, "scope": obj.get("scope") is not False,
            "intent": intent if intent in INTENTS else "unknown",
            "tool_call": ({"name": tname, "args": targs} if tname else None)}


def needs_smart(text, history=None):
    """v219: deterministic router — long/complex messages and multi-turn
    follow-ups deserve AI_MODEL_SMART; everything else uses the cheap model.
    No extra model call: pure length/turn heuristics, easy to test."""
    if len(_norm(text)) > 150:
        return True
    return len(history or []) >= 4


# ------------------------------------------------------------------ semantic cache (v220)
CACHE_TTL = 12 * 3600       # repeated public answers stay fresh half a day
CACHE_MAX_ROWS = 500
CACHE_MIN_JACCARD = 0.75    # high on purpose: one swapped content word must miss
CACHE_MAX_LEN = 200         # longer questions are too specific to reuse

_cache_punct_re = re.compile(r"[?؟!.,،؛:;،\-_\"'«»()\[\]{}+*=<>|/\\@#%^&~`]")


def _cache_norm(text):
    s = _cache_punct_re.sub(" ", db.normalize_fa(text))
    return re.sub(r"\s+", " ", s).strip()


def _cache_tokens(norm):
    return {w for w in norm.split(" ") if len(w) > 1}


def cache_lookup(text, ctx, history=None, hint_intent=None):
    """A cached model answer for this question, or None.

    Guests without history only — signed-in answers may embed personal data
    (orders, businesses) and follow-ups depend on earlier turns. Exact
    normalized matches hit instantly; otherwise the best token-set (Jaccard)
    match wins when it clears CACHE_MIN_JACCARD and agrees with the rule
    hint. Hits are free: no quota, no provider call.
    """
    if history or (ctx.get("customer") or ctx.get("owner")):
        return None
    if _coords(ctx or {}):   # v222: cached answers are location-agnostic
        return None
    norm = _cache_norm(text)
    if not norm or len(norm) > CACHE_MAX_LEN:
        return None
    want = _cache_tokens(norm)
    if not want:
        return None
    try:
        rows = db._rows("SELECT id, q_norm, tokens, answer, links, intent, model "
                        "FROM ai_cache WHERE expires>? ORDER BY id DESC LIMIT ?",
                        (int(time.time()), CACHE_MAX_ROWS))
    except Exception:
        return None
    best = None
    for r in rows:
        if hint_intent and r["intent"] and r["intent"] != hint_intent:
            continue
        if r["q_norm"] == norm:
            score = 1.0
        else:
            have = set((r["tokens"] or "").split(" "))
            have.discard("")
            if not have:
                continue
            score = len(want & have) / len(want | have)
            if score < CACHE_MIN_JACCARD:
                continue
        if best is None or score > best[0]:
            best = (score, r)
    if not best:
        return None
    r = best[1]
    try:
        con = db.connect()
        con.execute("UPDATE ai_cache SET hits=hits+1 WHERE id=?", (r["id"],))
        con.commit(); con.close()
    except Exception:
        pass
    try:
        links = [(str(a), str(b)) for a, b in json.loads(r["links"] or "[]")]
    except (ValueError, TypeError):
        links = []
    return {"text": r["answer"], "links": links, "intent": r["intent"] or "unknown",
            "model": r["model"] or "fast"}


def cache_store(text, ctx, history, answer, links, intent, model, mtokens):
    """Remember a model-written answer for future guests. Never raises."""
    try:
        if history or (ctx.get("customer") or ctx.get("owner")):
            return False
        if _coords(ctx or {}):   # v222: never poison the cache with local answers
            return False
        norm = _cache_norm(text)
        if not norm or len(norm) > CACHE_MAX_LEN or not answer:
            return False
        toks = " ".join(sorted(_cache_tokens(norm)))
        if not toks:
            return False
        now = int(time.time())
        con = db.connect()
        con.execute("INSERT INTO ai_cache(q_norm,tokens,answer,links,intent,model,mtokens,hits,created,expires) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (norm, toks, answer[:1200],
                     json.dumps([(a, b) for a, b in (links or [])][:5], ensure_ascii=False),
                     (intent or "")[:32], (model or "")[:32], int(mtokens or 0), 0, now, now + CACHE_TTL))
        con.execute("DELETE FROM ai_cache WHERE expires<?", (now,))
        n = con.execute("SELECT COUNT(*) c FROM ai_cache").fetchone()["c"]
        if n > CACHE_MAX_ROWS:
            con.execute("DELETE FROM ai_cache WHERE id IN "
                        "(SELECT id FROM ai_cache ORDER BY id ASC LIMIT ?)", (n - CACHE_MAX_ROWS,))
        con.commit(); con.close()
        return True
    except Exception:
        return False


def cache_stats():
    """Panel projection: stored questions, cache hits, tokens saved."""
    try:
        r = db._one("SELECT COUNT(*) rows, COALESCE(SUM(hits),0) hits, "
                    "COALESCE(SUM(hits*mtokens),0) saved FROM ai_cache")
        return {"rows": int(r["rows"]), "hits": int(r["hits"]), "saved": int(r["saved"])}
    except Exception:
        return {"rows": 0, "hits": 0, "saved": 0}


def cache_clear():
    try:
        con = db.connect()
        con.execute("DELETE FROM ai_cache")
        con.commit(); con.close()
    except Exception:
        pass


# ------------------------------------------------------------------ threads (v221)
THREAD_TTL = 600         # v270 (دستور مدیر): حافظهٔ چت عمومی ۱۰ دقیقه می‌ماند
THREAD_MAX_MSGS = 20     # stored per thread; prompts only see the last 6
THREAD_WINDOW = 6

# v270 (دستور مدیر): every public-chat exchange is appended to ONE file the
# owner downloads from the admin bot («چت‌ها»). Operational log only —
# user_key is pseudonymous (cust:<id> / <platform>:<uid>) and guest IPs are
# masked to "guest", so the file never holds raw addresses or accounts.
CHAT_LOG = os.path.join(db.DATA_DIR, "site_chats.log")


def chat_log(ctx, text, out_text, source="rule", model="rule", intent=""):
    """Append one public-chat exchange as a JSON line. Never raises."""
    try:
        uk = str(ctx.get("user_key") or "anon")
        if uk.startswith("ip:"):
            uk = "guest"          # shared hardware, not a person
        rec = {"ts": int(time.time()),
               "when": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
               "channel": str(ctx.get("channel") or "web"),
               "user": uk,
               "q": str(text)[:400],
               "a": str(out_text)[:1200],
               "source": str(source), "model": str(model),
               "intent": str(intent or "")}
        with open(CHAT_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return True
    except Exception:
        return False

CHAT_LOG_MAX = 24 * 1024 * 1024   # v275 G20: rotation ceiling for the public log


def chat_log_prune():
    """Hourly sweep hook: if the public chat log outgrows the ceiling, keep the
    newest half. Never raises (a pruning failure must never kill the sweep)."""
    try:
        if not os.path.exists(CHAT_LOG):
            return
        size = os.path.getsize(CHAT_LOG)
        if size <= CHAT_LOG_MAX:
            return
        with open(CHAT_LOG, "rb") as f:
            f.seek(max(0, size - CHAT_LOG_MAX // 2))
            f.readline()                     # drop the partial line
            tail = f.read()
        tmp = CHAT_LOG + ".tmp"
        with open(tmp, "wb") as f:
            f.write(tail)
        os.replace(tmp, CHAT_LOG)
    except Exception:
        pass


def thread_key(ctx):
    """Stable server-thread key, or None when the speaker has no account.

    Linked speakers share one thread across web + bots (cust:<id>); unlinked
    bot users get <platform>:<uid>. Guests (ip:*) are NEVER persisted: the
    key is shared hardware, not a person.
    """
    if ctx.get("customer") or ctx.get("channel") in ("bale", "soroush"):
        return ctx.get("user_key") or None
    return None


def thread_get(tkey, limit=THREAD_WINDOW):
    """Last `limit` turns, oldest-first, as [{role, text}]. Never raises."""
    if not tkey:
        return []
    try:
        rows = db._rows("SELECT role, text FROM ai_threads WHERE tkey=? AND created>? "
                        "ORDER BY id DESC LIMIT ?",
                        (tkey, int(time.time()) - THREAD_TTL, int(limit)))
        return [{"role": r["role"], "text": r["text"]} for r in reversed(rows)]
    except Exception:
        return []


def thread_append(tkey, user_text, bot_text):
    """Append one exchange; enforces the per-thread cap + TTL. Never raises."""
    try:
        if not tkey or (not user_text and not bot_text):
            return False
        now = int(time.time())
        con = db.connect()
        if user_text:
            con.execute("INSERT INTO ai_threads(tkey,role,text,created) VALUES(?,'user',?,?)",
                        (tkey, str(user_text)[:400], now))
        if bot_text:
            con.execute("INSERT INTO ai_threads(tkey,role,text,created) VALUES(?,'assistant',?,?)",
                        (tkey, str(bot_text)[:1200], now))
        con.execute("DELETE FROM ai_threads WHERE tkey=? AND id NOT IN "
                    "(SELECT id FROM ai_threads WHERE tkey=? ORDER BY id DESC LIMIT ?)",
                    (tkey, tkey, THREAD_MAX_MSGS))
        con.execute("DELETE FROM ai_threads WHERE created<?", (now - THREAD_TTL,))
        con.commit(); con.close()
        return True
    except Exception:
        return False


def threads_active():
    try:
        r = db._one("SELECT COUNT(DISTINCT tkey) n FROM ai_threads WHERE created>?",
                    (int(time.time()) - THREAD_TTL,))
        return int(r["n"])
    except Exception:
        return 0


def threads_forget(tkey):
    """Wipe one thread (explicit user request; account delete in features)."""
    try:
        con = db.connect()
        con.execute("DELETE FROM ai_threads WHERE tkey=?", (tkey,))
        con.commit(); con.close()
    except Exception:
        pass


# ------------------------------------------------------------------ safe tools (v223)
# The model NEVER acts: it may only propose {"name", "args"} inside its answer
# JSON. The server validates (allow-list, schema, login, ownership, live
# policy), executes through the SAME functions the site uses, and audit-logs.
# Trivially reversible `favorite` runs at once (+ undo hint); cancellations
# need a second user turn («بله») within 10 minutes.
TOOLS = ("favorite", "cancel_booking", "cancel_order", "book", "review")
TOOL_TTL = 600

_CONFIRM_RE = re.compile(r"^(بله|آره|اره|تأیید|تاييد|انجام بده|انجامش بده|حتماً|اوکی|ok|yes)\b", re.U)
_DECLINE_RE = re.compile(r"^(نه|خیر|نخیر|لغو|کنسل|انصراف|نه ممنون|no)\b", re.U)


def parse_tool_call(obj):
    """Strict-validate a model-proposed tool call. Returns (name, args) or
    (None, {}). Unknown tools, bad shapes and invented ids never pass."""
    try:
        if not isinstance(obj, dict):
            return None, {}
        name = str(obj.get("name") or "").strip()
        if name not in TOOLS:
            return None, {}
        args = obj.get("args")
        if not isinstance(args, dict):
            return None, {}
        if name == "favorite":
            slug = str(args.get("slug") or "").strip()[:80]
            if not slug or "/" in slug or " " in slug:
                return None, {}
            return name, {"slug": slug}
        if name == "book":
            # Loose here, strict in precheck (which explains failures to the
            # user instead of silently dropping the call).
            slug = str(args.get("slug") or "").strip()[:80]
            date = str(args.get("date") or "").strip()[:20]
            tm = str(args.get("time") or "").strip()[:20]
            nm = str(args.get("name") or "").strip()[:50]
            if not slug or "/" in slug or " " in slug or not date or not tm:
                return None, {}
            return name, {"slug": slug, "date": date, "time": tm, "name": nm}
        if name == "review":
            slug = str(args.get("slug") or "").strip()[:80]
            body = str(args.get("body") or "").strip()
            if not slug or "/" in slug or " " in slug or not body or len(body) > 2000:
                return None, {}
            return name, {"slug": slug, "body": body}
        if name not in ("cancel_booking", "cancel_order"):
            return None, {}
        bid = args.get("id")
        try:
            bid = int(str(bid).strip())
        except (TypeError, ValueError):
            return None, {}
        if bid <= 0 or bid > 1_000_000_000:
            return None, {}
        return name, {"id": bid}
    except Exception:
        return None, {}


def pending_save(user_key, tool, args):
    """One outstanding confirmation per user: a new proposal replaces the old."""
    try:
        now = int(time.time())
        con = db.connect()
        con.execute("DELETE FROM ai_tool_pending WHERE user_key=?", (user_key,))
        cur = con.execute("INSERT INTO ai_tool_pending(user_key,tool,args,created,expires) "
                          "VALUES(?,?,?,?,?)",
                          # v225: review bodies ride along (≤2000 chars); ids/slugs stay tiny.
                          (user_key, tool, json.dumps(args, ensure_ascii=False)[:4000],
                           now, now + TOOL_TTL))
        pid = cur.lastrowid
        con.execute("DELETE FROM ai_tool_pending WHERE expires<?", (now,))
        con.commit(); con.close()
        return pid
    except Exception:
        return 0


def pending_get(user_key):
    try:
        con = db.connect()
        con.execute("DELETE FROM ai_tool_pending WHERE expires<?", (int(time.time()),))
        con.commit()
        r = db._one("SELECT id, tool, args FROM ai_tool_pending WHERE user_key=? "
                    "ORDER BY id DESC LIMIT 1", (user_key,))
        con.close()
        if not r:
            return None
        try:
            args = json.loads(r["args"] or "{}")
        except ValueError:
            args = {}
        if not isinstance(args, dict):
            args = {}
        return {"id": r["id"], "tool": r["tool"], "args": args}
    except Exception:
        return None


def pending_clear(user_key):
    try:
        con = db.connect()
        con.execute("DELETE FROM ai_tool_pending WHERE user_key=?", (user_key,))
        con.commit(); con.close()
    except Exception:
        pass


def _tool_customer(ctx):
    c = ctx.get("customer")
    return c if isinstance(c, dict) and c.get("id") else None


def _norm_jalali(ds):
    """v225: normalize a model/user Jalali date to 'YYYY/MM/DD' or ''.

    Accepts Persian digits and -/. separators; checks real month lengths
    (Esfand 29/30 via a g2j probe — no second calendar implementation)
    and rejects past dates. 13xx/14xx years only: Gregorian is refused.
    """
    try:
        s = db.normalize_fa(ds).strip().replace("-", "/").replace(".", "/").replace(" ", "")
        m = re.match(r"^((?:13|14)\d\d)/(0?[1-9]|1[0-2])/(0?[1-9]|[12]\d|3[01])$", s)
        if not m:
            return ""
        jy, jm, jd = int(m.group(1)), int(m.group(2)), int(m.group(3))
        maxd = 31 if jm <= 6 else 30
        if jm == 12 and g2j(jy + 622, 3, 20) != (jy, 12, 30):
            maxd = 29
        if jd > maxd:
            return ""
        norm = f"{jy:04d}/{jm:02d}/{jd:02d}"
        t = datetime.date.today()
        jy0, jm0, jd0 = g2j(t.year, t.month, t.day)
        if norm < f"{jy0:04d}/{jm0:02d}/{jd0:02d}":
            return ""
        return norm
    except Exception:
        return ""


def _norm_time(ts):
    """v225: normalize a clock time to 'HH:MM' (24h) or ''."""
    try:
        m = re.match(r"^([01]?\d|2[0-3]):([0-5]\d)$", db.normalize_fa(ts).strip().replace(" ", ""))
        return f"{int(m.group(1)):02d}:{m.group(2)}" if m else ""
    except Exception:
        return ""


def _tool_identity(ctx):
    """v225: fresh (name, phone) for the caller's account — the ctx copy may
    be stale, and bookings/reviews are written under this name."""
    try:
        cust = _tool_customer(ctx)
        r = db._one("SELECT name, phone FROM customers WHERE id=?", (cust["id"],)) if cust else None
        if r:
            return (str(r["name"] or "").strip(), str(r["phone"] or "").strip())
        if cust:
            return (str(cust.get("name") or "").strip(), str(cust.get("phone") or "").strip())
    except Exception:
        pass
    return "", ""


def _tool_fail_text(tool, why):
    """v225: user-facing sentence for a precheck failure. The cancel texts
    are byte-identical legacy (v223 tests pin them)."""
    if tool in ("cancel_booking", "cancel_order"):
        if why == "missing":
            return "\n\nولی چنین موردی برای شما پیدا نکردم؛ لطفاً از فهرست خودتان انتخاب کنید."
        return "\n\nولی آن مورد قبلاً نهایی شده و قابل لغو نیست."
    if tool == "book":
        t = datetime.date.today() + datetime.timedelta(days=1)
        jy, jm, jd = g2j(t.year, t.month, t.day)
        ex = _fa(f"{jy}/{jm:02d}/{jd:02d}")
        return {
            "missing": "\n\nولی آن کسب‌وکار را پیدا نکردم؛ از لینک‌های همین گفت‌وگو انتخاب کنید.",
            "nobook": "\n\nولی آن کسب‌وکار فعلاً نوبت نمی‌پذیرد.",
            "noname": "\n\nولی اسمتان را نمی‌دانم؛ نام و نام خانوادگی‌تان را بگویید.",
            "baddate": f"\n\nولی تاریخ نامعتبر است؛ یک تاریخ شمسی از امروز به بعد بگویید (مثلاً {ex}).",
            "badtime": "\n\nولی ساعت نامعتبر است؛ ساعت را ۲۴ساعته بگویید (مثلاً ۱۷:۳۰).",
        }.get(why, "\n\nولی نتوانستم نوبت را آماده کنم؛ لطفاً از صفحهٔ کسب‌وکار اقدام کنید.")
    if tool == "review":
        return {
            "missing": "\n\nولی آن کسب‌وکار را پیدا نکردم؛ از لینک‌های همین گفت‌وگو انتخاب کنید.",
            "self": "\n\nولی به کسب‌وکار خودتان نمی‌توانید نظر ثبت کنید.",
            "emptybody": "\n\nولی متن نظر خالی است؛ نظرتان را در یک جمله بگویید.",
        }.get(why, "\n\nولی نتوانستم نظر را آماده کنم؛ لطفاً از صفحهٔ کسب‌وکار اقدام کنید.")
    return "\n\nولی نتوانستم انجامش دهم."


def tool_describe(tool, args, ctx):
    """Live one-liner for the confirm question. Never raises."""
    try:
        cust = _tool_customer(ctx)
        if tool == "cancel_booking" and cust:
            r = db._one("SELECT k.date, k.time, k.status, b.name biz FROM bookings k "
                        "JOIN businesses b ON b.id=k.biz_id WHERE k.id=? AND k.customer_id=?",
                        (args.get("id"), cust["id"]))
            if r:
                return f"نوبت «{r['biz']}» در {r['date']} ساعت {r['time']}"
        if tool == "cancel_order" and cust:
            r = db._one("SELECT o.id, o.total, b.name biz FROM orders o LEFT JOIN businesses b "
                        "ON b.id=o.biz_id WHERE o.id=? AND o.customer_id=?", (args.get("id"), cust["id"]))
            if r:
                return f"سفارش #{r['id']} از «{r['biz'] or ''}» ({r['total'] or 0} تومان)"
        if tool == "favorite":
            b = db.business(slug=args.get("slug") or "")
            if b:
                return f"«{b['name']}»"
        if tool == "book" and cust:
            b = db.business(slug=args.get("slug") or "")
            if b:
                nm = str(args.get("name") or "").strip() or _tool_identity(ctx)[0]
                return (f"ثبت نوبت «{b['name']}» در {_fa(_norm_jalali(args.get('date')))} "
                        f"ساعت {_fa(_norm_time(args.get('time')))} به نام {nm}")
        if tool == "review" and cust:
            b = db.business(slug=args.get("slug") or "")
            if b:
                body = str(args.get("body") or "").strip()
                return f"ثبت این نظر برای «{b['name']}»: «{body[:160]}»" + ("…" if len(body) > 160 else "")
    except Exception:
        pass
    return ""


def tool_precheck(tool, args, ctx):
    """Dry-run policy WITHOUT writing. Returns (ok, reason)."""
    try:
        cust = _tool_customer(ctx)
        if not cust:
            return False, "login"
        if tool == "favorite":
            b = db.business(slug=args.get("slug") or "")
            return (True, "") if b and b.get("status") == "published" else (False, "missing")
        if tool == "cancel_booking":
            r = db._one("SELECT status FROM bookings WHERE id=? AND customer_id=?",
                        (args.get("id"), cust["id"]))
            if not r:
                return False, "missing"
            return (True, "") if r["status"] in ("new", "confirmed") else (False, "final")
        if tool == "cancel_order":
            r = db._one("SELECT status FROM orders WHERE id=? AND customer_id=?",
                        (args.get("id"), cust["id"]))
            if not r:
                return False, "missing"
            return (True, "") if r["status"] not in ("done", "cancelled") else (False, "final")
        if tool == "book":
            b = db.business(slug=args.get("slug") or "")
            if not b:
                return False, "missing"
            if not b.get("booking_on"):
                return False, "nobook"
            nm = str(args.get("name") or "").strip() or _tool_identity(ctx)[0]
            if len(nm) < 2:
                return False, "noname"
            if not _norm_jalali(args.get("date")):
                return False, "baddate"
            if not _norm_time(args.get("time")):
                return False, "badtime"
            return True, ""
        if tool == "review":
            b = db.business(slug=args.get("slug") or "")
            if not b:
                return False, "missing"
            owner_ph = db.business_owner_phone(b["id"])
            if owner_ph and _tool_identity(ctx)[1] == owner_ph:
                return False, "self"
            if not str(args.get("body") or "").strip():
                return False, "emptybody"
            return True, ""
    except Exception:
        return False, "error"
    return False, "error"


def tool_execute(tool, args, ctx):
    """Run a validated tool through the site's own functions. Returns
    (ok, message, links). Re-validates everything; audit-logs; never raises."""
    links = []
    try:
        cust = _tool_customer(ctx)
        if not cust:
            return False, "برای این کار باید وارد حساب شوید.", [("ورود", "/login")]
        cid = cust["id"]
        if tool == "favorite":
            ok, why = tool_precheck(tool, args, ctx)
            if not ok:
                return False, "آن کسب‌وکار را پیدا نکردم؛ از لینک‌های همین گفت‌وگو انتخاب کنید.", []
            import features
            b = db.business(slug=args["slug"])
            on = features.fav_toggle(cid, b["id"])
            db.log("assistant_tool", f"favorite user=cust:{cid} biz={b['id']} on={int(bool(on))}")
            links = [("علاقه‌مندی‌ها", "/me/favorites"), (b["name"][:28], f"/b/{b['slug']}")]
            if on:
                return True, f"💾 «{b['name']}» ذخیره شد. برای لغو، دوباره همین را بخواهید.", links
            return True, f"«{b['name']}» از ذخیره‌ها برداشته شد.", links
        if tool == "cancel_booking":
            res = db.customer_booking_cancel(cid, args["id"])
            if res == "cancelled":
                db.log("assistant_tool", f"cancel_booking user=cust:{cid} booking={args['id']}")
                return True, f"🗓 نوبت لغو شد. ({tool_describe(tool, args, ctx)})", [("نوبت‌های من", "/me")]
            if res == "missing":
                return False, "نوبتی با این مشخصات برای شما پیدا نکردم.", [("نوبت‌های من", "/me")]
            return False, "این نوبت قبلاً نهایی شده و قابل لغو نیست.", [("نوبت‌های من", "/me")]
        if tool == "cancel_order":
            import features
            res = features.request_order_cancel(args["id"], cid, "لغو از دستیار هوشمند")
            if not res.get("ok"):
                if res.get("error") == "access":
                    return False, "سفارشی با این مشخصات برای شما پیدا نکردم.", [("سفارش‌ها", "/me/orders")]
                return False, "این سفارش قبلاً نهایی شده و قابل لغو نیست.", [("سفارش‌ها", "/me/orders")]
            db.log("assistant_tool", f"cancel_order user=cust:{cid} order={args['id']} result={res.get('result')}")
            links = [(f"سفارش #{args['id']}", f"/me/order/{args['id']}")]
            if res.get("result") == "cancelled":
                return True, "🧾 سفارش لغو شد.", links
            return True, "🧾 مهلت لغو مستقیم گذشته؛ درخواست لغو برای دکان‌دار فرستاده شد و نتیجه را خبر می‌دهم.", links
        if tool == "book":
            import sms
            slug = str(args.get("slug") or "")
            b = db.business(slug=slug)
            blink = [(b["name"][:28], f"/b/{slug}")] if b else []
            ok, why = tool_precheck(tool, args, ctx)
            if not ok:
                return False, _tool_fail_text(tool, why).strip(), blink
            nm = str(args.get("name") or "").strip() or _tool_identity(ctx)[0]
            date, tm = _norm_jalali(args.get("date")), _norm_time(args.get("time"))
            kid = db.add_booking(b["id"], nm, _tool_identity(ctx)[1], date, tm, "", cid)
            sms.notify_owner(db.get_settings(), f"رزرو نوبت جدید برای «{b['name']}» در {date} {tm}")
            db.log("assistant_tool", f"book user=cust:{cid} biz={b['id']} booking={kid} date={date} time={tm}")
            links = [(b["name"][:28], f"/b/{b['slug']}"), ("نوبت‌های من", "/me")]
            return True, f"🗓 نوبت «{b['name']}» در {_fa(date)} ساعت {_fa(tm)} به نام {nm} ثبت شد.", links
        if tool == "review":
            import sms
            slug = str(args.get("slug") or "")
            b = db.business(slug=slug)
            blink = [(b["name"][:28], f"/b/{slug}")] if b else []
            ok, why = tool_precheck(tool, args, ctx)
            if not ok:
                return False, _tool_fail_text(tool, why).strip(), blink
            body = str(args.get("body") or "").strip()[:2000]
            author = _tool_identity(ctx)[0] or "کاربر دست‌گیر"
            auto = db.get_settings().get("reviews_moderated") != "1"
            rid = db.add_review_full(b["id"], author, 0, body, auto_approve=auto, customer_id=cid)
            sms.notify_owner(db.get_settings(), f"نظر جدید برای «{b['name']}» از {author}")
            db.log("assistant_tool", f"review user=cust:{cid} biz={b['id']} review={rid}")
            links = [(b["name"][:28], f"/b/{b['slug']}")]
            tail = "نمایش داده شد." if auto else "پس از تأیید نمایش داده می‌شود."
            return True, f"⭐ نظر شما برای «{b['name']}» ثبت شد؛ {tail}", links
    except Exception:
        pass
    return False, "نتوانستم انجامش دهم؛ لطفاً از مسیر سایت اقدام کنید.", []


def _parse_tool_detail(detail):
    """v227: 'tool k=v k=v...' → (tool, dict). Unknown keys tolerated so the
    owner page never breaks when a format gains a field."""
    try:
        parts = str(detail or "").split()
        if not parts or parts[0] not in TOOLS:
            return None, {}
        kv = {}
        for p in parts[1:]:
            if "=" in p:
                k, v = p.split("=", 1)
                kv[k] = v
        return parts[0], kv
    except Exception:
        return None, {}


def _tool_customer_label(cid):
    """v227: account name, else a masked phone, else «مشتری». Never raises."""
    try:
        r = db._one("SELECT name, phone FROM customers WHERE id=?", (int(cid),))
    except (TypeError, ValueError):
        return "مشتری"
    if not r:
        return "مشتری"
    nm = str(r["name"] or "").strip()
    if nm:
        return nm
    ph = db.norm_phone(r["phone"] or "")
    return ph[:4] + "••••" + ph[-3:] if len(ph) == 11 else "مشتری"


def _owned_tool_event(owner_id, detail):
    """v227: one audit detail → (tool, text, link) for this owner's shops,
    or None (foreign/malformed/deleted). Never raises."""
    try:
        tool, kv = _parse_tool_detail(detail)
        if not tool:
            return None
        try:
            cid = int(str(kv.get("user", "")).split("cust:", 1)[1])
        except (IndexError, ValueError):
            return None
        who = _tool_customer_label(cid)
        if tool in ("favorite", "book", "review"):
            try:
                bid = int(kv.get("biz", 0))
            except ValueError:
                return None
            b = db.business(bid=bid) or {}
            if not b or not db.owns(owner_id, bid):
                return None
            name = b.get("name") or ""
            if tool == "favorite":
                verb = "ذخیره کرد" if kv.get("on") == "1" else "از ذخیره‌ها برداشت"
                return tool, f"{who} «{name}» را {verb}", f"/b/{b.get('slug') or ''}"
            if tool == "book":
                return tool, (f"نوبت تازه «{name}» برای {who} "
                              f"({kv.get('date', '')} ساعت {kv.get('time', '')})"), "/my/bookings"
            return tool, f"نظر تازهٔ {who} روی «{name}»", "/my/reviews"
        if tool == "cancel_booking":
            try:
                k = db._one("SELECT biz_id, date, time FROM bookings WHERE id=?",
                            (int(kv.get("booking", 0)),))
            except ValueError:
                return None
            if not k or not db.owns(owner_id, k["biz_id"]):
                return None
            b = db.business(bid=k["biz_id"]) or {}
            return tool, (f"{who} نوبت {k['date']} ساعت {k['time']} "
                          f"«{b.get('name') or ''}» را لغو کرد"), "/my/bookings"
        if tool == "cancel_order":
            try:
                o = db._one("SELECT biz_id FROM orders WHERE id=?", (int(kv.get("order", 0)),))
            except ValueError:
                return None
            if not o or not db.owns(owner_id, o["biz_id"]):
                return None
            if kv.get("result") == "requested":
                return tool, f"درخواست لغو سفارش #{kv.get('order')} از {who} — نیاز به تصمیم شما", "/my/orders"
            return tool, f"{who} سفارش #{kv.get('order')} را لغو کرد", "/my/orders"
    except Exception:
        pass
    return None


def owner_assistant_data(owner_id, limit=50):
    """v227: what the assistant did for one owner's shops — latest rows,
    7-day per-tool counts, open cancel requests. Never raises."""
    out = {"rows": [], "counts": {t: 0 for t in TOOLS}, "pending_cancels": 0}
    try:
        oid = int(owner_id)
    except (TypeError, ValueError):
        return out
    try:
        try:
            out["pending_cancels"] = sum(
                1 for o in db.orders_for_owner(oid) if o.get("cancel_requested"))
        except Exception:
            pass
        # Note: exact match on purpose — db.audit_log is a prefix filter
        # (v228 fixed its "_" handling, but prefix is still wrong here).
        for r in db._rows("SELECT detail, created FROM audit WHERE action='assistant_tool' "
                          "ORDER BY id DESC LIMIT 400"):
            ev = _owned_tool_event(oid, r.get("detail"))
            if ev and len(out["rows"]) < limit:
                out["rows"].append({"tool": ev[0], "text": ev[1], "link": ev[2],
                                    "created": r.get("created") or ""})
        for r in db._rows("SELECT detail FROM audit WHERE action='assistant_tool' "
                          "AND created >= datetime('now', '-7 days') ORDER BY id DESC LIMIT 5000"):
            ev = _owned_tool_event(oid, r.get("detail"))
            if ev and ev[0] in out["counts"]:
                out["counts"][ev[0]] += 1
    except Exception:
        pass
    return out


def digest_counts(owner_id):
    """v231: current-state assistant numbers for the owner morning digest —
    tool events in the rolling 24h (owned shops only) + open cancel requests.
    Never raises."""
    out = {"tool_events": 0, "open_cancels": 0}
    try:
        oid = int(owner_id)
    except (TypeError, ValueError):
        return out
    try:
        out["open_cancels"] = sum(
            1 for o in db.orders_for_owner(oid) if o.get("cancel_requested"))
    except Exception:
        pass
    try:
        for r in db._rows("SELECT detail FROM audit WHERE action='assistant_tool' "
                          "AND created >= datetime('now','-1 day') LIMIT 2000"):
            if _owned_tool_event(oid, r.get("detail")):
                out["tool_events"] += 1
    except Exception:
        pass
    return out


def generate(text, ctx, history=None, hint=("unknown", "")):
    """Grounded free-form answer from the model.
    Returns (parsed|None, tokens, calls, used_smart).

    v269 (دستور مدیر): چت عمومی سایت فقط از اسلات مستقل هوش سایت
    (AI_SITE_*) می‌خواند — نه از مغزهای مدیر؛ کلید نبود = None یعنی
    پاسخ قاعده‌مند + کش (بدون تماس با محیط مدیر)."""
    c = site_config()
    want_smart = bool(c["model_smart"]) and needs_smart(text, history)
    attempts = []
    if c["base_url"] and c["api_key"]:
        attempts.append((c["base_url"], c["api_key"],
                         c["model_smart"] if want_smart else c["model"], want_smart))
    # v265: no fallback, ever (owner order) — the chosen brain answers or
    # nobody does; the recorded error tells «تشخیص» the exact reason.
    if not attempts:
        return None, 0, 0, False
    context = build_context(text, hint[1], ctx, history)
    msgs = [{"role": "system", "content": ANSWER_PROMPT + "\n\n# داده‌های سایت (تنها منبع مجاز)\n" + context}]
    for h in (history or [])[-6:]:
        msgs.append({"role": "assistant" if h.get("role") == "assistant" else "user", "content": _norm(h.get("text"))[:400]})
    msgs.append({"role": "user", "content": _norm(text)[:400]})
    calls = 0
    for i, (base, key, model, is_smart) in enumerate(attempts):
        calls += 1
        try:
            content, tokens = _chat(base, key, model, msgs, c["timeout"], max_tokens=700)
            parsed = parse_answer_json(content)
            if parsed:
                _record_provider("smart" if is_smart else "primary", model)
                return parsed, tokens, calls, is_smart
            _record_error("bad-json:" + model)
        except urllib.error.HTTPError as e:
            _record_error(f"http-{e.code}:{model}")
        except Exception as e:
            _record_error(type(e).__name__ + ":" + model)
    return None, 0, calls, False


# ------------------------------------------------------------------ answers
def _fa(n):
    return str(n).translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))


def _price(v):
    try:
        v = int(v)
    except (TypeError, ValueError):
        return ""
    return "رایگان" if v == 0 else _fa(f"{v:,}") + " تومان"


def _search_answer(q, ctx):
    q = _norm(q)[:60]
    if len(db.normalize_fa(q)) < 2:
        return {"text": "چه چیزی را جست‌وجو کنم؟ مثلاً «داروخانه شبانه‌روزی» یا «کافه».",
                "links": [("جست‌وجو در سایت", "/businesses")]}
    rows = db.search_business_summaries(q, 5)
    if not rows:
        return {"text": f"برای «{q}» کسب‌وکاری پیدا نکردم. عبارت دیگری امتحان کنید یا در فهرست بگردید.",
                "links": [("فهرست کسب‌وکارها", "/businesses?q=" + urllib.parse.quote(q))]}
    lines = [f"🔍 {_fa(len(rows))} نتیجه برای «{q}»:"]
    links = []
    for r in rows:
        tag = " ✅" if r.get("verified") else ""
        addr = (r.get("address") or "").strip()
        lines.append(f"• {r['name']}{tag}" + (f" — {addr[:50]}" if addr else ""))
        links.append((r["name"][:28], f"/b/{r['slug']}"))
    links.append(("همهٔ نتایج", "/businesses?q=" + urllib.parse.quote(q)))
    return {"text": "\n".join(lines), "links": links[:6]}


def _orders_answer(ctx):
    cust = ctx.get("customer")
    if not cust:
        return {"text": "برای دیدن سفارش‌ها باید وارد حساب شوید.", "links": [("ورود", "/login?next=/me/orders")]}
    import features
    rows = features.customer_order_summaries(cust["id"], 5)
    if not rows:
        return {"text": "هنوز سفارشی ثبت نکرده‌اید. از صفحهٔ کسب‌وکارهایی که کاتالوگ دارند می‌توانید سفارش دهید.",
                "links": [("محصولات", "/catalog")]}
    lines = ["📦 سفارش‌های اخیر شما:"]
    for r in rows:
        lines.append(f"• #{_fa(r['id'])} — {r['bizname']} — {r.get('status_label') or r.get('status')} — {_price(r.get('total'))}")
    return {"text": "\n".join(lines), "links": [("همهٔ سفارش‌ها", "/me/orders")]}


def _bookings_answer(ctx):
    cust = ctx.get("customer")
    if not cust:
        return {"text": "برای دیدن نوبت‌ها باید وارد حساب شوید.", "links": [("ورود", "/login?next=/me")]}
    rows = db.customer_booking_summaries(cust["id"], 5)
    if not rows:
        return {"text": "نوبتی ثبت نشده است. کسب‌وکارهایی که نوبت‌دهی دارند دکمهٔ «رزرو» دارند.",
                "links": [("کسب‌وکارها", "/businesses")]}
    lines = ["📅 نوبت‌های اخیر شما:"]
    for r in rows:
        lines.append(f"• {r['bizname']} — {r['date']} {r['time']} — {r.get('status_label') or r.get('status')}")
    return {"text": "\n".join(lines), "links": [("حساب من", "/me")]}


def _favorites_answer(ctx):
    cust = ctx.get("customer")
    if not cust:
        return {"text": "علاقه‌مندی‌ها پس از ورود در دسترس است.", "links": [("ورود", "/login?next=/me/favorites")]}
    rows = db._rows("SELECT b.name, b.slug FROM favorites f JOIN businesses b ON b.id=f.biz_id "
                    "WHERE f.customer_id=? AND b.status='published' ORDER BY f.id DESC LIMIT 5", (cust["id"],))
    if not rows:
        return {"text": "هنوز چیزی ذخیره نکرده‌اید. روی قلب کنار هر کسب‌وکار بزنید.", "links": [("کسب‌وکارها", "/businesses")]}
    return {"text": "❤️ ذخیره‌شده‌های شما: " + "، ".join(r["name"] for r in rows),
            "links": [(r["name"][:28], f"/b/{r['slug']}") for r in rows[:3]] + [("علاقه‌مندی‌ها", "/me/favorites")]}


def _plans_answer():
    rows = db.plans()
    lines = ["💳 پلن‌های دست گیر:"]
    for p in rows:
        months = p.get("months") or 12
        lines.append(f"• {p['name']} — {_price(p.get('price'))}" + ("" if int(p.get('price') or 0) == 0 else f" / {_fa(months)} ماه")
                     + (f" — {p['tagline']}" if p.get("tagline") else ""))
    lines.append("ثبت کسب‌وکار همیشه رایگان است.")
    return {"text": "\n".join(lines), "links": [("تعرفه‌ها", "/pricing"), ("ثبت رایگان", "/register-business")]}


def _near_answer(ctx, q=""):
    if ctx.get("channel") in ("bale", "soroush"):
        return {"text": "📍 برای دیدن کسب‌وکارهای بازِ نزدیک، موقعیت مکانی خود را همین‌جا ارسال کنید (گیرهٔ پیوست ← موقعیت). موقعیت فقط برای همین جست‌وجو استفاده و ذخیره نمی‌شود.",
                "links": [("نزدیک من در سایت", "/nearby")]}
    latlon = _coords(ctx or {})
    if latlon:
        try:
            rows = db.nearby(latlon[0], latlon[1], 5.0, term=q or "", limit=60)
        except Exception:
            rows = []
        rows = [b for b in rows if b.get("status") == "published"][:5]
        if rows:
            lines = [f"📍 {_fa(len(rows))} کسب‌وکار نزدیک شما:"]
            links = []
            for b in rows:
                try:
                    open_now = db.is_open_now(b) if b.get("hours") else None
                except Exception:
                    open_now = None
                mark = "🟢" if open_now is True else ("🔴" if open_now is False else "•")
                lines.append(f"{mark} {b['name']} — {_dist_str(b.get('distance_km'))}"
                             + (" (الان باز)" if open_now is True else (" (بسته)" if open_now is False else "")))
                links.append((b["name"][:28], f"/b/{b['slug']}"))
            links.append(("نقشهٔ کامل", "/map"))
            return {"text": "\n".join(lines), "links": links[:6]}
        return {"text": "📍 در ۵ کیلومتری شما کسب‌وکاری ثبت نشده است. نقشهٔ کامل شهر را ببینید.",
                "links": [("نقشه", "/map"), ("نزدیک من", "/nearby")]}
    return {"text": "📍 صفحهٔ «نزدیک من» با اجازهٔ موقعیت، کسب‌وکارهای باز اطراف شما را با فاصله نشان می‌دهد. "
                    "💡 اگر موقعیت مکانی را در مرورگر فعال کرده باشید، همین‌جا هم فاصلهٔ دقیق را می‌گویم.",
            "links": [("نزدیک من", "/nearby"), ("نقشه", "/map")]}


def _faq_answer(text, reply=""):
    if reply:
        return {"text": reply, "links": [("راهنمای کامل", "/contact")]}
    low = _norm(text).lower()
    best = None
    for q, a in _knowledge_pool():
        words = [w for w in re.split(r"[\s،؟?]+", q) if len(w) > 2]
        score = sum(1 for w in words if w in low)
        if score and (best is None or score > best[0]):
            best = (score, a)
    if best:
        return {"text": best[1], "links": [("راهنما", "/contact")]}
    return _offline_answer(text) or _help_answer()   # v274: هوش آفلاین


def _help_answer():
    return {"text": ("من دستیار دست گیر هستم و فقط دربارهٔ همین سایت کمک می‌کنم:\n"
                     "• جست‌وجوی مغازه و خدمات (مثلاً «داروخانه شبانه‌روزی»)\n"
                     "• کسب‌وکارهای نزدیک شما\n• ثبت یا تصاحب کسب‌وکار\n"
                     "• سفارش‌ها و نوبت‌های شما\n• پلن‌ها و تعرفه‌ها\n• پشتیبانی تیکتی"),
            "links": [("جست‌وجو", "/businesses"), ("نزدیک من", "/nearby"), ("ثبت کسب‌وکار", "/register-business")]}


def _off_topic_answer():
    return {"text": "این دستیار فقط برای کارهای دست گیر است (جست‌وجوی کسب‌وکار، نزدیک من، ثبت کسب‌وکار، سفارش‌ها، نوبت‌ها، تعرفه‌ها و پشتیبانی). دربارهٔ موضوعات دیگر نمی‌توانم کمک کنم.",
            "links": [("راهنما", "/contact")]}


def compose(intent, q, text, ctx, reply=""):
    """Turn a (validated) intent into the final answer. Pure read paths."""
    if intent == "search":
        out = _search_answer(q or text, ctx)
        # v274 (دستور مدیر): «هوش آفلاین» باید آموزش‌دیده باشد — وقتی جست‌وجو
        # هیچ کسب‌وکاری پیدا نکرد ولی جمله یک موضوع شناخته‌شدهٔ سایت است
        # («ساعت کاری چنده؟»، «پرداخت چطوریه؟»)، بن‌بست «پیدا نکردم» نمی‌دهیم.
        if "کسب‌وکاری پیدا نکردم" in out["text"]:
            alt = _offline_answer(text)
            if alt:
                return alt
        return out
    if intent == "near":
        out = _near_answer(ctx, q)
        if q:
            out["links"].insert(0, (f"«{q}» نزدیک من", "/nearby?q=" + urllib.parse.quote(q)))
        return out
    if intent == "orders":
        return _orders_answer(ctx)
    if intent == "bookings":
        return _bookings_answer(ctx)
    if intent == "favorites":
        return _favorites_answer(ctx)
    if intent == "plans":
        return _plans_answer()
    if intent == "register":
        return {"text": "➕ ثبت کسب‌وکار رایگان است و چند دقیقه طول می‌کشد: نام، دسته، نشانی و ساعت کاری. پس از تأیید مدیر منتشر می‌شود.",
                "links": [("شروع ثبت", "/register-business"), ("تعرفه‌ها", "/pricing")]}
    if intent == "claim":
        return {"text": "اگر کسب‌وکارتان از قبل در سایت هست، وارد شوید و از «تصاحب کسب‌وکار» درخواست دهید؛ با یکی‌بودن شماره فوراً وصل می‌شود.",
                "links": [("تصاحب کسب‌وکار", "/my/claim")]}
    if intent == "support":
        target = "/my/tickets" if (ctx.get("owner") or ctx.get("customer")) else "/login?next=/my/tickets"
        return {"text": "🛟 پشتیبانی فقط از مسیر تیکت انجام می‌شود تا پاسخ و وضعیت رسیدگی را در حساب خود ببینید.",
                "links": [("ثبت تیکت", target)]}
    if intent == "login":
        if ctx.get("customer") or ctx.get("owner"):
            return {"text": "شما وارد حساب هستید.", "links": [("حساب من", "/me")]}
        return {"text": "ورود فقط با بله یا سروش انجام می‌شود؛ در صفحهٔ ورود دکمهٔ «ورود با …» را بزنید.", "links": [("ورود", "/login")]}
    if intent == "owner":
        return {"text": "🏪 پنل کسب‌وکار: سفارش‌ها، نوبت‌ها، گالری، کاتالوگ و آمار در «کسب‌وکارهای من».",
                "links": [("پنل کسب‌وکار", "/my"), ("ثبت کسب‌وکار جدید", "/register-business")]}
    if intent == "account":
        return {"text": "حساب شما: سفارش‌ها، نوبت‌ها، علاقه‌مندی‌ها و اتصال به بله/سروش در «حساب من».",
                "links": [("حساب من", "/me")]}
    if intent == "greeting":
        return {"text": "سلام! من دستیار دست گیر هستم. دنبال چه کسب‌وکار یا خدمتی هستید؟",
                "links": [("نزدیک من", "/nearby"), ("ثبت کسب‌وکار", "/register-business")]}
    if intent == "faq":
        return _faq_answer(text, reply)
    if intent == "off_topic":
        # v274: پیش از «نمی‌توانم کمک کنم»، مغز آفلاین یک فرصت دارد.
        return _offline_answer(text) or _off_topic_answer()
    return _offline_answer(text) or _help_answer()   # v274: هوش آفلاین


# ------------------------------------------------------------------ entry
# ------------------------------------------- v238→v239: admin copilot (+content tools)
ADMIN_PROMPT = (
    "تو «دستیار مدیر» سایت دستگیر هستی و فقط با خود مدیر حرف می‌زنی.\n"
    "به کل سایت دسترسی داری: هم محتوا (متن‌ها، کسب‌وکارها، محصولات، …) و هم «کد سایت» "
    "(هر فایل متنی: قالب‌ها، استایل‌ها، اسکریپت‌ها، منطق سرور). تغییر هر کدام در اختیار توست. "
    "عددها را فقط از داده‌ها بیاور و حدس نزن.\n\n"
    "# ابزارهای تو — محتوا + کدِ کل سایت\n"
    "برای هر درخواست تغییر «بدون استثنا» ابزار مناسب را با مقادیر کامل و نهایی پیشنهاد بده:\n"
    "- setting {key,value}: هر کلید تنظیماتی که در فهرست محتوا می‌بینی (tagline, description, hero_title, "
    "hero_lead, hero_cta, footer_note, address, email, phone, whatsapp, site_url, "
    "instagram/telegram/eitaa/bale/soroush/rubika, map_lat, map_lng, map_zoom, "
    "order_cancel_minutes, founder_limit, کلیدهای روشن/خاموش مانند prices_enabled و حر کلید دیگری که در تنظیمات موجودست؛ حتی کلیدهای ورود (owner_token، owner_pass_hash، panel_allow_ips، admin_bot)). "
    "چند تنظیم را یک‌جا در items بفرست (حداکثر ۸): {items:[{key,value},…]} — مثلاً هر ۴ رنگ با هم (رنگ اصلی=color_primary، رنگ تأکید=color_accent، پس‌زمینه=color_background، متن اصلی=color_foreground). پیشنهاد معتبر فوراً اجرا می‌شود؛ تأیید نخواه.\n"
    "- page {slug,title,body}: بازنویسی کامل صفحهٔ about یا rules (یا هر صفحهٔ موجود دیگر).\n"
    "- post_save {id=0,title,excerpt,body,cover?,status} / post_delete {id}: مقاله‌ها.\n"
    "- category_save {id=0,name,icon,blurb,sort,active,parent,image?} / category_delete {id}.\n"
    "- business_save: ویرایش کسب‌وکار موجود {id: N, fields:{...}} یا «ساخت تازه» "
    "{id: 0, fields:{name, cat_slug, ...}}؛ برای ساخت name و cat_slug لازم‌اند (دسته از فهرست محتوا) و بقیه اختیاری‌اند "
    "(cat_slug/phone/descr/address/tags/hours/images/cover/lat/lng/…). fields کامل: "
    "{name,descr,phone,whatsapp,address,city,area,province,cat_slug,tags,hours,featured,"
    "verified,status,booking_on,phone_public,website,instagram,telegram,eitaa,bale,soroush,"
    'rubika,lat,lng,cover,images}؛ hours مثل {"sat":[["09:00","22:00"]]}.\n'
    "- item_save {id=0,biz_id,title,descr,price,old_price,kind,price_type,stock,unit,code,"
    "note,brand,warranty,tags,min_order,weight,prep_days,sort,delivery,video,images,"
    "options,spec,available,featured,handmade,returnable,haggle,bulk_price} / "
    "item_delete {id}: محصول/خدمت.\n"
    "- review_moderate {id,action=approve|reject,reply?} / review_delete {id}.\n"
    "- biz_moderate {id,action=approve|reject|hide|show}: کسب‌وکار.\n"
    "- broadcast {text}: پیام همگانی (≤۵۰۰ نویسه).\n"
    "- coupon_save {id=0,biz_id,code,title,percent,expires?,active} / coupon_delete {id}: کد تخفیف.\n"
    "- toplist_save {id=0,title,descr,kind,items,limit_n,sort,active} / toplist_delete {id}: "
    "لیست‌های برترین‌ها (items = شناسهٔ کسب‌وکارها).\n"
    "- flashdeal_save {id=0,biz_id,title,descr,percent,starts,ends,active} / "
    "flashdeal_delete {id}: پیشنهد ویژه/فلش‌سیل (تاریخ YYYY-MM-DD HH:MM).\n"
    "- event_save {id=0,title,descr,place,date,time,biz_id?,image?,status} / event_delete {id}: "
    "رویدادهای شهر.\n"
    "- ad_save {id=0,title,body,image?,url,slot,biz_id?,starts,ends,weight,active} / "
    "ad_delete {id}: بنر تبلیغاتی (slot: home/directory/business/sidebar).\n"
    "- plan_save {id,name,tagline,price,months,featured_slots,max_items,max_photos,perks,"
    "features,badge_slug,sort,active} / plan_delete {id}: پلن‌های اشتراک.\n"
    "- badge_save {id=0,slug?,name,icon,color,descr,sort,active} / badge_delete {id}: نشان‌ها.\n"
    "- story_add {biz_id,image,caption,kind,duration} / story_delete {id}: استوری ۲۴ ساعته.\n"
    "- claim_moderate {id,action=approve|reject}: درخواست تصاحب کسب‌وکار.\n"
    "- ticket_reply {id,body}: پاسخ به تیکت پشتیبانی.\n"
    "- customer_moderate {phone,action=block|unblock}: مسدود/آزاد کردن مشری.\n"
    "- order_status {id,status}: وضعیت سفارش (new/confirmed/ready/done/cancelled).\n"
    "- booking_status {id,status}: وضعیت نوبت (new/confirmed/done/cancelled).\n"
    "- area_rename {old,new}: تغییر نام محله در همه‌جا.\n"
    "- trash_restore {id}: بازگرداندن از سطل بازیافت.\n"
    "- subscription_set {biz_id, plan_slug, months?}: فعال‌سازی/تمدید اشتراک هر کسب‌وکار "
    "(پلن‌های معتبر از panel_read {section: plans}).\n"
    "- owner_moderate {owner, action=block|unblock}: مسدود/آزادسازی مالک با شناسه یا شماره.\n\n"
    "# ابزارهای خواندن پنل — دسترسی کامل به همهٔ بخش‌ها (v282)\n"
    "هر بخش پنل مدیریت را می‌توانی بخوانی و بررسی کنی؛ خواندن فوری است و تأیید نمی‌خواهد:\n"
    "- panel_sections {}: فهرست همهٔ بخش‌های خواندنی.\n"
    "- sec_report {}: گزارش زندهٔ امنیت سرور و سایت — SSH (تلاش ناموفق ۲۴ ساعت، "
    "مهاجمان برتر با شمار، ورودهای موفق و IPها)، وضعیت fail2ban و رسید آخرین "
    "سخت‌سازی، تنظیمات sshd، فایروال و پورت‌های گوش‌دهنده، سپر سایت، ضداسپم و "
    "وضعیت رمز/IP پنل. برای هر پرسش امنیت/SSH/هک/رمز اول این را بخوان؛ خروجی "
    "بخش «نتیجه و دلیل» دارد — همان را با عدد نقل کن. اگر ابزار کافی نبود بگو "
    "کدام داده کم است، نگو «خارج از ابزارهای من است».\n"
    "- panel_read {section, q?, id?, page?}: محتوای زندهٔ هر بخش. بخش‌ها: settings, businesses, "
    "queue, items, orders, bookings, chats, reviews, claims, tickets, customers, owners, "
    "subscriptions, plans, coupons, toplists, flashdeals, events, ads, badges, stories, areas, "
    "categories, posts, pages, inbox, inquiries, questions, reports, haggles, trash, spam, "
    "traffic, analytics, audit, searches, ai, founders, stats. "
    "id = جزئیات کامل یک مورد (مثلاً چت، سفارش، کسب‌وکار)؛ q = جست‌وجو/فیلتر.\n"
    "قبل از هر تغییر، بخش مربوط را با panel_read بخوان تا شناسه‌ها و وضعیت‌های واقعی را ببینی؛ "
    "عددها را از همان بخوان و حدس نزن.\n\n"
    "# ابزارهای کد — دسترسی کامل به کد سایت\n"
    "«دسترسی به کد ندارم» مطلقاً نادرست است؛ این ابزارها را داری. اگر مدیر خواست رنگ، دکمه، قالب، "
    "متن چاپ‌شده در قالب، منو، منطق یا هر چیزِ دیگری در سایت عوض شود، مسیرش همین است: "
    "code_search/code_read → code_edit.\n"
    "- code_list {path}: فهرست فایل‌های یک پوشه (ریشه = «»). اجرای فوری.\n"
    "- code_search {query}: جست‌وجوی یک عبارت در کل کد سایت (فایل:خط) — برای پیدا کردن محل هر چیز. اجرای فوری.\n"
    "- code_status {}: وضعیت واقعی صف استقرار و نتیجهٔ آخرین استقرارها. اجرای فوری.\n"
    "- code_read {path, from_line, to_line}: خواندن فایل با شمارهٔ خط، حداکثر ۲۵۰ خط. اجرای فوری.\n"
    "- code_edit {path, edits:[{\"old\",\"new\"}], summary}: جایگزینی دقیق متن در فایل. "
    "در code_edit لازم نیست متن old را حرفی کپی کنی — مشابه‌اش با همانی که خواندی کافی است؛ "
    "سرور خودش تطبیق هوشمند (بی‌توجه به فاصله/تورفتگی) انجام می‌دهد و متن دقیق را پیدا می‌کند.\n"
    "- code_write {path, content, summary}: ساخت فایل تازه یا بازنویسی کامل (تا ۲۴ هزار نویسه).\n"
    "- code_revert {path}: برگاندن فایل به آخرین نسخهٔ پشتیبان.\n"
    "- service_restart {}: راه‌اندازی مجدد سرویس.\n"
    "- ai_setup {provider=gemini|groq|astra|openai|muse|openrouter|glm|site, key, base?, model?}: وقتی مدیر کلید فرستاد (رایگان، GPT یا کلود aa-…)، مغز تازه را وصل می‌کند؛ کلید aa-… یعنی provider=muse؛ کلید sk-or-v1-… یعنی provider=openrouter (مغز چهارم)؛ کلید مغز پنجم GLM یعنی provider=glm (اسلات AI_BRAIN_GLM_KEY). v269: provider=site فقط برای هوش عمومی سایت است (اسلات مستقل AI_SITE_*، جدا از مغزهای مدیر) — وقتی مدیر گفت «کلید/هوش سایت»، با base/model اختیاری (پیش‌فرض AvalAI + glm-5.3-flash).\n"
    "- brain_switch {brain=opus|sonnet|haiku|openrouter|glm}: سوئیچ فوری مغز فعال (همان /مغز …)؛ وقتی مدیر خواست با مغز دیگری حرف بزند — فوراً اجرا می‌شود.\n"
    "جریان کارِ کد: اول با code_search/code_read ببین و بگرد (می‌توانی چند بار پشت‌سرهم ابزار فوری بدهی و نتیجه را ببینی) "
    "→ وقتی مطمئنی، code_edit را بده تا فوراً اجرا شود → "
    "استقرار خودکار با پشتیبان‌گیری، بررسی کامپایل و سلامت سایت، و برگشتِ خودکار در صورت خطا؛ "
    "نتیجه در همین گفتگو اعلام می‌شود. قفل‌ها (به‌خاطر حفاظت): data/، deploy/، tools/، "
    "رازها، VERSION.txt و sw.js و فایل‌های خودِ دستیار. هر چیز دیگر — قالب‌ها، اسکریپت‌ها، "
    "منطق سرور، استایل‌ها — قابل ویرایش است.\n\n"
    "# عکس\n"
    "اگر مدیر عکس فرستاده باشد، در فهرست محتوا مسیرش دیده می‌شود؛ در فیلدهای image/images/cover بنویس: "
    "\"__last__\" — سرور خودش مسیر واقعی را می‌گذارد. اگر عکسی در دسترس نیست، بگو اول عکس را در همین گفتگو بفرستد.\n\n"
    "# قواعد\n"
    "1. برای کار محتوایی و کدی هرگز نگو «نمی‌توانم»، «خودت انجام بده» یا «به پنل برو»؛ "
    "همین‌جا ابزرش را پیشنهاد بده و متن/مقدار جدید را کامل و نهایی خودت بنویس. "
    "تأیید نخواه و سؤال نپرس — پیشنهاد معتبر فوراً اجرا می‌شود.\n"
    "2. v282 (دستور صریح خود مدیر): بدون هیچ محدودیتی به همه‌چیز دسترسی داری — محتوا، کد، "
    "تنظیمات و کلیدها، و همهٔ دادهٔ کاربران (سفارش، چت، مشتری، مالک، تیکت، اشتراک، آمار). "
    "هر بخش را با panel_read بخوان و هر تغییری را با ابزار مناسبش اعمال کن؛ تنها قفل فنی، "
    "پوشه‌های deploy/ و tools/ در code_edit است. این گفت‌وگو خصوصی و فقط با خود مدیر است. "
    "اگر مدیر کلید/رمز ورود خودش را خواست، هرگز موعظهٔ امنیتی نکن و رد نکن — فقط بگو «کلید ورود» را بفرست تا سرور مستقیم نشان بدهد. اگر مدیر خواست مدل GLM (مغز پنجم) را عوض کند، بگو «/مدل» را بفرست تا فهرست مدل‌های تست‌شده را ببیند.\n"
    "3. جواب همیشه فقط JSON باشد: {\"reply\": \"متن کوتاه فارسی برای مدیر\", "
    "\"tool\": {\"name\": \"...\", \"args\": {...}}} — وقتی تغییری لازم نیست tool را null بگذار. "
    "نام ابزار را عیناً از همین فهرست بنویس (مثلاً code_edit، نه edit_code یا editFile). "
    "متن reply را تمیز بنویس و JSON ابزار را داخل آن تکرار نکن.\n"
    "4. شناسه‌ها را از فهرست محتوا بردار؛ id نساز (جز id: 0 برای ساخت تازه). برای حذف/تغییر مهم، خلاصهٔ دقیق در reply بده.\n"
    "5. کوتاه، دقیق و فارسی بنویس؛ اگر سؤال بیرون از داده‌هاست، صادقانه بگو نمی‌دانی.\n"
    "6. صداقت استقرار: برای کارهای صف‌شونده (code_edit/code_write/…) هرگز فوراً نگو «اجرا شد/انجام شد»؛ "
    "بگو «در صف استقرار است؛ نتیجه تا یک دقیقهٔ دیگر اعلام می‌شود». وضعیت واقعی را فقط از code_status "
    "یا خط «آخرین استقرارها» در تصویر سایت بخوان و همان را به مدیر بگو — نه حدس خودت را."
)


def admin_answer(text, snapshot, memory=None):
    """v239: admin Q&A + content-tool proposals over a live site snapshot.

    Returns (reply, source, tool) where source is llm|fallback|unconfigured|
    error and tool is a STRICTLY validated {"name","args"} proposal from
    adminbot_content.parse_tool_call, or None. The model only proposes; the
    server validates and executes at once (v268: no «بله»). Plain-text
    model replies (no JSON) still pass through untouched — v238 behaviour.

    No quotas, no threads, no DB writes on this path (provider/error markers
    are in-memory only).
    """
    c = config()
    attempts = []
    if c["base_url"] and c["api_key"]:
        attempts.append((c["base_url"], c["api_key"], c["model_smart"] or c["model"]))
    # v265: no fallback, ever (owner order).
    if not attempts:
        return "هوش مصنوعی پیکربندی نشده (کلید API در سرور نیست).", "unconfigured", None
    msgs = [{"role": "system", "content": ADMIN_PROMPT + "\n\n# تصویر زندهٔ سایت\n" + str(snapshot or "")}]
    for m in (memory or [])[-4:]:
        msgs.append({"role": "user", "content": _norm(m.get("q"))[:400]})
        msgs.append({"role": "assistant", "content": _norm(m.get("a"))[:600]})
    msgs.append({"role": "user", "content": _norm(text)[:400]})
    last_err = ""
    for base, key, model in attempts:
        try:
            content, _tokens = _chat(base, key, model, msgs, c["timeout"], max_tokens=700)
            body = (content or "").strip()
            if body:
                reply, tool = _admin_parse(body)
                _record_provider("primary", model)
                return reply[:3000], "llm", tool
            last_err = "empty:" + model
            _record_error(last_err)
        except urllib.error.HTTPError as e:
            last_err = f"http-{e.code}:{model}"
            _record_error(last_err)
        except Exception as e:
            last_err = type(e).__name__ + ":" + model
            _record_error(last_err)
    return _brain_fail_fa(last_err, c.get("brain")), "error", None


# ---------- v246: server-driven autopilot (works with weak brains) ----------

_CODE_PATH_RX = re.compile(r"[A-Za-z0-9_./\-]+\.(py|js|css|html|md|svg|json)\b")
_CODE_NOUN_RX = re.compile(
    "کد|فایل|قالب|دکمه|رنگ|منو|فونت|استایل|اسکریپت|لوگو|آیکن|هدر|فوتر|سایدبار|سرویس"
    "|css|js|html|button|menu|color|style|template", re.I)
_CHANGE_VERB_RX = re.compile(
    "عوض|تغییر|اصلاح|درست|بساز|ساخت|اضافه|حذف|بذار|بگذار|گذار|بازنویس|کوچک‌?تر|بزرگ‌?تر|شد کن|کن")
_LOCATE_RX = re.compile("کجاست|کجا است|کجاست؟|نشان بده|نشون بده|کدام فایل|چه فایلی")
_STOP = {"را", "رو", "به", "در", "و", "با", "که", "این", "آن", "برای", "از", "تا",
         "کن", "بده", "کنید", "لطفا", "لطفاً", "سایت", "صفحه", "هم", "یه", "یک",
         "می", "چه", "چیزی", "شود", "بود", "است", "هست", "من", "تو", "شما"}


def code_change_intent(text):
    """Server-side: is this a CODE change request? (never trusts the model)"""
    t = str(text or "")
    if _CODE_PATH_RX.search(t):
        return True
    if re.search("تنظیمات|پنل", t):        # content-settings wording → not code
        return False
    return bool(_CODE_NOUN_RX.search(t)) and bool(_CHANGE_VERB_RX.search(t))


def code_locate_intent(text):
    return bool(_LOCATE_RX.search(str(text or "")))


def mine_query(text):
    """Best search term from the owner's words: quoted span > latin > Persian."""
    t = str(text or "")
    m = re.search("[«\"']([^»\"']{2,40})[»\"']", t)
    if m:
        return m.group(1).strip()
    words = []
    for w in re.split(r"[\s،؛:!؟.()]+", t):
        w = w.replace("\u0654", "").replace("\u200c", "").strip()
        if len(w) < 3 or w in _STOP or _CHANGE_VERB_RX.fullmatch(w):
            continue
        words.append(w)
    latin = [w for w in words if re.match("[A-Za-z]", w)]
    if latin:
        return latin[0]
    longs = [w for w in words if len(w) >= 4]
    return (longs or words or [""])[0]


def _extract_edit(body):
    """(old, new) from a weak model's answer: JSON, fenced blocks, or old:/new:"""
    s = str(body or "").strip()
    blocks = re.findall(r"```[a-zA-Z]*\n(.*?)```", s, re.S)
    if len(blocks) >= 2:
        return blocks[0].strip("\n"), blocks[1].strip("\n")
    m = re.search(r"\{.*\}", s, re.S)
    if m:
        try:
            d = json.loads(m.group(0))
            if isinstance(d, dict) and d.get("old") and d.get("new"):
                return str(d["old"]), str(d["new"])
        except ValueError:
            pass
    mo = re.search(r"old\s*[:=]\s*(.+?)(?:\n\s*new\s*[:=]|\Z)", s, re.S | re.I)
    mn = re.search(r"new\s*[:=]\s*(.+)", s, re.S | re.I)
    if mo and mn:
        return mo.group(1).strip("\n `"), mn.group(1).strip("\n `")
    if len(blocks) == 1:
        parts = re.split(r"\n-{3,}\n", blocks[0])
        if len(parts) == 2:
            return parts[0].strip("\n"), parts[1].strip("\n")
    return None, None


def _mini_edit_call(text, path, a, b, code, retry=False):
    """Tiny, weak-model-friendly ask: ONLY the edit, nothing else."""
    c = config()
    attempts = []
    if c["base_url"] and c["api_key"]:
        attempts.append((c["base_url"], c["api_key"], c["model_smart"] or c["model"]))
    # v265: no fallback, ever (owner order).
    if not attempts:
        return ""
    msgs = [
        {"role": "system", "content":
            "تو برنامه‌نویس وب هستی. فقط و فقط این JSON را بده: "
            '{"old": "چند خط دقیق از کد فعلی", "new": "همان خطوط در نسخهٔ جدید"}. '
            "مقدار old باید عیناً از کد داده‌شده کپی شود و کوتاه باشد (حداکثر چند خط). "
            "هیچ توضیحی ننویس."},
        {"role": "user", "content":
            f"درخواست مدیر: {str(text)[:300]}\n\nفایل {path} (خطوط {a}–{b}):\n"
            f"```\n{code}\n```\n"
            "حالا فقط JSON با کلیدهای old و new را بده." +
            ("\n(جواب قبلی قابل استفاده نبود؛ این بار فقط JSON.)" if retry else "")},
    ]
    for base, key, model in attempts:
        try:
            content, _t = _chat(base, key, model, msgs, 25, 350)
            if content and content.strip():
                return content
        except Exception:
            continue
    return ""


def autopilot(text):
    """v246: the SERVER is the agent. It searches, picks the file, reads a
    small region, and asks the model only for the tiny old→new edit —
    so even a weak brain gets the job done. Returns (reply, tool|None).
    Never fabricates success; failures return honest progress."""
    try:
        if not (code_change_intent(str(text)) or code_locate_intent(str(text))):
            return "", None
        q = mine_query(text)
        if not q:
            return ("بگو دقیقاً چه چیزی در سایت (مثلاً «دکمهٔ خرید»، «فوتر» یا نام فایل).",
                    None)
        hits = CODE.search_hits(q) or CODE.search_hits(q.split()[0] if " " in q else q[:4])
        if not hits:
            return (f"🔍 در کد سایت چیزی برای «{q}» پیدا نکردم؛ دقیق‌تر بگو یا نام فایل را بده.",
                    None)
        if code_locate_intent(text):
            shown = "\n".join(f"{p}:{ln}: {s[:60]}" for p, ln, s in hits[:8])
            return (f"🔍 «{q}» این‌جاست:\n{shown}", None)
        path, ln, _s = hits[0]
        region = CODE.read_region(path, ln)
        if not region:
            return (f"«{q}» را در {path} پیدا کردم ولی محتوایش قابل‌خواندن نیست.", None)
        a, b, code = region
        src = CODE.read_file(path) or ""
        for attempt in (False, True):
            body = _mini_edit_call(text, path, a, b, code, retry=attempt)
            if not body:
                break
            old, new = _extract_edit(body)
            if not old or new is None:
                continue
            exact, why = CODE.resolve_edit(src, old) if src else (None, "nomatch")
            if exact:
                return (f"🛠 «{q}» را در {path} پیدا کردم (حدود خط {ln})؛ "
                        "تغییر آمادهٔ تأیید است.",
                        {"name": "code_edit",
                         "args": {"path": path,
                                  "edits": [{"old": exact, "new": new}],
                                  "summary": str(text)[:80]}})
        return (f"🔍 «{q}» را در {path} (خط {ln}) پیدا کردم و کدش را خواندم، ولی مغز "
                "هوش مصنوعی ویرایش درست را ننوشت. یک بار دیگر بفرست، یا با "
                "«/کلید astra …» مغز قوی‌تر وصل کن.\n"
                "🩺 برای دیدن علت دقیق (مغز/کلید/استقرار) بفرست: تشخیص",
                None)
    except Exception:
        return ("خلبان خودکار به مشکل خورد؛ دوباره بفرست.", None)


_REFUSAL_RX = re.compile(
    "دسترسی.{0,12}کد|کد.{0,16}دسترسی ندار|نمی.?توانم کد|نمیتوانم کد|کد.{0,20}امکان پذیر نیست"
    "|فقط محتوا|به پنل (برو|بروید)|خودت تغییر بده")


def _looks_like_refusal(reply):
    """True when the model claims it cannot touch the site's code/content."""
    return bool(_REFUSAL_RX.search(str(reply or "")))


def admin_agent(text, snapshot, memory=None, max_steps=6):
    """v242 agentic loop: like a real agent, the model may chain immediate
    read tools (code_list/code_read/code_search); the server executes each
    one and feeds the result back, until the model proposes a WRITE tool
    (returned to the owner's «بله» wall) or produces a final answer.
    Weak-model friendly: it never has to nail a whole task in one shot."""
    c = config()
    attempts = []
    if c["base_url"] and c["api_key"]:
        attempts.append((c["base_url"], c["api_key"], c["model_smart"] or c["model"]))
    # v265: no fallback, ever (owner order).
    if not attempts:
        return ("هوش مصنوعی پیکربندی نشده (کلید API در سرور نیست).", "unconfigured", None)
    msgs = [{"role": "system",
             "content": ADMIN_PROMPT + "\n\n# تصویر زندهٔ سایت\n" + str(snapshot or "")}]
    for m in (memory or [])[-4:]:
        msgs.append({"role": "user", "content": _norm(m.get("q"))[:400]})
        msgs.append({"role": "assistant", "content": _norm(m.get("a"))[:600]})
    msgs.append({"role": "user", "content": _norm(text)[:400]})
    last_reply, last_tool_out, reminded, last_err = "", "", False, ""
    try:
        for _step in range(max_steps):
            got = None
            for base, key, model in attempts:
                try:
                    content, _tokens = _chat(base, key, model, msgs, c["timeout"],
                                             max_tokens=700)
                    body = (content or "").strip()
                    if not body:
                        last_err = "empty:" + model
                        _record_error(last_err)
                        continue
                    reply, tool = _admin_parse(body)
                    _record_provider("primary", model)
                    got = (reply, tool, "llm")
                    break
                except urllib.error.HTTPError as e:
                    last_err = f"http-{e.code}:{model}"
                    _record_error(last_err)
                except Exception as e:
                    last_err = type(e).__name__ + ":" + model
                    _record_error(last_err)
            if not got:
                break
            reply, tool, srcname = got
            if tool and tool["name"] in adminbot_content.IMMEDIATE_TOOLS:   # v282
                ok, msg = adminbot_content.tool_execute(tool["name"], tool["args"])
                if not ok:
                    msg = "⚠️ " + msg
                last_tool_out = str(msg)[:CHAT_FEED_CAP]
                msgs.append({"role": "assistant", "content": reply_or_body(reply, tool)})
                msgs.append({"role": "user",
                             "content": "نتیجهٔ ابزار " + tool["name"] + ":\n" + last_tool_out +
                                        "\n(اگر کافی است، حالا جواب نهایی بده یا ابزار تغییر را پیشنهاد بده؛ "
                                        "در غیر این صورت ابزار فوری بعدی را بده.)"})
                last_reply = reply or ""
                continue
            if not tool and _looks_like_refusal(reply) and not reminded:
                # weak-brain fix: the model claims it has no access (it does).
                # Push back ONCE with the exact truth, then take the retry.
                msgs.append({"role": "user",
                             "content": "یادآوری سرور: به کد سایت دسترسی داری؛ ابزارهای "
                                        "code_search، code_read و code_edit در اختیار توست "
                                        "و استقرار خودکار انجام می‌شود. "
                                        "جواب درست را همین حالا با ابزار مناسب بده."})
                reminded = True
                continue
            out = reply
            if last_tool_out:
                out = (out + "\n\n" + last_tool_out).strip()
            return out[:3000], srcname, tool
        if last_reply or last_tool_out:
            return ((last_reply or "الان به نتیجه نرسیدم؛ لطفاً دقیق‌تر بگو.")
                    + (("\n\n" + last_tool_out) if last_tool_out else "")
                    + "\n🩺 برای دیدن علت دقیق بفرست: تشخیص", "error", None)
        # v265: nothing ever worked — the primary brain itself is dead.
        return _brain_fail_fa(last_err, c.get("brain")), "error", None
    except Exception:
        return ("هوش مصنوعی جواب نداد؛ کمی بعد دوباره بفرست.\n"
                "🩺 برای دیدن علت دقیق بفرست: تشخیص"), "error", None


CHAT_FEED_CAP = 1600


def reply_or_body(reply, tool):
    """Compact representation of the model's own turn for the transcript."""
    import json as _json
    return _json.dumps({"reply": str(reply or "")[:400], "tool": tool},
                       ensure_ascii=False)[:1200]


def _admin_parse(body):
    """v239: parse the admin model's JSON answer. Returns (reply, tool|None).

    Accepts {"reply","tool"} JSON (optionally fenced); anything else (plain
    text, broken JSON) degrades to the raw text with no tool — exactly the
    v238 contract, so a model that ignores the protocol can never break the
    bot. Tool calls are re-validated by adminbot_content.parse_tool_call, so
    unknown tools/bad args/secret keys never survive.
    """
    try:
        cand = body.strip()
        if cand.startswith("```"):
            # ```json ... ```  -> drop the fence line + trailing fence
            parts = cand.split("\n", 1)
            cand = parts[1] if len(parts) == 2 else cand.strip("` \n")
            if "```" in cand:
                cand = cand.rsplit("```", 1)[0]
            cand = cand.strip()
        obj = json.loads(cand, strict=False)   # tolerate raw newlines in strings
        if not isinstance(obj, dict):
            raise ValueError("not an object")
        reply = str(obj.get("reply") or "").strip()
        tool = None
        tc = obj.get("tool")
        if isinstance(tc, str):            # weak models sometimes stringify
            try:
                tc = json.loads(tc)
            except ValueError:
                tc = None
        if isinstance(tc, dict):
            if tc.get("name"):
                tc["name"] = str(tc["name"]).strip().lower()
            if isinstance(tc.get("args"), str):
                try:
                    tc["args"] = json.loads(tc["args"])
                except ValueError:
                    pass
        if isinstance(tc, dict) and tc.get("name"):
            name, args = adminbot_content.parse_tool_call(tc)
            if name:
                tool = {"name": name, "args": args}
            else:
                # v240/v248: a rejected proposal must be visible — now with
                # the exact name the model asked for.
                want = ""
                if isinstance(tc, dict):
                    want = str(tc.get("name") or "").strip()[:40]
                # v250: if the NAME was valid and only the args failed, say
                # WHICH gate failed. «ابزار setting شناخته نشد» was a lie
                # that hid locked/secret keys and bad toggle words.
                why = ""
                try:
                    why = adminbot_content.reject_reason(tc)
                except Exception:
                    why = ""
                if why:
                    reply = (reply + f"\n\n⚠️ ابزار «{want}» درست بود ولی اجرا نشد: {why}"
                             + "؛ درخواست را با همین نکته دقیق‌تر بگو.").strip()
                else:
                    reply = (reply + "\n\n⚠️ ابزار پیشنهادی معتبر شناخته نشد و اجرا نمی‌شود"
                             + (f" (ابزار «{want}» شناخته نشد)" if want else "")
                             + "؛ درخواست را یک بار دیگر دقیق‌تر بگو.").strip()
        if not reply and not tool:
            raise ValueError("empty")
        return (reply or "آماده‌ام؛ تغییر را توضیح بده."), tool
    except Exception:
        return body, None


def answer(text, ctx, history=None):
    """Main entry for every channel.

    ctx = {"channel": web|bale|soroush, "user_key": str, "customer": dict|None,
           "owner": dict|None}
    Returns {"ok", "text", "links", "intent", "source", "remaining", "quota", "tier",
             "degraded", "model"} — source is llm|rule|rule-fallback|cache;
    degraded is "" normally, "quota"/"cap"/"login" when the model was skipped
    (budget out, or v259 guest gate: token only for signed-in panels + admin
    team) and rules answered instead; model is "smart"/"fast" for
    model-written answers (fresh or cached), "rule" otherwise.
    or {"ok": False, "error": "disabled"|"empty", "text": ...}.
    v219: rule answers are FREE and unlimited — the quota and the daily cap
    gate only the model. An exhausted model budget degrades to rules instead
    of erroring, so the assistant never goes silent.
    v220: repeated public (guest, history-less) questions are served from the
    semantic cache — free, and available even when the budget is out.
    v221: bots and signed-in web keep a server-side thread (ai_threads, 20
    msgs) that survives restarts and wins over client history.
    v270 (دستور مدیر): thread TTL = 10 minutes — «چت تا ده دقیقه برای کاربر
    بمونه» — and every exchange is appended to CHAT_LOG (data/site_chats.log),
    one file the owner downloads from the admin bot with «چت‌ها».
    v223: safe tools — the model only proposes (favorite/cancel_booking/
    cancel_order); the server validates, executes via the site's own
    functions and audit-logs. Cancellations need a «بله» turn (intent
    confirm, free, rules). Tool answers are never cached.
    v224: order cancels notify the shopkeeper (in-app, via
    request_order_cancel); generate() records which provider answered.
    v225: book (Jalali date + 24h time, booking_on only, account phone) and
    review (text-only) tools — login + «بله» gated like the cancels.
    v226: tool proposals carry pending_tool so bots can attach ✅/❌ buttons.
    """
    text = _norm(text)[:400]
    user_key = ctx.get("user_key") or "anon"
    tier = ctx.get("tier") or tier_of(ctx.get("customer"), ctx.get("owner"))
    quota = quota_for(tier, ctx.get("customer"), ctx.get("owner"))

    def _rem():   # v285: باقی‌ماندهٔ سطح شخص (هر دو هویت)، نه فقط یک کلید
        return max(0, quota - person_used(ctx.get("customer"), ctx.get("owner"),
                                          user_key))
    if not enabled():
        return {"ok": False, "error": "disabled", "text": "دستیار هوشمند فعلاً غیرفعال است.", "tier": tier,
                "quota": quota, "remaining": 0}
    if not text:
        return {"ok": False, "error": "empty", "text": "پیامی ننوشتید.", "tier": tier, "tier_label": TIER_LABEL.get(tier, ""), "quota": quota,
                "remaining": _rem()}
    # v223: «بله/نه» answers an outstanding tool confirmation (free, rules).
    # Only short texts match, so «اپ بله چطور نصب میشه» still reaches faq.
    if len(text) <= 20 and (_CONFIRM_RE.match(text) or _DECLINE_RE.match(text)):
        pend = pending_get(user_key)
        if pend or text != "بله":
            # No pending + unambiguous confirm/decline → gentle note (free).
            # Bare «بله» keeps its legacy faq meaning (the messenger's name).
            if pend:
                pending_clear(user_key)
            if not pend and _DECLINE_RE.match(text):
                out_text, links = "چیزی برای لغو نیست. 🙂", []
            elif not pend:
                out_text, links = "چیزی در انتظار تأیید نیست. 🙂", []
            elif _DECLINE_RE.match(text):
                out_text, links = "باشه، انجام نشد. 👍", []
            else:
                _ok, out_text, links = tool_execute(pend["tool"], pend["args"], ctx)
            try:
                _count(user_key, ctx.get("channel") or "web", 0, 0, "confirm")
            except Exception:
                pass
            thread_append(thread_key(ctx), text, out_text)
            chat_log(ctx, text, out_text, "rule", "rule", "confirm")   # v270
            return {"ok": True, "text": out_text, "links": links, "intent": "confirm",
                    "source": "rule", "model": "rule", "degraded": "",
                    "tier": tier, "tier_label": TIER_LABEL.get(tier, ""), "quota": quota,
                    "remaining": _rem()}
    used_q = person_used(ctx.get("customer"), ctx.get("owner"), user_key)
    # v221: the server thread (DB, survives restarts) wins over client history.
    tkey = thread_key(ctx)
    eff_history = thread_get(tkey) if tkey else []
    if not eff_history:
        eff_history = history or []

    intent, q = rule_intent(text)
    source, reply, tokens, calls = "rule", "", 0, 0
    # v213.1: with a model configured, the model WRITES the answer itself,
    # grounded in a live context pack (site facts, search hits for the user's
    # words, plans, pages, the user's own orders). Rules only pre-extract a
    # search query and serve as the offline fallback.
    # v219: the model runs only while the personal AND global model budgets
    # last; otherwise rules answer and the result is marked degraded.
    degraded = ""
    # v274 (دستور مدیر): کاربر می‌تواند از بالای صفحهٔ چت دستی روی «هوش آفلاین
    # (نامحدود)» سوییچ کند؛ در این حالت مدل هرگز صدا زده نمی‌شود و سهمیه مصرف
    # نمی‌شود — فقط کش رایگان + قواعد. حالت پیش‌فرض «auto» یعنی هوش اختصاصی.
    if str(ctx.get("mode") or "").strip() == "offline":
        degraded = "offline"
    if configured() or site_configured():   # v274: quota must gate the site slot too
        # v220: repeated public questions are served from the semantic cache —
        # free for everyone, even when the model budget is out (it costs $0).
        hit = cache_lookup(text, ctx, eff_history, intent)
        if hit:
            try:
                _count(user_key, ctx.get("channel") or "web", 0, 0, hit["intent"])
            except Exception:
                pass
            thread_append(tkey, text, hit["text"])
            chat_log(ctx, text, hit["text"], "cache", hit["model"], hit["intent"])   # v270
            return {"ok": True, "text": hit["text"], "links": hit["links"], "intent": hit["intent"],
                    "source": "cache", "model": hit["model"], "degraded": degraded,
                    "mode": ("offline" if degraded == "offline" else "smart"),
                    "tier": tier, "tier_label": TIER_LABEL.get(tier, ""), "quota": quota,
                    "remaining": _rem()}
        if not degraded:
            # v300: agent unlimited personal — key via Bale bot bypasses quota/cap
            if ctx.get("agent_unlimited"):
                degraded = ""
            elif is_guest(ctx) and not guest_model_allowed():
                # v259 (دستور مدیر): توکن Claude فقط برای پنل کاربری (واردشده)
                # و مدیرتیم است — مهمان مدل صدا نمی‌زند (کش رایگان بالا همچنان
                # برای همه آزاد است چون هزینهٔ توکن ندارد).
                degraded = "login"
            elif used_q >= quota:
                degraded = "quota"
            elif global_quota_today() >= global_cap():
                degraded = "cap"
    if site_configured() and not degraded:   # v269: فقط اسلات هوش سایت (جدا از مغزهای مدیر)
        gen, tokens, calls, used_smart = generate(text, ctx, eff_history, (intent or "unknown", q))
        if gen:
            out_intent = gen["intent"] if gen["scope"] else "off_topic"
            try:
                _count(user_key, ctx.get("channel") or "web", calls, tokens, out_intent,
                       quota=1, smart=1 if used_smart else 0)
            except Exception:
                pass
            ans_text, ans_links = gen["answer"], list(gen["links"])
            tc = gen.get("tool_call")
            pending_tool = ""
            if tc:
                # v223: the model proposes, the server disposes. Stateful
                # answers are never cached.
                if not _tool_customer(ctx):
                    ans_text += "\n\n🔑 برای این کار باید وارد حساب شوید."
                    ans_links.append(("ورود", "/login"))
                elif tc["name"] == "favorite":
                    _ok, msg, tlinks = tool_execute("favorite", tc["args"], ctx)
                    ans_text += "\n\n" + msg
                    ans_links += tlinks
                else:
                    ok, why = tool_precheck(tc["name"], tc["args"], ctx)
                    if not ok:
                        ans_text += _tool_fail_text(tc["name"], why)
                    else:
                        pending_save(user_key, tc["name"], tc["args"])
                        pending_tool = tc["name"]   # v226: bots attach ✅/❌ to this
                        what = tool_describe(tc["name"], tc["args"], ctx)
                        ans_text += f"\n\n⚠️ {what} — انجام شود؟ (بله / نه)"
            else:
                cache_store(text, ctx, eff_history, gen["answer"], gen["links"], out_intent,
                            "smart" if used_smart else "fast", tokens)
            thread_append(tkey, text, ans_text)
            chat_log(ctx, text, ans_text, "llm",
                     "smart" if used_smart else "fast", out_intent)   # v270
            return {"ok": True, "text": ans_text, "links": ans_links[:6], "intent": out_intent,
                    "source": "llm", "model": "smart" if used_smart else "fast", "degraded": "",
                    "mode": "smart",
                    "tier": tier, "tier_label": TIER_LABEL.get(tier, ""), "quota": quota,
                    "remaining": max(0, quota - used_q - 1), "pending_tool": pending_tool}
    # Offline / model failed / budget out → rule-based answers (never silent,
    # never quota-counted).
    if intent is None:
        # No model available: a short noun phrase is most likely a search;
        # a question is answered from the knowledge list or refused politely.
        asks = re.search(r"[?؟]|چیست|چیه|چطور|چگونه|بگو|بنویس|توضیح", text)
        intent, source = (("unknown" if asks else "search") if len(text) <= 60 else "unknown"), "rule-fallback"
    elif calls:
        source = "rule-fallback"
    out = compose(intent, q, text, ctx, reply if source == "llm" else "")
    out_text, out_links = out["text"], list(out.get("links") or [])
    if degraded == "login":
        # v259 (دستور مدیر): مهمان بداند پاسخ هوشمند مال پنل کاربری است.
        out_text += "\n\n🔑 پاسخ هوشمند (Claude) فقط برای کاربران واردشده است — وارد شوید."
        if not any(h == "/login" for _, h in out_links):
            out_links.append(("ورود", "/login"))
    elif degraded in ("quota", "cap"):
        # v274 (دستور مدیر): وقتی سهمیهٔ هوشمند تمام شد کاربر صریحاً بداند و
        # بداند به هوش آفلاین (نامحدود) وصل شده؛ شمارنده هم ۰ بماند نه ۱.
        out_text += ("\n\n🔋 سهمیهٔ پاسخ هوشمند امروز شما به پایان رسید؛ از این پس به "
                     "«هوش آفلاین» (نامحدود و رایگان) متصل هستید. از بالای صفحهٔ چت هر وقت "
                     "خواستید بین هوش آفلاین و هوش اختصاصی دست گیر سوییچ کنید.")
    try:
        _count(user_key, ctx.get("channel") or "web", calls, tokens, intent)
    except Exception:
        pass
    thread_append(tkey, text, out_text)
    chat_log(ctx, text, out_text, source, "rule", intent)   # v270
    rem = 0 if degraded in ("quota", "cap") else max(0, quota - used_q)
    return {"ok": True, "text": out_text, "links": out_links, "intent": intent,
            "source": source, "model": "rule", "degraded": degraded,
            "mode": ("offline" if degraded == "offline" else "smart"),
            "tier": tier, "tier_label": TIER_LABEL.get(tier, ""), "quota": quota,
            "remaining": rem}


# ------------------------------------------------------------------ bots (v221: threads live in ai_threads, not RAM)
def bot_render(res, customer, callback_prefix="dg198:"):
    """v226: (body, reply_markup) for a bot answer — shared by free-text
    replies and ✅/❌ confirmations so both render identically. A pending
    tool proposal gets its confirm buttons; everything else is unchanged."""
    body = res["text"]
    rows = []
    for label, href in (res.get("links") or [])[:4]:
        url = href if href.startswith("http") else SITE + href
        rows.append([{"text": "🌐 " + label, "url": url}])
    if res.get("intent") == "register" and customer:
        rows.insert(0, [{"text": "➕ ثبت همین‌جا در بات", "callback_data": callback_prefix + "reg_start"}])
    if res.get("pending_tool"):
        rows.append([{"text": "✅ تأیید", "callback_data": callback_prefix + "ai_yes"},
                     {"text": "❌ انصراف", "callback_data": callback_prefix + "ai_no"}])
    if res.get("ok") and res.get("remaining") is not None:
        body += f"\n\n— دستیار دست گیر · {_fa(res['remaining'])} پاسخ هوشمند دیگر امروز"   # v219: quota = smart answers; rules are free
    rows.append([{"text": "🏠 منوی اصلی", "callback_data": callback_prefix + "menu"}])
    return body, {"inline_keyboard": rows}


def bot_reply(platform, platform_user_id, chat_id, text, send, customer=None, owner=None, callback_prefix="dg198:"):
    """Free text in Bale/Soroush → assistant. Always consumes non-empty text.
    Links become inline URL buttons; tool proposals get ✅/❌ buttons."""
    text = _norm(text)
    if not text:
        return False
    key = f"{platform}:{platform_user_id}"
    ctx = {"channel": platform, "user_key": (f"cust:{customer['id']}" if customer else key),
           "customer": customer, "owner": owner}
    res = answer(text, ctx, None)   # v221: history lives in the server thread
    body, markup = bot_render(res, customer, callback_prefix)
    send(chat_id, body, markup)
    return True
