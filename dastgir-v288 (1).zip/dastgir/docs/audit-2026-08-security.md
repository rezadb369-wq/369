# 🔐 وضعیت امنیتی جاری — ممیزی ایستا + نفوذ پویا (v280)

> **این سند وضعیت «الان» است**، نه روایت یک ممیزی گذشته. هر بند با `file:line` واقعیِ همین بسته شاهد دارد؛ جاهایی که شمارهٔ خط از زمان ممیزی اولیه جابه‌جا شده، با نام نماد مشخص شده است.
> لایهٔ ضداسپم و ماتریس پوشش: `docs/SECURITY-SPAM-PLAN.md` · `docs/SECURITY-MATRIX.md` · قوانین: `docs/collaboration/RULES.md`.
> تاریخ بازبینی: ۲۰۲۶-۰۹-۱۳.

---

## ۱) یافته‌های ایستا — همه رفع و قفل‌شده

چهار یافتهٔ ممیزی ایستا (۱ بحرانی، ۲ زیاد، ۱ متوسط) رفع شده‌اند و با `tools/test_security.py` قفل شده‌اند (پس از هر تغییر، همین سوئیت باید سبز بماند):

| # | یافته | محل | رفع جاری |
|---|---|---|---|
| F1 🔴 | **DOM XSS** در ویجت «اخیراً دیده‌شده»: `name` از `document.title` و `img` از `og:image` خوانده و در `localStorage` ذخیره، سپس با `innerHTML` تزریق می‌شد (نام کسب‌وکار می‌تواند مارک‌اپ داشته باشد چون `esc()` سمت سرور در title رمزگشایی می‌شود) | `site/assets/js/app.js` | ساخت DOM با `createElement`/`textContent` + `encodeURIComponent` برای slug + اجبار `String()` در برابر دادهٔ خراب |
| F2 🟠 | **ریدایرکت باز** در `POST /alert`: `back` بدون اعتبارسنجی به `redirect()` می‌رفت ⇒ فیشینگ پس از یک POST مشروع | `server/app.py` (روت `/alert`) | فقط مسیر داخلی: `/…` و نه `//…` |
| F3 🟠 | **نشت کد OTP روی سیم**: اگر SMS وصل نبود و `site_url` خالی بود، کد ورود برای هر بازدیدکننده در HTML چاپ می‌شد ⇒ تصاحب هر حساب | `server/app.py` (شاخهٔ dev-code) | کد dev فقط به peer لوپ‌بک (۱۲۷٫۰٫۰٫۱/::۱) نشان داده می‌شود؛ از اینترنت هرگز. ضمناً مسیرهای OTP/رمز مشتری الان با ۴۰۴ بسته‌اند (ورود فقط پیام‌رسان) |
| F4 🟡 | **نبود HSTS** پشت پروکسی HTTPS | `Handler.send()` | هدر `Strict-Transport-Security: max-age=31536000; includeSubDomains` فقط وقتی `X-Forwarded-Proto: https` است (و روی http معمولی هرگز — per spec) + افزودن `upgrade-insecure-requests` به CSP |

---

## ۲) سالم تأییدشده — با شاهد واقعی در v280

| حوزه | وضعیت | شاهد (خروجی واقعی از همین بسته) |
|---|---|---|
| تزریق SQL | ✅ همهٔ `execute`ها پارامتری؛ شناسه‌های f-string فقط لیترال داخلی | `server/db.py` — `pbkdf2_hmac`×۳، بدون `random` در مسیر رمز |
| XSS سمت سرور | ✅ `esc()` سراسری؛ نمونه‌گیری term/query پاک | `server/views_*.py` |
| ریدایرکت `next` ورود | ✅ `/` و نه `//`، بدون `\`، < ۳۰۰ نویسه، بدون `..`، بدون `/panel` | `server/app.py:255-257` |
| `/ad/<id>` مقصد خارجی | ✅ by-design (تبلیغ)؛ `//` و `javascript:` رد می‌شوند؛ ورودی فقط از پنل مدیر | `server/app.py` |
| احراز هویت | ✅ دروازهٔ سراسری `/my` (یک نقطه) + کلید پنل + رمز PBKDF2 + `panel_allow_ips` | `server/app.py` |
| فایل چت/تیکت | ✅ `chat_role` (customer/owner/admin) و `owner_id` قبل از سرو چک می‌شود | `server/app.py` |
| Path traversal | ✅ `posixpath.normpath` + رد `..` و مسیر مطلق | `server/app.py:372-373` |
| آپلود | ✅ سقف ۳MB هر عکس / ۸MB پیوست چت / ۳۰MB بدنه، حداکثر ۱۵ فایل، تشخیص پسوند از بایت نه نام، حذف EXIF/XMP/ICC | `server/uploads.py:34-36,127,158,229` |
| رمزها/توکن‌ها | ✅ `secrets` همه‌جا، PBKDF2، `compare_digest` (۷ فایل) | `server/db.py`، `server/app.py:457` |
| کوکی‌ها | ✅ `HttpOnly` + `SameSite=Lax` + `Secure` پشت https | `server/app.py:457` |
| CSRF | ✅ `SameSite=Lax` + کلید در فرم‌های پنل؛ همهٔ حذف‌ها POST | — |
| هدرها | ✅ `X-Content-Type-Options: nosniff` · `X-Frame-Options: DENY` · `Referrer-Policy: strict-origin-when-cross-origin` · `Cross-Origin-Opener-Policy: same-origin` · `Cross-Origin-Resource-Policy: same-origin` · `Permissions-Policy: geolocation=(self), camera=(), microphone=(), payment=()` · CSP سخت‌گیرانه با `frame-src none` | `server/app.py:149-…` (`SECURITY_HEADERS`) |
| slowloris | ✅ `Handler.timeout = 30` (با assert در نگهبان پوشش) | `server/app.py:277` |
| خطای ۵۰۰ | ✅ پیام عمومی به کلاینت؛ traceback فقط در لاگ سرور | `server/app.py` |
| نشست‌ها | ✅ `secrets.token_urlsafe(24)`، TTL ۳۰ روز، پاک‌سازی منقضی‌ها | `server/db.py` |
| رازها | ✅ فقط `/etc/dastgir-secrets.env` با `root:root/600`؛ nginx مسیر webhook را لاگ نمی‌کند؛ `_REDACT_RX` در بات؛ اسکنر نشت `tools/scan_tokens.py` | `deploy/nginx-dastgir.conf`، `server/adminbot.py` |
| ایزوله‌سازی سرویس | ✅ `NoNewPrivileges` · `PrivateTmp` · `ProtectSystem=full` · `ProtectHome` · `ReadWritePaths` فقط دو مسیر | `deploy/bazarche.service` |
| ضداسپم/نرخ | ✅ سه لایه (سپر + سیاست مرکزی ۲۲ کنش + هوش محتوایی) با پوشش ۰ مسیر بی‌سیاست | `docs/SECURITY-SPAM-PLAN.md` |
| IDOR | ✅ پین سراسری G25 با تست زندهٔ cross-account | `tools/test_idor_v280.py` |

---

## ۳) نفوذ پویا — سناریوهای جاری

`tools/test_pentest.py` روی **سرور در حال اجرا** اجرا می‌شود (بدون سرور زنده، خودش صادقانه می‌گوید «سرور در دسترس نیست» و رد می‌شود). سناریوها:

| حمله | انتظار |
|---|---|
| P1 گریز فایل استاتیک (واریانت‌های `..`، رمز شده، دوبار-رمز) | ۴۰۳/۴۰۴ بدون نشت |
| P2 رشته‌های SQL زنده (`' OR '1'='1`، `DROP TABLE`، `UNION SELECT`) | ۲۰۰ سالم، جدول‌ها دست‌نخورده |
| P3 فاز فرم: بدنهٔ بزرگ، بایت NUL، RTL-override، ارقام عربی، نویسهٔ کنترلی، ایموجی، CRLF خام | **صفر ۵۰۰** |
| P4 طوفان از یک IP هم‌زمان با ترافیک کاربر سالم | مهاجم ۴۲۹؛ کاربر سالم ۲۰۰ |
| P5 سیل صدور OTP از چند IP جعلی برای یک شماره | یک کد فعال؛ هرگز در پاسخ لو نمی‌رود |
| P6 حدس کد: تلاش‌های غلط سپس حدس از IPهای متفاوت | قفل پس از ۵ تلاش؛ کد درستِ بعد از قفل هم رد می‌شود |
| P7 حدس id فایل چت/تیکت + id نجومی | همه ۴۰۳/۴۰۴ |
| P8 بازتاب XSS در جست‌وجو (`<img onerror>`، `<script>`) | escape شده |
| P9 تزریق CRLF در هدر (`back` با `%0d%0a`) | هدر تزریعی ظاهر نمی‌شود |
| P10 verb tampering (PUT/DELETE/PATCH) | ۵۰۱ |
| P11 دود هم‌زمانی: درخواست انبوه/کلاینت موازی | بدون ۵xx |
| P12+ یکتایی ورود، پمپ رأی، scrape، وب‌هوک جعلی، بیکن بازدید | در `tools/test_attack_v280.py` — همه باید **شکست بخورند** |

**نکته‌های طراحی تست (جاری):** endpoint تأیید کد `/login/verify` است نه `/login`؛ «قطعی اتصال» در تست هرگز موفقیت حساب نمی‌شود (exit صریح)؛ پنتست باید روی سرور موقت با دیتابیس خالی هم سبز باشد (سناریوها خود-بسنده‌اند).

**شرط اجرا:** سایت باید روی `http://127.0.0.1:8080` بالا باشد (مثلاً `python3 run.py`) و `BZ_DATA_DIR` تست با سرور یکی باشد.

---

## ۴) باگ‌کلاسی که در فاز ۶ امنیت پیدا و رفع شد

`spam_gate()` خودش پاسخ می‌فرستد؛ هر `return self.redirect(...)`/`json_out(...)` بعدش = نوشتن هدر دوم روی اتصال keep-alive ⇒ **۵۰۰**. ۲۲ نقطه از این دست پیدا شد — latent بود چون هیچ تستی به مسیر reject نمی‌رسید و پنتست لو داد. همه به پاسخ یگانه اصلاح شدند و `tools/test_coverage_guard.py` بند «هیچ پاسخ دومی پس از `spam_gate` فرستاده نمی‌شود (۰ مورد)» برای همیشه قفلش کرد.
**قاعدهٔ دائمی:** بعد از دروازه‌ای که خودش پاسخ می‌دهد، هیچ پاسخ دومی نفرست؛ برای مسیرهای ضد-oracle از `spam_gate(action, silent=(payload, code))` استفاده کن — دقیقاً یک پاسخ.

---

## ۵) چگونه دوباره ممیزی کنیم (روش جاری)

1. **ایستا:** `python3 tools/audit.py` و `python3 tools/scan_tokens.py` (خروجی ۱ اگر راز واقعی پیدا شود) + `python3 tools/qa_security.py`.
2. **پوشش:** `python3 tools/test_coverage_guard.py` ⇒ باید `COVERAGE GUARD PASS <n>` بدهد (در این بسته: ۳۴).
3. **پویا:** سایت را بالا بیاور و `python3 tools/test_pentest.py`، `tools/test_attack_v280.py`، `tools/test_idor_v280.py` را اجرا کن.
4. **مرورگری:** `python3 tools/test_security.py` (نیاز به Playwright/Chromium دارد).
5. هر یافتهٔ تازه: `file:line` + شاهد + رفع + **تست قفل‌کننده** در همان مسیر. ادعای «رفع شد» بدون خروجی سبز ممنوع (قانون ۱).
