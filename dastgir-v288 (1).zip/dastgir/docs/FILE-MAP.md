# FILE-MAP — نقشهٔ کامل فایل‌های سایت (هر بخش کجاست)

> **هدف:** هر کس (یا هر عامل) بخواهد چیزی را در سایت تغییر دهد یا باگی را
> عیب‌یابی کند، از این یک سند بفهمد **فایلِ آن بخش کجاست**. این سند با
> `tools/routemap.py` و `tools/build_filemap.py` تولید می‌شود.

## ۰) یک‌نگاه — درخت پوشه‌ها

```
repo-369/
├── run.py                  نقطهٔ ورود اجرا (پورت خودکار، سقف fd، systemd-ready)
│
├── server/                 ⬅ همهٔ منطق سمت سرور (پایتون خالص، stdlib-only)
│   ├── app.py              هسته: HTTP handler + مسیریابی + auth/سشن + آپلود + هدرها
│   ├── db.py               لایهٔ داده: ۸۴ جدول، CRUD، rate_ok، مهاجرت/سازگاری SCHEMA
│   ├── features.py         زیرسیستم‌های چندجدولی: چت، سفارش، تیکت، علاقه‌مندی، چانه
│   ├── ui.py               قالب صفحات: کروم، هدر/فوتر، منو، قفل‌ها، بامپ ?vNNN
│   ├── pagecache.py        کش صفحات مهمان (TTL ۸s، ابطال با هر POST)
│   ├── shield.py           سپر ضد-اسپم/حمله: rate-limit، اسکنر، UA مخرب
│   ├── analytics.py        آمار بازدید واقعی (IP/دستگاه/نشست، فیلتر بات)
│   ├── uploads.py          پارسر multipart دستی + سقف‌ها + EXIF-strip
│   ├── sms.py              کد یک‌بارمصرف (SMS/نمایش توسعه)
│   ├── qr.py               رمزگذار QR بدون کتابخانه (SVG)
│   ├── views_public.py     صفحات عمومی: خانه، فهرست، دکان، ثبت‌نام، جست‌وجو
│   ├── views_public2.py    عمومی ۲: مقایسه، نزدیک‌من، رویداد، چانه، تماس
│   ├── views_catalog.py    کاتالوگ/ویترین/کشف
│   ├── views_chat.py       چت بلادرنگ
│   ├── views_customer.py   پنل مشتری (/me)
│   ├── views_owner.py      پنل دکان‌دار (/my)
│   ├── views_panel.py      پنل مدیر بخش ۱ (کسب‌وکارها، نظرات، محتوا…)
│   ├── views_panel2.py     پنل مدیر بخش ۲ (moderation/audit/traffic/قابلیت‌ها)
│   └── views_extra.py      صفحه‌های ریز (درباره/تماس/آفلاین)
│
├── site/                   ⬅ فایل‌های سمت مرورگر
│   ├── sw.js               سرویس‌ورکر (PWA) — VERSION اینجا بامپ می‌شود
│   ├── offline.html        صفحهٔ آفلاین فارسی
│   ├── manifest.webmanifest  مانیفست PWA (نصب روی گوشی)
│   └── assets/
│       ├── css/            ۸ فایل — جدول آن‌ها در بخش ۲
│       ├── js/             ۲۶ فایل — جدول آن‌ها در بخش ۳
│       ├── fonts/          Vazirmatn (وزیرمتن)
│       ├── img/            آیکون‌ها، لوگو، هیرو (۱۹۷ فایل)
│       └── vendor/         کتابخانه‌های محلی: Leaflet و… (بدون CDN)
│
├── tools/                  ⬅ ابزارها و آزمون‌ها (جدول بخش ۵)
├── data/                   ⬅ دیتابیس + آپلودها (در زیپ تحویلی نیست)
├── docs/                   گزارش‌های ممیزی، تحقیق پنل، نقشهٔ مسیرها
└── *.md                    مستندات (HANDBOOK/READY/DEPLOY/…)
```

## ۱) «این صفحه/بخش کدام فایل است؟» — جدول بخش‌ها

| بخش سایت | مسیرها | فایل‌های منطق | فایل‌های ظاهر | فایل‌های رفتار (JS) |
|---|---|---|---|---|
| صفحهٔ اصلی | `/` | `views_public.py` | `main.css`, `pages.css` | `app.js`, `stories.js` |
| فهرست/جست‌وجو/دسته‌ها | `/businesses`, `/areas` | `views_public.py` | `pages.css` | `app.js`, `catpicker.js` |
| صفحهٔ کسب‌وکار | `/b/<slug>` | `views_public.py` | `pages.css`, `main.css` | `app.js`, `gallery.js` |
| نقشه | `/map` | `views_public2.py` | `pages.css` (`.map-*`) | `mappage.js` |
| مقایسهٔ قیمت | `/prices` | `views_public2.py` | `pages.css` | `app.js` |
| کاتالوگ/ویترین | `/catalog` | `views_catalog.py` | `pages.css` | `app.js` |
| چانه‌زنی | `/haggle/*`, `/offer/*` | `views_public2.py` | `pages.css` | `app.js` |
| ثبت کسب‌وکار | `/submit` | `views_public.py` | `pages.css` | `app.js`, `catpicker.js` |
| پنل مشتری | `/me/*` | `views_customer.py` | `pages.css` | `app.js` |
| پنل دکان‌دار | `/my/*` | `views_owner.py` | `main.css`, `pages.css` | `app.js`, `imagefield.js` |
| پنل مدیر | `/panel/*` | `views_panel.py`, `views_panel2.py` | `main.css`, `pages.css` | `panel.js` |
| چت | `/chat/*` | `views_chat.py` | `pages.css` | `chat.js` |
| ورود/OTP | `/login*`, `/alert` | `app.py` (auth) + `views_public.py` | `main.css` | `app.js` |
| API | `/api/*` | `app.py` | — | — |

## ۲) فایل‌های CSS (چه چیزی کجاست)

| فایل | اندازه (خط) | نقش |
|---|---|---|
| `jdatepicker.css` | 150 | — |
| `main.css` | 2205 | — |
| `mobile-refine.css` | 555 | — |
| `mobile-standard.css` | 142 | — |
| `pages.css` | 4710 | — |
| `theme-light.css` | 35 | — |
| `theme-night.css` | 35 | — |
| `tokens.css` | 311 | — |

- **توکن‌ها** همه در `tokens.css` (`:root` روز + `[data-theme]` شب).
- **رنگ خام در ویوها ممنوع است** (قانون معماری) — فقط توکن.
- **چیدمان موبایل:** `mobile-refine.css` و `mobile-standard.css` — هدف لمس ≥۴۴px با
  `var(--tap)`.
- **کامپوننت‌های نقشه** (نزدیک‌من/زوم/کارت انتخاب‌شده) همگی با پیشوند `.map-`
  در `pages.css`.

## ۳) فایل‌های JS (رفتار)

| فایل | خط | نقش |
|---|---|---|
| `admin-edit.js` | 84 | — |
| `app.js` | 2231 | — |
| `assist.js` | 227 | — |
| `bulk.js` | 53 | — |
| `cart.js` | 129 | — |
| `catpicker.js` | 194 | — |
| `chat.js` | 279 | — |
| `compress.js` | 634 | — |
| `countdown.js` | 27 | — |
| `dupcheck.js` | 125 | — |
| `favorites.js` | 64 | — |
| `imagefield.js` | 390 | — |
| `itemform.js` | 106 | — |
| `jalali.js` | 115 | — |
| `jdatepicker.js` | 260 | — |
| `live.js` | 125 | — |
| `map.js` | 334 | — |
| `mappage.js` | 497 | — |
| `nearby.js` | 208 | — |
| `notifpoll.js` | 41 | — |
| `notifpush.js` | 171 | — |
| `qa.js` | 98 | — |
| `regwizard.js` | 88 | — |
| `social.js` | 50 | — |
| `stories.js` | 252 | — |
| `upload.js` | 182 | — |

قانون: HTML سمت سرور رندر می‌شود؛ JS فقط رفتار (تعامل، OTP خودکار، بیکن آمار).

## ۴) نقشهٔ مسیرها (تولید خودکار)

# نقشهٔ مسیرها — هر URL کجاست؟

> تولید خودکار با `python3 tools/routemap.py -o docs/FILE-MAP.md` — اگر مسیر تازه‌ای اضافه شد، دوباره اجرا کنید.


## پنل مدیر (/panel)

| مسیر | فایل | خط |
|---|---|---|
| `/panel` | `server/app.py` | 848 |
| `/panel` | `server/app.py` | 1170 |
| `/panel` | `server/app.py` | 1178 |
| `/panel` | `server/app.py` | 1901 |
| `/panel/ad/(` | `server/app.py` | 5271 |
| `/panel/ad/new` | `server/app.py` | 4171 |
| `/panel/ads` | `server/app.py` | 1999 |
| `/panel/alert/(` | `server/app.py` | 5383 |
| `/panel/alerts` | `server/app.py` | 2009 |
| `/panel/analytics` | `server/app.py` | 1967 |
| `/panel/analytics/export` | `server/app.py` | 1969 |
| `/panel/appearance` | `server/app.py` | 1931 |
| `/panel/appearance` | `server/app.py` | 4134 |
| `/panel/appearance` | `server/app.py` | 4800 |
| `/panel/areas` | `server/app.py` | 2085 |
| `/panel/areas/rename` | `server/app.py` | 4291 |
| `/panel/assistant` | `server/app.py` | 2054 |
| `/panel/assistant` | `server/app.py` | 4895 |
| `/panel/audit` | `server/app.py` | 2056 |
| `/panel/audit/export` | `server/app.py` | 2058 |
| `/panel/backup` | `server/app.py` | 2096 |
| `/panel/backup/db` | `server/app.py` | 2140 |
| `/panel/backup/export` | `server/app.py` | 2098 |
| `/panel/backup/full` | `server/app.py` | 2104 |
| `/panel/backup/import` | `server/app.py` | 5399 |
| `/panel/badge/(` | `server/app.py` | 5127 |
| `/panel/badge/new` | `server/app.py` | 5117 |
| `/panel/badges` | `server/app.py` | 1993 |
| `/panel/badges/auto` | `server/app.py` | 5168 |
| `/panel/badges/grant` | `server/app.py` | 5156 |
| `/panel/booking/(` | `server/app.py` | 4722 |
| `/panel/bookings` | `server/app.py` | 1919 |
| `/panel/broadcast` | `server/app.py` | 2081 |
| `/panel/broadcast` | `server/app.py` | 4413 |
| `/panel/business/(` | `server/app.py` | 1907 |
| `/panel/business/(` | `server/app.py` | 4560 |
| `/panel/business/(` | `server/app.py` | 4566 |
| `/panel/business/(` | `server/app.py` | 4630 |
| `/panel/business/(new|` | `server/app.py` | 4525 |
| `/panel/business/new` | `server/app.py` | 1905 |
| `/panel/businesses` | `server/app.py` | 1903 |
| `/panel/businesses/bulk` | `server/app.py` | 4972 |
| `/panel/businesses/export` | `server/app.py` | 2092 |
| `/panel/businesses/import` | `server/app.py` | 2090 |
| `/panel/businesses/import` | `server/app.py` | 4993 |
| `/panel/catalog/(` | `server/app.py` | 1947 |
| `/panel/catalog/(` | `server/app.py` | 1951 |
| `/panel/catalog/(` | `server/app.py` | 5042 |
| `/panel/catalog/(` | `server/app.py` | 5049 |
| `/panel/categories` | `server/app.py` | 1911 |
| `/panel/category/(` | `server/app.py` | 1913 |
| `/panel/category/(` | `server/app.py` | 3875 |
| `/panel/category/(` | `server/app.py` | 4649 |
| `/panel/category/(` | `server/app.py` | 4659 |
| `/panel/category/new` | `server/app.py` | 3852 |
| `/panel/category/new` | `server/app.py` | 4640 |
| `/panel/chat/(` | `server/app.py` | 2029 |
| `/panel/chat/(` | `server/app.py` | 4230 |
| `/panel/chat/(` | `server/app.py` | 4242 |
| `/panel/chats` | `server/app.py` | 2027 |
| `/panel/claim/(` | `server/app.py` | 5020 |
| `/panel/claims` | `server/app.py` | 1939 |
| `/panel/customer/(` | `server/app.py` | 4386 |
| `/panel/customer/(` | `server/app.py` | 4401 |
| `/panel/customers` | `server/app.py` | 2079 |
| `/panel/deal/(` | `server/app.py` | 4375 |
| `/panel/deal/new` | `server/app.py` | 4350 |
| `/panel/deals` | `server/app.py` | 2046 |
| `/panel/demo` | `server/app.py` | 2087 |
| `/panel/demo` | `server/app.py` | 4298 |
| `/panel/edit/(` | `server/app.py` | 5322 |
| `/panel/editor` | `server/app.py` | 2052 |
| `/panel/editor` | `server/app.py` | 4277 |
| `/panel/edits` | `server/app.py` | 2007 |
| `/panel/edits/toggle` | `server/app.py` | 5337 |
| `/panel/event/(` | `server/app.py` | 2003 |
| `/panel/event/(` | `server/app.py` | 5299 |
| `/panel/event/new` | `server/app.py` | 5292 |
| `/panel/events` | `server/app.py` | 2001 |
| `/panel/features` | `server/app.py` | 2015 |
| `/panel/features` | `server/app.py` | 4489 |
| `/panel/follows` | `server/app.py` | 2083 |
| `/panel/gallery/(` | `server/app.py` | 1943 |
| `/panel/gallery/(` | `server/app.py` | 5037 |
| `/panel/inbox` | `server/app.py` | 2013 |
| `/panel/inline-edit` | `server/app.py` | 2900 |
| `/panel/inquiries` | `server/app.py` | 1941 |
| `/panel/inquiry/(` | `server/app.py` | 5032 |
| `/panel/insights` | `server/app.py` | 2011 |
| `/panel/list/(` | `server/app.py` | 2042 |
| `/panel/list/(` | `server/app.py` | 4325 |
| `/panel/list/(` | `server/app.py` | 4340 |
| `/panel/list/new` | `server/app.py` | 4316 |
| `/panel/lists` | `server/app.py` | 2040 |
| `/panel/login` | `server/app.py` | 2873 |
| `/panel/logout` | `server/app.py` | 2894 |
| `/panel/media` | `server/app.py` | 2178 |
| `/panel/media/delete` | `server/app.py` | 4964 |
| `/panel/media/gc` | `server/app.py` | 4958 |
| `/panel/message/(` | `server/app.py` | 4774 |
| `/panel/messages` | `server/app.py` | 1927 |
| `/panel/moderation` | `server/app.py` | 2077 |
| `/panel/order/(` | `server/app.py` | 4259 |
| `/panel/order/(` | `server/app.py` | 4264 |
| `/panel/orders` | `server/app.py` | 2036 |
| `/panel/owner/(` | `server/app.py` | 5000 |
| `/panel/owners` | `server/app.py` | 1937 |
| `/panel/pages` | `server/app.py` | 1929 |
| `/panel/pages` | `server/app.py` | 4788 |
| `/panel/plan/(` | `server/app.py` | 5189 |
| `/panel/plan/new` | `server/app.py` | 5174 |
| `/panel/plans` | `server/app.py` | 1995 |
| `/panel/plans/payment` | `server/app.py` | 5208 |
| `/panel/post/(` | `server/app.py` | 1923 |
| `/panel/post/(` | `server/app.py` | 4737 |
| `/panel/post/(` | `server/app.py` | 4763 |
| `/panel/post/new` | `server/app.py` | 4753 |
| `/panel/posts` | `server/app.py` | 1921 |
| `/panel/qa` | `server/app.py` | 1957 |
| `/panel/question/(` | `server/app.py` | 5059 |
| `/panel/report/(` | `server/app.py` | 5101 |
| `/panel/reports` | `server/app.py` | 1959 |
| `/panel/reports/bulk` | `server/app.py` | 5082 |
| `/panel/review/(` | `server/app.py` | 4701 |
| `/panel/reviews` | `server/app.py` | 1917 |
| `/panel/reviews/bulk` | `server/app.py` | 4684 |
| `/panel/rotate-token` | `server/app.py` | 4927 |
| `/panel/search` | `server/app.py` | 1933 |
| `/panel/searches/clear` | `server/app.py` | 5378 |
| `/panel/security` | `server/app.py` | 4933 |
| `/panel/settings` | `server/app.py` | 1935 |
| `/panel/settings` | `server/app.py` | 4821 |
| `/panel/spam` | `server/app.py` | 1965 |
| `/panel/spam/ban` | `server/app.py` | 4477 |
| `/panel/spam/lift` | `server/app.py` | 4467 |
| `/panel/spam/policy` | `server/app.py` | 4453 |
| `/panel/spam/policy-reset` | `server/app.py` | 4461 |
| `/panel/stories` | `server/app.py` | 2048 |
| `/panel/story/(` | `server/app.py` | 4426 |
| `/panel/subscription/(` | `server/app.py` | 5245 |
| `/panel/subscription/new` | `server/app.py` | 5227 |
| `/panel/subscriptions` | `server/app.py` | 1997 |
| `/panel/ticket/(` | `server/app.py` | 2019 |
| `/panel/ticket/(` | `server/app.py` | 3993 |
| `/panel/ticket/(` | `server/app.py` | 4501 |
| `/panel/tickets` | `server/app.py` | 2017 |
| `/panel/tickets/bulk` | `server/app.py` | 4670 |
| `/panel/traffic` | `server/app.py` | 1963 |
| `/panel/traffic/unblock` | `server/app.py` | 4440 |
| `/panel/trash` | `server/app.py` | 1961 |
| `/panel/trash/(` | `server/app.py` | 4430 |
| `/panel/unlock/(` | `server/app.py` | 5344 |
| `/panel/unlocks` | `server/app.py` | 2023 |
| `/panel/unlocks/founder` | `server/app.py` | 5367 |

## پنل دکان‌دار (/my)

| مسیر | فایل | خط |
|---|---|---|
| `/my` | `server/app.py` | 850 |
| `/my` | `server/app.py` | 1205 |
| `/my` | `server/app.py` | 1635 |
| `/my/` | `server/app.py` | 3176 |
| `/my/account` | `server/app.py` | 1701 |
| `/my/account` | `server/app.py` | 3201 |
| `/my/assistant` | `server/app.py` | 1671 |
| `/my/booking/(` | `server/app.py` | 3528 |
| `/my/bookings` | `server/app.py` | 1681 |
| `/my/broadcast` | `server/app.py` | 1699 |
| `/my/broadcast/(fulfill|dismiss)$` | `server/app.py` | 3358 |
| `/my/broadcast/send` | `server/app.py` | 3340 |
| `/my/business/(` | `server/app.py` | 1722 |
| `/my/business/(` | `server/app.py` | 3280 |
| `/my/business/(` | `server/app.py` | 3464 |
| `/my/businesses` | `server/app.py` | 1677 |
| `/my/catalog/(` | `server/app.py` | 1734 |
| `/my/catalog/(` | `server/app.py` | 1738 |
| `/my/catalog/(` | `server/app.py` | 3392 |
| `/my/catalog/(` | `server/app.py` | 3559 |
| `/my/catalog/(` | `server/app.py` | 3587 |
| `/my/chat/(` | `server/app.py` | 1652 |
| `/my/chat/(` | `server/app.py` | 1661 |
| `/my/chat/(` | `server/app.py` | 3208 |
| `/my/chats` | `server/app.py` | 1659 |
| `/my/claim` | `server/app.py` | 1685 |
| `/my/claim` | `server/app.py` | 3546 |
| `/my/export` | `server/app.py` | 1703 |
| `/my/gallery/(` | `server/app.py` | 1726 |
| `/my/gallery/(` | `server/app.py` | 3596 |
| `/my/inquiries` | `server/app.py` | 1683 |
| `/my/inquiry/(` | `server/app.py` | 3605 |
| `/my/logout` | `server/app.py` | 3168 |
| `/my/notif-settings` | `server/app.py` | 1639 |
| `/my/notif-settings` | `server/app.py` | 3194 |
| `/my/notif/(` | `server/app.py` | 1641 |
| `/my/notifications` | `server/app.py` | 1637 |
| `/my/notifications/read` | `server/app.py` | 3190 |
| `/my/offer/(` | `server/app.py` | 3428 |
| `/my/offers` | `server/app.py` | 1689 |
| `/my/order/(` | `server/app.py` | 3228 |
| `/my/order/(` | `server/app.py` | 3233 |
| `/my/orders` | `server/app.py` | 1669 |
| `/my/plan` | `server/app.py` | 1697 |
| `/my/question/(` | `server/app.py` | 3512 |
| `/my/questions` | `server/app.py` | 1687 |
| `/my/review/(` | `server/app.py` | 3497 |
| `/my/reviews` | `server/app.py` | 1679 |
| `/my/stats/(` | `server/app.py` | 1730 |
| `/my/stories` | `server/app.py` | 1673 |
| `/my/story/(` | `server/app.py` | 1195 |
| `/my/story/(` | `server/app.py` | 3249 |
| `/my/story/add` | `server/app.py` | 4009 |
| `/my/ticket/(` | `server/app.py` | 1693 |
| `/my/ticket/(` | `server/app.py` | 3371 |
| `/my/ticket/(` | `server/app.py` | 3976 |
| `/my/tickets` | `server/app.py` | 1691 |
| `/my/tickets` | `server/app.py` | 3315 |
| `/my/tickets` | `server/app.py` | 3950 |
| `/my/trash` | `server/app.py` | 1675 |
| `/my/trash/(` | `server/app.py` | 3259 |

## پنل مشتری (/me)

| مسیر | فایل | خط |
|---|---|---|
| `/me` | `server/app.py` | 852 |
| `/me` | `server/app.py` | 1218 |
| `/me` | `server/app.py` | 1747 |
| `/me/account` | `server/app.py` | 1769 |
| `/me/account` | `server/app.py` | 2602 |
| `/me/bale/connect` | `server/app.py` | 1771 |
| `/me/chat/(` | `server/app.py` | 1753 |
| `/me/chat/(` | `server/app.py` | 1820 |
| `/me/chat/(` | `server/app.py` | 2811 |
| `/me/chat/(` | `server/app.py` | 2831 |
| `/me/chats` | `server/app.py` | 1751 |
| `/me/export` | `server/app.py` | 1791 |
| `/me/favorites` | `server/app.py` | 1767 |
| `/me/following` | `server/app.py` | 1831 |
| `/me/login` | `server/app.py` | 1214 |
| `/me/login` | `server/app.py` | 2544 |
| `/me/login/password` | `server/app.py` | 2567 |
| `/me/login/verify` | `server/app.py` | 2561 |
| `/me/logout` | `server/app.py` | 2570 |
| `/me/name` | `server/app.py` | 2593 |
| `/me/notif-settings` | `server/app.py` | 1829 |
| `/me/notif-settings` | `server/app.py` | 2707 |
| `/me/notif/(` | `server/app.py` | 1796 |
| `/me/notifications` | `server/app.py` | 1827 |
| `/me/notifications/read` | `server/app.py` | 2690 |
| `/me/order/(` | `server/app.py` | 1763 |
| `/me/order/(` | `server/app.py` | 1809 |
| `/me/order/(` | `server/app.py` | 2801 |
| `/me/orders` | `server/app.py` | 1761 |
| `/me/profile` | `server/app.py` | 1749 |
| `/me/profile` | `server/app.py` | 2578 |
| `/me/soroush/connect` | `server/app.py` | 1783 |

## صفحهٔ کسب‌وکار (/b)

| مسیر | فایل | خط |
|---|---|---|
| `/b/` | `server/app.py` | 1486 |
| `/b/` | `server/app.py` | 1499 |
| `/b/([^/?#]+)$` | `server/app.py` | 1811 |
| `/b/([^/]+)/ask-question$` | `server/app.py` | 2965 |
| `/b/([^/]+)/book$` | `server/app.py` | 3139 |
| `/b/([^/]+)/chat$` | `server/app.py` | 1332 |
| `/b/([^/]+)/report$` | `server/app.py` | 3018 |
| `/b/([^/]+)/review$` | `server/app.py` | 3055 |
| `/b/([^/]+)/review$` | `server/app.py` | 4036 |

## API

| مسیر | فایل | خط |
|---|---|---|
| `/api/` | `server/app.py` | 293 |
| `/api/alert` | `server/app.py` | 3034 |
| `/api/assistant/chat` | `server/app.py` | 2497 |
| `/api/assistant/status` | `server/app.py` | 1397 |
| `/api/businesses` | `server/app.py` | 1440 |
| `/api/chat/` | `server/app.py` | 875 |
| `/api/chat/(` | `server/app.py` | 1353 |
| `/api/check-duplicate` | `server/app.py` | 2933 |
| `/api/favorite` | `server/app.py` | 2612 |
| `/api/follow` | `server/app.py` | 2631 |
| `/api/live` | `server/app.py` | 1272 |
| `/api/nearby` | `server/app.py` | 1421 |
| `/api/push/config` | `server/app.py` | 1385 |
| `/api/push/subscribe` | `server/app.py` | 2644 |
| `/api/push/unsubscribe` | `server/app.py` | 2669 |
| `/api/question-helpful` | `server/app.py` | 3000 |
| `/api/review-helpful` | `server/app.py` | 2718 |
| `/api/search` | `server/app.py` | 1447 |
| `/api/soroush` | `server/app.py` | 1136 |
| `/api/stories` | `server/app.py` | 1264 |
| `/api/stories/` | `server/app.py` | 871 |
| `/api/stories/(` | `server/app.py` | 2488 |
| `/api/unread-count` | `server/app.py` | 1406 |

## فایل‌های ثابت / PWA

| مسیر | فایل | خط |
|---|---|---|
| `/assets/` | `server/app.py` | 1008 |
| `/favicon.ico` | `server/app.py` | 1012 |
| `/robots.txt` | `server/app.py` | 1014 |
| `/sitemap.xml` | `server/app.py` | 1031 |

## عمومی / متفرقه

| مسیر | فایل | خط |
|---|---|---|
| `/` | `server/adminbot.py` | 1916 |
| `/` | `server/app.py` | 1462 |
| `/` | `server/bale.py` | 170 |
| `/` | `server/soroush.py` | 130 |
| `/#[0-9a-fA-F]{6}$` | `server/adminbot_content.py` | 989 |
| `/(` | `server/features.py` | 1027 |
| `/((?:13|14)` | `server/assistant.py` | 1394 |
| `/((?:13|14)` | `server/features.py` | 1010 |
| `/([01]?` | `server/assistant.py` | 1416 |
| `/([a-f0-9]{16})` | `server/analytics.py` | 143 |
| `/(me|my|panel)/chat/(` | `server/app.py` | 3915 |
| `/(my|panel)/catalog/(` | `server/app.py` | 4198 |
| `/(my|panel)/gallery/(` | `server/app.py` | 4070 |
| `/.well-known/security.txt` | `server/app.py` | 1044 |
| `/?(search|جست‌?وجو)` | `server/assistant.py` | 529 |
| `/ad/(` | `server/app.py` | 1587 |
| `/alert` | `server/app.py` | 3043 |
| `/area/([^/]+)$` | `server/app.py` | 1240 |
| `/areas` | `server/app.py` | 1234 |
| `/assistant` | `server/app.py` | 1612 |
| `/auth/bale` | `server/app.py` | 1106 |
| `/auth/soroush` | `server/app.py` | 1121 |
| `/blog` | `server/app.py` | 1514 |
| `/blog/` | `server/app.py` | 1520 |
| `/businesses` | `server/app.py` | 1464 |
| `/cart` | `server/app.py` | 1230 |
| `/catalog` | `server/app.py` | 1316 |
| `/categories` | `server/app.py` | 1236 |
| `/chat-file/(` | `server/app.py` | 1067 |
| `/cities` | `server/app.py` | 1238 |
| `/contact` | `server/app.py` | 1610 |
| `/contact` | `server/app.py` | 2921 |
| `/deals` | `server/app.py` | 1260 |
| `/events` | `server/app.py` | 1580 |
| `/events/` | `server/app.py` | 1584 |
| `/favorites` | `server/app.py` | 1600 |
| `/features` | `server/app.py` | 1626 |
| `/feed.xml` | `server/app.py` | 1029 |
| `/haggle/(` | `server/app.py` | 1525 |
| `/haggle/(` | `server/app.py` | 3082 |
| `/healthz` | `server/app.py` | 1033 |
| `/item/(` | `server/app.py` | 1294 |
| `/item/(` | `server/app.py` | 1810 |
| `/item/(` | `server/app.py` | 2946 |
| `/list/([^/]+)$` | `server/app.py` | 1254 |
| `/lists` | `server/app.py` | 1250 |
| `/login` | `server/app.py` | 2907 |
| `/login/password` | `server/app.py` | 2913 |
| `/login/verify` | `server/app.py` | 2910 |
| `/map` | `server/app.py` | 1512 |
| `/nearby` | `server/app.py` | 1576 |
| `/offer/([A-Za-z0-9_-]{6,64})$` | `server/app.py` | 1531 |
| `/offer/([A-Za-z0-9_-]{6,64})$` | `server/app.py` | 3109 |
| `/order/create` | `server/app.py` | 2740 |
| `/order/ok` | `server/app.py` | 1244 |
| `/prices` | `server/app.py` | 1570 |
| `/prices/alert` | `server/app.py` | 2547 |
| `/pricing` | `server/app.py` | 1602 |
| `/qr/([^/]+)` | `server/app.py` | 1541 |
| `/start(?:@` | `server/app.py` | 2296 |
| `/submit` | `server/app.py` | 1620 |
| `/submit` | `server/app.py` | 2929 |
| `/subscribe` | `server/app.py` | 1604 |
| `/subscribe` | `server/app.py` | 2917 |
| `/subscribe` | `server/app.py` | 3837 |
| `/ticket-file/(` | `server/app.py` | 1086 |
| `/vcard/([^/]+)$` | `server/app.py` | 1560 |
| `/[a-z0-9_-]{2,30}$` | `server/adminbot_content.py` | 633 |

## ۵) ابزارها و آزمون‌ها (tools/)

| ابزار | نقش |
|---|---|
| `routemap.py` | ⭐ همین نقشهٔ مسیرها را می‌سازد (بعد از هر مسیر تازه اجرا کنید) |
| `build_filemap.py` | این سند را می‌سازد |
| `design_audit.py` | ممیزی جامع طراحی: ۹۴ صفحه × ۷ عرض، شات + متریک (tap/font/overflow/…) |
| `mobile_audit.py` | ممیزی موبایل (۴ دستگاه) |
| `contrast_audit.py` | کنتراست دو تم (AA) |
| `audit.py` | شکار کنترل‌های بی‌عمل (۴۶+ صفحه) |
| `navfit.py` | اندازه‌گیری سرریز هدر |
| `bench_load.py`, `bench_1000.py`, `bench_panel.py` | بار/کارایی (۵۰۰–۱۰۰۰ کاربر) |
| `test_*.py` (۴۰+ فایل) | باتری رگرسیون — فهرست کامل در `ARCHITECTURE.md` بخش ۷ |
| `seed_demo.py`, `reset_testdata.py` | دادهٔ نمونه / پاک‌سازی |
| `taxonomy.py`, `slice_taxonomy_icons.py` | درخت ۱۷۳ دسته و برش آیکون‌ها |
| `make_evidence*.py` | شواهد تصویری ممیزی (Playwright) |

## ۶) «برای تغییر X کجا بروم؟» — برگهٔ تقلب

| می‌خواهم… | برو به |
|---|---|
| متن/تایتل صفحه‌ای را عوض کنم | ویو همان مسیر (بخش ۱ یا جدول مسیرها) |
| رنگ/فونت/فاصله را عوض کنم | `site/assets/css/` — اول `tokens.css`، بعد `main.css`/`pages.css` |
| رفتار دکمه/فرم را عوض کنم | `site/assets/js/app.js` (یا فایل JS همان بخش) |
| مسیر جدید اضافه کنم | `server/app.py` → `route_get`/`route_post` + ویو مناسب |
| ستون/جدول جدید در دیتابیس | `server/db.py` → `SCHEMA` + `_reconcile_schema()` (مهاجرت خودکار) |
| سقف/قاعدهٔ امنیتی | `server/shield.py` + `db.rate_ok` + `SECURITY_HEADERS` در app.py |
| کش/سرعت | `server/pagecache.py` + بخش gzip/ETag در `app.py` |
| نسخهٔ assetها را بامپ کنم | `server/ui.py` (`?vNNN`) + `site/sw.js` (`VERSION`) + `tools/test_migration.py` |
| باگی در پنل مدیر | `views_panel.py` / `views_panel2.py` + `test_panel_*.py` |
| استقرار روی هاست | `DEPLOY.md` + `docs/HOSTING-v119.md` |
