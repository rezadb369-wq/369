# 📱 به‌روزرسانی سایت در نسخه‌های بعدی از راه ترموکس (Termux)

> **روش، همان روش کنونی است:** از گوشی با SSH به سرور وصل می‌شوید و **یک فرمان** `deploy/update.sh` را با زیپ نسخهٔ تازه اجرا می‌کنید. هیچ چیز دیگری لازم نیست.
> این راهنما بر پایهٔ رفتار واقعی `deploy/update.sh` (۲۴۴۴ بایت، در همین بسته) نوشته شده است.
>
> **قرارداد این سند:** هر فرمان یا **آزموده‌شده** است (روی همین بسته اجرا شده و خروجی‌اش آمده) یا صریحاً **[الگو]** علامت خورده — یعنی جای‌نما دارد (`<…>`) و باید مقدار واقعی‌اش را از پیام تحویل همان نسخه بردارید. فرمان‌های سمت سرور روی VPS واقعی **اجرا نشده‌اند** (اینجا سرور زنده در دسترس نیست) و همه **[الگو]** هستند؛ فقط نحوِ آن‌ها با `bash -n` بررسی شده است.
>
> سرور زنده: `130.185.78.237` · مسیر برنامه: `/opt/dastgir` · سرویس systemd: `bazarche` · پورت داخلی: `8080` · دامنه: `daastgir.ir`.

---

## ۰) چه اتفاقی می‌افتد (قبل از اینکه چیزی بزنید)

`update.sh` دقیقاً این کارها را به همین ترتیب می‌کند:

1. چک می‌کند **root** باشید (`sudo`) و زیپ وجود داشته باشد و `unzip`/`rsync`/`python3` نصب باشند — وگرنه با پیام فارسی متوقف می‌شود.
2. زیپ را در یک پوشهٔ موقت (`mktemp -d /tmp/dastgir-update.XXXXXX`) باز می‌کند و **ساختارش را اعتبارسنجی** می‌کند: باید `dastgir/run.py` و `dastgir/VERSION.txt` داشته باشد + `unzip -t` سالم باشد.
3. **پشتیبان سازگار** می‌گیرد: `python3 /opt/dastgir/tools/backup.py --dir /var/backups/dastgir --no-rotate` (با API رسمی backup در SQLite، بدون توقف سرور).
4. `systemctl stop bazarche`.
5. `rsync -a --delete` از پوشهٔ موقت به `/opt/dastgir/` — با **حفظ** این سه‌تا: `/data/`، `/site/assets/img/uploads/`، `/site/assets/chat-files/`. یعنی پایگاه داده، عکس‌ها و فایل‌های چت **هرگز پاک نمی‌شوند**.
6. مسیرهای لازم را می‌سازد (`data/chat-files`، `data/code-jobs`، `data/code-backups`، `site/assets/img/uploads`).
7. اگر کرون کدگارد نباشد، `/etc/cron.d/dastgir-codeguard` را می‌گذارد (هر دقیقه، کاربر root).
8. `chown -R www-data:www-data /opt/dastgir` و نصب `bazarche.service` + `systemctl daemon-reload`.
9. اگر `deploy/brain.env` در بسته باشد، `deploy/apply-brain.sh` را اجرا می‌کند → **همهٔ خط‌های `AI_*` قبلی روی سرور حذف و مغز بسته جایگزین می‌شود** (بقیهٔ رازها مثل توکن بات دست‌نخورده می‌مانند).
10. `systemctl start bazarche` → ۲ ثانیه صبر → `systemctl is-active --quiet bazarche` → `curl -fsS http://127.0.0.1:8080/healthz`.
11. چاپ می‌کند: **`نسخه <VERSION.txt> با موفقیت نصب شد.`**

اگر هر جا شکست بخورد، `trap cleanup EXIT` پوشهٔ موقت را پاک می‌کند و **اگر سرویس را متوقف کرده بود، خودش روشنش می‌کند** — پس سایت خاموش نمی‌ماند.
چون اسکریپت `set -euo pipefail` دارد، اولین خطا آن را متوقف می‌کند.

---

## ۱) آماده‌سازی ترموکس روی گوشی

```bash
pkg update && pkg install openssh curl
```

**[الگو]** — روی VPS اجرا نشده؛ این دستور استاندارد خودِ Termux است. اگر `pkg` از شما تأیید خواست، `y` بزنید. اگر `openssh` از قبل نصب است، همان `pkg update` کافی است.

بررسی نصب:
```bash
ssh -V; curl --version | head -1
```

---

## ۲) وصل شدن به سرور

```bash
ssh <user>@<server-ip>
```

**[الگو]** — برای سایت خودتان:
```bash
ssh root@130.185.78.237
```
`<user>` همان کاربری است که هنگام خرید VPS گرفته‌اید (معمولاً `root`). اولین بار اثر انگشت میزبان را می‌پرسد → `yes`.
اگر کلید SSH ندارید، رمز را می‌پرسد؛ برای راحتیِ بعدی می‌توانید کلید بسازید:

```bash
ssh-keygen -t ed25519            # [الگو] — یک‌بار روی گوشی
ssh-copy-id root@130.185.78.237  # [الگو] — کلید عمومی را روی سرور می‌گذارد
```

---

## ۳) الگوی به‌روزرسانی (یک خط، همان روش کنونی)

این **الگوی اصلی** است. `<LINK>` و `<SHA256>` و `vXXX` را از پیام تحویل همان نسخه بردارید:

```bash
cd /tmp && rm -f dastgir-vXXX.zip && curl -sSL -o dastgir-vXXX.zip <LINK> && echo "<SHA256>  dastgir-vXXX.zip" | sha256sum -c && sudo bash /opt/dastgir/deploy/update.sh /tmp/dastgir-vXXX.zip
```

**نکته‌های حیاتی:**
- بین `<SHA256>` و نام فایل **دو فاصله** هست (یک فاصله + یک فاصلهٔ جداساز که `sha256sum` می‌خواهد). با یک فاصله، `sha256sum -c` شکست می‌خورد.
- `curl -sSL` یعنی بی‌صدا + خطاها را نشان بده + redirect را دنبال کن. اگر میزبان فایل کاربر‌ایجنت خاصی می‌خواهد، `-A 'curl/8.5'` اضافه کنید.
- `&&` بین همهٔ بخش‌هاست: اگر هش نخواند، `update.sh` **هرگز اجرا نمی‌شود**. این عمدی است.

### نمونهٔ پرشده برای همین نسخه

فایل واقعی این بسته `dastgir-v280.zip` است و هش آن:

```
2611689ea7da1f23323162b09e0e2e03192f33144aba913e4ac2b5f85fbf13ee  dastgir-v280.zip
```

**آزموده‌شده (روی همین بسته، در محیط کاری — نه روی VPS):**
```
$ echo "2611689ea7da1f23323162b09e0e2e03192f33144aba913e4ac2b5f85fbf13ee  dastgir-v280.zip" | sha256sum -c
dastgir-v280.zip: OK
```

پس الگوی پرشده برای v280 (بخش `<LINK>` هنوز الگو است):

```bash
cd /tmp && rm -f dastgir-v280.zip && curl -sSL -o dastgir-v280.zip <LINK> && echo "2611689ea7da1f23323162b09e0e2e03192f33144aba913e4ac2b5f85fbf13ee  dastgir-v280.zip" | sha256sum -c && sudo bash /opt/dastgir/deploy/update.sh /tmp/dastgir-v280.zip
```

**[الگو]** — `<LINK>` را با نشانی دانلود همان نسخه عوض کنید.

### اگر `update.sh` روی سرور قدیمی‌تر از بسته است

اسکریپت را از داخل خودِ زیپ اجرا کنید (زیپ ریشهٔ `dastgir/` دارد):

```bash
cd /tmp && rm -rf dg && mkdir dg && unzip -q dastgir-v280.zip -d dg && sudo bash dg/dastgir/deploy/update.sh /tmp/dastgir-v280.zip
```
**[الگو]** — `unzip` روی سرور نصب است (خود `update.sh` هم به آن نیاز دارد و چک می‌کند).

### نصب اول روی VPS تازه (یک‌بار)

اگر سایت هنوز نصب نشده، به‌جای `update.sh` از نصب‌کننده استفاده کنید:
```bash
cd /root && unzip -oq dastgir-v280.zip -d /root && sudo bash /root/dastgir/deploy/install.sh /root/dastgir-v280.zip
```
**[الگو]** — `install.sh` خودش بسته‌های پایه، سواپ ۲ گیگ، فایروال (اول ۲۲ بعد ۸۰/۴۴۳)، سرویس systemd، nginx، `chown` و پشتیبان شبانهٔ ۳ بامداد را انجام می‌دهد و در پایان نشانی سایت و دستور پیدا کردن لینک پنل را چاپ می‌کند. جزئیات: `deploy/README-fa.md`.

---

## ۴) بررسی پس از نصب (هر سه را انجام دهید)

### ۴٫۱ نسخه روی سرور

```bash
cat /opt/dastgir/VERSION.txt
```
**[الگو]** — انتظار: `280`. همین عدد باید با `DIAG_LATEST` در `server/adminbot.py` و `bazarche-v280` در `site/sw.js` یکی باشد.

```bash
systemctl is-active bazarche
curl -s http://127.0.0.1:8080/healthz; echo
curl -s https://daastgir.ir/sw.js | grep -o "bazarche-v[0-9]*"
```
**[الگو]** — انتظار: `active` · `ok` · `bazarche-v280`.

### ۴٫۲ دستور «تشخیص» در بات مدیر

در چت **خصوصی** بات مدیر (بله) بنویسید:

```
تشخیص
```

گزارش زندهٔ **۶ خطی شماره‌دار** می‌گیرید: نسخه · مغز با تست واقعی · کرون کدگارد · صف استقرار · سرویس · تأیید معلق.
خط ۱ باید `۲۸۰` و **«✅ به‌روز»** باشد؛ اگر «⚠️ قدیمی‌تر از آخرین نسخه» دیدید یعنی `VERSION.txt` سرور با `DIAG_LATEST` بسته یکی نیست (نصب درست انجام نشده).
صفحه‌کلید بات هم پس از هر نصب یک‌بار خودکار بازنشر می‌شود (`admin_kb_ver`)، پس دکمه‌های تازه باید دیده شوند.

### ۴٫۳ بازکردن سایت

```bash
curl -fsS https://daastgir.ir/healthz >/dev/null && echo "site OK"
```
**[الگو]** — سپس در مرورگر گوشی `https://daastgir.ir` را باز کنید. اگر ظاهر قدیمی دیدید، یک بار **Ctrl+F5** (یا در موبایل: بستن و بازکردن دوباره) — سرویس‌ورکر با نام کش `bazarche-v280` کش قبلی را خودش دور می‌ریزد.

چند چیز که باید ببینید: صفحهٔ اصلی با فهرست کسب‌وکارها · `/assistant` با سوئیچ «هوش اختصاصی ↔ هوش آفلاین» و تایمر «⏱ حافظهٔ چت» · `/panel/spam` (کنسول ضداسپم) · `/panel/traffic` (ترافیک و سپر).

---

## ۵) عیب‌یابی

### ۵٫۱ `sha256sum -c` نگرفت (FAILED)

```
dastgir-v280.zip: FAILED
sha256sum: WARNING: 1 computed checksum did NOT match
```
یعنی فایل دانلودشده با هش پیام تحویل یکی نیست. سه علت رایج:
1. **دانلود ناقص/صفحهٔ خطا به‌جای زیپ** — بررسی کنید:
   ```bash
   ls -l /tmp/dastgir-v280.zip; file /tmp/dastgir-v280.zip; unzip -t /tmp/dastgir-v280.zip | tail -3
   ```
   **[الگو]** — اگر `file` گفت `HTML document` یا `ASCII text` یعنی لینک صفحهٔ خطا/حذف‌شده داده است، نه زیپ.
2. **هش با فاصلهٔ غلط چسبانده شده** — باید `هش␣␣نام‌فایل` (دو فاصله) باشد.
3. **لینک میزبان موقت منقضی شده** — میزبان‌های آپلود موقت فایل را بعداً حذف می‌کنند. پشتیبان همیشه روی خود سرور است:
   ```bash
   ls -lt /root/*.zip | head -5
   ```
   **[الگو]** — اگر زیپ قبلی آنجا بود، از همان نصب کنید.

**قاعده: تا هش نخوانده، `update.sh` را اجرا نکنید.**

### ۵٫۲ سایت بالا نیامد

به همین ترتیب جلو بروید (همه **[الگو]**):

```bash
systemctl status bazarche --no-pager | head -20
journalctl -u bazarche -n 60 --no-pager
curl -s http://127.0.0.1:8080/healthz; echo
nginx -t && systemctl status nginx --no-pager | head -10
df -h; free -m
```

- **`is-active` = `failed` و در لاگ Traceback** → آخرین خطوط Traceback را بخوانید؛ اگر مربوط به ماژول/کلید است، `deploy/brain.env` یا رازها را چک کنید:
  ```bash
  grep -c '^AI_' /etc/dastgir-secrets.env     # انتظار: 9
  test "$(stat -c '%U:%G:%a' /etc/dastgir-secrets.env)" = 'root:root:600' && echo perms-OK
  ```
- **`healthz` روی ۸۰۸۰ جواب می‌دهد ولی سایت از بیرون باز نمی‌شود** → مشکل از nginx/فایروال است: `nginx -t`، `systemctl restart nginx`، `ufw status` (باید ۲۲/۸۰/۴۴۳ باز باشد).
- **`update.sh` وسط کار مرد** → `trap cleanup` سرویس را برگردانده؛ دوباره از ۴٫۱ چک کنید. اگر نسخه عوض نشده بود، همان فرمان نصب را تکرار کنید.
- **بازگشت کامل (Rollback):**
  ```bash
  ls -t /var/backups/dastgir | head -5
  sudo bash /opt/dastgir/deploy/update.sh /root/dastgir-<نسخهٔ-قبلی>.zip
  ```
  برای داده فقط از بکاپ معتبر و **پس از توقف سرویس** استفاده کنید.

### ۵٫۳ مسیر لاگ سرویس

| چیز | مسیر/فرمان |
|---|---|
| لاگ زندهٔ سرویس سایت | `journalctl -u bazarche -f` |
| ۱۰۰ خط آخر | `journalctl -u bazarche -n 100 --no-pager` |
| از ۱۰ دقیقهٔ پیش | `journalctl -u bazarche --since '-10 minutes' --no-pager` |
| واحد systemd | `/etc/systemd/system/bazarche.service` |
| لاگ پشتیبان شبانه | `/var/log/dastgir-backup.log` |
| پشتیبان‌ها | `/var/backups/dastgir` (`db_تاریخ.db` + `files_تاریخ.tar.gz`، نگهداری ۱۴ روز) |
| کرون کدگارد | `/etc/cron.d/dastgir-codeguard` (هر دقیقه) |
| کرون پشتیبان | `/etc/cron.d/dastgir-backup` (۳ بامداد) |
| رازها | `/etc/dastgir-secrets.env` (`root:root/600` — هرگز چاپش نکنید) |
| چت‌های عمومی سایت | `/opt/dastgir/data/site_chats.log` (JSONL) |
| nginx | `/etc/nginx/sites-available/dastgir` · `nginx -t` · `journalctl -u nginx -n 50` |
| در بات مدیر | «لاگ» و «خطا» و «سیستم» و «وضعیت» و «تشخیص» |

---

## ۶) چک‌لیست پایانی هر به‌روزرسانی

- [ ] `sha256sum -c` → `OK`
- [ ] `update.sh` → `نسخه 280 با موفقیت نصب شد.`
- [ ] `cat /opt/dastgir/VERSION.txt` → نسخهٔ درست
- [ ] `systemctl is-active bazarche` → `active`
- [ ] `curl /healthz` → `ok` (هم ۱۲۷.۰.۰.۱:۸۰۸۰ هم دامنه)
- [ ] «تشخیص» در بات مدیر → ۶ خط سبز، خط نسخه «✅ به‌روز»
- [ ] سایت در مرورگر باز می‌شود؛ `/assistant` و `/panel/spam` دیده می‌شوند
- [ ] `ls -t /var/backups/dastgir | head -3` → بکاپ همین نصب وجود دارد

**هرگز بدون خروجی واقعی نگویید «نصب شد».** اگر مرحله‌ای اجرا نشد، همان را بنویسید.
