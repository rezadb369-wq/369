# 🧮 ماتریس پوشش امنیت/اسپم — وضعیت جاری v280 (پیوست `SECURITY-SPAM-PLAN.md`)

> **روش تولید:** پارس مکانیکی `server/app.py` + بازبینی دستی گروه‌ها. اعداد این سند خروجی واقعی همان پارس روی همین بسته‌اند (نه ادعا).
> **قانون:** هر سطر یا «سیاست» دارد یا «معاف با دلیل». سطر بی‌تصمیم ممنوع — و `tools/test_coverage_guard.py` همین ماتریس را به assert تبدیل می‌کند (خروجی واقعی: `COVERAGE GUARD PASS 34`).

## عدد واقعی اینونتوری

```
POST routes inventoried: 160
  covered by a gate/bucket: 71
  panel (admin-key gated): 85
  EXEMPT with written reason: 4
  UNCOVERED: 0
path conditions total in app.py: 215
```

علامت‌ها: ✔ = پوشش فعال در کد · `POLICY` = سطل کنش در `antispam.POLICY` · **always** = کلید `ratelimit_on` مدیر و کنسول نمی‌توانند خاموشش کنند · G## = شناسهٔ شکاف در برنامهٔ امنیت.

## A) مهمان (عمومی)

| مسیر | وضعیت جاری | تصمیم |
|---|---|---|
| `/login` , `/login/verify` , `/login/password` | با ۴۰۴ بسته (ورود فقط پیام‌رسان) | ✔ قفل `loginlock` + سطل هش‌شدهٔ per-شماره + `logindiv` (defence in depth) |
| `/subscribe` | `sb:6` ✔ | POLICY |
| `/contact` | ریدایرکت به تیکت ✔ | معاف (بدون نوشتن) |
| `/submit` | ۳۰۳ به ویزارد ✔ | معاف |
| `/prices/alert` (فراخوان قیمت) | `pricealert` **always** ✔ | ✔ toggle per-مشتری + dedup ۲۴ساعتهٔ «خبرم کن» با درگاه `stockdup` |
| `/api/check-duplicate` | `checkdup` **always** ✔ | POLICY + پاسخ مبهم (G27) |
| `/offer/<code>` | `offer` **always** ✔ | POLICY always + قفل (G28) |
| ویزارد `/register-business/*` | `regweb` + `regip` + `regsub` ✔ | POLICY per-IP + cooldown هم‌هویت + رویداد hold نام/تلفن/نشانی تقریباً تکراری |
| وب‌هوک بله/سروش/ادمین | `*-hook:180` ✔ | ✔ secret غلط ⇒ strike؛ ۶ ضربه/۱۰دق ⇒ بلاک IP (۴۰۳) |
| `/api/stories/<id>/view` | `view` **always** ✔ | POLICY خواندنی (G14) — تورم بیکن ⇒ deny با پاسخ بی‌صدا |
| `/businesses?q` | `search` **always** ✔ | POLICY خواندنی (G16) |
| `/api/chat/<tid>/msgs` | `msgpoll` **always** ✔ | POLICY خواندنی (G26) |

## B) مشتری (نشست customer)

| مسیر | وضعیت جاری | تصمیم |
|---|---|---|
| چت `POST /me/chat/<tid>` | `chat:customer:60/600` ✔ | POLICY + `content_gate` + سقف ۶۴KB + `bytes_add` روی پیوست |
| `/me/chat/<tid>/notify-me` | `notifyme` **always** ✔ | POLICY (G11) |
| `/api/favorite` , `/api/follow` | `fav`/`follow` 30/600 ✔ | POLICY (G12) |
| `/api/push/subscribe|unsubscribe` | `pushsub`/`pushunsub` 10/600 ✔ | POLICY (G13) |
| تیکت نو `/my/tickets` | `tk:10` + `ticketnew` ✔ | ✔ honeypot + `content_gate` + `spam_flag` |
| پاسخ تیکت `/my/ticket/<id>` | `ticketreply` ✔ | POLICY |
| نظر/پرسش/رأی | `rv/qa/rh/qh` ✔ | ✔ دِدوپ `question_votes` + `content_gate` + `spam_flag` |
| سفارش/نوبت | `ord/bk` ✔ | POLICY (ثبت) |
| `/me/name|profile|notif-settings|logout` | خود-پیکربندی | POLICY سبک (ضد چرخش)؛ `/me/logout` و `/me/profile` در EXEMPT با دلیل |
| لغو سفارش `/me/order/<id>/cancel` | تک‌پرچم ✔ + پین IDOR | POLICY سبک |

## C) دکاندار (نشست owner)

| مسیر | وضعیت جاری | تصمیم |
|---|---|---|
| چرخهٔ کسب‌وکار `/my/business/<id>/*` | `ownerbiz:20/60` ✔ | POLICY |
| **وضعیت سفارش** `/my/order/<id>` | `ordstatus` **always** ✔ | POLICY always (G22) — اعلان به مشتری = تقویت |
| پاسخ/لغو تیکت، moderate نظر/پرسش/نوبت | `omod` 60/600 ✔ | POLICY per-owner |
| `/my/story/add` , آپلود گالری , ذخیرهٔ کالا | `storyadd`/`upload`/`itemsave` ✔ | ✔ عنوان تکراری ⇒ `spam_flag` (نگه‌بررسی، درگاه `itemdup`) + `bytes_add` (G21) |
| `/my/claim` | `claim:5/3600` ✔ | POLICY |
| broadcast fulfill/dismiss | `bcastfd` 30/600 ✔ | POLICY سبک |
| broadcast سفارشی | `bcast:10/3600` ✔ | POLICY |
| `/my/trash/<id>/restore` | پین IDOR ✔ | POLICY سبک |

## D) مدیر `/panel/*` (۸۵ مسیر POST از ۱۶۰)

معاف با دلیل: دسترسی حداکثری مدیر (RULES §۳) + گیت کلید ورود + `panel_allow_ips`. **استثناهای سخت‌سازی** (همه در کد موجودند):
`/panel/backup/import` · `/panel/media/gc` · `/panel/media/delete` · `/panel/demo` · `/panel/trash/*/restore` → سطل سبک always (سناریوی نشست دزدیده‌شده).
`/panel/spam` = UI دیدنی همین ماتریس (کاشی‌های زنده، ویرایش سیاست با حفظ alwaysها، ban/lift، ۵۰ رویداد اخیر).

## E) نقشهٔ تقویت (محرک کاربر → ارسال برون‌سو)

| محرک کاربر | ارسال | سطل جاری | تصمیم |
|---|---|---|---|
| چت/تیکت/نظر/سفارش/نوبت | اعلان مالک (بله/سروش) | ✔ `chat`/`tk`/`rv`/`ord`/`bk` | POLICY |
| stock «خبرم کن» | اعلان مالک | ✔ `notifyme` **always** | POLICY always (G11) |
| وضعیت سفارش (owner) | اعلان مشتری | ✔ `ordstatus` **always** | POLICY always (G22) |
| درخواست لغو > ۳۰ دقیقه | اعلان مالک | تک‌پرچم ✔ | POLICY سبک |
| broadcast مدیر | همه | ✔ `bcast` | معاف مدیر |

## F) انبارهای رشدکننده و هرس — وضعیت جاری

| انبار | هرس | مکانیزم |
|---|---|---|
| `ratelimit` | ✔ ۷ روز + سقف ۵۰٬۰۰۰ ردیف (G24) | `antispam.prune()` از sweep ساعتی |
| `spam_events` | ✔ ۷ روز + `EVENTS_MAX=5000` | هر ۱۰۰ رویداد یک‌بار + `prune()` |
| `spam_bans` | ✔ ۳۰ روز پس از انقضا | `prune()`؛ در بکاپ هست |
| `site_chats.log` | ✔ چرخش (G20) | `assistant.chat_log_prune()` از sweep ساعتی؛ `CHAT_LOG_MAX = 24MB` و نگه‌داشتن نیمهٔ تازه‌تر |
| `ai_threads` | ✔ | `THREAD_TTL=600` + هرس در maintenance |
| otp/sessions/ai_cache | ✔ | هرس در maintenance |
| uploads/chat-files | ✔ GC + سقف بایت روزانه (G21) | `BYTES_DAY = 60MB` per-حساب |
| code-deploys.log / backup index | ✔ ۶۰/۴۰۰ | سقف ذاتی |

## G) شناسهٔ شکاف‌ها — همه بسته

| شناسه | موضوع | وضعیت |
|---|---|---|
| G10 | دِدوپ رأی پرسش | ✔ `question_votes` |
| G11 | اعلان «خبرم کن» بدون سطل | ✔ `notifyme` always |
| G12 | favorite/follow بدون سطل | ✔ `fav`/`follow` |
| G13 | push subscribe/unsubscribe | ✔ `pushsub`/`pushunsub` |
| G14 | بیکن بازدید استوری | ✔ `view` always |
| G16 | scrape جست‌وجو | ✔ `search` always |
| G18 | پاسخ ورود یکسان (ضد enumeration) | ✔ پین با تست |
| G19 | سقف فرم متنی | ✔ ۶۴KB + ۴۱۳ با نام gate |
| G20 | چرخش `site_chats.log` | ✔ `chat_log_prune()` |
| G21 | سقف بایت روزانهٔ آپلود | ✔ `bytes_add` (۶۰MB) |
| G22 | اعلان تغییر وضعیت سفارش | ✔ `ordstatus` always |
| G24 | سقف سطر `ratelimit` | ✔ ۵۰٬۰۰۰ در `prune()` |
| G25 | IDOR سراسری | ✔ `tools/test_idor_v280.py` (تست زندهٔ cross-account) |
| G26 | polling پیام‌ها | ✔ `msgpoll` always |
| G27 | enumeration از `/api/check-duplicate` | ✔ `checkdup` always + پاسخ مبهم |
| G28 | حدس کد `/offer/<code>` | ✔ `offer` always + قفل |

---

## بازتولید این ماتریس

پس از هر تغییر مسیر:
```
python3 tools/build_filemap.py          # docs/FILE-MAP.md
python3 tools/routemap.py -o docs/FILE-MAP.md
python3 tools/test_coverage_guard.py    # باید بدهد: COVERAGE GUARD PASS <n>
```
مسیر نوشتنی تازهٔ بدون سیاست ⇒ `test_coverage_guard.py` قرمز می‌شود.
