# -*- coding: utf-8 -*-
"""v275 — هستهٔ ضداسپم ماندگار (لایهٔ سوم امنیت).

چرا لایهٔ تازه: سپر درخواستی (shield.py) فقط «حجم کل» را می‌بیند و در حافظه است؛
سطل‌های db.rate_ok جزیره‌ای‌اند و تکرارِ متخلف پلهٔ تنبیه ندارد. این ماژول سه چیز
اضافه می‌کند: (۱) سیاست مرکزی per-کنش با نامِ درگاه در پیام خطا (قانون RULES §۱)،
(۲) رویدادنامهٔ ماندگار spam_events + فهرست ban ماندگار spam_bans که ری‌استارت را
زنده می‌ماند و توسط shield هم خوانده می‌شود، (۳) پلهٔ تنبیه (اخطار→بلاک ۱س→۲۴س)
و سقف بایت روزانه per-حساب (abus ظرفیت).

فقط کتابخانهٔ استاندارد. جدول‌ها در SCHEMA db ساخته می‌شوند؛ spam_bans در بکاپ
است و spam_events گذرا (مثل sessions) عمداً بیرون می‌ماند.
"""
import time

import db

# ---------------------------------------------------------------- سیاست مرکزی
# action -> (limit, window_s, always)
# always=True یعنی کلید «ratelimit_on» مدیر آن را خاموش نمی‌کند (دروازه‌های امنیتی
# و مسیرهای اعلان‌ساز/خواندنیِ ضدscrape). بقیه با سوئیچ مدیر احترام می‌بینند.
POLICY = {
    # -- مشتری
    "fav":        (30, 600, False),
    "follow":     (30, 600, False),
    "pushsub":    (10, 600, False),
    "pushunsub":  (10, 600, False),
    "notifyme":   (6, 600, True),    # اعلان برون‌سو به مالک = تقویت
    "ticketreply": (30, 600, False),
    "ticketnew":  (10, 600, False),
    # -- مهمان
    "pricealert": (10, 600, False),  # فراخوان قیمت
    "checkdup":   (20, 600, True),   # ضد enumeration (G27)
    "offer":      (10, 900, True),   # ضد حدس کد (G28)
    # -- خواندنی‌های ضدscrape (هرگز با سوئیچ خاموش نمی‌شوند)
    "view":       (60, 600, True),
    "search":     (60, 600, True),
    "msgpoll":    (120, 600, True),
    # -- دکاندار
    "storyadd":   (10, 600, False),
    "upload":     (30, 600, False),
    "itemsave":   (60, 3600, False),
    "claim":      (5, 3600, False),
    "ordstatus":  (30, 600, True),   # اعلان به مشتری = تقویت (G22)
    "omod":       (60, 600, False),  # moderate نظر/پرسش/نوبت + story delete
    "bcastfd":    (30, 600, False),
}

# پلهٔ تنبیه: این تعداد رد در پنجره => بلاک
STRIKE_LIMIT = 6
STRIKE_WINDOW = 600.0
BAN_T1 = 3600.0        # بار اول: یک ساعت
BAN_T2 = 86400.0       # تکرار در ۲۴ ساعت: یک روز
EVENTS_MAX = 5000
EVENTS_KEEP_DAYS = 7
BYTES_DAY = 60 * 1024 * 1024   # سقف آپلود روزانه per-حساب (G21)

_lock_count = [0]


def _now():
    return time.time()


def event(ident, action, verdict, gate, actor="", detail=""):
    """ثبت رویداد ماندگار؛ هرگز استثنا نمی‌دهد (ضداسپم نباید سایت را بخواباند)."""
    try:
        con = db.connect()
        con.execute("INSERT INTO spam_events(ts,ident,actor,action,verdict,gate,detail)"
                    " VALUES (?,?,?,?,?,?,?)",
                    (_now(), ident, actor, action, verdict, gate, (detail or "")[:120]))
        _lock_count[0] += 1
        if _lock_count[0] % 100 == 0:
            con.execute("DELETE FROM spam_events WHERE ts < ?",
                        (_now() - EVENTS_KEEP_DAYS * 86400,))
            con.execute("DELETE FROM spam_events WHERE id NOT IN "
                        "(SELECT id FROM spam_events ORDER BY id DESC LIMIT ?)",
                        (EVENTS_MAX,))
        con.commit(); con.close()
    except Exception:
        pass


def ban(ident, reason, secs, by="auto"):
    try:
        con = db.connect()
        con.execute("INSERT INTO spam_bans(ident,reason,until,by,created) VALUES(?,?,?,?,?)"
                    " ON CONFLICT(ident) DO UPDATE SET reason=excluded.reason,"
                    " until=excluded.until, by=excluded.by",
                    (ident, reason[:120], _now() + secs, by, _now()))
        con.commit(); con.close()
    except Exception:
        pass


def lift(ident):
    try:
        db._run("DELETE FROM spam_bans WHERE ident=?", (ident,))
        return True
    except Exception:
        return False


def banned(ident):
    """آیا این هویت الان ban ماندگار دارد؟ (shield هم همین را می‌خواند)."""
    try:
        con = db.connect()
        r = con.execute("SELECT until FROM spam_bans WHERE ident=?", (ident,)).fetchone()
        con.close()
        return bool(r and r[0] > _now())
    except Exception:
        return False


def _escalate(con, ident, now):
    n = con.execute("SELECT COUNT(*) c FROM spam_events WHERE ident=? AND verdict='deny'"
                    " AND ts > ?", (ident, now - STRIKE_WINDOW)).fetchone()["c"]
    if n < STRIKE_LIMIT:
        return
    prev = con.execute("SELECT until,created FROM spam_bans WHERE ident=?",
                       (ident,)).fetchone()
    secs = BAN_T1
    if prev and now - prev["created"] < 86400:
        secs = BAN_T2
    con.execute("INSERT INTO spam_bans(ident,reason,until,by,created) VALUES(?,?,?,?,?)"
                " ON CONFLICT(ident) DO UPDATE SET reason=excluded.reason,"
                " until=excluded.until, by=excluded.by",
                (ident, "escalation:%d denies/%ds" % (n, int(STRIKE_WINDOW)),
                 now + secs, "auto", now))
    con.commit()


def _policy(action):
    """v279: سیاست مؤثر = POLICY کد + اورراید زمان‌اجرا از کنسول اسپم.
    پرچم always همیشه از کد می‌آید — کنسول نمی‌تواند سطل امنیتی را
    به سوئیچ‌پذیر تبدیل کند (حفظ alwaysها)."""
    pol = POLICY.get(action)
    if not pol:
        return None
    limit, window, always = pol
    try:
        ov = (db.get_settings().get("spam_pol_" + action) or "").strip()
        if ov:
            a, b = ov.split(":")
            limit, window = int(a), float(b)
    except Exception:
        pass
    return limit, window, always


def policy_set(action, limit, window):
    """ذخیرهٔ اورراید سیاست از کنسول. همیشه‌بودن (always) دست‌نخوردنی است."""
    if action not in POLICY:
        return False, "کنش ناشناخته: %s" % action
    try:
        limit = int(limit); window = float(window)
    except (TypeError, ValueError):
        return False, "عدد نامعتبر"
    if not (0 <= limit <= 100000) or not (60 <= window <= 86400):
        return False, "بازه مجاز: limit ۰..۱۰۰۰۰۰ و window ۶۰..۸۶۴۰۰"
    db.set_setting("spam_pol_" + action, "%d:%d" % (limit, int(window)))
    db.log("spam.policy", f"{action} => {limit}/{int(window)}")
    return True, "سیاست «%s» ذخیره شد." % action


def policy_clear(action):
    if action not in POLICY:
        return False, "کنش ناشناخته"
    db.set_setting("spam_pol_" + action, "")
    db.log("spam.policy", f"{action} => default")
    return True, "سیاست «%s» به پیش‌فرض برگشت." % action


def ban_now(ident, hours, by="admin"):
    try:
        hours = max(1, min(720, int(hours)))
    except (TypeError, ValueError):
        hours = 1
    ban(ident, "manual:%s" % by, hours * 3600.0, by=by)
    db.log("spam.ban", f"{ident} {hours}h by {by}")
    return True


def bans_active():
    try:
        con = db.connect()
        rows = con.execute("SELECT ident, reason, until, by FROM spam_bans"
                           " WHERE until > ? ORDER BY until DESC LIMIT 100",
                           (_now(),)).fetchall()
        con.close()
        out = []
        for r in rows:
            d = dict(r)
            d["left_m"] = int((d["until"] - _now()) / 60)
            out.append(d)
        return out
    except Exception:
        return []


def stats_today():
    """شمار زنده per-کنش از نیمه‌شب + رویدادهای اخیر (کنسول/بات)."""
    try:
        import time as _tm
        now = _now()
        day0 = now - (now % 86400) - _tm.timezone * 0  # UTC midnight; fine for counters
        con = db.connect()
        rows = con.execute("SELECT action, verdict, COUNT(*) c FROM spam_events"
                           " WHERE ts > ? GROUP BY action, verdict", (day0,)).fetchall()
        ev = con.execute("SELECT ts, ident, action, verdict, gate, detail"
                         " FROM spam_events ORDER BY id DESC LIMIT 50").fetchall()
        con.close()
        per = {}
        total = denies = 0
        for r in rows:
            a = per.setdefault(r["action"], {"n": 0, "deny": 0})
            a["n"] += r["c"]; total += r["c"]
            if r["verdict"] == "deny":
                a["deny"] += r["c"]; denies += r["c"]
        return {"per": per, "total": total, "denies": denies,
                "events": [dict(x) for x in ev]}
    except Exception:
        return {"per": {}, "total": 0, "denies": 0, "events": []}


def held_counts():
    """محتوای نگه‌بررسی (spam_flag=1) — برای کاشی‌های کنسول و گزارش بات."""
    out = {}
    try:
        con = db.connect()
        for tbl, key in (("reviews", "reviews"), ("questions", "questions"),
                         ("tickets", "tickets"), ("items", "items")):
            try:
                out[key] = con.execute(
                    "SELECT COUNT(*) c FROM %s WHERE IFNULL(spam_flag,0)=1" % tbl
                ).fetchone()["c"]
            except Exception:
                out[key] = 0
        con.close()
    except Exception:
        pass
    return out


def guard(action, ident, actor=""):
    """دروازهٔ کنش. برمی‌گرداند (ok, gate, retry_s).

    پیامِ لایهٔ بالاتر باید نام gate را به کاربر نشان دهد (قانون صداقت RULES)."""
    now = _now()
    if banned(ident):
        event(ident, action, "ban", "ban", actor)
        return False, "ban", 3600
    pol = _policy(action)
    if not pol:
        # مسیر بدون سیاست = باگ پوشش؛ باز مجاز (سایت نمی‌خوابد) ولی ثبت می‌شود
        event(ident, action, "nopolicy", action, actor)
        return True, action, 0
    limit, window, always = pol
    if not always:
        s = db.get_settings()
        if s.get("ratelimit_on") != "1":
            return True, action, 0
    if limit <= 0:
        ok = False                  # سیاست صفر = رد بی‌قیدوشرط
    else:
        ok = db.rate_ok("as:%s:%s" % (action, ident), limit=limit,
                        window=window, always=True)
    if ok:
        return True, action, 0
    try:
        con = db.connect()
        con.execute("INSERT INTO spam_events(ts,ident,actor,action,verdict,gate,detail)"
                    " VALUES (?,?,?,?,?,?,?)", (now, ident, actor, action, "deny",
                                               action, ""))
        con.commit()
        _escalate(con, ident, now)
        con.close()
    except Exception:
        pass
    return False, action, int(window)


DIV_WINDOW = 600.0          # پنجرهٔ تنوع شماره per-IP
DIV_THRESHOLD = 3           # ≥۳ شمارهٔ متفاوت در پنجره = enumeration


def strike(ident, action, gate, actor=""):
    """رویداد deny صریح (بدون سطل): برای تخلف‌های قطعی مثل secret غلط وب‌هوک.
    پلهٔ تنبیه مثل guard کار می‌کند (۶ deny در ۱۰دق => ban). هرگز استثنا نمی‌دهد."""
    try:
        con = db.connect()
        con.execute("INSERT INTO spam_events(ts,ident,actor,action,verdict,gate,detail)"
                    " VALUES (?,?,?,?,?,?,?)",
                    (_now(), ident, actor, action, "deny", gate, ""))
        con.commit()
        _escalate(con, ident, _now())
        con.close()
    except Exception:
        pass


def enum_check(ident, value, action="logindiv"):
    """تنوع مقدار per-هویت (ضد enumeration ورود): ارزش‌های متمایز در پنجره را
    می‌شمارد؛ از آستانه به بعد هر درخواست یک deny ثبت می‌کند و پله می‌تواند
    هویت را ban کند. درخواست را مستقیم رد نمی‌کند (CGNAT). هرگز استثنا نمی‌دهد.
    برمی‌گرداند تعداد متمایزها."""
    try:
        now = _now()
        con = db.connect()
        con.execute("DELETE FROM spam_divers WHERE ts < ?", (now - DIV_WINDOW,))
        con.execute("INSERT OR IGNORE INTO spam_divers(ident,value,ts)"
                    " VALUES (?,?,?)", (ident, value, now))
        n = con.execute("SELECT COUNT(*) c FROM spam_divers WHERE ident=?",
                        (ident,)).fetchone()["c"]
        if n >= DIV_THRESHOLD:
            con.execute("INSERT INTO spam_events(ts,ident,actor,action,verdict,gate,detail)"
                        " VALUES (?,?,?,?,?,?,?)",
                        (now, ident, "", action, "deny", action,
                         "distinct:%d" % n))
            con.commit()
            _escalate(con, ident, now)
        con.commit(); con.close()
        return n
    except Exception:
        return 0


def bytes_add(actor, n):
    """سقف حجم روزانهٔ آپلود per-حساب (G21). True یعنی مجاز."""
    if not actor:
        return True
    now = _now()
    day0 = now - (now % 86400)
    try:
        con = db.connect()
        r = con.execute("SELECT n, window FROM ratelimit WHERE bucket=?",
                        ("bytes:%s" % actor,)).fetchone()
        used = int(r["n"]) if r and r["window"] >= day0 else 0
        if used + n > BYTES_DAY:
            con.close()
            event("acct:%s" % actor, "bytes", "deny", "bytes", actor, str(n))
            return False
        con.execute("INSERT INTO ratelimit(bucket,n,window) VALUES(?,?,?) "
                    "ON CONFLICT(bucket) DO UPDATE SET n=n+?, window=excluded.window",
                    ("bytes:%s" % actor, n, now, n))
        con.commit(); con.close()
        return True
    except Exception:
        return True


def prune():
    """هرس دوره‌ای — از sweep ساعتی app صدا زده می‌شود (G20/G24)."""
    try:
        con = db.connect()
        con.execute("DELETE FROM spam_events WHERE ts < ?",
                    (_now() - EVENTS_KEEP_DAYS * 86400,))
        con.execute("DELETE FROM spam_events WHERE id NOT IN "
                    "(SELECT id FROM spam_events ORDER BY id DESC LIMIT ?)",
                    (EVENTS_MAX,))
        con.execute("DELETE FROM spam_bans WHERE until < ? AND until != 0",
                    (_now() - 30 * 86400,))
        con.execute("DELETE FROM ratelimit WHERE window < ?", (_now() - 7 * 86400,))
        nr = con.execute("SELECT COUNT(*) c FROM ratelimit").fetchone()["c"]
        if nr > 50000:
            con.execute("DELETE FROM ratelimit WHERE bucket NOT IN "
                        "(SELECT bucket FROM ratelimit ORDER BY window DESC LIMIT 50000)")
        con.commit(); con.close()
    except Exception:
        pass


def report():
    """خلاصه برای کنسول فاز ۵ (الان هم قابل استفاده)."""
    try:
        con = db.connect()
        day0 = _now() - 86400
        rows = con.execute("SELECT action, verdict, COUNT(*) c FROM spam_events"
                           " WHERE ts > ? GROUP BY action, verdict"
                           " ORDER BY c DESC LIMIT 40", (day0,)).fetchall()
        bans = con.execute("SELECT ident, reason, until, by FROM spam_bans"
                           " ORDER BY created DESC LIMIT 50").fetchall()
        con.close()
        return {"actions": [dict(r) for r in rows],
                "bans": [dict(b) for b in bans]}
    except Exception:
        return {"actions": [], "bans": []}

# ================= v276 — هوش محتوایی (فاز ۲ امنیت) =================
import hashlib as _hl
import re as _re

_LINK_RX = _re.compile(r"https?://|www\.|t\.me/|telegram\.me/", _re.I)
_INVIS_RX = _re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f‏‏‎‎‪-‮⁦-⁩]")
_NORM_RX = _re.compile(r"\s+")


def _norm_text(t):
    t = (t or "").lower().replace("ي", "ی").replace("ك", "ک") \
        .replace("‌", "").replace("‍", "")
    return _NORM_RX.sub(" ", t).strip()


def content_score(text):
    """پرچم‌های محتوایی. برمی‌گرداند (flags, reasons)."""
    flags = 0
    reasons = []
    t = text or ""
    links = len(_LINK_RX.findall(t))
    if links >= 3:
        flags += 2; reasons.append("links:%d" % links)
    inv = len(_INVIS_RX.findall(t))
    if inv >= 3:
        flags += 2; reasons.append("invisible:%d" % inv)
    if len(t) > 4000:
        flags += 1; reasons.append("long")
    return flags, reasons


def content_gate(action, ident, text):
    """verdict سه‌حالته برای محتوای ارسالی: ok | hold | reject.

    تکرار سراسری همان متن: ۳ بار در ۱۰ دقیقه = hold، ۵ بار = reject (سیل
    یک‌متنی). پرچم محتوایی >=۲ = hold. هرگز استثنا نمی‌دهد.
    """
    try:
        norm = _norm_text(text)
        h = _hl.sha1(norm.encode("utf-8")).hexdigest()[:16] if norm else ""
        now = _now()
        con = db.connect()
        dup = 0
        if h:
            dup = con.execute("SELECT COUNT(*) c FROM spam_events WHERE detail=? "
                              "AND verdict='text' AND ts > ?",
                              (h, now - 600)).fetchone()["c"]
        con.execute("INSERT INTO spam_events(ts,ident,actor,action,verdict,gate,detail)"
                    " VALUES (?,?,?,?,?,?,?)", (now, ident, "", action, "text",
                                               action, h or "-"))
        con.commit(); con.close()
        flags, reasons = content_score(text)
        if dup >= 4 or flags >= 4:
            event(ident, action, "reject", action, "", reasons[0] if reasons else "dup")
            return "reject", action
        if dup >= 2 or flags >= 2:
            event(ident, action, "hold", action, "", reasons[0] if reasons else "dup")
            return "hold", action
        return "ok", action
    except Exception:
        return "ok", action
