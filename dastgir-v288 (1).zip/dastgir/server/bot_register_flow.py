# -*- coding: utf-8 -*-
"""v207 — conversational layer of staged business registration (shared by
Bale and Soroush).  All state decisions are delegated to bot_register; this
module only renders prompts and maps allow-listed callbacks to core calls.

Callback namespace stays `dg198:` (stable since v198); actions are `reg_*`
and every callback_data is kept under 64 bytes.
"""
import re
import db
import bot_register as R

SITE = "https://daastgir.ir"
P = "dg198:"           # imported by bot_menu as the same CALLBACK_PREFIX
RATE_LIMIT = (40, 60)  # per platform user per minute; a full 9-step flow with retries is ~25 events

_CB_RE = re.compile(
    r"reg_(start|resume|cancel|cancel_yes|back|skip|imgdone|preview|confirm|"
    r"cat:[a-z0-9_-]{2,40}|catq|phone:(pub|prv)|hours:(allday|split|weekdays|skip)|"
    r"yes:[A-Za-z0-9_-]{8,24})")


def matches(action):
    return bool(_CB_RE.fullmatch(action or ""))


# ------------------------------------------------------------------ keyboards
def _kb(rows):
    return {"inline_keyboard": rows}


def _nav(back=True, skip=False, cancel=True):
    row = []
    if back:
        row.append({"text": "⬅️ مرحلهٔ قبل", "callback_data": P + "reg_back"})
    if skip:
        row.append({"text": "⏭ رد کردن", "callback_data": P + "reg_skip"})
    if cancel:
        row.append({"text": "✖️ انصراف", "callback_data": P + "reg_cancel"})
    return row


def _menu_btn():
    return [{"text": "🏠 منوی اصلی", "callback_data": P + "menu"}]


# ------------------------------------------------------------------ account
def _customer(platform, platform_user_id):
    acc = db.messenger_account_by_platform(platform, platform_user_id)
    if not acc or acc.get("customer_status") == "blocked":
        return None
    return db.customer_by_id(acc["customer_id"])


def _masked(phone):
    p = db.norm_phone(phone or "")
    return p[:4] + "••••" + p[-3:] if len(p) == 11 else "ثبت نشده"


def _allowed(platform, platform_user_id, chat_id, send):
    if db.rate_ok(f"bot-reg:{platform}:{platform_user_id}", limit=RATE_LIMIT[0],
                  window=RATE_LIMIT[1], always=True):
        return True
    send(chat_id, "درخواست‌های ثبت زیاد است؛ یک دقیقه بعد ادامه دهید.")
    return False


# ------------------------------------------------------------------ prompts
def prompt(platform, customer, chat_id, send, note=""):
    """Render the prompt for the draft's CURRENT step (server-decided)."""
    d = R.get(customer["id"])
    head = (note + "\n\n") if note else ""
    if not d:
        return send(chat_id, head + "پیش‌نویسی فعال نیست. برای شروع «ثبت کسب‌وکار» را بزنید.",
                    _kb([[{"text": "🏪 ثبت کسب‌وکار", "callback_data": P + "reg_start"}], _menu_btn()]))
    step, x = d["step"], d["data"]
    if step == "category":
        cats = R.search_categories("")
        rows = [[{"text": c["name"], "callback_data": P + "reg_cat:" + c["slug"]}] for c in cats]
        rows.append(_nav(back=False))
        return send(chat_id, head + "🏪 ثبت کسب‌وکار — مرحلهٔ ۱ از ۹\n\nدستهٔ کسب‌وکار را انتخاب کنید یا نام دسته را تایپ کنید تا جست‌وجو شود.",
                    _kb(rows))
    if step == "name":
        return send(chat_id, head + f"مرحلهٔ ۲ از ۹ — دسته: {x.get('cat_name','')}\n\nنام کسب‌وکار را بنویسید (۲ تا ۶۰ نویسه، بدون لینک و شماره).",
                    _kb([_nav()]))
    if step == "city":
        return send(chat_id, head + "مرحلهٔ ۳ از ۹\n\nشهر را بنویسید (مثلاً نجف‌آباد).", _kb([_nav()]))
    if step == "area":
        return send(chat_id, head + "مرحلهٔ ۴ از ۹\n\nمحله را بنویسید یا رد کنید.", _kb([_nav(skip=True)]))
    if step == "address":
        return send(chat_id, head + "مرحلهٔ ۵ از ۹\n\nنشانی دقیق را بنویسید (۵ تا ۱۶۰ نویسه).", _kb([_nav()]))
    if step == "descr":
        return send(chat_id, head + "مرحلهٔ ۶ از ۹\n\nتوضیح کوتاه (تا ۳۰۰ نویسه، بدون لینک) بنویسید یا رد کنید.", _kb([_nav(skip=True)]))
    if step == "phone_public":
        return send(chat_id, head + f"مرحلهٔ ۷ از ۹\n\nشمارهٔ تماس کسب‌وکار همان شمارهٔ تأییدشدهٔ حساب شماست: {_masked(customer.get('phone'))}\n"
                    "این شماره قابل تغییر از بات نیست. آیا در صفحهٔ عمومی نمایش داده شود؟",
                    _kb([[{"text": "✅ بله، نمایش عمومی", "callback_data": P + "reg_phone:pub"},
                          {"text": "🔒 خیر، فقط سایت/مدیر", "callback_data": P + "reg_phone:prv"}], _nav()]))
    if step == "hours":
        rows = [[{"text": label, "callback_data": P + "reg_hours:" + key}] for key, (label, _) in R.HOURS_PRESETS.items()]
        rows.append(_nav())
        return send(chat_id, head + "مرحلهٔ ۸ از ۹\n\nساعات کاری را انتخاب کنید (ویرایش دقیق روزانه در سایت ممکن است).", _kb(rows))
    if step == "images":
        n = len(x.get("images") or [])
        return send(chat_id, head + f"مرحلهٔ ۹ از ۹ — تصاویر ({n} از {R.MAX_IMAGES})\n\n"
                    "لوگو یا عکس کسب‌وکار را به‌صورت «عکس» بفرستید (JPEG/PNG/WebP، حداکثر ۳ مگابایت). "
                    "گالری کامل بعداً در سایت قابل مدیریت است.",
                    _kb([[{"text": "✅ تصاویر کافی است", "callback_data": P + "reg_imgdone"}], _nav(skip=True)]))
    if step == "preview":
        return send(chat_id, head + R.preview_text(customer["id"], _masked(customer.get("phone"))),
                    _kb([[{"text": "✅ تأیید و ارسال برای بررسی", "callback_data": P + "reg_confirm"}],
                         _nav()]))
    return send(chat_id, "وضعیت نامشخص؛ دوباره شروع کنید.", _kb([_menu_btn()]))


# ------------------------------------------------------------------ entry points
def start(platform, platform_user_id, chat_id, send):
    customer = _customer(platform, platform_user_id)
    if not customer:
        return send(chat_id, "برای ثبت کسب‌وکار ابتدا از سایت وارد یا ثبت‌نام کنید.",
                    _kb([[{"text": "🔐 ورود یا ثبت‌نام", "url": SITE + "/login"}]]))
    if not _allowed(platform, platform_user_id, chat_id, send):
        return True
    if db.get_settings().get("reg_open") != "1":
        return send(chat_id, "ثبت کسب‌وکار جدید موقتاً بسته است.", _kb([_menu_btn()]))
    existing = R.get(customer["id"])
    if existing and (existing["step"] != "category" or existing["data"]):
        return send(chat_id, "یک پیش‌نویس ناتمام دارید. ادامه می‌دهید یا از نو شروع می‌کنید؟",
                    _kb([[{"text": "▶️ ادامهٔ پیش‌نویس", "callback_data": P + "reg_resume"},
                          {"text": "🗑 شروع از نو", "callback_data": P + "reg_cancel"}], _menu_btn()]))
    R.start(customer["id"], platform)
    return prompt(platform, customer, chat_id, send)


def handle_text(platform, platform_user_id, chat_id, text, send):
    """Consume free text ONLY when a draft is active and its step takes text.
    Returns True when consumed."""
    customer = _customer(platform, platform_user_id)
    if not customer:
        return False
    d = R.get(customer["id"])
    if not d:
        return False
    if not _allowed(platform, platform_user_id, chat_id, send):
        return True
    step = d["step"]
    if step == "category":
        hits = R.search_categories(text)
        if not hits:
            prompt(platform, customer, chat_id, send, "دسته‌ای با این نام پیدا نشد؛ از فهرست انتخاب کنید یا واژهٔ دیگری بنویسید.")
            return True
        rows = [[{"text": c["name"], "callback_data": P + "reg_cat:" + c["slug"]}] for c in hits]
        rows.append(_nav(back=False))
        send(chat_id, "نتایج جست‌وجوی دسته:", _kb(rows))
        return True
    if step in R.LIMITS:
        ok, err = R.set_text(customer["id"], text)
        prompt(platform, customer, chat_id, send, "" if ok else "⚠️ " + err)
        return True
    prompt(platform, customer, chat_id, send, "در این مرحله از دکمه‌ها استفاده کنید.")
    return True


def handle_photo(platform, platform_user_id, chat_id, fetch_bytes, send):
    """`fetch_bytes()` downloads the largest photo via the platform's getFile.
    Only invoked while the draft is at the images step."""
    customer = _customer(platform, platform_user_id)
    if not customer:
        return False
    d = R.get(customer["id"])
    if not d or d["step"] != "images":
        return False
    if not _allowed(platform, platform_user_id, chat_id, send):
        return True
    data = fetch_bytes()
    if not data:
        prompt(platform, customer, chat_id, send, "⚠️ دریافت تصویر از پیام‌رسان ناموفق بود؛ دوباره بفرستید.")
        return True
    ok, err, n = R.add_image(customer["id"], data)
    prompt(platform, customer, chat_id, send, ("✅ تصویر ذخیره شد." if ok else "⚠️ " + err))
    return True


def handle_callback(platform, platform_user_id, chat_id, action, send):
    if not matches(action):
        return False
    customer = _customer(platform, platform_user_id)
    if not customer:
        send(chat_id, "برای ثبت کسب‌وکار ابتدا از سایت وارد شوید.", _kb([[{"text": "🔐 ورود", "url": SITE + "/login"}]]))
        return True
    if not _allowed(platform, platform_user_id, chat_id, send):
        return True
    cid = customer["id"]
    if action == "reg_start":
        return start(platform, platform_user_id, chat_id, send)
    if action == "reg_resume":
        return prompt(platform, customer, chat_id, send)
    if action == "reg_cancel":
        if not R.get(cid):
            return prompt(platform, customer, chat_id, send)
        return send(chat_id, "پیش‌نویس ثبت کسب‌وکار حذف شود؟ این کار برگشت‌پذیر نیست.",
                    _kb([[{"text": "🗑 بله، حذف شود", "callback_data": P + "reg_cancel_yes"},
                          {"text": "↩️ خیر، ادامه", "callback_data": P + "reg_resume"}]]))
    if action == "reg_cancel_yes":
        R.cancel(cid)
        return send(chat_id, "پیش‌نویس حذف شد.", _kb([[{"text": "🏪 ثبت کسب‌وکار جدید", "callback_data": P + "reg_start"}], _menu_btn()]))
    if action == "reg_back":
        R.go_back(cid); return prompt(platform, customer, chat_id, send)
    if action == "reg_skip":
        R.skip_optional(cid) or (R.get(cid) and R.get(cid)["step"] == "images" and R.finish_images(cid))
        return prompt(platform, customer, chat_id, send)
    if action == "reg_imgdone":
        R.finish_images(cid); return prompt(platform, customer, chat_id, send)
    if action.startswith("reg_cat:"):
        ok, err = R.set_category(cid, action.split(":", 1)[1])
        return prompt(platform, customer, chat_id, send, "" if ok else "⚠️ " + err)
    if action.startswith("reg_phone:"):
        R.set_phone_public(cid, action.endswith(":pub")); return prompt(platform, customer, chat_id, send)
    if action.startswith("reg_hours:"):
        R.set_hours(cid, action.split(":", 1)[1]); return prompt(platform, customer, chat_id, send)
    if action == "reg_preview":
        return prompt(platform, customer, chat_id, send)
    if action == "reg_confirm":
        token = R.prepare_confirm(cid)
        if not token:
            return prompt(platform, customer, chat_id, send, "⚠️ پیش‌نویس کامل نیست.")
        return send(chat_id, "تأیید نهایی: اطلاعات بالا برای بررسی مدیر ارسال شود؟ (این دکمه ۵ دقیقه معتبر و یک‌بارمصرف است)",
                    _kb([[{"text": "✅ بله، ارسال شود", "callback_data": P + "reg_yes:" + token}],
                         [{"text": "↩️ بازگشت به پیش‌نمایش", "callback_data": P + "reg_preview"}]]))
    if action.startswith("reg_yes:"):
        bid, err = R.submit(cid, action.split(":", 1)[1], customer.get("phone"))
        if not bid:
            return prompt(platform, customer, chat_id, send, "⚠️ " + (err or "ثبت انجام نشد."))
        # v278: رویداد hold برای نام/تلفن/نشانی تقریباً تکراری (پنل تصمیم می‌گیرد)
        try:
            _b = db.business(bid=bid) or {}
            _dups = db.find_duplicates(name=_b.get("name") or "",
                                       phone=customer.get("phone") or "",
                                       address=_b.get("address") or "", exclude_id=bid)
            if _dups:
                import antispam
                antispam.event("c%d" % cid, "regweb", "hold", "neardup",
                               "c%d" % cid, "n%d" % len(_dups))
        except Exception:
            pass
        try:
            import sms
            sms.notify_owner(db.get_settings(), "کسب‌وکار جدید از بات ثبت شد و در انتظار تأیید شماست.")
        except Exception:
            pass
        db.notify(cid, "news", "✅ درخواست ثبت کسب‌وکار شما دریافت شد و پس از بررسی مدیر منتشر می‌شود.", "/my/businesses")
        return send(chat_id, "✅ ثبت شد و در انتظار بررسی مدیر است. پس از تأیید، در سایت منتشر می‌شود و از همان‌جا می‌توانید گالری و جزئیات را کامل کنید.",
                    _kb([[{"text": "🌐 کسب‌وکارهای من", "url": SITE + "/my/businesses"}], _menu_btn()]))
    return prompt(platform, customer, chat_id, send)
