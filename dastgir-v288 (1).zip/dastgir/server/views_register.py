# -*- coding: utf-8 -*-
"""v208 — staged business registration on the site (`/register-business/…`).

Same server-side draft/state machine as the bots (`bot_register`), rendered
as a seven-page wizard.  Design rules:
  • every page is a plain HTML form that works with JavaScript off; JS only
    enhances (category search, live duplicate hints, map pin, image picker);
  • the server decides which page may be opened (no page beyond the first
    incomplete one), and re-validates every field on every POST;
  • the applicant must be signed in — the business phone is the verified
    account phone and cannot be typed;
  • the last page shows the business card exactly as it will be published,
    then a one-use hash-only confirmation creates the row as `pending`.
"""
import json

import db
import bot_register as R
from ui import (icon, esc, page, fa, empty_state, flash, cat_options, json_embed, biz_card, cat_icon)

BASE = "/register-business"
DAYS = [("sat", "شنبه"), ("sun", "یک‌شنبه"), ("mon", "دوشنبه"), ("tue", "سه‌شنبه"),
        ("wed", "چهارشنبه"), ("thu", "پنج‌شنبه"), ("fri", "جمعه")]
STEP_META = [
    ("category", "دسته", "store"),
    ("identity", "معرفی", "edit"),
    ("location", "مکان", "map"),
    ("contact", "تماس", "phone"),
    ("hours", "ساعت کاری", "clock"),
    ("images", "تصاویر", "image"),
    ("preview", "پیش‌نمایش", "check-circle"),
]
STEP_INDEX = {k: i for i, (k, _, _) in enumerate(STEP_META)}
STEP_HINT = {
    "category": "شغلتان را انتخاب کنید تا مشتری‌ها در دستهٔ درست پیدایتان کنند.",
    "identity": "نام و یک معرفی کوتاه — همان چیزی که در کارت شما دیده می‌شود.",
    "location": "شهر و نشانی؛ اگر روی نقشه هم علامت بزنید، «نزدیک من» شما را نشان می‌دهد.",
    "contact": "شماره از حساب تأییدشدهٔ شماست؛ راه‌های تماس دیگر اختیاری است.",
    "hours": "یک گزینهٔ سریع بزنید یا ساعت هر روز را جداگانه تنظیم کنید.",
    "images": "چند عکس خوب، اعتماد مشتری را چند برابر می‌کند. اولین عکس، کاور می‌شود.",
    "preview": "همه‌چیز را یک‌بار دیگر ببینید و برای بررسی بفرستید.",
}
JS = ('<script type="module" src="/assets/js/catpicker.js?v109"></script>'
      '<script type="module" src="/assets/js/dupcheck.js?v155"></script>'
      '<script type="module" src="/assets/js/mappage.js?v216"></script>'
      '<script type="module" src="/assets/js/imagefield.js?v109"></script>'
      '<script type="module" src="/assets/js/regwizard.js?v212"></script>')


def _masked(phone):
    p = db.norm_phone(phone or "")
    return p[:4] + "•••" + p[-4:] if len(p) == 11 else "—"


def _stepper(current, reached):
    n = len(STEP_META)
    items = ""
    for i, (key, label, ic) in enumerate(STEP_META):
        state = "is-done" if i < reached and key != current else ("is-current" if key == current else "")
        link = i <= reached
        inner = (f'<span class="rw-dot">{icon("check") if state == "is-done" else fa(i + 1)}</span>'
                 f'<span class="rw-lbl">{label}</span>')
        items += (f'<a class="rw-step {state}" href="{BASE}/{key}" aria-current="{"step" if key == current else "false"}">{inner}</a>'
                  if link else f'<span class="rw-step is-locked">{inner}</span>')
    pct = int(round(100 * STEP_INDEX[current] / (n - 1)))
    return (f'<nav class="rw-stepper" aria-label="مراحل ثبت" style="--rw-pct:{pct}%">'
            f'<div class="rw-track"><span class="rw-fill"></span></div><div class="rw-steps">{items}</div></nav>')


def _summary(x, me):
    """Desktop side rail: what has been captured so far — a live receipt."""
    rows = [("store", "دسته", x.get("cat_name")), ("edit", "نام", x.get("name")),
            ("map", "شهر", " · ".join(v for v in (x.get("city"), x.get("area")) if v)),
            ("phone", "تلفن", "نمایش عمومی" if x.get("phone_public", True) else "خصوصی"),
            ("clock", "ساعت", x.get("hours_label")), ("image", "تصاویر", f"{fa(len(x.get('images') or []))} عدد" if x.get("images") else "")]
    li = "".join(f'<li class="{"is-set" if v else ""}">{icon(ic)}<span>{esc(k)}</span><b>{esc(str(v)) if v else "—"}</b></li>'
                 for ic, k, v in rows)
    return f'<aside class="rw-side"><p class="rw-side-title">{icon("sparkles")} خلاصهٔ ثبت</p><ul class="rw-summary">{li}</ul></aside>'


def _shell(s, me, current, body, msg="", title=None, extra_js=JS):
    d = R.get(me["cust_id"])
    x = d["data"] if d else {}
    reached = R.web_reached(x) if d else 0
    n, total = STEP_INDEX[current] + 1, len(STEP_META)
    key, label, ic = STEP_META[STEP_INDEX[current]]
    ring = int(round(100 * n / total))
    head = (f'<header class="rw-hero"><div class="rw-ring" style="--p:{ring}" role="img" aria-label="مرحلهٔ {fa(n)} از {fa(total)}">'
            f'<span>{icon(ic)}</span></div><div><p class="eyebrow">ثبت کسب‌وکار · مرحلهٔ {fa(n)} از {fa(total)}</p>'
            f'<h1 class="page-title">{esc(title or label)}</h1><p class="rw-sub">{esc(STEP_HINT.get(key, ""))}</p></div></header>')
    cancel = (f'<form method="post" action="{BASE}/cancel" class="rw-cancel" data-confirm="پیش‌نویس ثبت حذف شود؟ این کار برگشت‌پذیر نیست.">'
              f'<button class="btn btn-ghost btn-sm" type="submit">{icon("trash")}<span>انصراف و حذف پیش‌نویس</span></button></form>') if d else ""
    html = (f'<div class="container-wide"><section class="section rw">{head}{_stepper(current, reached)}{msg}'
            f'<div class="rw-layout"><div class="card rw-card">{body}</div>{_summary(x, me)}</div>{cancel}'
            f'<p class="rw-foot text-xs text-muted">{icon("lock")} پیش‌نویس شما تا ۴۸ ساعت پس از آخرین تغییر روی سرور ذخیره می‌ماند و از بات‌های بله/سروش هم قابل ادامه است.</p>'
            f'</section></div>')
    return page(s, "ثبت کسب‌وکار", html, "", extra_js=extra_js, cats=db.category_tree())


def _nav(prev_key=None, next_label="ادامه", skip=False):
    left = (f'<a class="btn btn-glass" href="{BASE}/{prev_key}">{icon("chevron-right")}<span>مرحلهٔ قبل</span></a>'
            if prev_key else "<span></span>")
    sk = f'<button class="btn btn-ghost" type="submit" name="skip" value="1">رد کردن</button>' if skip else ""
    return (f'<div class="rw-nav">{left}<div class="cluster">{sk}'
            f'<button class="btn btn-primary btn-lg rw-next" type="submit"><span>{esc(next_label)}</span>{icon("arrow-left")}</button></div></div>')


def _err(errors):
    if not errors:
        return ""
    items = "".join(f"<li>{esc(e)}</li>" for e in errors)
    return f'<div class="alert alert-error mb-md" role="alert">{icon("alert")}<ul class="rw-errs">{items}</ul></div>'


# ------------------------------------------------------------------ gates
def closed(s):
    body = f'''<div class="container-wide"><section class="section">
      {empty_state("lock", "ثبت‌نام موقتاً بسته است",
                   "در حال حاضر امکان ثبت کسب‌وکار جدید وجود ندارد. لطفاً بعداً مراجعه کنید.")}
    </section></div>'''
    return page(s, "ثبت کسب‌وکار", body, "", cats=db.category_tree())


def intro(s, token=""):
    """Landing for guests: what the wizard asks, then sign in."""
    steps = "".join(f'<li>{icon(ic)}<span>{esc(label)}</span></li>' for _, label, ic in STEP_META)
    body = f'''<div class="container-wide"><section class="section rw">
      <header class="rw-head"><p class="eyebrow">رایگان · ۷ مرحلهٔ کوتاه</p>
        <h1 class="page-title">ثبت کسب‌وکار در دست گیر</h1>
        <p class="lead">اطلاعات را مرحله‌به‌مرحله وارد می‌کنید؛ هر مرحله همان لحظه ذخیره می‌شود و می‌توانید بعداً ادامه دهید.</p></header>
      <div class="card rw-card">
        <ol class="rw-intro">{steps}</ol>
        <div class="alert alert-info mt-md">{icon("shield")}<span>شمارهٔ تماس کسب‌وکار همان شمارهٔ تأییدشدهٔ حساب شماست؛ برای همین ابتدا وارد شوید. پس از ثبت، مدیر بررسی می‌کند و سپس صفحهٔ شما منتشر می‌شود.</span></div>
        <div class="cluster mt-lg">
          <a class="btn btn-primary btn-lg" href="/login?next={BASE}">{icon("user")}<span>ورود و شروع ثبت</span></a>
          <a class="btn btn-glass" href="/rules">{icon("book")}<span>قوانین</span></a>
        </div>
      </div></section></div>'''
    return page(s, "ثبت کسب‌وکار", body, "", token=token, cats=db.category_tree())


def resume(s, me, d):
    """A live draft exists: continue or start over (explicit choice)."""
    x = d["data"]; step = R.web_step_for(x)
    body = f'''<h2 class="card-title">{icon("refresh")} یک ثبت ناتمام دارید</h2>
      <p class="text-muted">{esc(x.get("name") or "بدون نام")} · {esc(x.get("cat_name") or "بدون دسته")} — آخرین مرحله: <b>{esc(STEP_META[STEP_INDEX[step]][1])}</b></p>
      <div class="cluster mt-lg">
        <a class="btn btn-primary btn-lg" href="{BASE}/{step}">{icon("chevron-left")}<span>ادامهٔ ثبت</span></a>
        <form method="post" action="{BASE}/cancel" data-confirm="پیش‌نویس فعلی حذف و ثبت جدید شروع شود؟"><input type="hidden" name="restart" value="1">
          <button class="btn btn-glass" type="submit">{icon("plus")}<span>شروع از نو</span></button></form>
      </div>'''
    return _shell(s, me, step, body, title="ادامه یا شروع دوباره", extra_js="")


# ------------------------------------------------------------------ pages
def step_category(s, me, d, errors=None, q=""):
    x = d["data"]
    tree = db.category_tree()
    sel = x.get("cat_slug", "")
    opts = cat_options(tree, selected=sel)
    groups = ""
    for c in tree:
        kids = c.get("children") or []
        if not kids and not c.get("active"):
            continue
        chips = "".join(f'<button class="rw-chip{" is-on" if k["slug"] == sel else ""}" type="button" data-cat="{esc(k["slug"])}" data-name="{esc(k["name"])}">{esc(k["name"])}</button>'
                        for k in kids if k.get("active", 1)) if kids else \
                f'<button class="rw-chip{" is-on" if c["slug"] == sel else ""}" type="button" data-cat="{esc(c["slug"])}" data-name="{esc(c["name"])}">{esc(c["name"])}</button>'
        on = sel and (sel == c["slug"] or any(k["slug"] == sel for k in kids))
        groups += f'''<details class="rw-group{" is-on" if on else ""}"{" open" if on else ""} data-group>
          <summary>{cat_icon(c.get("icon") or "store", 56)}<span class="rw-group-name">{esc(c["name"])}</span>
            <small>{esc(c.get("blurb") or "")}</small>{icon("chevron-down")}</summary>
          <div class="rw-chips">{chips}</div></details>'''
    cur_name = esc(x.get("cat_name") or "")
    body = f'''{_err(errors)}
    <form method="post" action="{BASE}/category" data-validate data-catgrid>
      <label class="rw-search"><span class="sr-only">جست‌وجوی شغل</span>{icon("search")}
        <input type="search" placeholder="شغلتان را بنویسید — مثلاً نانوایی، قالیشویی…" autocomplete="off" data-cat-search></label>
      <div class="rw-picked{" is-on" if sel else ""}" data-cat-picked aria-live="polite">{icon("check-circle")}<span>انتخاب شما: <b data-cat-picked-name>{cur_name}</b></span></div>
      <div class="rw-groups" data-groups>{groups}</div>
      <p class="rw-empty text-muted" data-cat-empty hidden>چیزی پیدا نشد؛ نزدیک‌ترین دسته را بزنید — بعداً از پنل قابل تغییر است.</p>
      <div class="rw-native-wrap">
        <label class="field-label" for="rw-cat">انتخاب از فهرست کامل</label>
        <select class="select rw-native" id="rw-cat" name="cat_slug">
          <option value="">انتخاب کنید…</option>{opts}</select></div>
      <noscript><style>.rw-native-wrap{{display:block!important}}.rw-search,.rw-groups{{display:none!important}}</style></noscript>
      {_nav(None)}
    </form>'''
    return _shell(s, me, "category", body)


def step_identity(s, me, d, errors=None, form=None):
    x = d["data"]
    g = lambda k, default="": esc((form or {}).get(k, [x.get(k, default)])[0] if form else x.get(k, default) or "")
    body = f'''{_err(errors)}
    <form method="post" action="{BASE}/identity" data-validate data-dupcheck>
      <div class="field"><label class="field-label" for="rw-name">نام کسب‌وکار<span class="req">*</span></label>
        <input class="input" id="rw-name" name="name" required minlength="2" maxlength="80" value="{g('name')}" data-dup="name" autocomplete="organization">
        <div class="dup-hint" data-dup-for="name" hidden></div>
        <p class="field-hint">بدون شماره تلفن و لینک؛ اگر نام تکراری بود با نام محله دقیق‌ترش کنید.</p></div>
      <div class="field"><label class="field-label" for="rw-descr">توضیح کوتاه</label>
        <textarea class="textarea" id="rw-descr" name="descr" maxlength="2000" rows="5" placeholder="چه می‌فروشید یا چه خدمتی می‌دهید؟ چه چیزی شما را متمایز می‌کند؟">{g('descr')}</textarea>
        <p class="field-hint">تا {fa(2000)} نویسه؛ لینک مجاز نیست.</p></div>
      <div class="field"><label class="field-label" for="rw-tags">برچسب‌ها</label>
        <input class="input" id="rw-tags" name="tags" maxlength="200" value="{g('tags')}" placeholder="با ویرگول جدا کنید؛ مثال: کباب کوبیده، بیرون‌بر، پارکینگ"></div>
      {_nav("category")}
    </form>'''
    return _shell(s, me, "identity", body)


def step_location(s, me, d, errors=None, form=None):
    x = d["data"]
    g = lambda k, default="": esc((form or {}).get(k, [x.get(k, default)])[0] if form else (x.get(k, default) or ""))
    provs = db.provinces()
    prov_opts = "".join(f'<option value="{esc(p)}"{" selected" if g("province") == p else ""}>{esc(p)}</option>' for p in provs)
    cities = {p: [c["name"] for c in db.cities_in(p)] for p in provs}
    cur_prov = g("province") or ""
    city_opts = "".join(f'<option value="{esc(c)}"{" selected" if g("city") == c else ""}>{esc(c)}</option>'
                        for c in (cities.get(cur_prov) or []))
    lat = g("lat") or s.get("map_lat", "32.6340"); lng = g("lng") or s.get("map_lng", "51.3670")
    body = f'''{_err(errors)}
    <form method="post" action="{BASE}/location" data-validate data-dupcheck>
      <div class="grid grid-2" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="rw-prov">استان</label>
          <select class="select" id="rw-prov" name="province" data-prov><option value="">انتخاب کنید…</option>{prov_opts}</select></div>
        <div class="field"><label class="field-label" for="rw-city">شهر<span class="req">*</span></label>
          <select class="select" id="rw-city-sel" data-city-sel{"" if city_opts else " hidden"}><option value="">انتخاب کنید…</option>{city_opts}</select>
          <input class="input" id="rw-city" name="city" required minlength="2" maxlength="40" value="{g('city')}" placeholder="نام شهر" data-city-input{" hidden" if city_opts else ""}>
          <p class="field-hint">اگر استان را انتخاب کنید فهرست شهرها می‌آید؛ در غیر این صورت نام شهر را بنویسید.</p></div>
      </div>
      <div class="field"><label class="field-label" for="rw-area">محله</label>
        <input class="input" id="rw-area" name="area" maxlength="60" value="{g('area')}" placeholder="مثلاً ویلاشهر، خیابان امام"></div>
      <div class="field"><label class="field-label" for="rw-addr">نشانی دقیق<span class="req">*</span></label>
        <input class="input" id="rw-addr" name="address" required minlength="5" maxlength="300" value="{g('address')}" data-dup="address" autocomplete="street-address">
        <div class="dup-hint" data-dup-for="address" hidden></div></div>
      <fieldset class="sub-fields">
        <legend>{icon("map")}<span>موقعیت روی نقشه (اختیاری)</span></legend>
        <div class="map-stage" data-map-wrap data-map="pending" style="min-height:240px;border-radius:var(--radius-md);margin-bottom:var(--space-md)">
          <div data-map-canvas data-pick data-lat="{esc(lat)}" data-lng="{esc(lng)}" style="position:absolute;inset:0"></div>
          <div class="map-legend">{icon("info")}<span data-map-status>بارگذاری…</span></div>
        </div>
        <div class="grid grid-2" style="gap:0 var(--space-md)">
          <div class="field"><label class="field-label" for="sb-lat">عرض جغرافیایی</label>
            <input class="input nums" id="sb-lat" name="lat" dir="ltr" inputmode="decimal" value="{g('lat')}" placeholder="32.6340"></div>
          <div class="field"><label class="field-label" for="sb-lng">طول جغرافیایی</label>
            <input class="input nums" id="sb-lng" name="lng" dir="ltr" inputmode="decimal" value="{g('lng')}" placeholder="51.3660"></div>
        </div>
        <button class="btn btn-glass btn-sm" type="button" data-geo-fill>{icon("compass")}<span>گرفتن موقعیت فعلی من</span></button>
        <p class="field-hint" data-geo-msg hidden></p>
      </fieldset>
      <script type="application/json" id="rw-cities">{json_embed(cities)}</script>
      {_nav("identity")}
    </form>'''
    return _shell(s, me, "location", body)


def step_contact(s, me, d, errors=None, form=None):
    x = d["data"]
    g = lambda k, default="": esc((form or {}).get(k, [x.get(k, default)])[0] if form else (x.get(k, default) or ""))
    pub = x.get("phone_public", True) if not form else bool(form.get("phone_public"))
    body = f'''{_err(errors)}
    <form method="post" action="{BASE}/contact" data-validate>
      <div class="field"><label class="field-label">تلفن کسب‌وکار</label>
        <input class="input nums" type="tel" dir="ltr" value="{esc(me['phone'])}" readonly aria-readonly="true">
        <p class="field-hint">{icon("shield")} همان شمارهٔ تأییدشدهٔ حساب شماست و از این فرم قابل تغییر نیست.</p></div>
      <label class="switch-row mb-lg">
        <input type="checkbox" name="phone_public" value="1"{" checked" if pub else ""}>
        <span class="sw-copy"><strong>{icon("eye")}نمایش شماره در صفحهٔ عمومی</strong><small>اگر خاموش باشد، شماره فقط برای شما و مدیر می‌ماند و مشتری از راه گفتگو یا واتساپ تماس می‌گیرد.</small></span>
        <span class="track" aria-hidden="true"></span>
      </label>
      <div class="grid grid-2" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="rw-wa">واتساپ</label>
          <input class="input nums" id="rw-wa" name="whatsapp" type="tel" dir="ltr" inputmode="tel" value="{g('whatsapp')}" placeholder="09xxxxxxxxx"></div>
        <div class="field"><label class="field-label" for="rw-web">وب‌سایت</label>
          <input class="input" id="rw-web" name="website" type="url" dir="ltr" value="{g('website')}" placeholder="https://"></div>
        <div class="field"><label class="field-label" for="rw-ig">اینستاگرام</label>
          <input class="input" id="rw-ig" name="instagram" dir="ltr" value="{g('instagram')}" placeholder="username"></div>
        <div class="field"><label class="field-label" for="rw-tg">تلگرام</label>
          <input class="input" id="rw-tg" name="telegram" dir="ltr" value="{g('telegram')}" placeholder="username"></div>
      </div>
      <p class="field-label mt-sm">پیام‌رسان‌های ایرانی <span class="text-muted">(اختیاری — شناسه یا لینک صفحه)</span></p>
      <div class="grid grid-2 rw-msgrs" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="rw-eitaa">{icon("eitaa")} ایتا</label>
          <input class="input" id="rw-eitaa" name="eitaa" dir="ltr" value="{g('eitaa')}" placeholder="username"></div>
        <div class="field"><label class="field-label" for="rw-bale">{icon("bale")} بله</label>
          <input class="input" id="rw-bale" name="bale" dir="ltr" value="{g('bale')}" placeholder="username"></div>
        <div class="field"><label class="field-label" for="rw-soroush">{icon("soroush")} سروش</label>
          <input class="input" id="rw-soroush" name="soroush" dir="ltr" value="{g('soroush')}" placeholder="username"></div>
        <div class="field"><label class="field-label" for="rw-rubika">{icon("rubika")} روبیکا</label>
          <input class="input" id="rw-rubika" name="rubika" dir="ltr" value="{g('rubika')}" placeholder="username"></div>
      </div>
      {_nav("location")}
    </form>'''
    return _shell(s, me, "contact", body)


def step_hours(s, me, d, errors=None, form=None):
    x = d["data"]
    hours = x.get("hours") if isinstance(x.get("hours"), dict) else None
    presets = "".join(
        f'<label class="rw-preset"><input type="radio" name="preset" value="{k}"{" checked" if (x.get("hours_label") == lbl) else ""}><span>{esc(lbl)}</span></label>'
        for k, (lbl, _) in R.HOURS_PRESETS.items())
    rows = ""
    for k, label in DAYS:
        if form:
            o, c, closed = form.get(f"h_{k}_open", [""])[0], form.get(f"h_{k}_close", [""])[0], bool(form.get(f"h_{k}_closed"))
        elif hours is not None:
            span = (hours.get(k) or [[None, None]])[0]
            o, c, closed = (span[0] or ""), (span[1] or ""), k not in hours
        else:
            o, c, closed = "09:00", "21:00", k == "fri"
        rows += f'''<div class="hours-row"><span class="text-sm fw-700">{label}</span>
          <input class="input" type="time" name="h_{k}_open" value="{esc(o or '09:00')}" aria-label="شروع {label}">
          <input class="input" type="time" name="h_{k}_close" value="{esc(c or '21:00')}" aria-label="پایان {label}">
          <label class="check"><input type="checkbox" name="h_{k}_closed"{" checked" if closed else ""}><span>تعطیل</span></label></div>'''
    body = f'''{_err(errors)}
    <form method="post" action="{BASE}/hours">
      <p class="field-label">انتخاب سریع</p>
      <div class="rw-presets" data-hours-presets>{presets}</div>
      <details class="more-fields"{" open" if (hours and x.get("hours_label") == "تنظیم دقیق") else ""}><summary>{icon("clock")}<span>تنظیم دقیق روزانه</span><small>ساعت باز و بسته شدن هر روز را جداگانه بنویسید</small></summary>
        <div class="more-fields-body" data-hours-grid>{rows}</div></details>
      {_nav("contact")}
    </form>'''
    return _shell(s, me, "hours", body)


def step_images(s, me, d, errors=None):
    x = d["data"]; imgs = x.get("images") or []
    tiles = "".join(f'''<figure class="rw-thumb"><img src="{esc(p)}" alt="" loading="lazy">
        <form method="post" action="{BASE}/images/remove"><input type="hidden" name="src" value="{esc(p)}">
          <button class="btn btn-ghost btn-sm" type="submit" aria-label="حذف تصویر">{icon("trash")}</button></form></figure>''' for p in imgs)
    left = R.MAX_IMAGES_WEB - len(imgs)
    # 3.11-safe: precomputed (nested same-quote f-string ban)
    _add_form = "" if left <= 0 else f"""<form method="post" action="{BASE}/images" enctype="multipart/form-data" class="mt-md">
      <div data-imagefield data-name="images" data-max="{left}" data-existing="[]"></div>
      <noscript><input type="file" name="images" accept="image/*" multiple></noscript>
      <button class="btn btn-glass mt-sm" type="submit">{icon("upload")}<span>افزودن تصاویر</span></button></form>"""
    body = f'''{_err(errors)}
    <p class="text-muted">{fa(len(imgs))} از {fa(R.MAX_IMAGES_WEB)} تصویر · JPEG/PNG/WebP تا ۳ مگابایت؛ اولین تصویر کاور صفحه می‌شود. بعداً می‌توانید گالری را از پنل کامل کنید.</p>
    <div class="rw-thumbs">{tiles}</div>
    {_add_form}
    <form method="post" action="{BASE}/images/done">{_nav("hours", next_label="ادامه به پیش‌نمایش", skip=not imgs)}</form>'''
    return _shell(s, me, "images", body)


def step_preview(s, me, d, token, errors=None):
    x = d["data"]
    fake = {"id": 0, "slug": "#", "name": x.get("name", ""), "cat_slug": x.get("cat_slug", ""),
            "descr": x.get("descr", ""), "address": x.get("address", ""), "area": x.get("area", ""),
            "city": x.get("city", ""), "images": x.get("images") or [], "tag_list": [t.strip() for t in str(x.get("tags") or "").split("،") if t.strip()][:3],
            "rating": 0, "nreviews": 0, "verified": 0, "featured": 0,
            "phone": me["phone"] if x.get("phone_public") else "", "open_state": {"state": "unknown", "label": "", "detail": ""}}
    try:
        card = biz_card(fake, {x.get("cat_slug", ""): (db.category(x.get("cat_slug", "")) or {}).get("icon", "store")})
    except Exception:
        card = ""
    hours = x.get("hours") or {}
    hrs = "".join(f'<li><span>{lbl}</span><span class="nums">{esc(" و ".join(f"{a}–{b}" for a, b in hours[k]))}</span></li>' if hours.get(k)
                  else f'<li><span>{lbl}</span><span class="text-muted">تعطیل</span></li>' for k, lbl in DAYS)
    rows = [("دسته", x.get("cat_name")), ("نام", x.get("name")), ("توضیح", x.get("descr") or "—"),
            ("برچسب‌ها", x.get("tags") or "—"), ("استان / شهر / محله", " / ".join(v for v in (x.get("province"), x.get("city"), x.get("area")) if v)),
            ("نشانی", x.get("address")), ("موقعیت", f"{x['lat']}, {x['lng']}" if x.get("lat") else "—"),
            ("تلفن", f"{_masked(me['phone'])} — {'نمایش عمومی' if x.get('phone_public') else 'فقط شما و مدیر'}"),
            ("واتساپ", x.get("whatsapp") or "—"), ("سایت / اینستاگرام / تلگرام", " · ".join(v for v in (x.get("website"), x.get("instagram"), x.get("telegram")) if v) or "—"),
            ("پیام‌رسان‌های ایرانی", " · ".join(f"{lbl} @{x[k]}" for k, (_p, lbl, _i) in db.MESSENGERS.items() if x.get(k)) or "—"),
            ("تصاویر", f"{fa(len(x.get('images') or []))} عدد")]
    table = "".join(f'<div class="rw-row"><dt>{esc(k)}</dt><dd>{esc(str(v or ""))} <a class="rw-edit" href="{BASE}/{step}">{icon("edit")}</a></dd></div>'
                    for (k, v), step in zip(rows, ("category", "identity", "identity", "identity", "location", "location", "location", "contact", "contact", "contact", "contact", "images")))
    body = f'''{_err(errors)}
    <div class="grid grid-2 rw-preview">
      <div><p class="field-label">کارت شما در فهرست</p>{card}
        <p class="field-label mt-md">ساعت کاری</p><ul class="rw-hours">{hrs}</ul></div>
      <dl class="rw-table">{table}</dl>
    </div>
    <div class="alert alert-info mt-lg">{icon("info")}<span>پس از تأیید، ثبت شما در صف بررسی مدیر قرار می‌گیرد و تا تأیید نهایی منتشر نمی‌شود. از پنل «کسب‌وکارهای من» می‌توانید وضعیت را ببینید و گالری و کاتالوگ را کامل کنید.</span></div>
    <form method="post" action="{BASE}/submit" class="mt-md" data-once>
      <input type="hidden" name="confirm" value="{esc(token)}">
      <label class="check mb-lg"><input type="checkbox" name="accept" value="1" required><span><a href="/rules" style="color:var(--color-primary)">قوانین</a> را می‌پذیرم و صحت اطلاعات را تأیید می‌کنم.</span></label>
      {_nav("images", next_label="ثبت نهایی و ارسال برای بررسی")}
    </form>'''
    return _shell(s, me, "preview", body)


def done(s, me, bid):
    b = db.business(bid=bid) or {}
    body = f'''<div class="container-wide"><section class="section">
      {empty_state("check-circle", "درخواست شما ثبت شد",
                   f"«{esc(b.get('name', ''))}» در صف بررسی مدیر است و پس از تأیید روی سایت منتشر می‌شود. تا آن زمان می‌توانید گالری، کاتالوگ و جزئیات را از پنل کامل کنید.",
                   f"""<div class="cluster mt-lg" style="justify-content:center">
                     <a class="btn btn-primary" href="/my/businesses">{icon("store")}<span>کسب‌وکارهای من</span></a>
                     <a class="btn btn-glass" href="{BASE}">{icon("plus")}<span>ثبت کسب‌وکار دیگر</span></a>
                   </div>""")}
    </section></div>'''
    return page(s, "ثبت کسب‌وکار", body, "", cats=db.category_tree())
