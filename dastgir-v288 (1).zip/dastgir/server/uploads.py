# -*- coding: utf-8 -*-
"""
Image uploads without any third-party library.

`cgi` was removed in Python 3.13, so multipart/form-data is parsed by hand.
Pillow is not available in Pydroid either, so images are downscaled in the
BROWSER (canvas -> JPEG) before upload; the server validates the magic bytes,
enforces a size cap, and stores the file.
"""

import os
import re
import json
import time
import secrets

# v98: optional real recompression. When Pillow is installed (Pydroid: pip
# install Pillow) uploads are resized+re-encoded at high quality to cut size;
# without it we fall back to the dependency-free metadata strip below.
try:
    from PIL import Image as _PILImage
    _HAS_PIL = True
except Exception:
    _HAS_PIL = False

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
UPLOAD_DIR = os.path.join(ROOT, "site", "assets", "img", "uploads")
CHAT_UPLOAD_DIR = os.path.join(ROOT, "data", "chat-files")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(CHAT_UPLOAD_DIR, exist_ok=True)

PUBLIC_PREFIX = "/assets/img/uploads/"
MAX_FILE = 3 * 1024 * 1024          # 3 MB per image after browser downscale
MAX_FILES = 15
MAX_BODY = 30 * 1024 * 1024

MAGIC = {
    b"\xff\xd8\xff": ".jpg",
    b"\x89PNG\r\n\x1a\n": ".png",
    b"RIFF": ".webp",               # RIFF....WEBP
    b"GIF87a": ".gif",
    b"GIF89a": ".gif",
}

# Video detection lives in sniff_media() below: MP4/MOV/M4V are matched by the
# 'ftyp' brand at offset 4 (the box size varies by encoder) and WebM by its
# EBML header. The server stores the bytes verbatim; playback is client-side.


def sniff(data):
    """Return an extension if the bytes really are an image, else None."""
    for magic, ext in MAGIC.items():
        if data.startswith(magic):
            if ext == ".webp" and data[8:12] != b"WEBP":
                continue
            return ext
    return None


def sniff_media(data):
    """-> (ext, kind) where kind is 'image' | 'video', or (None, None)."""
    ext = sniff(data)
    if ext:
        return ext, "image"
    # MP4 / MOV / M4V are ISO-BMFF: the file always opens with a box whose
    # 4-byte size prefix is followed by the literal brand 'ftyp'. That size
    # varies by encoder (24, 28, 32, 36 …), so match the brand at offset 4
    # instead of a fixed-size magic. v89: phones were rejected as «فایل
    # نامعتبر» because only two exact box sizes were whitelisted.
    if len(data) >= 12 and data[4:8] == b"ftyp":
        brand = data[8:12]
        return (".mov" if brand[:2] == b"qt" else ".mp4"), "video"
    # Matroska / WebM EBML header.
    if data.startswith(b"\x1aE\xdf\xa3"):
        return ".webm", "video"
    return None, None


# --------------------------------------------------------------------------
# multipart/form-data parser
# --------------------------------------------------------------------------
def parse_multipart(body, content_type):
    """
    -> (fields: {name: str}, files: [(field, filename, bytes)])
    Tolerant of CRLF/LF and quoted or bare boundary values.
    """
    m = re.search(r'boundary=(?:"([^"]+)"|([^;\s]+))', content_type or "", re.I)
    if not m:
        return {}, []
    boundary = (m.group(1) or m.group(2)).encode()
    delim = b"--" + boundary

    fields, files = {}, []
    for part in body.split(delim):
        if not part or part in (b"--", b"--\r\n", b"\r\n"):
            continue
        part = part.lstrip(b"\r\n")
        if part.startswith(b"--"):
            continue
        head, sep, payload = part.partition(b"\r\n\r\n")
        if not sep:
            continue
        payload = payload.rstrip(b"\r\n")

        headers = head.decode("utf-8", "replace")
        name_m = re.search(r'name="([^"]*)"', headers)
        if not name_m:
            continue
        name = name_m.group(1)
        file_m = re.search(r'filename="([^"]*)"', headers)

        if file_m:
            fn = file_m.group(1)
            if fn and payload:
                files.append((name, fn, payload))
        else:
            fields[name] = payload.decode("utf-8", "replace")
    return fields, files


# --------------------------------------------------------------------------
# storage
# --------------------------------------------------------------------------
def save_image(data, prefix="img"):
    """-> (public_path, error). Validates real image bytes."""
    if len(data) > MAX_FILE:
        return None, "حجم تصویر بیش از حد مجاز است (حداکثر ۳ مگابایت)."
    ext = sniff(data)
    if not ext:
        return None, "فایل انتخابی یک تصویر معتبر نیست."
    data = optimize_image(data, ext)
    name = f"{prefix}-{int(time.time())}-{secrets.token_hex(4)}{ext}"
    with open(os.path.join(UPLOAD_DIR, name), "wb") as f:
        f.write(data)
    return PUBLIC_PREFIX + name, None


def save_media(data, prefix="story"):
    """-> (public_path, kind, error). Accepts a real image OR a short video
    (mp4/webm/mov by magic bytes) — used for stories. v100: the old 20 MB cap
    is gone; the real story rule is a 30-second duration limit, enforced in the
    browser (compress.js trims before upload). The multipart body cap
    (uploads.MAX_BODY) remains only as a server-side safety net."""
    ext, kind = sniff_media(data)
    if not ext:
        return None, None, "فایل انتخابی تصویر یا ویدیوی معتبر نیست."
    data = optimize_image(data, ext) if kind == "image" else optimize_video(data, ext)
    name = f"{prefix}-{int(time.time())}-{secrets.token_hex(4)}{ext}"
    with open(os.path.join(UPLOAD_DIR, name), "wb") as f:
        f.write(data)
    return PUBLIC_PREFIX + name, kind, None


# --------------------------------------------------------------------------
# private chat attachments (v73)
# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
# v285: news/event media for the admin panel (image OR video + embed links)
# --------------------------------------------------------------------------
NEWS_VIDEO_MAX = 64 * 1024 * 1024      # hard cap for admin video uploads


def save_news_media(data, prefix="news"):
    """-> (public_path, kind, error). Size-capped wrapper over save_media."""
    if len(data) > NEWS_VIDEO_MAX:
        return None, None, "حجم فایل بیشتر از ۶۴ مگابایت است؛ ویدیوی سبک‌تر بگذارید یا لینک آپارات بدهید."
    return save_media(data, prefix=prefix)


def embed_from_url(url):
    """Normalise an admin-pasted media URL to something safe to render.

    Returns ("iframe", src) for allowlisted embeds (Aparat/YouTube),
    ("video", src) for a direct HTTPS video file or a same-site path,
    and None for anything else (arbitrary iframes are never allowed).
    """
    u = (url or "").strip()
    if not u:
        return None
    if u.startswith("//"):
        u = "https:" + u
    m = re.search(r"aparat\.(?:com|ir)/(?:v/|video/video/embed/videohash/)([A-Za-z0-9]+)", u)
    if m and u.lower().startswith("https://"):
        return ("iframe", f"https://www.aparat.com/video/video/embed/videohash/{m.group(1)}/vt/frame")
    m = re.search(r"(?:youtube\.com/(?:watch\?v=|embed/|live/)|youtu\.be/)([A-Za-z0-9_-]{6,24})", u)
    if m and u.lower().startswith("https://"):
        return ("iframe", f"https://www.youtube-nocookie.com/embed/{m.group(1)}")
    if re.search(r"\.(mp4|webm|ogv|m4v)(?:$|\?)", u.split("#")[0], re.I):
        if u.startswith("/") and not u.startswith("//"):
            return ("video", u)                       # same-site upload path
        if u.lower().startswith("https://"):
            return ("video", u)                       # direct file (e.g. WordPress)
    return None


CHAT_MAX_FILE = 8 * 1024 * 1024
CHAT_ALLOWED_LABEL = "عکس"


def _chat_type(data):
    """Return (extension, MIME, kind) from bytes, never from the filename."""
    ext = sniff(data)
    if ext:
        # A forged signature alone is not an image. Verify the mandatory end
        # marker/container length as a second signal without any third-party
        # decoder (Pydroid runtime must stay standard-library-only).
        structurally_valid = {
            ".jpg": data.rfind(b"\xff\xd9") >= max(0, len(data) - 64),
            ".png": len(data) >= 20 and data.endswith(b"IEND\xaeB`\x82"),
            ".gif": len(data) >= 14 and data.endswith(b";"),
            ".webp": (len(data) >= 20 and int.from_bytes(data[4:8], "little") + 8 <= len(data)),
        }[ext]
        if not structurally_valid:
            return None
        mime = {".jpg": "image/jpeg", ".png": "image/png", ".webp": "image/webp",
                ".gif": "image/gif"}[ext]
        return ext, mime, "image"
    # v88: photo-only messenger — PDFs and text notes are no longer accepted.
    return None


def _safe_chat_original(original_name, detected_ext):
    raw = os.path.basename(str(original_name or "").replace("\\", "/"))
    raw = re.sub(r"[\x00-\x1f\x7f<>:\"/\\|?*]", "_", raw).strip(" ._")
    stem = os.path.splitext(raw)[0].strip(" ._") or "file"
    # Keep room for the trusted, detected extension.
    stem = stem[:max(1, 120 - len(detected_ext))]
    return stem + detected_ext


# ---------------------------------------------------------------------
#  Dependency-free image trim (the "compression script").
#
#  Pillow is unavailable in Pydroid, and the standard library ships no
#  JPEG/PNG/WebP *encoder*, so the server cannot re-encode pixels. Real
#  downscaling therefore happens in the browser (chat.js draws the image
#  to a canvas and re-exports a smaller JPEG before upload). This server
#  side is a safety net for clients that post the original bytes: it drops
#  EXIF/XMP/ICC and other non-essential metadata, which is where a large
#  share of a phone photo's bytes often live. Every routine returns the
#  ORIGINAL bytes unless the result is both smaller and still structurally
#  valid, so a photo is never corrupted to save a few kilobytes.
# ---------------------------------------------------------------------
def _strip_jpeg(data):
    if data[:3] != b"\xff\xd8\xff":
        return data
    out = bytearray(b"\xff\xd8")
    i, n = 2, len(data)
    while i + 1 < n:
        if data[i] != 0xFF:
            i += 1
            continue
        marker = data[i + 1]
        if marker == 0xD9:                      # EOI
            out += b"\xff\xd9"
            break
        if marker == 0xDA:                      # SOS: rest is entropy data
            out += data[i:]
            break
        if 0xD0 <= marker <= 0xD7 or marker in (0x01, 0xFF):
            out += data[i:i + 2]                # standalone marker
            i += 2
            continue
        seg_len = int.from_bytes(data[i + 2:i + 4], "big")
        if seg_len < 2 or i + 2 + seg_len > n:
            return data
        # Drop APPn (n>=1: EXIF/XMP/ICC/IPTC) and COM; keep APP0 (JFIF) and
        # all image-data segments (DQT/DHT/SOF/DRI...).
        if not (0xE1 <= marker <= 0xEF) and marker != 0xFE:
            out += data[i:i + 2 + seg_len]
        i += 2 + seg_len
    res = bytes(out)
    if (len(res) < len(data) and res[:3] == b"\xff\xd8\xff"
            and res[-2:] == b"\xff\xd9"):
        return res
    return data


def _strip_png(data):
    sig = b"\x89PNG\r\n\x1a\n"
    if not data.startswith(sig):
        return data
    drop = {b"tEXt", b"zTXt", b"iTXt", b"eXIf", b"iCCP", b"tIME"}
    out = bytearray(sig)
    i, n = 8, len(data)
    while i + 8 <= n:
        length = int.from_bytes(data[i:i + 4], "big")
        ctype = data[i + 4:i + 8]
        end = i + 12 + length
        if end > n:
            return data
        if ctype not in drop:
            out += data[i:end]
        i = end
    res = bytes(out)
    if len(res) < len(data) and res.endswith(b"IEND\xaeB`\x82"):
        return res
    return data


def _strip_webp(data):
    if data[:4] != b"RIFF" or data[8:12] != b"WEBP":
        return data
    drop = {b"EXIF", b"XMP "}
    body = bytearray()
    i, n = 12, len(data)
    while i + 8 <= n:
        fourcc = data[i:i + 4]
        size = int.from_bytes(data[i + 4:i + 8], "little")
        end = i + 8 + size + (size & 1)
        if end > n:
            return data
        if fourcc not in drop:
            body += data[i:end]
        i = end
    res = b"RIFF" + (len(body) + 4).to_bytes(4, "little") + b"WEBP" + bytes(body)
    return res if len(res) < len(data) else data


def compress_image(data, ext):
    """Trim metadata from a chat image. Pure stdlib, never re-encodes, and
    always falls back to the original bytes when unsure."""
    try:
        if ext == ".jpg":
            return _strip_jpeg(data)
        if ext == ".png":
            return _strip_png(data)
        if ext == ".webp":
            return _strip_webp(data)
    except Exception:
        return data
    return data


def optimize_image(data, ext, max_dim=1600, quality=82):
    """v98: high-quality recompression to shrink uploads. With Pillow it
    downscales oversized photos and re-encodes (quality 82, optimize) — visually
    lossless for a directory — and only keeps the result when it is smaller.
    Without Pillow it degrades to the dependency-free metadata strip, so the
    site never depends on a third-party lib being present."""
    if not _HAS_PIL:
        return compress_image(data, ext)
    try:
        import io
        img = _PILImage.open(io.BytesIO(data))
        img = img.convert("RGB") if img.mode not in ("RGBA", "LA") else img.convert("RGBA")
        w, h = img.size
        if max(w, h) > max_dim:
            s = max_dim / float(max(w, h))
            img = img.resize((max(1, int(w * s)), max(1, int(h * s))), _PILImage.LANCZOS)
        fmt = {".jpg": "JPEG", ".jpeg": "JPEG", ".png": "PNG", ".webp": "WEBP"}.get(ext, "JPEG")
        if fmt == "JPEG" and img.mode != "RGB":
            img = img.convert("RGB")
        out = io.BytesIO()
        img.save(out, fmt, quality=quality, optimize=True)
        new = out.getvalue()
        return new if 0 < len(new) < len(data) else data
    except Exception:
        return compress_image(data, ext)


def optimize_video(data, ext):
    """v98: best-effort video recompression. ffmpeg is NOT bundled on Pydroid,
    so this only runs when the binary happens to exist; otherwise the original
    bytes are kept (never worse, never a hard dependency)."""
    import shutil, subprocess, tempfile
    if not shutil.which("ffmpeg"):
        return data
    in_path = out_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as fin:
            fin.write(data); in_path = fin.name
        out_path = in_path + ".c.mp4"
        subprocess.run(
            ["ffmpeg", "-y", "-i", in_path, "-vf", "scale='min(720,iw)':-2",
             "-c:v", "libx264", "-crf", "30", "-preset", "veryfast",
             "-c:a", "aac", "-b:a", "96k", out_path],
            capture_output=True, timeout=120, check=True)
        with open(out_path, "rb") as f:
            new = f.read()
        return new if 0 < len(new) < len(data) else data
    except Exception:
        return data
    finally:
        for p in (in_path, out_path):
            if p and os.path.exists(p):
                try: os.unlink(p)
                except Exception: pass


def save_chat_file(data, original_name, prefix="chat"):
    """Validate and store one private chat attachment.

    Returns (metadata, error). `full_path` is for the controller's rollback
    only and must never be serialized to a browser or inserted into messages.
    """
    data = bytes(data or b"")
    if len(data) > CHAT_MAX_FILE:
        return None, "حجم فایل بیش از حد مجاز است (حداکثر ۸ مگابایت)."
    detected = _chat_type(data)
    if not detected:
        return None, f"این فایل مجاز نیست. فقط {CHAT_ALLOWED_LABEL} پذیرفته می‌شود."
    ext, mime, kind = detected
    if kind == "image":
        # Dependency-free metadata trim; falls back to the original bytes if
        # the result would not be both smaller and structurally valid.
        data = compress_image(data, ext)
    safe_prefix = re.sub(r"[^A-Za-z0-9_-]", "", str(prefix or "chat"))[:40] or "chat"
    stored_name = f"{safe_prefix}-{int(time.time())}-{secrets.token_hex(12)}{ext}"
    full_path = os.path.abspath(os.path.join(CHAT_UPLOAD_DIR, stored_name))
    if os.path.commonpath([full_path, CHAT_UPLOAD_DIR]) != CHAT_UPLOAD_DIR:
        return None, "نام فایل نامعتبر است."
    try:
        with open(full_path, "xb") as f:
            f.write(data)
        os.chmod(full_path, 0o600)
    except OSError:
        return None, "ذخیرهٔ فایل ممکن نشد. دوباره تلاش کنید."
    return {
        "stored_name": stored_name,
        "original_name": _safe_chat_original(original_name, ext),
        "mime": mime,
        "size": len(data),
        "kind": kind,
        "full_path": full_path,
    }, None


def _chat_full_path(stored_name):
    name = str(stored_name or "")
    if not name or name != os.path.basename(name) or not re.fullmatch(
            r"[A-Za-z0-9_-]{1,80}\.(?:jpg|png|webp|gif|pdf|txt)", name):
        return None
    full = os.path.abspath(os.path.join(CHAT_UPLOAD_DIR, name))
    if os.path.commonpath([full, CHAT_UPLOAD_DIR]) != CHAT_UPLOAD_DIR:
        return None
    return full


def read_chat_file(stored_name):
    full = _chat_full_path(stored_name)
    if not full:
        return None
    try:
        with open(full, "rb") as f:
            return f.read()
    except OSError:
        return None


def delete_chat_file(stored_name):
    full = _chat_full_path(stored_name)
    if not full:
        return False
    try:
        os.remove(full)
        return True
    except OSError:
        return False


def gc_chat_files(referenced, min_age_seconds=3600):
    """Delete private attachment bytes no longer referenced by SQLite."""
    keep = {str(x) for x in (referenced or ())}
    now = time.time()
    removed, freed = 0, 0
    for name in os.listdir(CHAT_UPLOAD_DIR):
        if name in keep:
            continue
        full = _chat_full_path(name)
        if not full or not os.path.isfile(full):
            continue
        try:
            if now - os.path.getmtime(full) < min_age_seconds:
                continue
            size = os.path.getsize(full)
            os.remove(full)
            removed += 1
            freed += size
        except OSError:
            continue
    return removed, freed


def list_chat_files():
    out = []
    for name in sorted(os.listdir(CHAT_UPLOAD_DIR)):
        full = _chat_full_path(name)
        if not full or not os.path.isfile(full):
            continue
        try:
            st = os.stat(full)
            out.append({"name": name, "size": st.st_size, "mtime": st.st_mtime})
        except OSError:
            continue
    return out


def delete_image(public_path):
    """Remove a stored upload. Refuses anything outside the upload dir."""
    if not public_path or not public_path.startswith(PUBLIC_PREFIX):
        return False
    name = os.path.basename(public_path)
    full = os.path.abspath(os.path.join(UPLOAD_DIR, name))
    if not full.startswith(UPLOAD_DIR):
        return False
    try:
        os.remove(full)
        return True
    except OSError:
        return False


def disk_usage():
    total = 0
    n = 0
    for f in os.listdir(UPLOAD_DIR):
        try:
            total += os.path.getsize(os.path.join(UPLOAD_DIR, f))
            n += 1
        except OSError:
            pass
    return n, total


def list_files():
    """-> [{name, path, size, mtime}] for the media manager."""
    out = []
    for f in sorted(os.listdir(UPLOAD_DIR)):
        if f == ".gitkeep":
            continue
        full = os.path.join(UPLOAD_DIR, f)
        if not os.path.isfile(full):
            continue
        try:
            st = os.stat(full)
            out.append({"name": f, "path": PUBLIC_PREFIX + f,
                        "size": st.st_size, "mtime": st.st_mtime})
        except OSError:
            continue
    return out


def delete_file(public_path):
    """Delete one upload by its public path. Refuses paths outside the upload
    dir. -> bool"""
    if not public_path or not public_path.startswith(PUBLIC_PREFIX):
        return False
    name = os.path.basename(public_path)
    full = os.path.abspath(os.path.join(UPLOAD_DIR, name))
    if not full.startswith(UPLOAD_DIR):
        return False
    try:
        os.remove(full)
        return True
    except OSError:
        return False


def gc(referenced, min_age_seconds=3600):
    """Delete upload files nobody references anymore. A file must be BOTH
    unreferenced AND older than min_age so an upload still in flight (or a
    preview the user hasn't saved yet) is never touched.

    -> (removed_count, freed_bytes)"""
    if referenced is None:
        referenced = set()
    now = time.time()
    removed, freed = 0, 0
    for f in os.listdir(UPLOAD_DIR):
        if f == ".gitkeep":
            continue
        full = os.path.join(UPLOAD_DIR, f)
        if not os.path.isfile(full):
            continue
        if PUBLIC_PREFIX + f in referenced:
            continue
        try:
            if now - os.path.getmtime(full) < min_age_seconds:
                continue
            freed += os.path.getsize(full)
            os.remove(full)
            removed += 1
        except OSError:
            continue
    return removed, freed
