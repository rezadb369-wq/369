// Dastgir: independently rendered logo geometry and lighting, not a rotating photograph.
const root=document.documentElement;
if(root.hasAttribute('data-dg-bazaar')){
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');let manual=false,cleanup=()=>{},generation=0;
 try{manual=localStorage.getItem('dg-bazaar-pause')==='1'}catch{}
 const button=document.createElement('button');button.className='b-motion';button.type='button';
 const icon=paused=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true">${paused?'<path d="m9 5 11 7-11 7Z"/>':'<path d="M8 5v14M16 5v14"/>'}</svg>`;
 function state(){const off=manual||reduced.matches;root.dataset.dgMotion=off?'off':'on';button.innerHTML=icon(off);button.title=off?'پخش جلوه‌های بصری':'توقف جلوه‌های بصری';button.setAttribute('aria-label',reduced.matches?'کاهش حرکت دستگاه فعال است':button.title);button.setAttribute('aria-pressed',String(!off));button.disabled=reduced.matches;window.dispatchEvent(new Event('dg:motion'))}
 button.onclick=()=>{manual=!manual;try{localStorage.setItem('dg-bazaar-pause',manual?'1':'0')}catch{}state()};document.body.append(button);reduced.addEventListener('change',state);state();
 async function mount(){const id=++generation;cleanup();cleanup=()=>{};const host=document.querySelector('.b-logo-stage'),sceneEl=document.querySelector('.b-scene');if(!host||!sceneEl){button.hidden=true;return}button.hidden=false;
  const light=document.createElement('div');light.className='b-light';light.setAttribute('aria-hidden','true');sceneEl.append(light);
  let active=true,dead=false,frame=0,time=0,last=0,glLost=false;let renderer,environment;let px=0,py=0;
  const observer=new IntersectionObserver(es=>{active=es[0].isIntersecting;sync()},{rootMargin:'80px'});observer.observe(sceneEl);
  let draw=()=>{};
  function running(){return !dead&&!manual&&!reduced.matches&&!document.hidden&&active&&!glLost}
  function tick(stamp){frame=0;if(!running())return;if(stamp-last>=32){time+=Math.min((stamp-last)/1000,.05);last=stamp;draw(time);light.style.transform=`translateX(${Math.sin(time*.38)*14}%)`;}frame=requestAnimationFrame(tick)}
  function sync(){if(frame){cancelAnimationFrame(frame);frame=0}last=performance.now();if(running())frame=requestAnimationFrame(tick)}
  const move=e=>{if(!running())return;const r=sceneEl.getBoundingClientRect();px=((e.clientX-r.left)/r.width-.5)*2;py=((e.clientY-r.top)/r.height-.5)*2};const leave=()=>{px=py=0};
  sceneEl.addEventListener('pointermove',move,{passive:true});sceneEl.addEventListener('pointerleave',leave);document.addEventListener('visibilitychange',sync);window.addEventListener('dg:motion',sync);
  let resizeObserver;
  cleanup=()=>{dead=true;cancelAnimationFrame(frame);observer.disconnect();resizeObserver?.disconnect();document.removeEventListener('visibilitychange',sync);window.removeEventListener('dg:motion',sync);sceneEl.removeEventListener('pointermove',move);sceneEl.removeEventListener('pointerleave',leave);light.remove();if(renderer){renderer.setAnimationLoop(null);renderer.dispose();renderer.domElement.remove()}environment?.dispose();host.removeAttribute('data-ready')};
  try{
   const [T,shapes]=await Promise.all([import('./three.module.min.js'),fetch('/assets/bazaar/logo-shapes.json',{cache:'force-cache'}).then(r=>{if(!r.ok)throw Error('shape');return r.json()})]);if(id!==generation||dead)return;
   renderer=new T.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.setClearColor(0,0);renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;host.append(renderer.domElement);
   const scene=new T.Scene(),camera=new T.PerspectiveCamera(34,1,.1,40);camera.position.set(0,0,6.4);
   const envCanvas=document.createElement('canvas');envCanvas.width=512;envCanvas.height=256;const ec=envCanvas.getContext('2d');ec.fillStyle='#71634b';ec.fillRect(0,0,512,256);let grad=ec.createLinearGradient(0,0,0,256);grad.addColorStop(0,'#fff3d6');grad.addColorStop(.5,'#847c69');grad.addColorStop(1,'#272522');ec.fillStyle=grad;ec.fillRect(0,0,512,256);ec.fillStyle='#fff9e9';ec.fillRect(48,32,75,122);ec.fillStyle='#a7cbbb';ec.fillRect(300,45,40,130);const raw=new T.CanvasTexture(envCanvas);raw.mapping=T.EquirectangularReflectionMapping;raw.colorSpace=T.SRGBColorSpace;const pmrem=new T.PMREMGenerator(renderer);environment=pmrem.fromEquirectangular(raw);scene.environment=environment.texture;raw.dispose();pmrem.dispose();
   const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const ctx=canvas.getContext('2d'),image=ctx.createImageData(128,128);for(let i=0;i<128*128;i++){const v=128+Math.sin(i*123.17)*18;image.data[i*4]=image.data[i*4+1]=image.data[i*4+2]=v;image.data[i*4+3]=255}ctx.putImageData(image,0,0);const bump=new T.CanvasTexture(canvas);bump.wrapS=bump.wrapT=T.RepeatWrapping;bump.repeat.set(4,4);
   const brass=new T.MeshStandardMaterial({color:0xb7894c,metalness:.92,roughness:.28,bumpMap:bump,bumpScale:.018,envMapIntensity:1.2});const jade=new T.MeshPhysicalMaterial({color:0x206855,metalness:.35,roughness:.24,clearcoat:.65,clearcoatRoughness:.16,bumpMap:bump,bumpScale:.004});
   const pearl=new T.MeshPhysicalMaterial({color:0xefdfbf,metalness:.35,roughness:.27,clearcoat:.5});
   const group=new T.Group();scene.add(group);const geometries=[];
   for(const data of shapes){const vector=p=>new T.Vector2((p[0]-384)/215,(384-p[1])/215);const shape=new T.Shape(data.points.map(vector));for(const hole of data.holes)shape.holes.push(new T.Path(hole.map(vector)));const geometry=new T.ExtrudeGeometry(shape,{depth:data.jade?.085:.12,bevelEnabled:true,bevelSegments:3,steps:1,bevelSize:.009,bevelThickness:.015,curveSegments:10});geometries.push(geometry);const mesh=new T.Mesh(geometry,[data.jade?jade:brass,brass]);mesh.castShadow=true;mesh.receiveShadow=true;group.add(mesh);
    if(data.jade)for(const hole of data.holes){const inlayShape=new T.Shape(hole.map(vector));const ig=new T.ExtrudeGeometry(inlayShape,{depth:.058,bevelEnabled:true,bevelSegments:2,bevelSize:.004,bevelThickness:.005,steps:1});geometries.push(ig);const inset=new T.Mesh(ig,pearl);inset.receiveShadow=true;group.add(inset)}
   }
   scene.add(new T.HemisphereLight(0xffebcb,0x45321c,2));const key=new T.DirectionalLight(0xffedca,3);key.position.set(-3,4,6);key.castShadow=true;key.shadow.mapSize.set(512,512);key.shadow.camera.left=-3;key.shadow.camera.right=3;key.shadow.camera.top=3;key.shadow.camera.bottom=-3;key.shadow.bias=-.001;scene.add(key);
   const rim=new T.PointLight(0xb2e0ce,12,12);rim.position.set(3,-1,3);scene.add(rim);
   const shadowG=new T.PlaneGeometry(8,8),shadowM=new T.ShadowMaterial({opacity:.3});const shadow=new T.Mesh(shadowG,shadowM);shadow.position.z=-.06;shadow.receiveShadow=true;scene.add(shadow);
   function resize(){if(dead)return;const w=host.clientWidth,h=host.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/Math.max(h,1);camera.updateProjectionMatrix();renderer.render(scene,camera)}resizeObserver=new ResizeObserver(resize);resizeObserver.observe(host);resize();
   draw=t=>{group.rotation.y+=(-.10+px*.17+Math.sin(t*.55)*.09-group.rotation.y)*.055;group.rotation.x+=(-py*.10+Math.sin(t*.38)*.025-group.rotation.x)*.06;key.position.x=-2.4+Math.sin(t*.8)*2.1;rim.position.y=Math.cos(t*.7)*2;renderer.render(scene,camera);host.dataset.frame=String(Math.round(t*100))};draw(0);host.dataset.ready='webgl';root.dataset.dgRenderer='webgl';sync();
   renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();glLost=true;host.removeAttribute('data-ready');root.dataset.dgRenderer='fallback';sync()});
   const old=cleanup;cleanup=()=>{old();geometries.forEach(g=>g.dispose());brass.dispose();jade.dispose();pearl.dispose();bump.dispose();shadowG.dispose();shadowM.dispose();key.shadow.map?.dispose()};
  }catch{root.dataset.dgRenderer='fallback';host.removeAttribute('data-ready');sync()}
 }
 window.addEventListener('bz:content-updated',mount);mount();window.addEventListener('pagehide',()=>{generation++;cleanup()});window.addEventListener('pageshow',e=>{if(e.persisted)mount()});
}
