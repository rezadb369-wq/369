#!/usr/bin/env bash
# ============================================================================
# نصب‌کنندهٔ یک‌بارِ سایت «دست گیر» روی VPS اوبونتو (۲۰.۰۴ تا ۲۴.۰۴)
#   روش اجرا:   sudo bash deploy/install.sh [مسیر-زیپ]
#   اگر مسیر زیپ ندهید، تازه‌ترین dastgir-*.zip کنار این اسکریپت را برمی‌دارد.
# داده‌ها در /opt/dastgir/data می‌مانند و این اسکریپت هرگز آن‌ها را پاک نمی‌کند.
# ============================================================================
set -euo pipefail

APP_DIR="/opt/dastgir"
PORT=8080

# ---- ۰) پیدا کردن زیپ
ZIP="${1:-}"
if [ -z "$ZIP" ]; then
  ZIP=$(ls -t "$(dirname "$0")"/../dastgir-*.zip 2>/dev/null | head -1 || true)
fi
[ -n "$ZIP" ] && [ -f "$ZIP" ] || { echo "✕ زیپ سایت پیدا نشد. مسیرش را بدهید: sudo bash deploy/install.sh dastgir-vNNN.zip"; exit 1; }
echo "۱/۷) زیپ: $ZIP"

# ---- ۱) بسته‌های پایه
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y python3 nginx unzip curl ca-certificates
echo "۲/۷) بسته‌های پایه نصب شد"

# ---- ۲) سواپ ۲ گیگ (برای سرورهای رم‌کم)
if ! swapon --show | grep -q .; then
  fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
  echo "۳/۷) سواپ ۲ گیگ ساخته شد"
else
  echo "۳/۷) سواپ از قبل موجود است"
fi

# ---- ۳) فایروال — اول SSH تا قفل نشویم
if command -v ufw >/dev/null; then
  ufw allow 22/tcp   >/dev/null 2>&1 || true
  ufw allow OpenSSH  >/dev/null 2>&1 || true
  ufw allow 80/tcp   >/dev/null 2>&1 || true
  ufw allow 443/tcp  >/dev/null 2>&1 || true
  ufw --force enable >/dev/null 2>&1 || true
  echo "۴/۷) فایروال: فقط 22/80/443 باز است"
fi

# ---- ۳b) fail2ban — v286 audit: روی سرور مدیر ۱۱٬۴۸۲ ورود ناموفق SSH در
# ۲۴ ساعت دیده شد (brute-force دائمی اینترنتی). جیل پیش‌فرض sshd:
# ۵ تلاش ناموفق در ۱۰ دقیقه = ۱۰ دقیقه بنِ IP. راهنمای کاملِ سخت‌سازی:
# deploy/SSH-HARDENING-fa.md
if command -v apt-get >/dev/null && ! command -v fail2ban-client >/dev/null; then
  DEBIAN_FRONTEND=noninteractive apt-get install -y -q fail2ban >/dev/null 2>&1 || true
fi
if command -v fail2ban-client >/dev/null; then
  systemctl enable  fail2ban >/dev/null 2>&1 || true
  systemctl restart fail2ban >/dev/null 2>&1 || true
  echo "۴b/۷) fail2ban فعال شد (بنِ خودکار IP متجاوز SSH)"
fi

# ---- ۴) استخراج زیپ در /opt  (ریشهٔ زیپ «dastgir/» است؛ data/ دست‌نخورده می‌ماند)
mkdir -p /opt
unzip -oq "$ZIP" -d /opt
[ -d "$APP_DIR/run.py" ] || [ -f "$APP_DIR/run.py" ] || { echo "✕ ساختار زیپ عجیب است — run.py در $APP_DIR نیست"; exit 1; }
mkdir -p "$APP_DIR/data" "$APP_DIR/site/assets/img/uploads"
echo "۵/۷) سایت در $APP_DIR استخراج شد"

# ---- ۵) سرویس systemd
cp "$APP_DIR/deploy/bazarche.service" /etc/systemd/system/bazarche.service
systemctl daemon-reload
systemctl enable bazarche >/dev/null 2>&1
systemctl restart bazarche

# ---- ۶) nginx
cp "$APP_DIR/deploy/nginx-dastgir.conf" /etc/nginx/sites-available/dastgir
ln -sf /etc/nginx/sites-available/dastgir /etc/nginx/sites-enabled/dastgir
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx
echo "۶/۷) سرویس سایت + nginx فعال شد"

# ---- ۷) مالکیت + پشتیبان شبانه
chown -R www-data:www-data "$APP_DIR"
cp "$APP_DIR/deploy/backup.sh" /usr/local/bin/dastgir-backup && chmod +x /usr/local/bin/dastgir-backup
cat > /etc/cron.d/dastgir-backup <<CRON
# پشتیبان شبانهٔ دست گیر — ساعت ۳ بامداد
0 3 * * * root /usr/local/bin/dastgir-backup >> /var/log/dastgir-backup.log 2>&1
CRON
echo "۷/۷) پشتیبان شبانه (۳ بامداد) تنظیم شد"

# ---- جمع‌بندی
sleep 2
IP=$(curl -s --max-time 5 https://api.ipify.org || hostname -I | awk '{print $1}')
echo
echo "══════════════════════════════════════════════════════════"
echo "  ✓ نصب تمام شد"
echo "  سایت:        http://$IP"
echo "  وضعیت:       systemctl status bazarche"
echo "  لاگ زنده:    journalctl -u bazarche -f"
echo "  لینک پنل:    journalctl -u bazarche | grep -o '/panel?key=[a-z0-9]*' | tail -1"
echo "  پشتیبان‌ها:  /var/backups/dastgir"
echo "  برای TLS با دامنه:  sudo certbot --nginx -d DOMAIN.ir"
echo "══════════════════════════════════════════════════════════"
