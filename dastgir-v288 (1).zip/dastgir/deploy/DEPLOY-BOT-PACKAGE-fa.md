# استقرار بستهٔ بات‌های عمومی روی سایت اصلی (daastgir.ir)

سرور: `130.185.78.237` · مسیر برنامه: `/opt/dastgir` · سرویس: `bazarche` · پورت داخلی: `8080`.
این راهنما راستی‌آزمایی **بات‌های بله/سروش و بستهٔ کامل قابلیت‌ها** بعد از نصب است. خودِ نصب یک‌فرمانی: `deploy/DEPLOY-TERMIUS-fa.md` (کلاینت SSH) یا `docs/TERMUX-GUIDE.md` (گوشی/ترموکس).
مهاجرت پایگاه داده خودکار است (`CREATE TABLE IF NOT EXISTS` — از جمله `order_receipts` و جدول‌های `ai_cache/ai_faq/ai_intents/ai_threads/ai_tool_pending/ai_usage`؛ هیچ‌چیز حذف نمی‌شود). داده‌ها، آپلودها و فایل‌های گفت‌وگو حفظ می‌شوند و قبل از به‌روزرسانی پشتیبان خودکار در `/var/backups/dastgir` گرفته می‌شود.

---

## گام ۱ — دانلود و صحت‌سنجی ZIP

```bash
cd /root && rm -f dastgir-v280.zip \
 && curl -fL -o dastgir-v280.zip 'URL_FROM_DELIVERY_MESSAGE' \
 && echo 'SHA256_FROM_DELIVERY_MESSAGE  dastgir-v280.zip' | sha256sum -c - \
 && unzip -t dastgir-v280.zip | tail -2
```

`URL_FROM_DELIVERY_MESSAGE` و `SHA256_FROM_DELIVERY_MESSAGE` **الگو** هستند؛ مقدار واقعی هر نسخه در پیام تحویل همان نسخه می‌آید.
خروجی مورد انتظار: `dastgir-v280.zip: OK` و `No errors detected`. اگر هش نخواند، **ادامه ندهید**.

## گام ۲ — نصب (پشتیبان خودکار + توقف/شروع سرویس + healthz)

```bash
sudo bash /opt/dastgir/deploy/update.sh /root/dastgir-v280.zip
```

خروجی پایانی باید باشد: `نسخه 280 با موفقیت نصب شد.`

> اگر `update.sh` روی سرور قدیمی‌تر است و ارور داد، نسخهٔ داخل همین ZIP را اجرا کنید:
> ```bash
> cd /root && rm -rf /tmp/dg && mkdir /tmp/dg && unzip -q dastgir-v280.zip -d /tmp/dg \
>  && sudo bash /tmp/dg/dastgir/deploy/update.sh /root/dastgir-v280.zip
> ```

## گام ۳ — بررسی‌های پس از نصب

```bash
cat /opt/dastgir/VERSION.txt
systemctl is-active bazarche
curl -s http://127.0.0.1:8080/healthz; echo
curl -s https://daastgir.ir/sw.js | grep -o "bazarche-v[0-9]*"
curl -s https://daastgir.ir/ | grep -o 'app.js?v[0-9]*'
journalctl -u bazarche -n 30 --no-pager
```

انتظار: `280` · `active` · `ok` · `bazarche-v280` · `app.js?v280` · بدون Traceback در لاگ.

بررسی جدول رسید سفارش و ثبت منوی دستورات بات:

```bash
sudo -u www-data python3 - <<'EOF'
import sqlite3;c=sqlite3.connect('/opt/dastgir/data/bazarche.db')
print('order_receipts:',c.execute("select count(*) from sqlite_master where name='order_receipts'").fetchone()[0])
print(c.execute("select action,detail,created from audit where action='bot.commands' order by rowid desc limit 1").fetchall())
EOF
```

`order_receipts: 1` و یک ردیف `bot.commands` مثل `bale=skip,soroush=ok` (در بله `skip` طبیعی است — گام ۵).

## گام ۴ — تست دستی بات‌ها (۲ دقیقه)

در بله و سروش با حساب متصل:
1. `/start` → دکمهٔ «📍 نزدیک من» باید دیده شود.
2. `/search کافه` → برای هر نتیجه یک کارت (عکس کاور اگر دارد) با «📞 تماس / 🗺 مسیر / 🌐 صفحه».
3. `/near` → دکمهٔ «📍 ارسال موقعیت من» → ارسال موقعیت → کارت‌ها با «… متر از شما».
4. یک سفارش آزمایشی ثبت کنید و از پنل دکان‌دار وضعیت را «تأیید شد» و بعد «آمادهٔ تحویل» کنید → **همان پیامِ** «🧾 رسید سفارش» در بات به‌روز می‌شود (پیام جدید نمی‌آید).
5. `/menu` و `/account` و `/help` فقط در گفت‌وگوی خصوصی کار می‌کنند و اطلاعات تماس/آدرس را نشان نمی‌دهند؛ `/orders` `/bookings` `/favorites` `/messages` `/stock` `/notifications` را هم چک کنید و یک عملیات لغو را تا **تأیید دوم** ببرید.
6. مالک: `/owner` → داشبورد روزانه (سفارش، نوبت امروز، پیام، موجودی، فراخوان).

## گام ۵ — (اختیاری) منوی دستورات در بله

`setMyCommands` در مستندات رسمی بله نیست؛ به‌صورت پیش‌فرض تلاش نمی‌شود. اگر می‌خواهید امتحان شود:

```bash
sudo sh -c 'grep -q "^BALE_SET_COMMANDS=" /etc/dastgir-secrets.env || echo "BALE_SET_COMMANDS=1" >> /etc/dastgir-secrets.env'
sudo systemctl restart bazarche && sleep 3 && curl -s http://127.0.0.1:8080/healthz; echo
```

بی‌ضرر است: اگر بله رد کند فقط `bale=skip` لاگ می‌شود. (هیچ توکنی را در چت یا خروجی چاپ نکنید.)

## گام ۶ — ضداسپم را هم ببینید

`/panel/spam` را باز کنید: کاشی‌های شمار per-کنش، فهرست banها با lift، ویرایش سیاست (limit/window) و ۵۰ رویداد اخیر. در بات مدیر «اسپم» گزارش ۲۴ ساعت را می‌دهد و «اسپم ban <شناسه> [ساعت]» / «اسپم lift <شناسه>» کار می‌کند. پیام هر محدودیت باید **نام دقیق دروازه** را بگوید (مثلاً «درگاه: regsub»).

## بازگشت (Rollback) در صورت مشکل

```bash
ls -t /var/backups/dastgir | head -3          # آخرین پشتیبان قبل از نصب
sudo bash /opt/dastgir/deploy/update.sh /root/dastgir-<نسخهٔ-قبلی>.zip
```

پایگاه داده با نسخهٔ قبلی سازگار می‌ماند (فقط جدول/ستون اضافه شده، چیزی حذف نشده).

## اگر کش مرورگر قدیمی ماند

سرویس‌ورکر با نام کش `bazarche-v280` خودش کش قبلی را دور می‌ریزد؛ در بدترین حالت یک بار صفحه را با Ctrl+F5 باز کنید.
