# استقرار نهایی روی VPS با کلاینت SSH (Termius)

تمام مراحل در همین راهنماست. `URL` و `SHA-256` را از پیام تحویل همان نسخه بردارید (اینجا جای‌نما هستند). توکن‌ها یا راز webhook را در فرمان، چت یا خروجی قرار ندهید.
نسخهٔ گوشی/ترموکس همین روند (با `ssh` و `curl` خود ترموکس): `docs/TERMUX-GUIDE.md`.

## ۱) ورود و بررسی رازهای موجود

```bash
sudo -i
set -euo pipefail
install -d -m 700 /var/backups/dastgir
chown root:root /etc/dastgir-secrets.env
chmod 600 /etc/dastgir-secrets.env
grep -q '^BALE_BOT_TOKEN=' /etc/dastgir-secrets.env
grep -q '^BALE_WEBHOOK_SECRET=' /etc/dastgir-secrets.env
grep -q '^SOROUSH_BOT_TOKEN=' /etc/dastgir-secrets.env
grep -q '^SOROUSH_WEBHOOK_SECRET=' /etc/dastgir-secrets.env
```

اگر فایل راز وجود ندارد، ابتدا با `sudoedit /etc/dastgir-secrets.env` آن را بسازید؛ مقادیر واقعی را در پیام یا history تایپ نکنید. مجوز باید `root:root/600` بماند.

## ۲) دانلود، hash و آزمون ZIP

```bash
ZIP_URL='URL_FROM_DELIVERY_MESSAGE'          # الگو — مقدار واقعی از پیام تحویل
ZIP_SHA256='SHA256_FROM_DELIVERY_MESSAGE'    # الگو — مقدار واقعی از پیام تحویل
curl -fL --retry 4 --retry-all-errors "$ZIP_URL" -o /tmp/dastgir-v280.zip
printf '%s  %s\n' "$ZIP_SHA256" /tmp/dastgir-v280.zip | sha256sum -c -
apt-get update
apt-get install -y unzip rsync curl ca-certificates
unzip -t /tmp/dastgir-v280.zip >/dev/null
STAGE=$(mktemp -d /tmp/dastgir-v280.XXXXXX)
unzip -q /tmp/dastgir-v280.zip -d "$STAGE"
test "$(cat "$STAGE/dastgir/VERSION.txt")" = 280
```

## ۳) به‌روزرسانی تمیز با پشتیبان

اسکریپت از staging اجرا می‌شود، پیش از توقف سرویس با API رسمی SQLite پشتیبان سازگار می‌گیرد (`/var/backups/dastgir`)، کد قدیمی را با `rsync --delete` پاک می‌کند و `data/`، uploadها و chat-files را نگه می‌دارد؛ کرون کدگارد را می‌گذارد، مغز بسته (`deploy/brain.env`) را اعمال می‌کند و در پایان `is-active` + `healthz` را خودش چک می‌کند.

```bash
bash "$STAGE/dastgir/deploy/update.sh" /tmp/dastgir-v280.zip
rm -rf "$STAGE"
test "$(cat /opt/dastgir/VERSION.txt)" = 280
systemctl is-active --quiet bazarche
curl -fsS http://127.0.0.1:8080/healthz >/dev/null
curl -fsS https://daastgir.ir/healthz >/dev/null
```

خروجی پایانی خود اسکریپت: `نسخه 280 با موفقیت نصب شد.`

## ۴) فعال‌سازی خلاصهٔ روزانهٔ مالک

```bash
APP_DIR=/opt/dastgir bash /opt/dastgir/tools/install-owner-summary.sh
systemctl is-enabled --quiet dastgir-owner-summary.timer
systemctl list-timers dastgir-owner-summary.timer --no-pager
systemctl start dastgir-owner-summary.service
systemctl is-failed --quiet dastgir-owner-summary.service && exit 1 || true
journalctl -u dastgir-owner-summary.service -n 20 --no-pager
```

اجرای دستی دوم در همان روز پیام تکراری نمی‌فرستد.

## ۵) ثبت webhook بله و سروش بدون نمایش راز

```bash
bash -c 'set -euo pipefail;set -a;. /etc/dastgir-secrets.env;set +a
curl -fsS -X POST "https://tapi.bale.ai/bot${BALE_BOT_TOKEN}/setWebhook" \
  -H "Content-Type: application/json" \
  --data "{\"url\":\"https://daastgir.ir/api/bale/webhook/${BALE_WEBHOOK_SECRET}\"}" >/dev/null
BASE="https://api.splus.ir/bot${SOROUSH_BOT_TOKEN}"
HOOK="https://daastgir.ir/api/soroush/webhook/${SOROUSH_WEBHOOK_SECRET}"
curl -fsS -X POST "$BASE/setWebhook" -H "Content-Type: application/json" \
  --data "{\"url\":\"$HOOK\",\"allowed_updates\":[\"message\",\"callback_query\"],\"drop_pending_updates\":false}" >/dev/null
unset BALE_BOT_TOKEN BALE_WEBHOOK_SECRET SOROUSH_BOT_TOKEN SOROUSH_WEBHOOK_SECRET BASE HOOK'
```

`getWebhookInfo` را بدون redirect به فایل عمومی اجرا نکنید؛ ممکن است URL شامل راز webhook باشد.

## ۶) بررسی نهایی بدون چاپ راز

```bash
systemctl is-active --quiet bazarche
nginx -t
curl -fsS https://daastgir.ir/healthz >/dev/null
test "$(stat -c '%U:%G:%a' /etc/dastgir-secrets.env)" = 'root:root:600'
curl -s https://daastgir.ir/sw.js | grep -o "bazarche-v[0-9]*"
journalctl -u bazarche --since '-10 minutes' --no-pager | tail -n 80
exit
```

انتظار: `active` · `ok` · `bazarche-v280` · بدون Traceback.
سپس در چت بات مدیر **«تشخیص»** را بفرستید: ۶ خط شماره‌دار (نسخه · مغز با تست واقعی · کرون کدگارد · صف استقرار · سرویس · تأیید معلق) باید سبز باشد و خط نسخه «✅ به‌روز» بدهد.

بعد روی موبایل، در گفتگوی خصوصی هر دو بات `/menu` را آزمایش کنید؛ مشتری `/orders`، `/bookings`، `/notifications`، `/stock`، `/favorites`، `/search` و `/messages` و مالک `/owner` را بررسی کند. یک عملیات آزمایشی را تا صفحهٔ تأیید دوم ببرید و فقط روی دادهٔ آزمایشی تأیید کنید. کنسول ضداسپم `/panel/spam` و «ترافیک و سپر» `/panel/traffic` هم باید باز شوند.

## بازگشت اضطراری

در صورت خطا webhookها را حذف نکنید مگر اینکه سرویس قابل بازیابی نباشد. ابتدا `journalctl -u bazarche` و آخرین پشتیبان در `/var/backups/dastgir` را بررسی کنید. برای بازگردانی کد، ZIP نسخهٔ قبلی را با همین `deploy/update.sh` اجرا کنید؛ برای داده، فقط از backup معتبر و پس از توقف سرویس استفاده کنید.
