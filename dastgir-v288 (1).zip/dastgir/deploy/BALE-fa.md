# راه‌اندازی امن بازوی بله در دست گیر

> webhook را فقط **پس از** نصب بسته، سبزشدن healthcheck و آزمون مسیر عمومی ثبت کنید.

## ۱) رازهای بیرون از پروژه

فایل `/etc/dastgir-secrets.env` باید مالک `root:root` و مجوز `600` داشته باشد و مقادیر واقعی فقط همان‌جا بمانند:

```bash
sudo chown root:root /etc/dastgir-secrets.env
sudo chmod 600 /etc/dastgir-secrets.env
sudo systemctl daemon-reload
sudo systemctl restart bazarche
sudo systemctl is-active bazarche
curl -fsS https://daastgir.ir/healthz
```

نام متغیرها: `BALE_BOT_TOKEN`، `BALE_WEBHOOK_SECRET` و `BALE_BOT_USERNAME=daastgirbot`. مقدارها را در دستور، تاریخچه، خروجی ترمینال، ZIP یا مخزن چاپ نکنید.

## ۲) ثبت webhook ـ فقط پس از استقرار موفق

دستور زیر رازها را بی‌صدا در یک زیرپوستهٔ root می‌خواند و URL سخت‌حدس را ثبت می‌کند. پاسخ نباید توکن را نمایش دهد:

```bash
sudo bash -c 'set -a; . /etc/dastgir-secrets.env; set +a; \
curl -fsS -X POST "https://tapi.bale.ai/bot${BALE_BOT_TOKEN}/setWebhook" \
  -H "Content-Type: application/json" \
  --data "{\"url\":\"https://daastgir.ir/api/bale/webhook/${BALE_WEBHOOK_SECRET}\"}"'
```

سپس در سایت با یک حساب مشتری آزمایشی وارد شوید، از `/me/notif-settings` اتصال بله را انجام دهید، خارج شوید و «ورود بدون کد با بله» را تا بازگشت خودکار مرورگر آزمایش کنید. اگر همان شماره مالک فعال هم باشد، `/my` نیز باید باز شود.

## ۳) بازگشت امن

در صورت مشکل جدی، webhook بله را موقتاً حذف کنید. این کار fallback پیامکی/رمز ایجاد نمی‌کند و ورود بله تا ثبت دوبارهٔ webhook متوقف می‌شود:

```bash
sudo bash -c 'set -a; . /etc/dastgir-secrets.env; set +a; \
curl -fsS -X POST "https://tapi.bale.ai/bot${BALE_BOT_TOKEN}/deleteWebhook"'
```

توکن یا راز webhook را در گزارش خطا کپی نکنید. برای چرخش راز URL، webhook قبلی را حذف، `BALE_WEBHOOK_SECRET` را با مقدار تصادفی تازه جایگزین، سرویس را restart و webhook جدید را ثبت کنید. ورود پیامکی و رمز عبور در نسخه‌های فعلی غیرفعال‌اند؛ حذف webhook فقط ورود/ثبت‌نام بات بله را موقتاً متوقف می‌کند و fallback ناامن فعال نمی‌سازد.
