#!/usr/bin/env python3
"""Presentation + synchronized version metadata only. Strict allowlist, backup and rollback."""
import argparse,datetime,fcntl,hashlib,json,os,shutil,subprocess,sys,tempfile,time
from pathlib import Path
APP=Path('/opt/dastgir');BACKUPS=Path('/var/backups/dastgir-appearance')
ALLOWED=set(['README.md', 'VERSION.txt', 'docs/BAZAAR-PROMPT.md', 'docs/BAZAAR-v281.md', 'docs/collaboration/CURRENT-STATE.md', 'server/adminbot.py', 'server/ui.py', 'site/assets/bazaar/THREE-LICENSE.txt', 'site/assets/bazaar/bazaar.css', 'site/assets/bazaar/bazaar.js', 'site/assets/bazaar/inlay.svg', 'site/assets/bazaar/logo-relief.png', 'site/assets/bazaar/logo-shapes.json', 'site/assets/bazaar/market.webp', 'site/assets/bazaar/three.module.min.js', 'site/assets/bazaar/walnut.webp', 'site/assets/css/heritage.css', 'site/assets/img/heritage/dastgir-emblem.webp', 'site/assets/img/heritage/girih.svg', 'site/assets/img/heritage/plaster.webp', 'site/assets/js/heritage.js', 'site/assets/vendor/gsap/LICENSE.txt', 'site/assets/vendor/gsap/gsap.min.js', 'site/sw.js', 'tools/test_adminbot_v259.py', 'tools/test_adminbot_v269.py', 'tools/test_adminbot_v270.py', 'tools/test_adminbot_v271.py', 'tools/test_adminbot_v272.py', 'tools/test_adminbot_v274.py'])

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None

def target(rel):
 if rel not in ALLOWED:raise RuntimeError('مسیر خارج از محدوده: '+rel)
 p=APP/rel
 if p.is_symlink() or not p.resolve().is_relative_to(APP.resolve()) or (p.exists() and not p.is_file()):raise RuntimeError('مسیر نامعتبر: '+rel)
 return p

def cmd(a):subprocess.run(a,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
def active():return subprocess.run(['systemctl','is-active','--quiet','bazarche'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0

def health(new=False):
 for _ in range(15):
  if active() and subprocess.run(['curl','--noproxy','*','-fsS','--max-time','2','http://127.0.0.1:8080/healthz'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:
   if not new:return True
   r=subprocess.run(['curl','--noproxy','*','-fsS','--max-time','4','http://127.0.0.1:8080/'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
   if r.returncode==0 and b'data-dg-bazaar="merchant1"' in r.stdout:return True
  time.sleep(1)
 return False

def write(p,raw,m):
 p.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(prefix='.dg-',dir=p.parent)
 try:
  with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
  os.chmod(tmp,m['mode']);os.chown(tmp,m['uid'],m['gid']);os.replace(tmp,p)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)

def restore(folder):
 snap=json.loads((folder/'snapshot.json').read_text())
 if set(snap)!=ALLOWED:raise RuntimeError('فهرست بکاپ نامعتبر')
 for r,m in snap.items():
  target(r)
  if m['exists'] and digest(folder/'files'/r)!=m['sha']:raise RuntimeError('بکاپ خراب: '+r)
 cmd(['systemctl','stop','bazarche'])
 try:
  for r,m in snap.items():
   p=target(r)
   if m['exists']:write(p,(folder/'files'/r).read_bytes(),m)
   elif p.exists():p.unlink()
 finally:cmd(['systemctl','start','bazarche'])
 if not health():raise RuntimeError('فایل‌ها برگشتند، ولی سلامت سرویس تأیید نشد؛ بررسی دستی لازم است')

def install(payload,check=False):
 entries=json.loads((payload/'deploy/bazaar-manifest.json').read_text())['files']
 if set(entries)!=ALLOWED:raise RuntimeError('بستهٔ نامعتبر')
 if not (APP/'run.py').is_file():raise RuntimeError('/opt/dastgir پیدا نشد')
 same=True
 for r,info in entries.items():
  if info['new'] is not None:
   if digest(payload/r)!=info['new']:raise RuntimeError('هش بسته نامعتبر: '+r)
   if r.endswith('.py'):compile((payload/r).read_bytes(),r,'exec')
  now=digest(target(r))
  if now not in info['accepted']+[info['new']]:raise RuntimeError('نسخهٔ فعلی متفاوت است؛ بدون تغییر متوقف شد: '+r)
  same=same and now==info['new']
 if check:print('بررسی موفق؛ هیچ تغییری اعمال نشد.');return
 if same:print('این طراحی قبلاً نصب شده است؛ تغییری لازم نیست.');return
 if not active():raise RuntimeError('سرویس فعلی فعال نیست؛ نصب متوقف شد')
 BACKUPS.mkdir(parents=True,exist_ok=True,mode=0o700);folder=BACKUPS/datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f');folder.mkdir(mode=0o700);snap={};fallback=(APP/'server/ui.py').stat()
 for r in sorted(ALLOWED):
  p=target(r);st=p.stat() if p.exists() else fallback;snap[r]={'exists':p.exists(),'sha':digest(p),'uid':st.st_uid,'gid':st.st_gid,'mode':st.st_mode&0o777}
  if p.exists():q=folder/'files'/r;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 (folder/'snapshot.json').write_text(json.dumps(snap,indent=2));shutil.copy2(__file__,folder/'install-bazaar.py')
 print('بکاپ فایل‌های تغییرکرده: '+str(folder),flush=True)
 try:
  cmd(['systemctl','stop','bazarche'])
  for r,info in entries.items():
   p=target(r)
   if info['new'] is None:
    if p.exists():p.unlink()
   else:write(p,(payload/r).read_bytes(),snap[r])
  cmd(['systemctl','start','bazarche'])
  if not health(new=True):raise RuntimeError('سلامت یا نمایش پوستهٔ تازه تأیید نشد')
 except BaseException:
  print('نصب ناموفق؛ بازگردانی…',flush=True);restore(folder);raise
 print('نصب v281 موفق؛ healthz و نشان HTML پوستهٔ تازه تأیید شد. داده و تنظیمات حفظ شدند.')
 print('بازگشت: sudo python3 '+str(folder/'install-bazaar.py')+' --rollback '+str(folder))

def main():
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');p.add_argument('--rollback',type=Path);a=p.parse_args()
 if os.geteuid()!=0:raise RuntimeError('با sudo اجرا کنید')
 for t in ['systemctl','curl']:
  if not shutil.which(t):raise RuntimeError('ابزار موجود نیست: '+t)
 with open('/var/lock/dastgir-appearance.lock','w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if a.rollback:
   f=a.rollback.resolve()
   if not f.is_relative_to(BACKUPS.resolve()):raise RuntimeError('مسیر بکاپ نامعتبر')
   restore(f);print('بازگشت انجام شد؛ سلامت تأیید شد.')
  else:install(Path(__file__).resolve().parents[1],a.check)
if __name__=='__main__':
 try:main()
 except Exception as e:print('خطا: '+str(e),file=sys.stderr);sys.exit(1)
