#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v287 — امنیت واقعی از بات مدیر (دستور مدیر: «بیشتر دسترسی بده حتی
امنیت‌ها تا گزارش و دلیل بهم بگه» + «نمایشی نباشه و کاملاً اثبات شده»).

پوشش:
  · دستور «امنیت» = do_sec(): گزارش زنده با عدد + بخش «نتیجه و دلیل»؛ در
    محیط بدون ژورنال صادقانه می‌گوید «خوانده نشد» (حدس نمی‌زند).
  · شبیه‌سازی حملهٔ رمزکشا (۶۰۰ تلاش ناموفق): قضاوت 🔴 سنگین + مهاجم برتر
    با شمار + دلیل «سخت‌سازی را بفرست» + هشدار ورود موفق در بازهٔ حمله.
  · شبیه‌سازی fail2ban فعال: jail ✅ + «لایهٔ ۱ برقرار» + لیست مسدودها.
  · «سخت‌سازی» → تأیید «بله» → صف ریشه (cmd=secharden در adminbot-cmd)؛
    گیت is_team_chat دست‌نخورده؛ «نه»/انقضا لغو می‌کند.
  · ALLOWED_QUEUE_CMDS و «حذف سخت‌سازی» (do_unqueue).
  · ثبت sec_report در CT: TOOLS + IMMEDIATE_TOOLS + parse + precheck +
    execute + describe + نام‌های خودساخته (alias).
  · ADMIN_PROMPT ابزار را به مغز معرفی می‌کند (تا «خارج از ابزارهای من»
    نگوید) · راهنما · codeguard.sh case secharden (bash -n + محتوای jail).
"""
import glob
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="adm-v287-")
os.environ["BZ_DATA_DIR"] = TMP
os.environ["BALE_ADMIN_TOKEN"] = "test-token-not-real"
os.environ["BALE_ADMIN_SECRET"] = "s" * 40
os.environ["BALE_ADMIN_CHAT"] = "893219571"
os.environ["ADMINBOT_QUEUE"] = os.path.join(TMP, "q")
os.environ["ADMINBOT_PENDING"] = os.path.join(TMP, "pending.json")
sys.path.insert(0, str(ROOT / "server"))
sys.path.insert(0, str(ROOT / "tools"))

import db                      # noqa: E402
import adminbot as A           # noqa: E402
import adminbot_content as CT  # noqa: E402
import assistant               # noqa: E402

FAILS = []


def ck(cond, label):
    print(("  ✓ " if cond else "  ✗ ") + label)
    if not cond:
        FAILS.append(label)


A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: "42"
A.NGINX_ACCESS = os.path.join(TMP, "no-access.log")
A.NGINX_ERROR = os.path.join(TMP, "no-error.log")
A.OFFSITE_LOG = os.path.join(TMP, "no-offsite.log")
A.WATCHDOG_LOG = os.path.join(TMP, "no-watchdog.log")
db.init()
CHAT = "893219571"

# ---- 1. صف ریشه: secharden مجاز است، ناشناس نه
ck(A.ALLOWED_QUEUE_CMDS == ("backup", "restart", "secharden"),
   "ALLOWED_QUEUE_CMDS = backup/restart/secharden (دقیق)")
ck(A.queue_write("secharden") is True, "queue_write('secharden') پذیرفت")
files = sorted(glob.glob(os.path.join(A.queue_dir(), "secharden-*.json")))
ck(len(files) == 1, "فایل صف secharden-*.json نوشته شد")
ck(json.load(open(files[0], encoding="utf-8"))["cmd"] == "secharden",
   "محتوای فایل صف: cmd=secharden")
ck(A.queue_write("rm -rf /") is False, "cmd ناشناس همچنان رد می‌شود")

# ---- 2. «حذف سخت‌سازی» — لغو از صف
out = A.do_unqueue("سخت‌سازی")
ck(glob.glob(os.path.join(A.queue_dir(), "secharden-*.json")) == [],
   "«حذف سخت‌سازی» فایل صف را برداشت")
ck("«سخت‌سازی» از صف حذف شد" in out,
   "do_unqueue برچسب درست دارد (نه «ریستارت»): " + out)

# ---- 3. گیت مدیر: غریبه به هیچ‌کدام از مسیرهای جدید نمی‌رسد
t, m = A.handle_text("u1", "111", "امنیت")
ck(t.startswith("⛔") and m is None, "غریبه ← امنیت: رد (گیت is_team_chat سالم)")
t, m = A.handle_text("u1", "111", "سخت‌سازی")
ck(t.startswith("⛔"), "غریبه ← سخت‌سازی: رد")

# ---- 4. «امنیت» در همین سندباکس — صادقانه، بدون کرش
t, m = A.handle_text("u1", CHAT, "امنیت")
ck(t.startswith("🛡️ گزارش امنیت سرور و سایت"), "«امنیت» با سربرگ گزارش برگشت")
ck("🔎 نتیجه و دلیل:" in t, "بخش «نتیجه و دلیل» همیشه هست")
ck("۱) SSH" in t and ("تلاش ناموفق" in t or "خوانده نشد" in t),
   "بخش SSH: یا عدد واقعی یا «خوانده نشد» — حدس نیست")
t2, _ = A.handle_text("u1", CHAT, "ssh")
ck(t2.startswith("🛡️"), "میان‌بر ssh هم همان گزارش است")

# ---- 5. شبیه‌سازی حملهٔ رمزکشا: ۶۰۰ ناموفق (۳ مهاجم) + ۲ ورود موفق
FAIL_LN = ("Sep 14 03:%02d:%02d srv sshd[9%d]: Failed password for invalid "
           "user admin from %s port 4%d ssh2")
OK_LN = ("Sep 14 09:11:02 srv sshd[800]: Accepted password for mgr from "
         "5.6.7.8 port 51000 ssh2")


def brute_journal():
    lines = []
    for i in range(400):
        lines.append(FAIL_LN % (i % 60, i % 60, i, "203.0.113.9", i % 999))
    for i in range(150):
        lines.append(FAIL_LN % (i % 60, i % 60, i, "198.51.100.7", i % 999))
    for i in range(50):
        lines.append(FAIL_LN % (i % 60, i % 60, i, "192.0.2.15", i % 999))
    lines.append(OK_LN)
    lines.append(OK_LN)
    return "\n".join(lines)


REAL_RUN = A._run


def fake_run_no_f2b(args, timeout=10):
    if args and args[0] == "journalctl":
        return brute_journal()
    return ""          # fail2ban/ufw/ss: نیست یا خوانده نشد


A._run = fake_run_no_f2b
t, _ = A.handle_text("u1", CHAT, "امنیت")
ck("600 تلاش ناموفق · 🔴 سنگین" in t, "۶۰۰ ناموفق ⇒ قضاوت «🔴 سنگین» با عدد")
ck("203.0.113.9 (400 بار)" in t and "198.51.100.7 (150 بار)" in t,
   "مهاجمان برتر با شمار دقیق لیست شدند")
ck("ورود موفق: 2 از: 5.6.7.8" in t, "ورودهای موفق + IP مدیر نمایان است")
ck("حملهٔ سنگین رمزکشا روی SSH در جریان است" in t
   and "«سخت‌سازی»" in t, "دلیل: حمله سنگین ⇒ راهنمایی به «سخت‌سازی»")
ck("در همان بازهٔ حمله 2 ورود موفق ثبت شده" in t,
   "دلیل: ورود موفق در بازهٔ حمله ⇒ بررسی IP + تعویض رمز")
ck("fail2ban: ❌ نصب نیست" in t and "بدون fail2ban" in t,
   "fail2ban نبود ⇒ گزارش نصب‌نبودن + دلیل اقدام")

# ---- 6. شبیه‌سازی fail2ban فعال با زندانی‌های واقعی
F2B_STATUS = """Status for the jail: sshd
|- Filter
|  |- Currently failed:\t3
|  |- Total failed:\t900
`- Actions
   |- Currently banned:\t5
   |- Total banned:\t12
   `- Banned IP list:\t203.0.113.9 198.51.100.7 192.0.2.15 45.13.20.1 45.13.20.2"""


def fake_run_f2b(args, timeout=10):
    if args and args[0] == "journalctl":
        return brute_journal()
    if args[:2] == ["fail2ban-client", "status"]:
        return F2B_STATUS
    if args[:2] == ["fail2ban-client", "--version"]:
        return "fail2ban v1.0.2"
    return ""


A._run = fake_run_f2b
t, _ = A.handle_text("u1", CHAT, "امنیت")
ck("fail2ban: ✅ jail فعال" in t and "مسدود: 12" in t,
   "fail2ban فعال ⇒ jail ✅ + شمار مسدودها از Total banned")
ck("203.0.113.9 198.51.100.7" in t, "لیست IPهای مسدود در گزارش آمد")
ck("لایهٔ ۱ برقرار است" in t, "دلیل: لایهٔ ۱ برقرار")
ck("❌ نصب نیست" not in t, "در حالت فعال، ادعای نصب‌نبودن نمی‌آید")

# ---- 7. رسید سخت‌سازی قبلی خوانده می‌شود (data/sec-harden-result.txt)
with open(A.SEC_HARDEN_RESULT, "w", encoding="utf-8") as f:
    f.write("=== سخت‌سازی SSH — 2026-09-15 10:00:00 ===\n"
            "fail2ban: jail sshd فعال ✅\nمسدودسازی فوری: 9 IP\n")
A._run = fake_run_f2b
t, _ = A.handle_text("u1", CHAT, "امنیت")
ck("رسید آخرین سخت‌سازی" in t and "مسدودسازی فوری: 9 IP" in t,
   "رسید codeguard در گزارش بات خوانده شد (اثبات پایان‌به‌پایان)")
os.remove(A.SEC_HARDEN_RESULT)
A._run = REAL_RUN

# ---- 8. «سخت‌سازی» → «بله» → صف ریشه؛ «نه» و انقضا لغو می‌کند
t, m = A.handle_text("u1", CHAT, "سخت‌سازی")
ck("codeguard" in t and "بفرست: بله" in t and m is None,
   "«سخت‌سازی» اول تأیید می‌خواهد (بدون اجرای بی‌تأیید)")
t, m = A.handle_text("u1", CHAT, "نه")
ck(t.startswith("لغو شد"), "«نه» لغو می‌کند")
ck(glob.glob(os.path.join(A.queue_dir(), "secharden-*.json")) == [],
   "بعد از لغو هیچ فایلی در صف نیست")
t, m = A.handle_text("u1", CHAT, "سخت‌سازی")
t, m = A.handle_text("u1", CHAT, "بله")
ck("⏳ سخت‌سازی تو صف ریشه رفت" in t, "«بله» ⇒ تأیید صف رفت")
qf = glob.glob(os.path.join(A.queue_dir(), "secharden-*.json"))
ck(len(qf) == 1 and json.load(open(qf[0], encoding="utf-8"))["cmd"] == "secharden",
   "فایل واقعی cmd=secharden در adminbot-cmd — codeguard همان را برمی‌دارد")
for f_ in qf:
    os.remove(f_)
# انقضا: پیام «دوباره بفرست: سخت‌سازی»
A._pending_write(time.time() - 5, "sec_harden")
t, m = A.handle_text("u1", CHAT, "بله")
ck("منقضی" in t and "سخت‌سازی" in t, "pending منقضی ⇒ «دوباره بفرست: سخت‌سازی»")
A._pending_clear()

# ---- 9. ثبت sec_report در لایهٔ ابزار هوش (CT)
ck("sec_report" in CT.TOOLS, "sec_report در TOOLS")
ck("sec_report" in CT.IMMEDIATE_TOOLS,
   "sec_report در IMMEDIATE_TOOLS (خواندنی — فوری، بدون «بله»)")
nm, ar = CT.parse_tool_call({"name": "sec_report", "args": {}})
ck(nm == "sec_report" and ar == {}, "parse_tool_call: sec_report معتبر است")
ok, why = CT.tool_precheck("sec_report", {})
ck(ok is True and why == "", "tool_precheck: sec_report ⇒ (True, '')")
for alias in ("security", "ssh_status", "fail2ban", "audit"):
    ck(CT.normalize_tool_name(alias) == "sec_report",
       "alias خودساختهٔ مدل: %s ⇒ sec_report" % alias)
ok, msg = CT.tool_execute("sec_report", {})
ck(ok is True and msg.startswith("🛡️ گزارش امنیت"),
   "tool_execute('sec_report') گزارش واقعی برگرداند")
d = CT.tool_describe("sec_report", {})
ck("امنیت" in d, "tool_describe: شرح فارسی دارد")

# ---- 10. مغز می‌داند ابزار را دارد (پایان «خارج از ابزارهای من است»)
ck("sec_report {}" in assistant.ADMIN_PROMPT,
   "ADMIN_PROMPT: sec_report معرفی شده")
ck("نتیجه و دلیل" in assistant.ADMIN_PROMPT,
   "ADMIN_PROMPT: دستورِ نقل «نتیجه و دلیل» داده شده")

# ---- 11. راهنمای بات + codeguard.sh (اجرای واقعی ریشه)
t, m = A.handle_text("u1", CHAT, "راهنما")
ck("امنیت" in t and "سخت‌سازی" in t, "راهنما: امنیت · سخت‌سازی لیست شدند")
cg = (ROOT / "deploy" / "codeguard.sh").read_text(encoding="utf-8")
for needle in ("secharden)", "dastgir-sshd.local", "maxretry = 3",
               "bantime  = 86400", "set sshd banip",
               "sec-harden-result.txt", "fail2ban"):
    ck(needle in cg, "codeguard.sh شامل %r است" % needle)
ck("127.*|10.*|192.168.*" in cg, "codeguard.sh هرگز IP خصوصی/لوکال را بن نمی‌کند")
rc = subprocess.run(["bash", "-n", str(ROOT / "deploy" / "codeguard.sh")],
                    capture_output=True).returncode
ck(rc == 0, "bash -n codeguard.sh: سینتکس سالم")
inst = (ROOT / "deploy" / "install.sh").read_text(encoding="utf-8")
ck("fail2ban" in inst, "install.sh همچنان fail2ban را برای نصب تازه دارد")

print()
if FAILS:
    print("✗ %d شکست:" % len(FAILS))
    for f_ in FAILS:
        print("   -", f_)
    sys.exit(1)
print("✅ همه سبز")
