#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v275 — هستهٔ ضداسپم ماندگار: سیاست مرکزی، پلهٔ تنبیه، ban ماندگار، سقف بایت،
هرس‌ها، و درگاه‌های HTTP با نامِ دقیق gate (قانون RULES §1).

دستور مدیر: «سیستم اسپم اعم از پیام‌ها تیکت‌ها وارد شدن به حساب کاربری اضافه
کردن کسب و کار محصولات فراخوان» — فاز ۱: هسته + سطل‌های جامانده + ماندگاری.
"""
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="asv275-")
os.environ["BZ_DATA_DIR"] = TMP
sys.path.insert(0, str(ROOT / "server"))

import db          # noqa: E402
import antispam    # noqa: E402
import shield      # noqa: E402
import assistant   # noqa: E402

db.init()
n = 0


def ck(ok, label):
    global n
    assert ok, label
    n += 1
    print("  ✓", label)


# ---------- 1. جدول‌ها در SCHEMA ----------
con = db.connect()
tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
con.close()
ck({"spam_events", "spam_bans"} <= tables, "جدول‌های spam_events/spam_bans ساخته شدند")

# ---------- 2. guard: مجاز تا سقف، بعد رد با نام gate ----------
antispam.POLICY["t_act"] = (3, 600, True)
for i in range(3):
    ok, g, _ = antispam.guard("t_act", "ip1")
    ck(ok, "درخواست %d مجاز" % (i + 1))
ok, g, r = antispam.guard("t_act", "ip1")
ck(not ok and g == "t_act" and r == 600, "درخواست چهارم رد + نام gate دقیق")

# ---------- 3. پلهٔ تنبیه: ۶ رد در پنجره = ban ----------
antispam.POLICY["t_deny"] = (0, 600, True)
for i in range(6):
    antispam.guard("t_deny", "ip2")
ck(antispam.banned("ip2"), "پلهٔ تنبیه: ۶ رد => ban خودکار")
ok, g, _ = antispam.guard("t_deny", "ip2")
ck(not ok and g == "ban", "هویت ban‌شده: gate=ban")

# ---------- 4. ماندگاری ban پس از «ری‌استارت» (پردازهٔ مجزا) ----------
code = ("import os,sys; sys.path.insert(0,%r); import antispam;"
        "print(antispam.banned('ip2'))" % str(ROOT / "server"))
env = dict(os.environ, BZ_DATA_DIR=TMP)
out = subprocess.run([sys.executable, "-c", code], env=env,
                     capture_output=True, text=True, timeout=60)
ck(out.stdout.strip() == "True", "ban در پردازهِ تازه (پس از ری‌استارت) زنده است")

# ---------- 5. lift ----------
ck(antispam.lift("ip2"), "lift دستی ban")
ck(not antispam.banned("ip2"), "پس از lift هویت آزاد است")

# ---------- 6. سوئیچ ratelimit_on فقط غیرalways را خاموش می‌کند ----------
db.set_setting("ratelimit_on", "0")
antispam.POLICY["t_off"] = (1, 600, False)
a = antispam.guard("t_off", "ip3")
b = antispam.guard("t_off", "ip3")
ck(a[0] and b[0], "سوئیچ خاموش: کنش غیرalways محدود نمی‌شود")
antispam.POLICY["t_on"] = (1, 600, True)
antispam.guard("t_on", "ip3")
ok2, _, _ = antispam.guard("t_on", "ip3")
ck(not ok2, "سوئیچ خاموش: کنش always همچنان سخت می‌ماند")
db.set_setting("ratelimit_on", "1")

# ---------- 7. سقف بایت روزانه (G21) ----------
antispam.BYTES_DAY = 1000
ck(antispam.bytes_add("u1", 700), "۷۰۰ بایت مجاز")
ck(not antispam.bytes_add("u1", 400), "عبور از سقف روزانه رد می‌شود (gate bytes)")
antispam.BYTES_DAY = 60 * 1024 * 1024

# ---------- 8. هرس: رویدادها سقف ۵۰۰۰، بن‌های کهنه حذف ----------
con = db.connect()
old = time.time() - 30 * 86400
for i in range(60):
    con.execute("INSERT INTO spam_events(ts,ident,action,verdict,gate) "
                "VALUES (?,?,?,?,?)", (old, "old", "x", "deny", "x"))
con.execute("INSERT INTO spam_bans(ident,reason,until,by,created) VALUES(?,?,?,?,?)",
            ("oldban", "x", old, "auto", old))
con.commit(); con.close()
antispam.prune()
con = db.connect()
ce = con.execute("SELECT COUNT(*) c FROM spam_events WHERE ident='old'").fetchone()["c"]
cb = con.execute("SELECT COUNT(*) c FROM spam_bans WHERE ident='oldban'").fetchone()["c"]
con.close()
ck(ce == 0 and cb == 0, "هرس: رویداد و ban کهنه پاک شدند")

# ---------- 9. shield هویت ban‌شده را ۴۰۳ می‌کند (لایهٔ ماندگار) ----------
antispam.ban("ipban", "test", 3600)


class Stub:
    path = "/businesses"
    headers = {"User-Agent": "pytest"}

    def client_key(self):
        return "ipban"


res = shield.check(Stub())
ck(res is not None and res[0] == 403 and "ضداسپم" in res[1],
   "shield: هویت ban‌شده => 403 ماندگار")
antispam.lift("ipban")


# ---------- 10. HTTP زنده: 429 با نام gate ----------
import app  # noqa: E402
antispam.POLICY["checkdup"] = (2, 600, True)
antispam.POLICY["search"] = (1, 600, True)
srv = app.make_server(8095)
threading.Thread(target=srv.serve_forever, daemon=True).start()
time.sleep(0.4)


def req(path, ident, method="POST"):
    kw = {"method": method}
    if method == "POST":
        kw["data"] = b"x=1"
    r = urllib.request.Request("http://127.0.0.1:8095" + path,
                               headers={"X-Forwarded-For": ident}, **kw)
    try:
        with urllib.request.urlopen(r, timeout=10) as resp:
            return resp.status, resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8")


codes = []
for i in range(3):
    st, body = req("/api/check-duplicate", "8.8.8.1")
    codes.append((st, body))
ck(codes[2][0] == 429 and "checkdup" in codes[2][1],
   "HTTP: سومین check-duplicate => 429 با نام gate")
st1, _ = req("/businesses?q=a", "9.9.9.2", method="GET")
st2, b2 = req("/businesses?q=a", "9.9.9.2", method="GET")
ck(st2 == 429 and "search" in b2, "HTTP: دومین جست‌وجو => 429 با نام gate")
antispam.ban("ipweb", "test", 3600)
stb, bb = req("/businesses?q=a", "ipweb", method="GET")
ck(stb == 403 and "ضداسپم" in bb, "HTTP: هویت ban‌شده => 403 ماندگار در لایهٔ وب")
antispam.lift("ipweb")

# ---------- 11. چرخش لاگ چت (G20) ----------
lg = os.path.join(TMP, "site_chats.log")
with open(lg, "w", encoding="utf-8") as f:
    for i in range(4000):
        f.write(json.dumps({"ts": i, "q": "x" * 200}, ensure_ascii=False) + "\n")
assistant.CHAT_LOG = lg
assistant.CHAT_LOG_MAX = 200_000
assistant.chat_log_prune()
size = os.path.getsize(lg)
ck(size <= 200_000, "لاگ چت پس از هرس زیر سقف است (%d بایت)" % size)
last = open(lg, encoding="utf-8").read().splitlines()[-1]
json.loads(last)
ck(True, "آخرین خط لاگ پس از چرخش JSON سالم است")

print("ANTISPAM v275 PASS %d" % n)
