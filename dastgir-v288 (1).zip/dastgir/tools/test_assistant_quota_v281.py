#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v281 — رگرسیون «کاربر اعتبار/اشتراک دارد ولی سایت می‌گوید تمام شد».

سه دفاع واقعی را قفل می‌کند (نه نمایشی):
  ۱) reset سراسری [hidden] در main.css — چون display:flex روی .ai-quotaend
     بر قاعدهٔ UA یعنی [hidden]{display:none} غلبه می‌کرد و بنر «سهمیه تمام
     شد» را حتی با اعتبارِ باقی‌مانده همیشه نمایش می‌داد.
  ۲) بنر پایان سهمیه در ui.py با ویژگی hidden رندر می‌شود و assist.js فقط بر
     اساس remaining واقعی وضعیت آن را عوض می‌کند (پنهان وقتی rem>0).
  ۳) هر اشتراک زنده در tier_of سطح واقعی‌اش را می‌گیرد (plus/pro) و هرگز
     «بدون اشتراک» نمی‌شود — حتی با اسلاگ سفارشی/ناسشناخته.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))

import assistant as A  # noqa: E402

FAILS = []


def ck(cond, label):
    print(("  ✓ " if cond else "  ✗ ") + label)
    if not cond:
        FAILS.append(label)


def main():
    print("== v281: بنر سهمیه فقط با اعتبارِ صفر، و اشتراک زنده هرگز رایگان نیست ==")

    css = (ROOT / "site" / "assets" / "css" / "main.css").read_text(encoding="utf-8")
    ck(re.search(r"\[hidden\]\s*\{\s*display:\s*none\s*!important", css) is not None,
       "main.css: reset سراسری [hidden]{display:none!important} حضور دارد")

    ui = (ROOT / "server" / "ui.py").read_text(encoding="utf-8")
    ck("data-ai-quotaend hidden" in ui,
       "ui.py: بنر پایان سهمیه به‌صورت hidden رندر می‌شود")

    live = (ROOT / "site" / "assets" / "js" / "live.js").read_text(encoding="utf-8")
    ck("'/assistant'" in live.split("SKIP_PATHS")[1].split(";")[0],
       "live.js: /assistant در SKIP_PATHS — سواپ خاموش <main> حالت چت/سهمیه را برنمی‌گرداند")
    ck("live.js?v156" in ui, "ui.py: live.js?v156 (کش‌شکنِ تغییر SKIP_PATHS)")

    js = (ROOT / "site" / "assets" / "js" / "assist.js").read_text(encoding="utf-8")
    ck("else if (rem > 0) quotaRestored();" in js and "quotaEndEl.hidden = true" in js,
       "assist.js: با remaining>0 بنر پنهان می‌شود (quotaRestored)")
    ck("if (r.quota > 0 && rem === 0) quotaEnded();" in js,
       "assist.js: بنر فقط وقتی remaining==0 ظاهر می‌شود")

    # نگاشت سطح از اشتراک زنده — اسلاگ‌های استاندارد و سفارشی
    ck(A._tier_from_sub({"plan_slug": "plus"}) == "plus", "اسلاگ plus → plus")
    ck(A._tier_from_sub({"plan_slug": "pro"}) == "pro", "اسلاگ pro → pro")
    ck(A._tier_from_sub({"plan_slug": "gold", "planname": "طلایی"}) == "plus",
       "اسلاگ سفارشیِ پولی → plus (هرگز رایگان)")
    ck(A._tier_from_sub({"plan_slug": "vip-pro", "planname": "ویژهٔ من"}) == "pro",
       "اسلاگ/نام دارای «ویژه/pro» → pro")
    ck(A._tier_from_sub({"plan_slug": "", "planname": ""}) == "plus",
       "اشتراک زندهٔ بدون پلن قابل‌شناسایی → plus (نه رایگان)")

    # برچسب سطح: هیچ‌وقت «بدون اشتراک» برای plus/pro
    ck(A.TIER_LABEL["plus"] != "بدون اشتراک" and A.TIER_LABEL["pro"] != "بدون اشتراک",
       "برچسب plus/pro برابر «بدون اشتراک» نیست")

    print()
    if FAILS:
        print(f"  {len(FAILS)} مورد ناموفق:")
        for f in FAILS:
            print("   -", f)
        return 1
    print("  همه موفق — v281 quota/subscription regression PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
