#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v282 — ربات بله: دسترسی کامل به پنل مدیریت (دستور مدیر).

  · خواندن «همهٔ» بخش‌های پنل بدون محدودیت: panel_sections + panel_read
    (فوری، بدون «بله») و مسیر قطعی چت «پنل <بخش> [id|عبارت]».
  · تغییرات فقط از چت مدیر: گیت is_team_chat اولِ handle_text می‌ماند و
    ابزارهای نوشتن (subscription_set / owner_moderate / …) فقط همان‌جا اجرا
    می‌شوند.
  · حلقهٔ agent دستیار همهٔ IMMEDIATE_TOOLS را زنجیر می‌کند (نه فقط code_*).
"""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))
os.environ["BZ_DATA_DIR"] = tempfile.mkdtemp(prefix="v282-")

import db                    # noqa: E402
import adminbot_content as CT  # noqa: E402

FAILS = []


def ck(cond, label):
    print(("  ✓ " if cond else "  ✗ ") + label)
    if not cond:
        FAILS.append(label)


def main():
    print("== v282: دسترسی کامل ربات پنل‌مدیریت (خواندن همه‌جا، تغییر با دستور مدیر) ==")
    db.init()
    o = db.owner_by_phone("09121112233", create=True)
    biz = db.save_business({"name": "نانوایی تست", "owner_id": o["id"],
                            "phone": "09121112233", "cat_slug": "نانوایی"})
    bid = biz["id"] if isinstance(biz, dict) else biz

    # --- ثبت ابزارها
    for name in ("panel_read", "panel_sections", "subscription_set", "owner_moderate"):
        ck(name in CT.TOOLS, f"ابزار {name} در TOOLS ثبت است")
    ck("panel_read" in CT.IMMEDIATE_TOOLS and "panel_sections" in CT.IMMEDIATE_TOOLS,
       "خواندن‌ها فوری‌اند (IMMEDIATE_TOOLS) — «بله» نمی‌خواهند")
    ck("subscription_set" not in CT.IMMEDIATE_TOOLS,
       "نوشتن (subscription_set) فوری نیست")

    # --- همهٔ بخش‌ها خواندنی‌اند
    txt = CT.panel_sections_text()
    ck(len(CT.PANEL_READERS) >= 39 and all(k in txt for k in CT.PANEL_READERS),
       f"panel_sections همهٔ {len(CT.PANEL_READERS)} بخش را فهرست می‌کند")
    unreadable = [k for k in CT.PANEL_READERS
                  if "خوانده نشد" in CT.panel_read(k) or not CT.panel_read(k).strip()]
    ck(not unreadable, f"همهٔ بخش‌ها بدون خطا خوانده شدند ({unreadable or 'ok'})")

    # --- جزئیات و جست‌وجو
    ck("نانوایی تست" in CT.panel_read("businesses", rid=bid),
       "panel_read(businesses, id) جزئیات کامل کسب‌وکار را می‌دهد")
    ck("ai_quota_free" in CT.panel_read("settings", q="ai"),
       "panel_read(settings, q=ai) کلیدهای هوش را فیلتر می‌کند")

    # --- مسیر قطعی چت «پنل …»
    r = CT.panel_read_cmd("کسب و کارها نانوایی")
    ck("[businesses]" in r and "نانوایی تست" in r,
       "«پنل کسب و کارها نانوایی» → بخش درست + جست‌وجو قورت داده نشد")
    r = CT.panel_read_cmd("صفحات about")
    ck("[pages]" in r and "body:" in r, "«پنل صفحات about» → متن کامل صفحه")
    r = CT.panel_read_cmd("مشتریان 09121112233")
    ck("[customers]" in r and "شناسه نیست" not in r,
       "شمارهٔ ۱۱ رقمی = جست‌وجو، نه شناسهٔ ردیف")
    ck("شناخته نشد" in CT.panel_read_cmd("بخش‌خیالی"),
       "بخش ناشناخته → راهنمای فهرست بخش‌ها")

    # --- چرخهٔ کامل ابزار: parse → precheck → execute
    t, a = CT.parse_tool_call({"name": "panel_read", "args": {"section": "orders"}})
    ck(t == "panel_read" and CT.tool_precheck(t, a)[0],
       "panel_read: parse+precheck سالم")
    ok, msg = CT.tool_execute(t, a)
    ck(ok and "[orders]" in msg, "panel_read: execute خروجی واقعی می‌دهد")
    t2, a2 = CT.parse_tool_call({"name": "panel_read", "args": {"section": "خیالی"}})
    bad, why = CT.tool_precheck(t2, a2)
    ck(not bad and why == "section" and "panel_sections" in CT.fail_text(t2, why),
       "بخش نامعتبر → رد با راهنمای فهرست بخش‌ها")

    # --- نوشتن: اشتراک (قبلاً از چت ممکن نبود)
    t3, a3 = CT.parse_tool_call({"name": "subscription_set",
                                 "args": {"biz_id": bid, "plan_slug": "pro", "months": 3}})
    ok, msg = CT.tool_execute(t3, a3)
    s = db.subscription_of(bid)
    ck(ok and s and s["plan_slug"] == "pro" and s["is_live"],
       "subscription_set: اشتراک pro واقعاً فعال شد")
    bad, why = CT.tool_precheck(*CT.parse_tool_call(
        {"name": "subscription_set", "args": {"biz_id": bid, "plan_slug": "gold"}}))
    ck(not bad and why == "plan", "پلن نامعتبر → رد (plan)")

    # --- نوشتن: مسدود/آزادسازی مالک
    ok, _m = CT.tool_execute("owner_moderate",
                             {"owner": "09121112233", "action": "block"})
    ck(ok and db.owner_by_id(o["id"])["status"] == "blocked",
       "owner_moderate: مسدودسازی با شماره واقعی اعمال شد")
    ok, _m = CT.tool_execute("owner_moderate",
                             {"owner": str(o["id"]), "action": "unblock"})
    ck(ok and db.owner_by_id(o["id"])["status"] == "active",
       "owner_moderate: آزادسازی با شناسه واقعی اعمال شد")

    # --- حلقهٔ agent + پرامپت (دسترسی کامل، بدون محدودیت)
    asrc = (ROOT / "server" / "assistant.py").read_text(encoding="utf-8")
    ck("tool[\"name\"] in adminbot_content.IMMEDIATE_TOOLS" in asrc,
       "assistant.py: حلقهٔ agent همهٔ ابزارهای فوری (از جمله panel_read) را زنجیر می‌کند")
    ck("panel_read {section" in asrc and "panel_sections {}" in asrc,
       "ADMIN_PROMPT: ابزارهای خواندن پنل مستند شده‌اند")
    ck("subscription_set {biz_id" in asrc and "owner_moderate {owner" in asrc,
       "ADMIN_PROMPT: دو ابزار نوشتن تازه مستند شده‌اند")
    ck("بدون هیچ محدودیتی" in asrc and "رازها (توکن/کلید/رمز)، دیتای کاربران" not in asrc,
       "ADMIN_PROMPT: ممنوعیت قدیمیِ دادهٔ کاربران برداشته شد (دستور مدیر)")

    # --- گیت امنیت: فقط چت مدیر
    bsrc = (ROOT / "server" / "adminbot.py").read_text(encoding="utf-8")
    ck("if not is_team_chat(chat_id):\n            return DENIED" in bsrc,
       "adminbot.py: گیت is_team_chat هنوز اولِ handle_text است (فقط دستور مدیر)")
    ck("CT.panel_read_cmd(_rest(text))" in bsrc,
       "adminbot.py: دستور قطعی «پنل» به panel_read_cmd وصل است")
    ck("پنل <بخش>" in bsrc, "راهنمای ربات: دستور «پنل» فهرست شده")

    # --- snapshot به مدل یادآوری می‌کند
    inv = CT.content_inventory()
    ck("panel_read" in inv and "panel_sections" in inv,
       "content_inventory: راهنمای panel_read در تصویر زندهٔ سایت هست")

    print()
    if FAILS:
        print(f"  {len(FAILS)} مورد ناموفق:")
        for f in FAILS:
            print("   -", f)
        return 1
    print(f"  همه موفق — v282 panel-access: {39 + 12} checks PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
