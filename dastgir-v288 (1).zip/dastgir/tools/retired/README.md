# آزمون‌های بازنشسته

- `test_onboarding_v156.py` — فرم تک‌صفحه‌ای `/submit` را می‌آزمود که با ویزارد مرحله‌ای `/register-business` جایگزین شد.
  پوشش معادل: `tools/test_register_web_*.py` (ماندگاری همهٔ فیلدها، ساعت کاری، تصاویر، مرورگر) و `tools/test_browser.py`.
