#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v280 — فاز ۶ امنیت: پین‌های سراسری IDOR (G25).

دستور مدیر: هر مسیر مالکیت‌دار باید در برابر حسابِ دیگر ۴۰۳/۴۰۴ بدهد —
نه با ادعا، با تست زندهٔ cross-account:
۱) GET /me/order/<id> — مشتری دیگر؛
۲) POST /my/order/<id>/cancel و تغییر وضعیت — دکان‌دار دیگر؛
۳) POST /my/booking/<id> — دکان‌دار دیگر؛
۴) POST /my/trash/<id>/restore — دکان‌دار دیگر؛
۵) POST /my/broadcast/fulfill — دکان‌دار دیگر روی «خبرم کن» رقیب.
"""
import os
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="idor280-")
os.environ["BZ_DATA_DIR"] = TMP
sys.path.insert(0, str(ROOT / "server"))

import db          # noqa: E402

db.init()
n = 0


def ck(ok, label):
    global n
    assert ok, label
    n += 1
    print("  ✓", label)


# ---------- داده: دو دکان‌دار، دو مشتری، منابع متعلق به دکان‌دار ۱ ----------
con = db.connect()
con.execute("INSERT INTO categories(slug,name) VALUES('t280','آزمون')")
con.execute("INSERT INTO owners(phone) VALUES('09120001280')")
con.execute("INSERT INTO owners(phone) VALUES('09120002280')")
con.commit()
O1 = con.execute("SELECT id FROM owners WHERE phone='09120001280'").fetchone()[0]
O2 = con.execute("SELECT id FROM owners WHERE phone='09120002280'").fetchone()[0]
con.execute("INSERT INTO businesses(name,cat_slug,slug,status,owner_id) "
            "VALUES('دکان یک','t280','b280a','published',?)", (O1,))
con.execute("INSERT INTO businesses(name,cat_slug,slug,status,owner_id) "
            "VALUES('دکان دو','t280','b280b','published',?)", (O2,))
con.commit(); con.close()
B1, B2 = 1, 2
c1 = db.customer_by_phone("09120003280", create=True)
c2 = db.customer_by_phone("09120004280", create=True)
i1 = db.save_item({"biz_id": B1, "kind": "product", "title": "کالای دکان یک",
                   "price": 100, "price_type": "fixed", "available": 1})

con = db.connect()
con.execute("INSERT INTO orders(biz_id,customer_id,name,phone,status,cancel_requested) "
            "VALUES(?,?,?,?,'confirmed',1)", (B1, c1["id"], "مشتری", "09120003280"))
ORD_A = con.execute("SELECT last_insert_rowid()").fetchone()[0]
con.execute("INSERT INTO orders(biz_id,customer_id,name,phone,status,cancel_requested) "
            "VALUES(?,?,?,?,'confirmed',1)", (B1, c1["id"], "مشتری", "09120003280"))
ORD_B = con.execute("SELECT last_insert_rowid()").fetchone()[0]
con.commit(); con.close()
k1 = db.add_booking(B1, "نوبت‌گیر", "09120003280", "1405/06/25", "10:00")
okk, _m = db.stock_request_add(B1, i1, c1["id"])
SR1 = db._one("SELECT id FROM stock_requests ORDER BY id DESC LIMIT 1")["id"]
db.delete_item(i1)   # جریان واقعی حذف => ردیف زباله با snapshot کامل
T1 = db._one("SELECT id FROM trash ORDER BY id DESC LIMIT 1")["id"]

tok_o1 = db.session_new(O1)
tok_o2 = db.session_new(O2)
tok_c1 = db.customer_session_new(c1["id"])
tok_c2 = db.customer_session_new(c2["id"])

# ---------- سرور زنده ----------
import app  # noqa: E402
srv = app.make_server(8100)
threading.Thread(target=srv.serve_forever, daemon=True).start()
time.sleep(0.4)


def req(method, path, data=None, cookie=None, ident="203.0.113.95"):
    body = urllib.parse.urlencode(data, encoding="utf-8").encode() if data else None
    headers = {"X-Forwarded-For": ident}
    if cookie:
        headers["Cookie"] = cookie
    r = urllib.request.Request("http://127.0.0.1:8100" + path, data=body,
                               headers=headers, method=method)

    class NoRedir(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None
    op = urllib.request.build_opener(NoRedir)
    try:
        with op.open(r, timeout=10) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


CO1 = "bzv2_sess=" + tok_o1
CO2 = "bzv2_sess=" + tok_o2
CC1 = "bzv2_cust=" + tok_c1
CC2 = "bzv2_cust=" + tok_c2

# ---------- 1) /me/order/<id> ----------
st_a, body_a = req("GET", "/me/order/%d" % ORD_A, cookie=CC2)
st_b, body_b = req("GET", "/me/order/%d" % ORD_A, cookie=CC1)
ck(st_a in (403, 404) and b"09120003280" not in body_a,
   "سفارش مشتری ۱ برای مشتری ۲ => ۴۰۳/۴۰۴ بدون نشت")
ck(st_b == 200, "مالک سفارش صفحهٔ خودش را می‌بیند (۲۰۰)")

# ---------- 2) لغو/وضعیت سفارش — دکان‌دار دیگر ----------
st, _b = req("POST", "/my/order/%d/cancel" % ORD_A, {"action": "approve"}, cookie=CO2)
ck(st == 403, "لغو سفارش دکان ۱ توسط دکان‌دار ۲ => ۴۰۳")
ck(db.order(ORD_A)["status"] == "confirmed", "وضعیت سفارش دست‌نخورده ماند")
st, _b = req("POST", "/my/order/%d" % ORD_A, {"status": "done"}, cookie=CO2)
ck(db.order(ORD_A)["status"] == "confirmed",
   "تغییر وضعیت سفارش توسط دکان‌دار دیگر بی‌اثر است")
st, _b = req("POST", "/my/order/%d/cancel" % ORD_B, {"action": "approve"}, cookie=CO1)
ck(st == 303, "دکان‌دار خودش لغو را تأیید می‌کند (۳۰۳)")

# ---------- 3) نوبت — دکان‌دار دیگر ----------
st, _b = req("POST", "/my/booking/%d" % k1, {"status": "done"}, cookie=CO2)
ck(db._one("SELECT status FROM bookings WHERE id=?", (k1,))["status"] == "new",
   "نوبت دکان ۱ توسط دکان‌دار ۲ تغییر نمی‌کند")
st, _b = req("POST", "/my/booking/%d" % k1, {"status": "confirmed"}, cookie=CO1)
ck(db._one("SELECT status FROM bookings WHERE id=?", (k1,))["status"] == "confirmed",
   "دکان‌دار خودش نوبت را به‌روز می‌کند")

# ---------- 4) سطل بازیافت — دکان‌دار دیگر ----------
st, _b = req("POST", "/my/trash/%d/restore" % T1, {}, cookie=CO2)
ck(db._one("SELECT COUNT(*) c FROM trash WHERE id=?", (T1,))["c"] == 1,
   "بازیافت زبالهٔ دکان ۱ توسط دکان‌دار ۲ ممکن نیست")
st, _b = req("POST", "/my/trash/%d/restore" % T1, {}, cookie=CO1)
ck(db._one("SELECT COUNT(*) c FROM trash WHERE id=?", (T1,))["c"] == 0,
   "دکان‌دار خودش زباله‌اش را بازیابی می‌کند")

# ---------- 5) «خبرم کن» — fulfill توسط رقیب ----------
st, _b = req("POST", "/my/broadcast/fulfill", {"rid": str(SR1)}, cookie=CO2)
ck(db._one("SELECT status FROM stock_requests WHERE id=?", (SR1,))["status"] == "open",
   "fulfill درخواست دکان ۱ توسط دکان‌دار ۲ بی‌اثر است")
st, _b = req("POST", "/my/broadcast/fulfill", {"rid": str(SR1)}, cookie=CO1)
ck(db._one("SELECT status FROM stock_requests WHERE id=?", (SR1,))["status"] == "fulfilled",
   "دکان‌دار خودش درخواست را fulfill می‌کند")

print("IDOR PINS v280 PASS %d" % n)
