#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""audit_crawl.py — v286 audit phase 1: crawl every reachable route in three
roles (public / owner / customer / admin) and report anomalies.

Usage: BZ_DATA_DIR=/tmp/audit-data python3 tools/audit_crawl.py
Expects a live server on http://127.0.0.1:8080 (override with BZ=...).
"""
import os, re, sys, json, html.parser, urllib.request, urllib.error, urllib.parse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "server"))
DATA = os.environ.get("BZ_DATA_DIR", "/tmp/audit-data")
os.environ["BZ_DATA_DIR"] = DATA
BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
import db

BLOCK = ("logout", "delete", "/kill", "clear", "reset", "/gc", "restore",
         "answer-clear", "dl=1", "remove", "cancel", "ban", "lift")

class LinkGrab(html.parser.HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links = []
    def handle_starttag(self, tag, attrs):
        if tag == "a":
            for k, v in attrs:
                if k == "href" and v:
                    self.links.append(v)

def get(url, cookie=None, timeout=20):
    req = urllib.request.Request(url, headers={"Cookie": cookie} if cookie else {})
    try:
        r = urllib.request.urlopen(req, timeout=timeout)
        return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except Exception as e:
        return 0, str(e).encode()

def blocked(path):
    p = path.lower()
    return any(b in p for b in BLOCK)

report = {"errors5xx": [], "notfound": [], "conn": [], "visited": 0}

def visit(path, cookie=None, role="public", note=""):
    if blocked(path):
        return None
    url = BASE + path
    st, body = get(url, cookie)
    report["visited"] += 1
    if st >= 500:
        report["errors5xx"].append((role, path, st, note))
    elif st == 0:
        report["conn"].append((role, path, note))
    elif st == 404:
        report["notfound"].append((role, path, note))
    return st, body

# ---------- identities ----------
cust = db.customer_by_phone("09121110001", create=True)
owner = db.owner_by_phone("09121110001", create=True)
biz = db._rows("SELECT id, slug FROM businesses LIMIT 1")[0]
db.set_business_owner(biz["id"], owner["id"])
COOKIES = {
    "admin": "bzv2_admin=" + db.admin_session_new(),
    "owner": "bzv2_sess=" + db.session_new(owner["id"]),
    "customer": "bzv2_cust=" + db.customer_session_new(cust["id"]),
}

# ---------- 1. public BFS crawl ----------
seen = set()
queue = ["/"]
PUBLIC_START = ["/", "/businesses", "/map", "/pricing", "/events", "/blog",
                "/catalog", "/rules", "/about", "/contact", "/assistant",
                "/login", "/register-business", "/b/" + biz["slug"]]
queue = PUBLIC_START[:]
while queue:
    path = queue.pop(0)
    if path in seen or blocked(path):
        continue
    seen.add(path)
    res = visit(path, None, "public")
    if not res:
        continue
    st, body = res
    if st == 200 and b"<html" in body[:2000].lower():
        grab = LinkGrab()
        try:
            grab.feed(body.decode("utf-8", "ignore"))
        except Exception:
            pass
        for href in grab.links:
            if href.startswith("/") and not href.startswith("//"):
                p = urllib.parse.urlparse(href).path
                q = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
                full = p + (("?" + urllib.parse.urlencode({k: v[0] for k, v in q.items()})) if q else "")
                if full not in seen and len(seen) < 400:
                    queue.append(full)

# ---------- 2. role routes extracted from source ----------
lits = set()
for root_dir, _, files in os.walk(os.path.join(ROOT, "server")):
    for f in files:
        if not f.endswith(".py"):
            continue
        src = open(os.path.join(root_dir, f), encoding="utf-8").read()
        for m in re.findall(r'"(/(?:panel|my|me)/[A-Za-z0-9\-_/]*)"', src):
            lits.add(m)

subs = {
    "<id>": str(biz["id"]), "<slug>": biz["slug"], "<qid>": "1", "<tid>": "1",
}
def concrete(p):
    out = p
    for k, v in subs.items():
        out = out.replace(k, v)
    return out

role_prefix = {"/panel": "admin", "/my": "owner", "/me": "customer"}
extra = {
    "admin": COOKIES["admin"], "owner": COOKIES["owner"],
    "customer": COOKIES["customer"],
}
dynamic = re.compile(r"<\w+>")
for p in sorted(lits):
    if dynamic.search(p):
        continue   # only literal-safe routes; dynamic ones covered below
    role = next((v for k, v in role_prefix.items() if p.startswith(k)), None)
    if not role:
        continue
    visit(p, extra[role], role, "src-literal")

# dynamic routes with seeded ids — a curated sample
sample = {
    "admin": ["/panel/business/1", "/panel/post/1", "/panel/event/1",
              "/panel/owner/1", "/panel/customer/1", "/panel/ticket/1",
              "/panel/review/1", "/panel/item/1"],
    "owner": ["/my/business/1", "/my/questions", "/my/qr", "/my/assistant",
              "/my/ticket/1", "/my/story", "/my/orders"],
    "customer": ["/me/chat/1", "/me/order/1", "/me/booking/1", "/me/favorites"],
}
for role, paths in sample.items():
    for p in paths:
        visit(p, extra[role], role, "sample")

# ---------- 3. server log scan ----------
log = open(os.path.join(DATA, "srv.log"), encoding="utf-8", errors="ignore").read()
tracebacks = len(re.findall(r"Traceback \(most recent call last\)", log))

print(json.dumps({
    "visited": report["visited"],
    "errors5xx": report["errors5xx"],
    "notfound_count": len(report["notfound"]),
    "notfound": report["notfound"][:40],
    "conn_fail": report["conn"],
    "server_tracebacks": tracebacks,
}, ensure_ascii=False, indent=1))
