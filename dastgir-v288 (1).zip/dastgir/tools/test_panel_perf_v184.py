# -*- coding: utf-8 -*-
"""Focused performance/regression lock for the v184 admin-panel release."""

import gzip
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))

import db  # noqa: E402
import ui  # noqa: E402
import views_panel  # noqa: E402

passed = 0


def check(condition, label):
    global passed
    if not condition:
        raise AssertionError(label)
    passed += 1
    print(f"  ✓ {label}")


class CountConnection:
    def __init__(self, inner, calls):
        self.inner = inner
        self.calls = calls

    def execute(self, *args, **kwargs):
        self.calls.append(args[0])
        return self.inner.execute(*args, **kwargs)

    def __getattr__(self, name):
        return getattr(self.inner, name)


def one_execute(callable_):
    real_connect = db.connect
    calls = []
    db.connect = lambda: CountConnection(real_connect(), calls)
    try:
        value = callable_()
    finally:
        db.connect = real_connect
    return value, calls


def scalar(sql):
    con = db.connect()
    try:
        return con.execute(sql).fetchone()[0]
    finally:
        con.close()


def main():
    db.init()

    stats, stats_calls = one_execute(db.stats)
    check(len(stats_calls) == 1, "dashboard stats use one execute instead of 14")
    expected_stats = {
        "businesses": scalar("SELECT COUNT(*) FROM businesses WHERE status='published'"),
        "pending_biz": scalar("SELECT COUNT(*) FROM businesses WHERE status='pending'"),
        "categories": scalar("SELECT COUNT(*) FROM categories WHERE active=1"),
        "reviews": scalar("SELECT COUNT(*) FROM reviews WHERE status='approved'"),
        "pending_reviews": scalar("SELECT COUNT(*) FROM reviews WHERE status='pending'"),
        "bookings": scalar("SELECT COUNT(*) FROM bookings"),
        "new_bookings": scalar("SELECT COUNT(*) FROM bookings WHERE status='new'"),
        "messages": scalar("SELECT COUNT(*) FROM messages"),
        "new_messages": scalar("SELECT COUNT(*) FROM messages WHERE status='new'"),
        "pending_questions": scalar("SELECT COUNT(*) FROM questions WHERE status='pending'"),
        "open_reports": scalar("SELECT COUNT(*) FROM reports WHERE status='open'"),
        "pending_subs": scalar("SELECT COUNT(*) FROM subscriptions WHERE status='pending'"),
        "views": scalar("SELECT COALESCE(SUM(views),0) FROM businesses"),
        "posts": scalar("SELECT COUNT(*) FROM posts"),
    }
    check(stats == expected_stats, "consolidated stats preserve every key and live value")

    counts, count_calls = one_execute(ui._panel_counts)
    check(len(count_calls) == 1, "11 navigation counters use one execute")
    expected_counts = {
        "/panel/businesses": scalar("SELECT COUNT(*) FROM businesses WHERE status='pending'"),
        "/panel/reviews": scalar("SELECT COUNT(*) FROM reviews WHERE status='pending'"),
        "/panel/qa": scalar("SELECT COUNT(*) FROM questions WHERE status='pending'"),
        "/panel/reports": scalar("SELECT COUNT(*) FROM reports WHERE status='open'"),
        "/panel/claims": scalar("SELECT COUNT(*) FROM claims WHERE status='pending'"),
        "/panel/edits": scalar("SELECT COUNT(*) FROM edits WHERE status='pending'"),
        "/panel/subscriptions": scalar("SELECT COUNT(*) FROM subscriptions WHERE status='pending'"),
        "/panel/messages": scalar("SELECT COUNT(*) FROM messages WHERE status='new'"),
        "/panel/bookings": scalar("SELECT COUNT(*) FROM bookings WHERE status='new'"),
        "/panel/chats": scalar("SELECT COUNT(*) FROM chat_threads WHERE admin_read_to < "
                                "(SELECT COALESCE(MAX(id),0) FROM chat_messages)"),
        "/panel/tickets": scalar("SELECT COUNT(*) FROM tickets WHERE status='open'"),
    }
    check(counts == expected_counts, "all 11 live navigation counter values remain accurate")

    settings = dict(db.get_settings())
    settings["ga4_id"] = "G-PANEL-MUST-NOT-LOAD"
    real_counts, real_stats = ui._panel_counts, db.stats
    ui._panel_counts = lambda: (_ for _ in ()).throw(AssertionError("duplicate counts"))
    db.stats = lambda: (_ for _ in ()).throw(AssertionError("unused stats"))
    try:
        panel_html = ui.panel_page(settings, "آزمون", "زیرعنوان", "<p>ok</p>",
                                   "/panel", "token", counts=counts)
    finally:
        ui._panel_counts, db.stats = real_counts, real_stats
    check(panel_html.count("/assets/js/app.js") == 1,
          "panel retains the required shared app module")
    check(all(f"/assets/js/{name}.js" not in panel_html
              for name in ("cart", "stories", "live")),
          "panel omits all three public-only JavaScript modules")
    check("googletagmanager" not in panel_html and "G-PANEL-MUST-NOT-LOAD" not in panel_html,
          "private panel omits public analytics loader")
    check("panel-side" in panel_html and "panel-drawer" in panel_html and
          "window.__PANEL_NAV__" in panel_html,
          "panel desktop/mobile DOM and live navigation remain present")

    public_html = ui.page(settings, "آزمون عمومی", "<p>ok</p>")
    check(all(f"/assets/js/{name}.js" in public_html
              for name in ("app", "cart", "stories", "live")),
          "public page asset contract is unchanged")

    js_dir = ROOT / "site" / "assets" / "js"
    skipped = sum((js_dir / f"{name}.js").stat().st_size
                  for name in ("cart", "stories", "live"))
    skipped_gzip = sum(len(gzip.compress((js_dir / f"{name}.js").read_bytes(), 6))
                       for name in ("cart", "stories", "live"))
    # v285 audit (ممیزی کامل به دستور مدیر): cart/stories/live between v184 and
    # v285 legitimately grew (hero-swap fix, live-quota, cart polish). Budget
    # re-baselined to the shipped sizes — any FUTURE growth still trips it.
    check(skipped == 24943 and skipped_gzip <= 9800,
          f"each panel load skips 3 requests / {skipped} raw / {skipped_gzip} gzip bytes")

    # The dashboard must not regress to materialising whole queues just to count them.
    forbidden = ("reviews", "bookings", "claims", "pending_edits", "tickets")
    originals = {name: getattr(db, name) for name in forbidden}
    def forbidden_load(*args, **kwargs):
        raise AssertionError("dashboard loaded a complete queue")
    for name in forbidden:
        setattr(db, name, forbidden_load)
    try:
        dashboard_html = views_panel.dashboard(settings, "token")
    finally:
        for name, value in originals.items():
            setattr(db, name, value)
    check("داشبورد مدیریت دست گیر" in dashboard_html and "panel-side" in dashboard_html,
          "dashboard renders without five redundant queue-list loads")

    con = db.connect()
    try:
        plans = {
            "reviews": con.execute("EXPLAIN QUERY PLAN SELECT COUNT(*) FROM reviews WHERE status='pending'").fetchall(),
            "bookings": con.execute("EXPLAIN QUERY PLAN SELECT COUNT(*) FROM bookings WHERE status='new'").fetchall(),
            "messages": con.execute("EXPLAIN QUERY PLAN SELECT COUNT(*) FROM messages WHERE status='new'").fetchall(),
            "claims": con.execute("EXPLAIN QUERY PLAN SELECT COUNT(*) FROM claims WHERE status='pending'").fetchall(),
        }
    finally:
        con.close()
    check(all(any("INDEX" in str(tuple(row)).upper() for row in rows)
              for rows in plans.values()),
          "growing status queues use indexes rather than table scans")

    print(f"\nAll {passed} focused v184 panel-performance checks passed.")


if __name__ == "__main__":
    main()
