#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Live E2E for v285 round — fresh server, fresh data dir, real HTTP."""
import os, sys, json, time, socket, subprocess, tempfile, urllib.request, urllib.error

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = 8471 + (os.getpid() % 100)
DATA = tempfile.mkdtemp(prefix="v285-live-")
BASE = "http://127.0.0.1:%d" % PORT
ok = fail = 0
def check(name, cond, detail=""):
    global ok, fail
    if cond: ok += 1; print("  OK   %s" % name)
    else:    fail += 1; print("  FAIL %s  %s" % (name, detail))

# ---- seed the fresh DB before boot
sys.path.insert(0, os.path.join(ROOT, "server"))
os.environ["BZ_DATA_DIR"] = DATA
import db
db.init()
BID = db.save_business({"name": "کافه زنده", "slug": "livebiz", "cat_slug": "food",
                        "city": "نجف‌آباد", "slogan": "طعم خوب، حال خوب", "status": "published"})
db.save_post({"title": "خبر ویدیویی", "slug": "live-news", "body": "متن خبر",
              "cover": "", "video": "", "status": "published"}, None)
db.set_setting("blog_enabled", "1")
db.save_cityevent({"biz_id": BID, "title": "رویداد زنده", "date": "1404-06-20",
                   "image": "", "video": ""})
ADMIN = db.admin_session_new()
MEDIA_FILES = []
cust = db.customer_by_phone("09120000001", create=True)
owner = db.owner_by_phone("09120000001", create=True)
db.set_business_owner(BID, owner["id"])

env = dict(os.environ, PORT=str(PORT), BZ_DATA_DIR=DATA)
log = open(os.path.join(DATA, "srv.log"), "wb")
proc = subprocess.Popen([sys.executable, os.path.join(ROOT, "run.py")],
                        env=env, stdout=log, stderr=subprocess.STDOUT, cwd=ROOT)
for _ in range(80):
    try:
        socket.create_connection(("127.0.0.1", PORT), 0.25).close(); break
    except OSError:
        time.sleep(0.25)
else:
    print(open(os.path.join(DATA, "srv.log")).read()[-2000:]); sys.exit("server never bound")
logtxt = open(os.path.join(DATA, "srv.log")).read()
if "Address already in use" in logtxt:
    proc.kill(); sys.exit("STALE-SERVER TRAP: bind failed")

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None
OPENER = urllib.request.build_opener(NoRedirect)

def req(path, headers=None, data=None, method=None):
    r = urllib.request.Request(BASE + path, data=data, method=method,
                               headers=headers or {})
    try:
        resp = OPENER.open(r, timeout=15)
        return resp.status, dict(resp.headers), resp.read()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read()

try:
    print("== public pages ==")
    st, h, b = req("/")
    check("home 200", st == 200)
    check("security headers", h.get("X-Frame-Options") == "DENY"
          and "nosniff" in (h.get("X-Content-Type-Options") or "")
          and "aparat.com" in (h.get("Content-Security-Policy") or ""))
    st, h, b = req("/pricing")
    t = b.decode("utf-8", "ignore")
    check("pricing 200", st == 200)
    check("pricing AI line + trust", "پیام هوشمند" in t and "plan-trust" in t and "پرداخت امن" in t)
    st, h, b = req("/rules")
    t = b.decode("utf-8", "ignore")
    check("rules 200 + مادهٔ ۱", st == 200 and "مادهٔ ۱" in t)
    st, h, b = req("/b/livebiz")
    t = b.decode("utf-8", "ignore")
    check("business page 200 + slogan", st == 200 and "طعم خوب، حال خوب" in t and "biz-slogan" in t)
    st, h, b = req("/events")
    check("events 200", st == 200)

    print("== static: ETag / 304 / Range 206 / gzip ==")
    st, h, b = req("/assets/css/main.css?v285")
    etag = h.get("ETag")
    check("css 200 + ETag", st == 200 and bool(etag))
    st2, h2, b2 = req("/assets/css/main.css?v285", {"If-None-Match": etag or ""})
    check("conditional 304", st2 == 304)
    # real media file for Range support (video/audio only, by design)
    import uploads
    fake_mp4 = b"\x00\x00\x00\x20ftypmp42" + b"\x00" * 4000
    vpath, vkind, verr = uploads.save_media(fake_mp4, "livetest")
    MEDIA_FILES.append(vpath)
    check("save_media accepts fake mp4", vkind == "video" and not verr, str(verr))
    stv, hv, bv = req(vpath)
    check("media 200 + Accept-Ranges", stv == 200 and hv.get("Accept-Ranges") == "bytes",
          "st=%s ar=%s" % (stv, hv.get("Accept-Ranges")))
    st3, h3, b3 = req(vpath, {"Range": "bytes=0-99"})
    check("range 206 + 100 bytes", st3 == 206 and len(b3) == 100 and b3 == bv[:100],
          "st=%s len=%s cr=%s" % (st3, len(b3), h3.get("Content-Range")))
    st3b, h3b, b3b = req(vpath, {"Range": "bytes=-50"})
    check("suffix range 206 + 50 bytes", st3b == 206 and len(b3b) == 50, "st=%s len=%s" % (st3b, len(b3b)))
    st4, h4, b4 = req(vpath, {"Range": "bytes=99999999-"})
    check("unsatisfiable range 416", st4 == 416, "st=%s" % st4)
    st5, h5, b5 = req("/assets/css/main.css?v285", {"Accept-Encoding": "gzip"})
    check("gzip served", h5.get("Content-Encoding") == "gzip" or st5 == 200)
    st6, h6, b6 = req("/assets/js/live.js")
    check("plain js still 200", st6 == 200 and len(b6) > 100)

    print("== QR svg + rate limit ==")
    st, h, b = req("/qr/livebiz.svg")
    check("qr svg 200", st == 200 and b.startswith(b"<?xml") or b.startswith(b"<svg"), str(b[:40]))
    codes = [req("/qr/livebiz.svg")[0] for _ in range(64)]
    check("qr rate limit kicks in (429)", 429 in codes, "codes tail=%s" % codes[-5:])

    print("== assistant status API ==")
    st, h, b = req("/api/assistant/status")
    j = json.loads(b or b"{}")
    check("status 200 + quota fields", st == 200 and "remaining" in j and "quota" in j, str(j)[:120])

    print("== admin multipart: news with video_url ==")
    boundary = "----v285b"
    def mp(fields):
        body = b""
        for k, v in fields.items():
            body += ("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n"
                     % (boundary, k, v)).encode()
        body += ("--%s--\r\n" % boundary).encode()
        return body
    st, h, b = req("/panel/post/new", {"Cookie": "bzv2_admin=" + ADMIN,
                   "Content-Type": "multipart/form-data; boundary=" + boundary},
                   mp({"title": "خبر با ویدیو", "body": "b", "status": "published",
                       "video_url": "https://www.aparat.com/v/Ab12cd"}), "POST")
    check("admin news save redirect", st in (302, 303) and "ok=" in (h.get("Location") or ""),
          "st=%s loc=%s" % (st, h.get("Location")))
    row = [dict(r) for r in db._rows("SELECT * FROM posts WHERE title='خبر با ویدیو'")]
    check("video_url -> embed stored", row and "aparat.com/video/video/embed" in (row[0]["video"] or ""),
          str(row and row[0]["video"]))
    slug = row[0]["slug"] if row else ""
    st, h, b = req("/blog/" + slug)
    t = b.decode("utf-8", "ignore")
    check("news page renders iframe", st == 200 and "<iframe" in t and "aparat" in t,
          "st=%s slug=%s head=%s" % (st, slug, t[:160].replace("\n", " ")))
    # non-admin must be rejected
    st, h, b = req("/panel/post/new", {"Content-Type": "multipart/form-data; boundary=" + boundary},
                   mp({"title": "هک", "body": "x"}), "POST")
    check("non-admin news save blocked", st in (302, 303, 401, 403) and "هک" not in
          str([dict(r)["title"] for r in db._rows("SELECT title FROM posts")]), "st=%s" % st)

    print("== anon guards ==")
    st, h, b = req("/my/qr")
    check("/my/qr anon redirects", st in (302, 303) and "/login" in (h.get("Location") or "") or st == 200,
          "st=%s loc=%s" % (st, h.get("Location")))
finally:
    proc.terminate()
    try: proc.wait(timeout=5)
    except subprocess.TimeoutExpired: proc.kill()
    for vp in MEDIA_FILES:
        try:
            os.remove(os.path.join(ROOT, vp.lstrip("/").replace("assets/img/uploads", "site/assets/img/uploads", 1)))
        except OSError:
            pass

print("\n== live result: %d OK, %d FAIL == (data=%s)" % (ok, fail, DATA))
sys.exit(1 if fail else 0)
