#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v286 audit (ممیزی کامل به دستور مدیر — فاز ۳: رندر روان‌تر).

Real-browser render battery across the whole site:
  * four viewports — 360/390/412 (قانون سه عرض موبایل) + 1440 desktop
  * Core-Web-Vitals style metrics per page: CLS (layout-shift), LCP,
    domcontentloaded/load timings
  * hard fails: horizontal overflow, same-origin console errors, pageerrors
  * soft reports: small tap targets (<24px), images without alt

Run:  BZ=http://127.0.0.1:8080 BZ_DATA_DIR=<same as server> python3 tools/render_audit.py
Exit code 0 only when every page passes every hard check in every viewport.
"""
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))
BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")

from playwright.sync_api import sync_playwright  # noqa: E402
import db  # noqa: E402

G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
VIEWPORTS = [(360, 844), (390, 844), (412, 915), (1440, 1000)]

# third-party resource noise (enamad hotlink is unreachable from sandboxes)
IGNORE = ("VALIDATE_STATUS", "Shader Error", "GroupMarkerNotSet",
          "software WebGL", "unpkg", "openstreetmap", "tile",
          "net::ERR_INTERNET", "Automatic fallback")

CLS_JS = """() => new Promise(res => setTimeout(() => res(window.__cls || 0), 150))"""

INIT_JS = """
window.__cls = 0; window.__lcp = 0;
try {
  new PerformanceObserver(l => { for (const e of l.getEntries())
    if (!e.hadRecentInput) window.__cls += e.value;
  }).observe({type: 'layout-shift', buffered: true});
} catch (e) {}
try {
  new PerformanceObserver(l => { const es = l.getEntries();
    if (es.length) window.__lcp = es[es.length - 1].startTime;
  }).observe({type: 'largest-contentful-paint', buffered: true});
} catch (e) {}
"""

A11Y_JS = """() => {
  const out = {imgNoAlt:0, smallTap:0, overflow:false};
  document.querySelectorAll('img').forEach(i => { if (!i.hasAttribute('alt')) out.imgNoAlt++; });
  document.querySelectorAll('button, a[href], input[type=checkbox]').forEach(el => {
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return;
    if (el.closest('.leaflet-control-attribution, .gm-style')) return;
    const p = el.parentElement;
    if (el.tagName === 'A' && p && /^(P|SPAN|LI|LABEL|SMALL|TD)$/.test(p.tagName)
        && p.innerText.trim() !== el.innerText.trim()) return;
    if (r.height < 24 || r.width < 24) out.smallTap++;
  });
  out.overflow = document.documentElement.scrollWidth > document.documentElement.clientWidth + 2;
  return out;
}"""


def build_pages():
    """Public + customer + panel pages, seeded from the live DB when possible."""
    biz, posts, cats = [], [], []
    try:
        biz = [r["slug"] for r in
               db._rows("SELECT slug FROM businesses WHERE status='published' LIMIT 2")]
        posts = [r["slug"] for r in db._rows("SELECT slug FROM posts LIMIT 1")]
        cats = [r["slug"] for r in db._rows("SELECT slug FROM categories LIMIT 1")]
    except Exception:
        pass
    pub = ["/", "/businesses", "/categories", "/map", "/nearby", "/blog",
           "/prices", "/contact", "/about", "/rules", "/login", "/favorites",
           "/assistant", "/events", "/submit"]
    if biz:
        pub.append(f"/b/{biz[0]}")
        pub.append(f"/b/{biz[1] if len(biz) > 1 else biz[0]}")
    if cats:
        pub.append(f"/businesses?cat={cats[0]}")
    if posts:
        pub.append(f"/blog/{posts[0]}")
    pages = [("public", u) for u in pub]
    # customer pages (mint a real session)
    try:
        cust = db.customer_by_phone("09120000009", create=True)
        tok = db.customer_session_new(cust["id"])
        pages += [("cust:" + tok, "/me/notifications"), ("cust:" + tok, "/me/profile")]
    except Exception as e:
        print("  (customer session unavailable:", e, ")")
    # panel pages via owner key
    try:
        key = db.owner_token()
        if key:
            pages += [("panel", f"/panel?key={key}"),
                      ("panel", f"/panel/chats?key={key}"),
                      ("panel", f"/panel/businesses?key={key}")]
    except Exception:
        pass
    return pages


def main():
    pages = build_pages()
    print(f"{B}رندر‌سنجی v286 — {len(pages)} صفحه × {len(VIEWPORTS)} ویوپورت{X}")
    fails, warns, rows = [], [], []
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--no-sandbox", "--enable-unsafe-swiftshader"])
        for w, h in VIEWPORTS:
            print(f"\n{B}── ویوپورت {w}×{h} ──{X}")
            for kind, path in pages:
                ctx = browser.new_context(viewport={"width": w, "height": h},
                                          locale="fa-IR",
                                          is_mobile=(w < 500), has_touch=(w < 500))
                if kind.startswith("cust:"):
                    ctx.add_cookies([{"name": "bzv2_cust", "value": kind[5:],
                                      "url": BASE}])
                pg = ctx.new_page()
                errs = []

                def _cerr(m):
                    if m.type != "error" or any(k in m.text for k in IGNORE):
                        return
                    loc = ""
                    try:
                        loc = (m.location or {}).get("url", "") or ""
                    except Exception:
                        pass
                    if loc.startswith("http") and not loc.startswith(BASE):
                        return
                    errs.append(m.text[:90])
                pg.on("console", _cerr)
                pg.on("pageerror", lambda e: errs.append("JS " + str(e)[:90]))
                ctx.add_init_script(INIT_JS)
                try:
                    pg.goto(BASE + path, wait_until="load", timeout=20000)
                    pg.wait_for_timeout(700)
                    timing = pg.evaluate("""() => {
                      const nav = performance.getEntriesByType('navigation')[0] || {};
                      return {dcl: Math.round(nav.domContentLoadedEventEnd||0),
                              load: Math.round(nav.loadEventEnd||0),
                              lcp: Math.round(window.__lcp||0)};
                    }""")
                    cls = pg.evaluate(CLS_JS)
                    a = pg.evaluate(A11Y_JS)
                except Exception as e:
                    fails.append((w, path, f"LOAD {type(e).__name__}: {str(e)[:80]}"))
                    ctx.close()
                    continue
                probs = []
                if errs:
                    probs.append(f"کنسول: {errs[0]}")
                if a["overflow"]:
                    probs.append("سرریز افقی")
                if cls > 0.1:
                    probs.append(f"CLS={cls:.3f}")
                if timing["load"] > 4000:
                    probs.append(f"load={timing['load']}ms")
                soft = []
                if a["smallTap"]:
                    soft.append(f"{a['smallTap']} هدف کوچک")
                if a["imgNoAlt"]:
                    soft.append(f"{a['imgNoAlt']} img بی‌alt")
                tag = "✓" if not probs else "✗"
                color = G if not probs else R
                print(f"  {color}{tag}{X} {path[:44]:44} dcl={timing['dcl']:>4} "
                      f"load={timing['load']:>4} lcp={timing['lcp']:>4} "
                      f"cls={cls:.3f}" + ("  | " + " · ".join(probs) if probs else "")
                      + ("  ‖ " + " · ".join(soft) if soft else ""))
                if probs:
                    fails.append((w, path, " · ".join(probs)))
                if soft:
                    warns.append((w, path, " · ".join(soft)))
                rows.append({"w": w, "path": path, **timing, "cls": round(cls, 4)})
                ctx.close()
        browser.close()

    print(f"\n{B}{'=' * 62}{X}")
    if fails:
        print(f"{R}{B}  {len(fails)} خطای سخت رندر:{X}")
        for w, path, msg in fails[:25]:
            print(f"    ✗ {w}px {path}: {msg}")
    else:
        print(f"{G}  همهٔ صفحه‌ها در همهٔ ویوپورت‌ها پاک رندر شدند.{X}")
    if warns:
        seen = {}
        for w, path, msg in warns:
            seen.setdefault((path, msg), []).append(w)
        print(f"  {len(warns)} گزارش نرم (اهداف کوچک/alt):")
        for (path, msg), ws in list(seen.items())[:15]:
            print(f"    ‖ {path} [{','.join(str(x) for x in ws)}px]: {msg}")
    Path("/tmp/render-audit.json").write_text(json.dumps(rows, ensure_ascii=False))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
