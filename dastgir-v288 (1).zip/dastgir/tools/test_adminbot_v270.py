#!/usr/bin/env python3
# دستور مدیر: پین انتشار با v281 هماهنگ شد؛ رفتار محصول تغییر نکرده است.
# -*- coding: utf-8 -*-
"""v270: حافظهٔ ۱۰ دقیقه‌ای چت عمومی + فایل کل چت‌ها برای مدیر.

Owner's order (2026-09-12): «چت تا ده دقیقه برای کاربر اطلاعات چتش بمونه»
+ «کل چت‌های عمومی هم تو یک فایل ذخیره بشه و من با پنل مدیریتی بتونم اون
فایل دریافت کنم» + کلید تازهٔ aa-… برای glm-5.3-flash (اسلات سایت).

Pins:
1)  THREAD_TTL = 600 — رشتهٔ گفت‌وگو دقیقاً ۱۰ دقیقه می‌ماند (دستور مدیر).
2)  حافظهٔ ۱۰ دقیقه‌ای واقعی: پیام older از ۱۰ دقیقه فراموش، تازه‌تر ماندگار.
3)  هر تبادل چت عمومی (llm/cache/rule/confirm) یک خط JSONL در
    data/site_chats.log می‌گیرد: when/channel/user/q/a/source/model/intent؛
    آی‌پی مهمان هرگز ثبت نمی‌شود (ماسک "guest").
4)  «چت‌ها» در بات مدیر فایل را sendDocument می‌کند (فقط چت تیم)؛ فایل
    خالی/نبود = پیام صادقانه؛ send_document مولتی‌پارت درست می‌سازد.
5)  brain.env نُه‌خطی با کلید تازهٔ سایت؛ انحصار هش: کلید فقط در brain.env
    و با هیچ کلید مغز مدیر یکی نیست. کلید واقعی هرگز چاپ نمی‌شود.
6)  پین نسخهٔ پنج‌جانبهٔ 270.
"""
import hashlib
import json
import os
import re
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v270-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'https://api.example.invalid/v1'
os.environ['AI_API_KEY'] = 'test-legacy-key-not-real'
os.environ['AI_MODEL'] = 'fake-lite'
os.environ['AI_SITE_BASE_URL'] = 'https://site.example.invalid/v1'
os.environ['AI_SITE_API_KEY'] = 'aa-sitekey0000000000000000000000'
os.environ['AI_SITE_MODEL'] = 'site-model-x'
sys.path.insert(0, str(ROOT / 'server'))
import db, adminbot as A, assistant as AI   # noqa: E402

n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
CALLS = []
def fake_chat(base, key, model, msgs, timeout, max_tokens=220):
    CALLS.append((base, key, model))
    return ('{"answer":"باشه","links":[],"scope":true,"intent":"faq"}', 7)
AI._chat = fake_chat
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]
ctx5 = {"channel": "web", "user_key": "cust:5",
        "customer": {"id": 5, "name": "نازنین"}, "owner": None}

# ================= 1. TTL = 10 minutes (دستور مدیر) =================
ck(AI.THREAD_TTL == 600, 'THREAD_TTL is 600s — 10-minute chat memory')

# ================= 2. the 10-minute window really forgets =================
AI.thread_append('t70', 'قدیمی', 'جواب قدیمی')
con = db.connect()
con.execute("UPDATE ai_threads SET created=? WHERE tkey='t70'",
            (int(time.time()) - 700,))
con.commit(); con.close()
ck(AI.thread_get('t70') == [], 'context older than 10 minutes is forgotten')
AI.thread_append('t70', 'تازه', 'جواب تازه')
ck(len(AI.thread_get('t70')) == 2,
   'inside the window the thread is remembered (user+assistant rows)')
con = db.connect()
con.execute("INSERT INTO ai_threads(tkey,role,text,created) "
            "VALUES('t300','user','نیمه‌تازه',?)", (int(time.time()) - 300,))
con.commit(); con.close()
ck(any(r['text'] == 'نیمه‌تازه' for r in AI.thread_get('t300', limit=20)),
   'a 5-minute-old message is still in context')

# ================= 3. chat log file =================
LOG = os.path.join(TMP, 'site_chats.log')
ck(AI.CHAT_LOG == LOG, 'CHAT_LOG lives in the data dir (site_chats.log)')
res = AI.answer('سلام', ctx5, None)
ck(res['ok'] and res['source'] == 'llm', 'llm answer through the site slot')
lines = Path(LOG).read_text(encoding='utf-8').strip().splitlines()
rec = json.loads(lines[-1])
ck(rec['q'] == 'سلام' and rec['a'] == 'باشه',
   'the exchange (q + a) is written to the log')
ck(rec['user'] == 'cust:5' and rec['channel'] == 'web',
   'speaker is pseudonymous (user_key + channel)')
ck(rec['source'] == 'llm' and rec['model'] == 'fast' and rec['intent'] == 'faq',
   'source/model/intent recorded')
ck(isinstance(rec['ts'], int) and re.match(r'^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$',
                                           rec['when']),
   'ts + human-readable when on every line')
# guest: IP is never written
gctx = {"channel": "web", "user_key": "ip:1.2.3.4",
        "customer": None, "owner": None}
AI.answer('قیمت دلار', gctx, None)
lines = Path(LOG).read_text(encoding='utf-8').strip().splitlines()
rec = json.loads(lines[-1])
ck(rec['user'] == 'guest' and '1.2.3.4' not in lines[-1],
   'guest IPs are masked to "guest" — the file never holds raw addresses')
# confirm-path turns are logged too («بله» bare keeps its legacy faq meaning,
# so exercise the decline branch — it always lands on the confirm path)
AI.answer('نه', ctx5, None)
lines = Path(LOG).read_text(encoding='utf-8').strip().splitlines()
ck(json.loads(lines[-1])['intent'] == 'confirm',
   'tool-confirm turns are logged as well')

# ================= 4. «چت‌ها» — owner downloads the file =================
DOCS = []
_real_send_doc = A.send_document
A.send_document = lambda cid, path, caption='': DOCS.append((str(cid), path, caption)) or True
msg = t('چت‌ها')
ck(len(DOCS) == 1 and DOCS[0][0] == CHAT and DOCS[0][1] == LOG,
   '«چت‌ها» sends the log file as a document to the owner chat')
n_lines = len(Path(LOG).read_text(encoding='utf-8').strip().splitlines())
ck('ارسال شد' in msg and AI._fa(n_lines) in msg,
   'owner gets a confirmation message with the message count')
t('چت های سایت')
t('chats')
ck(len(DOCS) == 3, 'aliases: «چت های سایت» and «chats» also deliver the file')
old_log = AI.CHAT_LOG
AI.CHAT_LOG = os.path.join(TMP, 'does-not-exist.log')
msg = t('چت‌ها')
ck('ثبت نشده' in msg and len(DOCS) == 3,
   'no file yet → honest message, nothing sent')
AI.CHAT_LOG = old_log
# non-team chats get nothing
denied = A.handle_text('u1', '999999', 'چت‌ها')
ck(denied[0] == A.DENIED and len(DOCS) == 3,
   'non-team chat is denied — the file never leaves the owner circle')

# ================= 5. send_document builds valid multipart =================
A.send_document = _real_send_doc   # test the REAL transport now
REQS = []
class FakeResp:
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def read(self, n=-1): return b'{"ok": true, "result": {}}'
def fake_urlopen(req, timeout=None):
    REQS.append(req); return FakeResp()
_real = urllib.request.urlopen
urllib.request.urlopen = fake_urlopen
try:
    ok = A.send_document('123', LOG, 'کپشن تست')
finally:
    urllib.request.urlopen = _real
ck(ok is True, 'send_document returns True on an ok response')
req = REQS[-1]
body, ctype = req.data, req.get_header('Content-type') or ''
first = Path(LOG).read_text(encoding='utf-8').splitlines()[0]
ck('/sendDocument' in req.full_url and 'test-token-not-real' in req.full_url,
   'posts to the bot API sendDocument with the admin token')
ck(ctype.startswith('multipart/form-data; boundary='), 'multipart content type')
b = ('--' + ctype.split('boundary=')[1]).encode()
ck('name="chat_id"' in body.decode('utf-8', 'replace') and b'\r\n123\r\n' in body,
   'chat_id field present')
ck('name="caption"' in body.decode('utf-8', 'replace') and
   'کپشن تست'.encode() in body, 'caption field present')
ck('filename="site_chats.log"' in body.decode('utf-8', 'replace'),
   'document part carries the filename')
ck(first.encode() in body, 'the real file bytes are inside the multipart body')
ck(body.endswith(b + b'--\r\n'), 'multipart body closes cleanly')

# ================= 6. brain.env: 9 lines + fresh site key exclusivity =====
be = (ROOT / 'deploy' / 'brain.env').read_text(encoding='utf-8')
_ai = [ln for ln in be.splitlines() if ln.startswith('AI_')]
ck(len(_ai) == 9 and 'AI_SITE_MODEL=glm-5.3-flash' in _ai and
   'AI_SITE_BASE_URL=https://api.avalai.ir/v1' in _ai and
   any(re.match(r'^AI_SITE_API_KEY=aa-[A-Za-z0-9]{30,}$', ln) for ln in _ai),
   'brain.env ships the 9-line store with the fresh site key (glm-5.3-flash)')
_vals = {}
for ln in _ai:
    k, _, v = ln.partition('=')
    _vals[k] = v
# دستور مدیر v273: کیرا کلا حذف شد؛ کلید GLM فقط برای پنل مدیریتی است —
# هر شش اسلات کلید مقدار متمایز دارند.
ck(len({_vals['AI_SITE_API_KEY'], _vals['AI_BRAIN_OPUS_KEY'],
        _vals['AI_BRAIN_SONNET_KEY'], _vals['AI_BRAIN_HAIKU_KEY'],
        _vals['AI_BRAIN_OR_KEY'], _vals['AI_BRAIN_GLM_KEY']}) == 6,
   'v273: the glm key is admin-panel-only; all six key slots distinct')
_site_sha = hashlib.sha256(_vals['AI_SITE_API_KEY'].encode()).hexdigest()
_rx = re.compile(r'aa-[A-Za-z0-9]{30,}')
where = set()
for p in ROOT.rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts or '.git' in p.parts:
        continue
    try:
        txt = p.read_text(encoding='utf-8', errors='ignore')
    except OSError:
        continue
    for m in _rx.findall(txt):
        if hashlib.sha256(m.encode()).hexdigest() == _site_sha:
            where.add(str(p.relative_to(ROOT)))
ck(where == {'deploy/brain.env'},
   'the live site key exists ONLY in deploy/brain.env (hash-pinned)')

# ================= 7. version pins (5 places) =================
# دستور مدیر: پین نسخه همیشه آخرین انتشار را دنبال می‌کند (v272).
ver = (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip()
sw = (ROOT / 'site' / 'sw.js').read_text(encoding='utf-8')
rd = (ROOT / 'README.md').read_text(encoding='utf-8')
cs = (ROOT / 'docs' / 'collaboration' / 'CURRENT-STATE.md').read_text(encoding='utf-8')
# دستور مدیر v280: پین به آخرین انتشار بامپ شد.
ck(ver == '281' and A.DIAG_LATEST == '281' and 'bazarche-v281' in sw and
   any('دست گیر — v281' in ln for ln in rd.splitlines()[:20]) and
   'v281' in cs.splitlines()[0],
   'version pins: VERSION.txt + DIAG_LATEST + sw.js + README + CURRENT-STATE')

print(f'\n✅ test_adminbot_v270: {n}/{n} checks green')
