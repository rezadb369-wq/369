#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v237 admin powers -- offline tests.

Bot: business approve/reject queue (two-step), broadcast with preview,
24h pulse, customer dossier, ops watch, queue cancel, prices toggle,
Persian-digit args, stranger denial. Panel: server-health card on the
dashboard. No network: fetch/cert stubbed, sqlite in a temp dir.
"""
import os, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='adm-v237-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_WATCHDOG_STATE'] = os.path.join(TMP, 'watch.state')
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))  # v238: assistant/layout
import db, adminbot as A
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-09 20:40:01 OK: db=892960B\n')
db.init()
CHAT = '893219571'
t = lambda text, chat=CHAT: A.handle_text('u1', chat, text)[0]
FA = str.maketrans('0123456789', '۰۱۲۳۴۵۶۷۸۹')
to_fa = lambda v: str(v).translate(FA)

# ---- 1. strangers denied everywhere new
for probe in ('تأیید', 'تأیید 1', 'رد 1', 'پیام x', 'تازه‌ها', 'کاربر 0912', 'نگهبان', 'حذف بکاپ', 'قیمت روشن'):
    ck(t(probe, chat='111').startswith('⛔'), f'stranger denied: {probe[:8]}')

# ---- 2. empty queue, then seed (helpers first, raw SQL + one commit)
ck('در انتظاری نیست' in t('تأیید'), 'empty biz queue is friendly')
buyer = db.customer_by_phone('09120000041', create=True)
con = db.connect()
con.execute("UPDATE customers SET name='تستی',status='active' WHERE id=?", (buyer['id'],))
con.execute("INSERT INTO customers(phone,name,status) VALUES('09120000042','مسدود','blocked')")
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,phone,city) VALUES('pub1','منتشرشده','services','published','0211','تهران')")
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,phone,city) VALUES('p1','در انتظار یک','services','pending','0212','تهران')")
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,phone,city) VALUES('p2','در انتظار دو','services','pending','0213','مشهد')")
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,phone,city) VALUES('p3','در انتظار سه','services','pending','0214','اصفهان')")
con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,?,?,?)",
            (buyer['id'], 'bale', 'u41', '741'))
con.execute("INSERT INTO bookings(biz_id,name,phone,date,time,customer_id) VALUES(1,'تستی','09120000041','1405/06/18','10:00',?)",
            (buyer['id'],))
con.commit(); con.close()
b1 = db._one("SELECT id FROM businesses WHERE slug='p1'")['id']
b2 = db._one("SELECT id FROM businesses WHERE slug='p2'")['id']
b3 = db._one("SELECT id FROM businesses WHERE slug='p3'")['id']
db.create_order(1, buyer['id'], 'تستی', '09120000041', 'آدرس', '', [{'item_id': None, 'title': 'کالا', 'price': 500, 'qty': 1}])
db.chat_start(1, buyer['id'])

# ---- 3. queue lists pending rows
blob = t('تأیید')
ck('در انتظار یک' in blob and 'در انتظار دو' in blob and '(3)' in blob, 'queue lists pending rows + total')
ck('تأیید ۱۲' in blob, 'queue hints the decide syntax')

# ---- 4. approve flow (Persian digits) + decide-once safety
ck('منتشر بشه' in t(f'تأیید {to_fa(b1)}'), 'approve asks with fa digits')
ck('منتشر شد ✅' in t('بله'), 'yes publishes')
ck(db.business(bid=b1)['status'] == 'published', 'db: status published')
ck(db._one("SELECT published_once p FROM businesses WHERE id=?", (b1,))['p'] == 1, 'db: published_once set')
ck('قبلاً بررسی' in t(f'تأیید {b1}'), 're-ask after decide is safe')
ck(t('تأیید 999').find('پیدا نشد') != -1, 'unknown id refused')
ck('درست نیست' in t('تأیید دوازده'), 'non-numeric id refused')

# ---- 5. reject flow + no cancels + other commands clear pending
ck('رد بشه' in t(f'رد {b2}'), 'reject asks')
ck(t('خیر') == 'لغو شد ✅', 'no cancels the reject')
ck(db.business(bid=b2)['status'] == 'pending', 'db: no-op leaves pending')
ck('رد بشه' in t(f'رد {b2}'), 'reject asks again')
ck('رد شد' in t('بله'), 'yes rejects')
ck('رد بشه' in t(f'رد {b3}'), 'third reject asks')
t('وضعیت')
ck(t('بله') == 'چیزی در انتظار تأیید نیست ✅', 'another command expires the pending yes')
ck(db.business(bid=b3)['status'] == 'pending', 'db: expired yes changes nothing')

# ---- 6. broadcast with preview + count
ck('متن پیام را هم بفرست' in t('پیام'), 'empty cast refused')
ck('۵۰۰ نویسه' in t('پیام ' + 'x' * 501), 'long cast refused')
prev = t('پیام سلام! فروش ویژه شروع شد.')
ck('به 1 مشتری' in prev and 'فروش ویژه' in prev, 'preview shows count + body')
before = db._one("SELECT COUNT(*) c FROM notifications")['c']
ck('برای 1 مشتری ارسال شد ✅' in t('بله'), 'cast sends to actives')
after = db._one("SELECT COUNT(*) c FROM notifications")['c']
ck(after - before == 1, 'db: blocked customer skipped')

# ---- 7. fresh pulse
fresh = t('تازه‌ها')
ck('مشتری تازه: 2' in fresh, 'fresh counts new customers')
ck('سفارش تازه: 1' in fresh and 'نوبت جدید (باز): 1' in fresh, 'fresh counts orders + bookings')
ck('گفتگوی باز: 1' in fresh and 'در انتظار: 1' in fresh, 'fresh counts chats + pending biz')

# ---- 8. customer dossier
ck('شماره را هم بفرست' in t('کاربر'), 'who needs a phone')
ck('پیدا نشد' in t('کاربر 09120000099'), 'unknown phone refused')
d = t('کاربر 09120000041')
ck('تستی' in d and 'فعال ✅' in d, 'dossier shows profile')
ck('سفارش: 1' in d and 'نوبت: 1' in d and 'گفتگوی باز: 1' in d and 'اتصال پیام‌رسان: 1' in d, 'dossier aggregates activity')
ck('فعال ✅' in t('کاربر ۰۹۱۲۰۰۰۰۰۴۱'), 'fa-digit phone works')

# ---- 9. ops watch
w = t('نگهبان')
ck('🛡 نگهبان' in w and 'صف اجرا: 0' in w, 'watch shows queue depth')
ck('دقیقه پیش ✅' in w and 'گواهی: 42 روز' in w, 'watch shows backup + cert')
ck('نیست ✅' in w, 'watch reports no alerts')
Path(os.environ['ADMINBOT_WATCHDOG_STATE']).write_text('backup\n')
ck('هشدار فعال: backup' in t('/watch'), 'watch surfaces the alert')

# ---- 10. queue cancel (selective)
ck('فقط بکاپ و ریستارت' in t('حذف ناهار'), 'unqueue validates the job')
ck('تو صف نیست' in t('حذف بکاپ'), 'empty unqueue is friendly')
A.queue_write('backup'); A.queue_write('restart')
ck('از صف حذف شد ✅' in t('حذف بکاپ'), 'backup file removed')
left = os.listdir(os.environ['ADMINBOT_QUEUE'])
ck(len(left) == 1 and left[0].startswith('restart-'), 'restart file survives')
ck('تو صف نیست' in t('حذف بکاپ'), 'second cancel finds nothing')

# ---- 11. prices toggle
ck('قیمت روشن' in t('قیمت'), 'prices usage hint')
ck(t('قیمت خاموش') == 'نمایش قیمت: خاموش ✅' and db.get_settings()['prices_enabled'] == '0', 'prices off sticks')
ck(t('قیمت روشن') == 'نمایش قیمت: روشن ✅' and db.get_settings()['prices_enabled'] == '1', 'prices on sticks')

# ---- 12. help + keyboard advertise the powers
h, kb = A.handle_text('u1', CHAT, 'راهنما')
ck(all(k in h for k in ('تأیید', 'تازه‌ها', 'نگهبان', 'پیام', 'کاربر', 'قیمت', 'حذف')), 'help lists every power')
# دستور مدیر v271: ردیف مغز + ردیف‌های «هوش سایت/کلیدها» و «چت‌ها».
# دستور مدیر v280 (فاز۵): ردیف «اسپم» (کنسول ضداسپم) اضافه شد => ۱۰ ردیف.
ck(len(kb['keyboard']) == 10, 'keyboard: + v280 spam row (10 rows)')

# ---- 13. panel dashboard carries the health card
import views_panel as P
html = P.dashboard(db.get_settings(), db.owner_token() or '', {})
ck('سلامت سرور' in html and 'بکاپ خارجی' in html and 'هشدار فعال' in html, 'dashboard renders the health card')
ck('42 روز' in html and 'دقیقه پیش ✅' in html, 'card shows live stubbed values')

print(f'v237 admin powers: {n} checks green')
