#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Real HTTP/webhook/browser-cookie flow for Soroush v206, using a local fake API."""
import http.cookiejar
import http.server
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="dastgir-soroush-http-")
PORT, FAKE = 8095, 8096
SECRET = "W" * 43
received = []

class Fake(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0)); body = self.rfile.read(n)
        try: received.append((self.path, json.loads(body)))
        except Exception: received.append((self.path, {}))
        out = b'{"ok":true,"result":true}'
        self.send_response(200); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out))); self.end_headers(); self.wfile.write(out)
    def log_message(self, *args): pass

fake = http.server.ThreadingHTTPServer(("127.0.0.1", FAKE), Fake)
threading.Thread(target=fake.serve_forever, daemon=True).start()
env = dict(os.environ, BZ_DATA_DIR=TMP, PORT=str(PORT),
           SOROUSH_BOT_TOKEN="unit-test-token", SOROUSH_WEBHOOK_SECRET=SECRET,
           SOROUSH_BOT_USERNAME="dastgirbot", SOROUSH_API_ROOT=f"http://127.0.0.1:{FAKE}/bot")
sys.path.insert(0, str(ROOT / "server")); os.environ["BZ_DATA_DIR"] = TMP
import db  # noqa
db.init(); cust = db.customer_by_phone("09120000002", create=True)
owner=db.owner_by_phone("09120000002", create=True)
con = db.connect(); con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,'soroush','513379886','513379886')", (cust["id"],)); con.execute("INSERT INTO businesses(slug,name,cat_slug,status,address,lat,lng,owner_id) VALUES('bot-order-shop','فروشگاه بات','services','published','خیابان تست',35.7,51.4,?)",(owner['id'],)); con.commit(); con.close()
biz=db.business(slug='bot-order-shop'); bot_order_id=db.create_order(biz['id'],cust['id'],'مشتری','09120000002','','',[{'title':'کالای تست بات','price':12000,'qty':2}]); bot_booking_id=db.add_booking(biz['id'],'مشتری','09120000002','1405/07/20','10:30','خصوصی',cust['id']); con=db.connect();con.execute("INSERT INTO items(biz_id,title,stock,available) VALUES(?,?,0,0)",(biz['id'],'کالای پیگیری'));bot_item_id=con.execute('SELECT last_insert_rowid()').fetchone()[0];con.commit();con.close();db.stock_request_add(biz['id'],bot_item_id,cust['id'],qty=2);bot_stock_id=db.customer_stock_requests(cust['id'])[0]['id'];bot_chat_id=db.chat_start(biz['id'],cust['id'],'پرسش بات');db.chat_send(bot_chat_id,'owner','پاسخ از فروشگاه')
proc = subprocess.Popen([sys.executable, str(ROOT / "run.py")], cwd=ROOT, env=env,
                        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

npass = 0
def check(ok, label):
    global npass
    if not ok: raise AssertionError(label)
    npass += 1; print("  ✓", label)

def request(opener, path, data=None):
    raw = json.dumps(data).encode() if isinstance(data, dict) else data
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}{path}", data=raw)
    if isinstance(data, dict): req.add_header("Content-Type", "application/json")
    try:
        r = opener.open(req, timeout=10); return r.status, r.read().decode(), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode(), dict(e.headers)

try:
    for _ in range(50):
        try:
            if urllib.request.urlopen(f"http://127.0.0.1:{PORT}/healthz", timeout=.3).status == 200: break
        except Exception: time.sleep(.1)
    jar = http.cookiejar.CookieJar(); op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
    code, login_page, _ = request(op, "/login")
    check(code == 200 and "ادامه با سروش‌پلاس" in login_page and
          "روبیکا" not in login_page and 'action="/login"' not in login_page,
          "public login is messenger-only with no SMS/password form")
    check(request(op, "/login", {})[0] == 404 and
          request(op, "/login/password", {})[0] == 404,
          "legacy OTP and password POST endpoints are unavailable")
    # A plain /start explains the manual start -> site -> copy -> bot flow.
    start = {"update_id": 990, "message": {"text": "/start",
             "from": {"id": 777000}, "chat": {"id": 777000, "type":"private"}}}
    code, body, _ = request(op, "/api/soroush/webhook/" + SECRET, start)
    start_msg = received[-1][1].get("text", "") if received else ""
    check(code == 200 and json.loads(body)["ok"] and "بات رسمی دست گیر" in start_msg and
          "کلید ورود از قبل" in start_msg,
          "unlinked Soroush /start preserves direct-link handoff guidance")

    linked_menu = {"update_id": 991, "message": {"text":"/menu",
                   "from":{"id":513379886}, "chat":{"id":513379886,"type":"private"}}}
    code, _, _ = request(op, "/api/soroush/webhook/" + SECRET, linked_menu)
    menu_payload = received[-1][1]
    check(code == 200 and "متصل است" in menu_payload.get("text", "") and
          "dg198:account" in json.dumps(menu_payload), "linked Soroush user receives shared secure menu")
    account_cb = {"update_id": 992, "callback_query": {"id":"menu-cb", "data":"dg198:account",
                  "from":{"id":513379886}, "message":{"chat":{"id":513379886,"type":"private"}}}}
    code, _, _ = request(op, "/api/soroush/webhook/" + SECRET, account_cb)
    check(code == 200 and any("0912••••002" in x[1].get("text", "") for x in received[-2:]),
          "Soroush account callback returns only a masked phone")
    orders_update={"update_id":994,"message":{"text":"/orders","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}}
    code,_,_=request(op,"/api/soroush/webhook/"+SECRET,orders_update);orders_payload=received[-1][1]
    check(code==200 and f"dg198:order:{bot_order_id}" in json.dumps(orders_payload),"Soroush lists only linked-customer order actions")
    detail_update={"update_id":995,"callback_query":{"id":"order-cb","data":f"dg198:order:{bot_order_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}}
    code,_,_=request(op,"/api/soroush/webhook/"+SECRET,detail_update)
    check(code==200 and any("کالای تست بات" in x[1].get("text","") for x in received[-2:]),"Soroush returns owned order detail")
    bookings_update={"update_id":996,"message":{"text":"/bookings","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}}
    code,_,_=request(op,"/api/soroush/webhook/"+SECRET,bookings_update)
    check(code==200 and f"dg198:booking:{bot_booking_id}" in json.dumps(received[-1][1]),"Soroush lists linked-customer bookings")
    booking_detail={"update_id":997,"callback_query":{"id":"book-cb","data":f"dg198:booking:{bot_booking_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}}
    code,_,_=request(op,"/api/soroush/webhook/"+SECRET,booking_detail)
    check(code==200 and any("1405/07/20" in x[1].get("text","") and "خصوصی" not in x[1].get("text","") for x in received[-2:]),"Soroush returns safe booking detail")
    ask_cancel={"update_id":998,"callback_query":{"id":"cancel-ask","data":f"dg198:booking_cancel:{bot_booking_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}}
    request(op,"/api/soroush/webhook/"+SECRET,ask_cancel)
    check(db.customer_booking_detail(cust['id'],bot_booking_id)['status']=='new' and f"dg198:booking_cancel_yes:{bot_booking_id}" in json.dumps(received[-1][1]),"Soroush cancellation requires a second confirmation")
    yes_cancel={"update_id":999,"callback_query":{"id":"cancel-yes","data":f"dg198:booking_cancel_yes:{bot_booking_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}}
    code,_,_=request(op,"/api/soroush/webhook/"+SECRET,yes_cancel)
    check(code==200 and db.customer_booking_detail(cust['id'],bot_booking_id)['status']=='cancelled',"Soroush confirmed cancellation updates the owned booking")
    notif_update={"update_id":880,"message":{"text":"/notifications","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}};code,_,_=request(op,"/api/soroush/webhook/"+SECRET,notif_update)
    check(code==200 and "dg198:notif:booking" in json.dumps(received[-1][1]),"Soroush renders notification preferences")
    notif_toggle={"update_id":881,"callback_query":{"id":"notif-cb","data":"dg198:notif:booking","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/soroush/webhook/"+SECRET,notif_toggle)
    check(not db.kind_enabled('cust',cust['id'],'booking'),"Soroush notification toggle persists to shared site preferences")
    stock_update={"update_id":882,"message":{"text":"/stock","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}};code,_,_=request(op,"/api/soroush/webhook/"+SECRET,stock_update)
    check(code==200 and f"dg198:stock_cancel:{bot_stock_id}" in json.dumps(received[-1][1]),"Soroush lists customer stock tracking")
    stock_ask={"update_id":883,"callback_query":{"id":"stock-ask","data":f"dg198:stock_cancel:{bot_stock_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/soroush/webhook/"+SECRET,stock_ask)
    check(db.stock_request_status(biz['id'],bot_item_id,cust['id'])=='open' and 'stock_cancel_yes' in json.dumps(received[-1][1]),"Soroush stock cancellation requires confirmation")
    stock_yes={"update_id":884,"callback_query":{"id":"stock-yes","data":f"dg198:stock_cancel_yes:{bot_stock_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/soroush/webhook/"+SECRET,stock_yes)
    check(db.stock_request_status(biz['id'],bot_item_id,cust['id'])=='dismissed',"Soroush confirmed stock cancellation persists")
    search_update={"update_id":885,"message":{"text":"/search فروشگاه بات","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}};n_before=len(received);code,_,_=request(op,"/api/soroush/webhook/"+SECRET,search_update)
    batch=json.dumps([r[1] for r in received[n_before:]],ensure_ascii=False)
    check(code==200 and '/b/bot-order-shop' in batch and 'google.com/maps' in batch and '🗺 مسیر' in batch and '🌐 صفحه' in batch,"Soroush search returns v212 card with site and route actions")
    fav_add={"update_id":886,"callback_query":{"id":"fav-add","data":f"dg198:fav_add:{biz['id']}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/soroush/webhook/"+SECRET,fav_add)
    check(db.fav_state(cust['id'],biz['id']),"Soroush search result adds shared favorite")
    fav_list={"update_id":887,"message":{"text":"/favorites","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}};request(op,"/api/soroush/webhook/"+SECRET,fav_list)
    check(f"dg198:fav_remove:{biz['id']}" in json.dumps(received[-1][1]),"Soroush lists shared favorites")
    fav_ask={"update_id":888,"callback_query":{"id":"fav-ask","data":f"dg198:fav_remove:{biz['id']}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/soroush/webhook/"+SECRET,fav_ask)
    check(db.fav_state(cust['id'],biz['id']) and 'fav_remove_yes' in json.dumps(received[-1][1]),"Soroush favorite removal requires confirmation")
    fav_yes={"update_id":889,"callback_query":{"id":"fav-yes","data":f"dg198:fav_remove_yes:{biz['id']}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/soroush/webhook/"+SECRET,fav_yes)
    check(not db.fav_state(cust['id'],biz['id']),"Soroush confirmed favorite removal persists")
    chat_list={"update_id":890,"message":{"text":"/messages","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}};request(op,"/api/soroush/webhook/"+SECRET,chat_list)
    check(f"dg198:chat:{bot_chat_id}" in json.dumps(received[-1][1]),"Soroush lists customer conversations")
    chat_detail={"update_id":891,"callback_query":{"id":"chat-detail","data":f"dg198:chat:{bot_chat_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/soroush/webhook/"+SECRET,chat_detail)
    check('پاسخ از فروشگاه' in received[-1][1].get('text','') and '/me/chat/' in json.dumps(received[-1][1]),"Soroush shows safe conversation summary and site handoff")
    chat_ask={"update_id":892,"callback_query":{"id":"chat-ask","data":f"dg198:chat_reply:{bot_chat_id}:thanks","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/soroush/webhook/"+SECRET,chat_ask)
    before_msgs=len(db.chat_messages(bot_chat_id));yes_data=received[-1][1]['reply_markup']['inline_keyboard'][0][0]['callback_data'];check('chat_reply_yes' in yes_data and len(db.chat_messages(bot_chat_id))==before_msgs,"Soroush short reply requires one-use confirmation")
    chat_yes={"update_id":893,"callback_query":{"id":"chat-yes","data":yes_data,"from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/soroush/webhook/"+SECRET,chat_yes)
    check(len(db.chat_messages(bot_chat_id))==before_msgs+1,"Soroush confirmed short reply persists")
    db._run("DELETE FROM ratelimit WHERE bucket=?",('bot-menu:soroush:513379886',))
    owner_menu={"update_id":894,"message":{"text":"/owner","from":{"id":513379886},"chat":{"id":513379886,"type":"private"}}};request(op,"/api/soroush/webhook/"+SECRET,owner_menu)
    check('پنل کسب‌وکار' in received[-1][1].get('text','') and 'owner_orders' in json.dumps(received[-1][1]),"Soroush exposes daily owner dashboard to linked shopkeeper")
    owner_detail={"update_id":895,"callback_query":{"id":"owner-detail","data":f"dg198:owner_order:{bot_order_id}","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/soroush/webhook/"+SECRET,owner_detail)
    check('owner_act:order_status' in json.dumps(received[-1][1]),"Soroush owner sees safe next order transition")
    owner_ask={"update_id":896,"callback_query":{"id":"owner-ask","data":f"dg198:owner_act:order_status:{bot_order_id}:confirmed","from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/soroush/webhook/"+SECRET,owner_ask);owner_yes=received[-1][1]['reply_markup']['inline_keyboard'][0][0]['callback_data']
    check(db.order(bot_order_id)['status']=='new' and 'owner_yes:' in owner_yes,"Soroush owner change requires one-use confirmation")
    owner_confirm={"update_id":897,"callback_query":{"id":"owner-confirm","data":owner_yes,"from":{"id":513379886},"message":{"chat":{"id":513379886,"type":"private"}}}};request(op,"/api/soroush/webhook/"+SECRET,owner_confirm)
    check(db.order(bot_order_id)['status']=='confirmed',"Soroush confirmed owner transition persists")
    before=len(received);group_menu={"update_id":993,"message":{"text":"/menu","from":{"id":513379886},"chat":{"id":-21,"type":"group"}}}
    code, _, _=request(op,"/api/soroush/webhook/"+SECRET,group_menu)
    check(code==200 and len(received)==before,"Soroush menu ignores group chats")

    code, html, _ = request(op, "/auth/soroush")
    check(code == 200 and "ورود یا ثبت‌نام با سروش‌پلاس" in html and
          'href="soroush://resolve?domain=dastgirbot"' in html and
          "data-soroush-direct" in html and "data-soroush-copy" in html and
          "intent:" not in html and "login_" not in re.search(r'href="soroush:[^"]+"', html).group(0),
          "Soroush login copies the key and opens the exact direct bot resolver")
    token = re.search(r"login_([A-Za-z0-9_-]{20,60})", html).group(1)
    code, _, _ = request(op, "/api/soroush/webhook/badbadbadbadbadbadbadbadbadbadbadbad", {})
    # دستور مدیر (v277): secret غلط حالا یک strike ضداسپم هم ثبت می‌کند
    # (۶ strike در ۱۰دقیقه => بلاک موقت IP)؛ پاسخ همچنان ۴۰۴ بی‌نشت است.
    check(code == 404, "wrong webhook secret is indistinguishable from missing route")
    update = {"update_id": 1001, "message": {"text": "login_" + token,
                           "from": {"id": 513379886}, "chat": {"id": 513379886, "type":"private"}}}
    code, body, _ = request(op, "/api/soroush/webhook/" + SECRET, update)
    check(code == 200 and json.loads(body)["ok"], "webhook accepts copied browser request")
    callback = next(x[1]["reply_markup"]["inline_keyboard"][0][0]["callback_data"]
                    for x in received if x[0].endswith("/sendMessage") and x[1].get("reply_markup") and
                    x[1]["reply_markup"]["inline_keyboard"][0][0].get("callback_data", "").startswith("sp193:"))
    update = {"update_id": 1002, "callback_query": {"id": "cb1", "data": callback,
              "from": {"id": 513379886}, "message": {"chat": {"id": 513379886, "type":"private"}}}}
    code, _, _ = request(op, "/api/soroush/webhook/" + SECRET, update)
    check(code == 200, "approval callback reaches application")
    code, body, _ = request(op, "/api/soroush/webhook/" + SECRET, update)
    check(code == 200 and json.loads(body).get("duplicate") is True,
          "duplicate update_id is acknowledged but never executed twice")
    cid = json.loads(re.search(r"encodeURIComponent\((\"[A-Za-z0-9_-]+\")\)", html).group(1))
    code, body, _ = request(op, "/api/soroush/status?id=" + cid)
    out = json.loads(body)
    check(out["status"] == "approved" and out["redirect"] == "/my",
          "bound browser receives approval and normal site session")
    code, page, _ = request(op, "/me")
    check(code == 200 and "حساب" in page, "minted customer session opens private account")
    code, page, _ = request(op, "/my")
    check(code == 200, "same phone also receives its eligible owner session")
    code, body, _ = request(op, "/api/soroush/status?id=" + cid)
    check(json.loads(body)["status"] == "expired", "consumed approval cannot be replayed")

    # Exercise the one-time account-link flow through the authenticated browser.
    db.messenger_unlink(cust["id"], "soroush")
    code, link_html, _ = request(op, "/me/soroush/connect")
    check(code == 200 and "اتصال حساب سروش‌پلاس" in link_html,
          "authenticated customer can start one-time Soroush linking")
    link_token = re.search(r"link_([A-Za-z0-9_-]{20,60})", link_html).group(1)
    link_cid = json.loads(re.search(r"encodeURIComponent\((\"[A-Za-z0-9_-]+\")\)", link_html).group(1))
    update = {"update_id": 2001, "message": {"text": "/start link_" + link_token,
              "from": {"id": 888001}, "chat": {"id": 888001, "type":"private"}}}
    code, _, _ = request(op, "/api/soroush/webhook/" + SECRET, update)
    check(code == 200, "bot resolves authenticated linking challenge")
    callback = next(x[1]["reply_markup"]["inline_keyboard"][0][0]["callback_data"]
                    for x in reversed(received)
                    if x[0].endswith("/sendMessage") and x[1].get("reply_markup") and
                    x[1]["reply_markup"]["inline_keyboard"][0][0].get("callback_data", "").startswith("sp193:"))
    update = {"update_id": 2002, "callback_query": {"id": "cb-link", "data": callback,
              "from": {"id": 888001}, "message": {"chat": {"id": 888001, "type":"private"}}}}
    code, _, _ = request(op, "/api/soroush/webhook/" + SECRET, update)
    code, body, _ = request(op, "/api/soroush/status?id=" + link_cid)
    account = db.messenger_account_for_customer(cust["id"], "soroush")
    check(code == 200 and json.loads(body)["status"] == "approved" and
          account and account["platform_user_id"] == "888001",
          "explicit bot confirmation completes browser-bound account link")

    # Unknown Soroush identity: verified own contact, then a separate confirmation.
    signup_op = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    code, signup_html, _ = request(signup_op, "/auth/soroush")
    signup_token = re.search(r"login_([A-Za-z0-9_-]{20,60})", signup_html).group(1)
    signup_cid = json.loads(re.search(
        r"encodeURIComponent\((\"[A-Za-z0-9_-]+\")\)", signup_html).group(1))
    keyboards_before = sum(1 for x in received if x[0].endswith('/sendMessage') and
                           (x[1].get('reply_markup') or {}).get('keyboard'))
    group = {"update_id": 3000, "message": {"text": "login_" + signup_token,
             "from": {"id": 700001}, "chat": {"id": -1001, "type":"group"}}}
    request(signup_op, "/api/soroush/webhook/" + SECRET, group)
    keyboards_after = sum(1 for x in received if x[0].endswith('/sendMessage') and
                          (x[1].get('reply_markup') or {}).get('keyboard'))
    check(keyboards_before == keyboards_after, "group messages cannot bind an authentication challenge")
    update = {"update_id": 3001, "message": {"text": "login_" + signup_token,
              "from": {"id": 700001}, "chat": {"id": 700001, "type":"private"}}}
    request(signup_op, "/api/soroush/webhook/" + SECRET, update)
    contact_call = next(x for x in reversed(received)
                        if x[0].endswith("/sendMessage") and
                        (x[1].get("reply_markup") or {}).get("keyboard"))
    check(contact_call[1]["reply_markup"]["keyboard"][0][0].get("request_contact") is True,
          "unknown Soroush user receives official own-contact signup button")
    before = sum(1 for x in received if x[0].endswith('/sendMessage') and
                 'sp193:signup:' in str((x[1].get('reply_markup') or {})))
    bad = {"update_id": 3002, "message": {"contact": {
           "phone_number": "+989131234567", "user_id": 999999},
           "from": {"id": 700001}, "chat": {"id": 700001, "type":"private"}}}
    request(signup_op, "/api/soroush/webhook/" + SECRET, bad)
    missing = {"update_id": 3003, "message": {"contact": {
               "phone_number": "+989131234567"}, "from": {"id": 700001},
               "chat": {"id": 700001, "type":"private"}}}
    request(signup_op, "/api/soroush/webhook/" + SECRET, missing)
    after = sum(1 for x in received if x[0].endswith('/sendMessage') and
                'sp193:signup:' in str((x[1].get('reply_markup') or {})))
    check(before == after, "foreign or ownerless contact cannot advance signup")
    update = {"update_id": 3004, "message": {"contact": {
              "phone_number": "+989131234567", "user_id": 700001},
              "from": {"id": 700001}, "chat": {"id": 700001, "type":"private"}}}
    request(signup_op, "/api/soroush/webhook/" + SECRET, update)
    signup_callback = next(x[1]["reply_markup"]["inline_keyboard"][0][0]["callback_data"]
                           for x in reversed(received)
                           if x[0].endswith("/sendMessage") and
                           str((x[1].get("reply_markup") or {})).find("sp193:signup:") >= 0)
    check(signup_callback.startswith("sp193:signup:"),
          "verified own contact still requires separate registration approval")
    update = {"update_id": 3005, "callback_query": {"id": "cb-signup",
              "data": signup_callback, "from": {"id": 700001},
              "message": {"chat": {"id": 700001, "type":"private"}}}}
    request(signup_op, "/api/soroush/webhook/" + SECRET, update)
    code, body, _ = request(signup_op, "/api/soroush/status?id=" + signup_cid)
    check(code == 200 and json.loads(body)["status"] == "approved" and
          db.messenger_account_by_platform("soroush", 700001),
          "Soroush-only flow creates, links and signs in a new customer")

    # Two login challenges above used two of six slots for this IP.
    codes = []
    for _ in range(5):
        fresh = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        codes.append(request(fresh, "/auth/soroush")[0])
    check(codes[:4] == [200] * 4 and codes[4] == 429,
          "security-critical challenge issuance is rate-limited even if spam limits are disabled")
    print(f"\nAll {npass} Soroush HTTP v206 checks passed.")
finally:
    proc.terminate()
    try: proc.wait(timeout=5)
    except Exception: proc.kill()
    fake.shutdown(); fake.server_close(); shutil.rmtree(TMP, ignore_errors=True)
