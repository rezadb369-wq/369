#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v274 (دستور مدیر): «هوش آفلاین (نامحدود)» + سوئیچ بالای صفحهٔ چت.

Pins:
1) حالت آفلاین: ctx["mode"]=="offline" هرگز مدل را صدا نمی‌زند (حتی با کلید
   سایت)، سهمیه مصرف نمی‌شود و پاسخ با mode=="offline" برمی‌گردد.
2) پایان سهمیه: degraded quota/cap → remaining صفر (نه ۱) + یادداشت اتصال به
   هوش آفلاین به پاسخ چسبیده.
3) مغز آفلاین واقعاً آموزش‌دیده است: موضوع‌های رایج سایت (ساعت کاری، پرداخت،
   حریم، نقشه، چانه‌زنی، دستیار/سهمیه، …) پاسخ قطعی و لینک‌دار می‌گیرند و
   «پیدا نکردم» فقط برای جست‌وجوی واقعی می‌ماند.
4) KNOWLEDGE بزرگ‌تر شده و _knowledge_pool نسخهٔ ویرایش‌شدهٔ مدیر را برنده
   می‌کند ولی هرگز ادعای ورود پیامکی نمی‌کند.
"""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='ai-v274-')
os.environ['BZ_DATA_DIR'] = TMP
for k in ('AI_BASE_URL', 'AI_API_KEY', 'AI_MODEL', 'AI_MODEL_SMART',
          'AI_SITE_BASE_URL', 'AI_SITE_API_KEY', 'AI_SITE_MODEL'):
    os.environ.pop(k, None)
sys.path.insert(0, str(ROOT / 'server'))

import db  # noqa: E402
import assistant as A  # noqa: E402

db.init()
n = 0


def ck(ok, label):
    global n
    assert ok, label
    n += 1
    print('  ✓', label)


CUST = {"id": 7, "name": "کاربر"}
ctx = lambda key, **kw: dict({"channel": "web", "user_key": key,
                              "customer": CUST, "owner": None}, **kw)

# ---- 1. offline mode never touches the model even when a site key exists ----
CALLS = []
def fake_chat(base, key, model, msgs, timeout, max_tokens=700):
    CALLS.append(model)
    return ('{"answer":"از مدل","links":[],"scope":true,"intent":"faq"}', 5)
A._chat = fake_chat
os.environ.update(AI_SITE_BASE_URL="https://site.example.invalid/v1",
                  AI_SITE_API_KEY="test-site-key", AI_SITE_MODEL="site-model")
ck(A.site_configured(), 'site slot configured for the contrast test')

r = A.answer("سلام", ctx("u-auto"), None)
ck(r["source"] == "llm" and CALLS, 'auto mode with key → model is called')
before = len(CALLS)
r = A.answer("سلام", ctx("u-off", mode="offline"), None)
ck(len(CALLS) == before, 'offline mode → model NOT called')
ck(r["mode"] == "offline" and r["degraded"] == "offline",
   'offline answer echoes mode=offline')
ck(A.quota_used_today("u-off") == 0, 'offline answers consume no smart quota')

# ---- 2. quota end: remaining is 0, never «1 remaining», note appended ----
key = "u-quota"
q = A.quota_for(A.tier_of(CUST, None))
# burn the whole quota with counted model answers
for _ in range(q):
    A._count(key, "web", 1, 10, "faq", quota=1, smart=1)
r = A.answer("سلام", ctx(key), None)   # now budget out → degraded quota
ck(r["degraded"] in ("quota", "cap"), 'exhausted budget degrades to quota')
ck(r["remaining"] == 0, 'remaining forced to 0 at exhaustion (no phantom 1)')
ck("هوش آفلاین" in r["text"] and "به پایان رسید" in r["text"],
   'user is told the quota ended and they are on the offline AI')

# ---- 3. the offline brain is well-trained on site topics ----
os.environ.pop('AI_SITE_API_KEY', None)   # back to pure rules
topics = {
    "ساعت کاری چنده": "باز/بسته",
    "پرداخت چطوریه": "پولی نمی‌گیرد",
    "حسابم رو چطور حذف کنم": "حساب",
    "نقشه کجاست": "/map",
    "چانه زنی چطوریه": "چانه",
    "حریم خصوصی چیه": "نشان داده نمی‌شود",
    "هوش آفلاین چیه": "نامحدود",
    "تخفیف‌های امروز": "/deals",
}
for qtext, frag in topics.items():
    r = A.answer(qtext, ctx("u-topics"), None)
    ck(frag in r["text"], f'offline topic answered: {qtext!r}')

# a real search that truly finds nothing keeps the honest dead-end
r = A.answer("کافه", ctx("u-none"), None)
ck("پیدا نکردم" in r["text"], 'genuine empty search still says not-found')

# ---- 4. knowledge grew, deduped, no SMS-login claim ----
ck(len(A.KNOWLEDGE) >= 30, 'KNOWLEDGE expanded for the offline brain')
pool = A._knowledge_pool()
qs = [q0 for q0, _ in pool]
ck(len(qs) == len(set(qs)), 'knowledge pool has no duplicate questions')
bad = [a for _, a in A.KNOWLEDGE if "ورود با پیامک" in a or "با پیامک است" in a]
ck(not bad, 'no KNOWLEDGE entry claims SMS login')
# admin edit wins over the built-in copy in the offline pool
row = [x for x in db.ai_faq_list(active_only=False) if x["q"] == "حساب مشتری"]
if row:
    db.ai_faq_upsert(row[0]["id"], row[0]["q"], "نسخهٔ ویرایش‌شدهٔ مدیر ۲۷۴", 1, row[0]["ord"])
    pool2 = dict(A._knowledge_pool())
    ck(pool2.get("حساب مشتری") == "نسخهٔ ویرایش‌شدهٔ مدیر ۲۷۴",
       'admin-edited answer wins the offline pool')

print(f"\n  {n} checks passed — assistant v274 offline brain OK")
