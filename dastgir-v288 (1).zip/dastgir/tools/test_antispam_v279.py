#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v279 — فاز ۵ امنیت: کنسول اسپم (UI پنل + دستور «اسپم» بات مدیر).

دستور مدیر: قانون §78 — قابلیت بدون UI دیده‌شدنی = انجام‌نشده.
۱) /panel/spam: شمار زنده per-کنش، ویرایش سیاست (limit/window) با حفظ
   alwaysها، banها با lift، ban دستی، ۵۰ رویداد اخیر؛
۲) بات مدیر: «اسپم» = گزارش ۲۴ ساعت + «اسپم ban/lift» — فقط چت تیم؛
۳) سیاست زمان‌اجرا: اورراید در settings می‌نشیند؛ always از کد می‌آید و
   از کنسول قابل خاموش‌کردن نیست.
"""
import os
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="asv279-")
os.environ["BZ_DATA_DIR"] = TMP
os.environ["BALE_ADMIN_TOKEN"] = "test-token-not-real"
os.environ["BALE_ADMIN_SECRET"] = "s" * 40
os.environ["BALE_ADMIN_CHAT"] = "111"
os.environ["ADMINBOT_QUEUE"] = os.path.join(TMP, "q")
os.environ["ADMINBOT_PENDING"] = os.path.join(TMP, "pending.json")
sys.path.insert(0, str(ROOT / "server"))

import db          # noqa: E402
import antispam    # noqa: E402

db.init()
n = 0


def ck(ok, label):
    global n
    assert ok, label
    n += 1
    print("  ✓", label)


# ---------- 1. سیاست زمان‌اجرا ----------
ck(antispam._policy("fav") == antispam.POLICY["fav"],
   "بدون اورراید، سیاست مؤثر = POLICY کد")
okk, _m = antispam.policy_set("fav", 5, 300)
ck(okk and antispam._policy("fav") == (5, 300.0, False),
   "policy_set => اورراید limit/window مؤثر است")
okk2, _m2 = antispam.policy_set("view", 10, 120)
ck(okk2 and antispam._policy("view")[2] is True,
   "always از کد می‌آید — کنسول نمی‌تواند خاموشش کند (حفظ always)")
bad, _mb = antispam.policy_set("nosuch", 1, 60)
ck(not bad, "کنش ناشناخته رد می‌شود")
antispam.policy_clear("fav")
ck(antispam._policy("fav") == antispam.POLICY["fav"],
   "policy_clear => بازگشت به پیش‌فرض")

# ---------- 2. guard از اورراید می‌خواند ----------
antispam.policy_set("fav", 0, 600)          # limit=0 => رد بی‌قیدوشرط
ok, gate, _r = antispam.guard("fav", "7.7.7.7")
ck(not ok and gate == "fav", "guard با اورراید limit=0 رد می‌کند")
antispam.policy_clear("fav")
ok2, _g2, _r2 = antispam.guard("fav", "7.7.7.8")
ck(ok2, "پس از clear، guard دوباره بر اساس POLICY کد است")

# ---------- 3. ban دستی / lift ----------
antispam.ban_now("8.8.8.8", 1, by="test")
ck(antispam.banned("8.8.8.8") and
   any(b["ident"] == "8.8.8.8" for b in antispam.bans_active()),
   "ban_now => بن فعال در bans_active")
ck(antispam.lift("8.8.8.8") and not antispam.banned("8.8.8.8"),
   "lift => بن برداشته می‌شود")

# ---------- 4. HTTP: صفحهٔ کنسول ----------
import app  # noqa: E402
srv = app.make_server(8099)
threading.Thread(target=srv.serve_forever, daemon=True).start()
time.sleep(0.4)
KEY = db.owner_token()


def req(path, data=None, method=None):
    body = urllib.parse.urlencode(data, encoding="utf-8").encode() if data else None
    r = urllib.request.Request("http://127.0.0.1:8099" + path, data=body,
                               method=method)

    class NoRedir(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None
    op = urllib.request.build_opener(NoRedir)
    try:
        with op.open(r, timeout=10) as resp:
            return resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


antispam.ban_now("6.6.6.6", 1, by="test")   # تا فرم lift هم رندر شود
st, body = req("/panel/spam?key=" + urllib.parse.quote(KEY))
ck(st == 200 and "کنسول اسپم" in body and "<code>fav</code>" in body,
   "/panel/spam رندر می‌شود (کاشی‌ها + جدول سیاست)")
ck("/panel/spam/policy" in body and "/panel/spam/lift" in body,
   "فرم‌های ویرایش سیاست و lift در صفحه‌اند")
antispam.lift("6.6.6.6")

st_n, _bn = req("/panel/spam")
ck(st_n in (303, 401, 403) or "کنسول اسپم" not in _bn,
   "بدون کلید/نشست، کنسول در دسترس نیست")

# ---------- 5. POST: سیاست و ban/lift ----------
st, _b = req("/panel/spam/policy", {"key": KEY, "action": "fav",
                                    "limit": "9", "window": "700"})
ck(st == 303 and antispam._policy("fav") == (9, 700.0, False),
   "POST /panel/spam/policy => سیاست ذخیره و مؤثر شد")
st, _b = req("/panel/spam/policy-reset", {"key": KEY, "action": "fav"})
ck(st == 303 and antispam._policy("fav") == antispam.POLICY["fav"],
   "POST /panel/spam/policy-reset => پیش‌فرض")
st, _b = req("/panel/spam/ban", {"key": KEY, "ident": "8.8.4.4", "hours": "2"})
ck(st == 303 and antispam.banned("8.8.4.4"), "POST /panel/spam/ban => بن")
st, body2 = req("/panel/spam?key=" + urllib.parse.quote(KEY))
ck("8.8.4.4" in body2, "بن فعال در جدول بن‌های کنسول دیده می‌شود")
st, _b = req("/panel/spam/lift", {"key": KEY, "ident": "8.8.4.4"})
ck(st == 303 and not antispam.banned("8.8.4.4"), "POST /panel/spam/lift => رفع بن")
st, _b = req("/panel/spam/lift", {"key": KEY, "ident": "no-such-ident"})
ck(st == 303, "lift بی‌اثر صادقانه رد می‌شود (بدون «موفق» جعلی)")

# ---------- 6. بات مدیر: «اسپم» ----------
import adminbot  # noqa: E402
reply, _mk = adminbot.handle_text("u1", "111", "اسپم")
ck("گزارش ضداسپم" in reply and "/panel/spam" in reply,
   "«اسپم» در چت تیم => گزارش + نشانی کنسول")
reply2, _mk2 = adminbot.handle_text("u2", "999", "اسپم")
ck(reply2 == adminbot.DENIED, "«اسپم» از چت غیرتیم => DENIED")
r3, _m3 = adminbot.handle_text("u1", "111", "اسپم ban 9.9.9.9 1")
ck(antispam.banned("9.9.9.9") and "ban شد" in r3, "«اسپم ban <شناسه>» کار می‌کند")
r4, _m4 = adminbot.handle_text("u1", "111", "اسپم lift 9.9.9.9")
ck(not antispam.banned("9.9.9.9") and "برداشته شد" in r4,
   "«اسپم lift <شناسه>» کار می‌کند")

print("ANTISPAM v279 PASS %d" % n)
