# -*- coding: utf-8 -*-
"""v114 real-visit analytics tests.

Proves, against the live server on :8080 (same pattern as test_abuse.py):
  * a public page view records ONE visits row with the real IP (XFF honoured
    from loopback), device class and a first-party bz_cid/bz_sid cookie
  * the visitor cookie is stable: same cookie = same cid = one unique visitor
  * businesses.views (and the events series) move for humans ONLY — a
    Googlebot hit is recorded as bot=1 and never inflates the counter
  * story views carry the full identity now (kind='story', ip present)
  * panel/login/api paths are NOT tracked as content views
  * the one-time counter reset (analytics_reset_v114) is registered
  * GA4: no id => zero Google code; valid id => gtag + consent-granted +
    CSP allows googletagmanager/google-analytics
  * /panel/analytics renders for the owner key and 403s without it

Run:  python3 tools/test_analytics.py        (server on :8080)
"""
import os
import sys
import time
import random
import urllib.parse
import urllib.request
import urllib.error

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
passed = failed = 0
fails = []


def ok(label, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  {G}✓{X} {label}")
    else:
        failed += 1
        fails.append(label)
        print(f"  {R}✗{X} {label}   {detail}")


def req(path, ident=None, ua=None, post=None, cookie=None):
    url = BASE + path
    data = None
    HUMAN = ("Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
             "(KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36")
    headers = {"User-Agent": ua or HUMAN}
    if ident:
        headers["X-Forwarded-For"] = ident
    if cookie:
        headers["Cookie"] = cookie
    if post is not None:
        data = urllib.parse.urlencode(post).encode()
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    r = urllib.request.Request(url, data=data, headers=headers)

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None

    try:
        with urllib.request.build_opener(NoRedirect).open(r, timeout=10) as resp:
            return (resp.status, resp.read().decode("utf-8", "replace"),
                    resp.headers.get_all("Set-Cookie") or [])
    except urllib.error.HTTPError as e:
        return (e.code, e.read().decode("utf-8", "replace"),
                e.headers.get_all("Set-Cookie") or [])


sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "server"))
import db          # noqa: E402
import analytics   # noqa: E402

TOK = db.owner_token()
_r = random.Random()
ME = f"10.{_r.randint(2,250)}.{_r.randint(2,250)}.{_r.randint(2,250)}"   # "me"
BOT_IP = f"10.{_r.randint(2,250)}.{_r.randint(2,250)}.{_r.randint(2,250)}"

biz = db._one("SELECT id, slug, views FROM businesses "
              "WHERE status='published' LIMIT 1")
if not biz:
    print("یک کسب‌وکار منتشرشده لازم است — tools/seed_demo.py را اجرا کنید.")
    sys.exit(2)


def n_visits(where, *args):
    return (db._one(f"SELECT COUNT(*) n FROM visits WHERE {where}", args)
            or {}).get("n", 0)


print(f"\n{B}۱) بازدید صفحهٔ اول: ردیف visits با IP واقعی + کوکی شناسه{X}")
st, body, cookies = req("/", ident=ME)
joined = ";".join(cookies)
ok("صفحهٔ اول ۲۰۰", st == 200, str(st))
ok("کوکی bz_cid ست می‌شود", "bz_cid=" in joined, joined[:80])
ok("کوکی نشست bz_sid ست می‌شود", "bz_sid=" in joined, joined[:80])
row = db._one("SELECT * FROM visits WHERE ip=? AND path='/' "
              "ORDER BY id DESC LIMIT 1", (ME,))
ok("ردیف visits با آی‌پی واقعی ثبت شد", bool(row), ME)
if row:
    ok("نوع صفحه = home", row["kind"] == "home", row["kind"])
    ok("دستگاه = mobile (از UA اندروید)", row["dev"] == "mobile", row["dev"])
    ok("بات نیست", row["bot"] == 0)
    ok("شناسهٔ بازدیدکننده پر است", len(row["cid"]) == 16, row["cid"])

print(f"\n{B}۲) کوکی پایدار: همان آدم = یک بازدیدکنندهٔ یکتا{X}")
cid = ""
for c in cookies:
    if c.startswith("bz_cid="):
        cid = c.split(";", 1)[0]
st2, _, cookies2 = req("/businesses", ident=ME, cookie=cid)
ok("درخواست دوم با کوکی = ۲۰۰", st2 == 200, str(st2))
ok("کوکی تازه ست نشد (شناسه پایدار)", not any(c.startswith("bz_cid=")
                                                for c in cookies2))
row2 = db._one("SELECT cid FROM visits WHERE ip=? AND path='/businesses' "
               "ORDER BY id DESC LIMIT 1", (ME,))
ok("همان cid در ردیف دوم", bool(row2) and row2["cid"] == (cid.split("=", 1)[1]
                                                           if cid else ""))

print(f"\n{B}۳) صفحهٔ کسب‌وکار: شمارنده فقط برای آدم واقعی{X}")
v_before = db.business(bid=biz["id"])["views"]
ev_before = (db._one("SELECT n FROM events WHERE biz_id=? AND kind='view' "
                     "AND day=date('now')", (biz["id"],)) or {}).get("n", 0)
st, _, _ = req(f"/b/{biz['slug']}", ident=ME, cookie=cid)
v_after = db.business(bid=biz["id"])["views"]
ev_after = (db._one("SELECT n FROM events WHERE biz_id=? AND kind='view' "
                    "AND day=date('now')", (biz["id"],)) or {}).get("n", 0)
ok("بازدید انسان شمارنده را +۱ کرد", v_after == v_before + 1,
   f"{v_before}->{v_after}")
ok("سری روزانهٔ events هم +۱ شد", ev_after == ev_before + 1,
   f"{ev_before}->{ev_after}")
ok("ردیف visits kind=business",
   n_visits("ip=? AND kind='business'", ME) >= 1)

print(f"\n{B}۴) خزنده (Googlebot): ثبت می‌شود ولی شماره را بالا نمی‌برد{X}")
v_before = db.business(bid=biz["id"])["views"]
st, _, _ = req(f"/b/{biz['slug']}", ident=BOT_IP,
               ua="Mozilla/5.0 (compatible; Googlebot/2.1; "
                  "+http://www.google.com/bot.html)")
v_after = db.business(bid=biz["id"])["views"]
ok("شمارندهٔ کسب‌وکار دست‌نخورد", v_after == v_before,
   f"{v_before}->{v_after}")
brow = db._one("SELECT bot, dev FROM visits WHERE ip=? "
               "ORDER BY id DESC LIMIT 1", (BOT_IP,))
ok("ردیف بات با bot=1 ثبت شد", bool(brow) and brow["bot"] == 1)
ok("دستگاه = bot", bool(brow) and brow["dev"] == "bot")

print(f"\n{B}۵) استوری: بازدید با هویت کامل{X}")
st_row = db._one("SELECT id FROM stories LIMIT 1")
if not st_row:
    sid = db._run("INSERT INTO stories(biz_id,image,kind,caption,expires) "
                  "VALUES(?,?,'image','',?)",
                  (biz["id"], "/assets/img/favicon.svg", time.time() + 86400))
else:
    sid = st_row["id"]
before = n_visits("story_id=? AND ip=?", sid, ME)
st, _, _ = req(f"/api/stories/{sid}/view", ident=ME, cookie=cid, post={})
after = n_visits("story_id=? AND ip=?", sid, ME)
ok("POST استوری ۲۰۰", st == 200, str(st))
ok("ردیف story با آی‌پی ثبت شد", after == before + 1, f"{before}->{after}")
srow = db._one("SELECT kind, cid FROM visits WHERE story_id=? AND ip=? "
               "ORDER BY id DESC LIMIT 1", (sid, ME))
ok("kind=story و cid پر", bool(srow) and srow["kind"] == "story"
   and len(srow["cid"] or "") == 16)

print(f"\n{B}۶) مسیرهای غیرمحتوایی ردیابی نمی‌شوند{X}")
req("/panel/settings", ident=ME, cookie=cid)          # 403, no html 200
req(f"/panel/settings?key={urllib.parse.quote(TOK)}", ident=ME, cookie=cid)
req("/api/search?q=test", ident=ME, cookie=cid)
ok("پنل بازدید شمرده نمی‌شود",
   n_visits("path LIKE '/panel%' AND ip=?", ME) == 0)
ok("api بازدید شمرده نمی‌شود",
   n_visits("path LIKE '/api%' AND ip=? AND kind!='story'", ME) == 0)

print(f"\n{B}۷) ریست یک‌بارِ شمارنده‌ها ثبت شده{X}")
flag = db._one("SELECT value FROM settings WHERE key='analytics_reset_v114'")
ok("پرچم analytics_reset_v114 = 1", bool(flag) and flag["value"] == "1")

print(f"\n{B}۸) GA4: بدون شناسه هیچ چیز گوگلی نیست؛ با شناسه کامل{X}")
db.set_setting("ga_measurement_id", "")
st, body, _ = req("/", ident=ME, cookie=cid)
ok("بدون شناسه: gtag در صفحه نیست", "googletagmanager" not in body)
db.set_setting("ga_measurement_id", "G-TEST123456")
st, body, _ = req("/", ident=ME, cookie=cid)
ok("با شناسه: اسکریپت gtag بارگذاری می‌شود",
   "https://www.googletagmanager.com/gtag/js?id=G-TEST123456" in body)
ok("consent پیش‌فرض granted (بدون بنر)",
   "gtag('consent','default'" in body and "'analytics_storage':'granted'" in body)
ok("config با شناسه", "gtag('config','G-TEST123456')" in body)
db.set_setting("ga_measurement_id", "not-a-valid-id!!")
st, body, _ = req("/", ident=ME, cookie=cid)
ok("شناسهٔ نامعتبر نادیده گرفته می‌شود", "googletagmanager" not in body)
db.set_setting("ga_measurement_id", "")

# CSP must allow the GA domains (checked through the actual response headers)
rq = urllib.request.Request(BASE + "/", headers={"User-Agent": "Mozilla/5.0"})
with urllib.request.urlopen(rq, timeout=10) as resp:
    csp = resp.headers.get("Content-Security-Policy", "")
ok("CSP اسکریپت googletagmanager را اجازه می‌دهد",
   "https://www.googletagmanager.com" in csp)
ok("CSP اتصال به google-analytics را اجازه می‌دهد",
   "https://www.google-analytics.com" in csp)

print(f"\n{B}۹) صفحهٔ پنل «آمار بازدید»{X}")
st, _, _ = req("/panel/analytics", ident=ME, cookie=cid)
ok("بدون کلید = ۴۰۳", st == 403, str(st))
st, body, _ = req(f"/panel/analytics?key={urllib.parse.quote(TOK)}",
                  ident=ME, cookie=cid)
ok("با کلید = ۲۰۰", st == 200, str(st))
ok("عنوان صفحه درست است", "آمار بازدید واقعی" in body)
ok("کاشی بازدیدکننده هست", "بازدیدکننده ۲۴ ساعت" in body)

print(f"\n{B}۱۰) گزارش overview عدد می‌دهد{X}")
r = analytics.overview()
ok("pv24 ≥ ۱ (همین تست‌ها)", r["pv24"] >= 1, str(r["pv24"]))
ok("uv24 ≥ ۱", r["uv24"] >= 1, str(r["uv24"]))
ok("سری ۱۴ روزه کامل است", len(r["series"]) == 14, str(len(r["series"])))
ok("بات‌ها شمرده شده‌اند", r["bots24"] >= 1, str(r["bots24"]))

print(f"\n{B}۱۱) GeoIP آفلاین: شهر از روی آی‌پی{X}")
import geoip  # noqa: E402
ok("آی‌پی تهران → تهران", geoip.lookup("80.191.42.5") == ("تهران", "تهران"),
   str(geoip.lookup("80.191.42.5")))
nj = geoip.lookup("5.123.232.10")
ok("آی‌پی نجف‌آباد → اصفهان/نجف‌آباد", nj[0] == "اصفهان" and "نجف" in nj[1], str(nj))
ok("آی‌پی خارجی → خالی صادقانه", geoip.lookup("1.1.1.1") == ("", ""))
ok("IPv6/لوپ‌بک → خالی", geoip.lookup("::1") == ("", "")
   and geoip.lookup("127.0.0.1") == ("", ""))
# NOTE: 80.191.0.0/16 (TCI) spans MANY provinces — a random host in it is
# Tehran only ~54% of the time (measured 92/200 non-Tehran). The invariant
# that matters is: the visits row carries exactly what geoip says for the IP.
TEH = f"80.191.{_r.randint(2,250)}.{_r.randint(2,250)}"
exp_prov, exp_city = geoip.lookup(TEH)
req("/", ident=TEH)
grow = db._one("SELECT prov, city FROM visits WHERE ip=? "
               "ORDER BY id DESC LIMIT 1", (TEH,))
ok("ردیف visits شهر/استان دارد",
   bool(grow) and bool(exp_prov) and grow["prov"] == exp_prov
   and grow["city"] == exp_city,
   f"{grow} != ({exp_prov},{exp_city})")

print(f"\n{B}۱۲) کمپین utm ثبت می‌شود{X}")
req("/?utm_source=insta&utm_medium=story&utm_campaign=test115",
    ident=ME, cookie=cid)
urow = db._one("SELECT utm FROM visits WHERE ip=? AND utm!='' "
               "ORDER BY id DESC LIMIT 1", (ME,))
ok("utm = insta|story|test115",
   bool(urow) and urow["utm"] == "insta|story|test115", str(urow))

print(f"\n{B}۱۳) الان آنلاین + ساعت اوج{X}")
r = analytics.overview()
ok("online ≥ ۱ (۵ دقیقهٔ اخیر)", r["online"] >= 1, str(r["online"]))
ok("شبکهٔ حرارتی ۷×۲۴", len(r["heat"]) == 7 and all(len(x) == 24
                                                    for x in r["heat"]))
ok("کمپین‌ها در گزارش هستند",
   any("insta" in (c["utm"] or "") for c in r["campaigns"]))
# 80.191/16 is multi-province (see NOTE above): the drawn IP resolves to
# Tehran only ~50% of the time, so asserting a hard-coded Tehran made this
# suite a coin-flip. The real invariant: the city geoip reported for THIS
# IP (exp_city, already proven stored in the visits row) shows in the report.
ok("شهرها در گزارش هستند",
   bool(exp_city) and any(c["city"] == exp_city for c in r["top_cities"]),
   f"expected {exp_city!r} in {[c['city'] for c in r['top_cities']]}")

print(f"\n{B}۱۴) خروجی CSV{X}")
st, body, _ = req(f"/panel/analytics/export?key={urllib.parse.quote(TOK)}"
                  "&days=30", ident=ME, cookie=cid)
ok("CSV = ۲۰۰", st == 200, str(st))
ok("سرستون‌ها درست است", body.startswith("\ufeffts_utc,path,kind,"))
ok("ردیف واقعی دارد", f",{ME}," in body)
st, _, _ = req("/panel/analytics/export", ident=ME, cookie=cid)
ok("بدون کلید = ۴۰۳", st == 403, str(st))

print(f"\n{B}۱۵) صفحهٔ آمار دکان‌دار + پاکسازی ۹۰ روزه{X}")
import views_owner as O  # noqa: E402
own = db._one("SELECT id FROM owners LIMIT 1")
if not own:
    # v285 audit (ممیزی کامل به دستور مدیر): seed_demo دیگر owner نمی‌سازد —
    # تست خودش یک مالک نمونه mint می‌کند (دادهٔ demo طبق کامنت پایین unclaimed
    # است و مکانیزم borrow دست‌نخورده می‌ماند).
    db.owner_by_phone("09120007777", create=True)
    own = db._one("SELECT id FROM owners LIMIT 1")
biz_own = db._one("SELECT id, owner_id FROM businesses "
                  "WHERE owner_id=? LIMIT 1", (own["id"],)) if own else None
borrowed = None
if own and not biz_own:
    # demo data ships unclaimed; borrow an unclaimed published business for
    # this direct-call test and give it back right after.
    borrowed = db._one("SELECT id, owner_id FROM businesses "
                       "WHERE status='published' "
                       "AND (owner_id IS NULL OR owner_id=0) LIMIT 1")
    if borrowed:
        db._run("UPDATE businesses SET owner_id=? WHERE id=?",
                (own["id"], borrowed["id"]))
        biz_own = {"id": borrowed["id"]}
if biz_own:
    html = O.stats(db.get_settings(), dict(own), biz_own["id"])
    ok("صفحهٔ آمار دکان‌دار ساخته می‌شود", bool(html))
    ok("بخش بازدیدکنندهٔ واقعی دارد", "بازدیدکنندهٔ واقعی" in (html or ""))
    ok("قیف بازدید←اقدام←سفارش دارد", "قیف ۳۰ روز" in (html or ""))
else:
    ok("دکان‌دار نمونه برای تست هست", False, "no owner/biz")
if borrowed:
    db._run("UPDATE businesses SET owner_id=NULL WHERE id=?",
            (borrowed["id"],))
old = db._run("INSERT INTO visits(ts,path,kind,ip,ua,dev,cid,sid,ref,bot) "
              "VALUES(?,?,?,?,?,?,?,?,'',0)",
              (time.time() - 91 * 86400, "/", "home", "9.9.9.9", "t",
               "desktop", "f" * 16, "e" * 16 + ".0000000000"))
db.init()
prow = db._one("SELECT ip FROM visits WHERE id=?", (old,))
ok("آی‌پی ۹۱ روزه پاک شد (حریم خصوصی)", bool(prow) and prow["ip"] == "",
   str(prow))

print()
print(f"{B}{'='*58}{X}")
print(f"  موفق: {G}{passed}{X}   ناموفق: "
      f"{(R + str(failed) + X) if failed else '0'}")
if fails:
    print(f"  {R}ناموفق‌ها:{X} " + " · ".join(fails))
    sys.exit(1)
print(f"  {G}همه موفق — آنالیتیکس واقعی کار می‌کند.{X}")
