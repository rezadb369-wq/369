#!/usr/bin/env python3
"""build_filemap.py — ساخت FILE-MAP.md: نقشهٔ کامل «هر بخش سایت کجاست»."""
import os, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True,
                          cwd=ROOT).stdout.strip()

routes = sh("python3 tools/routemap.py")

css = {}
for f in sorted(os.listdir(os.path.join(ROOT, "site/assets/css"))):
    p = os.path.join(ROOT, "site/assets/css", f)
    n = sum(1 for _ in open(p, encoding="utf-8"))
    css[f] = n

js = {}
for f in sorted(os.listdir(os.path.join(ROOT, "site/assets/js"))):
    if f.endswith(".js"):
        p = os.path.join(ROOT, "site/assets/js", f)
        n = sum(1 for _ in open(p, encoding="utf-8"))
        js[f] = n

n_img = sum(len(files) for _,_,files in os.walk(os.path.join(ROOT, "site/assets/img")))
_FA = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
def fa(n): return str(n).translate(_FA)

md = f"""# FILE-MAP — نقشهٔ کامل فایل‌های سایت (هر بخش کجاست)

> **هدف:** هر کس (یا هر عامل) بخواهد چیزی را در سایت تغییر دهد یا باگی را
> عیب‌یابی کند، از این یک سند بفهمد **فایلِ آن بخش کجاست**. این سند با
> `tools/routemap.py` و `tools/build_filemap.py` تولید می‌شود.

## ۰) یک‌نگاه — درخت پوشه‌ها

```
repo-369/
├── run.py                  نقطهٔ ورود اجرا (پورت خودکار، سقف fd، systemd-ready)
│
├── server/                 ⬅ همهٔ منطق سمت سرور (پایتون خالص، stdlib-only)
│   ├── app.py              هسته: HTTP handler + مسیریابی + auth/سشن + آپلود + هدرها
│   ├── db.py               لایهٔ داده: ۸۴ جدول، CRUD، rate_ok، مهاجرت/سازگاری SCHEMA
│   ├── features.py         زیرسیستم‌های چندجدولی: چت، سفارش، تیکت، علاقه‌مندی، چانه
│   ├── ui.py               قالب صفحات: کروم، هدر/فوتر، منو، قفل‌ها، بامپ ?vNNN
│   ├── pagecache.py        کش صفحات مهمان (TTL ۸s، ابطال با هر POST)
│   ├── shield.py           سپر ضد-اسپم/حمله: rate-limit، اسکنر، UA مخرب
│   ├── analytics.py        آمار بازدید واقعی (IP/دستگاه/نشست، فیلتر بات)
│   ├── uploads.py          پارسر multipart دستی + سقف‌ها + EXIF-strip
│   ├── sms.py              کد یک‌بارمصرف (SMS/نمایش توسعه)
│   ├── qr.py               رمزگذار QR بدون کتابخانه (SVG)
│   ├── views_public.py     صفحات عمومی: خانه، فهرست، دکان، ثبت‌نام، جست‌وجو
│   ├── views_public2.py    عمومی ۲: مقایسه، نزدیک‌من، رویداد، چانه، تماس
│   ├── views_catalog.py    کاتالوگ/ویترین/کشف
│   ├── views_chat.py       چت بلادرنگ
│   ├── views_customer.py   پنل مشتری (/me)
│   ├── views_owner.py      پنل دکان‌دار (/my)
│   ├── views_panel.py      پنل مدیر بخش ۱ (کسب‌وکارها، نظرات، محتوا…)
│   ├── views_panel2.py     پنل مدیر بخش ۲ (moderation/audit/traffic/قابلیت‌ها)
│   └── views_extra.py      صفحه‌های ریز (درباره/تماس/آفلاین)
│
├── site/                   ⬅ فایل‌های سمت مرورگر
│   ├── sw.js               سرویس‌ورکر (PWA) — VERSION اینجا بامپ می‌شود
│   ├── offline.html        صفحهٔ آفلاین فارسی
│   ├── manifest.webmanifest  مانیفست PWA (نصب روی گوشی)
│   └── assets/
│       ├── css/            {fa(len(css))} فایل — جدول آن‌ها در بخش ۲
│       ├── js/             {fa(len(js))} فایل — جدول آن‌ها در بخش ۳
│       ├── fonts/          Vazirmatn (وزیرمتن)
│       ├── img/            آیکون‌ها، لوگو، هیرو ({fa(n_img)} فایل)
│       └── vendor/         کتابخانه‌های محلی: Leaflet و… (بدون CDN)
│
├── tools/                  ⬅ ابزارها و آزمون‌ها (جدول بخش ۵)
├── data/                   ⬅ دیتابیس + آپلودها (در زیپ تحویلی نیست)
├── docs/                   گزارش‌های ممیزی، تحقیق پنل، نقشهٔ مسیرها
└── *.md                    مستندات (HANDBOOK/READY/DEPLOY/…)
```

## ۱) «این صفحه/بخش کدام فایل است؟» — جدول بخش‌ها

| بخش سایت | مسیرها | فایل‌های منطق | فایل‌های ظاهر | فایل‌های رفتار (JS) |
|---|---|---|---|---|
| صفحهٔ اصلی | `/` | `views_public.py` | `main.css`, `pages.css` | `app.js`, `stories.js` |
| فهرست/جست‌وجو/دسته‌ها | `/businesses`, `/areas` | `views_public.py` | `pages.css` | `app.js`, `catpicker.js` |
| صفحهٔ کسب‌وکار | `/b/<slug>` | `views_public.py` | `pages.css`, `main.css` | `app.js`, `gallery.js` |
| نقشه | `/map` | `views_public2.py` | `pages.css` (`.map-*`) | `mappage.js` |
| مقایسهٔ قیمت | `/prices` | `views_public2.py` | `pages.css` | `app.js` |
| کاتالوگ/ویترین | `/catalog` | `views_catalog.py` | `pages.css` | `app.js` |
| چانه‌زنی | `/haggle/*`, `/offer/*` | `views_public2.py` | `pages.css` | `app.js` |
| ثبت کسب‌وکار | `/submit` | `views_public.py` | `pages.css` | `app.js`, `catpicker.js` |
| پنل مشتری | `/me/*` | `views_customer.py` | `pages.css` | `app.js` |
| پنل دکان‌دار | `/my/*` | `views_owner.py` | `main.css`, `pages.css` | `app.js`, `imagefield.js` |
| پنل مدیر | `/panel/*` | `views_panel.py`, `views_panel2.py` | `main.css`, `pages.css` | `panel.js` |
| چت | `/chat/*` | `views_chat.py` | `pages.css` | `chat.js` |
| ورود/OTP | `/login*`, `/alert` | `app.py` (auth) + `views_public.py` | `main.css` | `app.js` |
| API | `/api/*` | `app.py` | — | — |

## ۲) فایل‌های CSS (چه چیزی کجاست)

| فایل | اندازه (خط) | نقش |
|---|---|---|
{chr(10).join(f"| `{f}` | {n} | — |" for f, n in css.items())}

- **توکن‌ها** همه در `tokens.css` (`:root` روز + `[data-theme]` شب).
- **رنگ خام در ویوها ممنوع است** (قانون معماری) — فقط توکن.
- **چیدمان موبایل:** `mobile-refine.css` و `mobile-standard.css` — هدف لمس ≥۴۴px با
  `var(--tap)`.
- **کامپوننت‌های نقشه** (نزدیک‌من/زوم/کارت انتخاب‌شده) همگی با پیشوند `.map-`
  در `pages.css`.

## ۳) فایل‌های JS (رفتار)

| فایل | خط | نقش |
|---|---|---|
{chr(10).join(f"| `{f}` | {n} | — |" for f, n in js.items())}

قانون: HTML سمت سرور رندر می‌شود؛ JS فقط رفتار (تعامل، OTP خودکار، بیکن آمار).

## ۴) نقشهٔ مسیرها (تولید خودکار)

{routes}

## ۵) ابزارها و آزمون‌ها (tools/)

| ابزار | نقش |
|---|---|
| `routemap.py` | ⭐ همین نقشهٔ مسیرها را می‌سازد (بعد از هر مسیر تازه اجرا کنید) |
| `build_filemap.py` | این سند را می‌سازد |
| `design_audit.py` | ممیزی جامع طراحی: ۹۴ صفحه × ۷ عرض، شات + متریک (tap/font/overflow/…) |
| `mobile_audit.py` | ممیزی موبایل (۴ دستگاه) |
| `contrast_audit.py` | کنتراست دو تم (AA) |
| `audit.py` | شکار کنترل‌های بی‌عمل (۴۶+ صفحه) |
| `navfit.py` | اندازه‌گیری سرریز هدر |
| `bench_load.py`, `bench_1000.py`, `bench_panel.py` | بار/کارایی (۵۰۰–۱۰۰۰ کاربر) |
| `test_*.py` (۴۰+ فایل) | باتری رگرسیون — فهرست کامل در `ARCHITECTURE.md` بخش ۷ |
| `seed_demo.py`, `reset_testdata.py` | دادهٔ نمونه / پاک‌سازی |
| `taxonomy.py`, `slice_taxonomy_icons.py` | درخت ۱۷۳ دسته و برش آیکون‌ها |
| `make_evidence*.py` | شواهد تصویری ممیزی (Playwright) |

## ۶) «برای تغییر X کجا بروم؟» — برگهٔ تقلب

| می‌خواهم… | برو به |
|---|---|
| متن/تایتل صفحه‌ای را عوض کنم | ویو همان مسیر (بخش ۱ یا جدول مسیرها) |
| رنگ/فونت/فاصله را عوض کنم | `site/assets/css/` — اول `tokens.css`، بعد `main.css`/`pages.css` |
| رفتار دکمه/فرم را عوض کنم | `site/assets/js/app.js` (یا فایل JS همان بخش) |
| مسیر جدید اضافه کنم | `server/app.py` → `route_get`/`route_post` + ویو مناسب |
| ستون/جدول جدید در دیتابیس | `server/db.py` → `SCHEMA` + `_reconcile_schema()` (مهاجرت خودکار) |
| سقف/قاعدهٔ امنیتی | `server/shield.py` + `db.rate_ok` + `SECURITY_HEADERS` در app.py |
| کش/سرعت | `server/pagecache.py` + بخش gzip/ETag در `app.py` |
| نسخهٔ assetها را بامپ کنم | `server/ui.py` (`?vNNN`) + `site/sw.js` (`VERSION`) + `tools/test_migration.py` |
| باگی در پنل مدیر | `views_panel.py` / `views_panel2.py` + `test_panel_*.py` |
| استقرار روی هاست | `DEPLOY.md` + `docs/HOSTING-v119.md` |
"""

out = os.path.join(ROOT, "docs", "FILE-MAP.md")
with open(out, "w", encoding="utf-8") as f:
    f.write(md)
print("FILE-MAP.md:", len(md), "chars")
