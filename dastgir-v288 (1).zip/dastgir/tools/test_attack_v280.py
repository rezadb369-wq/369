#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v280 — فاز ۶ امنیت: تهاجم زنده روی سایت در حال اجرا.

دستور مدیر: سناریوهای تهاجمی برنامهٔ امنیت (فاز۶) — هرکدام باید روی سرور
زنده شکست بخورند:
۱) طوفان محتوایی نظر (سیل متن یکسان => hold/reject)؛
۲) تهاجم‌گر چندکنشی => پلهٔ تنبیه ban می‌دهد؛
۳) سیل «فراخوان قیمت» از یک IP => ۴۲۹ و سپس ban (۴۰۳)؛
۴) پایداری ban: در بکاپ هست و پس از «ری‌استارت» هم برقرار؛
۵) honeypot: نظر/پرسش با فیلد تله بی‌صدا دور ریخته می‌شوند؛
۶) پمپ رأی پرسش: ۳۰ رأی از یک رأی‌دهنده => شمار ۱؛
۷) scrape جست‌وجو: سقف always => ۴۲۹؛
۸) تورم بیکن بازدید استوری: deny ثبت می‌شود (پاسخ بی‌صدا)؛
۹) slowloris: اتصال نیمه‌باز، سرویس‌دهی به بقیه را نمی‌خواباند.
"""
import os
import socket
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="atk280-")
os.environ["BZ_DATA_DIR"] = TMP
sys.path.insert(0, str(ROOT / "server"))

import db          # noqa: E402
import antispam    # noqa: E402

db.init()
n = 0


def ck(ok, label):
    global n
    assert ok, label
    n += 1
    print("  ✓", label)


con = db.connect()
con.execute("INSERT INTO categories(slug,name) VALUES('t280x','آزمون')")
con.execute("INSERT INTO businesses(name,cat_slug,slug,status) "
            "VALUES('دکان حمله','t280x','b280x','published')")
con.commit(); con.close()
qid = db.add_question(1, "پرسشگر", "آیا باز هستید؟")

import app  # noqa: E402
srv = app.make_server(8101)
threading.Thread(target=srv.serve_forever, daemon=True).start()
time.sleep(0.4)


def req(path, data=None, ident="203.0.113.60", ua="atk/280"):
    body = urllib.parse.urlencode(data, encoding="utf-8").encode() if data else None
    r = urllib.request.Request("http://127.0.0.1:8101" + path, data=body,
                               headers={"X-Forwarded-For": ident, "User-Agent": ua})

    class NoRedir(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None
    op = urllib.request.build_opener(NoRedir)
    try:
        with op.open(r, timeout=10) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


# ---------- 1) طوفان محتوایی نظر (متن یکسان بدون پرچم => نردبان dup) ----------
SPAM = "این یک نظر تکراری اسپم برای پرکردن صفحه است"
for i in range(6):
    req("/b/b280x/review", {"author": "ربات‌نما", "body": SPAM,
                            "rating": "5"}, ident="203.0.113.61")
rows = db.connect().execute("SELECT spam_flag,status FROM reviews").fetchall()
saved = len(rows)
held = sum(1 for r in rows if r["spam_flag"])
ck(saved == 4, "سیل ۶ نظر یکسان => ۴ تا ذخیره (بار ۵ و ۶ reject بی‌صدا)")
ck(held >= 2, "بار ۳ و ۴ با spam_flag=1 نگه‌بررسی شدند")

# ---------- 2) تهاجم‌گر چندکنشی => ban ----------
antispam.policy_set("fav", 1, 600)
for _ in range(9):
    antispam.guard("fav", "203.0.113.62")
ck(antispam.banned("203.0.113.62"),
   "denyهای پیاپی (چندکنشی) => پلهٔ تنبیه ban می‌دهد")
antispam.policy_clear("fav")

# ---------- 3) سیل فراخوان قیمت از یک IP ----------
codes = [req("/prices/alert", {"key": "x", "on": "1"},
             ident="203.0.113.63")[0] for _ in range(16)]
ck(429 in codes, "پس از سقف pricealert => ۴۲۹")
ck(antispam.banned("203.0.113.63"), "۶ deny => ban خودکار")
st, _b = req("/", ident="203.0.113.63")
ck(st == 403, "IP بن‌شده از shield => ۴۰۳")

# ---------- 4) پایداری ban (بکاپ + ری‌استارت) ----------
exp = db.export_all()
ck(any(b.get("ident") == "203.0.113.63" for b in exp.get("spam_bans", [])),
   "ban در بکاپ صادر می‌شود (پس از restore هم هست)")
ck(antispam.banned("203.0.113.63"),
   "ban از دیتابیس خوانده می‌شود — ری‌استارت پاکش نمی‌کند")

# ---------- 5) honeypot نظر/پرسش ----------
before_r = db.connect().execute("SELECT COUNT(*) c FROM reviews").fetchone()["c"]
req("/b/b280x/review", {"author": "ربات", "body": "نظر واقعی و محترمانه.",
                        "rating": "5", "website_hp": "http://bot"},
    ident="203.0.113.64")
after_r = db.connect().execute("SELECT COUNT(*) c FROM reviews").fetchone()["c"]
ck(after_r == before_r, "honeypot نظر: ارسال بات بی‌صدا دور ریخته شد")
before_q = db.connect().execute("SELECT COUNT(*) c FROM questions").fetchone()["c"]
req("/b/b280x/ask-question", {"asker": "ربات", "body": "پرسش بلند enough",
                              "website_hp": "x"}, ident="203.0.113.65")
after_q = db.connect().execute("SELECT COUNT(*) c FROM questions").fetchone()["c"]
ck(after_q == before_q, "honeypot پرسش: ارسال بات بی‌صدا دور ریخته شد")

# ---------- 6) پمپ رأی پرسش ----------
for _ in range(30):
    req("/api/question-helpful", {"id": str(qid)}, ident="203.0.113.66")
cnt = db._one("SELECT helpful FROM questions WHERE id=?", (qid,))["helpful"]
ck(cnt == 1, "۳۰ رأی از یک رأی‌دهنده => شمار ۱ (دِدوپ question_votes)")

# ---------- 7) scrape جست‌وجو ----------
codes = [req("/businesses?q=" + urllib.parse.quote("دکان"),
             ident="203.0.113.67")[0] for _ in range(65)]
ck(codes.count(429) >= 1, "سقف always جست‌وجو => ۴۲۹ برای جاروگر")

# ---------- 8) تورم بیکن بازدید استوری ----------
codes = [req("/api/stories/1/view", ident="203.0.113.68")[0] for _ in range(65)]
row = db._one("SELECT COUNT(*) c FROM spam_events WHERE ident='203.0.113.68' "
              "AND verdict='deny' AND gate='view'")
ck(row and row["c"] >= 1, "بیکن بازدید: از سقف به بعد deny ثبت می‌شود")
ck(500 not in codes, "پین v280-fix: پاسخ دوم روی اتصال => هرگز ۵۰۰")

# ---------- 9) slowloris ----------
s1 = socket.create_connection(("127.0.0.1", 8101), timeout=5)
s1.sendall(b"GET / HTTP/1.1\r\nHost: x\r\n")   # بدون پایان هدر — اتصال نیمه‌باز
time.sleep(0.3)
st, _b = req("/", ident="203.0.113.69")
ck(st == 200, "اتصال نیمه‌باز (slowloris) سرویس‌دهی به بقیه را نمی‌خواباند")
ck(getattr(app.App, "timeout", 0) == 30, "Handler.timeout=30 — نخ تا ابد نگه داشته نمی‌شود")
s1.close()

print("ATTACK v280 PASS %d" % n)
