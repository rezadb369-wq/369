#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v276 — فاز ۲ امنیت: هوش محتوایی + honeypot + دِدوپ رأی پرسش + سقف فرم متنی.

دستور مدیر: سیستم ضداسپم چندفازی. فاز ۲ = لایهٔ محتوا:
۱) پرچم‌های محتوایی (سیل لینک، نویسه‌های نامرئی/RTL-override، طول انفجاری)؛
۲) تکرار سراسری یک متن: ۳بار=hold / ۵بار=reject؛
۳) honeypot روی فرم تیکت (نظر/پرسش از قبل داشتند)؛
۴) question_votes = دِدوپ رأی «مفید» پرسش (موازی review_votes، رفع G10)؛
۵) سقف ۶۴KB فرم متنی (G19) با ۴۱۳ و نام gate.
"""
import os
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="asv276-")
os.environ["BZ_DATA_DIR"] = TMP
sys.path.insert(0, str(ROOT / "server"))

import db          # noqa: E402
import antispam    # noqa: E402

db.init()
n = 0


def ck(ok, label):
    global n
    assert ok, label
    n += 1
    print("  ✓", label)


# ---------- 1. پرچم‌های محتوایی ----------
f1, r1 = antispam.content_score("خرید عالی http://a http://b https://c.t www.x")
ck(f1 >= 2 and any(x.startswith("links") for x in r1), "سیل لینک => پرچم")
f2, r2 = antispam.content_score("متن \u202e\u202e\u202e\u200e\u200f پنهان")
ck(f2 >= 2 and any(x.startswith("invisible") for x in r2), "نویسهٔ نامرئی/RTL => پرچم")
f3, _ = antispam.content_score("یک نظر معمولی و محترمانه دربارهٔ این دکان.")
ck(f3 == 0, "متن سالم بدون پرچم")

# ---------- 2. تکرار سراسری: hold و reject ----------
v1, _ = antispam.content_gate("review", "u1", "متن تکراری اسپم شماره یک")
v2, _ = antispam.content_gate("review", "u2", "متن تکراری اسپم شماره یک")
v3, _ = antispam.content_gate("review", "u3", "متن تکراری اسپم شماره یک")
ck(v1 == "ok" and v2 == "ok" and v3 == "hold",
   "سومین تکرار سراسری همان متن => hold")
antispam.content_gate("review", "u4", "متن تکراری اسپم شماره یک")
v5, _ = antispam.content_gate("review", "u5", "متن تکراری اسپم شماره یک")
ck(v5 == "reject", "پنجمین تکرار => reject (سیل یک‌متنی)")

# ---------- 3. دِدوپ رأی پرسش (G10) ----------
con = db.connect()
con.execute("INSERT INTO categories(slug,name) VALUES('t276','آزمون')")
con.execute("INSERT INTO businesses(name,cat_slug,slug,status) VALUES('دکان آزمون','t276','t276','published')")
con.commit(); con.close()
qid = db.add_question(1, "پرسشگر", "آیا باز هستید؟")
a = db.question_helpful(qid, "k voter1")
b = db.question_helpful(qid, "k voter1")   # تکرار همان رأی‌دهنده
c = db.question_helpful(qid, "k voter2")
ck(a == 1 and b == 1 and c == 2, "رأی تکراری پرسش شمرده نمی‌شود (G10)")

# ---------- 4. HTTP زنده ----------
import app  # noqa: E402
srv = app.make_server(8096)
threading.Thread(target=srv.serve_forever, daemon=True).start()
time.sleep(0.4)


def post(path, data, ident="6.6.6.6"):
    body = urllib.parse.urlencode(data, encoding="utf-8").encode()
    r = urllib.request.Request("http://127.0.0.1:8096" + path, data=body,
                               headers={"X-Forwarded-For": ident})
    class NoRedir(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None
    try:
        with urllib.request.urlopen(r, timeout=10) as resp:
            return resp.status, dict(resp.headers), resp.read()[:100]
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read()[:100]


# honeypot: فرم تیکت با فیلد تله پر شده => حذف بی‌صدا (بدون ساخت تیکت)
before = db.connect().execute("SELECT COUNT(*) c FROM tickets").fetchone()["c"]
st, hd, _ = post("/my/tickets", {"subject": "سلام", "body": "متن تیکت",
                                 "website_hp": "http://bot"})
after = db.connect().execute("SELECT COUNT(*) c FROM tickets").fetchone()["c"]
ck(after == before, "honeypot تیکت: ارسال بات بی‌صدا دور ریخته شد")

# hold: نظر با سیل لینک => ذخیره با spam_flag=1 و بدون انتشار خودکار
st, hd, _ = post("/b/t276/review", {"author": "کاربر", "body":
                 "بخرید http://a http://b https://c www.d", "rating": "5"})
row = db.connect().execute("SELECT spam_flag,status FROM reviews ORDER BY id DESC LIMIT 1").fetchone()
ck(row and row["spam_flag"] == 1 and row["status"] == "pending",
   "نظر پرچم‌خورده => spam_flag=1 + status=pending (نگه برای بررسی)")

# G19: فرم متنی بالای ۶۴KB => 413 با نام gate
big = "x" * 70000
st, hd, body = post("/subscribe", {"phone": "09120000000", "term": big})
ck(st == 413 and b"bodycap" in body, "فرم متنی غول‌پیکر => 413 با نام gate")

print("ANTISPAM v276 PASS %d" % n)
