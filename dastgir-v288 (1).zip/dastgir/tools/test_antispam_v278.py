#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v278 — فاز ۴ امنیت: ثبت کسب‌وکار/محصول/فراخوان.

دستور مدیر: سیستم ضداسپم چندفازی. فاز ۴:
۱) ویزارد/بات: سطل per-IP (regip) + cooldown ثبت هم‌هویت (regsub، ۲ در ۳۰دقیقه)
   + تشخیص نام/تلفن/نشانی تقریباً تکراری => رویداد hold برای moderation؛
۲) کالای با عنوان تکراری => spam_flag=1 (نگه‌بررسی) — از دید عمومی پنهان،
   در کاتالوگ مالک/مدیر با نشان可见؛ مدیر با «رفع نگه‌بررسی» آزاد می‌کند؛
۳) «خبرم کن»: dedup ۲۴ساعته پس از fulfill/dismiss (درگاه: stockdup)؛
۴) پین v275: سطل‌های fav/follow/claim/itemsave در POLICY مرکزی.
"""
import os
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="asv278-")
os.environ["BZ_DATA_DIR"] = TMP
sys.path.insert(0, str(ROOT / "server"))

import db          # noqa: E402
import antispam    # noqa: E402
import bot_register as R  # noqa: E402

db.init()
n = 0


def ck(ok, label):
    global n
    assert ok, label
    n += 1
    print("  ✓", label)


# ---------- آماده‌سازی داده ----------
con = db.connect()
con.execute("INSERT INTO categories(slug,name) VALUES('t278','آزمون')")
con.execute("INSERT INTO businesses(name,cat_slug,slug,status) "
            "VALUES('دکان آزمون','t278','t278','published')")
con.execute("INSERT INTO owners(phone) VALUES('09120000278')")
con.commit()
_oid = con.execute("SELECT id FROM owners WHERE phone='09120000278'").fetchone()[0]
con.execute("UPDATE businesses SET owner_id=? WHERE id=1", (_oid,))
con.commit(); con.close()
BIZ = 1
OWNER = db._one("SELECT id FROM owners WHERE phone='09120000278'")["id"]
cust = db.customer_by_phone("09120000278", create=True)
CID = cust["id"]

# ---------- 1. عنوان تکراری => نگه‌بررسی ----------
i1 = db.save_item({"biz_id": BIZ, "kind": "product", "title": "کالای یکتای ۲۷۸",
                   "price": 1000, "price_type": "fixed", "available": 1},
                  dup_hold=True)
i2 = db.save_item({"biz_id": BIZ, "kind": "product", "title": "کالای یکتای ۲۷۸",
                   "price": 2000, "price_type": "fixed", "available": 1},
                  dup_hold=True)
i3 = db.save_item({"biz_id": BIZ, "kind": "product", "title": "کالای یکتای 278",
                   "price": 3000, "price_type": "fixed", "available": 1},
                  dup_hold=True)   # همان عنوان با یونیدigit/نیم‌فاصله نرمال‌شده
i4 = db.save_item({"biz_id": BIZ, "kind": "product", "title": "کالای یکتای ۲۷۸",
                   "price": 4000, "price_type": "fixed", "available": 1})  # مدیر
ck(not db.item(i1)["spam_flag"], "اولین کالا بدون پرچم ذخیره می‌شود")
ck(db.item(i2)["spam_flag"] == 1 and db.item(i3)["spam_flag"] == 1,
   "عنوان تکراری (حتی نرمال‌شده) => spam_flag=1")
ck(not db.item(i4)["spam_flag"], "مسیر مدیر بدون dup_hold پرچم نمی‌گیرد")

# ---------- 2. دید عمومی در برابر دید مالک ----------
pub = [r["id"] for r in db.items(biz_id=BIZ)]
own = [r["id"] for r in db.items(biz_id=BIZ, include_flagged=True)]
ck(i1 in pub and i2 not in pub, "کالای پرچم‌خورده از دید عمومی پنهان است")
ck(i2 in own, "کاتالوگ مالک/مدیر پرچم‌خورده را می‌بیند (include_flagged)")
ck(i2 not in [r["id"] for r in db.search_items("کالای")],
   "جست‌وجوی عمومی هم پرچم‌خورده را برنمی‌گرداند")

# ---------- 3. dedup «خبرم کن» (stockdup) ----------
ok1, _m1 = db.stock_request_add(BIZ, i1, CID)
rid = db._one("SELECT id FROM stock_requests WHERE customer_id=? "
              "ORDER BY id DESC LIMIT 1", (CID,))["id"]
ck(ok1, "اولین «خبرم کن» ثبت می‌شود")
db.stock_request_fulfill(rid, OWNER)
ok2, m2 = db.stock_request_add(BIZ, i1, CID)
ck(not ok2 and "stockdup" in m2,
   "درخواست دوبارهٔ همان مورد زیر ۲۴ ساعت => no-op با نام درگاه")
db._run("UPDATE stock_requests SET fulfilled=datetime('now','-25 hours') "
        "WHERE id=?", (rid,))
ok3, _m3 = db.stock_request_add(BIZ, i1, CID)
ck(ok3, "پس از ۲۴ ساعت درخواست دوباره آزاد است")

# ---------- 4. cooldown ثبت هم‌هویت (regsub) ----------
def full_draft(name):
    d = R.start(CID, "web")
    R.web_save(CID, {"cat_slug": "t278", "cat_name": "آزمون", "name": name,
                     "city": "نجف‌آباد", "address": "خیابان آزمون، پلاک ۱",
                     "phone_public": False, "hours": {}})
    db._run("UPDATE biz_reg_drafts SET step='preview' WHERE customer_id=?", (CID,))
    return R.prepare_confirm(CID)


tok1 = full_draft("کسب‌وکار نخست ۲۷۸")
bid1, err1 = R.submit(CID, tok1, "09120000278")
ck(bid1 is not None, "اولین ثبت کسب‌وکار موفق است (%s)" % (err1 or "ok"))
# یک ثبت تازهٔ دیگر برای همان مالک (سومین ثبت در ۳۰ دقیقه => رد)
db._run("INSERT INTO businesses(name,cat_slug,slug,status,owner_id) "
        "VALUES('کسب‌وکار دوم ۲۷۸','t278','t278-b','pending',?)", (OWNER,))
tok2 = full_draft("کسب‌وکار سوم ۲۷۸")
bid2, err2 = R.submit(CID, tok2, "09120000278")
ck(bid2 is None and "regsub" in (err2 or ""),
   "سومین ثبت در ۳۰ دقیقه => رد با نام درگاه regsub")

# ---------- 5. پین v275: سطل‌های کنش‌ها ----------
ck(all(a in antispam.POLICY for a in ("fav", "follow", "claim", "itemsave")),
   "fav/follow/claim/itemsave در POLICY مرکزی هستند (پین v275)")

# ---------- 6. HTTP: صفحهٔ عمومی ----------
import app  # noqa: E402
srv = app.make_server(8098)
threading.Thread(target=srv.serve_forever, daemon=True).start()
time.sleep(0.4)


def get(path, ident="203.0.113.90"):
    r = urllib.request.Request("http://127.0.0.1:8098" + path,
                               headers={"X-Forwarded-For": ident})
    try:
        with urllib.request.urlopen(r, timeout=10) as resp:
            return resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


st, body = get("/b/t278")
ck("کالای یکتای ۲۷۸" in body, "کالای سالم در صفحهٔ عمومی هست")
st2, body2 = get("/item/%d" % i2)
st3, _b3 = get("/item/%d" % i1)
ck(st2 == 404 and st3 == 200,
   "صفحهٔ کالای پرچم‌خورده برای عموم ۴۰۴ و کالای سالم ۲۰۰ است")

print("ANTISPAM v278 PASS %d" % n)
