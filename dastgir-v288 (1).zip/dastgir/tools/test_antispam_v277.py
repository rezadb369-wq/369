#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v277 — فاز ۳ امنیت: سخت‌سازی ورود حساب.

دستور مدیر: سیستم ضداسپم چندفازی. فاز ۳ = لایهٔ ورود/احراز:
۱) secret غلط وب‌هوک = deny قطعی؛ ۶ deny در ۱۰دق => بلاک موقت IP (قابل‌دسترس)؛
۲) قفل تأیید loginlock: ۵ تأیید ناموفق برای (شماره،IP) یا (نام‌کاربری،IP)
   => ۱۵دقیقه — مسیرهای OTP/رمز از v186 با ۴۰۴ بسته‌اند، قفل defence in depth؛
۳) سطل per-شماره با هش + تنوع شماره per-IP در صدور OTP (همان وضعیت)؛
۴) پین G18: پاسخ ورود برای شمارهٔ ثبت‌شده/نشده کاملاً یکسان (ضد enumeration).
"""
import os
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="asv277-")
os.environ["BZ_DATA_DIR"] = TMP
sys.path.insert(0, str(ROOT / "server"))

import db          # noqa: E402
import antispam    # noqa: E402

db.init()
n = 0


def ck(ok, label):
    global n
    assert ok, label
    n += 1
    print("  ✓", label)


# ---------- 1. قفل تأیید (واحد) ----------
db.login_fail("t277|k1")
db.login_fail("t277|k1")
db.login_fail("t277|k1")
db.login_fail("t277|k1")
locked, fails = db.login_fail("t277|k1")
ck(locked and fails == 5, "پنجمین تأیید ناموفق => قفل ۱۵دقیقه")
ck(db.login_locked("t277|k1"), "login_locked پس از قفل True است")
db.login_fail_clear("t277|k1")
ck(not db.login_locked("t277|k1"), "پاک‌سازی کلید => قفل برداشته می‌شود")

# ---------- 2. strike و پلهٔ تنبیه (واحد) ----------
for _ in range(antispam.STRIKE_LIMIT):
    antispam.strike("9.9.0.1", "webhook", "secret")
ck(antispam.banned("9.9.0.1"), "۶ secret غلط => ban ماندگار موقت")
antispam.lift("9.9.0.1")

# ---------- 3. تنوع شماره per-IP (واحد) ----------
antispam.enum_check("203.0.99.1", "aaa")
antispam.enum_check("203.0.99.1", "bbb")
cnt = antispam.enum_check("203.0.99.1", "ccc")
row = db._one("SELECT COUNT(*) c FROM spam_events WHERE ident=? AND verdict='deny' "
              "AND gate='logindiv'", ("203.0.99.1",))
ck(cnt == 3 and row and row["c"] >= 1,
   "سومین شمارهٔ متفاوت از یک IP => رویداد deny با gate=logindiv")

# ---------- 4. HTTP زنده ----------
import app  # noqa: E402
srv = app.make_server(8097)
threading.Thread(target=srv.serve_forever, daemon=True).start()
time.sleep(0.4)


def req(path, data=None, ident="203.0.113.50"):
    headers = {"X-Forwarded-For": ident}
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data, encoding="utf-8").encode()
    r = urllib.request.Request("http://127.0.0.1:8097" + path, data=body,
                               headers=headers)

    class NoRedir(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None
    op = urllib.request.build_opener(NoRedir)
    try:
        with op.open(r, timeout=10) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


# ---------- پین G18: یکتایی پاسخ ورود ----------
# v186: ورود فقط پیام‌رسان است — درِ OTP برای همه یکسان ۴۰۴ می‌شود؛
# این پین تضمین می‌کند شمارهٔ ثبت‌شده/نشده هیچ تفاوتی ایجاد نمی‌کند.
db.customer_by_phone("09120000277", create=True)     # شمارهٔ ثبت‌شده
st1, body1 = req("/login", {"phone": "09120000277"}, ident="203.0.113.51")
st2, body2 = req("/login", {"phone": "09120009277"}, ident="203.0.113.52")  # نشده
ck(st1 == st2 == 404 and body1 == body2,
   "G18: پاسخ ورود برای شمارهٔ ثبت‌شده/نشده کاملاً یکسان است")

st3, _b3 = req("/login/verify", {"phone": "09120000277", "code": "12345"},
               ident="203.0.113.53")
st4, _b4 = req("/login/password", {"username": "x", "password": "y"},
               ident="203.0.113.54")
ck(st3 == 404 and st4 == 404,
   "درهای OTP/رمز بسته می‌مانند (۴۰۴) — احیای بی‌صدا ممکن نیست")

# ---------- secret غلط وب‌هوک => بلاک IP ----------
# (وب‌هوک در do_POST است؛ دادهٔ فرم می‌فرستیم تا مسیر POST شود)
for _ in range(antispam.STRIKE_LIMIT):
    st, _b = req("/api/bale/webhook/" + "x" * 40, {"a": "b"},
                 ident="203.0.113.81")
    assert st == 404, "secret غلط همیشه ۴۰۴ می‌ماند (بدون نشت)"
ck(antispam.banned("203.0.113.81"),
   "۶ secret غلط وب‌هوک => ban خودکار IP")
st, body = req("/", ident="203.0.113.81")
ck(st == 403, "IP بلاک‌شده از طریق shield رد می‌شود (۴۰۳)")
ck(not antispam.banned("203.0.113.50"), "IPهای سالم بلاک نشده‌اند")

print("ANTISPAM v277 PASS %d" % n)
