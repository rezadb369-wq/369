#!/bin/bash
# audit_harness.sh — per-suite fresh scene: wipe DB, seed demo, boot server, run suite.
# Usage: bash tools/audit_harness.sh <results-file> [suite...]
cd /home/user/dastgir || exit 1
RES="${1:-/tmp/audit-results.txt}"; shift || true
SUITES="$@"
if [ -z "$SUITES" ]; then
  SUITES="test_all test_v3 test_v3_owner test_chat_v73 test_gates test_haggle test_actions test_prices test_analytics test_discovery test_favorites_v74 test_isolation test_migration test_panel_mod test_remaining_v76 test_section4_v75 test_v68 test_v69 test_tickets test_trash test_broadcast_v156 test_notif_v142 test_abuse test_admin_extras test_audit_fixes test_register_web_v208 test_open test_privacy test_privacy_v117 test_robustness test_security test_panel_robust test_panel_security test_panel_ux test_panel_perf_v184 test_pentest test_brand_browser_v179 test_browser test_open_parity test_public_perf_v184 test_appearance test_context test_section1 test_category_images_v181 test_icon_search_v182 test_live"
fi
: > "$RES"
# kill anything on 8080 first
PID8080=$(ss -tlnp 2>/dev/null | grep ':8080 ' | grep -oP 'pid=\K[0-9]+' | head -1)
[ -n "$PID8080" ] && kill "$PID8080" 2>/dev/null && sleep 1
for t in $SUITES; do
  D=/tmp/audit-scene
  rm -rf "$D"; mkdir -p "$D"
  BZ_DATA_DIR="$D" python3 tools/seed_demo.py > "$D/seed.log" 2>&1
  BZ_DATA_DIR="$D" PORT=8080 python3 run.py > "$D/srv.log" 2>&1 &
  SRV=$!
  for i in $(seq 1 40); do
    curl -s -o /dev/null http://127.0.0.1:8080/healthz && break
    sleep 0.25
  done
  out=$(BZ_DATA_DIR="$D" BZ=http://127.0.0.1:8080 timeout 300 python3 "tools/$t.py" 2>&1)
  rc=$?
  kill $SRV 2>/dev/null; wait $SRV 2>/dev/null
  tb=$(grep -c "Traceback" "$D/srv.log" 2>/dev/null)
  echo "SUITE $t rc=$rc srv_tracebacks=$tb | $(echo "$out" | tail -1 | cut -c1-100)" >> "$RES"
  if [ "$rc" -ne 0 ]; then
    echo "$out" | grep -aE "✗|FAIL|AssertionError|Error" | head -5 >> "$RES"
  fi
done
echo HARNESS_DONE >> "$RES"
