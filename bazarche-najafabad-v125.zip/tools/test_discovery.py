# -*- coding: utf-8 -*-
"""
Discoverability tests.

Written after the owner reported "the site looks like the old prototype".
Nothing was missing — every feature worked — but the shopkeeper features live
behind /login and the sign-in button said nothing about what was behind it, so
from the public menu the site looked unchanged. These tests lock in the fix:

  * the perk list is visible in the menu BEFORE signing in
  * /features lists every capability, each row a working link
  * ?next= survives both OTP steps and lands on the requested page
  * ?next= cannot be turned into an open redirect

Run against a live server:
    BZ=http://127.0.0.1:8080 python3 tools/test_discovery.py
"""

import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"

passed = failed = 0
fails = []


def ok(label, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  {G}✓{X} {label}")
    else:
        failed += 1
        fails.append(label)
        print(f"  {R}✗{X} {label}   {detail}")


class Client:
    """Cookie-keeping client that does not auto-follow redirects."""

    def __init__(self):
        self.cj = http.cookiejar.CookieJar()

        class NoRedir(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *a, **k):
                return None

        self.op = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.cj), NoRedir)

    def get(self, path):
        try:
            r = self.op.open(BASE + path, timeout=20)
            return r.getcode(), r.read().decode("utf-8", "ignore"), r.headers
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "ignore"), e.headers

    def post(self, path, data):
        body = urllib.parse.urlencode(data).encode()
        try:
            r = self.op.open(BASE + path, body, timeout=20)
            return r.getcode(), r.read().decode("utf-8", "ignore"), r.headers
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "ignore"), e.headers


def otp_from(html):
    m = re.search(r'letter-spacing:.2em">(\d{5})<', html)
    return m.group(1) if m else ""


def main():
    # login is rate-limited per client; the suite runs from one loopback IP,
    # so clear stale buckets from previous runs before anything logs in.
    try:
        import db as _db0
        _db0.rate_clear()
    except Exception:
        pass
    print(f"\n{B}══ آزمون پیدا‌شدنی‌بودن قابلیت‌ها ══{X}\n")

    # ---------------------------------------------------------- perks in menu
    print(f"{B}۱) فهرست مزایا در منو، پیش از ورود{X}")
    c = Client()
    code, home, _ = c.get("/")
    ok("صفحهٔ اصلی باز می‌شود", code == 200, f"HTTP {code}")
    ok("بلوک مزایا در منو هست", "mnav-perks" in home)
    ok("عنوان بلوک درست است", "با ثبت دکان چه چیزی می‌گیرید" in home)
    for label in ("بارکد QR ویترین", "نوبت‌دهی اینترنتی",
                  "گفت‌وگو با مشتریان", "پشتیبانی مستقیم"):
        ok(f"مزیت «{label}» دیده می‌شود", label in home)
    ok("لینک همهٔ امکانات در منو هست", 'href="/features"' in home)
    # every perk must carry a working ?next=
    nexts = re.findall(r'/login\?next=([^"]+)', home)
    ok("لینک‌های مزایا ?next= دارند", len(nexts) >= 6, f"{len(nexts)} مورد")

    # -------------------------------------------------------- features page
    print(f"\n{B}۲) صفحهٔ /features{X}")
    code, feats, _ = c.get("/features")
    ok("صفحه باز می‌شود", code == 200, f"HTTP {code}")
    ok("عنوان درست است", "هر کاری در بازارچه می‌شود کرد" in feats)
    ok("بخش مردم شهر هست", "برای مردم شهر" in feats)
    ok("بخش صاحبان کسب‌وکار هست", "برای صاحبان کسب‌وکار" in feats)
    cards = re.findall(r'class="feat-card" href="([^"]+)"', feats)
    ok("کارت‌ها ساخته شده‌اند", len(cards) >= 18, f"{len(cards)} کارت")
    ok("قفل روی بخش دکان‌دار هست", "feat-lock" in feats)

    # every single card must resolve — no dead links on the map of the site
    dead = []
    for href in cards:
        target = href.split("?")[0]
        st, _, hd = c.get(href)
        if st not in (200, 303, 302):
            dead.append((href, st))
    ok("هیچ کارتی لینک مرده نیست", not dead, str(dead[:3]))

    # ------------------------------------------------------------ next chain
    print(f"\n{B}۳) زنجیرهٔ ?next= در ورود{X}")
    phone = "09134900001"
    c2 = Client()
    code, page1, _ = c2.get("/login?next=%2Fmy%2Fbookings")
    ok("صفحهٔ ورود با next باز می‌شود", code == 200, f"HTTP {code}")
    ok("فیلد پنهان next ساخته شد",
       'name="next" value="/my/bookings"' in page1)

    code, page2, _ = c2.post("/login", {"phone": phone, "next": "/my/bookings"})
    ok("مرحلهٔ کد باز شد", code == 200, f"HTTP {code}")
    ok("next در مرحلهٔ دوم حفظ شد",
       'name="next" value="/my/bookings"' in page2)

    otp = otp_from(page2)
    ok("کد آزمایشی نمایش داده شد", len(otp) == 5, otp)
    if otp:
        code, _, hd = c2.post("/login/verify",
                              {"phone": phone, "code": otp,
                               "next": "/my/bookings"})
        loc = hd.get("Location", "")
        ok("پس از ورود به مقصد درست رفت", loc == "/my/bookings", loc)

    # -------------------------------------------------------- open redirect
    print(f"\n{B}۴) ?next= نباید ریدایرکت باز بسازد{X}")
    # the login endpoint is rate-limited per client (SMS cost control); the
    # test below logs in repeatedly from the same loopback address, so clear
    # the bucket first — otherwise the legitimate cap masquerades as a failure.
    try:
        import db as _db
        _db.rate_clear()
    except Exception:
        pass
    attacks = ["https://evil.com", "//evil.com", "/panel?key=x",
               "javascript:alert(1)", "/my/../panel", "/panel"]
    for i, bad in enumerate(attacks):
        # login is rate-limited per client (SMS cost control); clear the bucket
        # before EACH attempt so the security cap doesn't mask the redirect test.
        try:
            _db.rate_clear()
        except Exception:
            pass
        ph = "0913491%04d" % i
        c3 = Client()
        _, p2, _ = c3.post("/login", {"phone": ph, "next": bad})
        code = otp_from(p2)
        if not code:
            ok(f"«{bad}» — کد صادر نشد", False, "کد پیدا نشد")
            continue
        _, _, hd = c3.post("/login/verify",
                           {"phone": ph, "code": code, "next": bad})
        loc = hd.get("Location", "")
        ok(f"«{bad}» دفع شد", loc.startswith("/my") and "panel" not in loc, loc)

    # ------------------------------------------------- owner nav completeness
    print(f"\n{B}۵) منوی دکان‌دار کامل است{X}")
    c4 = Client()
    ph = "09134920001"
    _, p2, _ = c4.post("/login", {"phone": ph})
    code = otp_from(p2)
    if code:
        c4.post("/login/verify", {"phone": ph, "code": code})
        st, my, _ = c4.get("/my")
        ok("داشبورد باز شد", st == 200, f"HTTP {st}")
        for href, label in [("/my/tickets", "پشتیبانی"),
                            ("/my/bookings", "نوبت‌ها"),
                            ("/my/chats", "گفت‌وگوها")]:
            ok(f"«{label}» در منوی دکان‌دار", href in my)
        # haggling is off by default (v65) — its inbox only appears when enabled
        haggle_on = _db.haggle_settings().get("enabled")
        if haggle_on:
            ok("«پیشنهادهای قیمت» در منوی دکان‌دار (چانه‌زنی فعال)",
               "/my/offers" in my)
        else:
            ok("چانه‌زنی خاموش → «پیشنهادهای قیمت» در منو نیست",
               "/my/offers" not in my)
        # signed in, the features page must drop the locks
        st, f2, _ = c4.get("/features")
        ok("قفل‌ها پس از ورود برداشته شد", "feat-lock" not in f2)

    # ------------------------------------------------------------- home page
    print(f"\n{B}۶) کارت‌های مزیت در صفحهٔ اصلی لینک دارند{X}")
    ok("مزایای صفحهٔ اصلی <a> شده‌اند", 'class="feat-card reveal"' in home)
    perk_links = re.findall(r'<a class="feat-card[^"]*" href="([^"]+)"', home)
    ok("همهٔ مزایا لینک دارند", len(perk_links) >= 6, f"{len(perk_links)} لینک")

    print(f"\n{B}{'=' * 58}{X}")
    if failed:
        print(f"{B}{R}  {passed} موفق، {failed} ناموفق{X}")
        for f in fails:
            print(f"    ✗ {f}")
    else:
        print(f"{B}{G}  همه موفق — {passed} آزمون، ۰ ناموفق{X}")
    print(f"{B}{'=' * 58}{X}\n")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
