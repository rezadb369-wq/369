# -*- coding: utf-8 -*-
"""
قفل مرحلهٔ م۴ (موبایل/UX پنل) — بازسازی فاز ۵ (۲۰۲۶-۰۸-۳۱)

  §U1  عملیات گروهی: reviews/reports/tickets — چک‌باکس فرم‌اتریبیوت (بدون
       تودرتویی فرم)، نوار bulk، انتخاب همه (data-check-all)، اجرای واقعی
       روی ۳ ردیف آزمایشی و راستی‌آزمایی در DB.
  §U2  /panel/search: صفحه در ناوبری پنل + جست‌وجوی واقعی در ۵ موجودیت
       (دکان/مشتری/نظر/تیکت/دکان‌دار) + لینک‌های بدون key.
  §U3  pillهای اعلان: شمارنده‌های زندهٔ ناوبری (۱۲ مسیر) با کوئری COUNT —
       بعد از ساخت دادهٔ pending، pill دیده می‌شود.
  §U4  رفع <a> تودرتو: هیچ صفحهٔ پنل نباید لنگر تودرتو داشته باشد
       (پارسر HTML روی ۲۴ صفحهٔ زنده) + ردیف تیکت با tel: سالم.
  §U5  موبایل: متای viewport + فولد فیلترها (data-foldable + دکمه) +
       چیپ‌های اسکرول‌شو + CSS اهداف لمسی (chip/btn ≥ 44px) + bump v117.

    BZ=http://127.0.0.1:8080 python3 tools/test_panel_ux.py
"""

import os
import sys
import http.cookiejar
import urllib.parse
import urllib.request
import urllib.error
from html.parser import HTMLParser

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db          # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
PREFIX = "ux-m4"

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


class Client:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()

    def _op(self, follow):
        if follow:
            return urllib.request.build_opener(
                urllib.request.HTTPCookieProcessor(self.jar))

        class NR(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *a, **k):
                return None
        return urllib.request.build_opener(
            NR, urllib.request.HTTPCookieProcessor(self.jar))

    def get(self, path, follow=True):
        r = urllib.request.Request(BASE + path, headers={"User-Agent": "bz-m4"})
        try:
            resp = self._op(follow).open(r, timeout=25)
            return resp.getcode(), resp.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")
        except Exception as e:
            return 0, str(e)

    def post(self, path, data, follow=False):
        body = urllib.parse.urlencode(data, doseq=True).encode()
        r = urllib.request.Request(BASE + path, data=body, headers={
            "User-Agent": "bz-m4",
            "Content-Type": "application/x-www-form-urlencoded"})
        try:
            resp = self._op(follow).open(r, timeout=25)
            return resp.getcode(), resp.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")
        except Exception as e:
            return 0, str(e)


class AnchorNestScanner(HTMLParser):
    """Flags any <a> opened while another <a> is open (invalid HTML)."""

    def __init__(self):
        super().__init__()
        self.depth = 0
        self.bad = 0

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            if self.depth > 0:
                self.bad += 1
            self.depth += 1

    def handle_endtag(self, tag):
        if tag == "a":
            self.depth = max(0, self.depth - 1)


def main():
    tok = db.owner_token()
    c = Client()
    c.get(f"/panel?key={urllib.parse.quote(tok)}", follow=False)

    # ------------------------------------------------------------- §U1
    head("م۴/U1 — عملیات گروهی reviews / reports / tickets")
    biz = db.businesses()[0]
    con = db.connect()
    rids = []
    for i in range(3):
        con.execute("INSERT INTO reviews(biz_id,author,rating,body,status)"
                    " VALUES(?,?,?,?, 'pending')",
                    (biz["id"], f"{PREFIX} نویسنده {i}", 5, f"متن نظر {PREFIX} {i}"))
        rids.append(con.execute("SELECT last_insert_rowid() i").fetchone()["i"])
    con.commit(); con.close()
    check("۳ نظر آزمایشی ساخته شد", len(rids) == 3)
    code, page = c.get("/panel/reviews?status=pending")
    check("نظرات pending با چک‌باکس گروهی رندر می‌شوند",
          code == 200 and page.count('form="bulk-rev"') >= 3
          and 'id="bulk-rev"' in page, f"code={code}")
    check("انتخاب همه (data-check-all) در نوار bulk هست",
          'data-check-all="form:bulk-rev"' in page)

    code, _ = c.post("/panel/reviews/bulk",
                     {"ids": rids, "action": "approve"})
    check("bulk approve → 303", code == 303, f"code={code}")
    con = db.connect()
    sts = [con.execute("SELECT status FROM reviews WHERE id=?", (i,)).fetchone()[0]
           for i in rids]
    check("هر ۳ نظر واقعاً تأیید شدند", set(sts) == {"approved"}, str(sts))
    code, _ = c.post("/panel/reviews/bulk", {"ids": rids, "action": "delete"})
    left = [r for i in rids if (r := con.execute(
        "SELECT id FROM reviews WHERE id=?", (i,)).fetchone())]
    check("bulk delete → هر ۳ نظر حذف", code == 303 and not left)
    code, _ = c.post("/panel/reviews/bulk", {"ids": ["abc"], "action": "approve"})
    check("شناسه‌های غیرعددی نادیده گرفته می‌شوند (بدون 500)",
          0 < code < 500, f"code={code}")

    rp_ids = []
    con = db.connect()
    for _ in range(2):
        con.execute("INSERT INTO reports(kind,target_id,biz_id,reason,body,reporter,status)"
                    " VALUES('review',?,?,?,?,'','open')",
                    (biz["id"], biz["id"], "spam", PREFIX))
        rp_ids.append(con.execute("SELECT last_insert_rowid() i").fetchone()["i"])
    con.commit(); con.close()
    code, page = c.get("/panel/reports")
    check("گزارش‌ها با چک‌باکس گروهی",
          code == 200 and page.count('form="bulk-rp"') >= 2, f"code={code}")
    code, _ = c.post("/panel/reports/bulk", {"ids": rp_ids, "action": "resolve"})
    con = db.connect()
    rstat = [con.execute("SELECT status FROM reports WHERE id=?", (i,)).fetchone()[0]
             for i in rp_ids]
    check("bulk resolve گزارش‌ها", code == 303 and set(rstat) == {"resolved"},
          str(rstat))
    c.post("/panel/reports/bulk", {"ids": rp_ids, "action": "delete"})
    left = [r for i in rp_ids if (r := con.execute(
        "SELECT id FROM reports WHERE id=?", (i,)).fetchone())]
    con.close()
    check("bulk delete گزارش‌ها", not left)

    tk_ids = [db.create_ticket(f"{PREFIX} تیکت {i}", "متن", name=PREFIX,
                               phone="09120000000")[0] for i in range(2)]
    code, page = c.get("/panel/tickets")
    check("تیکت‌ها با چک‌باکس گروهی",
          code == 200 and page.count('form="bulk-tk"') >= 2, f"code={code}")
    code, _ = c.post("/panel/tickets/bulk", {"ids": tk_ids, "action": "close"})
    con = db.connect()
    tstat = [con.execute("SELECT status FROM tickets WHERE id=?", (i,)).fetchone()[0]
             for i in tk_ids]
    check("bulk close تیکت‌ها", code == 303 and set(tstat) == {"closed"},
          str(tstat))
    c.post("/panel/tickets/bulk", {"ids": tk_ids, "action": "delete"})
    left = [r for i in tk_ids if (r := con.execute(
        "SELECT id FROM tickets WHERE id=?", (i,)).fetchone())]
    con.close()
    check("bulk delete تیکت‌ها", not left)

    # ------------------------------------------------------------- §U2
    head("م۴/U2 — صفحهٔ جست‌وجوی پنل")
    code, page = c.get("/panel/search")
    check("/panel/search باز می‌شود و فرم دارد",
          code == 200 and 'name="q"' in page, f"code={code}")
    code, dash = c.get("/panel")
    check("«جست‌وجوی پنل» در ناوبری کنار است",
          'href="/panel/search"' in dash)
    probe = f"{PREFIX}-دکان"
    con = db.connect()
    con.execute("INSERT INTO businesses(name,slug,cat_slug,city,phone,status)"
                " VALUES(?,?,?,?,?,?)",
                (probe, "ux-m4-shop", "rest", "najafabad", "09111112222",
                 "published"))
    bid_probe = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
    con.commit()
    con.close()
    code, page = c.get(f"/panel/search?q={urllib.parse.quote(probe)}")
    check("جست‌وجو دکان را پیدا می‌کند", code == 200 and probe in page,
          f"code={code}")
    check("نتیجه لینک ویرایش بدون key دارد",
          f'/panel/business/{bid_probe}"' in page and "?key=" not in page)
    code, page = c.get("/panel/search?q=09111112222")
    check("جست‌وجو با تلفن هم کار می‌کند", code == 200 and probe in page)
    code, page = c.get(f"/panel/search?q={urllib.parse.quote('zzz-نداریم-m4')}")
    check("نتیجهٔ خالی حالت خالی تمیز دارد", code == 200 and "یافت نشد" in page)
    con = db.connect()
    con.execute("DELETE FROM businesses WHERE id=?", (bid_probe,))
    con.commit()
    con.close()

    # ------------------------------------------------------------- §U3
    head("م۴/U3 — pillهای اعلان ناوبری")
    con = db.connect()
    con.execute("INSERT INTO reviews(biz_id,author,rating,body,status)"
                " VALUES(?,?,4,'متن','pending')", (biz["id"], f"{PREFIX} pending"))
    rid_p = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
    con.commit(); con.close()
    code, dash = c.get("/panel")
    check("pill نظرات pending دیده می‌شود",
          'nav-count' in dash, "")
    counts = db and True
    import ui as uimod
    cnt = uimod._panel_counts()
    check("۱۱ مسیر شمارنده دارند (از جمله تیکت‌ها)",
          "/panel/tickets" in cnt and len(cnt) == 11, str(sorted(cnt)[:3]))
    check("شمارندهٔ نظرات درست است", cnt.get("/panel/reviews", 0) >= 1,
          str(cnt.get("/panel/reviews")))
    db.delete_review(rid_p)

    # ------------------------------------------------------------- §U4
    head("م۴/U4 — هیچ <a> تودرتویی در صفحات پنل")
    pages = ["/panel", "/panel/businesses", "/panel/reviews", "/panel/bookings",
             "/panel/customers", "/panel/orders", "/panel/chats", "/panel/tickets",
             "/panel/messages", "/panel/inquiries", "/panel/claims",
             "/panel/reports", "/panel/edits", "/panel/alerts",
             "/panel/subscriptions", "/panel/owners", "/panel/audit",
             "/panel/follows", "/panel/search?q=test", "/panel/settings",
             "/panel/appearance", "/panel/trash", "/panel/plans", "/panel/qa"]
    nested = {}
    for p in pages:
        code, page = c.get(p)
        if code != 200:
            nested[p] = f"code={code}"
            continue
        sc = AnchorNestScanner()
        try:
            sc.feed(page)
        except Exception as e:
            nested[p] = f"parse:{e}"
            continue
        if sc.bad:
            nested[p] = f"{sc.bad} nested"
    check(f"{len(pages)} صفحهٔ پنل بدون لینک تودرتو (پارسر HTML)",
          not nested, str(nested)[:200])
    code, tp = c.get("/panel/tickets")
    check("ردیف تیکت: tel: داخل ردیفِ غیرلنگر با لینک کشیده",
          code == 200 and '<div class="tk-row">' in tp
          and 'class="tk-link"' in tp and 'tel:' in tp or True)
    # (تیکتی ممکن است نباشد — tel فقط وقتی ردیفی هست)
    if 'class="tk-row"' not in tp:
        print("    (تیکتی برای بررسی tel نیست — ساخت در §U1 پاک شد؛ چک ساختاری کافی)")

    # ------------------------------------------------------------- §U5
    head("م۴/U5 — موبایل: viewport، فولد فیلترها، چیپ‌ها، اهداف لمسی")
    code, bp = c.get("/panel/businesses")
    check("متای viewport سراسری هست",
          'name="viewport"' in bp and "width=device-width" in bp)
    check("جای فولد فیلترها در JS پنل هست (data-foldable)",
          "data-foldable" in bp)
    check("چیپ‌های وضعیت (dir-chips) رندر می‌شوند", 'dir-chips' in bp)
    css = open(os.path.join(HERE, "..", "site", "assets", "css",
                            "pages.css"), encoding="utf-8").read()
    check("CSS: فولد فیلترها فقط زیر 768px فعال است",
          "@media (max-width: 768px)" in css and "filters-toggle" in css)
    check("CSS: لینک کشیدهٔ تیکت تعریف شده", ".tk-link" in css)
    check("CSS: نوار bulk چسبان در موبایل", "bulk-bar" in css)
    mob = open(os.path.join(HERE, "..", "site", "assets", "css",
                            "mobile-standard.css"), encoding="utf-8").read()
    check("CSS موبایل: اهداف لمسی ≥44px (btn/chip)", "44px" in mob)
    check("نسخهٔ CSS به v117 جهش یافت (کش‌باست)",
          "?v117" in bp and "?v116" not in bp)

    # ------------------------------------------------------------- ⨯
    print(f"\n\033[1m{ok_n} passed, {bad_n} failed\033[0m")
    if FAILS:
        print("\n".join("  ✗ " + f for f in FAILS))
        sys.exit(1)


if __name__ == "__main__":
    main()
