# 🛒 بازارچهٔ ایران — v119

دایرکتوری/مارکت‌پلیس کسب‌وکارهای ایران (الگوی دیوار): بازدیدکننده شهر را انتخاب می‌کند،
کسب‌وکارها و محصولات را می‌بیند، نظر می‌دهد، چت می‌کند و سفارش می‌گذارد؛ دکان‌دار پنل
کامل دارد و مدیر کل بر همه‌چیز ناظر است. **بدون هیچ وابستگی غیر کتابخانهٔ استاندارد
پایتون** — روی Pydroid 3 اندروید و هر کامپیوتری اجرا می‌شود. پایگاه داده SQLite.

> اسناد عمیق‌تر: `WHATS-NEW.md` (لاگ نسخه‌ها)، `HANDBOOK.md` (راهنمای کامل)،
> `ARCHITECTURE.md` (نقشهٔ ساختمان). حافظهٔ همکاری و قوانین بیرون از بسته نگه‌داری می‌شود.

---

## 🚪 سه راه ورود

| نقش | نشانی | چگونه |
|---|---|---|
| مدیر کل | `/panel?key=…` | لینکی که هنگام اجرای `run.py` چاپ می‌شود (و رمز اختیاری از تنظیمات) |
| دکان‌دار | `/login` | شمارهٔ موبایل + کد یک‌بارمصرف؛ ورود و ثبت‌نام یکی است |
| بازدیدکننده/مشتری | `/` | بدون حساب؛ حساب مشتری اختیاری برای سفارش/چت/علاقه‌مندی |

---

## ▶️ اجرا

۱. زیپ را استخراج کنید. ۲. `run.py` را با پایتون ۳ (یا Pydroid 3) اجرا کنید.
۳. لینک پنل مالک چاپ می‌شود. سایت روی `0.0.0.0:8080` گوش می‌دهد.
هیچ `pip install` لازم نیست.

---

## 🎨 تم روز/شب — «رسمی» (v111)

- هویت: خاکستری خنثی + یک آبی اداری. ساده و استاندارد؛ بدون گرادیان رنگی، هاله،
  بلور و بافت. شب `#12151a`/کارت `#1b2027`؛ روز `#f0f2f4`/کارت سفید.
- همهٔ رنگ‌ها **توکن معنایی** در `site/assets/css/tokens.css` هستند
  (روز روی `:root`، شب روی `:root[data-theme="dark|night|luxury"]`).
- `theme-night.css` / `theme-light.css` فقط توکن/استثنای کنتراست نگه می‌دارند؛
  override ساختاری در آن‌ها ممنوع است و توسط `tools/test_appearance.py` نگهبانی می‌شود.
- بازدید اول از تمایل سیستم پیروی می‌کند؛ ترجیح در `localStorage['bz-theme']`؛
  تعویض تم با محو شدن ۳۰۰ms همهٔ رنگ‌ها (`html.theme-fade`) و احترام به
  `prefers-reduced-motion`.
- کنتراست: `tools/contrast_audit.py` متنِ واقعی هر صفحه را در هر دو تم می‌سنجد
  (AA: متن ≥۴٫۵:۱). کف اندازهٔ متن ۱۲px.
- رنگ انتخابی مالک در پنل فقط تم **روز** را تغییر می‌دهد تا شب هرگز ناخوانا نشود.

---

## 🛡️ سپر ضد-اسپم (v112)

`server/shield.py` در ابتدای هر GET/POST:
- بیش از ۱۲۰ درخواست در ۱۰ ثانیه از یک آی‌پی → ۴۲۹؛ تکرار پشت‌سرهم → مسدود ۱۰ دقیقه‌ای.
- مسیرهای اسکنر (`/.env`, `/.git`, `/wp-*`, …) → ۴۰۴ + ۳ ضربه/۶۰ث → مسدود ۳۰ دقیقه.
- User-Agent ابزار مخرب (sqlmap, nikto, masscan, …) → ۴۰۳.
- `robots.txt` خزنده‌های آموزشی AI را هم به‌صورت رسمی ممنوع می‌کند.
- گزارش زنده و برداشتن مسدودی: پنل → «ترافیک و سپر» (`/panel/traffic`).
- تنظیم سقف‌ها بدون دست‌زدن به کد: `BZ_SHIELD_RATE`, `BZ_SHIELD_WINDOW`.

---

## 🧪 تست‌ها

همه در `tools/` و فقط کتابخانهٔ استاندارد (جز تست‌های مرورگری که Playwright می‌خواهند):

```
python3 tools/test_all.py        # ۱۵۲ آزمون هسته
python3 tools/test_abuse.py      # سپر ضد-اسپم
python3 tools/test_analytics.py  # آمار بازدید واقعی + GA4
python3 tools/contrast_audit.py  # کنتراست هر دو تم
python3 tools/test_browser.py    # a11y + واکنش‌گرایی ۱۱ عرض
python3 tools/test_panel_mod.py  # م۵: بن/بلاک، فیلتر+CSV ممیزی، صف تعدیل
python3 tools/mobile_audit.py    # ۲۴ صفحهٔ پنل × ۴ دستگاه موبایل
python3 tools/test_geoip_fa.py   # فاز ۶: نقشهٔ فارسی شهرها
python3 tools/test_privacy_v117.py  # فاز ۶: دادهٔ من + retention ساعتی
python3 tools/public_audit.py    # فاز ۷: ۲۵ صفحهٔ عمومی × ۴ دستگاه
python3 tools/contrast_audit.py  # فاز ۷: کنتراست AA در هر دو تم
python3 tools/bench_1000.py      # تست بار ۱۰۰۰ کاربر + رمبش
```

باتری کامل ۲۷ مجموعه است (gates, actions, tickets, trash, discovery, onboarding,
admin_extras, chat_v73, context, favorites_v74, haggle, isolation, open, open_parity,
prices, remaining_v76, section1, section4_v75, v3, v3_owner, v68, v69, appearance…).
قبل از هر تحویل: باتری سبز + `node --check` روی JS‌ها.

---

## 📦 ساختار بسته

```
run.py              اجراکننده (Pydroid/کامپیوتر)
server/             app.py مسیریابی+امنیت+سپر · db.py داده (۵۷ جدول + ۶ آبجکت FTS) ·
                    features.py زیرسیستم‌ها · analytics.py آمار بازدید واقعی ·
                    ui.py کروم+توکن روز+GA4 · views_*.py نماها · shield.py سپر
site/               assets (css/js/fonts/img) · sw.js · manifest · offline.html
tools/              ۲۶+ مجموعه تست + seed_demo + ممیزی‌ها
```

---

## 🔐 امنیت، خلاصه

کلید پنل + رمز اختیاری (PBKDF2) · OTP با سهمیهٔ per-phone و سقف IP ·
rate-limit سطح کنش (`db.rate_ok`) + سپر کل ترافیک · سطل بازیافت ۷روزه (v105) ·
فایل‌های چت خصوصی با مجوز قبل از خواندن · حذف EXIF پیوست‌ها · `data/` هرگز در
زیپ/ریپو نیست.

---

## 🔢 پروتکل نسخه

هر تحویل: زیپ تازه `bazarche-najafabad-vNNN.zip` بدون `data/` + بامپ `?vNNN`
در `server/ui.py` و `VERSION` در `site/sw.js` + ورودی در `WHATS-NEW.md`.
ریپوی گیت‌هاب `rezadb369-wq/369` منبع حقیقت است.
