# HANDOFF — v319 (۲۲/۰۹/۲۰۲۶)

بخوان: `RULES.md` · `CURRENT-STATE.md` · `KNOWLEDGE.md` · `WHATS-NEW.md` · همین فایل.

## الان چیست

ایجنت مالک **دسترسی آزاد** به فایل‌ها و بخش‌های سایت دارد و ابزارها **فوری** اجرا می‌شوند (جز `shell_exec` / `service_restart` / `broadcast` که «بله» می‌خواهند). مهمان به `/api/agent/*` نمی‌رسد.

مغز پیش‌فرض: `ling-3.0-flash-sante-free`. توکن ایجنت بله در زیپ نیست. پالر دوم نساز.

## پین

| فایل | مقدار |
|---|---|
| `VERSION.txt` | `319` |
| `site/sw.js` | `bazarche-v319` |
| `DIAG_LATEST` | `"319"` |

## تست

```
python3 tools/test_v319.py
python3 tools/test_security_v318.py
python3 tools/test_agent_tools_v310.py
```

نصب: `sudo bash /opt/dastgir/deploy/update.sh /tmp/dastgir-v319.zip`
