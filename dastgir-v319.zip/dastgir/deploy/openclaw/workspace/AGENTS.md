# AGENTS.md

Workspace = `/opt/dastgir` (کد زندهٔ سایت).

قبل از ویرایش کد: فایل را بخوان، بعد ویرایش دقیق. استقرار از مسیر codeguard
سایت (`deploy/codeguard.sh`) می‌گذرد اگر از بات مدیر `code_edit` بدهی.

مهارت‌ها:
- `dastgir-panel-access` — نشانی و وضعیت پنل
- `dastgir-site-data` — تصویر زندهٔ محتوا (بدون راز)
