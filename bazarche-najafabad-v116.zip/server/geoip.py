"""v115: offline city lookup for Iranian IPv4 addresses — stdlib only.

Data: server/geoip_ir.csv (start_int, end_int, region, city), extracted from
DB-IP's free "DB-IP City Lite" open database (CC-BY 4.0, db-ip.com) — Iranian
ranges only, 501 KB, no network call, works inside Pydroid. IP geolocation is
approximate by nature (ISP-level); the panel says so.

Lookup is a binary search over sorted, non-overlapping ranges plus a small
in-memory cache. Unknown / IPv6 / private addresses honestly return ("", "")
rather than a guess.
"""

import bisect
import csv
import os

_DATA = None
_STARTS = None
_cache = {}

REGION_FA = {
    "Alborz": "البرز", "Alborz Province": "البرز",
    "Ardabil Province": "اردبیل", "Bushehr": "بوشهر",
    "Chaharmahal and Bakhtiari": "چهارمحال و بختیاری",
    "East Azerbaijan": "آذربایجان شرقی", "West Azerbaijan": "آذربایجان غربی",
    "Fars": "فارس", "Gilan Province": "گیلان", "Gīlān": "گیلان",
    "Golestan": "گلستان", "Hamadan Province": "همدان", "Hamadān": "همدان",
    "Hormozgan": "هرمزگان", "Ilam Province": "ایلام", "Isfahan": "اصفهان",
    "Kerman": "کرمان", "Kermanshah Province": "کرمانشاه",
    "Khuzestan": "خوزستان",
    "Kohgiluyeh and Boyer-Ahmad": "کهگیلویه و بویراحمد",
    "Kordestān": "کردستان", "Kurdistan Province": "کردستان",
    "Lorestan Province": "لرستان", "Markazi": "مرکزی",
    "Māzandarān": "مازندران", "North Khorasan": "خراسان شمالی",
    "Qazvin Province": "قزوین", "Qazvīn": "قزوین",
    "Qom": "قم", "Qom Province": "قم",
    "Razavi Khorasan": "خراسان رضوی",
    "South Khorasan Province": "خراسان جنوبی", "Semnan": "سمنان",
    "Sistan and Baluchestan": "سیستان و بلوچستان",
    "Tehran": "تهران", "Tehrān": "تهران",
    "Yazd": "یزد", "Yazd Province": "یزد", "Zanjan": "زنجان",
}

CITY_FA = {
    "Tehran": "تهران", "Tehrān": "تهران", "Shiraz": "شیراز",
    "Isfahan": "اصفهان", "Mashhad": "مشهد", "Tajrīsh": "تجریش",
    "Karaj": "کرج", "Qom": "قم", "Tabriz": "تبریز", "Ahvāz": "اهواز",
    "Rasht": "رشت", "Kerman": "کرمان", "Yazd": "یزد", "Sanandaj": "سنندج",
    "Bushehr": "بوشهر", "Gorgan": "گرگان", "Arak": "اراک",
    "Zahedan": "زاهدان", "Bandar Abbas": "بندرعباس", "Urmia": "ارومیه",
    "Qazvin": "قزوین", "Kermanshah": "کرمانشاه", "Zanjan": "زنجان",
    "Hamadan": "همدان", "Semnan": "سمنان", "Babol": "بابل",
    "Ardabil": "اردبیل", "Īlām": "ایلام", "Bojnourd": "بجنورد",
    "Khorramabad": "خرم‌آباد", "Rey": "ری", "Shahr-e Kord": "شهرکرد",
    "Sari": "ساری", "Najafābād": "نجف‌آباد", "Najafabad": "نجف‌آباد",
    "Eslāmābād": "اسلام‌آباد", "Vaḩīdīyeh": "وحیدیه", "Fardīs": "فردیس",
    "Qarchak": "قرچک", "Shahr-e Ṣadrā": "شهر صدرا", "Sīrjān": "سیرجان",
    "Bandar-e Emam Khomeyni": "بندر امام خمینی", "Ţorqabeh": "طرقبه",
    "Lamerd": "لامرد", "Varamin": "ورامین", "Varāmīn": "ورامین",
    "Khomeyni Shahr": "خمینی‌شهر", "Kāshān": "کاشان", "Kashan": "کاشان",
    "Dezful": "دزفول", "Borūjerd": "بروجرد", "Malāyer": "ملایر",
    "Sāveh": "ساوه", "Saveh": "ساوه", "Shāhīn Shahr": "شاهین‌شهر",
    "Islamshahr": "اسلامشهر", "Eslāmshahr": "اسلامشهر",
    "Pākdasht": "پاکدشت", "Shahrīār": "شهریار", "Shahriar": "شهریار",
    "Maragheh": "مراغه", "Marāgheh": "مراغه", "Khowy": "خوی", "Khoy": "خوی",
    "Zābol": "زابل", "Zabol": "زابل", "Gonbad-e Kāvūs": "گنبد کاووس",
    "Āmol": "آمل", "Amol": "آمل", "Sārī": "ساری",
}


def _norm_city(c):
    """'Tehran (District 6)' -> 'Tehran'; keeps base name mappings working."""
    i = c.find(" (")
    return c[:i] if i > 0 else c


def _load():
    global _DATA, _STARTS
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "geoip_ir.csv")
    rows = []
    try:
        with open(path, newline="") as f:
            for r in csv.reader(f):
                if len(r) >= 4:
                    rows.append((int(r[0]), int(r[1]), r[2], r[3]))
    except OSError:
        rows = []
    rows.sort()
    _DATA = rows
    _STARTS = [r[0] for r in rows]


def _ip2int(ip):
    parts = ip.split(".")
    if len(parts) != 4:
        return None                       # IPv6 or garbage — honest empty
    n = 0
    for p in parts:
        if not p.isdigit():
            return None
        v = int(p)
        if v > 255:
            return None
        n = n * 256 + v
    return n


def lookup(ip):
    """(province_fa, city_fa) for an IPv4 string.

    Returns ("", "") for anything not found — never a fabricated city.
    """
    if not ip:
        return ("", "")
    hit = _cache.get(ip)
    if hit is not None:
        return hit
    n = _ip2int(ip)
    if n is None:
        return ("", "")
    if _DATA is None:
        _load()
    if not _DATA:
        return ("", "")
    i = bisect.bisect_right(_STARTS, n) - 1
    if i < 0:
        return ("", "")
    s, e, reg, city = _DATA[i]
    if n > e:                             # fell in a gap between ranges
        return ("", "")
    prov = REGION_FA.get(reg, reg)
    out = (prov, CITY_FA.get(_norm_city(city), _norm_city(city)))
    if len(_cache) < 8192:
        _cache[ip] = out
    return out
