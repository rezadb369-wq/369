# HANDOFF مرجع پروژهٔ «دست گیر»

آخرین به‌روزرسانی: ۲۰۲۶-۰۹-۰۷ — این فایل نقطهٔ شروع چت/عامل جدید است.

## ۱) منبع حقیقت و نسخه

- درخت فعال: همین پوشه (`dastgir/`).
- نسخهٔ فعلی درخت و بستهٔ مستنداتی: v206؛ منطق کامل بات‌ها از v205 بدون تغییر عملکردی منتقل شده است.
- آرشیو تأییدشدهٔ v205: `dastgir-v205.zip`، 484 فایل، 5,306,546 بایت.
- SHA-256 v205: `624c864ea4ea7f3308148107332a16d6b7c980178d91c1ad3129ae2570c709a9`.
- URL تحویل v205: `https://x0.at/pNMN.zip` (موقت؛ hash معیار اعتماد است).
- آرشیو نهایی v206: 489 فایل، 5,345,615 بایت؛ SHA-256 `9812482352b166927369da5ee04dc30b5f99c97bc56d0fbcde6d9e75c29539fc`؛ URL `https://x0.at/7I2w.zip`.
- نام نمایشی محصول همیشه «دست گیر» با فاصله است.
- کد فعال workspace فاقد `.git` است. clone مستندات ساخته شد، ولی push HTTPS/SSH به‌دلیل نبود credential مجاز شکست خورد؛ SHA آنلاین در آخرین بررسی `781f18ffc29a6952aeace9029f39bb026b7341ae` بود و GitHub هنوز به‌روز نشده بود.

## ۲) وضعیت قابلیت‌ها

هر دو بات بله و سروش‌پلاس از هستهٔ مشترک استفاده می‌کنند:

- ورود/ثبت‌نام بدون SMS و password با contact رسمی و تأیید جداگانه؛ مرورگر باز پس از تأیید خودکار وارد می‌شود.
- `/menu`, `/account`, `/help` با private-chat enforcement، webhook secret، replay claim و rate limit.
- `/orders`: فهرست/جزئیات مشتری، بدون phone/address/note.
- `/bookings`: نوبت‌های customer-bound، اعلان تاریخ/ساعت، لغو اتمیک پس از تأیید دوم.
- `/notifications`: تنظیم مشترک `notif_prefs` برای سایت و بات.
- `/stock`: درخواست‌های مشتری، بدون note، لغو تأییدی؛ fulfil به هر دو بات متصل.
- `/search query` و `/favorites`: نتیجهٔ published، مسیر، علاقه‌مندی مشترک و حذف تأییدی.
- `/messages`: پنج گفتگو، شش پیام اخیر، handoff فایل/پیچیدگی به سایت، پاسخ کوتاه با token یک‌بارمصرف hash-only.
- `/owner`: خلاصه روز، سفارش، نوبت امروز، پیام مشتری، موجودی و فراخوان؛ همهٔ mutationها owner-bound، یک‌بارمصرف و اتمیک.
- خلاصهٔ مالک ساعت 09:00 Asia/Tehran با systemd timer و dedup مالک/روز.
- Rubika در UI/runtime غیرفعال است اما رکوردهای قدیمی به‌صورت مخرب حذف نشده‌اند.

## ۳) امنیت تثبیت‌شده

- token واقعی بات‌ها و webhook secret فقط در `/etc/dastgir-secrets.env` با `root:root/600`؛ هرگز در چت، ZIP، history یا خروجی چاپ نشود.
- webhookهای بله/سروش URL secret را با `secrets.compare_digest` بررسی می‌کنند؛ JSON محدود، update_id عددی و replay claim پلتفرم‌محور است.
- عملیات حساب فقط در private chat؛ callbackها regex allow-list و کمتر از 64 بایت.
- authorization مشتری با `customer_id` و authorization مالک با `owner_id + business ownership` سمت سرور انجام می‌شود.
- confirmation پاسخ/مالک فقط به‌صورت SHA-256 در DB ذخیره می‌شود؛ bearer خام پنج دقیقه‌ای و یک‌بارمصرف است.
- private fields در بات ممنوع: order phone/address/note، booking phone/note، stock note/customer phone، stored attachment path/name.
- `push=False` فقط FCM را خاموش می‌کند، نه messenger fan-out.

## ۴) استقرار

- مسیر VPS ثبت‌شده: `/opt/dastgir`؛ service: `bazarche.service`؛ پورت داخلی: 8080؛ nginx روی دامنه.
- updater نهایی: `deploy/update.sh` — backup سازگار SQLite، staging، `rsync --delete` و حفظ `data/`، uploadها و chat-files.
- راهنمای همهٔ فرمان‌های Termius: `deploy/FINAL-v205-TERMIUS-fa.md`.
- گزارش امنیت: `deploy/FINAL-SECURITY-v205-fa.md`.
- کاربر تصویر `Final checks finished` و prompt فعال Termius را فرستاد؛ اما خروجی کامل version/health در تصویر نبود، پس deploy زنده را قطعی اعلام نکن.
- همان تصویر admin panel key را آشکار کرد. به کاربر دستور rotation بدون چاپ کلید داده شد؛ اجرای rotation هنوز تأیید نشده و باید در ادامه پرسیده/بررسی شود. خود کلید قدیمی را هرگز بازنویسی یا تکرار نکن.

## ۵) آخرین نتایج آزمون v205

- امنیت مستقل 25/25
- منوی مشترک و همه قابلیت‌ها 66/66
- Bale core 26/26؛ Bale HTTP 45/45
- Soroush core 13/13؛ Soroush HTTP 48/48
- public performance 12/12
- compile، shell، fresh schema/index، notifmeta، backup exclusions، browser/login، logo، credential/deploy policy: PASS

## ۶) درخواست بعدی کاربر — هنوز پیاده‌سازی نشده

کاربر خواسته است «ثبت کسب‌وکار مرحله‌به‌مرحله داخل هر دو بات» اضافه شود. قبل از آن صریحاً خواست فایل‌های دانش، قوانین و handoff به‌روز شوند تا چت جدید دقیق باشد.

طرح پیشنهادی ثبت کسب‌وکار:

1. `/register_business` و دکمهٔ «ثبت کسب‌وکار».
2. draft پایدار مشترک با state machine صریح، expiry، resume و cancel تأییدی.
3. انتخاب/جست‌وجوی دسته‌بندی فعال.
4. نام، شهر، محله، نشانی، توضیح کوتاه.
5. تلفن از حساب تأییدشده و غیرقابل جعل؛ گزینهٔ نمایش عمومی جداگانه.
6. ساعات کاری.
7. تصویر: تصمیم محصول هنوز قطعی نشده؛ پیشنهاد امن «لوگو و چند تصویر سبک در بات + مدیریت کامل گالری در سایت» است.
8. پیش‌نمایش و تأیید دوم یک‌بارمصرف.
9. ثبت نهایی با مالکیت معتبر و `status=pending` برای بررسی مدیر؛ انتشار مستقیم ممنوع.
10. parity بله/سروش، محدودیت نرخ/طول/MIME/اندازه، عدم ذخیرهٔ bearer خام، و ZIP کامل مستقل پس از اتمام.

تصمیم‌های باز که در چت بعدی بهتر است تأیید شوند: روش تصویر (کامل در بات/فقط سایت/ترکیبی) و اینکه همهٔ ثبت‌ها حتماً در انتظار بررسی مدیر بمانند (پیشنهاد: بله).

## ۷) قوانین ادامه

- در مخزن مستندات/GitHub ابتدا `CURRENT-STATE.md`، سپس `RULES (2).md`، `KNOWLEDGE.md` و این `HANDOFF.md` خوانده شوند؛ `HANDOFF (5).md` فقط آرشیو تاریخی است.
- قبل از هر تغییر، فایل‌های مرتبط و رفتار واقعی بررسی شوند.
- هر بخش مستقل، نسخهٔ تازه و ZIP کامل clean دارد؛ patch archive ممنوع.
- موفقیت بدون تست واقعی ادعا نشود.
- stable callback prefix `dg198:` صرفاً برای هماهنگی نسخه تغییر نکند.
- هر state-changing/destructive action تأیید دوم و predicate اتمیک مالکیت/وضعیت می‌خواهد.
- پس از بسته، clean extraction QA، hash، remote redownload و ثبت در KNOWLEDGE انجام شود.
