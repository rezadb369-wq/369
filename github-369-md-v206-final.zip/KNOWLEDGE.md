# 📚 KNOWLEDGE.md — دانش‌نامهٔ کامل پروژه «دست گیر / بازارچه» (نسل سوم)
> **این فایل تاریخچهٔ انباشته است؛ برای شروع ابتدا `CURRENT-STATE.md` و سپس `HANDOFF.md` خوانده شود.** آخرین به‌روزرسانی: ۲۰۲۶-۰۹-۰۷ · منطق محصول: **v205** · بستهٔ مستنداتی: **v206**
> قوانین همکاری در `RULES (2).md` است (کنار همین فایل) — آن را هم بخوان.

## تحویل جاری — v188 / رفع webhook واقعی روبیکا (۲۰۲۶-۰۹-۰۷)
- تشخیص تولید از `/root/rubika-diagnostic.json`: getUpdates رویدادهای واقعی را مستقیم به‌شکل `{type,chat_id,new_message,...}` می‌دهد؛ v187 فقط wrapper مستند `{"update":...}` را می‌خواند و بی‌صدا 200 می‌داد. parser v188 هر دو شکل direct/wrapped را برای Update و InlineMessage قبول می‌کند.
- تست HTTP مستقیم `/start` اضافه شد و پاسخ بات اثبات شد؛ Rubika ۱۰/۱۰ + HTTP ۸/۸، Bale ۲۶/۲۶ + HTTP ۱۸/۱۸، همه از خود ZIP نیز سبز.
- challenge روبیکا برای جبران preview رسمی HTTPS از ۲ به ۵ دقیقه افزایش یافت؛ بله ۲ دقیقه باقی ماند.
- بسته `dastgir-v188.zip`: ۵٬۲۱۸٬۹۴۶ بایت، ۴۵۸ فایل؛ MD5 `6c898f1edb7e6e068b0d267102fdc94f`؛ SHA-256 `c76a2e560d0903cfb952dfbc9c5b6d43b16bacb04a1bff89607e6038e29e819f`؛ لینک shell-only `https://x0.at/nKk8.zip`، بازدانلود و integrity منطبق. تولید فعلی v187 است و باید v188 نصب شود؛ endpoint/token/secret فعلی حفظ می‌شود و نیاز به ثبت دوباره ندارد.

## تحویل قبلی — v187 / بله + روبیکا بدون پیامک (۲۰۲۶-۰۹-۰۷)
- روبیکا Bot API رسمی v3 به‌صورت stdlib اضافه شد: deep-link پارامتر `st`، دکمه `AskMyPhoneNumber`، تأیید Inline جدا، دو endpoint رازدار ReceiveUpdate/ReceiveInlineMessage، replay hash پایدار، rate limit و browser-bound polling.
- حساب شمارهٔ یکسان بین بله و روبیکا ادغام می‌شود؛ هر دو mapping هم‌زمان مجازند؛ اعلان‌ها best-effort به هر دو chat fan-out می‌شوند. SMS/password مشتری/مالک همچنان غیرفعال؛ پنل مدیر مستقل است.
- بسته `dastgir-v187.zip`: ۵٬۲۱۸٬۳۰۷ بایت، ۴۵۸ فایل؛ MD5 `0c10a123d3595f877d660a2857d333fe`؛ SHA-256 `dfbe5cef8c46ee973309e77921a9de1265738320a4c72b14ff3a45f1b8132c87`؛ لینک shell-only `https://x0.at/WoPt.zip` با بازدانلود و integrity منطبق.
- QA از منبع و ZIP: Bale ۲۶/۲۶ + HTTP ۱۸/۱۸؛ Rubika ۱۰/۱۰ + HTTP ۷/۷؛ py_compile، health/login packaged boot، secret scan، ZIP integrity/path پاک؛ panel perf ۱۲/۱۲ و logo guard سبز.
- تولید فعلی پیش از اقدام کاربر v186/Bale است؛ token/secret روبیکا در `/etc/dastgir-secrets.env` آماده است. پس از deploy v187 باید دو endpoint روبیکا ثبت و سپس جریان واقعی موبایل آزمایش شود.

## تحویل قبلی — v186 / ثبت‌نام و ورود فقط با بله (۲۰۲۶-۰۹-۰۷)
- بنا به انتخاب صریح کاربر، login مشتری/دکان‌دار فقط بله است؛ UI پیامک و رمز حذف و POSTهای OTP/verify/password/credential با 404 بسته‌اند. احراز هویت مستقل مدیر کل دست‌نخورده است.
- کاربر ناشناس از challenge مرورگر وارد بات می‌شود؛ بات `request_contact` رسمی می‌خواهد و فقط contact با `contact.user_id == from.id` را می‌پذیرد. سپس bearer دوم تصادفی و hash-only برای دکمهٔ جداگانهٔ «تأیید ثبت‌نام و ورود» صادر می‌شود. پس از تأیید، حساب همان شماره create/match، Bale mapping ثبت و browser-bound polling نشست مشتری/مالک را می‌سازد.
- مهاجرت in-place از جدول v185 برای `platform_user_id/chat_id/approval_hash` تست شده؛ challenge دو دقیقه، single-use، rate-limited و update replay-safe مانده است.
- بستهٔ کامل `dastgir-v186.zip`: **۵٬۲۱۰٬۵۵۱ بایت، ۴۵۴ فایل** · MD5 `cd142ccf77bd2aa3c809f0a7bf077d42` · SHA-256 `1f53c85f0f6bb25345577cc00ed13d4e43a418700754890b62a16a6e4cdc35de` · لینک shell-only `https://x0.at/T52F.zip`؛ بازدانلود و integrity منطبق.
- QA: focused/migration/security ۲۶/۲۶؛ HTTP واقعی Bale-only signup/login/link ۱۸/۱۸؛ packaged boot همان دو باتری سبز؛ Playwright public ۱۴/۱۴ و browser کامل ۲۱ صفحه × ۱۱ عرض؛ panel-security ۴۳/۴۳؛ pentest بدون شکست ۳۳ check (بخش‌های OTP عمداً دیگر اجرا نمی‌شوند)؛ panel-perf ۱۲/۱۲؛ secret scan و ZIP path/integrity پاک.
- وضعیت تولید: v185 اکنون deploy و webhook بله فعال/پاسخ‌گو است؛ v186 هنوز باید با updater نصب شود. فایل secret تولیدی سالم و خارج ZIP است؛ webhook بعد از update همان URL را حفظ می‌کند و نیاز به setWebhook دوباره ندارد.

## تحویل قبلی — v185 / ورود بدون کد، اتصال حساب و اعلان بله (۲۰۲۶-۰۹-۰۷)
- بستهٔ کامل: `dastgir-v185.zip` · **۵٬۲۰۸٬۲۴۶ بایت** · **۴۵۴ فایل** · MD5 `85214a4d44887d154685c29f503bd49f` · SHA-256 `d8bb622b13f017a6d87fa42201ee66c3e9ddd286b25f4775c7c0217cb33e7b4b` · لینک موقت shell-only `https://x0.at/WX7u.zip` (بازدانلود، checksum و ZIP integrity منطبق).
- پیاده‌سازی: چالش تصادفی دو‌دقیقه‌ای، فقط hash در SQLite، browser-bound و single-use؛ `/start` تنها challenge را resolve می‌کند و تأیید callback مستقل لازم است؛ هویت بله فقط پس از link از حساب مشتری احرازشده مجاز است؛ unlinked رد می‌شود؛ polling همان مرورگر نشست عادی مشتری و در صورت شمارهٔ مالک فعال، نشست مالک را می‌سازد؛ OTP و رمز باقی‌اند.
- webhook: مسیر رازدار HTTPS، JSON حداکثر ۲۵۶KB، `update_id` replay wall پایدار و اتمی، سهمیهٔ مستقل webhook/challenge/poll و بدون log کردن bearer. Token/secret فقط environment و `/etc/dastgir-secrets.env` root:root/600؛ فایل راز، مقادیر واقعی و runtime data در ZIP نیستند. webhook هنوز عمداً ثبت نشده و فقط بعد از استقرار/healthcheck باید ثبت شود.
- اعلان‌ها: نگاشت chat بله با messenger_accounts، fan-out از هستهٔ اعلان مشتری/مالک در کنار in-app/web-push؛ شکست API بله swallow می‌شود و عملیات سایت rollback نمی‌شود. نگاشت حساب در backup هست؛ challenge و update replay گذرا در backup نیستند.
- QA: focused ۲۱/۲۱؛ HTTP واقعی با API جعلی ۱۳/۱۳؛ py_compile کامل؛ security ۹/۹؛ panel-security ۴۳/۴۳؛ pentest ۳۸/۳۸؛ actions ۵۵/۵۵؛ panel-perf ۱۲/۱۲؛ Playwright: public-perf ۱۴/۱۴، category ۱۵/۱۵، icon ۲۱/۲۱، brand ۲۴/۲۴، browser کامل ۲۱ صفحه × ۱۱ عرض. `test_all` همان دو شکست شناخته‌شدهٔ نامرتبط `/compare` و نوار زیردسته را دارد. تست‌های focused و HTTP از خود ZIP نیز سبز؛ boot endpointها ۴/۴ و integrity/secret/path scan پاک.
- راه‌اندازی: `deploy/BALE-v185-fa.md`. updater واحد systemd تازه را هم نصب می‌کند تا EnvironmentFile حتماً اعمال شود. بازوی تولیدی `@daastgirbot` (ID 513379886)؛ webhook تا استقرار v185 ثبت نشود.

## تحویل قبلی — v184 / سرعت پنل مدیریت، بخش ۲ (۲۰۲۶-۰۹-۰۷)
- بستهٔ کامل: `dastgir-v184-section2.zip` · ۵٬۲۳۹٬۵۵۰ بایت · ۴۵۱ فایل · لینک موقت shell-only: `https://x0.at/v5r1.zip` (بازدانلود، checksum و ZIP integrity منطبق).
- MD5: `2232a7ffffe7466e7a8453472dbfc873`
- SHA-256: `aaab70f949b00550fe5da8f0f8223ab2c03c56457c9df884847fccbb5963d6a7`
- بدون تغییر DOM/ظاهر/مسیر/فرم/مجوز: هزینهٔ ثابت پوستهٔ غیر‌داشبورد از ۳۶ execute آمار/شمارنده به ۱ رسید؛ `db.stats` چهارده مقدار را با یک execute می‌دهد؛ داشبورد پنج list-load اضافی را حذف و snapshot شمارنده را بین کارت‌ها، sidebar و drawer به‌اشتراک می‌گذارد. status-indexهای هدفمند افزوده شد؛ index نظر `(status,biz_id)` است تا queryهای امتیاز پس‌رفت نکنند.
- پنل فقط `app.js?v184` را می‌گیرد؛ cart/stories/live و analytics عمومی حذف شدند: ۳ درخواست، ۲۴٬۵۵۹ بایت خام / ۹٬۵۳۱ بایت gzip کمتر در هر بارگذاری. بنچ سنگین یکسان: داشبورد 80.7→32.5ms (59.7% سریع‌تر)، ۱۸/۱۸ صفحه زیر 500ms/400KB.
- QA: panel-perf ۱۲/۱۲؛ public-perf ۱۴/۱۴؛ panel UX/mod/robust/security برابر ۳۲/۳۲، ۲۸/۲۸، ۱۶/۱۶، ۴۳/۴۳؛ مرورگر کامل ۲۱ صفحه × ۱۱ عرض؛ command palette/drawer/network واقعی؛ همه از بستهٔ استخراج‌شده نیز سبز. `qa_panel.py` فقط در T4.2/T4.3 پیش‌نمایش pending (شکست قدیمی/نامرتبط) متوقف شد. ZIP integrity/clean-tree/boot HTTP پاس شد. v183 پس از تأیید v184 حذف شد.

## تحویل قبلی — v183 / سرعت سایت عمومی و موبایل، بخش ۱ (۲۰۲۶-۰۹-۰۷)
- بستهٔ کامل: `dastgir-v183-section1.zip` · ۵٬۲۰۴٬۶۶۳ بایت · ۴۵۰ فایل.
- MD5: `1b312513cd74bc08ac30cc621f299d12`
- SHA-256: `2289e7e02b2387fff76bc43077e2974cb13813b544eb6205e84a503d9868cc43`
- بدون تغییر DOM/ظاهر/مسیر: لوگوی runtime از 256,588 به 33,646 بایت (7.6× / 86.8% کمتر) با مشتق 192px مناسب 38px تا DPR5؛ منبع 768px حفظ. CSS/JS نسخه‌دار immutable یک‌ساله؛ unversioned service-worker no-cache؛ gzip: pages 45,464 و app 29,351؛ HTML خانه <25KB.
- perf v183: ۱۴ قفل سبز؛ مرورگر کامل ۲۱ صفحه × ۱۱ عرض؛ logo/icon/category/brand سبز؛ تست perf از خود ZIP سبز. بخش ۲ در v184 تکمیل شد. v182 پس از تأیید v183 حذف شد.

## تحویل قبلی — v182 / جست‌وجوی آیکون دسته‌بندی، بخش ۲ (۲۰۲۶-۰۹-۰۷)
- بستهٔ کامل و جایگزین بخش ۱: `dastgir-v182-section2.zip` · ۵٬۱۶۷٬۹۲۸ بایت · ۴۴۸ فایل.
- MD5: `98b3aa5a4f4ff5cff3e31dbee2374e5c`
- SHA-256: `b0aeeb787f785196fcd4643042a452ae61e1f06b0d059b0423f78bb65ba21722`
- هر دو فرم ساخت/ویرایش دسته جست‌وجوی زندهٔ فارسی+لاتین، شمار نتیجه aria-live، حالت بدون نتیجه، Escape، لیست لمسی بازشونده و preview همگام دارند. انتخاب فعلی در جست‌وجوی بی‌نتیجه همچنان در FormData حفظ می‌شود.
- تست icon browser: ۲۱ قفل سبز؛ category image CRUD: ۱۵/۱۵؛ actions: ۵۵/۵۵؛ logo/brand سبز؛ مرورگر کامل ۲۱ صفحه × ۱۱ عرض؛ آزمون هر دو باتری از خود ZIP سبز و health/categories/assets همگی 200.
- `app.js?v182`، `pages.css?v182`، `VERSION=182` و `bazarche-v182`. بخش‌های ۱ و ۲ درخواست پنل دسته‌بندی اکنون کامل‌اند؛ بستهٔ مستقل v181 پس از تأیید بستهٔ کامل v182 حذف شد.

## تحویل قبلی — v181 / مدیریت تصویر دسته‌بندی از موبایل، بخش ۱ (۲۰۲۶-۰۹-۰۷)
- بستهٔ کامل: `dastgir-v181-section1.zip` · ۵٬۱۶۴٬۵۴۵ بایت · ۴۴۷ فایل.
- MD5: `dac01c2e609a944163694e87f9ddaaf1`
- SHA-256: `244534aa521f7069a7228d41ef2319bb04d470a25976988028521116eea3d4a1`
- ساخت و ویرایش دسته در پنل اکنون upload از گالری/دوربین موبایل، preview/editor، حذف و جایگزینی تصویر دارد. ستون categories.image با migration خودکار؛ custom بر slug.webp مقدم؛ sentinel حذف پایدار؛ فایل قدیمی در replace/delete پاک؛ GC تصویر دسته را محافظت می‌کند؛ فهرست پنل و صفحه عمومی تصویر تازه را نشان می‌دهند.
- تست زنده `test_category_images_v181.py`: ۱۵/۱۵ (auth/create/public/replace/delete packaged+custom/reupload/GC/category-delete/mobile)؛ migration v180 PASS؛ test_actions ۵۵/۵۵؛ مرورگر کامل ۲۱ صفحه × ۱۱ عرض سبز؛ آزمون از خود ZIP نیز ۱۵/۱۵ و health/categories=200.
- بخش ۲ درخواست کاربر—جست‌وجوی انتخابگر آیکون—هنوز انجام نشده و باید در پیام اجرایی بعدی اجرا شود. تحویل v180 پس از تأیید این بسته حذف شد.

## تحویل قبلی — v180 / فشرده‌سازی لوگو بدون افت کیفیت (۲۰۲۶-۰۹-۰۷)
- بستهٔ کامل: `dastgir-v180.zip` · ۵٬۱۵۹٬۶۴۳ بایت · ۴۴۶ فایل.
- MD5: `451aadaca5f3e53f019e7c2bb99998ba`
- SHA-256: `e95ceaadff4397e5180c06f690270b24496c93d63d21b65412ed98cd2b7986cd`
- خانوادهٔ تصویر منبع+چهار SVG از ۱٬۶۲۵٬۸۷۲ به ۳۷۲٬۶۷۶ بایت رسید (۱٬۲۵۳٬۱۹۶ بایت / ۷۷٪ کاهش). ZIP کامل نسبت به تحویل v179 برابر ۹۴۸٬۲۱۰ بایت / ۱۵٫۵٪ کوچک‌تر شد.
- منبع اصلی PNG با ابعاد ۷۶۸×۷۶۸ و SHA/pixel ثابت ماند و هدر/فوتر مستقیماً همان را نمایش می‌دهند؛ SVGهای مستقل ۲۵۶px و favicon مستقل ۱۲۸px، PNG بدون codec اتلافی هستند. کش و VERSION به ۱۸۰ ارتقا یافت.
- تست متمرکز حجم/کیفیت، مرورگر روشن/تاریک در ۱۴۴۰/۳۹۰، brand browser، باتری کامل مرورگر ۲۱ صفحه × ۱۱ عرض و بوت مرورگری از خود ZIP همگی سبز. تحویل v179 پس از تأیید v180 حذف شد.

## تحویل قبلی — v179 / بخش ۲ قرارداد نام عمومی (۲۰۲۶-۰۹-۰۷)
- بستهٔ کامل و جایگزین بخش ۱: `dastgir-v179-section2.zip` · ۶٬۱۰۷٬۸۵۳ بایت · ۴۴۶ فایل.
- MD5: `f8de1d6beb24b70fb16b3af3705c0a14`
- SHA-256: `d4133b86d392dbe9071993eef56b9a93a7c65cb8d775275eb754270fd99ce52c`
- نام عمومی دقیق **«دست گیر»** در لایهٔ DB ثابت شد: نصب تازه، migration، خواندن DB دست‌کاری‌شده، هر دو setter و restore پشتیبان نمی‌توانند نام دیگری را عمومی کنند. سه مسیر مدیریتی (settings/editor/inline-edit) نیز اجازهٔ تغییر ندارند و دو فرم نام را فقط‌خواندنی و بدون `name=site_name` نشان می‌دهند.
- راهنماها و عنوان‌های قابل‌مشاهدهٔ باقی‌مانده از برند قدیمی اصلاح شدند؛ شناسه‌های فنی لاتین (`bazarche.service`، DB، کش، `.bz-*`) طبق دستور دست‌نخورده‌اند.
- تست‌ها: brand unit/integration و brand browser هر دو سبز؛ isolation ۳۱/۳۱؛ phase11 برابر ۱۹/۱۹؛ actions برابر ۵۵/۵۵؛ مرورگر کامل ۲۱ صفحه + ۱۱ عرض سبز؛ بوت HTTP از خود ZIP روی health/home/manifest برابر 200 و عنوان `خانه | دست گیر`. `test_all` فقط همان دو شکست شناخته‌شده و نامرتبط `/compare` و نوار زیردسته را دارد.

### بخش ۱ موجود در همین بسته
- منبع نشان: concept-5.png کاربر، برش مربع ۷۶۸×۷۶۸؛ خروجی‌های SVG، favicon و PWA با `tools/build_logo.py` ساخته شدند.
- تست متمرکز لوگو، تکرارپذیری سازنده، PWA و مرورگر در ۱۹۲۰ تا ۳۶۰ پیکسل سبز شدند. آرشیو مستقل بخش ۱ پس از تأیید آرشیو کامل بخش ۲ طبق زنجیرهٔ پاک حذف شد.

---

## ۱) پروژه در یک نگاه
سایت آگهی/بازارچهٔ محلی «دست گیر» برای نجف‌آباد — تک‌فایل‌سرور پایتونیِ بدون وابستگی (Pydroid روی گوشی کاربر هم اجرا می‌شود)، دیتابیس SQLite، فرانت دستی (بدون فریم‌ورک)، پنل مدیر + پنل دکاندار + حساب مشتری، PWA با سرویس‌ورکر. سه نقش: **مشتری / دکاندار / مدیر**.
- نام برند: **«دست گیر»** (با فاصله — تصمیم کاربر ۲۰۲۶-۰۹-۰۶؛ همهٔ کد/DB از v177 پایه دست گیر است) · دامنه: `daastgir.ir` (دوتا «a» — عمدی) · VPS: `130.185.78.237` (پارس‌پک)
- مخزن: github.com/rezadb369-wq/369 · آخرین شناخته: `main @ 239b2bf` (= v152 کاربر)
- **فقط v152 به بعد وظیفهٔ من است؛ هر کار تازه از زیپِ تازه‌آپلودیِ کاربر در ریپو شروع می‌شود (قانون ۳).**

## ۲) وضعیت لحظهٔ پاکسازی (۲۰۲۶-۰۹-۰۶)
| موضوع | وضعیت |
|---|---|
| **v176** | ساخته/آزمون/تحویل شد: md5 تاریخی ثبت نشده (مقدار قبلی حدسی بود و حذف شد) · ۴٬۷۳۸٬۳۵۶ بایت · ۴۴۴ فایل · بوت‌تست ✔ (لینک x0.at/kFg7.zip منقضی) |
| **v177** | دور ۶دستوری + ادامهٔ ارتقا: تحویل تدریجی در ۸ بخش · **زیپ نهایی `dastgir-v177.zip` · md5 `3a152b55358acfe920ce7e979e2b2ee9` · ۴٬۵۳۳٬۵۸۶ بایت · ۴۶۴ فایل · لینک `https://x0.at/fd9x.zip` (md5 دانلود منطبق) · بوت‌تست 200** |
| آپلود موقت | `https://x0.at/kFg7.zip` (md5 دانلود منطبق؛ x0.at بعد از مدتی حذف می‌کند) |
| **استقرار روی VPS** | ✅ **انجام شد ۲۰۲۶-۰۹-۰۶ ~۱۲:۳۸ UTC** — md5 روی سرور منطبق `3a152b55…` · سرویس active · `curl 127.0.0.1` → 200 (اسکرین‌شات ترمینال کاربر). دستورها: `curl -sL -o /root/dastgir-v177.zip https://x0.at/fd9x.zip` سپس `bash /opt/dastgir/deploy/update.sh /root/dastgir-v177.zip` · ✅ **بدهی مهاجرت qty/note بسته شد (۲۰۲۶-۰۹-۰۶):** `_reconcile_schema` (v116) ستون‌های سادهٔ SCHEMA را روی DB کهنه خودکار ALTER می‌کند و در هر بوت اجرا می‌شود؛ مدرک: DB کهنه‌سازی‌شده (DROP qty/note) → بوت v177 ستون‌ها را برگرداند (`qty INTEGER DEFAULT 1` · `note TEXT DEFAULT ''`) و `qa_stock_fast` روی همان DB کهنه **۱۱/۱۱** پاس شد (F6 فقط برای نبود Playwright در سندباکس تازه نایستاد — قبلاً ✔). کد تغییر نکرد → همان زیپ `3a152b55` معتبر است. تفاوت ترتیب ستون‌ها بعد از مهاجرت بی‌اثر است (کد همیشه ستون‌ها را با نام می‌خواند). |
| A1 | باز: «رمز عبور پنل» روی سرور زنده هنوز تنظیم نشده (کلید پنل فعلاً = ادمین کامل) |
| دامنه | ✅ **کامل** — DNS + HTTPS (dns-01 با توکن کلادفلر) + ریدایرکت + site_url؛ گواهی تا ۲۰۲۶-۱۲-۰۵ با تمدید خودکار (بخش ۹) |
| لوگو (بازطراحی) | ✅ v179 بخش ۱ — `concept-5.png` کاربر جایگزین همهٔ خروجی‌های لوگو، favicon و PWA شد؛ در بستهٔ کامل بخش ۲ نیز موجود است |
| پاکسازی دوم | ✅ ۲۰۲۶-۰۹-۰۶ — فقط KNOWLEDGE + RULES + `dastgir-v177.zip` ماند |
| ریپو | آپلود v177 = کار کاربر (پوش از سندباکس نمی‌شود) |
| بازبینی مشتری | تمام — صفر باگ واقعی؛ ۸ یافتهٔ UX که **هر ۸ در v176 رفع شدند** (بخش ۷) |
| سرور سندباکس | حین پاکسازی خاموش شد؛ سشن بعد: از زیپ تازه باز کن یا منتظر آپلود کاربر باش |

## ۳) نسخه‌شناسی (v152 → v177)
- **v152** شش اصلاح بازبینی کاربر (نقطهٔ شروع مسئولیت من) · **v156** نقشه (فرمول مقیاس پین) + فراخوان دکان · **v157–v159** درس‌های UX/اعلان/استقرار (در RULES.md ثبت است)
- ممیزی جامع پنل (مصوب کاربر؛ `QA-panel-audit-plan.md` داخل زیپ): **۲۴ باگ #17–#40 + ۵ ارتقا A1–A5**
  - v167(A2/#17) · v168(A3/#18) · v170(A4/A5/#20–23) · v171(#24–26) · v172(#27–31؛ #30 بحرانی) · v173(#32–34) · v174(#35–39؛ #39 ریشهٔ WAL) · v175(#40 + دِدوپ queue_edit)
- **v177 (فعلی)** — دور ۶دستوری کاربر + ادامهٔ ارتقای استاندارد:
  1. برند «دست گیر» (همه‌جا، حتی DB) · 2. لوگوی تازه (هدر/فوتر/favicon/PWA) ·
  3. بازدید واقعی یکتا (story_views.viewer UNIQUE + page_viewers روزانه + بایگانی legacy) ·
  4. تاریخچهٔ استوری‌ها (صفحهٔ عمومی /b/{slug}/stories + بخش دکاندار + توقف پاک‌سازی منقضی‌ها) ·
  5. «بازیابی فایل‌ها» (تغییر نام + پیش‌نمایش/لایت‌باکس + مهلت ۳۰روزه + رفع ۲ باگ GC) ·
  6. فرم سریع «موجود شد خبرم کن» (چیپ کالا + تعداد + یادداشت → کارت در چت) ·
  7. scene_v177 خودکفا (بازسازی دنیای دمو + بذر تیکت/نظر) · نگهبان: VERSION=177 · sw bazarche-v177 · css ?v178
  درس‌های کلیدی: کوکی bz_cid روی هر صفحهٔ HTML سنجاق شود؛ ملاک مهاجرت = ایندکس UNIQUE؛ گارد «دست‌نخوردگی» = غیر-دمو.
- **v176** — رفع کامل یافته‌های دور «چشم مشتری»:
  1. **دِدوپ یک‌رأیِ «مفید بود»** — جدول تازه `review_votes(review_id, voter UNIQUE)` در db.py؛ `features.review_helpful(rid, voter)`؛ مسیر `/api/review-helpful` در app.py رأی‌دهنده می‌سازد: واردشده=`c<id>`، مهمان=`k+sha256(client_key+UA)[:16]` (هیچ IP خامی ذخیره نمی‌شود). تکرار = no-op. **تصمیم مستند v175 (رد دِدوپ) با فرمان کاربر لغو شد.**
  2. لمس ≥۴۴px: چیپ استوری inline (pages.css)، `.map-me`، چک‌باکس‌های فرم موبایل (بلوک تازه در main.css با `:not(.check input)` تا `.check` قدیمی نشکند)، `.biz-own-actions .btn` و `.map-selected .ms-acts .btn` (mobile-refine.css از ۳۸→۴۴)
  3. متن ≥۱۲px: `.item-price s { font-size: max(.9em, 12px) }`
  4. اعلان سقف ۹۹: پرچم `qty_capped` در `/order/create` → `/order/ok?cap=1` → پیام روی رسید (`order_done(s, oid, cap)`)
  5. نگهبان نسخه: `VERSION.txt=176` · `sw.js=bazarche-v176` · `main/pages/mobile-refine.css ?v176` در ui.py

## ۴) محتویات زیپ v177
کد کامل + `tools/qa_*.py` (۱۶ باتری) + مستندات (ARCHITECTURE.md، HANDBOOK.md، MOBILE.md، DEPLOY.md، QA-panel-audit-plan.md، WHATS-NEW.md، VERSION.txt=176) + `deploy/` (update.sh، backup.sh). **نیست داخل زیپ:** `data/`، `qa/*.json` (نتایج)، `shots*/`، `__pycache__`.

## ۵) آیین شروع کار (هر چت تازه)
1. این فایل + `RULES.md` را بخوان.
2. **قانون ۳:** وضعیت ریپو را اعلام کن؛ اگر کاربر zip تازه گذاشته، آن منبع حقیقت است — باز کن، باتری‌ها را اجرا کن، ادامه بده.
3. سرور تست: `cd <ریشهٔ پروژه> && python3 run.py` (پورت 8080؛ `GET /healthz` باید 200 بدهد). برای پراسهٔ بلند از start_process استفاده کن، نه nohup داخل bash.
4. playwright هر سشن تازه نصب شود: `pip install playwright -q && python3 -m playwright install --with-deps chromium` (~۲۳ ثانیه).
5. صحنهٔ آزمون را بچین (بخش ۶)، بعد کار.

## ۶) آزمون‌ها — باتری‌ها و صحنهٔ استاندارد
### ۶.۱ باتری‌ها (داخل `tools/qa_*.py`، اجرا از ریشهٔ پروژه)
`qa_crawl` (خزندهٔ ۴ نقش) · `qa_customer` (۳۵) · `qa_shop` (۳۰) · `qa_panel` (۳۶) · `qa_security` (۲۲) · `qa_mobile` (۱۶) · `qa_phase5..15` (۲۳،۳۴،۲۹،۳۶،۳۲،۱۸،۲۶،۲۳،۳۰،۱۲) · `qa_views` (۱۰) · `qa_archive` (۲۲) · `qa_file_recovery` (۱۷) · `qa_stock_fast` (۱۴) → **جمع ۴۶۵ تست (۱۹ باتری)**. نتیجه‌ها در `qa/*-results.json`. آخرین وضعیت کامل سبز: ۲۰۲۶-۰۹-۰۶ (v177 · ۴۶۵/۴۶۵).

### ۶.۲ صحنهٔ استاندارد (قبل از هر باتری چک/بازگردان)
**میان‌بر تازه:** `python3 tools/scene_v177.py` صحنهٔ کامل را با شناسه‌های قطعی می‌سازد/ترمیم می‌کند (idempotent؛ شامل FTS rebuild). از دور v177 داخل زیپ هم هست.
```sql
update items set available=1 where id=336;
-- بذر نظر فقط اگر نیست:
insert into reviews(biz_id,author,rating,body,status,customer_id,created)
  values(214,'مشتری آزمون',5,'بذر آزمون برای qa_panel','approved',NULL,datetime('now'));
```
- حساب‌ها: **ادمین** 09131110011 (owner 1، ورود پنل با کلید `db.owner_token()`) · **دکاندار A** 09352223344 (owner 2؛ دکان 214) · **دکاندار B** 09134950001 (owner 89؛ دکان 215) · **مشتری** 09361112233 (customer 17) · دکان‌ها 214–216 پایان هر دور: `owner_id=NULL, booking_on=0`
- ⚠️ **qa_shop کالای 336 را می‌خرد** → قبل از qa_customer/qa_mobile/فازها برگردان به 1
- ⚠️ **بذر نظر باید `customer_id=NULL` باشد** — اگر با customer_id=17 بذری، گیت «یک امتیاز برای هر حساب» C7 و C9 را قرمز می‌کند (درس این دور)
- بنر بذر `id=8` تگ‌دار است — `demo.clear` نابودش می‌کند؛ پاک‌سازی فقط با id/نشانهٔ دقیق · `reset_testdata` وصله‌خورده (KEEP_SLUGS/KEEP_OWNERS) · `wipe_all --all` مخرب
- otp/ratelimit/searches بین دورها خالی شوند

### ۶.۳ قراردادهای مسیرها (تغییر نکن مگر با قفل باتری)
- ورود مشتری: `POST /login` → `POST /login/verify` (فیلدها phone/code). `/me/login` فقط GET-ریدایرکت است.
- `/contact` پیام نمی‌پذیرد → ریدایرکت به تیکت (`/my/tickets` یا `/login?next=`).
- چت: **GET** `/b/{slug}/chat` رشته می‌سازد/باز می‌کند → `POST /me/chat/{tid}` (فیلد body + attachment) · API خواندن: `/api/chat/{tid}/msgs?after=N`
- رأی مفید: `POST /api/review-helpful {id}` (v176: یک‌رأی با review_votes) · نظیر پرسش: `/api/question-helpful`
- دنبال‌کردن/علاقه‌مندی: `POST /api/follow`، `POST /api/favorite` (body: biz_id)
- multipart-only: `/panel/ad/new` و `/panel/appearance` · unlock پنل = `POST /panel/login` با کلید
- جست‌وجو = `/businesses?q=` · برترین‌ها = `/lists` (نه `/top`) · جزئیات مالک/مشتری در پنل POST-only است (GET‌شان 404 عمدی)
- لغو سفارش: <۳۰ دقیقه مستقیم (`cancelled`)، بعدش `cancel_requested=1` (درخواست برای دکاندار) — هر دو با DB اثبات شد
- نوبت: فرم `/b/{slug}/book` دیت‌پیکر شمسی دارد (فیلد مرئی بی‌نام + hidden name=date)؛ دکاندار تأیید با `button[value=confirmed]`
- پس از POSTهای عمومی **مکث کش ۵٫۲ ثانیه** (تست UI با reload + ~۶s)
- POST با متن فارسی: `urllib.parse.urlencode(..., encoding='utf-8')` وگرنه UnicodeEncodeError
- playwright: کلیک submit با `no_wait_after=True` + انتظار با `wait_for_url`؛ دیالوگ‌ها: `pg.on('dialog', accept)`؛ دکمه‌های تکراری‌ناپذیرِ verify گاهی تایم‌اوت کلیک می‌دهند → fallback `form.submit()` از evaluate

### ۶.۴ جداول مرجع (آخرین بررسی)
`alerts(id,phone,term,cat_slug,active,sent,created)` · `price_alerts(customer_id,group_key,title)` — هشدار قیمت کلید-گروهی است نه item_id · `review_votes(id,review_id,voter,created, UNIQUE(review_id,voter))` — تازهٔ v176 · `reviews(id,biz_id,author,rating,body,reply,image,status,customer_id,created,helpful)` · `order_items.item_id` nullable-FK · `items.available=0` یعنی خریدار خریده · `owner_notifications` ستون `text` · `stock_requests(biz_id,item_id,customer_id,status,...)` · `favorites`/`follows` (customer_id,biz_id)

## ۷) بازبینی «چشم مشتری» — نتیجه و رفع‌ها
دور کامل ۱۲-بخشی (۱۹۹ سنج، ~۶۰ صفحه، موبایل ۳۶۰×۷۴۰ + ۳۲۰/۴۱۲): **صفر باگ واقعی**. ۸ یافتهٔ جزئی → **هر ۸ در v176 رفع شد** (فهرست فنی در بخش ۳). مدرک کامل با اسکرین‌شات: `customer-audit-report.html` (در ورک‌اسپیس مانده). اعداد کراول این دوره: ۲٬۷۶۱ + ۲٬۱۰۰ + ۲٬۸۰۳ + ۱٬۰۶۰ صفحه در ۴ دور — **صفر غیر-200** · رگرسیون نهایی ۳۸۹/۳۸۹.
- نکتهٔ 403 تک‌بار در حالت مهمان: در بازتولید تمیز نیامد — غیرقابل بازتولید؛ اگر تکرار شد، ردیابی شود.

## ۸) زیرساخت
- **سندباکس:** پایتون ۳.۱۳؛ سرور `python3 run.py` (PORT=8080 پیش‌فرض؛ 8888 هم می‌شنود)؛ فقط فایل‌های داخل /home/user ماندگارند؛ `.cache` (شامل playwright) بین سشن‌ها پاک می‌شود.
- **سندباکس → VPS زنده بسته است** (TCP handshake می‌شود ولی صفر بایت؛ پروکسی‌های allorigins/codetabs/jina هم). **دیگر curl به VPS تلاش نشود** — تست زنده فقط لوکال یا تک‌خطِ روی خودِ سرور برای کاربر. whois/rdap هم از سندباکس نمی‌شود → وارسی رجیستری فقط با web_search.
- **VPS:** `root@130.185.78.237` · پروژه در `/opt/dastgir` · استقرار: `bash /opt/dastgir/deploy/update.sh /root/<zip>` · دست‌نخورده‌های سرور: `data/bazarche.db`، `uploads/`، `chat-files/` · systemd: `bazarche.service` · پشتیبان روی سرور: `/root/dastgir-v175.zip` (تا جایگزینی با v177)
- **x0.at:** `curl -sS -A "curl/8.5" -F "file=@F" https://x0.at` → لینک موقت (کم‌ترافیک بعداً حذف می‌شود) · توکن حذف ذخیره نشده → حذف دستی لینک از سمت ما ممکن نیست؛ لینک‌های کهنه (kFg7، S67Y) خودشان منقضی می‌شوند؛ `fd9x` = لینک رسمی v177 تا انقضا

## ۹) دامنهٔ daastgir.ir — ✅ کامل شد (۲۰۲۶-۰۹-۰۶): DNS + HTTPS + ریدایرکت
- مسیر نهایی: دامنه مستقیماً در پنل ایرنیک خود کاربر (`new.nic.ir`) بود؛ پارس‌پک فقط رجیسترا (هندل `pa602-irnic`) و dashboardش مدیریت NS/رکورد نداشت → آن مسیر رها شد.
- NS در ایرنیک ثبت شد: `ethan.ns.cloudflare.com` + `maya.ns.cloudflare.com` → کلادفلر همان روز **Active** («دامنهٔ شما اکنون توسط Cloudflare محافظت می‌شود»).
- کلادفلر DNS (پلن Free): A `@` و A `www` → `130.185.78.237`، هر دو **DNS only** (ابر خاکستری — عمداً بدون پروکسی تا certbot مستقیم روی سرور گواهی بگیرد).
- resolve از سندباکس تأیید شد: daastgir.ir و www.daastgir.ir → 130.185.78.237 ✔
- انقضای دامنه: ۲۰۲۸-۰۹-۰۲ (ایرنیک). هشدار «پروکسی مورد نیاز» کلادفلر و توصیهٔ MX/ایمیل → بی‌اهمیت/بعداً.
- **یافته‌های سرور (۲۰۲۶-۰۹-۰۶، اسکرین‌شات ترمینال):** کانفیگ nginx = `/etc/nginx/sites-available/dastgir` (سطر ۳-۵: `listen 80 default_server` + `listen [::]:80` + `server_name _;`) · تنها سایتِ enabled همین است (sites-enabled فقط symlink dastgir) · nginx روی :80، اپ python3 روی :8080 · certbot ابتدا نبود → نصب `certbot python3-certbot-nginx` در خط بعدی · بکاپ کانفیگ: `/root/dastgir.nginx.bak` · دامنهٔ ایمیل certbot کاربر: `rezahakimi689@gmail.com` (۶۸۹).
- **تلاش اول certbot (۱۶:۲۳):** server_name اعمال و nginx reload شد (`nginx -t` ok) و اکانت LE با `rezahakimi689@gmail.com` ثبت شد؛ اما HTTP-01 برای هر دو دامنه `Timeout during connect` خورد (LE به :80 نرسید — به احتمال زیاد فیلتر اسکن خارجی/موقتی). diagnose+retry در جریان؛ سایت در این فاصله سالم و بالا است.
- **تشخیص نهایی (۲ تلاش HTTP-01 شکست):** ufw باز (80/443) · loopback nginx: 404 سالم · هر ۲ تلاش certbot `Timeout during connect` از سمت LE → **ورودی پورت ۸۰ از خارج کشور به 130.185.78.237 ریزش می‌کند**؛ از داخل سرور قابل‌تعمیر نیست → سوئیچ به چالش **dns-01** با توکن کلادفلر (مسیر قطعی). جریان: (۱) کاربر توکن Edit zone DNS برای daastgir.ir می‌سازد، (۲) `read -s` → /root/cf.ini، (۳) `apt-get install python3-certbot-dns-cloudflare && certbot -a dns-cloudflare --dns-cloudflare-credentials /root/cf.ini --dns-cloudflare-propagation-seconds 30 -i nginx -d daastgir.ir -d www.daastgir.ir --redirect --non-interactive`. نکتهٔ جغرافیا: دسترسی بین‌المللی به سایت مستقل از گواهی است و با HTTP امروز هم‌اندازه؛ مخاطب داخلی مشکل ندارد. توکن برای تمدید خودکار باید بماند (حذف/لغو نشود).
- **✅ گواهی صادر و نصب شد (۱۷:۰۰، اسکرین‌شات):** `certbot -a dns-cloudflare --dns-cloudflare-credentials /root/cf.ini --dns-cloudflare-propagation-seconds 30 -i nginx -d daastgir.ir -d www.daastgir.ir --redirect` → Successfully received certificate · انقضا **۲۰۲۶-۱۲-۰۵** · تمدید خودکار scheduled · هر دو دامنه روی `/etc/nginx/sites-enabled/dastgir` deploy شد · `--redirect` → http 301 به https.
- **✅ site_url ست شد و تست نهایی سبز:** `site_url=https://daastgir.ir` + `systemctl restart bazarche` → active · از خود سرور: https://daastgir.ir → 200 · https://www → 200 · http → 301.
- **نگهداری:** `/root/cf.ini` (توکن کلادفلر، chmod 600) باید بماند — تمدید خودکار از همان استفاده می‌کند؛ توکن در داشبورد کلادفلر حذف/Roll نشود. بکاپ کانفیگ nginx: `/root/dastgir.nginx.bak`. مطمئن‌سازی آینده: `certbot renew --dry-run`. (دسترسی بین‌المللی مستقیم به :80 سرور نامطمئن است؛ چالش‌های بعدی هم dns-01 خواهد بود — نیازی به تغییر نیست.)

## ۱۰) کارهای باز (به‌ترتیب)
1. ~~استقرار v177 روی VPS~~ ✅ انجام شد ۲۰۲۶-۰۹-۰۶ (md5 منطبق؛ active/200).
2. **A1:** تنظیم «رمز عبور پنل» روی سرور زنده (باز از خیلی قبل؛ منتظر تأیید/اقدام کاربر).
3. **آپلود v177 به ریپو** — کار کاربر؛ کار بعدی من از همان شروع می‌شود (قانون ۳).
4. ~~HTTPS دامنه~~ ✅ بسته شد ۲۰۲۶-۰۹-۰۶ (گواهی dns-01 تا ۲۰۲۶-۱۲-۰۵ · 200/200/301 · بخش ۹). ماندهٔ واقعی فقط: A1 و آپلود ریپو (هر دو دست کاربر).
5. **بازطراحی لوگو** — ⏸ متوقف: ۳ دور پیشنهاد رد شد. شروع مجدد فقط با توصیف دقیق کاربر از نشان مطلوب → ساخت وکتوری → جایگزینی favicon/logo-mark/logo.svg + آیکون‌های PWA (192/512/maskable) + بامپ کش (`?v179`) + رگرسیون + زیپ.

## ۱۱) دام‌ها و درس‌های ثبت‌شده (سیاههٔ ضدتکرار)
- **کپی توکن/رمز از موبایل پرخطاست:** سه Paste پشت‌هم خراب (۱۳۴/۲۲۰/۸۱ بایت به‌جای ~۶۸) تا `"status":"active"` از endpoint verify کلادفلر برگشت. قانون: بعد از ذخیرهٔ هر توکن، اول verify (یا هر تست معادل) قبل از استفاده؛ دکمهٔ Copy خود پنجرهٔ کلادفلر، نه انتخاب دستی. توکن هرگز در چت (فقط `read -s` یا nano روی سرور).
- `edit_file` به old_text دقیق حساس است → متن واقعی را اول grep/bخوان؛ راه مطمئن: python replace با assert.
- **قفل SQLite در اسکریپت‌های بذر:** اتصال خامِ خودت با تراکنش باز، `db._run` سرور را قفل می‌کند → کامیت مرحله‌به‌مرحله بین نوشتن‌ها.
- #37: ریشهٔ «database is locked» دوگانه بود — گرسنگی WAL (truncate پیش‌گیرانهٔ >1.5MB در کد هست) + اتصال کامیت‌نشده در finally باتری‌ها → همهٔ پاک‌سازی‌ها با `q()`.
- `pkill -f` الگوی خود شل را هم می‌کشد (خود-کش) → bash با کد -1 تمام می‌شود؛ سرور فقط با start_process، توقف با stop_process.
- krawlerهای حدسی 404 می‌گیرند (`/top`، `/panel/questions`، `/panel/owner/{id}`، ...) — اول لینک واقعی UI را از DOM بگیر.
- «موفقیت جعل» خانوادهٔ باگ‌های #26/27/33/35/36 است — هر رفع تازه با باتریِ همان مسیر قفل شود؛ پیش‌فرض صحنه را از پایگاه بخوان (#31).
- #41/#42: فیلدِ دست‌خوردهٔ صحنه مالِ باتری‌های دیگر است — آزمون آماری درون‌مجموعه‌ای، ident پویا.
- بات‌تست: کپی پروژه در /tmp (بدون data/qa/shots) → `PORT=8097 python3 run.py` → curl → kill با pid → پاک‌سازی.
- X0.at لینک را بعداً حذف می‌کند — پشتیبان همیشه `/root/*.zip` روی VPS.
- باتری‌ها با تغییر رفتار باید هم‌زمان به‌روز شوند (نمونه: T3 فاز ۱۵ با دِدوپ v176 بازنویسی شد).

## ۱۲) نقشهٔ ورک‌اسپیس پس از پاکسازی (همین لحظه)
```
/home/user/
├── KNOWLEDGE.md                ← همین فایل (مرجع شروع)
├── RULES.md                    ← قوانین همکاری (قانون ۴)
└── dastgir-v177.zip            ← تنها آرتیفکت؛ آخرین نسخهٔ سایت (md5 3a152b55…) — هر دور جدید از بازکردن همین زیپ شروع می‌شود
```
حذف‌شده‌ها: `work/` (کدِ کاری v175/v176 — داخل زیپ هست)، `repo/` (کلون کهنه + v152)، `HANDOFF.md` (محتوای عملیاتی‌اش همه در همین فایل است؛ پیوست تاریخی‌اش = FULL-HANDOFF در ریپوی کاربر)، `qa-live-plan.md`، `qa-customer-plan.md`، `vps-comparison-fa.md`. **پاکسازی دوم (۲۰۲۶-۰۹-۰۶، فرمان کاربر «همه‌چیز واقعی حذف شود»):** `work/dastgir` (کدِ کاری v177 — هر دور از زیپ بازسازی می‌شود؛ تنها «راهنمای-راه‌اندازی-رایگان.md» ~۲KB و «نصب-سریع.md» ~۵KB خارجِ زیپ بودند و برای همیشه حذف شدند)، `logo-work/` (۳ دور پیشنهاد لوگو — رد کاربر)، `customer-audit-report.html`، `uploads/` (اسکرین‌شات‌های مدرک — نتایج کلیدی متنِ همین فایل است)، `.cache` و بقایای /tmp. فضای کار: ~۹۰MB → ۴.۴MB؛ فقط KNOWLEDGE + RULES + زیپ (md5 سالم).

## ۱۳) جملهٔ پایانی برای ادامه‌دهنده
کار تمیز است: v176 با صفر باگ شناخته‌شده و رگرسیون کامل سبز بسته شد؛ ماندهٔ کار فقط **عملیاتی** است (استقرار، رمز پنل، دامنه، پوش ریپو) و همه دستِ کاربر است. کار تازه فقط با فرمان کاربر و از آپلود تازهٔ او.

- **ترتیب باتری‌ها (پایان v177):** qa_shop ۳۳۶ را می‌خرد و qa_panel مرزهای
  مالکیت را می‌آزماید → قبل از qa_customer/qa_mobile و فازها `scene_v177` اجرا
  شود؛ **qa_phase9 دکان ۲۱۵ را بی‌مالک می‌خواهد** (خودش مالک ۲ را تأیید
  می‌کند) → پیش از فاز۹: `update businesses set owner_id=NULL where id=215`
  و پس از آن صحنه را برگردان. qa_phase10 T4.3 (وزن بنر) آماری است و روی
  ~۱۰۰ قرعه ممکن است یک‌بار قرمز شود → ران دوباره.
- **سرریز sitemap.xml خام در sweep کامل طبیعی است** (سند XML برای ربات،
  نه UI) — ملاک سرریز، باتری موبایل روی صفحات UI است.
- edit_file با متن بسیار بلندگاه path را می‌اندازد → بلوک‌های بزرگ را با
  python replace بزن؛ بریدن JS داخل f-string ممنوع (براکت‌ها) → JS را رشتهٔ
  خام جدا کن. `hidden` + `display:grid` = پوشش صفحه → همیشه
  `[hidden]{display:none}` همراهش بنویس.

## ۱۴) v189 — fallback رسمی Rubika getUpdates (۲۰۲۶-۰۹-۰۷)
- v188 در تولید سالم نصب شد (`VERSION=188`، health عمومی/محلی، ثبت هر دو endpoint و payload مصنوعی 200)، اما پیام واقعی `/start` پاسخ نگرفت. تشخیص رسمی `getUpdates` رویدادهای واقعی مستقیم `NewMessage` و `next_offset_id` را نشان داد؛ بنابراین OK ثبت endpoint مدرک تحویل push نیست.
- v189 یک poller daemon در همان تک‌پردازهٔ `run.py` دارد: `getUpdates` هر ۲ ثانیه، `start_id = next_offset_id`، سپس POST رویداد به مسیر داخلی `/api/rubika/update/<secret>`. خطا fail-open است و سرویس وب را نمی‌خواباند. webhook حفظ شده و replay-claim پایدار مانع اجرای دوبارهٔ payload برابر می‌شود.
- تأییدهای login/link/signup روبیکا ChatKeypad یک‌بارمصرف‌اند تا در ReceiveUpdate/getUpdates برسند؛ AskMyPhoneNumber و تأیید مستقل همچنان sender/chat-bound و اجباری‌اند. app update route اکنون `rz187:(login|link|signup):token` را پردازش می‌کند.
- تست کامل سورس: Rubika ۱۰/۱۰؛ Rubika HTTP/polling ۱۰/۱۰ (شامل صف واقعی و cursor)؛ Bale ۲۶/۲۶؛ Bale HTTP ۱۸/۱۸؛ public performance ۱۲/۱۲؛ logo guard PASS؛ py_compile و bash syntax PASS.
- مسیر سورس: `/home/user/repo369/v178/extracted/dastgir`؛ هدف بسته: `/home/user/repo369/v178/dastgir-v189.zip`. توکن Rubika داخل بسته/چت نیست و فقط باید در `/etc/dastgir-secrets.env` بماند.
- بستهٔ نهایی v189 ساخته و از خود ZIP دوباره آزموده شد: 459 فایل، 5,242,492 bytes، SHA-256 `0aba4c51fd065df141348d45c14fd40a695b9b4b7843af41449c60e7f6bac095`، MD5 `98174248d95f78fa55cf085810beec27`، integrity سالم، forbidden runtime/secrets صفر.
- لینک shell-only آپلود و redownload byte-identical: `https://x0.at/H0Nl.zip`.

## ۱۵) v190 — fallback امن برای چت فعال Rubika (۲۰۲۶-۰۹-۰۷)
- گزارش تولید: بات با `/start` فعال و پاسخ‌گو است، اما کلیک ورود سایت در چتی که قبلاً Start شده فقط چت را باز می‌کند؛ دکمه Start و رویداد جدید وجود ندارد. این رفتار کلاینت، نه خرابی polling، علت است.
- رفع: صفحهٔ انتظار payload تصادفی پنج‌دقیقه‌ای را با یک لمس کپی و بات را باز می‌کند؛ کاربر در چت فعال Paste+Send می‌کند (بدون تایپ). parser فقط payload دقیق `(?:/start )?(login|link)_TOKEN` را می‌پذیرد و سپس همان challenge هش‌شده، sender/chat binding، شمارهٔ خودم و تأیید مستقل را اجرا می‌کند. هیچ تطبیق ناامن با آخرین challenge وجود ندارد.
- مسیر استاندارد رسمی `?st=`/`aux_data.start_id` حفظ شده؛ v189 polling نیز بدون تغییر حفظ است.
- QA سورس v190: Rubika 10/10، Rubika HTTP/polling/active-chat 11/11، Bale 26/26، Bale HTTP 18/18، performance 12/12، logo PASS، صفحهٔ active-chat در Chromium بدون JS error، py_compile و bash syntax PASS.
- بستهٔ v190: `/home/user/repo369/v178/dastgir-v190.zip`، 460 فایل، 5,244,857 bytes، SHA-256 `2f0b791ecb8db9e560138fe5aaa1391af9c30a6fb8f18340dd9f2633fe326704`، MD5 `a308bf1d990f30339205a046380bbbb5`؛ package QA کامل سبز و forbidden runtime/secrets صفر.
- لینک shell-only و redownload byte-identical: `https://x0.at/VxUA.zip`.

## ۱۶) v191 — ContactMessage جدا پس از AskMyPhoneNumber (۲۰۲۶-۰۹-۰۷)
- گزارش زنده: بعد از «ارسال شمارهٔ تلفن» هیچ مرحله‌ای نمایش داده نشد. ریشه در v190: handler هم‌زمان contact_message و همان button_id را لازم داشت؛ Rubika شماره را به شکل NewMessage/ContactMessage جدا و احتمالاً بدون button_id می‌فرستد.
- رفع v191: هر ContactMessage فقط از sender_id+chat_id دارای challenge زنده و قبلاً bind‌شدهٔ Rubika پذیرفته می‌شود؛ db.messenger_signup_prepare همین اتصال را کنترل می‌کند. wrong-chat test ثابت می‌کند تماس خارجی دکمهٔ approval نمی‌سازد. تأیید مستقل پس از شماره پابرجاست.
- QA سورس و ZIP: Rubika 10/10، Rubika HTTP/polling/contact 13/13، Bale 26/26، Bale HTTP 18/18، performance 12/12، logo/syntax/compile PASS.
- بسته: `/home/user/repo369/v178/dastgir-v191.zip`، 461 فایل، 5,246,947 bytes، SHA-256 `ed6f023038a00971c59de26646e6578aa7f44caca0ab86e50f6ff0d84a64bd51`، MD5 `93bbf31754980af3169e9edd638d05ed`؛ forbidden صفر. لینک redownload-identical: `https://x0.at/M8Ln.zip`.

## ۱۷) v192 — AskMyPhoneNumber = text + button_id در تولید (۲۰۲۶-۰۹-۰۷)
- کاربر تصریح و اسکرین‌شات اثبات کرد شماره‌های حباب بنفش واقعاً خروجی دکمهٔ رسمی‌اند، نه تایپ دستی. Rubika این کلاینت شماره را در Message.text همراه aux_data.button_id می‌فرستد، نه ContactMessage.
- v192 شاخهٔ امن text+phone_button دارد: button_id باید `rz187:phone:<request>`، challenge زنده و platform=Rubika باشد و platform_user_id/chat_id دقیقاً با رویداد برابر باشد؛ سپس text به norm_phone/signup_prepare می‌رود. متن شماره بدون button_id رد می‌شود. ContactMessage جدا نیز برای کلاینت‌های دیگر حفظ شد.
- QA سورس/ZIP: Rubika 10/10، HTTP/polling/real-phone 14/14، Bale 26/26، Bale HTTP 18/18، performance 12/12، logo/syntax/compile PASS.
- بسته `/home/user/repo369/v178/dastgir-v192.zip`: 462 فایل، 5,249,043 bytes، SHA-256 `c8e95b1104c98b263046674bcb78158c04e0e563d028f8057907c9d1fc05b93a`، MD5 `9ce89c8c8b2951c6bf78b34f71c6fab3`، forbidden صفر. URL byte-identical: `https://x0.at/ZmEg.zip`.

## ۱۸) v193 — جایگزینی کامل Rubika با Soroush Plus (۲۰۲۶-۰۹-۰۷)
- فرمان کاربر: «کلا سروش جایگزین روبیکا». تفسیر اجراشده: بله حفظ؛ سروش جای روبیکا در login/signup/link/unlink/notifications/UI/runtime؛ داده‌های تاریخی Rubika در DB حذف نشوند ولی غیرفعال باشند.
- همه 11 chunk سند رسمی `https://soroushplus.com/p/documents/bot-platform` بررسی شد: API `https://api.splus.ir/bot<TOKEN>`، webhook/getUpdates انحصاری، update_id، نگهداری صف 24h، پورت webhook 443/80/88/8443، getWebhookInfo، callback_data<=64B و answerCallbackQuery، IDs تا 52-bit، request_contact فقط private، Contact.user_id.
- پیاده‌سازی: `server/soroush.py`; endpoint `/api/soroush/webhook/<secret>`؛ browser status `/api/soroush/status`; auth `/auth/soroush`; account routes `/me/soroush/{connect,unlink}`؛ platform=`soroush`; notification fanout Bale+Soroush. Rubika poller/import/routes/module/tests/deploy guides حذف شدند. Webhook سروش فقط push است و poller ندارد.
- امنیت signup: chat.type دقیقاً private؛ contact.user_id باید موجود و برابر message.from.id؛ شماره دستی/foreign/ownerless رد؛ callback مستقل، challenge browser-bound و replay claim update_id. چون deep-link payload رسمی مستند نیست، UI copy+open امن استفاده می‌کند و username با getMe کشف می‌شود.
- nginx fresh config برای webhookهای secret `access_log off` دارد؛ deployment live باید location مشابه را بدون overwrite کانفیگ certbot اضافه کند.
- QA source: Soroush 11/11، Soroush HTTP 20/20، Bale 26/26، Bale HTTP 18/18، performance 12/12، logo PASS، mobile Soroush UI/JS PASS، py_compile/bash syntax PASS.
- v193 final ZIP: `/home/user/repo369/v178/dastgir-v193.zip`, 458 files, 5,244,496 bytes, SHA-256 `8af787383d9a9920103a94236b87c647d17689c1050c49d9796468bdcb3216e7`, MD5 `10e13c0907a971a2a305c4ee46489e24`; forbidden runtime/secrets صفر و active Rubika artifacts صفر. Package QA کامل سبز.
- shell-only upload `https://x0.at/jjxp.zip`; redownload byte-identical و ZIP integrity سالم.

## ۱۹) v194 — Android direct Soroush app handoff (۲۰۲۶-۰۹-۰۷)
- گزارش/اسکرین‌شات: لینک رسمی splus.ir بات در Chrome صفحه واسط نشان می‌دهد و «مشاهده در نسخه اندروید» روی دستگاه نصب‌شده هم عمل نکرد. کاربر مستقیم مانند Bale خواست.
- رفع: `soroush.android_intent()` لینک HTTPS بات را در Android Intent استاندارد با package رسمی `mobi.mmdt.ottplus` و browser_fallback_url رسمی می‌پیچد. UI روی Android href دکمه اصلی را intent می‌کند؛ copyNow به‌صورت synchronous در همان click gesture قبل از navigation اجرا می‌شود. دکمه جدا «فقط کپی» و لینک وب باقی است. غیرAndroid همان HTTPS را می‌گیرد.
- QA: Soroush 12/12، HTTP 20/20، Bale 26/26، Bale HTTP 18/18، performance 12/12، logo PASS، Chromium Android UA href/package/JS PASS.
- ZIP `/home/user/repo369/v178/dastgir-v194.zip`: 459 files، 5,246,606 bytes، SHA-256 `c4505303ff5f8452f94d9721049b1111d2357a38bbce487e20daa05d668053f6`، MD5 `9aa7d39dc88c407fec2e71f4c89847b7`; URL byte-identical `https://x0.at/h7Bu.zip`.

## ۲۰) v195 — اجرای package launcher سروش بدون resolve وب (۲۰۲۶-۰۹-۰۷)
- بازخورد دستگاه واقعی بعد از v194: Intent حامل HTTPS توسط اپ resolve نشد و browser_fallback دوباره صفحه splus.ir را باز کرد.
- v195 آدرس بات را از Intent اصلی حذف کرد. Android href اکنون `intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=mobi.mmdt.ottplus;end` است؛ request در همان click synchronously کپی می‌شود. browser fallback داخل Intent نیست؛ لینک رسمی وب دکمه مستقل است. نتیجه مورد انتظار: خود اپ در home/last screen باز شود و کاربر گفت‌وگوی بات را باز و Paste کند.
- عمداً custom scheme/component داخلی حدس زده نشد. این روش direct bot-chat را تضمین نمی‌کند؛ فقط direct app launch را هدف می‌گیرد و باید روی دستگاه واقعی کاربر سنجیده شود. اگر launcher نیز توسط Chrome/ROM رد شود، fallback مورد قبول کاربر flow دستی bot-start → بازگشت سایت/copy → بازگشت bot است.
- QA: Soroush 12/12، HTTP 20/20، Bale 26/26، Bale HTTP 18/18، performance 12/12، logo PASS، Chromium Android MAIN/LAUNCHER exact href + separate web fallback PASS.
- ZIP `/home/user/repo369/v178/dastgir-v195.zip`: 460 files، 5,248,364 bytes، SHA-256 `d806020179c14b3edf267dd3985dd6f293a35f523e3f6d1de48458a96fa056a4`، MD5 `6543beda664f3c56fd93dfb8dfc680f5`; URL `https://x0.at/JWqy.zip` redownloaded over HTTP/1.1 byte-identical and passed unzip integrity. First HTTP/2 redownload hit curl (92), retry via HTTP/1.1 succeeded.

## ۲۱) v196 — جریان دستی Soroush + تب جدید مرورگر (۲۰۲۶-۰۹-۰۷)
- کاربر پس از محدودیت deep-link سروش، flow دستی را انتخاب کرد: Start بات → پیام راهنما → بازگشت سایت/copy key → بازگشت بات/Paste. سپس خواست صفحه رسمی سروش در tab جدید browser باز شود تا صفحه دست گیر در tab اصلی زنده بماند و Back/close سریع برگرداند.
- `soroush.send_start_instructions` برای هر private `/start` بدون payload راهنمای دقیق سه مرحله‌ای می‌فرستد. payload معتبر، contact ownership، separate confirmation و browser auto-login سابق بدون تغییر است.
- wait page نام بات و copy-name دارد؛ لینک رسمی با `target="_blank" rel="noopener noreferrer"` باز می‌شود؛ copy-key دکمه اصلی مستقل است؛ intent/direct package code کاملاً حذف شد؛ status polling در tab اصلی ادامه دارد.
- QA: Soroush 12/12، HTTP 21/21، Bale 26/26، Bale HTTP 18/18، performance 12/12، logo PASS، Chromium Android new-tab attributes/original URL/status element/manual copy/no-intent PASS.
- ZIP `/home/user/repo369/v178/dastgir-v196.zip`: 461 files، 5,250,546 bytes، SHA-256 `b382747593af3e9a271a1b0eeb2b598db90b6e86e42196e52c153b1f279bee91`، MD5 `a346c2243e152b1f2a32aa5eced0e6d2`; URL `https://x0.at/YejY.zip` redownload byte-identical and unzip-valid.

## ۲۲) v197 — resolver مستقیم واقعی Soroush (۲۰۲۶-۰۹-۰۷)
- کاربر URI عملی `soroush://resolve?domain=daastgirbot` را ارائه کرد و گفت مستقیماً اپ/بات را باز می‌کند؛ بنابراین محدودیت «scheme حدس زده نشود» برطرف شد چون syntax دقیق از کاربر/سرویس واقعی آمد.
- `soroush.app_link()` domain را از username configured/cached با allowlist `[A-Za-z0-9_]{3,64}` می‌سازد و encode می‌کند. request token/secret داخل URI نیست.
- دکمه اصلی wait page در همان click synchronously کلید را copy و بدون target/new-tab به resolver می‌رود. مرورگر wait page/history و polling باقی است. copy-only و HTTPS web fallback جدا هستند. /start message هم direct-arrival (already copied) و manual-start را پوشش می‌دهد.
- QA: Soroush 13/13، HTTP 21/21، Bale 26/26، Bale HTTP 18/18، performance 12/12، logo PASS، Chromium Android exact resolver/no-target/no-token-in-href/copy/polling PASS. باز شدن handler واقعی app مبتنی بر URI ارائه‌شده کاربر است و پس از production deploy روی device تأیید می‌شود.
- ZIP `/home/user/repo369/v178/dastgir-v197.zip`: 462 files، 5,252,261 bytes، SHA-256 `f47f72edd6da17e3adcb7e889e243068350bf55d9028fabdffd00cf93fd889cb`، MD5 `96e183ddeb5eb765636893d5543487fc`; URL `https://x0.at/3l6G.zip` redownload byte-identical and unzip-valid.

## ۲۳) v198 — بخش ۱ قابلیت‌های بات: منوی مشترک امن (۲۰۲۶-۰۹-۰۷)
- درخواست کاربر: افزودن تدریجی قابلیت‌های سایت به هر دو بات؛ بخش نخست زیرساخت مشترک، منو، account summary و help.
- `server/bot_menu.py`: router مشترک `/start|/menu|/account|/help` و callbackهای `dg198:*`. linked/unlinked menu متفاوت؛ Soroush unlinked راهنمای resolver/copy را حفظ می‌کند.
- account lookup فقط با platform + platform_user_id فعال؛ blocked بدون افشا؛ تلفن mask؛ owner role فقط count via `owner_business_count` و هنوز action مدیریتی ندارد. private chat برای Bale هم صریح شد (Soroush از قبل داشت). menu rate=24/min per platform user؛ webhook dedup قبلی برقرار.
- HTTP واقعی fake APIs: منو/callback هر دو transport، masked phone، group silence، auth/signup/link regressions. QA: shared menu 11/11، Soroush 13/13، Soroush HTTP 24/24، Bale 26/26، Bale HTTP 21/21، performance 12/12، logo/browser/compile/shell/policy PASS.
- ZIP `/home/user/repo369/v178/dastgir-v198.zip`: 466 files، 5,259,596 bytes، SHA-256 `8684cbc30212e89d7aa9f980911155bc25caa89b2202637b6bc04c80e34537c1`، MD5 `b32ac76e6d28569c8d20ac606367c85a`; URL `https://x0.at/8l7a.zip` redownload byte-identical and unzip-valid.
- برنامه: بخش ۱ ✅؛ بخش ۲ سفارش‌های مشتری ⏳؛ سپس نوبت، اعلان/stock، favorites/search، messages، owner controls، final comprehensive review.

## ۲۴) v199 — بخش ۲ قابلیت‌های بات: سفارش‌های مشتری (۲۰۲۶-۰۹-۰۷)
- `/orders` و button منو برای هر دو بات: latest 5 summaries، status label، conditional price، callback detail و site links.
- data layer bounded: `customer_order_summaries` بدون N+1؛ `customer_order_detail` با شرط atomic `o.id=? AND o.customer_id=?` و items max 30. Bot renders max 20؛ address/phone/note excluded. Forged foreign order callback returns generic no-data message.
- stable callback namespace `dg198:` عمداً حفظ شد تا keyboards نسخه قبل نشکنند؛ new actions `orders`, `order:<id>` زیر 64 bytes.
- QA: shared bot/orders 16/16، Soroush 13/13، Soroush HTTP 26/26، Bale 26/26، Bale HTTP 23/23، performance 12/12، logo/browser/compile/shell/policy PASS.
- ZIP `/home/user/repo369/v178/dastgir-v199.zip`: 468 files، 5,264,403 bytes، SHA-256 `72a4eea9d0cbd0fac3ed5703ee31d8f0bf11d495e994f76a4c8d598aba887f8a`، MD5 `821e60abfde5462579d85cf709e879fd`; URL `https://x0.at/UHcm.zip` redownload byte-identical and unzip-valid.
- برنامه: بخش ۱ ✅، بخش ۲ ✅، بخش ۳ نوبت‌ها ⏳.

## ۲۵) v200 — بخش ۳ قابلیت‌های بات: نوبت‌های مشتری (۲۰۲۶-۰۹-۰۷)
- `/bookings`, menu button, latest 5 summaries, safe detail, business link، two-click cancel for Bale/Soroush.
- Schema adds nullable `bookings.customer_id`; `_reconcile_schema` migrates old DB and index `idx_book_customer`. No historical/guest phone backfill due ownership/privacy risk. New public booking binds customer_id only when valid customer session phone exactly matches submitted normalized phone.
- Detail lookup id+customer; excludes name/phone/note. Cancel confirmation then `BEGIN IMMEDIATE`, owned active status condition; forged foreign ID unchanged. Owner notified on cancel.
- Linked booking creation sends dated reminder notification; owner status change sends customer notification with date/time and fans out under existing preferences/transports.
- QA: shared menu/bookings/migration 26/26، Soroush 13/13، Soroush HTTP 30/30، Bale 26/26، Bale HTTP 27/27، performance 12/12، fresh schema/index, logo/browser/compile/shell/policy PASS.
- ZIP `/home/user/repo369/v178/dastgir-v200.zip`: 470 files، 5,270,104 bytes، SHA-256 `0956ccb42e2c56d1244fa7e6cb3a26df34ef8025345cc106f3983a932b3b9504`، MD5 `afc9b4ac53ed99cfe2c2d9d8bf16f0d3`; URL `https://x0.at/JaVt.zip` redownload byte-identical and unzip-valid.
- برنامه: بخش ۱ ✅، بخش ۲ ✅، بخش ۳ ✅، بخش ۴ اعلان‌ها/پیگیری موجودی ⏳.

## ۲۶) v201 — بخش ۴ قابلیت‌های بات: اعلان‌ها و پیگیری موجودی (۲۰۲۶-۰۹-۰۷)
- `/notifications`: all customer notifmeta kinds, applied defaults, immediate toggle persisted in shared notif_prefs. Added booking kind to CUST_KINDS/meta so v200 booking notices can be controlled.
- `/stock`: latest 10 customer-scoped requests, item/business/qty/status, private note excluded, site links. Two-click cancel; atomic id+customer+open update; forged foreign callbacks safe.
- Root fix: messenger fanout separated from optional FCM in `_maybe_messenger`; push=False now truly means no web push, not no bot. Thus stock fulfill/broadcast low-value event reaches both linked bots while respecting broadcast pref.
- Added idx_stockreq_customer. Stable dg198 callback namespace retained.
- QA: shared menu/notif/stock 34/34، Soroush 13/13، Soroush HTTP 35/35، Bale 26/26، Bale HTTP 32/32، performance 12/12، fresh meta/index, logo/browser/compile/shell/policy PASS.
- ZIP `/home/user/repo369/v178/dastgir-v201.zip`: 472 files، 5,275,760 bytes، SHA-256 `aad8363239213aee2a044b19b4504176117f229d77646700e7de6759c92fc99b`، MD5 `6b9dd2d254ffaee5e914ade7a38bdf14`; URL `https://x0.at/DyOs.zip` redownload byte-identical and unzip-valid.
- برنامه: بخش‌های ۱ تا ۴ ✅؛ بخش ۵ علاقه‌مندی‌ها/جست‌وجو ⏳.

## ۲۷) v202 — بخش ۵ قابلیت‌های بات: جست‌وجو و علاقه‌مندی‌ها (۲۰۲۶-۰۹-۰۷)
- `/search query`: normalized Persian + FTS/fallback, query max60, max5 published business projection, no page decoration/N+1. Buttons site and Google Maps only for finite valid coords. Hidden excluded.
- Search results support idempotent favorite_add for published business. `/favorites` latest5 shared site state; site/map actions; two-click remove scoped customer+biz. Forged cross-customer removal safe.
- Menu buttons/help updated, stable dg198 namespace retained.
- QA: shared bot/search/favorites 42/42، Soroush 13/13، Soroush HTTP 40/40، Bale 26/26، Bale HTTP 37/37، performance 12/12، logo/browser/compile/shell/policy PASS.
- ZIP `/home/user/repo369/v178/dastgir-v202.zip`: 474 files، 5,281,053 bytes، SHA-256 `11094a9461d63713e8e06d16b16d17ca2ae62d404636fb6f565e68c6e01376df`، MD5 `db2132db9e99c35307650a9046e202a8`; URL `https://x0.at/wMFI.zip` redownload byte-identical and unzip-valid.
- برنامه: بخش‌های ۱ تا ۵ ✅؛ بخش ۶ پیام‌ها ⏳.

## ۲۸) v203 — بخش ۶ قابلیت‌های بات: پیام‌ها و پاسخ کوتاه (۲۰۲۶-۰۹-۰۷)
- `/messages`: latest5 customer-bound threads with unread/last preview; detail latest6. Customer phone/private stored filename excluded. Attachment indicated by display name; complex/file work handed to authenticated `/me/chat/<id>`.
- Three static short replies. Prepare creates random 5-minute customer+thread confirmation; confirm atomically consumes one-use token, rechecks open ownership, inserts message, advances customer read pointer, and notifies owner. Reuse/cross-user/closed thread fail safely.
- Existing owner/admin site response path uses shared `kind=chat` customer notification and now verified fanout to both linked bots respecting prefs.
- New ephemeral `bot_confirmations` table/index; excluded from backups by existing allow-list behavior.
- QA: shared menu/messages 50/50، Soroush 13/13، Soroush HTTP 44/44، Bale 26/26، Bale HTTP 41/41، performance 12/12، fresh confirmation schema/index, logo/browser/compile/shell/policy PASS.
- ZIP `/home/user/repo369/v178/dastgir-v203.zip`: 476 files، 5,287,208 bytes، SHA-256 `20b002058a8f606a82a24011da47bd4949c2a97c73507b9ba9f70a67a7b4897a`، MD5 `c744f63365ce3166ef845f68e40a1f12`; URL `https://x0.at/MTfN.zip` redownload byte-identical and unzip-valid.
- برنامه: بخش‌های ۱ تا ۶ ✅؛ بخش ۷ پنل مالک ⏳.

## ۲۹) v204 — بخش ۷ قابلیت‌های بات: پنل مالک (۲۰۲۶-۰۹-۰۷)
- `/owner`: linked messenger→customer→phone-matched active owner with business only. On-demand dashboard counts businesses, new orders, today appointments (Gregorian/Jalali), unread chats, open stock.
- Owner order list/detail safe projection; transitions only new→confirmed→ready→done. Today booking actions new→confirmed→done and recheck booking entitlement. Customer notifications follow shared prefs.
- Owner customer-message list/detail, no customer phone/private attachment path; file/reply handoff to authenticated site.
- Owner stock list excludes customer phone/note; confirmed atomic fulfill notifies exactly bound customer.
- Controlled preset broadcast only; rechecks ownership/entitlement and 3/hour rate, custom text stays on site.
- All owner mutations use random 5-minute owner-bound one-use confirmation; consume+ownership+transition/update atomic. Replay fails.
- Added owner summary notification kind and idempotent 09:00 Asia/Tehran systemd timer (`tools/install-owner-summary.sh`); per owner/day dedup and prefs respected.
- QA: shared bot/owner 66/66، Soroush 13/13، Soroush HTTP 48/48، Bale 26/26، Bale HTTP 45/45، performance 12/12، fresh owner schema/index, metadata, logo/browser/compile/shell/policy PASS.
- ZIP `/home/user/repo369/v178/dastgir-v204.zip`: 480 files، 5,297,755 bytes، SHA-256 `ad7b59f3c1039b92c2a52fab8ed16bfbe0ac20c945e7aac61c3f8081bec0d39e`، MD5 `9cde45ff326bdd769e5d95faeedab3de`; URL `https://x0.at/vg3d.zip` redownload byte-identical and unzip-valid.
- برنامه: بخش‌های ۱ تا ۷ ✅؛ بخش ۸ بازبینی جامع نهایی ⏳.

## ۳۰) v205 — بخش ۸ بازبینی جامع و انتشار نهایی بات‌ها (۲۰۲۶-۰۹-۰۷)
- Final independent security suite covers customer/owner order, booking, chat, stock boundaries; notification prefs; private chat; constant-time webhook secrets; body/rate bounds; platform-scoped update replay; Rubika inactivity; daily dedup.
- Customer and owner confirmation bearer values are now hash-only at rest (SHA-256). Raw random 5-minute token exists only in callback; consume/role/ownership/state/mutation remain atomic and one-use.
- Owner confirmation prepare now rejects skipped order/booking transitions and rechecks entitlement before showing confirmation.
- Replaced overlay updater with backup + validated staging + clean rsync --delete while preserving data/uploads/chat-files.
- Added final Termius all-in-one deployment guide and corrected obsolete Bale rollback text: SMS/password fallback remains disabled.
- QA: security 25/25، shared menu/features 66/66، Soroush 13/13، Soroush HTTP 48/48، Bale 26/26، Bale HTTP 45/45، performance 12/12; compile/shell/fresh schema/index/notifmeta/backup exclusions/browser/logo/credential/deploy policy PASS.
- ZIP `/home/user/repo369/v178/dastgir-v205.zip`: 484 files، 5,306,546 bytes، SHA-256 `624c864ea4ea7f3308148107332a16d6b7c980178d91c1ad3129ae2570c709a9`، MD5 `e9eb60654a7e15589622d8d31d6b6b7b`; URL `https://x0.at/pNMN.zip` redownload byte-identical and unzip-valid.
- برنامهٔ هشت‌بخشی قابلیت‌های بله/سروش کامل شد ✅. Production deployment is not claimed until user runs final Termius guide and validates live health/webhooks.

## ۳۱) v206 — همگام‌سازی دانش/قوانین و handoff برای چت جدید (۲۰۲۶-۰۹-۰۷)
- User requested complete GitHub-facing knowledge/rules/handoff before staged business registration work.
- Workspace audit found no `.git` directory and no remote, so no GitHub push is claimed. Local project/docs are prepared for a future authenticated push.
- Added canonical project `HANDOFF.md`: source of truth, v205/v206 state, bot capabilities, security/deploy invariants, exact v205 evidence, live uncertainty, and next task.
- Added root `CURRENT-STATE.md`; prepended current-reference notices to historical `HANDOFF (5).md` and `GITHUB-STUDY-v178.md`; updated RULES with no-false-push rule, exposed-panel-key rotation pending, and bot business-registration constraints.
- Updated project README/ROADMAP/WHATS-NEW and copied collaboration `RULES.md`, `KNOWLEDGE.md`, `CURRENT-STATE.md` under project `docs/collaboration/` so a GitHub clone/new chat includes them.
- Next task remains unimplemented: staged business registration in both bots. Open decisions: image flow (recommended hybrid) and mandatory pending moderation (recommended yes).
- v206 is documentation/handoff synchronization; v205 bot logic is unchanged. Full suites rerun: security 25/25، menu/features 66/66، Soroush 13/13 + HTTP 48/48، Bale 26/26 + HTTP 45/45، performance 12/12، browser/logo/compile/shell/docs/credential checks PASS.
- v206 final full archive after embedding collaboration docs: 489 files، 5,345,615 bytes، SHA-256 `9812482352b166927369da5ee04dc30b5f99c97bc56d0fbcde6d9e75c29539fc`، MD5 `2a020937c666818517eab1162bfc487b`; URL `https://x0.at/7I2w.zip`; remote redownload byte-identical and unzip-valid. Supersedes preliminary v206 upload.


## ۳۲) بررسی واقعی GitHub و بستهٔ نهایی اسناد (۲۰۲۶-۰۹-۰۷)
- مخزن `https://github.com/rezadb369-wq/369` clone شد؛ شاخهٔ اصلی `main` و SHA آنلاین `781f18ffc29a6952aeace9029f39bb026b7341ae` بود.
- شش فایل Markdown به‌روز شدند: `README.md`، `CURRENT-STATE.md`، `HANDOFF.md`، `HANDOFF (5).md`، `KNOWLEDGE.md` و `RULES (2).md`.
- commit محلی `ac278d90b5a40f720b8a2a480b38c7cb059ebd77` ساخته شد. push HTTPS با خطای نبود Username/credential و SSH با نبود کلید مجاز شکست خورد؛ بنابراین remote به‌روز نشده و نباید خلاف آن ادعا شود.
- بررسی دوم remote نشان داد `CURRENT-STATE.md` روی raw URL برابر 404 و `KNOWLEDGE.md` آنلاین هنوز نشانگر v177 داشت؛ این مدرک قطعی عدم آپلود بود.
- کاربر خواست همهٔ MDها دوباره با تمام دانش لازم همین چت بازبینی و فقط در یک ZIP تحویل شوند. بستهٔ MD مستقل حاوی هیچ کد، DB، ZIP محصول یا secret نیست.
- وضعیت زنده تغییر نکرده: اجرای rotation کلید پنل و مشاهدهٔ صریح `VERSION=205`/health هنوز تأیید نشده است.
- کار بعدی همچنان ثبت مرحله‌به‌مرحلهٔ کسب‌وکار در هر دو بات است و هنوز پیاده‌سازی نشده؛ تصویر ترکیبی و moderation اجباری پیشنهادهای باز هستند.
