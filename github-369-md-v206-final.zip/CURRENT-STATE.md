# وضعیت جاری پروژهٔ «دست گیر»

آخرین بررسی: ۲۰۲۶-۰۹-۰۷ (Asia/Tehran)

## ترتیب مطالعه برای چت جدید

1. `CURRENT-STATE.md` (همین فایل)
2. `RULES (2).md`
3. `KNOWLEDGE.md`
4. `HANDOFF.md`
5. `HANDOFF (5).md` فقط برای تاریخچهٔ قدیمی

## منبع حقیقت و نسخه‌ها

- کد فعال workspace: `/home/user/repo369/v178/extracted/dastgir/`
- handoff مرجع کد: `/home/user/repo369/v178/extracted/dastgir/HANDOFF.md`
- منطق محصول کامل و آزموده: **v205**
- بستهٔ همگام‌سازی مستندات و handoff: **v206** (بدون تغییر عملکردی در منطق v205)
- آرشیو جاری محصول/اسناد: `dastgir-v206.zip`
- URL: `https://x0.at/7I2w.zip` (ممکن است موقت باشد؛ hash معیار اعتماد است)
- SHA-256: `9812482352b166927369da5ee04dc30b5f99c97bc56d0fbcde6d9e75c29539fc`
- MD5: `2a020937c666818517eab1162bfc487b`
- اندازه/تعداد: 5,345,615 بایت / 489 فایل
- آرشیو قبلی v205: 5,306,546 بایت / 484 فایل؛ SHA-256 `624c864ea4ea7f3308148107332a16d6b7c980178d91c1ad3129ae2570c709a9`.

## وضعیت واقعی GitHub

- مخزن: `https://github.com/rezadb369-wq/369`
- شاخهٔ اصلی: `main`
- SHA آنلاین در آخرین بررسی: `781f18ffc29a6952aeace9029f39bb026b7341ae`
- فایل‌های آنلاین در آن SHA فقط `HANDOFF (5).md`، `KNOWLEDGE.md`، `RULES (2).md` و `dastgir-v178 (1).zip` بودند؛ `README.md`، `CURRENT-STATE.md` و `HANDOFF.md` هنوز آنلاین نبودند.
- commit محلی مستندات ساخته شد: `ac278d90b5a40f720b8a2a480b38c7cb059ebd77` با پیام `docs: synchronize v206 knowledge rules and handoff`.
- push HTTPS به‌دلیل نبود credential و push SSH به‌دلیل نبود کلید مجاز انجام نشد. بنابراین **GitHub هنوز به‌روز نشده است** و commit محلی نباید با push موفق اشتباه شود.
- برای اثبات به‌روزرسانی بعدی باید SHA آنلاین تغییر کند، شش فایل MD در `main` دیده شوند و محتوای `CURRENT-STATE.md` نشانگر v206 را داشته باشد.

## وضعیت QA v206

- security: 25/25
- shared menu/features: 66/66
- Bale core/HTTP: 26/26 + 45/45
- Soroush core/HTTP: 13/13 + 48/48
- public performance: 12/12
- browser، logo، compile، shell، schema/policy، credential scan، clean extraction و remote redownload: PASS

## وضعیت زنده

کاربر تصویر پایان فرمان‌های Termius و prompt فعال را فرستاد، اما همان تصویر خروجی کامل `VERSION=205` و هر دو health check را به‌طور قابل مشاهده اثبات نکرد. تصویر admin panel key را آشکار کرد؛ rotation بدون چاپ پیشنهاد شد، ولی اجرای rotation هنوز تأیید نشده است. مقدار کلید افشاشده هرگز نباید بازنویسی یا تکرار شود.

## کار بعدی — هنوز پیاده‌سازی نشده

ثبت مرحله‌به‌مرحلهٔ کسب‌وکار در هر دو بات بله و سروش: draft پایدار/قابل ادامه و منقضی‌شونده، جست‌وجوی دسته، نام/شهر/محله/آدرس/شرح، تلفن تأییدشده با انتخاب نمایش عمومی، ساعات کاری، تصویر، preview، تأیید دوم hash-only و ثبت نهایی owner-bound با `status=pending` برای بررسی مدیر.

تصمیم‌های باز: مسیر تصویر (پیشنهاد: ترکیبی بات + سایت) و اجباری‌بودن moderation (پیشنهاد: بله).
