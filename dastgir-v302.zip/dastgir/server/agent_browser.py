# -*- coding: utf-8 -*-
"""
v302 external web browser + arena.ai bridge + file exchange
Standard library only.
"""

import os
import re
import json
import time
import html
import urllib.parse
import urllib.request
import urllib.error
import hashlib
import pathlib
import mimetypes

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "..", "data")
ARENA_DIR = os.path.join(DATA_DIR, "arena-bridge")
os.makedirs(ARENA_DIR, exist_ok=True)

DEFAULT_ARENA_URL = "https://arena.ai/agent/01a0acde-4c14-7c72-9934-1df78579ea49"
ALLOWED_HOSTS = {
    "arena.ai",
    "www.arena.ai",
}
BLOCKED_SUBSTR = ("127.0.0.1", "localhost", "0.0.0.0", "::1", "10.", "192.168.", "172.")

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

def _is_allowed_url(url: str):
    try:
        u = urllib.parse.urlparse(url)
        if u.scheme not in ("http", "https"):
            return False, "scheme must be http/https"
        host = (u.hostname or "").lower()
        if not host:
            return False, "no host"
        for bad in BLOCKED_SUBSTR:
            if bad in host and host not in ALLOWED_HOSTS and not host.endswith(".arena.ai"):
                return False, f"blocked host {host}"
        if host.startswith("127.") or host == "localhost":
            if host not in ALLOWED_HOSTS and not host.endswith(".arena.ai"):
                return False, "loopback blocked"
        return True, ""
    except Exception as e:
        return False, str(e)

def fetch_url(url: str, timeout=15):
    ok, why = _is_allowed_url(url)
    if not ok:
        return {"ok": False, "error": why}
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9,fa;q=0.8",
        })
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            ctype = resp.headers.get("Content-Type", "")
            body = resp.read(2_000_000)
            charset = "utf-8"
            if "charset=" in ctype:
                charset = ctype.split("charset=")[-1].split(";")[0].strip()
            try:
                text = body.decode(charset, errors="ignore")
            except Exception:
                text = body.decode("utf-8", errors="ignore")
            m = re.search(r"<title[^>]*>(.*?)</title>", text, re.I | re.S)
            title = html.unescape(m.group(1).strip()) if m else url
            title = re.sub(r"\s+", " ", title)[:300]
            txt = re.sub(r"<script.*?</script>", " ", text, flags=re.I | re.S)
            txt = re.sub(r"<style.*?</style>", " ", txt, flags=re.I | re.S)
            txt = re.sub(r"<[^>]+>", " ", txt)
            txt = html.unescape(txt)
            txt = re.sub(r"\s+", " ", txt).strip()[:8000]
            return {"ok": True, "url": url, "status": resp.status,
                    "content_type": ctype, "title": title, "text": txt,
                    "raw_len": len(body), "html": text[:200000]}
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": f"HTTP {e.code}", "code": e.code}
    except Exception as e:
        return {"ok": False, "error": str(e)[:300]}

def proxy_page(url: str):
    res = fetch_url(url)
    if not res.get("ok"):
        safe_err = html.escape(res.get("error","unknown"))
        return f"<html><body style='font-family:sans-serif;padding:20px'><h2>خطا در بارگذاری</h2><p>{safe_err}</p><p><a href='/agent/browser'>بازگشت</a></p></body></html>"
    raw = res.get("html","")
    parsed = urllib.parse.urlparse(url)
    base_href = f"{parsed.scheme}://{parsed.netloc}/"
    if "<head" in raw.lower():
        raw = re.sub(r"<head[^>]*>", lambda m: m.group(0) + f'<base href="{html.escape(base_href)}">', raw, count=1, flags=re.I)
    else:
        raw = f'<base href="{html.escape(base_href)}">' + raw
    banner = (
        '<div style="position:fixed;top:0;left:0;right:0;z-index:999999;background:#111;color:#fff;padding:8px 12px;font-family:sans-serif;font-size:13px;display:flex;gap:10px;align-items:center">'
        f'  <span>🔗 {html.escape(url[:120])}</span>'
        f'  <a href="/agent/browser?url={urllib.parse.quote(url)}" style="color:#8cf">بازگشت به پنل</a>'
        '  <span style="margin-left:auto;opacity:.7">proxy via bazarche</span>'
        '</div><div style="height:36px"></div>'
    )
    if "<body" in raw.lower():
        raw = re.sub(r"<body[^>]*>", lambda m: m.group(0) + banner, raw, count=1, flags=re.I)
    else:
        raw = banner + raw
    return raw

def _bridge_path(name="latest.json"):
    return os.path.join(ARENA_DIR, name)

def bridge_load():
    try:
        p = _bridge_path()
        if os.path.exists(p):
            return json.loads(open(p, encoding="utf-8").read()[:200000] or "{}")
    except Exception:
        pass
    return {"url": DEFAULT_ARENA_URL, "messages": [], "files": [], "updated": 0}

def bridge_save(data):
    try:
        data["updated"] = time.time()
        open(_bridge_path(), "w", encoding="utf-8").write(json.dumps(data, ensure_ascii=False, indent=2)[:500000])
        hist = _bridge_path(f"history-{int(time.time())}.json")
        open(hist, "w", encoding="utf-8").write(json.dumps(data, ensure_ascii=False)[:500000])
        return True
    except Exception:
        return False

def bridge_append_message(role, text, files=None):
    d = bridge_load()
    d.setdefault("messages", []).append({
        "ts": time.time(),
        "role": role,
        "text": text[:8000],
        "files": files or []
    })
    if len(d["messages"]) > 200:
        d["messages"] = d["messages"][-200:]
    bridge_save(d)
    return d

EXCHANGE_DIR = os.path.join(DATA_DIR, "agent-exchange")
os.makedirs(EXCHANGE_DIR, exist_ok=True)

def exchange_list():
    out = []
    try:
        for fn in os.listdir(EXCHANGE_DIR):
            fp = os.path.join(EXCHANGE_DIR, fn)
            if not os.path.isfile(fp):
                continue
            st = os.stat(fp)
            out.append({"name": fn, "size": st.st_size, "mtime": st.st_mtime})
    except Exception:
        pass
    out.sort(key=lambda x: x["mtime"], reverse=True)
    return out[:100]

def exchange_save_file(data: bytes, filename: str):
    filename = re.sub(r"[^A-Za-z0-9._-]", "_", filename)[:120]
    if not filename:
        filename = f"file-{int(time.time())}.bin"
    fp = os.path.join(EXCHANGE_DIR, filename)
    base, ext = os.path.splitext(filename)
    i = 1
    while os.path.exists(fp):
        fp = os.path.join(EXCHANGE_DIR, f"{base}_{i}{ext}")
        i += 1
        if i > 20:
            break
    open(fp, "wb").write(data[:20_000_000])
    bridge_append_message("system", f"file uploaded: {os.path.basename(fp)} ({len(data)} bytes)", files=[os.path.basename(fp)])
    return {"ok": True, "name": os.path.basename(fp), "size": len(data), "path": f"/agent/file/{urllib.parse.quote(os.path.basename(fp))}"}

def browser_html(s, q):
    url = ""
    if isinstance(q, dict):
        v = q.get("url")
        if isinstance(v, list) and v:
            url = v[0]
        elif isinstance(v, str):
            url = v
    if not url:
        url = DEFAULT_ARENA_URL
    bridge = bridge_load()
    msgs = bridge.get("messages", [])[-30:]
    files = exchange_list()

    msgs_html = ""
    for m in msgs:
        role = m.get("role","")
        txt = html.escape(m.get("text","")[:1000])
        ts = time.strftime("%H:%M", time.localtime(m.get("ts",0)))
        cls = "user" if role=="user" else "arena" if role=="arena" else "sys"
        msgs_html += '<div class="msg '+cls+'"><span class="ts">'+ts+'</span> <b>'+html.escape(role)+'</b>: '+txt+'</div>\n'
    if not msgs_html:
        msgs_html = '<div class="muted">هنوز پیامی با آرنا ثبت نشده.</div>'

    files_html = ""
    for f in files:
        nm = html.escape(f["name"])
        sz = f["size"]
        qn = urllib.parse.quote(f["name"])
        files_html += '<div class="file"><a href="/agent/file/'+qn+'" target="_blank">'+nm+'</a> <small>'+str(sz)+'b</small></div>\n'
    if not files_html:
        files_html = '<div class="muted">فایلی نیست.</div>'

    esc_url = html.escape(url)
    proxy_src = "/agent/proxy?url="+urllib.parse.quote(url)
    def_arena_short = html.escape(DEFAULT_ARENA_URL[:60])

    # Build page without f-string for JS part to avoid brace issues
    page = (
        '<!doctype html>\n<html lang="fa" dir="rtl">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width,initial-scale=1">\n'
        '<title>مرورگر ایجنت - '+esc_url[:40]+'</title>\n'
        '<style>\n'
        'body{margin:0;font-family:Tahoma,sans-serif;background:#0f0f0f;color:#eee}\n'
        '.bar{display:flex;gap:8px;padding:10px;background:#1a1a1a;border-bottom:1px solid #333;flex-wrap:wrap;align-items:center}\n'
        '.bar input{flex:1;min-width:240px;padding:8px 10px;border-radius:8px;border:1px solid #444;background:#222;color:#fff;direction:ltr}\n'
        '.btn{padding:8px 12px;border-radius:8px;border:0;background:#4f46e5;color:#fff;cursor:pointer}\n'
        '.btn.ghost{background:#333}\n'
        '.layout{display:grid;grid-template-columns:1fr 360px;gap:0;height:calc(100vh - 52px)}\n'
        '@media(max-width:900px){.layout{grid-template-columns:1fr}}\n'
        '.iframe-wrap{position:relative;background:#fff}\n'
        '.iframe-wrap iframe{width:100%;height:100%;border:0;background:#fff}\n'
        '.side{background:#151515;border-left:1px solid #2a2a2a;display:flex;flex-direction:column;overflow:hidden}\n'
        '.side h3{margin:12px 12px 6px;font-size:14px}\n'
        '.msgs{flex:1;overflow:auto;padding:8px 12px;display:flex;flex-direction:column;gap:6px}\n'
        '.msg{padding:6px 8px;border-radius:8px;background:#222;font-size:13px;line-height:1.6}\n'
        '.msg.user{background:#1e293b}\n'
        '.msg.arena{background:#1a2e1a}\n'
        '.msg.sys{background:#2a2a1a;opacity:.8}\n'
        '.ts{opacity:.6;font-size:11px}\n'
        '.muted{opacity:.6;font-size:12px}\n'
        '.chat-box{padding:10px;border-top:1px solid #333;display:flex;gap:6px}\n'
        '.chat-box textarea{flex:1;padding:8px;border-radius:8px;border:1px solid #444;background:#222;color:#fff;min-height:44px;resize:vertical}\n'
        '.files{padding:8px 12px;max-height:180px;overflow:auto;border-top:1px solid #2a2a2a}\n'
        '.file{font-size:12px;padding:2px 0}\n'
        '.drop{border:2px dashed #444;border-radius:10px;padding:10px;margin:8px 12px;text-align:center;cursor:pointer}\n'
        '.drop.dragover{border-color:#4f46e5;background:#1e1e3a}\n'
        '</style>\n</head>\n<body>\n'
        '<div class="bar">\n'
        '  <span>🌐</span>\n'
        '  <input id="urlInput" value="'+esc_url+'" placeholder="https://...">\n'
        '  <button class="btn" onclick="go()">برو</button>\n'
        '  <button class="btn ghost" onclick="openProxy()">تب جدید</button>\n'
        '  <a class="btn ghost" href="/agent" style="text-decoration:none">/agent اصلی</a>\n'
        '  <span style="margin-left:auto;font-size:12px;opacity:.7">ابزار مرور وب خارجی فعال ✅</span>\n'
        '</div>\n'
        '<div class="layout">\n'
        '  <div class="iframe-wrap">\n'
        '    <iframe id="arenaFrame" src="'+proxy_src+'"></iframe>\n'
        '  </div>\n'
        '  <div class="side">\n'
        '    <h3>💬 پل به آرنا — '+def_arena_short+'</h3>\n'
        '    <div class="msgs" id="msgs">'+msgs_html+'</div>\n'
        '    <div class="chat-box">\n'
        '      <textarea id="chatText" placeholder="پیام به ایجنت خارجی arena.ai ..."></textarea>\n'
        '      <button class="btn" onclick="sendArena()">ارسال</button>\n'
        '    </div>\n'
        '    <div class="drop" id="dropZone">📁 فایل را اینجا رها کن یا کلیک کن<br><small>تبادل با ایجنت خارجی</small><input type="file" id="fileInput" hidden multiple></div>\n'
        '    <div class="files"><b>فایل‌های تبادل:</b><br>'+files_html+'</div>\n'
        '    <div style="padding:8px 12px"><button class="btn ghost" onclick="loadBridge()">🔄 تازه‌سازی</button> <button class="btn ghost" onclick="clearBridge()">پاک کردن</button></div>\n'
        '  </div>\n'
        '</div>\n'
        '<script>\n'
        'function go(){\n'
        '  var u=document.getElementById("urlInput").value.trim();\n'
        '  if(!u) return;\n'
        '  if(!u.startsWith("http")) u="https://"+u;\n'
        '  document.getElementById("arenaFrame").src="/agent/proxy?url="+encodeURIComponent(u);\n'
        '  history.replaceState(null,"","/agent/browser?url="+encodeURIComponent(u));\n'
        '}\n'
        'function openProxy(){\n'
        '  var u=document.getElementById("urlInput").value.trim();\n'
        '  if(!u.startsWith("http")) u="https://"+u;\n'
        '  window.open("/agent/proxy?url="+encodeURIComponent(u),"_blank");\n'
        '}\n'
        'document.getElementById("urlInput").addEventListener("keydown",function(e){if(e.key==="Enter") go();});\n'
        'async function sendArena(){\n'
        '  var t=document.getElementById("chatText").value.trim();\n'
        '  if(!t) return;\n'
        '  document.getElementById("chatText").value="";\n'
        '  var msgs=document.getElementById("msgs");\n'
        '  var d=document.createElement("div"); d.className="msg user"; d.innerHTML="<b>you</b>: "+t.replace(/</g,"&lt;"); msgs.appendChild(d); msgs.scrollTop=msgs.scrollHeight;\n'
        '  try{\n'
        '    var r=await fetch("/api/agent/arena",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:t,url:document.getElementById("urlInput").value})});\n'
        '    var j=await r.json();\n'
        '    var d2=document.createElement("div"); d2.className="msg arena"; d2.innerHTML="<b>arena</b>: "+(j.reply||j.text||JSON.stringify(j)).replace(/</g,"&lt;").substring(0,4000); msgs.appendChild(d2); msgs.scrollTop=msgs.scrollHeight;\n'
        '  }catch(e){\n'
        '    var d3=document.createElement("div"); d3.className="msg sys"; d3.textContent="خطا: "+e; msgs.appendChild(d3);\n'
        '  }\n'
        '}\n'
        'async function loadBridge(){\n'
        '  try{\n'
        '    var r=await fetch("/api/agent/arena?latest=1"); var j=await r.json();\n'
        '    var msgs=document.getElementById("msgs"); msgs.innerHTML="";\n'
        '    (j.messages||[]).slice(-30).forEach(function(m){\n'
        '      var div=document.createElement("div"); div.className="msg "+(m.role=="user"?"user":m.role=="arena"?"arena":"sys");\n'
        '      div.innerHTML="<span class=ts>"+new Date(m.ts*1000).toLocaleTimeString()+"</span> <b>"+m.role+"</b>: "+(m.text||"").replace(/</g,"&lt;");\n'
        '      msgs.appendChild(div);\n'
        '    });\n'
        '    msgs.scrollTop=msgs.scrollHeight;\n'
        '  }catch(e){}\n'
        '}\n'
        'async function clearBridge(){\n'
        '  if(!confirm("لاگ پل آرنا پاک شود؟")) return;\n'
        '  await fetch("/api/agent/arena",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:"__clear__"})});\n'
        '  loadBridge();\n'
        '}\n'
        'var dz=document.getElementById("dropZone");\n'
        'var fi=document.getElementById("fileInput");\n'
        'dz.addEventListener("click",function(){fi.click();});\n'
        'dz.addEventListener("dragover",function(e){e.preventDefault();dz.classList.add("dragover");});\n'
        'dz.addEventListener("dragleave",function(){dz.classList.remove("dragover");});\n'
        'dz.addEventListener("drop",async function(e){\n'
        '  e.preventDefault();dz.classList.remove("dragover");\n'
        '  var files=e.dataTransfer.files;\n'
        '  await uploadFiles(files);\n'
        '});\n'
        'fi.addEventListener("change",async function(){await uploadFiles(fi.files);});\n'
        'async function uploadFiles(files){\n'
        '  if(!files||!files.length) return;\n'
        '  var fd=new FormData();\n'
        '  for(var i=0;i<files.length;i++) fd.append("file",files[i]);\n'
        '  try{\n'
        '    var r=await fetch("/api/agent/upload",{method:"POST",body:fd});\n'
        '    var j=await r.json();\n'
        '    alert(j.ok?"آپلود شد":"خطا: "+(j.error||""));\n'
        '    location.reload();\n'
        '  }catch(e){alert("خطا "+e);}\n'
        '}\n'
        '</script>\n</body>\n</html>\n'
    )
    return page
