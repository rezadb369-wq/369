# HANDOFF مرجع پروژهٔ «دست گیر»

آخرین به‌روزرسانی: ۲۰۲۶-۰۹-۰۷ — این فایل نقطهٔ شروع چت/عامل جدید است.

## ۱) منبع حقیقت و نسخه

- درخت فعال: همین پوشه (`dastgir/`).
- نسخهٔ فعلی درخت و بستهٔ مستنداتی: v206؛ منطق کامل بات‌ها از v205 بدون تغییر عملکردی منتقل شده است.
- آرشیو تأییدشدهٔ v205: `dastgir-v205.zip`، 484 فایل، 5,306,546 بایت.
- SHA-256 v205: `624c864ea4ea7f3308148107332a16d6b7c980178d91c1ad3129ae2570c709a9`.
- URL تحویل v205: `https://x0.at/pNMN.zip` (موقت؛ hash معیار اعتماد است).
- نام نمایشی محصول همیشه «دست گیر» با فاصله است.
- هیچ `.git` یا remote در workspace فعلی موجود نیست؛ «push به GitHub» فقط پس از clone/remote معتبر و احراز هویت واقعی قابل ادعاست.

## ۲) وضعیت قابلیت‌ها

هر دو بات بله و سروش‌پلاس از هستهٔ مشترک استفاده می‌کنند:

- ورود/ثبت‌نام بدون SMS و password با contact رسمی و تأیید جداگانه؛ مرورگر باز پس از تأیید خودکار وارد می‌شود.
- `/menu`, `/account`, `/help` با private-chat enforcement، webhook secret، replay claim و rate limit.
- `/orders`: فهرست/جزئیات مشتری، بدون phone/address/note.
- `/bookings`: نوبت‌های customer-bound، اعلان تاریخ/ساعت، لغو اتمیک پس از تأیید دوم.
- `/notifications`: تنظیم مشترک `notif_prefs` برای سایت و بات.
- `/stock`: درخواست‌های مشتری، بدون note، لغو تأییدی؛ fulfil به هر دو بات متصل.
- `/search query` و `/favorites`: نتیجهٔ published، مسیر، علاقه‌مندی مشترک و حذف تأییدی.
- `/messages`: پنج گفتگو، شش پیام اخیر، handoff فایل/پیچیدگی به سایت، پاسخ کوتاه با token یک‌بارمصرف hash-only.
- `/owner`: خلاصه روز، سفارش، نوبت امروز، پیام مشتری، موجودی و فراخوان؛ همهٔ mutationها owner-bound، یک‌بارمصرف و اتمیک.
- خلاصهٔ مالک ساعت 09:00 Asia/Tehran با systemd timer و dedup مالک/روز.
- Rubika در UI/runtime غیرفعال است اما رکوردهای قدیمی به‌صورت مخرب حذف نشده‌اند.

## ۳) امنیت تثبیت‌شده

- token واقعی بات‌ها و webhook secret فقط در `/etc/dastgir-secrets.env` با `root:root/600`؛ هرگز در چت، ZIP، history یا خروجی چاپ نشود.
- webhookهای بله/سروش URL secret را با `secrets.compare_digest` بررسی می‌کنند؛ JSON محدود، update_id عددی و replay claim پلتفرم‌محور است.
- عملیات حساب فقط در private chat؛ callbackها regex allow-list و کمتر از 64 بایت.
- authorization مشتری با `customer_id` و authorization مالک با `owner_id + business ownership` سمت سرور انجام می‌شود.
- confirmation پاسخ/مالک فقط به‌صورت SHA-256 در DB ذخیره می‌شود؛ bearer خام پنج دقیقه‌ای و یک‌بارمصرف است.
- private fields در بات ممنوع: order phone/address/note، booking phone/note، stock note/customer phone، stored attachment path/name.
- `push=False` فقط FCM را خاموش می‌کند، نه messenger fan-out.

## ۴) استقرار

- مسیر VPS ثبت‌شده: `/opt/dastgir`؛ service: `bazarche.service`؛ پورت داخلی: 8080؛ nginx روی دامنه.
- updater نهایی: `deploy/update.sh` — backup سازگار SQLite، staging، `rsync --delete` و حفظ `data/`، uploadها و chat-files.
- راهنمای همهٔ فرمان‌های Termius: `deploy/FINAL-v205-TERMIUS-fa.md`.
- گزارش امنیت: `deploy/FINAL-SECURITY-v205-fa.md`.
- کاربر تصویر `Final checks finished` و prompt فعال Termius را فرستاد؛ اما خروجی کامل version/health در تصویر نبود، پس deploy زنده را قطعی اعلام نکن.
- همان تصویر admin panel key را آشکار کرد. به کاربر دستور rotation بدون چاپ کلید داده شد؛ اجرای rotation هنوز تأیید نشده و باید در ادامه پرسیده/بررسی شود. خود کلید قدیمی را هرگز بازنویسی یا تکرار نکن.

## ۵) آخرین نتایج آزمون v205

- امنیت مستقل 25/25
- منوی مشترک و همه قابلیت‌ها 66/66
- Bale core 26/26؛ Bale HTTP 45/45
- Soroush core 13/13؛ Soroush HTTP 48/48
- public performance 12/12
- compile، shell، fresh schema/index، notifmeta، backup exclusions، browser/login، logo، credential/deploy policy: PASS

## ۶) ثبت مرحله‌به‌مرحلهٔ کسب‌وکار در بات‌ها — پیاده‌سازی‌شده در v207

وضعیت v207 (۲۰۲۶-۰۹-۰۷): پیاده‌سازی و آزموده شد. مسیر داده و تصمیم‌های قطعی:

- ماژول‌ها: `server/bot_register.py` (state machine سمت سرور، ۹ مرحله: category→name→city→area→address→descr→phone_public→hours→images→preview) و `server/bot_register_flow.py` (لایهٔ گفت‌وگو مشترک بله/سروش، callbackهای `dg198:reg_*` با allow-list regex، همگی ≤۶۴ بایت). هوک‌ها: `bot_menu.handle_message` (متن آزاد فقط وقتی پیش‌نویس فعال است)، `bot_menu.handle_callback` (پیش از allow-list قدیمی)، `bot_menu.handle_photo` (از webhook هر دو پلتفرم وقتی `message.photo` هست).
- ورودی‌ها: `/register_business`، `/register`، دکمهٔ «➕ ثبت کسب‌وکار» در منوی کاربران متصل؛ فقط چت خصوصی؛ کاربر غیرمتصل به لینک ورود سایت ارجاع می‌شود؛ `reg_open` تنظیمات مدیر رعایت می‌شود.
- پیش‌نویس: جدول جدید `biz_reg_drafts` (یک ردیف به‌ازای هر customer، TTL ۴۸ ساعت، پاک‌سازی تنبل)؛ resume/شروع‌ازنو، بازگشت مرحله‌ای، انصراف با تأیید. **در فهرست backup نیست** (مثل `bot_confirmations` موقت است).
- تلفن: همیشه از حساب تأییدشدهٔ مشتری خوانده می‌شود؛ متن تایپ‌شده در آن مرحله نادیده گرفته می‌شود. تصمیم جداگانهٔ نمایش عمومی در ستون جدید `businesses.phone_public` (پیش‌فرض ۱؛ `_reconcile_schema` روی DBهای قدیمی اضافه می‌کند؛ روی DB v206 واقعی تأیید شد). `views_public._public_phone_mask` فقط projection عمومی (صفحهٔ کسب‌وکار و payload نقشه) را خالی می‌کند.
- تصاویر (تصمیم: ترکیبی): در بات حداکثر ۳ عکس، دریافت با `getFile` واقعی هر پلتفرم (`bale.download_file` / `soroush.download_file`: اعتبارسنجی file_id، رد `..`/مسیر مطلق، سقف ۳MB+۱، بدون exception)، تشخیص magic توسط `uploads.sniff` (JPEG/PNG/WebP/GIF)، ذخیره با پیشوند `bizreg`؛ گالری کامل در سایت `/my`.
- تأیید دوم: `prepare_confirm` توکن تصادفی ۵ دقیقه‌ای، فقط SHA-256 در `bot_confirmations` (action=`biz_register`)؛ `submit` اتمیک (`BEGIN IMMEDIATE`)، سوزاندن توکن + بایند مالک از طریق تلفن تأییدشده، replay کاربر دیگر/تکراری هیچ ردیفی نمی‌سازد؛ مالک مسدود رد می‌شود و توکن سوزانده می‌ماند.
- نتیجه همیشه `status='pending'`؛ انتشار فقط از پنل مدیر (تصمیم: moderation اجباری). اعلان مدیر (`sms.notify_owner`، best-effort) و اعلان درون‌برنامه‌ای مشتری (kind `news`).
- نرخ: bucket جداگانهٔ `bot-reg:<platform>:<uid>` ۴۰/دقیقه با `always=True`، پشت limiter عمومی منوی بات (۲۰/دقیقه) که اول می‌گیرد.
- آزمون: `tools/test_bot_register_v207.py` ۶۶/۶۶ (هستهٔ state machine بدون HTTP) و `tools/test_bot_register_http_v207.py` ۶۳/۶۳ (webhook واقعی هر دو پلتفرم با API جعلی شامل getFile و دانلود، جعل callback، replay، rate، صفحهٔ عمومی با phone_public=0/1).

متن اصلی درخواست (تاریخی):

کاربر خواسته است «ثبت کسب‌وکار مرحله‌به‌مرحله داخل هر دو بات» اضافه شود. قبل از آن صریحاً خواست فایل‌های دانش، قوانین و handoff به‌روز شوند تا چت جدید دقیق باشد.

طرح پیشنهادی ثبت کسب‌وکار:

1. `/register_business` و دکمهٔ «ثبت کسب‌وکار».
2. draft پایدار مشترک با state machine صریح، expiry، resume و cancel تأییدی.
3. انتخاب/جست‌وجوی دسته‌بندی فعال.
4. نام، شهر، محله، نشانی، توضیح کوتاه.
5. تلفن از حساب تأییدشده و غیرقابل جعل؛ گزینهٔ نمایش عمومی جداگانه.
6. ساعات کاری.
7. تصویر: تصمیم محصول هنوز قطعی نشده؛ پیشنهاد امن «لوگو و چند تصویر سبک در بات + مدیریت کامل گالری در سایت» است.
8. پیش‌نمایش و تأیید دوم یک‌بارمصرف.
9. ثبت نهایی با مالکیت معتبر و `status=pending` برای بررسی مدیر؛ انتشار مستقیم ممنوع.
10. parity بله/سروش، محدودیت نرخ/طول/MIME/اندازه، عدم ذخیرهٔ bearer خام، و ZIP کامل مستقل پس از اتمام.

تصمیم‌های باز در v207 بسته شدند (کاربر اجازهٔ انتخاب استاندارد داد): تصویر **ترکیبی**، moderation **اجباری** برای همهٔ ثبت‌های بات.

## ۶٫۵) ثبت کسب‌وکار در سایت — ویزارد v208

- `/register-business` (۷ مرحله) جایگزین `/submit` شد؛ `/submit` فقط 303 می‌دهد. ورود لازم است.
- موتور مشترک با بات‌ها (`bot_register.py`, platform="web") و همان `biz_reg_drafts`؛ ادامهٔ پیش‌نویس از هر کانال.
- فایل‌ها: `server/views_register.py`, `server/register_web.py`, `site/assets/js/regwizard.js`; آزمون `tools/test_register_web_v208.py` (۶۹).
- جزئیات کامل و شواهد QA: `docs/collaboration/KNOWLEDGE.md` بند ۳۳.

## ۶٫۶) چرخهٔ عمر کسب‌وکار برای دکان‌دار — v209

- `/my/businesses`: لغو درخواست بررسی، ارسال دوباره، پنهان/نمایش (فقط منتشرشده‌های قبلی)، حذف نرم با تایپ نام → سطل بازیافت ۳۰ روزه → بازیابی به «در انتظار».
- `db.owner_biz_transition` / `db.owner_delete_business` / `businesses.published_once`؛ آزمون `tools/test_owner_lifecycle_v209.py` (۴۶ در v210). v210: کنترل‌ها در داشبورد `/my` هم هستند، مرحلهٔ دسته یک فیلد، نشانگرهای asset با هم بالا رفتند. جزئیات: KNOWLEDGE بند ۳۴–۳۵.

## ۶٫۷) دستیار مدیر تمام‌قد — ابزارهای محتوا (v239)

- خواست کاربر (۲۰۲۶-۰۹-۱۰): هوش مصنوعی بات مدیریتی بله به همه‌چیز (محتوا) دسترسی داشته باشد، هرگز «نمی‌توانم» نگوید و خودش تغییرات محتوایی را کامل انجام دهد؛ فقط محتوا، هرگز کد سایت.
- ماژول تازه: `server/adminbot_content.py` — ۱۲ ابزار `setting/page/post_save/post_delete/category_save/category_delete/business_save/item_save/item_delete/review_moderate/biz_moderate/broadcast` با parse سخت‌گیرانه (allow-list کلیدها، رد رازها و site_name)، precheck بدون نوشتن و اجرا از توابع خود سایت + audit `admin_ai_tool`.
- مدل فقط پیشنهاد می‌دهد (`{"reply","tool"}`)؛ اجرا فقط با «بله» مدیر و با re-parse/re-precheck (pending دستکاری‌شده نمی‌نویسد). متن غیر-JSON خام مثل v238 رد می‌شود.
- `assistant.admin_answer` اکنون ۳تایی `(reply, source, tool)` برمی‌گرداند؛ ADMIN_PROMPT ابزارها و ممنوعیت رد کردن را دارد؛ snapshot شامل `content_inventory()` است.
- آزمون: `tools/test_adminbot_v239.py` (۱۰۸ چک) + همهٔ سوئیت‌های v233–v238 و بات‌ها/دستیار سبز + تست زندهٔ HTTP (وب‌هوک → LLM جعلی → اجرا → audit → replay بی‌اثر).
- sw.js به `bazarche-v239` بامپ شد (ترمیم نگهبان نسخهٔ جاافتاده از v233).

## ۶٫۸) دستیار همه‌توان — هر سطح محتوای پنل + عکس (v240)

- درخواست مدیر: «دسترسی محدود بود؛ همه‌چیز را می‌خواهم» → `server/adminbot_content.py` بازنویسی کامل: **۳۶ ابزار** = ۱۲ ابزار v239 + ۲۴ ابزار جدید (کد تخفیف، لیست برترین‌ها، پیشنهاد لحظه‌ای، رویداد شهر، بنر، پلن، نشان، استوری، ادعای مالکیت، پاسخ تیکت، مسدودسازی مشتری، وضعیت سفارش/رزرو، تغییر نام محله، بازیافت سطل، حذف نظر، حذف‌های مربوطه).
- **سیستم عکس**: مدیر عکس می‌فرستد → `adminbot._owner_photo` با `_download_file` (getFile توکن خود بات، سقف ۳MB) دانلود → `uploads.save_image(prefix="admin")` → `CT.image_save(path)` در سایدکار (env `ADMINBOT_IMAGE`، پیش‌فرض `/tmp/dastgir-admin-image.json`، TTL ۹۰۰s). ابزارها `image:"__last__"` می‌دهند؛ `_resolve_image` در precheck/execute مسیر واقعی را می‌گذارد و وجود فایل زیر `site/assets/img/uploads/` را چک می‌کند. مسیرهای دستی فقط با `^/?assets/img/[A-Za-z0-9_.\-/]{1,140}$` بدون `..` و فقط موجود — انتخاب مسیر دلخواه توسط مدل ناممکن است.
- **تنظیمات داینامیک**: هر کلید `^[a-z0-9_]{2,48}$` غیررازدار و غیر از `_DENY_KEYS` (که حالا `admin_bot`, `owner_token`, `owner_pass_hash`, `panel_allow_ips` را هم دارد) به‌عنوان رشتهٔ ≤۴۰۰ کاراکتر؛ precheck کلید را در settings یا فهرست‌های شناخته‌شده می‌خواهد.
- `business_save` += cat_slug (انتقال دسته با چک والد)/lat/lng/images/cover؛ `item_save` += images/options/spec (idempotent: رشتهٔ JSON در pending دوباره parse می‌شود)؛ `post_save`/`category_save` += cover/image؛ `page` داینامیک (هر slug موجود؛ slug ناشناس در precheck رد).
- `content_inventory()` += کدهای تخفیف/لیست‌ها/فلاش‌دیل‌ها/رویدادها/بنرها/پلن‌ها/نشان‌ها/ادعاهای در انتظار/تیکت‌های باز/آخرین عکس مدیر.
- پاسخ‌های نامعتبر در `assistant._admin_parse` حالا **نمایان**‌اند: «⚠️ ابزار پیشنهادی معتبر شناخته نشد و اجرا نمی‌شود» به reply اضافه می‌شود (قبل از v240 بی‌صدا حذف می‌شد).
- آزمون: `tools/test_adminbot_v240.py` (۷۶ چک) + رگرسیون کامل (v233–v239 و بات‌ها/دستیار/ثبت‌نام سبز) + تست زندهٔ HTTP: LLM جعلی → `coupon_save` → pending → «بله» → ردیف coupons + `admin_ai_tool` audit. sw.js → `bazarche-v240`.

## ۶٫۹) دستیار صاحب کل سایت — دسترسی به کد + کدگارد (v241)

- درخواست مدیر: «همهٔ دسترسی‌ها را بده — متن، تغییر کد، تمام سایت، هیچ‌جا از قلم نیفتد» → `server/adminbot_code.py` (نیمهٔ in-process) + `deploy/codeguard.sh` (نیمهٔ root) + `tools/bale_notify.py` (اعلان مستقل).
- **معماری دو نیمه**: systemd (`ReadWritePaths=data,uploads`) اجازهٔ نوشتن کد را به app نمی‌دهد؛ پس `code_edit/code_write/code_revert` فقط job در `data/code-jobs/` می‌نویسند و کرون root (`/etc/cron.d/dastgir-codeguard`، نصب خودکار در update.sh و در فرمان تحویل) اعمال می‌کند. `code_list/code_read` فوری‌اند (خواندن مجاز است) و متن خوانده‌شده در سایدکار `ADMINBOT_CODE` (TTL 1800s) می‌ماند و به snapshot مدل می‌چسبد (`admin_snapshot` → `CT.CODE.code_context()`، سقف کل 11000).
- **کدگارد**: قفل تک‌نمونه (`data/codeguard.lock`) → درین صف قدیمی `adminbot-cmd` (backup/restart) → اعمال jobها (پشتیبان در `data/code-backups/<stamp>/` + `index.json`، نوشتن اتمیک، `py_compile` قبل از جایگزینی، بامپ خودکار `sw.js` برای `site/*` با پسوند `.N`) → `systemctl restart` → healthz → در صورت ناسالمی: برگشت از manifest `code-pending-rollback.json`، ری‌استارت دوباره، healthz → اعلان بله (✅/⚠️/🚨) با `bale_notify.py` مستقل از کد app. قابل‌تست کامل با `DASTGIR_APP/SYSTEMCTL/CURL/NOTIFY/CODEGUARD_LOG/HEALTHZ`.
- **قفل‌ها (در هر دو نیمه، تست تطبیق)**: `data/`, `deploy/`, `tools/`, `docs/superpowers/`, uploads/chat-files, `VERSION.txt`, `sw.js`, `server/adminbot*.py|assistant.py|bale.py`. پسوندهای متنی allow-list؛ مسیر با realpath داخل ROOT؛ `old` باید یکتا باشد؛ `MAX_EDITS=8`, `MAX_WRITE_CHARS=24000`.
- `service_restart` → صف قدیمی با فرمت `{"cmd":"restart"}` + ریت‌لیمیت ۱۲۰ث.
- **آزمون**: `tools/test_adminbot_v241.py` (۷۰ چک) + رگرسیون کامل (v233:30، v234:24، v235:49، v237:56، v238:24، v239:139، v240:76، بات‌ها/دستیار/ثبت‌نام) + E2E زندهٔ سراسری (وب‌هوک→code_write→«بله»→job→کدگارد→فایل روی دیسک→✅→healthz ok). بونوس: `deploy/ai-free-setup.sh` (کلید رایگان gemini/groq با تست زندهٔ کلید قبل از نصب و نگه‌داشتن کلید قبلی به‌عنوان fallback).

## ۶٫۱۰) عاملِ واقعی + مغز رایگان از داخل چت (v242)

- شكایت مدیر: «هوش مصنوعی بلد نیست» — ریشه: مغز (کلید API) وصل/قوی نبود و پروتکل تک‌پاسخی برای مدل ضعیف سنگین بود.
- **حلقهٔ عامل**: `assistant.admin_agent()` (تا ۵ مرحله) — ابزارهای فوری `code_list/code_read/code_search` داخل حلقه اجرا و نتیجه (سقف ۳۵۰۰ نویسه) به مدل برمی‌گردد؛ ابزار نوشتن مثل قبل به دیوار «بله» می‌رود. آخرین خروجی ابزار برای شفافیت به پاسخ نهایی مدیر هم می‌چسبد.
- **`code_search`**: جست‌وجوی حروف‌بزرگ/کوچک‌بی‌تفاوت در کل درخت قابل‌ویرایش (فایل:خط، سقف ۲۵ نتیجه/۱۲۰۰ فایل)؛ فایل‌ها/پوشه‌های قفل از نتایج حذف‌اند (قفل‌ها نه خوانده می‌شوند نه جست‌وجو).
- **تطبیق هوشمند**: `adminbot_code.resolve_edit()` — دقیق → trim → تطبیق خط‌به‌خط بی‌توجه به تورفتگی؛ نتیجه (متن دقیق) در precheck داخل خود args بازنویسی می‌شود؛ کدگارد مثل قبل فقط جایگزینی دقیق انجام می‌دهد. ابهام → «ambiguous»، نبود → «nomatch».
- **`/کلید` در چت**: `adminbot.do_ai_key()` → `ai_setup {provider,key}` (پروایدر: gemini/groq؛ الگوی کلید چک می‌شود) → تست زندهٔ کلید در precheck (دلیل خطا: `akey:NNN`) → صف `{"kind":"ai_key"}` برای کدگارد → نوشتن در `/etc/dastgir-secrets.env` (با `DASTGIR_SECRETS` قابل‌تغییر برای تست؛ کلید قبلی → `AI_FALLBACK_*`) → ری‌استارت + سلامت + اعلان «مغز هوش مصنوعی جدید وصل شد». کلید در reply/pending-describe/audit فقط با ۴ حرف اول؛ `_redact()` الگوهای `AIza…/gsk_…` را از همهٔ پیام‌های ارسالی و حافظه پاک می‌کند.
- **آزمون**: `tools/test_adminbot_v242.py` (۴۰ چک) + رگرسیون کامل + E2E زنده (جست‌وجو→خواندن→ویرایش فازی→«بله»→کدگارد→تغییر واقعی README→✅→سلامت).

## ۶٫۱۱) مغز GPT-6 Astra + هر گیت‌وی سازگار با OpenAI (v243)

- مدیر کلید GPT-6 Astra دارد. `adminbot_code.AI_PROVIDERS` += `"astra": ("https://api.openai.com/v1", "gpt-6-astra")`؛ الگوی کلید `sk-[A-Za-z0-9_\-]{20,}`.
- **پروایدر generic `openai`**: `ai_setup {provider=openai, key, base, model}` — base فقط https با `_BASE_RX`، مدل با `_MODEL_RX`. `do_ai_key` فرم‌ها: `/کلید astra KEY` · `/کلید openai BASE KEY MODEL` (یا ۲تایی: KEY MODEL با base پیش‌فرض openai) · کلید sk- تنها → astra. نام سرویس بدون کلید → راهنمای کامل.
- کدگارد: job ‏`ai_key` با providerهای gemini/groq/astra/openai؛ برای astra/openai خط `AI_TIMEOUT=40` هم می‌نویسد (مدل‌های مفکر). رد job با base غیر-http تضمین شده.
- قرمزکننده: الگوی `sk-…` به `_REDACT_RX` اضافه شد.
- **آزمون**: `tools/test_adminbot_v243.py` (۲۶ چک) + رگرسیون کامل. sw.js → `bazarche-v243`.

## ۶٫۱۲) رسید استقرار — پایان «اجرا شد… نشد» (v244)

- شكایت مدیر: بات «اجرا شد» گفت و بعد «نشد». تشخیص: مدل نتیجهٔ استقرار صف‌شونده را نمی‌دید (و اگر کرون کدگارد نصب نباشد، کارها همیشه در صف می‌مانند).
- **کدگارد**: تابع `receipt()` — هر نتیجه به `data/code-deploys.log` (سقف ۶۰ خط): `OK <files>` / `FAIL …` / `ROLLBACK …` / `CRITICAL …`.
- **app**: `adminbot_code.code_status_text()` (صف + قدیمی‌ترین کار + هشدار «کدگارد اجرا نمی‌شود» برای کارهای >۳ دقیقه + ۳ رسید آخر) — از طریق ابزار فوری `code_status` و انتهای `content_inventory()` دیده می‌شود؛ پرامپت قانون ۶ (صداقت استقرار) گرفت.
- **آزمون**: `tools/test_adminbot_v244.py` (۱۶ چک) + رگرسیون کامل (چک inventory در v241 به عبارت جدید به‌روز شد). sw.js → `bazarche-v244`.

## ۶٫۱۳) ضدّ امتناع — پرامپت صادق + push-back سرور (v245)

- شكایت مدیر: بات گفته «دسترسی به کد ندارم». بررسی پرامپت: دو خط نخست قاب «فقط محتوا» می‌ساخت («تغییر همهٔ محتوا…» / «همهٔ محتوای پنل مدیر») — برای مدل سبک بر کل بخش کد می‌چربید.
- اصلاحات: مقدمهٔ پرامپت (دسترسی به کل سایت: محتوا + کد) · تیتر ابزارها («محتوا + کدِ کل سایت») · جملهٔ ضدامتناع صریح بالای بخش کد.
- **مکانیزم**: `assistant._REFUSAL_RX` + `_looks_like_refusal()` — در `admin_agent` اگر پاسخ نهایی بدون ابزار و رفوز-مانند بود، یک user-turn یادآوری («یادآوری سرور: به کد دسترسی داری…») اضافه و `reminded=True`؛ فقط یک بار؛ حداکثر مراحل ۵→۶.
- **آزمون**: `tools/test_adminbot_v245.py` (۲۰ چک) + رگرسیون کامل (سقف حلقه در تست v242 به ۶ به‌روز شد). sw.js → `bazarche-v245`.

## ۶٫۱۴) خلبان خودکار — سرور جای عامل می‌نشیند (v246)

- تحقیق: شبیه‌سازی ۶ شخصیت مدل ضعیف در خط لولهٔ واقعی؛ P2 (وعده بدون ابزار) عامل تجربهٔ «اجرا شد/نشد» بود. معماری قبلی بارِ انتخاب ابزار/JSON را روی مدل ضعیف می‌گذاشت.
- **`assistant.autopilot(text)`**: `code_change_intent` (اسم کد + فعل تغییر، یا مسیر فایل صریح؛ «تنظیمات/پنل» → محتوا) · `mine_query` (نقل‌قول > توکن لاتین > واژهٔ فارسی بلند) · `CODE.search_hits` (رفاکتور خالص) · `CODE.read_region` (±۴۰ خط، سقف ۳۸۰۰) · `_mini_edit_call` (پرامپت کوچک، دو تلاش، max_tokens 350) · `_extract_edit` (JSON، بلوک‌های ```، old:/new:) · `resolve_edit` فازی → پیشنهاد code_edit روی دیوار «بله». شکست = پیام صادقانه + پیشنهاد `/کلید`.
- ادغام در `adminbot`: بعد از `admin_agent` بدون ابزار → autopilot؛ جایگزینی/الحاق هوشمند (اگر مدل نتیجهٔ 🔍 واقعی نشان داده، الحاق). ادعای «انجام شد» بدون ابزار → مهر «⚠️ هنوز هیچ تغییری اجرا نشده». بدون کلید: «کجاست» با جست‌وجوی سروری جواب می‌شود.
- بخشندگی: `_admin_parse` ابزار رشته‌ای/نام کوچک/آرگومان رشته‌ای. رژیم زمینه: snapshot 7000، code_context 2400، CHAT_FEED_CAP 1600.
- **آزمون**: `tools/test_adminbot_v246.py` (۲۶ چک) + رگرسیون کامل (شمارش CALLS در v245 به ۵ به‌روز شد: ۳ خط مدل + ۲ مینی). sw.js → `bazarche-v246`.

## ۶٫۱۵) توکن ChatGPT بدون اصطکاک (v247)

- `do_ai_key`: نام‌های `chatgpt`/`gpt` با کلید تکی `sk-…` → مسیر مستقیم astra (api.openai.com/v1 + gpt-6-astra). فرم‌های قبلی (openai با base/model، astra، gemini، groq) دست‌نخورده.
- تست زندهٔ کلید: HTTP ۴۰۳ → دلیل `akey:403` → پیام «محدودیت منطقه‌ای + راه‌حل سایت واسط»؛ ۴۰۱ و بقیه مثل قبل.
- `/کلید` تنها → خط «🧠 مغز فعلی: <model>» از `assistant.config()`.
- **آزمون**: `tools/test_adminbot_v247.py` (۱۲ چک) + رگرسیون کامل. sw.js → `bazarche-v247`.

## ۶٫۱۶) ترمیم خودکار فراخوانی ابزار (v248)

- پیام «ابزار پیشنهادی معتبر شناخته نشد» = مدل ابزار را با نام/شکل اشتباه خواسته (مثل `edit_code`)؛ نه مشکل خواندن فایل (سرور می‌خواند).
- `adminbot_content`: `normalize_tool_name()` (exact → `_TOOL_ALIAS` ~۸۰ مورد → token-set برای جابجایی‌ها → `difflib.get_close_matches` cutoff 0.8) + `repair_args()` (file/start/end/q/dir/name/val و old/new تکی→edits) — هر دو pure؛ در `parse_tool_call` قبل از اعتبارسنجی.
- `_admin_parse`: پیام رد شامل نام ابزار درخواستی؛ عبارت «معتبر شناخته نشد» حفظ شد (تست‌های v233/v240 وابسته‌اند).
- پرامپت قانون ۳: «نام ابزار را عیناً از همین فهرست بنویس».
- امنیت: ترمیم نام، parse قفل‌ها را باز نمی‌کند (مسیر قفل همان parse رد می‌شود؛ کلید رازدار با name→key هم رد) — تست‌شده.
- **آزمون**: `tools/test_adminbot_v248.py` (۳۱ چک) + رگرسیون کامل. sw.js → `bazarche-v248`.

## ۶٫۱۷) دستور «تشخیص» — گزارش شماره‌دار وضعیت زنده (v249)

- مشکل بنیادی: عیب‌یابی از دور ناممکن بود (سرور واقعی دیده نمی‌شد؛ اسکرین‌شات‌ها هم برای عامل قابل‌دیدن نیست). v249 خودِ بات را عیب‌یاب می‌کند.
- `adminbot.do_diagnose()`: ۶ خط شماره‌دار — نسخه (مقایسه با ۲۴۹) · مغز (`assistant.config` + `_chat` واقعی با ping؛ HTTPError با کد و معنی ۴۰۳؛ `last_error()` که **dict** برمی‌گرداند) · کرون `/etc/cron.d/dastgir-codeguard` · `CT.CODE.code_status_text()` (صف/مانده/رسید) · سرویس · pending. Dispatch: تشخیص/عیب‌یابی/diagnose. بدون چاپ کلید.
- اشاره به تشخیص در: پیام بدون-کلید، خطای حلقهٔ عامل (هر دو مسیر: post-loop و exception)، شکست صادقانهٔ خلبان خودکار، راهنما.
- **آزمون**: `tools/test_adminbot_v249.py` (۲۳ چک) + رگرسیون کامل. sw.js → `bazarche-v249`.

## ۶٫۱۸) رد شدن‌های صادقانه — پایان «ابزار شناخته نشد» (v250)

- شاهد زندهٔ تولید: تشخیص تمام‌سبز + رد شدن واقعی «setting» با پیام گمراه‌کننده. اسم معتبر بود؛ یکی از دروازه‌های args رد شده بود (قفل برند site_name / کلید محرمانه / کلید غایب / واژگان تاگل).
- `adminbot_content`: `parse_with_reason()` (همان حکم parse_tool_call + دلیل فارسی) · `reject_reason()` · `_setting_parse()` منبع واحد لاین setting با دلیلِ هر دروازه · `_parse_tail()` = بدنهٔ v248 عیناً · واژگان تاگل: فعال/غیرفعال/yes/no/بله/نه/enable/disable · ترمیم: setting/setting_key/key_name→key، new_value/v/to/new→value، نرمال‌سازی «Site Title»→site_title · لاین کد: دلیل اختصاصی «مسیر قفل» (DENY_FILES/DENY_PREFIXES).
- `assistant._parse_admin_answer`: نام معتبر + args رد → «ابزار «X» درست بود ولی اجرا نشد: <دلیل>»؛ نام ناشناخته → پیام قدیمی. `adminbot.do_ai_key`: کلید aa-… → دستور آماده با base_url مغز فعلی (بدون چاپ کلید).
- **آزمون**: `tools/test_adminbot_v250.py` (۳۱ چک) + رگرسیون کامل (انتظار دو چک پیام در v240/v248 به پیام صادقانه ارتقا یافت؛ کلید تست v240 بدون زیررشتهٔ «key» تا واقعاً precheck را آزماید). sw.js → `bazarche-v250`.

## ۶٫۱۹) بازکردن دسترسی مدیر + حذف fallback + پین نسخه (v251)

- دستورهای مدیر بعد از اولین تشخیص زنده: «کلا همه جا خیلی کم دسترسی داشت» + «کلا چت جی پی تی جایگزین بشه و قبلی حذف» + باگ خط ۱ تشخیص (عدد ۲۴۹ سفت‌شده).
- `_DENY_KEYS` → فقط `panel_allow_ips/owner_token/owner_pass_hash/admin_bot`؛ `site_name` و کلیدهای سرویس باز شدند. `_secretish` دیگر در parse رد نمی‌کند — نوشتن با «بله» آزاد، مقدار در audit فقط `<مقدار پنهان>`، خواندن (snapshot) قرمز ماند.
- قرارداد برند v179 بازنشسته شد: `db.get_settings` (canonicalize)، `set_setting`، `set_settings`، بوت و `import_all` دیگر نام را به BRAND_NAME برنمی‌گردانند؛ پنل (هر دو فرم) و POSTهای `/panel/settings` و `/panel/editor` نام سایت را می‌پذیرند. PWA manifest/offline برند ثابت ماند.
- `DIAG_LATEST = "251"` در adminbot.py — **بامپ در هر نسخه** (تست v251 آن را به VERSION.txt قفل کرده).
- codeguard.sh: حفظ مغز قبلی به‌عنوان fallback حذف + پاک‌کردن AI_FALLBACK_* قدیمی.
- **آزمون**: v251 (۲۲ چک) + رگرسیون کامل؛ به‌روزرسانی انتظار تست‌ها: v239 (لیست قفل‌ها)، v242/v243 (بدون fallback)، v250 (site_name باز + کلیدهای سرویس)، brand v179 (سیاست نام انتخابی). sw.js → `bazarche-v251`.

## ۶٫۲۰) دلایل دقیق ورودی برای ai_setup (v252)

- شاهد زندهٔ دوم از سرور: درخواست طبیعی تغییر کلید → «ورودی‌های ابزار کد معتبر نبود» بدون گفتن کدام ورودی. `_ai_setup_reason(a)` در adminbot_content: provider ناشناخته/کلید غایب/شکل کلید per-provider/absenceٔ base یا model (مسیر openai)/ریدایرکت کلید aa- از مسیر astra به openai. مقدار کلید هرگز بازتاب نمی‌شود.
- وصله در `parse_with_reason` بعد از رد شدن `CODE.parse("ai_setup")` — حکم‌ها تغییر نکردند، فقط پیام‌ها.
- **آزمون**: v252 (۱۵ چک) + رگرسیون کامل. sw.js → `bazarche-v252`.

## ۶٫۲۱) کلید داخل بسته — نصب یعنی نصب کلید (v253)

- دستور مدیر: «کلیدو داخل کد قرار بده». `deploy/brain.env` (base+key+model+timeout) + `deploy/apply-brain.sh` (backup → حذف همهٔ AI_* → append → chmod 600 → stamp با sha256) + سیم‌کشی در update.sh قبل از systemctl start. مسیرها با DASTGIR_APP/DASTGIR_SECRETS قابل تست‌اند.
- **هشدار برای نسخه‌های بعد**: v253 دارای brain.env است. v254+ یا عمداً brain.env تازه بگذارد یا آن را حذف کند — stamp ضدِ له‌کردن کلیدِ تغییرکرده از بات را حفظ می‌کند ولی مغزِ داخل بسته در نصب بعدی (اگر باشد) اعمال می‌شود.
- بات به deploy/ هیچ دسترسی ندارد (DENY_PREFIXES) — کلید برای مدل ناخواناست.
- **آزمون**: v253 (۱۷ چک) + رگرسیون کامل. sw.js → `bazarche-v253`.

## ۶٫۲۲) پرامپت بدون محدودیت + بستهٔ بدون کلید (v254)

- دستورهای مدیر: «پرامپ چت بدون محدودیت» + «کلید جیمنای پاک کن، نسخه‌ای بده که هوش مصنوعی فعال نیست؛ توکن را خودم در ترموکس فعال می‌کنم».
- `ANSWER_PROMPT` قاعدهٔ ۱: از محدودیت موضوعی به «محدودیت موضوعی نداری، رد نکن» تغییر کرد؛ قواعد ۲-۹ (صداقت داده، ابزارها، grounding) عیناً ماندند؛ `scope` فقط آمار. تست‌های v213-232 همه بدون تغییر سبز ماندند (فقط رفتار مدل عوض شد، نه قرارداد سرور).
- `deploy/brain.env` بدون هیچ خط `AI_` → apply-brain حین نصب همهٔ AI_* قبلی را پاک می‌کند = مغز خاموش. فعال‌سازی بعدی با دستور ترمینال مدیر (تست زندهٔ کلید → نوشتن env → ری‌استارت) یا `/کلید`.
- **یادآوری v255+**: brain.env یا خالی بماند یا کلید تازه — کلیدِ فعال‌شدهٔ دستی با نصب مجدد همان زیپ له نمی‌شود (stamp) ولی brain.env تازه اعمال می‌شود.
- **آزمون**: v254 (۱۴ چک) + رگرسیون کامل. sw.js → `bazarche-v254`.

## ۶٫۲۳) یک دستور، همه‌چیز خودکار (v255)

- دستور مدیر بعد از v254 (که فعال‌سازی ترمینال می‌خواست): «توکن قبلی کلاً حذف بشه، ترامپی حذف بشه، خودش آزاد باشه». v255 = v253 (کلید داخل بسته) + v254 (پرامپت آزاد) + حذف ردپا: `apply-brain.sh` بعد از موفقیت `.bak` را هم پاک می‌کند.
- **یادآوری v256+**: brain.env همین کلید را دارد؛ برای کلید تازه فقط همان فایل را عوض کنید (stamp از له‌کردن تغییرات بات می‌محافظت اما brain.env تازه اعمال می‌شود).
- **آزمون**: v255 (۱۲ چک) + رگرسیون کامل؛ تست‌های v253/v254 به سیاست «کلید داخل بسته» برگردانده شدند. sw.js → `bazarche-v255`.

## ۶٫۲۴) کلاً بدون توکن — با مدرک (v256)

- دستور مدیر: «کلا توکن‌ها را حذف کن کلا کلا کلا با مدرک». brain.env بی‌کلید؛ نصب = پاک‌شدن همهٔ AI_* سرور + حذف .bak؛ `tools/scan_tokens.py` (فهرست سیاهٔ هش SHA-256 کلیدهای واقعی؛ خود کلید هرگز در بسته نیست) + `docs/TOKEN-FREE.md` (سند مدرک) + تست v256 که بی‌توکن‌بودن را برای همیشه قفل می‌کند.
- پاک‌سازی فضای کاری: زیپ‌های v253/v255 (حاوی کلید) حذف شدند؛ اسکرین‌شات‌های آپلودشده حذف شدند.
- خارج از دسترس: دو لینک عمومی x0.at (v253/v255) و پیام‌های چت مدیر — در TOKEN-FREE.md ثبت شد.
- **یادآوری v257+**: brain.env باید خالی بماند مگر دستور صریح جدید؛ تست v256 جاسازی کلید را قرمز می‌کند.
- **آزمون**: v256 (۱۲ چک) + رگرسیون کامل؛ تست‌های v253/v254/v255 از قید «محتوای brain.env» آزاد شدند (سیاست محتوا فقط در آخرین سوئیت پین می‌شود). sw.js → `bazarche-v256`.

## ۷) قوانین ادامه

- در clone/GitHub ابتدا `docs/collaboration/CURRENT-STATE.md`، سپس `docs/collaboration/RULES.md`، `docs/collaboration/KNOWLEDGE.md` و این `HANDOFF.md` خوانده شوند؛ نسخه‌های بیرون پروژه فقط workspace اصلی را تکمیل می‌کنند.
- قبل از هر تغییر، فایل‌های مرتبط و رفتار واقعی بررسی شوند.
- هر بخش مستقل، نسخهٔ تازه و ZIP کامل clean دارد؛ patch archive ممنوع.
- موفقیت بدون تست واقعی ادعا نشود.
- stable callback prefix `dg198:` صرفاً برای هماهنگی نسخه تغییر نکند.
- هر state-changing/destructive action تأیید دوم و predicate اتمیک مالکیت/وضعیت می‌خواهد.
- پس از بسته، clean extraction QA، hash، remote redownload و ثبت در KNOWLEDGE انجام شود.
