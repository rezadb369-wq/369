# -*- coding: utf-8 -*-
"""v239→v240: FULL-power content tools for the owner-only Bale admin copilot.

v239 covered settings/pages/posts/categories/businesses/items/reviews/
moderation/broadcast. v240 closes the gap to "everything the admin panel
can edit", mirroring each panel surface with the site's own functions:

  * dynamic settings: ANY key the panel itself uses (minus secrets/locks)
  * coupons, toplists, flashdeals, city events, ads, plans, badges, stories
  * business category / map pin / cover / images; item images/options/spec
  * claims moderation, ticket replies, customer block/unblock
  * order status, booking status, area rename, trash restore, review delete
  * IMAGES: the admin sends a photo in the bot chat (adminbot saves it via
    uploads.save_image) and the model references it as "__last__" — the
    sentinel is resolved server-side, so the model can never point at an
    arbitrary filesystem path.

Architecture is unchanged (the v223 safe-tools pattern, admin variant):
model PROPOSES → strict parse (allow-lists, no secrets, caps) → precheck
against the live DB without writing → the owner's separate «بله» →
re-parse + re-precheck + execute through the site's own savers + audit
row ``db.log("admin_ai_tool", ...)``. Site CODE, files and secrets stay
untouchable by design.
"""
import difflib
import json
import os
import re
import time

import db
import features
import adminbot_code as CODE   # v241: full-site code access

TOOLS = ("setting", "page", "post_save", "post_delete", "category_save",
         "category_delete", "business_save", "item_save", "item_delete",
         "review_moderate", "review_delete", "biz_moderate", "broadcast",
         # v240: the rest of the panel's content surfaces
         "coupon_save", "coupon_delete", "toplist_save", "toplist_delete",
         "flashdeal_save", "flashdeal_delete", "event_save", "event_delete",
         "ad_save", "ad_delete", "plan_save", "plan_delete",
         "badge_save", "badge_delete", "story_add", "story_delete",
         "claim_moderate", "ticket_reply", "customer_moderate",
         "order_status", "booking_status", "area_rename", "trash_restore",
         # v241: full code access (edits deploy via the root codeguard cron)
         "code_list", "code_read", "code_edit", "code_write", "code_revert",
         "code_search", "code_status", "ai_setup", "service_restart")

# v241: read-only code tools execute immediately (no «بله» needed for reads)
IMMEDIATE_TOOLS = ("code_list", "code_read", "code_search", "code_status")

# ---- v248: self-repairing tool calls (weak models misname/misshape) ----
_TOOL_ALIAS = {
    # code lane — the names weak brains naturally invent
    "read_file": "code_read", "open_file": "code_read", "view_file": "code_read",
    "read_code": "code_read", "cat": "code_read", "readfile": "code_read",
    "edit_code": "code_edit", "editfile": "code_edit", "edit_file": "code_edit",
    "modify_code": "code_edit", "modify_file": "code_edit", "apply_edit": "code_edit",
    "replace_text": "code_edit", "fix_code": "code_edit", "patch": "code_edit",
    "write_file": "code_write", "create_file": "code_write", "new_file": "code_write",
    "write_code": "code_write", "make_file": "code_write",
    "search_code": "code_search", "code_find": "code_search", "find_text": "code_search",
    "search_text": "code_search", "grep": "code_search", "search_files": "code_search",
    "list_files": "code_list", "ls": "code_list", "list_dir": "code_list",
    "list_directory": "code_list", "show_files": "code_list", "files": "code_list",
    "revert_file": "code_revert", "undo": "code_revert", "restore": "code_revert",
    "rollback": "code_revert", "code_rollback": "code_revert",
    "restart": "service_restart", "reboot": "service_restart",
    "restart_service": "service_restart", "reload": "service_restart",
    "deploy_status": "code_status", "status": "code_status",
    # content lane — common reformulations
    "save_setting": "setting", "set_setting": "setting", "settings": "setting",
    "update_setting": "setting", "set_config": "setting", "config_set": "setting",
    "save_post": "post_save", "create_post": "post_save", "new_post": "post_save",
    "update_post": "post_save", "remove_post": "post_delete",
    "save_category": "category_save", "remove_category": "category_delete",
    "save_business": "business_save", "update_business": "business_save",
    "save_item": "item_save", "update_item": "item_save", "create_item": "item_save",
    "remove_item": "item_delete", "save_coupon": "coupon_save",
    "remove_coupon": "coupon_delete", "save_plan": "plan_save",
    "remove_plan": "plan_delete", "save_badge": "badge_save",
    "remove_badge": "badge_delete", "save_ad": "ad_save", "remove_ad": "ad_delete",
    "save_event": "event_save", "remove_event": "event_delete",
    "save_toplist": "toplist_save", "remove_toplist": "toplist_delete",
    "save_flashdeal": "flashdeal_save", "remove_flashdeal": "flashdeal_delete",
    "add_story": "story_add", "remove_story": "story_delete",
    "reply_ticket": "ticket_reply", "answer_ticket": "ticket_reply",
    "block_customer": "customer_moderate", "moderate_customer": "customer_moderate",
    "update_order": "order_status", "update_booking": "booking_status",
    "rename_area": "area_rename", "restore_trash": "trash_restore",
    "review_action": "review_moderate", "moderate_review": "review_moderate",
    "biz_action": "biz_moderate", "send_broadcast": "broadcast",
}
_TOKEN_TOOLS = {frozenset(t.split("_")): t for t in TOOLS}


def normalize_tool_name(name):
    """Canonical tool name from a model's invented name, or None.
    exact → alias → token-set (handles save_post/post_save swaps) →
    close spelling (difflib). Deterministic and pure."""
    s = str(name or "").strip().lower().replace("-", "_").replace(" ", "_")
    s = re.sub(r"[^a-z0-9_]", "", s)
    if not s:
        return None
    if s in TOOLS:
        return s
    if s in _TOOL_ALIAS:
        return _TOOL_ALIAS[s]
    tok = frozenset(x for x in s.split("_") if x)
    if tok in _TOKEN_TOOLS:
        return _TOKEN_TOOLS[tok]
    m = difflib.get_close_matches(s, TOOLS, n=1, cutoff=0.8)
    return m[0] if m else None


def repair_args(name, a):
    """Fix the most common weak-model argument shapes (pure)."""
    try:
        if not isinstance(a, dict):
            return a
        if not a.get("path") and a.get("file") and name in (
                "code_list", "code_read", "code_edit", "code_write", "code_revert"):
            a = dict(a, path=a["file"])
        if name == "code_edit" and not a.get("edits") \
                and a.get("old") is not None and a.get("new") is not None:
            a = dict(a, edits=[{"old": str(a["old"]), "new": str(a["new"])}])
        if name == "code_read":
            frm = a.get("from_line") or a.get("start") or a.get("from") or 1
            to = a.get("to_line") or a.get("end") or a.get("to")
            a = dict(a, from_line=frm, **({"to_line": to} if to is not None else {}))
        if name == "code_search" and not a.get("query"):
            for k in ("q", "text", "term", "keyword", "search", "find"):
                if a.get(k):
                    a = dict(a, query=a[k])
                    break
        if name == "code_list" and "path" not in a:
            for k in ("dir", "folder", "directory"):
                if k in a:
                    a = dict(a, path=a[k])
                    break
        if name == "setting":
            # v250: weak brains wrap the pair in many shapes — setting/key_name
            # for the key, new_value/to/new for the value.
            if not a.get("key"):
                for k in ("setting", "setting_key", "key_name", "name"):
                    if a.get(k):
                        a = dict(a, key=a[k])
                        break
            if "value" not in a:
                for k in ("val", "new_value", "v", "to", "new"):
                    if a.get(k) is not None:
                        a = dict(a, value=a[k])
                        break
            if a.get("key"):     # v250: "Site Title" / "site-title" shapes
                k2 = str(a["key"]).strip().lower().replace(" ", "_").replace("-", "_")
                if k2:
                    a = dict(a, key=k2)
        return a
    except Exception:
        return a

TOOL_TTL = 300          # seconds a proposed tool stays confirmable

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ------------------------------------------------------------------ images
UPLOADS_URL = "/assets/img/uploads/"     # uploads.save_image returns leading-slash paths
_IMAGE_RX = re.compile(r"^/?assets/img/[A-Za-z0-9_.\-/]{1,140}$")
_DT_RX = re.compile(r"^\d{4}-\d{2}-\d{2}([ T]\d{2}:\d{2}(:\d{2})?)?$")


def image_sidefile():
    return os.environ.get("ADMINBOT_IMAGE") or "/tmp/dastgir-admin-image.json"


def image_save(public_path):
    """Remember the admin's last uploaded photo (15-minute TTL)."""
    try:
        with open(image_sidefile(), "w", encoding="utf-8") as f:
            json.dump({"path": str(public_path), "ts": time.time()}, f)
        return True
    except OSError:
        return False


def image_last(max_age=900):
    """Path of the admin's last uploaded photo, or ''. Never raises."""
    try:
        with open(image_sidefile(), encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict) and time.time() - float(d.get("ts", 0)) < max_age:
            p = str(d.get("path") or "")
            if p.startswith(UPLOADS_URL) and os.path.isfile(
                    os.path.join(ROOT, "site", p.lstrip("/"))):
                return p
    except (OSError, ValueError, TypeError):
        pass
    return ""


def _image_ok(v):
    """Parse-time shape check only (no FS)."""
    v = str(v or "").strip()
    if v == "__last__":
        return True
    return bool(_IMAGE_RX.match(v)) and ".." not in v


def _resolve_image(v):
    """Resolve to a real, existing public image path, or None."""
    v = str(v or "").strip()
    if v == "__last__":
        return image_last() or None
    if not _IMAGE_RX.match(v) or ".." in v:
        return None
    if not os.path.isfile(os.path.join(ROOT, "site", v.lstrip("/"))):
        return None
    return v if v.startswith("/") else "/" + v   # stored like save_image does


# ------------------------------------------------------------------ settings
# Keys the model may NEVER touch (mirrors adminbot._SNAP_SECRET_RX plus the
# brand lock and the lockout/operational keys). Refused at parse time.
_SECRET_RX = ("token", "secret", "pass", "key", "salt", "hash", "bearer",
              "credential", "private")
# v251 (دستور مدیر — «همه‌جا کم‌دسترسی بود»): فقط احراز هویت/قفل‌اوت قفل
# می‌مانند. کلیدهای سرویس (gmaps_key، tg_token، sms_key…) از بات قابل
# «نوشتن» هستند — با تأیید صریح مدیر و بدون ثبت مقدار در لاگ. خواندنشان
# همیشگی ممنوع است (قرمزسازی snapshot دست‌نخورده ماند).
_DENY_KEYS = {"panel_allow_ips", "owner_token", "owner_pass_hash",
              "admin_bot"}

# Text/content settings with their panel-matching length caps (typed knowns;
# anything else the panel stores is accepted dynamically as a string).
TEXT_SETTINGS = {
    "site_name": 60,
    "tagline": 120, "description": 400,
    "hero_title": 120, "hero_lead": 400, "hero_cta": 60, "footer_note": 160,
    "address": 300, "email": 120, "phone": 30, "whatsapp": 30,
    "site_url": 200,
    "instagram": 100, "telegram": 100, "eitaa": 100, "bale": 100,
    "soroush": 100, "rubika": 100,
    "announcement": 300, "seo_keywords": 300, "owner_whatsapp": 30,
}
FLOAT_SETTINGS = ("map_lat", "map_lng")
INT_SETTINGS = {"map_zoom": (2, 19), "order_cancel_minutes": (0, 1440),
                "founder_limit": (0, 100000)}
# Feature toggles the panel itself exposes (SITE_FEATURES) + prices + AI.
TOGGLE_SETTINGS = (
    "prices_enabled", "reviews_moderated", "catalog_enabled",
    "events_enabled", "blog_enabled", "ads_enabled", "plans_enabled",
    "reg_open", "owner_login", "claims_enabled", "support_widget",
    "stories_enabled", "follow_enabled", "notif_enabled", "chat_enabled",
    "shop_account", "orders_enabled", "lists_enabled", "deals_enabled",
    "inquiry_enabled", "reports_enabled", "alerts_enabled", "ai_enabled",
)
# v250: weak brains answer a toggle with فعال/yes/بله… — accept the common
# synonyms instead of silently rejecting the WHOLE tool call with a
# misleading «ابزار شناخته نشد» (seen live on the production server).
_ON_WORDS = ("1", "true", "on", "روشن", "فعال", "yes", "بله",
             "enable", "enabled")
_OFF_WORDS = ("0", "false", "off", "خاموش", "غیرفعال", "no", "نه",
              "disable", "disabled")
_SETTING_KEY_RX = re.compile(r"^[a-z0-9_]{2,48}$")

DAYS = ("sat", "sun", "mon", "tue", "wed", "thu", "fri")
_HHMM = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
_ITEM_KINDS = ("product", "service", "custom")
_PRICE_TYPES = ("fixed", "call", "hour")
_ORDER_STATUSES = ("new", "confirmed", "ready", "done", "cancelled")
_BOOKING_STATUSES = ("new", "confirmed", "done", "cancelled")
_LIST_KINDS = ("manual", "auto_rating", "auto_views", "auto_featured", "auto_new")
_AD_SLOTS = ("home", "directory", "business", "sidebar")

# business content fields (everything the panel edits except slug/ownership).
_BIZ_FIELDS = {
    "name": 80, "descr": 1500, "phone": 20, "whatsapp": 20, "address": 200,
    "city": 40, "area": 60, "province": 40, "tags": 200,
    "website": 100, "instagram": 100, "telegram": 100, "eitaa": 100,
    "bale": 100, "soroush": 100, "rubika": 100, "cat_slug": 80,
}
_BIZ_STATUSES = ("published", "pending", "hidden", "rejected")

# item content fields.
_ITEM_TEXT = {"title": 120, "descr": 2000, "unit": 20, "code": 40, "note": 300,
              "brand": 60, "warranty": 120, "tags": 200, "delivery": 200,
              "video": 200}
_ITEM_NUM = ("min_order", "price", "old_price", "floor_price", "stock",
             "weight", "prep_days", "sort", "bulk_price")
_ITEM_FLAGS = ("available", "featured", "handmade", "returnable", "haggle")


def _s(v, cap=None):
    """Content text, verbatim (only whitespace-stripped) + hard cap."""
    v = str(v or "").strip()
    return v[:cap] if cap else v


def _i(v):
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return None


def _secretish(key):
    k = str(key or "").lower()
    return k in _DENY_KEYS or any(s in k for s in _SECRET_RX)


def _norm_hours(h):
    """Validate/normalize a hours dict → JSON str; '' when malformed.

    Shape (same as the register wizard): {"sat": [["09:00","22:00"]], ...}
    Also accepts an already-serialized JSON string (idempotent re-parse).
    """
    if h in ("", None, {}):
        return "{}"
    if isinstance(h, str):
        try:
            h = json.loads(h)
        except ValueError:
            return ""
    if not isinstance(h, dict):
        return ""
    out = {}
    for day, spans in h.items():
        if day not in DAYS or not isinstance(spans, list) or len(spans) > 3:
            return ""
        norm = []
        for sp in spans:
            if (not isinstance(sp, (list, tuple)) or len(sp) != 2
                    or not _HHMM.match(str(sp[0])) or not _HHMM.match(str(sp[1]))
                    or str(sp[0]) >= str(sp[1])):
                return ""
            norm.append([str(sp[0]), str(sp[1])])
        if norm:
            out[day] = norm
    return json.dumps(out, ensure_ascii=False)


def _norm_images(v):
    """Parse-time shape check for an images value (str|list).'' when bad."""
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except ValueError:
            return ""
    if not isinstance(v, list) or len(v) > 10:
        return ""
    out = []
    for x in v:
        x = str(x or "").strip()
        if not _image_ok(x):
            return ""
        out.append(x)
    return json.dumps(out, ensure_ascii=False)


# ------------------------------------------------------------------ parse

def _setting_parse(a):
    """v250: the setting lane, single source of truth — every rejection now
    carries a Persian reason, so the owner sees WHICH gate failed instead of
    the old lie «ابزار setting شناخته نشد» (seen live on the production
    server: valid tool, rejected args, zero explanation)."""
    key = str(a.get("key") or "").strip()
    if not key:
        return None, {}, "کلید تنظیم (key) نفرستاده شد"
    if key in _DENY_KEYS:
        return None, {}, (f"کلید «{key}» از بات قابل تغییر نیست "
                          "(قفل احراز هویت/قفل‌اوت)")
    if not _SETTING_KEY_RX.match(key):
        return None, {}, (f"شکل کلید «{key[:24]}» معتبر نیست؛ "
                          "نام انگلیسی تنظیم را از پنل بپرس")
    if key in TOGGLE_SETTINGS:
        v = str(a.get("value")).strip().lower()
        if v in _ON_WORDS:
            return "setting", {"key": key, "value": "1"}, ""
        if v in _OFF_WORDS:
            return "setting", {"key": key, "value": "0"}, ""
        return None, {}, "مقدار این کلید فقط روشن یا خاموش است"
    if key in TEXT_SETTINGS:
        return "setting", {"key": key,
                           "value": _s(a.get("value"), TEXT_SETTINGS[key])}, ""
    if key in FLOAT_SETTINGS:
        try:
            f = float(str(a.get("value")).strip())
        except (TypeError, ValueError):
            return None, {}, "مقدار باید عدد باشد"
        if key == "map_lat" and not (-90 <= f <= 90):
            return None, {}, "عرض جغرافیایی باید بین ۹۰- تا ۹۰ باشد"
        if key == "map_lng" and not (-180 <= f <= 180):
            return None, {}, "طول جغرافیایی باید بین ۱۸۰- تا ۱۸۰ باشد"
        return "setting", {"key": key, "value": str(f)}, ""
    if key in INT_SETTINGS:
        n = _i(a.get("value"))
        lo, hi = INT_SETTINGS[key]
        if n is None or not (lo <= n <= hi):
            return None, {}, f"مقدار باید عدد بین {lo} و {hi} باشد"
        return "setting", {"key": key, "value": str(n)}, ""
    # v240 dynamic: any other panel key is a bounded string, exactly
    # like the panel's own form POST stores it.
    return "setting", {"key": key, "value": _s(a.get("value"), 400)}, ""


def _ai_setup_reason(a):
    """v252: exactly WHICH ai_setup input was wrong (the owner's live case:
    a valid tool died with the vague «ورودی‌ها معتبر نبود» and the owner had
    to ask why). Never echoes the key."""
    try:
        prov = str(a.get("provider") or "").strip().lower()
        key = str(a.get("key") or "").strip()
        if prov not in ("gemini", "groq", "astra", "openai"):
            return ("سرویس باید یکی از این‌ها باشد: openai / astra / gemini / groq"
                    "؛ برای کلید aa-… سرویس openai با آدرس و مدل")
        if not key:
            return "کلید (key) فرستاده نشد"
        if prov == "astra" and key.startswith("aa-"):
            return ("کلید aa-… مال سرویس واسط است؛ سرویس را openai بگذار و "
                    "آدرس (مثل https://api.avalai.ir/v1) و مدل gpt-6-astra را هم بفرست")
        if prov != "openai" and not CODE._KEY_RX[prov].match(key):
            return (f"شکل کلید برای سرویس {prov} معتبر نیست؛ "
                    "کلید کامل و بدون فاصله لازم است")
        if prov == "openai":
            base = str(a.get("base") or "").strip().rstrip("/")
            model = str(a.get("model") or "").strip()
            if not base or not CODE._BASE_RX.match(base):
                return "آدرس سرویس (base) لازم است؛ مثال: https://api.avalai.ir/v1"
            if not model or not CODE._MODEL_RX.match(model):
                return "نام مدل لازم است؛ مثال: gpt-6-astra"
            if not CODE._KEY_RX["openai"].match(key):
                return "شکل کلید معتبر نیست؛ کلید را کامل و بدون فاصله بفرست"
        return ""
    except Exception:
        return ""


def parse_with_reason(obj):
    """v250: same verdict as parse_tool_call plus a short Persian WHY a
    valid-named tool was rejected. why == '' both when accepted AND when the
    NAME itself was unknown (the caller then uses the older wording)."""
    try:
        if not isinstance(obj, dict):
            return None, {}, ""
        raw = str(obj.get("name") or "").strip()
        name = raw if raw in TOOLS else (normalize_tool_name(raw) or "")
        if not name or name not in TOOLS:
            return None, {}, ""               # the NAME is the problem
        a = obj.get("args")
        if not isinstance(a, dict):
            return None, {}, "ورودی ابزار (args) درست فرستاده نشد"
        a = repair_args(name, a)
        if name in ("code_list", "code_read", "code_edit", "code_write",
                    "code_revert", "code_search", "code_status", "ai_setup",
                    "service_restart"):
            n2, a2 = CODE.parse(name, a)
            if n2:
                return n2, a2, ""
            # v250: a locked path deserves its own honest reason — the inputs
            # were fine, the path is protected infrastructure.
            try:
                p = str(a.get("path") or "").strip().strip("/").lower()
                if p and (p in CODE.DENY_FILES
                          or any(p == d.rstrip("/") or p.startswith(d)
                                 for d in CODE.DENY_PREFIXES)):
                    return None, {}, "مسیر قفل است و از بات تغییر نمی‌کند (زیرساخت سایت)"
            except Exception:
                pass
            if name == "ai_setup":          # v252: name the exact bad input
                why = _ai_setup_reason(a)
                if why:
                    return None, {}, why
            return None, {}, "ورودی‌های ابزار کد کامل یا معتبر نبود"
        if name == "setting":
            return _setting_parse(a)
        n2, a2 = _parse_tail(obj)
        return (n2, a2, "") if n2 else (None, {},
                                        "ورودی‌های این ابزار کامل یا معتبر نبود")
    except Exception:
        return None, {}, ""


def reject_reason(obj):
    """v250: owner-facing why-string for a rejected proposal; '' when the
    tool NAME was the problem (a different, older message applies)."""
    try:
        return parse_with_reason(obj)[2] or ""
    except Exception:
        return ""


def parse_tool_call(obj):
    """Strict-validate a model-proposed tool call. Returns (name, args) or
    (None, {}). Unknown tools, bad shapes, secret keys and invented ids
    never pass. Pure -- no DB access. (v250: verdicts come from
    parse_with_reason; only rejection WORDING improved.)"""
    return parse_with_reason(obj)[:2]


def _parse_tail(obj):
    """The v248/v249 validation body, verbatim (verdicts unchanged)."""
    try:
        if not isinstance(obj, dict):
            return None, {}
        name = str(obj.get("name") or "").strip()
        if name not in TOOLS:                 # v248: repair invented names
            name = normalize_tool_name(name) or ""
        if not name or name not in TOOLS:
            return None, {}
        a = obj.get("args")
        if not isinstance(a, dict):
            return None, {}
        a = repair_args(name, a)              # v248: repair common arg shapes

        if name in ("code_list", "code_read", "code_edit", "code_write",
                    "code_revert", "code_search", "code_status", "ai_setup",
                    "service_restart"):
            return CODE.parse(name, a)

        if name == "setting":
            n2, a2, _why = _setting_parse(a)
            return n2, a2

        if name == "page":
            slug = str(a.get("slug") or "").strip()
            if not re.match(r"^[a-z0-9_-]{2,30}$", slug):
                return None, {}
            title = _s(a.get("title"), 100)
            body = str(a.get("body") or "").strip()
            if not title or not body or len(body) > 4000:
                return None, {}
            return name, {"slug": slug, "title": title, "body": body}

        if name == "post_save":
            pid = _i(a.get("id")) or 0
            if pid < 0:
                return None, {}
            title = _s(a.get("title"), 120)
            if not title:
                return None, {}
            cover = _s(a.get("cover"), 160)
            if cover and not _image_ok(cover):
                return None, {}
            excerpt = _s(a.get("excerpt"), 300)
            body = str(a.get("body") or "").strip()
            if len(body) > 20000:
                return None, {}
            status = str(a.get("status") or "published").strip()
            if status not in ("published", "hidden"):
                return None, {}
            return name, {"id": pid, "title": title, "excerpt": excerpt,
                          "body": body, "status": status, "cover": cover}

        if name in ("post_delete", "category_delete", "item_delete",
                    "coupon_delete", "toplist_delete", "flashdeal_delete",
                    "event_delete", "ad_delete", "plan_delete",
                    "badge_delete", "story_delete", "review_delete",
                    "trash_restore"):
            n = _i(a.get("id"))
            if not n or n <= 0:
                return None, {}
            return name, {"id": n}

        if name == "category_save":
            cid = _i(a.get("id")) or 0
            if cid < 0:
                return None, {}
            nm = _s(a.get("name"), 60)
            if not nm:
                return None, {}
            image = _s(a.get("image"), 160)
            if image and not _image_ok(image):
                return None, {}
            out = {"id": cid, "name": nm, "image": image}
            for k, cap in (("icon", 40), ("blurb", 200), ("parent", 80)):
                if a.get(k) is not None:
                    out[k] = _s(a.get(k), cap)
            if a.get("sort") is not None:
                out["sort"] = max(0, min(9999, _i(a.get("sort")) or 0))
            if a.get("active") is not None:
                out["active"] = 1 if str(a.get("active")).strip() in ("1", "true", "on") else 0
            return name, out

        if name == "business_save":
            bid = _i(a.get("id"))
            if not bid or bid <= 0:
                return None, {}
            # idempotent: accept the model shape (flat) and the normalized
            # shape ({"fields": {...}}) so a confirmed proposal round-trips.
            raw = a["fields"] if isinstance(a.get("fields"), dict) else a
            fields = {}
            for k, cap in _BIZ_FIELDS.items():
                if raw.get(k) is not None:
                    fields[k] = _s(raw.get(k), cap)
            for k in ("featured", "verified", "booking_on", "phone_public"):
                if raw.get(k) is not None:
                    fields[k] = 1 if str(raw[k]).strip() in ("1", "true", "on") else 0
            for k in ("lat", "lng"):
                if raw.get(k) is not None:
                    try:
                        fields[k] = float(str(raw.get(k)).strip())
                    except (TypeError, ValueError):
                        return None, {}
            if "status" in raw and str(raw.get("status") or "").strip() in _BIZ_STATUSES:
                fields["status"] = str(raw.get("status")).strip()
            if "hours" in raw:
                h = _norm_hours(raw.get("hours"))
                if h == "":
                    return None, {}          # malformed hours refuse the call
                fields["hours"] = h
            if "cover" in raw:
                cover = str(raw.get("cover") or "").strip()
                if cover and not _image_ok(cover):
                    return None, {}
                fields["cover"] = cover
            if "images" in raw:
                imgs = _norm_images(raw.get("images"))
                if imgs == "":
                    return None, {}
                fields["images"] = imgs
            if not fields:
                return None, {}
            return name, {"id": bid, "fields": fields}

        if name == "item_save":
            iid = _i(a.get("id")) or 0
            if iid < 0:
                return None, {}
            raw = a["data"] if isinstance(a.get("data"), dict) else a
            biz_id = _i(raw.get("biz_id"))
            if not biz_id or biz_id <= 0:
                return None, {}
            d = {"biz_id": biz_id}
            for k, cap in _ITEM_TEXT.items():
                if raw.get(k) is not None:
                    d[k] = _s(raw.get(k), cap)
            for k in _ITEM_NUM:
                if raw.get(k) is None:
                    continue
                n = _i(raw.get(k))
                if n is None or n < 0:
                    return None, {}
                d[k] = n
            if not iid and not d.get("title"):
                return None, {}              # new items need a title
            if raw.get("kind") is not None:
                if str(raw.get("kind")).strip() not in _ITEM_KINDS:
                    return None, {}
                d["kind"] = str(raw.get("kind")).strip()
            if raw.get("price_type") is not None:
                if str(raw.get("price_type")).strip() not in _PRICE_TYPES:
                    return None, {}
                d["price_type"] = str(raw.get("price_type")).strip()
            for k in _ITEM_FLAGS:
                if raw.get(k) is not None:
                    d[k] = 1 if str(raw[k]).strip() in ("1", "true", "on") else 0
            if raw.get("images") is not None:
                imgs = _norm_images(raw.get("images"))
                if imgs == "":
                    return None, {}
                d["images"] = imgs
            if raw.get("options") is not None:
                opts = raw.get("options")
                if isinstance(opts, str):          # idempotent re-parse
                    try:
                        opts = json.loads(opts)
                    except ValueError:
                        opts = None
                if not isinstance(opts, list) or len(opts) > 20:
                    return None, {}
                norm = []
                for o in opts:
                    if not isinstance(o, dict):
                        return None, {}
                    clean = {str(k)[:40]: (v if isinstance(v, (str, int, float)) else None)
                             for k, v in list(o.items())[:8]}
                    if not clean:
                        return None, {}
                    norm.append(clean)
                d["options"] = json.dumps(norm, ensure_ascii=False)[:4000]
            if raw.get("spec") is not None:
                spec = raw.get("spec")
                if isinstance(spec, str):          # idempotent re-parse
                    try:
                        spec = json.loads(spec)
                    except ValueError:
                        spec = None
                if not isinstance(spec, dict) or len(spec) > 20:
                    return None, {}
                clean = {str(k)[:60]: _s(v, 300) for k, v in list(spec.items())[:20]}
                d["spec"] = json.dumps(clean, ensure_ascii=False)[:4000]
            return name, {"id": iid, "data": d}

        if name == "review_moderate":
            rid = _i(a.get("id"))
            if not rid or rid <= 0:
                return None, {}
            action = str(a.get("action") or "").strip()
            if action not in ("approve", "reject"):
                return None, {}
            return name, {"id": rid, "action": action, "reply": _s(a.get("reply"), 500)}

        if name == "biz_moderate":
            bid = _i(a.get("id"))
            if not bid or bid <= 0:
                return None, {}
            action = str(a.get("action") or "").strip()
            if action not in ("approve", "reject", "hide", "show"):
                return None, {}
            return name, {"id": bid, "action": action}

        if name == "broadcast":
            text = str(a.get("text") or "").strip()
            if not text or len(text) > 500:
                return None, {}
            return name, {"text": text}

        # ---------------- v240 new tools ----------------

        if name == "coupon_save":
            cid = _i(a.get("id")) or 0
            if cid < 0:
                return None, {}
            biz_id = _i(a.get("biz_id")) or 0
            code = _s(a.get("code"), 40)
            title = _s(a.get("title"), 120)
            percent = _i(a.get("percent"))
            if not code or not title or percent is None or not (0 <= percent <= 99):
                return None, {}
            expires = _s(a.get("expires"), 20)
            if expires and not re.match(r"^\d{4}-\d{2}-\d{2}$", expires):
                return None, {}
            active = 1 if str(a.get("active", "1")).strip() in ("1", "true", "on") else 0
            return name, {"id": cid, "biz_id": biz_id, "code": code, "title": title,
                          "percent": percent, "expires": expires, "active": active}

        if name == "toplist_save":
            tid = _i(a.get("id")) or 0
            if tid < 0:
                return None, {}
            title = _s(a.get("title"), 120)
            if not title:
                return None, {}
            kind = str(a.get("kind") or "manual").strip()
            if kind not in _LIST_KINDS:
                return None, {}
            items = a.get("items")
            if items is None:
                items = []
            if not isinstance(items, list) or len(items) > 50:
                return None, {}
            ids = []
            for x in items:
                n = _i(x)
                if not n or n <= 0:
                    return None, {}
                ids.append(n)
            limit_n = _i(a.get("limit_n")) or 10
            if not (1 <= limit_n <= 50):
                return None, {}
            return name, {"id": tid, "title": title,
                          "descr": _s(a.get("descr"), 300), "kind": kind,
                          "items": ids, "limit_n": limit_n,
                          "sort": max(0, min(9999, _i(a.get("sort")) or 0)),
                          "active": 1 if str(a.get("active", "1")).strip() in ("1", "true", "on") else 0}

        if name == "flashdeal_save":
            did = _i(a.get("id")) or 0
            if did < 0:
                return None, {}
            biz_id = _i(a.get("biz_id"))
            if not biz_id or biz_id <= 0:
                return None, {}
            title = _s(a.get("title"), 120)
            percent = _i(a.get("percent"))
            ends = str(a.get("ends") or "").strip()
            if not title or percent is None or not (1 <= percent <= 99) or not ends:
                return None, {}
            for k in ("starts", "ends"):
                v = str(a.get(k) or "").strip()
                if v and not _DT_RX.match(v):
                    return None, {}
            return name, {"id": did, "biz_id": biz_id, "title": title,
                          "descr": _s(a.get("descr"), 500),
                          "percent": percent,
                          "starts": _s(a.get("starts"), 20), "ends": ends[:20],
                          "active": 1 if str(a.get("active", "1")).strip() in ("1", "true", "on") else 0}

        if name == "event_save":
            eid = _i(a.get("id")) or 0
            if eid < 0:
                return None, {}
            title = _s(a.get("title"), 120)
            if not title:
                return None, {}
            date = _s(a.get("date"), 10)
            tm = _s(a.get("time"), 5)
            if date and not re.match(r"^\d{4}-\d{2}-\d{2}$", date):
                return None, {}
            if tm and not _HHMM.match(tm):
                return None, {}
            image = _s(a.get("image"), 160)
            if image and not _image_ok(image):
                return None, {}
            status = str(a.get("status") or "published").strip()
            if status not in ("published", "hidden"):
                return None, {}
            biz_id = _i(a.get("biz_id")) or 0
            return name, {"id": eid, "title": title, "descr": _s(a.get("descr"), 1000),
                          "place": _s(a.get("place"), 120), "date": date, "time": tm,
                          "biz_id": biz_id, "image": image, "status": status}

        if name == "ad_save":
            aid = _i(a.get("id")) or 0
            if aid < 0:
                return None, {}
            title = _s(a.get("title"), 120)
            if not title:
                return None, {}
            url = _s(a.get("url"), 300)
            if url and not (url.startswith("/") or url.startswith("http://")
                            or url.startswith("https://")):
                return None, {}
            slot = str(a.get("slot") or "home").strip()
            if slot not in _AD_SLOTS:
                return None, {}
            image = _s(a.get("image"), 160)
            if image and not _image_ok(image):
                return None, {}
            for k in ("starts", "ends"):
                v = str(a.get(k) or "").strip()
                if v and not _DT_RX.match(v):
                    return None, {}
            weight = _i(a.get("weight")) or 1
            if not (1 <= weight <= 100):
                return None, {}
            return name, {"id": aid, "title": title, "body": _s(a.get("body"), 500),
                          "image": image, "url": url, "slot": slot,
                          "biz_id": _i(a.get("biz_id")) or 0,
                          "starts": _s(a.get("starts"), 20), "ends": _s(a.get("ends"), 20),
                          "weight": weight,
                          "active": 1 if str(a.get("active", "1")).strip() in ("1", "true", "on") else 0}

        if name == "plan_save":
            pid = _i(a.get("id")) or 0
            if pid < 0:
                return None, {}
            nm = _s(a.get("name"), 60)
            price = _i(a.get("price"))
            if not nm or price is None or price < 0:
                return None, {}
            months = _i(a.get("months")) or 12
            if not (1 <= months <= 36):
                return None, {}
            return name, {"id": pid, "name": nm, "slug": _s(a.get("slug"), 40),
                          "tagline": _s(a.get("tagline"), 200), "price": price,
                          "months": months,
                          "featured_slots": max(0, _i(a.get("featured_slots")) or 0),
                          "max_items": max(0, _i(a.get("max_items")) or 0),
                          "max_photos": max(0, _i(a.get("max_photos")) or 0),
                          "perks": _s(a.get("perks"), 1000),
                          "features": _s(a.get("features"), 200),
                          "badge_slug": _s(a.get("badge_slug"), 40),
                          "sort": max(0, min(9999, _i(a.get("sort")) or 0)),
                          "active": 1 if str(a.get("active", "1")).strip() in ("1", "true", "on") else 0}

        if name == "badge_save":
            bid = _i(a.get("id")) or 0
            if bid < 0:
                return None, {}
            nm = _s(a.get("name"), 60)
            if not nm:
                return None, {}
            color = _s(a.get("color"), 7) or "#059669"
            if not re.match(r"^#[0-9a-fA-F]{6}$", color):
                return None, {}
            return name, {"id": bid, "slug": _s(a.get("slug"), 40), "name": nm,
                          "icon": _s(a.get("icon"), 40) or "award", "color": color,
                          "descr": _s(a.get("descr"), 200),
                          "sort": max(0, min(9999, _i(a.get("sort")) or 0)),
                          "active": 1 if str(a.get("active", "1")).strip() in ("1", "true", "on") else 0}

        if name == "story_add":
            biz_id = _i(a.get("biz_id"))
            if not biz_id or biz_id <= 0:
                return None, {}
            image = str(a.get("image") or "").strip()
            if not image or not _image_ok(image):
                return None, {}
            kind = str(a.get("kind") or "image").strip()
            if kind not in ("image", "video"):
                return None, {}
            duration = _i(a.get("duration")) or 0
            if not (0 <= duration <= 60):
                return None, {}
            return name, {"biz_id": biz_id, "image": image,
                          "caption": _s(a.get("caption"), 200), "kind": kind,
                          "duration": duration}

        if name == "claim_moderate":
            cid = _i(a.get("id"))
            if not cid or cid <= 0:
                return None, {}
            action = str(a.get("action") or "").strip()
            if action not in ("approve", "reject"):
                return None, {}
            return name, {"id": cid, "action": action}

        if name == "ticket_reply":
            tid = _i(a.get("id"))
            if not tid or tid <= 0:
                return None, {}
            body = str(a.get("body") or "").strip()
            if not body or len(body) > 2000:
                return None, {}
            return name, {"id": tid, "body": body}

        if name == "customer_moderate":
            action = str(a.get("action") or "").strip()
            if action not in ("block", "unblock"):
                return None, {}
            phone = db.norm_phone(str(a.get("phone") or ""))
            if not phone:
                return None, {}
            return name, {"phone": phone, "action": action}

        if name == "order_status":
            oid = _i(a.get("id"))
            status = str(a.get("status") or "").strip()
            if not oid or oid <= 0 or status not in _ORDER_STATUSES:
                return None, {}
            return name, {"id": oid, "status": status}

        if name == "booking_status":
            kid = _i(a.get("id"))
            status = str(a.get("status") or "").strip()
            if not kid or kid <= 0 or status not in _BOOKING_STATUSES:
                return None, {}
            return name, {"id": kid, "status": status}

        if name == "area_rename":
            old = _s(a.get("old"), 60)
            new = _s(a.get("new"), 60)
            if not old or not new or old == new:
                return None, {}
            return name, {"old": old, "new": new}
    except Exception:
        return None, {}
    return None, {}


# ------------------------------------------------------------------ describe

_FA_ACTION = {"approve": "تأیید", "reject": "رد", "hide": "پنهان", "show": "نمایش",
              "block": "مسدود", "unblock": "رفع مسدودی"}


def tool_describe(tool, args):
    """Live one-liner for the confirm question. Never raises."""
    try:
        if tool == "code_list":
            return f"فهرست فایل‌های {(args.get('path') or 'ریشهٔ سایت')}"
        if tool == "code_read":
            return f"خواندن {args.get('path')} (خطوط {args.get('from_line')}–{args.get('to_line')})"
        if tool == "code_edit":
            return (f"ویرایش کد {args.get('path')} — "
                    f"{len(args.get('edits') or [])} جایگزینی"
                    + (f" ({args.get('summary')[:60]})" if args.get("summary") else ""))
        if tool == "code_write":
            what = "بازنویسی کامل" if os.path.isfile(
                os.path.join(CODE.ROOT, args.get("path") or "?")) else "ایجاد فایل"
            return f"{what}: {args.get('path')}"
        if tool == "code_revert":
            return f"برگشت {args.get('path')} به آخرین نسخهٔ پشتیبان"
        if tool == "code_search":
            return f"جست‌وجوی «{args.get('query')}» در کل کد سایت"
        if tool == "code_status":
            return "خواندن وضعیت واقعی صف و آخرین استقرارها"
        if tool == "ai_setup":
            m = args.get("model") or ""
            return (f"وصل‌کردن مغز {args.get('provider')}"
                    + (f" — مدل {m}" if m else "") + " (کلید تست‌شده)")
        if tool == "service_restart":
            return "راه‌اندازی مجدد سرویس سایت"
        if tool == "setting":
            return f"تغییر «{args.get('key')}» به «{str(args.get('value'))[:80]}»"
        if tool == "page":
            return f"نوشتن کامل صفحهٔ {args.get('slug')} («{args.get('title')}»)"
        if tool == "post_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} مقالهٔ «{args.get('title')}»"
        if tool == "post_delete":
            return f"حذف مقالهٔ #{args.get('id')}"
        if tool == "category_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} دستهٔ «{args.get('name')}»"
        if tool == "category_delete":
            return f"حذف دستهٔ #{args.get('id')}"
        if tool == "business_save":
            b = db._one("SELECT name FROM businesses WHERE id=?", (args.get("id"),))
            nm = (b or {}).get("name") or f"#{args.get('id')}"
            keys = "، ".join(sorted((args.get("fields") or {}).keys())[:6])
            return f"ویرایش «{nm}» ({keys})"
        if tool == "item_save":
            if args.get("id"):
                it = db._one("SELECT title FROM items WHERE id=?", (args.get("id"),))
                nm = (it or {}).get("title") or f"#{args.get('id')}"
                return f"ویرایش محصول «{nm}»"
            return f"ایجاد محصول «{(args.get('data') or {}).get('title') or ''}»"
        if tool == "item_delete":
            return f"حذف محصول #{args.get('id')}"
        if tool == "review_moderate":
            return f"{_FA_ACTION.get(args.get('action'))} نظر #{args.get('id')}"
        if tool == "review_delete":
            return f"حذف نظر #{args.get('id')}"
        if tool == "biz_moderate":
            b = db._one("SELECT name FROM businesses WHERE id=?", (args.get("id"),))
            nm = (b or {}).get("name") or f"#{args.get('id')}"
            return f"{_FA_ACTION.get(args.get('action'))} کسب‌وکار «{nm}»"
        if tool == "broadcast":
            body = str(args.get("text") or "")
            return f"ارسال پیام همگانی: «{body[:160]}»" + ("…" if len(body) > 160 else "")
        if tool == "coupon_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} کد تخفیف «{args.get('code')}» ({args.get('percent')}٪)"
        if tool == "coupon_delete":
            return f"حذف کد تخفیف #{args.get('id')}"
        if tool == "toplist_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} لیست «{args.get('title')}»"
        if tool == "toplist_delete":
            return f"حذف لیست #{args.get('id')}"
        if tool == "flashdeal_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} پیشنهاد ویژهٔ «{args.get('title')}» ({args.get('percent')}٪)"
        if tool == "flashdeal_delete":
            return f"حذف پیشنهاد ویژه #{args.get('id')}"
        if tool == "event_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} رویداد «{args.get('title')}»"
        if tool == "event_delete":
            return f"حذف رویداد #{args.get('id')}"
        if tool == "ad_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} بنر «{args.get('title')}»"
        if tool == "ad_delete":
            return f"حذف بنر #{args.get('id')}"
        if tool == "plan_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} پلن «{args.get('name')}» ({args.get('price')} تومان)"
        if tool == "plan_delete":
            return f"حذف پلن #{args.get('id')}"
        if tool == "badge_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} نشان «{args.get('name')}»"
        if tool == "badge_delete":
            return f"حذف نشان #{args.get('id')}"
        if tool == "story_add":
            b = db._one("SELECT name FROM businesses WHERE id=?", (args.get("biz_id"),))
            return f"استوری تازه برای «{(b or {}).get('name') or args.get('biz_id')}»"
        if tool == "story_delete":
            return f"حذف استوری #{args.get('id')}"
        if tool == "claim_moderate":
            c = db._one("SELECT b.name n FROM claims c JOIN businesses b ON b.id=c.biz_id "
                        "WHERE c.id=?", (args.get("id"),))
            return (f"{_FA_ACTION.get(args.get('action'))} درخواست تصاحب «{(c or {}).get('n') or ''}»")
        if tool == "ticket_reply":
            return f"پاسخ به تیکت #{args.get('id')}"
        if tool == "customer_moderate":
            return f"{_FA_ACTION.get(args.get('action'))} مشتری {args.get('phone')}"
        if tool == "order_status":
            return f"تغییر وضعیت سفارش #{args.get('id')} به {args.get('status')}"
        if tool == "booking_status":
            return f"تغییر وضعیت نوبت #{args.get('id')} به {args.get('status')}"
        if tool == "area_rename":
            return f"تغییر نام محلهٔ «{args.get('old')}» به «{args.get('new')}»"
        if tool == "trash_restore":
            r = db._one("SELECT title FROM trash WHERE id=?", (args.get("id"),))
            return f"بازیابی «{(r or {}).get('title') or args.get('id')}» از سطل"
    except Exception:
        pass
    return "این تغییر محتوا"


def fail_text(tool, why):
    """Owner-facing sentence for a precheck failure."""
    if isinstance(why, str) and why.startswith("akey"):
        if why == "akey:403":
            return ("این کلید توسط سرویس OpenAI رد شد (۴۰۳ — به‌احتمال زیاد محدودیت "
                    "منطقه‌ای سرور). راه‌حل: از سایتِ واسط کلید بگیر و این‌طور بفرست: "
                    "/کلید openai <آدرس-سایت> <کلید> gpt-6-astra")
        detail = why[4:].strip()
        return ("این کلید را سرویس هوش مصنوعی قبول نکرد" +
                (f" (کد {detail})" if detail else "") +
                "؛ از aistudio.google.com یا console.groq.com کلید تازه بساز و دوباره بفرست.")
    base = {"missing": "چنین موردی در سایت پیدا نشد؛ شناسه را دقیق بگو.",
            "already": "این مورد قبلاً بررسی/تغییر کرده و دیگر در صف نیست.",
            "never": "این کسب‌وکار هنوز منتشر نشده؛ اول باید از صف بررسی بگذرد.",
            "parent": "دستهٔ والد معتبر نیست.",
            "empty": "محتوایی برای نوشتن نبود.",
            "image": "عکسی در دسترس نیست؛ اول عکس را در همین گفتگو بفرست.",
            "key": "این کلید تنظیمات شناخته نشد؛ نام دقیق را از تنظیمات بخواه.",
            "path": "این مسیر مجاز نیست؛ با code_list فهرست واقعی را ببین.",
            "nomatch": "متنِ old در فایل پیدا نشد؛ اول فایل را با code_read بخوان و عیناً کپی کن.",
            "ambiguous": "متنِ old دو بار در فایل هست؛ با چند خط بیشتر حولش یکتایش کن.",
            "binary": "این فایل متنی نیست (یا قابل‌خواندن نیست).",
            "big": "این فایل/تغییر از حد مجاز بزرگ‌تر است؛ بخشی از آن را بخوان/ویرایش کن.",
            "rate": "همین الان راه‌اندازی مجدد در صف است؛ کمی صبر کن."}
    return base.get(why, "فعلاً نمی‌شود این کار را انجام داد؛ وضعیت را با «وضعیت» چک کن.")


# ------------------------------------------------------------------ precheck

def tool_precheck(tool, args):
    """Dry-run policy WITHOUT writing. Returns (ok, reason)."""
    try:
        if tool in ("code_list", "code_read", "code_edit", "code_write",
                    "code_revert", "code_search", "code_status", "ai_setup",
                    "service_restart"):
            return CODE.precheck(tool, args)
        if tool in ("broadcast",):
            return True, ""
        if tool == "setting":
            # v240 dynamic: the key must already exist in settings or be a
            # key the panel itself would write.
            row = db._one("SELECT key FROM settings WHERE key=?", (args.get("key"),))
            if row or args["key"] in TEXT_SETTINGS or args["key"] in TOGGLE_SETTINGS \
                    or args["key"] in FLOAT_SETTINGS or args["key"] in INT_SETTINGS:
                return True, ""
            return False, "key"
        if tool == "page":
            if args["slug"] in ("about", "rules"):
                return True, ""
            return (True, "") if db._one("SELECT slug FROM pages WHERE slug=?",
                                         (args["slug"],)) else (False, "missing")
        if tool == "post_save":
            if args.get("id") and not db._one("SELECT id FROM posts WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            if args.get("cover") and not _resolve_image(args["cover"]):
                return False, "image"
            return True, ""
        if tool == "post_delete":
            if not db._one("SELECT id FROM posts WHERE id=?", (args.get("id"),)):
                return False, "missing"
            return True, ""
        if tool == "category_save":
            if args.get("parent") and not db._one(
                    "SELECT id FROM categories WHERE slug=?", (args.get("parent"),)):
                return False, "parent"
            if args.get("id") and not db._one(
                    "SELECT id FROM categories WHERE id=?", (args.get("id"),)):
                return False, "missing"
            if args.get("image") and not _resolve_image(args["image"]):
                return False, "image"
            return True, ""
        if tool == "category_delete":
            if not db._one("SELECT id FROM categories WHERE id=?", (args.get("id"),)):
                return False, "missing"
            return True, ""
        if tool == "business_save":
            if not db._one("SELECT id FROM businesses WHERE id=?", (args.get("id"),)):
                return False, "missing"
            f = args.get("fields") or {}
            if f.get("cat_slug") and not db._one(
                    "SELECT id FROM categories WHERE slug=?", (f.get("cat_slug"),)):
                return False, "parent"
            if f.get("cover") and not _resolve_image(f["cover"]):
                return False, "image"
            if "images" in f:
                for p in json.loads(f["images"]):
                    if not _resolve_image(p):
                        return False, "image"
            return True, ""
        if tool == "item_save":
            if not db._one("SELECT id FROM businesses WHERE id=?",
                           ((args.get("data") or {}).get("biz_id"),)):
                return False, "missing"
            if args.get("id") and not db._one(
                    "SELECT id FROM items WHERE id=?", (args.get("id"),)):
                return False, "missing"
            if "images" in (args.get("data") or {}):
                for p in json.loads(args["data"]["images"]):
                    if not _resolve_image(p):
                        return False, "image"
            return True, ""
        if tool == "item_delete":
            if not db._one("SELECT id FROM items WHERE id=?", (args.get("id"),)):
                return False, "missing"
            return True, ""
        if tool == "review_moderate":
            r = db._one("SELECT status FROM reviews WHERE id=?", (args.get("id"),))
            if not r:
                return False, "missing"
            if r["status"] != "pending":
                return False, "already"
            return True, ""
        if tool == "review_delete":
            return (True, "") if db._one("SELECT id FROM reviews WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "biz_moderate":
            need = {"approve": "pending", "reject": "pending",
                    "hide": "published"}.get(args.get("action"))
            r = db._one("SELECT status,published_once FROM businesses WHERE id=?",
                        (args.get("id"),))
            if not r:
                return False, "missing"
            if args.get("action") == "show":
                if r["status"] != "hidden":
                    return False, "already"
                if not r["published_once"]:
                    return False, "never"
            elif r["status"] != need:
                return False, "already"
            return True, ""
        # ---------------- v240 ----------------
        if tool == "coupon_save":
            if args.get("id") and not db._one("SELECT id FROM coupons WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            if args.get("biz_id") and not db._one(
                    "SELECT id FROM businesses WHERE id=?", (args.get("biz_id"),)):
                return False, "missing"
            return True, ""
        if tool == "coupon_delete":
            return (True, "") if db._one("SELECT id FROM coupons WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "toplist_save":
            if args.get("id") and not db._one("SELECT id FROM toplists WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            if args.get("kind") == "manual" and args.get("items"):
                n = len(set(args["items"]))
                got = db._one("SELECT COUNT(*) c FROM businesses WHERE id IN (%s)"
                              % ",".join("?" * n), list(set(args["items"])))["c"]
                if got != n:
                    return False, "missing"
            return True, ""
        if tool == "toplist_delete":
            return (True, "") if db._one("SELECT id FROM toplists WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "flashdeal_save":
            if args.get("id") and not db._one("SELECT id FROM flashdeals WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            return (True, "") if db._one("SELECT id FROM businesses WHERE id=?",
                                         (args.get("biz_id"),)) else (False, "missing")
        if tool == "flashdeal_delete":
            return (True, "") if db._one("SELECT id FROM flashdeals WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "event_save":
            if args.get("id") and not db._one("SELECT id FROM cityevents WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            if args.get("biz_id") and not db._one(
                    "SELECT id FROM businesses WHERE id=?", (args.get("biz_id"),)):
                return False, "missing"
            if args.get("image") and not _resolve_image(args["image"]):
                return False, "image"
            return True, ""
        if tool == "event_delete":
            return (True, "") if db._one("SELECT id FROM cityevents WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "ad_save":
            if args.get("id") and not db._one("SELECT id FROM ads WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            if args.get("biz_id") and not db._one(
                    "SELECT id FROM businesses WHERE id=?", (args.get("biz_id"),)):
                return False, "missing"
            if args.get("image") and not _resolve_image(args["image"]):
                return False, "image"
            return True, ""
        if tool == "ad_delete":
            return (True, "") if db._one("SELECT id FROM ads WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "plan_save":
            if args.get("id") and not db._one("SELECT id FROM plans WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            return True, ""
        if tool == "plan_delete":
            return (True, "") if db._one("SELECT id FROM plans WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "badge_save":
            if args.get("id") and not db._one("SELECT id FROM badges WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            return True, ""
        if tool == "badge_delete":
            return (True, "") if db._one("SELECT id FROM badges WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "story_add":
            if not db._one("SELECT id FROM businesses WHERE id=?", (args.get("biz_id"),)):
                return False, "missing"
            if not _resolve_image(args.get("image")):
                return False, "image"
            return True, ""
        if tool == "story_delete":
            return (True, "") if db._one("SELECT id FROM stories WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "claim_moderate":
            r = db._one("SELECT status FROM claims WHERE id=?", (args.get("id"),))
            if not r:
                return False, "missing"
            if r["status"] != "pending":
                return False, "already"
            return True, ""
        if tool == "ticket_reply":
            return (True, "") if db._one("SELECT id FROM tickets WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "customer_moderate":
            return (True, "") if db._one("SELECT id FROM customers WHERE phone=?",
                                         (args.get("phone"),)) else (False, "missing")
        if tool == "order_status":
            return (True, "") if db._one("SELECT id FROM orders WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "booking_status":
            return (True, "") if db._one("SELECT id FROM bookings WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "area_rename":
            n = db._one("SELECT COUNT(*) c FROM businesses WHERE area=?",
                        (args.get("old"),))["c"]
            return (True, "") if n else (False, "missing")
        if tool == "trash_restore":
            return (True, "") if db._one("SELECT id FROM trash WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
    except Exception:
        return False, "error"
    return False, "error"


# ------------------------------------------------------------------ execute

def tool_execute(tool, args):
    """Run a validated tool through the site's own functions. Re-validates
    everything (parse + precheck), audit-logs, never raises.
    Returns (ok, message)."""
    try:
        tool, args = parse_tool_call({"name": tool, "args": args})
        if not tool:
            return False, "درخواست معتبر نبود؛ دوباره بگو."
        ok, why = tool_precheck(tool, args)
        if not ok:
            return False, fail_text(tool, why)

        if tool in ("code_list", "code_read", "code_edit", "code_write",
                    "code_revert", "code_search", "code_status", "ai_setup",
                    "service_restart"):
            ok2, msg = CODE.execute(tool, args)
            return (ok2, msg if ok2 else fail_text(tool, msg))
        if tool == "setting":
            db.set_setting(args["key"], args["value"])
            _v = ("<مقدار پنهان>" if _secretish(args["key"])
                  else str(args["value"])[:80])
            db.log("admin_ai_tool", f"setting {args['key']}={_v}")
            return True, f"✏️ «{args['key']}» ذخیره شد."
        if tool == "page":
            db.save_page(args["slug"], args["title"], args["body"])
            db.log("admin_ai_tool", f"page {args['slug']} title={args['title'][:40]}")
            return True, f"📄 صفحهٔ {args['slug']} کامل بازنویسی شد."
        if tool == "post_save":
            data = {"title": args["title"], "excerpt": args["excerpt"],
                    "body": args["body"], "status": args["status"]}
            if args["id"] and args.get("cover"):
                data["cover"] = _resolve_image(args["cover"]) or ""
            elif args["id"]:      # keep the existing cover
                cur = db._one("SELECT cover FROM posts WHERE id=?", (args["id"],))
                data["cover"] = (cur or {}).get("cover") or ""
            elif args.get("cover"):
                data["cover"] = _resolve_image(args["cover"]) or ""
            pid = db.save_post(data, pid=args["id"] or None)
            db.log("admin_ai_tool", f"post_save id={pid} {args['title'][:40]}")
            return True, f"📰 مقالهٔ «{args['title']}» ذخیره شد (#{pid})."
        if tool == "post_delete":
            db.delete_post(args["id"])
            db.log("admin_ai_tool", f"post_delete id={args['id']}")
            return True, f"🗑 مقالهٔ #{args['id']} حذف شد."
        if tool == "category_save":
            if args["id"]:      # merge unspecified columns from the live row
                cur = db._one("SELECT icon,blurb,sort,active,parent,image "
                              "FROM categories WHERE id=?", (args["id"],)) or {}
                data = {"name": args["name"],
                        "icon": args.get("icon") or cur.get("icon") or "store",
                        "blurb": args["blurb"] if "blurb" in args else (cur.get("blurb") or ""),
                        "sort": args["sort"] if "sort" in args else (cur.get("sort") or 0),
                        "active": args["active"] if "active" in args else (cur.get("active") or 1),
                        "parent": args["parent"] if "parent" in args else (cur.get("parent") or ""),
                        "image": (_resolve_image(args["image"]) if args.get("image")
                                  else (cur.get("image") or ""))}
            else:
                data = {"name": args["name"],
                        "icon": args.get("icon") or "store",
                        "blurb": args.get("blurb") or "",
                        "sort": args.get("sort") or 0,
                        "active": args.get("active", 1),
                        "parent": args.get("parent") or "",
                        "image": (_resolve_image(args["image"]) if args.get("image") else "")}
            cid = db.save_category(data, cid=args["id"] or None)
            db.log("admin_ai_tool", f"category_save id={cid} {args['name'][:40]}")
            return True, f"🗂 دستهٔ «{args['name']}» ذخیره شد (#{cid})."
        if tool == "category_delete":
            ok2, msg = db.delete_category(args["id"])
            if ok2:
                db.log("admin_ai_tool", f"category_delete id={args['id']}")
                return True, f"🗑 دستهٔ #{args['id']} حذف شد."
            return False, msg
        if tool == "business_save":
            fields = dict(args["fields"])
            if "cover" in fields and fields["cover"]:
                fields["cover"] = _resolve_image(fields["cover"])
            if "images" in fields and fields["images"]:
                fields["images"] = [_resolve_image(p) for p in json.loads(fields["images"])]
            bid = db.save_business(fields, bid=args["id"])
            b = db._one("SELECT name FROM businesses WHERE id=?", (bid,)) or {}
            db.log("admin_ai_tool",
                   f"business_save id={bid} fields={','.join(sorted(fields))}")
            return True, f"🏪 «{b.get('name') or bid}» به‌روز شد."
        if tool == "item_save":
            d = dict(args["data"])
            if "images" in d and d["images"]:
                d["images"] = [_resolve_image(p) for p in json.loads(d["images"])]
            iid = db.save_item(d, iid=args["id"] or None)
            db.log("admin_ai_tool",
                   f"item_save id={iid} biz={(args['data'] or {}).get('biz_id')}")
            return True, f"📦 محتوا ذخیره شد (#{iid})."
        if tool == "item_delete":
            it = db._one("SELECT title FROM items WHERE id=?", (args.get("id"),)) or {}
            db.delete_item(args["id"])
            db.log("admin_ai_tool", f"item_delete id={args['id']}")
            return True, f"🗑 «{it.get('title') or args['id']}» حذف شد (سطل بازیافت)."
        if tool == "review_moderate":
            if args["action"] == "approve":
                kw = {"status": "approved"}
                if args.get("reply"):
                    kw["reply"] = args["reply"]
                db.update_review(args["id"], **kw)
                db.log("admin_ai_tool", f"review_approve id={args['id']}")
                return True, f"✅ نظر #{args['id']} تأیید و منتشر شد."
            kw = {"status": "rejected"}
            if args.get("reply"):
                kw["reply"] = args["reply"]
            db.update_review(args["id"], **kw)
            db.review_reject_notify(args["id"])
            db.log("admin_ai_tool", f"review_reject id={args['id']}")
            return True, f"🚫 نظر #{args['id']} رد شد."
        if tool == "review_delete":
            db.delete_review(args["id"])
            db.log("admin_ai_tool", f"review_delete id={args['id']}")
            return True, f"🗑 نظر #{args['id']} حذف شد."
        if tool == "biz_moderate":
            act = args["action"]
            status = {"approve": "published", "reject": "rejected",
                      "hide": "hidden", "show": "published"}[act]
            b = db._one("SELECT name FROM businesses WHERE id=?", (args["id"],)) or {}
            db.save_business({"status": status}, bid=args["id"])
            db.log("admin_ai_tool", f"biz_{act} id={args['id']} {b.get('name') or ''}")
            return True, f"🏪 «{b.get('name') or args['id']}» → {status}."
        if tool == "broadcast":
            n = db.notify_all("info", args["text"], "")
            db.log("admin_ai_tool", f"broadcast n={n}")
            return True, f"📣 اعلان برای {n} مشتری ارسال شد."
        # ---------------- v240 ----------------
        if tool == "coupon_save":
            if args["id"]:
                con = db.connect()
                con.execute("UPDATE coupons SET biz_id=?,code=?,title=?,percent=?,"
                            "expires=?,active=? WHERE id=?",
                            (args["biz_id"] or None, args["code"], args["title"],
                             args["percent"], args["expires"], args["active"], args["id"]))
                con.commit(); con.close()
                cid = args["id"]
            else:
                cid = db._run("INSERT INTO coupons(biz_id,code,title,percent,expires,active) "
                              "VALUES(?,?,?,?,?,?)",
                              (args["biz_id"] or None, args["code"], args["title"],
                               args["percent"], args["expires"], args["active"]))
            db.log("admin_ai_tool", f"coupon_save id={cid} {args['code']}")
            return True, f"🎟 کد «{args['code']}» ذخیره شد (#{cid})."
        if tool == "coupon_delete":
            db._run("DELETE FROM coupons WHERE id=?", (args["id"],))
            db.log("admin_ai_tool", f"coupon_delete id={args['id']}")
            return True, f"🗑 کد تخفیف #{args['id']} حذف شد."
        if tool == "toplist_save":
            data = {"title": args["title"], "descr": args["descr"], "kind": args["kind"],
                    "items": args["items"], "limit_n": args["limit_n"],
                    "sort": args["sort"], "active": args["active"]}
            tid = features.save_toplist(data, tid=args["id"] or None)
            db.log("admin_ai_tool", f"toplist_save id={tid} {args['title'][:40]}")
            return True, f"🏆 لیست «{args['title']}» ذخیره شد (#{tid})."
        if tool == "toplist_delete":
            features.delete_toplist(args["id"])
            db.log("admin_ai_tool", f"toplist_delete id={args['id']}")
            return True, f"🗑 لیست #{args['id']} حذف شد."
        if tool == "flashdeal_save":
            data = {"biz_id": args["biz_id"], "title": args["title"],
                    "descr": args["descr"], "percent": args["percent"],
                    "starts": args["starts"], "ends": args["ends"], "active": args["active"]}
            did = features.save_flashdeal(data, did=args["id"] or None)
            db.log("admin_ai_tool", f"flashdeal_save id={did} {args['title'][:40]}")
            return True, f"⚡ پیشنهاد «{args['title']}» ذخیره شد (#{did})."
        if tool == "flashdeal_delete":
            features.delete_flashdeal(args["id"])
            db.log("admin_ai_tool", f"flashdeal_delete id={args['id']}")
            return True, f"🗑 پیشنهاد #{args['id']} حذف شد."
        if tool == "event_save":
            data = {"title": args["title"], "descr": args["descr"], "place": args["place"],
                    "date": args["date"], "time": args["time"],
                    "biz_id": args["biz_id"] or None,
                    "image": (_resolve_image(args["image"]) if args["image"] else ""),
                    "status": args["status"]}
            eid = db.save_cityevent(data, eid=args["id"] or None)
            db.log("admin_ai_tool", f"event_save id={eid} {args['title'][:40]}")
            return True, f"🎉 رویداد «{args['title']}» ذخیره شد (#{eid})."
        if tool == "event_delete":
            db.delete_cityevent(args["id"])
            db.log("admin_ai_tool", f"event_delete id={args['id']}")
            return True, f"🗑 رویداد #{args['id']} حذف شد."
        if tool == "ad_save":
            data = {"title": args["title"], "body": args["body"],
                    "image": (_resolve_image(args["image"]) if args["image"] else ""),
                    "url": args["url"], "slot": args["slot"],
                    "biz_id": args["biz_id"] or None, "starts": args["starts"],
                    "ends": args["ends"], "weight": args["weight"], "active": args["active"]}
            aid = db.save_ad(data, aid=args["id"] or None)
            db.log("admin_ai_tool", f"ad_save id={aid} {args['title'][:40]}")
            return True, f"📢 بنر «{args['title']}» ذخیره شد (#{aid})."
        if tool == "ad_delete":
            db.delete_ad(args["id"])
            db.log("admin_ai_tool", f"ad_delete id={args['id']}")
            return True, f"🗑 بنر #{args['id']} حذف شد."
        if tool == "plan_save":
            data = dict(args)
            pid = db.save_plan(data, pid=args["id"] or None)
            db.log("admin_ai_tool", f"plan_save id={pid} {args['name'][:40]}")
            return True, f"💳 پلن «{args['name']}» ذخیره شد (#{pid})."
        if tool == "plan_delete":
            ok2, msg = db.delete_plan(args["id"])
            if ok2:
                db.log("admin_ai_tool", f"plan_delete id={args['id']}")
                return True, f"🗑 پلن #{args['id']} حذف شد."
            return False, msg
        if tool == "badge_save":
            data = dict(args)
            bid = db.save_badge(data, bid=args["id"] or None)
            db.log("admin_ai_tool", f"badge_save id={bid} {args['name'][:40]}")
            return True, f"🏅 نشان «{args['name']}» ذخیره شد (#{bid})."
        if tool == "badge_delete":
            db.delete_badge(args["id"])
            db.log("admin_ai_tool", f"badge_delete id={args['id']}")
            return True, f"🗑 نشان #{args['id']} حذف شد."
        if tool == "story_add":
            img = _resolve_image(args["image"])
            if not img:
                return False, fail_text(tool, "image")
            features.stories_add(args["biz_id"], img, args["caption"],
                                 args["kind"], args["duration"])
            db.log("admin_ai_tool", f"story_add biz={args['biz_id']} image={img[:60]}")
            return True, "📸 استوری ثبت شد (۲۴ ساعت)."
        if tool == "story_delete":
            db._run("DELETE FROM stories WHERE id=?", (args["id"],))
            db.log("admin_ai_tool", f"story_delete id={args['id']}")
            return True, f"🗑 استوری #{args['id']} حذف شد."
        if tool == "claim_moderate":
            approve = args["action"] == "approve"
            if not db.claim_decide(args["id"], approve):
                return False, fail_text(tool, "missing")
            db.log("admin_ai_tool", f"claim_{args['action']} id={args['id']}")
            return True, ("🔑 کسب‌وکار واگذار شد." if approve else "درخواست تصاحب رد شد.")
        if tool == "ticket_reply":
            mid = db.ticket_reply(args["id"], args["body"])
            if not mid:
                return False, "پاسخ ثبت نشد؛ دوباره بگو."
            db.log("admin_ai_tool", f"ticket_reply id={args['id']} msg={mid}")
            return True, f"💬 پاسخ به تیکت #{args['id']} ارسال شد."
        if tool == "customer_moderate":
            c = db._one("SELECT id FROM customers WHERE phone=?", (args["phone"],))
            if not c or not features.customer_set_status(c["id"], "blocked" if args["action"] == "block" else "active"):
                return False, fail_text(tool, "missing")
            db.log("admin_ai_tool", f"customer_{args['action']} {args['phone']}")
            return True, (f"⛔ مشتری {args['phone']} مسدود شد."
                          if args["action"] == "block"
                          else f"✅ مسدودی مشتری {args['phone']} برداشته شد.")
        if tool == "order_status":
            db._run("UPDATE orders SET status=? WHERE id=?", (args["status"], args["id"]))
            db.log("admin_ai_tool", f"order_status id={args['id']} -> {args['status']}")
            return True, f"📦 سفارش #{args['id']} → {args['status']}."
        if tool == "booking_status":
            if not db.update_booking(args["id"], status=args["status"]):
                return False, "وضعیت نوبت معتبر نیست."
            db.log("admin_ai_tool", f"booking_status id={args['id']} -> {args['status']}")
            return True, f"📅 نوبت #{args['id']} → {args['status']}."
        if tool == "area_rename":
            n = features.rename_area(args["old"], args["new"])
            db.log("admin_ai_tool", f"area_rename '{args['old']}'->'{args['new']}' n={n}")
            return True, f"📍 نام محله عوض شد ({n} کسب‌وکار)."
        if tool == "trash_restore":
            if not db.trash_restore(args["id"]):
                return False, fail_text(tool, "missing")
            db.log("admin_ai_tool", f"trash_restore id={args['id']}")
            return True, "♻️ از سطل بازیافت برگشت."
    except Exception as e:
        print("adminbot_content execute error:", e, flush=True)
        return False, "خطای داخلی؛ تغییر انجام نشد."
    return False, "این ابزار شناخته نشد."


# ------------------------------------------------------------------ snapshot

def content_inventory():
    """Compact live listing of editable content so the model can ground its
    proposals (real ids, real current texts). Never raises; no secrets."""
    try:
        s = db.get_settings()
        txt = " · ".join(f"{k}={str(s.get(k) or '')[:60]}" for k in
                        ("tagline", "hero_title", "hero_cta", "footer_note"))
        cats = db._rows("SELECT id,slug,name,active,parent FROM categories "
                        "ORDER BY sort,id LIMIT 40")
        catline = " · ".join(f"#{r['id']} {r['name']}" + ("" if r["active"] else " (خاموش)")
                             for r in cats) or "—"
        posts = db._rows("SELECT id,title,status FROM posts ORDER BY id DESC LIMIT 10")
        postline = " · ".join(f"#{r['id']} {r['title']}" for r in posts) or "—"
        bizs = db._rows("SELECT id,name,status FROM businesses ORDER BY id DESC LIMIT 15")
        bizline = " · ".join(f"#{r['id']} {r['name']} ({r['status']})" for r in bizs) or "—"
        items = db._rows("SELECT COUNT(*) c FROM items")
        about = db.get_page("about")
        rules = db.get_page("rules")
        out = ("محتوای متن: " + (txt or "—") +
               f"\nدسته‌ها (تا ۴۰): {catline}" +
               f"\nمقاله‌ها (۱۰ اخیر): {postline}" +
               f"\nکسب‌وکارها (۱۵ اخیر): {bizline}" +
               f"\nمحصولات: {items[0]['c'] if items else '?'}" +
               f"\nصفحات: about «{about.get('title') or ''}» ({len(about.get('body') or '')} نویسه)" +
               f" · rules «{rules.get('title') or ''}» ({len(rules.get('body') or '')} نویسه)")
        # v240: the rest of the panel's editable surfaces
        try:
            coupons = db._rows("SELECT id,code,percent,active FROM coupons ORDER BY id DESC LIMIT 8")
            out += "\nکدهای تخفیف: " + (" · ".join(
                f"#{r['id']} {r['code']} {r['percent']}٪" + ("" if r["active"] else " (خاموش)")
                for r in coupons) or "—")
        except Exception:
            pass
        try:
            lists = db._rows("SELECT id,title,kind,active FROM toplists ORDER BY id LIMIT 10")
            out += "\nلیست‌ها: " + (" · ".join(
                f"#{r['id']} {r['title']} ({r['kind']})" for r in lists) or "—")
        except Exception:
            pass
        try:
            deals = db._rows("SELECT id,title,percent FROM flashdeals ORDER BY id DESC LIMIT 6")
            out += "\nپیشنهادها: " + (" · ".join(
                f"#{r['id']} {r['title']} {r['percent']}٪" for r in deals) or "—")
        except Exception:
            pass
        try:
            evs = db._rows("SELECT id,title,date FROM cityevents ORDER BY id DESC LIMIT 6")
            out += "\nرویدادها: " + (" · ".join(
                f"#{r['id']} {r['title']} {r['date']}" for r in evs) or "—")
        except Exception:
            pass
        try:
            ads = db._rows("SELECT id,title,slot,active FROM ads ORDER BY id DESC LIMIT 6")
            out += "\nبنرها: " + (" · ".join(
                f"#{r['id']} {r['title']} [{r['slot']}]" for r in ads) or "—")
        except Exception:
            pass
        try:
            plans = db._rows("SELECT id,slug,name,price,active FROM plans ORDER BY sort,id")
            out += "\nپلن‌ها: " + (" · ".join(
                f"#{r['id']} {r['name']} {r['price']}ت" for r in plans) or "—")
        except Exception:
            pass
        try:
            badges = db._rows("SELECT id,slug,name FROM badges WHERE active=1 ORDER BY sort LIMIT 10")
            out += "\nنشان‌ها: " + (" · ".join(f"#{r['id']} {r['name']}" for r in badges) or "—")
        except Exception:
            pass
        try:
            clm = db._rows("SELECT c.id, b.name FROM claims c JOIN businesses b ON b.id=c.biz_id "
                           "WHERE c.status='pending' ORDER BY c.id DESC LIMIT 5")
            out += "\nتصاحب در انتظار: " + (" · ".join(
                f"#{r['id']} {r['name']}" for r in clm) or "—")
        except Exception:
            pass
        try:
            tix = db._rows("SELECT id,subject FROM tickets WHERE status<>'closed' ORDER BY id DESC LIMIT 5")
            out += "\nتیکت‌های باز: " + (" · ".join(
                f"#{r['id']} {(r['subject'] or '')[:30]}" for r in tix) or "—")
        except Exception:
            pass
        img = image_last()
        out += ("\nآخرین عکس ارسالی مدیر: " + img + " (برای استفاده: image=\"__last__\")"
                if img else "\nعکسی از مدیر در دسترس نیست (برای عکس، خودت در بات عکس بفرست)")
        try:
            out += "\n" + CODE.code_status_text()[:400]
        except Exception:
            pass
        return out
    except Exception:
        return "محتوا: خوانده نشد"
