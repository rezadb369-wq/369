#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v251: «همه‌جا کم‌دسترسی بود» — دسترسی مدیر باز شد + هشدار نسخه درست شد.

Owner's live directions (2026-09-10, after the first real تشخیص report):
1) «کلا همه جا خیلی کم دسترسی داشت» → the bot lane opens: site_name is
   owner-renamable (v179 brand contract retired by owner decision), service
   keys (tg_token/sms_key/gmaps_key…) are bot-writable with an explicit
   «بله» and values never logged. Only auth/lockout keys stay fenced.
2) «کلا چت جی پی تی جایگزین بشه و قبلی حذف» → codeguard no longer keeps
   the old brain as AI_FALLBACK; old fallback lines are wiped on install.
3) تشخیص line 1 hardcoded «۲۴۹» and lied «قدیمی‌تر» at v250 → DIAG_LATEST
   constant, pinned to VERSION.txt by a test so it can never drift again.
"""
import os, sys, json, time, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v251-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
SCRIPT = []
def fake_chat(*a, **k):
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]
P = lambda name, args: json.dumps(
    {"reply": "می‌خواهم این کار را بکنم.", "tool": {"name": name, "args": args}},
    ensure_ascii=False)
S = lambda key, value: {"name": "setting", "args": {"key": key, "value": value}}

# ================= 1. DIAG_LATEST pinned to VERSION.txt — never drift again
ver = (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip()
ck(ver == A.DIAG_LATEST,
   f'DIAG_LATEST ({A.DIAG_LATEST}) == VERSION.txt ({ver}) — line 1 can never lie')
r = t('تشخیص')
ck('به‌روز' in r and 'قدیمی‌تر' not in r,
   'تشخیص line 1: running version reports «به‌روز» (the v250 bug is dead)')
ck('۲) مغز هوش مصنوعی' in r and '۳) کرون' in r, 'تشخیص structure intact')

# ================= 2. site_name: the owner renames their site — E2E
SCRIPT.append(P('setting', {"key": "site_name", "value": "بازار من"}))
r = t('اسم سایت را بشکن بازار من')
ck('تأیید' in r and 'شناخته نشد' not in r, 'site_name proposal accepted')
t('بله')
ck(db.get_settings().get('site_name') == 'بازار من',
   'site_name actually renamed in DB after «بله»')
ck(len(db.get_settings()['site_name']) <= 60, 'site_name cap 60 respected')

# ================= 3. service keys: writable with «بله», never logged
SCRIPT.append(P('setting', {"key": "gmaps_key", "value": "AIza-test-key-123"}))
r = t('کلید نقشهٔ گوگل را بگذار')
ck('تأیید' in r and 'AIza-test-key-123' in r,
   'gmaps_key confirm SHOWS the value (owner verifies before «بله»)')
t('بله')
ck(db.get_settings().get('gmaps_key') == 'AIza-test-key-123',
   'gmaps_key written to DB')
row = db.connect().execute(
    "SELECT detail FROM audit WHERE action='admin_ai_tool' "
    "ORDER BY rowid DESC LIMIT 1").fetchone()
ck(row and 'gmaps_key' in row[0] and 'AIza-test-key-123' not in row[0],
   'audit log stores the KEY NAME but never the secret value')

# ================= 4. auth/lockout keys stay fenced — with their names
for k in ('owner_token', 'owner_pass_hash', 'panel_allow_ips', 'admin_bot'):
    nm, _ = CT.parse_tool_call(S(k, 'x'))
    ck(nm is None and k in CT.reject_reason(S(k, 'x')),
       f'{k}: refused AND the reason names the key')

# ================= 5. reads stay redacted (write-yes / read-never)
snap = A.admin_snapshot()
txt = json.dumps(snap, ensure_ascii=False, default=str)
ck('AIza-test-key-123' not in txt and 'k-test' not in txt,
   'admin snapshot never exposes secret values to the model')

# ================= 6. codeguard: full replacement, no fallback (owner order)
cg = (ROOT / 'deploy' / 'codeguard.sh').read_text(encoding='utf-8')
ck('AI_FALLBACK_BASE_URL=" + old_base' not in cg and
   'keep the old brain as fallback' not in cg,
   'codeguard no longer preserves the old brain as fallback')
ck('"AI_FALLBACK_BASE_URL=", "AI_FALLBACK_API_KEY=", "AI_FALLBACK_MODEL="' in cg,
   'codeguard actively WIPES old AI_FALLBACK_* lines on every key install')

# ================= 7. panel accepts site_name (regression for the unlock)
import views_panel as VP, views_panel2 as VP2
s = db.get_settings()
h1 = VP.settings_page(s, 'token')
h2 = VP2.editor_page(s, 'token')
ck('name="site_name"' in h1 and 'value="بازار من"' in h1,
   'settings panel shows an editable site_name with the chosen value')
ck('name="site_name"' in h2 and 'value="بازار من"' in h2,
   'editor panel shows an editable site_name with the chosen value')

# ================= 8. quick regressions of the v250 lanes
ck(CT.parse_tool_call(S('reviews_moderated', 'فعال'))[1]['value'] == '1',
   'toggle «فعال» still maps to 1')
ck('بین 2 و 19' in CT.reject_reason(S('map_zoom', '42')),
   'numeric range reason intact')
r = t('/کلید aa-fake' + 'k' * 44)
ck('/کلید openai' in r and 'gpt-6-astra' in r, 'aa- gateway hint intact')

# ================= 9. boot does NOT revert the chosen name (fresh init)
db.set_setting('site_name', 'نام انتخابی')
import importlib
db.init()          # idempotent re-init runs the boot migrations
ck(db.get_settings().get('site_name') == 'نام انتخابی',
   're-running boot migrations keeps the owner-chosen name')

print(f'v251 owner access: {n} checks green')
