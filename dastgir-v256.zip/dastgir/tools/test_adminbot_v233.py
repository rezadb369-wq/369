#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v233 admin bot (owner-only Bale bot over webhook) -- offline tests.

Covers: stranger denial, help+keyboard, status/traffic/db/sys/errors/log/
report replies, backup/restart queueing, restart two-step confirm (yes/no/
expiry), command aliases, queue whitelist, update entry (private/stranger/
group/no-message), and the date/size helpers. No network: the URL fetch and
the cert getter are stubbed, sqlite runs in a temp dir.
"""
import os, sys, tempfile, time, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='adm-v233-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))  # v238: assistant/layout
import db, adminbot as A
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
REAL_G_CERT = A.g_cert
A.g_cert = lambda: '42'
A.NGINX_ACCESS = os.path.join(TMP, 'no-access.log')
A.NGINX_ERROR = os.path.join(TMP, 'no-error.log')
A.OFFSITE_LOG = os.path.join(TMP, 'no-offsite.log')
A.WATCHDOG_LOG = os.path.join(TMP, 'no-watchdog.log')

db.init()
CHAT = '893219571'

# ---- 1. owner gate + help/keyboard
t, m = A.handle_text('u1', '111', 'وضعیت')
ck(t.startswith('⛔') and m is None, 'stranger chat denied, no keyboard')
t, m = A.handle_text('u1', 893219571, 'راهنما')
ck('دستورات' in t and isinstance(m, dict) and any('وضعیت' in row for row in m['keyboard']),
   'numeric owner chat id accepted; help carries button keyboard')

# ---- 2. status + aliases (network stubbed)
t, _ = A.handle_text('u1', CHAT, 'وضعیت')
ck('وضعیت دستگیر (v%s)' % A.g_ver() in t and '🔒 گواهی: 42 روز' in t and '✅ بالا' in t,
   'status shows version, stubbed cert days, site up')
t2, _ = A.handle_text('u1', CHAT, '/status')
ck('وضعیت دستگیر' in t2, '/status alias works')

# ---- 3. db stats on seeded rows
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status) VALUES('t-shop','تست','services','published')")
con.execute("INSERT INTO bookings(biz_id,name,phone,date,time,status) VALUES(1,'a','p','1405/06/18','10:00','new')")
con.execute("INSERT INTO customers(phone,name) VALUES('09120000000','تستی')")
con.commit(); con.close()
t, _ = A.handle_text('u1', CHAT, 'دیتابیس')
ck('۱' not in t and '1 کل' in t and '1 جدید' in t and 'مشتری: 1' in t, 'seeded booking+customer counted')
t, _ = A.handle_text('u1', CHAT, '/db')
ck('🗄 دیتابیس' in t, '/db alias works')

# ---- 4. traffic/sys/errors/log degrade cleanly without prod files
t, _ = A.handle_text('u1', CHAT, 'آمار')
ck('پیدا نشد' in t, 'missing nginx log degrades to a clear message')
t, _ = A.handle_text('u1', CHAT, 'سیستم')
ck('🖥 سیستم' in t and 'لود:' in t and 'رم:' in t, 'sys reply renders without prod logs')
t, _ = A.handle_text('u1', CHAT, 'خطا')
ck('ندارد ✅' in t, 'no journal errors renders clean')
t, _ = A.handle_text('u1', CHAT, 'لاگ')
ck('خالی' in t, 'missing logs render as empty')
t, _ = A.handle_text('u1', CHAT, 'گزارش')
ck('📋 گزارش دستگیر' in t and 'نوبت جدید: 1' in t, 'report composes sections')

# ---- 5. backup queueing
t, _ = A.handle_text('u1', CHAT, 'بکاپ')
files = sorted(Path(os.environ['ADMINBOT_QUEUE']).glob('*.json'))
ck('صف اجرا' in t and len(files) == 1 and json.loads(files[0].read_text())['cmd'] == 'backup',
   'backup writes one queue file and acks')

# ---- 6. restart two-step confirm
t, _ = A.handle_text('u1', CHAT, 'ریستارت')
ck('بفرست: بله' in t and Path(os.environ['ADMINBOT_PENDING']).exists(), 'restart asks, pending stored')
t, _ = A.handle_text('u1', CHAT, 'بله')
files = sorted(Path(os.environ['ADMINBOT_QUEUE']).glob('*.json'))
ck('صف اجرا' in t and len(files) == 2 and not Path(os.environ['ADMINBOT_PENDING']).exists(),
   'yes queues restart and clears pending')
Path(os.environ['ADMINBOT_PENDING']).write_text(json.dumps({'exp': 1}))
t, _ = A.handle_text('u1', CHAT, 'بله')
ck('منقضی' in t, 'stale confirm expires')
A.handle_text('u1', CHAT, 'ریستارت')
t, _ = A.handle_text('u1', CHAT, 'خیر')
ck('لغو شد' in t and not Path(os.environ['ADMINBOT_PENDING']).exists(), 'no cancels pending')
A.handle_text('u1', CHAT, 'ریستارت')
A.handle_text('u1', CHAT, 'وضعیت')
ck(not Path(os.environ['ADMINBOT_PENDING']).exists(), 'any other command clears pending')
ck(A.queue_write('rm -rf') is False, 'queue rejects non-whitelisted commands')

# ---- 7. unknown + empty (v238: routed to the copilot; unconfigured here)
t, _ = A.handle_text('u1', CHAT, 'سلام')
ck('وصل نیست' in t and '/کلید' in t, 'unknown text gets the AI setup guide')
t, _ = A.handle_text('u1', CHAT, '')
ck('وصل نیست' in t or t == '', 'empty text gets the AI setup guide')

# ---- 8. update entry
sent = []
A.send_message = lambda cid, text, markup=None: sent.append((str(cid), text, markup)) or True
upd = lambda mid, cid, text, typ='private': {'update_id': mid, 'message': {
    'message_id': 1, 'from': {'id': 'u1'}, 'chat': {'id': cid, 'type': typ}, 'text': text}}
A.handle_update(upd(1, 893219571, 'راهنما'))
ck(len(sent) == 1 and sent[0][0] == CHAT and sent[0][2] is not None, 'private owner update answered with keyboard')
A.handle_update(upd(2, '111', 'وضعیت'))
ck(len(sent) == 2 and sent[1][1].startswith('⛔'), 'stranger update gets denied')
A.handle_update(upd(3, 893219571, 'وضعیت', 'group'))
A.handle_update({'update_id': 4})
ck(len(sent) == 2, 'group and message-less updates ignored')

# ---- 9. backup freshness reads content+mtime, FAIL-last wins
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-09 20:39:01 Transferred: 1.1M\n2026-09-09 20:40:01 OK: db=1138720B\n')
ck('دقیقه پیش ✅' in A.g_backup(), 'fresh OK log reads fresh')
Path(A.OFFSITE_LOG).write_text('2026-09-09 20:40:01 OK: db=1138720B\n2026-09-09 20:41:01 FAIL: connection refused\n')
ck(A.g_backup() == 'خطا! 🚨', 'FAIL-last overrides older OK')
Path(A.OFFSITE_LOG).write_text('2026-09-09 20:40:01 OK: db=1138720B\n')
os.utime(A.OFFSITE_LOG, (time.time() - 3 * 3600,) * 2)
ck(A.g_backup() == '3 ساعت پیش ✅', 'old OK log reads in hours')

# ---- 10. helpers
ck(A._human(1138720) == '1.1M' and A._human(2048) == '2K' and A._human(500) == '500B',
   'byte sizes format like the old bot')
ck((A._days_until('2030-01-01') or 0) > 1000 and A._days_until('not a date') is None,
   'days-until parses real dates, rejects garbage')

# ---- 11. v236: cert pipeline runs the real openssl calls (s_client stubbed, x509 real)
CERT_PEM = """-----BEGIN CERTIFICATE-----
MIIDETCCAfmgAwIBAgIUN6QYRltUsXyyJGSJM5XqNLOgaL0wDQYJKoZIhvcNAQEL
BQAwFzEVMBMGA1UEAwwMZGFzdGdpci10ZXN0MCAXDTI2MDkwOTIwNDcwNloYDzIx
MjYwODE2MjA0NzA2WjAXMRUwEwYDVQQDDAxkYXN0Z2lyLXRlc3QwggEiMA0GCSqG
SIb3DQEBAQUAA4IBDwAwggEKAoIBAQDitJSSXq0VDSL2iBfdCPQn8rGpvvtIyapl
0+FJHEZxXR7gSQqtMiK6157l0D/jGBBunFEtTF6NLoMICn305zs0M8qmipIP7Xse
D2p6sRnGAFQyaOe25Q/fBbUDKGB8mV8bS2iOfnbVfqzECJ2KqiyqIqX+jigutryM
xJhN73mWwRqpgb9LG6fDcasvhqiI0REMB5qa10qMA6+E3UKuuKS91W+qQK6Za4kJ
vedbORPYoywvAydIxoBEO2btgSnItQdQb0+lkXsCP3xYsVrTMW10VpLdVooIHB8C
YUys0dK6Q+qHpjlI0yaMekDYEHOBR/TlzNVIW9+7Xh1uSEYz1RgpAgMBAAGjUzBR
MB0GA1UdDgQWBBQcH4iAA50yWycfL1zcAGUSnH2rGTAfBgNVHRMEGDAWgBQcH4iA
A50yWycfL1zcAGUSnH2rGTAPBgNVHRMBAf8EBTADAQH/MA0GCSqGSIb3DQEBCwUA
A4IBAQBFx2TzeisXErnRCKmMQUmIhmufxLl8oTK8DIq865514tHg4X9ZASY/itaU
hCb11jP1Doct6AAVyh6h2/bgLPj7eylUp66FBSuL3BnzRMzyPwtd99VNpAJ+PpFM
AZKGELHYRlBF3Qp/WWpFVvp3Bf3BgV1fpkxycdZPVjfovnqC651mRdaM7AkPLAyl
5ITnhmK7mYzYhPrWK4w+URThkB4Pjqmo164DHOFJ35JCj0j5NVaIUVLdutCvjdWu
NN0CA572rQCkFjZJtnR7CyEoRNpWNON7d0QrGt8HzOwWzrehrCvCfBLK1N1Ry+NY
JxBsmSdBxUQetGwzCsoI38AKSk8z
-----END CERTIFICATE-----"""
import shutil as _shutil_v236
if _shutil_v236.which('openssl') and _shutil_v236.which('date'):
    _CANNED = 'CONNECTED(00000003)\ndepth=0 CN = daastgir.ir\n' + CERT_PEM + '\n---\nDONE\n'
    _real_run = A._run
    def _fake_run(args, timeout=10, canned=_CANNED):
        if args and args[0] == 'openssl' and 's_client' in args:
            return canned
        return _real_run(args, timeout=timeout)
    A.g_cert = REAL_G_CERT
    A._run = _fake_run
    try:
        _got = A.g_cert()
    finally:
        A._run = _real_run
    ck(_got != '?' and int(_got) > 30000, 'cert pipeline parses enddate without ValueError')
    A._run = lambda args, timeout=10: '' if (args and args[0] == 'openssl') else _real_run(args, timeout=timeout)
    try:
        ck(A.g_cert() == '?', 'empty s_client output yields ?')
    finally:
        A._run = _real_run
        A.g_cert = lambda: '42'
else:
    print('  \u2013 cert pipeline skipped (no openssl/date)')

print(f'v233: {n} checks passed')
