#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v247: trying a ChatGPT/OpenAI key must be frictionless:
  /کلید chatgpt sk-…        → direct OpenAI brain (gpt-6-astra)
  /کلید gpt sk-…            → same
  403 from OpenAI (region-blocked server) → clear reseller guidance
  /کلید (bare)              → shows the CURRENT brain + all forms
"""
import os, sys, json, tempfile, urllib.error
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v247-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
SCRIPT = []
def fake_chat(*a, **k):
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]
def jobs():
    d = os.path.join(TMP, 'code-jobs')
    return [json.load(open(os.path.join(d, x), encoding='utf-8'))
            for x in sorted(os.listdir(d))] if os.path.isdir(d) else []

SK = "sk-chatgpt" + "z" * 30

# ================= 1. /کلید chatgpt sk-… → direct astra brain
r = t('/کلید chatgpt ' + SK)
ck('صف' in r and SK not in r, 'chatgpt alias accepted, key hidden')
ck(any(j['kind'] == 'ai_key' and j['provider'] == 'astra' and j['key'] == SK
       for j in jobs()), 'chatgpt key routed to the direct OpenAI brain')

# ================= 2. /کلید gpt sk-… → same
r = t('/کلید gpt ' + "sk-gpt" + "y" * 30)
ck(any(j['kind'] == 'ai_key' and j['provider'] == 'astra'
       for j in jobs()[-1:]), 'gpt alias with bare sk- key → astra')

# ================= 3. gateway form still intact
r = t('/کلید openai https://api.gw.example/v1 ' + "gh_" + "k" * 30 + ' gpt-6-astra')
j = [x for x in jobs() if x.get('provider') == 'openai']
ck(j and j[-1]['base'] == 'https://api.gw.example/v1', 'gateway form untouched')

# ================= 4. 403 → reseller guidance (region-blocked servers)
def deny403(*a, **k):
    raise urllib.error.HTTPError("u", 403, "Forbidden", {}, None)
AI._chat = deny403
r = t('/کلید chatgpt ' + "sk-blocked" + "b" * 30)
ck('۴۰۳' in r and '/کلید openai' in r, '403 explains the region block + reseller fix')
ck('قابل‌قبول' not in r, '403 not presented as an invalid key')
def deny401(*a, **k):
    raise urllib.error.HTTPError("u", 401, "Unauthorized", {}, None)
AI._chat = deny401
r = t('/کلید chatgpt ' + "sk-bad" + "c" * 30)
ck('قبول نکرد' in r, '401 still the normal invalid-key message')
AI._chat = fake_chat

# ================= 5. bare /کلید shows the current brain
r = t('/کلید')
ck('مغز فعلی' in r and 'm1' in r, 'usage shows the currently-connected brain')
ck('chatgpt' in r and 'astra' in r and 'openai' in r, 'usage lists every form')

# ================= 6. existing v243 forms still parse
r = t('/کلید astra ' + "sk-direct" + "d" * 30)
ck(any(j['provider'] == 'astra' for j in jobs()[-1:]), 'astra form intact')

# ================= 7. fail_text unit for both akey reasons
ck('منطقه‌ای' in CT.fail_text('ai_setup', 'akey:403'), 'fail_text: 403 branch')
ck('قبول نکرد' in CT.fail_text('ai_setup', 'akey:401'), 'fail_text: generic branch')

print(f'v247 chatgpt-key frictionless: {n} checks green')
