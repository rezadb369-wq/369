#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v254: پرامپت چت بدون محدودیت موضوعی + بستهٔ بدون کلید.

Owner's orders (2026-09-10):
1) «کلا پرامپ چت هوش مصنوعی نوشته باشه بدون محدودیت» — ANSWER_PROMPT rule 1
   no longer fences the chat to site topics: any question gets a straight,
   useful answer; site-data integrity rules stay (no invented businesses);
   scope stays as a pure analytics flag.
2) «کلید جیمنای پاک کن، نسخه آخر ده که هوش مصنوعی فعال نیست» — brain.env
   ships EMPTY of AI_ lines, so installing v254 wipes every previous AI_*
   line (gemini included) and the brain stays OFF until the owner activates
   their ChatGPT token from Termux (/کلید).
"""
import os, sys, json, subprocess, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v254-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
AI._chat = lambda *a, **k: ('{"answer":"باشه","links":[],"scope":true,"intent":"faq"}', 5)
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]

P = AI.ANSWER_PROMPT

# ================= 1. the chat prompt is topically unrestricted
ck('محدودیت موضوعی نداری' in P and 'رد نکن' in P,
   'rule 1 states: no topical restriction, never refuse')
ck('فقط برای کارهای دست گیر هستی' not in P,
   'the old polite-refusal sentence is gone from the prompt')
ck('برنامه‌نویسی' in P and 'ترجمه' in P,
   'general topics (coding, translation…) explicitly answered')

# ================= 2. data integrity + tool protocol stay pinned
ck('از خودت نساز' in P or 'خودت نساز' in P,
   'no-invented-businesses rule stays (integrity, not restriction)')
ck('زمان فعلی' in P and 'فاصله‌ها' in P,
   'grounding of today/distances stays (v222 pin)')
ck('tool_call' in P and 'cancel_booking' in P and 'شمسی' in P,
   'tool protocol documented (v223/v225 pins)')
ck('scope را false بگذار' in P and 'روی جواب‌دادن هیچ اثری ندارد' in P,
   'scope is documented as analytics-only, never a refusal switch')

# ================= 3. v256 (owner order: «کلا توکن‌ها را حذف کن»): the package
# ships NO key — brain.env content policy is pinned by the latest suite (v256).
BR = ROOT / 'deploy' / 'brain.env'
ck(BR.is_file(), 'brain.env exists in the package')

# ================= 4. install mechanics on a local fixture: gemini wiped,
# new brain ON, bot token intact (policy of WHAT ships is v256's business)
W = Path(TMP)
(W / 'app' / 'deploy').mkdir(parents=True)
FIX = ('AI_BASE_URL=https://api.avalai.ir/v1\nAI_API_KEY=fixture-key-1234567890\n'
       'AI_MODEL=gpt-6-astra\nAI_TIMEOUT=40\n')
(W / 'app' / 'deploy' / 'brain.env').write_text(FIX, encoding='utf-8')
SEC = W / 'secrets.env'
SEC.write_text('AI_BASE_URL=https://api.avalai.ir/v1\n'
               'AI_API_KEY=gemini-old\nAI_MODEL=gemini-2.5-flash-lite\n'
               'BALE_ADMIN_TOKEN=keepme\n', encoding='utf-8')
r = subprocess.run(['bash', str(ROOT / 'deploy' / 'apply-brain.sh')],
                   capture_output=True, text=True,
                   env=dict(os.environ, DASTGIR_APP=str(W / 'app'),
                            DASTGIR_SECRETS=str(SEC)), timeout=30)
out = SEC.read_text(encoding='utf-8')
ck(r.returncode == 0, 'apply-brain runs clean on the package')
ck('gemini' not in out and 'AI_MODEL=gpt-6-astra' in out,
   'gemini fully wiped, the fixture brain is ON after install')
ck('BALE_ADMIN_TOKEN=keepme' in out, 'bot token untouched')

# ================= 5. تشخیص explains the OFF state with the fix path
os.environ['AI_BASE_URL'] = ''
os.environ['AI_API_KEY'] = ''
os.environ['AI_MODEL'] = ''
r = t('تشخیص')
ck('هیچ کلیدی وصل نیست' in r and '/کلید' in r,
   'تشخیص line 2: honest OFF state + how to activate')

# ================= 6. the termux activation path (what the owner will run)
ACT = ('AI_BASE_URL=https://api.avalai.ir/v1\nAI_API_KEY=<token>\n'
       'AI_MODEL=gpt-6-astra\nAI_TIMEOUT=40\n')
SEC.write_text('BALE_ADMIN_TOKEN=keepme\n', encoding='utf-8')
(W / 'app' / 'deploy' / 'brain.env').write_text(ACT, encoding='utf-8')
subprocess.run(['bash', str(ROOT / 'deploy' / 'apply-brain.sh')],
               capture_output=True, text=True,
               env=dict(os.environ, DASTGIR_APP=str(W / 'app'),
                        DASTGIR_SECRETS=str(SEC)), timeout=30)
out = SEC.read_text(encoding='utf-8')
ck('AI_MODEL=gpt-6-astra' in out and 'AI_TIMEOUT=40' in out
   and 'BALE_ADMIN_TOKEN=keepme' in out,
   'activating the ChatGPT token later: new brain in, bot token intact')

# ================= 7. version pins
ver = (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip()
ck(ver == A.DIAG_LATEST, f'DIAG_LATEST ({A.DIAG_LATEST}) == VERSION.txt ({ver})')

print(f'v254 unrestricted prompt + keyless package: {n} checks green')
