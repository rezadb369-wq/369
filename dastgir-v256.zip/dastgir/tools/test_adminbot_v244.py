#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v244: no more «executed... actually no» — deployment receipts.

codeguard appends what REALLY happened to data/code-deploys.log; the new
code_status tool (immediate) reads queue + receipts + raises a loud alarm
when jobs sit > 3 min (guard not installed); the snapshot carries the same
line so the model can answer «شد؟» from reality; the prompt forbids
claiming success for queued edits.
"""
import os, sys, json, time, subprocess, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v244-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT, adminbot_code as CODE
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
SCRIPT = []
def fake_chat(*a, **k):
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text, chat=CHAT: A.handle_text('u1', chat, text)[0]
yes = lambda: t('بله')
def P(tool, args):
    return json.dumps({"reply": "ok", "tool": {"name": tool, "args": args}},
                      ensure_ascii=False)

# ================= 1. code_status — empty world
r = t('وضعیت استقرار')  # plain question (model would call the tool)
SCRIPT.append(P('code_status', {}))
r = t('استقرارها چطوره؟')
ck('صف استقرار: خالی' in r and 'هنوز هیچی ثبت نشده' in r,
   'code_status answers inline with the real state')
ck(not os.path.exists(os.path.join(TMP, 'pending.json')), 'status needs no confirmation')

# ================= 2. queued job appears; stale job raises the alarm
_heading = next(ln for ln in (ROOT / 'README.md').read_text(encoding='utf-8').split('\n')
                if ln.startswith('# '))
SCRIPT.append(P('code_edit', {"path": "README.md",
                              "edits": [{"old": _heading, "new": _heading + " (تست)"}],
                              "summary": "تست"}))
r = t('یه ویرایش بده')
yes()
ok, msg = CODE.execute("code_status", {})
ck('۱ کار' in msg or '1 کار' in msg, 'queued job visible in status')
ck('کدگارد اجرا' not in msg, 'fresh job does not raise the alarm')
jobfile = [x for x in os.listdir(os.path.join(TMP, 'code-jobs')) if x.endswith('.json')][0]
old_ts = time.time() - 400
os.utime(os.path.join(TMP, 'code-jobs', jobfile), (old_ts, old_ts))
ok, msg = CODE.execute("code_status", {})
ck('کدگارد اجرا' in msg and 'کرون' in msg,
   'stale job raises the loud guard-not-running alarm')

# ================= 3. receipts are read back
with open(os.path.join(TMP, 'code-deploys.log'), 'w', encoding='utf-8') as f:
    f.write('2026-09-10 03:20:01 OK README.md\n2026-09-10 03:22:41 ROLLBACK کد ناسالم\n')
ok, msg = CODE.execute("code_status", {})
ck('OK README.md' in msg and 'ROLLBACK' in msg, 'receipts read back in order')
ck(CODE.deploy_receipts()[-1].startswith('2026-09-10 03:22:41'), 'receipt helper raw read')

# ================= 4. the snapshot carries the same truth
snap = A.admin_snapshot()
ck('آخرین استقرارها' in snap, 'snapshot carries the deploy-truth line')
ck('کدگارد اجرا' in snap, 'guard alarm reaches the model via snapshot')

# ================= 5. honesty rule in the prompt
ck('هرگز فوراً نگو «اجرا شد' in AI.ADMIN_PROMPT, 'prompt bans premature success claims')
ck('code_status' in AI.ADMIN_PROMPT, 'prompt documents code_status')

# ================= 6. guard writes receipts (stubbed end-to-end)
G = Path(tempfile.mkdtemp(prefix='cg244-'))
APP = G / 'app'
(APP / 'data' / 'code-jobs').mkdir(parents=True)
(APP / 'data' / 'code-backups').mkdir(parents=True)
(APP / 'server').mkdir(parents=True)
(APP / 'server' / 'x.py').write_text('X = 1\n', encoding='utf-8')
def stub(name, body):
    s = G / name; s.write_text('#!/usr/bin/env bash\n' + body, encoding='utf-8')
    s.chmod(0o755); return str(s)
SYSCTL = stub('systemctl', 'true')
NOTIFY = stub('notify', 'echo "$1" >> "$NLOG"')
CURL_OK = stub('curl-ok', 'exit 0')
CURL_BAD = stub('curl-bad', 'exit 1')
CURL_FLIP = stub('curl-flip', '[ -f /tmp/cg244-flip ] && exit 0 || { touch /tmp/cg244-flip; exit 1; }')
def run_guard(curl, log):
    subprocess.run(['bash', str(ROOT / 'deploy' / 'codeguard.sh')],
                   env=dict(os.environ, DASTGIR_APP=str(APP), DASTGIR_SYSTEMCTL=SYSCTL,
                            DASTGIR_CURL=curl, DASTGIR_NOTIFY=NOTIFY,
                            DASTGIR_CODEGUARD_LOG=str(G / log),
                            DASTGIR_HEALTHZ='http://x/h', SLOG=str(G / 's.log'),
                            NLOG=str(G / 'n.log')),
                   capture_output=True, timeout=90)
def qjob(o):
    (APP / 'data' / 'code-jobs' / f'j{time.time_ns()}.json').write_text(
        json.dumps(o), encoding='utf-8')
def receipts():
    p = APP / 'data' / 'code-deploys.log'
    return p.read_text(encoding='utf-8') if p.exists() else ''

# 6a. success → OK receipt
qjob({"kind": "code_edit", "path": "server/x.py",
      "edits": [{"old": "X = 1", "new": "X = 2"}], "ts": 1})
run_guard(CURL_OK, 'g1.log')
ck('OK server/x.py' in receipts(), 'success wrote an OK receipt')
# 6b. compile failure → FAIL receipt
(APP / 'server' / 'x.py').write_text('X = 2\n', encoding='utf-8')
qjob({"kind": "code_edit", "path": "server/x.py",
      "edits": [{"old": "X = 2", "new": "X = (broken"}], "ts": 2})
run_guard(CURL_OK, 'g2.log')
ck('FAIL' in receipts(), 'compile failure wrote a FAIL receipt')
# 6c. unhealthy after apply → ROLLBACK receipt
(APP / 'server' / 'x.py').write_text('X = 2\n', encoding='utf-8')
import os as _os; _os.path.exists('/tmp/cg244-flip') and _os.remove('/tmp/cg244-flip')
qjob({"kind": "code_edit", "path": "server/x.py",
      "edits": [{"old": "X = 2", "new": "X = 3"}], "ts": 3})
run_guard(CURL_FLIP, 'g3.log')          # unhealthy once, healthy after rollback
ck('ROLLBACK' in receipts(), 'rollback wrote a ROLLBACK receipt')
ck((APP / 'server' / 'x.py').read_text(encoding='utf-8') == 'X = 2\n',
   'file actually back to the known-good state')
# 6d. receipts trimmed (no unbounded growth)
for i in range(80):
    with open(APP / 'data' / 'code-deploys.log', 'a', encoding='utf-8') as f:
        f.write(f'2026-01-01 00:00:{i:02d} OK filler{i}\n')
qjob({"kind": "code_edit", "path": "server/x.py",
      "edits": [{"old": "X = 2", "new": "X = 4"}], "ts": 4})
run_guard(CURL_OK, 'g4.log')
lines = [l for l in receipts().split('\n') if l.strip()]
ck(len(lines) <= 60, f'receipt log stays trimmed ({len(lines)} lines)')

print(f'v244 deployment receipts: {n} checks green')
