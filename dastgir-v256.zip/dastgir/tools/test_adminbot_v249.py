#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v249: «تشخیص» — the bot itself names the exact broken link, live.

Why: every previous fix was built from SANDBOX simulations while the real
failure lived on the production server (old version / dead key / missing
cron). One word now tests each link ON THE REAL SERVER: running version,
brain (real round-trip + last error), codeguard cron, deploy queue +
receipts + stale alarm, service, pending confirm. Numbered lines so a
screenshot tells us exactly which link is broken.
"""
import os, sys, json, time, tempfile, urllib.error
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v249-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
SCRIPT = []
def fake_chat(*a, **k):
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]

# ================= 1. healthy-ish: report structure
r = t('تشخیص')
# NOTE: fragments avoid «هٔ»-style combining chars — two visually identical
# encodings broke an earlier check (lesson learned the hard way).
for frag, label in [("۱)", 'version line'),
                    ("۲) مغز هوش", 'brain line'),
                    ("۳) کرون", 'cron line'),
                    ("۴)", 'deploy status line'),
                    ("۵) سرویس", 'service line'),
                    ("۶)", 'pending line')]:
    ck(frag in r, f'report has the {label}')
ck("نسخه" in r and "سایت" in r, 'version line names the site')
ck('به‌روز' in r, 'current version flagged as up-to-date')
ck('✅ پاسخ داد' in r, 'live brain round-trip OK (fake model answered)')
ck('k-test' not in r and 'AIza' not in r and 'gsk_' not in r, 'no key material ever shown')
ck('راهنما' in t('راهنما') and 'تشخیص' in A.handle_text('u1', CHAT, 'راهنما')[0],
   'help lists the diagnose command')

# ================= 2. dead brain → the exact failure is named
def deny401(*a, **k):
    raise urllib.error.HTTPError("u", 401, "Unauthorized", {}, None)
AI._chat = deny401
r = t('تشخیص')
ck('❌ HTTP 401' in r, '401 brain failure named with its code')
def deny403(*a, **k):
    raise urllib.error.HTTPError("u", 403, "Forbidden", {}, None)
AI._chat = deny403
r = t('تشخیص')
ck('محدودیت منطقه‌ای' in r, '403 explained as region block')
def timeout(*a, **k):
    raise TimeoutError('down')
AI._chat = timeout
r = t('تشخیص')
ck('❌ TimeoutError' in r, 'network failure named by type')
AI._chat = fake_chat

# ================= 3. unconfigured brain → recipe + diagnose pointer
_cfg = AI.configured
AI.configured = lambda: False
r = t('سلام')
ck('وصل نیست' in r and '/کلید' in r and 'تشخیص' in r,
   'unconfigured copilot points to the fix AND the diagnose command')
AI.configured = _cfg

# ================= 4. cron missing (sandbox: file absent) → loud alarm
r = t('تشخیص')
ck('نصب نیست' in r and 'هرگز اعمال نمی‌شوند' in r,
   'missing cron called out as the edits-never-apply cause')

# ================= 5. stale queue + receipts surface in the report
os.makedirs(os.path.join(TMP, 'code-jobs'), exist_ok=True)
jf = os.path.join(TMP, 'code-jobs', 'stale.json')
open(jf, 'w').write('{}')
old = time.time() - 500
os.utime(jf, (old, old))
with open(os.path.join(TMP, 'code-deploys.log'), 'w', encoding='utf-8') as f:
    f.write('2026-09-10 13:00:00 FAIL تست\n')
r = t('تشخیص')
ck('کدگارد اجرا نمی‌شود' in r, 'stale-job alarm included')
ck('FAIL' in r and '۱۳:۰۰' in r.replace('13:00', '۱۳:۰۰') or 'FAIL' in r,
   'last receipt surfaced')
os.remove(jf)

# ================= 6. AI-error path carries the diagnose pointer
def boom(*a, **k):
    raise TimeoutError('down')
AI._chat = boom
r = t('یه چیزی را تغییر بده')
ck('تشخیص' in r, 'AI failure reply points to تشخیص')
AI._chat = fake_chat

# ================= 7. autopilot honest-failure carries the pointer too
FIX = ROOT / 'docs' / 'diag-fix-v249.js'
FIX.write_text('const DIAG_X = "old";\n', encoding='utf-8')
try:
    SCRIPT.clear()
    SCRIPT.append('نمی‌دانم')     # main model: useless
    SCRIPT.append('نمی‌دانم')     # mini try 1
    SCRIPT.append('نمی‌دانم')     # mini try 2
    r = t('متغیر DIAG_X را در کد تغییر بده')
    ck('تشخیص' in r and 'پیدا کردم' in r,
       'autopilot failure: found the spot + points to تشخیص')
finally:
    FIX.unlink(missing_ok=True)

# ================= 8. dispatch aliases
for alias in ('/تشخیص', 'عیب‌یابی', '/diagnose'):
    ck('۱) نسخهٔ سایت' in t(alias), f'alias «{alias}» works')

print(f'v249 live diagnose: {n} checks green')
