#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v238 admin copilot -- offline tests.

Free text in the owner-only Bale admin bot goes to a read-only AI that
sees a live redacted snapshot (+ short memory). No quotas, no threads,
no DB writes on this path. No network: _chat is stubbed.
"""
import os, sys, json, time, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='adm-v238-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-09 20:40:01 OK: db=892960B\n')
AI._chat = lambda *a, **k: ('پاسخ آزمایشی', 5)
db.init()
CHAT = '893219571'
t = lambda text, chat=CHAT: A.handle_text('u1', chat, text)[0]

buyer = db.customer_by_phone('09120000051', create=True)
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,phone,city) VALUES('pub9','فروشگاه نه','services','published','0219','تهران')")
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,phone,city) VALUES('pend9','در انتظار نه','services','pending','0218','تبریز')")
con.commit(); con.close()
db.create_order(1, buyer['id'], 'تستی', '09120000051', 'آدرس', '', [{'item_id': None, 'title': 'کالا', 'price': 700, 'qty': 1}])
db.set_setting('owner_token', 'SECRET-TOKEN-XYZ')
db.set_owner_pass('panel-pass-1')

# ---- 1. strangers never reach the AI
ck(t('سایت چطوره؟', chat='111').startswith('⛔'), 'stranger free text denied')

# ---- 2. free text routes to the copilot; commands intact
ck(t('سایت چطوره؟') == 'پاسخ آزمایشی', 'free text answered by AI')
ck('وضعیت دستگیر' in t('وضعیت'), 'status not hijacked')
ck('در انتظار نه' in t('تأیید'), 'biz queue not hijacked')

# ---- 3. memory accumulates + prunes + trims
t('سؤال دوم')
mem = json.loads(Path(os.environ['ADMINBOT_MEMORY']).read_text(encoding='utf-8'))
ck(len(mem) == 2 and mem[0]['q'] == 'سایت چطوره؟' and mem[1]['a'] == 'پاسخ آزمایشی', 'two turns remembered')
stale = [{'q': 'old', 'a': 'old', 'ts': time.time() - 4000}, {'q': 'new', 'a': 'new', 'ts': time.time()}]
Path(os.environ['ADMINBOT_MEMORY']).write_text(json.dumps(stale), encoding='utf-8')
ck(A._memory_load() == [stale[1]], 'stale memory pruned')
for i in range(8):
    A._memory_save(f'q{i}', f'a{i}')
ck(len(json.loads(Path(os.environ['ADMINBOT_MEMORY']).read_text(encoding='utf-8'))) == 6, 'memory trims to 6')

# ---- 4. snapshot sees everything but secrets
snap = A.admin_snapshot()
ck('SECRET-TOKEN-XYZ' not in snap and 'pbkdf2' not in snap, 'secrets redacted from snapshot')
ck('owner_token' not in snap and 'owner_pass_hash' not in snap, 'secret keys dropped')
ck('prices_enabled' in snap, 'operational settings visible')
ck('در انتظار نه' in snap and '#1' in snap, 'pending biz + recent order in snapshot')

# ---- 5. read-only: no quota, audit, notification or settings writes
u0 = db._one("SELECT COUNT(*) c FROM ai_usage")['c']
au0 = len(db.audit_log(100))
nt0 = db._one("SELECT COUNT(*) c FROM notifications")['c']
t('یه سؤال فقط خواندنی')
ck(db._one("SELECT COUNT(*) c FROM ai_usage")['c'] == u0, 'no quota rows for admin')
ck(len(db.audit_log(100)) == au0, 'no audit rows for admin reads')
ck(db._one("SELECT COUNT(*) c FROM notifications")['c'] == nt0, 'no notifications sent')
ck(db.get_settings()['prices_enabled'] == '1', 'settings untouched')

# ---- 6. long replies truncate; LLM errors are friendly
AI._chat = lambda *a, **k: ('z' * 5000, 5)
ck(len(t('خلاصه بده')) <= 3000, 'long reply truncates')
def boom(*a, **k):
    raise TimeoutError('down')
AI._chat = boom
_r = t('هستی؟')
ck('جواب نداد' in _r or 'نتیجه نرسیدم' in _r, 'LLM outage is friendly')

# ---- 7. fallback provider chain
os.environ['AI_FALLBACK_BASE_URL'] = 'http://fb.local'
os.environ['AI_FALLBACK_API_KEY'] = 'kf'
os.environ['AI_FALLBACK_MODEL'] = 'm2'
def flaky(base, key, model, *a, **k):
    if model == 'm1':
        raise TimeoutError('primary down')
    return ('از فالبک', 3)
AI._chat = flaky
ck(t('تست فالبک') == 'از فالبک', 'fallback answers when primary fails')
ck(AI.last_provider()['which'] == 'fallback', 'fallback recorded')
del os.environ['AI_FALLBACK_BASE_URL']; del os.environ['AI_FALLBACK_API_KEY']; del os.environ['AI_FALLBACK_MODEL']

# ---- 8. unconfigured AI explains itself
for k in ('AI_BASE_URL', 'AI_API_KEY', 'AI_MODEL'):
    del os.environ[k]
ck('وصل نیست' in t('سلام') and '/کلید' in t('سلام'), 'unconfigured bot guides to the free-key fix')
ck(AI.admin_answer('x', 'snap')[1] == 'unconfigured', 'direct source is unconfigured')
os.environ['AI_BASE_URL'] = 'http://llm.local'; os.environ['AI_API_KEY'] = 'k-test'; os.environ['AI_MODEL'] = 'm1'

# ---- 9. watch + help advertise the copilot
AI._chat = lambda *a, **k: ('پاسخ آزمایشی', 5)
ck('هوش: فعال ✅' in t('نگهبان'), 'watch shows AI state')
ck('هوش مصنوعی' in A.handle_text('u1', CHAT, 'راهنما')[0], 'help mentions free questions')

# ---- 10. AI questions clear pending confirms (like any command)
t('ریستارت')
t('راستی هوا چطوره؟')
ck(t('بله').startswith('⌛'), 'pending restart expired by a question')

print(f'v238 copilot: {n} checks green')
