#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v241: the admin copilot gets the whole SITE — code included.

Two halves:
  * in-process: code_list/code_read run immediately; code_edit/code_write/
    code_revert/service_restart are proposals that queue a job for the root
    codeguard cron (the sandboxed app itself can never write code).
  * deploy/codeguard.sh (tested here with stub systemctl/curl/notify):
    backup → apply → py_compile → sw.js bump → restart → healthz →
    auto-rollback + notify on failure.
Security pins: locked files (bot brains, secrets area, deploy/tools, sw.js,
VERSION.txt) refused at parse; traversal/absolute/binary refused; old-text
must match exactly once; the deny-list in code == the deny-list in guard.
"""
import os, sys, json, time, shutil, subprocess, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v241-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT, adminbot_code as CODE
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')

SCRIPT = []
def fake_chat(*a, **k):
    return (SCRIPT.pop(0), 5) if SCRIPT else ('{"reply":"باشه","tool":null}', 5)
AI._chat = fake_chat
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True

def propose(model_answer, question='تغییر بده'):
    SCRIPT.append(model_answer)
    return A.handle_text('u1', CHAT, question)[0]

db.init()
CHAT = '893219571'
t = lambda text, chat=CHAT: A.handle_text('u1', chat, text)[0]
yes = lambda: t('بله')
def P(tool, args):
    return json.dumps({"reply": "ok", "tool": {"name": tool, "args": args}},
                      ensure_ascii=False)
def jobs():
    d = os.path.join(TMP, 'code-jobs')
    return [json.load(open(os.path.join(d, x), encoding='utf-8'))
            for x in sorted(os.listdir(d))] if os.path.isdir(d) else []

# ================= 1. code_list — immediate, no pending
r = propose(P('code_list', {"path": ""}))
ck('server' in r and 'site' in r and '🗂' in r, 'root listing answered inline')
ck('🔒' in r or '+' in r, 'locked entries marked/hidden')
ck(not os.path.exists(os.path.join(TMP, 'pending.json')), 'read-only tool needs no «بله»')
r = propose(P('code_list', {"path": "no-such-dir"}))
ck('پیدا نشد' in r, 'missing dir refused')
name, _ = CT.parse_tool_call({'name': 'code_list', 'args': {'path': 'data'}})
ck(name is None, 'listing the locked data/ dir refused at parse')

# ================= 2. code_read — immediate + sidecar into the snapshot
r = propose(P('code_read', {"path": "VERSION.txt"}))
ck(name is None or 'قفل' in r or 'مجاز' in r, 'VERSION.txt read refused (locked)')
r = propose(P('code_read', {"path": "README.md", "from_line": 1, "to_line": 15}))
ck('README.md' in r and '1|' in r or '| ' in r, 'read answered with numbered lines')
ck(not os.path.exists(os.path.join(TMP, 'pending.json')), 'read needs no confirmation')
snap = A.admin_snapshot()
ck('README.md' in snap and 'برای code_edit' in snap, 'snapshot carries the read file for the model')
name, _ = CT.parse_tool_call({'name': 'code_read', 'args': {'path': '../etc/passwd'}})
ck(name is None, 'traversal read refused at parse')
name, _ = CT.parse_tool_call({'name': 'code_read', 'args': {'path': '/etc/passwd'}})
ck(name is None, 'absolute path refused at parse')
name, _ = CT.parse_tool_call({'name': 'code_read', 'args': {'path': 'server/adminbot.py'}})
ck(name is None, "reading the bot's own brain refused")
name, _ = CT.parse_tool_call({'name': 'code_read',
                              'args': {'path': 'site/assets/img/og-default.png'}})
ck(name is None, 'binary file read refused at parse')

# ================= 3. code_edit — proposal → «بله» → job queued
victim = 'README.md'
uniq = '# 🛒'                       # appears once near the top
r = propose(P('code_edit', {"path": victim, "edits": [
    {"old": uniq, "new": "# 🛒 دست گیر (ویرایش تست)"}], "summary": "تست"}))
ck('ویرایش کد README.md' in r and 'تأیید می‌کنی' in r, 'code edit proposed with confirm wall')
before = open(ROOT / victim, encoding='utf-8').read()
yes()
after = open(ROOT / victim, encoding='utf-8').read()
ck(before == after, 'in-process execution never touches code (sandbox)')
j = jobs()
ck(len(j) == 1 and j[0]['kind'] == 'code_edit'
   and j[0]['edits'][0]['old'] == uniq, 'job queued with the exact edit')
ck(db._one("SELECT COUNT(*) c FROM audit WHERE action='admin_ai_tool'"
           " AND detail LIKE 'code_edit%'")['c'] >= 1, 'code edit audit-logged')
for bad, why in [
        ({"path": "server/adminbot.py", "edits": [{"old": "x=1", "new": "x=2"}]}, 'locked'),
        ({"path": "deploy/update.sh", "edits": [{"old": "x", "new": "y"}]}, 'locked deploy'),
        ({"path": "site/sw.js", "edits": [{"old": "x", "new": "y"}]}, 'locked sw'),
        ({"path": "no-such-file.py", "edits": [{"old": "x", "new": "y"}]}, 'missing'),
        ({"path": victim, "edits": [{"old": "∞∉∄xyz", "new": "y"}]}, 'nomatch'),
        ({"path": victim, "edits": [{"old": "دست", "new": "y"}]}, 'ambiguous or proposed')]:
    name, args = CT.parse_tool_call({'name': 'code_edit', 'args': bad})
    if name:
        ok, reason = CT.tool_precheck('code_edit', args)
        ck(not ok, f'bad edit refused: {why}')
    else:
        ck(True, f'bad edit refused at parse: {why}')
name, _ = CT.parse_tool_call({'name': 'code_edit',
                              'args': {'path': victim, 'edits': [{'old': 'a', 'new': 'a'}]}})
ck(name is None, 'no-op edit refused at parse')
name, _ = CT.parse_tool_call({'name': 'code_edit', 'args': {
    'path': victim, 'edits': [{"old": 'a', 'new': 'b'}] * 9}})
ck(name is None, '>8 edits refused at parse')

# ================= 4. code_write — new file job + guards
r = propose(P('code_write', {"path": "docs/ai-scratch.md", "content": "# تست\n", "summary": "تست"}))
yes()
j = jobs()
ck(any(x['kind'] == 'code_write' and x['path'] == 'docs/ai-scratch.md' for x in j),
   'code_write job queued')
ck(not (ROOT / 'docs' / 'ai-scratch.md').exists(), 'no file created in-process')
name, _ = CT.parse_tool_call({'name': 'code_write',
                              'args': {'path': 'x/shell.png', 'content': 'x'}})
ck(name is None, 'binary extension write refused')
name, _ = CT.parse_tool_call({'name': 'code_write',
                              'args': {'path': 'data/evil.py', 'content': 'x'}})
ck(name is None, 'write into data/ refused')
name, _ = CT.parse_tool_call({'name': 'code_write',
                              'args': {'path': 'docs/big.md', 'content': 'x' * 25000}})
ck(name is None, 'oversize write refused at parse')

# ================= 5. code_revert — needs a backup index
r = propose(P('code_revert', {"path": "README.md"}))
ck('پیدا نشد' in r, 'revert without any backup refused')
os.makedirs(os.path.join(TMP, 'code-backups'), exist_ok=True)
with open(os.path.join(TMP, 'code-backups', 'b1'), 'w', encoding='utf-8') as f:
    f.write('old content')
json.dump([{"ts": int(time.time()), "path": "README.md", "file": "b1", "existed": True}],
          open(os.path.join(TMP, 'code-backups', 'index.json'), 'w', encoding='utf-8'))
r = propose(P('code_revert', {"path": "README.md"}))
ck('برگشت' in r and 'تأیید' in r, 'revert proposed when a backup exists')
yes()
ck(any(x['kind'] == 'code_revert' for x in jobs()), 'revert job queued')

# ================= 6. service_restart — legacy queue + rate limit
r = propose(P('service_restart', {}))
ck('راه‌اندازی مجدد' in r, 'restart proposed')
yes()
qdir = os.path.join(TMP, 'adminbot-cmd')
qfiles = [x for x in os.listdir(qdir)] if os.path.isdir(qdir) else []
ck(len(qfiles) == 1 and json.load(open(os.path.join(qdir, qfiles[0])))['cmd'] == 'restart',
   'restart queued in the legacy root queue')
r = propose(P('service_restart', {}))
ck('صبر' in r, 'second restart within the window rate-limited')

# ================= 7. prompt + help + inventory
ck('code_edit' in AI.ADMIN_PROMPT and 'service_restart' in AI.ADMIN_PROMPT,
   'prompt documents the code tools')
ck('کد سایت' in A.handle_text('u1', CHAT, 'راهنما')[0], 'help mentions code access')
snap = A.admin_snapshot()
ck('صف استقرار' in snap, 'inventory hints at the code surface')

# ================= 8. deny lists identical in code and in the guard
guard = (ROOT / 'deploy' / 'codeguard.sh').read_text(encoding='utf-8')
for item in CODE.DENY_FILES:
    ck(item in guard, f'guard deny-list matches: {item}')
ck('docs/superpowers/' in guard and CODE.DENY_PREFIXES[0] in guard,
   'guard deny-prefixes match')

# ================= 9. codeguard.sh functional (stubs, temp app)
G = Path(tempfile.mkdtemp(prefix='cg-'))
APP = G / 'app'; (APP / 'server').mkdir(parents=True); (APP / 'site').mkdir(parents=True)
(APP / 'data' / 'code-jobs').mkdir(parents=True); (APP / 'data' / 'code-backups').mkdir(parents=True)
(APP / 'server' / 'hello.py').write_text('X = 1\n', encoding='utf-8')
(APP / 'site' / 'style.css').write_text('body{color:red}\n', encoding='utf-8')
(APP / 'site' / 'sw.js').write_text("const VERSION = 'bazarche-v241';\n", encoding='utf-8')
def stub(name, body):
    s = G / name; s.write_text('#!/usr/bin/env bash\n' + body, encoding='utf-8')
    s.chmod(0o755); return str(s)
SYSCTL = stub('systemctl-stub', 'echo "$*" >> "$SLOG"')
CURL_OK = stub('curl-ok', 'exit 0')
CURL_BAD = stub('curl-bad', 'exit 1')
NOTIFY = stub('notify-stub', 'echo "$1" >> "$NLOG"')
ENVBASE = dict(os.environ, DASTGIR_APP=str(APP), DASTGIR_SYSTEMCTL=SYSCTL,
               DASTGIR_NOTIFY=NOTIFY, DASTGIR_CODEGUARD_LOG=str(G / 'guard.log'),
               DASTGIR_HEALTHZ='http://stub/healthz',
               SLOG=str(G / 'sysctl.log'), NLOG=str(G / 'notify.log'))
def run_guard(curl):
    env = dict(ENVBASE, DASTGIR_CURL=curl)
    subprocess.run(['bash', str(ROOT / 'deploy' / 'codeguard.sh')],
                   env=env, capture_output=True, timeout=90)
def qjob(obj):
    (APP / 'data' / 'code-jobs' / f'j{time.time_ns()}.json').write_text(
        json.dumps(obj, ensure_ascii=False), encoding='utf-8')
def notifylog():
    p = G / 'notify.log'
    return p.read_text(encoding='utf-8') if p.exists() else ''

# 9a. happy path: edit a py file + a site css file
qjob({"kind": "code_edit", "path": "server/hello.py",
      "edits": [{"old": "X = 1", "new": "X = 2"}], "ts": 1})
qjob({"kind": "code_edit", "path": "site/style.css",
      "edits": [{"old": "color:red", "new": "color:blue"}], "ts": 2})
run_guard(CURL_OK)
ck((APP / 'server' / 'hello.py').read_text(encoding='utf-8') == 'X = 2\n',
   'guard applied the python edit')
ck('color:blue' in (APP / 'site' / 'style.css').read_text(encoding='utf-8'),
   'guard applied the css edit')
ck("bazarche-v241.1" in (APP / 'site' / 'sw.js').read_text(encoding='utf-8'),
   'site change auto-bumped the PWA version')
idx = json.load(open(APP / 'data' / 'code-backups' / 'index.json', encoding='utf-8'))
ck(len(idx) >= 2, 'backups indexed for both files')
ck('restart' in (G / 'sysctl.log').read_text(encoding='utf-8'), 'guard restarted the service')
ck('✅' in notifylog(), 'owner notified of the successful deploy')
ck(not list((APP / 'data' / 'code-jobs').glob('*.json')), 'jobs consumed')

# 9b. compile failure: file untouched, warning notified
(APP / 'server' / 'hello.py').write_text('X = 2\n', encoding='utf-8')
qjob({"kind": "code_edit", "path": "server/hello.py",
      "edits": [{"old": "X = 2", "new": "X = (bad syntax"}], "ts": 3})
run_guard(CURL_OK)
ck((APP / 'hello.py' if False else APP / 'server' / 'hello.py').read_text(
    encoding='utf-8') == 'X = 2\n', 'compile-failing edit left the file untouched')
ck('⚠️' in notifylog(), 'compile failure notified')
ck(not list((APP / 'data' / 'code-jobs').glob('*.json')), 'bad job consumed')
ck(not list((APP / 'server').glob('.cg-*')), 'no temp-file leak')

# 9c. unhealthy service → auto-rollback to the pre-job state
(APP / 'server' / 'hello.py').write_text('X = 2\n', encoding='utf-8')  # known good
qjob({"kind": "code_edit", "path": "server/hello.py",
      "edits": [{"old": "X = 2", "new": "X = 3"}], "ts": 4})
run_guard(CURL_BAD)          # healthz fails after restart
ck((APP / 'server' / 'hello.py').read_text(encoding='utf-8') == 'X = 2\n',
   'unhealthy deploy rolled back automatically')
ck('برگشت' in notifylog() or '⚠️' in notifylog(), 'rollback notified')

# 9d. revert job through the guard
qjob({"kind": "code_revert", "path": "server/hello.py", "ts": 5})
run_guard(CURL_OK)
ck((APP / 'server' / 'hello.py').read_text(encoding='utf-8') == 'X = 2\n',
   'revert restored the newest backup')

# 9e. new file via code_write + revert removes it
qjob({"kind": "code_write", "path": "server/brand_new.py",
      "content": "Y = 10\n", "ts": 6})
run_guard(CURL_OK)
ck((APP / 'server' / 'brand_new.py').read_text(encoding='utf-8') == 'Y = 10\n',
   'guard created the new file')
qjob({"kind": "code_revert", "path": "server/brand_new.py", "ts": 7})
run_guard(CURL_OK)
ck(not (APP / 'server' / 'brand_new.py').exists(), 'revert removed a file that never existed')

# 9f. legacy adminbot-cmd queue drained
(APP / 'data' / 'adminbot-cmd').mkdir(parents=True, exist_ok=True)
(APP / 'data' / 'adminbot-cmd' / 'r-1.json').write_text(
    '{"cmd": "restart", "ts": 9}', encoding='utf-8')
run_guard(CURL_OK)
ck(not list((APP / 'data' / 'adminbot-cmd').glob('*.json')), 'legacy restart queue drained')
ck((G / 'sysctl.log').read_text(encoding='utf-8').count('restart') >= 4,
   'legacy restart actually ran')

# 9g. deny-list respected by the guard itself
qjob({"kind": "code_edit", "path": "server/adminbot.py",
      "edits": [{"old": "x", "new": "y"}], "ts": 10})
run_guard(CURL_OK)
ck('⚠️' in notifylog() or not list((APP / 'data' / 'code-jobs').glob('*.json')),
   'guard refuses locked paths independently')

# ================= 10. bale_notify smoke + update.sh ships the cron
r = subprocess.run([sys.executable, str(ROOT / 'tools' / 'bale_notify.py'), 'سلام'],
                   capture_output=True, timeout=30)
ck(r.returncode == 0 and not r.stdout, 'notifier silent without credentials')
upd = (ROOT / 'deploy' / 'update.sh').read_text(encoding='utf-8')
ck('dastgir-codeguard' in upd and 'codeguard.sh' in upd, 'update.sh installs the cron')
ck('data/code-jobs' in upd, 'update.sh creates the code-jobs dir')
ai = (ROOT / 'deploy' / 'ai-free-setup.sh').read_text(encoding='utf-8')
ck('AI_FALLBASE' not in ai and 'AI_FALLBACK_API_KEY' in ai, 'free-key script keeps old key as fallback')

print(f'v241 full-site code access: {n} checks green')
