#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Focused regression checks for the immutable v179 public brand contract."""

from __future__ import annotations

import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / "server"
sys.path.insert(0, str(SERVER))

BRAND = "دست گیر"
HOSTILE = "نام دست‌کاری‌شده"


def check(ok: bool, label: str) -> None:
    if not ok:
        raise AssertionError(label)
    print("✓", label)


def raw_name(db_path: Path) -> str:
    con = sqlite3.connect(db_path)
    try:
        row = con.execute("SELECT value FROM settings WHERE key='site_name'").fetchone()
        return row[0] if row else ""
    finally:
        con.close()


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="dastgir-brand-") as tmp:
        os.environ["BZ_DATA_DIR"] = tmp
        import db
        import ui
        import views_panel as panel
        import views_panel2 as panel2

        db.init()
        db_path = Path(tmp) / "bazarche.db"
        check(raw_name(db_path) == BRAND, "fresh database stores the canonical name")

        # v251 (دستور مدیر): نام سایت دیگر قرارداد ثابت نیست — انتخاب مدیر است.
        con = sqlite3.connect(db_path)
        con.execute("UPDATE settings SET value=? WHERE key='site_name'", (HOSTILE,))
        con.commit()
        con.close()
        check(db.get_settings()["site_name"] == HOSTILE,
              "v251: the chosen name is served as-is (no read-side rewrite)")

        db.set_setting("site_name", HOSTILE)
        check(raw_name(db_path) == HOSTILE,
              "v251: set_setting stores the owner's chosen name")
        db.set_settings({"site_name": BRAND, "tagline": "آزمون"})
        check(raw_name(db_path) == BRAND and db.get_settings()["tagline"] == "آزمون",
              "v251: set_settings respects the submitted name and other settings")

        db.import_all({"settings": [
            {"key": "site_name", "value": HOSTILE},
            {"key": "tagline", "value": "پس از بازیابی"},
        ]})
        check(raw_name(db_path) == HOSTILE,
              "v251: backup restore brings back the backed-up name")

        db.set_setting("site_name", HOSTILE)
        s = db.get_settings()
        public = ui.page(s, "خانه", "<main>آزمون</main>")
        check(HOSTILE in public and "دستِ گیر" not in public,
              "v251: public page chrome uses the chosen name")

        settings_html = panel.settings_page(s, "token")
        editor_html = panel2.editor_page(s, "token")
        for label, html in (("settings", settings_html), ("editor", editor_html)):
            check('name="site_name"' in html and f'value="{HOSTILE}"' in html,
                  f"v251: panel {label} shows an EDITABLE site_name field")
            check('id="g-n" readonly' not in html and 'id="e-name" readonly' not in html,
                  f"v251: panel {label} brand input is no longer readonly")

    manifest = json.loads((ROOT / "site/manifest.webmanifest").read_text())
    check(manifest["name"] == BRAND and manifest["short_name"] == BRAND,
          "PWA manifest name and short_name are exact")
    offline = (ROOT / "site/offline.html").read_text()
    check(BRAND in offline and HOSTILE not in offline, "offline page uses the canonical name")

    app_src = (ROOT / "server/app.py").read_text()
    post_at = app_src.index("def do_POST")
    settings_at = app_src.index('if path == "/panel/settings":', post_at)
    settings_block = app_src[settings_at:
                             app_src.index('if path == "/panel/rotate-token":', settings_at)]
    editor_at = app_src.index('if path == "/panel/editor":', post_at)
    editor_block = app_src[editor_at:
                           app_src.index("# ---- neighbourhood rename", editor_at)]
    check('"site_name"' in settings_block and '"site_name"' in editor_block,
          "v251: both admin POST handlers now accept site_name")
    inline_at = app_src.index("def _inline_edit")
    inline_block = app_src[inline_at:app_src.index("# -------------------------------------------------------------- GET", inline_at)]
    check('"site_name"' not in inline_block,
          "legacy inline-edit allow-list cannot mutate the brand")

    print("\nهمهٔ آزمون‌های متمرکز برند v179 موفق بودند.")


if __name__ == "__main__":
    main()
