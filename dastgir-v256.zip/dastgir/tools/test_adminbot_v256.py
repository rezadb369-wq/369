#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v256: کلاً بدون توکن — با مدرک.

Owner's order (2026-09-10): «آقا کلا توکن ها را حذف کن کلا کلا کلا با مدرک».
This suite is the enforcement of that order:
1) deploy/brain.env ships ZERO AI_ lines — installing v256 wipes EVERY AI_*
   line on the server (gemini, ChatGPT/AvalAI, fallbacks) and the AI stays
   OFF until the owner connects a key via /کلید.
2) tools/scan_tokens.py scans every file of the package for real-token
   shapes; real secrets are detected by SHA-256 against a blocklist (the
   real key itself never appears in the package). The scan must pass.
3) The real AvalAI key must be absent from the whole tree.
"""
import os, sys, json, subprocess, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v256-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_MEMORY'] = os.path.join(TMP, 'mem.json')
os.environ['ADMINBOT_IMAGE'] = os.path.join(TMP, 'image.json')
os.environ['ADMINBOT_CODE'] = os.path.join(TMP, 'code.json')
os.environ['AI_BASE_URL'] = 'http://llm.local'
os.environ['AI_API_KEY'] = 'k-test'
os.environ['AI_MODEL'] = 'm1'
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, adminbot as A, assistant as AI, adminbot_content as CT
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.OFFSITE_LOG = os.path.join(TMP, 'offsite.log')
Path(A.OFFSITE_LOG).write_text('2026-09-10 10:40:01 OK: db=892960B\n')
AI._chat = lambda *a, **k: ('{"answer":"باشه","links":[],"scope":true,"intent":"faq"}', 5)
SENT = []
A.send_message = lambda cid, text, markup=None: SENT.append(text) or True
db.init()
CHAT = '893219571'
t = lambda text: A.handle_text('u1', CHAT, text)[0]

BR = ROOT / 'deploy' / 'brain.env'

# ================= 1. the package is keyless
be = BR.read_text(encoding='utf-8')
ck(not [ln for ln in be.splitlines() if ln.startswith('AI_')],
   'brain.env ships ZERO AI_ lines (کلاً بدون توکن)')

# ================= 2. the token scan — the مدرک — passes on the whole tree
r = subprocess.run([sys.executable, str(ROOT / 'tools' / 'scan_tokens.py')],
                   capture_output=True, text=True, timeout=120)
ck(r.returncode == 0 and 'راز واقعی: ۰' in r.stdout,
   'scan_tokens.py: zero real secrets in the whole package')
ck('فایل‌های اسکن‌شده:' in r.stdout, 'the scan reports its file count (auditable)')

# ================= 3. the real key is gone from every text file
import hashlib
REAL_SHA = 'a415b87134b42ca583c621849da783e8ee6850681bbe2cc0f50147ff5a52ff60'
hits = []
for p in ROOT.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:
        try:
            txt = p.read_text(encoding='utf-8', errors='ignore')
        except OSError:
            continue
        if 'aa-' in txt or 'sk-' in txt:
            for fam in (r'aa-[A-Za-z0-9]{30,}', r'sk-[A-Za-z0-9_\-]{30,}'):
                import re as _re
                for m in _re.findall(fam, txt):
                    if hashlib.sha256(m.encode()).hexdigest() == REAL_SHA:
                        hits.append(str(p))
ck(not hits, 'the real AvalAI key appears in 0 files (hash-checked)')

# ================= 4. installing v256 wipes EVERY AI key on the server
W = Path(TMP)
(W / 'app' / 'deploy').mkdir(parents=True)
(W / 'app' / 'deploy' / 'brain.env').write_text(be, encoding='utf-8')
SEC = W / 'secrets.env'
SEC.write_text('AI_BASE_URL=https://api.avalai.ir/v1\n'
               'AI_API_KEY=gemini-old\nAI_MODEL=gemini-2.5-flash-lite\n'
               'AI_FALLBACK_API_KEY=oldfb\nBALE_ADMIN_TOKEN=keepme\n',
               encoding='utf-8')
r = subprocess.run(['bash', str(ROOT / 'deploy' / 'apply-brain.sh')],
                   capture_output=True, text=True,
                   env=dict(os.environ, DASTGIR_APP=str(W / 'app'),
                            DASTGIR_SECRETS=str(SEC)), timeout=30)
out = SEC.read_text(encoding='utf-8')
ck(r.returncode == 0, 'apply-brain runs clean on the keyless package')
ck(not [ln for ln in out.splitlines() if ln.startswith('AI_')],
   'install wipes gemini + avalai + every AI_ line completely')
ck('BALE_ADMIN_TOKEN=keepme' in out, 'the bot login token stays (it is not an AI key)')
ck(not (W / 'secrets.env.bak').exists(), 'no .bak trace is left behind')

# ================= 5. تشخیص is honest about the OFF state + the way back
os.environ['AI_BASE_URL'] = ''
os.environ['AI_API_KEY'] = ''
os.environ['AI_MODEL'] = ''
r = t('تشخیص')
ck('هیچ کلیدی وصل نیست' in r and '/کلید' in r,
   'تشخیص line 2: honest OFF state + /کلید as the only way back')

# ================= 6. re-enabling later still works (mechanics intact)
FIX = ('AI_BASE_URL=https://api.avalai.ir/v1\nAI_API_KEY=fixture-key-1234567890\n'
       'AI_MODEL=gpt-6-astra\nAI_TIMEOUT=40\n')
(W / 'app' / 'deploy' / 'brain.env').write_text(FIX, encoding='utf-8')
SEC.write_text('BALE_ADMIN_TOKEN=keepme\n', encoding='utf-8')
subprocess.run(['bash', str(ROOT / 'deploy' / 'apply-brain.sh')],
               capture_output=True, text=True,
               env=dict(os.environ, DASTGIR_APP=str(W / 'app'),
                        DASTGIR_SECRETS=str(SEC)), timeout=30)
ck('AI_MODEL=gpt-6-astra' in SEC.read_text(encoding='utf-8'),
   'a future brain.env (owner order) can still activate a key')

# ================= 7. version pins
ver = (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip()
ck(ver == A.DIAG_LATEST, f'DIAG_LATEST ({A.DIAG_LATEST}) == VERSION.txt ({ver})')
r = t('تشخیص')
ck('به‌روز' in r and 'قدیمی‌تر' not in r, 'تشخیص line 1 reports به‌روز')

print(f'v256 token-free with evidence: {n} checks green')
