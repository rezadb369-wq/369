#!/usr/bin/env bash
# v241: free-tier AI provider setup — no cost, no card.
#
#   sudo bash deploy/ai-free-setup.sh gemini <API_KEY>     (aistudio.google.com)
#   sudo bash deploy/ai-free-setup.sh groq   <API_KEY>     (console.groq.com)
#
# Live-tests the key BEFORE touching the config, keeps the old primary as
# the fallback chain, restarts the service, verifies health. The key is
# never echoed or logged.
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo 'با sudo اجرا کنید.' >&2; exit 1; }
P="${1:-}"; KEY="${2:-}"
case "$P" in
  gemini) BASE='https://generativelanguage.googleapis.com/v1beta/openai'; MODEL='gemini-2.5-flash-lite' ;;
  groq)   BASE='https://api.groq.com/openai/v1';                          MODEL='llama-3.3-70b-versatile' ;;
  *) echo 'روش: sudo bash deploy/ai-free-setup.sh gemini|groq <API_KEY>' >&2; exit 1 ;;
esac
[ ${#KEY} -ge 20 ] && [[ "$KEY" != *' '* ]] || { echo 'کلید معتبر به نظر نمی‌رسد.' >&2; exit 1; }

# 1) live test BEFORE any change
code=$(curl -s -o /tmp/ai-key-test.json -w '%{http_code}' --max-time 20 \
  -X POST "$BASE/chat/completions" \
  -H "Authorization: Bearer $KEY" -H 'Content-Type: application/json' \
  --data "{\"model\":\"$MODEL\",\"messages\":[{\"role\":\"user\",\"content\":\"ping\"}],\"max_tokens\":5}")
[ "$code" = 200 ] || { echo "کلید جواب نداد (HTTP $code)؛ کلید و سرویس را چک کن." >&2; exit 1; }

# 2) keep the old primary as fallback
ENV=/etc/dastgir-secrets.env; touch "$ENV"; chmod 600 "$ENV"
old_base=$(grep -m1 '^AI_BASE_URL=' "$ENV" | cut -d= -f2- || true)
old_key=$(grep -m1 '^AI_API_KEY=' "$ENV" | cut -d= -f2- || true)
old_model=$(grep -m1 '^AI_MODEL=' "$ENV" | cut -d= -f2- || true)
if [ -n "$old_key" ] && [ "$old_key" != "$KEY" ]; then
  sed -i '/^AI_FALLBACK_BASE_URL=/d;/^AI_FALLBACK_API_KEY=/d;/^AI_FALLBACK_MODEL=/d' "$ENV"
  [ -n "$old_base" ]  && printf 'AI_FALLBACK_BASE_URL=%s\n' "$old_base"  >> "$ENV"
  [ -n "$old_key" ]   && printf 'AI_FALLBACK_API_KEY=%s\n'  "$old_key"   >> "$ENV"
  [ -n "$old_model" ] && printf 'AI_FALLBACK_MODEL=%s\n'    "$old_model" >> "$ENV"
fi

# 3) install the new primary
sed -i '/^AI_BASE_URL=/d;/^AI_API_KEY=/d;/^AI_MODEL=/d' "$ENV"
printf 'AI_BASE_URL=%s\nAI_API_KEY=%s\nAI_MODEL=%s\n' "$BASE" "$KEY" "$MODEL" >> "$ENV"
chmod 600 "$ENV"

# 4) restart + health
systemctl restart bazarche
sleep 3
curl -fsS http://127.0.0.1:8080/healthz >/dev/null
echo "✅ اتصال هوش مصنوعی با $P برقرار شد (مدل $MODEL)؛ کلید قبلی به‌عنوان یدک نگه داشته شد."
