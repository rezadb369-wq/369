#!/usr/bin/env bash
# v253: اعمال مغز پخته‌شده در بسته (deploy/brain.env) روی فایل رازها —
# همهٔ خط‌های AI_* قبلی را کامل حذف و مغز جدید را می‌گذارد؛ بقیهٔ خط‌ها
# (توکن بات و…) دست‌نخورده می‌مانند. idempotent با stamp.
# قابل تست: مسیرها با DASTGIR_APP / DASTGIR_SECRETS قابل تغییرند.
set -euo pipefail
APP="${DASTGIR_APP:-/opt/dastgir}"
SECRETS="${DASTGIR_SECRETS:-/etc/dastgir-secrets.env}"
BRAIN="$APP/deploy/brain.env"
[ -f "$BRAIN" ] || exit 0
H="$(sha256sum "$BRAIN" | cut -d' ' -f1)"
STAMP="$SECRETS.brain-stamp"
if [ "$(cat "$STAMP" 2>/dev/null || true)" = "$H" ]; then exit 0; fi
if [ -f "$SECRETS" ]; then cp -f "$SECRETS" "$SECRETS.bak"; fi
touch "$SECRETS"
grep -v '^AI_' "$SECRETS" > "$SECRETS.new" || true
cat "$BRAIN" >> "$SECRETS.new"
mv -f "$SECRETS.new" "$SECRETS"
chmod 600 "$SECRETS"
# v255 (دستور مدیر: «توکن قبلی کلاً حذف بشه»): پس از اعمال موفق، هیچ ردپایی
# از کلید قبلی نمی‌ماند — فایل پشتیبانِ گذرا هم پاک می‌شود.
rm -f "$SECRETS.bak"
printf '%s\n' "$H" > "$STAMP"
chmod 600 "$STAMP"
echo "مغز هوش مصنوعی بسته نصب شد (کلید قبلی کامل حذف شد)."
