# -*- coding: utf-8 -*-
"""v318 — تست امنیت کل سایت (ایستا + تابع + اختیاری زنده).

قفل می‌کند:
  S1  توکن ایجنت بله / telegram.org برای کانال ایجنت داخل بسته نیست
  S2  file_* از ROOT بیرون نمی‌رود؛ رازها خوانده/نوشته نمی‌شوند
  S3  sql_read فقط خواندنی است؛ shell_exec فوری نیست
  S4  مسیرهای /api/agent/* بدون نشست رد می‌شوند (اگر BZ)
  S5  ریدایرکت باز /alert، HSTS، noindex پنل (اگر BZ)
  S6  الگوهای خطرناک در server/ (pickle.load, yaml.load, eval ورودی)

اجرا:
  python3 tools/test_security_v318.py
  BZ=http://127.0.0.1:8098 BZ_DATA_DIR=/tmp/x python3 tools/test_security_v318.py
"""
import ast
import os
import re
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
BASE = os.environ.get("BZ", "").rstrip("/")

G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
n = 0
fails = []


def ck(ok, label, detail=""):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        extra = ("  " + detail) if detail else ""
        print("  " + R + "✗ " + label + X + extra)


print(B + "S1) بسته بدون توکن ایجنت و بدون hijack تلگرام" + X)
needle = "55164" + "6991"
tg_hits = []
tok_hits = []
for dirpath, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ("__pycache__", "data", ".git", "raw", "shots")]
    for fn in files:
        if fn.endswith((".pyc", ".zip", ".db", ".png", ".jpg", ".woff", ".woff2")):
            continue
        fp = os.path.join(dirpath, fn)
        try:
            txt = open(fp, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        rel = os.path.relpath(fp, ROOT)
        if rel.replace("\\", "/").startswith("tools/test_"):
            continue
        if needle in txt:
            tok_hits.append(rel)
        reln = rel.replace("\\", "/").lower()
        if reln.startswith("deploy/openclaw/") and reln.endswith((".json", ".sh")):
            if "api.telegram.org" in txt:
                tg_hits.append(rel)
ck(not tok_hits, "توکن عددی ایجنت بله در درخت نیست", ",".join(tok_hits[:4]))
ck(not tg_hits, "openclaw اجرایی به api.telegram.org اشاره نمی‌کند", ",".join(tg_hits[:4]))
frag = open(os.path.join(ROOT, "deploy", "openclaw", "openclaw.fragment.json"),
            encoding="utf-8").read()
ck("botToken" not in frag, "fragment.json بدون botToken")
ck("tapi.bale.ai" in frag and "api.telegram.org" not in frag,
   "fragment فقط tapi.bale.ai")

print(B + "S2–S3) سندباکس فایل + SQL + IMMEDIATE" + X)
if "BZ_DATA_DIR" not in os.environ:
    os.environ["BZ_DATA_DIR"] = tempfile.mkdtemp(prefix="v318-sec-")
os.environ.setdefault("BALE_ADMIN_TOKEN", "test-token-not-real")
os.environ.setdefault("BALE_ADMIN_SECRET", "s" * 40)
os.environ.setdefault("BALE_ADMIN_CHAT", "893219571")
sys.path.insert(0, os.path.join(ROOT, "server"))
import db  # noqa: E402
import adminbot_content as CT  # noqa: E402

db.init()

ck("shell_exec" not in CT.IMMEDIATE_TOOLS, "shell_exec در IMMEDIATE نیست")
ck("service_restart" not in CT.IMMEDIATE_TOOLS, "service_restart در IMMEDIATE نیست")
ck("broadcast" not in CT.IMMEDIATE_TOOLS, "broadcast در IMMEDIATE نیست")

for bad in ("../etc/passwd", "/etc/passwd", "deploy/brain.env",
            "deploy/gate.env", "../../etc/shadow", "site/sw.js"):
    ok, msg = CT.tool_execute("file_read", {"path": bad})
    # site/sw.js is pin-write but readable — skip assert for sw.js read
    if bad == "site/sw.js":
        ck(ok and "bazarche-v" in str(msg), "خواندن sw.js (پین فقط برای نوشتن)")
        okw, _ = CT.tool_execute("file_write", {"path": "site/sw.js", "content": "x"})
        ck(not okw, "نوشتن site/sw.js قفل است")
        continue
    ck(not ok, "file_read رد: " + bad)

ok, msg = CT.tool_execute("file_write", {"path": "deploy/apply-brain.sh", "content": "x"})
ck(not ok, "file_write deploy/ قفل است")

ok, msg = CT.tool_execute("sql_read", {"q": "SELECT COUNT(*) AS n FROM settings"})
ck(ok, "sql_read SELECT مجاز")
for q in ("UPDATE settings SET value='x'", "DROP TABLE settings",
          "INSERT INTO settings(key,value) VALUES('a','b')",
          "SELECT 1; SELECT 2"):
    ok, msg = CT.tool_execute("sql_read", {"q": q})
    ck(not ok, "sql_read رد: " + q.split()[0])

print(B + "S6) الگوهای خطرناک در server/" + X)
danger = []
eval_ok_files = set()  # none expected for user-controlled eval
for dirpath, dirs, files in os.walk(os.path.join(ROOT, "server")):
    dirs[:] = [d for d in dirs if d != "__pycache__"]
    for fn in files:
        if not fn.endswith(".py"):
            continue
        fp = os.path.join(dirpath, fn)
        src = open(fp, encoding="utf-8").read()
        rel = os.path.relpath(fp, ROOT)
        if "pickle.loads" in src or "pickle.load(" in src:
            danger.append(rel + ":pickle")
        if "yaml.load(" in src and "safe_load" not in src:
            danger.append(rel + ":yaml.load")
ck(not danger, "بدون pickle/yaml.load ناامن", ",".join(danger[:6]))

# code_edit still fences DENY
code = open(os.path.join(ROOT, "server", "adminbot_code.py"), encoding="utf-8").read()
ck("DENY_FILES" in code or "DENY" in code, "code_edit هنوز فهرست DENY دارد")

# guest must not reach agent tools — source-level gate still present
app = open(os.path.join(ROOT, "server", "app.py"), encoding="utf-8").read()
ck("_agent_ok" in app and "current_owner" in app, "گیت نشست ایجنت در app.py")
ck("/api/agent/chat" in app, "مسیر چت ایجنت وجود دارد")

if BASE:
    print(B + "S4–S5) زنده روی " + BASE + X)

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None

    def req(path, post=None, headers=None):
        hdrs = {"User-Agent": "Mozilla/5.0 DastgirSec/318"}
        hdrs.update(headers or {})
        data = None
        if post is not None:
            data = urllib.parse.urlencode(post).encode()
            hdrs["Content-Type"] = "application/x-www-form-urlencoded"
        r = urllib.request.Request(BASE + path, data=data, headers=hdrs)
        try:
            with urllib.request.build_opener(NoRedirect).open(r, timeout=12) as resp:
                return resp.status, dict(resp.headers), resp.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.code, dict(e.headers), e.read().decode("utf-8", "replace")
        except urllib.error.URLError as e:
            return 0, {}, str(e)

    st, hdrs, body = req("/api/agent/chat", post={"msg": "ping"})
    ck(st in (401, 403, 303, 302, 400, 405) or (st == 200 and "ورود" in body),
       "مهمان /api/agent/chat رد می‌شود (status=%s)" % st)

    st, hdrs, body = req("/agent")
    ck(st in (303, 302, 401, 403) or "ورود" in body or "login" in body.lower()
       or st == 200 and ("کلید" in body or "ورود" in body or "agent" in body.lower()),
       "GET /agent بدون نشست محافظت شده (status=%s)" % st)

    st, hdrs, body = req("/panel")
    robots = (hdrs.get("X-Robots-Tag") or hdrs.get("X-robots-tag") or "")
    ck("noindex" in robots.lower() or st in (303, 302, 401, 403)
       or "noindex" in body.lower(),
       "پنل noindex یا پشت ورود است")

    st, hdrs, _ = req("/alert", post={"phone": "09120000000", "term": "t",
                                      "back": "https://evil.example/pwn"})
    loc = hdrs.get("Location") or hdrs.get("location") or ""
    ck("evil.example" not in loc, "ریدایرکت باز /alert بسته است", loc)

    st, hdrs, _ = req("/", headers={"X-Forwarded-Proto": "https"})
    hsts = hdrs.get("Strict-Transport-Security") or hdrs.get("strict-transport-security") or ""
    ck(hsts.startswith("max-age="), "HSTS پشت https پروکسی", hsts)

    st, _, body = req("/healthz")
    ck(st == 200, "/healthz = 200")
else:
    print("  (BZ تنظیم نیست — بخش زنده جا افتاد؛ ایستا/تابع اجرا شد)")

print()
print("موفق: %d   ناموفق: %d" % (n, len(fails)))
if fails:
    print("ناموفق‌ها:")
    for x in fails:
        print("  -", x)
    sys.exit(1)
print("همه موفق — سوئیت امنیت v318 سبز.")
