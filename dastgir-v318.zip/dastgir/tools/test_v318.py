# -*- coding: utf-8 -*-
"""v318 — ایجنت کامل + ling پیش‌فرض + پنل زیر ایجنت + OpenClaw بدون توکن.

دستور مدیر: ایجنت قبلی را برگردان و بهتر کن؛ ling پیش‌فرض؛ پنل مدیر زیر
ایجنت؛ دسترسی فایل سایت؛ توکن ایجنت بله داخل زیپ نیست؛ shell_exec غیرفوری.

اجرا:  python3 tools/test_v318.py
"""
import ast
import json
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))

G, R, X = "\033[32m", "\033[31m", "\033[0m"
n = 0
fails = []


def ck(ok, label):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        print("  " + R + "✗ " + label + X)


TMP = tempfile.mkdtemp(prefix="v318-")
os.environ["BZ_DATA_DIR"] = os.environ.get("BZ_DATA_DIR", TMP)
os.environ["BALE_ADMIN_TOKEN"] = "test-token-not-real"
os.environ["BALE_ADMIN_SECRET"] = "s" * 40
os.environ["BALE_ADMIN_CHAT"] = "893219571"
os.environ["ADMINBOT_QUEUE"] = os.path.join(TMP, "q")
os.environ["ADMINBOT_PENDING"] = os.path.join(TMP, "pending.json")
os.environ["ADMINBOT_MEMORY"] = os.path.join(TMP, "mem.json")
os.environ["ADMINBOT_IMAGE"] = os.path.join(TMP, "image.json")
os.environ["ADMINBOT_CODE"] = os.path.join(TMP, "code.json")
sys.path.insert(0, os.path.join(ROOT, "server"))

import db  # noqa: E402
import assistant as AI  # noqa: E402
import adminbot as A  # noqa: E402
import adminbot_content as CT  # noqa: E402
import agent_cmds as OC  # noqa: E402
import views_agent_full as VAF  # noqa: E402
import ui  # noqa: E402

db.init()

print("v318 — پین نسخه + ling + ایجنت + فایل + OpenClaw")

ver = open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8").read().strip()
sw = open(os.path.join(ROOT, "site", "sw.js"), encoding="utf-8").read()
readme = open(os.path.join(ROOT, "README.md"), encoding="utf-8").read()
ck(ver == "318" and A.DIAG_LATEST == "318", "VERSION.txt + DIAG_LATEST = 318")
ck("bazarche-v318" in sw, "site/sw.js cache = bazarche-v318")
ck("دست گیر — v318" in readme, "README سربرگ v318")

ck(AI.SITE_DEFAULT_MODEL == "ling-3.0-flash-sante-free", "SITE_DEFAULT_MODEL = ling")
ck(AI.BYNARA_MODELS[0] == "ling-3.0-flash-sante-free", "BYNARA_MODELS[0] = ling")
ck(AI.BRAINS["bynara"][2] == "ling-3.0-flash-sante-free", "BRAINS[bynara] model = ling")
ck(len(AI.BYNARA_MODELS) == 50, "۵۰ مدل بای‌نارا")
ck("agnes-2.5-flash" in AI.BYNARA_MODELS, "agnes هنوز در فهرست است")

brain = open(os.path.join(ROOT, "deploy", "brain.env"), encoding="utf-8").read()
ck("AI_MODEL=ling-3.0-flash-sante-free" in brain, "brain.env AI_MODEL = ling")
ck("AI_SITE_MODEL=ling-3.0-flash-sante-free" in brain, "brain.env AI_SITE_MODEL = ling")

kb = A.SITE_KEYBOARD["keyboard"]
ck(kb[0][0] == "ling-3.0-flash-sante-free", "SITE_KEYBOARD ling اول است")

ck("shell_exec" not in CT.IMMEDIATE_TOOLS,
   "shell_exec غیرفوری است (پین v310)")
ck("file_read" in CT.IMMEDIATE_TOOLS and "file_write" in CT.IMMEDIATE_TOOLS
   and "file_edit" in CT.IMMEDIATE_TOOLS and "file_delete" in CT.IMMEDIATE_TOOLS,
   "file_read/write/edit/delete فوری‌اند")

missing_fa = [t for t in CT.TOOLS if t not in VAF.TOOL_FA]
ck(not missing_fa, "TOOL_FA همهٔ ابزارها را پوشش می‌دهد")

ok, msg = CT.tool_execute("file_read", {"path": "VERSION.txt"})
ck(ok and "318" in str(msg), "file_read VERSION.txt (کل سایت)")

ok, msg = CT.tool_execute("file_read", {"path": "docs/collaboration/RULES.md"})
ck(ok and "صداقت" in str(msg), "file_read RULES.md")

ok, msg = CT.tool_execute("file_read", {"path": "docs/collaboration/KNOWLEDGE.md"})
ck(ok and "v318" in str(msg), "file_read KNOWLEDGE.md")

ok, msg = CT.tool_execute("file_read", {"path": "docs/collaboration/HANDOFF.md"})
ck(ok and "v318" in str(msg), "file_read HANDOFF.md")

ok, msg = CT.tool_execute("file_read", {"path": "deploy/brain.env"})
ck(not ok, "file_read brain.env قفل است")

ok, msg = CT.tool_execute("file_read", {"path": "server/../deploy/brain.env"})
ck(not ok, "file_read path traversal رد شد")

ok, msg = CT.tool_execute("file_read", {"path": "/etc/passwd"})
ck(not ok, "file_read /etc/passwd رد شد")

ok, msg = CT.tool_execute("file_list", {"path": "server"})
ck(ok and ("assistant.py" in str(msg) or "adminbot.py" in str(msg)),
   "file_list server/ فایل‌های کد را می‌بیند")

ok, msg = CT.tool_execute("file_write", {"path": "VERSION.txt", "content": "nope"})
ck(not ok, "file_write VERSION.txt قفل است")

ok, msg = CT.tool_execute("file_write", {"path": "v318probe", "content": "hello-318"})
ck(ok, "file_write تبادل مجاز است")
ok, msg = CT.tool_execute("file_read", {"path": "v318probe"})
ck(ok and "hello-318" in str(msg), "file_read همان فایل تبادل")
ok, msg = CT.tool_execute("file_delete", {"path": "v318probe"})
ck(ok, "file_delete تبادل")

ok, msg = CT.tool_execute("sql_read", {"q": "SELECT 1 AS n"})
ck(ok, "sql_read SELECT")
ok, msg = CT.tool_execute("sql_read", {"q": "DELETE FROM settings"})
ck(not ok, "sql_read نوشتن رد می‌شود")

# OpenClaw slashes
ck(OC.try_slash("سلام") is None, "متن آزاد → None")
ck(OC.try_slash("/help") is None, "/help fall-through به راهنمای فارسی")
ck(OC.try_slash("/status") is None, "/status fall-through")
h = OC.try_slash("/commands")
ck(isinstance(h, str) and "dastgir_panel_access" in h and "ling-3.0-flash-sante-free" in h,
   "/commands فهرست OpenClaw")
p = OC.try_slash("/dastgir_panel_access")
ck(isinstance(p, str) and "/panel" in p and "/agent" in p, "/dastgir_panel_access")
d = OC.try_slash("/dastgir_site_data")
ck(isinstance(d, str) and len(d) > 20, "/dastgir_site_data")
w = OC.try_slash("/whoami")
ck(isinstance(w, str) and "318" in w, "/whoami نسخه")
e = OC.try_slash("/elevated")
ck(isinstance(e, str) and "آزاد" in e, "/elevated")
sil = OC.try_slash("/browser")
ck(isinstance(sil, str) and "ساکت" not in sil, "/browser هرگز ساکت نیست")

# /exec is rewritten in handle_text before try_slash
rep, _ = A.handle_text("u1", "893219571", "/exec echo v318-exec")
ck("v318-exec" in (rep or "") and "کد خروج: 0" in (rep or ""),
   "/exec → do_shell واقعی")

# UI: agent group first, admin under agent
groups = ui.OWNER_NAV_GROUPS
ck(groups[0][0] == "ایجنت", "ناوی: گروه ایجنت اول است")
flat0 = [x[0] for x in groups[0][1]]
ck("/panel/agent" in flat0 and "/panel" in flat0, "ناوی: کنسول + پنل مدیر زیر آن")
src_vaf = open(os.path.join(ROOT, "server", "views_agent_full.py"), encoding="utf-8").read()
ck(src_vaf.count("پنل مدیر — زیر دست ایجنت") == 2, "هاب پنل در /agent و /panel/agent")

# OpenClaw package — no token value
frag = json.loads(open(os.path.join(ROOT, "deploy", "openclaw",
                                    "openclaw.fragment.json"), encoding="utf-8").read())
ck(len(frag["models"]["providers"]["bynara"]["models"]) == 50,
   "fragment ۵۰ مدل bynara")
ck(frag["agents"]["defaults"]["model"]["primary"] == "bynara/ling-3.0-flash-sante-free",
   "fragment مدل اولیه ling")
ck(frag["channels"]["telegram"]["apiRoot"] == "https://tapi.bale.ai",
   "fragment apiRoot = tapi.bale.ai")
ck("botToken" not in frag["channels"]["telegram"], "fragment بدون botToken")
ck(frag["commands"]["native"] is False, "fragment commands.native=false")

apply_oc = open(os.path.join(ROOT, "deploy", "openclaw", "apply-openclaw.sh"),
                encoding="utf-8").read()
ck("BALE_BOT_TOKEN" in apply_oc and "Never" in open(
    os.path.join(ROOT, "deploy", "openclaw", "apply-openclaw.sh"), encoding="utf-8").read()
   or "never copy BALE_BOT_TOKEN" in apply_oc.lower() or "BALE_ADMIN_TOKEN" in apply_oc,
   "apply-openclaw توکن‌های دیگر را کپی نمی‌کند")
ck(("55164"+"6991") not in apply_oc, "apply-openclaw بدون توکن عددی ایجنت")

upd = open(os.path.join(ROOT, "deploy", "update.sh"), encoding="utf-8").read()
ck("apply-openclaw.sh" in upd, "update.sh → apply-openclaw.sh")

abrain = open(os.path.join(ROOT, "deploy", "apply-brain.sh"), encoding="utf-8").read()
ck("ling-3.0-flash-sante-free" in abrain and "agnes-2.5-flash" in abrain,
   "apply-brain مهاجرت ling فقط برای خالی/agnes")

# token must not appear as a BALE agent secret in the tree (name is OK)
agent_tok_needle = "55164" + "6991"
hits = []
for dirpath, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ("__pycache__", "data", ".git")]
    for fn in files:
        rel = os.path.relpath(os.path.join(dirpath, fn), ROOT)
        if fn.endswith((".pyc", ".zip", ".db")):
            continue
        if rel.replace("\\", "/").startswith("tools/test_"):
            continue
        fp = os.path.join(dirpath, fn)
        try:
            txt = open(fp, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        if agent_tok_needle in txt:
            hits.append(rel)
ck(not hits, "توکن ایجنت بله در درخت نیست" + ((" — " + ",".join(hits[:5])) if hits else ""))

# key python files parse
for rel in ("server/adminbot.py", "server/adminbot_content.py",
            "server/agent_cmds.py", "server/views_agent_full.py",
            "server/assistant.py", "server/ui.py"):
    ast.parse(open(os.path.join(ROOT, rel), encoding="utf-8").read())
ck(True, "فایل‌های کلیدی parse می‌شوند")

# docs present
ck(os.path.isfile(os.path.join(ROOT, "docs", "collaboration", "HANDOFF.md")),
   "HANDOFF.md موجود است")
cs = open(os.path.join(ROOT, "docs", "collaboration", "CURRENT-STATE.md"),
          encoding="utf-8").read()
ck("v318" in cs.split("\n", 1)[0], "CURRENT-STATE سربرگ v318")

print()
print("موفق: %d   ناموفق: %d" % (n, len(fails)))
if fails:
    print("ناموفق‌ها:")
    for x in fails:
        print("  -", x)
    sys.exit(1)
print("همه موفق — v318 قفل شد.")
