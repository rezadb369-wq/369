# HANDOFF — v318 (۲۲/۰۹/۲۰۲۶)

بخوان قبل از هر تغییر: `RULES.md` · `CURRENT-STATE.md` · `KNOWLEDGE.md` · `WHATS-NEW.md` · همین فایل.

## الان چیست

سایت **دست‌گیر / daastgir.ir** — دایرکتوری کسب‌وکار. نسخهٔ زندهٔ بسته: **v318**.

- مغز پیش‌فرض مدیر+سایت+ایجنت: **`ling-3.0-flash-sante-free`** روی روتر byNara (کلید در `deploy/brain.env`). ۵۰ مدل در `assistant.BYNARA_MODELS`؛ `agnes-2.5-flash` هنوز هست.
- **سوئیچ خودکار مغز ممنوع** (v265). اسلات هوش سایت (`AI_SITE_*`) جدا از مغزهای مدیر است (v269) — فقط پس‌انداز کلید bynara وقتی کلید سایت خالی است (دستور مدیر v317).
- ایجنت داخلی: `/agent` و `/panel/agent` + بات مدیر بله (`adminbot.py` + `agent_cmds.py`). پنل مدیر از نظر UI **زیر** ایجنت است.
- OpenClaw روی VPS اگر از قبل نصب باشد: `deploy/openclaw/apply-openclaw.sh` (از `update.sh`). **توکن ایجنت بله در این زیپ نیست.** `BALE_BOT_TOKEN` و `BALE_ADMIN_TOKEN` را عوض نکن. پالر دوم نساز — OpenClaw زنده getUpdates را گرفته.
- `shell_exec` در `IMMEDIATE_TOOLS` نیست (پین `test_agent_tools_v310.py`).

## کار بعدی (اگر چیزی ماند)

1. روی VPS: `sudo bash /opt/dastgir/deploy/update.sh /tmp/dastgir-v318.zip`
2. اگر OpenClaw باید با توکن ایجنت حرف بزند، فقط در `/etc/dastgir-secrets.env` بگذار: `BALE_AGENT_TOKEN=...` (نه در زیپ) و دوباره `apply-openclaw.sh`.
3. هرگز `tapi.bale.ai` را با `api.telegram.org` عوض نکن برای این توکن.

## پین‌های نسخه

| فایل | مقدار |
|---|---|
| `VERSION.txt` | `318` |
| `site/sw.js` | `bazarche-v318` |
| `server/adminbot.py` → `DIAG_LATEST` | `"318"` |
| `README.md` سربرگ | `دست گیر — v318` |

## تست‌ها

```
python3 tools/test_v318.py
python3 tools/test_security_v318.py
python3 tools/test_agent_tools_v310.py
```

سرور زنده (اختیاری): `BZ_DATA_DIR=/tmp/x PORT=8098 python3 run.py` سپس `BZ=http://127.0.0.1:8098 python3 tools/test_security_v318.py`.
