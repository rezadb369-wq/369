# -*- coding: utf-8 -*-
"""v239→v240: FULL-power content tools for the owner-only Bale admin copilot.

v239 covered settings/pages/posts/categories/businesses/items/reviews/
moderation/broadcast. v240 closes the gap to "everything the admin panel
can edit", mirroring each panel surface with the site's own functions:

  * dynamic settings: ANY key the panel itself uses (minus secrets/locks)
  * coupons, toplists, flashdeals, city events, ads, plans, badges, stories
  * business category / map pin / cover / images; item images/options/spec
  * claims moderation, ticket replies, customer block/unblock
  * order status, booking status, area rename, trash restore, review delete
  * IMAGES: the admin sends a photo in the bot chat (adminbot saves it via
    uploads.save_image) and the model references it as "__last__" — the
    sentinel is resolved server-side, so the model can never point at an
    arbitrary filesystem path.

Architecture is unchanged (the v223 safe-tools pattern, admin variant):
model PROPOSES → strict parse (allow-lists, no secrets, caps) → precheck
against the live DB without writing → the owner's separate «بله» →
re-parse + re-precheck + execute through the site's own savers + audit
row ``db.log("admin_ai_tool", ...)``. Site CODE, files and secrets stay
untouchable by design.
"""
import difflib
import json
import os
import re
import time

import db
import features
import adminbot_code as CODE   # v241: full-site code access

TOOLS = ("setting", "page", "post_save", "post_delete", "category_save",
         "category_delete", "business_save", "item_save", "item_delete",
         "review_moderate", "review_delete", "biz_moderate", "broadcast",
         # v240: the rest of the panel's content surfaces
         "coupon_save", "coupon_delete", "toplist_save", "toplist_delete",
         "flashdeal_save", "flashdeal_delete", "event_save", "event_delete",
         "ad_save", "ad_delete", "plan_save", "plan_delete",
         "badge_save", "badge_delete", "story_add", "story_delete",
         "claim_moderate", "ticket_reply", "customer_moderate",
         "order_status", "booking_status", "area_rename", "trash_restore",
         # v241: full code access (edits deploy via the root codeguard cron)
         "code_list", "code_read", "code_edit", "code_write", "code_revert",
         "code_search", "code_status", "ai_setup", "service_restart", "brain_switch",
         # v282 (دستور مدیر): خواندن همهٔ بخش‌های پنل + دو تغییر جامانده
         "panel_read", "panel_sections", "subscription_set", "owner_moderate",
         # v287 (دستور مدیر): دسترسی واقعی امنیت — گزارش زنده با عدد و دلیل
         "sec_report",
         # v297: ایجنت جدید — عملیات گروهی + سلامت + سئو + بکاپ + کش
         "bulk_approve", "backup_now", "cache_clear", "seo_check", "health_check",
         # v316: file exchange only — arena removed per owner request
         "file_list", "file_upload", "file_download",
         # v310 (دستور مدیر): ترمینال واقعی + پرس‌وجوی خواندنی + لاگ زنده
         "shell_exec", "sql_read", "log_tail",
         # v312 (دستور مدیر): امکانات بیشتر — سیستم آزاد و کامل
         "sys_info", "file_read", "file_write", "file_edit", "file_delete",
         "db_tables", "backup_list", "version_info")

# v241: read-only code tools execute immediately (no «بله» needed for reads)
# v316: arena removed — only file_* remain immediate for live chat
IMMEDIATE_TOOLS = ("code_list", "code_read", "code_search", "code_status",
                   "panel_read", "panel_sections",   # v282: reads never wait
                   "sec_report",                     # v287: security read
                   "file_list", "file_upload", "file_download",
                   "seo_check", "health_check", "backup_now", "cache_clear", "bulk_approve",
                   # v310: خواندنی‌ها فوری‌اند؛ shell_exec عمداً فوری نیست —
                   # پیشنهادِ هوش برای فرمان باید از «بله» مدیر رد شود.
                   "sql_read", "log_tail",
                   # v312: خواندنی‌های جدید فوری‌اند
                   "sys_info", "file_read", "db_tables", "backup_list",
                   "version_info",
                   # v318: نوشتن فایل سایت/تبادل فوری است (مالک؛ رازها قفل)
                   "file_write", "file_edit", "file_delete")

# ---- v248: self-repairing tool calls (weak models misname/misshape) ----
_TOOL_ALIAS = {
    # v287: security lane — names weak brains invent for the security report
    "security": "sec_report", "security_report": "sec_report",
    "security_status": "sec_report", "sec_status": "sec_report",
    "sec_check": "sec_report", "ssh_report": "sec_report",
    "ssh_status": "sec_report", "ssh_check": "sec_report",
    "firewall": "sec_report", "fail2ban": "sec_report",
    "server_security": "sec_report", "audit": "sec_report",
    # code lane — the names weak brains naturally invent
    "read_file": "code_read", "open_file": "code_read", "view_file": "code_read",
    "read_code": "code_read", "cat": "code_read", "readfile": "code_read",
    "edit_code": "code_edit", "editfile": "code_edit", "edit_file": "code_edit",
    "modify_code": "code_edit", "modify_file": "code_edit", "apply_edit": "code_edit",
    "replace_text": "code_edit", "fix_code": "code_edit", "patch": "code_edit",
    "write_file": "code_write", "create_file": "code_write", "new_file": "code_write",
    "write_code": "code_write", "make_file": "code_write",
    "search_code": "code_search", "code_find": "code_search", "find_text": "code_search",
    "search_text": "code_search", "grep": "code_search", "search_files": "code_search",
    "list_files": "code_list", "ls": "code_list", "list_dir": "code_list",
    "list_directory": "code_list", "show_files": "code_list", "files": "code_list",
    "revert_file": "code_revert", "undo": "code_revert", "restore": "code_revert",
    "rollback": "code_revert", "code_rollback": "code_revert",
    "restart": "service_restart", "reboot": "service_restart",
    "restart_service": "service_restart", "reload": "service_restart",
    "deploy_status": "code_status", "status": "code_status",
    # content lane — common reformulations
    "save_setting": "setting", "set_setting": "setting", "settings": "setting",
    "update_setting": "setting", "set_config": "setting", "config_set": "setting",
    "save_post": "post_save", "create_post": "post_save", "new_post": "post_save",
    "update_post": "post_save", "remove_post": "post_delete",
    "save_category": "category_save", "remove_category": "category_delete",
    "save_business": "business_save", "update_business": "business_save",
    "save_item": "item_save", "update_item": "item_save", "create_item": "item_save",
    "remove_item": "item_delete", "save_coupon": "coupon_save",
    "remove_coupon": "coupon_delete", "save_plan": "plan_save",
    "remove_plan": "plan_delete", "save_badge": "badge_save",
    "remove_badge": "badge_delete", "save_ad": "ad_save", "remove_ad": "ad_delete",
    "save_event": "event_save", "remove_event": "event_delete",
    "save_toplist": "toplist_save", "remove_toplist": "toplist_delete",
    "save_flashdeal": "flashdeal_save", "remove_flashdeal": "flashdeal_delete",
    "add_story": "story_add", "remove_story": "story_delete",
    "reply_ticket": "ticket_reply", "answer_ticket": "ticket_reply",
    "block_customer": "customer_moderate", "moderate_customer": "customer_moderate",
    "update_order": "order_status", "update_booking": "booking_status",
    "rename_area": "area_rename", "restore_trash": "trash_restore",
    "review_action": "review_moderate", "moderate_review": "review_moderate",
    "biz_action": "biz_moderate", "send_broadcast": "broadcast",
    # v297 new tools
    "approve_all": "bulk_approve", "bulk_approve_all": "bulk_approve",
    "backup": "backup_now", "make_backup": "backup_now", "backup_db": "backup_now",
    "clear_cache": "cache_clear", "cache_purge": "cache_clear",
    "check_seo": "seo_check", "seo_report": "seo_check",
    "check_health": "health_check", "health": "health_check",
    # v310
    "shell": "shell_exec", "terminal": "shell_exec", "run": "shell_exec",
    "exec": "shell_exec", "ترمینال": "shell_exec", "فرمان": "shell_exec",
    "sql": "sql_read", "query": "sql_read", "select": "sql_read",
    "پرس‌وجو": "sql_read", "پرسوجو": "sql_read", "logs": "log_tail", "log": "log_tail", "لاگ": "log_tail",
    # v316: file exchange only — arena removed
    "list_files": "file_list", "files": "file_list", "ls_files": "file_list",
    "upload": "file_upload", "upload_file": "file_upload",
    "download": "file_download", "download_file": "file_download", "get_file": "file_download",
    # v312 new aliases
    "sysinfo": "sys_info", "sys": "sys_info", "system": "sys_info", "سیستم": "sys_info",
    "read": "file_read", "خواندن فایل": "file_read",
    "write": "file_write", "نوشتن فایل": "file_write",
    "edit": "file_edit", "ویرایش فایل": "file_edit",
    "delete_file": "file_delete", "rm": "file_delete", "حذف فایل": "file_delete",
    "tables": "db_tables", "جدول‌ها": "db_tables",
    "backups": "backup_list", "list_backups": "backup_list", "بکاپ‌ها": "backup_list",
    "version": "version_info", "نسخه": "version_info",
}
_TOKEN_TOOLS = {frozenset(t.split("_")): t for t in TOOLS}


def normalize_tool_name(name):
    """Canonical tool name from a model's invented name, or None.
    exact → alias → token-set (handles save_post/post_save swaps) →
    close spelling (difflib). Deterministic and pure."""
    s = str(name or "").strip().lower()
    # v310: مستعارهای فارسی قبل از حذف نویسه‌های غیرascii دیده شوند
    # (ZWNJ حذف و ي عربی به ی فارسی یکدست می‌شود).
    _fa = s.replace("\u200c", "").replace("ي", "ی")
    if _fa in _TOOL_ALIAS:
        return _TOOL_ALIAS[_fa]
    if s in _TOOL_ALIAS:
        return _TOOL_ALIAS[s]
    s = s.replace("-", "_").replace(" ", "_")
    s = re.sub(r"[^a-z0-9_]", "", s)
    if not s:
        return None
    if s in TOOLS:
        return s
    if s in _TOOL_ALIAS:
        return _TOOL_ALIAS[s]
    tok = frozenset(x for x in s.split("_") if x)
    if tok in _TOKEN_TOOLS:
        return _TOKEN_TOOLS[tok]
    m = difflib.get_close_matches(s, TOOLS, n=1, cutoff=0.8)
    return m[0] if m else None


def repair_args(name, a):
    """Fix the most common weak-model argument shapes (pure)."""
    try:
        if not isinstance(a, dict):
            return a
        if not a.get("path") and a.get("file") and name in (
                "code_list", "code_read", "code_edit", "code_write", "code_revert"):
            a = dict(a, path=a["file"])
        if name == "code_edit" and not a.get("edits") \
                and a.get("old") is not None and a.get("new") is not None:
            a = dict(a, edits=[{"old": str(a["old"]), "new": str(a["new"])}])
        if name == "code_read":
            frm = a.get("from_line") or a.get("start") or a.get("from") or 1
            to = a.get("to_line") or a.get("end") or a.get("to")
            a = dict(a, from_line=frm, **({"to_line": to} if to is not None else {}))
        if name == "code_search" and not a.get("query"):
            for k in ("q", "text", "term", "keyword", "search", "find"):
                if a.get(k):
                    a = dict(a, query=a[k])
                    break
        if name == "code_list" and "path" not in a:
            for k in ("dir", "folder", "directory"):
                if k in a:
                    a = dict(a, path=a[k])
                    break
        if name == "setting":
            # v268: batch form — repair every item's key the same way.
            if isinstance(a.get("items"), list):
                _fixed = []
                for _it in a.get("items"):
                    if isinstance(_it, dict):
                        _fixed.append(repair_args(name, dict(_it)))
                    else:
                        _fixed.append(_it)
                return dict(a, items=_fixed)
            # v250: weak brains wrap the pair in many shapes — setting/key_name
            # for the key, new_value/to/new for the value.
            if not a.get("key"):
                for k in ("setting", "setting_key", "key_name", "name"):
                    if a.get(k):
                        a = dict(a, key=a[k])
                        break
            if "value" not in a:
                for k in ("val", "new_value", "v", "to", "new"):
                    if a.get(k) is not None:
                        a = dict(a, value=a[k])
                        break
            if a.get("key"):     # v250: "Site Title" / "site-title" shapes
                _fk = _FA_SETTING_KEYS.get(_fa_key_norm(a["key"]))
                if _fk:               # v268: Persian name ("رنگ اصلی")
                    a = dict(a, key=_fk)
                else:
                    k2 = str(a["key"]).strip().lower().replace(" ", "_").replace("-", "_")
                    if k2:
                        a = dict(a, key=k2)
        return a
    except Exception:
        return a

TOOL_TTL = 300          # seconds a proposed tool stays confirmable

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ------------------------------------------------------------------ images
UPLOADS_URL = "/assets/img/uploads/"     # uploads.save_image returns leading-slash paths
_IMAGE_RX = re.compile(r"^/?assets/img/[A-Za-z0-9_.\-/]{1,140}$")
_DT_RX = re.compile(r"^\d{4}-\d{2}-\d{2}([ T]\d{2}:\d{2}(:\d{2})?)?$")


def image_sidefile():
    return os.environ.get("ADMINBOT_IMAGE") or "/tmp/dastgir-admin-image.json"


def image_save(public_path):
    """Remember the admin's last uploaded photo (15-minute TTL)."""
    try:
        with open(image_sidefile(), "w", encoding="utf-8") as f:
            json.dump({"path": str(public_path), "ts": time.time()}, f)
        return True
    except OSError:
        return False


def image_last(max_age=900):
    """Path of the admin's last uploaded photo, or ''. Never raises."""
    try:
        with open(image_sidefile(), encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict) and time.time() - float(d.get("ts", 0)) < max_age:
            p = str(d.get("path") or "")
            if p.startswith(UPLOADS_URL) and os.path.isfile(
                    os.path.join(ROOT, "site", p.lstrip("/"))):
                return p
    except (OSError, ValueError, TypeError):
        pass
    return ""


def _image_ok(v):
    """Parse-time shape check only (no FS)."""
    v = str(v or "").strip()
    if v == "__last__":
        return True
    return bool(_IMAGE_RX.match(v)) and ".." not in v


def _resolve_image(v):
    """Resolve to a real, existing public image path, or None."""
    v = str(v or "").strip()
    if v == "__last__":
        return image_last() or None
    if not _IMAGE_RX.match(v) or ".." in v:
        return None
    if not os.path.isfile(os.path.join(ROOT, "site", v.lstrip("/"))):
        return None
    return v if v.startswith("/") else "/" + v   # stored like save_image does


# ------------------------------------------------------------------ settings
# Keys the model may NEVER touch (mirrors adminbot._SNAP_SECRET_RX plus the
# brand lock and the lockout/operational keys). Refused at parse time.
_SECRET_RX = ("token", "secret", "pass", "key", "salt", "hash", "bearer",
              "credential", "private")
# v265 (دستور مدیر — «دسترسی کامل»): هیچ کلیدی از بات قفل نیست؛ هر ۴ کلید
# ورود/امنیت پنل هم با «بله» قابل تغییرند. این مجموعه حالا فقط یعنی
# «نوشتن-بله / خواندن-هرگز»: مقدارشان در پیشنهاد/لاگ/اسنپشات قرمز می‌ماند و
# مدل مقدار فعلی را هیچ‌وقت نمی‌بیند — فقط مقدار تازه‌ای که خود مدیر داده.
_AUTH_KEYS = {"panel_allow_ips", "owner_token", "owner_pass_hash",
              "admin_bot"}

# v268 (owner order + live screenshot): the model sends Persian key names
# ("رنگ اصلی #0b6059") — map them before the english-shape gate eats them.
_FA_SETTING_KEYS = {
    "رنگ اصلی": "color_primary",
    "رنگ تأکید": "color_accent", "رنگ تاکید": "color_accent",
    "رنگ تاكيد": "color_accent", "رنگ تاکیدی": "color_accent",
    "پس زمینه": "color_background", "پسزمینه": "color_background",
    "متن اصلی": "color_foreground", "رنگ متن": "color_foreground",
}


def _fa_key_norm(k):
    return " ".join(str(k or "").replace("\u200c", " ").split()).strip().lower()

# Text/content settings with their panel-matching length caps (typed knowns;
# anything else the panel stores is accepted dynamically as a string).
TEXT_SETTINGS = {
    "site_name": 60,
    "tagline": 120, "description": 400,
    "hero_title": 120, "hero_lead": 400, "hero_cta": 60, "footer_note": 160,
    "address": 300, "email": 120, "phone": 30, "whatsapp": 30,
    "site_url": 200,
    "instagram": 100, "telegram": 100, "eitaa": 100, "bale": 100,
    "soroush": 100, "rubika": 100,
    "announcement": 300, "seo_keywords": 300, "owner_whatsapp": 30,
}
FLOAT_SETTINGS = ("map_lat", "map_lng")
INT_SETTINGS = {"map_zoom": (2, 19), "order_cancel_minutes": (0, 1440),
                "founder_limit": (0, 100000)}
# Feature toggles the panel itself exposes (SITE_FEATURES) + prices + AI.
TOGGLE_SETTINGS = (
    "prices_enabled", "reviews_moderated", "catalog_enabled",
    "events_enabled", "blog_enabled", "ads_enabled", "plans_enabled",
    "reg_open", "owner_login", "claims_enabled", "support_widget",
    "stories_enabled", "follow_enabled", "notif_enabled", "chat_enabled",
    "shop_account", "orders_enabled", "lists_enabled", "deals_enabled",
    "inquiry_enabled", "reports_enabled", "alerts_enabled", "ai_enabled",
)
# v250: weak brains answer a toggle with فعال/yes/بله… — accept the common
# synonyms instead of silently rejecting the WHOLE tool call with a
# misleading «ابزار شناخته نشد» (seen live on the production server).
_ON_WORDS = ("1", "true", "on", "روشن", "فعال", "yes", "بله",
             "enable", "enabled")
_OFF_WORDS = ("0", "false", "off", "خاموش", "غیرفعال", "no", "نه",
              "disable", "disabled")
_SETTING_KEY_RX = re.compile(r"^[a-z0-9_]{2,48}$")

DAYS = ("sat", "sun", "mon", "tue", "wed", "thu", "fri")
_HHMM = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
_ITEM_KINDS = ("product", "service", "custom")
_PRICE_TYPES = ("fixed", "call", "hour")
_ORDER_STATUSES = ("new", "confirmed", "ready", "done", "cancelled")
_BOOKING_STATUSES = ("new", "confirmed", "done", "cancelled")
_LIST_KINDS = ("manual", "auto_rating", "auto_views", "auto_featured", "auto_new")
_AD_SLOTS = ("home", "directory", "business", "sidebar")

# business content fields (everything the panel edits except slug/ownership).
_BIZ_FIELDS = {
    "name": 80, "descr": 1500, "phone": 20, "whatsapp": 20, "address": 200,
    "city": 40, "area": 60, "province": 40, "tags": 200,
    "website": 100, "instagram": 100, "telegram": 100, "eitaa": 100,
    "bale": 100, "soroush": 100, "rubika": 100, "cat_slug": 80,
}
_BIZ_STATUSES = ("published", "pending", "hidden", "rejected")

# item content fields.
_ITEM_TEXT = {"title": 120, "descr": 2000, "unit": 20, "code": 40, "note": 300,
              "brand": 60, "warranty": 120, "tags": 200, "delivery": 200,
              "video": 200}
_ITEM_NUM = ("min_order", "price", "old_price", "floor_price", "stock",
             "weight", "prep_days", "sort", "bulk_price")
_ITEM_FLAGS = ("available", "featured", "handmade", "returnable", "haggle")


def _s(v, cap=None):
    """Content text, verbatim (only whitespace-stripped) + hard cap."""
    v = str(v or "").strip()
    return v[:cap] if cap else v


def _i(v):
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return None


def _secretish(key):
    k = str(key or "").lower()
    return k in _AUTH_KEYS or any(s in k for s in _SECRET_RX)


def _norm_hours(h):
    """Validate/normalize a hours dict → JSON str; '' when malformed.

    Shape (same as the register wizard): {"sat": [["09:00","22:00"]], ...}
    Also accepts an already-serialized JSON string (idempotent re-parse).
    """
    if h in ("", None, {}):
        return "{}"
    if isinstance(h, str):
        try:
            h = json.loads(h)
        except ValueError:
            return ""
    if not isinstance(h, dict):
        return ""
    out = {}
    for day, spans in h.items():
        if day not in DAYS or not isinstance(spans, list) or len(spans) > 3:
            return ""
        norm = []
        for sp in spans:
            if (not isinstance(sp, (list, tuple)) or len(sp) != 2
                    or not _HHMM.match(str(sp[0])) or not _HHMM.match(str(sp[1]))
                    or str(sp[0]) >= str(sp[1])):
                return ""
            norm.append([str(sp[0]), str(sp[1])])
        if norm:
            out[day] = norm
    return json.dumps(out, ensure_ascii=False)


def _norm_images(v):
    """Parse-time shape check for an images value (str|list).'' when bad."""
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except ValueError:
            return ""
    if not isinstance(v, list) or len(v) > 10:
        return ""
    out = []
    for x in v:
        x = str(x or "").strip()
        if not _image_ok(x):
            return ""
        out.append(x)
    return json.dumps(out, ensure_ascii=False)


# ------------------------------------------------------------------ parse

def _setting_parse(a):
    """v250: the setting lane, single source of truth — every rejection now
    carries a Persian reason, so the owner sees WHICH gate failed instead of
    the old lie «ابزار setting شناخته نشد» (seen live on the production
    server: valid tool, rejected args, zero explanation)."""
    if "items" in a:                      # v268: batch (4 colors, one call)
        _its = a.get("items")
        if not isinstance(_its, list) or not _its:
            return None, {}, "فهرست تنظیم‌ها (items) خالی است"
        if len(_its) > 8:
            return None, {}, "حداکثر ۸ تنظیم در یک درخواست"
        _out = []
        for _ix, _itm in enumerate(_its, 1):
            if not isinstance(_itm, dict):
                return None, {}, f"قلم {_ix} شکل درستی ندارد"
            _pn, _pa, _pw = _setting_parse(dict(_itm))
            if not _pn:
                return None, {}, f"قلم {_ix}: {_pw}"
            _out.append(_pa)
        return "setting", {"items": _out}, ""
    key = str(a.get("key") or "").strip()
    if not key:
        return None, {}, "کلید تنظیم (key) نفرستاده شد"
    # v265: no key is locked anymore — even the 4 auth keys write with «بله».
    if not _SETTING_KEY_RX.match(key):
        return None, {}, (f"شکل کلید «{key[:24]}» معتبر نیست؛ "
                          "نام انگلیسی تنظیم را از پنل بپرس")
    if key in TOGGLE_SETTINGS:
        v = str(a.get("value")).strip().lower()
        if v in _ON_WORDS:
            return "setting", {"key": key, "value": "1"}, ""
        if v in _OFF_WORDS:
            return "setting", {"key": key, "value": "0"}, ""
        return None, {}, "مقدار این کلید فقط روشن یا خاموش است"
    if key in TEXT_SETTINGS:
        return "setting", {"key": key,
                           "value": _s(a.get("value"), TEXT_SETTINGS[key])}, ""
    if key in FLOAT_SETTINGS:
        try:
            f = float(str(a.get("value")).strip())
        except (TypeError, ValueError):
            return None, {}, "مقدار باید عدد باشد"
        if key == "map_lat" and not (-90 <= f <= 90):
            return None, {}, "عرض جغرافیایی باید بین ۹۰- تا ۹۰ باشد"
        if key == "map_lng" and not (-180 <= f <= 180):
            return None, {}, "طول جغرافیایی باید بین ۱۸۰- تا ۱۸۰ باشد"
        return "setting", {"key": key, "value": str(f)}, ""
    if key in INT_SETTINGS:
        n = _i(a.get("value"))
        lo, hi = INT_SETTINGS[key]
        if n is None or not (lo <= n <= hi):
            return None, {}, f"مقدار باید عدد بین {lo} و {hi} باشد"
        return "setting", {"key": key, "value": str(n)}, ""
    # v240 dynamic: any other panel key is a bounded string, exactly
    # like the panel's own form POST stores it.
    return "setting", {"key": key, "value": _s(a.get("value"), 400)}, ""


def _ai_setup_reason(a):
    """v252: exactly WHICH ai_setup input was wrong (the owner's live case:
    a valid tool died with the vague «ورودی‌ها معتبر نبود» and the owner had
    to ask why). Never echoes the key."""
    try:
        prov = str(a.get("provider") or "").strip().lower()
        key = str(a.get("key") or "").strip()
        if prov not in ("gemini", "groq", "astra", "openai", "muse",
                        "openrouter", "glm", "bynara", "site"):
            return ("سرویس باید یکی از این‌ها باشد: Muse / openrouter / openai / astra / gemini / groq / bynara / site"
                    "؛ برای کلید aa-… سرویس Muse (یا openai با آدرس و مدل)"
                    "؛ برای کلید sk-nry-… سرویس bynara (مغز ششم — روتر byNara)"
                    "؛ برای هوش عمومی سایت سرویس site")
        if not key:
            return "کلید (key) فرستاده نشد"
        if prov == "astra" and key.startswith("aa-"):
            return ("کلید aa-… مال سرویس واسط است؛ سرویس را Muse بگذار "
                    "(یا openai با آدرس https://api.avalai.ir/v1 و مدل claude-sonnet-5)")
        if prov == "astra" and key.startswith("sk-or-v1-"):
            return ("کلید sk-or-v1-… مال OpenRouter است؛ سرویس را openrouter بگذار "
                    "(نصب به‌عنوان یدک، بدون دست‌خوردن مغز اصلی)")
        if prov != "openai" and not CODE._KEY_RX[prov].match(key):
            return (f"شکل کلید برای سرویس {prov} معتبر نیست؛ "
                    "کلید کامل و بدون فاصله لازم است")
        if prov == "openai":
            base = str(a.get("base") or "").strip().rstrip("/")
            model = str(a.get("model") or "").strip()
            if not base or not CODE._BASE_RX.match(base):
                return "آدرس سرویس (base) لازم است؛ مثال: https://api.avalai.ir/v1"
            if not model or not CODE._MODEL_RX.match(model):
                return "نام مدل لازم است؛ مثال: gpt-6-astra"
            if not CODE._KEY_RX["openai"].match(key):
                return "شکل کلید معتبر نیست؛ کلید را کامل و بدون فاصله بفرست"
        if prov == "site":          # v269: هوش عمومی سایت — base/model اختیاری
            base = str(a.get("base") or "").strip().rstrip("/")
            model = str(a.get("model") or "").strip()
            if base and not CODE._BASE_RX.match(base):
                return "آدرس سرویس سایت (base) معتبر نیست؛ مثال: https://api.avalai.ir/v1"
            if model and not CODE._MODEL_RX.match(model):
                return "نام مدل سایت معتبر نیست؛ مثال: glm-5.3-flash"
        return ""
    except Exception:
        return ""


def _business_save_reason(a):
    """v264: pinpoint WHY a business_save call was rejected (pure: no DB).

    parse_with_reason consults this only after _parse_tail already failed,
    so '' safely falls back to the generic wording. Mirrors the parse
    checks in the same order (id → lat/lng → hours → cover → images →
    empty), so the sentence always names the real culprit.
    """
    try:
        bid = _i(a.get("id")) or 0
    except Exception:
        return "شناسه (id) باید عدد باشد"
    if bid < 0:
        return "شناسه (id) نامعتبر است"
    raw = a["fields"] if isinstance(a.get("fields"), dict) else a
    if not isinstance(raw, dict):
        return "فیلدها (fields) درست فرستاده نشد"
    if bid == 0 and not str(raw.get("name") or "").strip():
        return "برای ساخت کسب‌وکار تازه، نام (name) لازم است"
    if bid == 0 and not str(raw.get("cat_slug") or "").strip():
        return ("برای ساخت کسب‌وکار تازه، دسته (cat_slug) هم لازم است؛ "
                "یکی از دسته‌های فهرست محتوا را بگذار")
    for k in ("lat", "lng"):
        if raw.get(k) is not None:
            try:
                float(str(raw.get(k)).strip())
            except (TypeError, ValueError):
                return "طول/عرض جغرافیایی (lat/lng) باید عدد باشد"
    if "hours" in raw and _norm_hours(raw.get("hours")) == "":
        return "ساعت کاری (hours) درست نیست؛ نمونه: {\"sat\":[[\"09:00\",\"22:00\"]]}"
    if "cover" in raw:
        cover = str(raw.get("cover") or "").strip()
        if cover and not _image_ok(cover):
            return "عکس جلد (cover) معتبر نیست؛ اول عکس را در همین گفتگو بفرست"
    if "images" in raw and _norm_images(raw.get("images")) == "":
        return "فهرست عکس‌ها (images) درست نیست (حداکثر ۱۰ عکس معتبر)"
    if bid:
        _known = (set(_BIZ_FIELDS) | {"featured", "verified", "booking_on",
                                      "phone_public", "lat", "lng", "status",
                                      "hours", "cover", "images"})
        if not any(k in raw for k in _known):
            return "هیچ فیلدی برای ویرایش فرستاده نشد"
    return ""


def parse_with_reason(obj):
    """v250: same verdict as parse_tool_call plus a short Persian WHY a
    valid-named tool was rejected. why == '' both when accepted AND when the
    NAME itself was unknown (the caller then uses the older wording)."""
    try:
        if not isinstance(obj, dict):
            return None, {}, ""
        raw = str(obj.get("name") or "").strip()
        name = raw if raw in TOOLS else (normalize_tool_name(raw) or "")
        if not name or name not in TOOLS:
            return None, {}, ""               # the NAME is the problem
        a = obj.get("args")
        if isinstance(a, list) and name == "setting":
            a = {"items": a}                  # v268: the model's natural batch
        if not isinstance(a, dict):
            return None, {}, "ورودی ابزار (args) درست فرستاده نشد"
        a = repair_args(name, a)
        if name in ("code_list", "code_read", "code_edit", "code_write",
                    "code_revert", "code_search", "code_status", "ai_setup",
                    "service_restart", "brain_switch"):
            n2, a2 = CODE.parse(name, a)
            if n2:
                return n2, a2, ""
            # v250: a locked path deserves its own honest reason — the inputs
            # were fine, the path is protected infrastructure.
            try:
                p = str(a.get("path") or "").strip().strip("/").lower()
                if p and (p in CODE.DENY_FILES
                          or any(p == d.rstrip("/") or p.startswith(d)
                                 for d in CODE.DENY_PREFIXES)):
                    return None, {}, "مسیر قفل است و از بات تغییر نمی‌کند (زیرساخت سایت)"
            except Exception:
                pass
            if name == "ai_setup":          # v252: name the exact bad input
                why = _ai_setup_reason(a)
                if why:
                    return None, {}, why
            return None, {}, "ورودی‌های ابزار کد کامل یا معتبر نبود"
        if name == "setting":
            return _setting_parse(a)
        n2, a2 = _parse_tail(obj)
        if n2:
            return n2, a2, ""
        if name == "business_save":      # v264: name the exact bad input
            why = _business_save_reason(a)
            if why:
                return None, {}, why
        return None, {}, "ورودی‌های این ابزار کامل یا معتبر نبود"
    except Exception:
        return None, {}, ""


def reject_reason(obj):
    """v250: owner-facing why-string for a rejected proposal; '' when the
    tool NAME was the problem (a different, older message applies)."""
    try:
        return parse_with_reason(obj)[2] or ""
    except Exception:
        return ""


def parse_tool_call(obj):
    """Strict-validate a model-proposed tool call. Returns (name, args) or
    (None, {}). Unknown tools, bad shapes, secret keys and invented ids
    never pass. Pure -- no DB access. (v250: verdicts come from
    parse_with_reason; only rejection WORDING improved.)"""
    return parse_with_reason(obj)[:2]


def _parse_tail(obj):
    """The v248/v249 validation body, verbatim (verdicts unchanged)."""
    try:
        if not isinstance(obj, dict):
            return None, {}
        name = str(obj.get("name") or "").strip()
        if name not in TOOLS:                 # v248: repair invented names
            name = normalize_tool_name(name) or ""
        if not name or name not in TOOLS:
            return None, {}
        a = obj.get("args")
        if isinstance(a, list) and name == "setting":
            a = {"items": a}                  # v268: the model's natural batch
        if not isinstance(a, dict):
            return None, {}
        a = repair_args(name, a)              # v248: repair common arg shapes

        if name in ("code_list", "code_read", "code_edit", "code_write",
                    "code_revert", "code_search", "code_status", "ai_setup",
                    "service_restart", "brain_switch"):
            return CODE.parse(name, a)

        if name == "panel_sections":           # v282
            return name, {}
        if name == "sec_report":               # v287: بدون آرگومان
            return name, {}
        if name == "panel_read":               # v282
            sec = _s(a.get("section"), 40) or _s(a.get("name"), 40) or ""
            if not sec:
                return None, {}
            return name, {"section": sec, "q": _s(a.get("q"), 60) or "",
                          "id": _i(a.get("id")) or 0, "page": _i(a.get("page")) or 1}
        if name == "subscription_set":         # v282
            bid = _i(a.get("biz_id")) or 0
            slug = _s(a.get("plan_slug"), 24) or ""
            months = _i(a.get("months")) or 0
            if not bid or not slug:
                return None, {}
            return name, {"biz_id": bid, "plan_slug": slug, "months": months}
        if name == "owner_moderate":           # v282
            who = (_s(a.get("owner"), 40) or _s(a.get("phone"), 40)
                   or (str(_i(a.get("id"))) if _i(a.get("id")) else ""))
            act = _s(a.get("action"), 10) or ""
            if not who or act not in ("block", "unblock"):
                return None, {}
            return name, {"owner": who, "action": act}

        if name == "setting":
            n2, a2, _why = _setting_parse(a)
            return n2, a2

        if name == "page":
            slug = str(a.get("slug") or "").strip()
            if not re.match(r"^[a-z0-9_-]{2,30}$", slug):
                return None, {}
            title = _s(a.get("title"), 100)
            body = str(a.get("body") or "").strip()
            if not title or not body or len(body) > 4000:
                return None, {}
            return name, {"slug": slug, "title": title, "body": body}

        if name == "post_save":
            pid = _i(a.get("id")) or 0
            if pid < 0:
                return None, {}
            title = _s(a.get("title"), 120)
            if not title:
                return None, {}
            cover = _s(a.get("cover"), 160)
            if cover and not _image_ok(cover):
                return None, {}
            excerpt = _s(a.get("excerpt"), 300)
            body = str(a.get("body") or "").strip()
            if len(body) > 20000:
                return None, {}
            status = str(a.get("status") or "published").strip()
            if status not in ("published", "hidden"):
                return None, {}
            return name, {"id": pid, "title": title, "excerpt": excerpt,
                          "body": body, "status": status, "cover": cover}

        if name in ("post_delete", "category_delete", "item_delete",
                    "coupon_delete", "toplist_delete", "flashdeal_delete",
                    "event_delete", "ad_delete", "plan_delete",
                    "badge_delete", "story_delete", "review_delete",
                    "trash_restore"):
            n = _i(a.get("id"))
            if not n or n <= 0:
                return None, {}
            return name, {"id": n}

        if name == "category_save":
            cid = _i(a.get("id")) or 0
            if cid < 0:
                return None, {}
            nm = _s(a.get("name"), 60)
            if not nm:
                return None, {}
            image = _s(a.get("image"), 160)
            if image and not _image_ok(image):
                return None, {}
            out = {"id": cid, "name": nm, "image": image}
            for k, cap in (("icon", 40), ("blurb", 200), ("parent", 80)):
                if a.get(k) is not None:
                    out[k] = _s(a.get(k), cap)
            if a.get("sort") is not None:
                out["sort"] = max(0, min(9999, _i(a.get("sort")) or 0))
            if a.get("active") is not None:
                out["active"] = 1 if str(a.get("active")).strip() in ("1", "true", "on") else 0
            return name, out

        if name == "business_save":
            # v264: id=0 (or missing) + name = CREATE, like item_save /
            # category_save / post_save. A positive id edits, as before.
            bid = _i(a.get("id")) or 0
            if bid < 0:
                return None, {}
            # idempotent: accept the model shape (flat) and the normalized
            # shape ({"fields": {...}}) so a confirmed proposal round-trips.
            raw = a["fields"] if isinstance(a.get("fields"), dict) else a
            fields = {}
            for k, cap in _BIZ_FIELDS.items():
                if raw.get(k) is not None:
                    fields[k] = _s(raw.get(k), cap)
            for k in ("featured", "verified", "booking_on", "phone_public"):
                if raw.get(k) is not None:
                    fields[k] = 1 if str(raw[k]).strip() in ("1", "true", "on") else 0
            for k in ("lat", "lng"):
                if raw.get(k) is not None:
                    try:
                        fields[k] = float(str(raw.get(k)).strip())
                    except (TypeError, ValueError):
                        return None, {}
            if "status" in raw and str(raw.get("status") or "").strip() in _BIZ_STATUSES:
                fields["status"] = str(raw.get("status")).strip()
            if "hours" in raw:
                h = _norm_hours(raw.get("hours"))
                if h == "":
                    return None, {}          # malformed hours refuse the call
                fields["hours"] = h
            if "cover" in raw:
                cover = str(raw.get("cover") or "").strip()
                if cover and not _image_ok(cover):
                    return None, {}
                fields["cover"] = cover
            if "images" in raw:
                imgs = _norm_images(raw.get("images"))
                if imgs == "":
                    return None, {}
                fields["images"] = imgs
            # v264: a create needs a name AND a category (businesses.cat_slug
            # is NOT NULL, and item_save likewise requires its parent).
            if bid == 0 and (not fields.get("name")
                             or not fields.get("cat_slug")):
                return None, {}
            if bid and not fields:
                return None, {}
            return name, {"id": bid, "fields": fields}

        if name == "item_save":
            iid = _i(a.get("id")) or 0
            if iid < 0:
                return None, {}
            raw = a["data"] if isinstance(a.get("data"), dict) else a
            biz_id = _i(raw.get("biz_id"))
            if not biz_id or biz_id <= 0:
                return None, {}
            d = {"biz_id": biz_id}
            for k, cap in _ITEM_TEXT.items():
                if raw.get(k) is not None:
                    d[k] = _s(raw.get(k), cap)
            for k in _ITEM_NUM:
                if raw.get(k) is None:
                    continue
                n = _i(raw.get(k))
                if n is None or n < 0:
                    return None, {}
                d[k] = n
            if not iid and not d.get("title"):
                return None, {}              # new items need a title
            if raw.get("kind") is not None:
                if str(raw.get("kind")).strip() not in _ITEM_KINDS:
                    return None, {}
                d["kind"] = str(raw.get("kind")).strip()
            if raw.get("price_type") is not None:
                if str(raw.get("price_type")).strip() not in _PRICE_TYPES:
                    return None, {}
                d["price_type"] = str(raw.get("price_type")).strip()
            for k in _ITEM_FLAGS:
                if raw.get(k) is not None:
                    d[k] = 1 if str(raw[k]).strip() in ("1", "true", "on") else 0
            if raw.get("images") is not None:
                imgs = _norm_images(raw.get("images"))
                if imgs == "":
                    return None, {}
                d["images"] = imgs
            if raw.get("options") is not None:
                opts = raw.get("options")
                if isinstance(opts, str):          # idempotent re-parse
                    try:
                        opts = json.loads(opts)
                    except ValueError:
                        opts = None
                if not isinstance(opts, list) or len(opts) > 20:
                    return None, {}
                norm = []
                for o in opts:
                    if not isinstance(o, dict):
                        return None, {}
                    clean = {str(k)[:40]: (v if isinstance(v, (str, int, float)) else None)
                             for k, v in list(o.items())[:8]}
                    if not clean:
                        return None, {}
                    norm.append(clean)
                d["options"] = json.dumps(norm, ensure_ascii=False)[:4000]
            if raw.get("spec") is not None:
                spec = raw.get("spec")
                if isinstance(spec, str):          # idempotent re-parse
                    try:
                        spec = json.loads(spec)
                    except ValueError:
                        spec = None
                if not isinstance(spec, dict) or len(spec) > 20:
                    return None, {}
                clean = {str(k)[:60]: _s(v, 300) for k, v in list(spec.items())[:20]}
                d["spec"] = json.dumps(clean, ensure_ascii=False)[:4000]
            return name, {"id": iid, "data": d}

        if name == "review_moderate":
            rid = _i(a.get("id"))
            if not rid or rid <= 0:
                return None, {}
            action = str(a.get("action") or "").strip()
            if action not in ("approve", "reject"):
                return None, {}
            return name, {"id": rid, "action": action, "reply": _s(a.get("reply"), 500)}

        if name == "biz_moderate":
            bid = _i(a.get("id"))
            if not bid or bid <= 0:
                return None, {}
            action = str(a.get("action") or "").strip()
            if action not in ("approve", "reject", "hide", "show"):
                return None, {}
            return name, {"id": bid, "action": action}

        if name == "broadcast":
            text = str(a.get("text") or "").strip()
            if not text or len(text) > 500:
                return None, {}
            return name, {"text": text}

        # ---------------- v240 new tools ----------------

        if name == "coupon_save":
            cid = _i(a.get("id")) or 0
            if cid < 0:
                return None, {}
            biz_id = _i(a.get("biz_id")) or 0
            code = _s(a.get("code"), 40)
            title = _s(a.get("title"), 120)
            percent = _i(a.get("percent"))
            if not code or not title or percent is None or not (0 <= percent <= 99):
                return None, {}
            expires = _s(a.get("expires"), 20)
            if expires and not re.match(r"^\d{4}-\d{2}-\d{2}$", expires):
                return None, {}
            active = 1 if str(a.get("active", "1")).strip() in ("1", "true", "on") else 0
            return name, {"id": cid, "biz_id": biz_id, "code": code, "title": title,
                          "percent": percent, "expires": expires, "active": active}

        if name == "toplist_save":
            tid = _i(a.get("id")) or 0
            if tid < 0:
                return None, {}
            title = _s(a.get("title"), 120)
            if not title:
                return None, {}
            kind = str(a.get("kind") or "manual").strip()
            if kind not in _LIST_KINDS:
                return None, {}
            items = a.get("items")
            if items is None:
                items = []
            if not isinstance(items, list) or len(items) > 50:
                return None, {}
            ids = []
            for x in items:
                n = _i(x)
                if not n or n <= 0:
                    return None, {}
                ids.append(n)
            limit_n = _i(a.get("limit_n")) or 10
            if not (1 <= limit_n <= 50):
                return None, {}
            return name, {"id": tid, "title": title,
                          "descr": _s(a.get("descr"), 300), "kind": kind,
                          "items": ids, "limit_n": limit_n,
                          "sort": max(0, min(9999, _i(a.get("sort")) or 0)),
                          "active": 1 if str(a.get("active", "1")).strip() in ("1", "true", "on") else 0}

        if name == "flashdeal_save":
            did = _i(a.get("id")) or 0
            if did < 0:
                return None, {}
            biz_id = _i(a.get("biz_id"))
            if not biz_id or biz_id <= 0:
                return None, {}
            title = _s(a.get("title"), 120)
            percent = _i(a.get("percent"))
            ends = str(a.get("ends") or "").strip()
            if not title or percent is None or not (1 <= percent <= 99) or not ends:
                return None, {}
            for k in ("starts", "ends"):
                v = str(a.get(k) or "").strip()
                if v and not _DT_RX.match(v):
                    return None, {}
            return name, {"id": did, "biz_id": biz_id, "title": title,
                          "descr": _s(a.get("descr"), 500),
                          "percent": percent,
                          "starts": _s(a.get("starts"), 20), "ends": ends[:20],
                          "active": 1 if str(a.get("active", "1")).strip() in ("1", "true", "on") else 0}

        if name == "event_save":
            eid = _i(a.get("id")) or 0
            if eid < 0:
                return None, {}
            title = _s(a.get("title"), 120)
            if not title:
                return None, {}
            date = _s(a.get("date"), 10)
            tm = _s(a.get("time"), 5)
            if date and not re.match(r"^\d{4}-\d{2}-\d{2}$", date):
                return None, {}
            if tm and not _HHMM.match(tm):
                return None, {}
            image = _s(a.get("image"), 160)
            if image and not _image_ok(image):
                return None, {}
            status = str(a.get("status") or "published").strip()
            if status not in ("published", "hidden"):
                return None, {}
            biz_id = _i(a.get("biz_id")) or 0
            return name, {"id": eid, "title": title, "descr": _s(a.get("descr"), 1000),
                          "place": _s(a.get("place"), 120), "date": date, "time": tm,
                          "biz_id": biz_id, "image": image, "status": status}

        if name == "ad_save":
            aid = _i(a.get("id")) or 0
            if aid < 0:
                return None, {}
            title = _s(a.get("title"), 120)
            if not title:
                return None, {}
            url = _s(a.get("url"), 300)
            if url and not (url.startswith("/") or url.startswith("http://")
                            or url.startswith("https://")):
                return None, {}
            slot = str(a.get("slot") or "home").strip()
            if slot not in _AD_SLOTS:
                return None, {}
            image = _s(a.get("image"), 160)
            if image and not _image_ok(image):
                return None, {}
            for k in ("starts", "ends"):
                v = str(a.get(k) or "").strip()
                if v and not _DT_RX.match(v):
                    return None, {}
            weight = _i(a.get("weight")) or 1
            if not (1 <= weight <= 100):
                return None, {}
            return name, {"id": aid, "title": title, "body": _s(a.get("body"), 500),
                          "image": image, "url": url, "slot": slot,
                          "biz_id": _i(a.get("biz_id")) or 0,
                          "starts": _s(a.get("starts"), 20), "ends": _s(a.get("ends"), 20),
                          "weight": weight,
                          "active": 1 if str(a.get("active", "1")).strip() in ("1", "true", "on") else 0}

        if name == "plan_save":
            pid = _i(a.get("id")) or 0
            if pid < 0:
                return None, {}
            nm = _s(a.get("name"), 60)
            price = _i(a.get("price"))
            if not nm or price is None or price < 0:
                return None, {}
            months = _i(a.get("months")) or 12
            if not (1 <= months <= 36):
                return None, {}
            return name, {"id": pid, "name": nm, "slug": _s(a.get("slug"), 40),
                          "tagline": _s(a.get("tagline"), 200), "price": price,
                          "months": months,
                          "featured_slots": max(0, _i(a.get("featured_slots")) or 0),
                          "max_items": max(0, _i(a.get("max_items")) or 0),
                          "max_photos": max(0, _i(a.get("max_photos")) or 0),
                          "perks": _s(a.get("perks"), 1000),
                          "features": _s(a.get("features"), 200),
                          "badge_slug": _s(a.get("badge_slug"), 40),
                          "sort": max(0, min(9999, _i(a.get("sort")) or 0)),
                          "active": 1 if str(a.get("active", "1")).strip() in ("1", "true", "on") else 0}

        if name == "badge_save":
            bid = _i(a.get("id")) or 0
            if bid < 0:
                return None, {}
            nm = _s(a.get("name"), 60)
            if not nm:
                return None, {}
            color = _s(a.get("color"), 7) or "#059669"
            if not re.match(r"^#[0-9a-fA-F]{6}$", color):
                return None, {}
            return name, {"id": bid, "slug": _s(a.get("slug"), 40), "name": nm,
                          "icon": _s(a.get("icon"), 40) or "award", "color": color,
                          "descr": _s(a.get("descr"), 200),
                          "sort": max(0, min(9999, _i(a.get("sort")) or 0)),
                          "active": 1 if str(a.get("active", "1")).strip() in ("1", "true", "on") else 0}

        if name == "story_add":
            biz_id = _i(a.get("biz_id"))
            if not biz_id or biz_id <= 0:
                return None, {}
            image = str(a.get("image") or "").strip()
            if not image or not _image_ok(image):
                return None, {}
            kind = str(a.get("kind") or "image").strip()
            if kind not in ("image", "video"):
                return None, {}
            duration = _i(a.get("duration")) or 0
            if not (0 <= duration <= 60):
                return None, {}
            return name, {"biz_id": biz_id, "image": image,
                          "caption": _s(a.get("caption"), 200), "kind": kind,
                          "duration": duration}

        if name == "claim_moderate":
            cid = _i(a.get("id"))
            if not cid or cid <= 0:
                return None, {}
            action = str(a.get("action") or "").strip()
            if action not in ("approve", "reject"):
                return None, {}
            return name, {"id": cid, "action": action}

        if name == "ticket_reply":
            tid = _i(a.get("id"))
            if not tid or tid <= 0:
                return None, {}
            body = str(a.get("body") or "").strip()
            if not body or len(body) > 2000:
                return None, {}
            return name, {"id": tid, "body": body}

        if name == "customer_moderate":
            action = str(a.get("action") or "").strip()
            if action not in ("block", "unblock"):
                return None, {}
            phone = db.norm_phone(str(a.get("phone") or ""))
            if not phone:
                return None, {}
            return name, {"phone": phone, "action": action}

        if name == "order_status":
            oid = _i(a.get("id"))
            status = str(a.get("status") or "").strip()
            if not oid or oid <= 0 or status not in _ORDER_STATUSES:
                return None, {}
            return name, {"id": oid, "status": status}

        if name == "booking_status":
            kid = _i(a.get("id"))
            status = str(a.get("status") or "").strip()
            if not kid or kid <= 0 or status not in _BOOKING_STATUSES:
                return None, {}
            return name, {"id": kid, "status": status}

        if name == "area_rename":
            old = _s(a.get("old"), 60)
            new = _s(a.get("new"), 60)
            if not old or not new or old == new:
                return None, {}
            return name, {"old": old, "new": new}

        # v297 new tools
        if name == "bulk_approve":
            kind = _s(a.get("kind"), 20) or ""
            if kind not in ("businesses","reviews","reports","claims","edits","subscriptions","messages"):
                return None, {}
            return name, {"kind": kind}
        if name in ("backup_now","cache_clear","seo_check","health_check"):
            return name, {}

        # v310 (دستور مدیر): ترمینال + پرس‌وجوی خواندنی + لاگ
        if name == "shell_exec":
            cmd = _s(a.get("cmd") or a.get("command") or a.get("value") or a.get("text"), 500)
            bg = str(a.get("bg") or "").strip().lower() in ("1", "true", "yes", "بله")
            return name, {"cmd": cmd, "bg": bg}
        if name == "sql_read":
            return name, {"q": _s(a.get("q") or a.get("query") or a.get("sql") or a.get("value"), 500)}
        if name == "log_tail":
            try:
                n = max(1, min(200, int(a.get("n") or a.get("lines") or 40)))
            except Exception:
                n = 40
            return name, {"n": n}

        if name == "file_list":
            path = _s(a.get("path"), 200) or _s(a.get("dir"), 200) or ""
            return name, {"path": path[:200]}
        if name == "file_upload":
            src = _s(a.get("src"), 500) or _s(a.get("url"), 500) or _s(a.get("path"), 500) or ""
            name_hint = _s(a.get("name"), 120) or ""
            if not src:
                return None, {}
            return name, {"src": src[:500], "name": name_hint[:120]}
        if name == "file_download":
            url = _s(a.get("url"), 500) or _s(a.get("src"), 500) or ""
            dest = _s(a.get("dest"), 200) or _s(a.get("path"), 200) or ""
            if not url:
                return None, {}
            if not (url.startswith("http://") or url.startswith("https://") or url.startswith("/")):
                return None, {}
            return name, {"url": url[:500], "dest": dest[:200]}


        # v312 new tools — v316 arena removed
        if name == "sys_info":
            return name, {}
        if name in ("file_read", "file_delete"):
            p = _s(a.get("path") or a.get("name") or a.get("file"), 200) or ""
            if not p:
                return None, {}
            return name, {"path": p[:200]}
        if name == "file_write":
            p = _s(a.get("path") or a.get("name") or a.get("file"), 200) or ""
            c = str(a.get("content") or a.get("text") or a.get("body") or "")[:8000]
            if not p:
                return None, {}
            return name, {"path": p[:200], "content": c}
        if name == "file_edit":
            p = _s(a.get("path") or a.get("name") or a.get("file"), 200) or ""
            old = str(a.get("old") or "")[:2000]
            new = str(a.get("new") or "")[:8000]
            if not p or not old:
                return None, {}
            return name, {"path": p[:200], "old": old, "new": new}
        if name in ("db_tables", "backup_list", "version_info"):
            return name, {}

    except Exception:
        return None, {}
    return None, {}


# ------------------------------------------------------------------ describe

_FA_ACTION = {"approve": "تأیید", "reject": "رد", "hide": "پنهان", "show": "نمایش",
              "block": "مسدود", "unblock": "رفع مسدودی"}


def tool_describe(tool, args):
    """Live one-liner for the confirm question. Never raises."""
    try:
        if tool == "code_list":
            return f"فهرست فایل‌های {(args.get('path') or 'ریشهٔ سایت')}"
        if tool == "code_read":
            return f"خواندن {args.get('path')} (خطوط {args.get('from_line')}–{args.get('to_line')})"
        if tool == "code_edit":
            return (f"ویرایش کد {args.get('path')} — "
                    f"{len(args.get('edits') or [])} جایگزینی"
                    + (f" ({args.get('summary')[:60]})" if args.get("summary") else ""))
        if tool == "code_write":
            what = "بازنویسی کامل" if os.path.isfile(
                os.path.join(CODE.ROOT, args.get("path") or "?")) else "ایجاد فایل"
            return f"{what}: {args.get('path')}"
        if tool == "code_revert":
            return f"برگشت {args.get('path')} به آخرین نسخهٔ پشتیبان"
        if tool == "code_search":
            return f"جست‌وجوی «{args.get('query')}» در کل کد سایت"
        if tool == "code_status":
            return "خواندن وضعیت واقعی صف و آخرین استقرارها"
        if tool == "panel_sections":
            return "فهرست همهٔ بخش‌های پنل مدیریت"
        if tool == "sec_report":
            return "گزارش زندهٔ امنیت سرور و سایت (SSH، fail2ban، فایروال، سپر، پنل)"
        if tool == "panel_read":
            _x = args.get("id") or args.get("q") or ""
            return f"خواندن بخش «{args.get('section')}»" + (f" ({_x})" if _x else "")
        if tool == "subscription_set":
            return (f"فعال‌سازی اشتراک «{args.get('plan_slug')}» روی کسب‌وکار "
                    f"#{args.get('biz_id')}"
                    + (f" برای {args.get('months')} ماه" if args.get("months") else ""))
        if tool == "owner_moderate":
            return (f"{'مسدود' if args.get('action')=='block' else 'آزاد'}‌سازی مالک "
                    f"«{args.get('owner')}»")
        if tool == "ai_setup":
            m = args.get("model") or ""
            if args.get("provider") == "site":   # v269: هوش عمومی سایت
                return (f"وصل‌کردن هوش عمومی سایت" +
                        (f" — مدل {m}" if m else "") + " (کلید تست‌شده)")
            return (f"وصل‌کردن مغز {args.get('provider')}"
                    + (f" — مدل {m}" if m else "") + " (کلید تست‌شده)")
        if tool == "brain_switch":
            import assistant as _AI   # lazy: brain names
            return ("سوئیچ فوری مغز به " +
                    _AI.BRAIN_FA.get(args.get("brain"), "؟") + " (تست‌شده، بدون ری‌استارت)")
        if tool == "service_restart":
            return "راه‌اندازی مجدد سرویس سایت"
        if tool == "setting":
            if "items" in args:
                _dks = "، ".join("«" + str(i.get("key")) + "»" for i in args["items"])
                return f"تغییر {len(args['items'])} تنظیم: {_dks}"
            if (args.get("key") or "") in _AUTH_KEYS:
                return f"تغییر «{args.get('key')}» به «<مقدار پنهان>»"
            return f"تغییر «{args.get('key')}» به «{str(args.get('value'))[:80]}»"
        if tool == "page":
            return f"نوشتن کامل صفحهٔ {args.get('slug')} («{args.get('title')}»)"
        if tool == "post_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} مقالهٔ «{args.get('title')}»"
        if tool == "post_delete":
            return f"حذف مقالهٔ #{args.get('id')}"
        if tool == "category_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} دستهٔ «{args.get('name')}»"
        if tool == "category_delete":
            return f"حذف دستهٔ #{args.get('id')}"
        if tool == "business_save":
            if args.get("id"):           # v264: edit keeps its old wording
                b = db._one("SELECT name FROM businesses WHERE id=?", (args.get("id"),))
                nm = (b or {}).get("name") or f"#{args.get('id')}"
                keys = "، ".join(sorted((args.get("fields") or {}).keys())[:6])
                return f"ویرایش «{nm}» ({keys})"
            nm = (args.get("fields") or {}).get("name") or "تازه"
            return f"🏪 ایجاد کسب‌وکار تازهٔ «{nm}»"
        if tool == "item_save":
            if args.get("id"):
                it = db._one("SELECT title FROM items WHERE id=?", (args.get("id"),))
                nm = (it or {}).get("title") or f"#{args.get('id')}"
                return f"ویرایش محصول «{nm}»"
            return f"ایجاد محصول «{(args.get('data') or {}).get('title') or ''}»"
        if tool == "item_delete":
            return f"حذف محصول #{args.get('id')}"
        if tool == "review_moderate":
            return f"{_FA_ACTION.get(args.get('action'))} نظر #{args.get('id')}"
        if tool == "review_delete":
            return f"حذف نظر #{args.get('id')}"
        if tool == "biz_moderate":
            b = db._one("SELECT name FROM businesses WHERE id=?", (args.get("id"),))
            nm = (b or {}).get("name") or f"#{args.get('id')}"
            return f"{_FA_ACTION.get(args.get('action'))} کسب‌وکار «{nm}»"
        if tool == "broadcast":
            body = str(args.get("text") or "")
            return f"ارسال پیام همگانی: «{body[:160]}»" + ("…" if len(body) > 160 else "")
        if tool == "coupon_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} کد تخفیف «{args.get('code')}» ({args.get('percent')}٪)"
        if tool == "coupon_delete":
            return f"حذف کد تخفیف #{args.get('id')}"
        if tool == "toplist_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} لیست «{args.get('title')}»"
        if tool == "toplist_delete":
            return f"حذف لیست #{args.get('id')}"
        if tool == "flashdeal_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} پیشنهاد ویژهٔ «{args.get('title')}» ({args.get('percent')}٪)"
        if tool == "flashdeal_delete":
            return f"حذف پیشنهاد ویژه #{args.get('id')}"
        if tool == "event_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} رویداد «{args.get('title')}»"
        if tool == "event_delete":
            return f"حذف رویداد #{args.get('id')}"
        if tool == "ad_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} بنر «{args.get('title')}»"
        if tool == "ad_delete":
            return f"حذف بنر #{args.get('id')}"
        if tool == "plan_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} پلن «{args.get('name')}» ({args.get('price')} تومان)"
        if tool == "plan_delete":
            return f"حذف پلن #{args.get('id')}"
        if tool == "badge_save":
            what = "ویرایش" if args.get("id") else "ایجاد"
            return f"{what} نشان «{args.get('name')}»"
        if tool == "badge_delete":
            return f"حذف نشان #{args.get('id')}"
        if tool == "story_add":
            b = db._one("SELECT name FROM businesses WHERE id=?", (args.get("biz_id"),))
            return f"استوری تازه برای «{(b or {}).get('name') or args.get('biz_id')}»"
        if tool == "story_delete":
            return f"حذف استوری #{args.get('id')}"
        if tool == "claim_moderate":
            c = db._one("SELECT b.name n FROM claims c JOIN businesses b ON b.id=c.biz_id "
                        "WHERE c.id=?", (args.get("id"),))
            return (f"{_FA_ACTION.get(args.get('action'))} درخواست تصاحب «{(c or {}).get('n') or ''}»")
        if tool == "ticket_reply":
            return f"پاسخ به تیکت #{args.get('id')}"
        if tool == "customer_moderate":
            return f"{_FA_ACTION.get(args.get('action'))} مشتری {args.get('phone')}"
        if tool == "order_status":
            return f"تغییر وضعیت سفارش #{args.get('id')} به {args.get('status')}"
        if tool == "booking_status":
            return f"تغییر وضعیت نوبت #{args.get('id')} به {args.get('status')}"
        if tool == "area_rename":
            return f"تغییر نام محلهٔ «{args.get('old')}» به «{args.get('new')}»"
        if tool == "trash_restore":
            r = db._one("SELECT title FROM trash WHERE id=?", (args.get("id"),))
            return f"بازیابی «{(r or {}).get('title') or args.get('id')}» از سطل"
        if tool == "bulk_approve":
            kind_fa = {"businesses":"کسب‌وکارها","reviews":"نظرات","reports":"گزارش‌ها","claims":"تصاحب‌ها","edits":"ویرایش‌ها","subscriptions":"اشتراک‌ها","messages":"پیام‌ها"}.get(args.get("kind"), args.get("kind"))
            return f"تایید گروهی همهٔ {kind_fa} در انتظار"
        if tool == "backup_now":
            return "بکاپ فوری از دیتابیس"
        if tool == "cache_clear":
            return "پاک‌سازی کش صفحات سایت"
        if tool == "seo_check":
            return "بررسی سئو (۲۵ چک) + گزارش"
        if tool == "health_check":
            return "بررسی سلامت کامل سایت + پنل"
        # v310
        if tool == "shell_exec":
            return f"🖥️ اجرای فرمان: {str(args.get('cmd') or '')[:120]}"
        if tool == "sql_read":
            return f"🗄️ پرس‌وجوی خواندنی: {str(args.get('q') or '')[:120]}"
        if tool == "log_tail":
            return f"📜 {int(args.get('n') or 40)} خط آخر لاگ سرویس"
        if tool == "file_list":
            return f"📁 فهرست فایل‌ها «{args.get('path') or 'آپلودها'}»"
        if tool == "file_upload":
            return f"📤 آپلود «{args.get('src','')[:60]}»"
        if tool == "file_download":
            return f"📥 دانلود «{args.get('url','')[:60]}»"
        # v312 — v316 arena removed
        if tool == "sys_info":
            return "🖥️ اطلاعات سیستم (CPU/RAM/Disk)"
        if tool == "file_read":
            return f"📖 خواندن فایل تبادل «{args.get('path','')[:60]}»"
        if tool == "file_write":
            return f"📝 نوشتن فایل «{args.get('path','')[:60]}» ({len(args.get('content',''))} نویسه)"
        if tool == "file_edit":
            return f"✏️ ویرایش فایل «{args.get('path','')[:60]}»"
        if tool == "file_delete":
            return f"🗑️ حذف فایل «{args.get('path','')[:60]}»"
        if tool == "db_tables":
            return "🗄️ فهرست جدول‌ها و تعداد ردیف‌ها"
        if tool == "backup_list":
            return "💾 فهرست بکاپ‌های موجود"
        if tool == "version_info":
            return "🏷️ اطلاعات نسخه و پین‌ها"
    except Exception:
        pass
    return "این تغییر محتوا"


def fail_text(tool, why):
    """Owner-facing sentence for a precheck failure."""
    if isinstance(why, str) and why.startswith("bkey"):
        return ("کلید این مغز در بسته نیست؛ اول با /کلید نصبش کن "
                "(Muse برای سه‌تای کلاد، openrouter برای چهارمی، bynara برای ششمی).")
    if isinstance(why, str) and why.startswith("btest"):
        import assistant as _AI   # lazy: brain names
        _pp = why.split(":")
        _bb = _pp[1] if len(_pp) > 1 else "?"
        _cc = _pp[2] if len(_pp) > 2 else "?"
        return (f"مغز {_AI.BRAIN_FA.get(_bb, _bb)} جواب نداد ({_cc})؛ سوئیچ نشد — "
                "مغز قبلی سر جایش است. اگر 401/403 است کلید آن مغز را با /کلید Muse تازه کن.")
    if isinstance(why, str) and why.startswith("akey"):
        if why == "akey:403":
            return ("این کلید توسط سرویس OpenAI رد شد (۴۰۳ — به‌احتمال زیاد محدودیت "
                    "منطقه‌ای سرور). راه‌حل: از سایتِ واسط کلید بگیر و این‌طور بفرست: "
                    "/کلید openai <آدرس-سایت> <کلید> gpt-6-astra")
        if why == "akey:429":
            return ("سقف رایگان سرویس تمام شد (۴۲۹)؛ کمی بعد دوباره تلاش کن "
                    "یا از openrouter.ai کلید تازه بگیر و با /کلید openrouter نصب کن.")
        if why == "akey:402":
            return ("اعتبار سرویس تمام شد (۴۰۲)؛ کلید تازه لازم است.")
        detail = why[4:].strip()
        return ("این کلید را سرویس هوش مصنوعی قبول نکرد" +
                (f" (کد {detail})" if detail else "") +
                "؛ از aistudio.google.com یا console.groq.com کلید تازه بساز و دوباره بفرست.")
    base = {"missing": "چنین موردی در سایت پیدا نشد؛ شناسه را دقیق بگو.",
            "already": "این مورد قبلاً بررسی/تغییر کرده و دیگر در صف نیست.",
            "never": "این کسب‌وکار هنوز منتشر نشده؛ اول باید از صف بررسی بگذرد.",
            "parent": "دستهٔ والد معتبر نیست.",
            "cat": "دسته‌ای با این cat_slug در سایت نیست؛ یک شناسهٔ معتبر از فهرست دسته‌ها بردار.",
            "empty": "محتوایی برای نوشتن نبود.",
            "image": "عکسی در دسترس نیست؛ اول عکس را در همین گفتگو بفرست.",
            "key": "این کلید تنظیمات شناخته نشد؛ نام دقیق را از تنظیمات بخواه.",
            "path": "این مسیر مجاز نیست؛ با code_list فهرست واقعی را ببین.",
            "nomatch": "متنِ old در فایل پیدا نشد؛ اول فایل را با code_read بخوان و عیناً کپی کن.",
            "ambiguous": "متنِ old دو بار در فایل هست؛ با چند خط بیشتر حولش یکتایش کن.",
            "binary": "این فایل متنی نیست (یا قابل‌خواندن نیست).",
            "big": "این فایل/تغییر از حد مجاز بزرگ‌تر است؛ بخشی از آن را بخوان/ویرایش کن.",
            "rate": "همین الان راه‌اندازی مجدد در صف است؛ کمی صبر کن."}
    base["section"] = ("این بخش شناخته نشد. فهرست کامل بخش‌ها را با "
                       "panel_sections (یا دستور «پنل») ببین.")
    base["plan"] = "این پلن در سایت تعریف نشده؛ فهرست پلن‌ها را با panel_read {section:plans} ببین."
    base["months"] = "مدت اشتراک باید عددی بین ۱ تا ۱۲۰ ماه باشد."
    base["owner"] = "این مالک (id یا شماره) پیدا نشد."
    return base.get(why, "فعلاً نمی‌شود این کار را انجام داد؛ وضعیت را با «وضعیت» چک کن.")


# ------------------------------------------------- v282: panel read (دستور مدیر)
# ربات باید «هر قسمتی از پنل مدیریتی» را بتواند بخواند و بررسی کند — بدون
# محدودیت. panel_sections فهرست بخش‌ها و panel_read محتوای زندهٔ هر بخش را
# می‌دهد. خواندن فوری است (IMMEDIATE_TOOLS) و «بله» نمی‌خواهد؛ تغییرات فقط
# با ابزارهای نوشتن و فقط از چت خود مدیر اعمال می‌شوند (is_team_chat).

# ---- v302: file tools (immediate, no بله) — v316 arena removed
# v310 (دستور مدیر): ترمینال واقعی برای کنسول ایجنت — همان موتور دستور
# «sh» در بله، بدون هوش در مسیر. کاربر اجراکننده = کاربر سرویس (بدون sudo).
# خروجی redact + سقف‌دار. shell_exec عمداً IMMEDIATE نیست: پیشنهاد هوش برای
# فرمان از دیوار «بله» مدیر رد می‌شود؛ اجرای فوری کنسول اقدام مستقیم خود مدیر است.
_SHELL_REDACT = re.compile(
    r"(AIza[A-Za-z0-9_\-]{16,}|gsk_[A-Za-z0-9]{16,}|sk-[A-Za-z0-9_\-]{16,}|"
    r"aa-[A-Za-z0-9_\-]{16,}|kira_[A-Za-z0-9]{16,})")
_APP_ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")


def _exec_shell(args):
    import subprocess
    cmd = (args.get("cmd") or "").strip()[:500]
    if not cmd:
        return False, "cmd خالی است"
    try:
        db.log("admin_ai_tool", "shell_exec " + cmd[:160])
    except Exception:
        pass
    if args.get("bg"):
        try:
            subprocess.Popen(cmd, shell=True, cwd=_APP_ROOT,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             stdin=subprocess.DEVNULL, start_new_session=True)
            return True, "▶️ در پس‌زمینه اجرا شد: " + cmd[:200]
        except Exception as e:
            return False, "اجرا نشد: " + str(e)[:200]
    try:
        p = subprocess.run(cmd, shell=True, cwd=_APP_ROOT,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           stdin=subprocess.DEVNULL, timeout=90)
        out = (p.stdout or b"").decode("utf-8", "replace")
        err = (p.stderr or b"").decode("utf-8", "replace")
        body = out
        if err.strip():
            body = (body + "\n— stderr —\n" if body.strip() else "") + err
        body = _SHELL_REDACT.sub("«مقدار پنهان»", body)[:3200]
        return True, f"کد خروج: {p.returncode}\n" + (body.strip() or "(خروجی خالی)")
    except subprocess.TimeoutExpired:
        return False, "فرمان بیش از ۹۰ ثانیه طول کشید — bg=true بزن."
    except Exception as e:
        return False, "خطا: " + str(e)[:200]


def _exec_sql_read(args):
    q = (args.get("q") or "").strip()[:500]
    if not re.match(r"^\s*(select|with|pragma|explain)\b", q, re.I):
        return False, "فقط SELECT/WITH/PRAGMA مجاز است"
    try:
        con = db.connect()   # اتصال thread-local — close خنثی است، قفل نمی‌کند
        cur = con.execute(q)
        cols = [d[0] for d in (cur.description or [])]
        rows = cur.fetchmany(50)
        lines = [" | ".join(str(c) for c in cols)] if cols else []
        for r in rows:
            lines.append(" | ".join(str(x)[:60] for x in r))
        more = "" if len(rows) < 50 else "\n(فقط ۵۰ ردیف اول)"
        return True, f"{len(rows)} ردیف:\n" + ("\n".join(lines))[:3500] + more
    except Exception as e:
        return False, "پرس‌وجو اجرا نشد: " + str(e)[:200]


def _exec_log_tail(args):
    import subprocess
    try:
        n = max(1, min(200, int(args.get("n") or 40)))
    except Exception:
        n = 40
    try:
        p = subprocess.run(["journalctl", "-u", "bazarche", "-n", str(n),
                            "--no-pager"], stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, timeout=20)
        out = (p.stdout or b"").decode("utf-8", "replace").strip()
        if p.returncode == 0 and out:
            return True, _SHELL_REDACT.sub("«مقدار پنهان»", out)[-3500:]
        return False, ("journalctl جواب نداد (کد %s) — بیرون از systemd؟ "
                       "با sh tail لاگ فایل را بخوان." % p.returncode)
    except FileNotFoundError:
        return False, "journalctl روی این سیستم نیست — با sh tail بخوان."
    except Exception as e:
        return False, "لاگ خوانده نشد: " + str(e)[:200]





# v318: owner full-tree file access (better than boxed agent-exchange).
# Secrets and pin files stay unreadable/unwritable. Writes of server/*.py
# still go through code_edit/codeguard when the owner uses those tools;
# file_write here is for docs/site/exchange and other non-pin paths.
_FILE_SECRET_RX = re.compile(
    r"(^|/)(\.env|\.netrc|dastgir-secrets\.env|brain\.env|gate\.env|"
    r"credentials|\.pem$|\.key$|id_rsa)", re.I)
_FILE_PIN_WRITE = {"VERSION.txt", "site/sw.js"}


def _file_rel(real):
    root = os.path.realpath(ROOT)
    real = os.path.realpath(real)
    if real == root:
        return ""
    if real.startswith(root + os.sep):
        return real[len(root) + 1:].replace("\\", "/")
    # BZ_DATA_DIR may sit outside ROOT (tests / custom data dir).
    try:
        ex = os.path.realpath(os.path.join(db.DATA_DIR, "agent-exchange"))
    except Exception:
        ex = ""
    if ex and real == ex:
        return "data/agent-exchange"
    if ex and real.startswith(ex + os.sep):
        return "data/agent-exchange/" + real[len(ex) + 1:].replace("\\", "/")
    return None


def _file_secret(rel):
    if not rel:
        return False
    return bool(_FILE_SECRET_RX.search(rel))


def _file_write_blocked(rel):
    if not rel:
        return True
    if rel in _FILE_PIN_WRITE or _file_secret(rel):
        return True
    if rel.startswith(("deploy/", ".git/")):
        return True
    if rel.startswith("data/") and "agent-exchange" not in rel:
        return True
    return False


def _resolve_owner_file(p, must_exist=True):
    """Resolve a path the owner typed to a real file under ROOT, or None."""
    p = (p or "").strip()
    if not p or ".." in p.replace("\\", "/").split("/"):
        return None
    cands = []
    # 1) as given relative to ROOT
    cands.append(os.path.join(ROOT, p.lstrip("/")))
    # 2) bare name in exchange / uploads
    base_ex = os.path.join(db.DATA_DIR, "agent-exchange")
    base_up = os.path.join(ROOT, "site", "assets", "img", "uploads")
    cands.append(os.path.join(base_ex, os.path.basename(p)))
    cands.append(os.path.join(base_up, os.path.basename(p)))
    for cand in cands:
        real = os.path.realpath(cand)
        rel = _file_rel(real)
        if rel is None:
            continue
        if _file_secret(rel):
            return None
        if must_exist and not os.path.isfile(real):
            continue
        if not must_exist:
            parent = os.path.dirname(real)
            prel = _file_rel(parent)
            if prel is None or _file_secret(prel or "x"):
                # parent must still be under ROOT
                if os.path.realpath(parent) != os.path.realpath(ROOT) and prel is None:
                    continue
        return real
    return None


def _exec_file_list(args):
    try:
        path = (args.get("path") or args.get("dir") or "").strip()
        if path:
            # list a site directory
            target = os.path.realpath(os.path.join(ROOT, path.lstrip("/")))
            rel = _file_rel(target)
            if rel is None and target != os.path.realpath(ROOT):
                return False, "مسیر بیرون از ریشهٔ سایت است"
            if _file_secret(rel or ""):
                return False, "این مسیر قفل است (راز/پین)"
            if not os.path.isdir(target):
                return False, "پوشه نیست: " + (rel or path)[:80]
            names = []
            for fn in sorted(os.listdir(target))[:80]:
                fp = os.path.join(target, fn)
                try:
                    if os.path.isdir(fp):
                        names.append(fn + "/")
                    else:
                        names.append("%s (%sB)" % (fn, os.path.getsize(fp)))
                except OSError:
                    names.append(fn)
            return True, ("📁 %s (%d):\n" % (rel or "/", len(names))) + "\n".join(names)[:3500]
        # default: exchange + uploads (legacy card)
        base = os.path.join(ROOT, "site", "assets", "img", "uploads")
        files = []
        if os.path.isdir(base):
            for fn in sorted(os.listdir(base))[-40:]:
                fp = os.path.join(base, fn)
                try:
                    sz = os.path.getsize(fp)
                    files.append("%s (%sKB)" % (fn, sz // 1024))
                except OSError:
                    pass
        out = "📁 فایل‌های آپلودها:\n" + ("\n".join(files[-30:]) if files else "— خالی")
        ex = os.path.join(db.DATA_DIR, "agent-exchange")
        try:
            os.makedirs(ex, exist_ok=True)
            xs = sorted(os.listdir(ex))[-30:]
            if xs:
                out += "\n\n📦 تبادل:\n" + "\n".join(xs)
        except OSError:
            pass
        out += "\n\n(v318: برای کل سایت بگو file_list {path: \"server\"} یا /ls server)"
        return True, out[:3500]
    except Exception as e:
        return False, "خطا در فهرست: %s" % e

def _exec_file_upload(args):
    try:
        src = (args.get("src") or "").strip()
        name_hint = (args.get("name") or "").strip()
        if not src:
            return False, "منبع خالی است"
        # if src is http -> download to uploads
        dest_dir = os.path.join(ROOT, "site", "assets", "img", "uploads")
        os.makedirs(dest_dir, exist_ok=True)
        exchange_files = os.path.join(db.DATA_DIR, "agent-exchange")
        os.makedirs(exchange_files, exist_ok=True)
        if src.startswith("http://") or src.startswith("https://"):
            # download
            try:
                import requests
                r = requests.get(src, timeout=20, stream=True, headers={"User-Agent":"Dastgir-Agent/302"})
                r.raise_for_status()
                # guess name
                fname = name_hint or os.path.basename(src.split("?")[0]) or f"file-{int(time.time())}.bin"
                # sanitize
                fname = re.sub(r"[^A-Za-z0-9._-]", "_", fname)[:80]
                if not fname:
                    fname = f"file-{int(time.time())}.bin"
                fpath = os.path.join(exchange_files, fname)
                with open(fpath, "wb") as out:
                    for chunk in r.iter_content(8192):
                        out.write(chunk)
                sz = os.path.getsize(fpath)
                # if image, also copy to uploads for site use
                if fname.lower().endswith((".jpg",".jpeg",".png",".webp",".gif")):
                    import shutil
                    shutil.copy2(fpath, os.path.join(dest_dir, fname))
                    public = f"/assets/img/uploads/{fname}"
                    return True, f"📥 فایل از {src[:80]} دانلود شد → {fname} ({sz}B)\nمسیر عمومی: {public}\nمسیر آرنا: {fpath}"
                return True, f"📥 فایل دانلود شد: {fname} ({sz}B) → {fpath}"
            except Exception as e:
                return False, f"❌ دانلود ناموفق {src[:80]}: {e}"
        else:
            # local path
            if not os.path.isfile(src):
                # try relative to ROOT
                alt = os.path.join(ROOT, src.lstrip("/"))
                if os.path.isfile(alt):
                    src = alt
                else:
                    return False, f"فایل محلی یافت نشد: {src[:120]}"
            fname = name_hint or os.path.basename(src)
            fname = re.sub(r"[^A-Za-z0-9._-]", "_", fname)[:80]
            dst = os.path.join(exchange_files, fname)
            import shutil
            shutil.copy2(src, dst)
            return True, f"📤 فایل کپی شد: {src} → {dst}"
    except Exception as e:
        return False, f"خطای آپلود: {e}"

def _exec_file_download(args):
    try:
        url = (args.get("url") or "").strip()
        dest = (args.get("dest") or "").strip()
        if not url:
            return False, "آدرس خالی است"
        # if url starts with /assets -> it's local file to serve
        if url.startswith("/assets/"):
            local = os.path.join(ROOT, "site", url.lstrip("/"))
            if os.path.isfile(local):
                sz = os.path.getsize(local)
                return True, f"📄 فایل محلی: {url} ({sz}B) → {local}\nبرای دانلود در مرورگر: {url}"
            else:
                return False, f"فایل محلی نیست: {url}"
        # otherwise fetch external
        return _exec_file_upload({"src": url, "name": dest})
    except Exception as e:
        return False, f"خطای دانلود: {e}"

# v312 new execs — آزادترین بخش
def _exec_sys_info(args):
    try:
        import platform, shutil
        # safe info without external deps
        info = []
        info.append(f"🖥️ سیستم: {platform.system()} {platform.release()} ({platform.machine()})")
        info.append(f"🐍 پایتون: {platform.python_version()}")
        info.append(f"📁 دیتا: {db.DATA_DIR}")
        try:
            du = shutil.disk_usage(db.DATA_DIR)
            info.append(f"💾 دیسک: آزاد {du.free//1024//1024}MB / کل {du.total//1024//1024}MB")
        except Exception as e:
            info.append(f"💾 دیسک: {e}")
        # uptime via /proc
        try:
            with open("/proc/uptime") as f:
                up = float(f.read().split()[0])
                h = int(up//3600); m = int((up%3600)//60)
                info.append(f"⏱ آپتایم: {h}h {m}m")
        except Exception:
            info.append("⏱ آپتایم: نامشخص (غیر لینوکس)")
        # load avg
        try:
            import os as _os
            la = _os.getloadavg()
            info.append(f"📊 لود: {la[0]:.2f} {la[1]:.2f} {la[2]:.2f}")
        except Exception:
            pass
        # count files in exchange
        try:
            import agent_browser as AB
            ex = []
            try:
                import agent_browser as AB
                ex = AB.exchange_list()
            except Exception:
                pass
            info.append(f"📦 تبادل: {len(ex)} فایل")
        except Exception:
            pass
        # env safe
        try:
            safe_keys = ["PORT","BZ_DATA_DIR","HTTP_PROXY","HTTPS_PROXY"]
            envs = []
            for k in safe_keys:
                v = os.environ.get(k,"")
                if v:
                    envs.append(f"{k}={v[:80]}")
            if envs:
                info.append("🔧 ENV: " + " | ".join(envs))
        except Exception:
            pass
        db.log("admin_ai_tool", "sys_info")
        return True, "\n".join(info)
    except Exception as e:
        return False, f"خطا: {e}"


def _exec_file_read(args):
    try:
        p = (args.get("path") or "").strip()[:200]
        if not p:
            return False, "مسیر خالی است"
        found = _resolve_owner_file(p, must_exist=True)
        if not found:
            return False, "فایل یافت نشد یا قفل است: %s" % p[:80]
        sz = os.path.getsize(found)
        if sz > 80000:
            return False, "فایل بزرگ است (%sB) — حداکثر ۸۰KB" % sz
        with open(found, "r", encoding="utf-8", errors="ignore") as f:
            txt = f.read(24000)
        rel = _file_rel(found) or os.path.basename(found)
        db.log("admin_ai_tool", "file_read " + rel[:120])
        return True, "📖 %s (%sB):\n%s" % (rel, sz, txt[:8000])
    except Exception as e:
        return False, "خواندن ناموفق: %s" % e

def _exec_file_write(args):
    try:
        p = (args.get("path") or "").strip()[:200]
        c = str(args.get("content") or "")[:24000]
        if not p:
            return False, "مسیر خالی است"
        # Prefer explicit site-relative path; else exchange.
        dest = None
        if "/" in p.replace("\\", "/") or p.endswith((".py", ".js", ".css", ".md", ".html", ".json", ".txt", ".svg")):
            dest = _resolve_owner_file(p, must_exist=False)
        if dest is None:
            base = os.path.join(db.DATA_DIR, "agent-exchange")
            os.makedirs(base, exist_ok=True)
            fname = re.sub(r"[^A-Za-z0-9._-]", "_", os.path.basename(p)[:80])
            if not fname:
                return False, "نام فایل نامعتبر"
            dest = os.path.join(base, fname)
        rel = _file_rel(dest)
        if rel is None:
            return False, "مسیر بیرون از ریشه است"
        if _file_write_blocked(rel):
            return False, "این فایل قفل است (راز/پین/زیرساخت)"
        os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
        with open(dest, "w", encoding="utf-8") as f:
            f.write(c)
        db.log("admin_ai_tool", "file_write %s %s" % (rel, len(c)))
        return True, "📝 نوشته شد: %s (%s نویسه)" % (rel, len(c))
    except Exception as e:
        return False, "نوشتن ناموفق: %s" % e

def _exec_file_edit(args):
    try:
        p = (args.get("path") or "").strip()[:200]
        old = str(args.get("old") or "")[:4000]
        new = str(args.get("new") or "")[:24000]
        if not p or not old:
            return False, "مسیر یا old خالی است"
        found = _resolve_owner_file(p, must_exist=True)
        if not found:
            return False, "فایل نیست یا قفل است: %s" % p[:80]
        rel = _file_rel(found) or p
        if _file_write_blocked(rel):
            return False, "این فایل قفل است"
        with open(found, "r", encoding="utf-8", errors="ignore") as f:
            txt = f.read()
        if old not in txt:
            return False, "متن old در فایل پیدا نشد"
        if txt.count(old) > 1:
            return False, "متن old چند بار تکرار شده — یکتایش کن"
        with open(found, "w", encoding="utf-8") as f:
            f.write(txt.replace(old, new, 1))
        db.log("admin_ai_tool", "file_edit " + rel[:120])
        return True, "✏️ ویرایش شد: %s" % rel
    except Exception as e:
        return False, "ویرایش ناموفق: %s" % e

def _exec_file_delete(args):
    try:
        p = (args.get("path") or "").strip()[:200]
        if not p:
            return False, "مسیر خالی است"
        found = _resolve_owner_file(p, must_exist=True)
        if not found:
            return False, "فایل نیست یا قفل است: %s" % p[:80]
        rel = _file_rel(found) or p
        if _file_write_blocked(rel):
            return False, "این فایل قفل است"
        # Only delete exchange by default unless path is clearly under site/docs
        if not (rel.startswith("data/agent-exchange/")
                or rel.startswith("site/")
                or rel.startswith("docs/")
                or "/agent-exchange/" in found.replace("\\", "/")):
            return False, "حذف فقط برای تبادل / site / docs — برای کد از code_edit"
        os.remove(found)
        db.log("admin_ai_tool", "file_delete " + rel[:120])
        return True, "🗑️ حذف شد: %s" % rel
    except Exception as e:
        return False, "حذف ناموفق: %s" % e

def _exec_db_tables(args):
    try:
        con = db.connect()
        rows = con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()
        out = []
        for r in rows:
            t = r[0]
            if t.startswith("sqlite_"):
                continue
            try:
                c = con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                out.append(f"{t}: {c} ردیف")
            except Exception as e:
                out.append(f"{t}: خطا {e}")
        return True, "🗄️ جدول‌ها:\n" + "\n".join(out)[:3500]
    except Exception as e:
        return False, f"خطا: {e}"

def _exec_backup_list(args):
    try:
        bdir = os.path.join(db.DATA_DIR, "backups")
        if not os.path.isdir(bdir):
            return True, "💾 پوشه بکاپ خالی است (هنوز بکاپ ساخته نشده)"
        files = sorted(os.listdir(bdir))[-20:]
        out = []
        for fn in files:
            fp = os.path.join(bdir, fn)
            try:
                sz = os.path.getsize(fp)//1024
                mt = time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(fp)))
                out.append(f"{fn} — {sz}KB — {mt}")
            except Exception:
                out.append(fn)
        return True, "💾 بکاپ‌ها (۲۰ اخیر):\n" + "\n".join(out) if out else "خالی"
    except Exception as e:
        return False, f"خطا: {e}"




def _exec_version_info(args):
    try:
        ver = ""
        try:
            ver = open(os.path.join(ROOT, "VERSION.txt")).read().strip()
        except Exception:
            ver = "نامشخص"
        import adminbot as ABot
        diag = ABot.DIAG_LATEST
        sw = ""
        try:
            sw = open(os.path.join(ROOT, "site", "sw.js")).read()[:200]
            m = re.search(r"bazarche-v[\w-]+", sw)
            sw_ver = m.group(0) if m else "نامشخص"
        except Exception:
            sw_ver = "نامشخص"
        lines = []
        lines.append(f"🏷️ VERSION.txt: {ver}")
        lines.append(f"🧩 DIAG_LATEST: {diag}")
        lines.append(f"📜 sw.js: {sw_ver}")
        lines.append(f"✅ هماهنگ: {'بله' if ver==diag else 'خیر — بامپ لازم'}")
        try:
            import assistant as AST
            cfg = AST.public_config()
            lines.append(f"🧠 مغز فعال: {cfg.get('brain')} / {cfg.get('model')} has_key={cfg.get('has_key')}")
        except Exception:
            pass
        return True, "\n".join(lines)
    except Exception as e:
        return False, f"خطا: {e}"

def _p_rows(rows, cap=30, fields=None, cell=46):
    """Compact list dump of dict-rows (panel parity, chat-friendly)."""
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    if not rows:
        return "— (موردی نیست)"
    keys = fields or [k for k in list(rows[0].keys())[:9]]
    lines = []
    for r in rows[:cap]:
        cells = []
        for k in keys:
            v = r.get(k)
            if isinstance(v, str):
                v = " ".join(v.split())[:cell]
            cells.append(f"{k}={v}")
        lines.append(" · ".join(str(c) for c in cells))
    more = f"\n… و {len(rows) - cap} مورد دیگر (با q/id دقیق‌تر کن)" if len(rows) > cap else ""
    return "\n".join(lines) + more


def _p_detail(row, cell=220):
    """Full single-row dump (every column)."""
    if not row:
        return "یافت نشد."
    return "\n".join(f"{k}: {' '.join(str(v).split())[:cell]}"
                     for k, v in dict(row).items())


def _p_any(v, cap=2800):
    """Whatever a report function returns (str/dict/list) → readable text."""
    if isinstance(v, str):
        return v[:cap] or "—"
    if isinstance(v, dict):
        if "rows" in v and isinstance(v["rows"], list):
            head = " · ".join(f"{k}={v[k]}" for k in v if k != "rows")
            return ((head + "\n") if head else "") + _p_rows(v["rows"])
        return "\n".join(f"{k}: {' '.join(str(x).split())[:120]}"
                         for k, x in v.items())[:cap] or "—"
    if isinstance(v, list):
        return _p_rows(v)
    return str(v)[:cap]


def _pr_settings(q, rid, page):
    s = db.get_settings()
    keys = sorted(s.keys())
    if q:
        ql = q.lower()
        keys = [k for k in keys if ql in k.lower() or q in str(s.get(k) or "")]
    return "\n".join(f"{k} = {str(s.get(k) if s.get(k) is not None else '')[:120]}"
                     for k in keys)[:2800] or "—"


def _pr_businesses(q, rid, page):
    cols = "id,name,slug,status,cat_slug,phone,city,featured,verified"
    if rid:
        r = db._one("SELECT * FROM businesses WHERE id=?", (rid,))
        if not r:
            return "کسب‌وکاری با این شناسه نیست."
        n_items = (db._one("SELECT COUNT(*) c FROM items WHERE biz_id=?", (rid,)) or {}).get("c", 0)
        sub = db.subscription_of(rid)
        extra = "\nتعداد محصولات: " + str(n_items)
        extra += ("\nاشتراک فعال: {} تا {}".format(sub.get("plan_slug"), sub.get("expires") or "—")
                  if sub else "\nاشتراک فعال: ندارد")
        return _p_detail(r) + extra
    if q:
        like = f"%{q}%"
        rows = db._rows(f"SELECT {cols} FROM businesses "
                        "WHERE name LIKE ? OR slug LIKE ? OR phone LIKE ? "
                        "ORDER BY id DESC LIMIT 60", (like, like, like))
    else:
        rows = db._rows(f"SELECT {cols} FROM businesses ORDER BY id DESC LIMIT 60")
    return _p_rows(rows, cap=40, fields=cols.split(","))


def _pr_queue(q, rid, page):
    rows = db._rows("SELECT id,name,slug,phone,city,cat_slug,status FROM businesses "
                    "WHERE status!='published' ORDER BY id DESC LIMIT 40")
    return _p_rows(rows, cap=40, fields=["id", "name", "status", "phone", "city", "cat_slug"])


def _pr_items(q, rid, page):
    if rid:
        r = db._one("SELECT * FROM items WHERE id=?", (rid,))
        return _p_detail(r) if r else "محصولی با این شناسه نیست."
    if q and str(q).isdigit():
        rows = db._rows("SELECT id,biz_id,title,price,kind,available FROM items "
                        "WHERE biz_id=? ORDER BY id DESC LIMIT 60", (int(q),))
    elif q:
        rows = db._rows("SELECT id,biz_id,title,price,kind,available FROM items "
                        "WHERE title LIKE ? ORDER BY id DESC LIMIT 60", (f"%{q}%",))
    else:
        rows = db._rows("SELECT id,biz_id,title,price,kind,available FROM items "
                        "ORDER BY id DESC LIMIT 60")
    return _p_rows(rows, cap=40, fields=["id", "biz_id", "title", "price", "kind", "available"])


def _pr_orders(q, rid, page):
    if rid:
        r = db._one("SELECT * FROM orders WHERE id=?", (rid,))
        if not r:
            return "سفارشی با این شناسه نیست."
        it = db._rows("SELECT * FROM order_items WHERE order_id=?", (rid,))
        return _p_detail(r) + "\n— قلم‌ها:\n" + _p_rows(it, cap=12)
    rows = db.orders_all()
    return _p_rows(rows, cap=30)


def _pr_bookings(q, rid, page):
    if rid:
        r = db._one("SELECT * FROM bookings WHERE id=?", (rid,))
        return _p_detail(r) if r else "نوبتی با این شناسه نیست."
    return _p_rows(db.bookings(), cap=30)


def _pr_chats(q, rid, page):
    if rid:
        t = db.chat_thread(rid)
        if not t:
            return "گفت‌وگویی با این شناسه نیست."
        msgs = db.chat_messages(rid)[-15:]
        return (_p_detail(t, 120) + "\n— ۱۵ پیام آخر:\n" + _p_rows(msgs, cap=15))
    return _p_rows(db.chat_threads_all(term=q or ""), cap=30)


def _pr_reviews(q, rid, page):
    if rid:
        r = db._one("SELECT * FROM reviews WHERE id=?", (rid,))
        return _p_detail(r) if r else "نظری با این شناسه نیست."
    rows = db.reviews()
    if q:
        rows = [r for r in rows if q in str(r.get("status") or "") or q in str(r.get("body") or "")]
    return _p_rows(rows, cap=30)


def _pr_claims(q, rid, page):
    return _p_rows(db.claims(), cap=30)


def _pr_tickets(q, rid, page):
    if rid:
        t = db.ticket(rid)
        if not t:
            return "تیکتی با این شناسه نیست."
        return _p_detail(t, 160) + "\n— پیام‌ها:\n" + _p_rows(db.ticket_msgs(rid), cap=15)
    return _p_rows(db.tickets(q=q or ""), cap=30)


def _pr_customers(q, rid, page):
    if rid:
        r = db._one("SELECT * FROM customers WHERE id=?", (rid,))
        return _p_detail(r) if r else "مشتری با این شناسه نیست."
    if q:
        like = f"%{q}%"
        rows = db._rows("SELECT * FROM customers WHERE phone LIKE ? OR name LIKE ? "
                        "ORDER BY id DESC LIMIT 40", (like, like))
    else:
        rows = db.customers_list()
    return _p_rows(rows, cap=30)


def _pr_owners(q, rid, page):
    if rid:
        r = db._one("SELECT * FROM owners WHERE id=?", (rid,))
        return _p_detail(r) if r else "مالکی با این شناسه نیست."
    if q:
        o = db.owner_by_phone(db.norm_phone(q) or q, create=False)
        if o:
            n = db.owner_business_count(o["id"])
            return _p_detail(o) + f"\nتعداد کسب‌وکارها: {n}"
        return "مالکی با این شماره نیست."
    return _p_rows(db.owners(), cap=30)


def _pr_subscriptions(q, rid, page):
    if rid:
        return _p_rows(db.subscriptions(biz_id=rid), cap=20)
    st = q if q in ("active", "pending", "expired", "cancelled", "rejected") else None
    return _p_rows(db.subscriptions(status=st), cap=30)


def _pr_plans(q, rid, page):
    return _p_rows(db.plans(only_active=False), cap=20)


def _pr_coupons(q, rid, page):
    return _p_rows(db._rows("SELECT * FROM coupons ORDER BY id DESC LIMIT 40"), cap=30)


def _pr_toplists(q, rid, page):
    return _p_rows(db.toplists(active_only=False), cap=20)


def _pr_flashdeals(q, rid, page):
    return _p_rows(db.flashdeals(active_only=False), cap=20)


def _pr_events(q, rid, page):
    return _p_rows(db._rows("SELECT * FROM cityevents ORDER BY id DESC LIMIT 30"), cap=25)


def _pr_ads(q, rid, page):
    return _p_rows(db.ads(), cap=25)


def _pr_badges(q, rid, page):
    return _p_rows(db.badges(only_active=False), cap=25)


def _pr_stories(q, rid, page):
    return _p_rows(db._rows("SELECT * FROM stories ORDER BY id DESC LIMIT 25"), cap=25)


def _pr_areas(q, rid, page):
    return _p_any(db.areas())


def _pr_categories(q, rid, page):
    return _p_rows(db.categories(only_active=False), cap=40)


def _pr_posts(q, rid, page):
    if rid:
        r = db.post_by_id(rid)
        return _p_detail(r) if r else "مقاله‌ای با این شناسه نیست."
    return _p_rows(db._rows("SELECT * FROM posts ORDER BY id DESC LIMIT 30"), cap=25)


def _pr_pages(q, rid, page):
    slug = q or (str(rid) if rid else "")
    if slug and not str(slug).isdigit():
        p = db.get_page(slug)
        if p:
            return _p_detail(p, 1200)
    return _p_rows(db._rows("SELECT slug,title FROM pages ORDER BY slug"), cap=25)


def _pr_inbox(q, rid, page):
    return _p_rows(db.messages(), cap=30)


def _pr_inquiries(q, rid, page):
    return _p_rows(db.inquiries(), cap=30)


def _pr_questions(q, rid, page):
    return _p_rows(db.questions(), cap=30)


def _pr_reports(q, rid, page):
    return _p_rows(db.reports(), cap=30)


def _pr_haggles(q, rid, page):
    return _p_rows(db.haggles(), cap=25)


def _pr_trash(q, rid, page):
    return _p_rows(db.trash_list(), cap=25)


def _pr_spam(q, rid, page):
    import antispam
    out = _p_any(antispam.report())
    try:
        out += "\n— صف نگه‌داشته‌ها:\n" + _p_any(antispam.held_counts())
        out += "\n— مسدودهای فعال:\n" + _p_any(antispam.bans_active())
    except Exception:
        pass
    return out


def _pr_traffic(q, rid, page):
    import shield
    return _p_any(shield.report())


def _pr_analytics(q, rid, page):
    import analytics
    return _p_any(analytics.overview())


def _pr_audit(q, rid, page):
    return _p_rows(db.audit_log(limit=60, detail=q or ""), cap=40)


def _pr_searches(q, rid, page):
    tot = _p_any(db.search_totals(30))
    top = _p_rows(db.top_searches(30, 20), cap=20)
    return "جمع ۳۰ روز: " + tot + "\n— پرجست‌وجوها:\n" + top


def _pr_ai(q, rid, page):
    s = db.get_settings()
    keys = sorted(k for k in s if k.startswith("ai_"))
    out = "\n".join(f"{k} = {str(s.get(k) or '')[:100]}" for k in keys) or "—"
    try:
        out += f"\nتعداد سؤال‌های آمادهٔ هوش (faq): {len(db.ai_faq_list(active_only=False))}"
    except Exception:
        pass
    return out


def _pr_founders(q, rid, page):
    out = _p_any(db.founder_settings())
    try:
        out += f"\nجای خالی بنیان‌گذاری: {db.founders_left()}"
    except Exception:
        pass
    return out


def _pr_stats(q, rid, page):
    return _p_any(db.stats()) + "\n— ۳۰ روز:\n" + _p_any(db.stats_totals(30))


PANEL_READERS = {
    "settings":      ("تنظیمات سایت (همهٔ کلیدها)", _pr_settings),
    "businesses":    ("کسب‌وکارها (q=جست‌وجو، id=جزئیات کامل)", _pr_businesses),
    "queue":         ("صف تأیید کسب‌وکارها", _pr_queue),
    "items":         ("محصولات/خدمات (q=عنوان یا شناسهٔ کسب‌وکار، id=جزئیات)", _pr_items),
    "orders":        ("سفارش‌ها (id=جزئیات + قلم‌ها)", _pr_orders),
    "bookings":      ("نوبت‌ها", _pr_bookings),
    "chats":         ("چت‌های سایت (q=جست‌وجو، id=رشته + ۱۵ پیام آخر)", _pr_chats),
    "reviews":       ("نظرات", _pr_reviews),
    "claims":        ("درخواست‌های تصاحب کسب‌وکار", _pr_claims),
    "tickets":       ("تیکت‌های پشتیبانی (id=جزئیات + پیام‌ها)", _pr_tickets),
    "customers":     ("مشتریان (q=شماره/نام، id=جزئیات)", _pr_customers),
    "owners":        ("مالکان (q=شماره، id=جزئیات)", _pr_owners),
    "subscriptions": ("اشتراک‌ها (id=فیلتر کسب‌وکار، q=وضعیت)", _pr_subscriptions),
    "plans":         ("پلن‌های اشتراک", _pr_plans),
    "coupons":       ("کدهای تخفیف", _pr_coupons),
    "toplists":      ("لیست‌های برترین‌ها", _pr_toplists),
    "flashdeals":    ("پیشنهادهای ویژه", _pr_flashdeals),
    "events":        ("رویدادهای شهر", _pr_events),
    "ads":           ("بنرهای تبلیغاتی", _pr_ads),
    "badges":        ("نشان‌ها", _pr_badges),
    "stories":       ("استوری‌ها", _pr_stories),
    "areas":         ("محله‌ها", _pr_areas),
    "categories":    ("دسته‌ها", _pr_categories),
    "posts":         ("مقاله‌ها (id=متن کامل)", _pr_posts),
    "pages":         ("صفحه‌های ثابت (q=اسلاگ → متن کامل)", _pr_pages),
    "inbox":         ("پیام‌های دریافتی سایت", _pr_inbox),
    "inquiries":     ("استعلام‌ها", _pr_inquiries),
    "questions":     ("پرسش‌وپاسخ‌ها", _pr_questions),
    "reports":       ("گزارش‌های کاربران", _pr_reports),
    "haggles":       ("چانه‌زنی‌ها", _pr_haggles),
    "trash":         ("سطل بازیافت", _pr_trash),
    "spam":          ("صف اسپم و مسدودها", _pr_spam),
    "traffic":       ("ترافیک و سپر سایت", _pr_traffic),
    "analytics":     ("آمار تحلیلی پنل", _pr_analytics),
    "audit":         ("لاگ تغییرات (q=جست‌وجو در جزئیات)", _pr_audit),
    "searches":      ("جست‌وجوهای سایت", _pr_searches),
    "ai":            ("تنظیمات و وضعیت هوش مصنوعی", _pr_ai),
    "founders":      ("بنیان‌گذاری", _pr_founders),
    "stats":         ("آمار کلی سایت", _pr_stats),
}

_PANEL_ALIASES = {
    "تنظیمات": "settings", "setting": "settings", "تنظیم": "settings",
    "کسب‌وکارها": "businesses", "کسب و کارها": "businesses", "کسبوکارها": "businesses",
    "دکان‌ها": "businesses", "دکانها": "businesses", "business": "businesses",
    "مغازه‌ها": "businesses",
    "صف تأیید": "queue", "صف تایید": "queue", "تأیید": "queue", "تایید": "queue",
    "pending": "queue",
    "محصولات": "items", "آیتم‌ها": "items", "item": "items", "خدمات": "items",
    "سفارش‌ها": "orders", "سفارشات": "orders", "سفارش": "orders", "order": "orders",
    "نوبت‌ها": "bookings", "نوبت": "bookings", "booking": "bookings",
    "چت‌ها": "chats", "چت": "chats", "گفت‌وگوها": "chats", "گفتگوها": "chats",
    "chat": "chats",
    "نظرات": "reviews", "نظر": "reviews", "review": "reviews",
    "تصاحب": "claims", "تصرف": "claims", "claim": "claims",
    "تیکت‌ها": "tickets", "تیکت": "tickets", "ticket": "tickets",
    "مشتریان": "customers", "مشتری": "customers", "customer": "customers",
    "مالکان": "owners", "owner": "owners", "صاحبان": "owners",
    "اشتراک‌ها": "subscriptions", "اشتراک": "subscriptions",
    "subscription": "subscriptions",
    "پلن‌ها": "plans", "پلن": "plans", "plan": "plans",
    "تخفیف‌ها": "coupons", "کوپن": "coupons", "کد تخفیف": "coupons",
    "coupon": "coupons",
    "لیست‌ها": "toplists", "برترین‌ها": "toplists", "toplist": "toplists",
    "پیشنهادها": "flashdeals", "پیشنهاد ویژه": "flashdeals", "فلش": "flashdeals",
    "deal": "flashdeals", "deals": "flashdeals",
    "رویدادها": "events", "رویداد": "events", "event": "events",
    "تبلیغات": "ads", "بنرها": "ads", "بنر": "ads", "ad": "ads",
    "نشان‌ها": "badges", "نشان": "badges", "badge": "badges",
    "استوری‌ها": "stories", "استوری": "stories", "story": "stories",
    "محله‌ها": "areas", "محله": "areas", "area": "areas",
    "دسته‌ها": "categories", "دسته": "categories", "دسته‌بندی": "categories",
    "category": "categories",
    "مقاله‌ها": "posts", "پست‌ها": "posts", "post": "posts", "مقاله": "posts",
    "صفحات": "pages", "صفحه": "pages", "page": "pages",
    "پیام‌ها": "inbox", "صندوق": "inbox", "messages": "inbox", "message": "inbox",
    "استعلام‌ها": "inquiries", "استعلام": "inquiries", "inquiry": "inquiries",
    "پرسش‌ها": "questions", "پرسش": "questions", "سؤالات": "questions",
    "question": "questions",
    "گزارش‌ها": "reports", "گزارش": "reports", "report": "reports",
    "چانه‌ها": "haggles", "چانه": "haggles", "haggle": "haggles",
    "سطل بازیافت": "trash", "سطل": "trash", "زباله": "trash",
    "اسپم": "spam", "هرزنامه": "spam",
    "ترافیک": "traffic", "بازدید": "traffic",
    "آمار": "analytics", "آنالیتیکس": "analytics", "analytics": "analytics",
    "لاگ": "audit", "ممیزی": "audit", "audit": "audit", "تغییرات": "audit",
    "جست‌وجوها": "searches", "جستجو": "searches", "search": "searches",
    "هوش": "ai", "ai": "ai", "هوش مصنوعی": "ai",
    "بنیان‌گذاران": "founders", "بنیانگذاران": "founders", "founder": "founders",
    "آمار سایت": "stats", "stats": "stats",
}


def _panel_key(name, strict=False):
    """Normalize any Persian/English section name to a registry key.
    strict=True skips the substring fallback (used for prefix splitting so a
    query word is never swallowed by a longer alias match)."""
    s = str(name or "").strip().lower().rstrip("‌")
    if not s:
        return ""
    if s in PANEL_READERS:
        return s
    s2 = s.replace("‌", " ").replace("ي", "ی").replace("ك", "ک")
    for k in (s2, s2.replace(" ", "‌"), s2.replace(" ", "")):
        if k in PANEL_READERS:
            return k
        if k in _PANEL_ALIASES:
            return _PANEL_ALIASES[k]
    if strict:
        return ""
    for a, k in _PANEL_ALIASES.items():          # substring tolerance
        if a and (a in s2 or s2 in a):
            return k
    return ""


def panel_sections_text():
    lines = [f"• {k} — {t}" for k, (t, _f) in PANEL_READERS.items()]
    return ("🗂 بخش‌های پنل مدیریت — خواندن همهٔ بخش‌ها آزاد است:\n"
            + "\n".join(lines)
            + "\n\nطرز خواندن: «پنل <بخش>» یا «پنل <بخش> <عدد/عبارت>» "
              "(عدد = شناسه، عبارت = جست‌وجو). نمونه: پنل سفارش‌ها · پنل چت‌ها ۱۲")


def panel_read(section, q="", rid=0, page=1):
    """Read ANY admin-panel section. Read-only; immediate; never raises."""
    key = _panel_key(section)
    if not key:
        return ("⚠️ «" + str(section or "") + "» بخش شناخته‌شده‌ای نیست.\n"
                + panel_sections_text())
    title, fn = PANEL_READERS[key]
    try:
        txt = fn(str(q or ""), int(rid or 0), int(page or 1))
    except Exception as e:
        txt = f"⚠️ این بخش خوانده نشد: {type(e).__name__}: {str(e)[:120]}"
    return f"🗂 {title} [{key}]\n{txt}"[:2900]


def panel_read_cmd(rest):
    """Deterministic chat command: «پنل <section> [id|query]» → text."""
    rest = str(rest or "").strip()
    if not rest:
        return panel_sections_text()
    words = rest.split()
    key, tail_from = "", 0
    # کوتاه‌ترین تطابقِ دقیق اول — تا عبارتِ جست‌وجو قورت داده نشود
    # («کسب و کارها نانوایی» → بخش=کسب‌وکارها، q=نانوایی).
    for n in (1, 2, 3, 4):
        if len(words) >= n:
            k = _panel_key(" ".join(words[:n]), strict=True)
            if k:
                key, tail_from = k, n
                break
    if not key:                                  # تحمل زیررشته، فقط تک‌واژه
        key = _panel_key(words[0])
        tail_from = 1 if key else 0
    if not key:
        return ("⚠️ بخش «" + words[0] + "» شناخته نشد.\n" + panel_sections_text())
    tail = " ".join(words[tail_from:]).strip()
    # دنبالهٔ تمام‌عدد (فارسی یا انگلیسی) و کوتاه = شناسهٔ ردیف؛ عدد بلند
    # (مثل شمارهٔ موبایل ۱۱ رقمی) = عبارت جست‌وجو، نه شناسه.
    t2 = _fa2en_digits(tail).replace(" ", "")
    rid = int(t2) if (t2.isdigit() and 0 < len(t2) <= 6) else 0
    q = "" if rid else tail
    return panel_read(key, q=q, rid=rid)


def _fa2en_digits(s):
    return (str(s or "").translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")))


def _owner_find(who):
    """owner by id or phone — for owner_moderate."""
    w = _fa2en_digits(str(who or "").strip())
    if not w:
        return None
    if w.isdigit() and len(w) <= 6:
        return db._one("SELECT * FROM owners WHERE id=?", (int(w),))
    ph = db.norm_phone(w) or w
    return db.owner_by_phone(ph, create=False)


# ------------------------------------------------------------------ precheck

def tool_precheck(tool, args):
    """Dry-run policy WITHOUT writing. Returns (ok, reason)."""
    try:
        if tool in ("code_list", "code_read", "code_edit", "code_write",
                    "code_revert", "code_search", "code_status", "ai_setup",
                    "service_restart", "brain_switch"):
            return CODE.precheck(tool, args)
        if tool in ("broadcast",):
            return True, ""
        if tool == "panel_sections":           # v282
            return True, ""
        if tool == "sec_report":               # v287
            return True, ""
        if tool == "panel_read":               # v282
            return (True, "") if _panel_key(args.get("section")) else (False, "section")
        if tool == "subscription_set":         # v282
            if not db._one("SELECT id FROM businesses WHERE id=?", (args["biz_id"],)):
                return False, "missing"
            try:
                slugs = {p["slug"] for p in db.plans(only_active=False)}
            except Exception:
                slugs = set()
            if args["plan_slug"] not in slugs:
                return False, "plan"
            if args.get("months") and not (1 <= int(args["months"]) <= 120):
                return False, "months"
            return True, ""
        if tool == "owner_moderate":           # v282
            return (True, "") if _owner_find(args.get("owner")) else (False, "owner")
        if tool == "setting":
            # v240 dynamic: the key must already exist in settings or be a
            # key the panel itself would write. v268: batch checks every key.
            _pks = ([i.get("key") for i in args.get("items", [])]
                    if "items" in args else [args.get("key")])
            for _pk in _pks:
                if (_pk or "") in _AUTH_KEYS:   # v265: full access
                    continue
                row = db._one("SELECT key FROM settings WHERE key=?", (_pk,))
                if row or _pk in TEXT_SETTINGS or _pk in TOGGLE_SETTINGS \
                        or _pk in FLOAT_SETTINGS or _pk in INT_SETTINGS:
                    continue
                return False, "key"
            return True, ""
        if tool == "page":
            if args["slug"] in ("about", "rules"):
                return True, ""
            return (True, "") if db._one("SELECT slug FROM pages WHERE slug=?",
                                         (args["slug"],)) else (False, "missing")
        if tool == "post_save":
            if args.get("id") and not db._one("SELECT id FROM posts WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            if args.get("cover") and not _resolve_image(args["cover"]):
                return False, "image"
            return True, ""
        if tool == "post_delete":
            if not db._one("SELECT id FROM posts WHERE id=?", (args.get("id"),)):
                return False, "missing"
            return True, ""
        if tool == "category_save":
            if args.get("parent") and not db._one(
                    "SELECT id FROM categories WHERE slug=?", (args.get("parent"),)):
                return False, "parent"
            if args.get("id") and not db._one(
                    "SELECT id FROM categories WHERE id=?", (args.get("id"),)):
                return False, "missing"
            if args.get("image") and not _resolve_image(args["image"]):
                return False, "image"
            return True, ""
        if tool == "category_delete":
            if not db._one("SELECT id FROM categories WHERE id=?", (args.get("id"),)):
                return False, "missing"
            return True, ""
        if tool == "business_save":
            bid = args.get("id") or 0
            if bid and not db._one("SELECT id FROM businesses WHERE id=?", (bid,)):
                return False, "missing"
            f = args.get("fields") or {}
            if f.get("cat_slug") and not db._one(
                    "SELECT id FROM categories WHERE slug=?", (f.get("cat_slug"),)):
                return False, "cat"
            if f.get("cover") and not _resolve_image(f["cover"]):
                return False, "image"
            if "images" in f:
                for p in json.loads(f["images"]):
                    if not _resolve_image(p):
                        return False, "image"
            return True, ""
        if tool == "item_save":
            if not db._one("SELECT id FROM businesses WHERE id=?",
                           ((args.get("data") or {}).get("biz_id"),)):
                return False, "missing"
            if args.get("id") and not db._one(
                    "SELECT id FROM items WHERE id=?", (args.get("id"),)):
                return False, "missing"
            if "images" in (args.get("data") or {}):
                for p in json.loads(args["data"]["images"]):
                    if not _resolve_image(p):
                        return False, "image"
            return True, ""
        if tool == "item_delete":
            if not db._one("SELECT id FROM items WHERE id=?", (args.get("id"),)):
                return False, "missing"
            return True, ""
        if tool == "review_moderate":
            r = db._one("SELECT status FROM reviews WHERE id=?", (args.get("id"),))
            if not r:
                return False, "missing"
            if r["status"] != "pending":
                return False, "already"
            return True, ""
        if tool == "review_delete":
            return (True, "") if db._one("SELECT id FROM reviews WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "biz_moderate":
            need = {"approve": "pending", "reject": "pending",
                    "hide": "published"}.get(args.get("action"))
            r = db._one("SELECT status,published_once FROM businesses WHERE id=?",
                        (args.get("id"),))
            if not r:
                return False, "missing"
            if args.get("action") == "show":
                if r["status"] != "hidden":
                    return False, "already"
                if not r["published_once"]:
                    return False, "never"
            elif r["status"] != need:
                return False, "already"
            return True, ""
        # ---------------- v240 ----------------
        if tool == "coupon_save":
            if args.get("id") and not db._one("SELECT id FROM coupons WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            if args.get("biz_id") and not db._one(
                    "SELECT id FROM businesses WHERE id=?", (args.get("biz_id"),)):
                return False, "missing"
            return True, ""
        if tool == "coupon_delete":
            return (True, "") if db._one("SELECT id FROM coupons WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "toplist_save":
            if args.get("id") and not db._one("SELECT id FROM toplists WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            if args.get("kind") == "manual" and args.get("items"):
                n = len(set(args["items"]))
                got = db._one("SELECT COUNT(*) c FROM businesses WHERE id IN (%s)"
                              % ",".join("?" * n), list(set(args["items"])))["c"]
                if got != n:
                    return False, "missing"
            return True, ""
        if tool == "toplist_delete":
            return (True, "") if db._one("SELECT id FROM toplists WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "flashdeal_save":
            if args.get("id") and not db._one("SELECT id FROM flashdeals WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            return (True, "") if db._one("SELECT id FROM businesses WHERE id=?",
                                         (args.get("biz_id"),)) else (False, "missing")
        if tool == "flashdeal_delete":
            return (True, "") if db._one("SELECT id FROM flashdeals WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "event_save":
            if args.get("id") and not db._one("SELECT id FROM cityevents WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            if args.get("biz_id") and not db._one(
                    "SELECT id FROM businesses WHERE id=?", (args.get("biz_id"),)):
                return False, "missing"
            if args.get("image") and not _resolve_image(args["image"]):
                return False, "image"
            return True, ""
        if tool == "event_delete":
            return (True, "") if db._one("SELECT id FROM cityevents WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "ad_save":
            if args.get("id") and not db._one("SELECT id FROM ads WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            if args.get("biz_id") and not db._one(
                    "SELECT id FROM businesses WHERE id=?", (args.get("biz_id"),)):
                return False, "missing"
            if args.get("image") and not _resolve_image(args["image"]):
                return False, "image"
            return True, ""
        if tool == "ad_delete":
            return (True, "") if db._one("SELECT id FROM ads WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "plan_save":
            if args.get("id") and not db._one("SELECT id FROM plans WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            return True, ""
        if tool == "plan_delete":
            return (True, "") if db._one("SELECT id FROM plans WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "badge_save":
            if args.get("id") and not db._one("SELECT id FROM badges WHERE id=?",
                                              (args.get("id"),)):
                return False, "missing"
            return True, ""
        if tool == "badge_delete":
            return (True, "") if db._one("SELECT id FROM badges WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "story_add":
            if not db._one("SELECT id FROM businesses WHERE id=?", (args.get("biz_id"),)):
                return False, "missing"
            if not _resolve_image(args.get("image")):
                return False, "image"
            return True, ""
        if tool == "story_delete":
            return (True, "") if db._one("SELECT id FROM stories WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "claim_moderate":
            r = db._one("SELECT status FROM claims WHERE id=?", (args.get("id"),))
            if not r:
                return False, "missing"
            if r["status"] != "pending":
                return False, "already"
            return True, ""
        if tool == "ticket_reply":
            return (True, "") if db._one("SELECT id FROM tickets WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "customer_moderate":
            return (True, "") if db._one("SELECT id FROM customers WHERE phone=?",
                                         (args.get("phone"),)) else (False, "missing")
        if tool == "order_status":
            return (True, "") if db._one("SELECT id FROM orders WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "booking_status":
            return (True, "") if db._one("SELECT id FROM bookings WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "area_rename":
            n = db._one("SELECT COUNT(*) c FROM businesses WHERE area=?",
                        (args.get("old"),))["c"]
            return (True, "") if n else (False, "missing")
        if tool == "trash_restore":
            return (True, "") if db._one("SELECT id FROM trash WHERE id=?",
                                         (args.get("id"),)) else (False, "missing")
        if tool == "bulk_approve":
            return True, ""
        if tool in ("backup_now","cache_clear","seo_check","health_check",
                    "file_list","file_upload","file_download",
                    "sys_info","file_read","file_write","file_edit","file_delete",
                    "db_tables","backup_list","version_info"):
            return True, ""
        # v310
        if tool == "shell_exec":
            return ((True, "") if (args.get("cmd") or "").strip()
                    else (False, "cmd خالی است"))
        if tool == "sql_read":
            q = (args.get("q") or "").strip()
            if not q:
                return False, "پرس‌وجو خالی است"
            if not re.match(r"^\s*(select|with|pragma|explain)\b", q, re.I):
                return False, "فقط SELECT/WITH/PRAGMA مجاز است — نوشتن با ابزارهای خودش"
            if ";" in q.rstrip().rstrip(";"):
                return False, "فقط یک پرس‌وجو در هر بار"
            return True, ""
        if tool == "log_tail":
            return True, ""
    except Exception:
        return False, "error"
    return False, "error"


# ------------------------------------------------------------------ execute

def tool_execute(tool, args):
    """Run a validated tool through the site's own functions. Re-validates
    everything (parse + precheck), audit-logs, never raises.
    Returns (ok, message)."""
    try:
        tool, args = parse_tool_call({"name": tool, "args": args})
        if not tool:
            return False, "درخواست معتبر نبود؛ دوباره بگو."
        ok, why = tool_precheck(tool, args)
        if not ok:
            return False, fail_text(tool, why)

        if tool == "file_list":
            return _exec_file_list(args)
        if tool == "file_upload":
            return _exec_file_upload(args)
        if tool == "file_download":
            return _exec_file_download(args)
        # v310: ترمینال + sql خواندنی + لاگ
        if tool == "shell_exec":
            return _exec_shell(args)
        if tool == "sql_read":
            return _exec_sql_read(args)
        if tool == "log_tail":
            return _exec_log_tail(args)
        # v312: ابزارهای جدید — v316 arena removed
        if tool == "sys_info":
            return _exec_sys_info(args)
        if tool == "file_read":
            return _exec_file_read(args)
        if tool == "file_write":
            return _exec_file_write(args)
        if tool == "file_edit":
            return _exec_file_edit(args)
        if tool == "file_delete":
            return _exec_file_delete(args)
        if tool == "db_tables":
            return _exec_db_tables(args)
        if tool == "backup_list":
            return _exec_backup_list(args)
        if tool == "version_info":
            return _exec_version_info(args)

        if tool in ("code_list", "code_read", "code_edit", "code_write",
                    "code_revert", "code_search", "code_status", "ai_setup",
                    "service_restart", "brain_switch"):
            ok2, msg = CODE.execute(tool, args)
            return (ok2, msg if ok2 else fail_text(tool, msg))
        if tool == "panel_sections":           # v282: خواندن فوری، بدون «بله»
            return True, panel_sections_text()
        if tool == "sec_report":               # v287: امنیت واقعی، فوری
            import adminbot                    # محلی: adminbot خودش CT را دارد
            return True, adminbot.do_sec()
        if tool == "panel_read":
            return True, panel_read(args.get("section"), q=args.get("q") or "",
                                    rid=args.get("id") or 0,
                                    page=args.get("page") or 1)
        if tool == "subscription_set":         # v282: اشتراک‌گذاری از چت مدیر
            sid, info = db.request_subscription(
                args["biz_id"], args["plan_slug"],
                method="adminbot", note="از دستور مدیر در ربات بله",
                months=(args.get("months") or None))
            if not sid:
                return False, str(info or "ثبت اشتراک ناموفق بود.")
            db.activate_subscription(sid, months=(args.get("months") or None))
            db.log("admin_ai_tool",
                   f"subscription_set biz={args['biz_id']} plan={args['plan_slug']} "
                   f"months={args.get('months') or 'plan-default'}")
            s = db.subscription_of(args["biz_id"])
            exp = (s or {}).get("expires") or "—"
            return True, (f"✅ اشتراک «{args['plan_slug']}» برای کسب‌وکار "
                          f"#{args['biz_id']} فعال شد (تا {exp}).\n"
                          "سطح سهمیهٔ هوش و امکانات پلن فوراً اعمال می‌شود.")
        if tool == "owner_moderate":           # v282
            o = _owner_find(args.get("owner"))
            if not o:
                return False, fail_text(tool, "owner")
            st = "blocked" if args["action"] == "block" else "active"
            db.set_owner_status(o["id"], st)
            db.log("admin_ai_tool", f"owner_moderate owner={o['id']} -> {st}")
            return True, (f"✅ مالک #{o['id']} ({o.get('phone') or '—'}) "
                          f"{'مسدود' if st=='blocked' else 'آزاد'} شد.")
        if tool == "setting":
            if "items" in args:               # v268: batch write, same rules
                _msgs, _errs = [], []
                for _it in args["items"]:
                    _ok, _m = tool_execute(tool, {"key": _it["key"], "value": _it["value"]})
                    (_msgs if _ok else _errs).append(_m)
                if _errs and not _msgs:
                    return False, "\n".join(_errs)
                _keys = "، ".join("«" + str(_it["key"]) + "»" for _it in args["items"])
                return True, f"✏️ {len(args['items'])} تنظیم ذخیره شد: {_keys}."
            if args["key"] == "owner_pass_hash":
                # v265: a panel password from chat is PLAINTEXT — only its
                # PBKDF2 hash is ever stored (same function the panel uses).
                db.set_owner_pass(args["value"])
            else:
                db.set_setting(args["key"], args["value"])
            _v = ("<مقدار پنهان>" if _secretish(args["key"])
                  else str(args["value"])[:80])
            db.log("admin_ai_tool", f"setting {args['key']}={_v}")
            if args["key"] == "owner_token":
                base = (db.get_settings().get("site_url") or "").strip().rstrip("/")
                link = (f"{base}/panel/settings?key={args['value']}" if base
                        else f"/panel/settings?key={args['value']}")
                return True, ("🔑 توکن تازهٔ ورود ذخیره شد.\n"
                              f"نشانی تازهٔ پنل:\n{link}\n"
                              "این نشانی را ذخیره کن؛ نشانی قبلی دیگر کار نمی‌کند.")
            if args["key"] == "owner_pass_hash":
                return True, "🔑 رمز تازهٔ پنل ذخیره شد (فقط هش آن نگه داشته شد)."
            return True, f"✏️ «{args['key']}» ذخیره شد."
        if tool == "page":
            db.save_page(args["slug"], args["title"], args["body"])
            db.log("admin_ai_tool", f"page {args['slug']} title={args['title'][:40]}")
            return True, f"📄 صفحهٔ {args['slug']} کامل بازنویسی شد."
        if tool == "post_save":
            data = {"title": args["title"], "excerpt": args["excerpt"],
                    "body": args["body"], "status": args["status"]}
            if args["id"] and args.get("cover"):
                data["cover"] = _resolve_image(args["cover"]) or ""
            elif args["id"]:      # keep the existing cover
                cur = db._one("SELECT cover FROM posts WHERE id=?", (args["id"],))
                data["cover"] = (cur or {}).get("cover") or ""
            elif args.get("cover"):
                data["cover"] = _resolve_image(args["cover"]) or ""
            pid = db.save_post(data, pid=args["id"] or None)
            db.log("admin_ai_tool", f"post_save id={pid} {args['title'][:40]}")
            return True, f"📰 مقالهٔ «{args['title']}» ذخیره شد (#{pid})."
        if tool == "post_delete":
            db.delete_post(args["id"])
            db.log("admin_ai_tool", f"post_delete id={args['id']}")
            return True, f"🗑 مقالهٔ #{args['id']} حذف شد."
        if tool == "category_save":
            if args["id"]:      # merge unspecified columns from the live row
                cur = db._one("SELECT icon,blurb,sort,active,parent,image "
                              "FROM categories WHERE id=?", (args["id"],)) or {}
                data = {"name": args["name"],
                        "icon": args.get("icon") or cur.get("icon") or "store",
                        "blurb": args["blurb"] if "blurb" in args else (cur.get("blurb") or ""),
                        "sort": args["sort"] if "sort" in args else (cur.get("sort") or 0),
                        "active": args["active"] if "active" in args else (cur.get("active") or 1),
                        "parent": args["parent"] if "parent" in args else (cur.get("parent") or ""),
                        "image": (_resolve_image(args["image"]) if args.get("image")
                                  else (cur.get("image") or ""))}
            else:
                data = {"name": args["name"],
                        "icon": args.get("icon") or "store",
                        "blurb": args.get("blurb") or "",
                        "sort": args.get("sort") or 0,
                        "active": args.get("active", 1),
                        "parent": args.get("parent") or "",
                        "image": (_resolve_image(args["image"]) if args.get("image") else "")}
            cid = db.save_category(data, cid=args["id"] or None)
            db.log("admin_ai_tool", f"category_save id={cid} {args['name'][:40]}")
            return True, f"🗂 دستهٔ «{args['name']}» ذخیره شد (#{cid})."
        if tool == "category_delete":
            ok2, msg = db.delete_category(args["id"])
            if ok2:
                db.log("admin_ai_tool", f"category_delete id={args['id']}")
                return True, f"🗑 دستهٔ #{args['id']} حذف شد."
            return False, msg
        if tool == "business_save":
            fields = dict(args["fields"])
            if "cover" in fields and fields["cover"]:
                fields["cover"] = _resolve_image(fields["cover"])
            if "images" in fields and fields["images"]:
                fields["images"] = [_resolve_image(p) for p in json.loads(fields["images"])]
            created = not args.get("id")
            bid = db.save_business(fields, bid=args["id"] or None)
            b = db._one("SELECT name FROM businesses WHERE id=?", (bid,)) or {}
            db.log("admin_ai_tool",
                   f"business_save id={bid} fields={','.join(sorted(fields))}")
            what = "ساخته شد" if created else "به‌روز شد"
            return True, f"🏪 «{b.get('name') or bid}» {what}."
        if tool == "item_save":
            d = dict(args["data"])
            if "images" in d and d["images"]:
                d["images"] = [_resolve_image(p) for p in json.loads(d["images"])]
            iid = db.save_item(d, iid=args["id"] or None)
            db.log("admin_ai_tool",
                   f"item_save id={iid} biz={(args['data'] or {}).get('biz_id')}")
            return True, f"📦 محتوا ذخیره شد (#{iid})."
        if tool == "item_delete":
            it = db._one("SELECT title FROM items WHERE id=?", (args.get("id"),)) or {}
            db.delete_item(args["id"])
            db.log("admin_ai_tool", f"item_delete id={args['id']}")
            return True, f"🗑 «{it.get('title') or args['id']}» حذف شد (سطل بازیافت)."
        if tool == "review_moderate":
            if args["action"] == "approve":
                kw = {"status": "approved"}
                if args.get("reply"):
                    kw["reply"] = args["reply"]
                db.update_review(args["id"], **kw)
                db.log("admin_ai_tool", f"review_approve id={args['id']}")
                return True, f"✅ نظر #{args['id']} تأیید و منتشر شد."
            kw = {"status": "rejected"}
            if args.get("reply"):
                kw["reply"] = args["reply"]
            db.update_review(args["id"], **kw)
            db.review_reject_notify(args["id"])
            db.log("admin_ai_tool", f"review_reject id={args['id']}")
            return True, f"🚫 نظر #{args['id']} رد شد."
        if tool == "review_delete":
            db.delete_review(args["id"])
            db.log("admin_ai_tool", f"review_delete id={args['id']}")
            return True, f"🗑 نظر #{args['id']} حذف شد."
        if tool == "biz_moderate":
            act = args["action"]
            status = {"approve": "published", "reject": "rejected",
                      "hide": "hidden", "show": "published"}[act]
            b = db._one("SELECT name FROM businesses WHERE id=?", (args["id"],)) or {}
            db.save_business({"status": status}, bid=args["id"])
            db.log("admin_ai_tool", f"biz_{act} id={args['id']} {b.get('name') or ''}")
            return True, f"🏪 «{b.get('name') or args['id']}» → {status}."
        if tool == "broadcast":
            n = db.notify_all("info", args["text"], "")
            db.log("admin_ai_tool", f"broadcast n={n}")
            return True, f"📣 اعلان برای {n} مشتری ارسال شد."
        # ---------------- v240 ----------------
        if tool == "coupon_save":
            if args["id"]:
                con = db.connect()
                con.execute("UPDATE coupons SET biz_id=?,code=?,title=?,percent=?,"
                            "expires=?,active=? WHERE id=?",
                            (args["biz_id"] or None, args["code"], args["title"],
                             args["percent"], args["expires"], args["active"], args["id"]))
                con.commit(); con.close()
                cid = args["id"]
            else:
                cid = db._run("INSERT INTO coupons(biz_id,code,title,percent,expires,active) "
                              "VALUES(?,?,?,?,?,?)",
                              (args["biz_id"] or None, args["code"], args["title"],
                               args["percent"], args["expires"], args["active"]))
            db.log("admin_ai_tool", f"coupon_save id={cid} {args['code']}")
            return True, f"🎟 کد «{args['code']}» ذخیره شد (#{cid})."
        if tool == "coupon_delete":
            db._run("DELETE FROM coupons WHERE id=?", (args["id"],))
            db.log("admin_ai_tool", f"coupon_delete id={args['id']}")
            return True, f"🗑 کد تخفیف #{args['id']} حذف شد."
        if tool == "toplist_save":
            data = {"title": args["title"], "descr": args["descr"], "kind": args["kind"],
                    "items": args["items"], "limit_n": args["limit_n"],
                    "sort": args["sort"], "active": args["active"]}
            tid = features.save_toplist(data, tid=args["id"] or None)
            db.log("admin_ai_tool", f"toplist_save id={tid} {args['title'][:40]}")
            return True, f"🏆 لیست «{args['title']}» ذخیره شد (#{tid})."
        if tool == "toplist_delete":
            features.delete_toplist(args["id"])
            db.log("admin_ai_tool", f"toplist_delete id={args['id']}")
            return True, f"🗑 لیست #{args['id']} حذف شد."
        if tool == "flashdeal_save":
            data = {"biz_id": args["biz_id"], "title": args["title"],
                    "descr": args["descr"], "percent": args["percent"],
                    "starts": args["starts"], "ends": args["ends"], "active": args["active"]}
            did = features.save_flashdeal(data, did=args["id"] or None)
            db.log("admin_ai_tool", f"flashdeal_save id={did} {args['title'][:40]}")
            return True, f"⚡ پیشنهاد «{args['title']}» ذخیره شد (#{did})."
        if tool == "flashdeal_delete":
            features.delete_flashdeal(args["id"])
            db.log("admin_ai_tool", f"flashdeal_delete id={args['id']}")
            return True, f"🗑 پیشنهاد #{args['id']} حذف شد."
        if tool == "event_save":
            data = {"title": args["title"], "descr": args["descr"], "place": args["place"],
                    "date": args["date"], "time": args["time"],
                    "biz_id": args["biz_id"] or None,
                    "image": (_resolve_image(args["image"]) if args["image"] else ""),
                    "status": args["status"]}
            eid = db.save_cityevent(data, eid=args["id"] or None)
            db.log("admin_ai_tool", f"event_save id={eid} {args['title'][:40]}")
            return True, f"🎉 رویداد «{args['title']}» ذخیره شد (#{eid})."
        if tool == "event_delete":
            db.delete_cityevent(args["id"])
            db.log("admin_ai_tool", f"event_delete id={args['id']}")
            return True, f"🗑 رویداد #{args['id']} حذف شد."
        if tool == "ad_save":
            data = {"title": args["title"], "body": args["body"],
                    "image": (_resolve_image(args["image"]) if args["image"] else ""),
                    "url": args["url"], "slot": args["slot"],
                    "biz_id": args["biz_id"] or None, "starts": args["starts"],
                    "ends": args["ends"], "weight": args["weight"], "active": args["active"]}
            aid = db.save_ad(data, aid=args["id"] or None)
            db.log("admin_ai_tool", f"ad_save id={aid} {args['title'][:40]}")
            return True, f"📢 بنر «{args['title']}» ذخیره شد (#{aid})."
        if tool == "ad_delete":
            db.delete_ad(args["id"])
            db.log("admin_ai_tool", f"ad_delete id={args['id']}")
            return True, f"🗑 بنر #{args['id']} حذف شد."
        if tool == "plan_save":
            data = dict(args)
            pid = db.save_plan(data, pid=args["id"] or None)
            db.log("admin_ai_tool", f"plan_save id={pid} {args['name'][:40]}")
            return True, f"💳 پلن «{args['name']}» ذخیره شد (#{pid})."
        if tool == "plan_delete":
            ok2, msg = db.delete_plan(args["id"])
            if ok2:
                db.log("admin_ai_tool", f"plan_delete id={args['id']}")
                return True, f"🗑 پلن #{args['id']} حذف شد."
            return False, msg
        if tool == "badge_save":
            data = dict(args)
            bid = db.save_badge(data, bid=args["id"] or None)
            db.log("admin_ai_tool", f"badge_save id={bid} {args['name'][:40]}")
            return True, f"🏅 نشان «{args['name']}» ذخیره شد (#{bid})."
        if tool == "badge_delete":
            db.delete_badge(args["id"])
            db.log("admin_ai_tool", f"badge_delete id={args['id']}")
            return True, f"🗑 نشان #{args['id']} حذف شد."
        if tool == "story_add":
            img = _resolve_image(args["image"])
            if not img:
                return False, fail_text(tool, "image")
            features.stories_add(args["biz_id"], img, args["caption"],
                                 args["kind"], args["duration"])
            db.log("admin_ai_tool", f"story_add biz={args['biz_id']} image={img[:60]}")
            return True, "📸 استوری ثبت شد (۲۴ ساعت)."
        if tool == "story_delete":
            db._run("DELETE FROM stories WHERE id=?", (args["id"],))
            db.log("admin_ai_tool", f"story_delete id={args['id']}")
            return True, f"🗑 استوری #{args['id']} حذف شد."
        if tool == "claim_moderate":
            approve = args["action"] == "approve"
            if not db.claim_decide(args["id"], approve):
                return False, fail_text(tool, "missing")
            db.log("admin_ai_tool", f"claim_{args['action']} id={args['id']}")
            return True, ("🔑 کسب‌وکار واگذار شد." if approve else "درخواست تصاحب رد شد.")
        if tool == "ticket_reply":
            mid = db.ticket_reply(args["id"], args["body"])
            if not mid:
                return False, "پاسخ ثبت نشد؛ دوباره بگو."
            db.log("admin_ai_tool", f"ticket_reply id={args['id']} msg={mid}")
            return True, f"💬 پاسخ به تیکت #{args['id']} ارسال شد."
        if tool == "customer_moderate":
            c = db._one("SELECT id FROM customers WHERE phone=?", (args["phone"],))
            if not c or not features.customer_set_status(c["id"], "blocked" if args["action"] == "block" else "active"):
                return False, fail_text(tool, "missing")
            db.log("admin_ai_tool", f"customer_{args['action']} {args['phone']}")
            return True, (f"⛔ مشتری {args['phone']} مسدود شد."
                          if args["action"] == "block"
                          else f"✅ مسدودی مشتری {args['phone']} برداشته شد.")
        if tool == "order_status":
            db._run("UPDATE orders SET status=? WHERE id=?", (args["status"], args["id"]))
            db.log("admin_ai_tool", f"order_status id={args['id']} -> {args['status']}")
            return True, f"📦 سفارش #{args['id']} → {args['status']}."
        if tool == "booking_status":
            if not db.update_booking(args["id"], status=args["status"]):
                return False, "وضعیت نوبت معتبر نیست."
            db.log("admin_ai_tool", f"booking_status id={args['id']} -> {args['status']}")
            return True, f"📅 نوبت #{args['id']} → {args['status']}."
        if tool == "area_rename":
            n = features.rename_area(args["old"], args["new"])
            db.log("admin_ai_tool", f"area_rename '{args['old']}'->'{args['new']}' n={n}")
            return True, f"📍 نام محله عوض شد ({n} کسب‌وکار)."
        if tool == "trash_restore":
            if not db.trash_restore(args["id"]):
                return False, fail_text(tool, "missing")
            db.log("admin_ai_tool", f"trash_restore id={args['id']}")
            return True, "♻️ از سطل بازیافت برگشت."

        # v297 new tools
        if tool == "bulk_approve":
            kind = args.get("kind")
            cnt = 0
            if kind == "businesses":
                rows = db._all("SELECT id FROM businesses WHERE status='pending'")
                for r in rows:
                    if db.approve_business(r["id"]): cnt+=1
            elif kind == "reviews":
                rows = db._all("SELECT id FROM reviews WHERE status='pending'")
                for r in rows:
                    db._run("UPDATE reviews SET status='approved' WHERE id=?", (r["id"],)); cnt+=1
            elif kind == "reports":
                rows = db._all("SELECT id FROM reports WHERE status='open'")
                for r in rows:
                    db._run("UPDATE reports SET status='resolved' WHERE id=?", (r["id"],)); cnt+=1
            elif kind == "claims":
                rows = db._all("SELECT id FROM claims WHERE status='pending'")
                for r in rows:
                    if db.claim_decide(r["id"], True): cnt+=1
            elif kind == "edits":
                rows = db._all("SELECT id FROM pending_edits WHERE status='pending'")
                for r in rows:
                    db._run("UPDATE pending_edits SET status='approved' WHERE id=?", (r["id"],)); cnt+=1
            elif kind == "subscriptions":
                rows = db._all("SELECT id FROM subscriptions WHERE status='pending'")
                for r in rows:
                    db._run("UPDATE subscriptions SET status='active' WHERE id=?", (r["id"],)); cnt+=1
            elif kind == "messages":
                rows = db._all("SELECT id FROM inbox WHERE status='new'")
                for r in rows:
                    db._run("UPDATE inbox SET status='read' WHERE id=?", (r["id"],)); cnt+=1
            db.log("admin_ai_tool", f"bulk_approve kind={kind} cnt={cnt}")
            return True, f"✅ {cnt} مورد {kind} تایید شد."
        if tool == "backup_now":
            import shutil, datetime
            src = db.DB_PATH
            dst_dir = os.path.join(db.DATA_DIR, "backups")
            os.makedirs(dst_dir, exist_ok=True)
            ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
            dst = os.path.join(dst_dir, f"bazarche-{ts}.db")
            try:
                shutil.copy2(src, dst)
                sz = os.path.getsize(dst)//1024
                db.log("admin_ai_tool", f"backup_now {dst} {sz}KB")
                return True, f"💾 بکاپ ساخته شد: {os.path.basename(dst)} ({sz}KB)"
            except Exception as e:
                return False, f"بکاپ ناموفق: {e}"
        if tool == "cache_clear":
            # clear file cache if exists
            import glob as _glob
            cache_dir = os.path.join(db.DATA_DIR, "cache")
            n=0
            if os.path.isdir(cache_dir):
                for f in _glob.glob(os.path.join(cache_dir, "*")):
                    try: os.remove(f); n+=1
                    except: pass
            db.log("admin_ai_tool", f"cache_clear n={n}")
            return True, f"🧹 کش پاک شد ({n} فایل)."
        if tool == "seo_check":
            # basic SEO checks
            checks=[]
            sets = db.get_settings()
            checks.append(("title" if sets.get("site_name") else "❌ site_name خالی", bool(sets.get("site_name"))))
            checks.append(("description" if sets.get("site_description") else "❌ توضیحات سایت خالی", bool(sets.get("site_description"))))
            # count businesses without description
            r = db._one("SELECT COUNT(*) c FROM businesses WHERE status='approved' AND (descr IS NULL OR descr='')")
            checks.append((f"{r['c']} کسب‌وکار بدون توضیح" if r and r['c']>0 else "همه کسب‌وکارها توضیح دارند", r['c']==0 if r else True))
            r2 = db._one("SELECT COUNT(*) c FROM posts WHERE status='published'")
            checks.append((f"{r2['c']} مقاله منتشرشده" if r2 else "0 مقاله", True))
            msg = "🔍 بررسی سئو:\n" + "\n".join([f"{'✅' if ok else '⚠️'} {txt}" for txt,ok in checks])
            db.log("admin_ai_tool", "seo_check")
            return True, msg
        if tool == "health_check":
            # comprehensive health
            out=[]
            out.append("🏥 سلامت سایت:")
            # db
            try:
                db._one("SELECT 1")
                out.append("✅ دیتابیس: متصل")
            except Exception as e:
                out.append(f"❌ دیتابیس: {e}")
            # tables
            for t in ("businesses","items","categories","posts","settings"):
                try:
                    c = db._one(f"SELECT COUNT(*) c FROM {t}")
                    out.append(f"✅ {t}: {c['c'] if c else 0} ردیف")
                except Exception as e:
                    out.append(f"❌ {t}: {e}")
            # settings
            s = db.get_settings()
            out.append(f"✅ تنظیمات: {len(s)} کلید")
            # disk
            import shutil as _sh
            du = _sh.disk_usage(db.DATA_DIR)
            out.append(f"💾 دیسک آزاد: {du.free//1024//1024}MB")
            db.log("admin_ai_tool", "health_check")
            return True, "\n".join(out)

    except Exception as e:
        print("adminbot_content execute error:", e, flush=True)
        return False, "خطای داخلی؛ تغییر انجام نشد."
    return False, "این ابزار شناخته نشد."


# ------------------------------------------------------------------ snapshot

# ------------------------------------------------------------------ v297: agent confirm with full report + rollback
# User request: when agent wants to apply a change, it must NOT execute until
# user confirms with new option. Show confirm/cancel. Before showing options,
# deliver full report of what it will do. /stop immediately stops and reverts.

def _rollback_path():
    return os.path.join(db.DATA_DIR, "agent-rollback.json")

def _last_action_path():
    return os.path.join(db.DATA_DIR, "agent-last-action.json")

def tool_report(tool, args):
    """Full report of what the tool will do — for confirmation screen."""
    try:
        desc = tool_describe(tool, args)
        lines = [f"📋 گزارش اقدام پیشنهادی", f"—" * 28, f"🔧 ابزار: {tool}", f"📝 خلاصه: {desc}", ""]
        # Add specific details per tool
        if tool == "setting":
            if "items" in args:
                for it in args["items"]:
                    k = it.get("key","")
                    old = db.get_settings().get(k, "")
                    lines.append(f"  • {k}: «{str(old)[:60]}» → «{str(it.get('value'))[:60]}»")
            else:
                k = args.get("key","")
                old = db.get_settings().get(k, "")
                lines.append(f"  • {k}: «{str(old)[:80]}» → «{str(args.get('value'))[:80]}»")
        elif tool == "business_save":
            bid = args.get("id")
            if bid:
                cur = db._one("SELECT * FROM businesses WHERE id=?", (bid,))
                if cur:
                    lines.append(f"  • کسب‌وکار #{bid} «{cur.get('name')}»")
                    for kk,vv in (args.get("fields") or {}).items():
                        old = cur.get(kk, "")
                        lines.append(f"    - {kk}: «{str(old)[:50]}» → «{str(vv)[:50]}»")
            else:
                lines.append(f"  • ایجاد کسب‌وکار «{(args.get('fields') or {}).get('name')}»")
        elif tool == "ad_save":
            aid = args.get("id")
            if aid:
                cur = db._one("SELECT * FROM ads WHERE id=?", (aid,))
                if cur:
                    lines.append(f"  • بنر #{aid} «{cur.get('title')}»")
                    for kk in ("title","body","slot","active","weight","url"):
                        if kk in args:
                            lines.append(f"    - {kk}: «{str(cur.get(kk))[:40]}» → «{str(args.get(kk))[:40]}»")
            else:
                lines.append(f"  • ایجاد بنر «{args.get('title')}» در جایگاه {args.get('slot')}")
        elif tool == "code_edit":
            lines.append(f"  • فایل: {args.get('path')}")
            lines.append(f"  • تعداد ویرایش: {len(args.get('edits') or [])}")
            if args.get("summary"):
                lines.append(f"  • خلاصه: {args.get('summary')}")
            for i,ed in enumerate((args.get("edits") or [])[:3]):
                lines.append(f"    [{i+1}] old: «{str(ed.get('old',''))[:60]}»")
                lines.append(f"        new: «{str(ed.get('new',''))[:60]}»")
        elif tool == "code_write":
            lines.append(f"  • فایل: {args.get('path')}")
            lines.append(f"  • حجم: {len(args.get('content',''))} نویسه")
            if args.get("summary"):
                lines.append(f"  • خلاصه: {args.get('summary')}")
        elif tool in ("post_save","category_save","item_save","coupon_save","toplist_save","flashdeal_save","event_save","plan_save","badge_save"):
            lines.append(f"  • شناسه: {args.get('id') or 'جدید'}")
            for kk,vv in args.items():
                if kk in ("id","image","images","cover"): continue
                if isinstance(vv,str) and len(vv)>80:
                    vv = vv[:80]+"…"
                lines.append(f"    - {kk}: {vv}")
        elif tool in ("post_delete","category_delete","business_save","item_delete","ad_delete","coupon_delete","toplist_delete","flashdeal_delete","event_delete","plan_delete","badge_delete"):
            lines.append(f"  • حذف #{args.get('id')}")
            # show what will be deleted
            table_map = {"post_delete":"posts","category_delete":"categories","item_delete":"items","ad_delete":"ads","coupon_delete":"coupons","toplist_delete":"toplists","flashdeal_delete":"flashdeals","event_delete":"cityevents","plan_delete":"plans","badge_delete":"badges"}
            tbl = table_map.get(tool)
            if tbl:
                cur = db._one(f"SELECT * FROM {tbl} WHERE id=?", (args.get("id"),))
                if cur:
                    lines.append(f"    نام/عنوان: {cur.get('title') or cur.get('name') or cur.get('code') or '—'}")
        elif tool == "bulk_approve":
            kind = args.get("kind")
            # count pending
            qmap = {"businesses":"SELECT COUNT(*) c FROM businesses WHERE status='pending'",
                    "reviews":"SELECT COUNT(*) c FROM reviews WHERE status='pending'",
                    "reports":"SELECT COUNT(*) c FROM reports WHERE status='open'",
                    "claims":"SELECT COUNT(*) c FROM claims WHERE status='pending'",
                    "edits":"SELECT COUNT(*) c FROM pending_edits WHERE status='pending'",
                    "subscriptions":"SELECT COUNT(*) c FROM subscriptions WHERE status='pending'",
                    "messages":"SELECT COUNT(*) c FROM inbox WHERE status='new'"}
            qq = qmap.get(kind)
            if qq:
                r = db._one(qq)
                lines.append(f"  • تعداد در انتظار: {r['c'] if r else 0}")
        elif tool == "backup_now":
            import shutil as _sh
            sz = 0
            try: sz = _sh.disk_usage(db.DATA_DIR).free//1024//1024
            except: pass
            lines.append(f"  • بکاپ DB → data/backups/ (آزاد: {sz}MB)")
        elif tool == "cache_clear":
            lines.append("  • حذف فایل‌های data/cache/")
        elif tool == "seo_check":
            lines.append("  • فقط خواندن — تغییری اعمال نمی‌شود")
        elif tool == "health_check":
            lines.append("  • فقط خواندن — تغییری اعمال نمی‌شود")

        elif tool in ("sys_info","db_tables","backup_list","version_info","file_read","file_list"):
            lines.append("  • فقط خواندن — تغییری اعمال نمی‌شود")
        elif tool in ("file_write","file_edit"):
            lines.append(f"  • فایل تبادل: {args.get('path')}")
        elif tool == "file_delete":
            lines.append(f"  • حذف فایل تبادل: {args.get('path')}")

        lines.append("")
        lines.append("📌 تأثیر روی سایت اصلی:")
        if tool in ("business_save","biz_moderate","bulk_approve"):
            lines.append("  • صفحهٔ کسب‌وکار /b/<slug> و فهرست /businesses")
        elif tool in ("item_save","item_delete"):
            lines.append("  • کاتالوگ کسب‌وکار و جست‌وجوی محصولات")
        elif tool in ("ad_save","ad_delete"):
            lines.append("  • بنرها در صفحهٔ اصلی و جایگاه‌های تبلیغاتی")
        elif tool in ("setting","page","appearance","cache_clear"):
            lines.append("  • تنظیمات عمومی سایت، هدر، فوتر، سئو")
        elif tool.startswith("code_"):
            lines.append("  • کد سایت — پس از اعمال، تست سلامت (healthz) و در صورت خطا بازگشت خودکار")
        elif tool in ("seo_check","health_check","backup_now"):
            lines.append("  • فقط گزارش — تغییری در سایت اصلی ایجاد نمی‌کند (بکاپ در data/backups)")
        else:
            lines.append("  • دادهٔ مربوطه در پنل و سایت اصلی")

        lines.append("")
        lines.append("⚠️ برای اعمال، «تایید» را بزنید. برای لغو، «لغو».")
        lines.append("برای توقف فوری و بازگشت: /stop")
        return "\n".join(lines)[:3500]
    except Exception as e:
        return f"📋 گزارش اقدام: {tool}\n{str(e)[:200]}\n\nبرای تایید: تایید / برای لغو: لغو"

def tool_snapshot(tool, args):
    """Capture current state for rollback — returns dict or None."""
    try:
        if tool == "setting":
            if "items" in args:
                snap = {}
                for it in args["items"]:
                    k = it.get("key")
                    snap[k] = db.get_settings().get(k)
                return {"type": "settings", "data": snap}
            else:
                k = args.get("key")
                return {"type": "setting", "key": k, "old": db.get_settings().get(k)}
        elif tool in ("business_save",):
            bid = args.get("id")
            if bid:
                cur = db._one("SELECT * FROM businesses WHERE id=?", (bid,))
                return {"type": "business", "id": bid, "old": dict(cur) if cur else None}
            else:
                return {"type": "business_new", "id": None}
        elif tool in ("ad_save",):
            aid = args.get("id")
            if aid:
                cur = db._one("SELECT * FROM ads WHERE id=?", (aid,))
                return {"type": "ad", "id": aid, "old": dict(cur) if cur else None}
            else:
                return {"type": "ad_new", "id": None}
        elif tool in ("post_save","category_save","item_save","coupon_save","toplist_save","flashdeal_save","event_save","plan_save","badge_save"):
            table_map = {"post_save":"posts","category_save":"categories","item_save":"items","coupon_save":"coupons","toplist_save":"toplists","flashdeal_save":"flashdeals","event_save":"cityevents","plan_save":"plans","badge_save":"badges"}
            tbl = table_map.get(tool)
            iid = args.get("id")
            if iid and tbl:
                cur = db._one(f"SELECT * FROM {tbl} WHERE id=?", (iid,))
                return {"type": tbl, "id": iid, "old": dict(cur) if cur else None}
            else:
                return {"type": f"{tbl}_new" if tbl else "new", "id": None}
        elif tool in ("post_delete","category_delete","item_delete","ad_delete","coupon_delete","toplist_delete","flashdeal_delete","event_delete","plan_delete","badge_delete"):
            table_map = {"post_delete":"posts","category_delete":"categories","item_delete":"items","ad_delete":"ads","coupon_delete":"coupons","toplist_delete":"toplists","flashdeal_delete":"flashdeals","event_delete":"cityevents","plan_delete":"plans","badge_delete":"badges"}
            tbl = table_map.get(tool)
            if tbl:
                cur = db._one(f"SELECT * FROM {tbl} WHERE id=?", (args.get("id"),))
                return {"type": f"{tbl}_delete", "id": args.get("id"), "old": dict(cur) if cur else None}
        elif tool.startswith("code_"):
            # code backup is handled by codeguard itself — snapshot is path
            return {"type": "code", "path": args.get("path"), "edits": args.get("edits")}
        elif tool == "bulk_approve":
            kind = args.get("kind")
            qmap = {"businesses":"SELECT id FROM businesses WHERE status='pending'",
                    "reviews":"SELECT id FROM reviews WHERE status='pending'",
                    "reports":"SELECT id FROM reports WHERE status='open'",
                    "claims":"SELECT id FROM claims WHERE status='pending'",
                    "edits":"SELECT id FROM pending_edits WHERE status='pending'",
                    "subscriptions":"SELECT id FROM subscriptions WHERE status='pending'",
                    "messages":"SELECT id FROM inbox WHERE status='new'"}
            qq = qmap.get(kind)
            ids=[]
            if qq:
                try: ids=[r["id"] for r in db._all(qq)]
                except: pass
            return {"type": f"bulk_{kind}", "ids": ids, "kind": kind}
        return {"type": "generic", "tool": tool, "args": args}
    except Exception:
        return None

def tool_rollback(snapshot):
    """Revert using snapshot — returns (ok, msg)."""
    try:
        if not snapshot:
            return False, "اسنپ‌شات موجود نیست"
        typ = snapshot.get("type")
        if typ == "setting":
            k = snapshot.get("key")
            old = snapshot.get("old")
            if old is None:
                # delete setting? set to empty?
                db.set_setting(k, "")
            else:
                db.set_setting(k, old)
            return True, f"تنظیم «{k}» به حالت قبل برگشت"
        elif typ == "settings":
            for k,v in (snapshot.get("data") or {}).items():
                db.set_setting(k, v if v is not None else "")
            return True, f"{len(snapshot.get('data') or {})} تنظیم به قبل برگشت"
        elif typ in ("business","ad","posts","categories","items","coupons","toplists","flashdeals","cityevents","plans","badges"):
            tbl = typ
            iid = snapshot.get("id")
            old = snapshot.get("old")
            if old:
                # restore old row
                cols = [c for c in old.keys() if c != "id"]
                vals = [old[c] for c in cols]
                sets = ", ".join(f"{c}=?" for c in cols)
                db._run(f"UPDATE {tbl} SET {sets} WHERE id=?", (*vals, iid))
                return True, f"{tbl} #{iid} به قبل برگشت"
            else:
                return False, "دادهٔ قبلی برای بازگشت نیست"
        elif typ.endswith("_new"):
            # newly created — delete it, need last inserted id from last-action
            # last-action file stores created id
            try:
                last = json.load(open(_last_action_path(), encoding="utf-8"))
                cid = last.get("created_id")
                tbl = typ.replace("_new","")
                if cid and tbl:
                    db._run(f"DELETE FROM {tbl} WHERE id=?", (cid,))
                    return True, f"{tbl} #{cid} (ایجادشده) حذف شد"
            except Exception:
                pass
            return False, "شناسهٔ ایجادشده برای حذف در دسترس نیست"
        elif typ.endswith("_delete"):
            tbl = typ.replace("_delete","")
            old = snapshot.get("old")
            if old:
                cols = [c for c in old.keys() if c != "id"]
                # for insert, need all cols
                all_cols = list(old.keys())
                vals = [old[c] for c in all_cols]
                placeholders = ", ".join("?" for _ in all_cols)
                colnames = ", ".join(all_cols)
                try:
                    db._run(f"INSERT OR REPLACE INTO {tbl} ({colnames}) VALUES ({placeholders})", vals)
                    return True, f"{tbl} #{snapshot.get('id')} بازیابی شد"
                except Exception as e:
                    return False, f"بازیابی {tbl} ناموفق: {e}"
            return False, "دادهٔ حذف‌شده برای بازیابی نیست"
        elif typ == "code":
            # code revert uses CODE module's revert
            path = snapshot.get("path")
            if path:
                ok, msg = CODE.execute("code_revert", {"path": path})
                return ok, msg
            return False, "مسیر کد برای بازگشت نیست"
        elif typ.startswith("bulk_"):
            kind = snapshot.get("kind")
            ids = snapshot.get("ids") or []
            # revert bulk approve: set back to pending/open/new
            cnt=0
            for iid in ids:
                try:
                    if kind=="businesses": db._run("UPDATE businesses SET status='pending' WHERE id=?", (iid,)); cnt+=1
                    elif kind=="reviews": db._run("UPDATE reviews SET status='pending' WHERE id=?", (iid,)); cnt+=1
                    elif kind=="reports": db._run("UPDATE reports SET status='open' WHERE id=?", (iid,)); cnt+=1
                    elif kind=="claims": db._run("UPDATE claims SET status='pending' WHERE id=?", (iid,)); cnt+=1
                    elif kind=="edits": db._run("UPDATE pending_edits SET status='pending' WHERE id=?", (iid,)); cnt+=1
                    elif kind=="subscriptions": db._run("UPDATE subscriptions SET status='pending' WHERE id=?", (iid,)); cnt+=1
                    elif kind=="messages": db._run("UPDATE inbox SET status='new' WHERE id=?", (iid,)); cnt+=1
                except: pass
            return True, f"{cnt} مورد {kind} به حالت قبل برگشت"
        return False, f"نوع بازگشت ناشناخته: {typ}"
    except Exception as e:
        return False, f"خطا در بازگشت: {e}"

def _save_rollback(snapshot):
    try:
        os.makedirs(os.path.dirname(_rollback_path()), exist_ok=True)
        with open(_rollback_path(), "w", encoding="utf-8") as f:
            json.dump({"ts": time.time(), "snapshot": snapshot}, f, ensure_ascii=False)
    except Exception:
        pass

def _save_last_action(tool, args, result_msg=""):
    try:
        os.makedirs(os.path.dirname(_last_action_path()), exist_ok=True)
        # try to extract created id from result_msg like "(#123)"
        import re
        m = re.search(r"#(\d+)", result_msg or "")
        cid = int(m.group(1)) if m else None
        with open(_last_action_path(), "w", encoding="utf-8") as f:
            json.dump({"ts": time.time(), "tool": tool, "args": args, "created_id": cid, "msg": result_msg}, f, ensure_ascii=False)
    except Exception:
        pass

def content_inventory():
    """Compact live listing of editable content so the model can ground its
    proposals (real ids, real current texts). Never raises; no secrets."""
    try:
        s = db.get_settings()
        txt = " · ".join(f"{k}={str(s.get(k) or '')[:60]}" for k in
                        ("tagline", "hero_title", "hero_cta", "footer_note"))
        cats = db._rows("SELECT id,slug,name,active,parent FROM categories "
                        "ORDER BY sort,id LIMIT 40")
        catline = " · ".join(f"#{r['id']} {r['name']}" + ("" if r["active"] else " (خاموش)")
                             for r in cats) or "—"
        posts = db._rows("SELECT id,title,status FROM posts ORDER BY id DESC LIMIT 10")
        postline = " · ".join(f"#{r['id']} {r['title']}" for r in posts) or "—"
        bizs = db._rows("SELECT id,name,status FROM businesses ORDER BY id DESC LIMIT 15")
        bizline = " · ".join(f"#{r['id']} {r['name']} ({r['status']})" for r in bizs) or "—"
        items = db._rows("SELECT COUNT(*) c FROM items")
        about = db.get_page("about")
        rules = db.get_page("rules")
        out = ("محتوای متن: " + (txt or "—") +
               f"\nدسته‌ها (تا ۴۰): {catline}" +
               f"\nمقاله‌ها (۱۰ اخیر): {postline}" +
               f"\nکسب‌وکارها (۱۵ اخیر): {bizline}" +
               f"\nمحصولات: {items[0]['c'] if items else '?'}" +
               f"\nصفحات: about «{about.get('title') or ''}» ({len(about.get('body') or '')} نویسه)" +
               f" · rules «{rules.get('title') or ''}» ({len(rules.get('body') or '')} نویسه)")
        out += ("\nخواندن جزئیات هر بخش پنل: panel_read {section} — "
                "فهرست کامل بخش‌ها: panel_sections (اجرای فوری، بدون تأیید).")
        # v240: the rest of the panel's editable surfaces
        try:
            coupons = db._rows("SELECT id,code,percent,active FROM coupons ORDER BY id DESC LIMIT 8")
            out += "\nکدهای تخفیف: " + (" · ".join(
                f"#{r['id']} {r['code']} {r['percent']}٪" + ("" if r["active"] else " (خاموش)")
                for r in coupons) or "—")
        except Exception:
            pass
        try:
            lists = db._rows("SELECT id,title,kind,active FROM toplists ORDER BY id LIMIT 10")
            out += "\nلیست‌ها: " + (" · ".join(
                f"#{r['id']} {r['title']} ({r['kind']})" for r in lists) or "—")
        except Exception:
            pass
        try:
            deals = db._rows("SELECT id,title,percent FROM flashdeals ORDER BY id DESC LIMIT 6")
            out += "\nپیشنهادها: " + (" · ".join(
                f"#{r['id']} {r['title']} {r['percent']}٪" for r in deals) or "—")
        except Exception:
            pass
        try:
            evs = db._rows("SELECT id,title,date FROM cityevents ORDER BY id DESC LIMIT 6")
            out += "\nرویدادها: " + (" · ".join(
                f"#{r['id']} {r['title']} {r['date']}" for r in evs) or "—")
        except Exception:
            pass
        try:
            ads = db._rows("SELECT id,title,slot,active FROM ads ORDER BY id DESC LIMIT 6")
            out += "\nبنرها: " + (" · ".join(
                f"#{r['id']} {r['title']} [{r['slot']}]" for r in ads) or "—")
        except Exception:
            pass
        try:
            plans = db._rows("SELECT id,slug,name,price,active FROM plans ORDER BY sort,id")
            out += "\nپلن‌ها: " + (" · ".join(
                f"#{r['id']} {r['name']} {r['price']}ت" for r in plans) or "—")
        except Exception:
            pass
        try:
            badges = db._rows("SELECT id,slug,name FROM badges WHERE active=1 ORDER BY sort LIMIT 10")
            out += "\nنشان‌ها: " + (" · ".join(f"#{r['id']} {r['name']}" for r in badges) or "—")
        except Exception:
            pass
        try:
            clm = db._rows("SELECT c.id, b.name FROM claims c JOIN businesses b ON b.id=c.biz_id "
                           "WHERE c.status='pending' ORDER BY c.id DESC LIMIT 5")
            out += "\nتصاحب در انتظار: " + (" · ".join(
                f"#{r['id']} {r['name']}" for r in clm) or "—")
        except Exception:
            pass
        try:
            tix = db._rows("SELECT id,subject FROM tickets WHERE status<>'closed' ORDER BY id DESC LIMIT 5")
            out += "\nتیکت‌های باز: " + (" · ".join(
                f"#{r['id']} {(r['subject'] or '')[:30]}" for r in tix) or "—")
        except Exception:
            pass
        img = image_last()
        out += ("\nآخرین عکس ارسالی مدیر: " + img + " (برای استفاده: image=\"__last__\")"
                if img else "\nعکسی از مدیر در دسترس نیست (برای عکس، خودت در بات عکس بفرست)")
        try:
            out += "\n" + CODE.code_status_text()[:400]
        except Exception:
            pass
        return out
    except Exception:
        return "محتوا: خوانده نشد"
