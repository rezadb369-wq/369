# -*- coding: utf-8 -*-
"""v318 — OpenClaw-compatible slash surface for the owner-only Bale admin bot.

The live BALE agent that only greets is OpenClaw on the VPS (it already owns
getUpdates). These commands also live on the dastgir admin bot so the same
muscle-memory works here, mapped onto real site tools (panel, files, exec,
brains). No second poller. The agent BALE token is never stored in this tree.
"""
import os
import time

# OpenClaw command names the owner listed, plus the two dastgir-specific ones.
# Implemented ones return a real answer; the rest point at the equivalent
# dastgir path so the bot never goes silent after a slash.
_OC_HELP = (
    "📋 دستورهای ایجنت دست‌گیر (سازگار با OpenClaw) — v318\n"
    "\n"
    "گفتگو\n"
    "• /help  /commands  — همین فهرست\n"
    "• /new  /reset  — پاک‌کردن حافظهٔ همین گفتگو\n"
    "• /stop  — توقف اقدام در صف\n"
    "• /whoami  /id  — هویت این چت\n"
    "\n"
    "وضعیت و مغز\n"
    "• /status  — وضعیت سایت (همان «وضعیت»)\n"
    "• /diagnostics  /diagnose  — تشخیص زنده (همان «تشخیص»)\n"
    "• /config  — مغز فعال (بدون کلید)\n"
    "• /model  /models  — مدل بای‌نارا (پیش‌فرض ling-3.0-flash-sante-free)\n"
    "• /usage  — مصرف هوش امروز\n"
    "• /tools  — ابزارهای داخلی ایجنت\n"
    "• /version  — پین نسخه\n"
    "\n"
    "سایت دست‌گیر\n"
    "• /dastgir_panel_access  — نشانی پنل مدیر + کنسول ایجنت\n"
    "• /dastgir_site_data  — تصویر زندهٔ تنظیمات (بدون راز)\n"
    "• /panel  — خواندن بخش‌های پنل («پنل سفارش‌ها»)\n"
    "\n"
    "فایل و اجرا (مالک)\n"
    "• /exec <فرمان>  /bash  /sh  — ترمینال (همان sh)\n"
    "• /read <مسیر>  — خواندن فایل سایت\n"
    "• /ls [مسیر]  — فهرست فایل\n"
    "• /elevated  — وضعیت دسترسی آزاد\n"
    "\n"
    "بقیهٔ دستورهای OpenClaw (/skill /session /subagents /think /verbose "
    "/context /export-session /acp /debug /steer /tell /compact /dock "
    "/channels /gateway /pairing /allowlist /browser /canvas /nodes /phone "
    "/voice /tts /add-image /approve /deny) از مسیر چت آزاد همین ایجنت "
    "انجام می‌شوند — بنویس چه می‌خواهی.\n"
    "\n"
    "مغز پیش‌فرض v318: ling-3.0-flash-sante-free روی بای‌نارا. "
    "سوئیچ خودکار مغز ممنوع است."
)


def _norm_cmd(text):
    t = (text or "").strip()
    if not t.startswith("/"):
        return "", ""
    # Telegram/BALE: /help@BotName
    head, _, rest = t.partition(" ")
    head = head.split("@", 1)[0].strip()
    return head.lower(), rest.strip()


def _clear_memory():
    try:
        import adminbot as A
        p = A.memory_path()
        if os.path.isfile(p):
            os.remove(p)
        return True
    except Exception:
        return False


def try_slash(text):
    """Return a reply string if this is an OpenClaw-style slash we handle
    here, else None so adminbot's existing Persian dispatch runs."""
    cmd, rest = _norm_cmd(text)
    if not cmd:
        return None

    # Already handled (Persian + English) in adminbot.handle_text — leave them.
    if cmd in ("/help", "/start", "/status", "/stop", "/panel", "/key",
               "/diagnose", "/restart", "/backup", "/log", "/db", "/sys",
               "/sec", "/spam", "/traffic", "/errors", "/report", "/cast",
               "/who", "/watch", "/unqueue", "/prices", "/fresh", "/queue",
               "/bizqueue", "/reject"):
        if cmd == "/help" or cmd == "/start":
            # Enrich the existing help with the OC list.
            return None
        return None

    if cmd in ("/commands", "/command", "/cmds"):
        return _OC_HELP

    if cmd == "/tools":
        try:
            import adminbot_content as CT
            import views_agent_full as V
            lines = ["🛠 ابزارهای داخلی ایجنت (%d):" % len(CT.TOOLS)]
            for t in CT.TOOLS:
                lines.append("• %s — %s" % (t, V.TOOL_FA.get(t, t)))
            return "\n".join(lines)[:3500]
        except Exception as e:
            return "فهرست ابزار خوانده نشد: %s" % type(e).__name__

    if cmd in ("/whoami", "/id", "/username"):
        return ("👤 ایجنت دست‌گیر — مالک سایت daastgir.ir\n"
                "نسخه: v318 · مغز پیش‌فرض: ling-3.0-flash-sante-free\n"
                "هویت چت از خودِ پیام بله خوانده می‌شود. "
                "توکن ایجنت بله در بستهٔ سایت ذخیره نمی‌شود.")

    if cmd in ("/new", "/reset"):
        ok = _clear_memory()
        return ("🧹 حافظهٔ این گفتگو پاک شد." if ok
                else "حافظه پاک نشد (فایل در دسترس نبود) — گفتگوی تازه را شروع کن.")

    if cmd in ("/models",):
        try:
            import assistant as AI
            rows = ["🧠 مدل‌های بای‌نارا — پیش‌فرض [0] = %s" % AI.BYNARA_MODELS[0]]
            for i, m in enumerate(AI.BYNARA_MODELS, 1):
                mark = " ← فعال‌شدنی با /مدل بای‌نارا %d" % i if i <= 8 else ""
                rows.append("%d. %s%s" % (i, m, mark))
            rows.append("سوئیچ: /مدل بای‌نارا <n یا شناسه> — تست زنده، بدون یدک.")
            return "\n".join(rows)[:3500]
        except Exception as e:
            return "فهرست مدل خوانده نشد: %s" % type(e).__name__

    if cmd == "/model" and not rest:
        try:
            import assistant as AI
            c = AI.config()
            sc = AI.site_config()
            return ("🧠 مغز مدیر: %s / %s (کلید: %s)\n"
                    "🌐 هوش سایت: %s (کلید: %s)\n"
                    "پیش‌فرض بسته: ling-3.0-flash-sante-free\n"
                    "تغییر: /مغز بای‌نارا  ·  /مدل بای‌نارا 2"
                    % (c.get("brain"), c.get("model"),
                       "هست" if c.get("api_key") else "نیست",
                       sc.get("model"),
                       "هست" if sc.get("api_key") else "نیست"))
        except Exception as e:
            return "وضعیت مدل خوانده نشد: %s" % type(e).__name__

    if cmd == "/config":
        try:
            import assistant as AI
            p = AI.public_config()
            s = AI.site_public_config()
            return ("⚙️ پیکربندی (بدون کلید)\n"
                    "مدیر: brain=%s model=%s has_key=%s timeout=%s\n"
                    "سایت: model=%s has_key=%s\n"
                    "سوئیچ خودکار مغز: خاموش (دستور مدیر)."
                    % (p.get("brain"), p.get("model"), p.get("has_key"),
                       p.get("timeout"), s.get("model"), s.get("has_key")))
        except Exception as e:
            return "config خوانده نشد: %s" % type(e).__name__

    if cmd == "/usage":
        try:
            import assistant as AI
            st = AI.stats(7)
            t = st.get("today") or {}
            return ("📊 مصرف ۷روز / امروز\n"
                    "امروز: %s پیام · %s تماس مدل · %s توکن\n"
                    "هفته: %s پیام"
                    % (t.get("n"), t.get("llm"), t.get("tokens"),
                       (st.get("week") or {}).get("n")))
        except Exception as e:
            return "آمار خوانده نشد: %s" % type(e).__name__

    if cmd in ("/diagnostics",):
        return None  # fall through to do_diagnose via /diagnose alias below

    if cmd in ("/version", "/ver"):
        try:
            import adminbot as A
            root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            ver = open(os.path.join(root, "VERSION.txt"), encoding="utf-8").read().strip()
            return "🏷️ VERSION.txt=%s  DIAG_LATEST=%s  (باید یکی باشند)" % (
                ver, A.DIAG_LATEST)
        except Exception as e:
            return "نسخه خوانده نشد: %s" % type(e).__name__

    if cmd == "/dastgir_panel_access":
        try:
            import db
            s = db.get_settings()
            base = (s.get("site_url") or "https://daastgir.ir").rstrip("/")
            return ("🔑 دسترسی پنل دست‌گیر\n"
                    "• کنسول ایجنت (فرمان): %s/agent\n"
                    "• پنل مدیر (زیر ایجنت): %s/panel\n"
                    "• نسخهٔ پنلی ایجنت: %s/panel/agent\n"
                    "ورود: کوکی مدیر / ایمیل مالک / کلید یک‌بارمصرف از بات بله.\n"
                    "از v318 پنل مدیر زیر دست ایجنت است — ایجنت فرمان می‌دهد."
                    % (base, base, base))
        except Exception:
            return ("🔑 /agent = کنسول ایجنت · /panel = پنل مدیر (زیر ایجنت)\n"
                    "ورود با نشست مدیر یا کلید بله.")

    if cmd == "/dastgir_site_data":
        try:
            import adminbot_content as CT
            snap = CT.content_inventory()
            return "🗂 دادهٔ زندهٔ سایت (بدون راز):\n" + str(snap)[:2800]
        except Exception as e:
            return "تصویر سایت خوانده نشد: %s" % type(e).__name__

    if cmd in ("/exec", "/bash", "/shell"):
        # Fall through: adminbot already has `sh <cmd>`. Rewrite so that path
        # runs — caller sees None and we don't duplicate the sandbox.
        return None

    if cmd in ("/read", "/cat"):
        if not rest:
            return "مسیر بده: /read server/assistant.py"
        try:
            import adminbot_content as CT
            ok, msg = CT.tool_execute("file_read", {"path": rest})
            return str(msg)[:3500]
        except Exception as e:
            return "خواندن ناموفق: %s" % type(e).__name__

    if cmd in ("/ls", "/dir"):
        try:
            import adminbot_content as CT
            ok, msg = CT.tool_execute("file_list", {"path": rest})
            return str(msg)[:3500]
        except Exception as e:
            return "فهرست ناموفق: %s" % type(e).__name__

    if cmd == "/elevated":
        return ("🔓 دسترسی آزاد ایجنت v318 (مالک):\n"
                "• خواندن هر فایل متنی زیر ریشهٔ سایت (رازها قفل‌اند)\n"
                "• نوشتن صندوق تبادل + فایل‌های غیر زیرساختی\n"
                "• code_read/code_edit/code_write برای کد (صف کدگارد)\n"
                "• shell_exec با تأیید «بله» از چت هوش؛ مستقیم از کنسول / ش\n"
                "• پنل مدیر زیر دست همین ایجنت است\n"
                "سوئیچ خودکار مغز: خاموش.")

    if cmd in ("/skill", "/skills"):
        return ("مهارت‌های دست‌گیر روی سرور در deploy/openclaw/skills/ "
                "نصب می‌شوند (dastgir_panel_access و dastgir_site_data). "
                "اگر OpenClaw روی VPS باشد، update.sh آن‌ها را به workspace "
                "می‌برد. از همین چت هم /dastgir_panel_access و "
                "/dastgir_site_data کار می‌کنند.")

    # Remaining OpenClaw names: never silent.
    if cmd.startswith("/") and cmd[1:].replace("-", "").replace("_", "").isalnum():
        known = (
            "subagents", "agents", "session", "sessions", "acp", "debug",
            "export-session", "export_session", "think", "verbose", "quiet",
            "context", "steer", "tell", "compact", "dock", "channels",
            "gateway", "pairing", "allowlist", "browser", "canvas", "nodes",
            "phone", "voice", "tts", "add-image", "add_image", "approve",
            "deny", "restart", "kill", "unfocus", "focus", "activation",
            "reason", "tts", "image", "voice", "subagent", "spawn",
            "send", "export", "import", "dock", "nodes", "gateway",
        )
        bare = cmd[1:].replace("_", "-")
        if bare in known or cmd[1:] in known:
            return ("این دستور OpenClaw در ایجنت داخلی دست‌گیر از مسیر چت آزاد "
                    "انجام می‌شود — همان کار را فارسی بنویس "
                    "(مثلاً «فایل X را بخوان»، «وضعیت»، «تشخیص»).\n"
                    "فهرست: /commands")

    return None


def help_extra():
    """Appended to the existing «راهنما» so the owner sees both surfaces."""
    return ("\n\n—— ایجنت v318 (سازگار با OpenClaw) ——\n"
            "/commands · /tools · /whoami · /new · /models · /config · "
            "/dastgir_panel_access · /dastgir_site_data · /elevated · /read")
