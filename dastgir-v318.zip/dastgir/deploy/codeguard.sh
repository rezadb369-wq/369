#!/usr/bin/env bash
# v241 «کدگارد» — root-side applier for the admin AI's code edits.
# Installed by deploy/update.sh (and the v241 delivery command) as
# /etc/cron.d/dastgir-codeguard (every minute).
#
# Pipeline for data/code-jobs/*.json:
#   backup → apply (exact-match edits, atomic) → py_compile → sw.js bump
#   → systemctl restart → healthz → on failure: auto-rollback + restart
#   → the owner gets the outcome in the Bale admin chat (tools/bale_notify).
# Also drains the legacy data/adminbot-cmd queue (backup / restart / secharden).
#
# Testable: DASTGIR_APP / DASTGIR_HEALTHZ / DASTGIR_SYSTEMCTL /
# DASTGIR_CURL / DASTGIR_NOTIFY / DASTGIR_CODEGUARD_LOG override everything.
set -u
APP="${DASTGIR_APP:-/opt/dastgir}"
LOG="${DASTGIR_CODEGUARD_LOG:-/var/log/dastgir-codeguard.log}"
HEALTHZ="${DASTGIR_HEALTHZ:-http://127.0.0.1:8080/healthz}"
SYSTEMCTL="${DASTGIR_SYSTEMCTL:-systemctl}"
CURL="${DASTGIR_CURL:-curl}"
NOTIFY="${DASTGIR_NOTIFY:-python3 ${APP}/tools/bale_notify.py}"
LOCK="${APP}/data/codeguard.lock"

mkdir -p "$APP/data/code-jobs" "$APP/data/code-backups" "$(dirname "$LOG")" 2>/dev/null
ts(){ date '+%F %T'; }
log(){ echo "$(ts) $*" >>"$LOG"; }
# v244: deployment receipts — the app (and the model) read what REALLY happened
receipt(){ echo "$(ts) $*" >>"$APP/data/code-deploys.log"
  tail -n 60 "$APP/data/code-deploys.log" >"$APP/data/code-deploys.log.tmp" 2>/dev/null \
    && mv "$APP/data/code-deploys.log.tmp" "$APP/data/code-deploys.log"; }
notify(){ [ -n "$NOTIFY" ] && $NOTIFY "$1" >/dev/null 2>&1 || true; }

# single instance per minute
mkdir "$LOCK" 2>/dev/null || exit 0
trap 'rmdir "$LOCK" 2>/dev/null' EXIT

healthy(){ "$CURL" -fsS --max-time 5 "$HEALTHZ" >/dev/null 2>&1; }

# ---------- 1) legacy privileged queue (backup / restart) ----------
shopt -s nullglob
for f in "$APP/data/adminbot-cmd"/*.json; do
  mv "$f" "$f.busy" 2>/dev/null || continue
  cmd=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1])).get("cmd",""))' "$f.busy" 2>/dev/null || true)
  case "$cmd" in
    backup) if [ -f "$APP/tools/backup.py" ]; then
              python3 "$APP/tools/backup.py" --dir /var/backups/dastgir >>"$LOG" 2>&1 || true
            fi; log "queue: backup done" ;;
    restart) "$SYSTEMCTL" restart bazarche >/dev/null 2>&1; log "queue: restart done" ;;
    secharden)
      # v287 (دستور مدیر): سخت‌سازی واقعی SSH — fail2ban نصب/فعال، jail سخت،
      # مسدودسازی فوری مهاجمان فعلی. رسید کامل در data/sec-harden-result.txt
      # می‌نشیند و بات («امنیت») همان را با عدد و دلیل گزارش می‌کند.
      R="$APP/data/sec-harden-result.txt"
      {
        echo "=== سخت‌سازی SSH — $(ts) ==="
        if ! command -v fail2ban-client >/dev/null 2>&1; then
          echo "fail2ban: نصب نیست — شروع نصب..."
          DEBIAN_FRONTEND=noninteractive apt-get update -qq >/dev/null 2>&1 || true
          DEBIAN_FRONTEND=noninteractive apt-get install -y -qq fail2ban >/dev/null 2>&1 || true
        fi
        if command -v fail2ban-client >/dev/null 2>&1; then
          echo "fail2ban: نصب است — $(fail2ban-client --version 2>/dev/null | head -n1)"
        else
          echo "fail2ban: ❌ نصب ناموفق (شبکه/مخزن را چک کن)"
        fi
        mkdir -p /etc/fail2ban/jail.d 2>/dev/null
        cat >/etc/fail2ban/jail.d/dastgir-sshd.local <<'F2BJAIL'
# v287 dastgir — jail سخت برای sshd (بات/مدیر می‌تواند دستی تعدیل کند)
[sshd]
enabled  = true
port     = ssh
maxretry = 3
findtime = 3600
bantime  = 86400
backend  = auto
F2BJAIL
        echo "jail: /etc/fail2ban/jail.d/dastgir-sshd.local نوشته شد (۳ تلاش در ۱ ساعت ⇒ ۲۴ ساعت مسدود)"
        systemctl enable fail2ban >/dev/null 2>&1 || true
        systemctl restart fail2ban >/dev/null 2>&1 || true
        sleep 2
        if fail2ban-client status sshd >/dev/null 2>&1; then
          echo "fail2ban: jail sshd فعال ✅"
          fail2ban-client status sshd 2>/dev/null | grep -E "Currently failed|Total failed|Currently banned|Total banned" || true
        else
          echo "fail2ban: ❌ jail بالا نیامد — journalctl -u fail2ban را ببین"
        fi
        ATTACKERS=$(journalctl -u ssh -u sshd --since "24 hours ago" --no-pager -q 2>/dev/null \
          | grep -F "Failed" | grep -oE "from [0-9]{1,3}(\.[0-9]{1,3}){3}" | awk '{print $2}' \
          | sort | uniq -c | sort -rn | head -n 15 | awk '{print $2}' || true)
        BANNED=0
        for ip in $ATTACKERS; do
          case "$ip" in
            127.*|10.*|192.168.*|172.1[6-9].*|172.2[0-9].*|172.3[01].*) continue ;;
          esac
          if fail2ban-client set sshd banip "$ip" >/dev/null 2>&1; then
            BANNED=$((BANNED+1))
            echo "مسدود شد: $ip"
          fi
        done
        echo "مسدودسازی فوری: $BANNED IP از مهاجمان ۲۴ ساعت اخیر"
        F24=$(journalctl -u ssh -u sshd --since "24 hours ago" --no-pager -q 2>/dev/null | grep -cF "Failed" || true)
        echo "تلاش ناموفق ۲۴ ساعت (لحظهٔ اجرا): $F24"
        echo "لایهٔ ۲ و ۳ (کلید SSH / پورت) دستی است — راهنما: deploy/SSH-HARDENING-fa.md"
      } >"$R" 2>&1
      tail -n 8 "$R" 2>/dev/null | while IFS= read -r ln; do log "secharden: $ln"; done
      notify "🛡 سخت‌سازی SSH اجرا شد — رسید: data/sec-harden-result.txt · برای نتیجه «امنیت» را به بات بفرست"
      log "queue: secharden done" ;;
    *) log "queue: unknown cmd '$cmd' skipped" ;;
  esac
  rm -f "$f.busy"
done

# ---------- 2) code jobs ----------
JOBS=("$APP/data/code-jobs"/*.json)
[ ${#JOBS[@]} -eq 0 ] && exit 0

python3 - "$APP" "${JOBS[@]}" <<'PYEOF' >>"$LOG" 2>&1
# v241 applier — self-contained on purpose (must run even if app code is
# mid-breakage). Deny-list kept in sync with server/adminbot_code.py.
import json, os, py_compile, re, shutil, sys, tempfile, time

APP = sys.argv[1]
ROOT = os.path.realpath(APP)
DENY_PREFIXES = ("data/", "deploy/", "tools/", "docs/superpowers/",
                 "site/assets/img/uploads/", "site/assets/chat-files/",
                 "backups/", ".git/")
DENY_FILES = {"VERSION.txt", "site/sw.js", "server/adminbot.py",
              "server/adminbot_content.py", "server/adminbot_code.py",
              "server/assistant.py", "server/bale.py"}
TEXT_EXT = (".py", ".html", ".js", ".css", ".md", ".json", ".txt", ".svg",
            ".webmanifest", ".xml", ".yml", ".yaml", ".toml", ".cfg", ".ini",
            ".conf", ".map", ".csv")
RX = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_./\-]{0,200}$")

def norm(p):
    p = str(p or "").strip().strip("/")
    if not p or not RX.match(p) or p.endswith("/") or ".." in p or "__pycache__" in p:
        return None
    low = p.lower()
    if any(low == d.rstrip("/") or low.startswith(d) for d in DENY_PREFIXES):
        return None
    if p in DENY_FILES:
        return None
    real = os.path.realpath(os.path.join(ROOT, p))
    if not real.startswith(ROOT + os.sep):
        return None
    return p

def texty(p):
    return os.path.splitext(p)[1].lower() in TEXT_EXT

BK = os.path.join(ROOT, "data", "code-backups")
def backup(rel):
    stamp = time.strftime("%Y%m%d-%H%M%S") + f"-{os.getpid()}"
    dst_dir = os.path.join(BK, stamp)
    os.makedirs(dst_dir, exist_ok=True)
    dst = os.path.join(dst_dir, rel.replace("/", "__"))
    src = os.path.join(ROOT, rel)
    existed = os.path.isfile(src)
    if existed:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
    idx_path = os.path.join(BK, "index.json")
    try:
        idx = json.load(open(idx_path, encoding="utf-8"))
        assert isinstance(idx, list)
    except Exception:
        idx = []
    idx.append({"ts": int(time.time()), "path": rel, "file": os.path.relpath(dst, BK),
                "existed": existed})
    json.dump(idx[-400:], open(idx_path, "w", encoding="utf-8"), ensure_ascii=False)
    return dst, existed

def atomic_write(rel, content):
    dst = os.path.join(ROOT, rel)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(dst), prefix=".cg-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
        if rel.endswith(".py"):
            py_compile.compile(tmp, cfile=tmp + "c", doraise=True)
            os.remove(tmp + "c")
        os.replace(tmp, dst)
    except BaseException:
        for junk in (tmp, tmp + "c"):
            try:
                os.remove(junk)
            except OSError:
                pass
        raise

def bump_sw():
    """site/* change → patch-bump the PWA cache version (sw.js is locked
    from the AI; only this guard touches it)."""
    sw = os.path.join(ROOT, "site", "sw.js")
    try:
        s = open(sw, encoding="utf-8").read()
        m = re.search(r"(bazarche-v\d+)(\.(\d+))?'", s)
        if not m:
            return
        new = f"{m.group(1)}.{int(m.group(3) or 0) + 1}'"
        s2 = s[:m.start()] + new + s[m.end():]
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(sw), prefix=".cg-")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(s2)
        os.replace(tmp, sw)
    except OSError:
        pass

applied, failed, touched_site = [], [], False
for job_path in sys.argv[2:]:
    try:
        job = json.load(open(job_path, encoding="utf-8"))
    except Exception as e:
        print("skip unreadable job", job_path, e); failed.append(job_path); continue
    kind = job.get("kind")
    if kind == "restart":
        print("restart job inside code-jobs: handled by caller"); continue
    if kind == "ai_key":
        prov, key = job.get("provider"), str(job.get("key") or "")
        base, model = "", ""
        if prov in ("gemini", "groq", "astra", "muse", "openrouter", "glm",
                    "bynara"):
            base, model = {
                "gemini": ("https://generativelanguage.googleapis.com/v1beta/openai",
                           "gemini-2.5-flash-lite"),
                "groq": ("https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
                "astra": ("https://api.openai.com/v1", "gpt-6-astra"),
                # v259 (دستور مدیر: مغز Claude): AvalAI gateway + Claude Sonnet.
                "muse": ("https://api.avalai.ir/v1", "claude-sonnet-5"),
                # v262 (دستور مدیر: کلید رایگان = یدک خودکار).
                "openrouter": ("https://openrouter.ai/api/v1",
                               "nvidia/nemotron-3-ultra-550b-a55b:free"),
                # v292 رفع باگ: glm در این دیکشنری نبود و base خالی می‌ماند،
                # پس گیت زیر آن را «invalid shape» می‌زد و هر کلید GLM (هرچند
                # سالم) رد می‌شد — همین پیام «بخشی از تغییرات اعمال نشد» را
                # برای مدیر می‌فرستاد. مغز پنجم روی AvalAI است.
                "glm": ("https://api.avalai.ir/v1", "glm-5.3-flash"),
                # v317 (دستور مدیر: کلید byNara به همهٔ قسمت‌ها): مغز ششم —
                # روتر byNara؛ پیش‌فرض ling-3.0-flash-sante-free (v318).
                "bynara": ("https://router.bynara.id/v1", "ling-3.0-flash-sante-free"),
            }[prov]
        elif prov in ("openai", "site"):   # v243 / v269: base+model از job
            base = str(job.get("base") or "").rstrip("/")
            model = str(job.get("model") or "")
            if prov == "site":
                # v269 (دستور مدیر: هوش سایت جدا): پیش‌فرض‌های اسلات سایت.
                base = base or "https://api.avalai.ir/v1"
                model = model or "glm-5.3-flash"
            if not re.fullmatch(r"https://[A-Za-z0-9.\-]+(?:/[A-Za-z0-9._\-]*){0,3}/?",
                                base) or not re.fullmatch(r"[A-Za-z0-9._\-/:]{1,80}", model):
                print("ai_key: invalid base/model"); failed.append("ai_key"); continue
        # v292: دو شرط به‌هم‌چسبیده بود و «نبودِ base» هم پیام «invalid shape»
        # می‌گرفت (گمراه‌کننده). حالا جدا و شفاف است.
        if not base:
            print("ai_key: missing base for", prov); failed.append("ai_key"); continue
        if not re.fullmatch(
                r"AIza[A-Za-z0-9_\-]{30,}|gsk_[A-Za-z0-9]{30,50}"
                r"|sk-[A-Za-z0-9_\-]{20,}|aa-[A-Za-z0-9_\-]{20,120}"
                r"|[A-Za-z0-9_\-]{24,120}", key):
            print("ai_key: invalid shape"); failed.append("ai_key"); continue
        envf = os.environ.get("DASTGIR_SECRETS", "/etc/dastgir-secrets.env")
        try:
            lines = open(envf, encoding="utf-8").read().splitlines() \
                if os.path.exists(envf) else []
        except OSError:
            lines = []
        if prov == "muse":
            # v263: کلید کلاد در اسلات مغز فعال می‌نشیند؛ شکاف‌های قدیمی
            # و بقیهٔ خط‌ها دست‌نخورده می‌مانند (خواندن در لحظه از اسلات‌هاست).
            slot = str(job.get("slot") or "sonnet").strip().lower()
            if slot not in ("opus", "sonnet", "haiku"):
                print("ai_key: bad muse slot"); failed.append("ai_key"); continue
            envk = "AI_BRAIN_" + slot.upper() + "_KEY"
            out = [ln for ln in lines if not ln.startswith(envk + "=")]
            out.append(envk + "=" + key)
            with open(envf, "w", encoding="utf-8") as f:
                f.write("\n".join(out) + "\n")
            os.chmod(envf, 0o600)
            print("ai_key: installed muse key into", slot)
            applied.append("ai_key:muse-" + slot)
            continue
        if prov == "openrouter":
            # v263→v265: کلید اوپن‌روتر در اسلات خودش می‌نشیند (مغز چهارم)؛
            # بقیهٔ خط‌ها دست‌نخورده می‌مانند.
            out = [ln for ln in lines if not ln.startswith("AI_BRAIN_OR_KEY=")]
            out.append("AI_BRAIN_OR_KEY=" + key)
            with open(envf, "w", encoding="utf-8") as f:
                f.write("\n".join(out) + "\n")
            os.chmod(envf, 0o600)
            print("ai_key: installed openrouter key")
            applied.append("ai_key:openrouter-key")
            continue
        if prov == "glm":
            # v273 (دستور مدیر: کیرا کلا حذف شد): کلید GLM مغز پنجم در
            # اسلات اختصاصی خودش می‌نشیند؛ اسلات قدیمی کیرا هم پاک می‌شود.
            out = [ln for ln in lines if not ln.startswith(
                ("AI_BRAIN_GLM_KEY=", "AI_BRAIN_KIRA_KEY="))]
            out.append("AI_BRAIN_GLM_KEY=" + key)
            with open(envf, "w", encoding="utf-8") as f:
                f.write("\n".join(out) + "\n")
            os.chmod(envf, 0o600)
            print("ai_key: installed glm key")
            applied.append("ai_key:glm-key")
            continue
        if prov == "bynara":
            # v317 (دستور مدیر: کلید byNara به همهٔ قسمت‌ها): کلید مغز ششم
            # در اسلات اختصاصی AI_BRAIN_BYNARA_KEY می‌نشیند؛ هوش عمومی سایت
            # هم (assistant.site_config) بدون کلید اختصاصی، همین کلید را
            # می‌خواند — یعنی با همین یک خط، سایت + ایجنت + بات روشن‌اند.
            out = [ln for ln in lines if not ln.startswith(
                ("AI_BRAIN_BYNARA_KEY=",))]
            out.append("AI_BRAIN_BYNARA_KEY=" + key)
            with open(envf, "w", encoding="utf-8") as f:
                f.write("\n".join(out) + "\n")
            os.chmod(envf, 0o600)
            print("ai_key: installed bynara key")
            applied.append("ai_key:bynara-key")
            continue
        if prov == "site":
            # v269 (دستور مدیر: هوش سایت کاملاً جدا از محیط مدیر):
            # هوش عمومی سایت در اسلات مستقل AI_SITE_* می‌نشیند؛
            # خط‌های AI_BRAIN_* (مغزهای مدیر) هرگز دست نمی‌خورند.
            out = [ln for ln in lines if not ln.startswith(
                ("AI_SITE_BASE_URL=", "AI_SITE_API_KEY=", "AI_SITE_MODEL="))]
            out += ["AI_SITE_BASE_URL=" + base,
                    "AI_SITE_API_KEY=" + key,
                    "AI_SITE_MODEL=" + model]
            with open(envf, "w", encoding="utf-8") as f:
                f.write("\n".join(out) + "\n")
            os.chmod(envf, 0o600)
            print("ai_key: installed site key")
            applied.append("ai_key:site")
            continue
        out = [ln for ln in lines if not ln.startswith(
            ("AI_BASE_URL=", "AI_API_KEY=", "AI_MODEL=",
             "AI_FALLBACK_BASE_URL=", "AI_FALLBACK_API_KEY=", "AI_FALLBACK_MODEL="))]
        # v251 (دستور مدیر: «کلا جایگزین بشه و قبلی حذف»): دیگر مغز قبلی به‌عنوان
        # یدکی نگه داشته نمی‌شود؛ هر AI_FALLBACK_* قدیمی هم کامل پاک می‌شود.
        if prov in ("astra", "openai", "muse"):
            out = [ln for ln in out if not ln.startswith("AI_TIMEOUT=")]
            out.append("AI_TIMEOUT=40")   # deep-reasoning models think longer
            # v259: Claude via /کلید also gets the smart model for the admin
            # agent (Opus for complex/code work, Sonnet for the user panel).
            if prov == "muse":
                out = [ln for ln in out if not ln.startswith("AI_MODEL_SMART=")]
                out.append("AI_MODEL_SMART=claude-opus-5")
        out += ["AI_BASE_URL=" + base, "AI_API_KEY=" + key, "AI_MODEL=" + model]
        with open(envf, "w", encoding="utf-8") as f:
            f.write("\n".join(out) + "\n")
        os.chmod(envf, 0o600)
        print("ai_key: installed", prov)
        applied.append("ai_key:" + prov)
        continue
    rel = norm(job.get("path"))
    if not rel or not texty(rel):
        print("deny/invalid path:", job.get("path")); failed.append(rel or "?"); continue
    try:
        if kind == "code_revert":
            # restore newest backup for rel
            idx_path = os.path.join(BK, "index.json")
            entry, efile = None, None
            try:
                idx = json.load(open(idx_path, encoding="utf-8"))
                for e in sorted(idx, key=lambda x: -int(x.get("ts", 0))):
                    if e.get("path") == rel:
                        if e.get("existed") is False:
                            entry, efile = e, None; break   # revert = delete
                        cand = os.path.join(BK, e.get("file", ""))
                        if os.path.isfile(cand):
                            entry, efile = e, cand; break
            except Exception:
                pass
            if not entry:
                print("no backup for", rel); failed.append(rel); continue
            backup(rel)
            if entry.get("existed") is False:
                os.remove(os.path.join(ROOT, rel)) if os.path.isfile(os.path.join(ROOT, rel)) else None
                print("revert: removed new-file", rel)
            else:
                shutil.copy2(efile, os.path.join(ROOT, rel))
                print("revert: restored", rel)
            applied.append(rel)
        elif kind == "code_write":
            backup(rel)
            atomic_write(rel, str(job.get("content") or ""))
            print("write:", rel); applied.append(rel)
            touched_site |= rel.startswith("site/")
        elif kind == "code_edit":
            f = os.path.join(ROOT, rel)
            if not os.path.isfile(f):
                print("edit: missing file", rel); failed.append(rel); continue
            src = open(f, encoding="utf-8").read()
            edits = job.get("edits") or []
            ok = True
            for e in edits:
                old, new = str(e.get("old") or ""), str(e.get("new") or "")
                n = src.count(old)
                if not old or n != 1:
                    print("edit: old not unique/found in", rel); ok = False; break
                src = src.replace(old, new, 1)
            if not ok:
                failed.append(rel); continue
            backup(rel)
            atomic_write(rel, src)
            print("edit:", rel, f"({len(edits)} جایگزینی)"); applied.append(rel)
            touched_site |= rel.startswith("site/")
        else:
            print("unknown kind", kind); failed.append(job_path)
    except py_compile.PyCompileError as e:
        print("COMPILE FAIL", rel, str(e)[:300]); failed.append(rel)
        # restore the backup we just took (atomic_write never touched dst)
        try:
            if rel in applied:
                applied.remove(rel)
        except ValueError:
            pass
    except Exception as e:
        print("job error", rel or job_path, str(e)[:200]); failed.append(rel or job_path)

if touched_site:
    bump_sw()

# rollback manifest for the caller (only successful applies)
man = os.path.join(ROOT, "data", "code-pending-rollback.json")
idx_path = os.path.join(BK, "index.json")
try:
    idx = json.load(open(idx_path, encoding="utf-8"))
except Exception:
    idx = []
roll = []
for rel in applied:
    for e in sorted(idx, key=lambda x: -int(x.get("ts", 0))):
        if e.get("path") == rel:
            roll.append(e); break
json.dump({"applied": applied, "entries": roll}, open(man, "w", encoding="utf-8"),
          ensure_ascii=False)
try:
    open(os.path.join(ROOT, "data", "code-last-applied.txt"), "w").write(",".join(applied))
except OSError:
    pass
print("applied:", applied, "failed:", failed)
sys.exit(1 if failed else 0)
PYEOF
rc=$?
rm -f "$APP/data/code-jobs"/*.json 2>/dev/null

if [ $rc -ne 0 ]; then
  notify "⚠️ بخشی از تغییرات کد اعمال نشد (مسیر/متن نامعتبر یا خطای کامپایل)؛ جزئیات در لاگ کدگارد."
  receipt "FAIL برخی کارهای کد ناموفق (مسیر/متن/کامپایل)"
  log "jobs done with failures (rc=$rc)"
fi

# any successful apply → restart + health check
if [ -f "$APP/data/code-pending-rollback.json" ] \
   && python3 -c 'import json,sys;d=json.load(open(sys.argv[1]));sys.exit(0 if d.get("applied") else 1)' \
        "$APP/data/code-pending-rollback.json" 2>/dev/null; then
  "$SYSTEMCTL" restart bazarche >/dev/null 2>&1
  sleep 4
  if healthy; then
    KINDS=$(cat "$APP/data/code-last-applied.txt" 2>/dev/null || echo "")
    case ",$KINDS," in
      *,ai_key:*,*) MSG="✅ مغز هوش مصنوعی جدید وصل شد و سایت سالم است." ;;
      *) MSG="✅ تغییر کد اعمال شد و سایت سالم است." ;;
    esac
    notify "$MSG"
    receipt "OK $KINDS"
    log "deploy ok ($KINDS)"
  else
    python3 - "$APP" <<'PYRB' >>"$LOG" 2>&1
import json, os, shutil, sys
app = sys.argv[1]; root = os.path.realpath(app)
bk = os.path.join(root, "data", "code-backups")
try:
    man = json.load(open(os.path.join(root, "data", "code-pending-rollback.json"),
                         encoding="utf-8"))
except Exception:
    man = {"entries": []}
for e in man.get("entries", []):
    dst = os.path.join(root, e["path"]); src = os.path.join(bk, e["file"])
    try:
        if e.get("existed") is False:
            if os.path.isfile(dst): os.remove(dst)
            print("rollback: removed new file", e["path"])
        else:
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            print("rollback: restored", e["path"])
    except OSError as err:
        print("rollback FAILED", e["path"], err)
PYRB
    "$SYSTEMCTL" restart bazarche >/dev/null 2>&1
    sleep 4
    if healthy; then
      notify "⚠️ کد جدید مشکل داشت؛ خودکار به نسخهٔ قبلی برگشت و سایت سالم است."
      receipt "ROLLBACK کد جدید ناسالم بود؛ به نسخهٔ قبل برگشت"
      log "rolled back, healthy"
    else
      notify "🚨 پس از برگشت خودکار هم سایت پاسخ نداد؛ لطفاً سرور را بررسی کن (لاگ کدگارد)."
      receipt "CRITICAL سایت پس از برگشت هم پاسخ نمی‌دهد — بررسی دستی لازم است"
      log "STILL DOWN after rollback"
    fi
  fi
  rm -f "$APP/data/code-pending-rollback.json"
else
  [ $rc -ne 0 ] || log "no applyable jobs"
fi
log "run end"
