/* ==========================================================================
   Bazarche Najafabad — Application layer
   Theme, navigation, 3D tilt engine, scroll reveal, filters, forms, toasts.
   Vanilla ES module. No build step. Degrades safely without JS.
   ========================================================================== */

/* -------------------------------------------------------------------------
   0. Boot flag — CSS uses .js to opt into reveal animations
   ---------------------------------------------------------------------- */
document.documentElement.classList.add('js');

const RM = window.matchMedia('(prefers-reduced-motion: reduce)');
const prefersReduced = () => RM.matches;
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

/* -------------------------------------------------------------------------
   0. MIGRATE FROM THE PROTOTYPE  (runs once, then never touches storage)
   -------------------------------------------------------------------------
   The early build stored under un-namespaced keys on the same origin. Left
   alone they shadow the new ones and the site behaves like the old version.
   Favourites are carried across because a shopkeeper's saved list is real;
   everything else from that build is dropped.
   ---------------------------------------------------------------------- */
(function migrateLegacyStorage() {
  // No "already done" flag on purpose. A one-shot flag looked tidier, but it
  // fails the exact case it exists for: the first visit sets the flag, and if
  // the legacy data shows up a moment later (another tab, a restored session,
  // a phone that opened the new site before the old one) it is stranded for
  // good. This costs two localStorage reads per page load and cannot strand
  // anything: it simply moves whatever legacy keys are present, whenever they
  // appear, and does nothing at all once they are gone.
  const LEGACY = { 'bazarche.favs': 'bazarche.v2.favs' };
  const DROP = ['bazarche.theme', 'bazarche.support.dismissed'];
  try {
    for (const [from, to] of Object.entries(LEGACY)) {
      const val = localStorage.getItem(from);
      if (val === null) continue;
      // Never clobber a newer list the visitor has already built here.
      if (localStorage.getItem(to) === null) localStorage.setItem(to, val);
      localStorage.removeItem(from);
    }
    DROP.forEach(k => localStorage.removeItem(k));
  } catch (e) { /* private mode or storage disabled — nothing to migrate */ }
})();

/* -------------------------------------------------------------------------
   1. THEME  (light / dark, persisted, respects OS default)
   ---------------------------------------------------------------------- */
/* Namespaced to v2. localStorage is keyed by ORIGIN, so a phone that ran the
   prototype on the same host/port handed its old values straight to this
   build. Theme is disposable, but favourites are real user data — so the
   migration below MOVES them instead of dropping them. */
/* v111: two themes, "light" and "dark". The attribute is set by a blocking
   script in <head> before any stylesheet loads (server/ui.py), so this module
   only has to flip it later — never decide the initial palette. */

/* -------------------------------------------------------------------------
   2. HEADER + MOBILE NAV  (focus trap, Esc, scroll lock)
   ---------------------------------------------------------------------- */
function initHeader() {
  const header = $('.site-header');
  if (header) {
    const onScroll = () => header.classList.toggle('is-stuck', window.scrollY > 8);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  const toggle = $('[data-nav-toggle]');
  const nav = $('#mobile-nav');
  if (!toggle || !nav) return;
  // v134: admin panel pages own their hamburger — PANEL_UX_JS opens the panel
  // drawer with it. Wiring the site's mobile-nav here too would reopen the
  // original «two menus» bug on /panel.
  if (document.body.classList.contains('page-admin')) return;

  const panel = $('.panel', nav);
  let lastFocus = null;

  const open = () => {
    lastFocus = document.activeElement;
    nav.classList.add('is-open');
    nav.removeAttribute('aria-hidden');
    toggle.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
    ($('a, button', panel) || panel).focus();
  };
  const close = () => {
    nav.classList.remove('is-open');
    nav.setAttribute('aria-hidden', 'true');
    toggle.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    lastFocus && lastFocus.focus();
  };

  toggle.addEventListener('click', () => nav.classList.contains('is-open') ? close() : open());
  $$('[data-nav-close]', nav).forEach(el => el.addEventListener('click', close));

  nav.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.preventDefault(); close(); return; }
    if (e.key !== 'Tab') return;
    const f = $$('a[href], button:not([disabled]), input, select, textarea', panel)
      .filter(el => el.offsetParent !== null);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });
}

/* -------------------------------------------------------------------------
   3. 3D TILT ENGINE
   Pointer-driven rotateX/rotateY + cursor sheen. Clamped, damped, and
   disabled on coarse pointers / reduced motion.
   ---------------------------------------------------------------------- */
function initTilt() {
  if (prefersReduced() || window.matchMedia('(pointer: coarse)').matches) return;

  $$('[data-tilt]').forEach(el => {
    const max = parseFloat(el.dataset.tilt) || 8;      // degrees
    let raf = 0, tx = 0, ty = 0, cx = 50, cy = 50;
    let rx = 0, ry = 0, mx = 50, my = 50;

    const loop = () => {
      rx += (tx - rx) * 0.14;
      ry += (ty - ry) * 0.14;
      mx += (cx - mx) * 0.18;
      my += (cy - my) * 0.18;
      el.style.setProperty('--rx', rx.toFixed(3) + 'deg');
      el.style.setProperty('--ry', ry.toFixed(3) + 'deg');
      el.style.setProperty('--mx', mx.toFixed(2) + '%');
      el.style.setProperty('--my', my.toFixed(2) + '%');
      if (Math.abs(tx - rx) > 0.01 || Math.abs(ty - ry) > 0.01 ||
          Math.abs(cx - mx) > 0.1 || Math.abs(cy - my) > 0.1) {
        raf = requestAnimationFrame(loop);
      } else { raf = 0; }
    };
    const kick = () => { if (!raf) raf = requestAnimationFrame(loop); };

    const onMove = (e) => {
      const r = el.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width;
      const py = (e.clientY - r.top) / r.height;
      // RTL-safe: rotateY follows horizontal position directly
      ty = (px - 0.5) * 2 * max;
      tx = -(py - 0.5) * 2 * max;
      cx = px * 100; cy = py * 100;
      kick();
    };
    const onLeave = () => { tx = 0; ty = 0; cx = 50; cy = 50; kick(); };

    el.addEventListener('pointerenter', () => el.classList.add('is-tracking'));
    el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerleave', () => { el.classList.remove('is-tracking'); onLeave(); });
    el.addEventListener('focusin', kick);
    el.addEventListener('focusout', onLeave);
  });
}

/* -------------------------------------------------------------------------
   4. SCROLL REVEAL  (IntersectionObserver, staggered)
   ---------------------------------------------------------------------- */
function initReveal() {
  const items = $$('.reveal, .reveal-3d');
  if (!items.length) return;

  // v54: touch devices show content instantly (CSS already makes it visible);
  // observing 60+ elements and staggering their fade-in is pure jank on a phone.
  if (prefersReduced() || !('IntersectionObserver' in window) ||
      window.matchMedia('(pointer: coarse)').matches) {
    items.forEach(el => el.classList.add('is-in'));
    return;
  }

  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const delay = parseInt(el.dataset.delay || '0', 10);
      setTimeout(() => el.classList.add('is-in'), delay);
      io.unobserve(el);
    });
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.06 });

  items.forEach((el, i) => {
    // auto-stagger siblings that don't declare an explicit delay
    if (!el.dataset.delay && el.parentElement?.dataset.stagger) {
      el.dataset.delay = String((i % 8) * 70);
    }
    io.observe(el);
  });
}

/* -------------------------------------------------------------------------
   5. PARALLAX LAYERS  (decorative only — never text, per motion rules)
   ---------------------------------------------------------------------- */
function initParallax() {
  const layers = $$('[data-parallax]');
  if (!layers.length || prefersReduced() ||
      window.matchMedia('(pointer: coarse)').matches) return;   // v54: no scroll-rAF on phones

  let raf = 0;
  const update = () => {
    raf = 0;
    const vh = window.innerHeight;
    layers.forEach(el => {
      const speed = parseFloat(el.dataset.parallax) || 0.08;
      const r = el.getBoundingClientRect();
      if (r.bottom < -200 || r.top > vh + 200) return;
      const progress = (r.top + r.height / 2 - vh / 2) / vh;
      el.style.transform = `translate3d(0, ${(-progress * speed * 100).toFixed(2)}px, 0)`;
    });
  };
  const onScroll = () => { if (!raf) raf = requestAnimationFrame(update); };
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll, { passive: true });
  update();
}

/* -------------------------------------------------------------------------
   6. COUNT-UP  (stat numbers, Persian digits preserved)
   ---------------------------------------------------------------------- */
const FA_DIGITS = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
export const toFa = (n) => String(n).replace(/\d/g, d => FA_DIGITS[+d]);
// Persian text uses ٬ (U+066C) as the thousands separator, not a Latin
// comma. db.fa_money() on the server already does this, so matching it here
// keeps the animated counter and the static prices visually identical.
export const faGroup = (n) =>
  toFa(Number(n).toLocaleString('en-US')).replace(/,/g, '٬');

function initCountUp() {
  const els = $$('[data-count]');
  if (!els.length) return;

  const run = (el) => {
    const target = parseFloat(el.dataset.count);
    const suffix = el.dataset.suffix || '';
    if (prefersReduced() || window.matchMedia('(pointer: coarse)').matches) {
      el.textContent = faGroup(target) + suffix; return; }   // v54: no rAF counter on phones
    const dur = 1400;
    const t0 = performance.now();
    const step = (now) => {
      const p = Math.min((now - t0) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      el.textContent = faGroup(Math.round(target * eased)) + suffix;
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };

  if (!('IntersectionObserver' in window)) { els.forEach(run); return; }
  const io = new IntersectionObserver((es) => es.forEach(e => {
    if (e.isIntersecting) { run(e.target); io.unobserve(e.target); }
  }), { threshold: 0.4 });
  els.forEach(el => io.observe(el));
}

/* -------------------------------------------------------------------------
   7. TOASTS
   ---------------------------------------------------------------------- */
const ICON_OK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>';
const ICON_ERR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>';

export function toast(message, kind = 'ok') {
  let stack = $('.toast-stack');
  if (!stack) {
    stack = document.createElement('div');
    stack.className = 'toast-stack';
    stack.setAttribute('role', 'status');
    stack.setAttribute('aria-live', 'polite');
    document.body.appendChild(stack);
  }
  const t = document.createElement('div');
  t.className = 'toast ' + kind;
  t.innerHTML = (kind === 'ok' ? ICON_OK : ICON_ERR) + '<span></span>';
  $('span', t).textContent = message;
  stack.appendChild(t);
  setTimeout(() => {
    t.style.transition = 'opacity .3s, transform .3s';
    t.style.opacity = '0';
    t.style.transform = 'translateY(10px)';
    setTimeout(() => t.remove(), 320);
  }, 3600);
}

/* -------------------------------------------------------------------------
   8. TABS / ACCORDION
   ---------------------------------------------------------------------- */
function initTabs() {
  $$('[data-tabs]').forEach(group => {
    const btns = $$('[role="tab"]', group);
    const select = (btn) => {
      btns.forEach(b => {
        const on = b === btn;
        b.setAttribute('aria-selected', String(on));
        b.tabIndex = on ? 0 : -1;
        const panel = document.getElementById(b.getAttribute('aria-controls'));
        if (panel) panel.hidden = !on;
      });
    };
    btns.forEach((b, i) => {
      b.addEventListener('click', () => select(b));
      b.addEventListener('keydown', (e) => {
        const dir = e.key === 'ArrowLeft' ? 1 : e.key === 'ArrowRight' ? -1 : 0; // RTL
        if (!dir) return;
        e.preventDefault();
        const next = btns[(i + dir + btns.length) % btns.length];
        next.focus(); select(next);
      });
    });
  });
}

function initAccordion() {
  $$('.accordion-trigger').forEach(btn => {
    btn.addEventListener('click', () => {
      const expanded = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!expanded));
      const panel = document.getElementById(btn.getAttribute('aria-controls'));
      if (panel) panel.hidden = expanded;
    });
  });
}

/* -------------------------------------------------------------------------
   9. MODALS
   ---------------------------------------------------------------------- */
function initModals() {
  $$('[data-modal-open]').forEach(btn => {
    btn.addEventListener('click', () => {
      const m = document.getElementById(btn.dataset.modalOpen);
      if (!m) return;
      m.hidden = false;
      document.body.style.overflow = 'hidden';
      ($('button, a, input', m) || m).focus();
    });
  });
  $$('.modal-backdrop').forEach(m => {
    const close = () => { m.hidden = true; document.body.style.overflow = ''; };
    m.addEventListener('click', (e) => { if (e.target === m) close(); });
    $$('[data-modal-close]', m).forEach(b => b.addEventListener('click', close));
    m.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
  });
}

/* -------------------------------------------------------------------------
   10. FORM VALIDATION  (inline, error near field, focus first invalid)
   ---------------------------------------------------------------------- */
const MSG = {
  valueMissing: 'این فیلد الزامی است.',
  typeMismatch: 'قالب واردشده معتبر نیست.',
  tooShort: 'متن واردشده کوتاه‌تر از حد مجاز است.',
  patternMismatch: 'قالب واردشده معتبر نیست.',
  default: 'مقدار واردشده معتبر نیست.'
};

function messageFor(input) {
  const v = input.validity;
  if (v.valueMissing) return input.dataset.msgRequired || MSG.valueMissing;
  if (v.typeMismatch) return input.dataset.msgType || MSG.typeMismatch;
  if (v.tooShort) return `حداقل ${toFa(input.minLength)} کاراکتر لازم است.`;
  if (v.patternMismatch) return input.dataset.msgPattern || MSG.patternMismatch;
  return MSG.default;
}

function showError(input, msg) {
  input.setAttribute('aria-invalid', 'true');
  const id = input.id + '-err';
  let box = document.getElementById(id);
  if (!box) {
    box = document.createElement('p');
    box.id = id;
    box.className = 'field-error';
    box.innerHTML = ICON_ERR + '<span></span>';
    input.insertAdjacentElement('afterend', box);
  }
  $('span', box).textContent = msg;
  const describedBy = (input.getAttribute('aria-describedby') || '').split(' ').filter(Boolean);
  if (!describedBy.includes(id)) input.setAttribute('aria-describedby', [...describedBy, id].join(' '));
}

function clearError(input) {
  input.removeAttribute('aria-invalid');
  document.getElementById(input.id + '-err')?.remove();
}

/* -------------------------------------------------------------------------
   v89 · shared upload UX — a real progress bar (with a percentage) for every
   file upload, plus a preview before send. Exposed on window so the bespoke
   uploaders (upload.js gallery, chat.js messenger) reuse the very same bar.
   ------------------------------------------------------------------------- */
const UpBar = (() => {
  let el, fill, txt, pct;
  const fa = (n) => String(n).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[+d]);
  function ensure() {
    if (el) return;
    el = document.createElement('div');
    el.className = 'up-progress';
    el.setAttribute('role', 'status');
    el.setAttribute('aria-live', 'polite');
    // v109: a SPINNING RING instead of the static arrow — it turns the whole
    // time bytes are moving, keeps spinning through the server phase, and the
    // inner core puffs once the upload completes.
    el.innerHTML =
      '<span class="up-ring" aria-hidden="true"></span>' +
      '<div class="up-body"><div class="up-label"><span class="up-txt">در حال آپلود…</span>' +
      '<span class="up-pct nums">۰٪</span></div>' +
      '<div class="up-track"><div class="up-fill"></div></div></div>';
    document.body.appendChild(el);
    fill = el.querySelector('.up-fill');
    txt = el.querySelector('.up-txt');
    pct = el.querySelector('.up-pct');
  }
  return {
    show(label = 'در حال آپلود…') {
      ensure(); txt.textContent = label;
      el.classList.remove('is-err', 'is-done', 'is-processing');
      fill.style.width = '0%'; pct.textContent = fa(0) + '٪'; el.classList.add('is-on');
    },
    set(p) {
      ensure(); p = Math.max(0, Math.min(100, Math.round(p)));
      fill.style.width = p + '%'; pct.textContent = fa(p) + '٪';
      if (p >= 100) this.process();      // bytes done -> server is working
    },
    process() {                          // v109: distinct server-processing phase
      ensure();
      el.classList.add('is-processing');
      txt.textContent = 'در حال پردازش روی سرور…';
      pct.textContent = '⌛';
    },
    hide() { if (el) el.classList.remove('is-on'); },
    error(msg = 'آپلود ناموفق بود') {
      ensure(); txt.textContent = msg;
      el.classList.remove('is-processing'); el.classList.add('is-err');
      fill.style.width = '100%'; setTimeout(() => UpBar.hide(), 2880);
    },
    done(msg = 'آپلود کامل شد') {
      ensure();
      el.classList.remove('is-processing'); el.classList.add('is-done');
      txt.textContent = msg; fill.style.width = '100%';
    },
  };
})();
window.UpBar = UpBar;

// Post a FormData over XHR so upload.onprogress can report a real percentage
// (fetch cannot). Resolves with the final URL after the server's redirect.
function uploadWithProgress(form, fd, label) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', form.action, true);
    xhr.upload.addEventListener('progress', (e) => {
      if (e.lengthComputable) UpBar.set((e.loaded / e.total) * 100);
    });
    xhr.addEventListener('load', () => {
      if (xhr.status >= 200 && xhr.status < 400) resolve(xhr.responseURL || location.href);
      else reject(new Error('http ' + xhr.status));
    });
    xhr.addEventListener('error', () => reject(new Error('network')));
    xhr.addEventListener('abort', () => reject(new Error('abort')));
    UpBar.show(label);
    xhr.send(fd);
  });
}
window.uploadWithProgress = uploadWithProgress;

// Show a thumbnail (image or video) beside a file input the moment a file is
// chosen, so the user sees exactly what they are about to send.
function bindFilePreview(input) {
  if (!input || input.dataset.upPreviewBound) return;
  input.dataset.upPreviewBound = '1';
  let box = null;
  const render = () => {
    const f = input.files && input.files[0];
    if (!f) { if (box) box.hidden = true; return; }
    if (!box) {
      box = document.createElement('div');
      box.className = 'up-preview';
      (input.closest('label') || input).insertAdjacentElement('afterend', box);
    }
    box.textContent = '';
    const url = URL.createObjectURL(f);
    let media;
    if (/^video\//.test(f.type || '')) {
      media = document.createElement('video');
      media.src = url; media.muted = true; media.playsInline = true;
      media.preload = 'metadata';
    } else {
      media = document.createElement('img');
      media.src = url; media.alt = 'پیش‌نمایش';
    }
    const meta = document.createElement('span');
    meta.className = 'up-meta';
    const strong = document.createElement('strong');
    strong.textContent = f.name;
    const kb = f.size > 1048576 ? (f.size / 1048576).toFixed(1) + ' مگابایت'
      : Math.round(f.size / 1024) + ' کیلوبایت';
    meta.append(strong, document.createElement('br'), document.createTextNode(kb));
    box.append(media, meta);
    box.hidden = false;
  };
  input.addEventListener('change', render);
  render();
}
window.bindFilePreview = bindFilePreview;

function initForms() {
  $$('form[data-validate]').forEach(form => {
    form.setAttribute('novalidate', '');
    const fields = $$('input, textarea, select', form).filter(f => f.willValidate && f.type !== 'hidden');

    fields.forEach(f => {
      f.addEventListener('blur', () => { if (f.value) f.checkValidity() ? clearError(f) : showError(f, messageFor(f)); });
      f.addEventListener('input', () => { if (f.getAttribute('aria-invalid') === 'true' && f.checkValidity()) clearError(f); });
    });

    // v89: preview the chosen file (photo or video) before the user sends.
    $$('input[type=file]', form).forEach(bindFilePreview);

    form.addEventListener('submit', (e) => {
      // v137: the story composer (data-compress) owns its own submit —
      // compress.js compresses on the device first, then publishes over XHR
      // with the UpBar progress pill. The generic multipart uploader below
      // must not run for it or every publish would POST twice.
      if (form.hasAttribute('data-compress')) return;
      // Validate, then LET THE FORM SUBMIT. This handler used to call
      // preventDefault() unconditionally and fake a success toast, so every
      // form carrying data-validate — login, submit a business, reviews,
      // questions, bookings, the whole panel — silently did nothing in a
      // real browser while looking like it had worked.
      // A button may opt out of validation (formnovalidate) — an "accept"
      // action has no fields to fill, and blocking it on a required input it
      // does not use makes the button silently dead.
      const via = e.submitter;
      if (via && (via.hasAttribute('formnovalidate') || via.formNoValidate)) {
        fields.forEach(clearError);
        return;                        // let the browser submit it as-is
      }

      let firstBad = null;
      fields.forEach(f => {
        if (f.checkValidity()) clearError(f);
        else { showError(f, messageFor(f)); firstBad = firstBad || f; }
      });

      if (firstBad) {
        e.preventDefault();            // the only case that blocks submission
        firstBad.focus();
        firstBad.scrollIntoView({ block: 'center', behavior: prefersReduced() ? 'auto' : 'smooth' });
        toast('لطفاً خطاهای مشخص‌شده را برطرف کنید.', 'err');
        return;
      }

      // v89: a multipart form with a chosen file uploads over XHR so the user
      // watches a real percentage instead of a blind full-page POST. Bespoke
      // uploaders (the gallery's data-upload) keep their own handler.
      const fileIn = form.querySelector('input[type=file]');
      if (form.enctype === 'multipart/form-data' && fileIn && fileIn.files && fileIn.files.length
          && !form.hasAttribute('data-upload')) {
        e.preventDefault();
        const fd = new FormData(form);
        const fbtn = $('[type="submit"]', form);
        if (fbtn) fbtn.disabled = true;
        uploadWithProgress(form, fd)
          .then(url => { UpBar.set(100); location.href = url; })
          .catch(() => { UpBar.error(); if (fbtn) fbtn.disabled = false; });
        return;
      }

      // Valid: show progress on the button and hand over to the browser.
      const btn = $('[type="submit"]', form);
      if (btn && !btn.dataset.busy) {
        btn.dataset.busy = '1';
        const old = btn.innerHTML;
        btn.innerHTML = '<span class="spinner"></span><span>در حال ارسال…</span>';
        // Do NOT set disabled before submit — a disabled button is omitted
        // from the payload, which would drop name="action" values the server
        // relies on. Guard against double-submit with the busy flag instead.
        setTimeout(() => {
          if (!btn.isConnected) return;
          btn.innerHTML = old;
          delete btn.dataset.busy;
        }, 8000);
      }
    });
  });
}

/* -------------------------------------------------------------------------
   11. BUSINESS DIRECTORY  — search / filter / sort / open-now
   Works entirely client-side over data-* attributes on the cards.
   ---------------------------------------------------------------------- */
function normalizeFa(s) {
  return (s || '')
    .replace(/[يﻱﻲ]/g, 'ی').replace(/[كﻙﻚ]/g, 'ک')
    .replace(/[ًٌٍَُِّْـ]/g, '')
    .replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .trim().toLowerCase();
}

/* ==========================================================================
   OPEN NOW
   The server renders these badges in Iran time and they are correct on
   arrival. This code only REFRESHES them while the page stays open, so a
   tab left on screen at closing time does not keep claiming "open".

   It deliberately uses a fixed UTC+3:30 offset rather than the device clock:
   a phone with the wrong timezone would otherwise be shown the wrong answer,
   which is the exact mistake this feature exists to prevent.
   ========================================================================== */
const DAY_KEYS = ['mon','tue','wed','thu','fri','sat','sun'];  // by weekday index
const IRAN_OFFSET_MIN = 210;
const FA_D = '۰۱۲۳۴۵۶۷۸۹';
const faNum = (n) => String(n).replace(/\d/g, d => FA_D[+d]);

function iranNow() {
  const now = new Date();
  return new Date(now.getTime() + (now.getTimezoneOffset() + IRAN_OFFSET_MIN) * 60000);
}

const hhmm = (t) => {
  const p = String(t).trim().split(':');
  const h = +p[0], m = +p[1];
  if (!isFinite(h) || !isFinite(m)) return null;
  return h * 60 + m;
};

/* Mirrors db.open_state() exactly. Returns {state,label,detail,minutes}. */
function openState(hoursJson) {
  let map;
  try { map = JSON.parse(hoursJson || '{}'); } catch (e) { return null; }
  if (!map || !DAY_KEYS.some(k => (map[k] || []).length)) {
    return { state: 'unknown', label: 'ساعت کاری ثبت نشده', detail: '', minutes: null };
  }
  const now = iranNow();
  // JS getDay() is Sunday=0; DAY_KEYS is Monday-first like Python's weekday()
  const wd  = (now.getDay() + 6) % 7;
  const cur = now.getHours() * 60 + now.getMinutes();
  const FA_DAY = { sat:'شنبه', sun:'یک‌شنبه', mon:'دوشنبه', tue:'سه‌شنبه',
                   wed:'چهارشنبه', thu:'پنج‌شنبه', fri:'جمعه' };

  for (const r of (map[DAY_KEYS[wd]] || [])) {
    if (!r || r.length !== 2) continue;
    const o = hhmm(r[0]), c = hhmm(r[1]);
    if (o === null || c === null) continue;
    const wraps = c <= o;
    const inside = wraps ? (cur >= o || cur < c) : (cur >= o && cur < c);
    if (inside) {
      const left = wraps ? ((c + 1440 - cur) % 1440) : (c - cur);
      if (left <= 60) return { state:'closing', label:`تا ${faNum(left)} دقیقهٔ دیگر می‌بندد`,
                               detail:`تا ساعت ${faNum(r[1])}`, minutes:left };
      return { state:'open', label:'الان باز است', detail:`تا ساعت ${faNum(r[1])}`, minutes:left };
    }
  }

  for (let step = 0; step < 8; step++) {
    const d = DAY_KEYS[(wd + step) % 7];
    const ranges = (map[d] || []).slice()
      .filter(r => r && r.length === 2 && hhmm(r[0]) !== null)
      .sort((a, b) => hhmm(a[0]) - hhmm(b[0]));
    for (const r of ranges) {
      const o = hhmm(r[0]);
      if (step === 0 && o <= cur) continue;
      if (step === 0) {
        const mins = o - cur;
        if (mins <= 90) return { state:'closed', label:`تا ${faNum(mins)} دقیقهٔ دیگر باز می‌شود`,
                                 detail:`ساعت ${faNum(r[0])}`, minutes:null };
        return { state:'closed', label:'الان بسته است',
                 detail:`امروز ساعت ${faNum(r[0])} باز می‌شود`, minutes:null };
      }
      const when = step === 1 ? 'فردا' : (FA_DAY[d] || d);
      return { state:'closed', label:'الان بسته است',
               detail:`${when} ساعت ${faNum(r[0])} باز می‌شود`, minutes:null };
    }
  }
  return { state:'closed', label:'الان بسته است', detail:'', minutes:null };
}

/* Exposed so tools/test_open_parity.py can drive this exact function and
   prove it agrees with db.open_state() in Python. Two implementations of one
   rule drift silently otherwise. */
if (typeof window !== 'undefined') window.__openState = openState;

const OPEN_CLS  = { open:'badge-open', closing:'badge-warn',
                    closed:'badge-closed', unknown:'badge-neutral' };

function paintOpenBadges(root = document) {
  const ICON = {
    open:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    closing: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>',
    closed:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="m15 9-6 6M9 9l6 6"/></svg>',
    unknown: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  };

  $$('[data-open-badge]', root).forEach(badge => {
    const host = badge.closest('[data-hours-json]') || badge;
    const json = badge.dataset.hoursJson || host.dataset.hoursJson || '';
    if (!json) return;                     // server already rendered it; leave it
    const st = openState(json);
    if (!st) return;
    const card = badge.closest('[data-biz]');
    const compact = card !== null;
    let text = st.label;
    if (compact && st.state === 'closing') text = `${faNum(st.minutes)} دقیقه تا بستن`;
    else if (compact && st.state === 'unknown') text = 'نامشخص';

    badge.className = 'badge ' + (OPEN_CLS[st.state] || 'badge-neutral');
    badge.dataset.openState = st.state;
    if (st.detail) badge.title = st.detail; else badge.removeAttribute('title');
    badge.innerHTML = (ICON[st.state] || ICON.unknown) + '<span>' + text + '</span>';
    if (card) card.dataset.open = st.state;
  });

  $$('[data-open-line]', root).forEach(line => {
    const host = line.closest('[data-hours-json]') || line;
    const json = line.dataset.hoursJson || host.dataset.hoursJson || '';
    if (!json) return;
    const st = openState(json);
    if (!st || st.state === 'unknown') return;
    line.dataset.openState = st.state;
    line.className = 'open-line ' + ({ open:'is-open', closing:'is-closing',
                                       closed:'is-closed' }[st.state] || '');
    line.innerHTML = '<span class="open-dot" aria-hidden="true"></span>' +
      '<strong>' + st.label + '</strong>' +
      (st.detail ? '<span class="open-detail">' + st.detail + '</span>' : '');
  });
}

/* Keep the badges honest on a page nobody reloads. */
let _openTimer = null;
function startOpenTicker() {
  if (_openTimer) return;
  _openTimer = setInterval(() => paintOpenBadges(), 60000);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) paintOpenBadges();   // catch up after a sleeping tab
  });
}

function initDirectory() {
  const root = $('[data-directory]');
  if (!root) return;

  const grid     = $('[data-dir-grid]', root);
  const cards    = $$('[data-biz]', grid);
  const q        = $('[data-dir-search]', root);
  const sortSel  = $('[data-dir-sort]', root);
  const openOnly = $('[data-dir-open]', root);
  const chips    = $$('[data-dir-cat]', root);
  const countEl  = $('[data-dir-count]', root);
  const empty    = $('[data-dir-empty]', root);
  const clearBtn = $('[data-dir-clear]', root);

  let activeCat = root.dataset.initialCat || 'all';

  paintOpenBadges(root);

  /* The server handles search/category/sort. This only refines the rendered
     page live: instant typing feedback and the "open now" toggle. */
  function apply() {
    const term = normalizeFa(q?.value);
    let shown = 0;
    cards.forEach(card => {
      const okTerm = !term || normalizeFa(card.dataset.search).includes(term);
      const okOpen = !openOnly?.checked ||
        card.dataset.open === 'open' || card.dataset.open === 'closing' ||
        card.dataset.open === 'unknown';
      const show = okTerm && okOpen;
      card.hidden = !show;
      if (show) shown++;
    });
    if (countEl) countEl.textContent = toFa(shown);
    if (empty) empty.hidden = shown > 0;
    if (grid) grid.hidden = shown === 0;
  }

  let debounce;
  q?.addEventListener('input', () => { clearTimeout(debounce); debounce = setTimeout(apply, 180); });
  sortSel?.addEventListener('change', apply);
  openOnly?.addEventListener('change', apply);

  clearBtn?.addEventListener('click', () => {
    if (q) q.value = '';
    if (openOnly) openOnly.checked = false;
    apply();
    q?.focus();
  });

  apply();
}

/* -------------------------------------------------------------------------
   12. GALLERY LIGHTBOX  (business page)
   ---------------------------------------------------------------------- */
function initGallery() {
  const gal = $('[data-gallery]');
  if (!gal) return;
  const main = $('[data-gallery-main]', gal);
  const thumbs = $$('[data-gallery-thumb]', gal);

  thumbs.forEach((t, i) => {
    t.addEventListener('click', () => {
      const img = $('img', t);
      if (main && img) {
        main.src = img.dataset.full || img.src;
        main.alt = img.alt;
      }
      thumbs.forEach(x => x.setAttribute('aria-current', String(x === t)));
    });
  });
}

/* -------------------------------------------------------------------------
   13. STAR RATING INPUT
   ---------------------------------------------------------------------- */
/* v158: مقیاس شش‌ستاره‌ای — برچسب فارسیِ انتخاب، بالای کادر امتیاز */
const RATING_LABELS = ['خیلی بد', 'بد', 'متوسط', 'خوب', 'خیلی خوب', 'عالی'];
function ratingText(v) { return v > 0 ? (RATING_LABELS[v - 1] || toFa(v)) : ''; }

function initRating() {
  $$('[data-rating-input]').forEach(group => {
    const input = $('input[type="hidden"]', group);
    const stars = $$('button', group);
    const lbl = group.closest('.rating-box')?.querySelector('[data-rating-label]');
    const paint = (v) => {
      stars.forEach((s, i) => s.setAttribute('aria-pressed', String(i < v)));
      if (lbl) {
        lbl.textContent = v > 0 ? ratingText(v) : 'یک ستاره انتخاب کنید';
        lbl.classList.toggle('is-set', v > 0);
      }
    };
    stars.forEach((s, i) => {
      s.addEventListener('click', () => { if (input) input.value = i + 1; paint(i + 1); liveRatingScore(input); });
      s.addEventListener('mouseenter', () => paint(i + 1));
    });
    group.addEventListener('mouseleave', () => paint(parseInt(input?.value || '0', 10)));
    paint(parseInt(input?.value || '0', 10));
  });
}

/* v151 → v158: the live "your score" box mirrors the chosen star's label. */
function liveRatingScore(input) {
  const box = $('[data-live-score]');
  if (!box) return;
  const v = parseInt((input && input.value) || '0', 10);
  if (v > 0) {
    box.hidden = false;
    const el = $('[data-live-val]', box);
    if (el) el.textContent = ratingText(v);
  } else {
    box.hidden = true;
  }
}

/* -------------------------------------------------------------------------
   14. COPY TO CLIPBOARD
   ---------------------------------------------------------------------- */
function initCopy() {
  $$('[data-copy]').forEach(btn => {
    btn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(btn.dataset.copy);
        toast('در حافظه کپی شد.', 'ok');
      } catch (e) { toast('کپی ناموفق بود.', 'err'); }
    });
  });
}

/* (v53) The WebGL hero scene was removed entirely for speed — the hero is now
   the lightweight looping video + gradient only. No Three.js, no GPU cost. */
/* -------------------------------------------------------------------------
   16. FAVORITES — one state for cards, detail, map, nearby and account
   ---------------------------------------------------------------------- */
const FAV_KEY = 'bazarche.v2.favs';
const FAV_BOOT = (window.__BAZARCHE__ || {});
const favNormalize = (values) => [...new Set((Array.isArray(values) ? values : [])
  .map(v => String(v || '').trim()).filter(Boolean))];
const favLocalRead = () => {
  try { return favNormalize(JSON.parse(localStorage.getItem(FAV_KEY) || '[]')); }
  catch (_) { return []; }
};
const favWrite = (values) => {
  try { localStorage.setItem(FAV_KEY, JSON.stringify(favNormalize(values))); }
  catch (_) {}
};
let favState = favNormalize(FAV_BOOT.favoriteSignedIn ? FAV_BOOT.favoriteSlugs : favLocalRead());
if (FAV_BOOT.favoriteSignedIn) favWrite(favState); // server truth -> offline/device mirror
const favRead = () => [...favState];
const favOn = slug => favState.includes(String(slug || ''));

function paintFavorites() {
  $$('[data-fav]').forEach(btn => {
    const slug = btn.dataset.fav || '';
    const on = favOn(slug);
    btn.setAttribute('aria-pressed', String(on));
    btn.classList.toggle('is-on', on);
    btn.dataset.favoriteState = on ? 'on' : 'off';
    btn.title = on ? 'حذف از علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی‌ها';
    // Keep the accessible name stable; aria-pressed communicates state.
    const name = btn.dataset.favName || slug;
    btn.setAttribute('aria-label', `علاقه‌مندی: ${name}`);
    const label = btn.querySelector('[data-fav-label]');
    if (label) label.textContent = on ? 'ذخیره شد' : 'علاقه‌مندی';
  });
  const n = favState.length;
  $$('[data-fav-count]').forEach(el => {
    el.hidden = n === 0; el.textContent = toFa(n);
  });
  $$('[data-favorites-link]').forEach(link => {
    link.classList.toggle('has-favorites', n > 0);
    link.setAttribute('aria-label', n ? `علاقه‌مندی‌ها، ${toFa(n)} مورد` : 'علاقه‌مندی‌ها، خالی');
  });
}

function favApply(values, detail = null) {
  favState = favNormalize(values); favWrite(favState); paintFavorites();
  if (detail) document.dispatchEvent(new CustomEvent('bazarche:favorites-changed', { detail }));
}

async function toggleFavorite(slug) {
  slug = String(slug || '').trim();
  if (!slug) return false;
  const previous = favRead();
  const next = favOn(slug) ? previous.filter(x => x !== slug) : [...previous, slug];
  const wanted = next.includes(slug);
  favApply(next, { slug, on: wanted, slugs: next });
  if (!FAV_BOOT.favoriteSignedIn) {
    window.Bazarche?.toast(wanted ? 'به علاقه‌مندی‌ها اضافه شد.' : 'از علاقه‌مندی‌ها حذف شد.');
    return wanted;
  }
  $$('[data-fav]').filter(b => b.dataset.fav === slug)
    .forEach(b => { b.disabled = true; b.setAttribute('aria-busy', 'true'); });
  try {
    const response = await fetch('/api/favorite', {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'slug=' + encodeURIComponent(slug),
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || 'favorite failed');
    favApply(data.slugs || next, { slug, on: Boolean(data.on), slugs: data.slugs || next });
    window.Bazarche?.toast(data.on ? 'به علاقه‌مندی‌ها اضافه شد.' : 'از علاقه‌مندی‌ها حذف شد.');
    return Boolean(data.on);
  } catch (_) {
    favApply(previous, { slug, on: previous.includes(slug), slugs: previous, error: true });
    window.Bazarche?.toast('ذخیرهٔ علاقه‌مندی انجام نشد. دوباره تلاش کنید.', 'err');
    return previous.includes(slug);
  } finally {
    $$('[data-fav]').filter(b => b.dataset.fav === slug)
      .forEach(b => { b.disabled = false; b.removeAttribute('aria-busy'); });
  }
}

let favoritesWired = false;
function initFavorites() {
  paintFavorites();
  if (favoritesWired) return;
  favoritesWired = true;
  document.addEventListener('click', (event) => {
    const btn = event.target.closest('[data-fav]');
    if (!btn || btn.disabled) return;
    event.preventDefault(); event.stopPropagation(); toggleFavorite(btn.dataset.fav);
  });
  window.addEventListener('storage', event => {
    if (event.key !== FAV_KEY) return;
    try { favApply(JSON.parse(event.newValue || '[]')); } catch (_) { favApply([]); }
  });
}

window.BazarcheFavorites = {
  read: favRead,
  has: favOn,
  paint: paintFavorites,
  toggle: toggleFavorite,
};

/* -------------------------------------------------------------------------
   17. SHARE  (Web Share API with clipboard fallback)
   ---------------------------------------------------------------------- */
function initShare() {
  $$('[data-share]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const data = { title: btn.dataset.share || document.title, url: location.href };
      if (navigator.share) {
        try { await navigator.share(data); return; } catch (e) { if (e.name === 'AbortError') return; }
      }
      try {
        await navigator.clipboard.writeText(location.href);
        toast('نشانی صفحه کپی شد.');
      } catch (e) { toast('اشتراک‌گذاری ممکن نبود.', 'err'); }
    });
  });
}

/* -------------------------------------------------------------------------
   18. CONFIRM  (destructive form actions)
   ---------------------------------------------------------------------- */
function initConfirm() {
  $$('form[data-confirm]').forEach(f => {
    f.addEventListener('submit', (e) => {
      if (!window.confirm(f.dataset.confirm)) e.preventDefault();
    });
  });
  // v209: native <dialog> openers + "type the name to confirm" gate.
  $$('[data-dialog-open]').forEach(b => {
    b.addEventListener('click', () => {
      const d = document.getElementById(b.dataset.dialogOpen);
      if (!d) return;
      if (typeof d.showModal === 'function') d.showModal(); else d.setAttribute('open', '');
      const inp = d.querySelector('input'); if (inp) setTimeout(() => inp.focus(), 50);
    });
  });
  $$('[data-dialog-close]').forEach(b => {
    b.addEventListener('click', () => { const d = b.closest('dialog'); if (d) d.close ? d.close() : d.removeAttribute('open'); });
  });
  $$('dialog').forEach(d => {
    d.addEventListener('click', (e) => { if (e.target === d && d.close) d.close(); });   // backdrop click
  });
  const fold = (t) => String(t || '').replace(/[\u064A]/g, '\u06CC').replace(/[\u0643]/g, '\u06A9')
    .replace(/[\u200C\s]+/g, ' ').trim();
  $$('input[data-must-equal]').forEach(inp => {
    const btn = inp.closest('form')?.querySelector('[type=submit]');
    const check = () => { if (btn) btn.disabled = fold(inp.value) !== fold(inp.dataset.mustEqual); };
    inp.addEventListener('input', check); check();
    inp.closest('form')?.addEventListener('submit', (e) => { check(); if (btn && btn.disabled) e.preventDefault(); });
  });
}

/* -------------------------------------------------------------------------
   19. ICON PICKER preview (owner panel)
   ---------------------------------------------------------------------- */
function initIconPicker() {
  const bg = (name, size) => {
    const aliases = { store:'business', shopping:'supermarket', briefcase:'business',
      camera:'photography', map:'attraction', compass:'attraction', pin:'attraction', mosque:'attraction' };
    const safe = /^[A-Za-z0-9_-]+$/.test(name || '') ? name : 'business';
    const picked = aliases[safe] || safe;
    return `width:${size}px;height:${size}px;` +
           `background-image:url(/assets/img/cats/${encodeURIComponent(picked)}.webp);` +
           'background-size:cover;background-position:center;';
  };
  const norm = (v) => String(v || '').toLocaleLowerCase('fa')
    .replace(/[يى]/g, 'ی').replace(/ك/g, 'ک').replace(/\u200c/g, ' ')
    .replace(/[_-]+/g, ' ').replace(/\s+/g, ' ').trim();

  $$('[data-icon-select]').forEach(sel => {
    const root = sel.closest('[data-icon-picker]') || sel.closest('.field');
    if (!root || root.dataset.bzIconPicker) return;
    root.dataset.bzIconPicker = '1';
    const prev = root.querySelector('[data-icon-preview]');
    const search = root.querySelector('[data-icon-search]');
    const status = root.querySelector('[data-icon-search-status]');
    const options = Array.from(sel.options);
    const total = options.length;

    const sync = () => {
      if (!prev) return;
      prev.innerHTML = '';
      const span = document.createElement('span');
      span.className = 'ic';
      span.setAttribute('style', bg(sel.value, 64));
      prev.appendChild(span);
    };
    const filter = () => {
      if (!search) return;
      const q = norm(search.value);
      let matches = 0;
      options.forEach(opt => {
        const hit = !q || norm(opt.dataset.iconTerms || opt.textContent).includes(q);
        if (hit) matches++;
        // The selected option always remains available, so searching nonsense
        // can never remove `name=icon` from form submission.
        opt.hidden = !hit && !opt.selected;
      });
      if (q) {
        const visible = options.filter(o => !o.hidden).length;
        sel.size = Math.max(2, Math.min(8, visible));
        sel.classList.add('is-searching');
        if (status) status.textContent = matches
          ? `${matches.toLocaleString('fa-IR')} آیکون پیدا شد؛ یکی را انتخاب کنید.`
          : 'آیکونی پیدا نشد؛ نام دیگری بنویسید. انتخاب فعلی حفظ شده است.';
      } else {
        sel.size = 1;
        sel.classList.remove('is-searching');
        if (status) status.textContent = `${total.toLocaleString('fa-IR')} آیکون؛ با نام فارسی یا لاتین جست‌وجو کنید.`;
      }
    };
    sel.addEventListener('change', () => { sync(); filter(); });
    if (search) {
      search.addEventListener('input', filter);
      search.addEventListener('keydown', e => {
        if (e.key === 'Escape') { search.value = ''; filter(); search.focus(); }
      });
    }
    sync(); filter();
  });
}

/* -------------------------------------------------------------------------
   20. LIVE COLOR PREVIEW (owner appearance page)
   ---------------------------------------------------------------------- */
function initColorSync() {
  const map = {
    color_primary: '--color-primary',
    color_accent: '--color-accent',
    color_background: '--color-background',
    color_foreground: '--color-foreground',
  };
  $$('[data-color-sync]').forEach(inp => {
    inp.addEventListener('input', () => {
      const v = map[inp.name];
      if (v) document.documentElement.style.setProperty(v, inp.value);
      const code = inp.closest('.color-row')?.querySelector('code');
      if (code) code.textContent = inp.value;
    });
  });
}

/* -------------------------------------------------------------------------
   21. PWA service worker
   ---------------------------------------------------------------------- */
function initPWA() {
  if (!('serviceWorker' in navigator)) return;
  if (location.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(location.hostname)) return;
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').then(reg => {
      // A stale worker used to keep serving an old shell after an update,
      // which looked like "the site won't open". Take over immediately.
      if (reg.waiting) reg.waiting.postMessage('skipWaiting');
      reg.addEventListener('updatefound', () => {
        const sw = reg.installing;
        sw && sw.addEventListener('statechange', () => {
          if (sw.state === 'installed' && navigator.serviceWorker.controller) {
            sw.postMessage('skipWaiting');
          }
        });
      });
    }).catch(() => {});
    let reloaded = false;
    // v137: only reload when a genuinely OLD worker gave way to a new one.
    // On the very first takeover (fresh browser/context, no controller yet)
    // the page was already served without the stale shell — reloading there
    // is pointless and wiped any input the user typed in the first ~0.4 s.
    const hadController = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (!hadController) return;    // first activation — nothing stale to evict
      if (reloaded) return;
      reloaded = true;
      location.reload();
    });
  });
}

/* -------------------------------------------------------------------------
   22. ANALYTICS  (fire-and-forget intent tracking)
   Counts what the owner actually cares about: calls, WhatsApp, directions.
   ---------------------------------------------------------------------- */
function track(slug, kind) {
  if (!slug || !kind) return;
  const url = `/t/${encodeURIComponent(slug)}/${encodeURIComponent(kind)}`;
  try {
    if (navigator.sendBeacon) navigator.sendBeacon(url);
    else fetch(url, { method: 'POST', keepalive: true }).catch(() => {});
  } catch (e) {}
}

function initTracking() {
  const slug = document.body.dataset.bizSlug;
  if (!slug) return;
  if (window.__bzTrackWired) return;          // v120: once — live swaps must not double-fire
  window.__bzTrackWired = true;
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a, button');
    if (!a) return;
    const href = a.getAttribute('href') || '';
    if (a.dataset.track) return track(slug, a.dataset.track);
    if (href.startsWith('tel:')) return track(slug, 'phone');
    if (href.includes('wa.me') || href.includes('whatsapp')) return track(slug, 'whatsapp');
    if (href.includes('google.com/maps/dir')) return track(slug, 'route');
    if (a.dataset.share !== undefined) return track(slug, 'share');
    if (a.dataset.fav !== undefined) return track(slug, 'save');
    if (href.includes('instagram.com')) return track(slug, 'instagram');
    if (href.includes('t.me/') || href.includes('telegram')) return track(slug, 'telegram');
    if (href.includes('eitaa.com')) return track(slug, 'eitaa');
    if (href.includes('ble.ir') || href.includes('bale.ai')) return track(slug, 'bale');
    if (href.includes('splus.ir') || href.includes('sapp.ir')) return track(slug, 'soroush');
    if (href.includes('rubika.ir')) return track(slug, 'rubika');
  }, { passive: true });
}

/* -------------------------------------------------------------------------
   23. OTP INPUT  (auto-advance + paste)
   ---------------------------------------------------------------------- */
function initOtp() {
  $$('.otp-input').forEach(inp => {
    inp.addEventListener('input', () => {
      inp.value = inp.value.replace(/[^\d]/g, '').slice(0, 5);
      if (inp.value.length === 5) inp.form?.requestSubmit?.();
    });
  });
}

/* -------------------------------------------------------------------------
   24. BOOT
   ---------------------------------------------------------------------- */
function boot() {
  initHeader();
  initTilt();
  initReveal();
  initParallax();
  initCountUp();
  initTabs();
  initAccordion();
  initModals();
  initForms();
  initDirectory();
  initGallery();
  initRating();
  initCopy();
  initFavorites();
  initShare();
  initConfirm();
  initIconPicker();
  initColorSync();
  paintOpenBadges();
  startOpenTicker();
  initCopyPhone();
  initDirFilters();
  initLiveDir();
  initLiveCatalog();
  initTracking();
  initChipOverflow();
  initGeoFill();
  initCatGroups();
  initCatSearch();
  initLiveSearch();
  initSupport();
  initPasswordReminder();
  initOtp();
  initPWA();

}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}

/* ---- v141: honest geolocation error messages ----------------------
   Browsers report err.code===1 (PERMISSION_DENIED) not only when the user
   refused, but also on insecure (non-HTTPS) contexts and inside any
   embedded/cross-origin frame — even when the user HAS granted the site.
   Instead of the misleading «اجازه داده نشد», explain the real reason. */
async function geoErrorText(err, actionLabel) {
  if (!navigator.geolocation) {
    return 'موقعیت‌یابی در این مرورگر پشتیبانی نمی‌شود (نیاز به HTTPS و مرورگر جدید).';
  }
  if (!window.isSecureContext) {
    return 'دسترسی به موقعیت فقط روی HTTPS کار می‌کند؛ این صفحه روی آدرس امن (https) باز نیست.';
  }
  try {
    if (window.self !== window.top) {
      return 'مرورگر اجازهٔ موقعیت را داخل نمای تعبیه‌شده (iframe) نمی‌دهد — صفحه را در یک برگهٔ مستقیم باز کنید.';
    }
  } catch (_) { /* cross-origin top → already blocked */ return 'اجازهٔ موقعیت در این نمای تعبیه‌شده مسدود است؛ صفحه را مستقیم باز کنید.'; }
  const code = err && err.code;
  if (code === 1) {
    // v144: one refusal, three real reasons — and each gets its own honest
    // message instead of a flat «داده نشد»:
    //   • denied  = a hard block on THIS origin (a past «Block» click, or the
    //               site was granted under a *different* origin — localhost,
    //               127.0.0.1 and any preview domain are separate origins in
    //               Chrome, each with its own geolocation decision).
    //   • granted = permission exists, yet the call was refused (transient).
    //   • prompt/unknown = the browser popup was dismissed or never answered;
    //               Chrome then refuses follow-up requests for a while.
    let state = '';
    try {
      const st = await navigator.permissions.query({ name: 'geolocation' });
      state = st ? st.state : '';
    } catch (_) { /* permissions API unsupported — state stays '' */ }
    if (state === 'denied') {
      return 'اجازهٔ موقعیت برای همین آدرس رد شده است — یا قبلاً «مسدود» را زده‌اید، یا به localhost/آدرس دیگری اجازه داده‌اید (مرورگر برای هر آدرس جدا تصمیم می‌گیرد). روی آیکون قفل کنار آدرس، «موقعیت» را «اجازه» بدهید؛ اگر «بپرس» نشان نمی‌دهد از «تنظیمات سایت» بازنشانی کنید و دوباره تلاش کنید.';
    }
    if (state === 'granted') {
      return 'اجازهٔ موقعیت روی همین آدرس داده شده، اما مرورگر این بار آن را برنگرداند؛ دوباره تلاش کنید، و اگر باز هم نشد GPS یا اتصال را بررسی و صفحه را رفرش کنید.';
    }
    // prompt or unknown — the earlier popup went unanswered/dismissed
    return 'مرورگر اجازهٔ موقعیت را نداد — اگر پاپ‌آپ اجازه را دیده‌اید و بسته شده، دوباره تلاش کنید و این بار «اجازه» را بزنید؛ اگر پاپ‌آپ نمی‌آید از «تنظیمات سایت» اجازه بدهید.';
  }
  if (code === 3) return 'گرفتن موقعیت بیش از حد طول کشید (GPS ضعیف). ' + (actionLabel || 'دوباره تلاش کنید یا روی نقشه نشان بزنید.');
  return 'موقعیت پیدا نشد؛ اتصال یا GPS را بررسی کنید و دوباره تلاش کنید.';
}


/* ---- v216: precise locator --------------------------------------------
   getCurrentPosition() returns the FIRST fix the phone has, which is usually
   the cell-tower / Wi-Fi guess (100–300 m off). Google Maps looks exact because
   it keeps listening while the GPS locks. So: watchPosition, keep the best
   (smallest accuracy) fix, stop as soon as it is good enough or when the time
   budget runs out, and hand back accuracy so the UI can be honest about it.
   opts: { good: 20 (m), max: 10000 (ms), onProgress(fix) }               */
function locatePrecise(opts) {
  opts = opts || {};
  const good = opts.good || 20, max = opts.max || 10000;
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) { reject({ code: 0, message: 'unsupported' }); return; }
    let best = null, wid = null, done = false, lastErr = null;
    const finish = () => {
      if (done) return; done = true;
      if (wid !== null) navigator.geolocation.clearWatch(wid);
      clearTimeout(timer);
      if (best) resolve(best); else reject(lastErr || { code: 3, message: 'timeout' });
    };
    const timer = setTimeout(finish, max);
    const take = (p) => {
      const fix = { lat: p.coords.latitude, lng: p.coords.longitude, acc: Math.round(p.coords.accuracy || 9999), ts: p.timestamp };
      if (!best || fix.acc < best.acc) { best = fix; opts.onProgress && opts.onProgress(fix); }
      if (best.acc <= good) finish();
    };
    const fail = (e) => { lastErr = e; if (e && e.code === 1) finish(); };
    try {
      wid = navigator.geolocation.watchPosition(take, fail, { enableHighAccuracy: true, timeout: max, maximumAge: 0 });
    } catch (e) { lastErr = e; finish(); }
  });
}
function accuracyText(acc) {
  if (!acc && acc !== 0) return '';
  if (acc <= 15) return `دقت عالی (حدود ${toFa(acc)} متر)`;
  if (acc <= 40) return `دقت خوب (حدود ${toFa(acc)} متر)`;
  if (acc <= 120) return `دقت متوسط (حدود ${toFa(acc)} متر) — GPS گوشی را روشن کنید و زیر سقف نباشید`;
  return `دقت کم (حدود ${toFa(acc)} متر) — فقط بر اساس شبکه؛ GPS را روشن کنید یا پین را روی نقشه جابه‌جا کنید`;
}

window.Bazarche = { toast, toFa, faGroup, geoErrorText, locatePrecise, accuracyText };

/* ========================================================================
   v120 — LIVE CONTENT UPDATES
   live.js محتوای <main> را بدون رفرش عوض می‌کند و جستجوی زندهٔ دایرکتوری
   بخش نتایج را. اینجا همهٔ ویجت‌های عنصر-محور برای هر دو مورد دوباره
   بسته می‌شوند (گاردهای یکباره در init* ها مانع دوباره‌بسته‌شدن لیسنرهای
   document-level می‌شوند).
   ====================================================================== */
function reinitWidgets() {
  paintOpenBadges();                 // ساعت کاری/وضعیت باز بودن را فوراً نو کن
  initReveal(); initTilt(); initCountUp(); initTabs(); initAccordion();
  initModals(); initForms(); initDirectory(); initGallery(); initRating();
  initCopy(); initCopyPhone(); initChipOverflow(); initCatGroups();
  initCatSearch(); initLiveSearch(); initGeoFill(); initPasswordReminder();
  initConfirm(); initShare(); initIconPicker(); initColorSync();
  initDirFilters(); initFavorites(); initTracking(); initLiveDir(); initLiveCatalog();
  // ماژول‌های جداگانه (countdown/stories) و بلوک «بازدیدهای اخیر»:
  window.dispatchEvent(new CustomEvent('bz:needs-countdown'));
  window.dispatchEvent(new CustomEvent('bz:needs-stories'));
  window.dispatchEvent(new CustomEvent('bz:needs-recent'));
}
window.addEventListener('bz:content-updated', reinitWidgets);

/* -------------------------------------------------------------------------
   23. CATEGORY CHIP OVERFLOW
   22 top-level categories do not fit on one row. Collapse to two rows and
   reveal the rest on demand — but only when there is actually something
   hidden, so the button never lies about there being more.
   ---------------------------------------------------------------------- */
/* -------------------------------------------------------------------------
   GEO FILL  ·  "use my current location" on the registration form
   -------------------------------------------------------------------------
   The shopkeeper is standing IN the shop while filling this in, so the phone
   already knows the answer. Typing coordinates by hand is the single most
   error-prone field on the form, and a wrong pin puts his shop on the wrong
   street. Failure is reported in words, never silently.
   ---------------------------------------------------------------------- */
function initGeoFill() {
  const btn = document.querySelector('[data-geo-fill]');
  if (!btn) return;
  const lat = document.querySelector('[name="lat"]');
  const lng = document.querySelector('[name="lng"]');
  const msg = document.querySelector('[data-geo-msg]');
  if (!lat || !lng) return;

  const say = (text, bad) => {
    if (!msg) return;
    msg.hidden = false;
    msg.textContent = text;
    msg.style.color = bad ? 'var(--color-danger, #b42318)' : 'var(--color-primary)';
  };

  btn.addEventListener('click', () => {
    if (!navigator.geolocation) {
      say('مرورگر شما موقعیت‌یابی را پشتیبانی نمی‌کند. مختصات را دستی بنویسید یا روی نقشه نشان بزنید.', true);
      return;
    }
    // The phone reports WHERE YOU ARE, not where the shop is. Remind the
    // shopkeeper to be on the premises, or the pin lands on the wrong street.
    say('موقعیت همین گوشی گرفته می‌شود — لطفاً در محل کسب‌وکار خود باشید، وگرنه پین جای اشتباه می‌افتد.');
    const label = btn.querySelector('span');
    const original = label ? label.textContent : '';
    if (label) label.textContent = 'در حال گرفتن موقعیت…';
    btn.disabled = true;
    const apply = (fix, final) => {
      const la = fix.lat.toFixed(6), ln = fix.lng.toFixed(6);
      lat.value = la; lng.value = ln;
      window.dispatchEvent(new CustomEvent('bz:geo', { detail: { lat: +la, lng: +ln, acc: fix.acc } }));
      if (label && !final) label.textContent = `در حال دقیق‌تر کردن… (${toFa(fix.acc)} متر)`;
    };
    locatePrecise({ good: 15, max: 12000, onProgress: (fix) => apply(fix, false) }).then((fix) => {
      apply(fix, true);
      btn.disabled = false;
      if (label) label.textContent = original;
      say(`موقعیت ثبت شد — ${accuracyText(fix.acc)}. اگر دقیق نیست، پین را روی نقشه بکشید.`, fix.acc > 120);
    }).catch(async (err) => {
      btn.disabled = false;
      if (label) label.textContent = original;
      say(await window.Bazarche.geoErrorText(err, 'روی نقشه نشان بزنید یا دستی بنویسید.'), true);
    });
  });
}

/* The chips live inside the collapsible dir-filters <details>.  On a phone
   the fold is closed on arrival (v146: no auto-open), so overflow checks
   done once at boot measure a hidden box.  Sync at every details toggle
   instead, and expand automatically when the ACTIVE chip is below the fold
   so the chosen category is never invisible. */
function dirChipsSyncBox(box, btn) {
  if (!box) return;
  if (box.classList.contains('is-expanded')) return;
  const overflowing = box.scrollHeight > box.clientHeight + 4;
  if (btn) btn.hidden = !overflowing;
  if (!overflowing) return;
  const active = box.querySelector('.chip.is-active');
  if (active && !box.classList.contains('is-expanded')) {
    const top = active.offsetTop - box.offsetTop;
    if (top > box.clientHeight - 10 && btn) btn.click();
  }
}

function dirChipsSync(det) {
  if (!det) return;
  dirChipsSyncBox(det.querySelector('[data-chips]'),
                  det.querySelector('[data-chips-more]'));
}

function initChipOverflow() {
  const box = document.querySelector('[data-chips]');
  const btn = document.querySelector('[data-chips-more]');
  if (!box || !btn) return;
  const det = box.closest('details');

  btn.addEventListener('click', () => {
    const open = box.classList.toggle('is-expanded');
    btn.setAttribute('aria-expanded', String(open));
    const label = btn.querySelector('span');
    if (label) label.textContent = open ? 'نمایش کمتر' : 'همهٔ دسته‌ها';
    if (!open) dirChipsSyncBox(box, btn);
  });

  if (det) {
    // the fold decides: sync only while open; a closed fold must not expand
    det.addEventListener('toggle', () => { if (det.open) dirChipsSync(det); });
    if (det.open) dirChipsSync(det);
    return;
  }
  dirChipsSyncBox(box, btn);
  window.addEventListener('resize', () => dirChipsSync(box.parentElement), { passive: true });
}

/* -------------------------------------------------------------------------
   24. CATEGORY ACCORDION
   22 parent tiles, each opening its own trades. Only one stays open at a
   time so the grid never reflows into a wall of pills.
   ---------------------------------------------------------------------- */
function initCatGroups() {
  const groups = $$('[data-cat-group]');
  if (!groups.length) return;

  groups.forEach(group => {
    const btn = $('.cat-tile-head', group);
    const subs = $('.cat-subs', group);
    if (!btn || !subs) return;

    btn.addEventListener('click', () => {
      const open = btn.getAttribute('aria-expanded') === 'true';

      // close the others: an accordion, not a set of independent toggles
      groups.forEach(g => {
        const b = $('.cat-tile-head', g);
        const s = $('.cat-subs', g);
        if (b && s && b !== btn) { b.setAttribute('aria-expanded', 'false'); s.hidden = true; }
      });

      btn.setAttribute('aria-expanded', String(!open));
      subs.hidden = open;

      // a tile near the bottom would otherwise open off-screen
      if (!open && !prefersReduced()) {
        requestAnimationFrame(() => {
          const r = group.getBoundingClientRect();
          if (r.bottom > window.innerHeight) {
            group.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
          }
        });
      }
    });
  });
}

/* -------------------------------------------------------------------------
   24b. LIVE CATEGORY SEARCH
   Filter the category tiles as the visitor types, so finding "کباب" or
   "دندان" among 173 trades is one keystroke instead of scrolling every
   group. Opens the "all categories" drawer automatically while filtering.
   ---------------------------------------------------------------------- */
function initCatSearch() {
  const norm = (s) => (s || '').replace(/[يی]/g, 'ی').replace(/[كک]/g, 'ک')
                        .replace(/\u200c/g, ' ').toLowerCase();

  // 1. Homepage category search
  const box = $('[data-cat-searchbox]');
  if (box) {
    const input = $('[data-cat-search-input]', box);
    const grid = $('[data-cat-grid]');
    const more = $('[data-cat-more]');
    const empty = $('[data-cat-empty]');
    const tiles = () => $$('[data-cat-search]');

    if (input) {
      input.addEventListener('input', () => {
        const q = norm(input.value.trim());
        let shown = 0;
        tiles().forEach(t => {
          const hit = !q || norm(t.getAttribute('data-cat-search')).includes(q);
          t.hidden = !hit;
          if (hit) shown++;
        });
        if (empty) empty.hidden = shown > 0;
        if (more) {
          const d = more.closest('details');
          if (d && q) d.open = true;
        }
        if (grid) grid.classList.remove('js');
        tiles().forEach(t => t.classList.add('is-in'));
      });
    }
  }

  // 2. Full /categories directory search & navigation
  const dirBox = $('[data-cats-searchbox]');
  if (dirBox) {
    const input = $('[data-cats-filter]', dirBox);
    const empty = $('[data-cats-empty]', dirBox);
    const groups = $$('.catgroup');
    const navChips = $$('[data-cat-nav]');

    if (input) {
      input.addEventListener('input', () => {
        const q = norm(input.value.trim());
        let totalMatches = 0;

        groups.forEach(g => {
          if (!q) {
            g.hidden = false;
            $$('.catcard', g).forEach(c => { c.hidden = false; });
            totalMatches++;
            return;
          }
          const grpText = norm(g.getAttribute('data-catgroup-search') || '');
          let grpHits = 0;
          $$('.catcard', g).forEach(c => {
            const cardName = norm(c.getAttribute('data-subcat-name') || c.textContent || '');
            const cardHit = cardName.includes(q);
            c.hidden = !cardHit;
            if (cardHit) grpHits++;
          });

          if (grpHits > 0 || grpText.includes(q)) {
            g.hidden = false;
            if (grpHits === 0) {
              $$('.catcard', g).forEach(c => { c.hidden = false; });
            }
            totalMatches++;
          } else {
            g.hidden = true;
          }
        });

        if (empty) empty.hidden = totalMatches > 0;
      });
    }

    // Nav chips click handling
    navChips.forEach(chip => {
      chip.addEventListener('click', (e) => {
        const targetSlug = chip.getAttribute('data-cat-nav');
        navChips.forEach(c => c.classList.remove('is-active'));
        chip.classList.add('is-active');

        if (targetSlug === 'all') {
          groups.forEach(g => { g.hidden = false; });
        } else {
          const targetEl = document.getElementById(`cg-${targetSlug}`);
          if (targetEl) {
            targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        }
      });
    });
  }
}

/* -------------------------------------------------------------------------
   24c. LIVE SEARCH — the hero box suggests businesses/trades as you type
   ---------------------------------------------------------------------- */
function initLiveSearch() {
  // v64: attach to EVERY form marked [data-live-search], not just the hero.
  const forms = $$('[data-live-search]');
  if (!forms.length) return;
  forms.forEach(form => {
    const input = $('input[name="q"]', form);
    const sugg = $('.live-sugg', form);
    if (!input || !sugg) return;
    wireLiveSearch(form, input, sugg);
  });
}

function wireLiveSearch(form, input, sugg) {
  let seq = 0;                       // discard stale async responses
  let activeIdx = -1;
  let items = [];

  const hide = () => { sugg.hidden = true; activeIdx = -1; };

  const render = (list) => {
    items = list; activeIdx = -1;
    sugg.textContent = '';
    if (!list.length) {
      const d = document.createElement('div');
      d.className = 'sugg-empty';
      d.textContent = 'موردی پیدا نشد — Enter بزنید تا همهٔ نتایج را ببینید.';
      sugg.appendChild(d);
      sugg.hidden = false;
      return;
    }
    list.forEach((r, i) => {
      const btn = document.createElement('button');
      btn.type = 'button'; btn.dataset.i = i; btn.setAttribute('role', 'option');
      const sub = r.kind === 'cat' ? 'دستهٔ تخصصی' : (r.cat || '');
      const main = document.createElement('span'); main.className = 'sugg-main';
      const name = document.createElement('span'); name.className = 'sugg-name';
      name.textContent = r.name; main.appendChild(name);
      if (sub) {
        const s = document.createElement('span'); s.className = 'sugg-sub';
        s.textContent = sub; main.appendChild(s);
      }
      btn.appendChild(main);
      sugg.appendChild(btn);
    });
    sugg.hidden = false;
  };

  const move = (d) => {
    const btns = sugg.querySelectorAll('button');
    if (!btns.length) return;
    activeIdx = (activeIdx + d + btns.length) % btns.length;
    btns.forEach((b, i) => b.classList.toggle('is-active', i === activeIdx));
    btns[activeIdx].scrollIntoView({ block: 'nearest' });
  };

  const pick = (r) => {
    if (r.kind === 'cat') {
      location.href = '/businesses?cat=' + encodeURIComponent(r.slug);
    } else {
      location.href = '/b/' + encodeURIComponent(r.slug);
    }
  };

  let timer = null;
  input.addEventListener('input', () => {
    clearTimeout(timer);
    const q = input.value.trim();
    if (q.length < 2) { hide(); return; }
    timer = setTimeout(async () => {
      const my = ++seq;
      try {
        const r = await fetch('/api/search?q=' + encodeURIComponent(q));
        const j = await r.json();
        if (my !== seq) return;        // a newer query already replaced us
        render(j.results || []);
      } catch (e) { hide(); }
    }, 160);
  });

  input.addEventListener('keydown', (e) => {
    if (sugg.hidden) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
    else if (e.key === 'Enter') {
      if (activeIdx >= 0 && items[activeIdx]) {
        e.preventDefault();
        pick(items[activeIdx]);
      }
    } else if (e.key === 'Escape') { hide(); }
  });

  sugg.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-i]');
    if (b && items[+b.dataset.i]) pick(items[+b.dataset.i]);
  });

  document.addEventListener('click', (e) => {
    if (!form.isConnected) return;            // v120: form swapped away — no-op
    if (!form.contains(e.target)) hide();
  });
}

/* -------------------------------------------------------------------------
   25. SUPPORT WIDGET
   Appears after a delay so it reads as help rather than an ad, and only
   once per session — a visitor who dismissed it should not be nagged again.
   ---------------------------------------------------------------------- */
function initPasswordReminder() {
  // Dismisses the "set username & password" nudge for THIS visit only.
  // It is intentionally session-scoped: the reminder must return on the next
  // sign-in until the account actually has a password set.
  const box = $('[data-pw-reminder]');
  if (!box) return;
  const close = $('[data-pw-close]', box);
  if (!close) return;
  close.addEventListener('click', () => {
    box.style.display = 'none';
    try { sessionStorage.setItem('bazarche.v2.pwReminderDismissed', '1'); } catch (e) {}
  });
  // re-show it when the page is re-visited in the SAME session without a
  // password (don't nag on every navigation)
  try {
    if (sessionStorage.getItem('bazarche.v2.pwReminderDismissed') === '1') {
      box.style.display = 'none';
    }
  } catch (e) {}
}

function initSupport() {
  const fab = $('[data-sup-open]');
  const panel = $('#support-panel');
  if (!fab || !panel) return;

  const DISMISS = 'bazarche.v2.support.dismissed';
  let dismissed = false;
  try { dismissed = sessionStorage.getItem(DISMISS) === '1'; } catch (e) {}

  const delay = Math.max(0, parseInt(panel.dataset.supDelay || '60', 10)) * 1000;

  const show = () => { fab.hidden = false; };
  const open = () => {
    panel.hidden = false;
    fab.setAttribute('aria-expanded', 'true');
    const first = $('summary', panel);
    if (first) first.focus();
  };
  const close = () => {
    panel.hidden = true;
    fab.setAttribute('aria-expanded', 'false');
    try { sessionStorage.setItem(DISMISS, '1'); } catch (e) {}
  };

  // Reveal the button on a timer, or immediately if the visitor looks stuck:
  // scrolling to the bottom without clicking anything is a help signal.
  if (!dismissed) {
    setTimeout(show, delay);
    const onScroll = () => {
      const past = window.scrollY + window.innerHeight;
      if (past > document.body.scrollHeight * 0.9) {
        show();
        window.removeEventListener('scroll', onScroll);
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
  } else {
    show();   // they know it exists; keep it available but never auto-open
  }

  fab.addEventListener('click', () => (panel.hidden ? open() : close()));
  $$('[data-sup-close]', panel).forEach(b => b.addEventListener('click', close));

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !panel.hidden) { close(); fab.focus(); }
  });
  document.addEventListener('click', (e) => {
    if (panel.hidden) return;
    if (!panel.contains(e.target) && !fab.contains(e.target)) close();
  });
}

/* ==========================================================================
   QUICK ACTIONS  ·  copy a phone number
   Research on directory behaviour: people copy a number as often as they
   tap it, because they want to save it, paste it into a message, or dial
   from a different SIM. Selecting a phone number by hand on a touch screen
   is genuinely awkward -- "text is too small or fingers are too fat" -- so
   one tap replaces the whole fiddly gesture.
   ========================================================================== */
/* The directory filters fold away on a phone to get results above the fold,
   but a desktop has the room and folding there would just add a click.
   CSS can hide the summary; only JS can set the `open` property. */
function initDirFilters() {
  const d = $('[data-dir-filters]');
  if (!d) return;
  const sync = () => { if (window.matchMedia('(min-width: 861px)').matches) d.open = true; };
  sync();
  window.addEventListener('resize', sync, { passive: true });
}

/* ========================================================================
   v120 — LIVE DIRECTORY SEARCH (جستجو/فیلتر زنده، بدون دکمه و بدون رفرش)
   با هر تایپ (debounce 300ms) یا انتخاب هر فیلتر (مرتب‌سازی، فقط-باز،
   چیپ دسته، صفحه‌بندی) فقط بخش نتایج از سرور گرفته می‌شود (frag=1،
   no-store) و جایگزین می‌گردد؛ URL با history.replaceState همگام می‌ماند
   تا ذخیره/اشتراک جست‌وجو خراب نشود. درخواست‌های قدیمی با AbortController
   لغو می‌شوند (نتیجهٔ دیررس هرگز نتیجهٔ تازه را له نمی‌کند).
   ====================================================================== */
function initLiveDir() {
  const root = $('[data-directory]');
  if (!root || root.dataset.bzLiveDir) return;
  root.dataset.bzLiveDir = '1';
  const form = $('form[data-live-search]', root);
  const results = $('[data-dir-results]', root);
  const input = $('[data-dir-search]', root);
  const sortSel = $('[data-dir-sort]', root);
  const openBox = $('[data-dir-open]', root);
  const catInput = $('input[name="cat"]', root);
  if (!form || !results || !input || !sortSel || !openBox || !catInput) return;

  let timer = null, ctl = null;

  const state = () => {
    const p = new URLSearchParams();
    const qv = input.value.trim();
    if (qv) p.set('q', qv);
    if (catInput.value) p.set('cat', catInput.value);
    if (sortSel.value !== 'featured') p.set('sort', sortSel.value);
    if (openBox.checked) p.set('open', '1');
    const city = new URLSearchParams(location.search).get('city');
    if (city) p.set('city', city);
    return p;
  };

  const run = (immediate) => {
    if (timer) { clearTimeout(timer); timer = null; }
    const go = async () => {
      const p = state();
      if (ctl) ctl.abort();
      ctl = new AbortController();
      results.classList.add('is-updating');
      try {
        const r = await fetch('/businesses?' + p.toString() + '&frag=1',
                               { cache: 'no-store', signal: ctl.signal });
        if (!r.ok) return;
        const html = await r.text();
        if (results.innerHTML === html) return;      // همان نتیجه — DOM دست‌نخورده
        results.innerHTML = html;
        try {
          history.replaceState(null, '', '/businesses' + (p.toString() ? '?' + p.toString() : ''));
        } catch (_) {}
        reinitWidgets();
      } catch (_) { /* لغو/قطع — دفعهٔ بعد */ }
      finally { results.classList.remove('is-updating'); }
    };
    if (immediate) go();
    else timer = setTimeout(go, 300);
  };

  input.addEventListener('input', () => {
    // خالی شدن = فوری (بدون انتظار debounce) تا کاربر بلافاصله لیست کامل را ببیند
    run(!input.value.trim());
  });
  sortSel.addEventListener('change', () => run(true));
  openBox.addEventListener('change', () => run(true));
  form.addEventListener('submit', (e) => { e.preventDefault(); run(true); });

  // چیپ‌های دسته/زیردسته + «حذف فیلتر شهر»: یک دسته‌بندی، سراسر صفحه را عوض
  // می‌کند — چیپ فعال، بنر دسته، زیردسته‌ها، خرده‌نوا و عنوان. آن‌ها در یک
  // fragment نتایج نیستند، پس فیلتر زنده فقط نیمی از صفحه را به‌روز می‌کرد و
  // باقی (مثل is-active روی «همه») کهنه می‌ماند. v146: ناوبری کامل با حفظ
  // جست‌وجو/مرتب‌سازی/فقط-باز/شهرِ جاری؛ سرور صفحهٔ سازگار می‌سازد.
  $$('a.chip, [data-chips] a, .dir-citybar a', root).forEach(a => {
    if (a.getAttribute('href') === '/cities') return;   // صفحهٔ انتخاب شهر — عادی
    a.addEventListener('click', (e) => {
      e.preventDefault();
      const p = state();
      const u = new URL(a.href, location.origin);
      if (u.searchParams.has('cat')) p.set('cat', u.searchParams.get('cat'));
      else p.delete('cat');
      if (u.searchParams.has('q')) p.set('q', u.searchParams.get('q'));
      if (a.closest('.dir-citybar')) p.delete('city');  // «حذف فیلتر شهر»
      p.delete('page');                                 // دستهٔ نو = از صفحهٔ ۱
      location.assign('/businesses?' + p.toString());
    });
  });

  // صفحه‌بندی هم زنده: کلیک روی لینک صفحه داخل نتایج
  results.addEventListener('click', (e) => {
    const a = e.target.closest('a[href^="/businesses?"]');
    if (!a) return;
    e.preventDefault();
    const p = state();
    const page = new URL(a.href, location.origin).searchParams.get('page');
    if (page) p.set('page', page);
    try { history.replaceState(null, '', '/businesses?' + p.toString()); } catch (_) {}
    run(true);
  });

  // v146+v148: آمدن با یک دسته یا جست‌وجو (کلیک روی کارت/چیپ دسته در خانه
  // یا جای دیگر) باید کاربر را پای نتیجهٔ همان دسته برساند — اما نه آن‌قدر
  // پایین که صفحه «به انتهای سایت رسیده» به نظر برسد: اولین کارت را در
  // حدود ۴۵٪ ارتفاع صفحه می‌نشانیم و فوتر بزرگ (فهرست دسته‌ها) را از قاب
  // بیرون نگه می‌داریم. برگشت با Back دست نمی‌خورد.
  const sp0 = new URLSearchParams(location.search);
  if ((sp0.get('cat') || sp0.get('q')) &&
      performance.getEntriesByType('navigation')[0].type !== 'back_forward') {
    const vh = () => window.innerHeight;
    let tries = 0;
    const align = () => {
      const card = results.querySelector('[data-dir-grid] .biz-card') ||
                   results.querySelector('[data-dir-empty]') || results;
      const rr = card.getBoundingClientRect();
      if (!rr || !rr.height) return false;   // هنوز چیده نشده — دوباره تلاش
      const absTop = rr.top + window.scrollY;
      const header = document.querySelector('.site-header, .topbar, header');
      const off = header ? header.getBoundingClientRect().height : 0;
      const maxScroll = Math.max(0, document.documentElement.scrollHeight - vh());
      const footer = document.querySelector('.site-footer');
      const footerAbs = footer ? footer.getBoundingClientRect().top + window.scrollY : null;
      let y = absTop - vh() * 0.45;
      if (footerAbs != null) y = Math.min(y, footerAbs - vh() + 24);
      y = Math.max(0, Math.min(y, maxScroll));
      if (rr.top >= off && rr.top <= vh() * 0.6 && y === 0) return true;
      if (y > 0) window.scrollTo({ top: y, behavior: 'smooth' });
      return true;
    };
    const fire = () => {
      if (tries > 10) return;
      tries++;
      if (!align()) setTimeout(fire, 180);
    };
    setTimeout(fire, 200);
  }
}

function initLiveCatalog() {
  const form = $('form[action="/catalog"][data-live-search]');
  const results = $('[data-catalog-results]');
  if (!form || !results || form.dataset.bzLiveCat) return;
  form.dataset.bzLiveCat = '1';
  const input = $('input[name="q"]', form);
  const kindInput = $('input[name="kind"]', form);
  if (!input || !kindInput) return;

  let timer = null, ctl = null;
  const run = (immediate) => {
    if (timer) { clearTimeout(timer); timer = null; }
    const go = async () => {
      if (ctl) ctl.abort();
      ctl = new AbortController();
      const p = new URLSearchParams();
      const qv = input.value.trim();
      if (qv) p.set('q', qv);
      if (kindInput.value) p.set('kind', kindInput.value);
      results.classList.add('is-updating');
      try {
        const r = await fetch('/catalog?' + p.toString() + '&frag=1',
                              { cache: 'no-store', signal: ctl.signal });
        if (!r.ok) return;
        const html = await r.text();
        results.innerHTML = html;
        try {
          history.replaceState(null, '', '/catalog' + (p.toString() ? '?' + p.toString() : ''));
        } catch (_) {}
      } catch (_) {}
      finally { results.classList.remove('is-updating'); }
    };
    if (immediate) go();
    else timer = setTimeout(go, 300);
  };

  input.addEventListener('input', () => run(!input.value.trim()));
  form.addEventListener('submit', (e) => { e.preventDefault(); run(true); });

  $$('.dir-chips a', form).forEach(a => {
    a.addEventListener('click', (e) => {
      e.preventDefault();
      $$('.dir-chips a', form).forEach(x => x.classList.remove('is-active'));
      a.classList.add('is-active');
      const u = new URL(a.href, location.origin);
      kindInput.value = u.searchParams.get('kind') || '';
      run(true);
    });
  });
}

function initCopyPhone() {
  $$('[data-copy-phone]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const num = btn.dataset.copyPhone || '';
      if (!num) return;
      let ok = false;
      try {
        await navigator.clipboard.writeText(num);
        ok = true;
      } catch (e) {
        // Clipboard API needs a secure context; on plain http (which is how
        // this runs on a local network) it throws, so fall back to the old
        // execCommand path rather than leaving the button dead.
        const ta = document.createElement('textarea');
        ta.value = num;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;top:-1000px;opacity:0';
        document.body.appendChild(ta);
        ta.select();
        try { ok = document.execCommand('copy'); } catch (e2) { ok = false; }
        document.body.removeChild(ta);
      }

      if (ok) {
        const label = $('span', btn);
        const was = label ? label.textContent : '';
        btn.classList.add('is-done');
        if (label) label.textContent = 'کپی شد';
        toast('شمارهٔ تلفن کپی شد: ' + num, 'ok');
        setTimeout(() => {
          btn.classList.remove('is-done');
          if (label) label.textContent = was;
        }, 2000);
      } else {
        toast('کپی نشد — شماره را دستی بردارید: ' + num, 'err');
      }
    });
  });
}

/* ======================================================================
   v68 — divar-style recently viewed + saved searches (localStorage only;
   zero server cost, works offline, Pydroid-safe)
   ====================================================================== */
(() => {
  const faNum = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d]);
  const read = (k) => { try { return JSON.parse(localStorage.getItem(k) || '[]'); } catch (e) { return []; } };
  const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };

  /* ---- recently viewed ---- */
  const slug = document.body.dataset.bizSlug;
  if (slug) {
    const name = (document.title || '').replace(/\s*\|.*$/, '').trim();
    const og = document.querySelector('meta[property="og:image"]');
    const img = og ? og.content || '' : '';
    let r = read('bz_recent');
    r = [{ slug, name, img, ts: Date.now() }, ...r.filter((x) => x.slug !== slug)].slice(0, 8);
    write('bz_recent', r);
  }
  function fillRecent() {
    const wrap = document.getElementById('recent-wrap');
    if (!wrap) return;
    const r = read('bz_recent').filter((x) => x.slug && x.slug !== slug);
    if (r.length) {
      wrap.hidden = false;
      /* v116-audit: DOM built with createElement/textContent — NEVER
         innerHTML. x.name comes from document.title and x.img from
         og:image; both are attacker-influenceable (a business name can
         contain markup) and an innerHTML sink here re-materialises it
         as live HTML = DOM XSS. */
      const row = document.getElementById('recent-row');
      row.textContent = '';
      r.forEach((x) => {
        const nmTxt = String((x && x.name) || '');   // hostile/corrupt storage
        const a = document.createElement('a');
        a.className = 'recent-card card glass';
        a.href = '/b/' + encodeURIComponent(String((x && x.slug) || ''));
        if (x && x.img) {
          const im = document.createElement('img');
          im.src = String(x.img);
          im.alt = '';
          im.loading = 'lazy';
          im.decoding = 'async';
          a.appendChild(im);
        } else {
          const ph = document.createElement('span');
          ph.className = 'recent-ph';
          ph.setAttribute('aria-hidden', 'true');
          ph.textContent = (nmTxt.trim()[0] || '؟');
          a.appendChild(ph);
        }
        const nm = document.createElement('span');
        nm.className = 'recent-name';
        nm.textContent = nmTxt;
        a.appendChild(nm);
        row.appendChild(a);
      });
    }
  }
  fillRecent();

  /* ---- saved searches ---- */
  const saveBtn = document.getElementById('save-search');
  if (!saveBtn) return;
  const params = new URLSearchParams(location.search);
  const q = params.get('q') || '', cat = params.get('cat') || '';
  const cntEl = document.querySelector('[data-dir-count]');
  const count = cntEl ? parseInt(cntEl.textContent.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))), 10) || 0 : 0;

  const render = () => {
    const box = document.getElementById('saved-chips');
    if (!box) return;
    const list = read('bz_saved');
    if (!list.length) { box.hidden = true; box.innerHTML = ''; return; }
    box.hidden = false;
    box.innerHTML = '<span class="saved-title text-xs text-muted">جست‌وجوهای شما:</span>' +
      list.map((s, i) => {
        const href = '/businesses?' + new URLSearchParams(Object.assign({}, s.q && { q: s.q }, s.cat && { cat: s.cat }));
        const label = s.label || s.q || s.cat || 'جست‌وجو';
        return '<span class="chip saved-chip"><a href="' + href + '">' + label +
          (s.count != null ? ' <small class="nums">' + faNum(s.count) + '</small>' : '') +
          '</a><button type="button" data-del="' + i + '" aria-label="حذف ' + label + '">×</button></span>';
      }).join('');
    box.querySelectorAll('[data-del]').forEach((btn) => btn.addEventListener('click', () => {
      const l = read('bz_saved'); l.splice(+btn.dataset.del, 1); write('bz_saved', l); render();
    }));
  };

  if ((q || cat)) {
    const l = read('bz_saved');
    const hit = l.find((s) => (s.q || '') === q && (s.cat || '') === cat);
    if (hit) { hit.count = count; write('bz_saved', l); }
  }
  if (!q && !cat) saveBtn.hidden = true;   // nothing to save on a bare list
  const onSave = () => {
    if (!q && !cat) return;
    const cEl = document.querySelector('[data-dir-count]');   // v120: count live at click
    const c = cEl ? parseInt(cEl.textContent.replace(/[۰-۹]/g,
        (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))), 10) || 0 : 0;
    // v150: on a category page the fold no longer carries category chips —
    // take the Persian name from the banner heading instead of the slug.
    const act = document.querySelector('form.dir-toolbar .dir-chips a.chip.is-active span');
    const bannerH = document.querySelector('.cat-banner h1');
    const label = q || (act ? act.textContent.trim() : '')
      || (bannerH ? bannerH.textContent.trim() : '')
      || cat || 'جست‌وجو';
    const l = read('bz_saved').filter((s) => !((s.q || '') === q && (s.cat || '') === cat));
    l.unshift({ q, cat, label, count: c, ts: Date.now() });
    write('bz_saved', l.slice(0, 6));
    render();
  };
  const bindSave = () => {
    const btn = document.getElementById('save-search');
    if (!btn || btn.dataset.bzSavedBound) return;
    btn.dataset.bzSavedBound = '1';
    btn.addEventListener('click', onSave);
  };
  bindSave();
  render();
  /* v120: بعد از سواپِ زنده، این بلوکها دوباره بسته/پر میشوند */
  window.addEventListener('bz:needs-recent', () => { fillRecent(); bindSave(); render(); });
})();

/* ---- v90: PWA install prompt (beforeinstallprompt) ----
   Shows a small dismissible banner only when the browser deems the site
   installable and the user hasn't already installed or dismissed it. */
(() => {
  const KEY = 'bz-install-dismissed';
  let deferred = null, bar = null;
  if (window.matchMedia('(display-mode: standalone)').matches || navigator.standalone) return;
  function show() {
    if (!deferred || bar || localStorage.getItem(KEY)) return;
    bar = document.createElement('div');
    bar.className = 'pwa-install';
    bar.setAttribute('role', 'region');
    bar.setAttribute('aria-label', 'نصب اپلیکیشن');
    bar.innerHTML = '<div class="pwa-install-txt"><strong>اپ دست گیر را نصب کن</strong>' +
      '<span>دسترسی سریع‌تر، مثل یک اپ واقعی</span></div>';
    const go = document.createElement('button');
    go.className = 'btn btn-primary btn-sm pwa-install-go'; go.textContent = 'نصب';
    const x = document.createElement('button');
    x.className = 'pwa-install-x'; x.setAttribute('aria-label', 'بستن'); x.textContent = '✕';
    bar.append(go, x);
    document.body.appendChild(bar);
    requestAnimationFrame(() => bar && bar.classList.add('show'));
    setTimeout(hide, 5000);   // v288: محو خودکار پس از ۵ ثانیه (بستن دستی = برای همیشه)
    go.addEventListener('click', async () => {
      if (!deferred) return;
      try { deferred.prompt(); const r = await deferred.userChoice; if (r && r.outcome === 'accepted') hide(); } catch (e) {}
      deferred = null; hide();
    });
    x.addEventListener('click', () => { try { localStorage.setItem(KEY, '1'); } catch (e) {} hide(); });
  }
  function hide() { if (!bar) return; bar.classList.remove('show'); const b = bar; bar = null; setTimeout(() => b.remove(), 260); settle(); }
  /* v288: به حبابِ دعوتِ دستیار خبر می‌دهد که prompt نصب تمام شده تا دعوت فقط
     پس از محو/بسته‌شدن این نوار ظاهر شود. */
  let settled = false;
  function settle() { if (settled) return; settled = true; try { window.dispatchEvent(new CustomEvent('bz:install-settled')); } catch (e) {} }
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e; setTimeout(show, 500); });   // v288: اول از همه
  window.addEventListener('appinstalled', () => { deferred = null; hide(); });
  setTimeout(() => { if (!bar) settle(); }, 4000);   // اگر مرورگر prompt نصب نداد
})();

/* ---- v91: light/dark theme toggle ---- */
(() => {
  const root = document.documentElement;
  const KEY = 'bz-theme';
  const host = document.querySelector('.header-actions');
  if (!host) return;
  const SUN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
  const MOON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z"/></svg>';
  const btn = document.createElement('button');
  btn.className = 'btn-icon theme-toggle';
  btn.type = 'button';
  btn.setAttribute('aria-label', 'تغییر پوستهٔ روشن و تاریک');
  btn.title = 'پوستهٔ روشن / تاریک';
  const isLight = () => root.getAttribute('data-theme') === 'light';
  // v288: the icon shows the mode tapping will switch TO (sun at night, moon in
  // day), matching the production screenshots; tapping flips the theme.
  // v109: the swap itself is animated — old glyph spins/fades out, the new
  // one settles in, matching the 420ms colour fade of the whole page.
  const paint = () => { btn.innerHTML = isLight() ? MOON : SUN; };
  const paintSwap = () => {
    btn.classList.add('is-swapping');
    setTimeout(() => {
      paint();
      requestAnimationFrame(() => btn.classList.remove('is-swapping'));
    }, prefersReduced() ? 0 : 190);
  };
  btn.addEventListener('click', () => {
    const next = isLight() ? 'dark' : 'light';
    root.classList.add('theme-fade');                 // smooth colour/font fade
    root.setAttribute('data-theme', next);
    try { localStorage.setItem(KEY, next); } catch (e) {}
    paintSwap();
    setTimeout(() => root.classList.remove('theme-fade'), 340);
  });
  host.prepend(btn);
  paint();
})();
