# PANEL-PLAN — ساختار و نقشهٔ پنل مدیریتی در v288

> این سند «چه صفحه‌ای برای چه کاری هست و چطور نگهبانی می‌شود» را می‌گوید. وضعیت لحظه‌ای پروژه: `docs/collaboration/CURRENT-STATE.md`.
> دسترسی به پنل: `/panel?key=…` (کلید لینک) + رمز اختیاری PBKDF2 + `panel_allow_ips` اختیاری. قانون جاری: **دسترسی مدیر حداکثری است و موعظهٔ امنیتی به مدیر ممنوع.**

---

## ۱) فهرست واقعی صفحه‌های پنل

از `tools/mobile_audit.py` (همین بسته) — ۲۴ صفحهٔ پنل که روی ۴ دستگاه موبایل ممیزی می‌شوند:

| گروه | صفحه‌ها |
|---|---|
| خانه و محتوا | `/panel` · `/panel/businesses` · `/panel/reviews` · `/panel/bookings` · `/panel/customers` · `/panel/orders` |
| گفت‌وگو و پشتیبانی | `/panel/chats` · `/panel/tickets` · `/panel/messages` · `/panel/inquiries` |
| مالکیت و گزارش | `/panel/claims` · `/panel/reports` · `/panel/edits` · `/panel/alerts` · `/panel/subscriptions` · `/panel/owners` |
| جست‌وجو و تنظیمات | `/panel/search?q=` · `/panel/settings` · `/panel/appearance` · `/panel/plans` |
| عملیات | `/panel/trash` · `/panel/insights` · `/panel/moderation` · `/panel/audit` |

صفحه‌های امنیتی/عملیاتی که در فهرست ممیزی موبایل نیستند ولی فعال‌اند:

| صفحه | نقش |
|---|---|
| `/panel/spam` | کنسول ضداسپم: کاشی‌های زندهٔ شمار per-کنش، ویرایش سیاست (`policy`/`policy-reset`)، ban/lift دستی، ۵۰ رویداد اخیر |
| `/panel/traffic` | سپر درخواستی: گزارش زندهٔ نرخ/اسکنر/UA و برداشتن مسدودی |
| `/panel/assistant` | دستیار: سهمیه‌ها (`ai_quota_free/plus/pro`)، «مدل برای مهمان‌ها» (`ai_guest_model`)، دکمهٔ «هوش سایت»، آخرین خطای مدل |

## ۲) اصل‌های طراحی پنل (قواعد جاری)

1. **سرور دیوار است، UI تعارف.** هر قابلیت قفل‌شده باید حتی با درخواست دست‌ساز هم رد شود (`tools/test_gates.py` همین را می‌آزماید: «قفل قابلیت‌ها واقعی است نه تزئینی» — هر بازکردن باید فوراً اثر کند).
2. **هر اکشن پنل باید واقعاً پایگاه داده را عوض کند**، نه فقط ۳۰۳ برگرداند — `tools/test_actions.py` داده را بعد از درخواست می‌خواند.
3. **noindex دوگانه:** هم `meta` و هم هدر `X-Robots-Tag: noindex, nofollow` روی همهٔ صفحه‌های پنل (برای خزنده‌هایی که `robots.txt` را رد می‌کنند).
4. **کلید در URL + رمز اختیاری + محدودیت IP**؛ کلید/رمز/محدودیت IP/بات مدیر همه از بات مدیر فوراً قابل تغییرند.
5. **ممیزی نوشتن:** هر تغییر حساس در جدول `audit` با `action`/`detail` ثبت می‌شود؛ مقدار راز فقط `<مقدار پنهان>`.
6. **صف تعدیل:** محتوای `spam_flag=1` (نظر/پرسش/تیکت/کالا) در `/panel/moderation` با «رفع نگه‌بررسی» آزاد می‌شود؛ شمارش زنده با `antispam.held_counts()`.
7. **موبایل اول:** ارتفاع هدف قابل لمس ≥ ۴۳٫۵px — `mobile_audit.py` با `TAP_JS` هر `.btn/.chip/.btn-icon/.panel-nav a/.pager a/.tk-row/.thread-row` را می‌سنجد.
8. **دادهٔ نمونه با برچسب:** `tools/seed_demo.py` می‌سازد و با `--clear` کامل پاک می‌کند؛ `/panel/demo` هم همین را از UI انجام می‌دهد (با سطل always — سناریوی نشست دزدیده‌شده).

## ۳) نگهبان‌های پنل

| نگهبان | چه می‌سنجد |
|---|---|
| `tools/test_panel_security.py` | مرز دسترسی، نشت، کلید/رمز، IP allow-list |
| `tools/test_panel_robust.py` | ورودی خراب/سنگین بدون ۵۰۰ |
| `tools/test_panel_ux.py` | a11y/تعامل (Playwright) |
| `tools/test_panel_mod.py` | بن/بلاک، فیلتر + CSV ممیزی، صف تعدیل |
| `tools/test_gates.py` | قفل قابلیت‌ها واقعی است + بازکردن فوری اثر می‌کند |
| `tools/test_actions.py` | هر اکشن واقعاً DB را عوض می‌کند |
| `tools/mobile_audit.py` | ۲۴ صفحه × ۴ دستگاه (۳۶۰/۳۹۰/۴۱۲/۷۶۸) |
| `tools/bench_panel.py` | کارایی صفحه‌های پنل |
| `tools/test_coverage_guard.py` | مسیرهای POST پنل با گیت کلید + استثناهای سخت‌سازی شده |

## ۴) کارهای باز پنل

- اتصال پلن‌های اشتراک به پرداخت واقعی (الان چرخهٔ پولی بسته نیست — `ROADMAP.md` بند ۴/۱).
- گزارش‌گیری تحلیلی مقایسه‌ای برای دکان‌دار (بازدید → تماس → سفارش) به‌جای شمار خام در `/panel/insights`.
- تنظیم آستانه‌های `POLICY` با دادهٔ واقعی ترافیک تولید (از `/panel/spam` بدون استقرار کد ممکن است).
