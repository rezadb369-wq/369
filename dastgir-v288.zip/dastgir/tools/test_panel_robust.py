# -*- coding: utf-8 -*-
"""
قفل مرحلهٔ م۲ (استحکام پنل) — بازسازی فاز ۵ (۲۰۲۶-۰۸-۳۱)

  §R1  جاروی همهٔ صفحات GET پنل (۷۶ مسیر ثابت + ۴۰ الگوی داینامیک با idهای
       خصمانه 0/1/999999999) — انتظار: هیچ 500/502؛ فقط 200/303/400/404.
  §R2  فازر پارامترهای رشتهٔ کوئری (page منفی/غول/غیرعددی، q/sort/status/cat
       نامعتبر) روی صفحات فهرست — انتظار: هیچ 500.
  §R3  فازر POSTهای پنل با بدنه‌های خصمانه (id ناموجود، رشتهٔ خالی، رشتهٔ
       ۱۰۰KB، unicode سنگین) — انتظار: هیچ 500.
  §R4  کناری XSS پایدار: عنوانِ فهرست برتر با payload → نمایش در /panel/lists
       باید escape شده باشد (نویسهٔ < خام فقط داخل text سالم).
  §R5  لبه‌های HTTP: کوئری زباله‌باایت، هدر عظیم، POST بدون content-type.

    BZ=http://127.0.0.1:8080 python3 tools/test_panel_robust.py
"""

import os
import re
import sys
import http.cookiejar
import urllib.parse
import urllib.request
import urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db          # noqa: E402

# v288 (دستور مدیر): این سوئیت دربارهٔ «کلید دوم» نیست. به‌جای حذفِ چک‌ها،
# صریحاً اعلام می‌کند که آن عامل اینجا آزموده نمی‌شود — خودش به‌طور کامل در
# test_panel_otp_v283 (۳۵ چک) و test_panel_otp_flow_v288 (۱۳ چک) پوشش دارد.
# توضیح کامل در tools/_testenv.py
db.init()
db.panel_otp_set(False)

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
PREFIX = "robust-m2"

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


class Client:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()

    def _op(self, follow):
        if follow:
            return urllib.request.build_opener(
                urllib.request.HTTPCookieProcessor(self.jar))
        class NR(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *a, **k):
                return None
        return urllib.request.build_opener(
            NR, urllib.request.HTTPCookieProcessor(self.jar))

    def get(self, path, follow=True, raw=False):
        r = urllib.request.Request(BASE + path, headers={"User-Agent": "bz-m2"})
        try:
            resp = self._op(follow).open(r, timeout=25)
            data = resp.read()
            return resp.getcode(), (data if raw
                                    else data.decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            data = e.read()
            return e.code, (data if raw else data.decode("utf-8", "replace"))
        except Exception as e:
            return 0, str(e)

    def post(self, path, data, follow=True):
        body = urllib.parse.urlencode(data, doseq=True).encode()
        r = urllib.request.Request(BASE + path, data=body, headers={
            "User-Agent": "bz-m2",
            "Content-Type": "application/x-www-form-urlencoded"})
        try:
            resp = self._op(follow).open(r, timeout=25)
            return resp.getcode(), resp.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")
        except Exception as e:
            return 0, str(e)


def main():
    tok = db.owner_token()
    assert tok, "این تست به کلید مالک نیاز دارد"
    c = Client()
    c.get(f"/panel?key={urllib.parse.quote(tok)}", follow=False)  # mint session

    import subprocess
    src = subprocess.run(
        ["grep", "-o", '"/panel/[a-z0-9/_-]*"',
         os.path.join(HERE, "..", "server", "app.py")],
        capture_output=True, text=True).stdout
    statics = sorted({p.strip('"') for p in src.splitlines()
                      if "/new" not in p and not p.endswith(
                          ("/export", "/full", "/import", "/login",
                           "/logout"))})

    # ------------------------------------------------------------- §R1
    head("م۲/R1 — جاروی صفحات GET پنل (بدون 500)")
    bad_codes = {}
    n_pages = 0
    for p in statics:
        if p in ("/panel/",):        # rstrip('/') in router → "/panel"
            continue
        code, _ = c.get(p)
        n_pages += 1
        if code >= 500 or code == 0:
            bad_codes[p] = code
    dyn = ["business", "category", "chat", "ticket", "order", "customer",
           "review", "booking", "report", "claim", "inquiry", "post",
           "question", "message", "owner", "plan", "badge", "ad", "event",
           "list", "edit", "story", "subscription", "unlock", "gallery",
           "catalog", "trash"]
    for seg in dyn:
        for bad_id in ("0", "999999999"):
            path = f"/panel/{seg}/{bad_id}"
            code, _ = c.get(path)
            n_pages += 1
            if code >= 500 or code == 0:
                bad_codes[path] = code
    check(f"{n_pages} صفحهٔ GET جارو شد — هیچ 500/قطعی ندارد",
          not bad_codes, str(bad_codes)[:200])

    # ------------------------------------------------------------- §R2
    head("م۲/R2 — فازر پارامترهای کوئری")
    list_pages = ["/panel/businesses", "/panel/reviews", "/panel/bookings",
                  "/panel/customers", "/panel/orders", "/panel/chats",
                  "/panel/posts", "/panel/messages", "/panel/claims",
                  "/panel/inquiries", "/panel/tickets", "/panel/audit",
                  "/panel/follows", "/panel/edits", "/panel/trash"]
    qs_bad = {}
    for page in list_pages:
        for q in ("?page=-1", "?page=0", "?page=999999999", "?page=abc",
                  "?page=999999999999999999999999",
                  "?q=%3Cscript%3Ealert(1)%3C%2Fscript%3E",
                  "?sort=bogus&status=bogus&cat=bogus",
                  "?status=" + "x" * 3000):
            code, _ = c.get(page + q)
            if code >= 500 or code == 0:
                qs_bad[f"{page}{q[:30]}"] = code
    check(f"{len(list_pages) * 8} کوئری خصمانه — هیچ 500 ندارد",
          not qs_bad, str(qs_bad)[:200])
    code, body = c.get("/panel/businesses?page=1")
    check("صفحهٔ فهرست بعد از فازر هنوز سالم است", code == 200, f"code={code}")

    # ------------------------------------------------------------- §R3
    head("م۲/R3 — فازر POSTهای پنل")
    posts = [
        ("/panel/business/999999999/status", {"status": "published"}),
        ("/panel/business/999999999/toggle", {}),
        ("/panel/business/999999999/delete", {}),
        ("/panel/chat/999999999/status", {"status": "open"}),
        ("/panel/order/999999999/cancel", {}),
        ("/panel/unlock/999999999",
         {"action": "save", "feat": ["catalog"]}),
        ("/panel/trash/999999999/restore", {}),
        ("/panel/customer/999999999/delete", {}),
        ("/panel/review/999999999",
         {"action": "approve"}),
        ("/panel/areas/rename", {"old": "", "new": ""}),
        ("/panel/areas/rename", {"old": "x" * 5000, "new": "y" * 5000}),
        ("/panel/list/new", {"title": "ز" * 4000, "kind": "manual"}),
        ("/panel/list/new", {"title": ""}),
        ("/panel/businesses/bulk", {"ids": "not-ids", "action": "publish"}),
        ("/panel/businesses/bulk", {"ids": ["999999999"], "action": "bogus"}),
        ("/panel/badges/grant", {"bid": "abc", "badge": "xyz"}),
        ("/panel/broadcast", {"text": ""}),
        ("/panel/editor", {"content": "ز" * 60000}),
        ("/panel/settings", {"site_name": "تست م۲", "features_tab": "1"}),
    ]
    # These POSTs touch REAL state (/panel/settings wipes toggles when the
    # checkboxes are absent; /panel/editor rewrites hero + pages). Snapshot
    # everything they can reach and restore right after — the trap that made
    # the original v117 panel battery flaky (settings pollution).
    snap = dict(db.get_settings())
    snap_pages = {slug: db.get_page(slug) for slug in ("about", "rules")}
    bad_posts = {}
    for path, data in posts:
        code, _ = c.post(path, data, follow=False)
        if code >= 500 or code == 0:
            bad_posts[f"{path} {list(data)[:1]}"] = code
    db.set_settings(snap)
    for slug, p in snap_pages.items():
        db.save_page(slug, p.get("title") or "", p.get("body") or "")
    check(f"{len(posts)} POST خصمانه — هیچ 500 ندارد", not bad_posts,
          str(bad_posts)[:300])
    check("state پس از فازر به‌طور کامل بازیابی شد",
          db.get_settings().get("site_name") == snap.get("site_name")
          and db.get_settings().get("reg_open") == snap.get("reg_open"))

    # ------------------------------------------------------------- §R4
    head("م۲/R4 — کناری XSS پایدار در پنل")
    payload = '"><script>alert("m2")</script> <img src=x onerror=alert(2)>'
    title = f"{PREFIX} {payload}"
    code, _ = c.post("/panel/list/new", {"title": title, "kind": "manual"},
                     follow=False)
    check("ایجاد فهرست با payload ممکن است (303)", code == 303, f"code={code}")
    code, page = c.get("/panel/lists")
    check("فهرست‌ها بعد از payload باز است", code == 200, f"code={code}")
    check("payload در HTML خام (XSS) نیست", "<script>alert" not in page)
    # the escaped TEXT may legitimately contain the word "onerror" — what
    # must never appear is a live tag/attribute (raw "<img" / "<script").
    check("تگ img/onerror به‌صورت خام تزریق نشده",
          "<img src=x" not in page and "<script>alert" not in page)
    check("payload به‌صورت escape شده دیده می‌شود", "&lt;script&gt;" in page
          or "\u200c" in page or page.count("robust-m2") >= 1)
    # dashboard & cmdk index must not carry it raw either
    code, dash = c.get("/panel")
    check("داشبورد هم payload خام ندارد", "<script>alert" not in dash)

    # cleanup: delete every list we made in this run
    con = db.connect()
    rows = con.execute(
        "SELECT id FROM toplists WHERE title LIKE ?", (PREFIX + "%",)
    ).fetchall()
    for r in rows:
        c.post(f"/panel/list/{r['id']}/delete", {}, follow=False)
    con.close()
    check(f"پاکسازی: {len(rows)} فهرست آزمایشی حذف شد", True)

    # ------------------------------------------------------------- §R5
    head("م۲/R5 — لبه‌های HTTP")
    code, _ = c.get("/panel/businesses?q=" + urllib.parse.quote(
        "\ufffd\ufffd\x00zz"))
    check("کوئری با بایت‌های زباله → بدون 500", 0 < code < 500, f"code={code}")
    r = urllib.request.Request(
        BASE + "/panel/businesses",
        data=b"title=zz",
        headers={"User-Agent": "bz-m2"})   # no content-type at all
    try:
        resp = c._op(False).open(r, timeout=25)
        code5 = resp.getcode()
    except urllib.error.HTTPError as e:
        code5 = e.code
    except Exception:
        code5 = 0
    check("POST بدون Content-Type → بدون 500", 0 < code5 < 500, f"code={code5}")
    code, _ = c.get("/panel/businesses?q=" + "z" * 20000)
    check("کوئری ۲۰هزار نویسه‌ای → بدون 500", 0 < code < 500, f"code={code}")
    # must be probed WITHOUT the admin session cookie (a fresh client)
    c9 = Client()
    code, _ = c9.get("/panel?key=" + "A" * 5000)
    check("کلید ۵هزار نویسه‌ای → 403 تمیز (بدون 500)", code == 403,
          f"code={code}")

    # ------------------------------------------------------------- ⨯
    print(f"\n\033[1m{ok_n} passed, {bad_n} failed\033[0m")
    if FAILS:
        print("\n".join("  ✗ " + f for f in FAILS))
        sys.exit(1)


if __name__ == "__main__":
    main()
