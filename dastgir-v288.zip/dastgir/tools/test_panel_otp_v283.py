#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v283 (دستور مدیر): «کلید دوم» — کدِ یکبارمصرفِ پنل که فقط از ربات بله صادر می‌شود.

چرا این تست وجود دارد (ضدِ «موفقیت جعل»):
  1) کد باید واقعاً تصادفی و از الفبای بدون‌ابهام باشد.
  2) فقط هشِ نمک‌دار ذخیره شود — هرگز متنِ کد.
  3) یکبارمصرف باشد؛ بار دوم حتی با کدِ درست رد شود.
  4) منقضی شود.
  5) با سقفِ تلاش، در همان تلاشِ آخر نابود شود.
  6) مقایسه ثابت‌زمان باشد و هیچ نشتیِ زمانی/متنی به بیرون نرود.
  7) سطحِ قفلِ نشست: رمز و کد، هر کدام جای درست خودشان را بگیرند.

این سوئیت فقط کتابخانهٔ استاندارد و یک دیتابیس موقت استفاده می‌کند.
"""
import os
import re
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='otp-v283-')
os.environ['BZ_DATA_DIR'] = TMP
sys.path.insert(0, str(ROOT / 'server'))

import db  # noqa: E402

db.init()
n = 0


def ck(ok, label):
    global n
    assert ok, label
    n += 1
    print('  ✓', label)


# ================= 1. صدور: تصادفی، بدون ابهام، با گروه‌بندی ==============
c1 = db.panel_otp_issue()
raw1 = c1.replace('-', '')
ck(len(raw1) == db.PANEL_OTP_LEN, f'کد {db.PANEL_OTP_LEN} حرف است')
ck(c1.count('-') == 2 and all(len(p) == 4 for p in c1.split('-')),
   'نمایش به‌صورت سه گروه چهارتایی است')
ck(set(raw1) <= set(db.OTP_ALPHABET), 'فقط از الفبای بدون‌ابهام استفاده شده')
# 0/O و 1/I/l حذف شده باشند تا از روی صفحهٔ موبایل اشتباه خوانده نشود
ck(not (set(db.OTP_ALPHABET) & set('01IOl')), 'حروف/ارقامِ مشابه (0/O/1/I/l) حذف شده‌اند')

c2 = db.panel_otp_issue()
ck(c2 != c1, 'دو صدورِ پشت‌سرهم دو کدِ متفاوت می‌دهند')
ck(db.panel_otp_verify(c1)[0] is False, 'صدورِ جدید، کدِ قبلی را باطل می‌کند')

# ================= 2. هیچ متنِ کدی ذخیره نمی‌شود ==========================
code = db.panel_otp_issue()
plain = code.replace('-', '')
st = db.get_settings()
ck(not any(plain in str(v) for v in st.values() if v),
   'هیچ متنِ کدی در تنظیمات ذخیره نشده (فقط هش)')
ck(st.get('panel_otp_hash', '').startswith('pbkdf2$'),
   'هش از جنس pbkdf2 است')
ck(int(st['panel_otp_hash'].split('$')[1]) == db.PBKDF2_ITERS,
   f'هزینهٔ هش = {db.PBKDF2_ITERS} تکرار (کف OWASP)')
ck(len(bytes.fromhex(st['panel_otp_hash'].split('$')[2])) >= 8,
   'هش نمک‌دار است (salt تصادفی)')

# ================= 3. تصدیقِ درست + یکبارمصرف =============================
ck(db.panel_otp_verify(code) == (True, 'ok'), 'کدِ درست (با خط‌تیره) پذیرفته می‌شود')
ck(db.panel_otp_verify(code) == (False, 'none'), 'بارِ دوم رد می‌شود — یکبارمصرف')
ck(db.panel_otp_state()['live'] is False, 'پس از مصرف، رکورد پاک شده')

# ورودیِ بی‌قاعده هم پذیرفته شود (حروف کوچک، فاصله، بدون خط‌تیره)
c3 = db.panel_otp_issue()
ck(db.panel_otp_verify(c3.lower().replace('-', ' ')) == (True, 'ok'),
   'ورودی با حروف کوچک/فاصله هم پذیرفته می‌شود')

# ================= 4. انقضا ==============================================
c4 = db.panel_otp_issue(ttl=1)
time.sleep(1.3)
ck(db.panel_otp_verify(c4) == (False, 'expired'), 'کدِ منقضی رد می‌شود')
ck(db.panel_otp_state()['live'] is False, 'کدِ منقضی پاک شده')

# ================= 5. سقفِ تلاش: در همان تلاشِ آخر نابود شود ==============
c5 = db.panel_otp_issue()
BAD = 'AAAA-AAAA-AAAA'
for _ in range(db.PANEL_OTP_TRIES - 1):
    r = db.panel_otp_verify(BAD)
ck(r == (False, 'wrong'), 'کدِ غلط رد می‌شود')
ck(db.panel_otp_state()['tries_left'] == 1, 'شمارندهٔ تلاش کم می‌شود')
ck(db.panel_otp_verify(BAD) == (False, 'locked'),
   'در تلاشِ آخر، قفل می‌شود (نه یکی بیشتر)')
ck(db.panel_otp_verify(c5) == (False, 'none'),
   'پس از قفل، خودِ کدِ درست هم مرده است')

# ================= 6. بدون کدِ زنده، هیچ ورودی راه نمی‌دهد ================
for probe in ('', '   ', '-----', 'A', 'x' * 4000):
    ck(db.panel_otp_verify(probe)[0] is False, f'ورودیِ هرز ({probe[:6]!r}…) رد می‌شود')

# ================= 7. سطحِ قفلِ نشست =====================================
db.set_setting('owner_pass_hash', '')
db.set_setting('panel_otp_on', '1')
ck(db.panel_otp_on() is True, 'کلید دوم پیش‌فرض روشن است')
ck(db.panel_second_factor_on() is True, 'یک عامل دوم هست')
ck(db.panel_lock_on_entry() == db.PANEL_LOCK_OTP,
   'بدون رمز + کد روشن ⇒ نشستِ تازه فقط بدهکارِ کد است')

db.set_setting('panel_otp_on', '0')
ck(db.panel_otp_on() is False, 'خاموش‌کردن با تنظیم ممکن است')
ck(db.panel_lock_on_entry() == db.PANEL_LOCK_NONE, 'هیچ عامل دومی ⇒ بدون قفل')

db.set_setting('panel_otp_on', '1')
db.set_owner_pass('secret123')
ck(db.panel_lock_on_entry() == db.PANEL_LOCK_PASS,
   'با رمز ⇒ ابتدا رمز، سپس کد (سطح ۲)')
db.set_owner_pass('')
ck(db.panel_lock_on_entry() == db.PANEL_LOCK_OTP, 'پاک‌کردنِ رمز ⇒ فقط کد می‌ماند')

# ================= 8. state هیچ‌وقت خودِ کد را لو نمی‌دهد =================
c6 = db.panel_otp_issue()
blob = repr(db.panel_otp_state())
ck(c6.replace('-', '') not in blob and c6 not in blob, 'state هرگز متنِ کد را برنمی‌گرداند')
ck(re.fullmatch(r'[0-9A-Z\-]+', c6), 'قالبِ کد قابل‌تایپ است')

# ================= 9. هیچ خروجیِ زمانی/متنی به بیرون ======================
db.panel_otp_clear()
ck(db.panel_otp_verify('ANY-CODE-HERE') == (False, 'none'),
   'بدون کدِ زنده، مسیر بسته است')

print(f'\n  {n} checks passed — panel second key (v283) OK')
