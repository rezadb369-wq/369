#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v288 (دستور مدیر): کلید دومِ پنل — صدور و مدیریت از خط فرمانِ سرور.

این ابزار «راهِ رهایی» است: اگر ربات بله قطع باشد (نصبِ تازه، توکنِ منقضی،
وب‌هوکِ خراب)، کلید دوم نباید مدیر را از پنلِ خودش قفل کند. پس هر کاری که
ربات می‌کند، از روی سرور هم شدنی است — و برعکس، دور زدنِ عمدیِ کلید دوم
نیاز به دسترسیِ پوسته دارد (کسی که پوسته دارد، از قبل صاحب سرور است).

کاربرد:
    python3 tools/panel_key.py            # یک کدِ یکبارمصرف بساز و نمایش بده
    python3 tools/panel_key.py on         # کلید دوم را روشن کن
    python3 tools/panel_key.py off        # کلید دوم را خاموش کن
    python3 tools/panel_key.py status     # وضعیت: روشن/خاموش، کدِ زنده، زمانِ باقی‌مانده

نکتهٔ امنیتی: خروجیِ این فرمان حاویِ کدِ خام است. آن را در تاریخچهٔ ترمینال،
لاگ یا تیکت نگذارید.

همتای بات: فرمانِ «کلید دوم» در ربات مدیریت بله.
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))
DEFAULT_DATA = os.environ.get("BZ_DATA_DIR") or "/opt/dastgir/data"
os.environ.setdefault("BZ_DATA_DIR", DEFAULT_DATA)

import db  # noqa: E402


def human(sec):
    sec = int(max(0, sec))
    return f"{sec // 60}:{sec % 60:02d}"


def main():
    db.init()
    arg = (sys.argv[1] if len(sys.argv) > 1 else "").strip().lower()

    if arg == "on":
        db.panel_otp_set(True)
        print("کلید دوم روشن شد: هر ورودِ تازه به پنل، کدِ یکبارمصرف می‌خواهد.")
        return 0
    if arg == "off":
        db.panel_otp_set(False)
        print("کلید دوم خاموش شد: ورود فقط با کلیدِ پیوندِ پنل"
              + (" و رمز" if db.owner_pass_set() else "") + ".")
        return 0
    if arg == "status":
        st = db.panel_otp_state()
        print(f"کلید دوم        : {'روشن' if st['on'] else 'خاموش'}")
        print(f"کدِ زنده        : {'هست' if st['live'] else 'نیست'}")
        if st["live"]:
            print(f"زمانِ باقی‌مانده : {human(st['seconds_left'])}")
            print(f"تلاشِ باقی‌مانده  : {st['tries_left']}")
        print(f"سطحِ قفلِ ورود   : {db.panel_lock_on_entry()} "
              f"(۰=بدون قفل، ۱=کد، ۲=رمز سپس کد)")
        return 0
    if arg in ("", "new", "issue"):
        if not db.panel_otp_on():
            print("کلید دوم خاموش است؛ کدی صادر نمی‌شود.")
            print("برای روشن‌کردن: python3 tools/panel_key.py on")
            return 1
        code = db.panel_otp_issue()
        # Note: no plaintext is stored anywhere — db keeps only a salted hash,
        # so this one print-out is the single moment the code ever exists.
        print("\n  کلید دومِ پنل")
        print(f"  {code}\n")
        print(f"  • {db.PANEL_OTP_TTL // 60} دقیقه معتبر است")
        print(f"  • یکبارمصرف: پس از ورود پاک می‌شود")
        print(f"  • {db.PANEL_OTP_TRIES} بار اشتباه ⇒ کد می‌سوزد")
        print("  • همین را در صفحهٔ ورودِ پنل وارد کنید\n")
        return 0

    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main())
