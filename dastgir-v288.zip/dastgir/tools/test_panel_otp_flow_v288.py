#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v288 (دستور مدیر): «کلید دوم» — مسیرِ کاملِ ورودِ دوعاملی به پنل.

نیاز به محیط: سرور زنده روی http://127.0.0.1:8080 با BZ_DATA_DIR مشترک.
(رد شدنِ این سوئیت بدون سرور به معنی خرابی کد نیست — مثل سایر سوئیت‌های
مسیرمحور.)

مسیرِ آزموده‌شده:
  بدون کلید → دروازهٔ ورود
  با کلید   → دروازهٔ کلید دوم (و تکرار نشدنِ کلید در HTML)
  بدون کدِ زنده → رد
  کدِ درست  → پنل
  همان کد دوباره → رد (یکبارمصرف)
  کدِ غلط   → شمارنده کم می‌شود → در تلاشِ آخر می‌سوزد
  خاموش‌کردنِ کلید دوم → بازگشت به رفتارِ تک‌عاملی
"""
import http.cookiejar
import os
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
import sys
sys.path.insert(0, str(ROOT / "server"))
os.environ.setdefault("BZ_DATA_DIR", os.environ.get("BZ_DATA_DIR") or "/tmp/e2edata")

import db
db.init()
db.set_setting('owner_pass_hash','')      # no password -> OTP is the ONLY 2nd factor
db.set_setting('panel_otp_on','1')
TOK = db.owner_token()
BASE='http://127.0.0.1:8080'

cj = http.cookiejar.CookieJar()
op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
op.addheaders=[('User-Agent','e2e')]

def get(path, code_only=True):
    try:
        r = op.open(BASE+path, timeout=10)
        return r.getcode(), r.read().decode('utf-8','replace')
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode('utf-8','replace')

def post(path, data):
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(BASE+path, data=body,
        headers={'Content-Type':'application/x-www-form-urlencoded'})
    try:
        r = op.open(req, timeout=10); return r.getcode(), r.read().decode('utf-8','replace')
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode('utf-8','replace')

ok = lambda c, l: (_ for _ in ()).throw(AssertionError(l)) if not c else print("  ✓", l)

# 1) no key at all -> login gate
c,h = get('/panel'); ok(c==403 and 'دسترسی محدود' in h, f'بدون کلید: دروازهٔ ورود ({c})')

# 2) with key -> OTP gate (second key owed)
c,h = get('/panel?key='+TOK)
ok(c==403 and 'کلید دوم' in h, f'با کلید: دروازهٔ کلید دوم ({c})')
ok('XXXX-XXXX-XXXX' in h, 'فیلدِ کد در صفحه هست')
ok(TOK not in h, 'کلیدِ پنل در HTMLِ دروازه تکرار نشده')

# 3) no code issued yet -> submitting anything is refused
c,h = post('/panel/otp', {'otp':'AAAA-AAAA-AAAA'})
ok(c==403 and 'کدی زنده نیست' in h, f'بدون کدِ زنده: رد می‌شود ({c})')

# 4) issue a code (what the bot does) and use it
code = db.panel_otp_issue()
c,h = post('/panel/otp', {'otp':code})
ok(c==200 and ('داشبورد' in h or 'panel' in h.lower()), f'کدِ درست: پنل باز شد ({c})')

# 5) unlocked session now reaches the panel
c,h = get('/panel'); ok(c==200, f'نشستِ باز: پنل در دسترس ({c})')

# 6) the code is single-use: a fresh session must be gate again
cj.clear()
c,h = get('/panel?key='+TOK)
ok(c==403 and 'کلید دوم' in h, 'نشستِ جدید دوباره بدهکارِ کد است')
c,h = post('/panel/otp', {'otp':code})
ok(c==403 and 'کدی زنده نیست' in h, 'همان کدِ مصرف‌شده دیگر کار نمی‌کند')

# 7) wrong code burns the budget
c2 = db.panel_otp_issue()
for _ in range(4):
    c,h = post('/panel/otp', {'otp':'BBBB-BBBB-BBBB'})
ok(c==403 and 'کد درست نیست' in h, 'کدِ غلط رد می‌شود')
c,h = post('/panel/otp', {'otp':'BBBB-BBBB-BBBB'})
ok(c==403 and 'از کار افتاد' in h, 'تلاشِ آخر: کد می‌سوزد')
c,h = post('/panel/otp', {'otp':c2})
ok(c==403 and 'کدی زنده نیست' in h, 'پس از سوختن، کدِ درست هم مرده است')

# 8) turning the second key off restores the old single-factor behaviour
db.panel_otp_set(False)
cj.clear(); c,h = get('/panel?key='+TOK)
ok(c==200, f'کلید دوم خاموش ⇒ ورود فقط با کلیدِ پیوند ({c})')
db.panel_otp_set(True)

print("\n  مسیرِ کاملِ کلید دوم (v288) OK")
