# -*- coding: utf-8 -*-
"""جاروی فاز ۳ — همهٔ مسیرهای GET با ورودی مرزی/خراب‌کارانه.

هدف: پیدا کردن هر 500 (خطای بی‌دلیل) و هر رفتار متناقض. خروجی: فهرست
(مسیر، کد) برای هر درخواست؛ فقط 5xxها و غافلگیرکننده‌ها چاپ می‌شوند.
"""
import re
import sys
import urllib.request
import urllib.error

BASE = "http://127.0.0.1:8080"

# ── همهٔ مسیرهای پارامتری از regexهای app.py + مسیرهای ثابت پرکاربرد ──
PATTERNS = [
    "/b/{slug}", "/item/{id}", "/blog/{slug}", "/events/{id}",
    "/haggle/{id}", "/offer/{token}", "/qr/{slug}.svg", "/vcard/{slug}",
    "/chat-file/{id}", "/ticket-file/{id}", "/my/chat/{id}",
    "/my/order/{id}", "/my/order/{id}/cancel", "/my/story/{id}",
    "/my/story/{id}/views", "/my/ticket/{id}", "/my/catalog/{id}",
    "/my/catalog/{id}/quick", "/my/business/{id}", "/my/review/{id}",
    "/my/question/{id}", "/my/booking/{id}", "/my/offer/{id}",
    "/my/stats/{id}", "/my/trash/{id}/restore", "/me/chat/{id}",
    "/me/order/{id}", "/me/order/{id}/cancel", "/me/ticket/{id}",
    "/panel/ticket/{id}", "/panel/chat/{id}", "/panel/owner-chat/{id}",
    "/panel/business/{id}", "/panel/plan/{id}", "/panel/badge/{id}",
    "/panel/event/{id}", "/panel/story/{id}",
]
FIXED = ["/", "/businesses", "/catalog", "/map", "/blog", "/events",
         "/cities", "/areas", "/categories", "/cart", "/login", "/contact",
         "/register-business", "/features", "/pricing", "/subscribe", "/prices",
         "/nearby", "/lists", "/deals", "/favorites", "/order/ok",
         "/offline.html", "/robots.txt", "/sitemap.xml",
         "/manifest.webmanifest", "/api/stories", "/api/nearby",
         "/api/businesses", "/api/search"]

EDGE_IDS = [
    "0", "-1", "999999999999999999999", "2147483648", "9223372036854775807",
    "9223372036854775808", "abc", "%20", "1.5", "1e10", "۰۱", "null",
    "1%00x", "../../etc/passwd", "%ff%fe", "x" * 500,
]
EDGE_SLUGS = [
    "-", "does-not-exist", "..", "%2e%2e", "%00", "x" * 300,
    "....//....//etc/passwd", "<script>", "' OR '1'='1", "\\back",
    "کراهی-فارسی", "%C3%A9", "a%20b",
]
EDGE_TOKENS = ["short", "<script>alert(1)</script>", "x" * 64,
               "'OR'1'='1", "%00", "..%2f..%2fetc"]


def build():
    urls = []
    for p in FIXED:
        urls.append(p)
        urls.append(p + "?q=" + "%D8%A7" * 50)   # query flood (valid Persian)
        urls.append(p + "?page=-1&page=abc")
    for pat in PATTERNS:
        if "{id}" in pat:
            for e in EDGE_IDS:
                urls.append(pat.replace("{id}", e))
        if "{slug}" in pat:
            for e in EDGE_SLUGS:
                urls.append(pat.replace("{slug}", urllib.parse.quote(e, safe="")))
        if "{token}" in pat:
            for e in EDGE_TOKENS:
                urls.append(pat.replace("{token}", urllib.parse.quote(e, safe="")))
    return urls


def get(url):
    r = urllib.request.Request(BASE + url, headers={"User-Agent": "bz-fuzz3"})
    try:
        resp = urllib.request.urlopen(r, timeout=15)
        return resp.getcode()
    except urllib.error.HTTPError as e:
        return e.code
    except Exception as e:
        return f"ERR:{type(e).__name__}"


def main():
    urls = build()
    print(f"تعداد درخواست: {len(urls)}")
    codes = {}
    bad = []
    for u in urls:
        c = get(u)
        codes[c] = codes.get(c, 0) + 1
        if c == 500 or (isinstance(c, str) and c.startswith("ERR")):
            bad.append((u, c))
    print("توزیع کدها:", dict(sorted(codes.items(), key=lambda kv: str(kv[0]))))
    if bad:
        print(f"\n🔴 {len(bad)} مورد ۵xx/خطا:")
        for u, c in bad:
            print(f"  {c}  {u[:110]}")
    else:
        print("\n✅ هیچ ۵xx یا خطای شبکه‌ای در کل جارو نیست")
    # رفتارهای غافلگیرکنندهٔ غیر-۵xx (مثلاً 200 برای آشغال بی‌معنا)
    odd = []
    for pat in PATTERNS[:12]:
        u = pat.replace("{id}", "999999999999").replace("{slug}", "zzzz").replace("{token}", "zzzzzz")
        if "{id}" in pat or "{slug}" in pat or "{token}" in pat:
            c = get(u)
            if c == 200:
                odd.append((u, c))
    if odd:
        print("\n🟡 200 برای موجودیت ناموجود (بررسی دستی):")
        for u, c in odd:
            print(f"  {u}")
    return 1 if bad else 0


if __name__ == "__main__":
    import urllib.parse  # noqa
    sys.exit(main())
