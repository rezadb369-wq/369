#!/usr/bin/env python3
# دستور مدیر: پین انتشار با v282 هماهنگ شد (دستور مدیر)؛ رفتار محصول تغییر نکرده است.
# -*- coding: utf-8 -*-
"""v272: GLM-5.3-Flash جایگزین کامل کیرا + تغییراتِ پس‌از‌نصب دیده می‌شوند.

دستور مدیر (۲۰۲۶-۰۹-۱۲): «مدل glm 5.3 flash هم تو ربات مدیریتی خودم کاملا
جایگزین کیرا بشه» + «مشکل از خودته حتی ربات بله هم تغییرات لازم نکرده چه
برسه به سایت» — یعنی امکانات باید پس از نصب روی VPS هم دیده شوند.

Pins:
1)  مغز پنجم = GLM-5.3-Flash روی AvalAI (BRAINS/BRAIN_FA/KIRA_MODELS/
    AI_PROVIDERS/_KEY_RX)؛ اسلات AI_BRAIN_KIRA_KEY کلید aa- مدیر را دارد.
2)  صفحه‌کلیدها: BRAIN_KEYBOARD «GLM ۵.۳»، KEY_KEYBOARD «کلید GLM»؛
    /مغز glm|جی‌ال‌ام|کیرا همه به مغز پنجم می‌روند.
3)  ریشهٔ «ربات تغییرات نکرده»: handle_update یک‌بار در هر نسخه
    (admin_kb_ver != DIAG_LATEST) صفحه‌کلید تازه را با پاسخ بعدی می‌فرستد.
4)  «چت‌ها»: اگر sendDocument نشد، گزارش به‌صورت متن می‌رسد (fallback).
5)  کش مرورگر: assist.js?v272 در ui.py و sw.js نسخهٔ bazarche-v273 با
    fetch بدون کش (no-store) برای /assets.
6)  نسخه ۲۷۲ در پنج جای قرارداد + brain.env نُه‌خطی و kira==site (aa-).
"""
import os
import re
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix='adm-v272-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '111,222'
sys.path.insert(0, str(ROOT / 'server'))

import db  # noqa: E402
import adminbot as A  # noqa: E402
import adminbot_code as CODE  # noqa: E402
import assistant  # noqa: E402

db.init()
A._fetch_url = lambda url, timeout=10: '{"ok": true}'   # بدون شبکه
A.g_cert = lambda: '42'
n = 0


def ck(ok, label):
    global n
    assert ok, label
    n += 1
    print('  ✓', label)


def t(text, chat='111'):
    r = A.handle_text('u1', chat, text)
    return r[0] if isinstance(r, tuple) else r


# ============ 1. مغز پنجم = GLM-5.3-Flash (دستور مدیر) ============
ck(assistant.BRAINS['glm'] == ('https://api.avalai.ir/v1',
                               'AI_BRAIN_GLM_KEY', 'glm-5.3-flash'),
   'v273: مغز پنجم = GLM روی AvalAI با اسلات اختصاصی AI_BRAIN_GLM_KEY')
ck('kira' not in assistant.BRAINS and 'kira' not in assistant.BRAIN_FA,
   'v273 (دستور مدیر): کیرا کلا حذف شد')
ck(assistant.BRAIN_FA['glm'] == 'GLM ۵.۳ فلش',
   'نام نمایشی مغز پنجم = GLM ۵.۳ فلش')
ck(assistant.GLM_MODELS == ('glm-5.3-flash', 'glm-5.3', 'glm-5.2',
                            'glm-5.1', 'glm-5-turbo'),
   'فهرست مدل‌های مغز پنجم = خانوادهٔ GLM (پیش‌فرض اول)')
ck(CODE.AI_PROVIDERS['glm'] == ('https://api.avalai.ir/v1',
                                'glm-5.3-flash') and
   'kiraai' not in CODE.AI_PROVIDERS,
   'v273: provider مغز پنجم = glm؛ kiraai حذف شد')
ck(CODE._KEY_RX['glm'].match('aa-' + 'a' * 40) and
   not CODE._KEY_RX['glm'].match('kira_' + 'k' * 32) and
   not CODE._KEY_RX['glm'].match('aa-short'),
   'v273: کلید مغز پنجم فقط aa- (کلید کیرا دیگر پذیرفته نمی‌شود)')
r = t('/مغز')
_rows = [ln for ln in r.split('\n') if ln.startswith(('○', '●'))]
ck(len(_rows) == 5 and 'GLM ۵.۳ فلش' in _rows[4] and
   'کیرا' not in r,
   '/مغز: ردیف پنجم = GLM ۵.۳ فلش (کیرا کلا حذف شد)')
ck('GLM ۵.۳' in [b for row in A.BRAIN_KEYBOARD['keyboard'] for b in row],
   'BRAIN_KEYBOARD دکمهٔ «GLM ۵.۳» دارد')
os.environ['AI_BRAIN_GLM_KEY'] = 'aa-glmk' + 'k' * 39
_saved_chat = assistant._chat
assistant._chat = lambda *a, **k: ('{}', 1)   # تست زنده بدون شبکه
try:
    for word in ('glm', 'جی‌ال‌ام'):
        db.set_settings({'ai_brain_active': 'sonnet'})
        r = t('/مغز ' + word)
        ck(db.get_settings().get('ai_brain_active') == 'glm' and
           ('GLM' in r or 'فعال' in r),
           '/مغز %s → مغز پنجم (GLM) سوئیچ می‌شود' % word)
    db.set_settings({'ai_brain_active': 'sonnet'})
    r = t('/مغز کیرا')
    ck(db.get_settings().get('ai_brain_active') == 'sonnet' and
       'درست نیست' in r,
       'v273: /مغز کیرا رد می‌شود (کیرا کلا حذف شد)')
finally:
    assistant._chat = _saved_chat
# مسیر config(): اسلات aa- مغز پنجم درست resolve می‌شود
os.environ['AI_BRAIN_GLM_KEY'] = 'aa-glmk' + 'k' * 39
db.set_settings({'ai_brain_active': 'glm', 'ai_brain_glm_model': ''})
c = assistant.config()
ck(c['brain'] == 'glm' and c['model'] == 'glm-5.3-flash' and
   c['base_url'] == 'https://api.avalai.ir/v1' and
   c['api_key'].startswith('aa-') and c['fb_model'] == '',
   'config(): مغز پنجم با کلید aa- روی AvalAI (بدون fallback)')

# ============ 2. صفحه‌کلید تازه پس از نصب (admin_kb_ver) ============
sent = []
_real_send = A.send_message
A.send_message = lambda chat, text, markup=None: sent.append(
    (chat, text, markup)) or True
try:
    db.set_settings({'admin_kb_ver': ''})
    upd = {'message': {'chat': {'id': '111', 'type': 'private'},
                       'from': {'id': 'u1'}, 'text': 'وضعیت'}}
    A.handle_update(upd)
    ck(len(sent) == 1 and sent[0][2] == A.KEYBOARD,
       'v272: نخستین پاسخ پس از نصب، صفحه‌کلید تازه می‌گیرد')
    ck(db.get_settings().get('admin_kb_ver') == A.DIAG_LATEST,
       'admin_kb_ver = نسخهٔ جاری ذخیره می‌شود')
    sent.clear()
    A.handle_update(upd)
    ck(len(sent) == 1 and sent[0][2] is None,
       'پاسخ‌های بعدی (همان نسخه) صفحه‌کلید تکراری نمی‌گیرند')
    # پاسخ خودش markup داشت → دست‌نخورده می‌ماند
    db.set_settings({'admin_kb_ver': ''})
    A.handle_update({'message': {'chat': {'id': '111', 'type': 'private'},
                                 'from': {'id': 'u1'}, 'text': '/مغز'}})
    ck(sent[-1][2] == A.BRAIN_KEYBOARD,
       'markup موجود (پیکر مغزها) با KEYBOARD بازنویسی نمی‌شود')
finally:
    A.send_message = _real_send

# ============ 3. «چت‌ها» — fallback متنی وقتی فایل نرسید ============
log = Path(TMP) / 'site_chats.log'
log.write_text(''.join('{"when":"x","q":"q%d"}\n' % i for i in range(50)),
               encoding='utf-8')
_real_doc = A.send_document
A.send_document = lambda *a, **k: False
try:
    sent.clear()
    A.send_message = lambda chat, text, markup=None: sent.append(
        (chat, text, markup)) or True
    r = t('چت‌ها')
    ck('متن فرستاده شد' in r,
       'v272: sendDocument که نشد، مدیر پاسخ متنی می‌گیرد (بی‌پاسخ نمی‌ماند)')
    ck(len(sent) == 1 and sent[0][1].count('"q"') == 40,
       'fallback: ۴۰ پیام آخر همین‌جا به‌صورت متن می‌رسد')
finally:
    A.send_document = _real_doc
    A.send_message = _real_send

# ============ 4. کش مرورگر — ریشهٔ «سایت تغییرات نکرده» ============
ui = (ROOT / 'server' / 'ui.py').read_text(encoding='utf-8')
ck('assist.js?v282' in ui and 'assist.js?v232' not in ui,
   'v274: ui.py فایل چت را با ?v274 می‌دهد (کش شکن)')
sw = (ROOT / 'site' / 'sw.js').read_text(encoding='utf-8')
ck("VERSION = 'bazarche-v282-merchant1'" in sw,
   'sw.js توکن کش bazarche-v282-merchant1 (evict کلاینت گرم)')
ck("cache: 'no-store'" in sw,
   'v272: sw.js دیگر بایت کهنهٔ immutable را برنمی‌گرداند (no-store)')

# ============ 5. نسخه + brain.env ============
ck((ROOT / 'VERSION.txt').read_text().strip() == '282',
   'VERSION.txt = 275')
ck(A.DIAG_LATEST == '282', 'DIAG_LATEST = 282')
ck('v282' in (ROOT / 'README.md').read_text(encoding='utf-8')[:2000],
   'README هدر v282')
ck('v282' in (ROOT / 'docs' / 'collaboration' / 'CURRENT-STATE.md').read_text(
    encoding='utf-8')[:1500], 'CURRENT-STATE هدر v282')
be = (ROOT / 'deploy' / 'brain.env').read_text(encoding='utf-8')
lines = [ln for ln in be.splitlines() if ln.startswith('AI_')]
vals = {}
for ln in lines:
    k, _, v = ln.partition('=')
    vals[k] = v
_kv = [v for k, v in vals.items() if k.endswith('_KEY')]
ck(len(lines) == 9 and len(_kv) == 6 and len(set(_kv)) == 6,
   'v273: brain.env ۹ خط؛ ۶ اسلات کلید، همه متمایز (کلید GLM فقط پنل مدیریتی)')
ck('AI_BRAIN_KIRA_KEY' not in vals and
   vals['AI_BRAIN_GLM_KEY'].startswith('aa-') and
   vals['AI_BRAIN_GLM_KEY'] != vals['AI_SITE_API_KEY'],
   'v273 (دستور مدیر): کیرا حذف؛ اسلات GLM مستقل و جدا از سایت')
ck(vals['AI_SITE_MODEL'] == 'glm-5.3-flash',
   'AI_SITE_MODEL = glm-5.3-flash')
ck(re.match(r'^aa-[A-Za-z0-9]{30,}$', vals['AI_BRAIN_GLM_KEY']),
   'شکل کلید مغز پنجم سالم است (بدون چاپ مقدار)')

print('v272 GLM-5.3-Flash + تغییرات دیده‌شدنی پس از نصب: %d checks green' % n)
