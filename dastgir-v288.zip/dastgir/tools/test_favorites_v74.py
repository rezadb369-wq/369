#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v74 unified favourites + heart-state regression suite."""

import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "server"))
import db  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
PREFIX = "v74-favorite-probe"
PHONE = "09129997701"
PASS, FAIL = [], []


def check(label, condition, detail=""):
    if condition:
        PASS.append(label); print("  ✓", label)
    else:
        FAIL.append((label, detail)); print("  ✗", label, f"[{detail}]" if detail else "")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def request(path, method="GET", data=None, cookie=""):
    headers = {"User-Agent": "bazarche-v74-favorite-test"}
    if cookie:
        headers["Cookie"] = cookie
    req = urllib.request.Request(BASE + path, data=data, method=method, headers=headers)
    try:
        res = urllib.request.build_opener(NoRedirect()).open(req, timeout=20)
        return res.status, dict(res.headers), res.read()
    except urllib.error.HTTPError as exc:
        return exc.code, dict(exc.headers), exc.read()


def cleanup():
    for business in db.businesses(status=None):
        if business["name"].startswith(PREFIX):
            db.delete_business(business["id"])
    customer = db.customer_by_phone(PHONE)
    if customer:
        db.customer_delete(customer["id"])


def setup():
    db.init()
    cleanup()
    category = db.categories(only_active=True)[0]
    first = db.save_business({
        "name": PREFIX + "-first", "cat_slug": category["slug"],
        "status": "published", "phone": "03142610001",
        "lat": 32.6340, "lng": 51.3660, "city": "نجف‌آباد", "province": "اصفهان",
        "address": "نجف‌آباد، نشانی قلب اول",
    })
    second = db.save_business({
        "name": PREFIX + "-second", "cat_slug": category["slug"],
        "status": "published", "phone": "03142610002",
        "lat": 32.6346, "lng": 51.3664, "city": "نجف‌آباد", "province": "اصفهان",
        "address": "نجف‌آباد، نشانی قلب دوم",
    })
    customer = db.customer_by_phone(PHONE, create=True)
    db.customer_set_profile(customer["id"], "کاربر", "قلب")
    db.fav_toggle(customer["id"], first)
    db.follow_toggle(customer["id"], first)
    return customer, db.business(bid=first), db.business(bid=second)


def rgb_is_red(value):
    try:
        nums = [int(float(x)) for x in value.replace("rgba(", "").replace("rgb(", "")
                .replace(")", "").split(",")[:3]]
        return nums[0] >= 170 and nums[0] > nums[1] * 1.25 and nums[0] > nums[2] * 1.12
    except Exception:
        return False


def task_data_and_api(customer, first, second):
    print("\n══ ۱) منبع واحد داده و API ══")
    check("تابع فهرست slugهای علاقه‌مندی وجود دارد", hasattr(db, "fav_slugs"))
    if hasattr(db, "fav_slugs"):
        check("علاقه‌مندی سرور slug درست می‌دهد",
              db.fav_slugs(customer["id"]) == [first["slug"]],
              str(db.fav_slugs(customer["id"])))

    con = db.connect()
    try:
        unique_indexes = [r for r in con.execute("PRAGMA index_list(favorites)") if r["unique"]]
    finally:
        con.close()
    check("پایگاه داده از علاقه‌مندی تکراری جلوگیری می‌کند",
          bool(unique_indexes), str([dict(r) for r in unique_indexes]))

    token = db.customer_session_new(customer["id"])
    cookie = "bzv2_cust=" + token
    payload = urllib.parse.urlencode({"slug": second["slug"]}).encode()
    code, _, body = request("/api/favorite", "POST", payload, cookie)
    try:
        result = json.loads(body.decode("utf-8"))
    except Exception:
        result = {}
    check("API علاقه‌مندی برای مشتری واردشده کار می‌کند",
          code == 200 and result.get("ok") and result.get("on") is True,
          f"HTTP {code} {result}")
    check("API واقعاً داده را در SQLite ثبت می‌کند",
          second["id"] in db.fav_list(customer["id"]), str(db.fav_list(customer["id"])))

    # Toggle back so browser starts from a known B1-only state.
    request("/api/favorite", "POST", payload, cookie)
    guest_code, _, _ = request("/api/favorite", "POST", payload)
    bad_payload = urllib.parse.urlencode({"slug": "not-a-real-shop"}).encode()
    bad_code, _, _ = request("/api/favorite", "POST", bad_payload, cookie)
    check("مهمان نمی‌تواند API حساب را دست‌کاری کند", guest_code == 403, str(guest_code))
    check("کسب‌وکار نامعتبر از API رد می‌شود", bad_code == 404, str(bad_code))

    code, _, html = request("/businesses", cookie=cookie)
    text = html.decode("utf-8", "ignore")
    check("وضعیت علاقه‌مندی سرور داخل bootstrap امن صفحه است",
          code == 200 and 'favoriteSlugs' in text and first["slug"] in text,
          "favorite bootstrap missing")
    # v288: قلب‌های علاقه‌مندی زنده‌اند، ولی روی صفحهٔ «مقایسهٔ کنارهم» نه —
    # آن مسیر بازنشسته شد (HANDBOOK.md:715). جای زندهٔ کارت‌های چنددکانی با
    # قلب، فهرستِ /businesses است؛ همان‌جا این رفتار را قفل می‌کنیم.
    cmp_path = "/businesses"
    cmp_code, _, cmp_body = request(cmp_path, cookie=cookie)
    cmp_html = cmp_body.decode("utf-8", "ignore")
    check("در فهرست برای هر دکان قلب ذخیره وجود دارد",
          cmp_code == 200 and cmp_html.count('data-fav=') >= 2,
          f"HTTP {cmp_code}, hearts={cmp_html.count('data-fav=')}")
    cmp_code, _, _ = request(
        "/compare?b=" + urllib.parse.quote(first["slug"])
        + "&b=" + urllib.parse.quote(second["slug"]), cookie=cookie)
    check("مسیر کهنهٔ /compare عمداً ۴۰۴ است", cmp_code == 404, f"HTTP {cmp_code}")
    return cookie


def task_guest_browser(first):
    print("\n══ ۲) تمام قلب‌های مهمان و صفحات پویا ══")
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        context = browser.new_context(
            viewport={"width": 390, "height": 844}, locale="fa-IR",
            is_mobile=True, has_touch=True,
            geolocation={"latitude": first["lat"], "longitude": first["lng"]},
            permissions=["geolocation"])
        context.add_init_script(
            "localStorage.setItem('bazarche.v2.favs', "
            + json.dumps(json.dumps([first["slug"]])) + ")")
        page = context.new_page()
        errors = []
        page.on("pageerror", lambda error: errors.append(str(error)))

        page.goto(BASE + "/businesses?q=" + urllib.parse.quote(PREFIX), wait_until="networkidle")
        page.wait_for_timeout(250)
        heart = page.locator(f'[data-fav="{first["slug"]}"]').first
        state = heart.evaluate("""e => ({pressed:e.getAttribute('aria-pressed'),
          color:getComputedStyle(e).color, fill:getComputedStyle(e.querySelector('svg')).fill,
          cls:e.className})""")
        check("قلب کارت مهمان پُر و قرمز است",
              state["pressed"] == "true" and rgb_is_red(state["color"])
              and state["fill"] not in ("none", "rgba(0, 0, 0, 0)"), str(state))
        check("مدیر یکپارچهٔ علاقه‌مندی در مرورگر وجود دارد",
              page.evaluate("typeof window.BazarcheFavorites === 'object'"))
        header = page.locator('[data-favorites-link]').first
        check("قلب سربرگ با وجود علاقه‌مندی قرمز می‌شود",
              header.count() == 1 and header.evaluate("e=>e.classList.contains('has-favorites')"),
              "header favorite state missing")

        # A dynamically inserted duplicate represents map/list widgets created after boot.
        duplicate_ready = page.evaluate("""slug => {
          const original=document.querySelector(`[data-fav="${slug}"]`);
          const clone=original.cloneNode(true); clone.id='duplicate-heart-probe';
          document.body.appendChild(clone); window.BazarcheFavorites?.paint();
          return clone.getAttribute('aria-pressed');
        }""", first["slug"])
        check("قلبی که بعداً ساخته می‌شود همان وضعیت را می‌گیرد",
              duplicate_ready == "true", str(duplicate_ready))
        heart.click(); page.wait_for_timeout(150)
        all_off = page.evaluate("""slug => Array.from(document.querySelectorAll(`[data-fav="${slug}"]`))
          .every(e => e.getAttribute('aria-pressed') === 'false' && !e.classList.contains('is-on'))""",
          first["slug"])
        check("با یک کلیک همهٔ قلب‌های همان دکان هم‌زمان خاموش می‌شوند", all_off)
        # Restore a known local state for the remaining page-by-page checks.
        page.evaluate("slug => localStorage.setItem('bazarche.v2.favs', JSON.stringify([slug]))",
                      first["slug"])

        page.goto(BASE + f"/b/{first['slug']}", wait_until="networkidle")
        page.wait_for_timeout(180)
        detail = page.locator(f'[data-fav="{first["slug"]}"]').first
        detail_state = detail.evaluate("""e=>({pressed:e.getAttribute('aria-pressed'),
          color:getComputedStyle(e).color,label:e.innerText.trim()})""")
        check("قلب صفحهٔ دکان قرمز و متن آن «ذخیره شد» است",
              detail_state["pressed"] == "true" and rgb_is_red(detail_state["color"])
              and "ذخیره" in detail_state["label"], str(detail_state))

        page.goto(BASE + "/favorites", wait_until="networkidle")
        page.wait_for_timeout(900)
        check("صفحهٔ علاقه‌مندی کلید نسخه‌دار را می‌خواند و کارت را نشان می‌دهد",
              page.locator(f'[data-fav="{first["slug"]}"]').count() >= 1,
              f"cards={page.locator('#fav-list article').count()}")
        saved = page.locator(f'[data-fav="{first["slug"]}"]').first
        saved_count = page.locator(f'[data-fav="{first["slug"]}"]').count()
        check("قلب حذف در صفحهٔ ذخیره‌شده‌ها از ابتدا قرمز است",
              saved_count >= 1 and saved.get_attribute("aria-pressed") == "true"
              and rgb_is_red(saved.evaluate("e=>getComputedStyle(e).color")) if saved_count else False)

        page.goto(BASE + "/map", wait_until="domcontentloaded")
        page.wait_for_timeout(1800)
        map_row = page.locator(f'[data-focus="{first["slug"]}"]')
        check("دکانٔ آزمون در فهرست نقشه هست", map_row.count() == 1)
        if map_row.count():
            map_row.click(); page.wait_for_timeout(250)
            map_heart = page.locator(f'[data-map-selected] [data-fav="{first["slug"]}"]')
            check("کارت انتخابی نقشه قلب علاقه‌مندی دارد",
                  map_heart.count() == 1 and map_heart.get_attribute("aria-pressed") == "true")

        page.goto(BASE + "/nearby", wait_until="networkidle")
        page.locator('[data-geo]').click();
        try:
            page.wait_for_selector(f'[data-near-grid] [data-fav="{first["slug"]}"]', timeout=12000)
            near_ok = True
        except Exception:
            near_ok = False
        check("کارت پویا در «نزدیک من» قلب همگام دارد", near_ok)
        if near_ok:
            check("قلب نزدیک من قرمز است",
                  page.locator(f'[data-near-grid] [data-fav="{first["slug"]}"]').first
                  .get_attribute("aria-pressed") == "true")
        check("جریان مهمان خطای JavaScript ندارد", not errors, str(errors))
        context.close(); browser.close()


def task_signed_in_browser(customer, first, second, cookie):
    print("\n══ ۳) همگام‌سازی حساب و قلب‌های مشابه ══")
    from playwright.sync_api import sync_playwright
    token = cookie.split("=", 1)[1]
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        context = browser.new_context(viewport={"width": 390, "height": 844},
                                      locale="fa-IR", is_mobile=True, has_touch=True)
        context.add_cookies([{"name": "bzv2_cust", "value": token, "url": BASE}])
        page = context.new_page()
        page.goto(BASE + "/businesses?q=" + urllib.parse.quote(PREFIX), wait_until="networkidle")
        page.wait_for_timeout(200)
        first_btn = page.locator(f'[data-fav="{first["slug"]}"]').first
        check("قلب علاقه‌مندی سرور با localStorage خالی هم قرمز است",
              first_btn.get_attribute("aria-pressed") == "true"
              and first["slug"] in page.evaluate("localStorage.getItem('bazarche.v2.favs') || ''"))

        second_btn = page.locator(f'[data-fav="{second["slug"]}"]').first
        second_btn.click(); page.wait_for_timeout(350)
        check("کلیک کاربر واردشده در SQLite ذخیره می‌شود",
              second["id"] in db.fav_list(customer["id"]), str(db.fav_list(customer["id"])))
        page.reload(wait_until="networkidle"); page.wait_for_timeout(150)
        check("بعد از بازخوانی قلب دوم همچنان قرمز است",
              page.locator(f'[data-fav="{second["slug"]}"]').first.get_attribute("aria-pressed") == "true")

        page.goto(BASE + "/me/favorites", wait_until="networkidle"); page.wait_for_timeout(180)
        pressed = page.locator('[data-fav][aria-pressed="true"]').count()
        check("صفحهٔ حساب هر دو کارت را با قلب قرمز نشان می‌دهد", pressed >= 2, str(pressed))

        page.goto(BASE + f"/b/{first['slug']}", wait_until="networkidle")
        follow = page.locator('[data-follow]')
        follow_state = follow.evaluate("""e=>({pressed:e.getAttribute('aria-pressed'),
          color:getComputedStyle(e).color, fill:getComputedStyle(e.querySelector('svg')).fill,
          text:e.innerText})""") if follow.count() else {}
        check("قلب دنبال‌کردن مشابه نیز حالت قبلی و قرمز را نشان می‌دهد",
              follow_state.get("pressed") == "true" and rgb_is_red(follow_state.get("color", ""))
              and "دنبال می‌کنید" in follow_state.get("text", ""), str(follow_state))
        context.close(); browser.close()


def main():
    customer, first, second = setup()
    try:
        cookie = task_data_and_api(customer, first, second)
        task_guest_browser(first)
        task_signed_in_browser(customer, first, second, cookie)
    finally:
        cleanup()
    print("\n" + "═" * 62)
    print(f"  {len(PASS)} موفق، {len(FAIL)} ناموفق")
    for label, detail in FAIL:
        print("   ✗", label, detail)
    print("═" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
