# -*- coding: utf-8 -*-
"""v298 Email OTP sender — mirrors server/sms.py pattern.

- If smtp_host is configured -> try SMTP.
- If not -> return (False, dev_note) so code shows on screen in dev.
- Always returns (delivered: bool, note: str)
"""
import smtplib
import ssl
from email.message import EmailMessage

def configured(settings):
    s = settings or {}
    return bool(s.get("smtp_host") and s.get("smtp_from"))

def send_otp(settings, to_email, code):
    """Send 6-digit email OTP. Returns (delivered, note)."""
    to_email = (to_email or "").strip().lower()[:120]
    code = str(code).strip()
    s = settings or {}
    host = (s.get("smtp_host") or "").strip()
    from_addr = (s.get("smtp_from") or s.get("email") or "").strip()
    if not host or not from_addr:
        # dev fallback — show code on screen like sms.py does
        return False, f"کد ایمیل (حالت توسعه): {code}"

    port = int(s.get("smtp_port") or 587)
    user = (s.get("smtp_user") or "").strip()
    pwd = (s.get("smtp_pass") or "").strip()
    use_tls = str(s.get("smtp_tls") or "1") not in ("0", "false", "False")

    site_name = s.get("site_name") or "دست گیر"
    subject = f"کد ورود به {site_name}: {code}"
    body_text = f"""سلام،

کد ورود شما به {site_name}:

{code}

این کد تا ۵ دقیقه معتبر است.

اگر شما این درخواست را نکرده‌اید، این ایمیل را نادیده بگیرید.

— {site_name}
"""
    body_html = f"""<div dir="rtl" style="font-family:Tahoma,sans-serif;line-height:1.8">
<p>سلام،</p>
<p>کد ورود شما به <b>{site_name}</b>:</p>
<p style="font-size:28px;font-weight:bold;letter-spacing:6px;background:#f3f4f6;padding:12px 20px;border-radius:8px;display:inline-block">{code}</p>
<p style="color:#6b7280">این کد تا ۵ دقیقه معتبر است.<br>اگر شما این درخواست را نکرده‌اید، این ایمیل را نادیده بگیرید.</p>
<p>— {site_name}</p>
</div>"""

    try:
        msg = EmailMessage()
        msg["From"] = from_addr
        msg["To"] = to_email
        msg["Subject"] = subject
        msg.set_content(body_text)
        msg.add_alternative(body_html, subtype="html")

        if use_tls and port == 465:
            ctx = ssl.create_default_context()
            with smtplib.SMTP_SSL(host, port, context=ctx, timeout=20) as smtp:
                if user and pwd:
                    smtp.login(user, pwd)
                smtp.send_message(msg)
        else:
            with smtplib.SMTP(host, port, timeout=20) as smtp:
                if use_tls:
                    ctx = ssl.create_default_context()
                    smtp.starttls(context=ctx)
                if user and pwd:
                    smtp.login(user, pwd)
                smtp.send_message(msg)
        return True, "ایمیل ارسال شد"
    except Exception as e:
        # don't leak exception, but give hint
        err = str(e)[:200]
        return False, f"خطای ارسال ایمیل: {err} — کد: {code}"
