# -*- coding: utf-8 -*-
"""Owner control panel — full authority over every part of the site."""

import json, os, sys, time as _time
from urllib.parse import urlencode

_BOOT = _time.time()   # v119: برای کارت «وضعیت فنی» داشبورد
import db
import adminbot
from ui import (av, panel_prefix, icon, stars, fa, fa_group, review_score_html, esc, panel_page, stat_card, flash, cat_icon,
                cat_options, json_embed, _panel_counts)
from ui import jdate, jdatetime, jdatetime_ts, media_embed

ICON_CHOICES = ["store","restaurant","cafe","bakery","confectionery","shopping",
                "clothing","jewellery","medical","auto","realestate","barber",
                "education","mobile","gym","homeservice","flowers","photography",
                "pin","map","compass","mosque"]
ICON_LABELS = {
    "store": "فروشگاه", "restaurant": "رستوران", "cafe": "کافه",
    "bakery": "نانوایی", "confectionery": "قنادی", "shopping": "خرید",
    "clothing": "پوشاک", "jewellery": "طلا و جواهر", "medical": "پزشکی",
    "auto": "خودرو", "realestate": "املاک", "barber": "آرایشگاه",
    "education": "آموزش", "mobile": "موبایل", "gym": "ورزش",
    "homeservice": "خدمات منزل", "flowers": "گل و گیاه",
    "photography": "عکاسی", "pin": "نشان مکان", "map": "نقشه",
    "compass": "قطب‌نما", "mosque": "مسجد",
}


def _icon_options(values, selected=""):
    out = []
    for name in values:
        label = ICON_LABELS.get(name, name.replace("-", " ").replace("_", " "))
        search = f"{name} {label}"
        out.append(f'<option value="{esc(name)}" data-icon-terms="{esc(search)}"'
                   f'{" selected" if selected == name else ""}>{esc(label)} — {esc(name)}</option>')
    return "".join(out)

DAYS = [("sat","شنبه"),("sun","یک‌شنبه"),("mon","دوشنبه"),("tue","سه‌شنبه"),
        ("wed","چهارشنبه"),("thu","پنج‌شنبه"),("fri","جمعه")]

MAP_JS = '<script type="module" src="' + av('/assets/js/mappage.js') + '"></script>'
IMAGEFIELD_JS = '<script type="module" src="' + av('/assets/js/imagefield.js') + '"></script>'
_CAT_IMG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "..", "site", "assets", "img", "cats")
_UPLOAD_PREFIX = "/assets/img/uploads/"


def _cat_photo(c):
    custom = c.get("image") or ""
    if custom == "-":
        return ""
    if custom.startswith(_UPLOAD_PREFIX):
        full = os.path.join(os.path.dirname(_CAT_IMG_DIR), "uploads",
                            os.path.basename(custom))
        if os.path.isfile(full):
            return custom
    fallback = os.path.join(_CAT_IMG_DIR, (c.get("slug") or "") + ".webp")
    return f'/assets/img/cats/{c["slug"]}.webp' if os.path.isfile(fallback) else ""


def _msg(q):
    if q.get("ok"):
        return flash("ok", q["ok"][0])
    if q.get("err"):
        return flash("err", q["err"][0])
    return ""


# ------------------------------------------------------------------ dashboard
def approve_btn(b, token, back=""):
    """Approve / reject controls, shown only where they make sense."""
    bid = b["id"]
    hidden = (f''
              f'<input type="hidden" name="back" value="{esc(back)}">')
    if b["status"] == "pending":
        return (f'<form method="post" action="/panel/business/{bid}/status" style="display:inline">'
                f'{hidden}<input type="hidden" name="status" value="published">'
                f'<button class="btn-icon btn-approve" type="submit" title="تأیید و انتشار"'
                f' aria-label="تأیید {esc(b["name"])}">{icon("check-circle")}</button></form>'
                f'<form method="post" action="/panel/business/{bid}/status" style="display:inline"'
                f' data-confirm="درخواست «{esc(b["name"])}» رد شود؟">'
                f'{hidden}<input type="hidden" name="status" value="rejected">'
                f'<button class="btn-icon" type="submit" title="رد درخواست"'
                f' aria-label="رد {esc(b["name"])}" style="color:var(--color-destructive)">'
                f'{icon("x-circle")}</button></form>')
    if b["status"] == "published":
        return (f'<form method="post" action="/panel/business/{bid}/status" style="display:inline">'
                f'{hidden}<input type="hidden" name="status" value="hidden">'
                f'<button class="btn-icon" type="submit" title="مخفی کردن"'
                f' aria-label="مخفی کردن {esc(b["name"])}">{icon("eye")}</button></form>')
    # hidden or rejected -> offer to publish
    return (f'<form method="post" action="/panel/business/{bid}/status" style="display:inline">'
            f'{hidden}<input type="hidden" name="status" value="published">'
            f'<button class="btn-icon btn-approve" type="submit" title="انتشار"'
            f' aria-label="انتشار {esc(b["name"])}">{icon("check-circle")}</button></form>')


def pending_box(s, token):
    """Big, unmissable queue of businesses waiting for a decision."""
    waiting = db.businesses(status="pending", order="newest")
    if not waiting:
        return ""
    cat_names = {c["slug"]: c["name"] for c in db.categories(only_active=False)}
    cards = "".join(f'''<div class="pending-card">
      <div class="pending-main">
        <strong>{esc(b["name"])}</strong>
        <div class="text-xs text-muted">{esc(cat_names.get(b.get("cat_slug"), b.get("cat_slug")))} · {esc(b.get("address") or "بدون نشانی")}</div>
        <p class="text-sm text-muted mt-sm">{esc((b.get("descr") or "")[:150])}</p>
        <div class="cluster mt-sm">
          {f'<span class="badge badge-neutral">{icon("phone")}<span class="nums">{esc(b["phone"])}</span></span>' if b.get("phone") else ""}
          <span class="badge badge-neutral">{icon("calendar")}<span>{esc(jdate(b["created"]))}</span></span>
        </div>
      </div>
      <div class="pending-actions">
        <a class="btn btn-glass btn-sm" href="/panel/business/{b["id"]}">
          {icon("edit")}<span>بررسی و ویرایش</span></a>
        <form method="post" action="/panel/business/{b["id"]}/status">
                    <input type="hidden" name="status" value="published">
          <button class="btn btn-primary btn-sm btn-block" type="submit">
            {icon("check")}<span>تأیید و انتشار</span></button></form>
        <form method="post" action="/panel/business/{b["id"]}/status"
              data-confirm="درخواست «{esc(b["name"])}» رد شود؟">
                    <input type="hidden" name="status" value="rejected">
          <button class="btn btn-ghost btn-sm btn-block" type="submit"
                  style="color:var(--color-destructive)">{icon("x")}<span>رد</span></button></form>
      </div>
    </div>''' for b in waiting)
    return f'''<div class="card glass card-pad mb-lg pending-box">
      <div class="between mb-lg">
        <h2 class="card-title">{icon("bell")} در انتظار تأیید شما</h2>
        <span class="badge badge-warn">{fa(len(waiting))} درخواست</span>
      </div>
      <p class="text-sm text-muted mb-lg">این کسب‌وکارها را کاربران ثبت کرده‌اند و
        تا تأیید شما روی سایت دیده نمی‌شوند.</p>
      <div class="pending-list">{cards}</div>
    </div>'''


def dashboard(s, token, q=None):
    st = db.stats()
    # v184: one live count snapshot drives the dashboard cards, desktop nav,
    # and mobile drawer. The old code additionally loaded five complete row
    # lists although it used only three lengths (and never used two lists).
    counts = _panel_counts()
    recent_biz = db.businesses(status=None, order="newest", limit=6)
    pending_claims_n = counts.get("/panel/claims", 0)
    pending_edits_n = counts.get("/panel/edits", 0)
    open_tickets_n = counts.get("/panel/tickets", 0)

    rows = "".join(f'''<tr>
      <td>
        <div style="display:flex;align-items:center;gap:10px">
          {cat_icon(b.get("icon") or "store", 32)}
          <div><strong>{esc(b['name'])}</strong><br>
            <small class="text-muted">{esc(b.get('cat_name') or b['cat_slug'])}</small></div>
        </div>
      </td>
      <td class="num nums">{fa(b['views'])}</td>
      <td><span class="badge {"badge-open" if b['status']=='published' else ("badge-warn" if b['status']=='pending' else "badge-neutral")}">
        {esc({"published":"منتشرشده","pending":"در انتظار تأیید","hidden":"مخفی","rejected":"رد شده"}.get(b['status'],b['status']))}</span></td>
      <td class="actions">
        <a class="btn-icon" href="/b/{esc(b['slug'])}" target="_blank" rel="noopener" aria-label="مشاهده" title="مشاهده در سایت">{icon("eye")}</a>
        <a class="btn-icon" href="/panel/business/{b['id']}" aria-label="ویرایش {esc(b['name'])}" title="ویرایش">{icon("edit")}</a>
      </td></tr>'''
      for b in recent_biz) or '<tr><td colspan="4" class="text-center text-muted">هنوز کسب‌وکاری ثبت نشده</td></tr>'

    # Actionable Pending Center
    pending_cards = []
    if st["pending_biz"]:
        pending_cards.append(f'''<a class="todo-item" href="/panel/businesses?status=pending">
          {icon("clock")}<span><strong>{fa(st["pending_biz"])} کسب‌وکار در انتظار تأیید</strong><br><small class="text-muted">بررسی و انتشار روی سایت</small></span>
          <span class="btn btn-primary btn-sm">{icon("arrow-left")}<span>بررسی</span></span></a>''')
    if st["pending_reviews"]:
        pending_cards.append(f'''<a class="todo-item" href="/panel/reviews?status=pending">
          {icon("message")}<span><strong>{fa(st["pending_reviews"])} نظر در انتظار بررسی</strong><br><small class="text-muted">تأیید یا پاسخ به نظر مشتریان</small></span>
          <span class="btn btn-primary btn-sm">{icon("arrow-left")}<span>بررسی</span></span></a>''')
    if pending_claims_n:
        pending_cards.append(f'''<a class="todo-item" href="/panel/claims?status=pending">
          {icon("shield")}<span><strong>{fa(pending_claims_n)} درخواست تصاحب دکان</strong><br><small class="text-muted">بررسی مالکیت کسب‌وکار</small></span>
          <span class="btn btn-primary btn-sm">{icon("arrow-left")}<span>بررسی</span></span></a>''')
    if pending_edits_n:
        pending_cards.append(f'''<a class="todo-item" href="/panel/edits?status=pending">
          {icon("edit")}<span><strong>{fa(pending_edits_n)} ویرایش کسب‌وکار توسط دکان‌دار</strong><br><small class="text-muted">بررسی تغییرات مشخصات</small></span>
          <span class="btn btn-primary btn-sm">{icon("arrow-left")}<span>بررسی</span></span></a>''')
    if open_tickets_n:
        pending_cards.append(f'''<a class="todo-item" href="/panel/tickets?status=open">
          {icon("help")}<span><strong>{fa(open_tickets_n)} تیکت پشتیبانی باز</strong><br><small class="text-muted">پاسخ به سوالات و مشکلات</small></span>
          <span class="btn btn-primary btn-sm">{icon("arrow-left")}<span>پاسخ</span></span></a>''')
    if st["new_bookings"]:
        pending_cards.append(f'''<a class="todo-item" href="/panel/bookings">
          {icon("calendar")}<span><strong>{fa(st["new_bookings"])} نوبت آنلاین جدید</strong><br><small class="text-muted">نوبت‌های ثبت‌شده مشتریان</small></span>
          <span class="btn btn-primary btn-sm">{icon("arrow-left")}<span>مشاهده</span></span></a>''')
    if st["new_messages"]:
        pending_cards.append(f'''<a class="todo-item" href="/panel/messages">
          {icon("mail")}<span><strong>{fa(st["new_messages"])} پیام خوانده‌نشده</strong><br><small class="text-muted">پیام‌های دریافتی از فرم تماس</small></span>
          <span class="btn btn-primary btn-sm">{icon("arrow-left")}<span>مشاهده</span></span></a>''')
    if st["pending_questions"]:
        pending_cards.append(f'''<a class="todo-item" href="/panel/qa?status=pending">
          {icon("help")}<span><strong>{fa(st["pending_questions"])} پرسش در انتظار انتشار</strong><br><small class="text-muted">پرسش‌های مشتریان دربارهٔ دکان‌ها</small></span>
          <span class="btn btn-primary btn-sm">{icon("arrow-left")}<span>بررسی</span></span></a>''')
    if st["open_reports"]:
        pending_cards.append(f'''<a class="todo-item" href="/panel/reports?status=open">
          {icon("alert")}<span><strong>{fa(st["open_reports"])} گزارش تخلف باز</strong><br><small class="text-muted">رسیدگی به گزارش‌های مردم</small></span>
          <span class="btn btn-primary btn-sm">{icon("arrow-left")}<span>رسیدگی</span></span></a>''')
    if st["pending_subs"]:
        pending_cards.append(f'''<a class="todo-item" href="/panel/subscriptions?status=pending">
          {icon("credit-card")}<span><strong>{fa(st["pending_subs"])} پرداخت در انتظار تأیید</strong><br><small class="text-muted">فیش‌های اشتراک دکان‌داران</small></span>
          <span class="btn btn-primary btn-sm">{icon("arrow-left")}<span>بررسی</span></span></a>''')

    todo_html = "".join(pending_cards)
    if not todo_html:
        todo_html = f'''<div class="alert alert-success" style="margin:0">
          {icon("check-circle")}<span>همهٔ کارها انجام شده است؛ هیچ کار معوق یا در انتظاری ندارید.</span></div>'''

    # Admin insights: market gaps + revenue
    _zrows = "".join(
        f'<tr><td><strong>{esc(r["term"])}</strong></td>'
        f'<td class="num nums">{fa(r["n"])}</td></tr>'
        for r in db.top_searches(days=30, limit=6, zero_only=True))
    _st_search = db.search_totals(30)
    _revenue = sum(x["amount"] for x in db.subscriptions(status="active"))
    _live = len([x for x in db.subscriptions(status="active") if x["is_live"]])
    _gap_card = f'''<div class="card glass card-pad mb-lg">
  <div class="between mb-md">
    <h2 class="card-title">{icon("search")} جست‌وجوهای بی‌نتیجه مردم در شهر</h2>
    <a class="btn btn-glass btn-sm" href="/panel/insights">{icon("chart")}<span>جزئیات آمار</span></a>
  </div>
  <p class="text-sm text-muted mb-md">این‌ها عناوینی هستند که مردم جست‌وجو کرده‌اند اما کسب‌وکاری نیافته‌اند — فرصتی عالی برای دعوت از این اصناف به دست گیر.</p>
  {f'<div class="table-wrap"><table class="table"><tbody>{_zrows}</tbody></table></div>' if _zrows else '<p class="text-sm text-muted">هر جست‌وجویی نتیجه داشته است — عالی است.</p>'}
</div>'''

    _cust = db.customer_counts()
    _audit = db.audit_log(6)
    _audit_rows = "".join(
        f'<tr><td><code>{esc(r["action"])}</code></td>'
        f'<td class="text-muted text-sm">{esc(r["detail"])}</td>'
        f'<td class="nums text-muted">{esc(jdatetime(r["created"]))}</td></tr>'
        for r in _audit)
    _activity_card = f'''<div class="card glass card-pad mb-lg">
  <div class="between mb-md">
    <h2 class="card-title">{icon("activity")} آخرین فعالیت‌های پنل</h2>
    <a class="btn btn-glass btn-sm" href="/panel/audit">{icon("list")}<span>همهٔ فعالیت‌ها</span></a>
  </div>
  {f'<div class="table-wrap"><table class="table"><tbody>{_audit_rows}</tbody></table></div>' if _audit_rows else '<p class="text-sm text-muted">هنوز فعالیتی ثبت نشده است.</p>'}
</div>'''

    # v237: server-health card — the same live getters the admin bot uses.
    try:
        _hq = len([f for f in os.listdir(adminbot.queue_dir()) if f.endswith(".json")])
    except OSError:
        _hq = 0
    _alerts = adminbot._active_alerts()
    _health_card = f'''<div class="card glass card-pad mb-lg">
  <div class="between mb-md">
    <h2 class="card-title">{icon("activity")} سلامت سرور</h2>
    <span class="text-sm text-muted">همان دیده‌بان بات مدیریتی</span>
  </div>
  <div class="table-wrap"><table class="table"><tbody>
    <tr><td>سرویس</td><td class="nums"><strong>{esc(adminbot.g_svc_cached())}</strong></td><td>آپتایم</td><td class="nums">{esc(adminbot.g_up())}</td></tr>
    <tr><td>دیسک</td><td class="nums">{esc(adminbot.g_disk())}</td><td>گواهی</td><td class="nums">{esc(adminbot.g_cert_cached())} روز</td></tr>
    <tr><td>بکاپ خارجی</td><td class="nums" colspan="3">{esc(adminbot.g_backup())}</td></tr>
    <tr><td>خطای ۲۴ ساعت</td><td class="nums">{fa(adminbot.g_errcount_cached())}</td><td>صف اجرا</td><td class="nums">{fa(_hq)}</td></tr>
    <tr><td>هشدار فعال</td><td colspan="3">{" ، ".join(esc(a) for a in _alerts) if _alerts else '<span class="text-muted">—</span>'}</td></tr>
  </tbody></table></div>
</div>'''

    content = f'''{_msg(q or {})}

<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("store", st['businesses'], "کسب‌وکار منتشرشده", href="/panel/businesses?status=published")}
  {stat_card("layers", st['categories'], "دستهٔ فعال", delay=60, href="/panel/categories")}
  {stat_card("message", st['reviews'], "نظر تأییدشده", delay=120, href="/panel/reviews?status=approved")}
  {stat_card("eye", st['views'], "بازدید کل", delay=180, href="/panel/insights")}
</div>

<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("users", _cust['customers'], "مشتری ثبت‌نام‌شده", href="/panel/customers")}
  {stat_card("cart", _cust['orders'], "سفارش آنلاین", delay=60, href="/panel/orders")}
  {stat_card("message", _cust['chats'], "گفتگو", delay=120, href="/panel/chats")}
  {stat_card("mail", _cust['messages'], "پیام جدید", delay=180, href="/panel/messages")}
</div>

<div class="card glass card-pad mb-lg">
  <div class="between mb-md">
    <h2 class="card-title">{icon("bell")} کارهای در انتظار بررسی مدیر</h2>
    <a class="btn btn-glass btn-sm" href="/panel/moderation">{icon("shield")}<span>صف تعدیل کامل</span></a>
  </div>
  <div class="todo-list">{todo_html}</div>
</div>

<div class="grid grid-2 mb-lg" style="grid-template-columns:minmax(0,1fr) minmax(0,340px);align-items:start">
  <div class="card glass card-pad">
    <div class="between mb-md">
      <h2 class="card-title">{icon("store")} آخرین کسب‌وکارهای ثبت‌شده</h2>
      <a class="btn btn-primary btn-sm" href="/panel/business/new">
        {icon("plus")}<span>ثبت جدید</span></a>
    </div>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>کسب‌وکار</th><th>بازدید</th><th>وضعیت</th><th>عملیات</th></tr></thead>
      <tbody>{rows}</tbody></table></div>
  </div>
  <div>
    {_gap_card}
  </div>
</div>

<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-lg">{icon("grid")} دسترسی سریع به بخش‌های اصلی پنل</h2>
  <div class="grid grid-4" style="gap:12px">
    <a class="btn btn-glass" href="/panel/businesses">{icon("store")}<span>کسب‌وکارها</span></a>
    <a class="btn btn-glass" href="/panel/categories">{icon("layers")}<span>دسته‌بندی‌ها</span></a>
    <a class="btn btn-glass" href="/panel/reviews">{icon("message")}<span>نظرات</span></a>
    <a class="btn btn-glass" href="/panel/orders">{icon("cart")}<span>سفارش‌ها</span></a>
    <a class="btn btn-glass" href="/panel/ads">{icon("zap")}<span>تبلیغات</span></a>
    <a class="btn btn-glass" href="/panel/plans">{icon("wallet")}<span>پلن‌ها و تعرفه</span></a>
    <a class="btn btn-glass" href="/panel/appearance">{icon("palette")}<span>ظاهر سایت</span></a>
    <a class="btn btn-glass" href="/panel/settings">{icon("settings")}<span>تنظیمات اصلی</span></a>
    <a class="btn btn-glass" href="/panel/backup">{icon("database")}<span>پشتیبان‌گیری</span></a>
    <a class="btn btn-glass" href="/panel/tickets">{icon("help")}<span>تیکت‌ها</span></a>
    <a class="btn btn-glass" href="/panel/stories">{icon("image")}<span>استوری‌ها</span></a>
    <a class="btn btn-primary" href="/" target="_blank" rel="noopener">{icon("external")}<span>مشاهدهٔ سایت اصلی</span></a>
  </div>
</div>

{_health_card}

{_activity_card}'''
    return panel_page(s, "داشبورد مدیریت دست گیر",
                      "نمای کلی سیستم، کارهای در انتظار و دسترسی سریع.", content, "/panel", token,
                      counts=counts)


# ------------------------------------------------------------------ businesses
def biz_list(s, token, q=None):
    q = q or {}
    g = lambda k, d="": (q.get(k) or [d])[0]
    term, status, cat = g("q"), g("status"), g("cat")
    sort = g("sort", "newest")
    try:
        page = max(1, int(g("page", "1") or 1))
    except ValueError:
        page = 1

    res = db.admin_businesses(q=term, status=status, cat=cat, page=page, sort=sort)
    rows, total, pages, cur = res["rows"], res["total"], res["pages"], res["page"]
    cats = db.categories(only_active=False)
    cmap = {c["slug"]: c for c in cats}

    STATUS = {"published": ("badge-open", "منتشرشده"),
              "pending": ("badge-warn", "در انتظار تأیید"),
              "hidden": ("badge-neutral", "مخفی"),
              "rejected": ("badge-closed", "رد شده")}

    trs = "".join(f'''<tr>
      <td><label class="check" style="min-height:0">
        <input type="checkbox" name="ids" value="{b["id"]}" form="bulk-form" data-bulk-item>
        <span class="sr-only">انتخاب {esc(b["name"])}</span></label></td>
      <td><div style="display:flex;align-items:center;gap:10px">
        {cat_icon(cmap.get(b["cat_slug"],{}).get("icon","store"), 34)}
        <div><strong>{esc(b["name"])}</strong><br>
          <small class="text-muted">{esc(cmap.get(b["cat_slug"],{}).get("name", b["cat_slug"]))}</small></div></div></td>
      <td class="num">{fa(round(b.get("rating") or 0, 1))}</td>
      <td class="num">{fa(b["views"])}</td>
      <td>{'<span class="badge badge-featured">ویژه</span>' if b["featured"] else '<span class="text-muted text-xs">—</span>'}</td>
      <td><span class="badge {STATUS.get(b["status"], ("badge-neutral",""))[0]}">
        {esc(STATUS.get(b["status"], ("", b["status"]))[1])}</span></td>
      <td class="actions">
        {approve_btn(b, token)}
        <a class="btn-icon" href="/b/{esc(b["slug"])}" target="_blank" rel="noopener"
           aria-label="مشاهدهٔ {esc(b["name"])}" title="مشاهده در سایت">{icon("eye")}</a>
        <a class="btn-icon" href="/panel/business/{b["id"]}"
           aria-label="ویرایش {esc(b["name"])}" title="ویرایش">{icon("edit")}</a>
        <a class="btn-icon" href="/panel/catalog/{b["id"]}"
           aria-label="کاتالوگ {esc(b["name"])}" title="کاتالوگ">{icon("shopping")}</a>
        <form method="post" action="/panel/business/{b["id"]}/delete" style="display:inline"
              data-confirm="حذف «{esc(b["name"])}»؟">
          <button class="btn-icon" type="submit" aria-label="حذف {esc(b["name"])}"
            title="حذف" style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for b in rows)

    # Mobile Cards View
    cards_html = "".join(f'''<div class="panel-biz-card hide-desktop">
      <div class="between" style="align-items:flex-start">
        <div style="display:flex;align-items:center;gap:10px">
          {cat_icon(cmap.get(b["cat_slug"],{}).get("icon","store"), 36)}
          <div>
            <strong>{esc(b["name"])}</strong>
            <div class="text-xs text-muted">{esc(cmap.get(b["cat_slug"],{}).get("name", b["cat_slug"]))}</div>
          </div>
        </div>
        <span class="badge {STATUS.get(b["status"], ("badge-neutral",""))[0]}">
          {esc(STATUS.get(b["status"], ("", b["status"]))[1])}
        </span>
      </div>
      <div class="cluster text-xs text-muted">
        <span>{icon("eye")}<strong class="nums">{fa(b["views"])}</strong> بازدید</span>
        <span>{icon("star")}<strong class="nums">{fa(round(b.get("rating") or 0, 1))}</strong> امتیاز</span>
        {f'<span>{icon("phone")}<span class="nums" dir="ltr">{esc(b["phone"])}</span></span>' if b.get("phone") else ''}
      </div>
      <div class="panel-biz-actions">
        {approve_btn(b, token)}
        <a class="btn btn-ghost btn-sm" href="/b/{esc(b["slug"])}" target="_blank" rel="noopener">{icon("eye")}<span>دیدن</span></a>
        <a class="btn btn-primary btn-sm" href="/panel/business/{b["id"]}">{icon("edit")}<span>ویرایش</span></a>
        <a class="btn btn-glass btn-sm" href="/panel/catalog/{b["id"]}">{icon("shopping")}<span>کالاها</span></a>
        <form method="post" action="/panel/business/{b["id"]}/delete" style="display:inline" data-confirm="حذف «{esc(b["name"])}»؟">
          <button class="btn btn-ghost btn-sm" type="submit" style="color:var(--color-destructive)">{icon("trash")}<span>حذف</span></button>
        </form>
      </div>
    </div>''' for b in rows)

    if not trs:
        trs = f'''<tr><td colspan="7"><div class="empty-state" style="padding:var(--space-2xl)">
          <span class="icon-wrap">{icon("store")}</span>
          <h3>{"نتیجه‌ای یافت نشد" if (term or status or cat) else "هنوز کسب‌وکاری نیست"}</h3>
          <p>{"عبارت جست‌وجو یا فیلترها را تغییر دهید." if (term or status or cat)
              else "اولین کسب‌وکار را اضافه کنید تا روی سایت نمایش داده شود."}</p>
          <a class="btn btn-primary mt-lg" href="/panel/business/new">
            {icon("plus")}<span>افزودن کسب‌وکار</span></a></div></td></tr>'''

    def link(**kw):
        p = {"q": term, "status": status, "cat": cat,
             "sort": sort, "page": cur}
        p.update(kw)
        return "/panel/businesses?" + urlencode({k: v for k, v in p.items() if v not in ("", None)})

    filt = "".join(f'<a class="chip{" is-active" if status == v else ""}" href="{link(status=v, page=1)}">{t}</a>'
                   for v, t in [("", "همه"), ("pending", "در انتظار تأیید"),
                                ("published", "منتشرشده"), ("hidden", "مخفی"),
                                ("rejected", "رد شده")])

    cat_opts = cat_options(cats, selected=cat, blank="همهٔ دسته‌ها",
                           group_selectable=True)
    sort_opts = "".join(
        f'<option value="{v}"{" selected" if sort == v else ""}>{t}</option>'
        for v, t in [("newest", "جدیدترین"), ("oldest", "قدیمی‌ترین"),
                     ("name", "حروف الفبا"), ("views", "پربازدیدترین"),
                     ("rating", "بیشترین امتیاز")])

    pager = ""
    if pages > 1:
        nums = ""
        for n in range(1, pages + 1):
            if n == 1 or n == pages or abs(n - cur) <= 2:
                nums += (f'<span class="pg-cur">{fa(n)}</span>' if n == cur
                         else f'<a href="{link(page=n)}">{fa(n)}</a>')
            elif abs(n - cur) == 3:
                nums += '<span class="pg-gap">…</span>'
        pager = f'''<nav class="pager" aria-label="صفحه‌بندی">
          {f'<a href="{link(page=cur-1)}">{icon("chevron-right")}<span>قبلی</span></a>' if cur > 1 else ""}
          {nums}
          {f'<a href="{link(page=cur+1)}"><span>بعدی</span>{icon("chevron-left")}</a>' if cur < pages else ""}
        </nav>'''

    bulk_cats = cat_options(cats)

    content = f'''{_msg(q)}
<div class="dir-chips cluster mb-md">{filt}</div>
<form class="dir-toolbar mb-lg" method="get" action="/panel/businesses" style="position:static">
  <input type="hidden" name="status" value="{esc(status)}">
  <div class="dir-row">
    <span class="search-wrap" style="flex:2">{icon("search", cls="search-icon")}
      <label class="sr-only" for="bq">جست‌وجو</label>
      <input class="input" id="bq" name="q" type="search" value="{esc(term)}"
             placeholder="نام کسب‌وکار، نشانی یا شماره تماس…" autocomplete="off">
    </span>
    <label class="sr-only" for="bcat">دسته</label>
    <select class="select" id="bcat" name="cat">{cat_opts}</select>
    <label class="sr-only" for="bsort">مرتب‌سازی</label>
    <select class="select" id="bsort" name="sort">{sort_opts}</select>
    <button class="btn btn-primary" type="submit">{icon("search")}<span>فیلتر</span></button>
    {f'<a class="btn btn-ghost" href="/panel/businesses">{icon("x")}<span>پاک کردن</span></a>' if (term or status or cat) else ''}
  </div>
</form>

<div class="between mb-md">
  <span class="text-sm text-muted">نمایش <strong>{fa(len(rows))}</strong> از <strong>{fa(total)}</strong> کسب‌وکار</span>
  <div class="cluster">
    <a class="btn btn-primary btn-sm" href="/panel/business/new">
      {icon("plus")}<span>کسب‌وکار جدید</span></a>
    <a class="btn btn-glass btn-sm" href="/panel/businesses/export">
      {icon("download")}<span>خروجی CSV</span></a>
  </div>
</div>

<form id="bulk-form" method="post" action="/panel/businesses/bulk" data-bulk class="bulk-bar">
  <label class="chip" data-check-all="form:bulk-form"><input type="checkbox" aria-label="انتخاب همه"> انتخاب همه</label>
  <label class="sr-only" for="bulk-act">عملیات گروهی</label>
  <select class="select" id="bulk-act" name="action" data-bulk-action>
    <option value="publish">انتشار</option>
    <option value="hide">مخفی‌سازی</option>
    <option value="reject">رد</option>
    <option value="delete">حذف</option>
    <option value="set_cat">تغییر دسته…</option>
  </select>
  <select class="select" name="new_cat" data-bulk-cat hidden aria-label="دستهٔ مقصد برای انتقال">{bulk_cats}</select>
  <button class="btn btn-primary btn-sm" type="submit">{icon("zap")}<span>اجرا روی انتخاب‌شده‌ها</span></button>
</form>

<div class="card glass card-pad hide-mobile mb-lg">
  <div class="table-wrap"><table class="table">
    <thead><tr>
      <th style="width:36px"></th>
      <th>کسب‌وکار</th>
      <th>امتیاز</th>
      <th>بازدید</th>
      <th>ویژه</th>
      <th>وضعیت</th>
      <th>عملیات</th>
    </tr></thead>
    <tbody>{trs}</tbody></table></div>
</div>

<div class="hide-desktop mb-lg">
  {cards_html or '<div class="card glass card-pad text-center text-muted">کسب‌وکاری یافت نشد.</div>'}
</div>

{pager}'''
    return panel_page(s, "مدیریت کسب‌وکارها",
                      "مشاهده، ویرایش، تغییر وضعیت و حذف کسب‌وکارهای ثبت‌شده.",
                      content, "/panel/businesses", token)
    sort = g("sort", "newest")
    try:                                  # v117/M2: ?page=abc must not 500
        page = max(1, int(g("page", "1") or 1))
    except ValueError:
        page = 1

    res = db.admin_businesses(q=term, status=status, cat=cat, page=page, sort=sort)
    rows, total, pages, cur = res["rows"], res["total"], res["pages"], res["page"]
    cats = db.categories(only_active=False)
    cmap = {c["slug"]: c for c in cats}

    STATUS = {"published": ("badge-open", "منتشرشده"),
              "pending": ("badge-warn", "در انتظار تأیید"),
              "hidden": ("badge-neutral", "مخفی"),
              "rejected": ("badge-closed", "رد شده")}

    trs = "".join(f'''<tr>
      <td><label class="check" style="min-height:0">
        <input type="checkbox" name="ids" value="{b["id"]}" form="bulk-form" data-bulk-item>
        <span class="sr-only">انتخاب {esc(b["name"])}</span></label></td>
      <td><div style="display:flex;align-items:center;gap:10px">
        {cat_icon(cmap.get(b["cat_slug"],{}).get("icon","store"), 34)}
        <div><strong>{esc(b["name"])}</strong><br>
          <small class="text-muted">{esc(cmap.get(b["cat_slug"],{}).get("name", b["cat_slug"]))}</small></div></div></td>
      <td class="num">{fa(round(b.get("rating") or 0, 1))}</td>
      <td class="num">{fa(b["views"])}</td>
      <td>{'<span class="badge badge-featured">ویژه</span>' if b["featured"] else '<span class="text-muted text-xs">—</span>'}</td>
      <td><span class="badge {STATUS.get(b["status"], ("badge-neutral",""))[0]}">
        {esc(STATUS.get(b["status"], ("", b["status"]))[1])}</span></td>
      <td class="actions">
        {approve_btn(b, token)}
        <a class="btn-icon" href="/b/{esc(b["slug"])}" target="_blank" rel="noopener"
           aria-label="مشاهدهٔ {esc(b["name"])}" title="مشاهده">{icon("eye")}</a>
        <a class="btn-icon" href="/panel/business/{b["id"]}"
           aria-label="ویرایش {esc(b["name"])}" title="ویرایش">{icon("edit")}</a>
        <a class="btn-icon" href="/panel/catalog/{b["id"]}"
           aria-label="کاتالوگ {esc(b["name"])}" title="کاتالوگ">{icon("shopping")}</a>
        <form method="post" action="/panel/business/{b["id"]}/delete" style="display:inline"
              data-confirm="حذف «{esc(b["name"])}»؟">
                    <button class="btn-icon" type="submit" aria-label="حذف {esc(b["name"])}"
            title="حذف" style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for b in rows)

    if not trs:
        trs = f'''<tr><td colspan="7"><div class="empty-state" style="padding:var(--space-2xl)">
          <span class="icon-wrap">{icon("store")}</span>
          <h3>{"نتیجه‌ای یافت نشد" if (term or status or cat) else "هنوز کسب‌وکاری نیست"}</h3>
          <p>{"عبارت جست‌وجو یا فیلترها را تغییر دهید." if (term or status or cat)
              else "اولین کسب‌وکار را اضافه کنید تا روی سایت نمایش داده شود."}</p>
          <a class="btn btn-primary mt-lg" href="/panel/business/new">
            {icon("plus")}<span>افزودن کسب‌وکار</span></a></div></td></tr>'''

    def link(**kw):
        p = {"q": term, "status": status, "cat": cat,
             "sort": sort, "page": cur}   # v117/M1: keyless (cookie auth)
        p.update(kw)
        return "/panel/businesses?" + urlencode({k: v for k, v in p.items() if v not in ("", None)})

    filt = "".join(f'<a class="chip{" is-active" if status == v else ""}" href="{link(status=v, page=1)}">{t}</a>'
                   for v, t in [("", "همه"), ("pending", "در انتظار تأیید"),
                                ("published", "منتشرشده"), ("hidden", "مخفی"),
                                ("rejected", "رد شده")])

    # group_selectable: filtering by a parent should sweep its whole branch
    cat_opts = cat_options(cats, selected=cat, blank="همهٔ دسته‌ها",
                           group_selectable=True)
    sort_opts = "".join(
        f'<option value="{v}"{" selected" if sort == v else ""}>{t}</option>'
        for v, t in [("newest", "جدیدترین"), ("oldest", "قدیمی‌ترین"),
                     ("name", "حروف الفبا"), ("views", "پربازدیدترین"),
                     ("rating", "بیشترین امتیاز")])

    pager = ""
    if pages > 1:
        nums = ""
        for n in range(1, pages + 1):
            if n == 1 or n == pages or abs(n - cur) <= 2:
                nums += (f'<span class="pg-cur">{fa(n)}</span>' if n == cur
                         else f'<a href="{link(page=n)}">{fa(n)}</a>')
            elif abs(n - cur) == 3:
                nums += '<span class="pg-gap">…</span>'
        pager = f'''<nav class="pager" aria-label="صفحه‌بندی">
          {f'<a href="{link(page=cur-1)}">{icon("chevron-right")}<span>قبلی</span></a>' if cur > 1 else ""}
          {nums}
          {f'<a href="{link(page=cur+1)}"><span>بعدی</span>{icon("chevron-left")}</a>' if cur < pages else ""}
        </nav>'''

    bulk_cats = cat_options(cats)

    content = f'''{_msg(q)}
{pending_box(s, token) if not status else ""}

<form class="dir-toolbar" method="get" action="/panel/businesses" style="position:static">
    <div class="dir-row">
    <span class="search-wrap">{icon("search", cls="search-icon")}
      <label class="sr-only" for="ab-q">جست‌وجو</label>
      <input class="input" id="ab-q" name="q" type="search" value="{esc(term)}"
             placeholder="نام، نشانی، تلفن یا برچسب…" autocomplete="off"></span>
    <label class="sr-only" for="ab-cat">دسته</label>
    <select class="select" id="ab-cat" name="cat" onchange="this.form.submit()">{cat_opts}</select>
    <label class="sr-only" for="ab-sort">مرتب‌سازی</label>
    <select class="select" id="ab-sort" name="sort" onchange="this.form.submit()">{sort_opts}</select>
    <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
  </div>
  <div class="dir-chips">{filt}</div>
</form>

<div class="dir-meta">
  <span><strong class="nums">{fa(total)}</strong> کسب‌وکار
    {f'· صفحهٔ {fa(cur)} از {fa(pages)}' if pages > 1 else ""}</span>
  <div class="cluster">
    <a class="btn btn-glass btn-sm" href="/panel/businesses/export">
      {icon("download")}<span>خروجی CSV</span></a>
    <a class="btn btn-glass btn-sm" href="/panel/businesses/import">
      {icon("upload")}<span>ورود از CSV</span></a>
    <a class="btn btn-primary btn-sm" href="/panel/business/new">
      {icon("plus")}<span>کسب‌وکار جدید</span></a>
  </div>
</div>

<form id="bulk-form" method="post" action="/panel/businesses/bulk" data-bulk
      data-confirm-delete="کسب‌وکارهای انتخاب‌شده حذف شوند؟">
    <div class="bulk-bar" data-bulk-bar hidden>
    <strong><span data-bulk-count>۰</span> مورد انتخاب شده</strong>
    <div class="cluster">
      <button class="btn btn-glass btn-sm" type="submit" name="action" value="publish">
        {icon("check")}<span>انتشار</span></button>
      <button class="btn btn-glass btn-sm" type="submit" name="action" value="hide">
        {icon("eye")}<span>مخفی</span></button>
      <button class="btn btn-glass btn-sm" type="submit" name="action" value="feature">
        {icon("sparkles")}<span>ویژه</span></button>
      <button class="btn btn-glass btn-sm" type="submit" name="action" value="unfeature">
        {icon("x")}<span>لغو ویژه</span></button>
      <select class="select" name="cat_to" style="min-width:150px" aria-label="انتقال به دسته">
        <option value="">انتقال به دسته…</option>{bulk_cats}</select>
      <button class="btn btn-glass btn-sm" type="submit" name="action" value="move">
        {icon("layers")}<span>انتقال</span></button>
      <button class="btn btn-ghost btn-sm" type="submit" name="action" value="delete"
              style="color:var(--color-destructive)">{icon("trash")}<span>حذف</span></button>
    </div>
  </div>
</form>

<div class="card glass card-pad">
  <div class="table-wrap"><table class="table">
    <thead><tr>
      <th style="width:38px"><label class="check" style="min-height:0">
        <input type="checkbox" data-bulk-all>
        <span class="sr-only">انتخاب همه</span></label></th>
      <th>کسب‌وکار</th><th>امتیاز</th><th>بازدید</th><th>ویژه</th>
      <th>وضعیت</th><th>عملیات</th></tr></thead>
    <tbody>{trs}</tbody></table></div>
  {pager}
</div>
<script type="module" src="/assets/js/bulk.js"></script>'''
    return panel_page(s, "مدیریت کسب‌وکارها",
                      "جست‌وجو، فیلتر، عملیات گروهی و ورود/خروجی CSV.",
                      content, "/panel/businesses", token)


def biz_edit(s, token, bid=None, q=None):
    cats = db.categories(only_active=False)
    b = db.business(bid=bid) if bid else None
    new = b is None
    v = lambda k, d="": esc(b.get(k, d)) if b else esc(d)

    opts = cat_options(cats, selected=(b["cat_slug"] if b else ""))

    hm = b["hours_map"] if b else {}
    hrows = ""
    for k, label in DAYS:
        rng = hm.get(k) or []
        o = rng[0][0] if rng else "09:00"
        c = rng[0][1] if rng else "21:00"
        closed = "" if rng else " checked"
        hrows += f'''<div class="hours-row">
          <span class="text-sm fw-700">{label}</span>
          <input class="input" type="time" name="h_{k}_open" value="{esc(o)}" aria-label="ساعت شروع {label}">
          <input class="input" type="time" name="h_{k}_close" value="{esc(c)}" aria-label="ساعت پایان {label}">
          <label class="check"><input type="checkbox" name="h_{k}_closed"{closed}><span>تعطیل</span></label>
        </div>'''

    st_opts = "".join(f'<option value="{val}"{" selected" if b and b["status"]==val else ""}>{t}</option>'
                      for val, t in [("published","منتشرشده"),("pending","در انتظار"),("hidden","مخفی")])

    lat = b["lat"] if b and b["lat"] else s.get("map_lat", "32.6340")
    lng = b["lng"] if b and b["lng"] else s.get("map_lng", "51.3670")

    review_bar = ""
    if b and b["status"] != "published":
        lbl = {"pending": "این کسب‌وکار در انتظار تأیید شماست.",
               "hidden": "این کسب‌وکار مخفی است و روی سایت دیده نمی‌شود.",
               "rejected": "این درخواست قبلاً رد شده است."}.get(b["status"], "")
        review_bar = f'''<div class="card glass card-pad mb-lg review-bar">
          <div class="between">
            <div><strong>{icon("bell")} {esc(lbl)}</strong>
              <p class="text-sm text-muted mt-sm">پس از بررسی اطلاعات، تصمیم خود را ثبت کنید.</p></div>
            <div class="cluster">
              <form method="post" action="/panel/business/{bid}/status">
                                <input type="hidden" name="back" value="/panel/business/{bid}">
                <input type="hidden" name="status" value="published">
                <button class="btn btn-primary" type="submit">
                  {icon("check")}<span>تأیید و انتشار</span></button></form>
              <form method="post" action="/panel/business/{bid}/status"
                    data-confirm="این درخواست رد شود؟">
                                <input type="hidden" name="back" value="/panel/business/{bid}">
                <input type="hidden" name="status" value="rejected">
                <button class="btn btn-ghost" type="submit"
                        style="color:var(--color-destructive)">{icon("x")}<span>رد</span></button></form>
            </div>
          </div></div>'''

    content = f'''{_msg(q or {})}
{review_bar}
<form method="post" action="/panel/business/{bid or 'new'}" data-validate>
  
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("store")} اطلاعات پایه</h2>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="f-name">نام کسب‌وکار<span class="req">*</span></label>
        <input class="input" id="f-name" name="name" required minlength="2" value="{v('name')}"></div>
      <div class="field"><label class="field-label" for="f-cat">دسته<span class="req">*</span></label>
        <select class="select" id="f-cat" name="cat_slug" required>
          <option value="">انتخاب کنید…</option>{opts}</select></div>
    </div>
    <div class="field"><label class="field-label" for="f-desc">توضیحات<span class="req">*</span></label>
      <textarea class="textarea" id="f-desc" name="descr" required minlength="10">{v('descr')}</textarea></div>
    <div class="field"><label class="field-label" for="f-slogan">شعار کسب‌وکار</label>
      <input class="input" id="f-slogan" name="slogan" maxlength="120" value="{v('slogan')}"
             placeholder="یک جملهٔ کوتاه و به‌یادماندنی برای بخش «درباره»"></div>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="f-phone">تلفن</label>
        <input class="input" id="f-phone" name="phone" type="tel" value="{v('phone')}"></div>
      <div class="field"><label class="field-label" for="f-wa">واتساپ</label>
        <input class="input" id="f-wa" name="whatsapp" type="tel" value="{v('whatsapp')}"
               placeholder="989123456789"></div>
    </div>
    <div class="field"><label class="field-label" for="f-addr">نشانی</label>
      <input class="input" id="f-addr" name="address" value="{v('address')}"></div>
    <div class="field"><label class="field-label" for="f-area">محله</label>
      <input class="input" id="f-area" name="area" value="{v('area')}" maxlength="100" placeholder="مثلاً امیرآباد"></div>
    <div class="grid grid-2" style="align-items:start">
      <div class="field"><label class="field-label" for="f-prov">استان</label>
        <select class="select" id="f-prov" name="province">
          <option value="">—</option>
          {"".join(f'<option value="{esc(p)}"{" selected" if v("province")==p else ""}>{esc(p)}</option>' for p in db.provinces())}
        </select></div>
      <div class="field"><label class="field-label" for="f-city">شهر</label>
        <input class="input" id="f-city" name="city" value="{v('city')}" maxlength="100" placeholder="نام شهر"></div>
    </div>
    <div class="field"><label class="field-label" for="f-tags">برچسب‌ها</label>
      <input class="input" id="f-tags" name="tags" value="{v('tags')}" placeholder="با ویرگول جدا کنید"></div>
    <div class="grid grid-3" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="f-ig">اینستاگرام</label>
        <input class="input" id="f-ig" name="instagram" value="{v('instagram')}"></div>
      <div class="field"><label class="field-label" for="f-tg">تلگرام</label>
        <input class="input" id="f-tg" name="telegram" value="{v('telegram')}"></div>
      <div class="field"><label class="field-label" for="f-web">وب‌سایت</label>
        <input class="input" id="f-web" name="website" value="{v('website')}"></div>
    </div>
    <p class="field-label">پیام‌رسان‌های ایرانی</p>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="f-eitaa">ایتا</label>
        <input class="input" id="f-eitaa" name="eitaa" dir="ltr" value="{v('eitaa')}"></div>
      <div class="field"><label class="field-label" for="f-bale">بله</label>
        <input class="input" id="f-bale" name="bale" dir="ltr" value="{v('bale')}"></div>
      <div class="field"><label class="field-label" for="f-soroush">سروش</label>
        <input class="input" id="f-soroush" name="soroush" dir="ltr" value="{v('soroush')}"></div>
      <div class="field"><label class="field-label" for="f-rubika">روبیکا</label>
        <input class="input" id="f-rubika" name="rubika" dir="ltr" value="{v('rubika')}"></div>
    </div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("pin")} موقعیت روی نقشه</h2>
    <p class="text-sm text-muted mb-md">روی نقشه بزنید یا نشانگر را بکشید تا موقعیت دقیق ثبت شود.</p>
    <div class="map-stage" data-map-wrap data-map="pending" style="min-height:340px;border-radius:var(--radius-lg)">
      <div data-map-canvas data-pick data-lat="{lat}" data-lng="{lng}" style="position:absolute;inset:0"></div>
      <div class="map-legend">{icon("info")}<span data-map-status>در حال بارگذاری…</span></div>
    </div>
    <div class="grid grid-2 mt-md" style="gap:0 var(--space-md)">
      <div class="field" style="margin-bottom:0"><label class="field-label" for="f-lat">عرض جغرافیایی</label>
        <input class="input nums" id="f-lat" name="lat" value="{esc(lat)}"></div>
      <div class="field" style="margin-bottom:0"><label class="field-label" for="f-lng">طول جغرافیایی</label>
        <input class="input nums" id="f-lng" name="lng" value="{esc(lng)}"></div>
    </div>
    <button class="btn btn-glass btn-sm mt-md" type="button" data-geo-fill aria-label="دریافت موقعیت فعلی من">
      {icon("compass")}<span>گرفتن موقعیت فعلی من</span></button>
    <p class="field-hint" data-geo-msg hidden></p>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("clock")} ساعت کاری</h2>
    <div class="hours-grid">{hrows}</div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("settings")} وضعیت و نشان‌ها</h2>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="f-status">وضعیت انتشار</label>
        <select class="select" id="f-status" name="status">{st_opts}</select></div>
    </div>
    <label class="switch mb-md"><input type="checkbox" name="featured"
      {" checked" if b and b['featured'] else ""}><span class="track"></span>
      <span>کسب‌وکار ویژه (اولویت در نتایج)</span></label>
    <label class="switch mb-md"><input type="checkbox" name="verified"
      {" checked" if b and b['verified'] else ""}><span class="track"></span>
      <span>نشان «تأییدشده»</span></label>
    <label class="switch mb-md"><input type="checkbox" name="booking_on"
      {" checked" if b and b['booking_on'] else ""}><span class="track"></span>
      <span>فعال‌سازی رزرو نوبت آنلاین</span></label>
  </div>

  <div class="cluster">
    <button class="btn btn-primary btn-lg" type="submit">{icon("check")}
      <span>{"ایجاد کسب‌وکار" if new else "ذخیرهٔ تغییرات"}</span></button>
    <a class="btn btn-ghost btn-lg" href="/panel/businesses">
      {icon("x")}<span>انصراف</span></a>
    {f'<a class="btn btn-glass btn-lg" href="/panel/gallery/{bid}">{icon("image")}<span>گالری</span></a>' if b else ''}
    {f'<a class="btn btn-glass btn-lg" href="/panel/catalog/{bid}">{icon("shopping")}<span>کاتالوگ</span></a>' if b else ''}
    {f'<a class="btn btn-outline btn-lg" href="/b/{esc(b["slug"])}" target="_blank" rel="noopener">{icon("external")}<span>مشاهده در سایت</span></a>' if b else ''}
  </div>
</form>'''
    return panel_page(s, "کسب‌وکار جدید" if new else f"ویرایش: {b['name']}",
                      "همهٔ اطلاعات این کسب‌وکار را می‌توانید تغییر دهید.",
                      content, "/panel/businesses", token, extra_js=MAP_JS)


# ------------------------------------------------------------------ categories
def cat_list(s, token, q=None):
    tree = db.category_tree(only_active=False)
    all_icons = sorted({c["icon"] for c in db.categories(only_active=False)}
                       | set(ICON_CHOICES))
    icons = _icon_options(all_icons)
    n_all = len(db.categories(only_active=False))

    def row(c, child=False):
        pad = ' style="padding-inline-start:34px"' if child else ''
        kid_note = ""
        if not child and c.get("children"):
            kid_note = (f'<br><small class="text-muted">'
                        f'{fa(len(c["children"]))} زیردسته · '
                        f'{fa(c["total"])} کسب‌وکار با زیرمجموعه‌ها</small>')
        photo = _cat_photo(c)
        visual = (f'<img src="{esc(photo)}" alt="" width="44" height="44" '
                  f'style="width:44px;height:44px;object-fit:cover;border-radius:10px">'
                  if photo else cat_icon(c['icon'], 32 if child else 40))
        return f'''<tr class="{"cat-child" if child else "cat-parent"}">
      <td{pad}><div style="display:flex;align-items:center;gap:12px">
        {visual}
        <div>{"↳ " if child else ""}<strong>{esc(c['name'])}</strong>{kid_note}</div></div></td>
      <td><code class="text-xs">{esc(c['slug'])}</code></td>
      <td class="num nums">{fa(c['count'])}</td>
      <td><span class="badge {"badge-open" if c['active'] else "badge-neutral"}">
        {"فعال" if c['active'] else "غیرفعال"}</span></td>
      <td class="actions">
        <a class="btn-icon" href="/panel/category/{c['id']}"
           aria-label="ویرایش {esc(c['name'])}" title="ویرایش">{icon("edit")}</a>
        <form method="post" action="/panel/category/{c['id']}/delete" style="display:inline"
              data-confirm="حذف دستهٔ «{esc(c['name'])}»؟">
                    <button class="btn-icon" type="submit" aria-label="حذف {esc(c['name'])}" title="حذف"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>'''

    trs = ""
    for c in tree:
        trs += row(c)
        for k in c.get("children", []):
            trs += row(k, child=True)

    parent_opts = '<option value="">— دستهٔ اصلی (بدون والد) —</option>' + "".join(
        f'<option value="{esc(c["slug"])}">{esc(c["name"])}</option>' for c in tree)

    content = f'''{_msg(q or {})}
<div class="grid grid-2" style="grid-template-columns:minmax(0,1fr) minmax(0,360px);align-items:start">
  <div class="card glass card-pad">
    <div class="between mb-md">
      <h2 class="card-title">{icon("layers")} دسته‌بندی‌ها</h2>
      <span class="badge badge-neutral">{fa(len(tree))} دستهٔ اصلی · {fa(n_all)} مجموع</span>
    </div>
    <div class="search-wrap mb-md">
      {icon("search", cls="search-icon")}
      <label class="sr-only" for="pcat-q">جست‌وجوی دسته</label>
      <input class="input" id="pcat-q" type="search" placeholder="جست‌وجوی سریع نام یا شناسه دسته…"
             data-panel-cat-search autocomplete="off">
    </div>
    <div class="table-wrap"><table class="table" data-panel-cat-table>
      <thead><tr><th>دسته</th><th>شناسه</th><th>تعداد</th><th>وضعیت</th><th>عملیات</th></tr></thead>
      <tbody>{trs}</tbody></table></div>
  </div>

  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("plus")} افزودن دسته جدید</h2>
    <form method="post" action="/panel/category/new" enctype="multipart/form-data" data-validate>
      <div class="field"><label class="field-label" for="nc-name">نام دسته<span class="req">*</span></label>
        <input class="input" id="nc-name" name="name" required minlength="2"
               placeholder="مثلاً: خدمات دامپزشکی"></div>
      <div class="field"><label class="field-label" for="nc-parent">زیرمجموعهٔ کدام دسته؟</label>
        <select class="select" id="nc-parent" name="parent">{parent_opts}</select>
        <p class="field-hint">اگر خالی بماند، یک دستهٔ اصلی روی صفحهٔ نخست ساخته می‌شود.</p></div>
      <div class="field" data-icon-picker><label class="field-label" for="nc-icon">آیکون</label>
        <label class="sr-only" for="nc-icon-search">جست‌وجوی آیکون</label>
        <input class="input icon-search" id="nc-icon-search" type="search" data-icon-search
               placeholder="جست‌وجوی آیکون؛ مثلاً رستوران یا restaurant" autocomplete="off">
        <p class="field-hint" data-icon-search-status aria-live="polite">نام فارسی یا لاتین را بنویسید.</p>
        <select class="select" id="nc-icon" name="icon" data-icon-select>{icons}</select>
        <div class="icon-preview mt-sm" data-icon-preview>{cat_icon('store', 64)}</div></div>
      <div class="field"><span class="field-label">تصویر دسته</span>
        <p class="field-hint mb-sm">از گالری یا دوربین موبایل انتخاب کنید؛ تصویر پیش از ارسال بهینه می‌شود.</p>
        <div data-imagefield data-name="image" data-max="1" data-existing='[]'></div></div>
      <div class="field"><label class="field-label" for="nc-blurb">توضیح کوتاه</label>
        <textarea class="textarea" id="nc-blurb" name="blurb" style="min-height:80px"></textarea></div>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>ایجاد دسته</span></button>
    </form>
  </div>
</div>'''
    return panel_page(s, "مدیریت دسته‌بندی‌ها",
                      "دسته‌های سایت را اضافه، ویرایش یا حذف کنید.",
                      content, "/panel/categories", token, extra_js=IMAGEFIELD_JS)


def cat_edit(s, token, cid, q=None):
    c = db.category_by_id(cid) if hasattr(db, "category_by_id") else None
    if c is None:
        for x in db.categories(only_active=False):
            if x["id"] == cid:
                c = x
                break
    if not c:
        return None
    all_icons = sorted({x["icon"] for x in db.categories(only_active=False)}
                       | set(ICON_CHOICES))
    icons = _icon_options(all_icons, c["icon"])
    # a category may not be its own parent, and a parent that already has
    # children cannot itself become a child (we only support two levels)
    has_kids = bool(db.category_children(c["slug"], only_active=False))
    cur_parent = (c.get("parent") or "")
    if has_kids:
        parent_opts = ('<option value="">— دستهٔ اصلی —</option>')
        parent_note = "این دسته زیردسته دارد، پس خودش باید دستهٔ اصلی بماند."
    else:
        parent_opts = ('<option value="">— دستهٔ اصلی (بدون والد) —</option>' + "".join(
            f'<option value="{esc(x["slug"])}"'
            f'{" selected" if cur_parent == x["slug"] else ""}>{esc(x["name"])}</option>'
            for x in db.category_tree(only_active=False) if x["slug"] != c["slug"]))
        parent_note = "با انتخاب والد، این دسته زیرمجموعه می‌شود."
    photo = _cat_photo(c)
    content = f'''{_msg(q or {})}
<div class="card glass card-pad" style="max-width:640px">
  <form method="post" action="/panel/category/{cid}" enctype="multipart/form-data" data-validate>
        <div class="field"><label class="field-label" for="c-name">نام دسته<span class="req">*</span></label>
      <input class="input" id="c-name" name="name" required value="{esc(c['name'])}"></div>
    <div class="field"><label class="field-label" for="c-parent">زیرمجموعهٔ کدام دسته؟</label>
      <select class="select" id="c-parent" name="parent"{" disabled" if has_kids else ""}>{parent_opts}</select>
      {'<input type="hidden" name="parent" value="">' if has_kids else ''}
      <p class="field-hint">{esc(parent_note)}</p></div>
    <div class="field" data-icon-picker><label class="field-label" for="c-icon">آیکون</label>
      <label class="sr-only" for="c-icon-search">جست‌وجوی آیکون</label>
      <input class="input icon-search" id="c-icon-search" type="search" data-icon-search
             placeholder="جست‌وجوی آیکون؛ مثلاً رستوران یا restaurant" autocomplete="off">
      <p class="field-hint" data-icon-search-status aria-live="polite">نام فارسی یا لاتین را بنویسید.</p>
      <select class="select" id="c-icon" name="icon" data-icon-select>{icons}</select>
      <div class="icon-preview mt-sm" data-icon-preview>{cat_icon(c['icon'], 64)}</div></div>
    <div class="field"><span class="field-label">تصویر دسته</span>
      <p class="field-hint mb-sm">تصویر فعلی را حذف کنید یا از فایل‌های موبایل جایگزین کنید.</p>
      <div data-imagefield data-name="image" data-max="1"
           data-existing='{json_embed([photo] if photo else [])}'></div></div>
    <div class="field"><label class="field-label" for="c-blurb">توضیح کوتاه</label>
      <textarea class="textarea" id="c-blurb" name="blurb" style="min-height:80px">{esc(c['blurb'])}</textarea></div>
    <div class="field"><label class="field-label" for="c-sort">ترتیب نمایش</label>
      <input class="input nums" id="c-sort" name="sort" type="number" value="{c['sort']}"></div>
    <label class="switch mb-lg"><input type="checkbox" name="active"{" checked" if c['active'] else ""}>
      <span class="track"></span><span>دسته فعال باشد</span></label>
    <div class="cluster">
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
      <a class="btn btn-ghost" href="/panel/categories">{icon("x")}<span>انصراف</span></a>
    </div>
  </form>
</div>'''
    return panel_page(s, f"ویرایش دسته: {c['name']}",
                      "تغییر نام، تصویر، آیکون و ترتیب نمایش.",
                      content, "/panel/categories", token, extra_js=IMAGEFIELD_JS)


# ------------------------------------------------------------------ reviews
def _pg(q, default=1):
    """v117/M3: safe page parse (?page=abc must never 500)."""
    try:
        return min(1_000_000, max(1, int((q.get("page") or [str(default)])[0] or default)))
    except (TypeError, ValueError):
        return default


def panel_pager(base, page, pages, extra=""):
    """v117/M3: shared pagination nav for panel lists (keyless links)."""
    if pages <= 1:
        return ""
    def href(n):
        return f"{base}?{extra}{'&' if extra else ''}page={n}"
    nums = ""
    for n in range(1, pages + 1):
        if n in (1, pages) or abs(n - page) <= 2:
            nums += (f'<span class="pg-cur">{fa(n)}</span>' if n == page
                     else f'<a href="{href(n)}">{fa(n)}</a>')
        elif abs(n - page) == 3:
            nums += '<span class="pg-gap">…</span>'
    prev = (f'<a href="{href(page - 1)}">{icon("chevron-right")}<span>قبلی</span></a>'
            if page > 1 else "")
    nxt = (f'<a href="{href(page + 1)}"><span>بعدی</span>{icon("chevron-left")}</a>'
           if page < pages else "")
    return f'<nav class="pager" aria-label="صفحه‌بندی">{prev}{nums}{nxt}</nav>'


def rev_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or [""])[0]
    page = _pg(q)
    res = db.reviews(status=status or None, page=page, per=50)
    rows, pages = res["rows"], res["pages"]

    items = "".join(f'''<article class="review">
      <input type="checkbox" form="bulk-rev" name="ids" value="{r['id']}" class="rev-check" aria-label="انتخاب نظر {r['id']}">
      <div class="review-head"><span class="avatar" aria-hidden="true">{esc(r['author'][:1])}</span>
        <div style="flex:1"><strong>{esc(r['author'])}</strong>
          <div class="card-meta" style="margin-top:3px">{review_score_html(r['rating'])}
            <span aria-hidden="true">·</span>
            <a href="/b/{esc(r['bizslug'])}">{esc(r['bizname'])}</a></div></div>
        <span class="badge {"badge-open" if r['status']=='approved' else ("badge-warn" if r['status']=='pending' else "badge-closed")}">
          {esc({"approved":"تأییدشده","pending":"در انتظار","rejected":"رد شده"}.get(r['status']))}</span>
      </div>
      <p class="review-body">{esc(r['body'])}</p>
      {f'<div class="review-reply"><strong>{icon("store")}پاسخ شما</strong>{esc(r["reply"])}</div>' if r['reply'] else ''}
      <form method="post" action="/panel/review/{r['id']}" class="mt-md">
                <label class="sr-only" for="rp{r['id']}">پاسخ به نظر</label>
        <textarea class="textarea" id="rp{r['id']}" name="reply" style="min-height:80px"
          placeholder="پاسخ رسمی…">{esc(r['reply'])}</textarea>
        <div class="cluster mt-sm">
          <button class="btn btn-primary btn-sm" type="submit" name="action" value="reply">
            {icon("send")}<span>ثبت پاسخ</span></button>
          <button class="btn btn-glass btn-sm" type="submit" name="action" value="approve">
            {icon("check")}<span>تأیید</span></button>
          <button class="btn btn-glass btn-sm" type="submit" name="action" value="reject">
            {icon("x")}<span>رد</span></button>
          <button class="btn btn-ghost btn-sm" type="submit" name="action" value="delete"
            style="color:var(--color-destructive)">{icon("trash")}<span>حذف</span></button>
        </div>
      </form></article>''' for r in rows)

    if not items:
        items = f'''<div class="empty-state"><span class="icon-wrap">{icon("message")}</span>
          <h3>نظری در این بخش نیست</h3><p>وقتی مشتریان نظر ثبت کنند، اینجا نمایش داده می‌شود.</p></div>'''

    bulk_rev = f'''<form id="bulk-rev" method="post" action="/panel/reviews/bulk" class="bulk-bar">
      <label class="chip" data-check-all="form:bulk-rev"><input type="checkbox" aria-label="انتخاب همه"> همه</label>
      <select class="select" name="action" aria-label="عملیات گروهی">
        <option value="approve">تأیید</option>
        <option value="reject">رد</option>
        <option value="delete">حذف</option>
      </select>
      <button class="btn btn-primary btn-sm" type="submit">{icon("zap")}<span>اجرا روی انتخاب‌شده‌ها</span></button>
    </form>'''

    filt = "".join(f'<a class="chip{" is-active" if status==v else ""}" '
                   f'href="/panel/reviews?status={v}">{t}</a>'
                   for v, t in [("","همه"),("pending","در انتظار"),
                                ("approved","تأییدشده"),("rejected","رد شده")])
    content = f'''{_msg(q)}
<div class="cluster mb-lg">{filt}</div>
{bulk_rev}
{panel_pager("/panel/reviews", page, pages, extra=(f"status={esc(status)}" if status else ""))}
<div class="card glass card-pad">{items}</div>'''
    return panel_page(s, "مدیریت نظرات", "تأیید، رد و پاسخ به نظرات مشتریان.",
                      content, "/panel/reviews", token)


# ------------------------------------------------------------------ bookings
def _status_chips(base, items, cur_status, cur_q, counts, total_n):
    """v296: چیپ‌های فیلتر وضعیت با شمارنده — لینک‌پذیر و بوکمارک‌شدنی."""
    def _url(val):
        ps = {}
        if val:
            ps["status"] = val
        if cur_q:
            ps["q"] = cur_q
        return base + (("?" + urlencode(ps)) if ps else "")
    out = []
    for label, val in items:
        n = total_n if not val else counts.get(val, 0)
        active = (cur_status == val)
        cls = "btn-primary" if active else "btn-glass"
        out.append(f'<a class="btn btn-sm {cls}" href="{_url(val)}">'
                   f'{label} <span class="nums">{fa(n)}</span></a>')
    return '<div class="cluster mb-lg" style="flex-wrap:wrap">' + "".join(out) + "</div>"


BOOK_BADGE = {"new":"badge-warn","confirmed":"badge-info",
              "done":"badge-open","cancelled":"badge-closed"}
BOOK_LABEL = {"new":"جدید","confirmed":"تأییدشده","done":"انجام‌شده","cancelled":"لغو"}


def book_list(s, token, q=None):
    q = q or {}
    page = _pg(q)
    _st = (q.get("status") or [""])[0].strip()
    if _st not in ("new", "confirmed", "done", "cancelled"):
        _st = ""
    _q = (q.get("q") or [""])[0].strip()[:80]
    res = db.bookings(page=page, per=50, status=_st or None, q=_q or None)
    rows, pages = res["rows"], res["pages"]
    for k in rows:
        k["_badge"] = BOOK_BADGE.get(k["status"], "badge-neutral")
        k["_label"] = BOOK_LABEL.get(k["status"], k["status"])
    _counts = {r["status"]: r["c"] for r in db._rows(
        "SELECT status, COUNT(*) c FROM bookings GROUP BY status")}
    _total_n = sum(_counts.values())
    trs = "".join(f'''<tr>
      <td><strong>{esc(k['name'])}</strong><br><small class="text-muted nums">{esc(k['phone'])}</small></td>
      <td>{esc(k['bizname'])}</td>
      <td class="num">{esc(jdate(k['date']))} — {esc(k['time'])}</td>
      <td>{esc(k['note'])[:40] or '<span class="text-muted">—</span>'}</td>
      <td><span class="badge {k['_badge']}">{esc(k['_label'])}</span></td>
      <td class="actions">
        <form method="post" action="/panel/booking/{k['id']}" style="display:flex;gap:4px">
                    <button class="btn-icon" type="submit" name="status" value="confirmed"
            aria-label="تأیید نوبت" title="تأیید">{icon("check")}</button>
          <button class="btn-icon" type="submit" name="status" value="done"
            aria-label="انجام شد" title="انجام شد">{icon("check-circle")}</button>
          <button class="btn-icon" type="submit" name="status" value="cancelled"
            aria-label="لغو نوبت" title="لغو" style="color:var(--color-destructive)">{icon("x")}</button>
        </form></td></tr>''' for k in rows)
    if not trs:
        trs = f'<tr><td colspan="6"><div class="empty-state" style="padding:var(--space-2xl)">' \
              f'<span class="icon-wrap">{icon("calendar")}</span><h3>نوبتی با این فیلتر نیست</h3>' \
              f'<p>نوبت‌های مشتریان اینجا می‌آید؛ فیلتر یا جستجو را تغییر دهید.</p></div></td></tr>'
    _qs_export = urlencode({k: v for k, v in (("status", _st), ("q", _q)) if v})
    chips = _status_chips("/panel/bookings",
                          [("همه", ""), ("جدید", "new"), ("تأییدشده", "confirmed"),
                           ("انجام‌شده", "done"), ("لغوشده", "cancelled")],
                          _st, _q, _counts, _total_n)
    content = f'''{_msg(q)}
{panel_pager("/panel/bookings", page, pages)}
<div class="between mb-md" style="flex-wrap:wrap;gap:10px">
  <form method="get" action="/panel/bookings" style="display:flex;gap:6px;flex:1;min-width:240px;max-width:420px">
    <input class="input" type="search" name="q" value="{esc(_q)}" placeholder="جستجو: نام یا تلفن مشتری…" aria-label="جستجوی نوبت">
    <input type="hidden" name="status" value="{esc(_st)}">
    <button class="btn btn-glass" type="submit">{icon("search")}<span>جستجو</span></button>
  </form>
  <a class="btn btn-ghost" href="/panel/bookings/export{'?' + _qs_export if _qs_export else ''}">{icon("download")}<span>خروجی CSV</span></a>
</div>
{chips}
<div class="card glass card-pad">
  <div class="table-wrap"><table class="table">
    <thead><tr><th>مشتری</th><th>کسب‌وکار</th><th>زمان</th><th>توضیح</th><th>وضعیت</th><th>عملیات</th></tr></thead>
    <tbody>{trs}</tbody></table></div></div>'''
    return panel_page(s, "نوبت‌های رزروشده", "درخواست‌های رزرو مشتریان را مدیریت کنید.",
                      content, "/panel/bookings", token)


# ------------------------------------------------------------------ posts
def post_list(s, token, q=None):
    rows = db.posts(status=None)
    trs = "".join(f'''<tr><td><strong>{esc(p['title'])}</strong><br>
      <small class="text-muted">{esc(p['excerpt'])[:60]}</small></td>
      <td class="num">{esc(jdate(p['created']))}</td>
      <td><span class="badge {"badge-open" if p['status']=='published' else "badge-neutral"}">
        {"منتشرشده" if p['status']=='published' else "پیش‌نویس"}</span></td>
      <td class="actions">
        <a class="btn-icon" href="/blog/{esc(p['slug'])}" target="_blank" rel="noopener"
           aria-label="مشاهدهٔ {esc(p['title'])}">{icon("eye")}</a>
        <a class="btn-icon" href="/panel/post/{p['id']}"
           aria-label="ویرایش {esc(p['title'])}">{icon("edit")}</a>
        <form method="post" action="/panel/post/{p['id']}/delete" style="display:inline"
              data-confirm="حذف «{esc(p['title'])}»؟">
                    <button class="btn-icon" type="submit" aria-label="حذف {esc(p['title'])}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for p in rows)
    if not trs:
        trs = '<tr><td colspan="4" class="text-center text-muted" style="padding:var(--space-xl)">هنوز مطلبی نیست</td></tr>'
    content = f'''{_msg(q or {})}
<div class="grid grid-2" style="grid-template-columns:minmax(0,1fr) minmax(0,380px);align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("book")} مطالب</h2>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>عنوان</th><th>تاریخ</th><th>وضعیت</th><th></th></tr></thead>
      <tbody>{trs}</tbody></table></div></div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("plus")} مطلب جدید</h2>
    <form method="post" action="/panel/post/new" data-validate
          enctype="multipart/form-data">
            <div class="field"><label class="field-label" for="p-title">عنوان<span class="req">*</span></label>
        <input class="input" id="p-title" name="title" required minlength="3"></div>
      <div class="field"><label class="field-label" for="p-ex">خلاصه</label>
        <textarea class="textarea" id="p-ex" name="excerpt" style="min-height:70px"></textarea></div>
      <div class="field"><label class="field-label" for="p-body">متن<span class="req">*</span></label>
        <textarea class="textarea" id="p-body" name="body" required minlength="20"
          style="min-height:160px"></textarea>
        <p class="field-hint">هر خط جدید یک پاراگراف می‌شود.</p></div>
      <div class="field"><label class="field-label" for="p-cv">تصویر کاور</label>
        <input class="input" id="p-cv" name="cover_file" type="file" accept="image/*">
        <p class="field-hint">jpg/png/webp — حداکثر ۳ مگابایت.</p></div>
      <div class="field"><label class="field-label" for="p-vf">ویدیو</label>
        <input class="input" id="p-vf" name="video_file" type="file" accept="video/mp4,video/webm,video/quicktime">
        <input class="input mt-sm" id="p-vu" name="video_url" type="url" dir="ltr"
               placeholder="https://www.aparat.com/v/… یا لینک مستقیم mp4">
        <p class="field-hint">آپلود مستقیم (mp4/webm/mov حداکثر ۶۴ مگابایت) یا لینک آپارات/یوتیوب/فایل ویدیوی خارجی — مثلاً از سایت وردپرسی.</p></div>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>انتشار</span></button>
    </form></div></div>'''
    return panel_page(s, "اخبار و مقالات", "مطالب بخش وبلاگ سایت را مدیریت کنید.",
                      content, "/panel/posts", token)


# v170/A5: ویرایش مقاله — قبلاً فقط ساخت/حذف بود و اصلاحِ غلطِ چاپی
# یعنی حذف مطلب و از دست رفتن آدرس (slug) آن.
def post_edit(s, token, pid, q=None):
    p = db.post_by_id(pid)
    if not p:
        return None
    pub = p["status"] == "published"
    content = f'''{_msg(q or {})}
<div class="grid grid-2" style="grid-template-columns:minmax(0,1fr) minmax(0,380px);align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("edit")} ویرایش مطلب</h2>
    <form method="post" action="/panel/post/{p['id']}" data-validate
          enctype="multipart/form-data">
      <div class="field"><label class="field-label" for="pe-title">عنوان<span class="req">*</span></label>
        <input class="input" id="pe-title" name="title" required minlength="3"
               value="{esc(p['title'])}"></div>
      <div class="field"><label class="field-label" for="pe-ex">خلاصه</label>
        <textarea class="textarea" id="pe-ex" name="excerpt" style="min-height:70px">{esc(p['excerpt'])}</textarea></div>
      <div class="field"><label class="field-label" for="pe-body">متن<span class="req">*</span></label>
        <textarea class="textarea" id="pe-body" name="body" required minlength="20"
          style="min-height:160px">{esc(p['body'])}</textarea>
        <p class="field-hint">هر خط جدید یک پاراگراف می‌شود.</p></div>
      <div class="field"><label class="field-label" for="pe-cv">تصویر کاور</label>
        {f'<img class="panel-media-prev" src="{esc(p["cover"])}" alt="" loading="lazy"><label class="check mt-sm"><input type="checkbox" name="clear_image" value="1"><span>کاور فعلی حذف شود</span></label>' if p.get('cover') else ''}
        <input class="input" id="pe-cv" name="cover_file" type="file" accept="image/*">
        <p class="field-hint">برای جایگزینی، فایل تازه انتخاب کنید.</p></div>
      <div class="field"><label class="field-label" for="pe-vf">ویدیو</label>
        {media_embed(p.get('video'), p['title']) if p.get('video') else ''}
        {f'<label class="check mt-sm"><input type="checkbox" name="clear_video" value="1"><span>ویدیوی فعلی حذف شود</span></label>' if p.get('video') else ''}
        <input class="input" id="pe-vf" name="video_file" type="file" accept="video/mp4,video/webm,video/quicktime">
        <input class="input mt-sm" id="pe-vu" name="video_url" type="url" dir="ltr"
               placeholder="https://www.aparat.com/v/… یا لینک مستقیم mp4">
        <p class="field-hint">آپلود مستقیم (حداکثر ۶۴ مگابایت) یا لینک مجاز — لینک، جای ویدیوی قبلی را می‌گیرد.</p></div>
      <div class="field"><label class="field-label" for="pe-st">وضعیت</label>
        <select class="select" id="pe-st" name="status">
          <option value="published" {"selected" if pub else ""}>منتشرشده</option>
          <option value="draft" {"selected" if not pub else ""}>پیش‌نویس</option>
        </select></div>
      <div class="cluster">
        <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیرهٔ تغییرات</span></button>
        <a class="btn btn-ghost" href="/panel/posts">بازگشت</a>
      </div>
    </form></div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("book")} مشخصات</h2>
    <p class="card-meta">نشانی عمومی: <code dir="ltr">/blog/{esc(p['slug'])}</code></p>
    <p class="card-meta">ایجاد: {esc(jdate(p['created']))}</p>
    <p class="card-meta">آدرس مطلب با ویرایش تغییر نمی‌کند.</p>
  </div></div>'''
    return panel_page(s, "ویرایش مطلب", p["title"],
                      content, "/panel/posts", token)


# ------------------------------------------------------------------ messages
def msg_list(s, token, q=None):
    page = _pg((q or {}))
    res = db.messages(page=page, per=50)
    rows, pages = res["rows"], res["pages"]
    items = "".join(f'''<article class="review">
      <div class="review-head"><span class="avatar" aria-hidden="true">{esc((m['name'] or '?')[:1])}</span>
        <div style="flex:1"><strong>{esc(m['name'])}</strong>
          <div class="card-meta" style="margin-top:3px"><span>{esc(m['subject'])}</span>
            <span aria-hidden="true">·</span><span>{esc(jdatetime(m['created']))}</span></div></div>
        <span class="badge {"badge-warn" if m['status']=='new' else "badge-neutral"}">
          {"جدید" if m['status']=='new' else "خوانده‌شده"}</span></div>
      <p class="review-body">{esc(m['body'])}</p>
      <div class="cluster mt-md">
        <a class="btn btn-primary btn-sm" href="mailto:{esc(m['email'])}">{icon("mail")}<span>پاسخ ایمیلی</span></a>
        <form method="post" action="/panel/message/{m['id']}" style="display:inline">
                    <button class="btn btn-glass btn-sm" type="submit" name="action" value="read">
            {icon("check")}<span>خوانده شد</span></button></form>
        <form method="post" action="/panel/message/{m['id']}" style="display:inline"
              data-confirm="حذف این پیام؟">
                    <button class="btn btn-ghost btn-sm" type="submit" name="action" value="delete"
            style="color:var(--color-destructive)">{icon("trash")}<span>حذف</span></button></form>
      </div></article>''' for m in rows)
    if not items:
        items = f'<div class="empty-state"><span class="icon-wrap">{icon("mail")}</span>' \
                f'<h3>پیامی نیست</h3><p>پیام‌های فرم تماس اینجا نمایش داده می‌شوند.</p></div>'
    content = (f'{_msg(q or {})}{panel_pager("/panel/messages", page, pages)}'
               f'<div class="card glass card-pad">{items}</div>')
    return panel_page(s, "پیام‌های دریافتی", "پیام‌های ارسالی از فرم تماس.",
                      content, "/panel/messages", token)


# ------------------------------------------------------------------ pages
def pages_edit(s, token, q=None):
    about = db.get_page("about")
    rules = db.get_page("rules")
    content = f'''{_msg(q or {})}
<div class="tabs mb-lg" data-tabs role="tablist" aria-label="صفحات ثابت">
  <button role="tab" id="t-ab" aria-controls="p-ab" aria-selected="true">درباره ما</button>
  <button role="tab" id="t-ru" aria-controls="p-ru" aria-selected="false" tabindex="-1">قوانین</button>
</div>
<div class="tab-panel" id="p-ab" role="tabpanel" aria-labelledby="t-ab">
  <div class="card glass card-pad">
    <form method="post" action="/panel/pages" data-validate>
            <input type="hidden" name="slug" value="about">
      <div class="field"><label class="field-label" for="ab-t">عنوان</label>
        <input class="input" id="ab-t" name="title" value="{esc(about['title'])}"></div>
      <div class="field"><label class="field-label" for="ab-b">متن صفحه</label>
        <textarea class="textarea" id="ab-b" name="body" style="min-height:280px">{esc(about['body'])}</textarea>
        <p class="field-hint">هر خط جدید یک پاراگراف می‌شود.</p></div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
    </form></div></div>
<div class="tab-panel" id="p-ru" role="tabpanel" aria-labelledby="t-ru" hidden>
  <div class="card glass card-pad">
    <form method="post" action="/panel/pages" data-validate>
            <input type="hidden" name="slug" value="rules">
      <div class="field"><label class="field-label" for="ru-t">عنوان</label>
        <input class="input" id="ru-t" name="title" value="{esc(rules['title'])}"></div>
      <div class="field"><label class="field-label" for="ru-b">متن صفحه</label>
        <textarea class="textarea" id="ru-b" name="body" style="min-height:280px">{esc(rules['body'])}</textarea></div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
    </form></div></div>'''
    return panel_page(s, "صفحات ثابت", "متن صفحات «درباره ما» و «قوانین» را ویرایش کنید.",
                      content, "/panel/pages", token)


# ------------------------------------------------------------------ appearance
def appearance(s, token, q=None):
    colors = [("رنگ اصلی","color_primary",s.get("color_primary"),"دکمه‌ها، لینک‌ها و عناصر تعاملی"),
              ("رنگ تأکید","color_accent",s.get("color_accent"),"دکمهٔ فراخوان و نشان ویژه"),
              ("پس‌زمینه","color_background",s.get("color_background"),"پس‌زمینهٔ کلی صفحات"),
              ("متن اصلی","color_foreground",s.get("color_foreground"),"رنگ متن بدنه و عناوین")]
    crows = "".join(f'''<div class="color-row">
      <input type="color" name="{k}" value="{esc(v)}" aria-label="{n}" data-color-sync>
      <div class="meta"><strong>{n}</strong><small>{d}</small></div>
      <code>{esc(v)}</code></div>''' for n, k, v, d in colors)

    content = f'''{_msg(q or {})}
<form method="post" action="/panel/appearance" enctype="multipart/form-data">
  
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("image")} لوگوی سایت</h2>
    <p class="text-sm text-muted mb-lg">تصویری از گالری گوشی انتخاب کنید.
      اگر خالی بماند، نشان پیش‌فرض نمایش داده می‌شود.</p>
    <div data-imagefield data-name="logo" data-max="1"
         data-existing='{json_embed([s.get("site_logo")] if s.get("site_logo") else [])}'></div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("palette")} رنگ‌های سایت</h2>
    {crows}
    <div class="alert alert-info mt-lg">{icon("info")}
      <span>تغییر رنگ بلافاصله روی کل سایت اعمال می‌شود. اگر کنتراست کم شد،
        دکمهٔ «بازگشت به پیش‌فرض» را بزنید.</span></div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("edit")} متن‌های صفحهٔ اصلی</h2>
    <div class="field"><label class="field-label" for="a-h1">عنوان اصلی (هیرو)</label>
      <textarea class="textarea" id="a-h1" name="hero_title" style="min-height:80px">{esc(s.get('hero_title'))}</textarea>
      <p class="field-hint">برای شکستن خط، Enter بزنید.</p></div>
    <div class="field"><label class="field-label" for="a-lead">متن معرفی</label>
      <textarea class="textarea" id="a-lead" name="hero_lead" style="min-height:90px">{esc(s.get('hero_lead'))}</textarea></div>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="a-cta">متن دکمهٔ فراخوان</label>
        <input class="input" id="a-cta" name="hero_cta" value="{esc(s.get('hero_cta'))}"></div>
      <div class="field"><label class="field-label" for="a-fn">متن پاورقی</label>
        <input class="input" id="a-fn" name="footer_note" value="{esc(s.get('footer_note'))}"></div>
    </div>
  </div>

  <div class="cluster">
    <button class="btn btn-primary btn-lg" type="submit">{icon("check")}<span>ذخیرهٔ ظاهر</span></button>
    <button class="btn btn-ghost btn-lg" type="submit" name="reset" value="1">
      {icon("refresh")}<span>بازگشت به پیش‌فرض</span></button>
  </div>
</form>'''
    return panel_page(s, "ظاهر و رنگ‌ها",
                      "لوگو، رنگ‌ها، متن‌های اصلی و جلوه‌های بصری سایت.",
                      content, "/panel/appearance", token,
                      extra_js='<script type="module" src="' + av('/assets/js/imagefield.js') + '"></script>')


# ------------------------------------------------------------------ settings
def settings_page(s, token, q=None):
    prov = s.get("map_provider", "osm")
    # v141: OpenStreetMap (vendored, tokenless) is the one map everywhere.
    # audit F-013: service keys are never echoed back into the form — the
    # input renders empty with a "stored" placeholder instead.
    MASKED = "(ذخیره شده — برای تغییر، مقدار تازه بنویسید)"
    popts = "".join(f'<option value="{v}"{" selected" if (prov==v or (v=="osm" and prov in ("","auto") and not (s.get("gmaps_key") or "").strip())) else ""}>{t}</option>'
                    for v, t in [("osm","OpenStreetMap (پیش‌فرض — بدون توکن)"),
                                 ("auto","خودکار (OSM؛ گوگل فقط اگر فعال شود)"),
                                 ("google","گوگل مپ (نیازمند کلید معتبر)")])
    content = f'''{_msg(q or {})}
<div class="tabs mb-lg" data-tabs role="tablist" aria-label="بخش‌های تنظیمات">
  <button role="tab" id="t-g" aria-controls="p-g" aria-selected="true">عمومی</button>
  <button role="tab" id="t-m" aria-controls="p-m" aria-selected="false" tabindex="-1">نقشه</button>
  <button role="tab" id="t-f" aria-controls="p-f" aria-selected="false" tabindex="-1">امکانات</button>
  <button role="tab" id="t-x" aria-controls="p-x" aria-selected="false" tabindex="-1">پیامک</button>
  <button role="tab" id="t-e" aria-controls="p-e" aria-selected="false" tabindex="-1">ایمیل</button>
  <button role="tab" id="t-p" aria-controls="p-p" aria-selected="false" tabindex="-1">اعلان گوشی</button>
  <button role="tab" id="t-s" aria-controls="p-s" aria-selected="false" tabindex="-1">امنیت</button>
</div>

<div class="tab-panel" id="p-g" role="tabpanel" aria-labelledby="t-g">
  <form method="post" action="/panel/settings">
        <div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-lg">{icon("settings")} اطلاعات سایت</h2>
      <div class="grid grid-2" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="g-n">نام سایت</label>
          <input class="input" id="g-n" name="site_name" maxlength="60"
                 value="{esc(s.get('site_name') or 'دست گیر')}">
          <p class="field-hint">نام نمایشی سایت — هرچه بخواهی می‌توانی بگذاری.</p></div>
        <div class="field"><label class="field-label" for="g-t">شعار</label>
          <input class="input" id="g-t" name="tagline" value="{esc(s.get('tagline'))}"></div>
      </div>
      <div class="field"><label class="field-label" for="g-u">آدرس سایت</label>
        <input class="input" id="g-u" name="site_url" dir="ltr"
               placeholder="bazarche-najafabad.ir"
               value="{esc(s.get('site_url', ''))}">
        <p class="field-hint">تا وقتی دامنه نگرفته‌اید خالی بگذارید — سایت خودش
          آدرس را از مرورگر برمی‌دارد. بعد از خرید دامنه اینجا بنویسید تا
          بارکدهای QR، نقشهٔ سایت و لینک‌های اشتراک‌گذاری همه به آن اشاره کنند.</p></div>
      <div class="field"><label class="field-label" for="g-d">توضیح سئو</label>
        <textarea class="textarea" id="g-d" name="description" style="min-height:80px">{esc(s.get('description'))}</textarea></div>
      <div class="grid grid-2" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="g-p">تلفن نمایشی</label>
          <input class="input" id="g-p" name="phone" value="{esc(s.get('phone'))}"></div>
        <div class="field"><label class="field-label" for="g-pr">تلفن (برای لینک تماس)</label>
          <input class="input" id="g-pr" name="phone_raw" value="{esc(s.get('phone_raw'))}"></div>
      </div>
      <div class="field"><label class="field-label" for="g-e">ایمیل</label>
        <input class="input" id="g-e" name="email" type="email" value="{esc(s.get('email'))}"></div>
      <div class="field"><label class="field-label" for="g-a">نشانی</label>
        <input class="input" id="g-a" name="address" value="{esc(s.get('address'))}"></div>
      <div class="grid grid-3" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="g-ig">اینستاگرام</label>
          <input class="input" id="g-ig" name="instagram" value="{esc(s.get('instagram'))}"></div>
        <div class="field"><label class="field-label" for="g-tg">تلگرام</label>
          <input class="input" id="g-tg" name="telegram" value="{esc(s.get('telegram'))}"></div>
        <div class="field"><label class="field-label" for="g-wa">واتساپ</label>
          <input class="input" id="g-wa" name="whatsapp" value="{esc(s.get('whatsapp'))}"></div>
      </div>
      <p class="field-label">پیام‌رسان‌های ایرانیِ سایت <span class="text-muted">(لینک یا شناسهٔ کانال؛ خالی = نمایش داده نمی‌شود)</span></p>
      <div class="grid grid-2" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="g-eitaa">ایتا</label>
          <input class="input" id="g-eitaa" name="eitaa" dir="ltr" value="{esc(s.get('eitaa'))}" placeholder="https://eitaa.com/..."></div>
        <div class="field"><label class="field-label" for="g-bale">بله</label>
          <input class="input" id="g-bale" name="bale" dir="ltr" value="{esc(s.get('bale'))}" placeholder="https://ble.ir/..."></div>
        <div class="field"><label class="field-label" for="g-soroush">سروش</label>
          <input class="input" id="g-soroush" name="soroush" dir="ltr" value="{esc(s.get('soroush'))}" placeholder="https://splus.ir/..."></div>
        <div class="field"><label class="field-label" for="g-rubika">روبیکا</label>
          <input class="input" id="g-rubika" name="rubika" dir="ltr" value="{esc(s.get('rubika'))}" placeholder="https://rubika.ir/..."></div>
      </div>
      <div class="field"><label class="field-label" for="g-ga">شناسهٔ گوگل‌آنالیتیکس (GA4)</label>
        <input class="input" id="g-ga" name="ga_measurement_id" dir="ltr"
               placeholder="G-XXXXXXXXXX"
               value="{esc(s.get('ga_measurement_id', ''))}">
        <p class="field-hint">اختیاری. شناسه را از analytics.google.com بگیرید
          (راهنمای گام‌به‌گام: docs/google-analytics.md) و اینجا بچسبانید؛
          اسکریپت گوگل و همهٔ کوکی‌هایش (_ga) بدون بنر، فعال می‌شوند.
          خالی بگذارید = هیچ اسکریپت و کوکی گوگلی بارگذاری نمی‌شود —
          آمار واقعی سایت (IP + کوکی شناسهٔ بازدیدکننده) همیشه در
          «آمار بازدید» هست و به این فیلد نیاز ندارد.</p></div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
    </div>
  </form>
</div>

<div class="tab-panel" id="p-m" role="tabpanel" aria-labelledby="t-m" hidden>
  <form method="post" action="/panel/settings">
        <div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-lg">{icon("map")} تنظیمات نقشه</h2>
      <div class="field"><label class="field-label" for="m-p">سرویس نقشه</label>
        <select class="select" id="m-p" name="map_provider">{popts}</select></div>
      <div class="field"><label class="field-label" for="m-k">کلید Google Maps API</label>
        <input class="input" id="m-k" name="gmaps_key" value="" autocomplete="off" dir="ltr"
               placeholder="{MASKED if (s.get('gmaps_key') or '').strip() else 'AIza… (خالی بگذارید تا OpenStreetMap استفاده شود)'}">
        <p class="field-hint">نقشهٔ پیش‌فرض سایت و پنل OpenStreetMap است — بدون هیچ
          توکن/کلیدی، یکسان در همه‌جا. کلید Google فقط زمانی استفاده می‌شود که
          گزینهٔ «گوگل مپ» را برگزینید و کلید معتبر وارد شود؛ اگر کلید وارد نشود
          یا گوگل در دسترس نباشد، همان OpenStreetMap کار می‌کند.
          این کلید برای اجرای نقشه در مرورگرِ همهٔ بازدیدکننده‌هاست (عمومی است؛
          مثل شناسهٔ GA) — برای جلوگیری از سوءاستفاده در کنسول گوگل
          «محدودیت دامنه/Referrer» را فعال کنید.</p></div>
      <div class="grid grid-3" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="m-lat">عرض مرکز نقشه</label>
          <input class="input nums" id="m-lat" name="map_lat" value="{esc(s.get('map_lat'))}"></div>
        <div class="field"><label class="field-label" for="m-lng">طول مرکز نقشه</label>
          <input class="input nums" id="m-lng" name="map_lng" value="{esc(s.get('map_lng'))}"></div>
        <div class="field"><label class="field-label" for="m-z">بزرگ‌نمایی</label>
          <input class="input nums" id="m-z" name="map_zoom" type="number" min="1" max="20"
                 value="{esc(s.get('map_zoom'))}"></div>
      </div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
    </div>
  </form>
</div>

<div class="tab-panel" id="p-f" role="tabpanel" aria-labelledby="t-f" hidden>
  <form method="post" action="/panel/settings">
        <input type="hidden" name="features_tab" value="1">
    <div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-lg">{icon("zap")} فعال/غیرفعال کردن امکانات</h2>
      <label class="switch mb-md"><input type="checkbox" name="reg_open"
        {" checked" if s.get('reg_open')=='1' else ""}><span class="track"></span>
        <span>ثبت کسب‌وکار جدید توسط کاربران باز باشد</span></label>
      <label class="switch mb-md"><input type="checkbox" name="reviews_moderated"
        {" checked" if s.get('reviews_moderated')=='1' else ""}><span class="track"></span>
        <span>نظرات پیش از انتشار بررسی شوند</span></label>
      <label class="switch mb-md"><input type="checkbox" name="booking_enabled"
        {" checked" if s.get('booking_enabled')=='1' else ""}><span class="track"></span>
        <span>رزرو نوبت آنلاین فعال باشد</span></label>
      <label class="switch mb-md"><input type="checkbox" name="blog_enabled"
        {" checked" if s.get('blog_enabled')=='1' else ""}><span class="track"></span>
        <span>بخش اخبار و مقالات فعال باشد</span></label>
      <label class="switch mb-md"><input type="checkbox" name="catalog_enabled"
        {" checked" if s.get('catalog_enabled')=='1' else ""}><span class="track"></span>
        <span>کاتالوگ محصولات و خدمات فعال باشد</span></label>
      <label class="switch mb-md"><input type="checkbox" name="inquiry_enabled"
        {" checked" if s.get('inquiry_enabled')=='1' else ""}><span class="track"></span>
        <span>ارتباط با دکان‌دار (بدون شمارهٔ تلفن) فعال باشد</span></label>
      <label class="switch mb-md"><input type="checkbox" name="owner_login"
        {" checked" if s.get('owner_login')=='1' else ""}><span class="track"></span>
        <span>ورود صاحبان کسب‌وکار با پیامک فعال باشد</span></label>
      <label class="switch mb-md"><input type="checkbox" name="claims_enabled"
        {" checked" if s.get('claims_enabled')=='1' else ""}><span class="track"></span>
        <span>درخواست تصاحب کسب‌وکار فعال باشد</span></label>
      <hr class="divider">
      <label class="switch mb-lg"><input type="checkbox" name="maintenance"
        {" checked" if s.get('maintenance')=='1' else ""}><span class="track"></span>
        <span>حالت تعمیر و نگهداری (سایت برای بازدیدکنندگان بسته می‌شود)</span></label>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
    </div>
  </form>
</div>

<div class="tab-panel" id="p-x" role="tabpanel" aria-labelledby="t-x" hidden>
  <form method="post" action="/panel/settings">
        <div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-lg">{icon("message")} سرویس پیامک</h2>
      <div class="alert alert-info mb-lg">{icon("info")}
        <span>تا وقتی کلید وارد نشود، کد ورود روی صفحه نمایش داده می‌شود و
          سایت کاملاً بدون اینترنت کار می‌کند. با وارد کردن کلید، پیامک واقعی ارسال می‌شود.</span></div>
      <div class="field"><label class="field-label" for="x-key">کلید API (کاوه‌نگار)</label>
        <input class="input" id="x-key" name="sms_key" dir="ltr" autocomplete="off"
               value="" placeholder="{MASKED if (s.get('sms_key') or '').strip() else 'خالی = نمایش کد روی صفحه'}"></div>
      <div class="grid grid-2" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="x-send">شمارهٔ فرستنده</label>
          <input class="input" id="x-send" name="sms_sender" dir="ltr"
                 value="{esc(s.get('sms_sender'))}" placeholder="۱۰۰۰۴۳۴۶"></div>
        <div class="field"><label class="field-label" for="x-tpl">نام الگو (Lookup)</label>
          <input class="input" id="x-tpl" name="sms_template" dir="ltr"
                 value="{esc(s.get('sms_template'))}" placeholder="verify">
          <p class="field-hint">برای ارسال مطمئن‌تر کد تأیید.</p></div>
      </div>
      <div class="card glass card-pad mt-lg">
        <h3 class="card-title mb-md">{icon("send")} اعلان تلگرام (اختیاری و رایگان)</h3>
        <p class="text-sm text-muted mb-md">رویدادهای مهم (ثبت جدید، پیام مشتری، رزرو) به تلگرام شما هم
          ارسال می‌شود. با @BotFather ربات بسازید و توکن و شناسهٔ چت را اینجا بگذارید.</p>
        <div class="field"><label class="field-label" for="x-tg">توکن ربات</label>
          <input class="input" id="x-tg" name="tg_token" dir="ltr" autocomplete="off"
                 value="" placeholder="{MASKED if (s.get('tg_token') or '').strip() else '123456:ABC-...'}"></div>
        <div class="field"><label class="field-label" for="x-tgc">شناسهٔ چت (عددی)</label>
          <input class="input" id="x-tgc" name="tg_chat_id" dir="ltr"
                 value="{esc(s.get('tg_chat_id'))}" placeholder="123456789"></div>
      </div>
      <label class="switch mb-md"><input type="checkbox" name="clear_keys"><span class="track"></span>
        <span>حذف کلیدهای ذخیره‌شده (پیامک / تلگرام / نقشه)</span></label>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
    </div>
  </form>
</div>


<div class="tab-panel" id="p-e" role="tabpanel" aria-labelledby="t-e" hidden>
  <form method="post" action="/panel/settings">
        <div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-lg">📧 ورود با ایمیل — SMTP</h2>
      <div class="alert alert-info mb-lg"><span>برای ورود با ایمیل SMTP را تنظیم کنید. اگر خالی باشد، کد روی صفحه فقط در حالت توسعه (localhost) نمایش داده می‌شود — مثل پیامک. کد ۶ رقمی، ۵ دقیقه اعتبار.</span></div>
      <div class="grid grid-2" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="e-host">SMTP Host</label>
          <input class="input" id="e-host" name="smtp_host" dir="ltr" value="{esc(s.get('smtp_host'))}" placeholder="smtp.gmail.com"></div>
        <div class="field"><label class="field-label" for="e-port">SMTP Port</label>
          <input class="input nums" id="e-port" name="smtp_port" dir="ltr" value="{esc(s.get('smtp_port') or '587')}" placeholder="587"></div>
      </div>
      <div class="grid grid-2" style="gap:0 var(--space-md)">
        <div class="field"><label class="field-label" for="e-user">SMTP User (ایمیل)</label>
          <input class="input" id="e-user" name="smtp_user" dir="ltr" value="{esc(s.get('smtp_user'))}" placeholder="you@gmail.com"></div>
        <div class="field"><label class="field-label" for="e-pass">SMTP Password</label>
          <input class="input" id="e-pass" name="smtp_pass" type="password" dir="ltr" value="" placeholder="{MASKED if (s.get('smtp_pass') or '').strip() else 'رمز یا App Password'}"></div>
      </div>
      <div class="field"><label class="field-label" for="e-from">From Email</label>
        <input class="input" id="e-from" name="smtp_from" dir="ltr" value="{esc(s.get('smtp_from'))}" placeholder="noreply@dastgir.ir"></div>
      <label class="switch mb-md"><input type="checkbox" name="smtp_tls" value="1" {" checked" if (s.get('smtp_tls') or '1')=='1' else ""}><span class="track"></span><span>TLS فعال (پیش‌فرض روشن — پورت 587)</span></label>
      <button class="btn btn-primary" type="submit"><span>ذخیره تنظیمات ایمیل</span></button>
      <p class="field-hint mt-sm">نکته: برای Gmail از App Password استفاده کنید (نه رمز اصلی). راهنما: myaccount.google.com → Security → 2-Step → App passwords.</p>
    </div>
  </form>
</div>

<div class="tab-panel" id="p-p" role="tabpanel" aria-labelledby="t-p" hidden>
  <form method="post" action="/panel/settings">
    <div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-lg">{icon("bell")} اعلان روی گوشی (Web Push — کروم/اندروید)</h2>
      <div class="alert alert-info mb-lg">{icon("info")}
        <span>راه‌اندازی: (۱) در <b>console.firebase.google.com</b> یک پروژه بسازید یا بردارید؛
          (۲) از Project settings ← Service accounts یک کلید (JSON) بسازید؛
          (۳) در تب Cloud Messaging ← Web Push certificates، «Generate key pair» را بزنید و
          کلید عمومی را کپی کنید؛ (۴) هر دو را همین‌جا بچسبانید.
          این کار فقط برای اعلان روی نوار بالای گوشی است؛ بدون آن، اعلان داخل سایت بی‌نقص کار می‌کند.</span></div>
      <div class="field"><label class="field-label" for="p-json">فایل JSON حساب سرویس Firebase</label>
        <textarea class="textarea" id="p-json" name="fcm_service_json" dir="ltr"
          style="min-height:110px" autocomplete="off"
          placeholder="{MASKED if (s.get('fcm_service_json') or '').strip() else 'JSON فایل حساب سرویس — کامل بچسبانید'}"></textarea>
        <p class="field-hint">خالی بگذارید = مقدار ذخیره‌شده می‌ماند (مثل سایر کلیدها).</p></div>
      <div class="field"><label class="field-label" for="p-vap">کلید عمومی VAPID (Web Push certificates)</label>
        <input class="input" id="p-vap" name="fcm_vapid_pub" dir="ltr" autocomplete="off"
               value="" placeholder="{MASKED if (s.get('fcm_vapid_pub') or '').strip() else 'BEl...'}"></div>
      <label class="switch mb-md"><input type="checkbox" name="clear_fcm"><span class="track"></span>
        <span>حذف تنظیمات اعلان گوشی (پس از حذف، اعلان داخل سایت بی‌تغییر کار می‌کند)</span></label>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
    </div>
  </form>
</div>

<div class="tab-panel" id="p-s" role="tabpanel" aria-labelledby="t-s" hidden>
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("lock")} رمز عبور پنل</h2>
    <p class="text-sm text-muted mb-lg">علاوه بر کلید، برای ورود به پنل رمز عبور هم بخواهید.
      تا وقتی رمز تعیین نشده، پنل فقط با کلید باز می‌شود.</p>
    <form method="post" action="/panel/security" class="mb-md">
            <div class="field"><label class="field-label" for="op">رمز عبور جدید</label>
        <input class="input" id="op" type="password" name="owner_password"
               autocomplete="new-password" minlength="6" placeholder="دست‌کم ۶ نویسه" dir="ltr"></div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>تنظیم رمز عبور</span></button>
    </form>
    <form method="post" action="/panel/security" data-confirm="رمز عبور حذف شود؟">
            <input type="hidden" name="clear_password" value="1">
      <button class="btn btn-ghost" type="submit"{" disabled" if not s.get('owner_pass_hash') else ""}>
        {icon("x")}<span>حذف رمز عبور</span></button>
    </form>
  </div>
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("shield")} کلید دسترسی پنل</h2>
    <p class="text-sm text-muted mb-lg">این نشانی را نزد خود نگه دارید. هرکس آن را داشته باشد
      به پنل مدیریت دسترسی کامل دارد.</p>
    <div class="field"><label class="field-label" for="tok">نشانی ورود به پنل</label>
      <input class="input" id="tok" value="{esc(panel_prefix(s))}?key={esc(token)}" readonly dir="ltr"></div>
    <div class="cluster">
      <button class="btn btn-glass" type="button" data-copy="{esc(panel_prefix(s))}?key={esc(token)}">
        {icon("share")}<span>کپی نشانی</span></button>
      <form method="post" action="/panel/rotate-token" style="display:inline"
            data-confirm="کلید فعلی باطل می‌شود و باید نشانی جدید را یادداشت کنید. ادامه؟">
                <button class="btn btn-danger" type="submit">{icon("refresh")}<span>تولید کلید جدید</span></button>
      </form>
    </div>
    <div class="alert alert-warn mt-lg">{icon("alert")}
      <span>پیش از آپلود روی هاست حتماً کلید جدید بسازید تا کلید موجود در فایل زیپ باطل شود.</span></div>
  </div>
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("shield")} محدودیت آی‌پی پنل (اختیاری)</h2>
    <p class="text-sm text-muted mb-lg">اگر فقط از یک یا چند آی‌پی ثابت وارد
      پنل می‌شوید (مثلاً خانه یا محل کار)، آن‌ها را اینجا بنویسید — هر
      آی‌پی دیگری حتی با کلید درست هم ۴۰۳ می‌گیرد. خالی بگذارید = برای همه باز است.
      <strong>آی‌پی خودتان (همان سرور) همیشه مجاز است</strong> تا قفل نشوید.
      (پشت nginx، آی‌پی واقعی از X-Forwarded-For خوانده می‌شود.)</p>
    <form method="post" action="/panel/security" class="mb-md">
      <div class="field"><label class="field-label" for="pal">آی‌پی‌های مجاز (با ویرگول یا خط جدید جدا کنید)</label>
        <textarea class="input" id="pal" name="panel_allow_ips" dir="ltr" rows="3"
          placeholder="192.168.1.10&#10;91.98.0.0/16&#10;2001:db8::1">{esc(s.get('panel_allow_ips') or '')}</textarea></div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیرهٔ فهرست</span></button>
    </form>
  </div>
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("lock")} نشانی مخفی پنل (لایهٔ اول)</h2>
    <p class="text-sm text-muted mb-lg">وقتی نشانی مخفی فعال باشد، <code>/panel</code> برای
      غریبه‌ها ۴۰۴ می‌شود و کنسول فقط از همان نشانی تصادفی باز می‌شود.
      نشانی را همین‌جا می‌سازید و کپی می‌کنید؛ بدون آن هیچ‌کس حتی نمی‌فهمد پنلی وجود دارد.</p>
    {('<div class="alert alert-ok mb-md">' + icon('check') + '<span>نشانی مخفی فعال است: <code dir="ltr">/' + esc(s.get('panel_hidden_path')) + '</code></span></div>') if s.get('panel_hidden_path') else '<div class="alert alert-info mb-md">' + icon('info') + '<span>نشانی مخفی هنوز فعال نیست؛ پنل با <code dir="ltr">/panel</code> عادی باز می‌شود.</span></div>'}
    <div class="cluster">
      <form method="post" action="/panel/security" style="display:inline"
            data-confirm="یک نشانی تصادفی تازه ساخته می‌شود. آن را کپی و نزد خود نگه دارید. ادامه؟">
        <input type="hidden" name="hidden_mint" value="1">
        <button class="btn btn-primary" type="submit">{icon("refresh")}<span>{'ساخت نشانی تازه' if s.get('panel_hidden_path') else 'فعال‌سازی نشانی مخفی'}</span></button>
      </form>
      {('<form method="post" action="/panel/security" style="display:inline" data-confirm="نشانی مخفی حذف شود؟ پنل دوباره از /panel عادی باز می‌شود."><input type="hidden" name="hidden_clear" value="1"><button class="btn btn-ghost" type="submit">' + icon('x') + '<span>حذف نشانی مخفی</span></button></form>') if s.get('panel_hidden_path') else ''}
    </div>
  </div>
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("shield")} تأیید ورود با ربات بله (لایهٔ سوم)</h2>
    <p class="text-sm text-muted mb-lg">وقتی فعال باشد، بعد از کلید و رمز درست، یک درخواست
      تأیید یک‌بارمصرف به ربات بلهٔ مدیر فرستاده می‌شود و پنل فقط پس از «تأیید» در بله باز
      می‌شود. نیازمند فعال بودن ربات مدیر است؛ بدون ربات، این لایه خودکار خاموش می‌ماند تا قفل نشوید.</p>
    <form method="post" action="/panel/security">
      <input type="hidden" name="bale_confirm_tab" value="1">
      <label class="check"><input type="checkbox" name="panel_bale_confirm" value="1"
        {"checked" if s.get("panel_bale_confirm", "1") == "1" else ""}>
        <span>درخواست تأیید ورود به پنل از ربات بله</span></label>
      <button class="btn btn-primary mt-md" type="submit">{icon("check")}<span>ذخیره</span></button>
    </form>
  </div>
</div>'''
    return panel_page(s, "تنظیمات سایت",
                      "اطلاعات کلی، نقشه، امکانات و امنیت.", content, "/panel/settings", token)


# ------------------------------------------------------------------ backup
def backup_page(s, token, q=None):
    st = db.stats()
    content = f'''{_msg(q or {})}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("store", st['businesses'], "کسب‌وکار")}
  {stat_card("layers", st['categories'], "دسته", delay=60)}
  {stat_card("message", st['reviews'], "نظر", delay=120)}
  {stat_card("book", st['posts'], "مطلب", delay=180)}
</div>
<div class="grid grid-2" style="align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("download")} دریافت پشتیبان</h2>
    <p class="text-sm text-muted mb-lg">یک فایل JSON شامل همهٔ داده‌های سایت
      (کسب‌وکارها، دسته‌ها، نظرات، تنظیمات و رنگ‌ها) دانلود می‌شود.</p>
    <div class="cluster">
      <a class="btn btn-primary" href="/panel/backup/export">
        {icon("download")}<span>فایل JSON</span></a>
      <a class="btn btn-glass" href="/panel/backup/full">
        {icon("database")}<span>بکاپ کامل (JSON + تصاویر)</span></a>
      <a class="btn btn-glass" href="/panel/backup/db">
        {icon("database")}<span>دیتابیس (SQLite)</span></a>
    </div>
    <p class="text-xs text-muted mt-sm">{icon("info")}
      <span>«دیتابیس» یک اسنپ‌شات مستقیم و سالم از پایگاه داده است (با API
      امن پشتیبان‌گیری SQLite — بدون توقف سایت). برای بازیابی کافی است فایل
      را با نام <code>bazarche.db</code> داخل پوشهٔ <code>data</code> بگذارید.</span></p>
    <p class="text-sm text-muted mt-md">آخرین پشتیبان: <strong class="nums">
      {esc(s.get('last_backup_at') or 'هنوز نگرفته‌اید')}</strong></p>
  </div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("upload")} بازیابی از فایل</h2>
    <form method="post" action="/panel/backup/import" data-validate>
            <div class="field"><label class="field-label" for="bk-json">محتوای فایل پشتیبان</label>
        <textarea class="textarea" id="bk-json" name="payload" required dir="ltr"
          style="min-height:180px;font-family:ui-monospace,monospace;font-size:12px"
          placeholder='{{"settings": [...], "businesses": [...]}}'></textarea>
        <p class="field-hint">محتوای فایل JSON را اینجا بچسبانید.</p></div>
      <div class="alert alert-warn mb-lg">{icon("alert")}
        <span>بازیابی همهٔ داده‌های فعلی را جایگزین می‌کند.</span></div>
      <button class="btn btn-danger btn-block" type="submit">
        {icon("upload")}<span>بازیابی داده‌ها</span></button>
    </form>
  </div>
</div>'''
    return panel_page(s, "پشتیبان‌گیری و بازیابی",
                      "از داده‌های سایت نسخهٔ پشتیبان بگیرید یا بازیابی کنید.",
                      content, "/panel/backup", token)


def approve_wait(s, state="pending"):
    """v293 لایهٔ سوم: پس از رمز درست، ورود به پنل یک تأیید یک‌بارمصرف از
    ربات بله مدیر می‌خواهد. این صفحه همان لحظه نمایش داده می‌شود و نتیجه را
    هر ۲ ثانیه از سرور می‌پرسد."""
    from ui import page
    if state == "rejected":
        return page(s, "ورود رد شد", f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass" style="text-align:center">
    <div class="auth-head"><span class="mark">{icon("shield")}</span>
      <h1>درخواست ورود رد شد</h1>
      <p>تأیید از ربات بله نرسید یا رد شد. اگر کار شما نبود، رمز پنل را فوراً عوض کنید.</p></div>
    <a class="btn btn-primary btn-block mt-lg" href="/">{icon("store")}<span>بازگشت به سایت</span></a>
  </div></div></div>''', "", cats=[], show_chrome=False)
    if state == "expired":
        return page(s, "مهلت تمام شد", f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass" style="text-align:center">
    <div class="auth-head"><span class="mark">{icon("clock")}</span>
      <h1>مهلت تأیید تمام شد</h1>
      <p>چالِنج تأیید منقضی شد. از نو وارد شوید و در ربات بله تأیید کنید.</p></div>
    <a class="btn btn-primary btn-block mt-lg" href="/">{icon("store")}<span>بازگشت به سایت</span></a>
  </div></div></div>''', "", cats=[], show_chrome=False)
    poll_js = (
        '<script>(function(){var n=0;function t(){fetch("/api/panel/approve-status",'
        '{credentials:"same-origin"}).then(function(r){return r.json()}).then(function(j){'
        'if(j.status==="approved"){location.href=j.redirect||"/panel";return}'
        'if(j.status==="rejected"||j.status==="expired"){location.reload();return}'
        'if(++n<150){setTimeout(t,2000)}}).catch(function(){if(++n<150){setTimeout(t,3000)}})}'
        'setTimeout(t,1500)})();</script>')
    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass" style="text-align:center">
    <div class="auth-head"><span class="mark">{icon("shield")}</span>
      <h1>در انتظار تأیید ربات بله</h1>
      <p>رمز درست است؛ برای باز شدن پنل، یک تأیید یک‌بارمصرف به ربات بلهٔ شما
      ارسال شد. در بله پیام «تأیید …» را ببینید و کد را تأیید کنید.</p></div>
    <div class="alert alert-info" style="text-align:start">{icon("info")}
      <span>این درخواست ۵ دقیقه اعتبار دارد. اگر شما نبودید، پیام را «رد» کنید و رمز پنل را عوض کنید.</span></div>
    <p class="field-hint nums">بررسی خودکار وضعیت…</p>
  </div></div></div>{poll_js}'''
    return page(s, "در انتظار تأیید", body, "", cats=[], show_chrome=False)


def password_gate(s, err=""):
    from ui import page
    err_html = flash("err", err) if err else ""
    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass" style="text-align:center">
    <div class="auth-head"><span class="mark">{icon("lock")}</span>
      <h1>رمز عبور پنل</h1>
      <p>پنل مدیریت با رمز عبور محافظت می‌شود. آن را وارد کنید.</p></div>
    {err_html}
    <form method="post" action="/panel/login">
            <div class="field"><label class="field-label" for="pw">رمز عبور</label>
        <input class="input" id="pw" type="password" name="password"
               autocomplete="current-password" required autofocus
               placeholder="••••••••"></div>
      <button class="btn btn-primary btn-block mt-lg" type="submit">
        {icon("shield")}<span>ورود به پنل</span></button>
    </form>
  </div></div></div>'''
    return page(s, "رمز عبور پنل", body, "", cats=[], show_chrome=False)


def login_gate(s):
    from ui import page
    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass" style="text-align:center">
    <div class="auth-head"><span class="mark">{icon("lock")}</span>
      <h1>دسترسی محدود</h1>
      <p>برای ورود به پنل مدیریت، نشانی همراه با کلید دسترسی لازم است.</p></div>
    <div class="alert alert-info" style="text-align:start">{icon("info")}
      <span>نشانی صحیح پنل هنگام اجرای <code>run.py</code> در Pydroid چاپ می‌شود.</span></div>
    <a class="btn btn-primary btn-block mt-lg" href="/">{icon("store")}<span>بازگشت به سایت</span></a>
  </div></div></div>'''
    return page(s, "دسترسی محدود", body, "", cats=[], show_chrome=False)


# ==========================================================================
#  OWNERS  &  CLAIMS  (admin)
# ==========================================================================
def owner_list(s, token, q=None):
    rows = db.owners()
    trs = "".join(f'''<tr>
      <td><div style="display:flex;align-items:center;gap:10px">
        <span class="avatar" style="width:36px;height:36px;font-size:14px" aria-hidden="true">
          {esc((o["name"] or o["phone"])[:1])}</span>
        <div><strong>{esc(o["name"] or "بدون نام")}</strong><br>
          <small class="text-muted nums">{esc(o["phone"])}</small></div></div></td>
      <td class="num">{fa(o["n_biz"])}</td>
      <td class="num nums">{fa(jdate(o["created"]))}</td>
      <td class="num nums">{jdatetime(o["last_login"] or "—")}</td>
      <td><span class="badge {"badge-open" if o["status"]=="active" else "badge-closed"}">
        {"فعال" if o["status"]=="active" else "مسدود"}</span></td>
      <td class="actions">
        <form method="post" action="/panel/owner/{o["id"]}" style="display:inline">
                    <input type="hidden" name="status" value="{"blocked" if o["status"]=="active" else "active"}">
          <button class="btn-icon" type="submit"
            aria-label="{"مسدودسازی" if o["status"]=="active" else "فعال‌سازی"} {esc(o["phone"])}"
            title="{"مسدود کن" if o["status"]=="active" else "فعال کن"}">
            {icon("lock" if o["status"]=="active" else "check")}</button></form>
        <form method="post" action="/panel/owner/{o["id"]}" style="display:inline"
              data-confirm="حساب {esc(o["phone"])} حذف شود؟ کسب‌وکارهایش حذف نمی‌شوند و بدون مالک می‌مانند.">
                    <input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف حساب"
            aria-label="حذف حساب {esc(o["phone"])}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for o in rows)
    if not trs:
        trs = '<tr><td colspan="6" class="text-center text-muted" style="padding:var(--space-xl)">هنوز کسی ثبت‌نام نکرده</td></tr>'
    content = f'''{_msg(q or {})}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("users", len(rows), "کل صاحبان")}
  {stat_card("check-circle", sum(1 for o in rows if o["status"]=="active"), "فعال", delay=60)}
  {stat_card("store", sum(o["n_biz"] for o in rows), "کسب‌وکار واگذارشده", delay=120)}
  {stat_card("lock", sum(1 for o in rows if o["status"]!="active"), "مسدود", delay=180)}
</div>
<div class="card glass card-pad">
  <div class="table-wrap"><table class="table">
    <thead><tr><th>کاربر</th><th>کسب‌وکار</th><th>عضویت</th><th>آخرین ورود</th><th>وضعیت</th><th></th></tr></thead>
    <tbody>{trs}</tbody></table></div></div>'''
    return panel_page(s, "صاحبان کسب‌وکار",
                      "کسانی که با شمارهٔ موبایل وارد می‌شوند و کسب‌وکار خود را مدیریت می‌کنند.",
                      content, "/panel/owners", token)


def claim_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or [""])[0]
    page = _pg(q)
    res = db.claims(status or None, page=page)
    rows, pages = res["rows"], res["pages"]
    items = "".join(f'''<article class="review">
      <div class="review-head">
        <span class="avatar" aria-hidden="true">{esc((c["ownername"] or c["phone"])[:1])}</span>
        <div style="flex:1"><strong>{esc(c["ownername"] or "بدون نام")}</strong>
          <div class="card-meta" style="margin-top:3px">
            <span class="nums">{esc(c["phone"])}</span><span aria-hidden="true">·</span>
            <span>می‌خواهد <a href="/b/{esc(c["bizslug"])}">{esc(c["bizname"])}</a> را تصاحب کند</span>
            <span aria-hidden="true">·</span><span>{esc(jdatetime(c["created"]))}</span></div></div>
        <span class="badge {"badge-open" if c["status"]=="approved" else ("badge-warn" if c["status"]=="pending" else "badge-closed")}">
          {esc({"approved":"تأییدشده","pending":"در انتظار","rejected":"رد شده"}.get(c["status"]))}</span>
      </div>
      {f'<p class="review-body">{esc(c["note"])}</p>' if c.get("note") else ""}
      {"" if c["status"] != "pending" else f"""<form method="post" action="/panel/claim/{c["id"]}" class="mt-md">
                <div class="cluster">
          <button class="btn btn-primary btn-sm" type="submit" name="action" value="approve">
            {icon("check")}<span>تأیید و واگذاری</span></button>
          <a class="btn btn-glass btn-sm" href="tel:{esc(c["phone"])}">{icon("phone")}<span>تماس برای احراز</span></a>
          <button class="btn btn-ghost btn-sm" type="submit" name="action" value="reject"
            style="color:var(--color-destructive)">{icon("x")}<span>رد</span></button>
        </div></form>"""}
    </article>''' for c in rows)
    if not items:
        items = f'''<div class="empty-state"><span class="icon-wrap">{icon("shield")}</span>
          <h3>درخواستی نیست</h3>
          <p>وقتی صاحب کسب‌وکاری بگوید «این مال من است»، اینجا برای تأیید می‌بینید.</p></div>'''
    filt = "".join(f'<a class="chip{" is-active" if status==v else ""}" '
                   f'href="/panel/claims?status={v}">{t}</a>'
                   for v, t in [("","همه"),("pending","در انتظار"),
                                ("approved","تأییدشده"),("rejected","رد شده")])
    content = (f'{_msg(q)}<div class="cluster mb-lg">{filt}</div>'
               f'{panel_pager("/panel/claims", page, pages)}'
               f'<div class="card glass card-pad">{items}</div>')
    return panel_page(s, "درخواست‌های تصاحب",
                      "پیش از تأیید، با شمارهٔ اعلامی تماس بگیرید و مالکیت را احراز کنید.",
                      content, "/panel/claims", token)


# ==========================================================================
#  CSV IMPORT PAGE
# ==========================================================================
def csv_import(s, token, q=None, result=None):
    cats = db.categories(only_active=False)
    sample = "name,cat_slug,descr,phone,address,tags,status\n" \
             "کبابی نمونه,restaurant,کباب سنتی,03142600000,خیابان امام,کباب,published"

    res_html = ""
    if result:
        added, updated, errors = result
        rows = "".join(f'<li>{icon("alert")}<span>{esc(e)}</span></li>' for e in errors[:20])
        res_html = f'''<div class="card glass card-pad mb-lg">
          <h2 class="card-title mb-lg">{icon("check-circle")} نتیجهٔ ورود</h2>
          <div class="grid grid-3" data-stagger>
            {stat_card("plus", added, "افزوده‌شده")}
            {stat_card("refresh", updated, "به‌روزشده", delay=60)}
            {stat_card("alert", len(errors), "خطا", delay=120)}
          </div>
          {f'<div class="prose mt-lg"><ul>{rows}</ul></div>' if errors else ""}
          {f'<p class="text-xs text-muted mt-md">{fa(len(errors)-20)} خطای دیگر نمایش داده نشد.</p>' if len(errors) > 20 else ""}
        </div>'''

    cat_rows = "، ".join(f"<code>{esc(c['slug'])}</code>" for c in cats[:20])

    content = f'''{_msg(q or {})}
{res_html}
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-lg">{icon("upload")} ورود کسب‌وکارها از فایل CSV</h2>
  <p class="text-sm text-muted mb-lg">محتوای فایل CSV را اینجا بچسبانید. اگر نام یا
    شمارهٔ تماس با کسب‌وکار موجودی یکسان باشد، به‌جای ایجاد تکراری
    <strong>به‌روزرسانی</strong> می‌شود.</p>
  <form method="post" action="/panel/businesses/import" data-validate>
        <div class="field">
      <label class="field-label" for="csv">محتوای CSV<span class="req">*</span></label>
      <textarea class="textarea" id="csv" name="csv" required dir="ltr"
        style="min-height:220px;font-family:ui-monospace,monospace;font-size:12px"
        placeholder="{esc(sample)}"></textarea>
    </div>
    <button class="btn btn-primary btn-lg" type="submit">
      {icon("upload")}<span>شروع ورود</span></button>
    <a class="btn btn-ghost btn-lg" href="/panel/businesses">
      {icon("x")}<span>انصراف</span></a>
  </form>
</div>

<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("info")} راهنمای ستون‌ها</h2>
  <div class="prose" style="max-width:none">
    <p>سطر اول باید نام ستون‌ها باشد. ستون‌های پشتیبانی‌شده:</p>
    <p><code>{"</code>، <code>".join(db.CSV_COLUMNS)}</code></p>
    <p><strong>الزامی:</strong> <code>name</code> و <code>cat_slug</code></p>
    <p><strong>شناسهٔ دسته‌های موجود:</strong> {cat_rows}</p>
    <p><code>status</code> یکی از: <code>published</code>، <code>pending</code>،
       <code>hidden</code>. <code>featured</code> و <code>verified</code> با
       <code>1</code> یا خالی.</p>
  </div>
  <hr class="divider">
  <p class="text-sm text-muted mb-md">نمونه:</p>
  <pre style="background:var(--color-muted);padding:14px;border-radius:var(--radius-md);
    overflow-x:auto;font-size:12px;direction:ltr;text-align:left">{esc(sample)}</pre>
  <a class="btn btn-glass mt-lg" href="/panel/businesses/export">
    {icon("download")}<span>دانلود نمونه از داده‌های فعلی</span></a>
</div>'''
    return panel_page(s, "ورود از CSV",
                      "افزودن یا به‌روزرسانی گروهی کسب‌وکارها.",
                      content, "/panel/businesses", token)
