# -*- coding: utf-8 -*-
"""
Public pages for the v3 features:
compare, nearby (radius search), city events, report form,
plus the reusable Q&A / criteria / badge / ad blocks used by
the business detail page.
"""

import json
import urllib.parse
import db
from ui import (av,icon, stars, fa, fa_group, esc, page, biz_card, stat_card, cat_icon, ctx_customer,
                section_head, breadcrumb, empty_state, flash, json_embed, cat_options)
from ui import jdate, jdatetime, jdatetime_ts, media_embed

def urlq(v):
    """Percent-encode a value for a query string. Comparison keys are Persian
    words joined by spaces, so they must be encoded or the link breaks."""
    return urllib.parse.quote(str(v), safe="")


MAP_JS = '<script type="module" src="' + av('/assets/js/mappage.js') + '"></script>'
NEAR_JS = ('<script type="module" src="' + av('/assets/js/catpicker.js') + '"></script>'
           '<script type="module" src="' + av('/assets/js/nearby.js') + '"></script>')
QA_JS = '<script type="module" src="' + av('/assets/js/qa.js') + '"></script>'


def _cat_icons():
    return {c["slug"]: c["icon"] for c in db.categories(only_active=False)}


def jsonld(*objs):
    out = ""
    for o in objs:
        if o:
            out += ('<script type="application/ld+json">'
                    + json_embed(o) + '</script>')
    return out


# ==========================================================================
#  REUSABLE BLOCKS (used inside the business detail page)
# ==========================================================================
def badge_strip(biz_id, badges=None):
    rows = badges if badges is not None else db.biz_badges(biz_id)
    if not rows:
        return ""
    out = ""
    for b in rows:
        try:
            ic = icon(b["icon"])
        except KeyError:
            ic = icon("award")
        # v117/فاز۷: رنگ خام نشان (مثل #059669) روی نوار روشن فقط ۳٫۴ بود —
        # رنگ متن حالا توکن تم است؛ هویت رنگ با حاشیه/پس‌زمینهٔ رنگ‌میکس می‌ماند.
        out += (f'<span class="badge badge-custom" title="{esc(b["descr"])}" '
                f'style="background:{esc(b["color"])}1F;color:var(--color-foreground);'
                f'border-color:{esc(b["color"])}66">{ic}<span>{esc(b["name"])}</span></span>')
    return f'<div class="badge-strip">{out}</div>'


def criteria_block(biz_id):
    rows = db.criteria_averages(biz_id)
    if not rows:
        return ""
    bars = "".join(f'''<div class="crit-row">
      <span>{esc(r['label'])}<small class="crit-n">از {fa(r['n'])} امتیاز</small></span>
      <span class="crit-track"><span class="crit-fill" style="width:{round(r['avg']*20)}%"></span></span>
      <strong class="nums">{fa(r['avg'])}</strong></div>''' for r in rows)
    return f'''<div class="crit-grid" role="group" aria-label="امتیاز تفکیکی">
      {bars}</div>'''


def criteria_inputs(biz_id):
    """The star pickers on the review form — real inputs, posted with the form.
    v151: only the criteria this business's facilities allow (biz_criteria);
    no silent default — every criterion starts unset (0)."""
    crits = db.biz_criteria(biz_id)
    rows = ""
    for code, label in crits:
        btns = "".join(
            f'<button type="button" data-v="{i}" aria-pressed="false" '
            f'aria-label="{esc(label)}: {fa(i)} از ۶">{icon("star")}</button>'
            for i in range(1, 7))
        rows += f'''<div class="row" data-crit="{code}">
          <span>{esc(label)}<b class="crit-lvl" data-crit-lvl aria-live="polite"></b></span>
          <span class="crit-stars">{btns}
            <input type="hidden" name="crit_{code}" value=""></span></div>'''
    if not crits:
        return ""
    return f'''<div class="field"><span class="field-label">امتیاز شما<span class="req">*</span></span>
      <div class="crit-input rating-box rating-box-wide" data-crit-input>{rows}</div>
      <p class="field-hint">امتیاز از میانگین معیارهایی که ستاره می‌دهید حساب می‌شود؛ بدون ستاره هم می‌توانید نظر بنویسید.</p></div>'''
def qa_block(s, b, token="", cust=None, can_owner=False):
    """v285: هر طرف فقط پیام خودش را ویرایش/حذف می‌کند؛ ویرایش با پنجرهٔ
    ۱۵ دقیقه و برچسب ریز «ویرایش شده»."""
    if s.get("qa_enabled") != "1":
        return ""
    import time as _time
    now = _time.time()
    rows = db.questions(biz_id=b["id"], status="published")

    def _ctrl_q(q):
        if not (cust and q.get("customer_id")
                and int(q["customer_id"]) == int(cust["id"])):
            return ""
        btns = []
        if now - (db._qa_ts(q["created"], utc=True) or 0) <= db.QA_EDIT_WINDOW:
            btns.append(f"""<details class="qa-edit"><summary>ویرایش</summary>
              <form method="post" action="/qa/{q['id']}/edit">
                <textarea class="textarea" name="body" required minlength="8"
                  maxlength="2000">{esc(q['body'])}</textarea>
                <button class="btn btn-glass btn-sm mt-sm" type="submit">
                  {icon('check')}<span>ذخیره</span></button></form></details>""")
        btns.append(f"""<form method="post" action="/qa/{q['id']}/delete"
            data-confirm="پرسش شما برای همیشه حذف شود؟">
            <button class="btn btn-glass btn-sm" type="submit">
              {icon('trash')}<span>حذف</span></button></form>""")
        return f'<span class="qa-ctrl">{"".join(btns)}</span>'

    def _ctrl_a(q):
        if not (can_owner and q["answer"]):
            return ""
        btns = []
        if now - (db._qa_ts(q["answered"]) or 0) <= db.QA_EDIT_WINDOW:
            btns.append(f"""<details class="qa-edit"><summary>ویرایش پاسخ</summary>
              <form method="post" action="/qa/{q['id']}/answer-edit">
                <textarea class="textarea" name="answer" required minlength="2"
                  maxlength="4000">{esc(q['answer'])}</textarea>
                <button class="btn btn-glass btn-sm mt-sm" type="submit">
                  {icon('check')}<span>ذخیره</span></button></form></details>""")
        btns.append(f"""<form method="post" action="/qa/{q['id']}/answer-delete"
            data-confirm="پاسخ شما حذف شود؟">
            <button class="btn btn-glass btn-sm" type="submit">
              {icon('trash')}<span>حذف پاسخ</span></button></form>""")
        return f'<span class="qa-ctrl">{"".join(btns)}</span>'

    items = ""
    for q in rows:
        ed_q = (' <span class="qa-edited">ویرایش شده</span>'
                if q.get("edited") else "")
        ed_a = (' <span class="qa-edited">ویرایش شده</span>'
                if q.get("answer_edited") else "")
        ans = (f'<div class="qa-a"><span class="amark">✓</span>'
               f'<span>{esc(q["answer"])}{ed_a}</span></div>'
               if q["answer"] else
               '<p class="text-xs text-muted mt-sm">هنوز پاسخی داده نشده.</p>')
        items += f"""<div class="qa-item">
      <div class="qa-q"><span class="qmark">؟</span><span>{esc(q['body'])}{ed_q}</span></div>
      {ans}
      <div class="qa-meta">
        <span>{esc(q['asker'])}</span><span aria-hidden="true">·</span>
        <span class="nums">{esc(jdate(q['created']))}</span>
        <button class="qa-helpful" type="button" data-helpful="{q['id']}"
          aria-pressed="false" aria-label="این پرسش مفید بود">
          {icon("check")}<span>مفید بود (<span class="nums" data-helpful-n>{fa(q['helpful'])}</span>)</span></button>
        {_ctrl_q(q)}{_ctrl_a(q)}
      </div></div>"""
    if not items:
        items = ('<p class="text-sm text-muted">هنوز پرسشی ثبت نشده. '
                 'اولین سؤال را شما بپرسید.</p>')
    note = ("پرسش شما پس از بررسی و پاسخ صاحب کسب‌وکار منتشر می‌شود."
            if s.get("qa_moderated") == "1" else "پرسش شما بلافاصله منتشر می‌شود.")
    return f"""<section class="card glass card-pad mt-lg reveal" id="qa">
  <h2 class="card-title mb-lg">{icon("help")} پرسش و پاسخ</h2>
  {items}
  <hr class="divider">
  <h3 class="card-title mb-md">{icon("edit")} سؤال خود را بپرسید</h3>
  <form method="post" action="/b/{esc(b['slug'])}/ask-question" data-validate>
  <span style="position:absolute;left:-9999px;top:-9999px;height:0;overflow:hidden" aria-hidden="true"><label for="hpq">وب‌سایت</label><input id="hpq" type="text" name="website_hp" tabindex="-1" autocomplete="off"></span>

    <div class="field"><label class="field-label" for="qa-name">نام شما<span class="req">*</span></label>
      <input class="input" id="qa-name" name="asker" required minlength="2"></div>
    <div class="field"><label class="field-label" for="qa-body">پرسش<span class="req">*</span></label>
      <textarea class="textarea" id="qa-body" name="body" required minlength="8"
        placeholder="مثلاً: پارکینگ دارید؟ ارسال به شهرک دارید؟"></textarea>
      <p class="field-hint">{esc(note)}</p></div>
    <button class="btn btn-primary" type="submit">{icon("send")}<span>ارسال پرسش</span></button>
  </form>
</section>"""


def report_block(s, b):
    if s.get("reports_enabled") != "1":
        return ""
    opts = "".join(f'<option value="{esc(c)}">{esc(t)}</option>'
                   for c, t in db.REPORT_REASONS)
    return f'''<details class="card glass card-pad mt-lg reveal">
  <summary style="cursor:pointer;font-weight:700;display:flex;align-items:center;gap:8px;min-height:44px;padding:8px 4px">
    {icon("alert")}<span>گزارش مشکل در این صفحه</span></summary>
  <p class="text-sm text-muted mt-md">اطلاعات اشتباه است؟ دکان تعطیل شده؟ به ما بگویید تا اصلاح کنیم.</p>
  <form method="post" action="/b/{esc(b['slug'])}/report" class="mt-md" data-validate>
    <div class="field"><label class="field-label" for="rp-reason">دلیل<span class="req">*</span></label>
      <select class="select" id="rp-reason" name="reason" required>{opts}</select></div>
    <div class="field"><label class="field-label" for="rp-body">توضیح</label>
      <textarea class="textarea" id="rp-body" name="body" style="min-height:70px"
        placeholder="هرچه بیشتر توضیح دهید، سریع‌تر رسیدگی می‌کنیم."></textarea></div>
    <div class="field"><label class="field-label" for="rp-who">شمارهٔ تماس شما</label>
      <input class="input nums" id="rp-who" name="reporter" dir="ltr" inputmode="numeric"
             placeholder="اختیاری — برای پیگیری"></div>
    <button class="btn btn-glass" type="submit" aria-label="ارسال گزارش مشکل">{icon("send")}<span>ارسال گزارش</span></button>
  </form>
</details>'''


def ad_block(slot, s):
    """Renders one ad and counts the impression. Click goes through /ad/<id>
    so the click counter is real, not a guess."""
    if s.get("ads_enabled") != "1":
        return ""
    a = db.pick_ad(slot)
    if not a:
        return ""
    img = (f'<div class="ad-media"><img src="{esc(a["image"])}" alt="{esc(a["title"])}" loading="lazy" decoding="async"></div>'
           if a.get("image") else f'<div class="ad-media ad-media-icon">{icon("zap")}</div>')

    body_txt = f'<p class="ad-desc">{esc(a["body"])}</p>' if a.get("body") else ''
    biz_tag = f'<span class="ad-biz-tag">{icon("store")}<span>{esc(a["bizname"])}</span></span>' if a.get("bizname") else ''

    return f'''<aside class="ad-slot card glass reveal" aria-label="تبلیغات">
  <a class="ad-link" href="/ad/{a['id']}" rel="nofollow sponsored noopener">
    <div class="ad-flag-wrap">
      <span class="badge badge-accent badge-sm">{icon("sparkles")}<span>آگهی ویژه</span></span>
      {biz_tag}
    </div>
    <div class="ad-inner">
      {img}
      <div class="ad-content">
        <h3 class="ad-title">{esc(a['title'])}</h3>
        {body_txt}
        <div class="ad-action-row">
          <span class="btn btn-primary btn-sm">{icon("arrow-left")}<span>مشاهده و اطلاعات بیشتر</span></span>
        </div>
      </div>
    </div>
  </a>
</aside>'''


def nearby_page(s, token=""):
    cats = db.category_tree()
    copts = cat_options(cats, blank="همهٔ دسته‌ها", group_selectable=False)
    withgeo = len([b for b in db.businesses() if b["lat"] and b["lng"]])

    # Quick category chips for popular categories
    pop_cats = [{"slug": "", "name": "همهٔ اصناف", "icon": "layers"}]
    for c in cats[:10]:
        pop_cats.append({"slug": c["slug"], "name": c["name"], "icon": c.get("icon", "store")})

    quick_chips = "".join(
        f'<button type="button" class="chip{" is-active" if not c["slug"] else ""}" data-near-chip="{esc(c["slug"])}">'
        f'{cat_icon(c.get("icon", "store"), 16)}<span>{esc(c["name"])}</span></button>'
        for c in pop_cats
    )

    ad_nearby = ad_block("nearby", s) or ad_block("directory", s)

    body = f'''<div class="container-wide">
  {breadcrumb(("نزدیک من", None))}
  <header class="page-hero"><span class="eyebrow">{icon("compass")}<span>جست‌وجوی شعاعی</span></span>
    <h1>کسب‌وکارهای نزدیک من</h1>
    <p>موقعیت خود را بدهید تا نزدیک‌ترین کسب‌وکارها را با فاصلهٔ دقیق ببینید.
      موقعیت شما فقط در مرورگر شما می‌ماند و ذخیره نمی‌شود.</p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div class="near-bar card glass card-pad mb-lg">
    <div class="near-main-row">
      <button class="btn btn-primary" type="button" data-geo>
        {icon("target")}<span>پیدا کردن موقعیت من</span></button>
      <label class="range near-range-wrap">
        <span class="text-xs text-muted">شعاع: <strong class="nums" data-near-r>۳</strong> کیلومتر</span>
        <input type="range" min="1" max="15" value="3" step="1" data-near-range
               aria-label="شعاع جست‌وجو به کیلومتر" style="width:100%">
      </label>
      <span class="text-xs text-muted" data-near-status>در انتظار اجازهٔ دسترسی به موقعیت…</span>
    </div>
    <div class="near-cat-box mt-md">
      <div class="near-cat-head mb-xs">
        <span class="text-xs font-bold" style="color:var(--color-primary-text)">{icon("search")} جست‌وجو و انتخاب سریع دسته:</span>
      </div>
      <div class="near-cat-controls">
        <div class="search-wrap near-cat-search">
          {icon("search", cls="search-icon")}
          <input class="input" type="search" placeholder="جست‌وجوی سریع نام صنف (نانوایی، رستوران، آرایشگاه…)"
                 data-near-cat-search autocomplete="off" aria-label="جست‌وجوی دسته در اطراف">
        </div>
        <div class="near-select-wrap">
          <label class="sr-only" for="near-cat">دسته</label>
          <select class="select" id="near-cat" data-near-cat data-catpick>{copts}</select>
        </div>
      </div>
      <div class="near-chips-bar mt-sm" data-near-chips>{quick_chips}</div>
    </div>
  </div>
  {f'<div class="mb-lg">{ad_nearby}</div>' if ad_nearby else ''}
  <div class="grid grid-3" data-near-grid></div>
  <div data-near-empty>{empty_state("compass", "هنوز موقعیتی مشخص نشده",
    f"روی «پیدا کردن موقعیت من» بزنید. در حال حاضر {withgeo} کسب‌وکار روی نقشه ثبت شده‌اند.")}</div>
</div></section>'''
    return page(s, "نزدیک من", body, "/map", token=token, cats=cats, extra_js=NEAR_JS)


# ==========================================================================
#  CITY EVENTS
# ==========================================================================
# v145: event date boxes are now Jalali (solar Hijri) — day + Persian month.
_JD_MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
              "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]
_JD_FA2EN = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")


def _date_box(d, past=False):
    if not d:
        return f'<span class="event-date{" is-past" if past else ""}"><span class="d">—</span></span>'
    try:
        j = jdate(d[:10])                    # '۱۴۰۵/۰۶/۲۲'
        if "/" in j:
            _, mm, dd = j.split("/")
            m_int = int(mm.translate(_JD_FA2EN))
            if 1 <= m_int <= 12:
                return (f'<span class="event-date"><span class="d nums">{dd}</span>'
                        f'<span class="m">{_JD_MONTHS[m_int - 1]}</span></span>')
    except Exception:
        pass
    # unrecognised input: never invent a month — show a placeholder
    return f'<span class="event-date"><span class="d">—</span></span>'


def events(s, token=""):
    cats = db.category_tree()
    rows = db.cityevents(status="published")
    upcoming = [e for e in rows if not e["past"]]
    past = [e for e in rows if e["past"]]

    def card(e):
        return f'''<article class="card card-hover glass card-pad reveal event-card{" is-past" if e['past'] else ""}">
      {_date_box(e['date'], e['past'])}
      <div style="flex:1;min-width:0">
        <h3 class="card-title"><a href="/events/{esc(e['slug'])}">{esc(e['title'])}</a></h3>
        <div class="card-meta">
          {f'{icon("clock")}<span class="nums">{fa(e["time"])}</span>' if e.get('time') else ''}
          {f'{icon("pin")}<span>{esc(e["place"])}</span>' if e.get('place') else ''}</div>
        <p class="card-desc">{esc(e['descr'])[:140]}</p>
        {f'<a class="btn btn-ghost btn-sm mt-sm" href="/b/{esc(e["bizslug"])}">{icon("store")}<span>{esc(e["bizname"])}</span></a>' if e.get('bizslug') else ''}
      </div></article>'''

    up_html = (f'<div class="grid grid-2">{"".join(card(e) for e in upcoming)}</div>'
               if upcoming else empty_state("calendar", "رویداد پیش‌رویی ثبت نشده",
                   "جشنواره‌ها و مناسبت‌های شهر به‌محض اعلام اینجا منتشر می‌شود."))
    past_html = ""
    if past:
        past_html = f'''<section class="section-sm"><div class="container-wide">
      {section_head("بایگانی", "رویدادهای گذشته", eyebrow_icon="clock")}
      <div class="grid grid-2">{"".join(card(e) for e in past[:8])}</div></div></section>'''

    body = f'''<div class="container-wide">
  {breadcrumb(("رویدادهای شهر", None))}
  <header class="page-hero"><span class="eyebrow">{icon("calendar")}<span>تقویم دست گیر</span></span>
    <h1>رویدادهای شهر</h1>
    <p>جشنواره‌ها، افتتاحیه‌ها، حراج‌های فصلی و مناسبت‌های دست گیر.</p></header>
</div>
<section class="section-sm"><div class="container-wide">{up_html}</div></section>
{past_html}
{jsonld(*[db.jsonld_event(e) for e in upcoming[:10]])}'''
    return page(s, "رویدادهای شهر", body, "/events", token=token, cats=cats)


def event_detail(s, slug, token=""):
    e = db.cityevent(slug=slug)
    if not e or e["status"] != "published":
        return None
    cats = db.category_tree()
    paras = "".join(f"<p>{esc(x)}</p>" for x in (e["descr"] or "").split("\n") if x.strip())
    body = f'''<div class="container-wide">
  {breadcrumb(("رویدادهای شهر", "/events"), (e["title"], None))}
  <header class="page-hero"><h1>{esc(e['title'])}</h1>
    <div class="cluster mt-md">
      {f'<span class="badge badge-info">{icon("calendar")}<span class="nums">{fa(e["date"])}</span></span>' if e.get('date') else ''}
      {f'<span class="badge badge-neutral">{icon("clock")}<span class="nums">{fa(e["time"])}</span></span>' if e.get('time') else ''}
      {f'<span class="badge badge-neutral">{icon("pin")}<span>{esc(e["place"])}</span></span>' if e.get('place') else ''}
    </div></header>
</div>
<section class="section-sm"><div class="container-wide">
  {f'<img class="news-hero-img reveal" src="{esc(e["image"])}" alt="{esc(e["title"])}" loading="eager">' if e.get('image') else ''}
  {media_embed(e.get('video'), e['title'])}
  <div class="card glass card-pad prose reveal" style="max-width:none">
    {paras or '<p class="text-muted">توضیحی ثبت نشده.</p>'}
    {f'<hr class="divider"><a class="btn btn-primary" href="/b/{esc(e["bizslug"])}">{icon("store")}<span>صفحهٔ {esc(e["bizname"])}</span></a>' if e.get('bizslug') else ''}
  </div>
  <div class="text-center mt-xl"><a class="btn btn-glass" href="/events">
    {icon("arrow-left")}<span>همهٔ رویدادها</span></a></div>
</div></section>
{jsonld(db.jsonld_event(e))}'''
    return page(s, e["title"], body, "/events", desc=e["descr"][:150],
                token=token, cats=cats)


# ==========================================================================
#  LOCAL PRICE COMPARISON  ("چند فروشی؟")
#
#  Torob answers "who sells this cheapest online". Nobody answers it for the
#  shops you can walk to. This page does, from the catalogues shopkeepers
#  already keep, and it is honest about its limits: it shows when a price was
#  last updated and never claims to cover shops that have not listed anything.
# ==========================================================================
def price_compare(s, term="", cat="", key="", token=""):
    cats = db.category_tree()
    groups = db.comparable_items(cat=cat or None, term=term)
    st = db.price_stats()

    copts = '<option value="">همهٔ دسته‌ها</option>' + "".join(
        f'<option value="{esc(c["slug"])}"'
        f'{" selected" if cat == c["slug"] else ""}>{esc(c["name"])}</option>'
        for c in cats)

    # ---- a single expanded group, when one is asked for
    detail = ""
    if key:
        g = next((x for x in groups if x["key"] == key), None) or db.price_group(key)
        if g:
            rows = ""
            for i, o in enumerate(g["offers"]):
                cheap = o["is_cheapest"]
                rows += f'''<tr class="{"is-best" if cheap else ""}">
          <td class="rank nums">{fa(i + 1)}</td>
          <td><a href="/b/{esc(o["bizslug"])}"><strong>{esc(o["bizname"])}</strong></a>
            {f'<span class="badge badge-open">{icon("award")}<span>ارزان‌ترین</span></span>' if cheap else ''}
          </td>
          <td class="num"><strong class="nums">{esc(o["price_text"])}</strong></td>
          <td class="num">{'<span class="text-muted">—</span>' if cheap else
                           f'<span class="over-pct nums">+{fa(o["over_pct"])}٪</span>'}</td>
          <td class="actions"><a class="btn btn-primary btn-sm" href="/b/{esc(o["bizslug"])}">
            {icon("store")}<span>دیدن دکان</span></a></td>
        </tr>'''
            # v68: price memory + drop alert inside the detail card
            _ch = next((o for o in g["offers"] if o["is_cheapest"]), g["offers"][0])
            _hist = db.price_history(_ch["id"])
            _spark = db.sparkline_svg([p for p, _ in _hist])
            _tr = db.price_trend(_ch["id"])
            _tr_badge = ""
            if _tr is not None:
                _tr_badge = (f'<span class="badge {("badge-open" if _tr < 0 else "badge-warn")} nums">'
                             f'<span>{"روند ↓" if _tr < 0 else "روند ↑"} {fa(abs(_tr))}٪</span></span>')
            _hist_html = (f'<div class="price-history between mt-md" style="gap:10px">'
                          f'{_spark}{_tr_badge}'
                          f'<span class="text-xs text-muted">تاریخچهٔ قیمت ارزان‌ترین دکان</span></div>'
                          if _spark else "")
            _cust = ctx_customer()
            if _cust:
                _watching = g["key"] in db.alert_keys(_cust["id"])
                _alert_btn = f'''<form method="post" action="/prices/alert" class="mt-md">
      <input type="hidden" name="key" value="{esc(g["key"])}">
      <input type="hidden" name="title" value="{esc(g["title"])}">
      <input type="hidden" name="on" value="{0 if _watching else 1}">
      <button class="btn {("btn-glass" if _watching else "btn-accent")} btn-sm" type="submit"
              aria-label="هشدار کاهش قیمت">
        {icon("bell")}<span>{"پاییدن قیمت فعال است — لغو" if _watching else "به من خبر بده ارزان‌تر شد"}</span></button>
    </form>'''
            else:
                _alert_btn = ('<p class="field-hint mt-md">برای هشدار کاهش قیمت، '
                              'اول <a href="/me/login">وارد شوید</a>.</p>')
            detail = f'''<div class="card glass card-pad mb-lg" id="cmp-detail">
  <div class="between mb-md">
    <h2 class="card-title">{icon("chart")} {esc(g["title"])}</h2>
    <a class="btn btn-ghost btn-sm" href="/prices">{icon("x")}<span>بستن</span></a>
  </div>
  <div class="price-summary mb-lg">
    <div><span class="k">ارزان‌ترین</span><strong class="v nums">{esc(g["min_text"])}</strong></div>
    <div><span class="k">گران‌ترین</span><strong class="v nums">{esc(g["max_text"])}</strong></div>
    <div class="save"><span class="k">اختلاف</span>
      <strong class="v nums">{esc(g["spread_text"])}</strong>
      <small class="nums">{fa(g["spread_pct"])}٪</small></div>
  </div>
  {_hist_html}
  {_alert_btn}
  <div class="table-wrap"><table class="table price-table">
    <thead><tr><th>#</th><th>دکان</th><th>قیمت</th><th>اختلاف</th><th></th></tr></thead>
    <tbody>{rows}</tbody></table></div>
</div>'''

    # ---- the list of comparable goods
    cards = ""
    for i, g in enumerate(groups):
        bars = ""
        for o in g["offers"][:4]:
            pct = int(o["price"] / g["max"] * 100) if g["max"] else 0
            bars += f'''<div class="pbar-row">
        <span class="pbar-name">{esc(o["bizname"])}</span>
        <span class="pbar-track"><span class="pbar-fill{" is-best" if o["is_cheapest"] else ""}"
              style="width:{max(8, pct)}%"></span></span>
        <span class="pbar-val nums">{esc(o["price_text"])}</span>
      </div>'''
        # v68: torob-style trend chip from the cheapest offer's price trail
        _cheapest = next((o for o in g["offers"] if o["is_cheapest"]), g["offers"][0])
        _trend = db.price_trend(_cheapest["id"])
        trend_chip = ""
        if _trend is not None:
            trend_chip = (f'<span class="badge {("badge-open" if _trend < 0 else "badge-warn")} nums">'
                          f'<span>{"↓" if _trend < 0 else "↑"} {fa(abs(_trend))}٪</span></span>')
        save = ""
        if g["spread"] > 0:
            save = (f'<span class="badge badge-open">{icon("trending")}'
                    f'<span>تا {fa_group(g["spread"])} تومان ارزان‌تر</span></span>')
        else:
            save = (f'<span class="badge badge-neutral">{icon("check")}'
                    f'<span>قیمت یکسان</span></span>')
        cards += f'''<article class="card glass card-pad price-card reveal-3d" data-delay="{i * 40}">
  <div class="between mb-sm" style="align-items:flex-start;gap:8px">
    <h3 class="card-title">{esc(g["title"])}</h3>
    <span class="badge badge-info nums">{fa(g["n"])} دکان</span>
  </div>
  {f'<div class="text-xs text-muted mb-sm">{esc(g["unit"])}</div>' if g["unit"] else ''}
  <div class="pbars mb-md">{bars}</div>
  <div class="between">
    <span class="row" style="gap:6px">{save}{trend_chip}</span>
    <a class="btn btn-glass btn-sm" href="/prices?key={urlq(g["key"])}{f'&cat={esc(cat)}' if cat else ''}#cmp-detail">
      {icon("layers")}<span>مقایسهٔ کامل</span></a>
  </div>
</article>'''

    if not cards:
        cards = empty_state(
            "chart",
            "هنوز کالای قابل مقایسه‌ای نیست" if not (term or cat) else "چیزی پیدا نشد",
            "مقایسه وقتی ممکن است که دست‌کم دو دکان یک کالا را با قیمت مشخص "
            "ثبت کرده باشند. هرچه دکان‌داران بیشتری کاتالوگ خود را پر کنند، "
            "این صفحه کامل‌تر می‌شود.",
            f'<a class="btn btn-primary mt-lg" href="/register-business">{icon("plus")}'
            f'<span>کسب‌وکار خود را ثبت کنید</span></a>')
    else:
        cards = f'<div class="grid grid-3 price-grid" data-stagger>{cards}</div>'

    body = f'''<div class="container-wide">
  {breadcrumb(("مقایسهٔ قیمت", None))}
  <header class="page-hero"><span class="eyebrow">{icon("chart")}<span>ویژهٔ شهر شما</span></span>
    <h1>یک کالا، چند دکان، چند قیمت</h1>
    <p>قیمت کالاهای پرمصرف را بین دکان‌های شهر مقایسه کنید و قبل از
       بیرون رفتن بدانید کجا ارزان‌تر است. قیمت‌ها را خودِ دکان‌داران
       ثبت می‌کنند.</p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div class="grid grid-3 mb-lg" data-stagger>
    {stat_card("layers", st["groups"], "کالای قابل مقایسه")}
    {stat_card("store", st["offers"], "قیمت ثبت‌شده", delay=60)}
    {stat_card("trending", st["best_saving"], "بیشترین صرفه‌جویی (تومان)",
               suffix="", delay=120)}
  </div>

  <form class="dir-toolbar mb-lg" method="get" action="/prices">
    <div class="dir-row">
      <span class="search-wrap">{icon("search", cls="search-icon")}
        <label class="sr-only" for="pq">جست‌وجوی کالا</label>
        <input class="input" id="pq" name="q" type="search" value="{esc(term)}"
               placeholder="نام کالا — مثلاً شیر، برنج، نان…" autocomplete="off"></span>
      <label class="sr-only" for="pcat">دسته</label>
      <select class="select" id="pcat" name="cat" onchange="this.form.submit()">{copts}</select>
      <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
    </div>
  </form>

  {detail}
  {cards}

  <div class="alert alert-info mt-lg">{icon("info")}<span>
    قیمت‌ها را دکان‌داران در کاتالوگ خودشان وارد می‌کنند و ممکن است
    تغییر کرده باشد. پیش از خرید، تلفنی تأیید بگیرید. اگر دکان‌دارید و
    می‌خواهید قیمت‌هایتان اینجا دیده شود،
    <a href="/register-business">کسب‌وکارتان را ثبت کنید</a>.</span></div>
</div></section>'''
    return page(s, "مقایسهٔ قیمت در ایران", body, "/prices", token=token,
                cats=cats,
                desc="قیمت کالاهای پرمصرف را بین دکان‌های شهر شما مقایسه کنید.")


def price_context_block(biz_id):
    """On a shop's own page: for each product it sells that other shops also
    sell, say plainly where this shop stands.

    This is deliberately even-handed. When the shop is cheapest it says so —
    that is a selling point it earned. When it is not, it says that too,
    because a directory that only ever flatters shops is worth nothing to the
    shopper it is supposed to serve, and shoppers are who bring the shops.
    """
    groups = [g for g in db.comparable_items()
              if any(o["biz_id"] == biz_id for o in g["offers"])]
    if not groups:
        return ""

    wins = rows = ""
    n_best = 0
    for g in groups:
        mine = next(o for o in g["offers"] if o["biz_id"] == biz_id)
        if mine["is_cheapest"]:
            n_best += 1
        rank = g["offers"].index(mine) + 1
        if mine["is_cheapest"]:
            verdict = (f'<span class="badge badge-open">{icon("award")}'
                       f'<span>ارزان‌ترین در شهر</span></span>')
        else:
            verdict = (f'<span class="text-xs text-muted">'
                       f'رتبهٔ {fa(rank)} از {fa(g["n"])} — '
                       f'{fa_group(mine["over_min"])} تومان بیشتر از ارزان‌ترین</span>')
        rows += f'''<div class="info-row">
      <span class="k">{esc(g["title"])}</span>
      <span class="v"><strong class="nums">{esc(mine["price_text"])}</strong> {verdict}</span>
    </div>'''

    if n_best:
        wins = (f'<div class="alert alert-success mb-md">{icon("award")}<span>'
                f'این دکان در <strong>{fa(n_best)}</strong> کالا '
                f'ارزان‌ترین قیمت شهر را دارد.</span></div>')

    return f'''<div class="card glass card-pad reveal" id="price-context">
  <div class="between mb-md">
    <h3 class="card-title">{icon("chart")} قیمت‌ها در مقایسه با شهر</h3>
    <a class="btn btn-ghost btn-sm" href="/prices">{icon("layers")}<span>همهٔ مقایسه‌ها</span></a>
  </div>
  {wins}
  {rows}
  <p class="text-xs text-muted mt-md">{icon("info")} مقایسه بر پایهٔ قیمت‌هایی است
    که دکان‌داران خودشان ثبت کرده‌اند.</p>
</div>'''


# ==========================================================================
#  چانه‌زنی — the offer form and the negotiation thread
# ==========================================================================
HAG_STATUS = {
    "open":      ("badge-warn",   "در انتظار پاسخ فروشنده"),
    "countered": ("badge-info",   "فروشنده قیمت دیگری پیشنهاد داد"),
    "accepted":  ("badge-open",   "پذیرفته شد"),
    "declined":  ("badge-closed", "رد شد"),
    "expired":   ("badge-neutral", "منقضی شد"),
}


def haggle_button(it):
    """The 'make an offer' control that sits next to a haggle-able price."""
    if not db.haggle_allowed(it):
        return ""
    return (f'<a class="btn btn-accent btn-sm" href="/haggle/{it["id"]}">'
            f'{icon("tag")}<span>پیشنهاد قیمت بدهید</span></a>')


def haggle_badge(it):
    if not db.haggle_allowed(it):
        return ""
    return (f'<span class="badge badge-accent haggle-flag">{icon("tag")}'
            f'<span>قابل چانه‌زنی</span></span>')


def haggle_form(s, item_id, token="", sent=None, err=""):
    """Where a buyer names their price."""
    it = db.item(item_id)
    if not it:
        return None
    biz = db.business(bid=it["biz_id"])
    if not db.haggle_allowed(it):
        return page(s, "چانه‌زنی", f'''<div class="container">
  {breadcrumb(("چانه‌زنی", None))}
  {empty_state("tag", "این کالا چانه‌زنی ندارد",
               "فروشندهٔ این کالا قیمت ثابت گذاشته است. می‌توانید مستقیم تماس بگیرید.",
               f'<a class="btn btn-primary mt-lg" href="/b/{esc(biz["slug"]) if biz else ""}">'
               f'{icon("store")}<span>دیدن دکان</span></a>')}
</div>''', "", token=token, cats=db.category_tree())

    listed = int(it.get("price") or 0)
    cfg = db.haggle_settings()

    # The hint must point at a price that would actually be ACCEPTED. The old
    # version quoted min_pct (50% of list) — the threshold below which an
    # offer is auto-countered — so it was steering buyers straight into a
    # refusal. Nudge just above the real floor instead, without ever
    # revealing the floor itself: rounding to the nearest 1,000 keeps the
    # seller's exact number private while still being useful.
    floor = int(it.get("floor_price") or 0)
    if floor:
        floor_hint = int(round(floor * 1.02 / 1000.0)) * 1000
    else:
        floor_hint = int(round(listed * 0.9 / 1000.0)) * 1000

    if sent:
        st = sent["verdict"]
        if st == "accepted":
            box = f'''<div class="hag-result is-yes">
        <span class="hag-emoji" aria-hidden="true">{icon("check-circle")}</span>
        <h2>پیشنهاد شما پذیرفته شد</h2>
        <p>فروشنده از قبل اعلام کرده بود تا این قیمت می‌فروشد، پس معامله
           همین حالا قطعی شد. برای هماهنگی تحویل تماس بگیرید.</p>
        <div class="cluster" style="justify-content:center">
          <a class="btn btn-primary" href="tel:{esc(biz["phone"])}">
            {icon("phone")}<span>تماس با {esc(biz["name"])}</span></a>
          <a class="btn btn-glass" href="/offer/{esc(sent["token"])}">
            {icon("list")}<span>دیدن گفت‌وگو</span></a>
        </div></div>'''
        elif st == "countered":
            box = f'''<div class="hag-result is-mid">
        <span class="hag-emoji" aria-hidden="true">{icon("tag")}</span>
        <h2>فروشنده قیمت دیگری پیشنهاد داد</h2>
        <p>پیشنهاد شما از کمترین قیمت این کالا پایین‌تر بود، ولی فروشنده
           در را نبسته — قیمت پیشنهادی او را ببینید.</p>
        <a class="btn btn-primary" href="/offer/{esc(sent["token"])}">
          {icon("list")}<span>دیدن پیشنهاد فروشنده</span></a></div>'''
        else:
            box = f'''<div class="hag-result">
        <span class="hag-emoji" aria-hidden="true">{icon("send")}</span>
        <h2>پیشنهاد شما ثبت شد</h2>
        <p>فروشنده پیشنهاد شما را می‌بیند و تا {fa(cfg["ttl"])} ساعت آینده
           پاسخ می‌دهد. این نشانی را نگه دارید تا نتیجه را ببینید.</p>
        <a class="btn btn-primary" href="/offer/{esc(sent["token"])}">
          {icon("list")}<span>پیگیری پیشنهاد</span></a></div>'''
        body = f'<div class="container"><section class="section-sm">{box}</section></div>'
        return page(s, "پیشنهاد شما ثبت شد", body, "", token=token,
                    cats=db.category_tree())

    body = f'''<div class="container">
  {breadcrumb((biz["name"], f"/b/{biz['slug']}"), ("پیشنهاد قیمت", None))}
  <header class="page-hero"><span class="eyebrow">{icon("tag")}<span>چانه‌زنی</span></span>
    <h1>قیمت خودتان را پیشنهاد بدهید</h1>
    <p>مثل خرید حضوری در بازار — شما قیمت می‌گویید، فروشنده قبول می‌کند،
       رد می‌کند، یا قیمت دیگری پیشنهاد می‌دهد.</p></header>
</div>
<section class="section-sm"><div class="container">
  {flash("err", err) if err else ""}
  <div class="card glass card-pad mb-lg">
    <div class="hag-item">
      {f'<img src="{esc(it["cover"])}" alt="" width="72" height="72" class="hag-thumb">' if it.get("cover") else ''}
      <div>
        <strong>{esc(it["title"])}</strong>
        <div class="text-sm text-muted">{esc(biz["name"])}</div>
        <div class="hag-listed">قیمت اعلام‌شده:
          <strong class="nums">{esc(it["price_text"])}</strong></div>
      </div>
    </div>
  </div>

  <form class="card glass card-pad" method="post" action="/haggle/{it["id"]}" data-validate>
    <div class="field">
      <label class="field-label" for="hg-offer">پیشنهاد شما (تومان)<span class="req">*</span></label>
      <input class="input nums" id="hg-offer" name="offer" inputmode="numeric"
             required placeholder="مثلاً {fa_group(int(listed * 0.9))}">
      <p class="field-hint">پیشنهاد خیلی پایین معمولاً جواب نمی‌گیرد —
         قیمت‌های نزدیک به {fa_group(floor_hint)} تومان شانس بیشتری دارند.</p>
    </div>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="hg-qty">تعداد</label>
        <input class="input nums" id="hg-qty" name="qty" type="number" min="1" value="1"></div>
      <div class="field"><label class="field-label" for="hg-name">نام شما<span class="req">*</span></label>
        <input class="input" id="hg-name" name="name" required minlength="2"></div>
    </div>
    <div class="field"><label class="field-label" for="hg-phone">شمارهٔ تماس<span class="req">*</span></label>
      <input class="input nums" id="hg-phone" name="phone" type="tel" required
             placeholder="09xxxxxxxxx">
      <p class="field-hint">فقط برای همین معامله استفاده می‌شود و روی سایت نمایش داده نمی‌شود.</p></div>
    <div class="field"><label class="field-label" for="hg-note">توضیح (اختیاری)</label>
      <textarea class="textarea" id="hg-note" name="note" style="min-height:80px"
        placeholder="مثلاً: نقد پرداخت می‌کنم، یا امروز می‌آیم می‌برم."></textarea></div>
    <button class="btn btn-primary btn-lg" type="submit">
      {icon("send")}<span>ارسال پیشنهاد</span></button>
    <p class="text-xs text-muted mt-md">{icon("info")} پیشنهاد شما تا
      {fa(cfg["ttl"])} ساعت معتبر است. اگر فروشنده قبول کند، خودتان خبردار می‌شوید.</p>
  </form>
</div></section>'''
    return page(s, f"پیشنهاد قیمت — {it['title']}", body, "", token=token,
                cats=db.category_tree())


def haggle_thread_page(s, thread_token, token="", err=""):
    """The negotiation itself, readable by whoever holds the link."""
    rows = db.haggle_thread(token=thread_token)
    if not rows:
        return None
    root = rows[0]
    biz = db.business(bid=root["biz_id"])
    it = db.item(root["item_id"]) if root.get("item_id") else None
    last = rows[-1]

    # The headline status describes the NEGOTIATION, not the last row. The
    # last row of a countered thread is the seller's fresh offer, whose own
    # status is 'open' — reading that literally told the buyer they were
    # "awaiting the seller" while the seller's counter sat right above it.
    if last["status"] == "accepted" or root["status"] == "accepted":
        state = "accepted"
    elif root["status"] in ("declined", "expired"):
        state = root["status"]
    elif not last["is_buyer"]:
        state = "countered"      # the ball is in the buyer's court
    else:
        state = "open"           # waiting on the shopkeeper
    cls, label = HAG_STATUS.get(state, ("badge-neutral", state))

    bubbles = ""
    for r in rows:
        who = "شما" if r["is_buyer"] else esc(biz["name"])
        side = "is-buyer" if r["is_buyer"] else "is-seller"
        bubbles += f'''<div class="hag-bubble {side}">
      <div class="hag-who">{icon("user" if r["is_buyer"] else "store")}<span>{who}</span>
        <time class="nums">{esc(jdatetime(r["created"]))}</time></div>
      <div class="hag-price nums">{esc(r["offer_text"])}</div>
      {f'<p class="hag-note">{esc(r["note"])}</p>' if r.get("note") else ''}
    </div>'''

    # A buyer may counter only while the thread is still live.
    reply = ""
    if last["status"] in ("open", "countered") and not last["is_buyer"]:
        reply = f'''<form class="card glass card-pad mt-lg" method="post"
      action="/offer/{esc(thread_token)}" data-validate>
  <h3 class="card-title mb-md">{icon("tag")} پاسخ شما</h3>
  <div class="field"><label class="field-label" for="rp-offer">قیمت پیشنهادی تازه (تومان)</label>
    <input class="input nums" id="rp-offer" name="offer" inputmode="numeric" required></div>
  <div class="field"><label class="field-label" for="rp-note">توضیح</label>
    <input class="input" id="rp-note" name="note"></div>
  <div class="cluster">
    <button class="btn btn-primary" type="submit" name="action" value="counter">
      {icon("send")}<span>ارسال پیشنهاد تازه</span></button>
    <button class="btn btn-glass" type="submit" name="action" value="accept"
      formnovalidate>{icon("check")}<span>قبول می‌کنم</span></button>
  </div>
</form>'''

    done = ""
    if state == "accepted":
        done = f'''<div class="alert alert-success mt-lg">{icon("check-circle")}<span>
      این معامله در قیمت <strong class="nums">{esc(last["offer_text"])}</strong> قطعی شد.
      برای هماهنگی با <a href="tel:{esc(biz["phone"])}">{esc(biz["phone"])}</a> تماس بگیرید.
    </span></div>'''

    body = f'''<div class="container">
  {breadcrumb((biz["name"], f"/b/{biz['slug']}"), ("گفت‌وگوی قیمت", None))}
  <header class="page-hero"><span class="eyebrow">{icon("tag")}<span>چانه‌زنی</span></span>
    <h1>{esc(it["title"]) if it else "گفت‌وگوی قیمت"}</h1>
    <p>{esc(biz["name"])} — <span class="badge {cls}">{esc(label)}</span></p></header>
</div>
<section class="section-sm"><div class="container">
  {flash("err", err) if err else ""}
  {f'<div class="card glass card-pad mb-lg"><div class="info-row">{icon("tag")}'
   f'<span class="k">قیمت اعلام‌شده</span>'
   f'<span class="v nums">{esc(it["price_text"])}</span></div></div>' if it else ''}
  <div class="hag-thread">{bubbles}</div>
  {done}
  {reply}
  <p class="text-xs text-muted mt-lg">{icon("info")} این نشانی خصوصی شماست؛
     هرکس آن را داشته باشد می‌تواند این گفت‌وگو را ببیند.</p>
</div></section>'''
    return page(s, "گفت‌وگوی قیمت", body, "", token=token, cats=db.category_tree())


# ---------------------------------------------------------------- features map
# Every capability the site has, on one page, each row a real link. Built
# because the shopkeeper features were invisible: they live behind /login, and
# a sign-in button with nothing written on it tells you nothing about what is
# on the other side. This doubles as the page to show a shopkeeper in person.
FEATURE_MAP = [
    ("برای مردم شهر", "users", [
        ("/businesses", "grid", "فهرست همهٔ کسب‌وکارها",
         "جست‌وجو بر پایهٔ نام، دسته، محله و امتیاز"),
        ("/map", "map", "نقشهٔ شهر",
         "روی نقشه ببینید کجاست؛ با یک کلیک مسیریابی"),
        ("/nearby", "compass", "نزدیک من",
         "نزدیک‌ترین دکان‌ها بر پایهٔ موقعیت شما"),
        ("/catalog", "shopping", "محصولات و خدمات",
         "کالاها را مستقیم ببینید، نه فقط اسم دکان"),
        ("/prices", "chart", "مقایسهٔ قیمت",
         "قیمت یک کالا را بین چند دکان بسنجید"),
        ("/events", "calendar", "رویدادهای شهر",
         "نمایشگاه، جشنواره و بازارچه"),
        ("/blog", "book", "اخبار شهر",
         "نوشته‌ها و اطلاعیه‌های دست گیر"),
        ("/favorites", "heart", "علاقه‌مندی‌ها",
         "دکان‌های موردعلاقه را نشان کنید"),
    ]),
    ("برای صاحبان کسب‌وکار", "store", [
        ("/register-business", "plus", "ثبت کسب‌وکار — رایگان",
         "سه فیلد: نام، دسته و شماره تلفن"),
        ("/my/businesses", "store", "صفحهٔ اختصاصی دکان",
         "عکس، ساعت کار، آدرس، شبکه‌های اجتماعی و پس‌زمینهٔ دلخواه"),
        ("/my/businesses", "grid", "بارکد QR ویترین",
         "دانلود کنید، چاپ کنید، روی شیشه بزنید"),
        ("/my/bookings", "calendar", "نوبت‌دهی اینترنتی",
         "مشتری خودش نوبت می‌گیرد، شما تأیید می‌کنید"),
        ("/my/inquiries", "message", "پیام مشتریان",
         "مشتری پیام می‌دهد، شما پاسخ می‌دهید"),
        ("/my/reviews", "message", "نظرات و امتیاز",
         "به نظر مشتری پاسخ بدهید"),
        ("/my/questions", "help", "پرسش و پاسخ",
         "سؤال‌های پرتکرار مشتری را همان‌جا جواب بدهید"),
        ("/my/tickets", "mail", "پشتیبانی مستقیم",
         "هر وقت کاری داشتید با مدیر سایت گفت‌وگو کنید"),
        ("/my/plan", "wallet", "اشتراک و آمار",
         "ببینید چند نفر شمارهٔ شما را گرفته‌اند"),
        ("/my/claim", "shield", "تصاحب کسب‌وکار",
         "دکان‌تان از قبل ثبت شده؟ آن را به نام خود کنید"),
    ]),
]


def features(s, token="", me=None):
    cats = db.category_tree()
    blocks = ""
    for title, ic, rows in FEATURE_MAP:
        cards = ""
        for href, ri, rt, rd in rows:
            if href == "/prices" and s.get("prices_enabled") != "1":
                continue
            # An owner link is useless to a signed-out visitor unless it takes
            # them through the door and back — so it does exactly that.
            link = href
            if href.startswith("/my") and not me:
                link = "/login?next=" + urllib.parse.quote(href)
            lock = ('<span class="feat-lock">'
                    + icon("lock") + "<span>نیاز به ورود</span></span>"
                    ) if href.startswith("/my") and not me else ""
            cards += f'''<a class="feat-card" href="{esc(link)}">
              <span class="feat-ico">{icon(ri)}</span>
              <span class="feat-txt"><strong>{esc(rt)}</strong>
                <small>{esc(rd)}</small>{lock}</span>
              {icon("chevron-left")}</a>'''
        blocks += f'''<section class="section-sm"><div class="container-wide">
          {section_head("امکانات", title, eyebrow_icon=ic)}
          <div class="feat-grid">{cards}</div>
        </div></section>'''

    cta = "" if me else f'''<section class="section-sm"><div class="container-wide">
      <div class="card glass card-pad center">
        <h2 class="h3">دکان دارید؟</h2>
        <p class="text-muted">ثبت کسب‌وکار رایگان است و کمتر از یک دقیقه طول می‌کشد.</p>
        <div class="row-center gap-sm mt-md wrap">
          <a class="btn btn-accent btn-lg" href="/register-business">{icon("plus")}<span>ثبت کسب‌وکار</span></a>
          <a class="btn btn-ghost btn-lg" href="/login">{icon("store")}<span>ورود دکان‌داران</span></a>
        </div>
      </div></div></section>'''

    body = f'''<div class="container-wide">{breadcrumb(("همهٔ امکانات", None))}
  <header class="page-hero">
    <span class="eyebrow">{icon("sparkles")}<span>راهنمای کامل</span></span>
    <h1>هر کاری با دست گیر می‌شود کرد</h1>
    <p class="lede">همهٔ امکانات سایت در یک صفحه. روی هر کدام بزنید تا مستقیم
       همان‌جا بروید.</p>
  </header></div>
{blocks}{cta}'''
    return page(s, "همهٔ امکانات", body, "", token=token, cats=cats)
