# -*- coding: utf-8 -*-
"""
v316 file exchange only — arena browser completely removed per owner request.
Only file exchange for agent panel remains: data/agent-exchange/
Standard library only.
"""

import os
import re
import time
import pathlib as _pl
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "..", "data")
EXCHANGE_DIR = os.path.join(DATA_DIR, "agent-exchange")
os.makedirs(EXCHANGE_DIR, exist_ok=True)

# Backward compat shims — arena removed, return 404 style
DEFAULT_ARENA_URL = "https://example.com"
ALLOWED_HOSTS = set()

def _proxy_env():
    return ""

def get_arena_cookie():
    return ""

def set_arena_cookie(s):
    return False

def _extract_arena_tokens(s):
    return {"access_token": "", "has_cf": False, "cookie_len": 0}

def fetch_raw(url, timeout=15, extra_headers=None):
    return {"ok": False, "error": "removed in v316 — این بخش حذف شد", "body": b"", "content_type": "", "status": 404, "headers": {}}

def fetch_url(url, timeout=15):
    return {"ok": False, "error": "removed in v316 — این بخش حذف شد"}

def proxy_fetch(url, timeout=15):
    return {"ok": False, "body": "removed in v316 — این بخش حذف شد".encode(), "content_type": "text/plain", "status": 404, "headers": {}, "is_html": False, "is_fallback": True}

def proxy_page(url):
    return "<html><body>این بخش حذف شد</body></html>"

def _bridge_path(name="latest.json"):
    return os.path.join(EXCHANGE_DIR, name)

def bridge_load():
    return {"url": "", "messages": [], "files": [], "updated": 0, "proxy": "", "cookie": False}

def bridge_save(data):
    return False

def bridge_append_message(role, text, files=None):
    return bridge_load()

def exchange_list():
    out = []
    try:
        for fn in os.listdir(EXCHANGE_DIR):
            fp = os.path.join(EXCHANGE_DIR, fn)
            if not os.path.isfile(fp):
                continue
            st = os.stat(fp)
            out.append({"name": fn, "size": st.st_size, "mtime": st.st_mtime})
    except Exception:
        pass
    out.sort(key=lambda x: x["mtime"], reverse=True)
    return out[:100]

def exchange_save_file(data: bytes, filename: str):
    filename = re.sub(r"[^A-Za-z0-9._-]", "_", filename)[:120]
    if not filename:
        filename = f"file-{int(time.time())}.bin"
    fp = os.path.join(EXCHANGE_DIR, filename)
    base, ext = os.path.splitext(filename)
    i = 1
    while os.path.exists(fp):
        fp = os.path.join(EXCHANGE_DIR, f"{base}_{i}{ext}")
        i += 1
        if i > 20:
            break
    open(fp, "wb").write(data[:20_000_000])
    return {"ok": True, "name": os.path.basename(fp), "size": len(data), "path": f"/agent/file/{urllib.parse.quote(os.path.basename(fp))}"}

def browser_html(s, q):
    return '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=/agent"></head><body>این بخش حذف شد — رفتن به <a href="/agent">/agent</a></body></html>'
