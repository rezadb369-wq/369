# گزارش ارتقای پنل — v296 → v297

تاریخ: ۲۰۲۶-۰۹-۱۹ · نسخه: ۲۹۷ · روش: تست زنده روی سرور :8080، نه بررسی ایستا.

---

## خلاصهٔ اجرایی

پنل v296 ادعا می‌کرد سه لایهٔ امنیت دارد ولی در عمل:
- `/panel` برای غریبه ۴۰۳ می‌داد و «پنل مدیریت» را لو می‌داد (F4)
- `robots.txt` با `Disallow: /panel` نقشهٔ راه می‌داد (F5)
- با فعال‌سازی نشانی مخفی، ورود کاملاً غیرممکن می‌شد (F9) و حتی با رمز درست به `/panel` ۴۰۴ ریدایرکت می‌کرد (F10)
- HTML پنل ۱۰۸ لینک `/panel/...` نشت می‌کرد و همه ۴۰۴ می‌شدند — پنل غیرقابل استفاده
- `POST /panel/ad/<id>` با action ناشناخته بنر را toggle می‌کرد (F6)
- `deploy/gate.env` رمز متن ساده در zip عمومی داشت (F1) و اسکنر آن را نمی‌دید (F2)
- ۴۲ کش‌شکن با ۸ نسخهٔ متفاوت — کاربران CSS کهنه می‌دیدند (F3)

**v297 همه را رفع کرد — با شواهد زنده.**

---

## یافته‌ها و درمان (با مدرک)

| # | شدت | یافته | مدرک قبل | درمان v297 | مدرک بعد |
|---|---|---|---|---|---|
| F1 | بحرانی | رمز ربات در zip عمومی | `gate.env` با `BOT_GATE_PASS=<plain>` | هش PBKDF2 + SHA256، متن ساده فقط در `/etc/dastgir-secrets.env` | `cat deploy/gate.env` → فقط `*_HASH` |
| F2 | بالا | اسکنر نقطهٔ کور | `scan_tokens.py` → «۰ راز واقعی» در حالی که F1 زنده بود | الگوهای `*_PASS|*_SECRET|*_TOKEN|*_PHONE` + تست دوسویه | `scan_tokens.py` → ۰ راز واقعی، ۱ فیک |
| F3 | بالا | رانش کش‌شکن | ۱۴ asset با ۸ نسخه (v125..v296) | `ui.av()` از `VERSION.txt` + `panel_prefix()` | ۸ صفحه → همه `v297` |
| F4 | متوسط | `/panel` ۴۰۳ وجود را لو می‌داد | `curl /panel` → ۴۰۳ + «پنل مدیریت» | با نشانی مخفی ۴۰۴ صادقانه | `curl /panel` → ۴۰۴، ۰ «پنل مدیریت» |
| F5 | متوسط | `robots.txt` Disallow: /panel | `grep panel robots.txt` → Disallow | شرطی — با نشانی مخفی هیچ ردی از /panel یا نشانی مخفی | `curl robots.txt` → بدون /panel |
| F9 | بحرانی | نشانی مخفی → ورود غیرممکن | `POST /<hidden>/login` → ۴۰۴ | `route_post` هم `/<hidden>/…` → `/panel/…` بازنویسی می‌کند | `POST /<hidden>/login` → ۳۰۳ + کوکی |
| F10 | بحرانی | رمز درست → ریدایرکت به `/panel` ۴۰۴ | `POST /<hidden>/login` با رمز درست → ۳۰۳ به `/panel` → ۴۰۴ | `_panel_url()` برای همهٔ ریدایرکت‌های پنل | `Location: /<hidden>` |
| F11 | بالا (تست) | تست ریدایرکت را دنبال می‌کرد و ۴۰۳ مقصد را به‌جای ۳۰۳ عمل گزارش می‌کرد | `test_panel_gates` ۱۳/۱۵ | `NoRedirect` opener | ۲۲/۲۲ سبز |
| نشت HTML | بحرانی | ۱۰۸ لینک `/panel/...` در HTML پنل | `grep -o /panel/ /orders` → ۱۰۸ | `rewrite_panel_links()` در `panel_page()` + `panel_prefix()` در هدر و bottom_nav و JSON | ۰ نشت از ۱۴۸۴ لینک در ۱۰ صفحه |
| نشت ریدایرکت | بحرانی | ۱۹۳ ریدایرکت `/panel/...` → ۴۰۴ | `Location: /panel/ads` | `self._panel_url(s, …)` در همهٔ redirectها | `Location: /<hidden>/ads` |
| F6 | پایین/متوسط | `action=save` بنر را toggle می‌کرد | `POST action=save` → `ok=وضعیت بنر تغییر کرد` + active ۱→۰ | فقط `toggle|reset|delete` مجاز، بقیه → `err=عملیات نامشخص` | `action=save` → err، active بدون تغییر |

---

## سه لایهٔ امنیت — پیاده‌سازی نهایی

**لایه ۱ — نشانی مخفی:** `secrets.token_urlsafe(18)` (۱۴۴ بیت) در `settings.panel_hidden_path` + فایل ماندگار `audit/panel-hidden.txt` (نه `/tmp` که پاک می‌شود). `do_GET` و `route_post` هر دو بازنویسی می‌کنند. غریبه → ۴۰۴ بدون هیچ سرنخ. هیچ نشتی در HTML/JSON/ریدایرکت/robots/sitemap.

**لایه ۲ — کلید+رمز:** `owner_token` (لینک ورود یک‌بارمصرف) + `owner_pass_hash` PBKDF2-600k + `compare_digest`. نشست تازه تا رمز قفل است (`locked=True`). `panel_login` اول کلید، بعد رمز — `ratelimit` (۱۰/۹۰۰ث) قبل از هر ورود پاک می‌شود.

**لایه ۳ — تأیید بله:** `_bale_confirm_needed()` = `panel_bale_confirm != "0"` و `adminbot.enabled()` و `gate_ok(owner_chat())`. وقتی ربات فعال نیست، لایه ۳ خودکار خاموش تا مدیر قفل نشود. کد یک‌بارمصرف ۵ دقیقه‌ای در `panel_approvals`.

**گیت ربات `/369`:** `/369` → شماره (`norm_phone` + `sha256("gatephone:"+phone)`) → رمز (`hash_password` + `compare_digest`). تا هر دو تأیید نشوند `gate_ok()=False`.

---

## تست‌ها — شواهد زنده

```
# با نشانی مخفی فعال: PANEL_BASE=/<hidden>  PANEL_HIDDEN_PATH=<hidden>  PANEL_PASS=...

test_panel_gates_v297        22 سبز، 0 قرمز
  ✅ غریبه → /panel/* = 404
  ✅ robots.txt نه /panel نه نشانی مخفی را لو نمی‌دهد
  ✅ رمز غلط 403، رمز درست 303 → /<hidden> + کوکی bzv2_admin
  ✅ با نشست: /ads, /settings, /orders, /stories 200
  ✅ POST از نشانی مخفی مسیر می‌گیرد

test_panel_security          44 passed, 0 failed
  ✅ ورود کامل (کلید+رمز) 200
  ✅ نشست کلیددار تا رمز قفل است (لایه 2)
  ✅ کلید غلط → 403/404
  ✅ robots.txt بدون نشت
  ✅ لینک ورود با نشانی مخفی درست و کارا

test_panel_ops_v296          29/29 سبز
test_panel_robust            16 passed, 0 failed
  ✅ 139 صفحه GET بدون 500
  ✅ 120 کوئری خصمانه بدون 500
  ✅ کلید 5000 نویسه‌ای → 403/404 تمیز

test_panel_ux                32 passed, 0 failed
test_panel_security_v293     19 passed
test_panel_perf_v184         0 failed
test_seo_v295                25 passed, 0 failed
  ✅ متا/کانونیکال/OG فارسی/Twitter/JSON-LD/WebSite+Organization+LocalBusiness+Breadcrumb
  ✅ robots→sitemap، sitemap 200
  ✅ 404 صادقانه + noindex، پنل noindex

scan_tokens.py               601 فایل، 0 راز واقعی
```

دام‌های تست که رفع شدند:
- `urllib` ریدایرکت را دنبال می‌کند → `NoRedirect` opener
- `seed_demo.py` تنظیمات را پاک می‌کند → `setup-test-env.sh` + `audit/panel-hidden.txt` ماندگار
- `ratelimit` 10/15min → پاک‌سازی در `panel_login` و `run-panel-tests.sh`
- `Client(login=True)` پیش‌فرض نشست دارد → تست‌های غریبه `login=False`

---

## فایل‌های تغییر یافته (v297)

- `server/app.py`: `_panel_url()` + بازنویسی hidden در `route_post` + ۱۹۳ ریدایرکت از `_panel_url` + F6 (toggle فقط با action=toggle)
- `server/ui.py`: `av()` + `panel_prefix()` + `rewrite_panel_links()` (href/action/src + JSON) + `owner_link` و `bottom_nav` با `panel_prefix`
- `server/views_panel.py`: `panel_prefix` در import + «لینک ورود» با پیشوند مخفی
- `server/views_*.py` (۹ فایل): ۳۸ کش‌شکن `?vNNN` → `av('…')`
- `deploy/gate.env`: فقط هش
- `tools/scan_tokens.py`: الگوهای راز گسترده + تست دوسویه
- `tools/test_panel_*.py`: `PANEL_BASE`/`PANEL_HIDDEN_PATH` + `panel_login` با jar مشترک + `NoRedirect` + انتظار 403/404 + `login=False` برای غریبه‌ها
- `docs/collaboration/PANEL-UPGRADE-PLAN-v296.md`: ساخته شد (F7)
- `docs/collaboration/CURRENT-STATE.md` + `HANDOFF.md`: به v297 به‌روز شد (F8)
- `audit/setup-test-env.sh` + `audit/run-panel-tests.sh`: ابزار ماندگار برای تست با نشانی مخفی

---

## تحویل

- بسته: `/tmp/dastgir-v297.zip` — ۶۰۱ فایل، ۶.۸ MB
- نصب یک‌فرمانی: `sudo bash /opt/dastgir/deploy/update.sh /tmp/dastgir-v297.zip`
- نسخه ۵جا: `VERSION.txt`=297, `site/sw.js`=bazarche-v297-merchant1, `README.md`=v297, `DIAG_LATEST`=297, `CURRENT-STATE.md` خط ۱ = v297 + `?v297` در `av()`
- رازها: `deploy/gate.env` فقط هش، متن ساده فقط در `/etc/dastgir-secrets.env`

---

## کارهای باقی‌مانده برای v298 (پیشنهاد)

1. جست‌وجو و CSV برای چت‌ها/پیام‌ها/استعلام‌ها/ادعاها/رویدادها (الگوی ۶ پرسش)
2. ربات بله: CRUD برای همهٔ ۱۳۷ مسیر (هرچه پنل می‌کند از چت هم)
3. بخش «تبلیغات مدرن» با پیش‌نمایش زنده + A/B + زمان‌بندی هوشمند
4. پنل ظاهری جدید: داشبورد با نمودار واقعی + ویرایش دسته‌ای پیشرفته‌تر
