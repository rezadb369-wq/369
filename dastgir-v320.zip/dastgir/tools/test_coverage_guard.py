#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v275 — تست نگهبان پوشش ضداسپم (متدولوژی §۷٫۲ برنامهٔ امنیت).

این تست همان «دورهای بازبینی» را برای همیشه مکانیکی می‌کند:
۱) هر مسیر POST غیرمدیر باید یا درگاه ضداسپم/سطل داشته باشد یا در EXEMPT با دلیل؛
۲) کنش‌های اعلان‌ساز/ضدscrape باید always باشند (سوئیچ مدیر خاموش‌شان نمی‌کند)؛
۳) وب‌هوک‌ها always؛ ۴) sweep ساعتی هرس‌ها را صدا می‌زند؛ ۵) جدول‌ها/بکاپ درست؛
۶) Handler timeout دارد؛ ۷) shield به banهای ماندگار وصل است.
مسیر نوشتنی تازهٔ بدون سیاست => این تست قرمز می‌شود.
"""
import os
import re
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="covguard-")
os.environ["BZ_DATA_DIR"] = TMP
sys.path.insert(0, str(ROOT / "server"))

import db          # noqa: E402
import antispam    # noqa: E402

db.init()
import app         # noqa: E402

n = 0


def ck(ok, label):
    global n
    assert ok, label
    n += 1
    print("  ✓", label)


src = (ROOT / "server" / "app.py").read_text(encoding="utf-8")
lines = src.splitlines()

# معاف‌های مشروع با دلیل مکتوب — هر افزودنی باید دلیل بیاورد
EXEMPT = {
    # دستور مدیر (v277): فاز۳ انجام شد — loginlock در _unified_verify/_unified_password
    # پیاده است؛ خود مسیرها از v186 (ورود فقط پیام‌رسان) با ۴۰۴ بسته‌اند.
    "/me/login/verify":  "v277: loginlock پیاده (مسیر از v186 بسته — defence in depth)",
    "/me/login/password": "v277: همان loginlock",
    "/me/logout":        "پایان نشست؛ هیچ منبعی نمی‌نویسد",
    "/my/logout":        "پایان نشست؛ هیچ منبعی نمی‌نویسد",
    "/me/profile":       "خود-پیکربندی بدون اعلان برون‌سو",
    # دستور مدیر v316: بخش آرنا کامل حذف شد — مسیرهای زیر دیگر وجود ندارند و ۴۰۴ می‌دهند
    # هیچ اثری در پنل نماند، فقط ایجنت مدیریتی داخلی
    "/api/agent/chat": "v316: rate_ok 60/60 + agent_ok — چت ایجنت با سهمیه (فارسی)",
    "/agent/chat": "v316: همان چت ایجنت (فارسی)",
    "/api/agent/chat2": "v316: همان چت ایجنت v2 (فارسی)",
    "/api/stories/": "v312: بیکن بازدید استوری — ضدتورم با cid، بدون هویت",
    "/t/": "v312: ترک کلیک کسب‌وکار — بیکن آنالیتیک بدون هویت",
}

routes = []
method = None
for i, l in enumerate(lines, 1):
    m = re.match(r"\s*def (do_\w+)", l)
    if m:
        method = m.group(1)
    if method != "do_POST":
        continue
    m = re.match(r"\s*(?:if|elif)\s+path\s*(==|in|startswith)\s*(.+?)\s*:", l)
    if m:
        routes.append((i, m.group(2))); continue
    m = re.match(r"\s*m\s*=\s*re\.match\(r?\"(\^?[^\"]+)\"", l)
    if m:
        routes.append((i, m.group(1)))

MARK = re.compile(r"spam_gate\(|rate_ok\(|antispam\.guard\(")   # v280: guard مستقیم هم پوشش است
uncovered = []
for i, pat in routes:
    if "/panel/" in pat:
        continue                      # گیت کلید مدیر (RULES §۳ دسترسی حداکثری)
    win = "\n".join(lines[i - 1:i + 40])   # v280: هندلرهای بلندتر هم دیده شوند
    if MARK.search(win):
        continue
    if any(e in pat for e in EXEMPT):
        continue
    uncovered.append((i, pat))
ck(not uncovered, "همهٔ مسیرهای POST غیرمدیر پوشش دارند (بدون پوشش: %s)" % uncovered)
ck(len(routes) > 140, "اینونتوری مسیرها سالم است (%d POST)" % len(routes))

# ۲) کنش‌های اعلان‌ساز/ضدscrape همیشه always
for a in ("notifyme", "ordstatus", "offer", "checkdup", "view", "search", "msgpoll"):
    ck(antispam.POLICY[a][2] is True, "کنش %s همیشه always (ضدتقویت/ضدscrape)" % a)

# ۳) وب‌هوک‌ها always
ck(src.count('window=60, always=True)') >= 3, "وب‌هوک‌های بله/سروش always")

# ۴) sweep ساعتی هرس‌ها را صدا می‌زند
ck("antispam.prune()" in src, "sweep: antispam.prune()")
ck("assistant.chat_log_prune()" in src, "sweep: چرخش لاگ چت")

# ۵) جدول‌ها + بکاپ
sch = db.SCHEMA if hasattr(db, "SCHEMA") else "\n".join(
    l for l in lines)  # fallback
raw = (ROOT / "server" / "db.py").read_text(encoding="utf-8")
ck("CREATE TABLE IF NOT EXISTS spam_events" in raw, "SCHEMA: spam_events")
ck("CREATE TABLE IF NOT EXISTS spam_bans" in raw, "SCHEMA: spam_bans")
exp = re.search(r"def export_all\(\):.*?return out", raw, re.S).group(0)
ck('"spam_bans"' in exp, "بکاپ: spam_bans در export_all")
ck("spam_events" not in exp, "بکاپ: spam_events عمداً گذرا (مثل sessions)")
rst = re.search(r"_RESTORE_ORDER = \(.*?\"audit\"\)", raw, re.S).group(0)
ck('"spam_bans"' in rst, "بکاپ: spam_bans در _RESTORE_ORDER")

# ۶) timeout اتصال (G15)
ck(getattr(app.App, "timeout", 0) == 30, "Handler.timeout=30 (ضد slowloris)")

# ۷) shield به banهای ماندگار وصل است
sh = (ROOT / "server" / "shield.py").read_text(encoding="utf-8")
ck("antispam.banned" in sh, "shield: ban ماندگار ضداسپم")

# ۸) سقف بایت روزانه در مسیرهای آپلود
ck(src.count("antispam.bytes_add") >= 2, "سقف بایت روزانه (پیوست چت + گالری)")

# ۹) v277: سخت‌سازی ورود سیم شده باشد
ck("login_locked" in src, "v277: قفل تأیید (loginlock) سیم شده")
ck("enum_check" in src, "v277: تنوع شماره per-IP سیم شده")
ck(src.count("antispam.strike") >= 3, "v277: strike وب‌هوک هر سه قلاب")

# ۱۰) v278: ضداسپم ثبت/محصول/فراخوان سیم شده باشد
rw = (ROOT / "server" / "register_web.py").read_text(encoding="utf-8")
br = (ROOT / "server" / "bot_register.py").read_text(encoding="utf-8")
raw278 = (ROOT / "server" / "db.py").read_text(encoding="utf-8")
ck("regip:" in rw, "v278: سطل per-IP ویزارد ثبت")
ck("regsub" in br, "v278: cooldown ثبت هم‌هویت")
ck("stockdup" in raw278, "v278: dedup ۲۴ساعتهٔ «خبرم کن»")
ck("item_title_dup" in raw278 and "dup_hold" in src, "v278: عنوان تکراری => نگه‌بررسی")
ck('"neardup"' in rw, "v278: رویداد hold ثبت تقریباً تکراری")

# ۱۱) v279: کنسول اسپم (قانون §78 — UI دیده‌شدنی)
ck('"/panel/spam"' in src, "v279: مسیر GET کنسول اسپم")
ck(src.count('"/panel/spam/') >= 4, "v279: مسیرهای POST کنسول (سیاست/لیفت/بن)")
vp = (ROOT / "server" / "views_panel2.py").read_text(encoding="utf-8")
ck("def admin_spam" in vp, "v279: صفحهٔ کنسول در views")
ab = (ROOT / "server" / "adminbot.py").read_text(encoding="utf-8")
ck("def do_spam" in ab and '"اسپم"' in ab, "v279: دستور «اسپم» بات مدیر")
ck("spam_pol_" in (ROOT / "server" / "antispam.py").read_text(encoding="utf-8"),
   "v279: سیاست زمان‌اجرا")

# ۱۲) v280: پاسخ دوم پس از spam_gate ممنوع (باگ‌کلاس پنتست v280)
_dbl = re.findall(r"self\.spam_gate\([^\n]*\):\n\s+return self\.(?:redirect|json_out|send)\(", src)
ck(not _dbl, "v280: هیچ پاسخ دومی پس از spam_gate فرستاده نمی‌شود (%d مورد)" % len(_dbl))

print("COVERAGE GUARD PASS %d" % n)
