# -*- coding: utf-8 -*-
"""
v293 — گیت فعال‌سازی ربات مدیر بله (فرمان /369).

دستور مدیر: ربات قبل از هر کاری باید با شمارهٔ تلفن تأییدشده و سپس رمزِ
حساس به حروف فعال شود؛ تا فعال‌نشده «هیچ» دستوری اجرا نمی‌شود.

این سوئیت منطق خالص گیت را با متغیرهای محیطیِ آزمون قفل می‌کند
(بدون نیاز به توکن واقعی بله):
  · تا فعال‌نشده، دستورهای عادی قفل‌اند
  · /369 مرحلهٔ شماره را شروع می‌کند
  · شمارهٔ درست/غلط (با نرمال‌سازی ۰۹۱۲/۹۸۹۱۲/فارسی)
  · رمز حساس به حروف
  · پس از فعال‌سازی، دستورهای عادی دوباره راه می‌افتند
  · حالت پایدار در settings می‌ماند (ری‌استارت را زنده می‌ماند)

اجرا (نیاز به سرور زنده ندارد؛ دیتابیس موقت):
    python3 tools/test_bot_gate_v293.py
"""

import os
import sys
import tempfile

TMP = tempfile.mkdtemp(prefix="bz-gate-test-")
os.environ["BZ_DATA_DIR"] = TMP
os.environ["BOT_GATE_PHONE"] = "09137412835"
os.environ["BOT_GATE_PASS"] = "Allahyareman963$"
# گیت فقط روی چت‌های تیم اعمال می‌شود؛ هر دو چت آزمون را عضو تیم می‌کنیم
os.environ["BALE_ADMIN_CHAT"] = "123456789,999"

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
sys.path.insert(0, os.path.join(HERE, "..", "tools"))
import db          # noqa: E402
db.init()
import adminbot    # noqa: E402

G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
ok_n = bad_n = 0
FAILS = []
CHAT = "123456789"


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  {G}✓{X} {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  {R}✗{X} {label}  {detail}")


def head(t):
    print(f"\n{B}── {t}{X}")


print(f"\n{B}\033[36mآزمون گیت فعال‌سازی ربات بله (v293){X}")

head("پیش‌فرض‌ها")
check("گیت مسلح است (شماره در محیط هست)", adminbot.gate_enabled())
check("چت تازه فعال‌نشده است", not adminbot.gate_ok(CHAT))
check("وضعیت اولیه خالی است", adminbot.gate_state(CHAT) == "")

head("شروع با /369")
reply, markup = adminbot.handle_text(1, CHAT, "/369")
check("/369 مرحلهٔ شماره را شروع می‌کند",
      adminbot.gate_state(CHAT) == "phone", f"state={adminbot.gate_state(CHAT)}")
check("کیبورد درخواست شماره رسمی بله فرستاده می‌شود",
      isinstance(markup, dict) and "keyboard" in markup,
      f"markup={markup}")
check("راهنمای شماره داده می‌شود", "شماره" in reply, reply[:60])

head("دستورهای عادی قبل از فعال‌سازی قفل‌اند")
reply, _ = adminbot.handle_text(1, CHAT, "/status")
check("وضعیت قبل از فعال‌سازی اجرا نمی‌شود",
      "فعال نشده" in reply, reply[:60])
reply, _ = adminbot.handle_text(1, CHAT, "اسپم")
check("«اسپم» قبل از فعال‌سازی اجرا نمی‌شود",
      "فعال نشده" in reply, reply[:60])

head("شمارهٔ غلط رد می‌شود")
reply, _ = adminbot.handle_text(1, CHAT, "09121111111")
check("شمارهٔ غلط رد می‌شود", "مطابقت ندارد" in reply, reply[:60])
check("هنوز در مرحلهٔ شماره است", adminbot.gate_state(CHAT) == "phone")

head("شمارهٔ درست (ارقام فارسی) پذیرفته می‌شود")
reply, _ = adminbot.handle_text(1, CHAT, "۰۹۱۳۷۴۱۲۸۳۵")   # ارقام فارسی
check("شمارهٔ فارسی پذیرفته شد", "✅" in reply, reply[:60])
check("به مرحلهٔ رمز رفت", adminbot.gate_state(CHAT) == "pass")

head("رمز حساس به حروف است")
reply, _ = adminbot.handle_text(1, CHAT, "allahyareman963$")
check("رمز با حروف کوچک رد می‌شود", "درست نیست" in reply, reply[:60])
check("هنوز در مرحلهٔ رمز است", adminbot.gate_state(CHAT) == "pass")
reply, _ = adminbot.handle_text(1, CHAT, "Allahyareman963$")
check("رمز درست پذیرفته شد", "🎉" in reply, reply[:60])
check("چت فعال شد", adminbot.gate_ok(CHAT))

head("پس از فعال‌سازی")
st = db.get_settings().get("bot_gate_" + adminbot._gate_id(CHAT))
check("وضعیت در settings ماندگار است", '"ok"' in (st or ""), st)
reply, _ = adminbot.handle_text(1, CHAT, "/369")
check("/369 بعد از فعال‌سازی دیگر گیت نمی‌سازد؛ پاسخ فعال‌سازی می‌دهد",
      adminbot.gate_state(CHAT) == "ok", f"state={adminbot.gate_state(CHAT)}")

head("چتِ دیگر هنوز قفل است")
OTHER = "999"
reply, _ = adminbot.handle_text(1, OTHER, "وضعیت")
check("چت تازه هنوز قفل است", "فعال نشده" in reply, reply[:60])

head("گیت بدون متغیر محیطی = خاموش (سازگاری عقب)")
os.environ["BOT_GATE_PHONE"] = ""
check("gate_enabled خاموش شد", not adminbot.gate_enabled())
check("gate_ok بدون گیت همیشه درست است", adminbot.gate_ok("777"))

print()
import shutil
shutil.rmtree(TMP, ignore_errors=True)
if bad_n:
    print(f"{R}{B}نتیجه: {ok_n} قبول / {bad_n} رد{X}")
    for f in FAILS:
        print(f"  {R}- {f}{X}")
    sys.exit(1)
print(f"{G}{B}نتیجه: همهٔ {ok_n} آزمون سبز شد.{X}")
sys.exit(0)
