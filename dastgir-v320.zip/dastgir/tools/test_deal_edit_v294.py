# -*- coding: utf-8 -*-
"""
v294 — ویرایش فلش‌سیل پس از انتشار (تکمیل حلقهٔ ممیزی پنل).

فلش‌سیل‌ها فقط ساخت+حذف داشتند؛ حالا GET /panel/deal/<id> و
POST (save/toggle) با اعتبارسنجی سمت سرور، هم‌الگو با ویرایش بنر.

  · ساخت سیل + دکمهٔ ویرایش + نشانگر وضعیت هوشمند در لیست
  · صفحهٔ ویرایش پیش‌پرشده
  · ذخیرهٔ ویرایش و اعمال فوری
  · اعتبارسنجی: تاریخ زباله، عنوان خالی، کسب وحشی، مهار درصد
  · سیل ناموجود → 404 صادقانه
  · toggle + delete بدون رگرسیون

اجرا: BZ=http://127.0.0.1:8097 python3 tools/test_deal_edit_v294.py
"""

import os
import sys
import urllib.error
import urllib.parse
import urllib.request
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db      # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
KEY = db.owner_token()
TAG = "آزمون-سیل۲۹۴"

G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  {G}✓{X} {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  {R}✗{X} {label}  {detail}")


def head(t):
    print(f"\n{B}── {t}{X}")


def session():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def get(op, path):
    try:
        res = op.open(BASE + path, timeout=25)
        return res.getcode(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


def post_form(op, path, data):
    body = urllib.parse.urlencode(data, doseq=True).encode()
    r = urllib.request.Request(BASE + path, data=body)
    r.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        res = op.open(r, timeout=25)
        return res.getcode(), res.geturl(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.geturl(), e.read().decode("utf-8", "replace")


def main():
    op = session()
    BID = db.businesses()[0]["id"]
    ENDS_OK = "2031-01-01 23:59:00"

    head("ورود به پنل و ساخت سیل اولیه")
    code, html = get(op, f"/panel/deals?key={urllib.parse.quote(KEY)}")
    check("صفحهٔ سیل‌ها باز می‌شود", code == 200, str(code))

    code, url, _ = post_form(op, "/panel/deal/new", {
        "key": KEY, "title": TAG, "biz_id": str(BID),
        "percent": "25", "ends": ENDS_OK, "descr": "تست اولیه"})
    check("ساخت سیل موفق", "ok=" in url, url)
    rows = db._rows("SELECT * FROM flashdeals WHERE title=?", (TAG,))
    check("سیل در دیتابیس هست", bool(rows))
    if not rows:
        print(f"نتیجه: {ok_n} قبول / {bad_n} رد"); sys.exit(1)
    did = rows[0]["id"]

    head("لیست: دکمهٔ ویرایش + وضعیت هوشمند")
    code, html = get(op, f"/panel/deals?key={urllib.parse.quote(KEY)}")
    check("دکمهٔ ویرایش در لیست", f"/panel/deal/{did}" in html)
    check("دکمهٔ toggle در لیست", html.count(f'action="/panel/deal/{did}"') >= 1)

    head("صفحهٔ ویرایش پیش‌پرشده")
    code, html = get(op, f"/panel/deal/{did}?key={urllib.parse.quote(KEY)}")
    check("صفحهٔ ویرایش ۲۰۰", code == 200, str(code))
    check("عنوان پیش‌پر شده", f'value="{TAG}"' in html)
    check("درصد پیش‌پر شده", 'value="25"' in html)
    check("فرم به مسیر درست پست می‌کند", f'action="/panel/deal/{did}"' in html)

    head("ذخیرهٔ ویرایش")
    code, url, _ = post_form(op, f"/panel/deal/{did}", {
        "key": KEY, "action": "save", "title": TAG + " ویرایش",
        "biz_id": str(BID), "percent": "40", "ends": "2032-05-01 20:30",
        "starts": "2020-01-01 00:00", "descr": "شرح جدید", "active": "1"})
    check("ری‌دایرکت موفقیت", "ok=" in url, url)
    d = db._rows("SELECT * FROM flashdeals WHERE id=?", (did,))[0]
    check("عنوان ذخیره شد", d["title"] == TAG + " ویرایش", d["title"])
    check("درصد ذخیره شد", d["percent"] == 40, str(d["percent"]))
    check("پایان ذخیره شد", d["ends"].startswith("2032-05-01 20:30"), d["ends"])
    check("شروع ذخیره شد", d["starts"].startswith("2020-01-01"), d["starts"])

    head("اعتبارسنجی سمت سرور")
    code, url, _ = post_form(op, f"/panel/deal/{did}", {
        "key": KEY, "action": "save", "title": TAG, "biz_id": str(BID),
        "percent": "20", "ends": "قربون‌صدقه"})
    check("تاریخ پایان زباله → err", "err=" in url, url)
    code, url, _ = post_form(op, f"/panel/deal/{did}", {
        "key": KEY, "action": "save", "title": "", "biz_id": str(BID),
        "percent": "20", "ends": ENDS_OK})
    check("عنوان خالی → err", "err=" in url, url)
    code, url, _ = post_form(op, f"/panel/deal/{did}", {
        "key": KEY, "action": "save", "title": TAG, "biz_id": "999999",
        "percent": "20", "ends": ENDS_OK})
    check("کسب وحشی → err", "err=" in url, url)
    code, url, _ = post_form(op, f"/panel/deal/{did}", {
        "key": KEY, "action": "save", "title": TAG, "biz_id": str(BID),
        "percent": "500", "ends": ENDS_OK})
    d = db._rows("SELECT * FROM flashdeals WHERE id=?", (did,))[0]
    check("درصد ۵۰ به ۹۰ مهار شد", d["percent"] == 90, str(d["percent"]))

    head("toggle و 404 صادقانه")
    a0 = db._rows("SELECT active FROM flashdeals WHERE id=?", (did,))[0]["active"]
    code, url, _ = post_form(op, f"/panel/deal/{did}", {"key": KEY, "action": "toggle"})
    d = db._rows("SELECT * FROM flashdeals WHERE id=?", (did,))[0]
    check("toggle وضعیت را برعکس کرد", d["active"] == (0 if a0 else 1), str(d["active"]))
    code, url, _ = post_form(op, f"/panel/deal/{did}", {"key": KEY, "action": "toggle"})
    d = db._rows("SELECT * FROM flashdeals WHERE id=?", (did,))[0]
    check("toggle برگرداند", d["active"] == a0, str(d["active"]))
    code, html = get(op, f"/panel/deal/999999?key={urllib.parse.quote(KEY)}")
    check("سیل ناموجود → 404", code == 404, str(code))

    head("پاک‌سازی")
    code, url, _ = post_form(op, f"/panel/deal/{did}/delete", {"key": KEY})
    check("حذف قدیمی بدون رگرسیون", "ok=" in url, url)
    check("واقعاً حذف شد", not db._rows("SELECT id FROM flashdeals WHERE id=?", (did,)))

    print()
    if bad_n:
        print(f"{R}{B}نتیجه: {ok_n} قبول / {bad_n} رد{X}")
        for f in FAILS:
            print(f"  {R}- {f}{X}")
        sys.exit(1)
    print(f"{G}{B}نتیجه: همهٔ {ok_n} آزمون سبز شد.{X}")
    sys.exit(0)


main()
