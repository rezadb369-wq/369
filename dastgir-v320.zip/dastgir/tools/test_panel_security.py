# -*- coding: utf-8 -*-
"""
قفل مرحلهٔ م۱ (امنیت پنل) — بازسازی فاز ۵ (۲۰۲۶-۰۸-۳۱)

  • نشت کلید ۱: کلید خام مالک در همهٔ لینک‌های داخلی پنل (۵۸ لینک در
    views_panel/2 + هدر دسکتاپ + ناوبری موبایل + ناوبری کنار پنل) —
    اکنون ورود با کلید فقط «یک‌بار» انجام می‌شود و سشن ۷روزهٔ کوکی‌دار
    می‌سازد؛ ناوبری داخل پنل کاملاً بدون key است.
  • نشت کلید ۲: کلید خام به‌صورت فیلد مخفی در HTML همهٔ فرم‌ها و در
    JSON بوت صفحه‌ها و file_url چت — حذف شد (احراز POST با کوکی سشن).
  • باگ مرگبار میراث: فرم ورود با رمز هرگز key را POST نمی‌کرد ولی
    هندلر token_ok(form) می‌خواست → ورود با رمزِ درست هم همیشه رد
    می‌شد. رفع شد (رمز + سقف ۱۰/۱۵دقیقه کافی است).
  • noindex دوطرفه: متای robots + هدر X-Robots-Tag روی همهٔ /panel.
  • TTL سشن ادمین: ۳۰ روز → ۷ روز.
  • F-010: PBKDF2 از ۱۲۰k به ۶۰۰k + ارتقای شفاف هش‌های قدیمی هنگام
    ورود موفق (rehash-on-login) + چرخش کلید، همهٔ سشن‌ها را می‌کشد.

    BZ=http://127.0.0.1:8080 python3 tools/test_panel_security.py
"""

import os
import sys
import time
import http.cookiejar
import urllib.parse
import urllib.request
import urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db          # noqa: E402
import ui          # noqa: E402
import app as appmod  # noqa: E402  (module import only — no server starts)

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
# The rate-limit table lives in the same SQLite file the server uses; the test
# battery needs to clear it or a correct password starts returning 429.
DB_PATH = os.path.join(os.environ.get("BZ_DATA_DIR", "."), "bazarche.db")

# v297 (دستور مدیر): پنل پشت «نشانی مخفی» است و /panel عادی برای غریبه
# ۴۰۴ می‌دهد. مسیر پنل از محیط خوانده می‌شود تا تست هم با پنل مخفی و
# هم با /panel کلاسیک کار کند.
PANEL = (os.environ.get("PANEL_BASE") or "").strip().rstrip("/") or "/panel"


# v297 (دستور مدیر): با رمز پنل، `admin_ok` کوکی نشست معتبر می‌خواهد و
# «?key=» در URL دیگر پنل را باز نمی‌کند (کلید در URL نشت می‌کند). تست‌ها
# پس اول واقعاً ورود می‌کنند و کوکی می‌گیرند؛ اگر رمزی تعیین نشده باشد،
# همان مسیر قدیمی «?key=» کار می‌کند و چیزی تغییر نمی‌کند.
def panel_login(op):
    """Authenticate `op` against the panel and leave the session cookie in
    its jar. Returns True on success. With no PANEL_PASS set this is a no-op
    and the legacy "?key=" path still works."""
    pw = os.environ.get("PANEL_PASS") or ""
    if not pw:
        return False
    jar = None
    for h in getattr(op, "handlers", []):
        if isinstance(h, urllib.request.HTTPCookieProcessor):
            jar = h.cookiejar
            break
    if jar is None:
        return False

    class _NoRedir(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None

    # The opener must share the caller's jar, otherwise the cookie is minted
    # into a throwaway jar and the caller stays logged out.
    o = urllib.request.build_opener(_NoRedir,
                                    urllib.request.HTTPCookieProcessor(jar))

    # The panel-login limiter is 10 tries per 15 min (app.py: apl:<ip>). A full
    # battery burns through it and every later test then reads 403/429 and
    # looks like a regression. Clear it as part of authenticating.
    try:
        import sqlite3 as _sq
        _con = _sq.connect(DB_PATH)
        _con.execute("DELETE FROM ratelimit")
        _con.commit(); _con.close()
    except Exception:
        pass

    body = urllib.parse.urlencode({"password": pw}).encode()
    req = urllib.request.Request(
        BASE + PANEL + "/login", data=body, method="POST",
        headers={"User-Agent": "bz-test",
                 "Content-Type": "application/x-www-form-urlencoded"})
    try:
        o.open(req, timeout=20)
    except urllib.error.HTTPError as e:
        if e.code not in (302, 303):
            return False
    except Exception:
        return False
    return any(c.name == "bzv2_admin" for c in jar)



ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


class Client:
    """Tiny cookie-carrying browser: never auto-follows redirects."""

    def __init__(self, xff=None, login=False):
        self.xff = xff
        self.jar = http.cookiejar.CookieJar()
        self.op = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.jar),
            urllib.request.HTTPRedirectHandler)
        # v297: این سوئیت عمداً سناریوهای «غریبه/بدون کوکی» را می‌سنجد، پس
        # پیش‌فرض ورود نمی‌کند؛ هر جا نشست واقعی لازم باشد login=True می‌دهد.
        if login:
            panel_login(self.op)

    def get(self, path, follow=True):
        return self._req("GET", path, None, follow)

    def post(self, path, data, follow=True):
        return self._req("POST", path, data, follow)

    def _req(self, method, path, data, follow):
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *a, **k):
                return None
        op = self.op if follow else urllib.request.build_opener(
            NoRedirect, urllib.request.HTTPCookieProcessor(self.jar))
        body = urllib.parse.urlencode(data, doseq=True).encode() if data else None
        h = {"User-Agent": "bz-panel-sec",
             "Content-Type": "application/x-www-form-urlencoded"}
        if self.xff:
            h["X-Forwarded-For"] = self.xff
        r = urllib.request.Request(BASE + path, data=body, method=method,
                                   headers=h)
        try:
            resp = op.open(r, timeout=20)
            return resp.getcode(), resp.read().decode("utf-8", "replace"), dict(resp.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace"), dict(e.headers)
        except Exception as e:
            return 0, str(e), {}

    def cookie(self, name):
        for c in self.jar:
            if c.name == name:
                return c.value
        return None


def main():
    tok = db.owner_token()
    assert tok, "این تست به کلید مالک نیاز دارد (DB دمو)"

    # ---------------------------------------------------------------- §a
    head("م۱-a — ورود تک‌باره با کلید؛ ناوبری بدون key")

    c1 = Client(login=True)
    code, body, hdrs = c1.get(f"{PANEL}?key={urllib.parse.quote(tok)}", follow=False)
    # v297: با نشانی مخفی فعال، ورود با کلید کوکی می‌سازد ولی نشست تازه
    # «قفل» است تا لایهٔ ۲ (رمز مالک) رد شود. پس ۴۰۳ دروازهٔ رمز است، نه خطا.
    check("GET <hidden>?key=… → 303 یا 403 (سشن ساخته شد، کلید در URL رندر نشد)",
          code in (200, 303, 403), f"code={code}")
    # entry minted a session cookie?
    if code == 303:  # follow to the panel itself
        code, body, hdrs = c1.get(PANEL + "")
    check("کوکی سشن ادمین ست شد", bool(c1.cookie("bzv2_admin")))
    # c1 already went through panel_login(), i.e. the owner password. So a 200
    # here is correct. The "key alone is not enough" half of layer 2 is proven
    # separately below on a client that never saw the password.
    check("ورود کامل (کلید + رمز) → 200", code == 200, f"code={code}")

    if db.owner_pass_set():
        # the decisive layer-2 proof: a key-only session must still be locked
        ck = Client()
        codek, _, _ = ck.get(f"{PANEL}?key={urllib.parse.quote(tok)}")
        codek2, _, _ = ck.get(PANEL + "")
        check("نشست کلیددار تا رمز مالک قفل است (لایهٔ ۲)",
              codek2 == 403, f"key={codek} then={codek2}")

    c2 = Client()
    code2, body2, _ = c2.get(PANEL + "")
    check("بدون کلید و بدون کوکی → دروازه (۴۰۳)", code2 == 403, f"code={code2}")

    c3 = Client()
    code3, _, _ = c3.get(PANEL + "?key=definitely-wrong")
    # v297: با نشانی مخفی، کلید غلط ۴۰۴ می‌گیرد — حتی دروازه لو نمی‌رود.
    check("کلید غلط → رد می‌شود (۴۰۳ یا ۴۰۴)", code3 in (403, 404),
          f"code={code3}")

    code4, body4, _ = c1.get(PANEL + "")            # cookie only, no key
    check("داشتن فقط کوکی سشن → 200 (بدون هیچ key)",
          code4 == 200, f"code={code4}")

    raw_in_html = urllib.parse.quote(tok) in body or tok in body4
    check("کلید خام در HTML داشبورد نیست", not raw_in_html)

    def key_leaks(html):
        return ("?key=" in html or "&key=" in html
                or 'name="key"' in html or '"key":' in html)
    check("هیچ لینک ?key= در داشبورد نیست", not key_leaks(body4))
    for page in (PANEL + "/businesses", PANEL + "/reviews", PANEL + "/settings",
                 PANEL + "/customers", PANEL + "/audit"):
        cp, bp, _ = c1.get(page)
        expect = 2 if page == PANEL + "/settings" else 0   # entry-link display (input+copy)
        check(f"{page}: 200 با کوکی و بدون key در HTML",
              cp == 200 and bp.count("?key=") == expect
              and 'name="key"' not in bp, f"code={cp} n={bp.count('?key=')}")
    _, bset, _ = c1.get(PANEL + "/settings")
    check("فرم تنظیمات فیلد مخفی key ندارد",
          'name="key"' not in bset)
    check("تنظیمات: کلید فقط در نمایش عمدی «لینک ورود» (۲ بار) است",
          bset.count(PANEL + "?key=" + tok) == 2
          and bset.count(tok) == 2, f"n={bset.count(tok)}")
    check("تنظیمات «لینک ورود» عمدی را هنوز نشان می‌دهد (فقط برای ادمین)",
          'id="tok"' in bset)

    # POST by cookie alone (no key anywhere in the form)
    code5, _, _ = c1.post(PANEL + "/list/new", {"title": ""}, follow=False)
    check("POST با فقط کوکی → پذیرفته (303 اعتبارسنجی، نه 403)",
          code5 == 303, f"code={code5}")
    c4 = Client()
    code6, _, _ = c4.post(PANEL + "/list/new", {"title": ""}, follow=False)
    # v297 (دستور مدیر): با نشانی مخفی فعال، POST بی‌کوکی ۴۰۴ می‌گیرد نه ۴۰۳ —
    # چون لایهٔ اول حتی وجود پنل را لو نمی‌دهد. هر دو یعنی «رد»، و ۴۰۴ قوی‌تر
    # است. انتظار قبلی فقط ۴۰۳ بود.
    check("POST بدون کوکی و بدون کلید → رد می‌شود (۴۰۳ یا ۴۰۴)",
          code6 in (403, 404), f"code={code6}")

    # ---------------------------------------------------------------- §b
    head("م۱-b — noindex و حذف نشت‌های دیگر")

    _, _, hdrs_p = c1.get(PANEL + "")
    check("هدر X-Robots-Tag: noindex روی /panel",
          "noindex" in (hdrs_p.get("X-Robots-Tag") or ""))
    _, bp2, _ = c1.get(PANEL + "")
    check('متای <meta name="robots" content="noindex"> در HTML پنل',
          'name="robots"' in bp2 and "noindex" in bp2)
    cr = Client()
    _, robots, _ = cr.get("/robots.txt")
    # v297 (دستور مدیر): انتظار قبلی «Disallow: /panel باید باشد» بود. آن خط
    # خودش یک نشت بود — به هر خزنده می‌گفت کنسول مدیریت کجاست. حالا که
    # نشانی مخفی فعال است /panel اصلاً ۴۰۴ می‌دهد، پس Disallow هم لازم نیست
    # و نشانی مخفی هم هرگز در robots نمی‌آید (وگرنه راز لو می‌رود).
    _hid = (os.environ.get("PANEL_BASE") or "").strip().rstrip("/")
    if _hid and _hid != "/panel":
        check("robots.txt نه /panel را لو می‌دهد نه نشانی مخفی را",
              "Disallow: /panel" not in robots and _hid not in robots,
              "robots=" + robots[:120])
    else:
        check("robots.txt همچنان /panel را Disallow می‌کند",
              "Disallow: /panel" in robots)
    check("JSON بوت صفحه توکن ادمین را ندارد",
          '"token"' not in bp2)

    import inspect
    hdr_src = inspect.getsource(ui.header)
    check("هدر دسکتاپ: دکمهٔ پنل بدون key", "panel?key" not in hdr_src)
    ppage_src = inspect.getsource(ui.panel_page)
    check("ناوبری کنار پنل بدون key", "key=" not in ppage_src)

    # ---------------------------------------------------------------- §c
    head("م۱-c — سشن ۷روزه، خروج، چرخش کلید")

    check("ADMIN_SESSION_TTL = ۷ روز",
          db.ADMIN_SESSION_TTL == 7 * 86400, f"ttl={db.ADMIN_SESSION_TTL}")
    st = db.admin_session_new()
    check("سشن تازه معتبر است", db.admin_session_ok(st))
    con = db.connect()
    con.execute("UPDATE admin_sessions SET expires=? WHERE token=?",
                (time.time() - 10, st))
    con.commit(); con.close()
    check("سشن منقضی رد می‌شود", not db.admin_session_ok(st))
    con = db.connect()
    con.execute("DELETE FROM admin_sessions WHERE token=?", (st,))
    con.commit(); con.close()

    c5 = Client(login=True)
    c5.get(f"{PANEL}?key={urllib.parse.quote(tok)}")
    c5.post(PANEL + "/logout", {}, follow=False)
    code7, _, _ = c5.get(PANEL + "")
    check("خروج → سشن مرده و پنل قفل (403)", code7 == 403, f"code={code7}")

    old_tok = db.get_settings().get("owner_token")
    try:
        db.rotate_owner_token()
        con = db.connect()
        n = con.execute("SELECT COUNT(*) c FROM admin_sessions").fetchone()["c"]
        con.close()
        check("چرخش کلید → همهٔ سشن‌های ادمین کشته شدند", n == 0, f"n={n}")
    finally:
        db.set_setting("owner_token", old_tok)

    # ---------------------------------------------------------------- §d
    head("م۱-d — رمز پنل و PBKDF2 600k (F-010)")

    check("PBKDF2_ITERS = 600,000", db.PBKDF2_ITERS == 600_000,
          f"iters={db.PBKDF2_ITERS}")

    old_hash = (db.get_settings().get("owner_pass_hash") or "")
    old_sess = []
    try:
        db.set_owner_pass("S3cret-Panel-Pass")
        h = db.get_settings().get("owner_pass_hash") or ""
        check("هش تازه با ۶۰۰هزار تکرار ساخته می‌شود",
              h.startswith("pbkdf2$600000$"), h[:24])
        check("هش هرگز در HTML پنل ظاهر نمی‌شود", h[:20] not in bp2)

        # legacy 120k hash still verifies + is transparently upgraded
        import hashlib
        salt = "abcd1234abcd1234"
        dk = hashlib.pbkdf2_hmac("sha256", b"legacy-pw", bytes.fromhex(salt),
                                 120_000)
        db.set_setting("owner_pass_hash",
                       f"pbkdf2$120000${salt}${dk.hex()}")
        check("هش قدیمی ۱۲۰k هنوز وارسی می‌شود",
              db.check_owner_pass("legacy-pw"))
        up = db.get_settings().get("owner_pass_hash") or ""
        check("وارسی موفق → ارتقای خودکار به ۶۰۰k",
              up.startswith("pbkdf2$600000$"), up[:24])
        check("رمز غلط رد می‌شود", not db.check_owner_pass("wrong"))

        # live two-step flow: key → password gate → login POST → cookie
        db.set_owner_pass("S3cret-Panel-Pass")
        c6 = Client(login=True)
        r6, b6, _ = c6.get(f"{PANEL}?key={urllib.parse.quote(tok)}", follow=False)
        if r6 == 303:
            r6, b6, _ = c6.get(PANEL + "")
        check("با رمزِ تعیین‌شده: GET پنل → 403 دروازهٔ رمز", r6 == 403,
              f"code={r6}")
        check("دروازهٔ رمز فرم ورود دارد", 'name="password"' in b6)
        c6 = Client(xff="10.77.7.6")   # fresh rate bucket for this section
        r7, _, _ = c6.post(PANEL + "/login", {"password": "wrong-pass"},
                           follow=False)
        check("رمز غلط → 403", r7 == 403, f"code={r7}")
        r8, _, _ = c6.post(PANEL + "/login", {"password": "S3cret-Panel-Pass"},
                           follow=False)
        check("رمز درست → 303 + کوکی (باگ مرگبار v116 رفع شد)",
              r8 == 303 and bool(c6.cookie("bzv2_admin")), f"code={r8}")
        r9, b9, _ = c6.get(PANEL + "")
        check("بعد از ورود رمز: پنل با کوکی باز است", r9 == 200, f"code={r9}")

        # CRITICAL (v117/M1 tiering): a key-only (locked) session must keep
        # facing the password gate — the key alone can never satisfy the
        # second factor, even on the second request with its cookie set.
        c8 = Client(xff="10.77.7.8")
        c8.get(f"{PANEL}?key={urllib.parse.quote(tok)}", follow=False)
        r10, b10, _ = c8.get(PANEL + "")     # now carries the locked cookie
        check("سشنِ فقط-کلیدی (locked) همچنان دروازهٔ رمز می‌گیرد (۴۰۳)",
              r10 == 403 and "رمز عبور" in b10, f"code={r10}")
        r11, _, _ = c8.post(PANEL + "/list/new", {"title": "x"}, follow=False)
        check("سشنِ فقط-کلیدی اجازهٔ POST ندارد (۴۰۳)",
              r11 == 403, f"code={r11}")

        c7 = Client(xff="10.77.7.7")
        last = 0
        for _ in range(11):
            last, _, _ = c7.post(PANEL + "/login", {"password": "nope"},
                                 follow=False)
            if last == 429:
                break
        check("۱۱ تلاش رمز غلط → قفل نرخ 429", last == 429, f"code={last}")
    finally:
        db.set_setting("owner_pass_hash", old_hash)
        con = db.connect()
        con.execute("DELETE FROM admin_sessions")
        con.commit(); con.close()

    # ---------------------------------------------------------------- ⨯
    print(f"\n\033[1m{ok_n} passed, {bad_n} failed\033[0m")
    if FAILS:
        print("\n".join("  ✗ " + f for f in FAILS))
        sys.exit(1)


if __name__ == "__main__":
    main()
