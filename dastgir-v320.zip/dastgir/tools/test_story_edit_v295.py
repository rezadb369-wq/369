# -*- coding: utf-8 -*-
"""
v295 — ویرایش/تمدید استوری پس از انتشار (تکمیل حلقهٔ ممیزی پنل).

استوری‌ها فقط «حذف» داشتند؛ حالا: لیست هوشمند (فعال/منقضی + ساعت مانده)،
صفحهٔ ویرایش کپشن، تمدید ۲۴ ساعته، آمار دیده‌شدن، ۴۰۴ صادقانه.

اجرا: BZ=http://127.0.0.1:8097 python3 tools/test_story_edit_v295.py
"""

import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db      # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
KEY = db.owner_token()
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  {G}✓{X} {label}")
    else:
        bad_n += 1
        FAILS.append(label)
        print(f"  {R}✗{X} {label}  {detail}")


def head(t):
    print(f"\n{B}── {t}{X}")


def session():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def get(op, path):
    try:
        res = op.open(BASE + path, timeout=25)
        return res.getcode(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


def post_form(op, path, data):
    body = urllib.parse.urlencode(data, doseq=True).encode()
    r = urllib.request.Request(BASE + path, data=body)
    r.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        res = op.open(r, timeout=25)
        return res.getcode(), res.geturl(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.geturl(), e.read().decode("utf-8", "replace")


op = session()
BID = db.businesses()[0]["id"]

head("ساخت استوری آزمایشی مستقیم در DB")
db._run("INSERT INTO stories(biz_id,image,kind,caption,expires) VALUES(?,?,?,?,?)",
        (BID, "/media/test-story.png", "image", "کپشن اولیه", time.time() + 3600))
sid = db._rows("SELECT id FROM stories ORDER BY id DESC LIMIT 1")[0]["id"]

head("لیست: وضعیت هوشمند + دکمه‌ها")
code, html = get(op, f"/panel/stories?key={urllib.parse.quote(KEY)}")
check("صفحهٔ استوری‌ها ۲۰۰", code == 200, str(code))
check("لینک ویرایش در لیست", f"/panel/story/{sid}" in html)
check("نشان فعال + ساعت مانده", "فعال" in html and "ساعت مانده" in html)
check("دکمهٔ تمدید در لیست", "تمدید ۲۴ساعت" in html)

head("صفحهٔ ویرایش پیش‌پرشده")
code, html = get(op, f"/panel/story/{sid}?key={urllib.parse.quote(KEY)}")
check("ویرایش ۲۰۰", code == 200, str(code))
check("کپشن پیش‌پر شده", "کپشن اولیه" in html)
check("آمار دیده‌شدن", "دیده‌شدن کل" in html)

head("ذخیرهٔ کپشن")
code, url, _ = post_form(op, f"/panel/story/{sid}", {
    "key": KEY, "action": "save", "caption": "کپشن ویرایش‌شدهٔ v295"})
check("ری‌دایرکت موفقیت", "ok=" in url, url)
cap = db._rows("SELECT caption FROM stories WHERE id=?", (sid,))[0]["caption"]
check("کپشن ذخیره شد", cap == "کپشن ویرایش‌شدهٔ v295", cap)

head("تمدید ۲۴ ساعته")
e0 = db._rows("SELECT expires FROM stories WHERE id=?", (sid,))[0]["expires"]
code, url, _ = post_form(op, f"/panel/story/{sid}", {"key": KEY, "action": "extend"})
check("ری‌دایرکت تمدید", "ok=" in url, url)
e1 = db._rows("SELECT expires FROM stories WHERE id=?", (sid,))[0]["expires"]
check("۲۴ ساعت اضافه شد", 86000 < (e1 - e0) < 87000, str(e1 - e0))

head("استوری منقضی در لیست")
db._run("UPDATE stories SET expires=? WHERE id=?", (time.time() - 100, sid))
code, html = get(op, f"/panel/stories?key={urllib.parse.quote(KEY)}")
check("نشان منقضی", "منقضی" in html)
db._run("UPDATE stories SET expires=? WHERE id=?", (time.time() + 3600, sid))

head("۴۰۴ صادقانه و حذف")
code, html = get(op, f"/panel/story/999999?key={urllib.parse.quote(KEY)}")
check("ناموجود → ۴۰۴", code == 404, str(code))
code, url, _ = post_form(op, f"/panel/story/{sid}/delete", {"key": KEY})
check("حذف بدون رگرسیون", "ok=" in url, url)
check("واقعاً حذف شد", not db._rows("SELECT id FROM stories WHERE id=?", (sid,)))

print()
if bad_n:
    print(f"{R}{B}نتیجه: {ok_n} قبول / {bad_n} رد{X}")
    for f in FAILS:
        print(f"  {R}- {f}{X}")
    sys.exit(1)
print(f"{G}{B}نتیجه: همهٔ {ok_n} آزمون سبز شد.{X}")
sys.exit(0)
