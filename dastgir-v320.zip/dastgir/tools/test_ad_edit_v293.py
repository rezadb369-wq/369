# -*- coding: utf-8 -*-
"""
v293 — ویرایش بنر تبلیغاتی پس از انتشار (رفع باگ «ویرایش بعد از اجرا نیست»).

ریشهٔ باگ: هندلر POST /panel/ad/<id> فقط delete/reset/toggle داشت و نمای
ویرایش وجود نداشت؛ با آنکه db.save_ad(data, aid) از قبل ویرایش را ساپورت
می‌کرد. این سوئیت جریان کامل را روی سرور زنده قفل می‌کند:

  · ساخت بنر (multipart) و دیده‌شدن دکمهٔ ویرایش در لیست
  · صفحهٔ ویرایش با فرم پیش‌پرشده
  · ذخیرهٔ ویرایش (عنوان/متن/لینک/جایگاه/وزن/تاریخ/وضعیت) با حفظ تصویر
  · بنر ناموجود → پیام صادقانه (جعل «ذخیره شد» ممنوع — هم‌الگوی ویرایش‌ها)
  · نشانگر وضعیت هوشمند: فعال / منقضی‌شده / زمان‌بندی‌شده
  · عملیات قدیمی (حذف/صفر/فعال‌سازی) بدون رگرسیون

اجرا: سرور زنده روی پورت مشخص + دیتابیس مشترک
    BZ=http://127.0.0.1:8097 python3 tools/test_ad_edit_v293.py
"""

import datetime
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db      # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
KEY = db.owner_token()
TAG = "آزمون-بنر۲۹۳"

G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
ok_n = bad_n = 0
FAILS = []
CREATED = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  {G}✓{X} {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  {R}✗{X} {label}  {detail}")


def head(t):
    print(f"\n{B}── {t}{X}")


def session():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def get(op, path):
    try:
        res = op.open(BASE + path, timeout=25)
        return res.getcode(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


def post_form(op, path, data):
    body = urllib.parse.urlencode(data, doseq=True).encode()
    r = urllib.request.Request(BASE + path, data=body)
    r.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        res = op.open(r, timeout=25)
        return res.getcode(), res.geturl(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.geturl(), e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, "", str(e)


def post_multipart(op, path, fields):
    """fields: list of (name, value). No file parts needed for these tests."""
    boundary = "----v293testboundary"
    parts = []
    for name, value in fields:
        parts.append(("--%s\r\n" % boundary).encode())
        parts.append(('Content-Disposition: form-data; name="%s"\r\n\r\n' % name).encode())
        parts.append(str(value).encode("utf-8"))
        parts.append(b"\r\n")
    parts.append(("--%s--\r\n" % boundary).encode())
    body = b"".join(parts)
    r = urllib.request.Request(BASE + path, data=body)
    r.add_header("Content-Type", "multipart/form-data; boundary=" + boundary)
    try:
        res = op.open(r, timeout=25)
        return res.getcode(), res.geturl(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.geturl(), e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, "", str(e)


def cleanup():
    for aid in CREATED:
        try:
            a = db.ad(aid)
            if a:
                db.delete_ad(aid)
        except Exception:
            pass


print(f"\n{B}\033[36mآزمون ویرایش بنر تبلیغاتی (v293) — {BASE}{X}")

head("آماده‌سازی")
db.rate_clear()

today = datetime.date.today()
iso_today = today.isoformat()
iso_yesterday = (today - datetime.timedelta(days=1)).isoformat()
iso_tomorrow = (today + datetime.timedelta(days=1)).isoformat()

op = session()

# mint the admin session cookie exactly like a browser entering the panel
code, html = get(op, f"/panel/ads?key={urllib.parse.quote(KEY)}")
check("ورود به پنل (کوکی نشست مدیر صادر شد)", code == 200, f"code={code}")

head("ساخت بنر (مسیر موجود)")
code, url, _ = post_multipart(op, "/panel/ad/new", [
    ("key", KEY), ("title", TAG), ("body", "متن اولیه"),
    ("url", "/b/test"), ("slot", "home"), ("biz_id", ""),
    ("starts", ""), ("ends", ""), ("weight", "3"), ("active", "on"),
])
check("ساخت بنر → ریدایرکت موفق", code == 200 and "ok=" in url,
      f"code={code} url={url}")
aid = 0
for a in db.ads():
    if a["title"] == TAG:
        aid = a["id"]
CREATED.append(aid)
check("بنر در دیتابیس ساخته شد", aid > 0, "db.ads خالی است")

head("دکمهٔ ویرایش در لیست")
code, html = get(op, "/panel/ads")
check("لیست بنرها باز می‌شود", code == 200, f"code={code}")
check("لینک ویرایش بنر در لیست هست",
      f'/panel/ad/{aid}"' in html and "ویرایش" in html, "لینک پیدا نشد")

head("صفحهٔ ویرایش")
code, html = get(op, f"/panel/ad/{aid}")
check("صفحهٔ ویرایش ۲۰۰ می‌دهد", code == 200, f"code={code}")
check("فرم پیش‌پرشده عنوان را دارد", TAG in html, "عنوان در فرم نیست")
check("اکشن فرم روی همان شناسه است",
      f'action="/panel/ad/{aid}"' in html, "اکشن فرم غلط است")
check("فیلد مخفی action=save هست", 'name="action" value="save"' in html,
      "فیلد مخفی نیست")

head("ذخیرهٔ ویرایش")
code, url, _ = post_multipart(op, f"/panel/ad/{aid}", [
    ("key", KEY), ("action", "save"), ("title", TAG + " ویرایش‌شده"),
    ("body", "متن تازه"), ("url", "/b/new-dest"), ("slot", "sidebar"),
    ("biz_id", ""), ("starts", iso_today), ("ends", iso_tomorrow),
    ("weight", "7"), ("active", "on"),
])
check("ذخیرهٔ ویرایش → ریدایرکت موفق",
      code == 200 and "ok=" in url and "/panel/ads" in url,
      f"code={code} url={url}")
a = db.ad(aid)
check("عنوان به‌روز شد", (a or {}).get("title") == TAG + " ویرایش‌شده",
      f"got={a.get('title') if a else None}")
check("جایگاه به‌روز شد", (a or {}).get("slot") == "sidebar",
      f"got={a.get('slot') if a else None}")
check("وزن به‌روز شد و در بازه ماند", (a or {}).get("weight") == 7,
      f"got={a.get('weight') if a else None}")
check("تاریخ شروع/پایان ذخیره شد",
      (a or {}).get("starts") == iso_today and (a or {}).get("ends") == iso_tomorrow,
      f"starts={a.get('starts') if a else None} ends={a.get('ends') if a else None}")

head("وزن خارج از بازه مهار می‌شود")
code, url, _ = post_multipart(op, f"/panel/ad/{aid}", [
    ("key", KEY), ("action", "save"), ("title", TAG + " ویرایش‌شده"),
    ("body", ""), ("url", ""), ("slot", "sidebar"), ("biz_id", ""),
    ("starts", ""), ("ends", ""), ("weight", "999"), ("active", "on"),
])
a = db.ad(aid)
check("وزن ۹۹۹ به سقف ۱۰ مهار شد", (a or {}).get("weight") == 10,
      f"got={a.get('weight') if a else None}")

head("بنر ناموجود جعل نمی‌شود")
code, url, _ = post_multipart(op, "/panel/ad/999999999", [
    ("key", KEY), ("action", "save"), ("title", "هکی"),
])
check("ذخیره روی شناسهٔ ناموجود رد شد",
      "err=" in url and "بنری با این شناسه نیست" in urllib.parse.unquote(url),
      f"url={url}")

head("نشانگر وضعیت هوشمند")
# منقضی‌شده
db.save_ad(dict(a, starts="", ends=iso_yesterday), aid)
code, html = get(op, "/panel/ads")
row = html.split(f'/panel/ad/{aid}"')[0].rsplit("<tr", 1)[-1] + \
      html.split(f'/panel/ad/{aid}"', 1)[1].split("</tr>")[0]
check("بنر گذشته «منقضی‌شده» نشان می‌دهد", "منقضی‌شده" in row, "badge پیدا نشد")
# زمان‌بندی‌شده
db.save_ad(dict(a, starts=iso_tomorrow, ends=""), aid)
code, html = get(op, "/panel/ads")
row = html.split(f'/panel/ad/{aid}"')[0].rsplit("<tr", 1)[-1] + \
      html.split(f'/panel/ad/{aid}"', 1)[1].split("</tr>")[0]
check("بنر آینده «زمان‌بندی‌شده» نشان می‌دهد", "زمان‌بندی‌شده" in row,
      "badge پیدا نشد")
# غیرفعال
db.save_ad(dict(a, active=0, starts="", ends=""), aid)
code, html = get(op, "/panel/ads")
row = html.split(f'/panel/ad/{aid}"')[0].rsplit("<tr", 1)[-1] + \
      html.split(f'/panel/ad/{aid}"', 1)[1].split("</tr>")[0]
check("بنر غیرفعال «غیرفعال» نشان می‌دهد", "غیرفعال" in row, "badge پیدا نشد")
db.save_ad(dict(a, active=1, starts="", ends=""), aid)

head("بدون نشست مدیر → ۴۰۳")
anon = session()
code, url, body = post_multipart(anon, f"/panel/ad/{aid}", [
    ("action", "save"), ("title", "نفوذ"),
])
check("ویرایش بدون احراز ۴۰۳ است", code == 403, f"code={code}")

head("عملیات قدیمی (رگرسیون)")
code, url, _ = post_form(op, f"/panel/ad/{aid}", {"key": KEY, "action": "toggle"})
a = db.ad(aid)
check("toggle هنوز کار می‌کند", (a or {}).get("active") == 0,
      f"active={a.get('active') if a else None}")
code, url, _ = post_form(op, f"/panel/ad/{aid}", {"key": KEY, "action": "reset"})
a = db.ad(aid)
check("آمار صفر می‌شود", (a or {}).get("views") == 0 and (a or {}).get("clicks") == 0,
      f"views={a.get('views') if a else None}")
code, url, _ = post_form(op, f"/panel/ad/{aid}", {"key": KEY, "action": "delete"})
check("حذف → ریدایرکت موفق", "ok=" in url, f"url={url}")
check("بنر واقعاً حذف شد", db.ad(aid) is None, "هنوز هست")
CREATED.remove(aid)

head("پاک‌سازی")
cleanup()
check("پاک‌سازی انجام شد", True)

print()
if bad_n:
    print(f"{R}{B}نتیجه: {ok_n} قبول / {bad_n} رد{X}")
    for f in FAILS:
        print(f"  {R}- {f}{X}")
    sys.exit(1)
print(f"{G}{B}نتیجه: همهٔ {ok_n} آزمون سبز شد.{X}")
sys.exit(0)
