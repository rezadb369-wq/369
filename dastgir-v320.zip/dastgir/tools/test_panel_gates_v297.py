#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v297: سه لایهٔ امنیت پنل + نشت‌نکردن وجود پنل.

ریشهٔ باگی که اینجا پین می‌شود (FINDINGS-v296 F4/F5 + باگ بحرانی ورود):
`do_GET` نشانی مخفی را به `/panel` بازنویسی می‌کرد ولی `route_post` نه.
نتیجه: با نشانی مخفی فعال، فرم ورود به مسیری POST می‌شد که هیچ هندلری
نمی‌شناخت ⇒ **هیچ راهی برای ورود به پنل نبود**. سه لایه پیاده شده بود
ولی غیرقابل استفاده. این تست همان حلقه را می‌بندد.

نیاز به سرور زنده:  BZ=<url>  (پیش‌فرض http://127.0.0.1:8080)
اجرا:  BZ=http://127.0.0.1:8080 python3 tools/test_panel_gates_v297.py
"""
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

BZ = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
HIDDEN = (os.environ.get("PANEL_HIDDEN_PATH") or "").strip()
PASS = os.environ.get("PANEL_PASS") or ""
CHECKS = []


def check(name, cond, extra=""):
    CHECKS.append((name, bool(cond), extra))


def _opener():
    """An opener that does NOT follow redirects — a login that answers 303 and
    points at a 404 would otherwise look like a plain 404 and hide the bug."""
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None
    return urllib.request.build_opener(NoRedirect)


OPENER = _opener()


def get(path, jar=None):
    req = urllib.request.Request(BZ + path, headers={"User-Agent": "gate-test"})
    if jar:
        req.add_header("Cookie", jar)
    try:
        r = OPENER.open(req, timeout=10)
        return r.status, r.read().decode("utf-8", "replace"), r.headers
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.headers


def post(path, data, jar=None):
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(BZ + path, data=body,
                                headers={"User-Agent": "gate-test",
                                         "Content-Type": "application/x-www-form-urlencoded"})
    if jar:
        req.add_header("Cookie", jar)
    try:
        r = OPENER.open(req, timeout=10)
        return r.status, r.read().decode("utf-8", "replace"), r.headers
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.headers


def cookie_jar(hdrs):
    out = []
    for k, v in hdrs.items():
        if k.lower() == "set-cookie":
            out.append(v.split(";")[0])
    return "; ".join(out)


def test_stranger_sees_nothing():
    """F4/F5: a stranger must not learn an admin console exists."""
    code, body, _ = get("/panel")
    check("غریبه → /panel = ۴۰۴", code == 404, "کد %s" % code)
    check("«پنل مدیریت» در پاسخ /panel نیست", "پنل مدیریت" not in body)
    check("«دسترسی محدود» در پاسخ /panel نیست", "دسترسی محدود" not in body)

    for sub in ("/panel/ads", "/panel/settings", "/panel/orders", "/panel/security"):
        c, _b, _h = get(sub)
        check("غریبه → %s = ۴۰۴" % sub, c == 404, "کد %s" % c)

    code, robots, _ = get("/robots.txt")
    check("robots.txt بارگذاری شد", code == 200, "کد %s" % code)
    check("robots.txt مسیر /panel را لو نمی‌دهد", "/panel" not in robots,
          "خط Disallow: /panel هنوز هست")
    if HIDDEN:
        check("robots.txt نشانی مخفی را لو نمی‌دهد", HIDDEN not in robots)


def test_hidden_path_layers():
    if not HIDDEN:
        check("نشانی مخفی برای تست داده شده", False, "PANEL_HIDDEN_PATH خالی است")
        return
    code, body, _ = get("/" + HIDDEN)
    check("نشانی مخفی بدون کلید = ۴۰۳ (فرم ورود)", code == 403, "کد %s" % code)

    if not PASS:
        check("رمز پنل برای تست داده شده", False, "PANEL_PASS خالی است")
        return

    # --- layer 2: wrong password must not open anything
    c, b, h = post("/" + HIDDEN + "/login", {"password": "definitely-wrong-" + PASS})
    check("رمز غلط رد می‌شود", c in (403, 429), "کد %s" % c)
    check("رمز غلط ریدایرکت نمی‌دهد", h.get("Location") in (None, ""),
          str(h.get("Location")))

    # --- layer 2: the correct password must work. This is the regression:
    # before v297 the hidden address posted to a path no handler knew, so a
    # correct password still returned 403 and the console was unreachable.
    c, b, h = post("/" + HIDDEN + "/login", {"password": PASS})
    loc = h.get("Location") or ""
    check("رمز درست پذیرفته می‌شود (رگرسیون v297)", c in (302, 303),
          "کد %s — اگر ۴۰۳ است، route_post نشانی مخفی را بازنویسی نمی‌کند" % c)
    # The redirect target must be the hidden address, not /panel — /panel
    # answers 404 once the hidden path is armed, so redirecting there dumped
    # a freshly-authenticated admin onto a 404.
    check("ریدایرکت به نشانی مخفی می‌رود نه /panel",
          loc.startswith("/" + HIDDEN), "Location=%r" % loc)
    jar = cookie_jar(h)
    check("کوکی نشست صادر شد", bool(jar), "هیچ Set-Cookie نبود")

    if jar:
        c, b, _h = get("/" + HIDDEN, jar)
        check("با نشست، پنل باز می‌شود", c == 200, "کد %s" % c)
        for sub in ("/ads", "/settings", "/orders", "/stories"):
            c, _b, _h = get("/" + HIDDEN + sub, jar)
            check("با نشست، %s باز است" % sub, c == 200, "کد %s" % c)
        # a real panel POST must also route through the hidden address
        c, _b, h2 = post("/" + HIDDEN + "/security", {}, jar)
        check("POST پنل از نشانی مخفی مسیر می‌گیرد", c in (302, 303),
              "کد %s" % c)


def main():
    test_stranger_sees_nothing()
    test_hidden_path_layers()
    bad = [n for n, ok, _ in CHECKS if not ok]
    print("=" * 62)
    print("آزمون لایه‌های امنیت پنل v297 — %d بررسی، %d سبز، %d قرمز"
          % (len(CHECKS), len(CHECKS) - len(bad), len(bad)))
    print("=" * 62)
    for n, ok, extra in CHECKS:
        print(("  ✅ " if ok else "  ❌ ") + n + (("  ← " + str(extra)) if (extra and not ok) else ""))
    if bad:
        print("\n❌ ناموفق:", ", ".join(bad))
        return 1
    print("\n✅ همهٔ بررسی‌ها سبز")
    return 0


if __name__ == "__main__":
    sys.exit(main())
