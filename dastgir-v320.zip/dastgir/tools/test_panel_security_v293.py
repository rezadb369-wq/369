# -*- coding: utf-8 -*-
"""
v293 — امنیت سه‌لایه‌ای ورود به پنل.

  لایهٔ اول  · نشانی مخفی: وقتی فعال است /panel برای غریبه‌ها ۴۰۴ است و
               کنسول فقط از نشانی تصادفی باز می‌شود.
  لایهٔ دوم  · کلید + رمز عبور (از قبل موجود).
  لایهٔ سوم  · تأیید یک‌بارمصرف از ربات بله پس از رمز درست.

این سوئیت بخش‌های قابل‌آزمونِ بدون توکن واقعی بله را قفل می‌کند:
  · منطق چالِنج تأیید در دیتابیس (ساخت/وضعیت/تصمیم/انقضا)
  · باز شدن نشست قفل‌شده با admin_session_unlock
  · رفتار نشانی مخفی روی سرور زنده (۴۰۴ برای غریبه، باز برای کلیددار)

اجرا: سرور زنده + دیتابیس مشترک
    BZ=http://127.0.0.1:8097 python3 tools/test_panel_security_v293.py
"""

import os
import sys
import urllib.error
import urllib.parse
import urllib.request
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db      # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
KEY = db.owner_token()

G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  {G}✓{X} {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  {R}✗{X} {label}  {detail}")


def head(t):
    print(f"\n{B}── {t}{X}")


def session():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def get(op, path):
    try:
        res = op.open(BASE + path, timeout=25)
        return res.getcode(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


print(f"\n{B}\033[36mآزمون امنیت سه‌لایه‌ای پنل (v293) — {BASE}{X}")

# =====================================================================
head("لایهٔ سوم — منطق چالِنج تأیید در دیتابیس")
tok = db.admin_session_new(locked=True)
check("نشست قفل‌شده ساخته شد", db.admin_session_ok(tok))
check("نشست قفل‌شده در حالت unlocked رد می‌شود",
      not db.admin_session_ok(tok, unlocked_only=True))

code = db.panel_approval_new(tok, "1.2.3.4")
check("کد چالِنج ۶رقمی است", len(code) == 6 and code.isdigit(), f"code={code}")
check("وضعیت اولیه «در انتظار» است", db.panel_approval_status(tok) == "pending")

check("تصمیم با کد غلط رد می‌شود",
      not db.panel_approval_decide("000000" if code != "000000" else "111111", True))
check("وضعیت هنوز «در انتظار» است", db.panel_approval_status(tok) == "pending")
check("تصمیم با کد درست پذیرفته می‌شود", db.panel_approval_decide(code, True))
check("وضعیت «تأیید شد»", db.panel_approval_status(tok) == "approved")
check("تصمیم دوباره روی چالِنج مصرف‌شده رد می‌شود",
      not db.panel_approval_decide(code, True))

db.admin_session_unlock(tok)
check("نشست پس از تأیید باز شد", db.admin_session_ok(tok, unlocked_only=True))
db.admin_session_kill(tok)

# رد کردن
tok2 = db.admin_session_new(locked=True)
code2 = db.panel_approval_new(tok2)
check("تصمیم «رد» پذیرفته می‌شود", db.panel_approval_decide(code2, False))
check("وضعیت «رد شد»", db.panel_approval_status(tok2) == "rejected")
db.admin_session_kill(tok2)

# =====================================================================
head("لایهٔ اول — نشانی مخفی (روی سرور زنده)")
saved_hidden = db.get_settings().get("panel_hidden_path", "")
HIDDEN = "x-" + "a1b2c3d4e5f6g7h8i9j0"   # نشانی تصادفی‌مانندِ آزمون

try:
    db.set_settings({"panel_hidden_path": ""})
    anon = session()
    code_, _ = get(anon, "/panel")
    check("بدون نشانی مخفی: /panel صفحهٔ دسترسی می‌دهد", code_ in (200, 403),
          f"code={code_}")

    db.set_settings({"panel_hidden_path": HIDDEN})
    anon = session()
    code_, body = get(anon, "/panel")
    check("با نشانی مخفی: /panel برای غریبه ۴۰۴ است", code_ == 404,
          f"code={code_}")
    code_, _ = get(anon, "/panel/settings")
    check("زیرمسیر /panel هم ۴۰۴ است", code_ == 404, f"code={code_}")

    # غریبه با کلید هم نباید از /panel لو بَرود (کوکی نشست هنوز در درخواست نیست)
    anon2 = session()
    code_, _ = get(anon2, "/panel?key=" + urllib.parse.quote(KEY))
    check("/panel با کلید هم برای بار اول ۴۰۴ می‌ماند (پنهان)",
          code_ == 404, f"code={code_}")

    # ورود از نشانی مخفی با کلید → پنل باز می‌شود
    own = session()
    code_, body = get(own, f"/{HIDDEN}?key=" + urllib.parse.quote(KEY))
    # ممکن است پنل یا دروازهٔ رمز باشد (بسته به داشتن رمز)؛ نباید ۴۰۴ باشد
    check("نشانی مخفی با کلید، غریبه‌نما نیست (۴۰۴ نمی‌دهد)",
          code_ in (200, 403), f"code={code_}")
    # حالا که نشست دارد، /panel عادی هم باز می‌شود
    code_, _ = get(own, "/panel")
    check("پس از ورود، /panel با نشست باز می‌شود", code_ in (200, 403),
          f"code={code_}")

    # زیرمسیر از راه مخفی
    code_, _ = get(own, f"/{HIDDEN}/settings")
    check("زیرمسیر از راه نشانی مخفی باز می‌شود", code_ in (200, 403),
          f"code={code_}")
finally:
    db.set_settings({"panel_hidden_path": saved_hidden})

print()
if bad_n:
    print(f"{R}{B}نتیجه: {ok_n} قبول / {bad_n} رد{X}")
    for f in FAILS:
        print(f"  {R}- {f}{X}")
    sys.exit(1)
print(f"{G}{B}نتیجه: همهٔ {ok_n} آزمون سبز شد.{X}")
sys.exit(0)
