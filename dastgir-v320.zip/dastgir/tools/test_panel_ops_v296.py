# -*- coding: utf-8 -*-
"""
v296 — عملیات پنل: جزئیات سفارش + فیلتر/جستجو/خروجی سه لیست پرمصرف.

اجرا: BZ=http://127.0.0.1:8097 python3 tools/test_panel_ops_v296.py
"""

import os
import sys
import urllib.error
import urllib.parse
import urllib.request
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db      # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")

# v297 (دستور مدیر): پنل پشت «نشانی مخفی» است و /panel عادی برای غریبه
# ۴۰۴ می‌دهد. مسیر پنل از محیط خوانده می‌شود تا تست هم با پنل مخفی و
# هم با /panel کلاسیک کار کند.
PANEL = (os.environ.get("PANEL_BASE") or "").strip().rstrip("/") or "/panel"


# v297 (دستور مدیر): با رمز پنل، `admin_ok` کوکی نشست معتبر می‌خواهد و
# «?key=» در URL دیگر پنل را باز نمی‌کند (کلید در URL نشت می‌کند). تست‌ها
# پس اول واقعاً ورود می‌کنند و کوکی می‌گیرند؛ اگر رمزی تعیین نشده باشد،
# همان مسیر قدیمی «?key=» کار می‌کند و چیزی تغییر نمی‌کند.
def panel_login(op):
    """Authenticate `op` against the panel and leave the session cookie in
    its jar. Returns True on success. With no PANEL_PASS set this is a no-op
    and the legacy "?key=" path still works."""
    pw = os.environ.get("PANEL_PASS") or ""
    if not pw:
        return False
    jar = None
    for h in getattr(op, "handlers", []):
        if isinstance(h, urllib.request.HTTPCookieProcessor):
            jar = h.cookiejar
            break
    if jar is None:
        return False

    class _NoRedir(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None

    # The opener must share the caller's jar, otherwise the cookie is minted
    # into a throwaway jar and the caller stays logged out.
    o = urllib.request.build_opener(_NoRedir,
                                    urllib.request.HTTPCookieProcessor(jar))
    body = urllib.parse.urlencode({"password": pw}).encode()
    req = urllib.request.Request(
        BASE + PANEL + "/login", data=body, method="POST",
        headers={"User-Agent": "bz-test",
                 "Content-Type": "application/x-www-form-urlencoded"})
    try:
        o.open(req, timeout=20)
    except urllib.error.HTTPError as e:
        if e.code not in (302, 303):
            return False
    except Exception:
        return False
    return any(c.name == "bzv2_admin" for c in jar)


KEY = db.owner_token()
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  {G}✓{X} {label}")
    else:
        bad_n += 1
        FAILS.append(label)
        print(f"  {R}✗{X} {label}  {detail}")


def head(t):
    print(f"\n{B}── {t}{X}")


def session():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def get(op, path):
    try:
        res = op.open(BASE + path, timeout=25)
        return res.getcode(), res.read().decode("utf-8", "replace"), res.headers.get("Content-Type", "")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.headers.get("Content-Type", "")
    except Exception as e:
        return 0, str(e), ""


def post_form(op, path, data):
    body = urllib.parse.urlencode(data, doseq=True).encode()
    r = urllib.request.Request(BASE + path, data=body)
    r.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        res = op.open(r, timeout=25)
        return res.getcode(), res.geturl(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.geturl(), e.read().decode("utf-8", "replace")


op = session()
panel_login(op)   # v297: با رمز پنل، کوکی نشست لازم است (نه ?key= در URL)
K = urllib.parse.quote(KEY)
BID = db.businesses()[0]["id"]
PH = "09350000296"

head("ساخت دادهٔ آزمایشی (مشتری + سفارش با اقلام + نوبت)")
db._run("DELETE FROM customers WHERE phone=?", (PH,))
db._run("DELETE FROM bookings WHERE phone=?", (PH,))
db._run("INSERT INTO customers(phone,name) VALUES(?,?)", (PH, "مشتری تست ۲۹۶"))
cid = db._rows("SELECT id FROM customers WHERE phone=?", (PH,))[0]["id"]
db._run("INSERT INTO orders(biz_id,customer_id,name,phone,address,note,total,status) "
        "VALUES(?,?,?,?,?,?,?,?)",
        (BID, cid, "مشتری تست ۲۹۶", PH, "خیابان تست، پلاک ۲۹۶", "زود تحویل شود", 150000, "new"))
oid = db._rows("SELECT id FROM orders WHERE phone=?", (PH,))[0]["id"]
db._run("INSERT INTO order_items(order_id,title,price,qty) VALUES(?,?,?,?)", (oid, "چای لاهیجان", 50000, 2))
db._run("INSERT INTO order_items(order_id,title,price,qty) VALUES(?,?,?,?)", (oid, "نبات زعفرانی", 25000, 2))
db._run("INSERT INTO bookings(biz_id,name,phone,date,time,note,status) VALUES(?,?,?,?,?,?,?)",
        (BID, "مشتری تست ۲۹۶", PH, "2026-09-25", "10:30", "نوبت تست", "new"))

head("لیست سفارش‌ها: چیپ وضعیت + جستجو + خروجی")
code, html, _ = get(op, f"{PANEL}/orders?key={K}")
check("لیست سفارش‌ها ۲۰۰", code == 200, str(code))
check("چیپ‌های وضعیت", "لغوشده" in html and "تحویل‌شده" in html)
check("جعبهٔ جستجو", 'name="q"' in html)
check("دکمهٔ خروجی", PANEL + "/orders/export" in html)
check("لینک جزئیات سفارش", f"{PANEL}/order/{oid}" in html)

code, html, _ = get(op, f"{PANEL}/orders?q={PH}&key={K}")
check("جستجو با تلفن پیدا می‌کند", f"{PANEL}/order/{oid}" in html)
code, html, _ = get(op, PANEL + "/orders?q=" + urllib.parse.quote("zzz-نیست-خالی") + f"&key={K}")
check("جستجوی بی‌نتیجه پیام مناسب", code == 200 and "پیدا نشد" in html, str(code))

head("صفحهٔ جزئیات سفارش")
code, html, _ = get(op, f"{PANEL}/order/{oid}?key={K}")
check("جزئیات ۲۰۰", code == 200, str(code))
check("اقلام نمایش داده می‌شوند", "چای لاهیجان" in html and "نبات زعفرانی" in html)
check("جمع قلم درست", "100" in html)   # 50000×2 = 100,000 → جداکنندهٔ هزارگان
check("آدرس و یادداشت", "خیابان تست" in html and "زود تحویل شود" in html)
check("فرم تغییر وضعیت", 'name="status"' in html)

code, html, _ = get(op, f"{PANEL}/order/999999?key={K}")
check("سفارش ناموجود → ۴۰۴ صادقانه", code == 404, str(code))

head("فیلتر وضعیت سفارش‌ها")
code, html, _ = get(op, f"{PANEL}/orders?status=new&key={K}")
check("فیلتر جدید سفارش تست را نشان می‌دهد", f"{PANEL}/order/{oid}" in html)
db._run("UPDATE orders SET status='done' WHERE id=?", (oid,))
code, html, _ = get(op, f"{PANEL}/orders?status=new&key={K}")
check("بعد از تغییر وضعیت، در فیلتر جدید نیست", f"{PANEL}/order/{oid}" not in html)
code, html, _ = get(op, f"{PANEL}/orders?status=done&key={K}")
check("در فیلتر تحویل‌شده هست", f"{PANEL}/order/{oid}" in html)

head("خروجی CSV سفارش‌ها")
code, csv, ctype = get(op, f"{PANEL}/orders/export?key={K}")
check("CSV سفارش‌ها ۲۰۰ و از نوع csv", code == 200 and "text/csv" in ctype, ctype)
check("شماره سفارش در CSV", str(oid) in csv)
check("BOM فارسی اکسل", csv.startswith("\ufeff"))
code, csv, _ = get(op, f"{PANEL}/orders/export?status=done&q={PH}&key={K}")
check("CSV با فیلتر", str(oid) in csv and "0935" in csv)

head("نوبت‌ها: چیپ + جستجو + خروجی")
code, html, _ = get(op, f"{PANEL}/bookings?key={K}")
check("لیست نوبت‌ها ۲۰۰", code == 200, str(code))
check("چیپ وضعیت نوبت‌ها", "انجام‌شده" in html)
code, html, _ = get(op, f"{PANEL}/bookings?q={PH}&key={K}")
check("جستجوی نوبت با تلفن", "نوبت تست" in html)
code, html, _ = get(op, f"{PANEL}/bookings?status=done&key={K}")
check("فیلتر انجام‌شده نوبت تست را ندارد", "نوبت تست" not in html)
code, csv, ctype = get(op, f"{PANEL}/bookings/export?key={K}")
check("CSV نوبت‌ها", code == 200 and "text/csv" in ctype and "نوبت تست" in csv)

head("مشتری‌ها: جستجو + خروجی")
code, html, _ = get(op, f"{PANEL}/customers?q={PH}&key={K}")
check("جستجوی مشتری", "مشتری تست ۲۹۶" in html)
code, csv, ctype = get(op, f"{PANEL}/customers/export?q={PH}&key={K}")
check("CSV مشتری‌ها", code == 200 and "text/csv" in ctype and PH in csv)

head("رگرسیون: تغییر وضعیت سفارش از پنل")
code, url, _ = post_form(op, f"{PANEL}/order/{oid}", {"key": KEY, "status": "confirmed"})
st = db._rows("SELECT status FROM orders WHERE id=?", (oid,))[0]["status"]
check("تغییر وضعیت کار می‌کند", st == "confirmed", st)

head("پاک‌سازی دادهٔ تست")
db._run("DELETE FROM orders WHERE phone=?", (PH,))
db._run("DELETE FROM bookings WHERE phone=?", (PH,))
db._run("DELETE FROM customers WHERE phone=?", (PH,))
check("پاک شد", not db._rows("SELECT id FROM orders WHERE phone=?", (PH,)))

print()
if bad_n:
    print(f"{R}{B}نتیجه: {ok_n} قبول / {bad_n} رد{X}")
    for f in FAILS:
        print(f"  {R}- {f}{X}")
    sys.exit(1)
print(f"{G}{B}نتیجه: همهٔ {ok_n} آزمون سبز شد.{X}")
sys.exit(0)
