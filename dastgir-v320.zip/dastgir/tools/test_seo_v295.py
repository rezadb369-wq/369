# -*- coding: utf-8 -*-
"""
v295 — سوئیت قفل SEO عمومی (مطالعهٔ استانداردها + ممیزی زنده).

ملاک‌ها (Google/Schema استاندارد): title/description یکتا و غیرplaceholder ·
canonical · robots+sitemap · OG کامل + twitter:card + og:locale · JSON-LD
(WebSite+SearchAction / Organization / LocalBusiness / BreadcrumbList) ·
h1 معنایی · noindex برای ۴۰۴ و پنل.

اجرا: BZ=http://127.0.0.1:8097 python3 tools/test_seo_v295.py
"""

import os
import re
import sys
import urllib.request
import urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db      # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  {G}✓{X} {label}")
    else:
        bad_n += 1
        FAILS.append(label)
        print(f"  {R}✗{X} {label}  {detail}")


def get(path):
    try:
        res = urllib.request.urlopen(BASE + path, timeout=25)
        return res.getcode(), res.read().decode("utf-8", "replace"), dict(res.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), dict(e.headers)
    except Exception as e:
        return 0, str(e), {}


print(f"{B}── صفحهٔ خانه{X}")
code, html, hdr = get("/")
check("خانه ۲۰۰", code == 200, str(code))
m = re.search(r"<title>([^<]{3,})</title>", html)
check("title معنادار", bool(m), html[:120])
md = re.search(r'<meta name="description" content="([^"]{10,})"', html)
check("meta description غیرplaceholder", bool(md) and md.group(1).strip() not in ("توضیح", "توضیحات", "description"))
check("canonical", 'rel="canonical"' in html)
check("og:title", 'property="og:title"' in html)
check("og:description", 'property="og:description"' in html)
check("og:locale fa_IR", 'og:locale" content="fa_IR"' in html)
check("twitter:card", 'name="twitter:card"' in html)
_site_url = (db.get_settings().get("site_url") or "").strip()
check("JSON-LD WebSite", '"@type": "WebSite"' in html)
if _site_url:
    check("JSON-LD SearchAction (چون site_url تنظیم است)", "SearchAction" in html)
else:
    print("    (SearchAction در محیط بدون site_url انتظار نمی‌رود؛ در پروداکشن تنظیم است)")
check("JSON-LD Organization", '"Organization"' in html)
check("h1 وجود دارد", "<h1" in html)

print(f"{B}── robots و sitemap{X}")
code, txt, _ = get("/robots.txt")
check("robots ۲۰۰", code == 200, str(code))
check("robots به sitemap اشاره دارد", "Sitemap:" in txt)
code, xml, _ = get("/sitemap.xml")
check("sitemap ۲۰۰", code == 200, str(code))
check("sitemap دارای URL", "<url>" in xml)

print(f"{B}── صفحهٔ کسب‌وکار (LocalBusiness + Breadcrumb){X}")
biz = db._rows("SELECT slug FROM businesses WHERE status='published' LIMIT 1")
if biz:
    code, html, hdr = get("/b/" + biz[0]["slug"])
    check("صفحهٔ کسب ۲۰۰", code == 200, str(code))
    check("JSON-LD LocalBusiness", '"LocalBusiness"' in html)
    check("JSON-LD BreadcrumbList", '"BreadcrumbList"' in html)
    check("h1 کسب", "<h1" in html)
    check("canonical کسب", 'rel="canonical"' in html)
else:
    check("کسب منتشرشده برای تست هست", False, "دیتابیس خالی")

print(f"{B}── فهرست‌ها (Breadcrumb){X}")
code, html, _ = get("/businesses")
check("فهرست کسب‌ها ۲۰۰", code == 200, str(code))
check("BreadcrumbList فهرست", '"BreadcrumbList"' in html)

print(f"{B}── رفتار ۴۰۴ و پنل{X}")
code, html, hdr = get("/no-such-page-xyz")
check("۴۰۴ صادقانه", code == 404, str(code))
check("۴۰۴ noindex", "noindex" in html or "noindex" in str(hdr))
code, html, hdr = get("/panel")
check("پنل noindex", "noindex" in html or "noindex" in str(hdr))

print()
if bad_n:
    print(f"{R}{B}نتیجه: {ok_n} قبول / {bad_n} رد{X}")
    for f in FAILS:
        print(f"  {R}- {f}{X}")
    sys.exit(1)
print(f"{G}{B}نتیجه: همهٔ {ok_n} بررسی SEO سبز شد.{X}")
sys.exit(0)
