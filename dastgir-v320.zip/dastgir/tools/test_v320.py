# -*- coding: utf-8 -*-
"""v320 — ساخت/ویرایش/حذف محتوا با توضیح-بعد-تأیید؛ هرگز sqlite DIY.

دستور مدیر: ایجنت می‌تواند کسب‌وکار بسازد/عوض کند/حذف کند، ولی اول توضیح
می‌دهد و بعد با «بله» اجرا می‌شود. sqlite3 / DELETE FROM ممنوع.

اجرا:  python3 tools/test_v320.py
"""
import ast
import json
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))

G, R, X = "\033[32m", "\033[31m", "\033[0m"
n = 0
fails = []


def ck(ok, label):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        print("  " + R + "✗ " + label + X)


TMP = tempfile.mkdtemp(prefix="v320-")
os.environ["BZ_DATA_DIR"] = os.environ.get("BZ_DATA_DIR", TMP)
os.environ.setdefault("BALE_ADMIN_TOKEN", "test-token-not-real")
os.environ.setdefault("BALE_ADMIN_SECRET", "s" * 40)
os.environ.setdefault("BALE_ADMIN_CHAT", "893219571")
os.environ.setdefault("ADMINBOT_QUEUE", os.path.join(TMP, "q"))
os.environ.setdefault("ADMINBOT_PENDING", os.path.join(TMP, "pending.json"))
os.environ.setdefault("ADMINBOT_MEMORY", os.path.join(TMP, "mem.json"))
sys.path.insert(0, os.path.join(ROOT, "server"))

import db  # noqa: E402
import assistant as AI  # noqa: E402
import adminbot as A  # noqa: E402
import adminbot_content as CT  # noqa: E402
import views_agent_full as VAF  # noqa: E402

db.init()
ver = open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8").read().strip()
sw = open(os.path.join(ROOT, "site", "sw.js"), encoding="utf-8").read()
readme = open(os.path.join(ROOT, "README.md"), encoding="utf-8").read()

print("v320 — پین + خواندن فوری + نوشتن با تأیید + ضد sqlite")

ck(ver == "320" and A.DIAG_LATEST == "320", "پین نسخه 320")
ck("bazarche-v320" in sw, "sw.js v320")
ck("دست گیر — v320" in readme, "README v320")
ck(AI.SITE_DEFAULT_MODEL == "ling-3.0-flash-sante-free", "مغز پیش‌فرض ling")

# reads immediate, writes confirm
ck("file_read" in CT.IMMEDIATE_TOOLS and "panel_read" in CT.IMMEDIATE_TOOLS
   and "sql_read" in CT.IMMEDIATE_TOOLS and "code_search" in CT.IMMEDIATE_TOOLS,
   "خواندن‌ها فوری‌اند")
ck("shell_exec" not in CT.IMMEDIATE_TOOLS, "shell_exec غیرفوری")
for t in ("business_save", "business_delete", "businesses_wipe", "setting",
          "file_write", "code_edit", "item_save", "broadcast", "service_restart"):
    ck(t in CT._CONFIRM_TOOLS and t not in CT.IMMEDIATE_TOOLS,
       t + " تأیید می‌خواهد")

ck("business_delete" in CT.TOOLS and "businesses_wipe" in CT.TOOLS,
   "ابزار حذف در TOOLS")
missing = [t for t in CT.TOOLS if t not in VAF.TOOL_FA]
ck(not missing, "TOOL_FA کامل" + ((" — " + ",".join(missing[:8])) if missing else ""))

# parse
name, args = CT.parse_tool_call({"name": "business_delete", "args": {"id": 3}})
ck(name == "business_delete" and args.get("id") == 3, "parse business_delete")
name, args = CT.parse_tool_call({"name": "delete_business", "args": {"id": 3}})
ck(name == "business_delete", "alias delete_business")
name, args = CT.parse_tool_call(
    {"name": "businesses_wipe", "args": {"confirm": "حذف همه کسب‌وکارها"}})
ck(name == "businesses_wipe", "parse wipe با confirm دقیق")
name, args = CT.parse_tool_call(
    {"name": "businesses_wipe", "args": {"confirm": "بله"}})
ck(name is None, "parse wipe بدون جملهٔ دقیق رد")
name, args = CT.parse_tool_call(
    {"name": "wipe_businesses", "args": {"confirm": "حذف همه کسب‌وکارها"}})
ck(name == "businesses_wipe", "alias wipe_businesses")

ok, why = CT.tool_precheck("businesses_wipe", {"confirm": "نه"})
ck(not ok and why == "confirm", "precheck wipe بدون confirm")
ok, why = CT.tool_precheck(
    "shell_exec", {"cmd": "sqlite3 data/bazarche.db 'DELETE FROM businesses'"})
ck(not ok and why == "sqlite_diy", "shell_exec نوشتن sqlite رد")
ok, why = CT.tool_precheck("shell_exec", {"cmd": "echo hello"})
ck(ok, "shell_exec echo مجاز (precheck)")

# sqlite DIY intercept
raw_diy = "برای پاک کردن همه باید sqlite3 data/bazarche.db 'DELETE FROM businesses' بزنی"
diy = CT.reject_sqlite_diy(raw_diy)
ck(diy != raw_diy and "business_save" in diy,
   "reject_sqlite_diy دستور sqlite را عوض می‌کند")
ck(CT.reject_sqlite_diy("فهرست کسب‌وکارها را نشان بده") == "فهرست کسب‌وکارها را نشان بده",
   "reject_sqlite_diy متن عادی را نگه می‌دارد")
ck("دسترسی شل" in CT.reject_sqlite_diy("عملیات حذف نیاز به دسترسی شل به دیتابیس نیست")
   or "ابزار" in CT.reject_sqlite_diy("عملیات حذف نیاز به دسترسی شل به دیتابیس نیست"),
   "پیام شل دیتابیس هم عوض می‌شود")

# live content tools on temp DB — never the VPS
b1 = db.save_business({"name": "نانوایی الف v320", "cat_slug": "نانوایی",
                       "phone": "09120000001", "status": "active"})
b2 = db.save_business({"name": "کافه ب v320", "cat_slug": "کافه",
                       "phone": "09120000002", "status": "active"})
ck(bool(b1) and bool(b2), "دو کسب‌وکار تست ساخته شد")

ok, why = CT.tool_precheck("business_delete", {"id": b1})
ck(ok, "precheck business_delete موجود")
desc = CT.tool_describe("business_delete", {"id": b1})
ck("نانوایی الف" in desc, "describe نام کسب‌وکار")
ok, msg = CT.tool_execute("business_delete", {"id": b1})
ck(ok and "الف" in str(msg), "execute business_delete")
ck(db._one("SELECT id FROM businesses WHERE id=?", (b1,)) is None,
   "بعد از حذف در businesses نیست")
gone = db._one("SELECT id FROM businesses WHERE id=?", (b1,))
ck(gone is None, "حذف تکی اعمال شد")

# wipe without confirm in execute
ok, msg = CT.tool_execute("businesses_wipe", {"confirm": "بله"})
ck(not ok, "execute wipe بدون جملهٔ دقیق رد")
ck(db._one("SELECT id FROM businesses WHERE id=?", (b2,)) is not None,
   "کسب‌وکار دوم هنوز هست")

ok, msg = CT.tool_execute("businesses_wipe",
                          {"confirm": "حذف همه کسب‌وکارها"})
ck(ok and "حذف" in str(msg), "execute businesses_wipe")
left = (db._one("SELECT COUNT(*) AS n FROM businesses") or {}).get("n") or 0
ck(left == 0, "بعد از wipe جدول خالی است (دیتابیس موقت)")

# create via business_save tool
name, args = CT.parse_tool_call({
    "name": "business_save",
    "args": {"id": 0, "fields": {"name": "گل فروشی v320", "cat_slug": "cafe"}},
})
ck(name == "business_save", "parse business_save ساخت تازه")
ok, msg = CT.tool_execute(name, args)
ck(ok and "گل فروشی" in str(msg), "execute business_save ساخت")
row = db._one("SELECT id,name FROM businesses WHERE name=?", ("گل فروشی v320",))
ck(bool(row), "کسب‌وکار تازه در DB")

# prompt never-sqlite
psrc = open(os.path.join(ROOT, "server", "assistant.py"), encoding="utf-8").read()
ck("هرگز دستور sqlite3" in psrc and "businesses_wipe" in psrc,
   "پرامپت: sqlite ممنوع + ابزار wipe")
ck("اول فارسی بگو چه عوض می‌شود" in psrc or "توضیح" in psrc,
   "پرامپت: اول توضیح")

asrc = open(os.path.join(ROOT, "server", "adminbot.py"), encoding="utf-8").read()
ck("_CONFIRM_TOOLS" in asrc and "reject_sqlite_diy" in asrc,
   "بات: دیوار تأیید + ضد sqlite")

soul = open(os.path.join(ROOT, "deploy", "openclaw", "workspace", "SOUL.md"),
            encoding="utf-8").read()
ck("sqlite3" in soul and "business_delete" in soul and "تأیید" in soul,
   "OpenClaw SOUL: بدون SQL خام")

# file_read still works
ok, msg = CT.tool_execute("file_read", {"path": "VERSION.txt"})
ck(ok and "320" in str(msg), "file_read VERSION.txt")
ok, msg = CT.tool_execute("file_read", {"path": "docs/collaboration/HANDOFF.md"})
ck(ok and "v320" in str(msg), "file_read HANDOFF v320")

# no agent token in tree
needle = "55164" + "6991"
hits = []
for dirpath, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ("__pycache__", "data", ".git")]
    for fn in files:
        if fn.endswith((".pyc", ".zip", ".db")):
            continue
        rel = os.path.relpath(os.path.join(dirpath, fn), ROOT)
        if rel.replace("\\", "/").startswith("tools/test_"):
            continue
        fp = os.path.join(dirpath, fn)
        try:
            txt = open(fp, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        if needle in txt:
            hits.append(rel)
ck(not hits, "توکن ایجنت بله در درخت نیست" + ((" — " + ",".join(hits[:5])) if hits else ""))

for rel in ("server/adminbot.py", "server/adminbot_content.py",
            "server/assistant.py", "server/agent_cmds.py"):
    ast.parse(open(os.path.join(ROOT, rel), encoding="utf-8").read())
ck(True, "فایل‌های کلیدی parse")

print()
print("موفق: %d   ناموفق: %d" % (n, len(fails)))
if fails:
    for x in fails:
        print("  -", x)
    sys.exit(1)
print("همه موفق — v320 قفل شد.")
