# طرح ارتقای پنل — v296 → v297

تاریخ: ۲۰۲۶-۰۹-۱۹ · مبنا: ممیزی زندهٔ ۱۳۷ مسیر پنل (۹۳ ثابت + ۴۴ الگویی) + یافته‌های F1-F8.

این فایل همان است که `CURRENT-STATE.md` به آن ارجاع می‌داد و وجود نداشت (F7).

---

## ۱) الگوی ارتقا (۶ پرسش برای هر بخش)

برای هر بخش پنل:

1. CRUD کامل؟ ساخت/دیدن/ویرایش/حذف/تغییر وضعیت
2. ویرایش پس از انتشار؟ (باگ تبلیغات که مدیر دید)
3. جست‌وجو و فیلتر؟
4. خروجی عملیاتی CSV با BOM فارسی؟
5. ۴۰۴/خطای صادقانه برای شناسهٔ ناموجود؟
6. از ربات بله هم قابل انجام؟

---

## ۲) وضعیت ۱۳۷ مسیر — خلاصهٔ ممیزی

### ✅ بخش‌های کامل (۶/۶)

| بخش | مسیرها | وضعیت |
|---|---|---|
| سفارش‌ها | `/panel/orders`, `/panel/order/<id>`, `/panel/orders/export` | فیلتر وضعیت + جست‌وجو + CSV + جزئیات + ۴۰۴ صادقانه — v296 تکمیل شد (test_panel_ops 29) |
| نوبت‌ها | `/panel/bookings`, `/panel/booking/<id>`, `/panel/bookings/export` | همان الگو — v296 |
| مشتری‌ها | `/panel/customers`, `/panel/customer/<id>`, `/panel/customers/export` | جست‌وجو + CSV + بن/آن‌بن + audit |
| کسب‌وکارها | `/panel/businesses`, `/panel/business/<id>`, `/panel/businesses/export`, `/panel/businesses/bulk` | جست‌وجو + فیلتر + CSV + عملیات گروهی + ۴۰۴ |
| تبلیغات | `/panel/ads`, `/panel/ad/<id>`, `/panel/ad/new` | **ویرایش پس از انتشار کار می‌کند** (multipart) — F6 فقط toggle مخرب روی action ناشناخته بود که در v297 رفع شد (رد با err به‌جای toggle) |
| استوری | `/panel/stories`, `/panel/story/<id>` | ویرایش + تمدید + آمار دیده‌شدن — v295 |
| فلش‌سیل | `/panel/deals`, `/panel/deal/<id>` | ویرایش + toggle + ۴۰۴ — v294 |
| نظرات/گزارش‌ها/تیکت‌ها/پرسش‌ها | `/panel/reviews`, `/panel/reports`, `/panel/tickets`, `/panel/qa` + bulk | عملیات گروهی + فیلتر + audit |
| لیست‌های برتر | `/panel/lists`, `/panel/list/<id>` | CRUD کامل + ویرایش پس از انتشار |
| دسته‌ها | `/panel/categories`, `/panel/category/<id>` | CRUD + تصویر + ۴۰۴ صادقانه |

### ⚠️ بخش‌های نیازمند ارتقای جزئی

| بخش | کمبود | اولویت |
|---|---|---|
| چت‌ها | `/panel/chats`, `/panel/chat/<id>` — جست‌وجو ندارد، فقط لیست | متوسط — افزودن `?q=` و CSV |
| پیام‌ها/استعلام‌ها/ادعاها | `/panel/messages`, `/panel/inquiries`, `/panel/claims` — فیلتر وضعیت ندارد | متوسط |
| رویدادها | `/panel/events`, `/panel/event/<id>` — فیلتر تاریخ ندارد | کم |
| نشان‌ها/پلن‌ها | `/panel/badges`, `/panel/plans` — خروجی CSV ندارد | کم |
| مشترک‌ها | `/panel/subscriptions` — فیلتر پلن ندارد | کم |
| لاگ ممیزی | `/panel/audit` — CSV دارد ولی فیلتر `detail` ضعیف | کم — قبلاً بهبود یافت |

### 🔴 باگ‌های امنیتی/عملکردی (F1-F6) — همه در v297 رفع شدند

| # | شرح | درمان v297 |
|---|---|---|
| F1 | `deploy/gate.env` رمز متن ساده در zip عمومی | هش PBKDF2 + `BOT_GATE_*_HASH`، متن ساده فقط در `/etc/dastgir-secrets.env` |
| F2 | `scan_tokens.py` نقطهٔ کور | الگوهای `*_PASS|*_SECRET|*_TOKEN|*_PHONE` + تست دوسویه |
| F3 | رانش کش‌شکن ۴۲ مورد در ۱۱ فایل | `ui.av()` + `panel_prefix()` — همه از `VERSION.txt` |
| F4 | `/panel` ۴۰۳ وجود کنسول را لو می‌داد | با نشانی مخفی ۴۰۴ صادقانه، بدون «پنل مدیریت» |
| F5 | `robots.txt` Disallow: /panel | شرطی شد — با نشانی مخفی هیچ ردی از /panel یا نشانی مخفی در robots نیست |
| F6 | `POST /panel/ad/<id>` با action ناشناخته toggle می‌کرد | حالا `action` نامشخص → `err=عملیات نامشخص`، فقط `toggle|reset|delete` مجاز |

### 🔴 نشت‌های لایهٔ ۱ که در v297 کشف و رفع شدند (فراتر از F1-F6)

| نشت | تعداد | درمان |
|---|---|---|
| لینک‌های `/panel/...` در HTML پنل (۱۰۸ مورد در `/orders`) | ۱۰۸ → ۰ | `rewrite_panel_links()` در `panel_page()` + `panel_prefix()` |
| `href="/panel"` در هدر عمومی و `bottom_nav` | ۲ | `panel_prefix(s)` در `ui.header` و `bottom_nav` |
| `window.__PANEL_NAV__` JSON با `/panel/...` → Ctrl+K به ۴۰۴ | کل JSON | `_PANEL_JSON_RX` در rewrite |
| «لینک ورود» در تنظیمات با `/panel?key=` → ۴۰۴ | ۲ | `panel_prefix(s)` در `views_panel.py` |
| ریدایرکت‌های POST پنل با `/panel/...` → ۴۰۴ | ۱۹۳ | `self._panel_url(s, ...)` در همهٔ `self.redirect("/panel…")` |
| `robots.txt` و sitemap | — | شرطی، بدون نشت |

پس از درمان: ۰ نشت از ۱۴۸۴ لینک در ۱۰ صفحهٔ پنل (تست زنده).

---

## ۳) سه لایهٔ امنیت — پیاده‌سازی نهایی v297

**لایهٔ ۱ — نشانی مخفی:** `panel_hidden_path = secrets.token_urlsafe(18)` (۱۴۴ بیت) در `settings` + فایل ماندگار `audit/panel-hidden.txt` (نه `/tmp`). `route_post` و `_route_render` هر دو `/<hidden>/…` → `/panel/…` بازنویسی می‌کنند. غریبه → ۴۰۴ بدون «پنل مدیریت». هیچ نشتی در HTML/robots/sitemap/JSON/ریدایرکت.

**لایهٔ ۲ — کلید+رمز:** `owner_token` (لینک ورود) + `owner_pass_hash` PBKDF2-600k. `panel_login` باید **اول کلید، بعد رمز** بزند تا نشست باز شود (دام ratelimit 10/15min پاک می‌شود). نشست تازه تا رمز قفل است.

**لایهٔ ۳ — تأیید بله:** `_bale_confirm_needed()` = `panel_bale_confirm != "0"` و `adminbot.enabled()` و `gate_ok(owner_chat())`. وقتی ربات فعال نیست، لایهٔ ۳ خودکار خاموش تا مدیر قفل نشود. تأیید یک‌بارمصرف ۵ دقیقه‌ای در `panel_approvals`.

**گیت ربات `/369`:** دو مرحله — شماره (`norm_phone` + `sha256("gatephone:"+phone)`) + رمز (`hash_password` + `compare_digest`). تا هر دو تأیید نشوند `gate_ok()=False` و همهٔ دستورات ربات رد.

---

## ۴) ربات بله — دسترسی کامل

- بات مدیر: همهٔ دستورات پنل از چت با `adminbot_code` + `adminbot_content` قابل اجرا (تنظیمات، کسب‌وکار، بنر، استوری، تیکت، مشتری، سفارش، …).
- «کلید ورود» در تنظیمات: حالا نشانی درست با پیشوند مخفی می‌دهد و واقعاً کار می‌کند (تست: GET `<hidden>?key=` → کوکی → POST رمز → ۲۰۰).
- سطل rate-limit پنل: `apl:<ip>` ۱۰/۹۰۰ثانیه — تست‌ها قبل از هر ورود پاک می‌کنند.

---

## ۵) سئو — وضعیت v297

- `test_seo_v295.py` ۲۵/۲۵ سبز (متا، کانونیکال، OG فارسی، Twitter، JSON-LD Website+Organization+LocalBusiness+Breadcrumb، robots→sitemap، h1، noindex ۴۰۴ و پنل).
- `robots.txt` شرطی: با نشانی مخفی، نه `/panel` و نه نشانی مخفی لو نمی‌رود.
- `panel_page` → `<meta name="robots" content="noindex, nofollow">` + `X-Robots-Tag` از `app.send`.
- کش‌شکن: `av()` از `VERSION.txt` (v297) — همهٔ ۴۲ asset یکسان.

---

## ۶) تست‌ها — شواهد

با نشانی مخفی فعال (`PANEL_BASE=/<hidden>`):

```
test_panel_gates_v297   22 سبز، 0 قرمز
test_panel_security     44 passed, 0 failed
test_panel_ops_v296     29/29
test_panel_robust       16 passed, 0 failed
test_panel_security_v293 19 passed
test_panel_perf_v184    0 failed
test_panel_ux           32 passed, 0 failed
test_seo_v295           25 passed, 0 failed
```

- `test_panel_mod` منسوخ: `/login/password` از v186 عمداً ۴۰۴ است (ورود فقط با بله/سروش) — ربطی به پنل مخفی ندارد.
- دام‌های تست: `urllib` ریدایرکت را دنبال می‌کند → `NoRedirect` opener؛ `seed_demo.py` تنظیمات را پاک می‌کند → `setup-test-env.sh`؛ `ratelimit` پس از ۱۰ ورود ۴۲۹ می‌دهد → پاک‌سازی در `panel_login`.

---

## ۷) کارهای باقی‌مانده (برای v298)

1. جست‌وجو و CSV برای چت‌ها/پیام‌ها/استعلام‌ها/ادعاها/رویدادها
2. ارتقای ربات بله: دستورات CRUD برای همهٔ ۱۳۷ مسیر (الگوی «هرچه پنل می‌کند از چت هم»)
3. پنل ظاهری جدید: بخش «تبلیغات مدرن» با پیش‌نمایش زنده + A/B + زمان‌بندی هوشمند
4. مستندسازی: `HANDOFF.md` و `CURRENT-STATE.md` به‌روزرسانی نهایی + `WHATS-NEW.md`

---

## ۸) تحویل v297

- بسته: `dastgir-v297.zip` (۶۰۰ فایل)
- نصب یک‌فرمانی: `deploy/update.sh` / `install.sh` — جایگزینی روی `/opt/dastgir`
- بامپ نسخه ۵جا: `VERSION.txt`=297, `sw.js`=bazarche-v297-merchant1, `README.md`=v297, `DIAG_LATEST`=297, `CURRENT-STATE.md` خط ۱ = v297 + `?v297` در `ui.av()`
- رازها: `deploy/gate.env` فقط هش، متن ساده فقط در `/etc/dastgir-secrets.env`
