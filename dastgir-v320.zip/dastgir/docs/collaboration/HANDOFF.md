# HANDOFF — v320 (۲۲/۰۹/۲۰۲۶)

بخوان: `RULES.md` · `CURRENT-STATE.md` · `KNOWLEDGE.md` · `WHATS-NEW.md` · همین فایل.

## الان چیست

ایجنت مالک **می‌تواند** کسب‌وکار بسازد/ویرایش/حذف کند و تنظیمات سایت را عوض کند،
ولی **اول فارسی توضیح می‌دهد** و بعد با «بله»/دکمه اجرا می‌شود. خواندن فوری است.
هرگز sqlite3 / DELETE FROM / کپی `.db` برای محتوا نده —
ابزار: `business_save` · `business_delete` · `businesses_wipe` · `setting`.

PhonePilot/OpenClaw جدا از بات ۷۰ابزاری دست‌گیر است؛ `deploy/openclaw/workspace/SOUL.md` سخت شده.

مغز پیش‌فرض: `ling-3.0-flash-sante-free`. توکن ایجنت بله در زیپ نیست. پالر دوم نساز.

## پین

| فایل | مقدار |
|---|---|
| `VERSION.txt` | `320` |
| `site/sw.js` | `bazarche-v320` |
| `DIAG_LATEST` | `"320"` |

## تست

```
python3 tools/test_v320.py
python3 tools/test_security_v318.py
python3 tools/test_agent_tools_v310.py
```

نصب: `sudo bash /opt/dastgir/deploy/update.sh /tmp/dastgir-v320.zip`
