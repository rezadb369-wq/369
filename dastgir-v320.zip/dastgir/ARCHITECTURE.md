# ARCHITECTURE — دست گیر (v280)

نقشهٔ ساختمان برای هر کس که می‌خواهد کد را بفهمد یا دست بزند.
تاریخ به‌روزرسانی: ۲۰۲۶-۰۹-۱۳ · همهٔ اعداد این سند خروجی واقعی فرمان روی همین بسته‌اند (`wc -l`، `sqlite_master`، پارس مکانیکی `app.py`).

---

## ۱) نمای کلی

- **پشته:** پایتون ۳ خالص (`http.server` سفارشی‌شده) + SQLite + HTML/CSS/JS دست‌نویس.
  **صفر وابستگی** — روی Pydroid 3 اندروید هم اجرا می‌شود (تست‌های مرورگری Playwright می‌خواهند، خود سایت نه).
- **داده:** یک فایل `data/bazarche.db` (WAL) — **۸۹ جدول زنده** (۸۴ دستور `CREATE TABLE` + ۵ آبجکت داخلی FTS) + **۱۱۸ ایندکس** + صفر trigger/view. تنها FTS: `businesses_fts`.
  عکس‌های آپلودی در `site/assets/img/uploads/` و پیوست‌های گفت‌وگو در `data/chat-files/` — هر دو بیرون از زیپ.
- **ورودی اجرا:** `run.py` → `db.init()` → `server/app.py:make_server(port, host="0.0.0.0")` (`ThreadingHTTPServer`، `serve_forever` روی پورت ۸۰۸۰).
- **مقیاس:** `server/` = ۳۵ فایل، ۴۰٬۴۷۱ خط · `site/` = ۲۴۲ فایل · `tools/` = ۱۱۶ سوئیت تست + ۷۴ ابزار.
- **مسیر داده:** `BZ_DATA_DIR` (محیط) جای `data/` را عوض می‌کند — همین باعث می‌شود بنچمارک/تست روی پایگاه جدا اجرا شوند بدون دست‌زدن به دادهٔ واقعی.

## ۲) مسیر یک درخواست

```
مرورگر → Handler (server/app.py)
  1) server/shield.py      سپر: rate limit / اسکنر / UA مخرب / ban ماندگار → 429/404/403
  2) app.py route          مسیرها: /robots.txt, /sitemap, static, /api/*, صفحات (۲۱۵ شرط مسیر)
  3) app.py auth           کلید پنل (query/path/keyfile) · سشن (HMAC cookie) · تأیید پیام‌رسان
  4) Handler.spam_gate     سیاست مرکزی ضداسپم per-کنش (نام دروازه در پیام خطا)
  5) db.rate_ok            سهمیهٔ per-action در لایهٔ داده (سطل‌های قدیمی‌تر)
  6) views_*.py            HTML سرور-رندر با server/ui.py (کروم + کروم‌هدر CSS توکن)
  7) db.py                 SQLite (WAL) — تنها نقطهٔ تماس با داده
```

## ۳) ماژول‌ها (`server/`) — خطوط واقعی

| فایل | خطوط | نقش |
|---|---|---|
| `db.py` | 7800 | لایهٔ داده: SCHEMA/مایگریشن، CRUD، `rate_ok`/`rate_clear`، تنظیمات، `log`، بکاپ/بازیابی، `sparkline_svg` |
| `app.py` | 5520 | HTTP handler، مسیریابی، auth/سشن، آپلود، robots/sitemap، روتر API، `spam_gate:279`، کنسول اسپم `:1965` |
| `views_panel2.py` | 2977 | پنل مدیر — بخش ۲ (از جمله `/panel/traffic` سپر و `/panel/spam`) |
| `assistant.py` | 2696 | مغز گفت‌وگو: چت عمومی (پرامپت آزاد + حالت آفلاین)، سهمیه/کش/رشته، لاگ چت و چرخش آن |
| `views_owner.py` | 2140 | پنل دکان‌دار کامل |
| `adminbot.py` | 1950 | بات مدیر: گزارش، سلامت، «تشخیص» (`DIAG_LATEST:648`)، دیسپچ، «اسپم»، اجرای فوری + «بله» فقط دستورهای مستقیم |
| `adminbot_content.py` | 1877 | ابزارهای محتوای پنل + اعتبارسنجی/ترمیم فراخوانی + دلیل‌های رد شدن |
| `views_panel.py` | 1858 | پنل مدیر — بخش ۱ |
| `features.py` | 1771 | زیرسیستم‌های چندجدولی: چت، سفارش، تیکت، علاقه‌مندی، چانه، نوبت، تیک‌ها |
| `views_public.py` | 1630 | خانه، جست‌وجو، دسته، شهر، صفحهٔ کسب‌وکار |
| `ui.py` | 1573 | کروم عمومی، منوی پایین، کروم‌هدر `<style>` توکن روز، کش‌شکن `?vNNN`، GA4 |
| `bot_menu.py` | 1058 | منوی مشترک حساب‌آگاه بات‌ها + ۱۱ فرمان عمومی |
| `views_public2.py` | 888 | محصول، کاتالوگ عمومی، صفحات کمکی |
| `adminbot_code.py` | 692 | لاین کد: خواندن/ویرایش/نوشتن/برگشت با مسیرهای قفل و صف استقرار |
| `views_catalog.py` | 665 | کاتالوگ/مقایسه/کشف |
| `views_customer.py` | 604 | پنل مشتری (`/me/*`) |
| `bot_register.py` | 556 | ثبت‌نام/چرخهٔ عمر کسب‌وکار در بات (درگاه `regsub:520`) |
| `uploads.py` | 548 | فایل: سقف‌ها، تشخیص نوع از بایت، حذف EXIF/XMP/ICC |
| **`antispam.py`** | **449** | **لایهٔ ضداسپم ماندگار: `POLICY:22`، `guard:245`، `strike:287`، `enum_check:302`، `bytes_add:328`، `content_gate:420`، `prune:352`** |
| `views_register.py` | 392 | ویزارد ثبت کسب‌وکار در وب |
| `fcm.py` | 361 | پوش/FCM و متادیتای اعلان |
| `analytics.py` | 328 | آمار بازدید واقعی: IP/دستگاه/`bz_cid`/نشست، فیلتر بات، گزارش پنل |
| `register_web.py` | 280 | ثبت‌نام وب (سطل `regip:120`) |
| `geoip.py` (+`geoip_ir.csv`) | 276 | نقشهٔ فارسی IP → شهر؛ خالیِ صادقانه برای IPv6/خصوصی/نامعتبر |
| `qr.py` | 274 | QR |
| `bot_register_flow.py` | 254 | جریان مرحله‌به‌مرحلهٔ ثبت در بات |
| `views_chat.py` | 219 | چت |
| `shield.py` | 178 | سپر درخواستی: `RATE_LIMIT=120`/`RATE_WINDOW=10`/`BLOCK_RATE_S=600`، `check:101` |
| `bale.py` | 176 | رابط webhook بله |
| `views_extra.py` | 154 | صفحه‌های ریز (درباره/تماس/offline) |
| `soroush.py` | 133 | رابط webhook سروش‌پلاس + resolver `soroush://resolve?domain=` |
| `sms.py` | 109 | مسیر پیامک — **غیرفعال** (مسیرهایش ۴۰۴) |
| `pagecache.py` | 46 | کش صفحه |
| `notifmeta.py` | 39 | متادیتای اعلان |

**زیرسیستم هوش مصنوعی و استقرار:** کلیدها فقط از `/etc/dastgir-secrets.env` خوانده می‌شوند؛ انبار ۹خطی `deploy/brain.env` با دستور صریح مدیر داخل بسته است (۵ کلید مغز مدیر + `AI_TIMEOUT` + ۳ خط اسلات مستقل هوش عمومی سایت `AI_SITE_*`). `deploy/apply-brain.sh` حین نصب همهٔ `AI_*` قبلی را کامل پاک و مغز بسته را جایگزین می‌کند (idempotent با stamp).
**دو محیط جدا:** چت عمومی کاربران فقط از `AI_SITE_*` می‌خواند (`site_config()` در `assistant.py`؛ تک‌مدل، سوئیچ مدل با تنظیم `ai_site_model`) و `admin_answer`/`admin_agent` فقط از ۶ مغز مدیر (`config()`) — (v317: + بای‌نارا) **بدون fallback و بدون سوئیچ خودکار** (دستور مدیر)؛ مغز مرده = `_brain_fail_fa` با نام مغز + دلیل + درمان دستی.
**دکمهٔ دیده‌شدنی:** دو ردیف «هوش سایت» و «کلیدها» و «چت‌ها» در `KEYBOARD` بات مدیر؛ اسلات هر کلید صریح است (`CODE.parse` اسلات را از نام کلید حدس نمی‌زند).

## ۴) سیستم تم — «رسمی»

```
site/assets/css/
  tokens.css      همهٔ توکن‌های معنایی: :root (روز) + [data-theme] (شب)
  main.css        ساختار/کامپوننت‌ها — بی‌رنگ‌های هاردکد؛ zoom نقشه هم اینجاست
  pages.css       صفحه‌های خاص (از جمله رنگ .spark از توکن)
  theme-night.css فقط توکن/استثنای کنتراست شب (guard: test_appearance)
  theme-light.css فقط توکن روز
```
- رنگ‌های روز در کروم‌هدر از توکن‌های `ui.py` تزریق می‌شوند تا بدون فایل خارجی هم کامل باشد.
- رنگ مالک (تنظیمات پنل) فقط توکن‌های **روز** را بازمی‌نویسد.
- سلسله‌مراتب تغییر رنگ: توکن → main/pages → theme-*. رنگ خام در ویوها ممنوع.
- نگهبان‌ها: `tools/contrast_audit.py` (AA هر دو تم، متن واقعی صفحات) و `tools/test_appearance.py` (توکن‌های ضروری، ممنوعیت override ساختاری، fade، `prefers-reduced-motion`، حداقل ۱۲px).

## ۵) لایه‌های امنیت

۱. **سپر (`shield.py`):** نخستین لایهٔ هر درخواست — آستانه‌های `BZ_SHIELD_*`؛ رخدادها در `shield_events` + نمودار `/panel/traffic`؛ به banهای ماندگار ضداسپم وصل است.
۲. **ضداسپم ماندگار (`antispam.py`):** سیاست مرکزی ۲۲ کنش + رویدادنامهٔ `spam_events` + `spam_bans` (در بکاپ) + پلهٔ تنبیه + سقف بایت روزانه + هرس. کنسول `/panel/spam` و دستور «اسپم» در بات.
۳. **هوش محتوایی:** `content_gate` سه‌حالته (ok/hold/reject) + honeypot + دِدوپ رأی + سقف ۶۴KB فرم.
۴. **Auth:** پنل = کلید + رمز PBKDF2 + `panel_allow_ips`؛ مشتری/دکان‌دار = سشن HMAC + ورود فقط با تأیید پیام‌رسان (مسیرهای OTP/رمز ۴۰۴) + `loginlock`/`logindiv`.
۵. **`rate_ok`:** سهمیهٔ معنایی هر کنش در `db.py`.
۶. **محتوا/هدرها:** HTML-escape همه‌جا، حذف EXIF، مجوز فایل چت قبل از سرو، `SECURITY_HEADERS` (CSP سخت‌گیرانه، XFO DENY، nosniff، COOP/CORP، Permissions-Policy)، HSTS فقط پشت پروکسی HTTPS، `X-Robots-Tag: noindex` روی پنل، `Handler.timeout=30`.
۷. **نگهبان پوشش:** `tools/test_coverage_guard.py` ⇒ `COVERAGE GUARD PASS 34`؛ مسیر نوشتنی تازهٔ بدون سیاست = قرمز.
جزئیات و ماتریس سطر‌به‌سطر: `docs/SECURITY-SPAM-PLAN.md` و `docs/SECURITY-MATRIX.md`.

## ۶) سرویس‌ورکر و کش

`site/sw.js` — `const VERSION = 'bazarche-v280'` (خط ۹)؛ کش پوسته با استراتژی network-first برای HTML و cache-first برای assets؛ هر کشی که نامش دقیقاً `VERSION` نباشد در activate حذف می‌شود.
**هر تغییر asset ⇒ بامپ `?vNNN` در `ui.py` و `VERSION` در `sw.js`** وگرنه کاربران قدیمی CSS کهنه می‌بینند. کش‌شکن اسکریپت چت در `ui.py:694` است و با سوئیت دستیار پین شده.

## ۷) نقشهٔ تست (۱۱۶ سوئیت در `tools/`)

```
ls tools/test_*.py | wc -l   → 116
```

- **هسته/مسیرمحور (نیاز به سرور زنده + دادهٔ seed + `BZ_DATA_DIR` مشترک):** `test_all`، `test_gates`، `test_actions`، `test_v3`، `test_v3_owner`، `test_open`، `test_open_parity`، `test_isolation`، `test_tickets`، `test_trash`، `test_discovery`، `test_haggle`، `test_prices`، `test_context`، `test_chat_v73`، `test_favorites_v74`، `test_remaining_v76`، `test_section*`، `test_migration`، `test_robustness`.
- **امنیت:** `test_security`، `test_pentest` (۳۹ سناریوی زنده)، `test_attack_v280` (تهاجم زنده)، `test_idor_v280` (پین سراسری IDOR)، `test_coverage_guard` (۳۴ assert)، `test_antispam_*` (۵ سوئیت)، `test_panel_security`، `test_abuse`، `test_privacy`، `test_privacy_v117`، `test_audit_fixes`.
- **بات مدیر/دستیار/بات‌های عمومی:** `test_adminbot_v2xx` (**۲۷ سوئیت**) · `test_assistant_v2xx` (**۱۷ سوئیت**) · `test_bot*` (**۷ سوئیت**).
- **کیفیت UI (Playwright + Chromium):** `test_browser` (a11y@1440، ۱۱ عرض، تعاملات)، `test_appearance`، `test_section1`، `test_panel_ux`، `test_brand_browser_v179`، `test_category_images_v181`، `test_icon_search_v182`.
- **ممیزی/بنچمارک (غیرتستی):** `contrast_audit`، `mobile_audit` (۲۴ صفحه × ۴ دستگاه)، `public_audit` (۲۵ صفحه × ۴ دستگاه)، `bench_1000`، `bench_load`، `bench_panel`، `qa_*`.
- `tools/seed_demo.py` دادهٔ نمایشی می‌سازد (۱۰ کسب‌وکار + نظر/پرسش/کاتالوگ/رویداد/بنر/استوری) و با `--clear` کامل پاک می‌شود؛ `tools/fixtures/` فقط کلیدهای RSA تستی دارد.
- **دو دسته رد شدنِ محیطی** (خرابی کد نیستند): (۱) نبود سرور زنده/دادهٔ seed/`BZ_DATA_DIR` مشترک، (۲) نبود Playwright+Chromium.

## ۸) پروتکل تغییر

۱. قابلیت/رفع را در `WHATS-NEW.md` (قابلیت‌های جاری) و در صورت نیاز در `KNOWLEDGE.md` ثبت کن.
۲. تغییر + تست مرتبط را سبز کن (بدون خروجی واقعی، ادعای «درست شد» ممنوع).
۳. باتری کامل را اجرا کن؛ ردشدن‌های محیطی را جدا فهرست کن.
۴. بامپ نسخه در **۵ جا** (`VERSION.txt`، `site/sw.js`، سربرگ `README.md`، `DIAG_LATEST` در `server/adminbot.py`، خط اول `docs/collaboration/CURRENT-STATE.md`) + کش‌شکن `?vNNN` در `ui.py`.
۵. زیپ کامل بدون `data/` و بدون عکس‌های `admin-*.png` + sha256 + بازدانلود و مقایسهٔ بایت‌به‌بایت.
۶. اسناد (این فایل + `docs/FILE-MAP.md` با `tools/build_filemap.py`/`routemap.py`) به‌روز.
۷. نصب یک‌فرمانی با `deploy/update.sh` و تأیید با «تشخیص» در بات مدیر. ریپو: `rezadb369-wq/369`.
