#!/usr/bin/env bash
# v293: اعمال گیت فعال‌سازی ربات مدیر (deploy/gate.env) روی فایل رازها —
# همهٔ خط‌های BOT_GATE_* قبلی را کامل حذف و مقدارهای تازه را می‌گذارد؛
# بقیهٔ خط‌ها (توکن بات، مغز هوش و…) دست‌نخورده می‌مانند. idempotent با stamp.
# قابل تست: مسیرها با DASTGIR_APP / DASTGIR_SECRETS قابل تغییرند.
set -euo pipefail
APP="${DASTGIR_APP:-/opt/dastgir}"
SECRETS="${DASTGIR_SECRETS:-/etc/dastgir-secrets.env}"
GATE="$APP/deploy/gate.env"
[ -f "$GATE" ] || exit 0
H="$(sha256sum "$GATE" | cut -d' ' -f1)"
STAMP="$SECRETS.gate-stamp"
if [ "$(cat "$STAMP" 2>/dev/null || true)" = "$H" ]; then exit 0; fi
if [ -f "$SECRETS" ]; then cp -f "$SECRETS" "$SECRETS.bak"; fi
touch "$SECRETS"
grep -v '^BOT_GATE_' "$SECRETS" > "$SECRETS.new" || true
cat "$GATE" >> "$SECRETS.new"
mv -f "$SECRETS.new" "$SECRETS"
chmod 600 "$SECRETS"
rm -f "$SECRETS.bak"
printf '%s\n' "$H" > "$STAMP"
chmod 600 "$STAMP"
echo "گیت فعال‌سازی ربات بله (شماره+رمز) نصب شد."
