# AGENTS.md

Workspace = `/opt/dastgir` (کد زندهٔ سایت).

قبل از ویرایش کد: فایل را بخوان، بعد ویرایش دقیق. استقرار از مسیر codeguard
سایت (`deploy/codeguard.sh`) می‌گذرد اگر از بات مدیر `code_edit` بدهی.

محتوای سایت (کسب‌وکار، تنظیم، صفحه) را با ابزارهای بات مدیر عوض کن
(`business_save` / `business_delete` / `businesses_wipe` / `setting`).
sqlite3 و DELETE FROM برای محتوا ممنوع است. نوشتن = توضیح فارسی + تأیید مالک.

مهارت‌ها:
- `dastgir-panel-access` — نشانی و وضعیت پنل
- `dastgir-site-data` — تصویر زندهٔ محتوا (بدون راز)
