# dastgir-panel-access

When the owner asks for the admin panel, agent console, or
`/dastgir_panel_access`:

- Agent console (command): `https://daastgir.ir/agent`
- Admin panel (under the agent): `https://daastgir.ir/panel`
- Panel-embedded agent: `https://daastgir.ir/panel/agent`

From v318 the admin panel is subordinate to the agent. Login is the
owner cookie, owner email, or a one-time key from the Bale admin bot.

If `site_url` in settings differs, use that origin. Never paste tokens.
