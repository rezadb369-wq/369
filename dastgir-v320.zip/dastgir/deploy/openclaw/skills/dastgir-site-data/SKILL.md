# dastgir-site-data

When the owner asks for live site data or `/dastgir_site_data`:

Read, don't guess:

- Settings: SQLite `settings` (skip keys matching token/secret/pass/key/hash)
- Counts: businesses, items, orders, customers
- Collaboration docs: `docs/collaboration/CURRENT-STATE.md`, `RULES.md`, `KNOWLEDGE.md`
- Version pin: `VERSION.txt`

If running inside the dastgir tree, `python3 -c "import adminbot_content as C; print(C.content_inventory())"` from `server/` after `BZ_DATA_DIR` is set.

Never dump `/etc/dastgir-secrets.env` or `deploy/brain.env`.
