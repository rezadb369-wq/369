#!/usr/bin/env bash
# v318: merge OpenClaw config for the existing gateway (BALE via tapi.bale.ai).
# Never writes BALE_AGENT_TOKEN into the dastgir tree. Idempotent. Missing
# OpenClaw = skip (the in-site /agent + admin bot remain the agent).
set -euo pipefail
APP="${DASTGIR_APP:-/opt/dastgir}"
SECRETS="${DASTGIR_SECRETS:-/etc/dastgir-secrets.env}"
FRAG="$APP/deploy/openclaw/openclaw.fragment.json"
[ -f "$FRAG" ] || exit 0

# Find an existing OpenClaw config — do not create a second poller from scratch.
CFG=""
for cand in \
  "${OPENCLAW_HOME:-}/openclaw.json" \
  /root/.openclaw/openclaw.json \
  "$HOME/.openclaw/openclaw.json" \
  /home/*/.openclaw/openclaw.json
do
  [ -n "$cand" ] && [ -f "$cand" ] && CFG="$cand" && break
done
if [ -z "$CFG" ]; then
  echo "v318 openclaw: نصب OpenClaw روی این سرور پیدا نشد — رد شد (ایجنت داخلی دست‌گیر کافی است)."
  exit 0
fi

python3 - "$CFG" "$FRAG" "$SECRETS" "$APP" <<'PY'
import json, os, sys, shutil, re
cfg_path, frag_path, secrets_path, app = sys.argv[1:5]

def load(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)

def deepmerge(a, b):
    if isinstance(a, dict) and isinstance(b, dict):
        out = dict(a)
        for k, v in b.items():
            out[k] = deepmerge(out[k], v) if k in out else v
        return out
    return b

cfg = load(cfg_path)
frag = load(frag_path)

# Inject bynara apiKey from secrets (never from the fragment).
env = {}
try:
    for ln in open(secrets_path, encoding="utf-8"):
        ln = ln.strip()
        if ln and not ln.startswith("#") and "=" in ln:
            k, v = ln.split("=", 1)
            env[k.strip()] = v.strip()
except OSError:
    pass
key = env.get("AI_BRAIN_BYNARA_KEY") or env.get("AI_API_KEY") or ""
if key:
    frag.setdefault("models", {}).setdefault("providers", {}).setdefault("bynara", {})["apiKey"] = key

# Telegram/BALE token: only if the owner already put BALE_AGENT_TOKEN in secrets.
# Never invent one, never copy BALE_BOT_TOKEN / BALE_ADMIN_TOKEN.
agent_tok = env.get("BALE_AGENT_TOKEN") or ""
if agent_tok and agent_tok != env.get("BALE_BOT_TOKEN") and agent_tok != env.get("BALE_ADMIN_TOKEN"):
    frag.setdefault("channels", {}).setdefault("telegram", {})["botToken"] = agent_tok
else:
    # Keep whatever token OpenClaw already has; just fix apiRoot / native.
    frag.get("channels", {}).get("telegram", {}).pop("botToken", None)

merged = deepmerge(cfg, frag)
# Hard constraints for BALE (override even if the old config disagreed).
tg = merged.setdefault("channels", {}).setdefault("telegram", {})
tg["apiRoot"] = "https://tapi.bale.ai"
tg["streamMode"] = "off"
tg["reactionNotifications"] = "off"
merged.setdefault("commands", {})["native"] = False
merged.setdefault("agents", {}).setdefault("defaults", {}).setdefault("sandbox", {})["mode"] = "off"
merged.setdefault("tools", {}).setdefault("elevated", {})["enabled"] = True
merged.setdefault("agents", {}).setdefault("defaults", {})["model"] = {
    "primary": "bynara/ling-3.0-flash-sante-free"
}
# Workspace = the live site so file/exec tools see daastgir.
merged.setdefault("agents", {}).setdefault("defaults", {})["workspace"] = app

bak = cfg_path + ".bak-v318"
if not os.path.exists(bak):
    shutil.copy2(cfg_path, bak)
tmp = cfg_path + ".tmp"
with open(tmp, "w", encoding="utf-8") as f:
    json.dump(merged, f, ensure_ascii=False, indent=2)
    f.write("\n")
os.replace(tmp, cfg_path)
print("v318 openclaw: ادغام شد →", cfg_path)

# Copy identity + skills next to the config's workspace.
home = os.path.dirname(cfg_path)
ws = os.path.join(home, "workspace")
os.makedirs(ws, exist_ok=True)
src_ws = os.path.join(app, "deploy", "openclaw", "workspace")
if os.path.isdir(src_ws):
    for fn in os.listdir(src_ws):
        shutil.copy2(os.path.join(src_ws, fn), os.path.join(ws, fn))
sk_src = os.path.join(app, "deploy", "openclaw", "skills")
sk_dst = os.path.join(ws, "skills")
if os.path.isdir(sk_src):
    os.makedirs(sk_dst, exist_ok=True)
    for name in os.listdir(sk_src):
        s = os.path.join(sk_src, name)
        d = os.path.join(sk_dst, name)
        if os.path.isdir(s):
            os.makedirs(d, exist_ok=True)
            for fn in os.listdir(s):
                shutil.copy2(os.path.join(s, fn), os.path.join(d, fn))
print("v318 openclaw: IDENTITY/skills در", ws)
PY

# Best-effort restart of a running gateway — never fail the site install.
if command -v openclaw >/dev/null 2>&1; then
  openclaw gateway restart >/dev/null 2>&1 || true
fi
if command -v systemctl >/dev/null 2>&1; then
  systemctl try-restart openclaw >/dev/null 2>&1 || true
  systemctl try-restart clawdbot >/dev/null 2>&1 || true
fi
echo "v318 openclaw: apply تمام شد."
