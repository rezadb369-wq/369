# OpenClaw روی بله — بدون توکن در بستهٔ سایت

v318. ایجنت بله‌ای که فقط سلام می‌دهد OpenClaw است (همان getUpdates را
گرفته). این پوشه **توکن ایجنت را ذخیره نمی‌کند**. توکن را خودت در
`/etc/dastgir-secrets.env` با نام `BALE_AGENT_TOKEN` بگذار اگر خواستی
کانال تلگرام/بله در کانفیگ نوشته شود.

```
BALE_AGENT_TOKEN=...     # فقط در رازهای سرور، نه در zip سایت
```

`update.sh` در پایان نصب `apply-openclaw.sh` را صدا می‌زند:

1. اگر `~/.openclaw/openclaw.json` (یا `/root/.openclaw`) باشد، ادغام می‌شود:
   - `channels.telegram.apiRoot = https://tapi.bale.ai` (بدون `/bot`)
   - `commands.native = false` (بله setMyCommands ندارد)
   - `streamMode = off`
   - sandbox off + tools.elevated
   - مدل: `bynara/ling-3.0-flash-sante-free` با کلید `AI_BRAIN_BYNARA_KEY`
2. مهارت‌ها و IDENTITY به workspace کپی می‌شوند.
3. اگر OpenClaw نصب نباشد، هیچ پالری ساخته نمی‌شود — ایجنت داخلی
   دست‌گیر (`/agent` و بات مدیر) کار می‌کند.

هرگز `api.telegram.org` را برای این توکن نگذار. هرگز `BALE_BOT_TOKEN` /
`BALE_ADMIN_TOKEN` را عوض نکن.
