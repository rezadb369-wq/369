# -*- coding: utf-8 -*-
"""
v310 — ترمینال بله + مغز هر پیام + ابزارهای جدید ایجنت (دستور مدیر).

دستورهای مدیر (۲۰۲۶-۰۹-۲۰):
- «کدهایی که تو ترموکس می‌زدم همان را در بله بزنم و واقعاً کار کند — بدون هوش»
- «بخش ایجنت مغز ایجنت بشه تغییر داد»
- «قسمت اجرای فوری ابزار به فارسی باشه»
- «چت ایجنت کامل کار کنه و مغزشم بشه تنظیم کرد»

دو بخش: (الف) سطح تابع — بات/ابزارها/مغز (مثل سوئیت‌های adminbot)؛
(ب) سرور زنده — کنسول، اجرا، چت، صندوق فایل.

اجرا:
  python3 tools/test_agent_tools_v310.py                 # بخش الف
  BZ_DATA_DIR=/tmp/x BZ=http://127.0.0.1:8097 python3 tools/test_agent_tools_v310.py   # الف+ب
"""
import json
import os
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")

G, R, X = "\033[32m", "\033[31m", "\033[0m"
n = 0
fails = []


def ck(ok, label):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        print("  " + R + "✗ " + label + X)


# ============ بخش الف — سطح تابع ============
TMP = tempfile.mkdtemp(prefix="agent-v310-")
os.environ["BZ_DATA_DIR"] = os.environ.get("BZ_DATA_DIR", TMP)
os.environ["BALE_ADMIN_TOKEN"] = "test-token-not-real"
os.environ["BALE_ADMIN_SECRET"] = "s" * 40
os.environ["BALE_ADMIN_CHAT"] = "893219571"
os.environ["ADMINBOT_QUEUE"] = os.path.join(TMP, "q")
os.environ["ADMINBOT_PENDING"] = os.path.join(TMP, "pending.json")
os.environ["ADMINBOT_MEMORY"] = os.path.join(TMP, "mem.json")
os.environ["ADMINBOT_IMAGE"] = os.path.join(TMP, "image.json")
os.environ["ADMINBOT_CODE"] = os.path.join(TMP, "code.json")
os.environ["AI_BRAIN_OPUS_KEY"] = "aa-opus" + "o" * 40
os.environ["AI_BRAIN_SONNET_KEY"] = "aa-sonnet" + "s" * 38
os.environ["AI_BRAIN_GLM_KEY"] = "aa-glmkey" + "g" * 36
sys.path.insert(0, os.path.join(ROOT, "server"))
import db                     # noqa: E402
import adminbot as A          # noqa: E402
import adminbot_content as CT # noqa: E402
import assistant as AI        # noqa: E402

db.init()
CHAT = "893219571"

print("v310 — بخش الف: ترمینال بله + ابزارها + مغز (سطح تابع)")

# ۱) sh مستقیم — بدون هوش
rep, _ = A.handle_text("u1", CHAT, "sh echo سلام-۳۱۰")
ck("سلام-۳۱۰" in rep and "کد خروج: 0" in rep, "sh echo — خروجی واقعی + کد خروج ۰")

# ۲) فقط چت تیم
rep, _ = A.handle_text("u1", "999888", "sh echo leak")
ck("leak" not in (rep or ""), "چت غیرتیم = DENIED (فرمان اجرا نشد)")

# ۳) sh خالی = راهنما
rep, _ = A.handle_text("u1", CHAT, "sh")
ck("ترمینال بله" in rep and "sh bg" in rep, "sh خالی = راهنمای ترمینال")

# ۴) redact راز در خروجی
rep, _ = A.handle_text("u1", CHAT, "sh echo aa-0123456789abcdefghij")
ck("مقدار پنهان" in rep and "aa-0123456789abcdefghij" not in rep,
   "راز در خروجی ترمینال redact می‌شود")

# ۵) sh bg — پس‌زمینه
bgf = os.path.join(TMP, "bgfile")
rep, _ = A.handle_text("u1", CHAT, "sh bg touch " + bgf)
import time as _tm
_tm.sleep(0.7)
ck("پس‌زمینه" in rep and os.path.exists(bgf), "sh bg — اجرا در پس‌زمینه واقعاً انجام شد")

# ۶) ابزار shell_exec
ok, msg = CT.tool_execute("shell_exec", {"cmd": "echo t310tool"})
ck(ok and "t310tool" in str(msg), "ابزار shell_exec — خروجی واقعی")

# ۷) sql_read — خواندنی کار می‌کند، نوشتنی رد می‌شود
ok, msg = CT.tool_execute("sql_read", {"q": "SELECT COUNT(*) AS n FROM settings"})
ck(ok and "ردیف" in str(msg), "ابزار sql_read — SELECT اجرا شد")
ok, msg = CT.tool_execute("sql_read", {"q": "UPDATE settings SET value='x'"})
ck(not ok, "sql_read — نوشتن رد می‌شود (صادقانه)")

# ۸) log_tail — اجرا یا پیام صادقانه
ok, msg = CT.tool_execute("log_tail", {"n": 5})
ck(bool(str(msg).strip()) and (ok or "journalctl" in str(msg)),
   "ابزار log_tail — اجرا یا پیام صادقانه")

# ۹) IMMEDIATE — shell عمدی غیرفوری، خواندنی‌ها فوری
ck("shell_exec" not in CT.IMMEDIATE_TOOLS, "shell_exec غیرفوری است (از چت هوش با «بله»)")
ck("sql_read" in CT.IMMEDIATE_TOOLS and "log_tail" in CT.IMMEDIATE_TOOLS,
   "sql_read/log_tail فوری‌اند (خواندنی)")

# ۱۰) alias فارسی/انگلیسی
tl, ta = CT.parse_tool_call({"name": "ترمینال", "args": {"cmd": "ls"}})
ck(tl == "shell_exec" and ta.get("cmd") == "ls", "alias «ترمینال» → shell_exec")

# ۱۱) مغز هر پیام — اوراید thread-local
AI.set_brain_override("opus")
b1 = AI.config().get("brain")
AI.set_brain_override("bogus")
b2 = AI.config().get("brain")
AI.clear_brain_override()
b3 = AI.config().get("brain")
ck(b1 == "opus", "اوراید مغز = opus برای همان درخواست")
ck(b2 != "opus" and b3 == AI.active_brain(), "نام نامعتبر نادیده + پاک‌سازی = مغز فعال")

# ۱۲) برچسب فارسی همهٔ ابزارها
import views_agent_full as VAF
missing = [t for t in CT.TOOLS if t not in VAF.TOOL_FA]
ck(not missing, "TOOL_FA همهٔ %d ابزار را پوشش می‌دهد%s" % (len(CT.TOOLS), (" — کم: " + ",".join(missing)) if missing else ""))

# ۱۳) صفحه‌کلید — دکمهٔ ترمینال، ۱۰ ردیف (پین v271)
rows = A.KEYBOARD["keyboard"]
flat = [b for row in rows for b in row]
ck("ترمینال" in flat and "ایجنت" in flat and len(rows) == 10,
   "صفحه‌کلید: ترمینال+ایجنت دیده‌شدنی، ۱۰ ردیف حفظ شد")

print()

# ============ بخش ب — سرور زنده ============
BASE = (os.environ.get("BZ") or "").rstrip("/")
if BASE:
    print("v310 — بخش ب: کنسول زنده (%s)" % BASE)
    KEY = db.owner_token()
    ow = db.owner_by_phone("09120310310", create=True)
    sess = db.session_new(ow["id"])

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None

    def req(path, data=None, cookies=None, ctype=None, raw=None):
        o = urllib.request.build_opener(NoRedirect)
        hdrs = {"User-Agent": "bz-test", "Sec-Fetch-Site": "same-origin", "Origin": BASE}
        if cookies:
            hdrs["Cookie"] = "; ".join("%s=%s" % kv for kv in cookies.items())
        if ctype:
            hdrs["Content-Type"] = ctype
        r = urllib.request.Request(BASE + path, data=(raw if raw is not None else data),
                                   headers=hdrs, method="POST" if (data is not None or raw is not None) else "GET")
        try:
            resp = o.open(r, timeout=60)
            return resp.status, resp.read().decode("utf-8", "replace"), resp.headers
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace"), (e.headers or {})

    OWN = {"bzv2_sess": sess}

    # ۱۴) کنسول: چیپ مغز + برچسب فارسی + صندوق فایل
    st, body, _ = req("/agent?key=" + urllib.parse.quote(KEY))
    ck(st == 200 and 'data-model="opus"' in body and 'data-model="glm"' in body,
       "کنسول: چیپ‌های مغز واقعی (اپوس/GLM) دیده می‌شوند")
    ck("🖥️ اجرای فرمان" in body and "🗄️ پرس‌وجوی خواندنی" in body,
       "کنسول: منوی ابزار فارسی است")
    ck("تبادل فایل ایجنت" in body, "کنسول: صندوق تبادل فایل دیده‌شدنی است")

    # ۱۵) اجرای shell_exec از کنسول با نشست مالک
    body_f = urllib.parse.urlencode({"tool": "shell_exec", "args": json.dumps({"cmd": "echo t310web"})}).encode()
    st, b2, hd = req("/agent/exec", data=body_f, cookies=OWN,
                     ctype="application/x-www-form-urlencoded")
    loc = hd.get("Location") or ""
    ck(st in (302, 303) and "t310web" in urllib.parse.unquote(loc),
       "اجرای shell_exec از کنسول = خروجی واقعی در پیام")

    # ۱۶) چت با مغز انتخابی — آفلاین و glm (بدون کلید = صادقانه، ولی ok)
    st, b3, _ = req("/api/agent/chat", cookies=OWN, ctype="application/json",
                    raw=json.dumps({"text": "سلام", "model": "offline"}).encode())
    try:
        j = json.loads(b3)
    except Exception:
        j = {}
    ck(st == 200 and j.get("ok") is True, "چت آفلاین با نشست مالک = ۲۰۰")
    st, b4, _ = req("/api/agent/chat", cookies=OWN, ctype="application/json",
                    raw=json.dumps({"text": "سلام", "model": "glm"}).encode())
    try:
        j2 = json.loads(b4)
    except Exception:
        j2 = {}
    ck(st == 200 and j2.get("ok") is True and j2.get("brain") == "glm",
       "چت با چیپ glm = مغز همان پیام (فیلد brain)")

    # ۱۷) صندوق فایل — آپلود multipart + دانلود
    boundary = "----bz310b"
    content = b"v310-exchange-test"
    raw = (("--%s\r\nContent-Disposition: form-data; name=\"file\"; filename=\"t310.txt\"\r\n"
            "Content-Type: text/plain\r\n\r\n") % boundary).encode() + content + \
          ("\r\n--%s--\r\n" % boundary).encode()
    st, b5, hd = req("/agent/upload", cookies=OWN, raw=raw,
                     ctype="multipart/form-data; boundary=" + boundary)
    loc = urllib.parse.unquote(hd.get("Location") or "")
    ck(st in (302, 303) and "ok=" in loc, "آپلود از کنسول = ذخیره + بازگشت به مبدأ")
    st, b6, _ = req("/agent/file/t310.txt", cookies=OWN)
    ck(st == 200 and b6 == content.decode(), "دانلود فایل تبادل = بایت‌به‌بایت همان محتوا")

    # ۱۸) نسخهٔ پنلی هم چیپ فارسی دارد
    st, b7, _ = req("/panel/agent?key=" + urllib.parse.quote(KEY))
    ck(st == 200 and 'data-model="opus"' in b7 and "🖥️ اجرای فرمان" in b7,
       "/panel/agent هم چیپ مغز + منوی فارسی دارد")
    print()

if fails:
    print(R + "FAIL" + X + " %d: " % len(fails) + " · ".join(fails))
    sys.exit(1)
print(G + "PASS" + X + " %d بررسی — v310 سبز است." % n)
