#!/usr/bin/env bash
# Atomic-style clean update from a full Dastgir ZIP; runtime data is preserved.
set -euo pipefail
ZIP="${1:-}";APP=/opt/dastgir;BACKUPS=/var/backups/dastgir
[ "$(id -u)" -eq 0 ] || { echo 'با sudo اجرا کنید.' >&2;exit 1; }
[ -f "$ZIP" ] || { echo 'روش: sudo bash /opt/dastgir/deploy/update.sh /tmp/dastgir-vNNN.zip' >&2;exit 1; }
for x in unzip rsync python3;do command -v "$x" >/dev/null || { echo "$x نصب نیست." >&2;exit 1; };done
TMP=$(mktemp -d /tmp/dastgir-update.XXXXXX);stopped=0
cleanup(){ rm -rf "$TMP";if [ "$stopped" = 1 ];then systemctl start bazarche >/dev/null 2>&1 || true;fi; }
trap cleanup EXIT
unzip -q "$ZIP" -d "$TMP"
# v302: support 3 layouts — dastgir/ (standard), site/ (agent workspace), root (legacy)
SRC=""
if [ -f "$TMP/dastgir/run.py" ] && [ -f "$TMP/dastgir/VERSION.txt" ]; then
  SRC="$TMP/dastgir"
elif [ -f "$TMP/site/run.py" ] && [ -f "$TMP/site/VERSION.txt" ]; then
  SRC="$TMP/site"
  # also if it was zipped as site/site/... handle nested
  if [ -f "$TMP/site/site/run.py" ]; then
    SRC="$TMP/site/site/.."
    # actually site folder contains site subfolder? normalize to site root
    SRC="$TMP/site"
  fi
elif [ -f "$TMP/run.py" ] && [ -f "$TMP/VERSION.txt" ]; then
  SRC="$TMP"
elif [ -f "$TMP/dastgir/site/run.py" ]; then
  SRC="$TMP/dastgir"
else
  echo 'ساختار ZIP نامعتبر است.' >&2;exit 1
fi
# if SRC is $TMP/site which itself contains site/ subdir, we need to rsync from SRC, but APP expects same layout as /opt/dastgir (which has server/, site/, etc.)
# So if SRC ends with /site and contains server/, it's actually already the app root (site zip with site/ prefix means APP root is $TMP/site, not $TMP)
# The above detection already sets SRC correctly.
unzip -t "$ZIP" >/dev/null
mkdir -p "$BACKUPS" "$APP/data" "$APP/site/assets/img/uploads"
if [ -f "$APP/tools/backup.py" ] && [ -f "$APP/data/bazarche.db" ];then
  python3 "$APP/tools/backup.py" --dir "$BACKUPS" --no-rotate
fi
systemctl stop bazarche;stopped=1
# rsync needs rsync or fallback to cp -a
if command -v rsync >/dev/null; then
  rsync -a --delete \
    --exclude '/data/' --exclude '/site/assets/img/uploads/' --exclude '/site/assets/chat-files/' --exclude '/data/agent-exchange/' --exclude '/data/arena-bridge/' \
    "$SRC/" "$APP/"
else
  # fallback cp
  cp -a "$SRC/." "$APP/"
  rm -rf "$APP/data/bazarche.db-shm" "$APP/data/bazarche.db-wal" 2>/dev/null || true
fi
mkdir -p "$APP/data/chat-files" "$APP/site/assets/img/uploads" "$APP/data/code-jobs" "$APP/data/code-backups" "$APP/data/agent-exchange" "$APP/data/arena-bridge"
# v241: root-side codeguard cron (applies admin-AI code edits safely).
if [ -f "$APP/deploy/codeguard.sh" ]; then
  chmod 0755 "$APP/deploy/codeguard.sh"
  if [ ! -f /etc/cron.d/dastgir-codeguard ]; then
    printf '%s\n' '* * * * * root /bin/bash /opt/dastgir/deploy/codeguard.sh >/dev/null 2>&1' > /etc/cron.d/dastgir-codeguard
    chmod 0644 /etc/cron.d/dastgir-codeguard
    echo "کرون کدگارد نصب شد."
  fi
fi
chown -R www-data:www-data "$APP"
install -m 0644 "$APP/deploy/bazarche.service" /etc/systemd/system/bazarche.service
systemctl daemon-reload
# v253: مغز پخته‌شدهٔ بسته (deploy/brain.env) — کلید هوش مصنوعی همراه همین
# نصب اعمال می‌شود؛ همهٔ AI_* قبلی حذف و سرویس پایین همین اسکریپت با آن بالا می‌آید.
if [ -f "$APP/deploy/brain.env" ]; then
  bash "$APP/deploy/apply-brain.sh"
fi
# v293: گیت فعال‌سازی ربات مدیر بله (شماره+رمز) — همراه نصب اعمال می‌شود.
if [ -f "$APP/deploy/gate.env" ]; then
  bash "$APP/deploy/apply-gate.sh"
fi
systemctl start bazarche;stopped=0
sleep 2
systemctl is-active --quiet bazarche
curl -fsS http://127.0.0.1:8080/healthz >/dev/null
echo "نسخه $(cat "$APP/VERSION.txt") با موفقیت نصب شد."
