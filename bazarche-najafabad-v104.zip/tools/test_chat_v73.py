#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v73 messenger chat regression/security suite.

The suite grows task-by-task. It is deliberately self-contained and removes
all rows/files it creates, so it can run before or after every other battery.
"""

import base64
import io
import json
import os
import sys
import zipfile
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "server"))

import db  # noqa: E402
import uploads  # noqa: E402

PASS = []
FAIL = []
PREFIX = "v73-chat-probe"
PHONE_C = "09129997301"
PHONE_O = "09129997302"
PHONE_C2 = "09129997303"
PHONE_O2 = "09129997304"
BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")

# Real 1x1 transparent PNG, not a made-up signature-only payload.
PNG_1PX = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk"
    "YAAAAAYAAjCB0C8AAAAASUVORK5CYII="
)
PDF_MIN = b"%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n"


def check(label, condition, detail=""):
    if condition:
        PASS.append(label)
        print("  ✓", label)
    else:
        FAIL.append((label, detail))
        print("  ✗", label, (f"[{detail}]" if detail else ""))


def table_columns(table):
    con = db.connect()
    try:
        return {r["name"] for r in con.execute(f"PRAGMA table_info({table})")}
    finally:
        con.close()


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def request(path, method="GET", data=None, cookie="", headers=None):
    hdr = {"User-Agent": "bazarche-v73-chat-test", **(headers or {})}
    if cookie:
        hdr["Cookie"] = cookie
    req = urllib.request.Request(BASE + path, data=data, method=method, headers=hdr)
    opener = urllib.request.build_opener(NoRedirect())
    try:
        res = opener.open(req, timeout=30)
        return res.status, dict(res.headers), res.read()
    except urllib.error.HTTPError as exc:
        return exc.code, dict(exc.headers), exc.read()


def multipart(fields, file_field=None, filename="", payload=b""):
    boundary = "----BazarcheV73Boundary"
    chunks = []
    for key, value in fields.items():
        chunks.append(
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"{key}\"\r\n\r\n"
            f"{value}\r\n".encode("utf-8"))
    if file_field:
        chunks.append(
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"{file_field}\"; "
            f"filename=\"{filename}\"\r\nContent-Type: application/octet-stream\r\n\r\n".encode("utf-8")
            + payload + b"\r\n")
    chunks.append(f"--{boundary}--\r\n".encode())
    return b"".join(chunks), {"Content-Type": f"multipart/form-data; boundary={boundary}"}


def cleanup():
    con = db.connect()
    try:
        rows = con.execute(
            "SELECT id FROM businesses WHERE name LIKE ?", (PREFIX + "%",)
        ).fetchall()
        stored = [r["stored_name"] for r in con.execute(
            "SELECT a.stored_name FROM chat_attachments a "
            "JOIN chat_messages m ON m.id=a.message_id "
            "JOIN chat_threads t ON t.id=m.thread_id "
            "JOIN businesses b ON b.id=t.biz_id WHERE b.name LIKE ?",
            (PREFIX + "%",))]
    finally:
        con.close()
    for name in stored:
        if hasattr(uploads, "delete_chat_file"):
            uploads.delete_chat_file(name)
    for row in rows:
        db.delete_business(row["id"])
    for phone in (PHONE_C, PHONE_O, PHONE_C2, PHONE_O2):
        customer = db.customer_by_phone(phone)
        if customer:
            db.customer_delete(customer["id"])
        owner = db.owner_by_phone(phone)
        if owner:
            db.delete_owner(owner["id"])
    chat_dir = getattr(uploads, "CHAT_UPLOAD_DIR", "")
    if chat_dir and os.path.isdir(chat_dir):
        for name in os.listdir(chat_dir):
            if name.startswith(PREFIX):
                try:
                    os.remove(os.path.join(chat_dir, name))
                except OSError:
                    pass


def task1_schema_storage_data():
    print("\n══ ۱) ساختار داده، فایل خصوصی و خوانده‌نشده ══")
    db.init()

    tcols = table_columns("chat_threads")
    acols = table_columns("chat_attachments")
    check("جدول پیوست گفتگو ساخته شده", bool(acols), str(sorted(acols)))
    check("ستون‌های read cursor وجود دارند",
          {"customer_read_to", "owner_read_to", "admin_read_to"} <= tcols,
          str(sorted(tcols)))
    check("ساختار پیوست کامل است",
          {"message_id", "stored_name", "original_name", "mime", "size", "kind"} <= acols,
          str(sorted(acols)))

    check("ذخیره‌ساز فایل چت وجود دارد", hasattr(uploads, "save_chat_file"))
    check("خواندن فایل خصوصی وجود دارد", hasattr(uploads, "read_chat_file"))
    check("حذف فایل خصوصی وجود دارد", hasattr(uploads, "delete_chat_file"))
    check("GC فایل خصوصی وجود دارد", hasattr(uploads, "gc_chat_files"))

    saved = None
    if hasattr(uploads, "save_chat_file"):
        saved, err = uploads.save_chat_file(PNG_1PX, "../تصویر<script>.png", prefix=PREFIX)
        check("PNG واقعی پذیرفته شد", bool(saved) and not err, str(err))
        if saved:
            check("فایل بیرون web root ذخیره شد",
                  os.path.commonpath([saved["full_path"], os.path.join(ROOT, "data")])
                  == os.path.join(ROOT, "data"), saved["full_path"])
            check("نام اصلی مسیر ذخیره نیست",
                  "تصویر" not in saved["stored_name"] and ".." not in saved["stored_name"],
                  saved["stored_name"])
            check("نام نمایشی کنترل و محدود شده",
                  "<" not in saved["original_name"] and ">" not in saved["original_name"]
                  and len(saved["original_name"]) <= 120,
                  saved["original_name"])
            check("نوع فایل از بایت تشخیص داده شد",
                  saved["mime"] == "image/png" and saved["kind"] == "image", str(saved))

        pdf, err = uploads.save_chat_file(PDF_MIN, "سند.pdf", prefix=PREFIX)
        check("PDF رد می‌شود (پیوست فقط عکس)", pdf is None and bool(err), str((pdf, err)))
        txt, err = uploads.save_chat_file("سلام بازارچه".encode(), "notes.txt", prefix=PREFIX)
        check("متن رد می‌شود (پیوست فقط عکس)", txt is None and bool(err), str((txt, err)))
        bad, err = uploads.save_chat_file(b"<?php echo 1;?>", "evil.php.jpg", prefix=PREFIX)
        check("فایل اجرایی با پسوند جعلی رد شد", bad is None and bool(err), str((bad, err)))
        poly, err = uploads.save_chat_file(
            b"\x89PNG\r\n\x1a\n<?php echo 'polyglot';?>", "polyglot.png", prefix=PREFIX)
        check("امضای PNG بدون ساختار واقعی تصویر رد می‌شود",
              poly is None and bool(err), str((poly, err)))
        svg, err = uploads.save_chat_file(b"<svg><script>alert(1)</script></svg>", "x.svg",
                                          prefix=PREFIX)
        check("SVG/HTML رد شد", svg is None and bool(err), str((svg, err)))

    # Existing text behavior must now return a real message id and support read state.
    category = db.categories(only_active=True)[0]
    owner = db.owner_by_phone(PHONE_O, create=True)
    customer = db.customer_by_phone(PHONE_C, create=True)
    bid = db.save_business({
        "name": PREFIX + "-shop",
        "cat_slug": category["slug"],
        "phone": PHONE_O,
        "status": "published",
        "owner_id": owner["id"],
    })
    tid = db.chat_start(bid, customer["id"], "گفتگوی آزمون v73")
    mid = db.chat_send(tid, "customer", "سلام")
    check("chat_send شناسهٔ عددی واقعی می‌دهد", type(mid) is int and mid > 0, repr(mid))
    check("پیام کاملاً خالی رد می‌شود", db.chat_send(tid, "customer", "") is None,
          repr(db.chat_send(tid, "customer", "")))
    check("تابع علامت‌گذاری خوانده‌شده وجود دارد", hasattr(db, "chat_mark_read"))
    check("تابع شمارش خوانده‌نشده وجود دارد", hasattr(db, "chat_unread_count"))
    if hasattr(db, "chat_unread_count") and hasattr(db, "chat_mark_read"):
        check("پیام مشتری برای دکان‌دار خوانده‌نشده است",
              db.chat_unread_count(tid, "owner") == 1,
              str(db.chat_unread_count(tid, "owner")))
        db.chat_mark_read(tid, "owner")
        check("با دیدن دکان‌دار شمارنده صفر می‌شود",
              db.chat_unread_count(tid, "owner") == 0,
              str(db.chat_unread_count(tid, "owner")))

    if saved and type(mid) is int:
        # The route will pass this metadata object to the DB layer in Task 2.
        amsg = db.chat_send(tid, "owner", "", attachment=saved)
        check("پیام فقط‌فایل ثبت می‌شود", type(amsg) is int and amsg > mid, repr(amsg))
        messages = db.chat_messages(tid)
        last = messages[-1] if messages else {}
        check("متادیتای عمومی پیوست با پیام برمی‌گردد",
              last.get("attachment_id") and last.get("file_name")
              and last.get("file_kind") == "image", str(last))
        check("نام ذخیرهٔ داخلی از پیام عمومی نشت نمی‌کند",
              "stored_name" not in last and "full_path" not in last, str(last))


def task2_http_security():
    print("\n══ ۲) مسیرهای امن ارسال، polling، دانلود و کنترل مدیر ══")
    db.rate_clear()
    customer = db.customer_by_phone(PHONE_C)
    owner = db.owner_by_phone(PHONE_O)
    shop = next((b for b in db.businesses(status=None)
                 if b["name"] == PREFIX + "-shop"), None)
    con = db.connect()
    try:
        thread = con.execute(
            "SELECT * FROM chat_threads WHERE biz_id=? AND customer_id=?",
            (shop["id"], customer["id"])).fetchone() if shop and customer else None
    finally:
        con.close()
    check("fixture اصلی گفتگو آماده است", bool(thread), str(thread))
    if not thread:
        return
    tid = thread["id"]
    messages = db.chat_messages(tid)
    attachment_id = next((m.get("attachment_id") for m in messages
                          if m.get("attachment_id")), None)
    check("پیوست پایه برای آزمون دانلود وجود دارد", bool(attachment_id), str(messages))

    category = db.categories(only_active=True)[0]
    owner2 = db.owner_by_phone(PHONE_O2, create=True)
    customer2 = db.customer_by_phone(PHONE_C2, create=True)
    bid2 = db.save_business({
        "name": PREFIX + "-foreign-shop", "cat_slug": category["slug"],
        "phone": PHONE_O2, "status": "published", "owner_id": owner2["id"],
    })
    db.chat_start(bid2, customer2["id"], "گفتگوی خارجی")

    cust_cookie = "bzv2_cust=" + db.customer_session_new(customer["id"])
    cust2_cookie = "bzv2_cust=" + db.customer_session_new(customer2["id"])
    owner_cookie = "bzv2_sess=" + db.session_new(owner["id"])
    owner2_cookie = "bzv2_sess=" + db.session_new(owner2["id"])
    key = db.owner_token()

    if attachment_id:
        own = request(f"/chat-file/{attachment_id}", cookie=cust_cookie)
        foreign = request(f"/chat-file/{attachment_id}", cookie=cust2_cookie)
        owner_own = request(f"/chat-file/{attachment_id}", cookie=owner_cookie)
        owner_foreign = request(f"/chat-file/{attachment_id}", cookie=owner2_cookie)
        admin = request(f"/chat-file/{attachment_id}?key={urllib.parse.quote(key)}")
        anonymous = request(f"/chat-file/{attachment_id}")
        check("مشتری فایل گفتگوی خودش را می‌گیرد", own[0] == 200, str(own[0]))
        check("مشتری دیگر از فایل منع می‌شود", foreign[0] == 403, str(foreign[0]))
        check("دکان‌دار فایل کسب‌وکار خودش را می‌گیرد", owner_own[0] == 200,
              str(owner_own[0]))
        check("دکان‌دار دیگر از فایل منع می‌شود", owner_foreign[0] == 403,
              str(owner_foreign[0]))
        check("مدیر با کلید فایل را می‌گیرد", admin[0] == 200, str(admin[0]))
        check("کاربر ناشناس فایل را نمی‌گیرد", anonymous[0] == 403, str(anonymous[0]))
        lower_headers = {k.lower(): v for k, v in own[1].items()}
        check("فایل خصوصی cache نمی‌شود",
              lower_headers.get("cache-control") == "private, no-store",
              str(lower_headers))
        check("نوع فایل sniff شده و nosniff فعال است",
              lower_headers.get("content-type", "").startswith("image/png")
              and lower_headers.get("x-content-type-options") == "nosniff",
              str(lower_headers))

    poll_own = request(f"/api/chat/{tid}/msgs?after=0", cookie=cust_cookie)
    poll_foreign = request(f"/api/chat/{tid}/msgs?after=0", cookie=cust2_cookie)
    poll_owner = request(f"/api/chat/{tid}/msgs?after=0", cookie=owner_cookie)
    poll_owner_foreign = request(f"/api/chat/{tid}/msgs?after=0", cookie=owner2_cookie)
    poll_admin = request(
        f"/api/chat/{tid}/msgs?after=0&key={urllib.parse.quote(key)}")
    check("poll مشتری خودش مجاز است", poll_own[0] == 200, str(poll_own[0]))
    check("poll مشتری دیگر 403 است", poll_foreign[0] == 403, str(poll_foreign[0]))
    check("poll مالک خودش مجاز است", poll_owner[0] == 200, str(poll_owner[0]))
    check("poll مالک دیگر 403 است", poll_owner_foreign[0] == 403,
          str(poll_owner_foreign[0]))
    check("poll مدیر با کلید مجاز است", poll_admin[0] == 200, str(poll_admin[0]))
    check("مسیر داخلی فایل در JSON نشت نمی‌کند",
          b"stored_name" not in poll_own[2] and b"full_path" not in poll_own[2],
          poll_own[2][:200].decode("utf-8", "ignore"))

    before_msgs = db.db_chat_msg_ids(tid)
    before_files = len(os.listdir(getattr(uploads, "CHAT_UPLOAD_DIR", ROOT)))
    body, headers = multipart({"body": ""}, "attachment", "عکس.png", PNG_1PX)
    sent = request(f"/me/chat/{tid}", "POST", body, cust_cookie, headers)
    after_msgs = db.db_chat_msg_ids(tid)
    check("مشتری پیام فقط‌فایل را از HTTP می‌فرستد",
          sent[0] == 303 and after_msgs == before_msgs + 1,
          f"HTTP {sent[0]}, {before_msgs}->{after_msgs}")

    # Cross-thread POST must be denied before any bytes are retained.
    n0 = db.db_chat_msg_ids(tid)
    body, headers = multipart({"body": "دسترسی غیرمجاز"}, "attachment", "x.png", PNG_1PX)
    denied = request(f"/me/chat/{tid}", "POST", body, cust2_cookie, headers)
    check("ارسال مشتری دیگر رد می‌شود",
          denied[0] == 403 and db.db_chat_msg_ids(tid) == n0,
          f"HTTP {denied[0]}")

    invalid_cases = [
        ("PHP با پسوند عکس", b"<?php echo 1;?>", "evil.php.jpg"),
        ("SVG فعال", b"<svg><script>alert(1)</script></svg>", "bad.svg"),
        ("ZIP", b"PK\x03\x04" + b"x" * 20, "bad.zip"),
    ]
    for label, payload, filename in invalid_cases:
        m0 = db.db_chat_msg_ids(tid)
        f0 = len(os.listdir(uploads.CHAT_UPLOAD_DIR))
        body, headers = multipart({"body": ""}, "attachment", filename, payload)
        result = request(f"/me/chat/{tid}", "POST", body, cust_cookie, headers)
        check(label + " در HTTP رد می‌شود",
              result[0] == 303 and db.db_chat_msg_ids(tid) == m0
              and len(os.listdir(uploads.CHAT_UPLOAD_DIR)) == f0,
              f"HTTP {result[0]}")

    m0 = db.db_chat_msg_ids(tid)
    f0 = len(os.listdir(uploads.CHAT_UPLOAD_DIR))
    body, headers = multipart({"body": ""}, "attachment", "large.txt",
                              b"a" * (uploads.CHAT_MAX_FILE + 1))
    too_big = request(f"/me/chat/{tid}", "POST", body, cust_cookie, headers)
    check("فایل بزرگ بدون اثر جانبی رد می‌شود",
          too_big[0] == 303 and db.db_chat_msg_ids(tid) == m0
          and len(os.listdir(uploads.CHAT_UPLOAD_DIR)) == f0,
          f"HTTP {too_big[0]}")

    close_body = urllib.parse.urlencode({"key": key, "status": "closed"}).encode()
    close = request(f"/panel/chat/{tid}/status", "POST", close_body, "",
                    {"Content-Type": "application/x-www-form-urlencoded"})
    check("مدیر گفتگو را می‌بندد",
          close[0] == 303 and db.chat_thread(tid).get("status") == "closed",
          f"HTTP {close[0]}, {db.chat_thread(tid).get('status')}")
    bad_body = urllib.parse.urlencode({"key": key, "status": "destroyed"}).encode()
    bad_status = request(f"/panel/chat/{tid}/status", "POST", bad_body, "",
                         {"Content-Type": "application/x-www-form-urlencoded"})
    check("وضعیت نامعتبر پذیرفته نمی‌شود",
          bad_status[0] in (400, 303) and db.chat_thread(tid).get("status") == "closed",
          f"HTTP {bad_status[0]}, {db.chat_thread(tid).get('status')}")


def task3_messenger_ui():
    print("\n══ ۳) رابط پیام‌رسان مشتری و دکان‌دار ══")
    customer = db.customer_by_phone(PHONE_C)
    owner = db.owner_by_phone(PHONE_O)
    shop = next((b for b in db.businesses(status=None)
                 if b["name"] == PREFIX + "-shop"), None)
    con = db.connect()
    try:
        thread = con.execute(
            "SELECT * FROM chat_threads WHERE biz_id=? AND customer_id=?",
            (shop["id"], customer["id"])).fetchone() if shop and customer else None
    finally:
        con.close()
    check("fixture رابط پیام‌رسان آماده است", bool(thread), str(thread))
    if not thread:
        return
    tid = thread["id"]
    db.chat_send(tid, "owner", "پاسخ دکان‌دار برای رابط")
    db.chat_send(tid, "admin", "پیام شفاف مدیر بازارچه")
    xss_body = '<script id="v73-xss">window.__CHAT_XSS__=1</script>'
    db.chat_send(tid, "customer", xss_body)

    cust_cookie = "bzv2_cust=" + db.customer_session_new(customer["id"])
    owner_cookie = "bzv2_sess=" + db.session_new(owner["id"])
    key = db.owner_token()
    ccode, _, cbody = request(f"/me/chat/{tid}", cookie=cust_cookie)
    ocode, _, obody = request(f"/my/chat/{tid}", cookie=owner_cookie)
    lcode, _, lbody = request("/me/chats", cookie=cust_cookie)
    customer_html = cbody.decode("utf-8", "ignore")
    owner_html = obody.decode("utf-8", "ignore")
    list_html = lbody.decode("utf-8", "ignore")

    check("صفحهٔ چت مشتری باز می‌شود", ccode == 200, str(ccode))
    check("صفحهٔ چت دکان‌دار باز می‌شود", ocode == 200, str(ocode))
    required = (
        'data-chat-room', 'role="log"', 'aria-live="polite"',
        'enctype="multipart/form-data"', 'data-chat-compose',
        'type="file"', 'data-attach-preview', 'data-chat-new',
    )
    check("ساختار پیام‌رسان مشتری کامل است",
          all(x in customer_html for x in required),
          str([x for x in required if x not in customer_html]))
    check("ساختار پیام‌رسان دکان‌دار کامل است",
          all(x in owner_html for x in required),
          str([x for x in required if x not in owner_html]))
    accepted = "image/jpeg,image/png,image/webp,image/gif"
    check("allowlist فقط عکس در رابط روشن است",
          accepted in customer_html and "application/pdf" not in customer_html,
          "accept missing")
    check("هویت مدیر برای دو طرف شفاف است",
          "مدیر بازارچه" in customer_html and "مدیر بازارچه" in owner_html,
          "admin label missing")
    check("صندوق گفتگو ساختار پیام‌رسان دارد",
          lcode == 200 and 'data-thread-list' in list_html and 'thread-row' in list_html,
          str(lcode))
    check("مسیر ذخیرهٔ داخلی در HTML نشت نمی‌کند",
          "stored_name" not in customer_html and "chat-files" not in customer_html,
          "private path leaked")
    check("متن پیام XSS اجراشدنی رندر نمی‌شود",
          xss_body not in customer_html and '&lt;script id=&quot;v73-xss&quot;&gt;' in customer_html,
          "message body was not escaped")

    if not all(x in customer_html for x in required):
        return

    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        for width in (360, 390, 412):
            context = browser.new_context(
                viewport={"width": width, "height": 844}, locale="fa-IR",
                is_mobile=True, has_touch=True)
            # Use the same valid customer session as the HTTP checks.
            token = cust_cookie.split("=", 1)[1]
            context.add_cookies([{"name": "bzv2_cust", "value": token, "url": BASE}])
            page = context.new_page()
            errors = []
            page.on("pageerror", lambda error: errors.append(str(error)))
            page.goto(BASE + f"/me/chat/{tid}", wait_until="networkidle")
            page.wait_for_timeout(300)
            metrics = page.evaluate("""() => {
              const de = document.documentElement;
              const composer = document.querySelector('[data-chat-composer]');
              const send = document.querySelector('[data-chat-send]');
              const attach = document.querySelector('[data-attach-button]');
              const box = document.querySelector('[data-chat-room]');
              const rect = el => { const r=el.getBoundingClientRect(); return {w:r.width,h:r.height}; };
              return {overflow:de.scrollWidth-de.clientWidth,
                      composer:rect(composer), send:rect(send), attach:rect(attach), room:rect(box)};
            }""")
            check(f"{width}px: چت سرریز افقی ندارد", metrics["overflow"] <= 0,
                  str(metrics))
            check(f"{width}px: دکمه‌های composer حداقل ۴۴px هستند",
                  metrics["send"]["w"] >= 44 and metrics["send"]["h"] >= 44
                  and metrics["attach"]["w"] >= 44 and metrics["attach"]["h"] >= 44,
                  str(metrics))
            check(f"{width}px: تاریخچه فضای واقعی پیام‌رسان دارد",
                  metrics["room"]["h"] >= 280, str(metrics["room"]))

            file_input = page.locator('input[type="file"][name="attachment"]')
            file_input.set_input_files({"name": "نمونه.png", "mimeType": "image/png",
                                        "buffer": PNG_1PX})
            page.wait_for_timeout(100)
            preview = page.locator("[data-attach-preview]").inner_text()
            check(f"{width}px: پیش‌نمایش فایل انتخابی دیده می‌شود",
                  "نمونه.png" in preview, preview)
            page.locator("[data-attach-remove]").click()

            composer = page.locator("[data-chat-compose]")
            before = db.db_chat_msg_ids(tid)
            composer.fill("خط اول")
            composer.press("Shift+Enter")
            check(f"{width}px: Shift+Enter خط تازه می‌سازد و ارسال نمی‌کند",
                  "\n" in composer.input_value() and db.db_chat_msg_ids(tid) == before,
                  repr(composer.input_value()))
            composer.fill(f"پیام Enter در {width}")
            composer.press("Enter")
            page.wait_for_load_state("networkidle")
            check(f"{width}px: Enter پیام را واقعاً ارسال می‌کند",
                  db.db_chat_msg_ids(tid) == before + 1,
                  f"{before}->{db.db_chat_msg_ids(tid)}")
            check(f"{width}px: خطای جاوااسکریپت ندارد", not errors, str(errors))
            context.close()
        browser.close()


def task4_admin_control_center():
    print("\n══ ۴) مرکز کنترل همهٔ گفتگوها برای مدیر ══")
    customer = db.customer_by_phone(PHONE_C)
    customer2 = db.customer_by_phone(PHONE_C2)
    shop = next((b for b in db.businesses(status=None)
                 if b["name"] == PREFIX + "-shop"), None)
    shop2 = next((b for b in db.businesses(status=None)
                  if b["name"] == PREFIX + "-foreign-shop"), None)
    con = db.connect()
    try:
        t1 = con.execute("SELECT * FROM chat_threads WHERE biz_id=? AND customer_id=?",
                         (shop["id"], customer["id"])).fetchone() if shop and customer else None
        t2 = con.execute("SELECT * FROM chat_threads WHERE biz_id=? AND customer_id=?",
                         (shop2["id"], customer2["id"])).fetchone() if shop2 and customer2 else None
    finally:
        con.close()
    check("دو گفتگوی مستقل برای مدیر آماده است", bool(t1 and t2), str((t1, t2)))
    if not (t1 and t2):
        return
    tid, tid2 = t1["id"], t2["id"]
    db.chat_send(tid2, "customer", "پیام گفتگوی دوم برای فیلتر")
    db.chat_set_status(tid2, "closed")
    db.chat_send(tid, "customer", "پیام خوانده‌نشدهٔ مدیر")

    all_rows = db.chat_threads_all()
    search_rows = db.chat_threads_all(term=PREFIX + "-foreign-shop")
    closed_rows = db.chat_threads_all(status="closed")
    check("مدیر همهٔ گفتگوها را از داده می‌گیرد",
          {tid, tid2} <= {r["id"] for r in all_rows}, str([r["id"] for r in all_rows]))
    check("جست‌وجوی مدیر گفتگو را دقیق محدود می‌کند",
          [r["id"] for r in search_rows] == [tid2], str([r["id"] for r in search_rows]))
    check("فیلتر بسته فقط گفتگوی بسته را می‌دهد",
          tid2 in {r["id"] for r in closed_rows} and tid not in {r["id"] for r in closed_rows},
          str([r["id"] for r in closed_rows]))
    admin_row = next((r for r in all_rows if r["id"] == tid), {})
    check("پیام مشتری برای مدیر خوانده‌نشده شمرده می‌شود",
          int(admin_row.get("unread") or 0) > 0, str(admin_row.get("unread")))

    key = db.owner_token()
    exported = db.export_all()
    check("پشتیبان JSON حساب و سه جدول گفتگو را دارد",
          {"customers", "chat_threads", "chat_messages", "chat_attachments"} <= set(exported),
          str(sorted(set(exported) & {"customers", "chat_threads", "chat_messages", "chat_attachments"})))
    backup_code, _, backup_body = request(
        f"/panel/backup/full?key={urllib.parse.quote(key)}")
    try:
        backup_names = zipfile.ZipFile(io.BytesIO(backup_body)).namelist()
    except zipfile.BadZipFile:
        backup_names = []
    check("پشتیبان کامل بایت فایل خصوصی گفتگو را دارد",
          backup_code == 200 and any(name.startswith("chat-files/") for name in backup_names),
          f"HTTP {backup_code}, files={backup_names[:8]}")

    code, _, body = request(f"/panel/chats?key={urllib.parse.quote(key)}")
    page = body.decode("utf-8", "ignore")
    filtered_code, _, filtered_body = request(
        f"/panel/chats?key={urllib.parse.quote(key)}&q="
        + urllib.parse.quote(PREFIX + "-foreign-shop"))
    filtered = filtered_body.decode("utf-8", "ignore")
    detail_code, _, detail_body = request(
        f"/panel/chat/{tid}?key={urllib.parse.quote(key)}")
    detail = detail_body.decode("utf-8", "ignore")

    check("صفحهٔ همهٔ گفتگوهای مدیر باز است", code == 200, str(code))
    try:
        chat_nav = page.split('href="/panel/chats?', 1)[1].split('</a>', 1)[0]
    except IndexError:
        chat_nav = ""
    check("منوی پنل تعداد گفتگوهای نیازمند مدیر را نشان می‌دهد",
          'nav-count' in chat_nav, chat_nav[:200])
    check("کارت‌های آمار کنترل گفتگو وجود دارند",
          'data-admin-chat-stats' in page and page.count('class="card glass stat') >= 3,
          "stats missing")
    check("جست‌وجو و فیلتر وضعیت در پنل وجود دارد",
          'name="q"' in page and 'name="status"' in page and 'data-thread-list' in page,
          "filters/list missing")
    check("فیلتر HTTP گفتگوی دیگر را حذف می‌کند",
          filtered_code == 200 and PREFIX + "-foreign-shop" in filtered
          and PREFIX + "-shop —" not in filtered,
          f"HTTP {filtered_code}")
    check("صفحهٔ جزئیات مدیر پیام‌رسان مشترک است",
          detail_code == 200 and 'data-chat-shell' in detail
          and 'data-me="admin"' in detail and 'مدیر بازارچه' in detail,
          f"HTTP {detail_code}")
    check("کلید مدیر به polling و فایل منتقل می‌شود",
          f"key={key}" in detail and 'as=admin' in detail,
          "admin API key missing")
    check("مدیر دکمهٔ بستن/بازکردن گفتگو دارد",
          f'action="/panel/chat/{tid}/status"' in detail and 'name="status"' in detail,
          "status form missing")
    check("دیدن صفحه شمارندهٔ خوانده‌نشدهٔ مدیر را صفر می‌کند",
          db.chat_unread_count(tid, "admin") == 0,
          str(db.chat_unread_count(tid, "admin")))

    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        context = browser.new_context(viewport={"width": 390, "height": 844},
                                      locale="fa-IR", is_mobile=True, has_touch=True)
        browser_page = context.new_page()
        errors = []
        browser_page.on("pageerror", lambda error: errors.append(str(error)))
        browser_page.goto(BASE + f"/panel/chat/{tid}?key={urllib.parse.quote(key)}",
                          wait_until="networkidle")
        browser_page.wait_for_timeout(250)
        mobile = browser_page.evaluate("""() => ({
          overflow: document.documentElement.scrollWidth-document.documentElement.clientWidth,
          room: document.querySelector('[data-chat-room]')?.getBoundingClientRect().height || 0,
          send: document.querySelector('[data-chat-send]')?.getBoundingClientRect().height || 0,
          attach: document.querySelector('[data-attach-button]')?.getBoundingClientRect().height || 0
        })""")
        check("پنل مدیر در 390px سرریز ندارد و composer لمسی است",
              mobile["overflow"] <= 0 and mobile["room"] >= 280
              and mobile["send"] >= 44 and mobile["attach"] >= 44,
              str(mobile))
        check("صفحهٔ مدیر خطای جاوااسکریپت ندارد", not errors, str(errors))
        context.close(); browser.close()


def main():
    cleanup()
    try:
        task1_schema_storage_data()
        task2_http_security()
        task3_messenger_ui()
        task4_admin_control_center()
    finally:
        cleanup()

    print("\n" + "═" * 62)
    print(f"  {len(PASS)} موفق، {len(FAIL)} ناموفق")
    for label, detail in FAIL:
        print("   ✗", label, detail)
    print("═" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
