/* ==========================================================================
   Image upload with in-browser downscaling.

   Pillow is unavailable in Pydroid, so the heavy lifting happens here:
   every picked file is drawn to a canvas, resized to fit MAX_EDGE and
   re-encoded as JPEG before it ever leaves the device. That keeps uploads
   fast on mobile data and keeps the server dependency-free.
   ========================================================================== */

const MAX_EDGE = 1600;      // px on the longest side
const QUALITY  = 0.82;
const HARD_CAP = 3 * 1024 * 1024;

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

const fmtSize = (b) => b > 1048576
  ? (b / 1048576).toFixed(1) + ' مگابایت'
  : Math.round(b / 1024) + ' کیلوبایت';

function loadImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('bad image')); };
    img.src = url;
  });
}

async function shrink(file) {
  // No type gate here: loadImage() decodes by actual bytes, so a mis-named
  // JPEG ("jpg.1000061182" from some Android gallery apps) still processes
  // instead of being rejected as «تصویر معتبر نیست».
  let img;
  try { img = await loadImage(file); } catch (e) { return null; }

  let { width: w, height: h } = img;
  const scale = Math.min(1, MAX_EDGE / Math.max(w, h));
  w = Math.round(w * scale);
  h = Math.round(h * scale);

  const canvas = document.createElement('canvas');
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingQuality = 'high';
  // flatten transparency onto white so JPEG never goes black
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, w, h);
  ctx.drawImage(img, 0, 0, w, h);

  const blob = await new Promise(r => canvas.toBlob(r, 'image/jpeg', QUALITY));
  if (!blob) return null;
  // v100: ALWAYS keep the re-encoded JPEG — compression is never skipped, even
  // when the original happened to be smaller.
  return {
    blob,
    name: file.name.replace(/\.(jpe?g|png|webp|gif|heic|heif|avif|bmp)$/i, '') + '.jpg',
    before: file.size,
    after: blob.size,
    url: canvas.toDataURL('image/jpeg', 0.5),
  };
}

function initUploader(form) {
  const input   = $('[data-file]', form);
  const drop    = $('[data-drop]', form);
  const preview = $('[data-preview]', form);
  const actions = $('[data-upload-actions]', form);
  const clear   = $('[data-clear]', form);
  const maxNew  = parseInt(form.dataset.max || '15', 10);
  if (!input) return;

  let ready = [];

  const render = () => {
    preview.innerHTML = ready.map((f, i) => `
      <figure class="dz-thumb">
        <img src="${f.url}" alt="پیش‌نمایش ${i + 1}">
        <figcaption>${fmtSize(f.before)} ← <strong>${fmtSize(f.after)}</strong></figcaption>
        <button class="btn-icon" type="button" data-drop-one="${i}"
                aria-label="حذف تصویر ${i + 1}">✕</button>
      </figure>`).join('');
    preview.hidden = ready.length === 0;
    actions.hidden = ready.length === 0;
  };

  async function accept(fileList) {
    const files = Array.from(fileList || []);
    if (!files.length) return;
    if (maxNew <= 0) {
      window.Bazarche?.toast('ظرفیت گالری تکمیل است.', 'err');
      return;
    }
    drop.classList.add('is-busy');
    for (const file of files) {
      if (ready.length >= maxNew) {
        window.Bazarche?.toast(`حداکثر ${maxNew} تصویر در هر بار.`, 'err');
        break;
      }
      const r = await shrink(file);
      if (r) ready.push(r);
      else window.Bazarche?.toast(`«${file.name}» تصویر معتبری نیست.`, 'err');
    }
    drop.classList.remove('is-busy');
    render();
  }

  input.addEventListener('change', () => accept(input.files));

  ['dragenter', 'dragover'].forEach(ev =>
    drop.addEventListener(ev, (e) => {
      e.preventDefault(); drop.classList.add('is-over');
    }));
  ['dragleave', 'drop'].forEach(ev =>
    drop.addEventListener(ev, (e) => {
      e.preventDefault(); drop.classList.remove('is-over');
    }));
  drop.addEventListener('drop', (e) => accept(e.dataTransfer?.files));

  preview.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-drop-one]');
    if (!btn) return;
    ready.splice(+btn.dataset.dropOne, 1);
    render();
  });

  clear?.addEventListener('click', () => { ready = []; input.value = ''; render(); });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!ready.length) return;

    const fd = new FormData();
    $$('input[type=hidden]', form).forEach(h => fd.append(h.name, h.value));
    ready.forEach((f, i) => fd.append('images', f.blob, f.name || `photo-${i}.jpg`));

    const btn = $('[type=submit]', form);
    const old = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span><span>در حال بارگذاری…</span>';

    fetch(form.action, { method: 'POST', body: fd })
      .then(r => r.ok ? r.json() : Promise.reject(new Error('http ' + r.status)))
      .then(res => {
        if (res.ok) { location.href = res.redirect || location.pathname; }
        else throw new Error(res.error || 'خطا');
      })
      .catch(err => {
        btn.disabled = false;
        btn.innerHTML = old;
        window.Bazarche?.toast('بارگذاری ناموفق بود: ' + err.message, 'err');
      });
  });
}

function boot() { $$('form[data-upload]').forEach(initUploader); }

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else { boot(); }
