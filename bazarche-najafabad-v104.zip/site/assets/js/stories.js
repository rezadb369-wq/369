/* Bazarche — story bar + fullscreen story viewer (v32) */
const esc = t => String(t == null ? '' : t)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// ---------- fullscreen story viewer (shared) ----------
function openGroup(group) {
  if (!group || !group.items || !group.items.length) return;
  let idx = 0;
  const ov = document.createElement('div');
  ov.className = 'story-viewer';
  ov.innerHTML = `
    <div class="sv-progress">${group.items.map(() => '<span><i></i></span>').join('')}</div>
    <button class="sv-close" type="button" aria-label="بستن">✕</button>
    <button class="sv-nav sv-prev" type="button" aria-label="قبلی">‹</button>
    <button class="sv-nav sv-next" type="button" aria-label="بعدی">›</button>
    <div class="sv-media"><img src="${esc(group.items[0].image)}" alt=""></div>
    <div class="sv-caption">
      <strong>${esc(group.name)}</strong>
      <span>${esc(group.items[0].caption || '')}</span>
    </div>
    <a class="sv-link" href="/b/${esc(group.slug)}">مشاهدهٔ صفحهٔ کسب‌وکار</a>`;
  document.body.appendChild(ov);
  document.body.style.overflow = 'hidden';

  const bars = ov.querySelectorAll('.sv-progress span');
  const media = ov.querySelector('.sv-media img');
  const capName = ov.querySelector('.sv-caption strong');
  const capText = ov.querySelector('.sv-caption span');
  const IMAGE_MS = 5000;

  // v103: real-time progress engine. The active bar is redrawn every animation
  // frame from the video's OWN currentTime (or real elapsed time for images),
  // so it reflects actual playback: it stalls when the video buffers, freezes
  // while the tab is hidden, and lands on 100% exactly at the end. No fixed
  // CSS timer. (Pattern: SegmentedProgressBar / insta-stories real-time sync.)
  let raf = null, safety = null, curVideo = null;
  let slideStart = 0, slideDur = IMAGE_MS, pausedAccum = 0, pausedAt = 0;
  const curFill = () => bars[idx] && bars[idx].querySelector('i');
  const setFills = () => bars.forEach((b, i) => {
    b.classList.toggle('is-on', i === idx);
    b.classList.toggle('is-done', i < idx);
    const f = b.querySelector('i');
    if (f) f.style.width = i < idx ? '100%' : '0%';
  });
  const progress = () => {
    if (curVideo) {
      const d = curVideo.duration;
      if (isFinite(d) && d > 0) return curVideo.currentTime / d;   // true sync
    }
    return (performance.now() - slideStart - pausedAccum) / slideDur;  // image / WebM w/o duration
  };
  const tick = () => {
    const frac = progress();
    const f = curFill();
    if (f) f.style.width = (Math.max(0, Math.min(1, frac)) * 100).toFixed(2) + '%';
    if (frac >= 1) { next(); return; }
    raf = requestAnimationFrame(tick);
  };
  const stop = () => { if (raf) cancelAnimationFrame(raf); raf = null; clearTimeout(safety); safety = null; };
  const startSlide = () => {
    stop();
    slideStart = performance.now(); pausedAccum = 0;
    const f = curFill(); if (f) f.style.width = '0%';
    raf = requestAnimationFrame(tick);
    safety = setTimeout(() => { if (raf) next(); }, slideDur + 4000);  // never hang if playback stalls
  };
  const onVis = () => {
    if (document.hidden) {
      pausedAt = performance.now();
      if (raf) cancelAnimationFrame(raf); raf = null;
      if (curVideo) curVideo.pause();
    } else {
      if (pausedAt) { pausedAccum += performance.now() - pausedAt; pausedAt = 0; }
      if (curVideo) curVideo.play().catch(() => {});
      if (!raf) raf = requestAnimationFrame(tick);
    }
  };

  const render = () => {
    const s = group.items[idx];
    // v100: record one anonymous view (no identity is sent or stored).
    if (s && s.id) { try { fetch('/api/stories/' + s.id + '/view', { method: 'POST' }).catch(() => {}); } catch (_) {} }
    capName.textContent = group.name;
    capText.textContent = s.caption || '';
    setFills();
    const wrap = ov.querySelector('.sv-media');
    if (s.kind === 'video') {
      const vid = document.createElement('video');
      vid.src = s.image;
      vid.autoplay = true; vid.playsInline = true; vid.loop = false; vid.controls = false;
      vid.muted = false;                                   // stories have sound (v101)
      wrap.innerHTML = ''; wrap.appendChild(vid);
      curVideo = vid;
      slideDur = (Number(s.duration) > 0 ? Number(s.duration) : 15) * 1000;
      const p = vid.play();
      if (p && p.catch) p.catch(() => { vid.muted = true; vid.play().catch(() => {}); });  // autoplay fallback
      vid.addEventListener('ended', () => { const f = curFill(); if (f) f.style.width = '100%'; });
    } else {
      if (wrap.querySelector('video')) { wrap.innerHTML = ''; wrap.appendChild(media); }
      media.src = s.image;
      curVideo = null;
      slideDur = IMAGE_MS;
    }
    startSlide();
  };
  const next = () => { stop(); if (idx + 1 >= group.items.length) return close(); idx++; render(); };
  const prev = () => { if (idx > 0) { stop(); idx--; render(); } };
  function onKey(e) { if (e.key === 'Escape') close(); }
  const close = () => {
    stop();
    document.removeEventListener('visibilitychange', onVis);
    document.removeEventListener('keydown', onKey);
    ov.remove(); document.body.style.overflow = '';
  };

  ov.querySelector('.sv-close').addEventListener('click', close);
  ov.querySelector('.sv-next').addEventListener('click', next);
  ov.querySelector('.sv-prev').addEventListener('click', prev);
  ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
  document.addEventListener('keydown', onKey);
  document.addEventListener('visibilitychange', onVis);
  render();
}

// ---------- v101: owner previews their OWN story from the panel ----------
document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-story-preview]');
  if (!btn) return;
  e.preventDefault();
  try {
    const item = JSON.parse(btn.dataset.storyPreview);
    openGroup({ name: item.bizname || '', slug: item.bizslug || '', items: [item] });
  } catch (_) { /* malformed payload */ }
});

// ---------- per-business story buttons (cards + business page) ----------
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-story-biz]');
  if (!btn) return;
  e.preventDefault();
  e.stopPropagation();
  const slug = btn.dataset.storyBiz;
  try {
    const r = await fetch('/api/stories');
    const j = await r.json();
    const mine = (j.stories || []).filter(s => s.bizslug === slug);
    if (!mine.length) return;
    openGroup({ name: mine[0].bizname, slug, items: mine });
  } catch (err) { /* offline */ }
});

// ---------- story bar on the homepage ----------
const bar = document.querySelector('[data-stories-bar]');
if (bar) {
  (async function boot() {
    let stories = [];
    try {
      const r = await fetch('/api/stories');
      const j = await r.json();
      stories = j.stories || [];
    } catch (e) { return; }

    const groups = new Map();
    for (const s of stories) {
      if (!groups.has(s.bizslug)) groups.set(s.bizslug, { name: s.bizname, slug: s.bizslug, items: [] });
      groups.get(s.bizslug).items.push(s);
    }
    const list = Array.from(groups.values());
    if (!list.length) { bar.hidden = true; return; }

    bar.innerHTML = list.map((g, i) => {
      const last = g.items[g.items.length - 1];
      const isVid = last.kind === 'video';
      const thumb = isVid
        ? `<span class="story-vid-tag" aria-hidden="true">▶</span>`
        : `<img src="${esc(last.image)}" alt="" loading="lazy" decoding="async">`;
      return `<button class="story-ring" type="button" data-story-group="${i}" aria-label="استوری‌های ${esc(g.name)}">
        <span class="story-ring-inner">${thumb}</span>
        <span class="story-name">${esc(g.name)}</span>
      </button>`;
    }).join('');

    bar.addEventListener('click', (e) => {
      const b = e.target.closest('[data-story-group]');
      if (!b) return;
      openGroup(list[+b.dataset.storyGroup]);
    });
  })();
}
