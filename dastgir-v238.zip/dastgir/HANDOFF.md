# HANDOFF مرجع پروژهٔ «دست گیر»

آخرین به‌روزرسانی: ۲۰۲۶-۰۹-۰۷ — این فایل نقطهٔ شروع چت/عامل جدید است.

## ۱) منبع حقیقت و نسخه

- درخت فعال: همین پوشه (`dastgir/`).
- نسخهٔ فعلی درخت و بستهٔ مستنداتی: v206؛ منطق کامل بات‌ها از v205 بدون تغییر عملکردی منتقل شده است.
- آرشیو تأییدشدهٔ v205: `dastgir-v205.zip`، 484 فایل، 5,306,546 بایت.
- SHA-256 v205: `624c864ea4ea7f3308148107332a16d6b7c980178d91c1ad3129ae2570c709a9`.
- URL تحویل v205: `https://x0.at/pNMN.zip` (موقت؛ hash معیار اعتماد است).
- نام نمایشی محصول همیشه «دست گیر» با فاصله است.
- هیچ `.git` یا remote در workspace فعلی موجود نیست؛ «push به GitHub» فقط پس از clone/remote معتبر و احراز هویت واقعی قابل ادعاست.

## ۲) وضعیت قابلیت‌ها

هر دو بات بله و سروش‌پلاس از هستهٔ مشترک استفاده می‌کنند:

- ورود/ثبت‌نام بدون SMS و password با contact رسمی و تأیید جداگانه؛ مرورگر باز پس از تأیید خودکار وارد می‌شود.
- `/menu`, `/account`, `/help` با private-chat enforcement، webhook secret، replay claim و rate limit.
- `/orders`: فهرست/جزئیات مشتری، بدون phone/address/note.
- `/bookings`: نوبت‌های customer-bound، اعلان تاریخ/ساعت، لغو اتمیک پس از تأیید دوم.
- `/notifications`: تنظیم مشترک `notif_prefs` برای سایت و بات.
- `/stock`: درخواست‌های مشتری، بدون note، لغو تأییدی؛ fulfil به هر دو بات متصل.
- `/search query` و `/favorites`: نتیجهٔ published، مسیر، علاقه‌مندی مشترک و حذف تأییدی.
- `/messages`: پنج گفتگو، شش پیام اخیر، handoff فایل/پیچیدگی به سایت، پاسخ کوتاه با token یک‌بارمصرف hash-only.
- `/owner`: خلاصه روز، سفارش، نوبت امروز، پیام مشتری، موجودی و فراخوان؛ همهٔ mutationها owner-bound، یک‌بارمصرف و اتمیک.
- خلاصهٔ مالک ساعت 09:00 Asia/Tehran با systemd timer و dedup مالک/روز.
- Rubika در UI/runtime غیرفعال است اما رکوردهای قدیمی به‌صورت مخرب حذف نشده‌اند.

## ۳) امنیت تثبیت‌شده

- token واقعی بات‌ها و webhook secret فقط در `/etc/dastgir-secrets.env` با `root:root/600`؛ هرگز در چت، ZIP، history یا خروجی چاپ نشود.
- webhookهای بله/سروش URL secret را با `secrets.compare_digest` بررسی می‌کنند؛ JSON محدود، update_id عددی و replay claim پلتفرم‌محور است.
- عملیات حساب فقط در private chat؛ callbackها regex allow-list و کمتر از 64 بایت.
- authorization مشتری با `customer_id` و authorization مالک با `owner_id + business ownership` سمت سرور انجام می‌شود.
- confirmation پاسخ/مالک فقط به‌صورت SHA-256 در DB ذخیره می‌شود؛ bearer خام پنج دقیقه‌ای و یک‌بارمصرف است.
- private fields در بات ممنوع: order phone/address/note، booking phone/note، stock note/customer phone، stored attachment path/name.
- `push=False` فقط FCM را خاموش می‌کند، نه messenger fan-out.

## ۴) استقرار

- مسیر VPS ثبت‌شده: `/opt/dastgir`؛ service: `bazarche.service`؛ پورت داخلی: 8080؛ nginx روی دامنه.
- updater نهایی: `deploy/update.sh` — backup سازگار SQLite، staging، `rsync --delete` و حفظ `data/`، uploadها و chat-files.
- راهنمای همهٔ فرمان‌های Termius: `deploy/FINAL-v205-TERMIUS-fa.md`.
- گزارش امنیت: `deploy/FINAL-SECURITY-v205-fa.md`.
- کاربر تصویر `Final checks finished` و prompt فعال Termius را فرستاد؛ اما خروجی کامل version/health در تصویر نبود، پس deploy زنده را قطعی اعلام نکن.
- همان تصویر admin panel key را آشکار کرد. به کاربر دستور rotation بدون چاپ کلید داده شد؛ اجرای rotation هنوز تأیید نشده و باید در ادامه پرسیده/بررسی شود. خود کلید قدیمی را هرگز بازنویسی یا تکرار نکن.

## ۵) آخرین نتایج آزمون v205

- امنیت مستقل 25/25
- منوی مشترک و همه قابلیت‌ها 66/66
- Bale core 26/26؛ Bale HTTP 45/45
- Soroush core 13/13؛ Soroush HTTP 48/48
- public performance 12/12
- compile، shell، fresh schema/index، notifmeta، backup exclusions، browser/login، logo، credential/deploy policy: PASS

## ۶) ثبت مرحله‌به‌مرحلهٔ کسب‌وکار در بات‌ها — پیاده‌سازی‌شده در v207

وضعیت v207 (۲۰۲۶-۰۹-۰۷): پیاده‌سازی و آزموده شد. مسیر داده و تصمیم‌های قطعی:

- ماژول‌ها: `server/bot_register.py` (state machine سمت سرور، ۹ مرحله: category→name→city→area→address→descr→phone_public→hours→images→preview) و `server/bot_register_flow.py` (لایهٔ گفت‌وگو مشترک بله/سروش، callbackهای `dg198:reg_*` با allow-list regex، همگی ≤۶۴ بایت). هوک‌ها: `bot_menu.handle_message` (متن آزاد فقط وقتی پیش‌نویس فعال است)، `bot_menu.handle_callback` (پیش از allow-list قدیمی)، `bot_menu.handle_photo` (از webhook هر دو پلتفرم وقتی `message.photo` هست).
- ورودی‌ها: `/register_business`، `/register`، دکمهٔ «➕ ثبت کسب‌وکار» در منوی کاربران متصل؛ فقط چت خصوصی؛ کاربر غیرمتصل به لینک ورود سایت ارجاع می‌شود؛ `reg_open` تنظیمات مدیر رعایت می‌شود.
- پیش‌نویس: جدول جدید `biz_reg_drafts` (یک ردیف به‌ازای هر customer، TTL ۴۸ ساعت، پاک‌سازی تنبل)؛ resume/شروع‌ازنو، بازگشت مرحله‌ای، انصراف با تأیید. **در فهرست backup نیست** (مثل `bot_confirmations` موقت است).
- تلفن: همیشه از حساب تأییدشدهٔ مشتری خوانده می‌شود؛ متن تایپ‌شده در آن مرحله نادیده گرفته می‌شود. تصمیم جداگانهٔ نمایش عمومی در ستون جدید `businesses.phone_public` (پیش‌فرض ۱؛ `_reconcile_schema` روی DBهای قدیمی اضافه می‌کند؛ روی DB v206 واقعی تأیید شد). `views_public._public_phone_mask` فقط projection عمومی (صفحهٔ کسب‌وکار و payload نقشه) را خالی می‌کند.
- تصاویر (تصمیم: ترکیبی): در بات حداکثر ۳ عکس، دریافت با `getFile` واقعی هر پلتفرم (`bale.download_file` / `soroush.download_file`: اعتبارسنجی file_id، رد `..`/مسیر مطلق، سقف ۳MB+۱، بدون exception)، تشخیص magic توسط `uploads.sniff` (JPEG/PNG/WebP/GIF)، ذخیره با پیشوند `bizreg`؛ گالری کامل در سایت `/my`.
- تأیید دوم: `prepare_confirm` توکن تصادفی ۵ دقیقه‌ای، فقط SHA-256 در `bot_confirmations` (action=`biz_register`)؛ `submit` اتمیک (`BEGIN IMMEDIATE`)، سوزاندن توکن + بایند مالک از طریق تلفن تأییدشده، replay کاربر دیگر/تکراری هیچ ردیفی نمی‌سازد؛ مالک مسدود رد می‌شود و توکن سوزانده می‌ماند.
- نتیجه همیشه `status='pending'`؛ انتشار فقط از پنل مدیر (تصمیم: moderation اجباری). اعلان مدیر (`sms.notify_owner`، best-effort) و اعلان درون‌برنامه‌ای مشتری (kind `news`).
- نرخ: bucket جداگانهٔ `bot-reg:<platform>:<uid>` ۴۰/دقیقه با `always=True`، پشت limiter عمومی منوی بات (۲۰/دقیقه) که اول می‌گیرد.
- آزمون: `tools/test_bot_register_v207.py` ۶۶/۶۶ (هستهٔ state machine بدون HTTP) و `tools/test_bot_register_http_v207.py` ۶۳/۶۳ (webhook واقعی هر دو پلتفرم با API جعلی شامل getFile و دانلود، جعل callback، replay، rate، صفحهٔ عمومی با phone_public=0/1).

متن اصلی درخواست (تاریخی):

کاربر خواسته است «ثبت کسب‌وکار مرحله‌به‌مرحله داخل هر دو بات» اضافه شود. قبل از آن صریحاً خواست فایل‌های دانش، قوانین و handoff به‌روز شوند تا چت جدید دقیق باشد.

طرح پیشنهادی ثبت کسب‌وکار:

1. `/register_business` و دکمهٔ «ثبت کسب‌وکار».
2. draft پایدار مشترک با state machine صریح، expiry، resume و cancel تأییدی.
3. انتخاب/جست‌وجوی دسته‌بندی فعال.
4. نام، شهر، محله، نشانی، توضیح کوتاه.
5. تلفن از حساب تأییدشده و غیرقابل جعل؛ گزینهٔ نمایش عمومی جداگانه.
6. ساعات کاری.
7. تصویر: تصمیم محصول هنوز قطعی نشده؛ پیشنهاد امن «لوگو و چند تصویر سبک در بات + مدیریت کامل گالری در سایت» است.
8. پیش‌نمایش و تأیید دوم یک‌بارمصرف.
9. ثبت نهایی با مالکیت معتبر و `status=pending` برای بررسی مدیر؛ انتشار مستقیم ممنوع.
10. parity بله/سروش، محدودیت نرخ/طول/MIME/اندازه، عدم ذخیرهٔ bearer خام، و ZIP کامل مستقل پس از اتمام.

تصمیم‌های باز در v207 بسته شدند (کاربر اجازهٔ انتخاب استاندارد داد): تصویر **ترکیبی**، moderation **اجباری** برای همهٔ ثبت‌های بات.

## ۶٫۵) ثبت کسب‌وکار در سایت — ویزارد v208

- `/register-business` (۷ مرحله) جایگزین `/submit` شد؛ `/submit` فقط 303 می‌دهد. ورود لازم است.
- موتور مشترک با بات‌ها (`bot_register.py`, platform="web") و همان `biz_reg_drafts`؛ ادامهٔ پیش‌نویس از هر کانال.
- فایل‌ها: `server/views_register.py`, `server/register_web.py`, `site/assets/js/regwizard.js`; آزمون `tools/test_register_web_v208.py` (۶۹).
- جزئیات کامل و شواهد QA: `docs/collaboration/KNOWLEDGE.md` بند ۳۳.

## ۶٫۶) چرخهٔ عمر کسب‌وکار برای دکان‌دار — v209

- `/my/businesses`: لغو درخواست بررسی، ارسال دوباره، پنهان/نمایش (فقط منتشرشده‌های قبلی)، حذف نرم با تایپ نام → سطل بازیافت ۳۰ روزه → بازیابی به «در انتظار».
- `db.owner_biz_transition` / `db.owner_delete_business` / `businesses.published_once`؛ آزمون `tools/test_owner_lifecycle_v209.py` (۴۶ در v210). v210: کنترل‌ها در داشبورد `/my` هم هستند، مرحلهٔ دسته یک فیلد، نشانگرهای asset با هم بالا رفتند. جزئیات: KNOWLEDGE بند ۳۴–۳۵.

## ۷) قوانین ادامه

- در clone/GitHub ابتدا `docs/collaboration/CURRENT-STATE.md`، سپس `docs/collaboration/RULES.md`، `docs/collaboration/KNOWLEDGE.md` و این `HANDOFF.md` خوانده شوند؛ نسخه‌های بیرون پروژه فقط workspace اصلی را تکمیل می‌کنند.
- قبل از هر تغییر، فایل‌های مرتبط و رفتار واقعی بررسی شوند.
- هر بخش مستقل، نسخهٔ تازه و ZIP کامل clean دارد؛ patch archive ممنوع.
- موفقیت بدون تست واقعی ادعا نشود.
- stable callback prefix `dg198:` صرفاً برای هماهنگی نسخه تغییر نکند.
- هر state-changing/destructive action تأیید دوم و predicate اتمیک مالکیت/وضعیت می‌خواهد.
- پس از بسته، clean extraction QA، hash، remote redownload و ثبت در KNOWLEDGE انجام شود.
