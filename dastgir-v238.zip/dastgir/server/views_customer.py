# -*- coding: utf-8 -*-
"""
Customer-facing pages: account (OTP), chat with shops, orders, favourites.
Standard library only — same constraints as the rest of the app.
"""

import json
import urllib.parse

import db
import views_chat as CH
from ui import (icon, stars, fa, fa_group, esc, page, breadcrumb, empty_state,
                section_head, stat_card, flash, json_embed, password_reminder,
                notif_push_card)
from ui import jdate, jdatetime, jdatetime_ts
from notifmeta import meta as _nmeta


def _msg(q):
    if q.get("ok"):
        return flash("ok", q["ok"][0])
    if q.get("err"):
        return flash("err", q["err"][0])
    return ""


# ------------------------------------------------------------------ auth
def login(s, phone="", err="", code_stage=False, dev_code="", note="", nxt=""):
    cats = db.category_tree()
    if code_stage:
        form_html = f'''<form method="post" action="/me/login/verify" data-validate>
      <input type="hidden" name="phone" value="{esc(phone)}">
      <input type="hidden" name="next" value="{esc(nxt)}">
      <input type="hidden" name="favs" id="c-favs" value="">
      <div class="field"><label class="field-label" for="c-code">کد ورود</label>
        <input class="input nums" id="c-code" name="code" type="tel" dir="ltr" required
               inputmode="numeric" pattern="[0-9]{{5}}" maxlength="5" autocomplete="one-time-code"
               placeholder="•••••"></div>
      <button class="btn btn-primary btn-block" type="submit">
        {icon("check")}<span>ورود</span></button>
      <p class="field-hint" style="text-align:center;margin-top:10px">
        <a href="/me/login">شماره را اشتباه وارد کردم</a></p>
    </form>
    <script>
      try {{
        var favs = JSON.parse(localStorage.getItem('bazarche.v2.favs') || '[]');
        var f = document.getElementById('c-favs');
        if (f && Array.isArray(favs)) f.value = JSON.stringify(favs);
      }} catch (e) {{}}
    </script>'''
        dev_html = (f'<div class="alert alert-warn" style="text-align:center">{icon("eye")}'
                    f'<span>کد نمایشی (بدون پیامک): <strong class="nums" dir="ltr">{esc(dev_code)}</strong></span></div>'
                    if dev_code else '')
    else:
        form_html = f'''<form method="post" action="/me/login" data-validate>
      <input type="hidden" name="next" value="{esc(nxt)}">
      <div class="field"><label class="field-label" for="c-phone">شمارهٔ موبایل</label>
        <input class="input nums" id="c-phone" name="phone" type="tel" dir="ltr" required
               inputmode="numeric" pattern="0[0-9]{{10}}" maxlength="11"
               value="{esc(phone)}" placeholder="۰۹۱۲۳۴۵۶۷۸۹"></div>
      <button class="btn btn-primary btn-block" type="submit">
        {icon("send")}<span>دریافت کد ورود</span></button>
    </form>'''
        dev_html = ''
    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass">
    <div class="auth-head"><span class="mark">{icon("user")}</span>
      <h1>ورود مشتری</h1>
      <p>با شمارهٔ موبایل وارد شوید تا سفارش‌ها، گفتگوها و علاقه‌مندی‌هایتان
        روی همهٔ دستگاه‌ها بماند. رمز عبور لازم نیست.</p></div>
    {flash("err", err) if err else ''}
    {f'<div class="alert alert-success">{icon("check-circle")}<span>{esc(note)}</span></div>' if note else ''}
    {dev_html}
    {form_html}
    <hr class="divider">
    <details class="auth-alt">
      <summary class="btn btn-ghost btn-block">{icon("lock")}<span>ورود با نام کاربری و رمز عبور</span></summary>
      <form method="post" action="/me/login/password" data-validate class="mt-md">
        <input type="hidden" name="next" value="{esc(nxt)}">
        <div class="field">
          <label class="field-label" for="c-lu">نام کاربری</label>
          <input class="input" id="c-lu" name="username" dir="ltr" required autocomplete="username"
                 placeholder="نام کاربری شما">
        </div>
        <div class="field">
          <label class="field-label" for="c-lp">رمز عبور</label>
          <input class="input" id="c-lp" name="password" type="password" dir="ltr" required
                 autocomplete="current-password" placeholder="••••••">
        </div>
        <button class="btn btn-primary btn-block" type="submit" aria-label="ورود با رمز عبور">{icon("lock")}<span>ورود</span></button>
      </form>
    </details>
    <p class="field-hint" style="text-align:center;margin-top:12px">
      با ورود، <a href="/rules">قوانین</a> را می‌پذیرید.</p>
  </div></div></div>'''
    return page(s, "ورود مشتری", body, "", cats=cats)


# --------------------------------------------------- complete profile (v65)
def profile(s, cust, q=None, err=""):
    """Name is REQUIRED after first login; family name is optional."""
    q = q or {}
    cats = db.category_tree()
    name = cust.get("name") or ""
    family = cust.get("family") or ""
    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass">
    <div class="auth-head"><span class="mark">{icon("user")}</span>
      <h1>خوش آمدید — نام شما چیست؟</h1>
      <p>برای ادامه، نام خود را بنویسید. نام خانوادگی اختیاری است و
        شمارهٔ تلفن شما همیشه محرمانه می‌ماند.</p></div>
    {flash("err", err) if err else ""}
    <form method="post" action="/me/profile" data-validate>
      <div class="field"><label class="field-label" for="pf-n">نام<span class="req">*</span></label>
        <input class="input" id="pf-n" name="name" maxlength="60" required minlength="2"
               placeholder="مثلاً: علی" value="{esc(name)}"></div>
      <div class="field"><label class="field-label" for="pf-f">نام خانوادگی</label>
        <input class="input" id="pf-f" name="family" maxlength="60"
               placeholder="اختیاری — مثلاً: محمدی" value="{esc(family)}"></div>
      <button class="btn btn-primary btn-block" type="submit">
        {icon("check")}<span>ثبت و ادامه</span></button>
    </form>
  </div></div></div>'''
    return page(s, "تکمیل حساب", body, "", cats=cats)


# ------------------------------------------------------------------ dashboard
def dashboard(s, cust, q=None):
    q = q or {}
    cats = db.category_tree()
    orders = db.orders_for_customer(cust["id"])[:5]
    chats = db.chat_threads_for_customer(cust["id"])[:5]
    favs = db.fav_list(cust["id"])
    prices_on = s.get("prices_enabled") == "1"

    ord_html = "".join(f'''<a class="todo-item" href="/me/order/{o["id"]}">
      {icon("shopping")}<span><strong>{esc(o["bizname"])}</strong>
      <small class="text-muted">{f'{fa_group(o["total"])} تومان · ' if prices_on else ''}
        <span class="badge {db.ORDER_LABELS.get(o["status"], ("badge-neutral",""))[0]}">{esc(o["status_label"])}</span></small></span>
      {icon("chevron-left")}</a>''' for o in orders)
    if not ord_html:
        ord_html = empty_state("shopping", "هنوز سفارشی ندارید",
                               "از کاتالوگ محصولات، اولین سفارش خود را ثبت کنید.")

    chat_html = "".join(f'''<a class="todo-item" href="/me/chat/{t["id"]}">
      {icon("message")}<span><strong>{esc(t["bizname"])}</strong><br>
      <small class="text-muted">{esc((t.get("last") or {}).get("body", "")[:60])}</small></span>
      {icon("chevron-left")}</a>''' for t in chats)
    if not chat_html:
        chat_html = empty_state("message", "گفتگویی ندارید",
                                "از صفحهٔ هر کسب‌وکار می‌توانید گفتگو را شروع کنید.")

    body = f'''{_msg(q)}

<div class="container-wide">
  {breadcrumb(("حساب من", None))}
  <header class="page-hero"><h1>سلام، {esc(cust["name"] or "مشتری عزیز")}</h1>
    <p>سفارش‌ها، گفتگوها و علاقه‌مندی‌های شما — همه در یک جا.</p></header>
  <div class="grid grid-3 mb-lg" data-stagger>
    {stat_card("shopping", len(db.orders_for_customer(cust["id"])), "سفارش")}
    {stat_card("message", len(db.chat_threads_for_customer(cust["id"])), "گفتگو", delay=60)}
    {stat_card("heart", len(favs), "علاقه‌مندی", delay=120)}
  </div>
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-md">{icon("user")} همهٔ بخش‌های پنل من</h2>
    <p class="text-sm text-muted mb-md">حساب شخصی شما — جدا از پنل دکان.</p>
    <div class="quick-grid">
      <a class="quick-tile" href="/me/profile">{icon("user")}<span>پروفایل</span><small>نام و تصویر شما</small></a>
      <a class="quick-tile" href="/me/orders">{icon("cart")}<span>سفارش‌های من</span><small>خریدهایی که ثبت کرده‌اید</small></a>
      <a class="quick-tile" href="/me/chats">{icon("message")}<span>گفت‌وگوهای من</span><small>پیام به دکان‌ها</small></a>
      <a class="quick-tile" href="/me/favorites">{icon("heart")}<span>علاقه‌مندی‌ها</span><small>دکان‌های نشان‌شده</small></a>
      <a class="quick-tile" href="/me/following">{icon("users")}<span>دنبال‌شده‌ها</span><small>اخبار دکان‌ها</small></a>
      <a class="quick-tile" href="/me/notifications">{icon("bell")}<span>اعلان‌ها</span><small>هشدارها و تخفیف‌ها</small></a>
      <a class="quick-tile" href="/me/account">{icon("shield")}<span>حساب و امنیت</span><small>ورود امن با بله</small></a>
    </div>
  </div>
  <div class="grid grid-2" style="align-items:start">
    <div class="card glass card-pad">
      <div class="between mb-md"><h2 class="card-title">{icon("shopping")} آخرین سفارش‌ها</h2>
        <a class="btn btn-ghost btn-sm" href="/me/orders">همه</a></div>
      {ord_html}
    </div>
    <div class="card glass card-pad">
      <div class="between mb-md"><h2 class="card-title">{icon("message")} گفتگوها</h2>
        <a class="btn btn-ghost btn-sm" href="/me/chats">همه</a></div>
      {chat_html}
    </div>
  </div>
  <div class="card glass card-pad mt-lg">
    <div class="between">
      <div><h2 class="card-title">{icon("heart")} علاقه‌مندی‌ها</h2>
        <p class="text-sm text-muted">روی همهٔ دستگاه‌ها همگام می‌ماند.</p></div>
      <a class="btn btn-glass" href="/favorites">{icon("grid")}<span>مشاهده</span></a>
    </div>
  </div>
  <div class="card glass card-pad mt-lg">
    <h2 class="card-title mb-md">{icon("user")} نام و نام خانوادگی</h2>
    <form method="post" action="/me/name" class="grid grid-2" style="gap:var(--space-md)">
      <div class="field"><label class="field-label" for="nm">نام<span class="req">*</span></label>
        <input class="input" id="nm" name="name" maxlength="60" required minlength="2"
               placeholder="نام شما" value="{esc(cust.get('name') or '')}"></div>
      <div class="field"><label class="field-label" for="fm">نام خانوادگی</label>
        <input class="input" id="fm" name="family" maxlength="60"
               placeholder="اختیاری" value="{esc(cust.get('family') or '')}"></div>
      <div class="cluster" style="grid-column:1/-1">
        <button class="btn btn-glass" type="submit">{icon("check")}<span>ذخیره</span></button>
      </div>
    </form>
  </div>
  <div class="cluster mt-lg" style="justify-content:center">
    <form method="post" action="/me/logout" style="display:inline">
      <button class="btn btn-ghost" type="submit">{icon("x")}<span>خروج</span></button>
    </form>
  </div>
</div>'''
    return page(s, "حساب من", body, "", cats=cats)


# ------------------------------------------------------------------ chat
def chats_list(s, cust, q=None):
    cats = db.category_tree()
    rows = db.chat_threads_for_customer(cust["id"])
    items = CH.thread_list(
        rows, "customer", "/me/chat",
        empty_title="گفتگویی ندارید",
        empty_text="از صفحهٔ هر کسب‌وکار می‌توانید گفتگو را شروع کنید.")
    unread = db.chat_unread_customer(cust["id"])
    body = f'''{_msg(q or {})}<div class="container-wide chat-inbox-page">
  {breadcrumb(("حساب من", "/me"), ("گفت‌وگوها", None))}
  {CH.conversations_tabs("customer", "chats", counts={"chats": unread})}
  <div class="chat-inbox-card">{items}</div>
</div>'''
    return page(s, "گفت‌وگوها", body, "", cats=cats)


def chat_view(s, cust, tid, q=None):
    thread = db.chat_thread(tid)
    if not thread or thread.get("customer_id") != cust["id"]:
        return None
    biz = db.business(bid=thread["biz_id"]) or {}
    cats = db.category_tree()
    messages = db.chat_messages(tid)
    room = CH.chat_room(
        thread, messages, "customer",
        biz.get("name", "کسب‌وکار"),
        "گفتگوی مستقیم؛ مدیر دست گیر در صورت نیاز امکان نظارت دارد.",
        f"/me/chat/{tid}", "/me/chats", status=thread.get("status", "open"))
    # v156: درخواست موجودی از دل گفتگو — v177: فرمِ سریع سه‌فیلدی (فقط ضروری):
    # کالا با چیپِ یک‌ضرب از کاتالوگ همین دکان (ناموجودها اول)، تعداد با +/−،
    # یادداشت اختیاری. ارسال = ثبت درخواست + کارت در خود رشتهٔ گفتگو.
    _stock_form = ""
    if thread.get("status", "open") == "open":
        _its = db.items(biz_id=thread["biz_id"])[:14]
        _chips = '<label class="stock-chip"><input type="radio" name="item_id" value="0" checked><span>هر کالا</span></label>'
        for _r in _its:
            _oos = "" if _r["available"] else ' <small class="stock-oos">ناموجود</small>'
            _chips += (f'<label class="stock-chip"><input type="radio" name="item_id" value="{_r["id"]}">'
                       f'<span>{esc(_r["title"])}{_oos}</span></label>')
        _stock_form = f'''
<form method="post" action="/me/chat/{tid}/notify-me" class="card glass card-pad mt-md" id="stock-quick">
  <h2 class="card-title mb-md">{icon("bell")} موجود شد خبرم کن</h2>
  <p class="field-hint mb-md">سه چیزِ ضروری؛ بدون فرم طولانی — با ارسال، کارتش داخل همین گفتگو برای دکاندار می‌نشیند.</p>
  <div class="field"><span class="field-label">کالا</span>
    <div class="stock-chips">{_chips}</div></div>
  <div class="field"><span class="field-label">تعداد</span>
    <div class="stock-qty">
      <button type="button" class="btn btn-glass btn-sm" data-qty-step="-1" aria-label="کمتر">−</button>
      <input class="input nums" name="qty" id="stock-qty" value="1" inputmode="numeric" readonly>
      <button type="button" class="btn btn-glass btn-sm" data-qty-step="1" aria-label="بیشتر">+</button>
    </div></div>
  <div class="field"><label class="field-label" for="stock-note">یادداشت (اختیاری)</label>
    <input class="input" id="stock-note" name="note" maxlength="140" placeholder="مثلاً: سایز بزرگ، تا آخر هفته"></div>
  <button class="btn btn-primary btn-block" type="submit">{icon("send")}<span>ارسال برای دکاندار</span></button>
  <button class="btn btn-glass btn-block mt-sm" type="button" id="stock-repeat" hidden>{icon("clock")}<span>تکرار آخرین درخواست</span></button>
</form>'''
    _stock_form += '\n<script>\n(function() {\n  var f = document.getElementById("stock-quick");\n  if (!f) return;\n  var qty = f.querySelector("#stock-qty");\n  f.querySelectorAll("[data-qty-step]").forEach(function(b) {\n    b.addEventListener("click", function() {\n      qty.value = Math.max(1, Math.min(99, (parseInt(qty.value, 10) || 1) + parseInt(b.dataset.qtyStep, 10)));\n    });\n  });\n  var KEY = "bz.v177.stockreq";\n  var last = null;\n  try { last = JSON.parse(localStorage.getItem(KEY) || "null"); } catch (_) {}\n  var rep = f.querySelector("#stock-repeat");\n  if (last && rep) {\n    rep.hidden = false;\n    rep.addEventListener("click", function() {\n      var rad = f.querySelector(\'input[name=item_id][value="\' + last.item + \'"]\');\n      if (rad) rad.checked = true;\n      qty.value = last.qty || 1;\n      f.querySelector("#stock-note").value = last.note || "";\n      f.submit();\n    });\n  }\n  f.addEventListener("submit", function() {\n    var sel = f.querySelector(\'input[name=item_id]:checked\');\n    try {\n      localStorage.setItem(KEY, JSON.stringify({item: sel ? sel.value : "0", qty: qty.value, note: f.querySelector("#stock-note").value}));\n    } catch (_) {}\n  });\n})();\n</script>'
    body = f'''{_msg(q or {})}<div class="container-wide chat-page">
  {breadcrumb(("حساب من", "/me"), ("گفتگوها", "/me/chats"), ("گفتگو", None))}
  {room}
  {_stock_form}
</div>
<script type="module" src="/assets/js/chat.js?v177"></script>'''
    return page(s, "گفتگو", body, "", cats=cats)


# ------------------------------------------------------------------ orders
def orders_list(s, cust, q=None):
    cats = db.category_tree()
    rows = db.orders_for_customer(cust["id"])
    prices_on = s.get("prices_enabled") == "1"
    items = "".join(f'''<a class="todo-item" href="/me/order/{o["id"]}">
      {icon("shopping")}<span><strong>{esc(o["bizname"])}</strong>
      <small class="text-muted">{f'{fa_group(o["total"])} تومان · ' if prices_on else ''}
      {esc(jdatetime(o["created"]))}</small></span>
      <span class="badge {db.ORDER_LABELS.get(o["status"], ("badge-neutral",""))[0]}">{esc(o["status_label"])}</span>
      {icon("chevron-left")}</a>''' for o in rows)
    if not items:
        items = empty_state("shopping", "هنوز سفارشی ندارید",
                            "از کاتالوگ محصولات، اولین سفارش خود را ثبت کنید.")
    body = f'''{_msg(q or {})}<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("سفارش‌ها", None))}
  <header class="page-hero"><h1>سفارش‌های من</h1><p>پیگیری وضعیت همهٔ سفارش‌ها.</p></header>
  <div class="card glass card-pad"><div class="todo-list notif-list">{items}</div></div>
</div>'''
    return page(s, "سفارش‌های من", body, "", cats=cats)


def order_view(s, cust, oid, q=None):
    o = db.order(oid)
    if not o or o.get("customer_id") != cust["id"]:
        return None
    biz = db.business(bid=o["biz_id"]) or {}
    cats = db.category_tree()
    rows = db.order_items(oid)
    prices_on = s.get("prices_enabled") == "1"
    if prices_on:
        items = "".join(f'''<tr><td>{esc(r["title"])}</td>
          <td class="nums">{fa_group(r["price"])} × {fa(r["qty"])}</td>
          <td class="nums">{fa_group(r["price"] * r["qty"])}</td></tr>''' for r in rows)
        item_head = "<tr><th>عنوان</th><th>قیمت</th><th>جمع</th></tr>"
        item_foot = (f'<tr><th colspan="2">مجموع</th><td class="nums">'
                     f'<strong>{fa_group(o["total"])}</strong></td></tr>')
    else:
        items = "".join(f'''<tr><td>{esc(r["title"])}</td>
          <td class="nums">{fa(r["qty"])} عدد</td></tr>''' for r in rows)
        item_head = "<tr><th>عنوان</th><th>تعداد</th></tr>"
        item_foot = ""
    badge = db.ORDER_LABELS.get(o["status"], ("badge-neutral", o["status"]))
    cancel_box=""
    if o.get("cancel_requested"):
        cancel_box=f'<div class="alert alert-warn mt-lg">{icon("clock")}<span>درخواست لغو برای دکان‌دار ارسال شده و منتظر تصمیم اوست.</span></div>'
    elif o.get("status") not in ("done","cancelled"):
        cancel_box=f'''<form class="card glass card-pad mt-lg" method="post" action="/me/order/{oid}/cancel" data-confirm="درخواست لغو ثبت شود؟">
          <h2 class="card-title mb-md">{icon("x-circle")} لغو سفارش</h2>
          <div class="field"><label class="field-label" for="cancel-reason">دلیل (اختیاری)</label><input class="input" id="cancel-reason" name="reason" maxlength="500"></div>
          <button class="btn btn-ghost" type="submit">ثبت لغو / درخواست لغو</button>
          <p class="field-hint">تا مهلت تعیین‌شده مستقیم لغو می‌شود؛ بعد از آن نیازمند تأیید دکان‌دار است.</p></form>'''
    body = f'''{_msg(q or {})}<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("سفارش‌ها", "/me/orders"), ("سفارش", None))}
  <header class="page-hero"><h1>سفارش #{fa(o["id"])} — {esc(biz.get("name", "کسب‌وکار"))}</h1>
    <div class="cluster mt-md">
      <span class="badge {badge[0]}">{esc(badge[1])}</span>
      <span class="badge badge-neutral">{esc(jdatetime(o["created"]))}</span>
    </div></header>
  <div class="grid grid-2" style="align-items:start">
    <div class="card glass card-pad">
      <h2 class="card-title mb-md">{icon("shopping")} اقلام</h2>
      <div class="table-wrap"><table class="table">
        <thead>{item_head}</thead><tbody>{items}</tbody>
        {f'<tfoot>{item_foot}</tfoot>' if item_foot else ''}
      </table></div>
    </div>
    <div class="card glass card-pad">
      <h2 class="card-title mb-md">{icon("cart")} مشخصات تحویل</h2>
      <p class="text-sm"><strong>نام:</strong> {esc(o["name"])}</p>
      <p class="text-sm"><strong>تلفن:</strong> {esc(o["phone"])}</p>
      <p class="text-sm"><strong>نشانی:</strong> {esc(o["address"] or "—")}</p>
      <p class="text-sm"><strong>یادداشت:</strong> {esc(o["note"] or "—")}</p>
    </div>
  </div>
  {cancel_box}
</div>'''
    return page(s, "سفارش", body, "", cats=cats)


# ------------------------------------------------------------------ server favourites
def favorites_server(s, cust):
    cats = db.category_tree()
    fav_ids = db.fav_list(cust["id"])
    rows = [b for b in db.businesses() if b["id"] in fav_ids]
    ci = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}
    from ui import biz_card
    cards = "".join(biz_card(b, ci, i * 50) for i, b in enumerate(rows))
    body = f'''<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("علاقه‌مندی‌ها", None))}
  <header class="page-hero"><h1>علاقه‌مندی‌های من</h1>
    <p>روی همهٔ دستگاه‌ها همگام می‌ماند.</p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div class="grid grid-3">{cards or empty_state("heart", "هنوز چیزی ذخیره نکرده‌اید",
    "روی نشان قلب در کارت هر کسب‌وکار بزنید تا اینجا ذخیره شود.")}</div>
</div></section>'''
    return page(s, "علاقه‌مندی‌های من", body, "", cats=cats)


# ------------------------------------------------------------------ order done
def order_done(s, oid, cap=False):
    cats = db.category_tree()
    o = db.order(oid)
    _capnote = (f'<div class="alert alert-info" style="max-width:560px;margin:0 auto 12px">'
                f'حداکثر تعداد هر کالا در یک سفارش ۹۹ عدد است؛ اقلام با همین حد ثبت شدند.</div>'
                if cap else '')
    body = f'''<div class="container-wide"><section class="section">
  {_capnote}
  {empty_state("check-circle", "سفارش شما ثبت شد",
    "کسب‌وکار به‌زودی با شما تماس می‌گیرد. وضعیت سفارش را از «حساب من → سفارش‌ها» دنبال کنید.",
    f'<div class="cluster" style="justify-content:center"><a class="btn btn-primary" href="/me/order/{oid}">{icon("shopping")}<span>مشاهدهٔ سفارش</span></a><a class="btn btn-glass" href="/catalog">{icon("grid")}<span>ادامهٔ خرید</span></a></div>')}
</section></div>''' if o else ''
    return page(s, "ثبت شد", body, "", cats=cats)


# ------------------------------------------------------------------ cart
def cart_page(s, token=""):
    cats = db.category_tree()
    body = f'''<div class="container-wide">
  {breadcrumb(("سبد خرید", None))}
  <header class="page-hero"><h1>سبد خرید</h1><p>اقلام انتخاب‌شده از کاتالوگ شهر.</p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div id="cart-root"></div>
</section>
<script type="module" src="/assets/js/cart.js?v109"></script>'''
    return page(s, "سبد خرید", body, "", token=token, cats=cats)


# ------------------------------------------------------------------ areas
def areas_page(s, token=""):
    cats = db.category_tree()
    rows = db.areas()
    tiles = "".join(f'''<a class="cat-tile tilt reveal-3d" data-tilt="7" data-delay="{i*40}"
      href="/area/{urllib.parse.quote(r['area'])}">
      <span class="sheen" aria-hidden="true"></span>
      <span class="art layer-2">{icon("pin")}</span>
      <span class="name layer-1">{esc(r['area'])}</span>
      <span class="count layer-1">{fa(r['c'])} کسب‌وکار</span></a>''' for i, r in enumerate(rows))
    body = f'''<div class="container-wide">
  {breadcrumb(("محله‌ها", None))}
  <header class="page-hero"><h1>محله‌های نجف‌آباد</h1>
    <p>کسب‌وکارها را محله‌به‌محله بگردید.</p></header></div>
<section class="section-sm"><div class="container-wide">
  <div class="cat-grid">{tiles or empty_state("pin", "هنوز محله‌ای ثبت نشده",
    "از پنل مدیریت، برای کسب‌وکارها «محله» تعیین کنید.")}</div>
</div></section>'''
    return page(s, "محله‌ها", body, "", token=token, cats=cats)


def area_page(s, area, token=""):
    cats = db.category_tree()
    rows = db.businesses_in_area(area)
    if not rows:
        return None
    ci = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}
    from ui import biz_card
    cards = "".join(biz_card(b, ci, i * 50) for i, b in enumerate(rows))
    body = f'''<div class="container-wide">
  {breadcrumb(("محله‌ها", "/areas"), (area, None))}
  <header class="page-hero"><h1>محلهٔ {esc(area)}</h1>
    <p>{fa(len(rows))} کسب‌وکار در این محله.</p></header></div>
<section class="section-sm"><div class="container-wide">
  <div class="grid grid-3">{cards}</div>
</div></section>'''
    return page(s, f"محلهٔ {area}", body, "", token=token, cats=cats)


# ------------------------------------------------------------------ notifications (v32, v142 rework)
def notifications_page(s, cust, q=None):
    q = q or {}
    cats = db.category_tree()
    rows = db.notifications(cust["id"])
    items = "".join(f'''<a class="todo-item {'is-unread' if not n['read'] else ''}"
      href="/me/notif/{n['id']}/go">
      {icon(_nmeta('cust', n['kind'])[0])}
      <span><strong>{esc(_nmeta('cust', n['kind'])[1])}</strong>
      <small class="text-muted">{esc(n['text'])}</small>
      <small class="text-muted nums time">{esc(jdatetime(n['created']))}</small></span>
      {icon('chevron-left')}</a>''' for n in rows)
    if not items:
        items = empty_state("bell", "اعلانی ندارید",
                            "پاسخ‌ها، وضعیت سفارش و پیام‌های جدید اینجا می‌آیند.")
    # v146: a shopkeeper visiting the customer inbox is pointed at the
    # business notifications of the same account (unified login, one person).
    owner_note = ""
    _ow = db.owner_by_phone(cust.get("phone") or "", create=False)
    if _ow and db.owner_has_business(_ow.get("id")) and db.owner_unread(_ow.get("id")):
        owner_note = (f'<div class="alert alert-info mb-lg">{icon("store")}'
                      f'<span>شما دکاندار هم هستید و {fa(db.owner_unread(_ow["id"]))} اعلان نخوانده '
                      f'<a href="/my/notifications">در اعلان‌های کسب‌وکارتان</a> دارید.</span></div>')
    body = f'''{_msg(q)}{owner_note}
<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("اعلان‌ها", None))}
  <header class="page-hero notifications-hero"><h1>{icon("bell")} اعلان‌های من</h1>
    <div class="cluster">
      <form method="post" action="/me/notifications/read">
        <button class="btn btn-glass btn-sm" type="submit">{icon("check")}<span>خواندن همه</span></button>
      </form>
      <a class="btn btn-glass btn-sm" href="/me/notif-settings">{icon("settings")}
        <span>تنظیم اعلان‌ها</span></a>
    </div></header>
  <div class="card glass card-pad"><div class="todo-list notif-list">{items}</div></div>
</div>'''
    return page(s, "اعلان‌های من", body, "", cats=cats)


def following_page(s, cust, q=None):
    q = q or {}
    cats = db.category_tree()
    ids = db.following_ids(cust["id"])
    rows = [b for b in db.businesses() if b["id"] in ids]
    ci = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}
    from ui import biz_card
    cards = "".join(biz_card(b, ci, i * 50) for i, b in enumerate(rows))
    body = f'''{_msg(q)}
<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("دنبال‌شده‌ها", None))}
  <header class="page-hero"><h1>{icon("heart")} کسب‌وکارهایی که دنبال می‌کنم</h1>
    <p>تازه‌های این کسب‌وکارها را دنبال کنید.</p></header>
  <section class="section-sm"><div class="container-wide">
    <div class="grid grid-3">{cards or empty_state("heart", "هنوز کسی را دنبال نمی‌کنید",
      "از صفحهٔ هر کسب‌وکار دکمهٔ «دنبال کردن» را بزنید.")}</div>
  </div></section>
</div>'''
    return page(s, "دنبال‌شده‌ها", body, "", cats=cats)


# ------------------------------------------------------------------ account & security
def account(s, cust, q=None):
    # v186: authentication is exclusively through Bale.
    connected = bool(db.messenger_account_for_customer(cust["id"], "bale") or
                     db.messenger_account_for_customer(cust["id"], "soroush"))
    state = ("حداقل یک پیام‌رسان رسمی متصل و ورود امن فعال است." if connected else
             "بله یا سروش‌پلاس را برای ورود دوباره متصل کنید.")
    body = f'''{_msg(q)}
<div class="container">
  {breadcrumb(("حساب و امنیت", None))}
  <div class="card glass card-pad">
    <h2 class="card-title mb-md">{icon("shield")} ورود امن با پیام‌رسان</h2>
    <div class="alert {'alert-success' if connected else 'alert-warn'} mb-lg"><span>{state}</span></div>
    <p class="text-sm text-muted mb-lg">ورود پیامکی و رمز عبور غیرفعال است. شماره فقط با دکمهٔ رسمی «ارسال شمارهٔ خودم» در بله یا سروش‌پلاس تأیید می‌شود.</p>
    <a class="btn btn-primary" href="/me/notif-settings">{icon("message")}<span>مدیریت اتصال بله</span></a>
  </div>
  <div class="card glass card-pad mt-lg">
    <h2 class="card-title mb-md">{icon("download")} داده‌های من</h2>
    <p class="text-sm text-muted mb-lg">داده‌های متصل به حساب را در فایل CSV دریافت کنید.</p>
    <a class="btn btn-glass" href="/me/export" download>{icon("download")}<span>دریافت CSV</span></a>
  </div>
</div>'''
    return page(s, "حساب و امنیت", body, "", cats=db.category_tree())


def notif_settings_page(s, cust, q=None):
    """v142: per-category notification switches + web-push card (customer)."""
    from notifmeta import kinds, meta
    q = q or {}
    cats = db.category_tree()
    rows = ""
    st = db.pref_state("cust", cust["id"], kinds("cust"))
    for k in kinds("cust"):
        ic, label, desc = meta("cust", k)
        rows += (f'<label class="switch-row">'
                 f'<input type="checkbox" name="k_{esc(k)}"{" checked" if st[k] else ""}>'
                 f'<span class="sw-copy"><strong>{icon(ic)}{esc(label)}</strong>'
                 f'<small>{esc(desc)}</small></span>'
                 f'<span class="track" aria-hidden="true"></span></label>')
    bale_acc = db.messenger_account_for_customer(cust["id"], "bale")
    if bale_acc:
        bale_card = f'''<div class="card glass card-pad mb-lg">
          <div class="between"><div><h2 class="card-title">{icon("message")} بله متصل است</h2>
          <p class="text-sm text-muted mt-sm">اعلان‌های انتخاب‌شده برای بازوی رسمی دست گیر هم ارسال می‌شوند.</p></div>
          <form method="post" action="/me/bale/unlink" data-confirm="اتصال بله قطع شود؟">
            <button class="btn btn-ghost" type="submit">{icon("x")}<span>قطع اتصال</span></button>
          </form></div></div>'''
    else:
        bale_card = f'''<div class="card glass card-pad mb-lg">
          <h2 class="card-title">{icon("message")} اعلان و ورود با بله</h2>
          <p class="text-sm text-muted mb-lg">یک‌بار حساب بله را متصل کنید؛ سپس بدون تایپ کد وارد شوید و اعلان‌ها را در بله بگیرید.</p>
          <a class="btn btn-primary" href="/me/bale/connect">{icon("message")}<span>اتصال حساب بله</span></a>
        </div>'''
    soroush_acc = db.messenger_account_for_customer(cust["id"], "soroush")
    if soroush_acc:
        soroush_card = f'''<div class="card glass card-pad mb-lg"><div class="between"><div>
          <h2 class="card-title">{icon("message")} سروش‌پلاس متصل است</h2>
          <p class="text-sm text-muted mt-sm">ورود و اعلان‌های انتخاب‌شده در بات سروش‌پلاس فعال‌اند.</p></div>
          <form method="post" action="/me/soroush/unlink" data-confirm="اتصال سروش‌پلاس قطع شود؟">
          <button class="btn btn-ghost" type="submit">{icon("x")}<span>قطع اتصال</span></button></form>
        </div></div>'''
    else:
        soroush_card = f'''<div class="card glass card-pad mb-lg">
          <h2 class="card-title">{icon("message")} اعلان و ورود با سروش‌پلاس</h2>
          <p class="text-sm text-muted mb-lg">حساب سروش‌پلاس را برای ورود و دریافت اعلان متصل کنید.</p>
          <a class="btn btn-primary" href="/me/soroush/connect">{icon("message")}<span>اتصال حساب سروش‌پلاس</span></a>
        </div>'''
    body = f'''{_msg(q)}
<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("تنظیم اعلان‌ها", None))}
  <header class="page-hero notifications-hero"><h1>{icon("settings")} تنظیم اعلان‌ها</h1>
    <p>کدام رویدادها به شما اطلاع بدهند؛ اعلان گوشی را هم همین‌جا فعال کنید.</p>
    <a class="btn btn-glass btn-sm" href="/me/notifications">{icon("bell")}
      <span>بازگشت به اعلان‌ها</span></a></header>
  <form method="post" action="/me/notif-settings">
    <div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-lg">{icon("settings")} کدام رویدادها اعلان بدهند؟</h2>
      <p class="text-sm text-muted mb-lg">خاموش‌کردن هر دسته، هم اعلان داخل سایت و هم
        اعلان گوشی همان دسته را متوقف می‌کند.</p>
      {rows}
      <hr class="divider">
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیرهٔ تنظیمات</span></button>
    </div>
  </form>
  {bale_card}
  {soroush_card}
  {notif_push_card("cust")}
</div>'''
    return page(s, "تنظیم اعلان‌ها", body, "", cats=cats,
                extra_js='<script src="/assets/js/notifpush.js?v154"></script>')
