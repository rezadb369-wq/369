# -*- coding: utf-8 -*-
"""v208 — HTTP controller for the site registration wizard.

Called from app.py for `/register-business…` (GET, urlencoded POST and
multipart POST).  All decisions are made against the server-side draft in
`bot_register`; the request only supplies candidate values.
"""
import json
import re
import urllib.parse

import db
import bot_register as R
import views_register as W
import views_public as V
import sms
import uploads

BASE = W.BASE
RATE = (60, 60)      # wizard POSTs per owner per minute (a whole flow is ~10)


def _cust_for(me):
    """Owner session → customer row with the same verified phone. The draft
    table is keyed by customer_id so bot and site share one draft."""
    if not me or me.get("status") == "blocked":
        return None
    c = db.customer_by_phone(me["phone"], create=True)
    if not c or c.get("status") == "blocked":
        return None
    return c


def _ctx(h, s):
    me = h.current_owner()
    if not me:
        return None, None
    c = _cust_for(me)
    if not c:
        return None, None
    me = dict(me, cust_id=c["id"])
    return me, R.get(c["id"])


def _guard(h, me, step, d):
    """Server decides reachability: a page beyond the first incomplete one
    redirects to that page instead of rendering."""
    reached = R.web_reached(d["data"])
    if W.STEP_INDEX[step] > reached:
        h.redirect(f"{BASE}/{W.STEP_META[reached][0]}"); return False
    return True


# ------------------------------------------------------------------ GET
def get(h, path, q, s):
    if s.get("reg_open") != "1":
        return h.send(W.closed(s))
    me = h.current_owner()
    if not me:
        if path != BASE:
            return h.redirect("/login?next=" + urllib.parse.quote(BASE))
        return h.send(W.intro(s))
    me, d = _ctx(h, s)
    if not me:
        return h.send(V.not_found(s), 403)
    step = path[len(BASE):].strip("/")
    if step.startswith("done/"):
        bid = int(step[5:]) if step[5:].isdigit() else 0
        if bid and db.owns(me["id"], bid):
            return h.send(W.done(s, me, bid))
        return h.redirect("/my/businesses")
    if not step:
        if d and (d["data"] or d["step"] != "category"):
            return h.send(W.resume(s, me, d))
        d = d or R.start(me["cust_id"], "web")
        return h.redirect(f"{BASE}/category")
    if step not in W.STEP_INDEX:
        return h.send(V.not_found(s), 404)
    if not d:
        R.start(me["cust_id"], "web")
        return h.redirect(f"{BASE}/category")
    if not _guard(h, me, step, d):
        return None
    if step == "category":
        return h.send(W.step_category(s, me, d))
    if step == "identity":
        return h.send(W.step_identity(s, me, d))
    if step == "location":
        return h.send(W.step_location(s, me, d))
    if step == "contact":
        return h.send(W.step_contact(s, me, d))
    if step == "hours":
        return h.send(W.step_hours(s, me, d))
    if step == "images":
        return h.send(W.step_images(s, me, d))
    if step == "preview":
        token = R.prepare_confirm(me["cust_id"])
        if not token:
            return h.redirect(f"{BASE}/{W.STEP_META[R.web_reached(d['data'])][0]}")
        return h.send(W.step_preview(s, me, d, token))
    return h.send(V.not_found(s), 404)


# ------------------------------------------------------------------ POST
def _fg(form, k):
    v = form.get(k, [""])
    return (v[0] if isinstance(v, list) else v) or ""


def post(h, path, form, s, files=None):
    if s.get("reg_open") != "1":
        return h.redirect(BASE)
    me, d = _ctx(h, s)
    if not me:
        return h.redirect("/login?next=" + urllib.parse.quote(BASE))
    if not db.rate_ok(f"regweb:{me['id']}", limit=RATE[0], window=RATE[1], always=True):
        return h.redirect("/my/businesses?err=" + urllib.parse.quote("درخواست‌ها زیاد است؛ یک دقیقه بعد ادامه دهید."))
    action = path[len(BASE):].strip("/")
    cid = me["cust_id"]

    if action == "cancel":
        R.cancel(cid)
        if _fg(form, "restart"):
            R.start(cid, "web")
            return h.redirect(f"{BASE}/category")
        return h.redirect("/my/businesses?ok=" + urllib.parse.quote("پیش‌نویس ثبت حذف شد."))

    if not d:
        d = R.start(cid, "web")
    if action in W.STEP_INDEX and action != "preview" and not _guard(h, me, action, d):
        return None
    x = d["data"]

    if action == "category":
        ok, err = (R.category_active(_fg(form, "cat_slug")) is not None, "دسته‌بندی معتبر نیست؛ دوباره انتخاب کنید.")
        if not ok:
            return h.send(W.step_category(s, me, d, errors=[err]))
        cat = R.category_active(_fg(form, "cat_slug"))
        R.web_save(cid, {"cat_slug": cat["slug"], "cat_name": cat["name"]})
        return h.redirect(f"{BASE}/identity")

    if action == "identity":
        errs, upd = [], {}
        for key, req in (("name", True), ("descr", False), ("tags", False)):
            val, err = R.web_validate_text(key, _fg(form, key), required=req)
            if err:
                errs.append(f"{ {'name':'نام','descr':'توضیح','tags':'برچسب‌ها'}[key]}: {err}")
            else:
                upd[key] = val
        if not errs:
            own = {b["id"] for b in db.businesses_of(me["id"])}
            dups = db.find_duplicates(name=upd["name"], exclude_ids=own or None)
            if any(z["strength"] == "exact" for z in dups) and not _fg(form, "confirm_dup"):
                errs.append("کسب‌وکاری با همین نام قبلاً ثبت شده است. اگر مطمئنید متعلق به شماست، نام را با محله دقیق‌تر کنید یا از پنل «ادعای مالکیت» استفاده کنید.")
        if errs:
            return h.send(W.step_identity(s, me, d, errors=errs, form=form))
        R.web_save(cid, upd)
        return h.redirect(f"{BASE}/location")

    if action == "location":
        errs, upd = [], {}
        for key, req in (("province", False), ("city", True), ("area", False), ("address", True)):
            val, err = R.web_validate_text(key, _fg(form, key), required=req)
            if err:
                errs.append(f"{ {'province':'استان','city':'شهر','area':'محله','address':'نشانی'}[key]}: {err}")
            else:
                upd[key] = val
        if upd.get("province") and upd["province"] not in db.provinces():
            errs.append("استان معتبر نیست.")
        lat, lng, err = R.web_validate_coord(_fg(form, "lat"), _fg(form, "lng"))
        if err:
            errs.append(err)
        if errs:
            return h.send(W.step_location(s, me, d, errors=errs, form=form))
        upd["lat"], upd["lng"] = lat, lng
        R.web_save(cid, upd)
        return h.redirect(f"{BASE}/contact")

    if action == "contact":
        errs, upd = [], {"phone_public": bool(_fg(form, "phone_public"))}
        _lbl = {"whatsapp": "واتساپ", "website": "وب‌سایت", "instagram": "اینستاگرام", "telegram": "تلگرام",
                "eitaa": "ایتا", "bale": "بله", "soroush": "سروش", "rubika": "روبیکا"}
        for key in ("whatsapp", "website", "instagram", "telegram", "eitaa", "bale", "soroush", "rubika"):
            val, err = R.web_validate_text(key, _fg(form, key))
            if err:
                errs.append(f"{_lbl[key]}: {err}")
            else:
                upd[key] = val
        if errs:
            return h.send(W.step_contact(s, me, d, errors=errs, form=form))
        R.web_save(cid, upd)
        return h.redirect(f"{BASE}/hours")

    if action == "hours":
        preset = _fg(form, "preset")
        hours, label = None, ""
        detailed = any(_fg(form, f"h_{k}_open") or form.get(f"h_{k}_closed") for k, _ in W.DAYS)
        if detailed and not preset:
            hours, errs = {}, []
            for k, lbl in W.DAYS:
                if form.get(f"h_{k}_closed"):
                    continue
                o, c = _fg(form, f"h_{k}_open").strip(), _fg(form, f"h_{k}_close").strip()
                if not o and not c:
                    continue                      # untouched day = closed (same as the edit page)
                if not (re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", o) and re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", c)):
                    errs.append(f"ساعت {lbl} معتبر نیست."); continue
                hours[k] = [[o, c]]
            if not errs and not hours:
                errs.append("دست‌کم یک روز باید ساعت کاری داشته باشد یا یکی از گزینه‌های سریع را انتخاب کنید.")
            if errs:
                return h.send(W.step_hours(s, me, d, errors=errs, form=form))
            label = "تنظیم دقیق"
        elif preset in R.HOURS_PRESETS:
            label, hours = R.HOURS_PRESETS[preset]
        else:
            return h.send(W.step_hours(s, me, d, errors=["یک گزینه را انتخاب کنید یا ساعت روزانه را تنظیم کنید."], form=form))
        R.web_save(cid, {"hours": hours, "hours_label": label})
        return h.redirect(f"{BASE}/images")

    if action == "images":
        errs, n = [], 0
        for fname, _fn, blob in (files or []):
            if fname != "images":
                continue
            ok, err, _ = R.add_image(cid, blob, cap=R.MAX_IMAGES_WEB, require_step=False)
            if ok:
                n += 1
            elif err:
                errs.append(err)
        if not files and not errs:
            errs.append("تصویری انتخاب نشد.")
        d = R.get(cid)
        if errs:
            return h.send(W.step_images(s, me, d, errors=errs))
        return h.redirect(f"{BASE}/images")

    if action == "images/remove":
        R.remove_image(cid, _fg(form, "src"))
        return h.redirect(f"{BASE}/images")

    if action == "images/done":
        R.web_save(cid, {"images": list(x.get("images") or [])})
        return h.redirect(f"{BASE}/preview")

    if action == "submit":
        if not _fg(form, "accept"):
            token = R.prepare_confirm(cid)
            return h.send(W.step_preview(s, me, d, token, errors=["پذیرش قوانین لازم است."]))
        bid, err = R.submit(cid, _fg(form, "confirm"), me["phone"])
        if not bid:
            token = R.prepare_confirm(cid)
            if not token:
                return h.redirect(BASE)
            return h.send(W.step_preview(s, me, R.get(cid), token, errors=[err or "ثبت انجام نشد."]))
        db.log("business.web-submit", f"{bid} by {me['phone']}")
        try:
            b = db.business(bid=bid) or {}
            sms.notify_owner(s, f"کسب‌وکار جدید از سایت ثبت شد: «{b.get('name','')}» — در انتظار تأیید شما.")
        except Exception:
            pass
        return h.redirect(f"{BASE}/done/{bid}")

    return h.send(V.not_found(s), 404)
