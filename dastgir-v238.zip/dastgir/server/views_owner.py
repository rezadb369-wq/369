# -*- coding: utf-8 -*-
"""Business-owner area: OTP login, my businesses, gallery, stats, claims."""

import json
import time
import db
import bale
import soroush
import views_chat as CH
from ui import (icon, stars, fa, fa_group, review_score_html, esc, page, stat_card, flash, cat_icon,
                breadcrumb, empty_state, section_head, cat_options,
                gated, lock_note, lock_overlay, json_embed, password_reminder,
                nav_tiles, OWNER_AREA_NAV, notif_push_card)
from ui import jdate, jdatetime, jdatetime_ts
from notifmeta import meta as _nmeta

import views_public2 as V2

MAP_JS = ('<script type="module" src="/assets/js/mappage.js?v216"></script>'
          '<script type="module" src="/assets/js/catpicker.js?v109"></script>')
UP_JS = '<script type="module" src="/assets/js/imagefield.js?v109"></script>'
# v99: in-browser media compressor for the story composer (image + video).
COMPRESS_JS = '<script type="module" src="/assets/js/compress.js?v177"></script>'

# v85: the old OWNER_NAV sidebar list was removed — the dashboard tiles
# (ui.OWNER_AREA_NAV) are now the shopkeeper's only section nav.


def _msg(q):
    q = q or {}
    if q.get("ok"):
        return flash("ok", q["ok"][0])
    if q.get("err"):
        return flash("err", q["err"][0])
    return ""


def gate_any(mine, key, content, compact=False):
    """Owner-area pages span every shop the person owns. Blur the page only
    when NONE of their shops has the feature — otherwise the page is real for
    at least one shop and must stay usable.

    `mine` is the list returned by db.businesses_of(). With no shops at all
    there is nothing to sell yet, so the content passes through untouched.
    """
    if not mine:
        return content
    if any(db.can(b["id"], key) for b in mine):
        return content
    return gated(key, mine[0]["id"], content, compact=compact)


def gate_note_any(mine, key):
    """The one-line version of gate_any, for a banner above real content."""
    if not mine or any(db.can(b["id"], key) for b in mine):
        return ""
    return lock_note(key, mine[0]["id"])


# which sidebar entries depend on a gated feature
def shell(s, title, subtitle, content, active, owner, extra_js=""):
    # v85: the panel-side sidebar is GONE. It was a second copy of the very
    # same section list the dashboard already renders as tiles, so on a phone
    # the shopkeeper saw every section twice (the menu stacked above, then the
    # tiles). One nav now: dashboard tiles + the bottom bar. The panel is a
    # single column with a compact head (title + logout), so every owner page
    # starts lighter and the content gets the full width.
    body = f'''
<div class="container-wide">
  <header class="panel-head between mb-lg">
    <div><h1>{esc(title)}</h1><p>{esc(subtitle)}</p></div>
    <form method="post" action="/my/logout">
      <button class="btn btn-glass btn-sm" type="submit">{icon("logout")}<span>خروج</span></button>
    </form>
  </header>
  {content}
</div>'''
    return page(s, title, body, "", cats=[], body_class="page-panel", extra_js=extra_js + COMPRESS_JS)


# ==========================================================================
#  LOGIN
# ==========================================================================
def login(s, step="phone", phone="", note="", err="", dev_code="", nxt=""):
    # Carry the intended destination through both steps so a shopkeeper who
    # tapped "نوبت‌دهی اینترنتی" lands on bookings, not a generic dashboard.
    nxt = nxt if (nxt or "").startswith("/my") else ""
    nxt_field = f'<input type="hidden" name="next" value="{esc(nxt)}">' if nxt else ""
    if step == "code":
        dev = ""
        if dev_code:
            dev = f'''<div class="alert alert-info mb-lg">{icon("info")}
              <span>سرویس پیامک تنظیم نشده، بنابراین کد اینجا نمایش داده می‌شود:
                <strong class="nums" style="font-size:1.3em;letter-spacing:.2em">{esc(dev_code)}</strong></span></div>'''
        inner = f'''
    <div class="auth-head">
      <span class="mark">{icon("message")}</span>
      <h1>کد تأیید را وارد کنید</h1>
      <p>کد ۵ رقمی به شمارهٔ <strong class="nums">{esc(phone)}</strong> ارسال شد.</p>
    </div>
    {dev}
    {f'<div class="alert alert-error mb-lg">{icon("x-circle")}<span>{esc(err)}</span></div>' if err else ''}
    {f'<div class="alert alert-info mb-lg">{icon("info")}<span>{esc(note)}</span></div>' if note and not dev_code else ''}
    <form method="post" action="/login/verify" data-validate>
      <input type="hidden" name="phone" value="{esc(phone)}">{nxt_field}
      <div class="field">
        <label class="field-label" for="otp">کد تأیید<span class="req">*</span></label>
        <input class="input otp-input nums" id="otp" name="code" required
               inputmode="numeric" pattern="[0-9]{{5}}" maxlength="5" autocomplete="one-time-code"
               autofocus placeholder="- - - - -"
               data-msg-pattern="کد باید ۵ رقم باشد.">
      </div>
      <button class="btn btn-primary btn-lg btn-block" type="submit">
        {icon("check")}<span>ورود</span></button>
    </form>
    <form method="post" action="/login" class="mt-md">
      <input type="hidden" name="phone" value="{esc(phone)}">{nxt_field}
      <button class="btn btn-ghost btn-block" type="submit">
        {icon("refresh")}<span>ارسال دوبارهٔ کد</span></button>
    </form>
    <div class="auth-foot"><a href="/login">تغییر شمارهٔ موبایل</a></div>'''
    else:
        inner = f'''
    <div class="auth-head">
      <span class="mark">{icon("store")}</span>
      <h1>ورود / ثبت‌نام صاحبان کسب‌وکار</h1>
      <p>با شمارهٔ موبایل وارد شوید. اگر حساب ندارید، همین‌جا ساخته می‌شود.</p>
    </div>
    {f'<div class="alert alert-error mb-lg">{icon("x-circle")}<span>{esc(err)}</span></div>' if err else ''}
    <form method="post" action="/login" data-validate>
      {nxt_field}
      <div class="field">
        <label class="field-label" for="ph">شمارهٔ موبایل<span class="req">*</span></label>
        <input class="input nums" id="ph" name="phone" type="tel" required dir="ltr"
               inputmode="numeric" autocomplete="tel" autofocus
               value="{esc(phone)}" placeholder="09123456789">
        <p class="field-hint">کد تأیید به همین شماره پیامک می‌شود. رمز عبور لازم نیست.</p>
      </div>
      <button class="btn btn-primary btn-lg btn-block" type="submit">
        {icon("send")}<span>دریافت کد تأیید</span></button>
    </form>

    <div class="auth-note mt-lg">
      <div class="auth-note-row">{icon("check-circle")}<span>ثبت‌نام و ورود یکی است — نیازی به رمز عبور نیست.</span></div>
      <div class="auth-note-row">{icon("store")}<span>پس از ورود، کسب‌وکار خود را ثبت یا تصاحب کنید.</span></div>
      <div class="auth-note-row">{icon("image")}<span>محصولات، تصاویر و ساعت کاری را خودتان مدیریت کنید.</span></div>
    </div>

    <hr class="divider">
    <div class="auth-foot">
      می‌خواهید فقط کسب‌وکارتان را معرفی کنید؟
      <a href="/register-business">فرم ثبت کسب‌وکار</a>
    </div>

    <hr class="divider">
    <details class="auth-alt"{" open" if step == "password" else ""}>
      <summary class="btn btn-ghost btn-block">{icon("lock")}<span>ورود با نام کاربری و رمز عبور</span></summary>
      <form method="post" action="/login/password" data-validate class="mt-md">
        {nxt_field}
        <div class="field">
          <label class="field-label" for="lu">نام کاربری</label>
          <input class="input" id="lu" name="username" dir="ltr" required autocomplete="username"
                 placeholder="نام کاربری شما">
        </div>
        <div class="field">
          <label class="field-label" for="lp">رمز عبور</label>
          <input class="input" id="lp" name="password" type="password" dir="ltr" required
                 autocomplete="current-password" placeholder="••••••">
        </div>
        <button class="btn btn-primary btn-block" type="submit" aria-label="ورود با رمز عبور">{icon("lock")}<span>ورود</span></button>
        {f'<div class="alert alert-error mt-md">{icon("x-circle")}<span>{esc(err)}</span></div>' if step == "password" and err else ''}
      </form>
    </details>'''

    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass">{inner}</div>
</div></div>'''
    return page(s, "ورود صاحبان کسب‌وکار", body, "", cats=[])


def login_unified(s, step="phone", phone="", note="", err="", dev_code="", nxt=""):
    """v186: Bale-only customer/shopkeeper registration and login."""
    error_html = (f'<div class="alert alert-error mb-lg">{icon("x-circle")}<span>{esc(err)}</span></div>'
                  if err else "")
    inner = f'''
    <div class="auth-head">
      <span class="mark">{icon("message")}</span>
      <h1>ورود یا ثبت‌نام با پیام‌رسان</h1>
      <p>بدون پیامک و بدون رمز؛ درخواست را در بات رسمی دست گیر تأیید کنید.</p>
    </div>
    {error_html}
    <a class="btn btn-primary btn-lg btn-block" href="/auth/bale">
      {icon("message")}<span>ادامه با بله</span></a>
    <a class="btn btn-glass btn-lg btn-block mt-sm" href="/auth/soroush">
      {icon("message")}<span>ادامه با سروش‌پلاس</span></a>
    <p class="field-hint text-center mt-sm">اگر حساب ندارید، بات شمارهٔ تأییدشدهٔ خودتان را می‌گیرد و پس از تأیید جداگانه حساب را می‌سازد.</p>
    <div class="auth-note mt-lg">
      <div class="auth-note-row">{icon("check")}<span>شماره فقط با دکمهٔ رسمی «ارسال شمارهٔ خودم» در بله یا سروش‌پلاس پذیرفته می‌شود.</span></div>
      <div class="auth-note-row">{icon("shopping")}<span>یک حساب برای سفارش‌ها، اعلان‌ها و مدیریت کسب‌وکار.</span></div>
      <div class="auth-note-row">{icon("shield")}<span>درخواست زمان محدود دارد و فقط در همین مرورگر کامل می‌شود.</span></div>
    </div>'''
    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass">{inner}</div>
</div></div>'''
    return page(s, "ورود یا ثبت‌نام با پیام‌رسان", body, "", cats=[])


def bale_wait_page(s, challenge, purpose="login", linked=False):
    """Two-minute, browser-bound wait screen for Bale confirmation."""
    payload = f"{purpose}_{challenge['request_token']}"
    bot_url = bale.bot_link(payload)
    heading = "اتصال حساب بله" if purpose == "link" else "ورود با بله"
    done = "حساب بله متصل شد." if purpose == "link" else "ورود تأیید شد."
    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass">
    <div class="auth-head">
      <span class="mark">{icon("message")}</span>
      <h1>{heading}</h1>
      <p>بازوی رسمی دست گیر را باز کنید و دکمهٔ تأیید را بزنید. این درخواست دو دقیقه اعتبار دارد.</p>
    </div>
    <a class="btn btn-primary btn-lg btn-block" href="{esc(bot_url)}" rel="noreferrer">
      {icon("external")}<span>بازکردن @‌{esc(bale.BOT_USERNAME)} در بله</span></a>
    <div class="alert alert-info mt-lg" data-bale-state>{icon("clock")}
      <span>منتظر تأیید شما در بله هستیم…</span></div>
    <div class="auth-foot"><a href="{'/me/notif-settings' if purpose == 'link' else '/login'}">انصراف و بازگشت</a></div>
  </div>
</div></div>'''
    cid = json_embed(challenge["id"])
    js = f'''<script>
(function(){{
  var box=document.querySelector('[data-bale-state]'), stopped=false;
  function poll(){{
    if(stopped)return;
    fetch('/api/bale/status?id='+encodeURIComponent({cid}),{{credentials:'same-origin',cache:'no-store'}})
      .then(function(r){{return r.json();}}).then(function(x){{
        if(x.status==='approved'){{stopped=true;box.className='alert alert-success mt-lg';
          box.innerHTML='<span>{done}</span>';location.replace(x.redirect||'/me');return;}}
        if(x.status==='expired'){{stopped=true;box.className='alert alert-error mt-lg';
          box.innerHTML='<span>درخواست منقضی شد؛ دوباره تلاش کنید.</span>';return;}}
        setTimeout(poll,1800);
      }}).catch(function(){{setTimeout(poll,3000);}});
  }}
  poll();
}})();
</script>'''
    return page(s, heading, body, "", cats=[], body_class="auth-page",
                extra_js=js)


def soroush_wait_page(s, challenge, purpose="login"):
    payload = f"{purpose}_{challenge['request_token']}"
    url, appurl = soroush.bot_link(), soroush.app_link()
    heading = "اتصال حساب سروش‌پلاس" if purpose == "link" else "ورود یا ثبت‌نام با سروش‌پلاس"
    done = "حساب سروش‌پلاس متصل شد." if purpose == "link" else "ورود تأیید شد."
    body = f'''<div class="container"><div class="auth-wrap"><div class="auth-card glass">
      <div class="auth-head"><span class="mark">{icon("message")}</span><h1>{heading}</h1>
      <p>دکمهٔ زیر کلید کوتاه‌عمر را کپی می‌کند و گفت‌وگوی بات را مستقیماً داخل اپ سروش‌پلاس باز می‌کند.</p></div>
      <a class="btn btn-primary btn-lg btn-block" href="{esc(appurl or url)}" data-soroush-direct data-copy-value="{esc(payload)}">{icon("external")}<span>کپی کلید و بازکردن مستقیم بات</span></a>
      <button class="btn btn-glass btn-block mt-sm" type="button" data-soroush-copy data-copy-value="{esc(payload)}">{icon("copy")}<span>فقط کپی کلید ورود</span></button>
      <div class="alert alert-info mt-lg"><span>اگر بات هنوز Start نشده است، Start را بزنید؛ سپس کلید کپی‌شده را در همان گفت‌وگو Paste و ارسال کنید.</span></div>
      <div class="form-control mt-sm" dir="ltr" data-soroush-command style="user-select:all;overflow-wrap:anywhere;text-align:left">{esc(payload)}</div>
      <a class="btn btn-ghost btn-block mt-sm" href="{esc(url)}" target="_blank" rel="noopener noreferrer">اگر اپ باز نشد: نسخهٔ وب بات</a>
      <div class="alert alert-info mt-lg" data-soroush-state>{icon("clock")}<span>این صفحه باز است و منتظر تأیید شما در سروش‌پلاس می‌ماند…</span></div>
      <div class="auth-foot"><a href="/login">انصراف و بازگشت</a></div>
    </div></div></div>'''
    cid=json_embed(challenge["id"])
    js=f'''<script>(function(){{var b=document.querySelector('[data-soroush-state]'),s=false;
    function copyNow(v){{var t=document.createElement('textarea');t.value=v;t.style.position='fixed';t.style.opacity='0';document.body.appendChild(t);t.select();
      try{{document.execCommand('copy')}}catch(e){{}}document.body.removeChild(t);if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(v).catch(function(){{}})}}
    document.querySelectorAll('[data-copy-value]').forEach(function(c){{c.addEventListener('click',function(){{copyNow(c.getAttribute('data-copy-value')||'');var x=c.querySelector('span');if(x)x.textContent=c.hasAttribute('data-soroush-copy-name')?'نام بات کپی شد':'کلید ورود کپی شد؛ به بات برگردید'}})}});
    function p(){{if(s)return;fetch('/api/soroush/status?id='+encodeURIComponent({cid}),{{credentials:'same-origin',cache:'no-store'}})
    .then(r=>r.json()).then(x=>{{if(x.status==='approved'){{s=true;b.className='alert alert-success mt-lg';b.textContent='{done}';location.replace(x.redirect||'/me');return}}
    if(x.status==='expired'){{s=true;b.className='alert alert-error mt-lg';b.textContent='درخواست منقضی شد؛ دوباره تلاش کنید.';return}}setTimeout(p,1800)}}).catch(()=>setTimeout(p,3000))}}p()}})();</script>'''
    return page(s,heading,body,"",cats=[],body_class="auth-page",extra_js=js)


# ==========================================================================
# ==========================================================================
#  DASHBOARD
# ==========================================================================

def draft_banner(owner):
    """v208: a live registration draft (site or bot) is one click away."""
    try:
        import bot_register as R
        c = db.customer_by_phone(owner["phone"], create=False)
        d = R.get(c["id"]) if c else None
    except Exception:
        d = None
    if not d or not (d["data"] or d["step"] != "category"):
        return ""
    x = d["data"]
    return (f'<div class="alert alert-info mb-md">{icon("refresh")}<span>یک ثبت کسب‌وکار ناتمام دارید'
            f'{(" («" + esc(x["name"]) + "»)") if x.get("name") else ""}. '
            f'<a href="/register-business" style="font-weight:700">ادامهٔ ثبت</a></span></div>')

def dashboard(s, owner, q=None, cust=None):
    mine = db.businesses_of(owner["id"])
    cust_strip = ""
    tot = {"view": 0, "phone": 0, "whatsapp": 0, "route": 0}
    for b in mine:
        st = db.stats_for(b["id"], 30)
        for k in tot:
            tot[k] += st[k]

    pend_rev = sum(1 for b in mine
                   for r in db.reviews(biz_id=b["id"], status="pending"))
    new_book = sum(1 for b in mine
                   for k in db.bookings() if k["biz_id"] == b["id"] and k["status"] == "new")
    n_orders = len(db.orders_for_owner(owner["id"]))
    n_followers = sum(db.follow_count(b["id"]) for b in mine)
    n_chats_unread = db.chat_unread_owner(owner["id"])
    my_stories = db.stories_for_owner(owner["id"])

    if not mine:
        content = (_msg(q) + draft_banner(owner)
                   + (password_reminder("/my/account") if not db.owner_has_password(owner["id"]) else "")
                   + empty_state(
            "store", "هنوز کسب‌وکاری ندارید",
            "اگر قبلاً با شمارهٔ دیگری ثبت کرده‌اید، با همان شماره وارد شوید. "
            "اگر کسب‌وکار شما توسط ما ثبت شده، آن را تصاحب کنید.",
            f'''<div class="cluster mt-lg" style="justify-content:center">
              <a class="btn btn-primary" href="/my/claim">{icon("shield")}<span>تصاحب کسب‌وکار</span></a>
              <a class="btn btn-glass" href="/register-business">{icon("plus")}<span>ثبت کسب‌وکار جدید</span></a>
            </div>'''))
        return shell(s, "داشبورد دکان", "خوش آمدید.", cust_strip + content, "/my", owner)

    STATUS = {"published": ("badge-open", "فعال و منتشرشده"),
              "pending":   ("badge-warn", "در انتظار تأیید"),
              "hidden":    ("badge-neutral", "مخفی"),
              "rejected":  ("badge-closed", "رد شده")}
    _ic = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}
    
    biz_cards = "".join(f'''<article class="card glass card-pad biz-own-card">
      <div class="biz-own-head">
        <div class="biz-own-media">
          {f'<img class="biz-own-cover" src="{esc(b["images"][0])}" alt="{esc(b["name"])}">' if b.get("images") else
           f'<div class="biz-own-cover biz-own-art">{cat_icon(_ic.get(b["cat_slug"], "store"), 128)}</div>'}
          <span class="badge {STATUS.get(b["status"], ("badge-neutral",""))[0]} biz-own-badge">
            {esc(STATUS.get(b["status"], ("", b["status"]))[1])}</span>
        </div>
        <div class="biz-own-main">
          <div class="between" style="align-items:flex-start">
            <div>
              <h3 class="card-title">{esc(b["name"])}</h3>
              <p class="text-xs text-muted">{icon("pin")}<span>{esc(b.get("city") or "نجف‌آباد")}</span>
                {f' · <span>{esc(b.get("address") or "")[:35]}</span>' if b.get("address") else ''}</p>
            </div>
            <div class="card-meta" style="margin:0">{review_score_html(b.get("rating") or 0)}</div>
          </div>
          <div class="biz-own-stats">
            <span class="biz-stat-item">{icon("eye")}<strong class="nums">{fa(b["views"])}</strong><span>بازدید</span></span>
            <span class="biz-stat-item">{icon("image")}<strong class="nums">{fa(len(b.get("images") or []))}</strong><span>عکس</span></span>
            <span class="biz-stat-item">{icon("heart")}<strong class="nums">{fa(db.follow_count(b["id"]))}</strong><span>دنبال‌کننده</span></span>
            <span class="biz-stat-item">{icon("star")}<strong class="nums">{fa(b.get("nreviews") or 0)}</strong><span>نظر</span></span>
          </div>
          <div class="biz-own-actions">
            <a class="btn btn-primary btn-sm" href="/my/business/{b['id']}">{icon("edit")}<span>ویرایش</span></a>
            <a class="btn btn-glass btn-sm" href="/my/catalog/{b['id']}">{icon("shopping")}<span>کاتالوگ</span></a>
            <a class="btn btn-glass btn-sm" href="/my/gallery/{b['id']}">{icon("image")}<span>گالری</span></a>
            <a class="btn btn-glass btn-sm" href="/my/stories">{icon("camera")}<span>استوری</span></a>
            <a class="btn btn-glass btn-sm" href="/my/stats/{b['id']}">{icon("chart")}<span>آمار</span></a>
            <a class="btn btn-ghost btn-sm" href="/b/{esc(b['slug'])}" target="_blank" rel="noopener">{icon("external")}<span>مشاهده</span></a>
          </div>
          {_lifecycle(b)}
        </div>
      </div>
    </article>''' for b in mine)

    todo = ""
    if pend_rev:
        todo += f'<a class="todo-item" href="/my/reviews">{icon("message")}<span>{fa(pend_rev)} نظر در انتظار بررسی مدیر</span>{icon("chevron-left")}</a>'
    if new_book:
        todo += f'<a class="todo-item" href="/my/bookings">{icon("calendar")}<span>{fa(new_book)} نوبت جدید</span>{icon("chevron-left")}</a>'
    if not todo:
        todo = f'<div class="alert alert-success" style="margin:0">{icon("check-circle")}<span>کار معوقی ندارید. همه چیز به‌روز است.</span></div>'

    EXPORTS = [
        ("customers", "user", "فهرست مشتریان",
         "نام هر کسی که نوبت گرفته یا پیام داده (بدون شمارهٔ تلفن — محرمانه)"),
        ("bookings", "calendar", "نوبت‌ها", "همهٔ رزروها با تاریخ و وضعیت"),
        ("inquiries", "message", "پیام مشتریان", "پیام‌ها و پاسخی که دادید"),
        ("items", "shopping", "کاتالوگ", "محصولات و خدمات با قیمت و بازدید"),
    ]
    ex_rows = "".join(
        f'<a class="todo-item" href="/my/export?kind={k}">{icon(ic)}'
        f'<span><strong>{lbl}</strong><br><small class="text-muted">{d}</small></span>'
        f'{icon("download")}</a>' for k, ic, lbl, d in EXPORTS)
    export_box = gate_any(mine, "export", f'''<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-md">{icon("download")} خروجی اکسل از داده‌های شما</h2>
  <p class="text-sm text-muted mb-md">داده‌های کسب‌وکار شما مال خودتان است.
     هر فایل با فرمت CSV دانلود می‌شود و مستقیم در اکسل باز می‌شود.</p>
  <div class="todo-list">{ex_rows}</div>
</div>''')

    b0 = mine[0]
    quick = f'''<div class="card glass card-pad mb-lg">
  <div class="between mb-md">
    <h2 class="card-title">{icon("zap")} کارهای سریع</h2>
    <span class="text-xs text-muted">دسترسی مستقیم</span>
  </div>
  <div class="quick-grid">
    <a class="quick-tile" href="/my/catalog/{b0["id"]}/item/new">
      {icon("plus")}<span>افزودن کالا</span><small>نام و قیمت، تمام</small></a>
    <a class="quick-tile" href="/my/gallery/{b0["id"]}">
      {icon("image")}<span>افزودن عکس</span><small>مستقیم از دوربین</small></a>
    <a class="quick-tile" href="/my/business/{b0["id"]}#hours">
      {icon("clock")}<span>ساعت کاری</span><small>الان باز/بسته</small></a>
    <a class="quick-tile" href="/b/{esc(b0["slug"])}" target="_blank" rel="noopener">
      {icon("eye")}<span>دیدن صفحه‌ام</span><small>نمای مشتری</small></a>
  </div>
</div>'''

    quick_add = f'''<div class="card glass card-pad mb-lg" id="quick-add">
  <div class="between mb-md">
    <h2 class="card-title">{icon("shopping")} افزودن سریع کالا</h2>
    <a class="text-xs" href="/my/catalog/{b0["id"]}/item/new">فرم کامل ←</a>
  </div>
  <form method="post" action="/my/catalog/{b0["id"]}/quick" data-validate>
    <div class="quick-add-row">
      <div class="field" style="margin-bottom:0">
        <label class="sr-only" for="qa-title">نام کالا</label>
        <input class="input" id="qa-title" name="title" required minlength="2"
               placeholder="نام کالا یا خدمت — مثلاً نان سنگک">
      </div>
      <div class="field" style="margin-bottom:0">
        <label class="sr-only" for="qa-price">قیمت</label>
        <input class="input nums" id="qa-price" name="price" inputmode="numeric"
               placeholder="قیمت (تومان)">
      </div>
      <button class="btn btn-primary" type="submit">
        {icon("plus")}<span>افزودن</span></button>
    </div>
    <p class="field-hint mt-sm">{icon("info")} قیمت را خالی بگذارید تا
      «تماس بگیرید» نمایش داده شود. عکس و جزئیات را بعداً اضافه کنید.</p>
  </form>
</div>'''

    qr_card = f'''<div class="card glass card-pad mb-lg">
  <div class="between mb-md">
    <h2 class="card-title">{icon("grid")} بارکد صفحهٔ شما</h2>
    <a class="btn btn-glass btn-sm" href="/qr/{esc(b0["slug"])}.svg?dl=1" download>
      {icon("download")}<span>دانلود</span></a>
  </div>
  <div class="qr-box">
    <img class="qr-img" src="/qr/{esc(b0["slug"])}.svg" alt="بارکد صفحهٔ {esc(b0["name"])}"
         width="200" height="200" loading="lazy">
    <div class="qr-txt">
      <p>این بارکد را چاپ کنید و روی شیشهٔ دکان بچسبانید. هرکس با دوربین
         گوشی اسکن کند، مستقیم به صفحهٔ شما می‌رسد — با ساعت کاری، شماره
         تماس و کاتالوگ.</p>
      <p class="text-xs text-muted">فایل SVG است، یعنی در هر اندازه‌ای چاپ
         شود بی‌کیفیت نمی‌شود. می‌توانید به چاپخانه هم بدهید.</p>
    </div>
  </div>
  <hr class="divider">
  <div class="qr-link">
    <p class="field-label" style="margin:0 0 6px">آدرس اختصاصی صفحهٔ عمومی شما</p>
    <div class="qr-link-row">
      <input class="input nums" id="biz-link-input" dir="ltr" readonly
             value="/b/{esc(b0["slug"])}" data-biz-link aria-label="آدرس صفحهٔ شما">
      <button type="button" class="btn btn-glass copy-link" data-biz-path="/b/{esc(b0["slug"])}">
        {icon("copy")}<span>کپی آدرس</span></button>
    </div>
    <p class="field-hint">در پیام‌رسان‌ها، کارت ویزیت یا شبکه‌های اجتماعی بگذارید؛
       همه با همین لینک مستقیم به صفحهٔ دکان شما می‌رسند.</p>
  </div>
  <script>
  (function(){{
    var inp=document.getElementById('biz-link-input'); var b=document.querySelector('.copy-link');
    if(!inp||!b) return;
    inp.value=location.origin+inp.getAttribute('value');
    b.setAttribute('data-copy',inp.value);
    function done(){{var o=b.querySelector('span');if(o){{var old=o.textContent;o.textContent='کپی شد ✓';b.classList.add('is-copied');setTimeout(function(){{o.textContent=old;b.classList.remove('is-copied');}},1800);}}}}
    function fb(){{var t=document.createElement('textarea');t.value=b.getAttribute('data-copy')||'';t.setAttribute('readonly','');t.style.cssText='position:fixed;opacity:0';document.body.appendChild(t);t.select();try{{document.execCommand('copy');done();}}catch(e){{}}document.body.removeChild(t);}}
    b.addEventListener('click',function(){{var txt=b.getAttribute('data-copy')||'';if(!txt)return;if(navigator.clipboard&&navigator.clipboard.writeText){{navigator.clipboard.writeText(txt).then(done,fb);}}else fb();}});
  }})();
  </script>
</div>'''

    _chk = [
        (len(b0.get("images") or []) > 0, "image", "عکس از دکان یا نمونه‌کار",
         f"/my/gallery/{b0['id']}"),
        (len((b0.get("descr") or "")) >= 20, "edit", "توضیحات کامل کسب‌وکار",
         f"/my/business/{b0['id']}"),
        (bool(b0.get("hours_map")), "clock", "ساعت کاری هفتگی",
         f"/my/business/{b0['id']}"),
        (b0.get("lat") is not None, "pin", "موقعیت روی نقشه",
         f"/my/business/{b0['id']}"),
        (db.items_count(b0["id"]) > 0, "shopping", "حداقل یک محصول یا خدمت",
         f"/my/catalog/{b0['id']}"),
        (any(b0.get(k) for k in db.SOCIAL_KEYS),
         "instagram", "لینک شبکهٔ اجتماعی، پیام‌رسان یا سایت", f"/my/business/{b0['id']}"),
    ]
    _done = sum(1 for ok, *_ in _chk if ok)
    _pct = round(_done / len(_chk) * 100)
    _pct_cls = "is-low" if _pct < 50 else ("is-mid" if _pct < 100 else "is-full")
    _rows = "".join(
        (f'<div class="cmp-row is-done">{icon("check-circle")}'
         f'<span>{esc(label)}</span><span class="cmp-tick">انجام شد</span></div>')
        if ok else
        (f'<a class="cmp-row" href="{href}">{icon(ic)}'
         f'<span>{esc(label)}</span>'
         f'<span class="cmp-go">{icon("chevron-left")}</span></a>')
        for ok, ic, label, href in _chk)
    complete = f'''<div class="card glass card-pad mb-lg" id="completeness">
  <div class="between mb-md">
    <h2 class="card-title">{icon("target")} تکمیل صفحهٔ شما</h2>
    <span class="badge badge-info nums">{fa(_pct)}٪</span>
  </div>
  <div class="cmp-bar"><span class="cmp-fill {_pct_cls}" style="width:{_pct}%"></span></div>
  <p class="text-sm text-muted mt-sm mb-md">صفحه‌های کامل‌تر بسیار بیشتر دیده
     می‌شوند و تماس می‌گیرند. موارد ناتمام را با یک ضربه تکمیل کنید:</p>
  <div class="cmp-list">{_rows}</div>
</div>'''

    _sb_opts = "".join(f'<option value="{b["id"]}">{esc(b["name"])}</option>' for b in mine)
    _story_thumbs = "".join(
        f'<img src="{esc(r["image"])}" alt="" loading="lazy" decoding="async" '
        f'title="{esc(r.get("caption") or "")}">' for r in my_stories[:6])
    story_card = f'''<div class="card glass card-pad mb-lg">
  <div class="between mb-md">
    <h2 class="card-title">{icon("image")} استوری امروز شما</h2>
    <a class="btn btn-glass btn-sm" href="/my/stories">{icon("list")}<span>مدیریت استوری‌ها</span></a>
  </div>
  <div class="story-own-row">
    <div class="story-own-thumbs">{_story_thumbs or '<span class="text-sm text-muted">هنوز استوری ندارید — اولین عکس امروزتان را بگذارید.</span>'}</div>
    <form method="post" action="/my/story/add" enctype="multipart/form-data" class="story-own-form" data-validate data-compress>
      <input type="hidden" name="biz_id" value="{b0["id"]}">
      <input class="input" name="caption" maxlength="200" placeholder="یک جمله کوتاه…" value="">
      <!-- دوربین مستقیم؛ بدون بازشدن انتخاب فایل (capture) -->
      <label class="btn btn-accent btn-sm" style="cursor:pointer">{icon("camera")}<span>عکس/فیلم</span>
        <input type="file" name="story_media" accept="image/*,video/*" capture="environment" required hidden data-compress-input></label>
      <button class="btn btn-primary btn-sm" type="submit">{icon("send")}<span>انتشار</span></button>
    </form>
  </div>
  <p class="field-hint mt-sm">{icon("info")} استوری ۲۴ ساعت روی سایت می‌ماند و در صفحهٔ کسب‌وکار و کارت‌ها با حلقهٔ سبز دیده می‌شود.</p>
</div>'''

    _recent_orders = db.orders_for_owner(owner["id"])[:5]
    _ro_html = "".join(f'''<a class="todo-item" href="/my/orders">
      {icon("cart")}<span><strong>{esc(o["bizname"])} — {esc(o["name"])}</strong><br>
      <small class="text-muted">{fa_group(o["total"])} تومان ·
        <span class="badge {db.ORDER_LABELS.get(o["status"], ("badge-neutral",""))[0]}">{esc(o["status_label"])}</span></small></span>
      {icon("chevron-left")}</a>''' for o in _recent_orders)
    if not _ro_html:
        _ro_html = '<p class="text-sm text-muted">هنوز سفارش آنلاینی ثبت نشده است.</p>'

    _recent_chats = db.chat_threads_for_owner(owner["id"])[:5]
    _rc_html = "".join(f'''<a class="todo-item" href="/my/chat/{t["id"]}">
      {icon("message")}<span><strong>{esc(t.get("custname") or "مشتری")}</strong><br>
      <small class="text-muted">{esc((t.get("last") or {}).get("body", "")[:50])}</small></span>
      {icon("chevron-left")}</a>''' for t in _recent_chats)
    if not _rc_html:
        _rc_html = '<p class="text-sm text-muted">گفتگویی با مشتری شروع نشده است.</p>'

    sections_card = f'''<div class="card glass card-pad mb-lg">
  <div class="between mb-md">
    <h2 class="card-title">{icon("grid")} بخش‌های مدیریت دکان</h2>
    <span class="text-xs text-muted">دسترسی سریع</span>
  </div>
  {nav_tiles([x for x in OWNER_AREA_NAV if x[0] != "/my"])}
</div>'''

    # Layout organized in clean mobile-first order:
    # 1. Flash message & password prompt
    # 2. My Businesses Cards (the core reason owner visits dashboard)
    # 3. Quick actions (افزودن کالا، استوری، ساعت کاری، مشاهده)
    # 4. Stats row (بازدید، تماس، سفارش، پیام)
    # 5. Recent orders & recent chats
    # 6. All panel section tiles
    # 7. Story creator & Completeness & QR
    content = f'''{_msg(q)}{draft_banner(owner)}

<section class="biz-own-section">
  <div class="between mb-md" style="flex-wrap:wrap;gap:8px">
    <h2 class="card-title">{icon("store")} کسب‌وکارهای من ({fa(len(mine))})</h2>
    <a class="btn btn-primary btn-sm" href="/register-business">{icon("plus")}<span>ثبت کسب‌وکار جدید</span></a>
  </div>
  <div class="biz-own-list">{biz_cards}</div>
</section>
{quick}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("eye", tot['view'], "بازدید ۳۰ روز")}
  {stat_card("phone", tot['phone'], "کلیک تماس", delay=60)}
  {stat_card("cart", n_orders, "سفارش آنلاین", delay=120)}
  {stat_card("message", n_chats_unread, "پیام نخوانده", delay=180)}
</div>
<div class="grid grid-2 mb-lg" style="align-items:start">
  <div class="card glass card-pad">
    <div class="between mb-md"><h2 class="card-title">{icon("cart")} آخرین سفارش‌ها</h2>
      <a class="btn btn-ghost btn-sm" href="/my/orders">همه</a></div>
    <div class="todo-list">{_ro_html}</div>
  </div>
  <div class="card glass card-pad">
    <div class="between mb-md"><h2 class="card-title">{icon("message")} آخرین گفتگوها</h2>
      <a class="btn btn-ghost btn-sm" href="/my/chats">همه</a></div>
    <div class="todo-list">{_rc_html}</div>
  </div>
</div>
{sections_card}
{story_card}
{complete}
{quick_add}
{qr_card}
<div class="card glass card-pad mb-lg">
  <div class="between mb-md">
    <h2 class="card-title">{icon("bell")} کارهای در انتظار و دسترسی‌ها</h2>
    <a class="btn btn-glass btn-sm" href="/my/claim">{icon("shield")}<span>تصاحب کسب‌وکار</span></a>
  </div>
  <div class="todo-list">{todo}</div>
</div>
{export_box}'''
    content = cust_strip + content
    return shell(s, "داشبورد دکان", "خلاصهٔ عملکرد کسب‌وکارهای شما.", content, "/my", owner)


# ==========================================================================
#  MY BUSINESSES  ·  EDIT
# ==========================================================================
def _lifecycle(b):
    """v209: status-aware owner controls (withdraw / resubmit / hide / show /
    delete). Every action is a POST with a confirm; delete asks for the name."""
    bid, st, name = b["id"], b["status"], esc(b["name"])

    def btn(act, ic, label, cls="btn-glass", confirm=""):
        attr = f' data-confirm="{esc(confirm)}"' if confirm else ""
        return (f'<form method="post" action="/my/business/{bid}/{act}" class="inl"{attr}>'
                f'<button class="btn {cls} btn-sm" type="submit">{icon(ic)}<span>{label}</span></button></form>')

    def note(cls, ic, title, sub):
        return f'<div class="lc-note {cls}">{icon(ic)}<div><strong>{title}</strong><small>{sub}</small></div></div>'

    parts, info = [], ""
    if st == "pending":
        info = note("lc-warn", "clock", "در صف بررسی مدیر", "معمولاً کمتر از یک روز کاری. تا آن زمان می‌توانید گالری و کاتالوگ را کامل کنید.")
        parts.append(btn("withdraw", "x-circle", "لغو درخواست بررسی",
                         confirm="درخواست بررسی لغو شود؟ کسب‌وکار به حالت پیش‌نویس مخفی می‌رود و بعداً می‌توانید دوباره ارسال کنید."))
    elif st == "hidden":
        if b.get("published_once"):
            info = note("", "eye", "پنهان از سایت", "هر وقت خواستید دوباره نمایش دهید.")
            parts.append(btn("show", "eye", "نمایش دوباره", "btn-primary"))
        else:
            info = note("", "file", "پیش‌نویس — ارسال نشده", "برای انتشار باید برای بررسی مدیر ارسال شود.")
            parts.append(btn("resubmit", "send", "ارسال برای بررسی", "btn-primary", confirm="برای بررسی مدیر ارسال شود؟"))
    elif st == "rejected":
        info = note("lc-err", "x-circle", "رد شده", "اطلاعات را اصلاح کنید و دوباره بفرستید، یا با پشتیبانی صحبت کنید.")
        parts.append(btn("resubmit", "refresh", "اصلاح و ارسال دوباره", "btn-primary", confirm="پس از اصلاح اطلاعات، برای بررسی دوباره ارسال شود؟"))
    elif st == "published":
        parts.append(btn("hide", "eye", "پنهان‌کردن موقت",
                         confirm="کسب‌وکار موقتاً از سایت پنهان شود؟ هر وقت خواستید می‌توانید دوباره نمایش دهید."))
    did = f"lc-del-{bid}"
    parts.append(f'<button class="btn btn-ghost btn-sm lc-danger" type="button" data-dialog-open="{did}">{icon("trash")}<span>حذف کسب‌وکار</span></button>')
    dialog = (
        f'<dialog class="lc-dialog" id="{did}">'
        f'<form method="post" action="/my/business/{bid}/delete" class="lc-dialog-body">'
        f'<h3 class="card-title">{icon("alert")} حذف «{name}»</h3>'
        '<p class="text-sm text-muted">صفحه، کاتالوگ، نظرها، سفارش‌ها و نوبت‌ها از سایت برداشته می‌شوند. '
        'تا <b>۳۰ روز</b> از «بازیابی فایل‌ها» قابل برگرداندن است؛ پس از آن برای همیشه پاک می‌شود.</p>'
        f'<label class="field-label" for="{did}-n">برای تأیید، نام کسب‌وکار را بنویسید</label>'
        f'<input class="input" id="{did}-n" name="confirm_name" autocomplete="off" placeholder="{name}" data-must-equal="{name}" required>'
        '<div class="cluster mt-md" style="justify-content:flex-end">'
        '<button class="btn btn-glass" type="button" data-dialog-close>انصراف</button>'
        f'<button class="btn btn-danger" type="submit" disabled>{icon("trash")}<span>حذف برای ۳۰ روز</span></button>'
        '</div></form></dialog>')
    return f'<div class="lc">{info}<div class="lc-actions">{"".join(parts)}</div></div>{dialog}'


def biz_list(s, owner, q=None):
    mine = db.businesses_of(owner["id"])
    if not mine:
        return shell(s, "کسب‌وکارهای من", "—",
                     _msg(q) + draft_banner(owner) + empty_state("store", "کسب‌وکاری ثبت نشده",
                       "ابتدا کسب‌وکار خود را تصاحب یا ثبت کنید.",
                       f'<a class="btn btn-primary mt-lg" href="/my/claim">{icon("shield")}<span>تصاحب کسب‌وکار</span></a>'
                       f' <a class="btn btn-glass mt-lg" href="/register-business">{icon("plus")}<span>ثبت کسب‌وکار جدید</span></a>'),
                     "/my/businesses", owner)
    _st = {"published": ("badge-open", "فعال و منتشرشده"), "pending": ("badge-warn", "در انتظار تأیید"),
           "hidden": ("badge-neutral", "مخفی"), "rejected": ("badge-closed", "رد شده")}
    _ic = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}
    cards = "".join(f'''<article class="card glass card-pad biz-own-card">
  <div class="biz-own-head">
    <div class="biz-own-media">
      {f'<img class="biz-own-cover" src="{esc(b["images"][0])}" alt="{esc(b["name"])}">' if b.get("images") else
       f'<div class="biz-own-cover biz-own-art">{cat_icon(_ic.get(b["cat_slug"], "store"), 128)}</div>'}
      <span class="badge {_st.get(b["status"], ("badge-neutral",""))[0]} biz-own-badge">{esc(_st.get(b["status"], ("",b["status"]))[1])}</span>
    </div>
    <div class="biz-own-main">
      <div class="between" style="align-items:flex-start">
        <div>
          <h3 class="card-title">{esc(b["name"])}</h3>
          <p class="text-xs text-muted">{icon("pin")}<span>{esc(b.get("city") or "نجف‌آباد")}</span>
            {f' · <span>{esc(b.get("address") or "")[:35]}</span>' if b.get("address") else ''}</p>
        </div>
        <div class="card-meta" style="margin:0">{review_score_html(b.get("rating") or 0)}</div>
      </div>
      <div class="biz-own-stats">
        <span class="biz-stat-item">{icon("eye")}<strong class="nums">{fa(b["views"])}</strong><span>بازدید</span></span>
        <span class="biz-stat-item">{icon("image")}<strong class="nums">{fa(len(b.get("images") or []))}</strong><span>عکس</span></span>
        <span class="biz-stat-item">{icon("heart")}<strong class="nums">{fa(db.follow_count(b["id"]))}</strong><span>دنبال‌کننده</span></span>
        <span class="biz-stat-item">{icon("star")}<strong class="nums">{fa(b.get("nreviews") or 0)}</strong><span>نظر</span></span>
      </div>
      <div class="biz-own-actions">
        <a class="btn btn-primary btn-sm" href="/my/business/{b["id"]}">{icon("edit")}<span>ویرایش</span></a>
        <a class="btn btn-glass btn-sm" href="/my/catalog/{b["id"]}">{icon("shopping")}<span>کاتالوگ</span></a>
        <a class="btn btn-glass btn-sm" href="/my/gallery/{b["id"]}">{icon("image")}<span>گالری</span></a>
        <a class="btn btn-glass btn-sm" href="/my/stories">{icon("camera")}<span>استوری</span></a>
        <a class="btn btn-glass btn-sm" href="/my/stats/{b["id"]}">{icon("chart")}<span>آمار</span></a>
        <a class="btn btn-ghost btn-sm" href="/b/{esc(b["slug"])}" target="_blank" rel="noopener">{icon("external")}<span>مشاهده</span></a>
      </div>
      {_lifecycle(b)}
    </div>
  </div>
</article>''' for b in mine)
    header = f'''<div class="between mb-lg" style="flex-wrap:wrap;gap:10px">
      <div><h2 class="card-title">{icon("store")} کسب‌وکارهای من ({fa(len(mine))})</h2>
        <p class="text-sm text-muted">همهٔ کسب‌وکارهایی که مدیریت می‌کنید — با آمار زنده.</p></div>
      <a class="btn btn-primary" href="/register-business">{icon("plus")}<span>ثبت کسب‌وکار جدید</span></a>
    </div>'''
    content = f'''{_msg(q)}{draft_banner(owner)}{header}
<div class="biz-own-list">{cards}</div>'''
    return shell(s, "کسب‌وکارهای من", "مدیریت همهٔ کسب‌وکارهای شما.",
                 content, "/my/businesses", owner)


DAYS = [("sat","شنبه"),("sun","یک‌شنبه"),("mon","دوشنبه"),("tue","سه‌شنبه"),
        ("wed","چهارشنبه"),("thu","پنج‌شنبه"),("fri","جمعه")]


def biz_edit(s, owner, bid, q=None):
    b = db.business(bid=bid)
    if not b or b.get("owner_id") != owner["id"]:
        return None
    cats = db.category_tree()
    opts = cat_options(cats, selected=b["cat_slug"])
    hm = b["hours_map"]
    hrows = ""
    for k, label in DAYS:
        rng = hm.get(k) or []
        o = rng[0][0] if rng else "09:00"
        c = rng[0][1] if rng else "21:00"
        closed = "" if rng else " checked"
        hrows += f'''<div class="hours-row">
          <span class="text-sm fw-700">{label}</span>
          <input class="input" type="time" name="h_{k}_open" value="{esc(o)}" aria-label="شروع {label}">
          <input class="input" type="time" name="h_{k}_close" value="{esc(c)}" aria-label="پایان {label}">
          <label class="check"><input type="checkbox" name="h_{k}_closed"{closed}><span>تعطیل</span></label>
        </div>'''

    content = f'''{_msg(q)}
<form method="post" action="/my/business/{bid}" data-validate>
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("store")} اطلاعات کسب‌وکار</h2>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="f-name">نام<span class="req">*</span></label>
        <input class="input" id="f-name" name="name" required minlength="2" value="{esc(b['name'])}"></div>
      <div class="field"><label class="field-label" for="f-cat">دسته<span class="req">*</span></label>
        <select class="select" id="f-cat" name="cat_slug" required data-catpick>{opts}</select></div>
    </div>
    <div class="field"><label class="field-label" for="f-desc">توضیحات<span class="req">*</span></label>
      <textarea class="textarea" id="f-desc" name="descr" required minlength="10">{esc(b['descr'])}</textarea></div>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="f-phone">تلفن (شمارهٔ ورود)</label>
        <input class="input" id="f-phone" name="phone" type="tel" value="{esc(owner['phone'])}" readonly>
        <p class="field-hint">شمارهٔ تلفن دکان با شمارهٔ ورود شما یکسان است و از همین صفحه تغییر نمی‌کند.</p></div>
      <div class="field"><label class="field-label" for="f-wa">واتساپ</label>
        <input class="input" id="f-wa" name="whatsapp" type="tel" value="{esc(b['whatsapp'])}"></div>
    </div>
    <div class="field"><label class="field-label" for="f-addr">نشانی</label>
      <input class="input" id="f-addr" name="address" value="{esc(b['address'])}"></div>
    <div class="field"><label class="field-label" for="f-area">محله</label>
      <input class="input" id="f-area" name="area" value="{esc(b.get('area') or '')}" maxlength="100" placeholder="مثلاً امیرآباد"></div>
    <div class="grid grid-2" style="align-items:start">
      <div class="field"><label class="field-label" for="f-prov">استان</label>
        <select class="select" id="f-prov" name="province">
          <option value="">—</option>
          {"".join(f'<option value="{esc(p)}"{" selected" if b.get("province")==p else ""}>{esc(p)}</option>' for p in db.provinces())}
        </select></div>
      <div class="field"><label class="field-label" for="f-city">شهر</label>
        <input class="input" id="f-city" name="city" value="{esc(b.get('city') or '')}" maxlength="100" placeholder="نام شهر"></div>
    </div>
    <div class="field"><label class="field-label" for="f-tags">برچسب‌ها</label>
      <input class="input" id="f-tags" name="tags" value="{esc(b['tags'])}"></div>
    <div class="grid grid-3" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="f-ig">اینستاگرام</label>
        <input class="input" id="f-ig" name="instagram" value="{esc(b['instagram'])}"></div>
      <div class="field"><label class="field-label" for="f-tg">تلگرام</label>
        <input class="input" id="f-tg" name="telegram" value="{esc(b['telegram'])}"></div>
      <div class="field"><label class="field-label" for="f-web">وب‌سایت</label>
        <input class="input" id="f-web" name="website" value="{esc(b['website'])}"></div>
    </div>
    <p class="field-label">پیام‌رسان‌های ایرانی <span class="text-muted">(شناسه یا لینک صفحه)</span></p>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="f-eitaa">{icon("eitaa")} ایتا</label>
        <input class="input" id="f-eitaa" name="eitaa" dir="ltr" value="{esc(b.get('eitaa') or '')}"></div>
      <div class="field"><label class="field-label" for="f-bale">{icon("bale")} بله</label>
        <input class="input" id="f-bale" name="bale" dir="ltr" value="{esc(b.get('bale') or '')}"></div>
      <div class="field"><label class="field-label" for="f-soroush">{icon("soroush")} سروش</label>
        <input class="input" id="f-soroush" name="soroush" dir="ltr" value="{esc(b.get('soroush') or '')}"></div>
      <div class="field"><label class="field-label" for="f-rubika">{icon("rubika")} روبیکا</label>
        <input class="input" id="f-rubika" name="rubika" dir="ltr" value="{esc(b.get('rubika') or '')}"></div>
    </div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("pin")} موقعیت روی نقشه</h2>
    <div class="map-stage" data-map-wrap data-map="pending" style="min-height:320px;border-radius:var(--radius-lg)">
      <div data-map-canvas data-pick data-lat="{b['lat'] or s.get('map_lat')}"
           data-lng="{b['lng'] or s.get('map_lng')}" style="position:absolute;inset:0"></div>
      <div class="map-legend">{icon("info")}<span data-map-status>بارگذاری…</span></div>
    </div>
    <div class="grid grid-2 mt-md" style="gap:0 var(--space-md)">
      <div class="field" style="margin-bottom:0"><label class="field-label" for="f-lat">عرض جغرافیایی</label>
        <input class="input nums" id="f-lat" name="lat" value="{b['lat'] or ''}"></div>
      <div class="field" style="margin-bottom:0"><label class="field-label" for="f-lng">طول جغرافیایی</label>
        <input class="input nums" id="f-lng" name="lng" value="{b['lng'] or ''}"></div>
    </div>
    <button class="btn btn-glass btn-sm mt-md" type="button" data-geo-fill aria-label="دریافت موقعیت فعلی من">
      {icon("compass")}<span>گرفتن موقعیت فعلی من</span></button>
    <p class="field-hint" data-geo-msg hidden></p>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("clock")} ساعت کاری</h2>
    <div class="hours-grid">{hrows}</div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("calendar")} رزرو نوبت</h2>
    <label class="switch"><input type="checkbox" name="booking_on"
      {" checked" if b['booking_on'] else ""}><span class="track"></span>
      <span>مشتریان بتوانند آنلاین نوبت بگیرند</span></label>
  </div>

  <div class="cluster">
    <button class="btn btn-primary btn-lg" type="submit">{icon("check")}<span>ذخیرهٔ تغییرات</span></button>
    <a class="btn btn-glass btn-lg" href="/my/gallery/{bid}">{icon("image")}<span>گالری</span></a>
    <a class="btn btn-glass btn-lg" href="/my/catalog/{bid}">{icon("shopping")}<span>کاتالوگ</span></a>
    <a class="btn btn-ghost btn-lg" href="/b/{esc(b['slug'])}" target="_blank" rel="noopener">
      {icon("external")}<span>مشاهده در سایت</span></a>
  </div>
</form>'''
    return shell(s, f"ویرایش: {b['name']}",
                 "تغییرات پس از ذخیره بلافاصله روی سایت اعمال می‌شود.",
                 content, "/my/businesses", owner, extra_js=MAP_JS)


# ==========================================================================
#  GALLERY
# ==========================================================================
def gallery(s, owner, bid, q=None, admin_token=""):
    b = db.business(bid=bid)
    if not b:
        return None
    if not admin_token and b.get("owner_id") != owner["id"]:
        return None
    imgs = b["images"]
    back = f"/panel/business/{bid}" if admin_token else f"/my/business/{bid}"
    action = "/panel/gallery" if admin_token else "/my/gallery"

    # The cap the server actually enforces on upload (app.py uses the same
    # number), so the counter can never promise slots the upload will refuse.
    acc = db.access(bid)
    cap = 15 if admin_token else acc["max_photos"]
    full = len(imgs) >= cap

    hint = ""
    if not admin_token and not db.can(bid, "gallery"):
        hint = (f'<div class="alert alert-warn mb-lg">{icon("lock")}<span>'
                f'پلن فعلی شما <strong>{fa(cap)} عکس</strong> اجازه می‌دهد. '
                f'با «گالری تصاویر کامل» تا {fa(20)} عکس بگذارید — '
                f'<a href="/pricing">دیدن پلن‌ها</a></span></div>')
    elif full:
        hint = (f'<div class="alert alert-info mb-lg">{icon("info")}<span>'
                f'به سقف {fa(cap)} عکس رسیده‌اید. برای افزودن عکس تازه، '
                f'یکی از عکس‌های فعلی را حذف کنید.</span></div>')

    cur_cover = b.get("cover") or ""
    if imgs:
        tiles = ""
        for src in imgs:
            on = " is-on" if src == cur_cover else ""
            tiles += (f'<button class="cover-tile{on}" type="submit" name="src" '
                      f'value="{esc(src)}" title="انتخاب به‌عنوان پس‌زمینه">'
                      f'<img src="{esc(src)}" alt="" loading="lazy">'
                      f'<span class="cover-mark">{icon("check")}</span></button>')
        clear = (f'<button class="btn btn-ghost btn-sm mt-md" type="submit" '
                 f'name="src" value="">{icon("x")}<span>بدون پس‌زمینه '
                 f'(زمینهٔ پیش‌فرض سایت)</span></button>' if cur_cover else "")
        cover_pick = (f'<form method="post" action="{action}/{bid}/banner">'
                      f'<input type="hidden" name="key" value="{esc(admin_token)}">'
                      f'<div class="cover-grid">{tiles}</div>{clear}</form>')
    else:
        cover_pick = ('<p class="text-sm text-muted">اول چند عکس بالا اضافه '
                      'کنید تا بتوانید یکی را پس‌زمینه کنید.</p>')

    content = f'''{_msg(q)}
{hint}
<div class="card glass card-pad mb-lg">
  <div class="between mb-lg">
    <h2 class="card-title">{icon("image")} گالری {esc(b['name'])}</h2>
    <span class="badge {"badge-warn" if full else "badge-neutral"}">{fa(len(imgs))} از {fa(cap)}</span>
  </div>

  <form method="post" action="{action}/{bid}/upload" enctype="multipart/form-data">
    <input type="hidden" name="key" value="{esc(admin_token)}">
    <div data-imagefield data-name="images" data-max="{cap}"
         data-existing='{json_embed(imgs)}'></div>
    <div class="cluster mt-md">
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیرهٔ گالری</span></button>
      <a class="btn btn-ghost" href="{back}">{icon("x")}<span>انصراف</span></a>
    </div>
  </form>
</div>

<!-- The shop's own background. A shopkeeper who has a good photo of their
     storefront should be able to put it behind their page header instead of
     living with the site gradient. Chosen from photos already uploaded, so
     there is no second upload flow to learn. -->
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-md">{icon("image")} تصویر پس‌زمینهٔ صفحهٔ شما</h2>
  <p class="text-sm text-muted mb-lg">یکی از عکس‌های بالا را به‌عنوان
    پس‌زمینهٔ سربرگ صفحه‌تان انتخاب کنید. عکس افقی و روشن بهترین نتیجه را
    می‌دهد.</p>
  {cover_pick}
</div>

'''

    if admin_token:
        from ui import panel_page
        return panel_page(s, f"گالری: {b['name']}", "افزودن و حذف تصاویر.",
                          content, "/panel/businesses", admin_token, extra_js=UP_JS)
    return shell(s, f"گالری: {b['name']}", "تصاویر کسب‌وکار خود را مدیریت کنید.",
                 content, "/my/businesses", owner, extra_js=UP_JS)


# ==========================================================================
#  STATS
# ==========================================================================
def stats(s, owner, bid, q=None):
    b = db.business(bid=bid)
    if not b or b.get("owner_id") != owner["id"]:
        return None
    st = db.stats_for(b["id"], 30)
    series = st["series"]
    mx = max((v for _, v in series), default=0) or 1
    bars = "".join(f'''<div class="spark-col" title="{d}: {v}">
      <span class="spark-bar" style="height:{max(2, v / mx * 100):.0f}%"></span></div>'''
      for d, v in series)

    conv = 0
    if st["view"]:
        conv = round((st["phone"] + st["whatsapp"] + st["route"]) / st["view"] * 100)

    # ---- real-visitor analytics from the visits table (bots excluded)
    now = time.time()

    def _pvuv(days):
        r = db._one("SELECT COUNT(*) pv, COUNT(DISTINCT cid) uv FROM visits "
                    "WHERE biz_id=? AND bot=0 AND ts>=?",
                    (b["id"], now - days * 86400)) or {}
        return r.get("pv", 0) or 0, r.get("uv", 0) or 0

    pv24, uv24 = _pvuv(1)
    pv7, uv7 = _pvuv(7)
    pv30, uv30 = _pvuv(30)
    orders30 = (db._one("SELECT COUNT(*) n FROM orders WHERE biz_id=? "
                        "AND created>=datetime('now','-30 day')",
                        (b["id"],)) or {}).get("n", 0)
    actions30 = st["phone"] + st["whatsapp"] + st["route"]

    body = f'''<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("eye", st['view'], "بازدید صفحه")}
  {stat_card("phone", st['phone'], "کلیک تماس", delay=60)}
  {stat_card("whatsapp", st['whatsapp'], "کلیک واتساپ", delay=120)}
  {stat_card("compass", st['route'], "درخواست مسیر", delay=180)}
</div>

<div class="card glass card-pad mb-lg">
  <div class="between mb-lg">
    <h2 class="card-title">{icon("chart")} بازدید ۳۰ روز اخیر</h2>
    <span class="badge badge-info">{icon("trending")}<span>نرخ تماس {fa(conv)}٪</span></span>
  </div>
  <div class="sparkline">{bars}</div>
  <div class="between text-xs text-muted mt-sm">
    <span>۳۰ روز پیش</span><span>امروز</span>
  </div>
</div>

<div class="card glass card-pad mb-lg">
  <div class="between mb-md" style="flex-wrap:wrap;gap:8px">
    <h2 class="card-title">{icon("users")} بازدیدکنندهٔ واقعی</h2>
    <span class="badge badge-info">{icon("shield")}<span>فقط کاربران واقعی (بدون بات)</span></span>
  </div>
  <div class="grid grid-3 mb-md" data-stagger>
    {stat_card("user", uv24, "بازدیدکنندهٔ ۲۴ ساعت")}
    {stat_card("user", uv7, "بازدیدکنندهٔ ۷ روز", delay=60)}
    {stat_card("user", uv30, "بازدیدکنندهٔ ۳۰ روز", delay=120)}
  </div>
  <p class="text-sm text-muted" style="margin:0">این آمار بر اساس شناسهٔ مرورگر افراد شمرده شده و ربات‌ها، خزنده‌ها و بازدیدهای تکراری از آن فیلتر شده‌اند تا دید دقیقی از مخاطبان واقعی دکان خود داشته باشید.</p>
</div>

<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-lg">{icon("trending")} قیف ۳۰ روز: بازدید ← اقدام ← سفارش</h2>
  <div class="grid grid-3" data-stagger>
    {stat_card("eye", pv30, "بازدید واقعی")}
    {stat_card("phone", actions30, "اقدام (تماس/واتساپ/مسیر)", delay=60)}
    {stat_card("cart", orders30, "سفارش", delay=120)}
  </div>
</div>

<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("info")} این اعداد یعنی چه؟</h2>
  <div class="info-row">{icon("eye")}<span class="k">بازدید</span>
    <span class="v">چند بار صفحهٔ شما باز شده است.</span></div>
  <div class="info-row">{icon("phone")}<span class="k">کلیک تماس</span>
    <span class="v">چند نفر روی شمارهٔ تلفن شما زده‌اند — یعنی قصد تماس داشته‌اند.</span></div>
  <div class="info-row">{icon("compass")}<span class="k">درخواست مسیر</span>
    <span class="v">چند نفر مسیریابی تا محل شما را باز کرده‌اند.</span></div>
  <div class="info-row">{icon("trending")}<span class="k">نرخ تماس</span>
    <span class="v">از هر ۱۰۰ بازدید، چند نفر اقدام عملی کرده‌اند.</span></div>
</div>'''
    content = _msg(q) + gated("stats", b["id"], body)
    return shell(s, f"آمار: {b['name']}", "عملکرد صفحهٔ شما در ۳۰ روز گذشته.",
                 content, "/my/businesses", owner)


# ==========================================================================
#  REVIEWS / BOOKINGS (owner view)
# ==========================================================================
def reviews(s, owner, q=None):
    mine = db.businesses_of(owner["id"])
    ids = {b["id"]: b["name"] for b in mine}
    rows = [r for r in db.reviews() if r["biz_id"] in ids]
    items = "".join(f'''<article class="review">
      <div class="review-head"><span class="avatar" aria-hidden="true">{esc(r['author'][:1])}</span>
        <div style="flex:1"><strong>{esc(r['author'])}</strong>
          <div class="card-meta" style="margin-top:3px">{review_score_html(r['rating'])}
            <span aria-hidden="true">·</span><span>{esc(ids[r['biz_id']])}</span></div></div>
        <span class="badge {"badge-open" if r['status']=='approved' else "badge-warn"}">
          {esc({"approved":"منتشرشده","pending":"در انتظار مدیر","rejected":"رد شده"}.get(r['status']))}</span>
      </div>
      <p class="review-body">{esc(r['body'])}</p>
      {f'<div class="review-reply"><strong>{icon("store")}پاسخ شما</strong>{esc(r["reply"])}</div>' if r['reply'] else ''}
      <form method="post" action="/my/review/{r['id']}" class="mt-md">
        <label class="sr-only" for="rp{r['id']}">پاسخ</label>
        <textarea class="textarea" id="rp{r['id']}" name="reply" style="min-height:80px"
          placeholder="پاسخ خود را بنویسید…">{esc(r['reply'])}</textarea>
        <button class="btn btn-primary btn-sm mt-sm" type="submit">
          {icon("send")}<span>ثبت پاسخ</span></button>
      </form></article>''' for r in rows)
    if not items:
        items = empty_state("message", "نظری ثبت نشده",
                            "وقتی مشتریان نظر بدهند، اینجا می‌بینید و می‌توانید پاسخ دهید.")
    # Reading reviews is always free — only the reply box is a paid feature,
    # so blur just the panel that holds the reply forms.
    body = gate_any(mine, "reply", f'<div class="card glass card-pad">{items}</div>')
    return shell(s, "نظرات مشتریان", "به نظرات پاسخ رسمی بدهید.",
                 _msg(q) + body, "/my/reviews", owner)


def bookings(s, owner, q=None):
    mine = db.businesses_of(owner["id"])
    ids = {b["id"]: b["name"] for b in mine}
    rows = [k for k in db.bookings() if k["biz_id"] in ids]
    BADGE = {"new":"badge-warn","confirmed":"badge-info","done":"badge-open","cancelled":"badge-closed"}
    LABEL = {"new":"جدید","confirmed":"تأییدشده","done":"انجام‌شده","cancelled":"لغو"}
    trs = "".join(f'''<tr>
      <td><strong>{esc(k['name'])}</strong><br><small class="text-muted">شمارهٔ تماس: محرمانه</small></td>
      <td>{esc(ids[k['biz_id']])}</td>
      <td class="num">{esc(jdate(k['date']))} — {esc(k['time'])}</td>
      <td><span class="badge {BADGE.get(k['status'],'badge-neutral')}">{LABEL.get(k['status'],k['status'])}</span></td>
      <td class="actions"><form method="post" action="/my/booking/{k['id']}" style="display:flex;gap:4px">
        <button class="btn-icon" type="submit" name="status" value="confirmed"
          aria-label="تأیید نوبت" title="تأیید">{icon("check")}</button>
        <button class="btn-icon" type="submit" name="status" value="done"
          aria-label="انجام شد" title="انجام شد">{icon("check-circle")}</button>
        <button class="btn-icon" type="submit" name="status" value="cancelled"
          aria-label="لغو" title="لغو" style="color:var(--color-destructive)">{icon("x")}</button>
      </form></td></tr>''' for k in rows)
    if not trs:
        body = empty_state("calendar", "نوبتی ثبت نشده",
                           "پس از فعال‌سازی «رزرو نوبت» در ویرایش کسب‌وکار، درخواست‌ها اینجا می‌آیند.")
    else:
        body = f'''<div class="table-wrap"><table class="table">
          <thead><tr><th>مشتری</th><th>کسب‌وکار</th><th>زمان</th><th>وضعیت</th><th>عملیات</th></tr></thead>
          <tbody>{trs}</tbody></table></div>'''
    wrapped = gate_any(mine, "booking", f'<div class="card glass card-pad">{body}</div>')
    return shell(s, "نوبت‌ها", "درخواست‌های رزرو مشتریان.",
                 _msg(q) + wrapped, "/my/bookings", owner)


# ==========================================================================
#  CLAIM
# ==========================================================================
def claim(s, owner, q=None, term=""):
    if s.get("claims_enabled") != "1":
        return shell(s, "تصاحب کسب‌وکار", "—",
                     empty_state("lock", "این بخش غیرفعال است",
                                 "برای تصاحب کسب‌وکار با پشتیبانی تماس بگیرید."),
                     "/my/claim", owner)

    mine = db.claims()
    my_claims = [c for c in mine if c["owner_id"] == owner["id"]]
    hist = ""
    if my_claims:
        rows = "".join(f'''<tr><td><strong>{esc(c['bizname'])}</strong></td>
          <td><span class="badge {"badge-open" if c['status']=='approved' else ("badge-warn" if c['status']=='pending' else "badge-closed")}">
            {esc({"approved":"تأییدشده","pending":"در حال بررسی","rejected":"رد شده"}.get(c['status']))}</span></td>
          <td class="num">{esc(jdate(c['created']))}</td></tr>''' for c in my_claims)
        hist = f'''<div class="card glass card-pad mb-lg">
          <h2 class="card-title mb-lg">{icon("list")} درخواست‌های شما</h2>
          <div class="table-wrap"><table class="table">
            <thead><tr><th>کسب‌وکار</th><th>وضعیت</th><th>تاریخ</th></tr></thead>
            <tbody>{rows}</tbody></table></div></div>'''

    results = ""
    if term:
        found = [b for b in db.search(term=term) if not b.get("owner_id")]
        if found:
            results = "".join(f'''<div class="claim-row">
              <div><strong>{esc(b['name'])}</strong>
                <div class="text-xs text-muted">{esc(b['address'])}</div></div>
              <form method="post" action="/my/claim">
                <input type="hidden" name="biz_id" value="{b['id']}">
                <button class="btn btn-primary btn-sm" type="submit">
                  {icon("shield")}<span>این مال من است</span></button></form>
            </div>''' for b in found[:12])
            results = f'<div class="card glass card-pad mb-lg"><h2 class="card-title mb-lg">{icon("search")} نتایج</h2>{results}</div>'
        else:
            results = f'''<div class="card glass card-pad mb-lg">
              {empty_state("search", "چیزی پیدا نشد",
                "کسب‌وکاری با این نام یافت نشد، یا قبلاً مالک دارد. می‌توانید آن را ثبت کنید.",
                f'<a class="btn btn-primary mt-lg" href="/register-business">{icon("plus")}<span>ثبت کسب‌وکار جدید</span></a>')}
            </div>'''

    content = f'''{_msg(q)}
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-lg">{icon("shield")} کسب‌وکار خود را پیدا کنید</h2>
  <p class="text-sm text-muted mb-lg">اگر کسب‌وکار شما توسط ما در سایت ثبت شده،
    آن را جست‌وجو کنید و درخواست تصاحب بدهید. پس از تأیید مدیر، مدیریت کامل
    صفحه به شما سپرده می‌شود.</p>
  <form method="get" action="/my/claim">
    <div class="dir-row">
      <span class="search-wrap">{icon("search", cls="search-icon")}
        <label class="sr-only" for="cq">نام کسب‌وکار</label>
        <input class="input" id="cq" name="q" type="search" value="{esc(term)}"
               placeholder="نام کسب‌وکار خود را بنویسید…" autocomplete="off"></span>
      <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
    </div>
  </form>
</div>
{results}
{hist}'''
    return shell(s, "تصاحب کسب‌وکار",
                 "کسب‌وکاری که قبلاً ثبت شده را به نام خود بگیرید.",
                 content, "/my/claim", owner)


# ==========================================================================
#  v3 — owner screens: questions, subscription, badges
# ==========================================================================
def questions(s, owner, q=None):
    """Answer customer questions about your own shops. An owner can only ever
    touch questions belonging to a business they own."""
    q = q or {}
    mine = db.businesses_of(owner["id"])
    ids = {b["id"] for b in mine}
    rows = [r for r in db.questions() if r["biz_id"] in ids]

    if not mine:
        return shell(s, "پرسش و پاسخ", "سؤال‌های مشتریان شما.",
                     _msg(q) + empty_state("help", "هنوز کسب‌وکاری ندارید",
                        "بعد از ثبت کسب‌وکار، پرسش‌های مشتریان اینجا می‌آید."),
                     "/my/questions", owner)

    LBL = {"pending": ("badge-warn", "در انتظار انتشار"),
           "published": ("badge-open", "منتشرشده"),
           "rejected": ("badge-closed", "رد شده")}
    items = "".join(f'''<article class="review">
      <div class="review-head">
        <span class="avatar" aria-hidden="true">{esc((r['asker'] or '?')[:1])}</span>
        <div style="flex:1"><strong>{esc(r['asker'])}</strong>
          <div class="card-meta" style="margin-top:3px">
            <span>{esc(r['bizname'])}</span><span aria-hidden="true">·</span>
            <span class="text-xs nums">{fa(jdate(r['created']))}</span></div></div>
        <span class="badge {LBL.get(r['status'],('badge-neutral',''))[0]}">
          {esc(LBL.get(r['status'], ('', r['status']))[1])}</span>
      </div>
      <p class="review-body">{esc(r['body'])}</p>
      {f'<div class="review-reply"><strong>{icon("store")}پاسخ شما</strong>{esc(r["answer"])}</div>' if r['answer'] else ''}
      <form method="post" action="/my/question/{r['id']}" class="mt-md">
        <label class="sr-only" for="oq{r['id']}">پاسخ</label>
        <textarea class="textarea" id="oq{r['id']}" name="answer" style="min-height:80px"
          placeholder="پاسخ شما — پس از ثبت، روی صفحهٔ کسب‌وکار منتشر می‌شود.">{esc(r['answer'])}</textarea>
        <button class="btn btn-primary btn-sm mt-sm" type="submit">
          {icon("send")}<span>ثبت پاسخ و انتشار</span></button>
      </form></article>''' for r in rows)

    if not items:
        items = ('<p class="text-sm text-muted">هنوز کسی از شما سؤالی نپرسیده. '
                 'وقتی بپرسند، اینجا خبردار می‌شوید.</p>')

    n_wait = len([r for r in rows if not r["answer"]])
    warn = ""
    if n_wait:
        warn = (f'<div class="alert alert-warn mb-lg">{icon("bell")}<span>'
                f'{fa(n_wait)} پرسش بی‌پاسخ دارید. پاسخ سریع، اعتماد مشتری را بالا می‌برد.'
                f'</span></div>')
    body = gate_any(mine, "qa", f'<div class="card glass card-pad">{items}</div>')
    if not any(db.can(b["id"], "qa") for b in mine):
        warn = ""      # do not nag about answering when answering is locked
    content = f'{_msg(q)}{warn}{body}'
    return shell(s, "پرسش و پاسخ", "به سؤال مشتریان دربارهٔ کسب‌وکارتان پاسخ دهید.",
                 content, "/my/questions", owner)


def plan_page(s, owner, q=None):
    """The owner's own subscription: what plan they are on, when it expires,
    and how to upgrade or renew — all backed by the real subscriptions table."""
    q = q or {}
    mine = db.businesses_of(owner["id"])
    if not mine:
        return shell(s, "اشتراک من", "پلن و اعتبار کسب‌وکار شما.",
                     _msg(q) + empty_state("wallet", "هنوز کسب‌وکاری ندارید",
                        "پس از ثبت کسب‌وکار می‌توانید پلن بگیرید."),
                     "/my/plan", owner)

    S_LBL = {"pending": ("badge-warn", "در انتظار تأیید پرداخت"),
             "active": ("badge-open", "فعال"),
             "expired": ("badge-closed", "منقضی"),
             "cancelled": ("badge-neutral", "لغو شده")}

    blocks = ""
    for b in mine:
        sub = db.subscription_of(b["id"])
        lim = db.plan_limits(b["id"])
        hist = db.subscriptions(biz_id=b["id"])
        n_items = db.items_count(b["id"])
        n_photos = len(b.get("images") or [])

        if sub:
            days = sub.get("days_left")
            urgency = ""
            if days is not None and days <= 14:
                urgency = (f'<div class="alert alert-warn mt-md">{icon("bell")}'
                           f'<span>تنها {fa(days)} روز تا پایان اعتبار مانده. '
                           f'برای قطع نشدن امتیازها تمدید کنید.</span></div>')
            state = f'''<div class="between">
              <div><strong style="font-size:var(--fs-lg)">{esc(sub.get("planname") or sub["plan_slug"])}</strong>
                <p class="plan-expiry">اعتبار تا <span class="nums">{jdate(sub["expires"] or "—")}</span>
                  {f'({fa(days)} روز مانده)' if days is not None else ''}</p></div>
              <span class="badge {S_LBL.get(sub["status"],("badge-neutral",""))[0]}">
                {esc(S_LBL.get(sub["status"], ("", sub["status"]))[1])}</span></div>
            {urgency}'''
        else:
            pending = [x for x in hist if x["status"] == "pending"]
            if pending:
                _pd = pending[0]
                _pinfo = (f' — {fa_group(_pd["amount"])} تومان'
                          f' برای {fa(_pd.get("months_eff") or 12)} ماه'
                          if (_pd.get("amount") or 0) > 0 else '')
                _pmethod = ("کارت‌به‌کارت" if _pd.get("method") == "manual"
                            else (_pd.get("method") or ""))
                _pmeta = ""
                if _pd.get("ref"):
                    _pmeta += (f'<div class="info-row">{icon("hash")}<span class="k">کد پیگیری</span>'
                               f'<span class="v nums" dir="ltr">{esc(_pd["ref"])}</span></div>')
                if _pd.get("receipt"):
                    _pmeta += (f'<div class="info-row">{icon("image")}<span class="k">فیش ارسالی</span>'
                               f'<span class="v"><a class="pay-receipt" href="{esc(_pd["receipt"])}" target="_blank" rel="noopener">'
                               f'<img src="{esc(_pd["receipt"])}" alt="فیش پرداخت" loading="lazy"> مشاهده</a></span></div>')
                state = f'''<div class="alert alert-info">{icon("clock")}<span>
                  <strong>در انتظار تأیید پرداخت</strong> — درخواست پلن «{esc(_pd.get("planname") or _pd["plan_slug"])}»{_pinfo}
                  با روش {esc(_pmethod)} ثبت شد و برای مدیر ارسال گردید.
                  معمولاً در کمتر از ۲۴ ساعت بررسی و فعال می‌شود؛ اگر فیش ارسال کرده‌اید همین‌جا پیوست شده است.</span>
                  {f'<div class="pay-meta mt-sm">{_pmeta}</div>' if _pmeta else ''}</div>'''
            else:
                state = f'''<div class="between">
                  <div><strong style="font-size:var(--fs-lg)">پلن پایه (رایگان)</strong>
                    <p class="plan-expiry">بدون محدودیت زمانی</p></div>
                  <span class="badge badge-neutral">رایگان</span></div>'''

        badges = db.biz_badges(b["id"])
        # v117/فاز۷: متن با توکن تم (کنتراست AA)؛ رنگ خام فقط روی حاشیه/پس‌زمینه
        bhtml = "".join(
            f'<span class="badge badge-custom" style="background:{esc(x["color"])}1F;'
            f'color:var(--color-foreground);border-color:{esc(x["color"])}66">'
            f'<span>{esc(x["name"])}</span></span>' for x in badges)

        hrows = "".join(f'''<tr>
          <td>{esc(h.get("planname") or h["plan_slug"])}</td>
          <td class="num nums">{fa_group(h["amount"])}</td>
          <td class="num nums">{fa(h.get("months_eff") or 12)} ماه</td>
          <td class="num nums">{jdate(h["starts"]) if h["starts"] else "—"}</td>
          <td class="num nums">{jdate(h["expires"]) if h["expires"] else "—"}</td>
          <td><span class="badge {S_LBL.get(h["status"],("badge-neutral",""))[0]}">
            {esc(S_LBL.get(h["status"], ("", h["status"]))[1])}</span></td>
        </tr>''' for h in hist)

        # ---- the feature matrix: what is on, what is locked, and why.
        # This is the page that sells; it must be honest and specific.
        acc = db.access(b["id"])
        on_rows, off_rows = "", ""
        SRC_LABEL = {"plan": "پلن", "founder": "بنیان‌گذار", "manual": "هدیه"}
        for key, label, ic, _f, why in db.FEATURES:
            try:
                gi = icon(ic)
            except KeyError:
                gi = icon("check")
            if key in acc["keys"]:
                src = acc["source"].get(key, "plan")
                on_rows += (f'<div class="unlock-row is-on">{gi}'
                            f'<span class="u-label">{esc(label)}'
                            f'<span class="u-why">{esc(why)}</span></span>'
                            f'<span class="unlock-src src-{src}">'
                            f'{esc(SRC_LABEL.get(src, src))}</span></div>')
            else:
                off_rows += (f'<div class="unlock-row">{icon("lock")}'
                             f'<span class="u-label">{esc(label)}'
                             f'<span class="u-why">{esc(why)}</span></span>'
                             f'<a class="btn btn-primary btn-sm" href="/pricing">'
                             f'{icon("zap")}<span>باز کن</span></a></div>')

        matrix = f'''<hr class="divider">
      <div class="grid grid-2" style="gap:var(--space-lg);align-items:start">
        <div><h3 class="card-title mb-md">{icon("check-circle")} فعال برای شما
          <span class="badge badge-open">{fa(len(acc["keys"]))}</span></h3>
          <div class="unlock-grid">{on_rows or '<p class="text-sm text-muted">هنوز قابلیتی فعال نیست.</p>'}</div></div>
        <div><h3 class="card-title mb-md">{icon("lock")} قفل
          <span class="badge badge-warn">{fa(len(db.FEATURES) - len(acc["keys"]))}</span></h3>
          <div class="unlock-grid">{off_rows or '<p class="text-sm text-muted">همهٔ قابلیت‌ها برای شما باز است.</p>'}</div></div>
      </div>'''

        founder_note = ""
        if acc["founder"]:
            founder_note = (f'<div class="founder-ribbon mt-md">{icon("award")}'
                            f'<span>شما کسب‌وکار شمارهٔ <strong>{fa(acc["rank"])}</strong> '
                            f'دست گیر هستید — عضو بنیان‌گذار. قابلیت‌های نشان‌دار '
                            f'«بنیان‌گذار» برای شما <strong>همیشه رایگان</strong> است.</span></div>')

        blocks += f'''<div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-lg">{icon("store")} {esc(b["name"])}</h2>
      {state}
      <div class="grid grid-2 mt-lg" style="gap:10px">
        <div class="info-row">{icon("shopping")}<span class="k">محصول و خدمت</span>
          <span class="v nums">{fa(n_items)} از {fa(lim["max_items"])}</span></div>
        <div class="info-row">{icon("image")}<span class="k">تصویر گالری</span>
          <span class="v nums">{fa(n_photos)} از {fa(lim["max_photos"])}</span></div>
      </div>
      {f'<div class="badge-strip mt-md">{bhtml}</div>' if bhtml else ''}
      {founder_note}
      {matrix}
      {f"""<div class="table-wrap mt-lg"><table class="table">
        <thead><tr><th>پلن</th><th>مبلغ</th><th>مدت</th><th>شروع</th><th>انقضا</th><th>وضعیت</th></tr></thead>
        <tbody>{hrows}</tbody></table></div>""" if hist else ''}
      <a class="btn btn-primary btn-sm mt-lg" href="/pricing">
        {icon("zap")}<span>{"تمدید یا ارتقای پلن" if sub else "دیدن پلن‌ها و ارتقا"}</span></a>
    </div>'''

    content = _msg(q) + blocks
    return shell(s, "اشتراک من", "پلن، اعتبار و سقف امکانات کسب‌وکار شما.",
                 content, "/my/plan", owner)


# ==========================================================================
#  چانه‌زنی — the seller's side of the negotiation
# ==========================================================================
def offers(s, owner, q=None):
    """Every open negotiation across this owner's shops.

    Gated behind `inquiry`: haggling is the same commercial capability as
    receiving quote requests, so it belongs to the same feature key rather
    than inventing a fifteenth one for the shopkeeper to reason about.
    """
    q = q or {}
    mine = db.businesses_of(owner["id"])
    ids = {b["id"] for b in mine}
    db.expire_haggles()

    if not mine:
        return shell(s, "پیشنهادهای قیمت", "چانه‌زنی مشتریان.",
                     _msg(q) + empty_state("tag", "هنوز کسب‌وکاری ندارید",
                        "پس از ثبت کسب‌وکار و باز کردن چانه‌زنی روی کالاها، "
                        "پیشنهادهای مشتریان اینجا می‌آید."),
                     "/my/offers", owner)

    rows = [h for h in db.haggles() if h["biz_id"] in ids]
    st = {"total": len(rows),
          "open": sum(1 for r in rows if r["status"] == "open"),
          "accepted": sum(1 for r in rows if r["status"] == "accepted"),
          "countered": sum(1 for r in rows if r["status"] == "countered")}

    cards = ""
    for h in rows:
        thread = db.haggle_thread(root_id=h["id"])
        last = thread[-1] if thread else h
        cls, label = V2.HAG_STATUS.get(h["status"], ("badge-neutral", h["status"]))
        listed = int(h.get("itemprice") or 0)
        floor = int(h.get("floor_price") or 0)
        gap = ""
        if listed and h["offer"]:
            off_pct = round((listed - h["offer"]) / listed * 100)
            gap = (f'<span class="text-xs text-muted">'
                   f'{fa(off_pct)}٪ پایین‌تر از قیمت اعلام‌شده</span>')
        floor_note = ""
        if floor:
            ok = h["offer"] >= floor
            floor_note = (f'<span class="badge {"badge-open" if ok else "badge-warn"}">'
                          f'{icon("shield")}<span>کف شما: {fa_group(floor)}</span></span>')

        history = "".join(
            f'<div class="hag-mini {"is-buyer" if r["is_buyer"] else "is-seller"}">'
            f'<span>{"مشتری" if r["is_buyer"] else "شما"}</span>'
            f'<strong class="nums">{esc(r["offer_text"])}</strong></div>'
            for r in thread)

        act = ""
        if h["status"] in ("open", "countered"):
            act = f'''<form method="post" action="/my/offer/{h["id"]}" class="mt-md">
        <div class="cluster">
          <button class="btn btn-primary btn-sm" type="submit" name="action" value="accept">
            {icon("check")}<span>قبول می‌کنم</span></button>
          <a class="btn btn-accent btn-sm" href="tel:{esc(h["phone"])}">
            {icon("phone")}<span>تماس</span></a>
          <button class="btn btn-ghost btn-sm" type="submit" name="action" value="decline"
            style="color:var(--color-destructive)">{icon("x")}<span>رد</span></button>
        </div>
        <div class="dir-row mt-sm">
          <label class="sr-only" for="cn{h["id"]}">قیمت پیشنهادی شما</label>
          <input class="input nums" id="cn{h["id"]}" name="offer" inputmode="numeric"
                 placeholder="قیمت پیشنهادی شما — مثلاً {fa_group(max(floor, h["offer"]))}">
          <button class="btn btn-glass btn-sm" type="submit" name="action" value="counter">
            {icon("send")}<span>پیشنهاد متقابل</span></button>
        </div>
      </form>'''

        cards += f'''<article class="card glass card-pad mb-md">
  <div class="between mb-sm" style="align-items:flex-start;gap:8px">
    <div>
      <strong>{esc(h.get("itemtitle") or "کالا")}</strong>
      <div class="text-xs text-muted">{esc(h["bizname"])} ·
        <span class="nums">{esc(jdatetime(h["created"]))}</span></div>
    </div>
    <span class="badge {cls}">{esc(label)}</span>
  </div>
  <div class="hag-offer-row">
    <div><span class="k">پیشنهاد مشتری</span>
      <strong class="v nums">{esc(last["offer_text"] if last["is_buyer"] else h["offer_text"])}</strong>
      {gap}</div>
    <div><span class="k">قیمت شما</span>
      <strong class="v nums">{fa_group(listed)} تومان</strong>{floor_note}</div>
    <div><span class="k">مشتری</span>
      <strong class="v">{esc(h["name"])}</strong>
      <a class="text-xs nums" href="tel:{esc(h["phone"])}">{esc(h["phone"])}</a></div>
  </div>
  {f'<p class="text-sm mt-sm">{esc(h["note"])}</p>' if h.get("note") else ''}
  {f'<div class="hag-minis mt-md">{history}</div>' if len(thread) > 1 else ''}
  {act}
</article>'''

    if not cards:
        cards = empty_state("tag", "هنوز پیشنهادی نرسیده",
            "برای اینکه مشتری بتواند قیمت پیشنهاد بدهد، در ویرایش هر کالا "
            "«چانه‌زنی» را روشن کنید و کف قیمت خود را بنویسید. هر پیشنهاد "
            "برابر یا بالاتر از کف، خودکار پذیرفته می‌شود.")

    content = f'''{_msg(q)}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("tag", st["total"], "کل پیشنهادها")}
  {stat_card("bell", st["open"], "در انتظار پاسخ", delay=60)}
  {stat_card("check-circle", st["accepted"], "پذیرفته‌شده", delay=120)}
  {stat_card("send", st["countered"], "پیشنهاد متقابل", delay=180)}
</div>
{gate_any(mine, "inquiry", cards)}'''
    return shell(s, "پیشنهادهای قیمت", "چانه‌زنی مشتریان روی کالاهای شما.",
                 content, "/my/offers", owner)


# ==========================================================================
#  TICKETS  --  the shopkeeper's side of the conversation
# ==========================================================================
def tickets(s, owner, q=None):
    """Inbox + new-ticket form in one page.

    Deliberately one page: a shopkeeper with a question should not have to
    find a "new ticket" button first. The form is at the top when there is
    nothing to read, and folded away once there is.
    """
    q = q or {}
    rows = db.tickets(owner_id=owner["id"])
    mine = db.businesses_of(owner["id"])

    topics = "".join(
        f'<option value="{esc(k)}">{esc(v)}</option>' for k, v in db.TICKET_TOPICS)
    bizopts = '<option value="">— مربوط به کسب‌وکار خاصی نیست —</option>' + "".join(
        f'<option value="{b["id"]}">{esc(b["name"])}</option>' for b in mine)

    items = ""
    for t in rows:
        unread = ('<span class="tk-dot" title="پاسخ تازه"></span>'
                  if t["unread_user"] else "")
        items += f'''<a class="tk-row" href="/my/ticket/{t['id']}">
      {unread}
      <div class="tk-main">
        <strong>{esc(t['subject'])}</strong>
        <div class="tk-meta">
          <span>{esc(t['topic_label'])}</span>
          {f'<span>· {esc(t["bizname"])}</span>' if t.get('bizname') else ''}
          <span>· {fa(t['nmsg'])} پیام</span>
          <span>· {esc(jdatetime(t['updated']))}</span>
        </div>
      </div>
      <span class="badge {t['status_cls']}">{esc(t['status_label'])}</span>
      {icon("chevron-left")}
    </a>'''

    if not items:
        items = ('<p class="text-sm text-muted">هنوز تیکتی نفرستاده‌اید. '
                 'اگر سؤالی دارید، همین پایین بنویسید.</p>')

    form = f'''<form method="post" action="/my/tickets" enctype="multipart/form-data" data-validate>
  <div class="grid grid-2" style="gap:0 var(--space-md)">
    <div class="field"><label class="field-label" for="tk-topic">موضوع</label>
      <select class="select" id="tk-topic" name="topic">{topics}</select></div>
    <div class="field"><label class="field-label" for="tk-biz">کسب‌وکار</label>
      <select class="select" id="tk-biz" name="biz_id">{bizopts}</select></div>
  </div>
  <div class="field"><label class="field-label" for="tk-sub">عنوان<span class="req">*</span></label>
    <input class="input" id="tk-sub" name="subject" required minlength="3"
           placeholder="در یک جمله — مثلاً: پول واریز کردم، قابلیت باز نشده"></div>
  <div class="field"><label class="field-label" for="tk-body">پیام شما<span class="req">*</span></label>
    <textarea class="textarea" id="tk-body" name="body" required minlength="10"
      placeholder="هرچه لازم است بنویسید. اگر پرداخت کرده‌اید، تاریخ و مبلغ را بنویسید."></textarea></div>
  <div class="field"><label class="field-label" for="tk-file">پیوست امن (اختیاری)</label>
    <input class="input" id="tk-file" type="file" name="attachment"
      accept="image/jpeg,image/png,image/webp,image/gif,application/pdf,text/plain">
    <p class="field-hint">عکس، PDF یا متن تا ۸ مگابایت؛ فقط مدیر می‌تواند ببیند.</p></div>
  <button class="btn btn-primary btn-lg" type="submit">
    {icon("send")}<span>ارسال تیکت</span></button>
  <p class="text-xs text-muted mt-md">{icon("info")} پاسخ پشتیبانی را همین‌جا می‌بینید؛
    پاسخ تازه با نقطهٔ «پاسخ تازه» در فهرست تیکت‌ها مشخص می‌شود.</p>
</form>'''

    _tk_unread = sum(1 for t in rows if t.get("unread_user"))
    content = f'''{CH.conversations_tabs("owner", "tickets", counts={"tickets": _tk_unread})}{_msg(q)}
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-md">{icon("message")} تیکت‌های من</h2>
  <div class="tk-list">{items}</div>
</div>
<details class="more-fields"{"" if rows else " open"}>
  <summary>{icon("plus")}<span>تیکت جدید</span>
    <small>سؤال، مشکل یا پیگیری پرداخت</small></summary>
  <div class="more-fields-body">{form}</div>
</details>'''
    return shell(s, "پشتیبانی", "گفت‌وگوی مستقیم با مدیر سایت.",
                 content, "/my/tickets", owner)


def ticket_view(s, owner, tid, q=None):
    t = db.ticket(tid=tid)
    if not t or (owner and t.get("owner_id") != owner["id"]):
        return None
    msgs = db.ticket_msgs(tid)
    db.set_ticket(tid, unread_user=0)

    bubbles = ""
    for m in msgs:
        me = m["side"] == "user"
        attachment = ""
        if m.get("attachment_id"):
            attachment = (f'<a class="tk-attachment" href="/ticket-file/{m["attachment_id"]}" target="_blank" rel="noopener">'
                          f'{icon("file")}<span>{esc(m.get("file_name") or "فایل پیوست")}</span>'
                          f'<small>{fa(max(1,int(m.get("file_size") or 0)//1024))} KB</small></a>')
        bubbles += f'''<div class="tk-bubble {"is-me" if me else "is-admin"}">
      <div class="tk-who">{icon("user" if me else "shield")}
        <span>{"شما" if me else "مدیر سایت"}</span>
        <time class="nums">{esc(jdatetime(m['created']))}</time></div>
      {f'<p>{esc(m["body"])}</p>' if m.get("body") else ''}{attachment}
    </div>'''

    reply = ""
    if t["status"] != "closed":
        reply = f'''<form class="card glass card-pad mt-lg" method="post"
      action="/my/ticket/{tid}" enctype="multipart/form-data" data-validate>
  <div class="field"><label class="field-label" for="rp">پاسخ شما</label>
    <textarea class="textarea" id="rp" name="body" minlength="2"
      placeholder="پاسخ خود را بنویسید…"></textarea></div>
  <div class="field"><label class="field-label" for="rp-file">پیوست</label>
    <input class="input" id="rp-file" type="file" name="attachment"
      accept="image/jpeg,image/png,image/webp,image/gif,application/pdf,text/plain"></div>
  <div class="cluster">
    <button class="btn btn-primary" type="submit" name="action" value="reply">
      {icon("send")}<span>ارسال</span></button>
    <button class="btn btn-ghost" type="submit" name="action" value="close"
      formnovalidate>{icon("check")}<span>مشکلم حل شد</span></button>
  </div>
</form>'''
    else:
        reply = f'''<div class="alert alert-success mt-lg">{icon("check-circle")}
      <span>این تیکت بسته شده است. اگر باز هم سؤالی دارید،
        <a href="/my/tickets">تیکت تازه</a> بفرستید.</span></div>'''

    content = f'''{_msg(q)}
<div class="card glass card-pad mb-lg">
  <div class="between mb-sm" style="align-items:flex-start;gap:10px">
    <div><h2 class="card-title">{esc(t['subject'])}</h2>
      <div class="tk-meta">{esc(t['topic_label'])}
        {f"· {esc(t['bizname'])}" if t.get('bizname') else ''}
        · <span class="nums">{esc(jdatetime(t['created']))}</span></div></div>
    <span class="badge {t['status_cls']}">{esc(t['status_label'])}</span>
  </div>
</div>
<div class="tk-thread">{bubbles}</div>
{reply}'''
    return shell(s, "تیکت", "گفت‌وگو با مدیر سایت.", content, "/my/tickets", owner)


# ==========================================================================
#  ORDERS & CHAT  (v28 — the shopkeeper's side of ordering & messaging)
# ==========================================================================
# ==========================================================================
#  ASSISTANT ACTIVITY (v227 — what the assistant did for this owner's shops)
# ==========================================================================
def owner_assistant(s, owner, q=None):
    """«فعالیت دستیار»: tool executions on the owner's businesses (newest
    first), open cancel requests, 7-day counts and the owner's own quota."""
    import assistant
    data = assistant.owner_assistant_data(owner["id"])
    box = ""
    if data["pending_cancels"]:
        box = (f'<div class="alert alert-warn mb-lg">{icon("clock")}'
               f'<span><b class="nums">{fa(data["pending_cancels"])}</b> درخواست لغو سفارش در انتظار تصمیم شماست.</span> '
               f'<a class="btn btn-primary btn-sm" href="/my/orders">بررسی سفارش‌ها</a></div>')
    tier = assistant.tier_of(None, owner)
    quota = assistant.quota_for(tier)
    rem = assistant.remaining(f"owner:{owner['id']}", tier)
    quota_strip = (
        f'<div class="card glass card-pad mb-lg"><p class="text-sm mb-sm">'
        f'{icon("sparkles")} سهمیهٔ هوشمند امروز شما: <b class="nums">{fa(rem)} از {fa(quota)}</b> '
        f'(سطح {esc(assistant.TIER_LABEL.get(tier, ""))})</p>'
        f'<a class="btn btn-glass btn-sm" href="/assistant">گفت‌وگو با دستیار</a></div>')
    CARDS = (("favorite", "star", "ذخیره ۷ روز"), ("book", "calendar", "نوبت ۷ روز"),
             ("review", "message", "نظر ۷ روز"), ("cancel_booking", "x-circle", "لغو نوبت ۷ روز"),
             ("cancel_order", "cart", "لغو سفارش ۷ روز"))
    cards = "".join(stat_card(ic, fa(data["counts"].get(t, 0)), lbl) for t, ic, lbl in CARDS)
    if data["rows"]:
        trs = "".join(
            f'<tr><td>{esc(r["text"])}</td>'
            f'<td><a class="btn btn-glass btn-sm" href="{esc(r["link"])}">مشاهده</a></td>'
            f'<td class="nums">{esc(jdatetime(r["created"]))}</td></tr>'
            for r in data["rows"])
        table = (f'<div class="card glass card-pad"><h2 class="card-title mb-md">{icon("activity")} آخرین اقدام‌ها</h2>'
                 f'<div class="table-wrap"><table class="table"><thead><tr><th>اقدام</th><th></th><th>زمان</th></tr></thead>'
                 f'<tbody>{trs}</tbody></table></div></div>')
    else:
        table = empty_state("sparkles", "هنوز اقدامی ثبت نشده",
                            "وقتی مشتری‌ها با دستیار هوشمند کار کنند — ذخیره، نوبت، نظر یا لغو — "
                            "همهٔ اقدام‌های مربوط به کسب‌وکارهای شما اینجا می‌آید.")
    content = f"{_msg(q)}\n{box}\n{quota_strip}\n" + \
        f'<div class="grid grid-3 mb-lg">{cards}</div>\n{table}'
    return shell(s, "فعالیت دستیار", "اقدام‌های دستیار هوشمند برای کسب‌وکارهای شما.",
                 content, "/my/assistant", owner)


def owner_orders(s, me, q=None):
    q = q or {}
    rows = db.orders_for_owner(me["id"])
    def cancel_buttons(o):
        if not o.get("cancel_requested"): return ""
        return (f'<form method="post" action="/my/order/{o["id"]}/cancel" class="mt-sm" style="display:flex;gap:4px">'
                '<button class="btn btn-primary btn-sm" name="action" value="approve">تأیید لغو</button>'
                '<button class="btn btn-ghost btn-sm" name="action" value="reject">رد لغو</button></form>')
    trs = "".join(f'''<tr>
      <td class="nums">#{fa(o["id"])}</td>
      <td>{esc(o["bizname"])}</td>
      <td>{esc(o["name"])}<br><small class="text-muted">{f'<span class="nums" dir="ltr">{esc(o.get("phone"))}</span>' if o.get("share_phone") and o.get("phone") else 'شمارهٔ تماس به‌اشتراک گذاشته نشده'}</small></td>
      <td class="nums">{fa_group(o["total"])} تومان</td>
      <td><span class="badge {db.ORDER_LABELS.get(o["status"], ("badge-neutral",""))[0]}">{esc(o["status_label"])}</span></td>
      <td class="nums">{esc(jdatetime(o["created"]))}</td>
      <td><form method="post" action="/my/order/{o["id"]}" style="display:inline-flex;gap:4px;flex-wrap:wrap">
        <input type="hidden" name="status" value="confirmed">
        <button class="btn btn-glass btn-sm" type="submit">تأیید</button></form>
        <form method="post" action="/my/order/{o["id"]}" style="display:inline">
        <input type="hidden" name="status" value="done">
        <button class="btn btn-ghost btn-sm" type="submit">تحویل شد</button></form>
        {cancel_buttons(o)}</td>
    </tr>''' for o in rows)
    if not trs:
        trs = f'<tr><td colspan="7">{esc("هنوز سفارشی ثبت نشده است.")}</td></tr>'
    content = f'''{_msg(q)}
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("cart")} سفارش‌های مشتریان</h2>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>شماره</th><th>کسب‌وکار</th><th>مشتری</th><th>مبلغ</th><th>وضعیت</th><th>تاریخ</th><th>عملیات</th></tr></thead>
    <tbody>{trs}</tbody></table></div>
</div>'''
    return shell(s, "سفارش‌ها", "سفارش‌های آنلاین مشتریان شما.", content, "/my/orders", me)


def owner_chats(s, me, q=None):
    q = q or {}
    rows = db.chat_threads_for_owner(me["id"])
    items = CH.thread_list(
        rows, "owner", "/my/chat",
        empty_title="گفتگویی نیست",
        empty_text="وقتی مشتری پیام بفرستد، همین‌جا با نشان خوانده‌نشده دیده می‌شود.")
    content = f'''{CH.conversations_tabs("owner", "chats", counts={"chats": db.chat_unread_owner(me["id"])})}{_msg(q)}
<div class="chat-inbox-card">{items}</div>'''
    return shell(s, "گفت‌وگوها", "پیام‌رسان مشتریان همهٔ کسب‌وکارهای شما.",
                 content, "/my/chats", me)


def owner_chat_view(s, me, tid, q=None):
    thread = db.chat_thread(tid)
    if not thread or not db.owns(me["id"], thread["biz_id"]):
        return None
    biz = db.business(bid=thread["biz_id"]) or {}
    cust = db.customer_by_id(thread.get("customer_id")) or {}
    title = cust.get("name") or "مشتری"
    subtitle = f'''{biz.get("name", "کسب‌وکار")} · شمارهٔ مشتری محرمانه است · مدیر دست گیر امکان نظارت دارد.'''
    room = CH.chat_room(
        thread, db.chat_messages(tid), "owner", title, subtitle,
        f"/my/chat/{tid}", "/my/chats", status=thread.get("status", "open"))
    content = f'''{_msg(q or {})}{room}
<script type="module" src="/assets/js/chat.js?v145"></script>'''
    return shell(s, "گفتگو", "پاسخ مستقیم به مشتری.", content, "/my/chats", me)


# ==========================================================================
#  STORIES  (v31) — 24-hour shop stories
# ==========================================================================
def owner_stories(s, me, q=None):
    q = q or {}
    mine = db.businesses_of(me["id"])
    if not mine:
        return shell(s, "استوری‌ها", "کسب‌وکار شما.", 
                     empty_state("store", "هنوز کسب‌وکاری ندارید",
                                 "ابتدا یک کسب‌وکار ثبت کنید."), "/my/stories", me)
    rows = db.stories_for_owner(me["id"])
    counts = db.story_view_counts([r["id"] for r in rows])
    _now = time.time()

    def _exp(r):
        try:
            return float(r["expires"] or 0)
        except (TypeError, ValueError):
            return 0.0
    live_rows = [r for r in rows if _exp(r) >= _now]
    past_rows = [r for r in rows if _exp(r) < _now]

    def _prev(r):
        obj = {"id": r["id"], "image": r["image"], "kind": r.get("kind") or "image",
               "caption": r.get("caption") or "", "duration": r.get("duration") or 0,
               "bizname": r["bizname"], "bizslug": r.get("bizslug") or ""}
        return esc(json.dumps(obj, ensure_ascii=False)).replace("'", "&#39;")

    def _row(r, past=False):
        return f'''<div class="card glass card-pad mb-md story-row">
      <div class="story-row-main">
        <button type="button" class="story-thumb-btn" data-story-preview="{_prev(r)}" aria-label="پیش‌نمایش استوری">
          <img src="{esc(r["image"])}" alt="" style="width:64px;height:64px;object-fit:cover;border-radius:12px" loading="lazy">
          {"<span class='story-vid-tag'>▶</span>" if (r.get("kind") == "video") else ""}
        </button>
        <div style="flex:1;min-width:180px">
          <strong>{esc(r["bizname"])}</strong>
          <p class="text-sm text-muted">{esc(r.get("caption") or "بدون توضیح")}</p>
          <small class="text-muted nums">{esc(jdatetime(r["created"]))}{(" · منقضی شده" if past else "")} · {("%d ثانیه" % int(r.get("duration") or 0)) if (r.get("kind") == "video" and (r.get("duration") or 0)) else "تصویر"}</small>
        </div>
        <button class="btn btn-glass btn-sm" type="button" data-story-stats="{r["id"]}"><span>بازدیدکنندهٔ واقعی ({counts.get(r["id"], 0)})</span></button>
        <form method="post" action="/my/story/{r["id"]}/delete" data-confirm="استوری حذف شود؟" style="display:inline">
          <button class="btn btn-ghost btn-sm" type="submit">{icon("x")}<span>حذف</span></button>
        </form>
      </div>
      <div class="story-stats" data-story-stats-panel="{r["id"]}" hidden></div>
    </div>'''

    items = "".join(_row(r) for r in live_rows)
    if not items:
        items = empty_state("image", "استوری فعالی ندارید",
                            "یک عکس از امروز دکان‌تان بگذارید — مشتری‌ها استوری‌های تازه را می‌بینند.")
    history = ""
    if past_rows:
        history = (f'<div class="card glass card-pad mb-lg"><h2 class="card-title mb-lg">{icon("clock")} '
                   f'تاریخچهٔ استوری‌ها <small class="text-muted nums">({fa(len(past_rows))})</small></h2>'
                   f'<p class="text-sm text-muted mb-lg">استوری‌های منقضی‌شده — مشتری‌ها آن‌ها را در '
                   f'<a href="/b/{esc(past_rows[0]["bizslug"])}/stories">تاریخچهٔ عمومی دکان</a> می‌بینند و این‌جا تعداد '
                   f'بازدیدکنندهٔ واقعی هرکدام را می‌بینید.</p>'
                   + "".join(_row(r, past=True) for r in past_rows) + '</div>')

    biz_opts = "".join(f'<option value="{b["id"]}">{esc(b["name"])}</option>' for b in mine)
    content = f'''{_msg(q)}
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-lg">{icon("image")} استوری جدید</h2>
  <p class="text-sm text-muted mb-lg">استوری‌ها ۲۴ ساعت روی سایت می‌مانند؛ بعد در «تاریخچهٔ استوری‌ها» می‌مانند تا شما و مشتری‌ها همیشه بتوانید ببینیدشان.</p>
  <form method="post" action="/my/story/add" enctype="multipart/form-data" data-validate data-compress>
    <div class="grid grid-2" style="align-items:start">
      <div class="field"><label class="field-label" for="st-biz">کسب‌وکار</label>
        <select class="select" id="st-biz" name="biz_id" required>{biz_opts}</select></div>
      <div class="field"><label class="field-label" for="st-cap">توضیح (اختیاری)</label>
        <input class="input" id="st-cap" name="caption" maxlength="200" placeholder="مثلاً: تخفیف امروز!"></div>
    </div>
    <div class="field"><label class="field-label" for="st-img">عکس یا فیلم استوری</label>
      <!-- دوربین مستقیم (بدون پنجرهٔ انتخاب فایل) -->
      <label class="btn btn-accent" style="cursor:pointer">{icon("camera")}<span>گرفتن عکس / فیلم با دوربین</span>
        <input id="st-img" type="file" name="story_media" accept="image/*,video/*" capture="environment" required hidden data-compress-input></label>
      <p class="field-hint">با زدن دکمه، دوربین گوشی مستقیم باز می‌شود. هر استوری حداکثر ۳۰ ثانیه — ویدیوی بلندتر را قبل از آپلود برش بزنید.</p></div>
    <button class="btn btn-primary" type="submit">{icon("send")}<span>انتشار استوری</span></button>
  </form>
</div>
<div class="card glass card-pad mb-lg"><h2 class="card-title mb-lg">{icon("list")} استوری‌های شما</h2>{items}</div>{history}'''
    return shell(s, "استوری‌ها", "عکس‌های ۲۴ ساعتهٔ کسب‌وکار شما.", content, "/my/stories", me,
                 )


# ==========================================================================
#  ACCOUNT & SECURITY  —  username + password (v57)
# ==========================================================================
def account(s, owner, q=None):
    # v186: customer/owner sessions are minted through Bale.
    connected = bool(db.messenger_chat_for("owner", owner["id"], "bale") or
                     db.messenger_chat_for("owner", owner["id"], "soroush"))
    state = ("حداقل یک پیام‌رسان رسمی متصل و ورود امن فعال است." if connected else
             "برای این شماره هنوز بله یا سروش‌پلاس متصل نشده است.")
    content = f'''{_msg(q)}
<div class="card glass card-pad">
  <h2 class="card-title mb-md">{icon("shield")} ورود امن با بله</h2>
  <div class="alert {'alert-success' if connected else 'alert-warn'} mb-lg"><span>{state}</span></div>
  <p class="text-sm text-muted mb-lg">ورود پیامکی و رمز عبور غیرفعال است. اتصال بله از حساب مشتری همین شماره مدیریت می‌شود.</p>
  <a class="btn btn-primary" href="/me/notif-settings">{icon("message")}<span>مدیریت اتصال بله</span></a>
</div>'''
    return shell(s, "حساب و امنیت", "ورود و ثبت‌نام فقط با بازوی بله.",
                 content, "/my/account", owner)


# ==========================================================================
#  v105/v109 — RECYCLE BIN (soft-delete, restorable, trackable)
#  Retention per the owner's rule: story 7 days · item/review 24 hours.
# ==========================================================================
_TRASH_LABEL = {"story": "استوری", "item": "محصول/خدمت", "review": "نظر", "report": "گزارش", "business": "کسب‌وکار"}


def _trash_keep_text(entity):
    return "۷ روز" if entity == "report" else "۳۰ روز"


def _trash_left_text(left_s):
    if left_s >= 86400:
        return f"{left_s // 86400} روز مانده"
    if left_s >= 3600:
        return f"{left_s // 3600} ساعت مانده"
    return f"{max(1, left_s // 60)} دقیقه مانده"


def _trash_rows(rows, base):
    if not rows:
        return empty_state("x", "بازیابی فایل‌ها خالی است",
                           "هر فایل حذف‌شده ۳۰ روز این‌جا می‌ماند "
                           "و بعد برای همیشه پاک می‌شود.")
    out = []
    for r in rows:
        d = jdatetime_ts(r["deleted_at"])
        left_s = db.trash_left_seconds(r)
        # v177: پیش‌نمایش تصویری — فایل حذف‌شده همین‌جا دیده می‌شود، بدون بازیابی
        img = _trash_image(r)
        thumb = (f'<button class="trash-thumb" type="button" data-zi-lb="{esc(img)}" '
                 f'aria-label="دیدن تصویر کامل">'
                 f'<img src="{esc(img)}" alt="" loading="lazy" decoding="async"></button>'
                 if img else f'<span class="trash-thumb is-empty">{icon("image")}</span>')
        out.append(f'''<div class="card glass card-pad mb-md trash-row">
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          {thumb}
          <span class="badge">{_TRASH_LABEL.get(r["entity"], r["entity"])}</span>
          <div style="flex:1;min-width:160px"><strong>{esc(r["title"] or "بدون عنوان")}</strong>
            <small class="text-muted nums"> حذف در {d} · {_trash_left_text(left_s)}</small></div>
          <form method="post" action="{base}/{r["id"]}/restore" style="display:inline">
            <button class="btn btn-glass btn-sm" type="submit"><span>بازیابی</span></button>
          </form>
          </div>
        </div>''')
    out.append(_TRASH_LIGHTBOX)
    return "".join(out)


_TRASH_LIGHTBOX = (
    '<div class="zi-lightbox" hidden>'
    '<button class="zi-lb-back" type="button" aria-label="بستن"></button>'
    '<img class="zi-lb-img" src="" alt="نمایش تصویر حذف‌شده">'
    '<button class="zi-lb-close" type="button" aria-label="بستن">✕</button></div>'
    '<script>(function(){var lb=document.querySelector(".zi-lightbox");if(!lb)return;'
    'document.addEventListener("click",function(e){var t=e.target.closest("[data-zi-lb]");'
    'if(t){lb.querySelector(".zi-lb-img").src=t.getAttribute("data-zi-lb");lb.hidden=false;}'
    'else if(e.target.closest(".zi-lb-back,.zi-lb-close")){lb.hidden=true;'
    'lb.querySelector(".zi-lb-img").src="";}});'
    'document.addEventListener("keydown",function(e){if(e.key==="Escape"&&!lb.hidden){'
    'lb.hidden=true;lb.querySelector(".zi-lb-img").src="";}});})();</script>')


def _trash_image(r):
    """v177: مسیر عکسِ یک ردیف سطل از payload — برای پیش‌نمایش بدون بازیابی."""
    try:
        row = json.loads(r["payload"])
    except Exception:
        return ""
    if not isinstance(row, dict):
        return ""
    img = row.get("image")
    if isinstance(img, str) and img.startswith("/assets/"):
        return img
    ims = row.get("images")
    if isinstance(ims, list):
        for p in ims:
            if isinstance(p, str) and p.startswith("/assets/"):
                return p
    return ""


def owner_trash(s, me, q=None):
    q = q or {}
    biz_ids = [b["id"] for b in db.businesses_of(me["id"])]
    rows = db.trash_list(entities=["story", "item", "review"], biz_ids=biz_ids)
    # v209: whole shops this owner deleted (their biz row is gone, so match
    # on the snapshot's owner_id instead of the live list).
    for r in db.trash_list(entities=["business"]):
        try:
            if json.loads(r["payload"]).get("owner_id") == me["id"]:
                rows.append(r)
        except Exception:
            pass
    rows.sort(key=lambda r: -r["deleted_at"])
    content = f'''{_msg(q)}
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-lg">بازیابی فایل‌ها</h2>
  <p class="text-sm text-muted mb-lg">فایل‌های حذف‌شده همین‌جا قابل دیدن‌اند — روی تصویر بزنید تا کامل باز شود؛
  اگر پشیمان شدید «بازیابی» بزنید تا سر جایش برگردد — هر حذف‌شده‌ای ۳۰ روز مهلت دارد.</p>
  {_trash_rows(rows, "/my/trash")}
</div>'''
    return shell(s, "بازیابی فایل‌ها", "حذف‌شده‌های اخیر کسب‌وکارهای شما — همین‌جا قابل دیدن و بازیابی.",
                 content, "/my/trash", me)


# ------------------------------------------------------------------ v142 notifications (owner)
def notifications_page(s, me, q=None):
    q = q or {}
    rows = db.owner_notifications(me["id"])
    items = "".join(
        f'''<a class="todo-item{' is-unread' if not n['read'] else ''}"
      href="/my/notif/{n['id']}/go">
      {icon(_nmeta('owner', n['kind'])[0])}
      <span><strong>{esc(_nmeta('owner', n['kind'])[1])}</strong>
      <small class="text-muted">{esc(n['text'])}</small>
      <small class="text-muted nums time">{esc(jdatetime(n['created']))}</small></span>
      {icon('chevron-left')}</a>''' for n in rows)
    if not items:
        items = empty_state("bell", "اعلانی ندارید",
                            "فعال شدن تعرفه، تأیید کسب\u200cوکار، سفارش و پیام تازه اینجا می\u200cآید.")
    # v146: unified login means a shopkeeper is usually a customer too (same
    # phone). Their customer-role notifications are shown here as well so the
    # single bell count always has a matching list behind it.
    cust_rows = ""
    cust_unread = 0
    c = db.customer_by_phone(me.get("phone") or "", create=False)
    if c:
        cro = db.notifications(c["id"])
        if cro:
            cust_rows = "".join(
                f'''<a class="todo-item{' is-unread' if not n['read'] else ''}"
      href="/me/notif/{n['id']}/go">
      {icon(_nmeta('cust', n['kind'])[0])}
      <span><strong>{esc(_nmeta('cust', n['kind'])[1])}</strong>
      <small class="text-muted">{esc(n['text'])}</small>
      <small class="text-muted nums time">{esc(jdatetime(n['created']))}</small></span>
      {icon('chevron-left')}</a>''' for n in cro)
            cust_unread = sum(1 for n in cro if not n["read"])
    extra_card = ""
    if cust_rows:
        extra_card = f'''<h2 class="card-title mt-lg mb-md">{icon("cart")} خریدها و پاسخ‌های من
          <small class="text-muted" style="font-weight:400">(حساب مشتری همان شماره)</small></h2>
        <div class="card glass card-pad"><div class="todo-list notif-list">{cust_rows}</div></div>
        {f'<form method="post" action="/me/notifications/read" class="mt-md">'
         f'<button class="btn btn-glass btn-sm" type="submit">{icon("check")}<span>خواندن همه در حساب مشتری</span></button></form>'
         if cust_unread else ""}'''
    else:
        extra_card = ""
    content = f'''{_msg(q)}
<header class="page-hero notifications-hero"><h1>{icon("bell")} اعلان‌های من</h1>
  <p>رویدادهای تعرفه، کسب‌وکار، سفارش و پشتیبانی شما.</p>
  <div class="cluster">
    <form method="post" action="/my/notifications/read">
      <button class="btn btn-glass btn-sm" type="submit">{icon("check")}<span>خواندن همه</span></button>
    </form>
    <a class="btn btn-glass btn-sm" href="/my/notif-settings">{icon("settings")}
      <span>تنظیم اعلان‌ها</span></a>
  </div></header>
<div class="card glass card-pad"><div class="todo-list notif-list">{items}</div></div>
{extra_card}'''
    return shell(s, "اعلان‌های من", "رویدادهای تعرفه، کسب‌وکار و پشتیبانی", content, "", me)


def notif_settings_page(s, me, q=None):
    """v142: per-category notification switches + web-push card (owner)."""
    from notifmeta import kinds, meta
    q = q or {}
    rows = ""
    st = db.pref_state("owner", me["id"], kinds("owner"))
    for k in kinds("owner"):
        ic, label, desc = meta("owner", k)
        rows += (f'<label class="switch-row">'
                 f'<input type="checkbox" name="k_{esc(k)}"{" checked" if st[k] else ""}>'
                 f'<span class="sw-copy"><strong>{icon(ic)}{esc(label)}</strong>'
                 f'<small>{esc(desc)}</small></span>'
                 f'<span class="track" aria-hidden="true"></span></label>')
    content = f'''{_msg(q)}
<div class="cluster mb-lg">
  <a class="btn btn-glass btn-sm" href="/my/notifications">{icon("bell")}
    <span>بازگشت به اعلان‌ها</span></a>
</div>
<form method="post" action="/my/notif-settings">
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("settings")} کدام رویدادها اعلان بدهند؟</h2>
    <p class="text-sm text-muted mb-lg">خاموش‌کردن هر دسته، هم اعلان داخل سایت و هم
      اعلان گوشی همان دسته را متوقف می‌کند.</p>
    {rows}
    <hr class="divider">
    <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیرهٔ تنظیمات</span></button>
  </div>
</form>
{notif_push_card("owner")}'''
    return shell(s, "تنظیم اعلان‌ها", "دسته‌ها و اعلان گوشی", content, "", me,
                 extra_js='<script src="/assets/js/notifpush.js?v154"></script>')


def broadcast_page(s, me, q=None):
    """v156: پنل فراخوان دکان — فراخوان به دنبال‌کننده‌ها + درخواست‌های
    «موجود شد خبرم کن». دسترسی: پرک اشتراک broadcast، بنیان‌گذار (اولین N)،
    گرهٔ مدیر، یا نشان بنیان‌گذار؛ غیرمجاز = کارت راهیاب به اشتراک."""
    q = q or {}
    bizs = db.businesses_of(me["id"])
    allowed = [b for b in bizs if db.broadcast_allowed(b["id"])]
    biz_ids = [b["id"] for b in bizs]

    if not bizs:
        content = (_msg(q)
                   + empty_state("store", "اول کسب‌وکارتان را ثبت کنید",
                                 "پنل فراخوان به کسب‌وکار شما وصل می‌شود.",
                                 f'<a class="btn btn-primary" href="/register-business">{icon("plus")}'
                                 f'<span>ثبت کسب‌وکار</span></a>'))
        return shell(s, "فراخوان دکان", "خبررسانی به دنبال‌کننده‌ها", content, "", me)

    if not allowed:
        content = f'''{_msg(q)}
<header class="page-hero"><h1>{icon("bell")} فراخوان دکان</h1>
  <p>خبرهای دکان‌تان را به دنبال‌کننده‌ها برسانید.</p></header>
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-md">{icon("zap")} این بخش ویژه است</h2>
  <p class="text-sm mb-md">با پنل فراخوان، هر وقت کالایی <strong>موجود شد</strong>،
    <strong>ارزان شد</strong> یا در حال تمام‌شدن بود، دنبال‌کننده‌های دکان‌تان
    همان لحظه روی زنگولهٔ داخل سایت خبر می‌گیرند؛ و مشتری می‌تواند برای کالای
    ناموجود «موجود شد خبرم کن» بگذارد تا خودتان انتخاب کنید به چه کسی خبر بدهید.</p>
  <div class="alert alert-info mb-md">{icon("star")}<span>این امکان برای
    <strong>بنیان‌گذاران</strong> (دکان‌های نخست دست گیر) و دارندگان
    <strong>نشان بنیان‌گذار</strong> رایگان است.</span></div>
  <div class="cluster">
    <a class="btn btn-primary" href="/pricing">{icon("wallet")}<span>فعال‌سازی با اشتراک</span></a>
    <a class="btn btn-glass" href="/my/plan">{icon("tag")}<span>اشتراک من</span></a>
  </div>
</div>'''
        return shell(s, "فراخوان دکان", "نیازمند اشتراک یا بنیان‌گذاری", content, "", me)

    # ---- مجاز: فرم ارسال + درخواست‌های باز + آرشیو
    opts = "".join(f'<option value="{b["id"]}">{esc(b["name"])}</option>' for b in allowed)
    kind_opts = "".join(f'<option value="{k}">{esc(lbl)}</option>'
                        for k, (_ic, lbl) in db.BCAST_KINDS.items())

    total_followers = sum(db.follower_count(b["id"]) for b in allowed)

    req_rows = db.stock_requests_open(me["id"])
    reqs = ""
    for r in req_rows:
        what = r["item_title"] or "کالای نامشخص (از گفتگو)"
        src = "از صفحهٔ کالا" if r["source"] == "item" else "از گفتگو"
        _extra = f'<small class="text-muted">تعداد: <span class="nums">{fa(r["qty"] or 1)}</span></small>'
        if r.get("note"):
            _extra += f'<small class="text-muted">یادداشت: {esc(r["note"])}</small>'
        reqs += f'''<div class="todo-item">
      {icon("box")}<span><strong>{esc(what)}</strong>
      {_extra}
      <small class="text-muted">درخواست از {esc(r["cust_name"] or "مشتری")} · {esc(r["biz_name"])} · {src}</small>
      <small class="text-muted nums time">{esc(jdatetime(r["created"]))}</small></span>
      <span class="cluster">
        <form method="post" action="/my/broadcast/fulfill">
          <input type="hidden" name="rid" value="{r["id"]}">
          <button class="btn btn-primary btn-sm" type="submit">{icon("bell")}<span>موجود شد — خبر بده</span></button>
        </form>
        <form method="post" action="/my/broadcast/dismiss">
          <input type="hidden" name="rid" value="{r["id"]}">
          <button class="btn btn-glass btn-sm" type="submit">{icon("x")}<span>بی‌خیال</span></button>
        </form>
      </span></div>'''
    if not reqs:
        reqs = empty_state("check-circle", "درخواست بازی ندارید",
                           "مشتری‌ها از صفحهٔ کالا یا گفتگو «موجود شد خبرم کن» می‌گذارند و اینجا می‌آید.")

    sent_rows = db.broadcasts_recent(biz_ids, limit=8)
    sent = ""
    for b in sent_rows:
        _ic, lbl = db.BCAST_KINDS.get(b["kind"], ("bell", "خبر"))
        sent += f'''<div class="todo-item">
      {icon(_ic)}<span><strong>{esc(b["text"])}</strong>
      <small class="text-muted">{esc(lbl)} · به {fa(b["recipients"] or 0)} دنبال‌کننده رسید</small>
      <small class="text-muted nums time">{esc(jdatetime(b["created"]))}</small></span></div>'''
    if not sent:
        sent = empty_state("bell", "هنوز فراخوانی نفرستاده‌اید",
                           "اولین خبر دکان‌تان را از فرم بالا بفرستید.")

    content = f'''{_msg(q)}
<header class="page-hero"><h1>{icon("bell")} فراخوان دکان</h1>
  <p>{fa(total_followers)} مشتری دکان(های) شما را دنبال می‌کنند.</p></header>
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-md">{icon("bell")} فراخوان تازه</h2>
  <form method="post" action="/my/broadcast/send" data-validate>
    <div class="field"><label class="field-label" for="bc-b">کسب‌وکار</label>
      <select class="select" id="bc-b" name="biz_id" required>{opts}</select></div>
    <div class="field"><label class="field-label" for="bc-k">نوع خبر</label>
      <select class="select" id="bc-k" name="kind">{kind_opts}</select></div>
    <div class="field"><label class="field-label" for="bc-t">متن خبر<span class="req">*</span></label>
      <textarea class="textarea" id="bc-t" name="text" required minlength="3" maxlength="300"
        placeholder="مثلاً: برنج هاشمی درجه‌یک موجود شد؛ تا پایان هفته با ۱۰٪ تخفیف."></textarea>
      <p class="field-hint">همین لحظه روی زنگولهٔ همهٔ دنبال‌کننده‌ها می‌نشیند.</p></div>
    <button class="btn btn-primary" type="submit">{icon("bell")}<span>ارسال فراخوان</span></button>
  </form>
</div>
<h2 class="card-title mt-lg mb-md">{icon("box")} درخواست‌های «موجود شد خبرم کن»
  <small class="text-muted" style="font-weight:400">({fa(len(req_rows))} باز)</small></h2>
<div class="card glass card-pad mb-lg"><div class="todo-list notif-list">{reqs}</div></div>
<h2 class="card-title mt-lg mb-md">{icon("clock")} فراخوان‌های اخیر</h2>
<div class="card glass card-pad"><div class="todo-list notif-list">{sent}</div></div>'''
    return shell(s, "فراخوان دکان", "خبررسانی و درخواست موجودی", content, "", me)
