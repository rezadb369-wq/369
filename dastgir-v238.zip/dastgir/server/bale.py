# -*- coding: utf-8 -*-
"""Bale bot transport for passwordless login and notification delivery (v185).

Secrets live only in the process environment. This module intentionally uses
stdlib urllib so the project remains dependency-free/Pydroid-compatible.
"""
import json
import os
import urllib.request
import urllib.error
import re

API_ROOT = os.environ.get("BALE_API_ROOT", "https://tapi.bale.ai/bot").rstrip("/")
FILE_ROOT = os.environ.get("BALE_FILE_ROOT", "https://tapi.bale.ai/file/bot").rstrip("/")
BOT_USERNAME = os.environ.get("BALE_BOT_USERNAME", "daastgirbot").strip().lstrip("@")


def token():
    return os.environ.get("BALE_BOT_TOKEN", "").strip()


def webhook_secret():
    return os.environ.get("BALE_WEBHOOK_SECRET", "").strip()


def enabled():
    return bool(token() and webhook_secret() and BOT_USERNAME)


def bot_link(payload=""):
    base = f"https://ble.ir/{BOT_USERNAME}"
    return base + (("?start=" + payload) if payload else "")


def _call(method, payload):
    tok = token()
    if not tok:
        return {"ok": False, "description": "bale disabled"}
    req = urllib.request.Request(
        f"{API_ROOT}{tok}/{method}",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json", "User-Agent": "Daastgir/212"},
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            out = json.loads(r.read(262144).decode("utf-8", "replace"))
            return out if isinstance(out, dict) else {"ok": False}
    except Exception:
        return {"ok": False}


def send_message(chat_id, text, reply_markup=None):
    data = {"chat_id": chat_id, "text": str(text)[:4096]}
    if reply_markup:
        data["reply_markup"] = reply_markup
    return bool(_call("sendMessage", data).get("ok"))


def send_message_id(chat_id, text, reply_markup=None):
    """v212: like send_message but returns the platform message_id (or None)."""
    data = {"chat_id": chat_id, "text": str(text)[:4096]}
    if reply_markup:
        data["reply_markup"] = reply_markup
    out = _call("sendMessage", data)
    result = out.get("result") if out.get("ok") and isinstance(out.get("result"), dict) else {}
    mid = result.get("message_id")
    return mid if isinstance(mid, int) else None


def send_photo(chat_id, photo_url, caption="", reply_markup=None):
    """v212: documented sendPhoto by HTTPS URL (Bale fetches ≤5 MB images)."""
    url = str(photo_url or "")
    if not url.startswith("https://"):
        return False
    data = {"chat_id": chat_id, "photo": url, "caption": str(caption or "")[:1024]}
    if reply_markup:
        data["reply_markup"] = reply_markup
    return bool(_call("sendPhoto", data).get("ok"))


def send_chat_action(chat_id, action="typing"):
    """v212: documented sendChatAction (typing/upload_photo/…); shown ≤6 s."""
    if action not in ("typing", "upload_photo", "record_video", "upload_video",
                      "record_voice", "upload_voice", "choose_sticker"):
        action = "typing"
    return bool(_call("sendChatAction", {"chat_id": chat_id, "action": action}).get("ok"))


def edit_message_text(chat_id, message_id, text, reply_markup=None):
    """v212: documented editMessageText (inline keyboards only)."""
    if not isinstance(message_id, int):
        return False
    data = {"chat_id": chat_id, "message_id": message_id, "text": str(text)[:4096]}
    if reply_markup:
        data["reply_markup"] = reply_markup
    return bool(_call("editMessageText", data).get("ok"))


def set_my_commands(commands):
    """v212: setMyCommands is NOT in the official Bale docs (docs.bale.ai, all
    sections read). It is only attempted when BALE_SET_COMMANDS=1 is set by
    the operator; otherwise this is a documented no-op returning False."""
    if os.environ.get("BALE_SET_COMMANDS", "").strip() != "1":
        return False
    cmds = [{"command": str(c)[:32], "description": str(d)[:256]} for c, d in commands][:100]
    return bool(_call("setMyCommands", {"commands": cmds}).get("ok"))


def send_approval(chat_id, challenge_token, purpose="login"):
    action = "اتصال حساب بله" if purpose == "link" else "ورود به دست گیر"
    markup = {"inline_keyboard": [[{
        "text": "✅ تأیید " + action,
        "callback_data": f"bz185:{purpose}:{challenge_token}",
    }], [{
        "text": "❌ لغو",
        "callback_data": f"bz185:cancel:{challenge_token}",
    }]]}
    return send_message(chat_id,
        f"درخواست {action}\n\nاگر این درخواست متعلق به شماست، دکمهٔ تأیید را بزنید. "
        "این درخواست فقط دو دقیقه اعتبار دارد.", markup)


def request_signup_contact(chat_id):
    markup = {"keyboard": [[{
        "text": "ارسال شمارهٔ خودم", "request_contact": True,
    }]], "resize_keyboard": True, "one_time_keyboard": True}
    return send_message(chat_id,
        "برای ثبت‌نام امن، شمارهٔ همین حساب بله را با دکمهٔ زیر تأیید کنید. "
        "شمارهٔ تایپی یا شمارهٔ شخص دیگر پذیرفته نمی‌شود.", markup)


def send_signup_approval(chat_id, approval_token):
    markup = {"inline_keyboard": [[{
        "text": "✅ تأیید ثبت‌نام و ورود",
        "callback_data": f"bz186:signup:{approval_token}",
    }], [{
        "text": "❌ لغو",
        "callback_data": f"bz186:cancel:{approval_token}",
    }]]}
    return send_message(chat_id,
        "شمارهٔ شما توسط بله تأیید شد. برای ساخت/اتصال حساب دست گیر و ورود، "
        "دکمهٔ تأیید را بزنید.", markup)


def remove_keyboard(chat_id, text):
    return send_message(chat_id, text, {"remove_keyboard": True})


def answer_callback(callback_id, text, alert=False):
    return bool(_call("answerCallbackQuery", {
        "callback_query_id": callback_id,
        "text": str(text)[:200],
        "show_alert": bool(alert),
    }).get("ok"))


def send_notification(chat_id, text, url=""):
    markup = None
    if url:
        markup = {"inline_keyboard": [[{"text": "مشاهده در دست گیر", "url": url}]]}
    return send_message(chat_id, "🔔 دست گیر\n\n" + str(text)[:3500], markup)


def download_file(file_id, max_bytes=3 * 1024 * 1024 + 1):
    """v207: getFile → bounded download. Returns bytes or b"" (never raises)."""
    if not re.fullmatch(r"[A-Za-z0-9_\-:.]{8,200}", str(file_id or "")):
        return b""
    info = _call("getFile", {"file_id": file_id})
    path = ((info.get("result") or {}).get("file_path") or "") if info.get("ok") else ""
    if not path or ".." in path or path.startswith("/"):
        return b""
    try:
        with urllib.request.urlopen(f"{FILE_ROOT}{token()}/{path}", timeout=15) as r:
            return r.read(max_bytes)
    except Exception:
        return b""
