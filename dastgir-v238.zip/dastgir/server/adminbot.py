# -*- coding: utf-8 -*-
"""Owner-only admin bot over a dedicated Bale bot (v233).

Why a second bot: the public customer bot (server/bale.py) must never mix
with server administration. This module mirrors its transport (stdlib urllib
against https://tapi.bale.ai/bot) but uses its own token/secret/owner chat:

  BALE_ADMIN_TOKEN   bot token from @BotFather (the admin bot)
  BALE_ADMIN_SECRET  unguessable webhook path segment (32+ chars)
  BALE_ADMIN_CHAT    owner chat id -- the ONLY chat ever answered

Route: POST /api/bale-admin/webhook/<secret> (see server/app.py, v185 mirror).

Sandbox note: the bazarche systemd unit sets NoNewPrivileges + ProtectSystem,
so privileged actions (backup now, service restart) CANNOT run in-process
(no sudo, no setuid). They are written to DATA_DIR/adminbot-cmd/*.json and
executed as root by /usr/local/sbin/dastgir-admin-exec.sh (cron, every
minute). Everything else answers instantly inside the webhook request.
"""
import datetime
import glob
import gzip
import json
import os
import random
import re
import subprocess
import time
import urllib.request

import assistant
import db

API_ROOT = os.environ.get("BALE_API_ROOT", "https://tapi.bale.ai/bot").rstrip("/")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PUBLIC_HEALTH = "https://daastgir.ir/healthz"
OFFSITE_LOG = "/var/log/dastgir-offsite.log"
WATCHDOG_LOG = "/var/log/dastgir-watchdog.log"
NGINX_ACCESS = "/var/log/nginx/access.log"
NGINX_ERROR = "/var/log/nginx/error.log"

KEYBOARD = {"keyboard": [
    ["وضعیت", "آمار"],
    ["دیتابیس", "سیستم"],
    ["بکاپ", "گزارش"],
    ["ریستارت", "لاگ"],
    ["تأیید", "تازه‌ها"],
    ["نگهبان", "صف"],
], "resize_keyboard": True}

ALLOWED_QUEUE_CMDS = ("backup", "restart")
DENIED = "⛔ این بات فقط مال مدیره."
UNKNOWN = "🤔 نفهمیدم. بفرست: راهنما"


def token():
    return os.environ.get("BALE_ADMIN_TOKEN", "").strip()


def webhook_secret():
    return os.environ.get("BALE_ADMIN_SECRET", "").strip()


def owner_chat():
    return os.environ.get("BALE_ADMIN_CHAT", "").strip()


def enabled():
    return bool(token() and webhook_secret() and owner_chat())


def queue_dir():
    return os.environ.get("ADMINBOT_QUEUE") or os.path.join(db.DATA_DIR, "adminbot-cmd")


def pending_path():
    # Prod runs under systemd PrivateTmp, so a restart naturally clears a
    # half-confirmed restart -- exactly the safe behaviour we want.
    return os.environ.get("ADMINBOT_PENDING") or "/tmp/dastgir-admin-pending.json"


# ---------- transport (same shape as server/bale.py) ----------

def _call(method, payload):
    tok = token()
    if not tok:
        return {"ok": False}
    req = urllib.request.Request(
        f"{API_ROOT}{tok}/{method}",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json", "User-Agent": "Daastgir/233"},
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            out = json.loads(r.read(262144).decode("utf-8", "replace"))
            return out if isinstance(out, dict) else {"ok": False}
    except Exception:
        return {"ok": False}


def send_message(chat_id, text, reply_markup=None):
    cid = str(chat_id)
    data = {"chat_id": int(cid) if cid.isdigit() else cid, "text": str(text)[:4096]}
    if reply_markup:
        data["reply_markup"] = reply_markup
    return bool(_call("sendMessage", data).get("ok"))


# ---------- small helpers ----------

def _run(args, timeout=10):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout,
                           stdin=subprocess.DEVNULL)
        return (p.stdout or "").strip()
    except Exception:
        return ""


def _fetch_url(url, timeout=10):
    req = urllib.request.Request(url, headers={"User-Agent": "Daastgir/233"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(4096).decode("utf-8", "replace")


def _human(n):
    try:
        n = int(n)
    except (TypeError, ValueError):
        return "?"
    if n >= 1048576:
        return f"{n / 1048576:.1f}M"
    if n >= 1024:
        return f"{n / 1024:.0f}K"
    return f"{n}B"


def _tail(path, n=3, width=120):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()[-n:]
        return "\n".join(l[:width] for l in lines)
    except OSError:
        return ""


def _days_until(datestr):
    """Whole days from now until a `date -d`-parseable date, or None."""
    try:
        then = int(_run(["date", "-d", datestr, "+%s"], timeout=5) or 0)
    except (TypeError, ValueError):
        return None
    if then <= 0:
        return None
    return max(0, (then - int(time.time())) // 86400)


_J_MONTHS = ("", "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
             "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
_J_WEEKDAYS = ("دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه", "یکشنبه")


def fa_today():
    """v234: «چهارشنبه ۱۸ شهریور» (Tehran); Gregorian fallback, never raises."""
    try:
        now = db.iran_now().replace(tzinfo=None)
        from layout import g2j  # tools/ is on sys.path next to server/
        jy, jm, jd = g2j(now.year, now.month, now.day)
        return "%s %d %s" % (_J_WEEKDAYS[now.weekday()], jd, _J_MONTHS[jm])
    except Exception:
        return time.strftime("%F")


# ---------- getters ----------

def g_site():
    t0 = time.time()
    try:
        body = _fetch_url(PUBLIC_HEALTH)
        ms = int((time.time() - t0) * 1000)
        return f"✅ بالا ({ms}ms)" if "ok" in body else "🚨 جواب خراب"
    except Exception:
        # The webhook itself is being served, so the app is up; only the
        # public loopback check failed.
        return "✅ بالا"


def g_svc():
    return _run(["systemctl", "is-active", "bazarche"]) or "?"


def _disk_pct():
    try:
        import shutil
        u = shutil.disk_usage("/")
        return u.used * 100 // u.total
    except Exception:
        return None


def g_disk():
    pct = _disk_pct()
    return f"{pct}٪" if pct is not None else "?"


def g_ver():
    try:
        with open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8") as f:
            return f.read().strip() or "?"
    except OSError:
        return "?"


def g_up():
    try:
        with open("/proc/uptime") as f:
            secs = int(float(f.read().split()[0]))
    except (OSError, ValueError, IndexError):
        return "?"
    if secs >= 86400:
        return f"{secs // 86400} روز"
    if secs >= 3600:
        return f"{secs // 3600} ساعت"
    return f"{secs // 60} دقیقه"


def g_backup():
    # The offsite log has no timestamps (plain cron capture), so freshness
    # comes from the file mtime while success comes from the content.
    lines = _tail(OFFSITE_LOG, 5, 200).splitlines()
    stripped = [l.strip() for l in lines]
    # v236: the offsite script timestamp-prefixes every line
    # ("2026-09-09 20:40:01 OK: db=..."), so the markers are matched
    # anywhere in the line, not just at the start.
    if stripped and "FAIL" in stripped[-1]:
        return "خطا! 🚨"
    if not any("OK:" in s for s in stripped):
        return "نامشخص"
    try:
        age_min = int((time.time() - os.path.getmtime(OFFSITE_LOG)) // 60)
    except OSError:
        return "نامشخص"
    if age_min >= 60:
        return f"{age_min // 60} ساعت پیش ✅"
    return f"{age_min} دقیقه پیش ✅"


def g_cert():
    out = _run(["openssl", "s_client", "-connect", "daastgir.ir:443",
                "-servername", "daastgir.ir"], timeout=12)
    if not out:
        return "?"
    try:
        # v236: input= already feeds stdin — passing stdin=DEVNULL too
        # raises ValueError, which made this always return "?".
        p = subprocess.run(["openssl", "x509", "-noout", "-enddate"], input=out,
                           capture_output=True, text=True, timeout=10)
        end = (p.stdout or "").strip().split("=", 1)[-1]
        days = _days_until(end)
        return str(days) if days is not None else "?"
    except Exception:
        return "?"


def g_traffic():
    """(hits, uniq_ips, err5) for today, or None when the log is unreadable."""
    try:
        day = time.strftime("%d/%b/%Y")
        hits, ips, e5 = 0, set(), 0
        with open(NGINX_ACCESS, encoding="utf-8", errors="replace") as f:
            for line in f:
                if "[" + day not in line:
                    continue
                hits += 1
                parts = line.split()
                if parts:
                    ips.add(parts[0])
                if len(parts) >= 9 and parts[8].startswith("5"):
                    e5 += 1
        return hits, len(ips), e5
    except OSError:
        return None


def g_errcount():
    out = _run(["journalctl", "-u", "bazarche", "-p", "err", "--since",
                "24 hours ago", "--no-pager", "-o", "cat"])
    return sum(1 for l in out.splitlines() if l.strip()) if out else 0


def g_db():
    """(bookings, new, today, customers, week_new, businesses, items, unread, new_inq)."""
    def q(sql):
        try:
            con = db.connect()
            row = con.execute(sql).fetchone()
            con.close()
            return str(row[0])
        except Exception:
            return "?"
    return (
        q("SELECT COUNT(*) FROM bookings"),
        q("SELECT COUNT(*) FROM bookings WHERE status='new'"),
        q("SELECT COUNT(*) FROM bookings WHERE substr(created,1,10)=date('now')"),
        q("SELECT COUNT(*) FROM customers"),
        q("SELECT COUNT(*) FROM customers WHERE substr(created,1,10)>=date('now','-7 days')"),
        q("SELECT COUNT(*) FROM businesses"),
        q("SELECT COUNT(*) FROM items"),
        q("SELECT COUNT(*) FROM messages WHERE status='new'"),
        q("SELECT COUNT(*) FROM inquiries WHERE status='new'"),
    )


def g_dbsize():
    try:
        return _human(os.path.getsize(db.DB_PATH))
    except OSError:
        return "?"


# ---------- replies (pure: return text, the route sends it) ----------

def watchdog_state_path():
    return os.environ.get("ADMINBOT_WATCHDOG_STATE") or "/var/lib/dastgir-watchdog.state"


def _active_alerts():
    try:
        with open(watchdog_state_path(), encoding="utf-8") as f:
            return [l.strip() for l in f if l.strip()]
    except OSError:
        return []


def do_queue():
    try:
        files = sorted(os.listdir(queue_dir()))
    except OSError:
        files = []
    files = [f for f in files if f.endswith(".json")]
    if not files:
        return "📭 صف اجرا خالی است."
    lines = ["📭 صف اجرا:"]
    now = time.time()
    for f in files[:10]:
        try:
            age = int((now - os.path.getmtime(os.path.join(queue_dir(), f))) // 60)
        except OSError:
            age = -1
        cmd = f.rsplit("-", 2)[0]
        lines.append(f"• {cmd} ({age} دقیقه در صف)" if age >= 0 else f"• {cmd}")
    return "\n".join(lines)


def do_status():
    alerts = _active_alerts()
    extra = ("\n🔕 هشدار فعال: %s" % ", ".join(alerts)) if alerts else ""
    return ("📊 وضعیت دستگیر (v%s)\n"
            "🌐 سایت: %s\n"
            "⚙️ سرویس: %s · 💾 دیسک: %s\n"
            "💿 بکاپ: %s\n"
            "🔒 گواهی: %s روز · ⏱ %s%s" % (
                g_ver(), g_site(), g_svc(), g_disk(), g_backup(),
                g_cert(), g_up(), extra))


def do_traffic():
    t = g_traffic()
    if t is None:
        return "📈 آمار: لاگ nginx پیدا نشد"
    h, u, e = t
    return ("📈 آمار امروز\n"
            "👁 بازدید: %s · 👤 آی‌پی یکتا: %s\n"
            "🔥 خطای 5xx: %s" % (h, u, e))


def do_db():
    b, bn, bt, c, cw, bz, it, m, q = g_db()
    return ("🗄 دیتابیس (%s)\n"
            "📅 نوبت‌ها: %s کل · %s جدید · %s امروز\n"
            "👥 مشتری: %s (%s این هفته) · 🏪 کسب‌وکار: %s · 📦 آیتم: %s\n"
            "✉️ پیام خوانده‌نشده: %s · 📩 استعلام جدید: %s" % (
                g_dbsize(), b, bn, bt, c, cw, bz, it, m, q))


def do_sys():
    try:
        load = "%.2f %.2f %.2f" % os.getloadavg()
    except (OSError, AttributeError):
        load = "?"
    mem = "?"
    try:
        info = {}
        with open("/proc/meminfo") as f:
            for line in f:
                p = line.split()
                if len(p) >= 2:
                    info[p[0].rstrip(":")] = int(p[1])
        pct = (info["MemTotal"] - info["MemAvailable"]) * 100 // info["MemTotal"]
        mem = "%d٪ (%dM آزاد)" % (pct, info["MemAvailable"] // 1024)
    except (OSError, KeyError, ValueError, ZeroDivisionError):
        pass
    top_s = "?"
    lines = _run(["ps", "-eo", "comm,%cpu", "--sort=-%cpu"]).splitlines()
    if len(lines) >= 2:
        p = lines[1].split()
        if len(p) >= 2:
            top_s = "%s %s٪" % (p[0], p[1])
    du = _run(["du", "-sb", os.path.join(ROOT, "site", "assets", "img", "uploads")]).split()
    ups = _human(du[0]) if du else "?"
    ssh = _run(["journalctl", "-u", "ssh", "--since", "24 hours ago",
                "--no-pager", "-o", "cat"])
    fails = sum(1 for l in ssh.splitlines() if "Failed" in l) if ssh else 0
    return ("🖥 سیستم\n"
            "📉 لود: %s · 🧠 رم: %s\n"
            "🔥 پرمصرف: %s\n"
            "🗄 دیتابیس: %s · 🖼 آپلودها: %s\n"
            "🛡 ورود ناموفق SSH: %s" % (load, mem, top_s, g_dbsize(), ups, fails))


def do_errors():
    j = _run(["journalctl", "-u", "bazarche", "-p", "err", "--since",
              "24 hours ago", "--no-pager", "-o", "cat"]).splitlines()[-2:]
    j = "\n".join(l[:150] for l in j) or "ندارد ✅"
    n = ""
    try:
        day = time.strftime("%Y/%m/%d")
        with open(NGINX_ERROR, encoding="utf-8", errors="replace") as f:
            hit = [l.rstrip() for l in f if day in l][-2:]
        n = "\n".join(l[:150] for l in hit)
    except OSError:
        pass
    n = n or "ندارد ✅"
    return "⚠️ خطاها (۲۴ ساعت)\nسرویس:\n%s\nnginx:\n%s" % (j, n)


def do_log():
    l1 = _tail(OFFSITE_LOG, 3) or "خالی"
    l2 = _tail(WATCHDOG_LOG, 3) or "خالی"
    return "📋 بکاپ:\n%s\n📋 نگهبان:\n%s" % (l1, l2)


def do_report():
    t = g_traffic()
    h, u, e = t if t else ("?", "?", "?")
    d = g_db()
    return ("📋 گزارش دستگیر (%s)\n"
            "🌐 سایت: %s · ⚙️ %s · 💾 %s\n"
            "💿 بکاپ: %s · 🔒 گواهی: %s روز\n"
            "📈 بازدید: %s (%s آی‌پی) · خطای 5xx: %s\n"
            "📅 نوبت جدید: %s · ✉️ پیام جدید: %s\n"
            "⚠️ خطای ۲۴ساعت: %s" % (
                fa_today(), g_site(), g_svc(), g_disk(),
                g_backup(), g_cert(), h, u, e, d[1], d[7], g_errcount()))


def do_help():
    return ("🤖 دستورات (یا دکمه‌ها):\n"
            "وضعیت · آمار · دیتابیس · سیستم\n"
            "بکاپ · گزارش · ریستارت · لاگ\n"
            "خطا · صف · تأیید · تازه‌ها\n"
            "نگهبان · پیام · کاربر · قیمت · حذف\n"
            "راهنما · سؤال آزاد (هوش مصنوعی)", KEYBOARD)


# ---------- v237: admin powers (visibility + actions) ----------

def do_bizqueue():
    rows = db._rows("SELECT id,name,phone,city FROM businesses WHERE status='pending' ORDER BY id DESC LIMIT 8")
    total = db._one("SELECT COUNT(*) c FROM businesses WHERE status='pending'")["c"]
    if not rows:
        return "📭 کسب‌وکار در انتظاری نیست."
    lines = [f"🏪 در انتظار تأیید ({total}):", ""]
    for r in rows:
        lines.append(f"#{r['id']} · {(r['name'] or '—')}\n{(r['phone'] or '—')} · {(r['city'] or '—')}")
    lines += ["", "تأیید ۱۲ = انتشار · رد ۱۲ = رد"]
    return "\n".join(lines)


def do_biz_ask(approve, bid):
    r = db._one("SELECT id,name FROM businesses WHERE id=? AND status='pending'", (bid,))
    if not r:
        return "این کسب‌وکار پیدا نشد یا قبلاً بررسی شده است."
    _pending_write(time.time() + 120, "biz_ok" if approve else "biz_no", str(bid))
    return f"«{r['name']}» {'منتشر' if approve else 'رد'} بشه؟ بفرست: بله"


def _do_biz_decide(action, target):
    try:
        bid = int(target)
    except (TypeError, ValueError):
        return "⚠️ خطای داخلی؛ دوباره بفرست.", None
    r = db._one("SELECT id,name FROM businesses WHERE id=? AND status='pending'", (bid,))
    if not r:
        return "این کسب‌وکار پیدا نشد یا قبلاً بررسی شده است.", None
    ok = action == "biz_ok"
    db.save_business({"status": "published" if ok else "rejected"}, bid=bid)
    db.log("biz.bot-" + ("approve" if ok else "reject"), f"{bid} {r['name']}")
    return (f"«{r['name']}» منتشر شد ✅" if ok else f"«{r['name']}» رد شد.", None)


def do_cast_ask(text):
    body = str(text or "").strip()
    if not body:
        return "متن پیام را هم بفرست. مثلاً: پیام سلام! فروش ویژه شروع شد."
    if len(body) > 500:
        return "متن تا ۵۰۰ نویسه باشد."
    n = db._one("SELECT COUNT(*) c FROM customers WHERE status='active'")["c"]
    _pending_write(time.time() + 120, "cast", body)
    return f"به {n} مشتری ارسال بشه؟\n\n«{body}»\n\nبفرست: بله"


def _do_cast(target):
    body = str(target or "").strip()
    if not body:
        return "متن خالی است؛ دوباره بفرست: پیام <متن>", None
    n = db.notify_all("info", body, "")
    db.log("broadcast", f"{n} customers (bot)")
    return f"اعلان برای {n} مشتری ارسال شد ✅", None


def do_fresh():
    try:
        cust24 = db._one("SELECT COUNT(*) c FROM customers WHERE created>=datetime('now','-1 day')")["c"]
        ord24 = db._one("SELECT COUNT(*) c FROM orders WHERE created>=datetime('now','-1 day')")["c"]
        book_new = db._one("SELECT COUNT(*) c FROM bookings WHERE status='new'")["c"]
        chats_open = db._one("SELECT COUNT(*) c FROM chat_threads WHERE status='open'")["c"]
        pend_biz = db._one("SELECT COUNT(*) c FROM businesses WHERE status='pending'")["c"]
    except Exception:
        return "⚠️ خطای داخلی؛ دوباره بفرست."
    return ("🆕 تازه‌ها (۲۴ ساعت)\n"
            f"👥 مشتری تازه: {cust24}\n"
            f"📦 سفارش تازه: {ord24}\n"
            f"📅 نوبت جدید (باز): {book_new}\n"
            f"💬 گفتگوی باز: {chats_open}\n"
            f"🏪 کسب‌وکار در انتظار: {pend_biz}")


def do_who(arg):
    phone = db.norm_phone(_fa2en(arg).strip())
    if not phone:
        return "شماره را هم بفرست. مثلاً: کاربر 09123456789"
    c = db._one("SELECT * FROM customers WHERE phone=?", (phone,))
    if not c:
        return "مشتری با این شماره پیدا نشد."
    o = db._one("SELECT COUNT(*) c,COALESCE(SUM(total),0) s FROM orders WHERE customer_id=?", (c["id"],))
    b = db._one("SELECT COUNT(*) c FROM bookings WHERE customer_id=?", (c["id"],))
    t = db._one("SELECT COUNT(*) c FROM chat_threads WHERE customer_id=? AND status='open'", (c["id"],))
    m = db._one("SELECT COUNT(*) c FROM messenger_accounts WHERE customer_id=?", (c["id"],))
    status = "مسدود ⛔" if c["status"] == "blocked" else "فعال ✅"
    return ("👤 پروندهٔ مشتری\n"
            f"نام: {(c['name'] or '—')}\n"
            f"شماره: {c['phone']} · {status}\n"
            f"📦 سفارش: {o['c']} (مجموع {o['s']})\n"
            f"📅 نوبت: {b['c']} · 💬 گفتگوی باز: {t['c']} · 🔗 اتصال پیام‌رسان: {m['c']}")


def do_watch():
    alerts = _active_alerts()
    try:
        qn = len([f for f in os.listdir(queue_dir()) if f.endswith(".json")])
    except OSError:
        qn = 0
    return ("🛡 نگهبان\n"
            f"هشدار فعال: {('، '.join(alerts)) if alerts else 'نیست ✅'}\n"
            f"📥 صف اجرا: {qn}\n"
            f"💿 بکاپ: {g_backup()}\n"
            f"🔒 گواهی: {g_cert()} روز · 💾 دیسک: {g_disk()}\n"
            f"🤖 هوش: {'فعال ✅' if assistant.configured() else 'پیکربندی نشده'}\n"
            f"⚠️ خطای سرویس (۲۴h): {g_errcount()} · ⏱ {g_up()}")


_UNQUEUE_FA = {"بکاپ": "backup", "بکاپ‌گیری": "backup",
               "ریستارت": "restart", "ری‌استارت": "restart"}


def do_unqueue(arg):
    want = _UNQUEUE_FA.get(_fa2en(arg).strip()) or _fa2en(arg).strip().lower()
    if want not in ALLOWED_QUEUE_CMDS:
        return "فقط بکاپ و ریستارت قابل لغون. مثلاً: حذف بکاپ"
    try:
        files = os.listdir(queue_dir())
    except OSError:
        files = []
    gone = 0
    for f in files:
        if f.startswith(want + "-") and f.endswith(".json"):
            try:
                os.remove(os.path.join(queue_dir(), f))
                gone += 1
            except OSError:
                pass
    fa = "بکاپ" if want == "backup" else "ریستارت"
    return f"«{fa}» از صف حذف شد ✅" if gone else f"چیزی از «{fa}» تو صف نیست."


def do_prices(arg):
    v = _fa2en(arg).strip().lower()
    if v in ("روشن", "on", "1"):
        db.set_setting("prices_enabled", "1")
        db._pagecache_drop()
        return "نمایش قیمت: روشن ✅"
    if v in ("خاموش", "off", "0"):
        db.set_setting("prices_enabled", "0")
        db._pagecache_drop()
        return "نمایش قیمت: خاموش ✅"
    return "بفرست: قیمت روشن (یا: قیمت خاموش)"


# ---------- weekly deep audit (v234: continuous review) ----------

def audit_snapshot_path():
    return os.environ.get("ADMINBOT_AUDIT") or os.path.join(db.DATA_DIR, "adminbot-audit.json")


_MNUM = {"Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6,
         "Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12}


def _week_traffic():
    """(hits, err5, days_seen) for the last 7 days across rotated nginx logs."""
    cutoff = datetime.date.today() - datetime.timedelta(days=7)
    hits, e5, seen = 0, 0, set()
    paths = sorted(glob.glob("/var/log/nginx/access.log*"))[:10]
    for p in paths:
        try:
            if p.endswith(".gz"):
                f = gzip.open(p, "rt", encoding="utf-8", errors="replace")
            else:
                f = open(p, encoding="utf-8", errors="replace")
        except OSError:
            continue
        try:
            for line in f:
                m = re.search(r"\[(\d{2})/(\w{3})/(\d{4})", line)
                if not m:
                    continue
                try:
                    day = datetime.date(int(m.group(3)), _MNUM.get(m.group(2), 0), int(m.group(1)))
                except ValueError:
                    continue
                if day < cutoff:
                    continue
                hits += 1
                seen.add(day.toordinal())
                parts = line.split()
                if len(parts) >= 9 and parts[8].startswith("5"):
                    e5 += 1
        finally:
            try:
                f.close()
            except Exception:
                pass
    return hits, e5, len(seen)


def _err_patterns():
    """Top-3 normalized service error patterns over 7 days + total count."""
    out = _run(["journalctl", "-u", "bazarche", "-p", "err", "--since",
                "7 days ago", "--no-pager", "-o", "cat"], timeout=20)
    groups = {}
    for line in out.splitlines():
        key = re.sub(r"\d+", "#", line.strip())[:90]
        if key:
            groups[key] = groups.get(key, 0) + 1
    top = sorted(groups.items(), key=lambda kv: -kv[1])[:3]
    return top, sum(groups.values())


def deep_audit_text():
    now = int(time.time())
    try:
        prev = json.load(open(audit_snapshot_path(), encoding="utf-8"))
        prev = prev if isinstance(prev, dict) else {}
    except (OSError, ValueError):
        prev = {}
    pct = _disk_pct()
    try:
        db_bytes = os.path.getsize(db.DB_PATH)
    except OSError:
        db_bytes = 0
    try:
        target = audit_snapshot_path()
        if os.path.dirname(target):
            os.makedirs(os.path.dirname(target), exist_ok=True)
        json.dump({"ts": now, "disk_pct": pct, "db_bytes": db_bytes},
                  open(target, "w", encoding="utf-8"))
    except OSError:
        pass
    disk_line = "؟"
    if pct is not None:
        disk_line = f"{pct}٪"
        if isinstance(prev.get("disk_pct"), int):
            dd = pct - prev["disk_pct"]
            disk_line += f" ({dd:+} نسبت به هفته پیش)" if dd else " (بدون تغییر)"
    db_line = _human(db_bytes)
    if db_bytes and isinstance(prev.get("db_bytes"), int) and prev["db_bytes"]:
        dg = db_bytes - prev["db_bytes"]
        db_line += f" ({dg / 1048576:+.1f}M)" if abs(dg) >= 104857 else " (بدون تغییر)"
    hits, e5, days = _week_traffic()
    top, err_total = _err_patterns()
    ssh = _run(["journalctl", "-u", "ssh", "--since", "7 days ago",
                "--no-pager", "-o", "cat"], timeout=20)
    fails = sum(1 for l in ssh.splitlines() if "Failed" in l) if ssh else 0
    oks = sum(1 for l in _tail(OFFSITE_LOG, 300, 60).splitlines() if l.strip().startswith("OK:"))
    cert = g_cert()
    sug = []
    if pct is not None and pct >= 85:
        sug.append("دیسک بحرانی است؛ لاگ/بکاپ قدیمی پاک شود")
    if e5:
        sug.append(f"{e5} خطای 5xx در هفته؛ لاگ nginx بررسی شود")
    if err_total:
        sug.append(f"{err_total} خطای سرویس در هفته")
    if fails > 50:
        sug.append(f"{fails} تلاش ناموفق SSH؛ زیر نظر باشد")
    if cert.isdigit() and int(cert) < 14:
        sug.append(f"گواهی فقط {cert} روز مانده؛ تمدید شود")
    if isinstance(prev.get("db_bytes"), int) and prev["db_bytes"] and db_bytes > prev["db_bytes"] * 1.5:
        sug.append("رشد سریع دیتابیس نسبت به هفته پیش")
    if not sug:
        sug.append("همه‌چیز عادی است ✅")
    lines = [f"🩺 بررسی هفتگی دستگیر ({fa_today()})",
             f"📈 ترافیک ۷ روز: {hits} بازدید · خطای 5xx: {e5}",
             f"💾 دیسک: {disk_line} · 🗄 دیتابیس: {db_line}",
             f"💿 بکاپ موفق (لاگ فعلی): {oks} · 🔒 گواهی: {cert} روز",
             f"⚠️ خطای سرویس: {err_total} · 🛡 SSH ناموفق: {fails}"]
    for pat, cnt in top:
        lines.append(f"• {cnt}× {pat[:80]}")
    lines.append("💡 پیشنهاد: " + "؛ ".join(sug))
    return "\n".join(lines)[:3500]


def run_weekly_audit():
    """Root-cron entry: send the deep audit to the owner. Never raises."""
    try:
        if not (token() and owner_chat()):
            return False
        return send_message(owner_chat(), deep_audit_text())
    except Exception as e:
        print("adminbot weekly audit error:", e, flush=True)
        return False


# ---------- privileged queue + restart confirm ----------

def queue_write(cmd):
    if cmd not in ALLOWED_QUEUE_CMDS:
        return False
    try:
        os.makedirs(queue_dir(), exist_ok=True)
        name = f"{cmd}-{int(time.time())}-{random.randrange(1000, 9999)}.json"
        with open(os.path.join(queue_dir(), name), "w", encoding="utf-8") as f:
            json.dump({"cmd": cmd, "ts": int(time.time())}, f)
        return True
    except OSError:
        return False


def _pending_read():
    try:
        with open(pending_path(), encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _pending_write(exp, action="restart", target=""):
    try:
        with open(pending_path(), "w", encoding="utf-8") as f:
            json.dump({"exp": exp, "action": action, "target": target}, f)
    except OSError:
        pass


def _pending_clear():
    try:
        os.remove(pending_path())
    except OSError:
        pass


def _cmd_of(text):
    w = (text or "").strip().split()
    return w[0].split("@")[0] if w else ""


_FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")


def _fa2en(text):
    return str(text or "").translate(_FA_DIGITS)


def _norm_id(arg):
    try:
        v = int(_fa2en(arg).strip())
        return v if v > 0 else None
    except (TypeError, ValueError):
        return None


def _rest(text):
    parts = str(text or "").strip().split(None, 1)
    return parts[1].strip() if len(parts) > 1 else ""


_SNAP_SECRET_RX = ("token", "secret", "pass", "key", "salt", "hash")


def admin_snapshot():
    """Live read-only site picture for the admin copilot. Never raises;
    secret-ish settings are dropped entirely (the model must never see them)."""
    try:
        t = g_traffic()
        traffic = f"{t[0]} بازدید · {t[1]} آی‌پی یکتا · {t[2]} خطای 5xx" if t else "لاگ خوانده نشد"
    except Exception:
        traffic = "؟"
    try:
        b, bn, bt, c, cw, bz, it, m, q = g_db()
        dbline = (f"{b} نوبت ({bn} جدید) · {c} مشتری ({cw} این هفته) · {bz} کسب‌وکار · "
                  f"{it} آیتم · {m} پیام خوانده‌نشده · {q} استعلام جدید")
    except Exception:
        dbline = "؟"
    try:
        pend = db._rows("SELECT id,name,phone FROM businesses WHERE status='pending' ORDER BY id DESC LIMIT 5")
        pend_n = db._one("SELECT COUNT(*) c FROM businesses WHERE status='pending'")["c"]
        rev_n = db._one("SELECT COUNT(*) c FROM reviews WHERE status='pending'")["c"]
        clm_n = db._one("SELECT COUNT(*) c FROM claims WHERE status='pending'")["c"]
        tix_n = db._one("SELECT COUNT(*) c FROM tickets WHERE status='open'")["c"]
        inq_n = db._one("SELECT COUNT(*) c FROM inquiries WHERE status='new'")["c"]
    except Exception:
        pend, pend_n, rev_n, clm_n, tix_n, inq_n = [], "؟", "؟", "؟", "؟", "؟"
    try:
        recent = db._rows("SELECT o.id,o.total,o.status,b.name biz FROM orders o "
                          "JOIN businesses b ON b.id=o.biz_id ORDER BY o.id DESC LIMIT 5")
        cust24 = db._one("SELECT COUNT(*) c FROM customers WHERE created>=datetime('now','-1 day')")["c"]
        ord24 = db._one("SELECT COUNT(*) c FROM orders WHERE created>=datetime('now','-1 day')")["c"]
    except Exception:
        recent, cust24, ord24 = [], "؟", "؟"
    try:
        ops = {k: v for k, v in (db.get_settings() or {}).items()
               if not any(s in k.lower() for s in _SNAP_SECRET_RX)}
        first = {"site_name", "prices_enabled", "order_cancel_minutes", "panel_allow_ips"}
        ordered = sorted(ops.items(), key=lambda kv: (kv[0] not in first, kv[0]))
        opsline = " · ".join(f"{k}={v}" for k, v in ordered)[:600] or "—"
    except Exception:
        opsline = "؟"
    alerts = _active_alerts()
    lines = [
        f"نسخه {g_ver()} · سرویس {g_svc()} · آپتایم {g_up()} · دیسک {g_disk()}",
        f"بکاپ: {g_backup()} · گواهی: {g_cert()} روز · دیتابیس: {g_dbsize()}",
        f"ترافیک امروز: {traffic} · خطای سرویس ۲۴h: {g_errcount()}",
        f"دیتابیس: {dbline}",
        f"هشدار: {('، '.join(alerts)) if alerts else 'نیست'}",
        f"صف تأیید: {pend_n} کسب‌وکار · {rev_n} نظر · {clm_n} تصاحب · {tix_n} تیکت باز · {inq_n} استعلام",
    ]
    if pend:
        lines.append("در انتظار: " + " · ".join(f"#{r['id']} {r['name']}" for r in pend))
    if recent:
        lines.append("سفارش اخیر: " + " · ".join(f"#{r['id']} {(r['biz'] or '')[:20]} {r['total']} ({r['status']})" for r in recent))
    lines.append(f"۲۴ ساعت: {cust24} مشتری تازه · {ord24} سفارش تازه")
    lines.append("تنظیمات: " + opsline)
    return "\n".join(lines)[:3000]


def memory_path():
    return os.environ.get("ADMINBOT_MEMORY") or "/tmp/dastgir-admin-memory.json"


def _memory_load(max_age=1800, limit=6):
    try:
        with open(memory_path(), encoding="utf-8") as f:
            items = json.load(f)
        now = time.time()
        return [m for m in items if isinstance(m, dict) and now - float(m.get("ts", 0)) < max_age][-limit:]
    except (OSError, ValueError, TypeError):
        return []


def _memory_save(q, a, limit=6):
    items = _memory_load(limit=limit - 1) + [{"q": str(q or "")[:400], "a": str(a or "")[:600], "ts": time.time()}]
    try:
        with open(memory_path(), "w", encoding="utf-8") as f:
            json.dump(items[-limit:], f, ensure_ascii=False)
    except OSError:
        pass


def handle_text(uid, chat_id, text):
    """Owner command dispatcher. Returns (reply_text, reply_markup|None)."""
    try:
        if str(chat_id) != owner_chat():
            return DENIED, None
        cmd = _cmd_of(text)
        if cmd in ("بله", "اره", "آره"):
            pend = _pending_read()
            if pend.get("exp", 0) > time.time():
                action, target = pend.get("action") or "restart", pend.get("target") or ""
                _pending_clear()
                if action in ("biz_ok", "biz_no"):
                    return _do_biz_decide(action, target)
                if action == "cast":
                    return _do_cast(target)
                if queue_write("restart"):
                    return "⏳ ری‌استارت تو صف اجرا رفت (حداکثر ۱ دقیقه)", None
                return "⚠️ صف نوشتن نشد؛ دیسک رو چک کن", None
            _pending_clear()
            again = {"restart": "ریستارت", "biz_ok": "تأیید", "biz_no": "رد",
                     "cast": "پیام"}.get(pend.get("action") or "restart", "ریستارت")
            return f"⌛ منقضی شد. دوباره بفرست: {again}", None
        if cmd in ("خیر", "نه", "لغو"):
            _pending_clear()
            return "لغو شد ✅", None
        if cmd in ("/restart", "ریستارت", "/ریستارت", "ری‌استارت"):
            _pending_write(time.time() + 120)
            return "⚠️ سرویس ری‌استارت بشه؟ بفرست: بله", None
        _pending_clear()
        if cmd in ("/status", "وضعیت", "/وضعیت"):
            return do_status(), None
        if cmd in ("آمار", "/آمار", "/traffic"):
            return do_traffic(), None
        if cmd in ("دیتابیس", "/دیتابیس", "/db"):
            return do_db(), None
        if cmd in ("سیستم", "/سیستم", "/sys"):
            return do_sys(), None
        if cmd in ("خطا", "/خطا", "/errors"):
            return do_errors(), None
        if cmd in ("/backup", "بکاپ", "/بکاپ"):
            if queue_write("backup"):
                return "⏳ بکاپ تو صف اجرا رفت (حداکثر ۱ دقیقه)", None
            return "⚠️ صف نوشتن نشد؛ دیسک رو چک کن", None
        if cmd in ("گزارش", "/گزارش", "/report"):
            return do_report(), None
        if cmd in ("/log", "لاگ", "/لاگ"):
            return do_log(), None
        if cmd in ("صف", "/صف", "/queue"):
            return do_queue(), None
        if cmd in ("تأیید", "/تأیید", "/bizqueue"):
            arg = _rest(text)
            if not arg:
                return do_bizqueue(), None
            bid = _norm_id(arg)
            if bid is None:
                return "شمارهٔ کسب‌وکار درست نیست. مثلاً: تأیید ۱۲", None
            return do_biz_ask(True, bid), None
        if cmd in ("رد", "/رد", "/reject"):
            bid = _norm_id(_rest(text))
            if bid is None:
                return "شمارهٔ کسب‌وکار درست نیست. مثلاً: رد ۱۲", None
            return do_biz_ask(False, bid), None
        if cmd in ("پیام", "/پیام", "/cast"):
            return do_cast_ask(_rest(text)), None
        if cmd in ("تازه‌ها", "تازه ها", "/تازه‌ها", "/fresh"):
            return do_fresh(), None
        if cmd in ("کاربر", "/کاربر", "/who"):
            return do_who(_rest(text)), None
        if cmd in ("نگهبان", "/نگهبان", "/watch"):
            return do_watch(), None
        if cmd in ("حذف", "/حذف", "/unqueue", "کنسل"):
            return do_unqueue(_rest(text)), None
        if cmd in ("قیمت", "/قیمت", "/prices"):
            return do_prices(_rest(text)), None
        if cmd in ("/help", "راهنما", "/راهنما", "/start", "شروع"):
            return do_help()
        # v238: anything else goes to the read-only admin copilot (Bale only).
        if assistant.configured():
            mem = _memory_load()
            reply, _src = assistant.admin_answer(text, admin_snapshot(), mem)
            _memory_save(text, reply)
            return reply, None
        return ("هوش مصنوعی پیکربندی نشده است. کلید API را در "
                "/etc/dastgir-secrets.env بگذار (AI_BASE_URL / AI_API_KEY / AI_MODEL).", None)
    except Exception as e:
        print("adminbot handle_text error:", e, flush=True)
        return "⚠️ خطای داخلی؛ دوباره بفرست.", None


def handle_update(update):
    """Webhook entry: private text messages from the owner only."""
    try:
        msg = update.get("message")
        if not isinstance(msg, dict):
            return
        chat = msg.get("chat") or {}
        if chat.get("type") != "private":
            return
        chat_id = chat.get("id")
        if chat_id is None:
            return
        text = str(msg.get("text") or "")
        sender = msg.get("from") or {}
        reply, markup = handle_text(sender.get("id"), chat_id, text)
        send_message(chat_id, reply, markup)
    except Exception as e:
        print("adminbot handle_update error:", e, flush=True)
