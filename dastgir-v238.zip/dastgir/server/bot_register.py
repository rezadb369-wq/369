# -*- coding: utf-8 -*-
"""v207 — staged business registration for the Bale/Soroush bots (core).

Design rules (see HANDOFF.md §6):
  * The server owns the state.  `biz_reg_drafts.step` is the only source of
    truth; nothing the client sends (text or callback) can jump steps.
  * One live draft per customer, shared across both messengers, expiring
    after DRAFT_TTL seconds of inactivity.  Resume is automatic; cancel needs
    a second confirmation.
  * Every field is validated and length-capped here, never in the transport.
  * Phone is NEVER typed: it is copied from the verified customer account at
    submit time.  The user only chooses whether it is shown publicly.
  * Final submission requires a random one-use confirmation whose SHA-256 is
    stored in `bot_confirmations` (action='biz_register'); the raw token lives
    only in the callback and expires after CONFIRM_TTL seconds.
  * Result is always `status='pending'` and owner-bound; the admin panel's
    pending box publishes.  No direct publish path exists in this module.
"""
import json
import re
import time
import hashlib
import secrets

import db

DRAFT_TTL = 48 * 3600          # inactivity expiry
CONFIRM_TTL = 300              # final confirmation lifetime
MAX_IMAGES = 3                 # hybrid image policy: light set in bot, gallery on site
MAX_IMAGES_WEB = 6             # v208: the site wizard may attach a fuller first gallery
PLATFORMS = ("bale", "soroush", "web")

STEPS = ("category", "name", "city", "area", "address", "descr",
         "phone_public", "hours", "images", "preview", "done")
LIMITS = {"name": (2, 60), "city": (2, 40), "area": (0, 40),
          "address": (5, 160), "descr": (0, 300)}
# v208 — the web wizard shares the same keys but has room for longer text and
# the extra profile fields the old one-page form already persisted.
LIMITS_WEB = {"name": (2, 80), "city": (2, 40), "area": (0, 60), "address": (5, 300),
              "descr": (0, 2000), "tags": (0, 200), "province": (0, 40),
              "whatsapp": (0, 20), "instagram": (0, 80), "telegram": (0, 80),
              "eitaa": (0, 80), "bale": (0, 80), "soroush": (0, 80), "rubika": (0, 80),
              "website": (0, 200)}
WEB_STEPS = ("category", "identity", "location", "contact", "hours", "images", "preview")


HOURS_PRESETS = {
    "allday":  ("همه‌روزه ۹ تا ۲۲", {d: [["09:00", "22:00"]] for d in
                ("sat", "sun", "mon", "tue", "wed", "thu", "fri")}),
    "split":   ("صبح و عصر (۹–۱۳ و ۱۶–۲۱)، جمعه تعطیل", {d: [["09:00", "13:00"], ["16:00", "21:00"]] for d in
                ("sat", "sun", "mon", "tue", "wed", "thu")}),
    "weekdays": ("شنبه تا پنج‌شنبه ۸ تا ۲۰", {d: [["08:00", "20:00"]] for d in
                 ("sat", "sun", "mon", "tue", "wed", "thu")}),
    "skip":    ("فعلاً ثبت نشود (بعداً در سایت)", {}),
}

_URLISH = re.compile(r"(https?://|www\.|\.ir\b|\.com\b|@\w{3,}|t\.me/)", re.I)
_PHONEISH = re.compile(r"(?:\d[\s\-]?){9,}")
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


# ------------------------------------------------------------------ helpers
def _now():
    return time.time()


def _clean(text, lo, hi):
    """Normalise whitespace, strip control chars, enforce [lo, hi] length.
    Returns (value, error)."""
    t = _CTRL.sub("", str(text or ""))
    t = re.sub(r"[ \t\u00a0]+", " ", t)
    t = re.sub(r"\n{3,}", "\n\n", t).strip()
    if len(t) < lo:
        return None, f"حداقل {lo} نویسه لازم است."
    if len(t) > hi:
        return None, f"حداکثر {hi} نویسه مجاز است."
    return t, None


def _load(row):
    if not row:
        return None
    d = dict(row)
    try:
        d["data"] = json.loads(d.get("payload") or "{}")
        if not isinstance(d["data"], dict):
            d["data"] = {}
    except Exception:
        d["data"] = {}
    return d


def _drop_files(rows):
    """v208: images attached to a draft that is being discarded must not stay
    orphaned in the public upload dir (they were never referenced by a
    business row, so nothing else would ever clean them)."""
    import uploads
    for r in rows or []:
        try:
            imgs = (json.loads(r["payload"] or "{}") or {}).get("images") or []
        except Exception:
            imgs = []
        for pth in imgs:
            if isinstance(pth, str) and "/bizreg-" in pth:
                uploads.delete_image(pth)


def gc():
    now = _now()
    con = db.connect()
    try:
        rows = con.execute("SELECT payload FROM biz_reg_drafts WHERE expires<?", (now,)).fetchall()
    finally:
        con.close()
    if rows:
        _drop_files(rows)
        db._run("DELETE FROM biz_reg_drafts WHERE expires<?", (now,))


# ------------------------------------------------------------------ drafts
def get(customer_id):
    """Live (non-expired) draft for a customer, or None."""
    if not customer_id:
        return None
    gc()
    return _load(db._one("SELECT * FROM biz_reg_drafts WHERE customer_id=? AND expires>=?",
                         (int(customer_id), _now())))


def start(customer_id, platform):
    """Create a fresh draft (replacing any expired one). Returns the draft.
    If a live draft exists it is returned untouched (resume)."""
    if not customer_id:
        return None
    if platform not in PLATFORMS:
        return None
    live = get(customer_id)
    if live:
        return live
    now = _now()
    db._run("DELETE FROM biz_reg_drafts WHERE customer_id=?", (int(customer_id),))
    db._run("INSERT INTO biz_reg_drafts(customer_id,platform,step,payload,created,updated,expires) "
            "VALUES(?,?,?,?,?,?,?)",
            (int(customer_id), platform, "category", "{}", now, now, now + DRAFT_TTL))
    return get(customer_id)


def cancel(customer_id):
    """Hard-delete the draft. Idempotent."""
    if not customer_id:
        return False
    con = db.connect()
    try:
        rows = con.execute("SELECT payload FROM biz_reg_drafts WHERE customer_id=?", (int(customer_id),)).fetchall()
        n = con.execute("DELETE FROM biz_reg_drafts WHERE customer_id=?", (int(customer_id),)).rowcount
        con.commit()
    finally:
        con.close()
    _drop_files(rows)
    return n > 0


def _save(customer_id, step, data, expect_step=None):
    """Persist step+payload atomically; if expect_step is given the update is a
    compare-and-set so a stale/duplicate update cannot regress the state."""
    now = _now()
    con = db.connect()
    try:
        con.execute("BEGIN IMMEDIATE")
        if expect_step is None:
            n = con.execute("UPDATE biz_reg_drafts SET step=?,payload=?,updated=?,expires=? "
                            "WHERE customer_id=? AND expires>=?",
                            (step, json.dumps(data, ensure_ascii=False), now, now + DRAFT_TTL,
                             int(customer_id), now)).rowcount
        else:
            n = con.execute("UPDATE biz_reg_drafts SET step=?,payload=?,updated=?,expires=? "
                            "WHERE customer_id=? AND step=? AND expires>=?",
                            (step, json.dumps(data, ensure_ascii=False), now, now + DRAFT_TTL,
                             int(customer_id), expect_step, now)).rowcount
        con.commit()
    except Exception:
        con.rollback()
        return False
    finally:
        con.close()
    return n == 1


def next_step(step):
    i = STEPS.index(step) if step in STEPS else 0
    return STEPS[min(i + 1, len(STEPS) - 1)]


def prev_step(step):
    i = STEPS.index(step) if step in STEPS else 0
    return STEPS[max(i - 1, 0)]


def go_back(customer_id):
    """Move one step back without discarding data (server decides the target)."""
    d = get(customer_id)
    if not d or d["step"] in ("category", "done"):
        return d
    _save(customer_id, prev_step(d["step"]), d["data"], expect_step=d["step"])
    return get(customer_id)


# ------------------------------------------------------------------ v208 shared-state helpers
def bot_step_for(data):
    """Canonical (bot) step implied by the payload — the first step whose
    data is still missing. Lets a draft written by the site wizard resume in
    the bot (and vice-versa) without any channel-specific state in the DB."""
    data = data or {}
    if not data.get("cat_slug"):
        return "category"
    if not data.get("name"):
        return "name"
    if not data.get("city"):
        return "city"
    if "area" not in data:
        return "area"
    if not data.get("address"):
        return "address"
    if "descr" not in data:
        return "descr"
    if "phone_public" not in data:
        return "phone_public"
    if "hours" not in data:
        return "hours"
    if "images" not in data:
        return "images"
    return "preview"


def web_step_for(data):
    """First incomplete web page for a payload (web pages group several keys)."""
    b = bot_step_for(data)
    return {"category": "category", "name": "identity", "city": "location", "area": "location",
            "address": "location", "descr": "identity", "phone_public": "contact",
            "hours": "hours", "images": "images", "preview": "preview"}[b]


def web_reached(data):
    """Index of the furthest web page the applicant may open (completed pages
    stay editable; pages beyond the first gap are not reachable)."""
    return WEB_STEPS.index(web_step_for(data or {}))


def web_save(customer_id, updates, require_live=True):
    """Merge validated web fields into the draft; step is re-derived so the
    bot always sees a canonical state. Returns True when persisted."""
    d = get(customer_id)
    if not d:
        return False
    data = dict(d["data"]); data.update(updates)
    return _save(customer_id, bot_step_for(data), data, expect_step=d["step"])


def web_validate_text(key, value, required=False):
    """Validate one web text field with the web limits + the same content
    rules as the bot (no links/phones in name, no links in description)."""
    lo, hi = LIMITS_WEB[key]
    if not required:
        lo = 0
    val, err = _clean(value, lo, hi)
    if err:
        return None, err
    if key in ("name", "city", "area", "province", "tags", "whatsapp", "instagram",
               "telegram", "eitaa", "bale", "soroush", "rubika", "website") and "\n" in val:
        return None, "این فیلد باید تک‌خطی باشد."
    if key == "name" and (_URLISH.search(val) or _PHONEISH.search(val)):
        return None, "نام کسب‌وکار نباید شامل لینک یا شماره باشد."
    if key == "descr" and _URLISH.search(val):
        return None, "لینک در توضیح مجاز نیست؛ نشانی سایت را در مرحلهٔ «تماس» وارد کنید."
    if key == "website" and val and not re.fullmatch(r"https?://[^\s<>\"']{4,190}", val):
        return None, "نشانی سایت باید با http:// یا https:// شروع شود."
    if key in ("instagram", "telegram", "eitaa", "bale", "soroush", "rubika") and val:
        val = val.strip().lstrip("@")
        val = re.sub(r"^https?://(www\.)?(instagram\.com|t\.me|telegram\.me|eitaa\.com|ble\.ir|bale\.ai|splus\.ir|sapp\.ir|rubika\.ir)/", "", val, flags=re.I).strip("/")
        val = re.sub(r"^(joinchat/|c/)", "", val)
        if not re.fullmatch(r"[A-Za-z0-9_.]{2,64}", val):
            return None, "شناسهٔ شبکهٔ اجتماعی معتبر نیست (فقط حروف انگلیسی، عدد، _ و .)."
    if key == "whatsapp" and val:
        digits = re.sub(r"\D", "", val.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")))
        if not re.fullmatch(r"(98|0)?9\d{9}", digits):
            return None, "شمارهٔ واتساپ معتبر نیست."
        val = "98" + digits[-10:]
    return val, None


def web_validate_coord(lat, lng):
    """Optional map pin; both or neither, inside Iran's bounding box."""
    tr = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
    a = str(lat or "").translate(tr).replace("\u066b", ".").replace("\u060c", ".").replace(",", ".").strip()
    b = str(lng or "").translate(tr).replace("\u066b", ".").replace("\u060c", ".").replace(",", ".").strip()
    if not a and not b:
        return None, None, None
    try:
        fa_, fb = float(a), float(b)
    except ValueError:
        return None, None, "مختصات نقشه معتبر نیست."
    if not (24.0 <= fa_ <= 40.5 and 43.0 <= fb <= 64.0):
        return None, None, "مختصات خارج از محدودهٔ ایران است."
    return round(fa_, 6), round(fb, 6), None


def remove_image(customer_id, path):
    """Web: drop one attached image from the draft (and disk)."""
    import uploads
    d = get(customer_id)
    if not d:
        return False
    imgs = list(d["data"].get("images") or [])
    if path not in imgs:
        return False
    imgs.remove(path)
    if _save(customer_id, bot_step_for(dict(d["data"], images=imgs)), dict(d["data"], images=imgs),
             expect_step=d["step"]):
        uploads.delete_image(path)
        return True
    return False


# ------------------------------------------------------------------ categories
def search_categories(query, limit=6):
    """Active categories whose name/slug/blurb contains the normalised query.
    Empty query → top-level categories. Never returns inactive rows."""
    q = db.normalize_fa(str(query or "")).strip()[:60]
    flat = [dict(r) for r in db._rows(
        "SELECT slug,name,blurb,COALESCE(parent,'') parent FROM categories WHERE active=1 ORDER BY sort,id")]
    if not q:
        out = [r for r in flat if not r["parent"]][:limit]
    else:
        out = [r for r in flat if q in db.normalize_fa(r.get("name") or "")
               or q in (r.get("slug") or "").lower()
               or q in db.normalize_fa(r.get("blurb") or "")][:limit]
    return [{"slug": r["slug"], "name": r["name"], "parent": r.get("parent") or ""} for r in out]


def category_active(slug):
    if not re.fullmatch(r"[a-z0-9_-]{2,40}", str(slug or "")):
        return None
    r = db._one("SELECT slug,name FROM categories WHERE slug=? AND active=1", (slug,))
    return dict(r) if r else None


# ------------------------------------------------------------------ step inputs
def set_category(customer_id, slug):
    d = get(customer_id)
    if not d or d["step"] != "category":
        return False, "این مرحله فعال نیست."
    cat = category_active(slug)
    if not cat:
        return False, "دسته‌بندی معتبر نیست؛ دوباره انتخاب کنید."
    data = dict(d["data"], cat_slug=cat["slug"], cat_name=cat["name"])
    return _save(customer_id, bot_step_for(data), data, expect_step="category"), ""


def set_text(customer_id, value):
    """Consume a free-text answer for whichever text step is active."""
    d = get(customer_id)
    if not d:
        return False, "پیش‌نویسی فعال نیست."
    step = d["step"]
    if step not in LIMITS:
        return False, "در این مرحله ورودی متنی پذیرفته نمی‌شود."
    lo, hi = LIMITS[step]
    val, err = _clean(value, lo, hi)
    if err:
        return False, err
    if step in ("name", "city", "area") and "\n" in val:
        return False, "این فیلد باید تک‌خطی باشد."
    if step == "name" and (_URLISH.search(val) or _PHONEISH.search(val)):
        return False, "نام کسب‌وکار نباید شامل لینک یا شماره باشد."
    if step == "descr" and _URLISH.search(val):
        return False, "لینک در توضیح مجاز نیست؛ آدرس سایت را بعداً در سایت ثبت کنید."
    if step == "name":
        dups = db.find_duplicates(name=val)
        if any(x["strength"] == "exact" for x in dups):
            return False, "کسب‌وکاری با همین نام قبلاً ثبت شده است. نام دقیق‌تری وارد کنید (مثلاً با محله)."
    data = dict(d["data"]); data[step] = val
    return _save(customer_id, bot_step_for(data), data, expect_step=step), ""


def skip_optional(customer_id):
    d = get(customer_id)
    if not d or d["step"] not in ("area", "descr", "images"):
        return False
    data = dict(d["data"])
    data.setdefault(d["step"], "" if d["step"] != "images" else [])
    return _save(customer_id, bot_step_for(data), data, expect_step=d["step"])


def set_phone_public(customer_id, public):
    d = get(customer_id)
    if not d or d["step"] != "phone_public":
        return False
    data = dict(d["data"], phone_public=bool(public))
    return _save(customer_id, bot_step_for(data), data, expect_step="phone_public")


def set_hours(customer_id, preset):
    d = get(customer_id)
    if not d or d["step"] != "hours" or preset not in HOURS_PRESETS:
        return False
    data = dict(d["data"], hours=HOURS_PRESETS[preset][1], hours_label=HOURS_PRESETS[preset][0])
    return _save(customer_id, bot_step_for(data), data, expect_step="hours")


def add_image(customer_id, raw_bytes, cap=MAX_IMAGES, require_step=True):
    """Validate + store one image via uploads.save_image (magic bytes, ≤3MB,
    re-encoded).  Returns (ok, message, count).  The bot calls it only at the
    images step; the site wizard (random access) passes require_step=False
    and its own cap."""
    import uploads
    d = get(customer_id)
    if not d or (require_step and d["step"] != "images"):
        return False, "در این مرحله تصویر پذیرفته نمی‌شود.", 0
    imgs = list(d["data"].get("images") or [])
    if len(imgs) >= cap:
        return False, (f"حداکثر {cap} تصویر در بات مجاز است؛ بقیه را در سایت اضافه کنید." if require_step
                       else f"حداکثر {cap} تصویر در ثبت اولیه مجاز است؛ بقیه را بعداً از گالری اضافه کنید."), len(imgs)
    path, err = uploads.save_image(raw_bytes or b"", prefix="bizreg")
    if err:
        return False, err, len(imgs)
    imgs.append(path)
    data = dict(d["data"], images=imgs)
    ok = _save(customer_id, d["step"] if not require_step else "images", data,
               expect_step=d["step"] if not require_step else "images")
    if not ok:
        uploads.delete_image(path)
        return False, "ذخیره نشد؛ دوباره تلاش کنید.", len(imgs) - 1
    return True, "", len(imgs)


def finish_images(customer_id):
    d = get(customer_id)
    if not d or d["step"] != "images":
        return False
    data = dict(d["data"]); data.setdefault("images", [])
    return _save(customer_id, "preview", data, expect_step="images")


# ------------------------------------------------------------------ preview + submit
def is_complete(data):
    return all(data.get(k) for k in ("cat_slug", "name", "city", "address")) \
        and "phone_public" in data and "hours" in data


def preview_text(customer_id, masked_phone):
    d = get(customer_id)
    if not d or d["step"] != "preview":
        return ""
    x = d["data"]
    imgs = x.get("images") or []
    lines = ["📋 پیش‌نمایش ثبت کسب‌وکار",
             f"• دسته: {x.get('cat_name','—')}",
             f"• نام: {x.get('name','—')}",
             f"• شهر / محله: {x.get('city','—')}" + (f" / {x['area']}" if x.get("area") else ""),
             f"• نشانی: {x.get('address','—')}",
             f"• توضیح: {x.get('descr') or '—'}",
             f"• تلفن: {masked_phone} ({'نمایش عمومی' if x.get('phone_public') else 'فقط برای سایت و مدیر'})",
             f"• ساعات کاری: {x.get('hours_label','—')}",
             f"• تصاویر: {len(imgs)} عدد" + ("" if imgs else " (بعداً در سایت)"),
             *( [f"• سایر: " + " · ".join(v for v in (x.get("whatsapp") and "واتساپ", x.get("website"), x.get("instagram") and ("@" + x["instagram"]), x.get("telegram") and ("@" + x["telegram"]), x.get("eitaa") and ("ایتا @" + x["eitaa"]), x.get("bale") and ("بله @" + x["bale"]), x.get("soroush") and ("سروش @" + x["soroush"]), x.get("rubika") and ("روبیکا @" + x["rubika"])) if v)] if any(x.get(k) for k in ("whatsapp","website","instagram","telegram","eitaa","bale","soroush","rubika")) else [] ),
             "",
             "پس از تأیید، ثبت در انتظار بررسی مدیر قرار می‌گیرد و منتشر نمی‌شود تا تأیید شود."]
    return "\n".join(lines)


def prepare_confirm(customer_id):
    """Issue a one-use hash-only confirmation for the final submission."""
    d = get(customer_id)
    if not d or d["step"] != "preview" or not is_complete(d["data"]):
        return ""
    token = secrets.token_urlsafe(9)
    h = hashlib.sha256(token.encode()).hexdigest()
    db._run("DELETE FROM bot_confirmations WHERE expires<? OR used=1", (_now(),))
    db._run("DELETE FROM bot_confirmations WHERE customer_id=? AND action='biz_register'", (int(customer_id),))
    db._run("INSERT INTO bot_confirmations(token,customer_id,action,target_id,value,expires) "
            "VALUES(?,?,'biz_register',?,?,?)",
            (h, int(customer_id), int(d["id"]), "", _now() + CONFIRM_TTL))
    return token


def submit(customer_id, token, customer_phone):
    """Consume the confirmation and create the pending business atomically.
    Returns (business_id, error)."""
    if not customer_id or not re.fullmatch(r"[A-Za-z0-9_-]{8,24}", str(token or "")):
        return None, "تأیید نامعتبر است."
    phone = db.norm_phone(customer_phone or "")
    if len(phone) != 11:
        return None, "شمارهٔ حساب معتبر نیست."
    h = hashlib.sha256(str(token).encode()).hexdigest()
    con = db.connect()
    try:
        con.execute("BEGIN IMMEDIATE")
        claim = con.execute("SELECT target_id FROM bot_confirmations WHERE token=? AND customer_id=? "
                            "AND action='biz_register' AND used=0 AND expires>=?",
                            (h, int(customer_id), _now())).fetchone()
        if not claim:
            con.rollback(); return None, "تأیید منقضی یا استفاده‌شده است."
        row = con.execute("SELECT * FROM biz_reg_drafts WHERE id=? AND customer_id=? AND step='preview' AND expires>=?",
                          (int(claim["target_id"]), int(customer_id), _now())).fetchone()
        d = _load(row)
        if not d or not is_complete(d["data"]):
            con.rollback(); return None, "پیش‌نویس کامل یا فعال نیست."
        if con.execute("UPDATE bot_confirmations SET used=1 WHERE token=? AND used=0", (h,)).rowcount != 1:
            con.rollback(); return None, "تأیید تکراری است."
        # owner-bound: the owner row is the verified phone of THIS customer.
        o = con.execute("SELECT id,status FROM owners WHERE phone=?", (phone,)).fetchone()
        if o and o["status"] == "blocked":
            # Burn the token even though we refuse: a blocked owner must not
            # keep a live confirmation around to retry against.
            con.commit(); return None, "حساب مالک مسدود است."
        if not o:
            con.execute("INSERT INTO owners(phone) VALUES(?)", (phone,))
            o = con.execute("SELECT id,status FROM owners WHERE phone=?", (phone,)).fetchone()
        x = d["data"]
        base = db.slugify(x["name"], "biz")
        slug, i = base, 2
        while con.execute("SELECT 1 FROM businesses WHERE slug=?", (slug,)).fetchone():
            slug = f"{base}-{i}"; i += 1
        lat = x.get("lat") if isinstance(x.get("lat"), (int, float)) else None
        lng = x.get("lng") if isinstance(x.get("lng"), (int, float)) else None
        con.execute("INSERT INTO businesses(slug,name,cat_slug,descr,phone,address,area,city,province,hours,images,"
                    "status,owner_id,phone_public,tags,whatsapp,instagram,telegram,eitaa,bale,soroush,rubika,website,lat,lng) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,'pending',?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (slug, x["name"], x["cat_slug"], x.get("descr") or "", phone, x["address"],
                     x.get("area") or "", x["city"], x.get("province") or "",
                     json.dumps(x.get("hours") or {}, ensure_ascii=False),
                     json.dumps(x.get("images") or [], ensure_ascii=False), int(o["id"]),
                     1 if x.get("phone_public") else 0, str(x.get("tags") or "")[:200],
                     str(x.get("whatsapp") or "")[:20], str(x.get("instagram") or "")[:80],
                     str(x.get("telegram") or "")[:80], str(x.get("eitaa") or "")[:80], str(x.get("bale") or "")[:80],
                     str(x.get("soroush") or "")[:80], str(x.get("rubika") or "")[:80],
                     str(x.get("website") or "")[:200], lat, lng))
        bid = int(con.execute("SELECT last_insert_rowid() i").fetchone()["i"])
        con.execute("DELETE FROM biz_reg_drafts WHERE id=?", (int(d["id"]),))
        con.commit()
    except Exception:
        con.rollback(); return None, "ثبت انجام نشد؛ دوباره تلاش کنید."
    finally:
        con.close()
    db._pagecache_drop(); db._fts_mark_dirty()
    db.log("business.bot-submit", f"{bid} customer={int(customer_id)} platform={d.get('platform')}")
    return bid, ""
