# -*- coding: utf-8 -*-
"""Shared, account-aware bot menu for Bale and Soroush Plus."""
import re
import math
import urllib.parse
import db
import notifmeta
import bot_register_flow as REG

SITE = "https://daastgir.ir"
CALLBACK_PREFIX = "dg198:"
PLATFORM_LABEL = {"bale": "بله", "soroush": "سروش‌پلاس"}


def _buttons(linked, owner=False):
    rows = []
    if linked:
        rows.append([{"text": "📦 سفارش‌های من", "callback_data": CALLBACK_PREFIX + "orders"},
                     {"text": "📅 نوبت‌های من", "callback_data": CALLBACK_PREFIX + "bookings"}])
        rows.append([{"text": "🔔 اعلان‌ها", "callback_data": CALLBACK_PREFIX + "notifications"},
                     {"text": "📌 موجودشدن‌ها", "callback_data": CALLBACK_PREFIX + "stock"}])
        rows.append([{"text": "❤️ علاقه‌مندی‌ها", "callback_data": CALLBACK_PREFIX + "favorites"},
                     {"text": "🔍 جست‌وجو", "callback_data": CALLBACK_PREFIX + "search"}])
        rows.append([{"text": "📍 نزدیک من", "callback_data": CALLBACK_PREFIX + "near"}])
        rows.append([{"text": "💬 پیام‌های من", "callback_data": CALLBACK_PREFIX + "messages"},
                     {"text": "👤 حساب من", "callback_data": CALLBACK_PREFIX + "account"}])
        if owner:
            rows.append([{"text":"🏪 پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}])
        rows.append([{"text":"➕ ثبت کسب‌وکار","callback_data":CALLBACK_PREFIX+"reg_start"}])
    else:
        rows.append([{"text": "🔐 ورود یا ثبت‌نام", "url": SITE + "/login"}])
    rows.append([{"text": "❓ راهنما", "callback_data": CALLBACK_PREFIX + "help"},
                 {"text": "🌐 دست گیر", "url": SITE}])
    return {"inline_keyboard": rows}


def _back():
    return {"inline_keyboard": [[{"text": "🏠 منوی اصلی",
                                  "callback_data": CALLBACK_PREFIX + "menu"}],
                                [{"text": "🌐 مشاهده در دست گیر", "url": SITE + "/me"}]]}


def _account(platform, platform_user_id):
    acc = db.messenger_account_by_platform(platform, platform_user_id)
    if not acc or acc.get("customer_status") == "blocked":
        return None, None
    customer = db.customer_by_id(acc["customer_id"])
    return acc, customer


def _owner_account(platform,platform_user_id):
    _,customer=_account(platform,platform_user_id)
    if not customer:return None
    owner=db.owner_by_phone(customer.get("phone") or "",create=False)
    return owner if owner and owner.get("status")!="blocked" and db.owner_business_count(owner["id"]) else None


def _masked_phone(value):
    phone = db.norm_phone(value or "")
    return phone[:4] + "••••" + phone[-3:] if len(phone) == 11 else "ثبت نشده"


def send_menu(platform, platform_user_id, chat_id, send):
    acc, customer = _account(platform, platform_user_id)
    label = PLATFORM_LABEL.get(platform, "پیام‌رسان")
    if customer:
        name = (customer.get("name") or "کاربر دست گیر").strip()
        text = (f"سلام {name} 👋\n\nحساب {label} شما با موفقیت به دست گیر متصل است. "
                "از منوی امن زیر استفاده کنید.")
        return send(chat_id, text, _buttons(True,bool(_owner_account(platform,platform_user_id))))
    handoff = (" اگر با دکمهٔ سایت وارد این گفت‌وگو شده‌اید، کلید ورود از قبل "
               "کپی شده است؛ همین‌جا Paste و ارسالش کنید.") if platform == "soroush" else ""
    text = (f"به بات رسمی دست گیر در {label} خوش آمدید 👋\n\n"
            "برای مشاهدهٔ اطلاعات شخصی، ابتدا از سایت رسمی وارد یا ثبت‌نام شوید."
            + handoff + " بات هیچ‌گاه رمز، کد بانکی یا اطلاعات کارت درخواست نمی‌کند.")
    return send(chat_id, text, _buttons(False))


def send_account(platform, platform_user_id, chat_id, send):
    acc, customer = _account(platform, platform_user_id)
    if not customer:
        return send(chat_id, "این حساب پیام‌رسان هنوز به دست گیر متصل نیست.", _buttons(False))
    owner = db.owner_by_phone(customer.get("phone") or "", create=False)
    n_biz = db.owner_business_count(owner["id"]) if owner and owner.get("status") != "blocked" else 0
    label = PLATFORM_LABEL.get(platform, "پیام‌رسان")
    name = (customer.get("name") or "ثبت نشده").strip()
    text = ("👤 حساب من\n\n"
            f"نام: {name}\n"
            f"شماره: {_masked_phone(customer.get('phone'))}\n"
            f"پیام‌رسان متصل: {label}\n"
            f"کسب‌وکارهای تحت مدیریت: {n_biz}\n"
            "وضعیت حساب: فعال ✅")
    return send(chat_id, text, _back())


def _fa_int(value):
    return str(int(value or 0)).translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))


def _urlq(value):
    return urllib.parse.quote(str(value or "")[:60],safe="")


def _short(value, limit=64):
    return re.sub(r"[\r\n\t]+", " ", str(value or "")).strip()[:limit]


def send_orders(platform, platform_user_id, chat_id, send):
    _, customer = _account(platform, platform_user_id)
    if not customer:
        return send(chat_id, "برای مشاهدهٔ سفارش‌ها ابتدا حساب خود را متصل کنید.", _buttons(False))
    rows = db.customer_order_summaries(customer["id"], 5)
    if not rows:
        return send(chat_id, "📦 سفارش‌های من\n\nهنوز سفارشی ثبت نکرده‌اید.", _back())
    prices = db.get_settings().get("prices_enabled") == "1"
    lines = ["📦 آخرین سفارش‌های من", ""]
    buttons = []
    for row in rows:
        total = f" · {_fa_int(row['total'])} تومان" if prices else ""
        pend = " ⏳" if row.get("cancel_requested") else ""
        lines.append(f"#{_fa_int(row['id'])} · {_short(row['bizname'])}{pend}\n{row['status_label']}{total}")
        buttons.append([{"text": f"#{_fa_int(row['id'])} · {_short(row['bizname'], 36)}",
                         "callback_data": CALLBACK_PREFIX + f"order:{row['id']}"}])
    buttons.append([{"text": "📋 همهٔ سفارش‌ها در سایت", "url": SITE + "/me/orders"}])
    buttons.append([{"text": "🏠 منوی اصلی", "callback_data": CALLBACK_PREFIX + "menu"}])
    return send(chat_id, "\n\n".join(lines), {"inline_keyboard": buttons})


def send_order(platform, platform_user_id, chat_id, order_id, send):
    _, customer = _account(platform, platform_user_id)
    if not customer:
        return send(chat_id, "برای مشاهدهٔ سفارش ابتدا حساب خود را متصل کنید.", _buttons(False))
    row = db.customer_order_detail(customer["id"], order_id)
    if not row:
        return send(chat_id, "این سفارش پیدا نشد یا متعلق به حساب شما نیست.", _back())
    prices = db.get_settings().get("prices_enabled") == "1"
    items = []
    for item in row["items"][:20]:
        price = f" · {_fa_int(item['price'])} تومان" if prices else ""
        items.append(f"• {_short(item['title'], 80)} × {_fa_int(item['qty'])}{price}")
    if len(row["items"]) > 20:
        items.append("• ادامهٔ اقلام در سایت…")
    total = f"\nمجموع: {_fa_int(row['total'])} تومان" if prices else ""
    cancel_line = "\n⏳ درخواست لغو شما در انتظار بررسی کسب‌وکار است." if row.get("cancel_requested") else ""
    text = (f"📦 سفارش #{_fa_int(row['id'])}\n\n"
            f"کسب‌وکار: {_short(row['bizname'], 100)}\n"
            f"وضعیت: {row['status_label']}\n"
            f"زمان ثبت: {_short(row['created'], 19)}{total}{cancel_line}\n\n"
            "اقلام:\n" + ("\n".join(items) if items else "بدون قلم ثبت‌شده"))
    buttons = []
    if not row.get("cancel_requested") and row["status"] in ("new", "confirmed", "ready"):
        buttons.append([{"text": "❌ درخواست لغو سفارش", "callback_data": CALLBACK_PREFIX + f"order_cancel:{row['id']}"}])
    buttons.extend([
        [{"text": "🌐 مشاهدهٔ کامل سفارش", "url": SITE + f"/me/order/{row['id']}"}],
        [{"text": "↩️ بازگشت به سفارش‌ها", "callback_data": CALLBACK_PREFIX + "orders"}],
        [{"text": "🏠 منوی اصلی", "callback_data": CALLBACK_PREFIX + "menu"}],
    ])
    return send(chat_id, text[:4096], {"inline_keyboard": buttons})


def send_bookings(platform, platform_user_id, chat_id, send):
    _, customer = _account(platform, platform_user_id)
    if not customer:
        return send(chat_id, "برای مشاهدهٔ نوبت‌ها ابتدا حساب خود را متصل کنید.", _buttons(False))
    rows = db.customer_booking_summaries(customer["id"], 5)
    if not rows:
        return send(chat_id, "📅 نوبت‌های من\n\nهنوز نوبت متصل به حساب شما ثبت نشده است.", _back())
    lines=["📅 آخرین نوبت‌های من",""];buttons=[]
    for row in rows:
        lines.append(f"#{_fa_int(row['id'])} · {_short(row['bizname'])}\n{_short(row['date'],20)} · {_short(row['time'],12)} · {row['status_label']}")
        buttons.append([{"text":f"#{_fa_int(row['id'])} · {_short(row['bizname'],30)}",
                         "callback_data":CALLBACK_PREFIX+f"booking:{row['id']}"}])
    buttons.append([{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}])
    return send(chat_id,"\n\n".join(lines),{"inline_keyboard":buttons})


def send_booking(platform, platform_user_id, chat_id, booking_id, send):
    _, customer = _account(platform, platform_user_id)
    if not customer:
        return send(chat_id,"برای مشاهدهٔ نوبت ابتدا حساب خود را متصل کنید.",_buttons(False))
    row=db.customer_booking_detail(customer["id"],booking_id)
    if not row:
        return send(chat_id,"این نوبت پیدا نشد یا متعلق به حساب شما نیست.",_back())
    text=(f"📅 نوبت #{_fa_int(row['id'])}\n\nکسب‌وکار: {_short(row['bizname'],100)}\n"
          f"تاریخ: {_short(row['date'],20)}\nساعت: {_short(row['time'],12)}\n"
          f"وضعیت: {row['status_label']}")
    buttons=[[{"text":"🌐 مشاهدهٔ کسب‌وکار","url":SITE+f"/b/{row['bizslug']}"}]]
    if row["status"] in ("new","confirmed"):
        buttons.append([{"text":"لغو نوبت","callback_data":CALLBACK_PREFIX+f"booking_cancel:{row['id']}"}])
    buttons.extend([[{"text":"↩️ بازگشت به نوبت‌ها","callback_data":CALLBACK_PREFIX+"bookings"}],
                    [{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]])
    return send(chat_id,text,{"inline_keyboard":buttons})


def confirm_booking_cancel(platform, platform_user_id, chat_id, booking_id, send):
    _,customer=_account(platform,platform_user_id)
    if not customer or not db.customer_booking_detail(customer["id"],booking_id):
        return send(chat_id,"این نوبت پیدا نشد یا متعلق به حساب شما نیست.",_back())
    markup={"inline_keyboard":[
        [{"text":"✅ بله، نوبت لغو شود","callback_data":CALLBACK_PREFIX+f"booking_cancel_yes:{booking_id}"}],
        [{"text":"↩️ خیر، بازگشت","callback_data":CALLBACK_PREFIX+f"booking:{booking_id}"}]]}
    return send(chat_id,"آیا مطمئن هستید که می‌خواهید این نوبت را لغو کنید؟",markup)


def cancel_booking(platform, platform_user_id, chat_id, booking_id, send):
    _,customer=_account(platform,platform_user_id)
    if not customer:
        return send(chat_id,"حساب متصل پیدا نشد.",_buttons(False))
    result=db.customer_booking_cancel(customer["id"],booking_id)
    if result=="cancelled":
        return send(chat_id,"نوبت با موفقیت لغو شد و به کسب‌وکار اطلاع داده شد.",
                    {"inline_keyboard":[[{"text":"📅 نوبت‌های من","callback_data":CALLBACK_PREFIX+"bookings"}],
                                        [{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})
    if result=="final":
        return send(chat_id,"این نوبت قبلاً نهایی یا لغو شده و قابل لغو نیست.",_back())
    return send(chat_id,"این نوبت پیدا نشد یا متعلق به حساب شما نیست.",_back())


CANCEL_REASONS = ("پشیمان شدم", "زمان تحویل طولانی شد", "اشتباه ثبت کردم")


def send_order_cancel_reasons(platform, platform_user_id, chat_id, order_id, send):
    _, customer = _account(platform, platform_user_id)
    row = db.customer_order_detail(customer["id"], order_id) if customer else None
    if not row or row["status"] in ("done", "cancelled") or row.get("cancel_requested"):
        return send(chat_id, "این سفارش قابل لغو نیست (نهایی شده یا درخواست بازی دارد).", _back())
    keys = [[{"text": f"• {r}", "callback_data": CALLBACK_PREFIX + f"order_cancel_reason:{order_id}:{i}"}]
            for i, r in enumerate(CANCEL_REASONS)]
    keys.append([{"text": "↩️ بازگشت", "callback_data": CALLBACK_PREFIX + f"order:{order_id}"}])
    return send(chat_id, "❌ لغو سفارش\n\nدلیل لغو را انتخاب کنید:", {"inline_keyboard": keys})


def execute_order_cancel(platform, platform_user_id, chat_id, order_id, reason_idx, send):
    _, customer = _account(platform, platform_user_id)
    if not customer:
        return send(chat_id, "حساب متصل پیدا نشد.", _buttons(False))
    try:
        reason = CANCEL_REASONS[int(reason_idx)]
    except (TypeError, ValueError, IndexError):
        return send(chat_id, "دلیل نامعتبر است.", _back())
    res = db.request_order_cancel(order_id, customer["id"], reason)
    if not res.get("ok"):
        if res.get("error") == "final":
            return send(chat_id, "این سفارش نهایی شده و قابل لغو نیست.", _back())
        return send(chat_id, "این سفارش پیدا نشد یا متعلق به حساب شما نیست.", _back())
    if res.get("result") == "cancelled":
        text = "سفارش شما لغو شد و به کسب‌وکار اطلاع داده شد."
    else:
        text = (f"درخواست لغو ثبت شد و برای کسب‌وکار ارسال شد.\n"
                f"(لغو مستقیم فقط تا {res.get('limit', 30)} دقیقه پس از ثبت ممکن است.)")
    return send(chat_id, text, {"inline_keyboard": [
        [{"text": "📦 سفارش‌های من", "callback_data": CALLBACK_PREFIX + "orders"}],
        [{"text": "🏠 منوی اصلی", "callback_data": CALLBACK_PREFIX + "menu"}]]})


def execute_ai_confirm(platform, platform_user_id, chat_id, yes, send):
    """v226: ✅/❌ buttons under an assistant tool proposal. Behaves exactly
    like typing «بله»/«نه» — same free confirm path, same thread, same render."""
    import assistant
    _, customer = _account(platform, platform_user_id)
    key = f"cust:{customer['id']}" if customer else f"{platform}:{platform_user_id}"
    if not assistant.pending_get(key):
        rows = [[{"text": "🏠 منوی اصلی", "callback_data": CALLBACK_PREFIX + "menu"}]]
        return send(chat_id, "⏰ زمان تأیید گذشت یا چیزی در انتظار نیست؛ دوباره بخواهید.",
                    {"inline_keyboard": rows})
    owner = _owner_account(platform, platform_user_id) if customer else None
    ctx = {"channel": platform, "user_key": key, "customer": customer, "owner": owner}
    res = assistant.answer("بله" if yes else "نه", ctx)
    body, markup = assistant.bot_render(res, customer, CALLBACK_PREFIX)
    return send(chat_id, body, markup)


def edit_or_send(platform, chat_id, msg_id, text, markup, send):
    """v234: refresh a bot message in place; fall back to a new message."""
    if msg_id:
        t = _transport(platform)
        try:
            mid = int(msg_id)
        except (TypeError, ValueError):
            mid = 0
        if t and mid:
            try:
                if t.edit_message_text(chat_id, mid, text, markup):
                    return True
            except Exception:
                pass
    return send(chat_id, text, markup)


def _notif_text_markup(customer):
    kinds=notifmeta.kinds("cust");state=db.pref_state("cust",customer["id"],kinds)
    lines=["🔔 تنظیم اعلان‌ها","","با لمس هر گزینه، همان دسته روشن یا خاموش می‌شود:"]
    buttons=[]
    for kind in kinds:
        _,label,_=notifmeta.meta("cust",kind);on=state[kind]
        lines.append(f"{'✅' if on else '🔕'} {label}")
        buttons.append([{"text":f"{'✅' if on else '🔕'} {label}","callback_data":CALLBACK_PREFIX+f"notif:{kind}"}])
    buttons.append([{"text":"⚙️ تنظیمات کامل در سایت","url":SITE+"/me/notif-settings"}])
    buttons.append([{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}])
    return "\n".join(lines),{"inline_keyboard":buttons}


def send_notifications(platform,platform_user_id,chat_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:
        return send(chat_id,"برای مدیریت اعلان‌ها ابتدا حساب خود را متصل کنید.",_buttons(False))
    text,markup=_notif_text_markup(customer)
    return send(chat_id,text,markup)


def toggle_notification(platform,platform_user_id,chat_id,kind,send,msg_id=None):
    _,customer=_account(platform,platform_user_id)
    if not customer:
        return send(chat_id,"حساب متصل پیدا نشد.",_buttons(False))
    if kind not in notifmeta.kinds("cust"):
        return send(chat_id,"دستهٔ اعلان نامعتبر است.",_back())
    new_state=not db.kind_enabled("cust",customer["id"],kind)
    if not db.set_customer_pref(customer["id"],kind,new_state):
        return send(chat_id,"ذخیرهٔ تنظیم اعلان انجام نشد.",_back())
    text,markup=_notif_text_markup(customer)
    return edit_or_send(platform,chat_id,msg_id,text,markup,send)


_STOCK_LABELS={"open":"در انتظار موجودشدن","fulfilled":"موجود شد","dismissed":"لغو شده"}


def send_stock(platform,platform_user_id,chat_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:
        return send(chat_id,"برای مشاهدهٔ پیگیری موجودی ابتدا حساب خود را متصل کنید.",_buttons(False))
    rows=db.customer_stock_requests(customer["id"],10)
    if not rows:
        return send(chat_id,"📌 پیگیری موجودی\n\nهنوز درخواست «موجود شد خبرم کن» ندارید.",_back())
    lines=["📌 پیگیری‌های موجودی من",""];buttons=[]
    for row in rows:
        title=_short(row.get("item_title") or "درخواست عمومی",60)
        lines.append(f"#{_fa_int(row['id'])} · {title}\n{_short(row['biz_name'],50)} · {_STOCK_LABELS.get(row['status'],row['status'])} · {_fa_int(row['qty'])} عدد")
        if row["status"]=="open":
            buttons.append([{"text":f"لغو #{_fa_int(row['id'])} · {_short(title,28)}","callback_data":CALLBACK_PREFIX+f"stock_cancel:{row['id']}"}])
        link=(SITE+f"/item/{row['item_id']}") if row.get("item_id") else (SITE+f"/b/{row['biz_slug']}")
        buttons.append([{"text":f"مشاهده #{_fa_int(row['id'])} در سایت","url":link}])
    buttons.append([{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}])
    return send(chat_id,"\n\n".join(lines)[:4096],{"inline_keyboard":buttons})


def confirm_stock_cancel(platform,platform_user_id,chat_id,request_id,send):
    _,customer=_account(platform,platform_user_id)
    rows=db.customer_stock_requests(customer["id"],20) if customer else []
    row=next((x for x in rows if int(x["id"])==int(request_id) and x["status"]=="open"),None)
    if not row:
        return send(chat_id,"این درخواست پیدا نشد، نهایی شده یا متعلق به حساب شما نیست.",_back())
    markup={"inline_keyboard":[
        [{"text":"✅ بله، پیگیری لغو شود","callback_data":CALLBACK_PREFIX+f"stock_cancel_yes:{request_id}"}],
        [{"text":"↩️ خیر، بازگشت","callback_data":CALLBACK_PREFIX+"stock"}]]}
    return send(chat_id,"آیا پیگیری موجودشدن این مورد لغو شود؟",markup)


def cancel_stock(platform,platform_user_id,chat_id,request_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:return send(chat_id,"حساب متصل پیدا نشد.",_buttons(False))
    result=db.customer_stock_request_cancel(customer["id"],request_id)
    if result=="cancelled":return send(chat_id,"پیگیری موجودشدن لغو شد.",{"inline_keyboard":[[{"text":"📌 موجودشدن‌ها","callback_data":CALLBACK_PREFIX+"stock"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})
    return send(chat_id,"این درخواست پیدا نشد، نهایی شده یا متعلق به حساب شما نیست.",_back())


def _map_url(row):
    try:
        lat,lng=float(row.get("lat")),float(row.get("lng"))
        if not (math.isfinite(lat) and math.isfinite(lng) and -90<=lat<=90 and -180<=lng<=180):return ""
        return f"https://www.google.com/maps/dir/?api=1&destination={lat:.6f},{lng:.6f}"
    except (TypeError,ValueError):return ""


BOT_COMMANDS=[("start","منوی اصلی"),("search","جست‌وجوی کسب‌وکار"),("near","کسب‌وکارهای باز نزدیک من"),
              ("orders","سفارش‌های من"),("bookings","نوبت‌های من"),("register","ثبت کسب‌وکار"),("help","راهنما")]


def _transport(platform):
    try:return __import__(platform) if platform in PLATFORM_LABEL else None
    except Exception:return None


def typing(platform,chat_id):
    """v212: best-effort «در حال نوشتن…» before slower replies; never raises."""
    t=_transport(platform)
    try:return bool(t and t.send_chat_action(chat_id,"typing"))
    except Exception:return False


def register_commands():
    """v212: idempotent setMyCommands on every enabled transport (best-effort)."""
    out={}
    for platform in PLATFORM_LABEL:
        t=_transport(platform)
        try:out[platform]=bool(t and t.enabled() and t.set_my_commands(BOT_COMMANDS))
        except Exception:out[platform]=False
    return out


def _site_base():
    try:base=(db.get_settings().get("site_url") or "").strip().rstrip("/")
    except Exception:base=""
    return base if base.startswith("https://") else SITE


def _cover_url(biz):
    cover=str(biz.get("cover") or "").strip()
    if not cover:
        imgs=biz.get("images") or []
        cover=str(imgs[0]).strip() if imgs else ""
    if not cover:return ""
    if cover.startswith("https://"):return cover
    if cover.startswith("/assets/img/uploads/"):return _site_base()+cover
    return ""


def _stars(rating):
    try:r=float(rating or 0)
    except (TypeError,ValueError):r=0.0
    return f"⭐ {r:.1f}".translate(str.maketrans("0123456789.","۰۱۲۳۴۵۶۷۸۹٫")) if r>0 else "⭐ بدون امتیاز"


def _fa_km(km):
    try:km=float(km)
    except (TypeError,ValueError):return ""
    text=f"{int(round(km*1000))} متر" if km<1 else f"{km:.1f} کیلومتر"
    return text.translate(str.maketrans("0123456789.","۰۱۲۳۴۵۶۷۸۹٫"))


def card_caption(biz,distance_km=None):
    """Customer-safe text of a business card (name, category, rating, open state, distance, address)."""
    cat=db.category(biz.get("cat_slug") or "") or {}
    state=db.open_state(biz)
    open_line={"open":"🟢 باز","closing":"🟠 به‌زودی بسته می‌شود","closed":"🔴 بسته"}.get(state.get("state"),"⚪️ ساعت کاری ثبت نشده")
    if state.get("detail"):open_line+=f" · {state['detail']}"
    lines=[f"🏪 {_short(biz.get('name'),80)}"+(" ✅" if biz.get("verified") else "")]
    if cat.get("name"):lines.append(f"🏷 {_short(cat['name'],40)}")
    nr=biz.get("nrated") or 0
    lines.append(_stars(biz.get("rating"))+(f" ({_fa_int(nr)} نظر)" if nr else ""))
    lines.append(open_line)
    if distance_km is not None:lines.append(f"📏 {_fa_km(distance_km)} از شما")
    if biz.get("address"):lines.append(f"📍 {_short(biz.get('address'),120)}")
    return "\n".join(lines)[:1024]


def card_buttons(customer_id,biz):
    row=[{"text":"🌐 صفحه","url":_site_base()+f"/b/{biz['slug']}"}]
    map_url=_map_url(biz)
    if map_url:row.insert(0,{"text":"🗺 مسیر","url":map_url})
    phone_ok=biz.get("phone") and int(biz.get("phone_public") if biz.get("phone_public") is not None else 1)
    if phone_ok:row.insert(0,{"text":"📞 تماس","callback_data":CALLBACK_PREFIX+f"card_phone:{biz['id']}"})
    rows=[row]
    if customer_id and not db.fav_state(customer_id,biz["id"]):
        rows.append([{"text":"❤️ افزودن به علاقه‌مندی‌ها","callback_data":CALLBACK_PREFIX+f"fav_add:{biz['id']}"}])
    return {"inline_keyboard":rows}


def send_card(platform,chat_id,customer_id,biz,send,distance_km=None):
    """v212: photo card via documented sendPhoto (HTTPS URL); text fallback when
    there is no cover or the platform rejects the photo."""
    caption=card_caption(biz,distance_km);markup=card_buttons(customer_id,biz)
    cover=_cover_url(biz);t=_transport(platform)
    if cover and t:
        try:
            if t.send_photo(chat_id,cover,caption,markup):return True
        except Exception:pass
    return send(chat_id,caption,markup)


def send_cards(platform,chat_id,customer_id,rows,send,with_distance=False):
    sent=0
    for row in rows[:5]:
        biz=db.business(bid=row["id"])
        if not biz or biz.get("status")!="published":continue
        distance=row.get("distance_km") if with_distance else None
        if send_card(platform,chat_id,customer_id,biz,send,distance):sent+=1
    return sent


def send_card_phone(platform,platform_user_id,chat_id,biz_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:return send(chat_id,"حساب متصل پیدا نشد.",_buttons(False))
    biz=db.business(bid=biz_id)
    public=biz and biz.get("status")=="published" and biz.get("phone") and int(biz.get("phone_public") if biz.get("phone_public") is not None else 1)
    if not public:return send(chat_id,"شمارهٔ تماس این کسب‌وکار به‌صورت عمومی ثبت نشده است.",_back())
    try:db.track(biz["id"],"phone")
    except Exception:pass
    return send(chat_id,f"📞 {_short(biz['name'],60)}\n{db.norm_phone(biz['phone']) or _short(biz['phone'],20)}",
                {"inline_keyboard":[[{"text":"🌐 صفحهٔ کسب‌وکار","url":_site_base()+f"/b/{biz['slug']}"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


def send_near_help(chat_id,send):
    markup={"keyboard":[[{"text":"📍 ارسال موقعیت من","request_location":True}]],"resize_keyboard":True,"one_time_keyboard":True}
    return send(chat_id,"📍 نزدیک من\n\nبا دکمهٔ زیر موقعیت خود را بفرستید تا پنج کسب‌وکار بازِ نزدیک شما را با فاصله نشان دهم. "
                "موقعیت شما ذخیره نمی‌شود.",markup)


def handle_location(platform,platform_user_id,chat_id,lat,lng,send):
    """v212: location message → 5 nearest open businesses (≤5 km), distance-sorted."""
    _,customer=_account(platform,platform_user_id)
    cid=customer["id"] if customer else None  # v234: guests welcome (location is used once, never stored)
    if not _allowed(platform,platform_user_id,chat_id,send):return True
    try:
        lat,lng=float(lat),float(lng)
        if not (math.isfinite(lat) and math.isfinite(lng) and -90<=lat<=90 and -180<=lng<=180):raise ValueError
    except (TypeError,ValueError):
        return send(chat_id,"موقعیت دریافتی معتبر نبود؛ دوباره تلاش کنید.",{"remove_keyboard":True})
    typing(platform,chat_id)
    rows=db.nearby(lat,lng,radius_km=5.0,limit=60)
    now=db.iran_now()
    open_rows=[r for r in rows if db.is_open_now(r,now)]
    picked=open_rows[:5]
    if not rows:
        return send(chat_id,"در شعاع ۵ کیلومتری شما کسب‌وکاری ثبت نشده است.",{"remove_keyboard":True})
    head="📍 نزدیک‌ترین کسب‌وکارهای باز به شما:" if picked else "📍 در حال حاضر کسب‌وکار بازی نزدیک شما نیست؛ نزدیک‌ترین‌ها:"
    if not picked:picked=rows[:5]
    send(chat_id,head,{"remove_keyboard":True})
    send_cards(platform,chat_id,cid,picked,send,with_distance=True)
    return send(chat_id,f"{_fa_int(len(picked))} مورد نمایش داده شد.",{"inline_keyboard":[[{"text":"📍 موقعیت دیگر","callback_data":CALLBACK_PREFIX+"near"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


def send_search_help(chat_id,send):
    return send(chat_id,"🔍 جست‌وجوی کسب‌وکار\n\nنام، خدمت، کالا یا محله را بعد از /search بنویسید.\nمثال:\n/search تعمیر موبایل",{"inline_keyboard":[[{"text":"🌐 جست‌وجوی پیشرفته در سایت","url":SITE+"/businesses"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


def send_search(platform,platform_user_id,chat_id,query,send):
    # v234: search is public data (like the site) — guests get cards too,
    # only without the save-to-favorites button.
    _,customer=_account(platform,platform_user_id)
    cid=customer["id"] if customer else None
    query=_short(query,60)
    if len(db.normalize_fa(query))<2:return send_search_help(chat_id,send)
    typing(platform,chat_id)
    rows=db.search_business_summaries(query,5)
    if not rows:return send(chat_id,f"برای «{query}» نتیجه‌ای پیدا نشد.",{"inline_keyboard":[[{"text":"🔍 جست‌وجوی دیگر","callback_data":CALLBACK_PREFIX+"search"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})
    send(chat_id,f"🔍 نتیجهٔ جست‌وجوی «{query}» ({_fa_int(len(rows))} مورد)")
    send_cards(platform,chat_id,cid,rows,send)
    return send(chat_id,"برای نتایج بیشتر از سایت استفاده کنید.",{"inline_keyboard":[[{"text":"🌐 جست‌وجوی پیشرفته در سایت","url":_site_base()+"/businesses?q="+_urlq(query)}],[{"text":"🔍 جست‌وجوی دیگر","callback_data":CALLBACK_PREFIX+"search"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


def send_favorites(platform,platform_user_id,chat_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:return send(chat_id,"برای مشاهدهٔ علاقه‌مندی‌ها ابتدا حساب خود را متصل کنید.",_buttons(False))
    rows=db.favorite_summaries(customer["id"],5)
    if not rows:return send(chat_id,"❤️ علاقه‌مندی‌های من\n\nهنوز کسب‌وکاری ذخیره نکرده‌اید.",{"inline_keyboard":[[{"text":"🔍 جست‌وجو","callback_data":CALLBACK_PREFIX+"search"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})
    typing(platform,chat_id)
    send(chat_id,f"❤️ علاقه‌مندی‌های من ({_fa_int(len(rows))} مورد اخیر)")
    send_cards(platform,chat_id,customer["id"],rows,send)
    buttons=[[{"text":f"حذف {_short(row['name'],26)}","callback_data":CALLBACK_PREFIX+f"fav_remove:{row['id']}"}] for row in rows]
    buttons.append([{"text":"📋 همه در سایت","url":_site_base()+"/me/favorites"}])
    buttons.append([{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}])
    return send(chat_id,"برای حذف از فهرست، دکمهٔ مربوط را بزنید.",{"inline_keyboard":buttons})


def add_favorite(platform,platform_user_id,chat_id,biz_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:return send(chat_id,"حساب متصل پیدا نشد.",_buttons(False))
    if not db.favorite_add(customer["id"],biz_id):return send(chat_id,"کسب‌وکار منتشرشده پیدا نشد.",_back())
    return send(chat_id,"کسب‌وکار به علاقه‌مندی‌های شما اضافه شد.",{"inline_keyboard":[[{"text":"❤️ علاقه‌مندی‌ها","callback_data":CALLBACK_PREFIX+"favorites"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


def confirm_favorite_remove(platform,platform_user_id,chat_id,biz_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer or not db.fav_state(customer["id"],biz_id):return send(chat_id,"این علاقه‌مندی پیدا نشد یا متعلق به حساب شما نیست.",_back())
    return send(chat_id,"این کسب‌وکار از علاقه‌مندی‌ها حذف شود؟",{"inline_keyboard":[[{"text":"✅ بله، حذف شود","callback_data":CALLBACK_PREFIX+f"fav_remove_yes:{biz_id}"}],[{"text":"↩️ خیر، بازگشت","callback_data":CALLBACK_PREFIX+"favorites"}]]})


def remove_favorite(platform,platform_user_id,chat_id,biz_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer or not db.favorite_remove(customer["id"],biz_id):return send(chat_id,"این علاقه‌مندی پیدا نشد یا متعلق به حساب شما نیست.",_back())
    return send(chat_id,"کسب‌وکار از علاقه‌مندی‌های شما حذف شد.",{"inline_keyboard":[[{"text":"❤️ علاقه‌مندی‌ها","callback_data":CALLBACK_PREFIX+"favorites"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


CHAT_REPLIES={"thanks":"متشکرم، پیام شما را دریافت کردم.","contact":"لطفاً برای هماهنگی با من تماس بگیرید.","details":"لطفاً جزئیات بیشتری بفرستید."}


def send_messages(platform,platform_user_id,chat_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:return send(chat_id,"برای مشاهدهٔ پیام‌ها ابتدا حساب خود را متصل کنید.",_buttons(False))
    rows=db.customer_chat_summaries(customer["id"],5)
    if not rows:return send(chat_id,"💬 پیام‌های من\n\nهنوز گفتگویی ندارید.",{"inline_keyboard":[[{"text":"🌐 شروع گفتگو در سایت","url":SITE+"/businesses"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})
    lines=["💬 آخرین گفتگوهای من",""];buttons=[]
    for row in rows:
        last=row.get("last") or {};preview=_short(last.get("body"),70)
        if last.get("attachment_id"):preview=(preview+" · " if preview else "")+"📎 فایل"
        unread=f" · {_fa_int(row['unread'])} خوانده‌نشده" if row.get("unread") else ""
        lines.append(f"• {_short(row['bizname'],70)}{unread}\n{preview or 'بدون پیام'}")
        buttons.append([{"text":f"گفتگو با {_short(row['bizname'],28)}","callback_data":CALLBACK_PREFIX+f"chat:{row['id']}"}])
    buttons.append([{"text":"📋 همهٔ گفتگوها در سایت","url":SITE+"/me/chats"}]);buttons.append([{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}])
    return send(chat_id,"\n\n".join(lines)[:4096],{"inline_keyboard":buttons})


def send_chat(platform,platform_user_id,chat_id,thread_id,send):
    _,customer=_account(platform,platform_user_id)
    if not customer:return send(chat_id,"حساب متصل پیدا نشد.",_buttons(False))
    row=db.customer_chat_detail(customer["id"],thread_id,6)
    if not row:return send(chat_id,"این گفتگو پیدا نشد یا متعلق به حساب شما نیست.",_back())
    lines=[f"💬 گفتگو با {_short(row['bizname'],90)}",f"وضعیت: {'باز' if row['status']=='open' else 'بسته'}",""]
    has_file=False
    for message in row["messages"]:
        who="شما" if message["sender"]=="customer" else ("مدیر دست گیر" if message["sender"]=="admin" else "کسب‌وکار")
        body=_short(message.get("body"),240)
        if message.get("attachment_id"):
            has_file=True;body+=(" · " if body else "")+f"📎 {_short(message.get('file_name'),70)}"
        lines.append(f"{who}: {body or 'فایل'}")
    if has_file:lines.extend(["","برای مشاهده یا ارسال فایل، گفتگو را در سایت باز کنید."])
    buttons=[]
    if row["status"]=="open":
        buttons.extend([[{"text":"🙏 متشکرم","callback_data":CALLBACK_PREFIX+f"chat_reply:{thread_id}:thanks"},
                         {"text":"📞 لطفاً تماس بگیرید","callback_data":CALLBACK_PREFIX+f"chat_reply:{thread_id}:contact"}],
                        [{"text":"ℹ️ جزئیات بیشتر","callback_data":CALLBACK_PREFIX+f"chat_reply:{thread_id}:details"}]])
    buttons.extend([[{"text":"🌐 ادامه و ارسال فایل در سایت","url":SITE+f"/me/chat/{thread_id}"}],
                    [{"text":"↩️ بازگشت به پیام‌ها","callback_data":CALLBACK_PREFIX+"messages"}]])
    return send(chat_id,"\n".join(lines)[:4096],{"inline_keyboard":buttons})


def confirm_chat_reply(platform,platform_user_id,chat_id,thread_id,code,send):
    _,customer=_account(platform,platform_user_id);text=CHAT_REPLIES.get(code)
    token=db.customer_chat_reply_prepare(customer["id"],thread_id,text) if customer and text else ""
    if not token:return send(chat_id,"این گفتگو بسته است، پیدا نشد یا متعلق به حساب شما نیست.",_back())
    return send(chat_id,f"این پاسخ ارسال شود؟\n\n«{text}»",{"inline_keyboard":[[{"text":"✅ بله، ارسال شود","callback_data":CALLBACK_PREFIX+f"chat_reply_yes:{token}"}],[{"text":"↩️ خیر، بازگشت","callback_data":CALLBACK_PREFIX+f"chat:{thread_id}"}]]})


def send_chat_reply(platform,platform_user_id,chat_id,token,send):
    _,customer=_account(platform,platform_user_id)
    result=db.customer_chat_reply_confirmed(customer["id"],token) if customer else None
    if not result:return send(chat_id,"این تأیید منقضی یا قبلاً استفاده شده است، یا گفتگو دیگر باز نیست.",_back())
    thread_id=result["thread_id"]
    return send(chat_id,"پاسخ کوتاه شما ارسال شد.",{"inline_keyboard":[[{"text":"💬 بازگشت به گفتگو","callback_data":CALLBACK_PREFIX+f"chat:{thread_id}"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


def send_owner(platform,platform_user_id,chat_id,send):
    owner=_owner_account(platform,platform_user_id)
    if not owner:return send(chat_id,"پنل کسب‌وکار فقط برای مالک متصل و فعال در دسترس است.",_back())
    s=db.owner_bot_summary(owner["id"])
    text=("🏪 پنل کسب‌وکار\n\n"
          f"کسب‌وکارها: {_fa_int(s['businesses'])}\nسفارش جدید: {_fa_int(s['new_orders'])}\n"
          f"نوبت امروز: {_fa_int(s['today_bookings'])}\nگفتگوی خوانده‌نشده: {_fa_int(s['unread_chats'])}\n"
          f"درخواست موجودی باز: {_fa_int(s['open_stock'])}\n⏳ لغو در انتظار: {_fa_int(s['open_cancels'])}")
    keys=[[{"text":"📦 سفارش‌ها","callback_data":CALLBACK_PREFIX+"owner_orders"},{"text":"📅 نوبت امروز","callback_data":CALLBACK_PREFIX+"owner_bookings"}],
          [{"text":"💬 پیام مشتریان","callback_data":CALLBACK_PREFIX+"owner_messages"},{"text":"📌 موجودی","callback_data":CALLBACK_PREFIX+"owner_stock"}],
          [{"text":"⏳ لغوها","callback_data":CALLBACK_PREFIX+"owner_cancels"},{"text":"📊 آمار فروش","callback_data":CALLBACK_PREFIX+"owner_stats"}],
          [{"text":"🏪 کسب‌وکارها","callback_data":CALLBACK_PREFIX+"owner_biz"},{"text":"📣 فراخوان","callback_data":CALLBACK_PREFIX+"owner_broadcast"}],
          [{"text":"🌐 پنل کامل سایت","url":SITE+"/my"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]
    return send(chat_id,text,{"inline_keyboard":keys})


def send_owner_orders(platform,user,chat_id,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    rows=db.owner_order_summaries(owner["id"],5);lines=["📦 آخرین سفارش‌های کسب‌وکار",""];keys=[]
    for r in rows:
        lines.append(f"#{_fa_int(r['id'])} · {_short(r['bizname'],50)} · {_short(r['name'],40)}\n{r['status_label']}")
        keys.append([{"text":f"سفارش #{_fa_int(r['id'])}","callback_data":CALLBACK_PREFIX+f"owner_order:{r['id']}"}])
    if not rows:lines.append("سفارشی ثبت نشده است.")
    keys.extend([[{"text":"🌐 همه در سایت","url":SITE+"/my/orders"}],[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]])
    return send(chat_id,"\n\n".join(lines),{"inline_keyboard":keys})


def send_owner_order(platform,user,chat_id,order_id,send):
    owner=_owner_account(platform,user);r=db.owner_order_detail(owner["id"],order_id) if owner else None
    if not r:return send(chat_id,"سفارش پیدا نشد یا متعلق به کسب‌وکار شما نیست.",_back())
    items=[f"• {_short(x['title'],70)} × {_fa_int(x['qty'])}" for x in r["items"]]
    text=f"📦 سفارش #{_fa_int(r['id'])}\n\nکسب‌وکار: {_short(r['bizname'],80)}\nمشتری: {_short(r['name'],60)}\nوضعیت: {r['status_label']}\n\n"+"\n".join(items)
    nxt={"new":("confirmed","تأیید سفارش"),"confirmed":("ready","آمادهٔ تحویل"),"ready":("done","تحویل شد")}.get(r["status"]);keys=[]
    if nxt:keys.append([{"text":"✅ "+nxt[1],"callback_data":CALLBACK_PREFIX+f"owner_act:order_status:{order_id}:{nxt[0]}"}])
    keys.extend([[{"text":"🌐 پنل سفارش‌ها","url":SITE+"/my/orders"}],[{"text":"↩️ سفارش‌ها","callback_data":CALLBACK_PREFIX+"owner_orders"}]])
    return send(chat_id,text[:4096],{"inline_keyboard":keys})


def send_owner_bookings(platform,user,chat_id,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    rows=db.owner_today_bookings(owner["id"],8);lines=["📅 نوبت‌های امروز",""];keys=[]
    for r in rows:
        lines.append(f"#{_fa_int(r['id'])} · {_short(r['bizname'],45)} · {_short(r['name'],40)}\n{_short(r['time'],12)} · {r['status_label']}")
        nxt=("confirmed","تأیید نوبت") if r["status"]=="new" else (("done","انجام شد") if r["status"]=="confirmed" else None)
        if nxt:keys.append([{"text":f"#{_fa_int(r['id'])} · {nxt[1]}","callback_data":CALLBACK_PREFIX+f"owner_act:booking_status:{r['id']}:{nxt[0]}"}])
    if not rows:lines.append("برای امروز نوبت بازی ثبت نشده است.")
    keys.extend([[{"text":"🌐 همهٔ نوبت‌ها","url":SITE+"/my/bookings"}],[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]])
    return send(chat_id,"\n\n".join(lines),{"inline_keyboard":keys})


def send_owner_messages(platform,user,chat_id,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    rows=db.owner_chat_summaries(owner["id"],5);lines=["💬 پیام‌های مشتریان",""];keys=[]
    for r in rows:
        last=r.get("last") or {};preview=_short(last.get("body"),70) or ("📎 فایل" if last.get("attachment_id") else "بدون پیام")
        lines.append(f"• {_short(r.get('custname') or 'مشتری',45)} · {_short(r['bizname'],45)}\n{preview}")
        keys.append([{"text":f"گفتگو با {_short(r.get('custname') or 'مشتری',28)}","callback_data":CALLBACK_PREFIX+f"owner_chat:{r['id']}"}])
    if not rows:lines.append("گفتگویی ثبت نشده است.")
    keys.extend([[{"text":"🌐 صندوق کامل","url":SITE+"/my/chats"}],[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]])
    return send(chat_id,"\n\n".join(lines)[:4096],{"inline_keyboard":keys})


def send_owner_chat(platform,user,chat_id,thread_id,send):
    owner=_owner_account(platform,user);r=db.owner_chat_detail(owner["id"],thread_id,6) if owner else None
    if not r:return send(chat_id,"گفتگو پیدا نشد یا متعلق به کسب‌وکار شما نیست.",_back())
    lines=[f"💬 {_short(r.get('custname') or 'مشتری',60)} · {_short(r['bizname'],60)}",""]
    for m in r["messages"]:
        who="شما" if m["sender"]=="owner" else ("مدیر" if m["sender"]=="admin" else "مشتری");body=_short(m.get("body"),220)
        if m.get("attachment_id"):body+=(" · " if body else "")+"📎 "+_short(m.get("file_name"),60)
        lines.append(f"{who}: {body or 'فایل'}")
    keys=[]
    if r.get("status")=="open":
        keys.append([{"text":"👋 خوش‌آمد","callback_data":CALLBACK_PREFIX+f"owner_reply:{thread_id}:thanks"},
                     {"text":"⏳ آماده‌سازی","callback_data":CALLBACK_PREFIX+f"owner_reply:{thread_id}:busy"}])
        keys.append([{"text":"🌐 ارجاع به سایت","callback_data":CALLBACK_PREFIX+f"owner_reply:{thread_id}:site"}])
    keys.extend([[{"text":"🌐 پاسخ و فایل در سایت","url":SITE+f"/my/chat/{thread_id}"}],[{"text":"↩️ پیام مشتریان","callback_data":CALLBACK_PREFIX+"owner_messages"}]])
    return send(chat_id,"\n".join(lines)[:4096],{"inline_keyboard":keys})


def send_owner_stock(platform,user,chat_id,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    rows=db.stock_requests_open(owner["id"])[:8];lines=["📌 درخواست‌های موجودی باز",""];keys=[]
    for r in rows:
        lines.append(f"#{_fa_int(r['id'])} · {_short(r.get('item_title') or 'هر کالا',60)} · {_short(r['biz_name'],45)} · تعداد {_fa_int(r['qty'])}")
        keys.append([{"text":f"موجود شد · #{_fa_int(r['id'])}","callback_data":CALLBACK_PREFIX+f"owner_act:stock_fulfill:{r['id']}:yes"}])
    if not rows:lines.append("درخواست بازی وجود ندارد.")
    keys.extend([[{"text":"🌐 مدیریت کامل","url":SITE+"/my/broadcast"}],[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]])
    return send(chat_id,"\n\n".join(lines),{"inline_keyboard":keys})


def send_owner_broadcast(platform,user,chat_id,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    rows=[b for b in db.businesses_of(owner["id"]) if db.broadcast_allowed(b["id"])]
    keys=[[{"text":"📣 "+_short(b["name"],32),"callback_data":CALLBACK_PREFIX+f"owner_act:broadcast:{b['id']}:news"}] for b in rows[:8]]
    text="📣 فراخوان آماده\n\nبا تأیید دوم، یک خبر کوتاه استاندارد برای دنبال‌کنندگان کسب‌وکار ارسال می‌شود. متن سفارشی فقط در پنل سایت نوشته می‌شود."
    if not rows:text="📣 فراخوان\n\nهیچ کسب‌وکار واجد دسترسی فراخوان نیست."
    keys.extend([[{"text":"🌐 فراخوان سفارشی در سایت","url":SITE+"/my/broadcast"}],[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]])
    return send(chat_id,text,{"inline_keyboard":keys})


def confirm_owner_action(platform,user,chat_id,action,target,value,send):
    owner=_owner_account(platform,user);token=db.owner_bot_action_prepare(owner["id"],action,target,value) if owner else ""
    if not token:return send(chat_id,"این عملیات معتبر نیست، مجاز نیست یا وضعیت قبلاً تغییر کرده است.",_back())
    labels={"order_status":"تغییر وضعیت سفارش","booking_status":"تغییر وضعیت نوبت","stock_fulfill":"اعلام موجودشدن","broadcast":"ارسال فراخوان"}
    return send(chat_id,f"آیا «{labels.get(action,'عملیات')}» انجام شود؟",{"inline_keyboard":[[{"text":"✅ بله، انجام شود","callback_data":CALLBACK_PREFIX+f"owner_yes:{token}"}],[{"text":"↩️ خیر، بازگشت","callback_data":CALLBACK_PREFIX+"owner"}]]})


def execute_owner_action(platform,user,chat_id,token,send):
    owner=_owner_account(platform,user);result=db.owner_bot_action_confirm(owner["id"],token) if owner else None
    if not result:return send(chat_id,"این تأیید منقضی، استفاده‌شده یا نامعتبر است.",_back())
    if not result.get("ok"):return send(chat_id,"فراخوان به‌دلیل محدودیت نرخ یا دسترسی ارسال نشد.",_back())
    extra=f" و به {_fa_int(result.get('recipients',0))} دنبال‌کننده رسید" if result["action"]=="broadcast" else ""
    return send(chat_id,"عملیات با موفقیت انجام شد"+extra+".",{"inline_keyboard":[[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


OWNER_CHAT_REPLIES={"thanks":"سلام! چطور می‌توانم کمکتان کنم؟","busy":"سفارش شما در حال آماده‌سازی است؛ به‌زودی خبر می‌دهم.","site":"لطفاً جزئیات کامل را در سایت ببینید."}


def send_owner_cancels(platform,user,chat_id,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    rows=db.owner_cancel_requests(owner["id"],8)
    if not rows:return send(chat_id,"⏳ لغوهای در انتظار\n\nدرخواستی برای بررسی وجود ندارد.",{"inline_keyboard":[[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]]})
    lines=["⏳ لغوهای در انتظار",""];keys=[]
    for r in rows:
        lines.append(f"#{_fa_int(r['id'])} · {_short(r['bizname'],40)} · {_short(r['name'],30)}\n«{_short(r['cancel_reason'],60)}» · {_short(r['cancel_requested_at'],16)}")
        keys.append([{"text":f"#{_fa_int(r['id'])} · بررسی","callback_data":CALLBACK_PREFIX+f"owner_cancel:{r['id']}"}])
    keys.append([{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}])
    return send(chat_id,"\n\n".join(lines),{"inline_keyboard":keys})


def confirm_owner_cancel(platform,user,chat_id,order_id,send):
    owner=_owner_account(platform,user)
    rows=db.owner_cancel_requests(owner["id"],20) if owner else []
    row=next((x for x in rows if int(x["id"])==int(order_id)),None)
    if not row:return send(chat_id,"این درخواست پیدا نشد یا قبلاً بررسی شده است.",_back())
    return send(chat_id,f"⏳ لغو سفارش #{_fa_int(row['id'])}\n\nکسب‌وکار: {_short(row['bizname'],60)}\nمشتری: {_short(row['name'],40)}\nدلیل: {_short(row['cancel_reason'],200)}",
                {"inline_keyboard":[[{"text":"✅ تأیید لغو","callback_data":CALLBACK_PREFIX+f"owner_cancel_ok:{order_id}"}],
                                    [{"text":"❌ رد درخواست","callback_data":CALLBACK_PREFIX+f"owner_cancel_no:{order_id}"}],
                                    [{"text":"↩️ بازگشت","callback_data":CALLBACK_PREFIX+"owner_cancels"}]]})


def execute_owner_cancel(platform,user,chat_id,order_id,approve,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    if db.decide_order_cancel(order_id,owner["id"],approve=approve):
        text="سفارش لغو شد و به مشتری اطلاع داده شد." if approve else "درخواست رد شد؛ سفارش همچنان فعال است و به مشتری اطلاع داده شد."
    else:
        text="این درخواست پیدا نشد یا قبلاً بررسی شده است."
    return send(chat_id,text,{"inline_keyboard":[[{"text":"⏳ لغوها","callback_data":CALLBACK_PREFIX+"owner_cancels"}],[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]]})


def send_owner_stats(platform,user,chat_id,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    s=db.owner_sales_summary(owner["id"])
    prices=db.get_settings().get("prices_enabled")=="1"
    rev=f"{_fa_int(s['rev7'])} تومان" if prices else f"{_fa_int(s['rev7_count'])} سفارش"
    text=("📊 آمار فروش (۷ روز)\n\n"
          f"💰 فروش نهایی: {rev}\n"
          f"🛒 سفارش باز: {_fa_int(s['open_count'])}" + (f" ({_fa_int(s['open_value'])} تومان)" if prices else "") + "\n"
          f"📅 نوبت ۷ روز آینده: {_fa_int(s['bookings7'])}\n"
          f"⏳ لغو در انتظار: {_fa_int(s['cancel_pending'])}")
    return send(chat_id,text,{"inline_keyboard":[[{"text":"🌐 گزارش کامل در سایت","url":SITE+"/my"}],[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]]})


def send_owner_biz(platform,user,chat_id,send):
    owner=_owner_account(platform,user)
    if not owner:return send(chat_id,"دسترسی مالک تأیید نشد.",_back())
    rows=[b for b in db.businesses_of(owner["id"])]
    if not rows:return send(chat_id,"🏪 کسب‌وکارها\n\nکسب‌وکاری ثبت نشده است.",{"inline_keyboard":[[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]]})
    labels={"published":"🟢 منتشر","hidden":"⏸ مخفی","pending":"🟡 در بررسی","rejected":"🔴 رد شده"}
    lines=["🏪 کسب‌وکارهای من",""];keys=[]
    for b in rows[:8]:
        lines.append(f"• {_short(b['name'],50)} — {labels.get(b.get('status'),'؟')}")
        if b.get("status")=="published":
            keys.append([{"text":f"⏸ بستن موقت «{_short(b['name'],24)}»","callback_data":CALLBACK_PREFIX+f"owner_biz_toggle:{b['id']}"}])
        elif b.get("status")=="hidden":
            keys.append([{"text":f"▶️ باز کردن «{_short(b['name'],24)}»","callback_data":CALLBACK_PREFIX+f"owner_biz_toggle:{b['id']}"}])
    keys.append([{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}])
    return send(chat_id,"\n".join(lines),{"inline_keyboard":keys})


def confirm_owner_biz_toggle(platform,user,chat_id,biz_id,send):
    owner=_owner_account(platform,user)
    biz=next((b for b in (db.businesses_of(owner["id"]) if owner else []) if int(b["id"])==int(biz_id)),None)
    if not biz or biz.get("status") not in ("published","hidden"):
        return send(chat_id,"این کسب‌وکار در وضعیت قابل تغییر نیست.",_back())
    act="hide" if biz.get("status")=="published" else "show"
    verb="موقتاً بسته (از سایت مخفی) شود" if act=="hide" else "دوباره باز (منتشر) شود"
    return send(chat_id,f"«{_short(biz['name'],60)}» {verb}؟",
                {"inline_keyboard":[[{"text":"✅ بله","callback_data":CALLBACK_PREFIX+f"owner_biz_toggle_yes:{biz_id}:{act}"}],
                                    [{"text":"↩️ خیر","callback_data":CALLBACK_PREFIX+"owner_biz"}]]})


def execute_owner_biz_toggle(platform,user,chat_id,biz_id,act,send):
    owner=_owner_account(platform,user)
    ok,new_status=db.owner_biz_transition(owner["id"],biz_id,act) if (owner and act in ("hide","show")) else (False,None)
    if ok:
        text="کسب‌وکار موقتاً بسته شد." if new_status=="hidden" else "کسب‌وکار دوباره منتشر شد."
    else:
        text="تغییر انجام نشد (وضعیت عوض شده یا انتشار مجدد نیازمند تأیید مدیر است)."
    return send(chat_id,text,{"inline_keyboard":[[{"text":"🏪 کسب‌وکارها","callback_data":CALLBACK_PREFIX+"owner_biz"}],[{"text":"↩️ پنل کسب‌وکار","callback_data":CALLBACK_PREFIX+"owner"}]]})


def confirm_owner_reply(platform,user,chat_id,thread_id,code,send):
    owner=_owner_account(platform,user);text=OWNER_CHAT_REPLIES.get(code)
    token=db.owner_chat_reply_prepare(owner["id"],thread_id,text) if owner and text else ""
    if not token:return send(chat_id,"این گفتگو بسته است، پیدا نشد یا متعلق به کسب‌وکار شما نیست.",_back())
    return send(chat_id,f"این پاسخ ارسال شود؟\n\n«{text}»",{"inline_keyboard":[[{"text":"✅ بله، ارسال شود","callback_data":CALLBACK_PREFIX+f"owner_reply_yes:{token}"}],[{"text":"↩️ خیر، بازگشت","callback_data":CALLBACK_PREFIX+f"owner_chat:{thread_id}"}]]})


def send_owner_reply(platform,user,chat_id,token,send):
    owner=_owner_account(platform,user)
    result=db.owner_chat_reply_confirmed(owner["id"],token) if owner else None
    if not result:return send(chat_id,"این تأیید منقضی یا قبلاً استفاده شده است، یا گفتگو دیگر باز نیست.",_back())
    thread_id=result["thread_id"]
    return send(chat_id,"پاسخ شما ارسال شد.",{"inline_keyboard":[[{"text":"💬 بازگشت به گفتگو","callback_data":CALLBACK_PREFIX+f"owner_chat:{thread_id}"}],[{"text":"🏠 منوی اصلی","callback_data":CALLBACK_PREFIX+"menu"}]]})


def send_help(platform, platform_user_id, chat_id, send):
    linked = bool(_account(platform, platform_user_id)[1])
    text = ("❓ راهنمای بات دست گیر\n\n"
            "• /start یا /menu — نمایش منوی اصلی\n"
            "• /account — مشاهدهٔ خلاصهٔ امن حساب\n"
            "• /orders — پنج سفارش اخیر و جزئیات امن\n"
            "• /bookings — نوبت‌ها، وضعیت و لغو با تأیید دوم\n"
            "• /notifications — روشن/خاموش‌کردن دسته‌های اعلان\n"
            "• /stock — پیگیری‌های موجودشدن و لغو با تأیید دوم\n"
            "• /favorites — کسب‌وکارهای ذخیره‌شده\n"
            "• /search عبارت — کارت کسب‌وکارها با عکس، امتیاز، باز/بسته و مسیر\n"
            "• /near — ارسال موقعیت و دیدن پنج کسب‌وکار بازِ نزدیک با فاصله\n"
            "• /messages — خلاصهٔ گفتگو و پاسخ کوتاه دومرحله‌ای\n"
            "• /owner — پنل مالک: سفارش، لغو، آمار فروش، پیام، موجودی، فراخوان\n"
            "• /register_business — ثبت مرحله‌به‌مرحلهٔ کسب‌وکار جدید (بررسی مدیر پیش از انتشار)\n"
            "• /help — نمایش این راهنما\n"
            "• هر متن دیگر — «دستیار هوشمند دست گیر» (فقط دربارهٔ همین سایت؛ سهمیهٔ روزانه دارد)\n\n"
            "عملیات حساب فقط در گفت‌وگوی خصوصی انجام می‌شود. برای امنیت، درخواست‌هایی را "
            "که خودتان آغاز نکرده‌اید تأیید نکنید.")
    return send(chat_id, text, _back() if linked else _buttons(False))


def _allowed(platform, platform_user_id, chat_id, send):
    if db.rate_ok(f"bot-menu:{platform}:{platform_user_id}", limit=24,
                  window=60, always=True):
        return True
    send(chat_id, "درخواست‌های شما زیاد است؛ یک دقیقه بعد دوباره تلاش کنید.")
    return False


def handle_message(platform, platform_user_id, chat_id, text, send):
    """Handle only menu commands; return True when the message was consumed."""
    raw=str(text or "").strip()
    search_match=re.fullmatch(r"/search(?:@\w+)?(?:\s+(.+))?",raw,re.I)
    persian_search=re.fullmatch(r"جست(?:‌|\s*)وجو(?:\s+(.+))?",raw)
    if search_match or persian_search:
        if not _allowed(platform,platform_user_id,chat_id,send):return True
        query=(search_match or persian_search).group(1) or ""
        (send_search(platform,platform_user_id,chat_id,query,send) if query else send_search_help(chat_id,send))
        return True
    value = re.sub(r"@\w+", "", raw, count=1).lower()
    actions = {
        "menu": ("/start", "/menu", "منو", "🏠 منوی اصلی"),
        "near": ("/near", "نزدیک من", "📍 نزدیک من", "📍 ارسال موقعیت من"),
        "account": ("/account", "حساب", "حساب من", "👤 حساب من"),
        "orders": ("/orders", "سفارش", "سفارش‌ها", "سفارش‌های من", "📦 سفارش‌های من"),
        "bookings": ("/bookings", "نوبت", "نوبت‌ها", "نوبت‌های من", "📅 نوبت‌های من"),
        "notifications": ("/notifications", "اعلان", "اعلان‌ها", "🔔 اعلان‌ها"),
        "stock": ("/stock", "موجودشدن", "موجودشدن‌ها", "📌 موجودشدن‌ها"),
        "favorites": ("/favorites", "علاقه‌مندی", "علاقه‌مندی‌ها", "❤️ علاقه‌مندی‌ها"),
        "search": ("جست‌وجو", "🔍 جست‌وجو"),
        "messages": ("/messages", "پیام", "پیام‌ها", "پیام‌های من", "💬 پیام‌های من"),
        "owner": ("/owner", "پنل کسب‌وکار", "🏪 پنل کسب‌وکار"),
        "register": ("/register_business", "/register", "ثبت کسب‌وکار", "➕ ثبت کسب‌وکار"),
        "help": ("/help", "راهنما", "❓ راهنما"),
    }
    action = next((key for key, values in actions.items() if value in values), "")
    if not action:
        # v207: free text belongs to an active registration draft, if any.
        if REG.handle_text(platform, platform_user_id, chat_id, raw, send):
            return True
        # v213: otherwise the site-scoped assistant answers (rule-based first,
        # model only for ambiguous text; daily quota by subscription tier).
        if raw and not raw.startswith("/"):
            if not _allowed(platform, platform_user_id, chat_id, send):
                return True
            import assistant
            _, customer = _account(platform, platform_user_id)
            owner = _owner_account(platform, platform_user_id) if customer else None
            typing(platform, chat_id)
            return assistant.bot_reply(platform, platform_user_id, chat_id, raw, send,
                                       customer=customer, owner=owner, callback_prefix=CALLBACK_PREFIX)
        if not raw:
            # v234: sticker/voice/video/document — a gentle hint instead of a bare menu.
            _, cust = _account(platform, platform_user_id)
            linked = bool(cust)
            return send(chat_id, "پیام شما رسید 🙂\n\nفعلاً فقط متن پشتیبانی می‌شود؛ عکس هم فقط موقع «ثبت کسب‌وکار» لازم است.",
                        _buttons(linked, bool(linked and _owner_account(platform, platform_user_id))))
        return False
    if not _allowed(platform, platform_user_id, chat_id, send):
        return True
    if action in ("orders","bookings","messages","owner","notifications","stock"):typing(platform,chat_id)
    if action == "menu": send_menu(platform, platform_user_id, chat_id, send)
    elif action == "near": send_near_help(chat_id, send)
    elif action == "account": send_account(platform, platform_user_id, chat_id, send)
    elif action == "orders": send_orders(platform, platform_user_id, chat_id, send)
    elif action == "bookings": send_bookings(platform, platform_user_id, chat_id, send)
    elif action == "notifications": send_notifications(platform,platform_user_id,chat_id,send)
    elif action == "stock": send_stock(platform,platform_user_id,chat_id,send)
    elif action == "favorites": send_favorites(platform,platform_user_id,chat_id,send)
    elif action == "search": send_search_help(chat_id,send)
    elif action == "messages": send_messages(platform,platform_user_id,chat_id,send)
    elif action == "owner": send_owner(platform,platform_user_id,chat_id,send)
    elif action == "register": REG.start(platform,platform_user_id,chat_id,send)
    else: send_help(platform, platform_user_id, chat_id, send)
    return True


def handle_callback(platform, platform_user_id, chat_id, data, send, msg_id=None):
    """Handle namespaced menu callbacks; return True when consumed."""
    if not str(data or "").startswith(CALLBACK_PREFIX):
        return False
    action = str(data)[len(CALLBACK_PREFIX):]
    if REG.matches(action):
        return REG.handle_callback(platform, platform_user_id, chat_id, action, send)
    order_match = re.fullmatch(r"order:(\d{1,12})", action)
    booking_match = re.fullmatch(r"booking:(\d{1,12})", action)
    cancel_match = re.fullmatch(r"booking_cancel:(\d{1,12})", action)
    cancel_yes_match = re.fullmatch(r"booking_cancel_yes:(\d{1,12})", action)
    notif_match = re.fullmatch(r"notif:([a-z_]{2,24})", action)
    stock_cancel_match = re.fullmatch(r"stock_cancel:(\d{1,12})", action)
    stock_cancel_yes_match = re.fullmatch(r"stock_cancel_yes:(\d{1,12})", action)
    fav_add_match = re.fullmatch(r"fav_add:(\d{1,12})", action)
    card_phone_match = re.fullmatch(r"card_phone:(\d{1,12})", action)
    fav_remove_match = re.fullmatch(r"fav_remove:(\d{1,12})", action)
    fav_remove_yes_match = re.fullmatch(r"fav_remove_yes:(\d{1,12})", action)
    chat_match=re.fullmatch(r"chat:(\d{1,12})",action)
    chat_reply_match=re.fullmatch(r"chat_reply:(\d{1,12}):(thanks|contact|details)",action)
    chat_reply_yes_match=re.fullmatch(r"chat_reply_yes:([A-Za-z0-9_-]{8,24})",action)
    owner_order_match=re.fullmatch(r"owner_order:(\d{1,12})",action)
    owner_chat_match=re.fullmatch(r"owner_chat:(\d{1,12})",action)
    owner_action_match=re.fullmatch(r"owner_act:(order_status|booking_status|stock_fulfill|broadcast):(\d{1,12}):(confirmed|ready|done|yes|news)",action)
    owner_yes_match=re.fullmatch(r"owner_yes:([A-Za-z0-9_-]{8,24})",action)
    order_cancel_match=re.fullmatch(r"order_cancel:(\d{1,12})",action)
    order_cancel_reason_match=re.fullmatch(r"order_cancel_reason:(\d{1,12}):([0-2])",action)
    owner_cancel_match=re.fullmatch(r"owner_cancel:(\d{1,12})",action)
    owner_cancel_ok_match=re.fullmatch(r"owner_cancel_ok:(\d{1,12})",action)
    owner_cancel_no_match=re.fullmatch(r"owner_cancel_no:(\d{1,12})",action)
    owner_biz_toggle_match=re.fullmatch(r"owner_biz_toggle:(\d{1,12})",action)
    owner_biz_toggle_yes_match=re.fullmatch(r"owner_biz_toggle_yes:(\d{1,12}):(hide|show)",action)
    owner_reply_match=re.fullmatch(r"owner_reply:(\d{1,12}):(thanks|busy|site)",action)
    owner_reply_yes_match=re.fullmatch(r"owner_reply_yes:([A-Za-z0-9_-]{8,24})",action)
    owner_static=("owner","owner_orders","owner_bookings","owner_messages","owner_stock","owner_broadcast","owner_stats","owner_cancels","owner_biz")
    if (action not in ("menu", "account", "orders", "bookings", "notifications", "stock", "favorites", "search", "near", "messages", "help", "ai_yes", "ai_no")+owner_static
            and not any((order_match,booking_match,cancel_match,cancel_yes_match,
                         notif_match,stock_cancel_match,stock_cancel_yes_match,
                         fav_add_match,fav_remove_match,fav_remove_yes_match,card_phone_match,
                         chat_match,chat_reply_match,chat_reply_yes_match,
                         owner_order_match,owner_chat_match,owner_action_match,owner_yes_match,
                         order_cancel_match,order_cancel_reason_match,
                         owner_cancel_match,owner_cancel_ok_match,owner_cancel_no_match,
                         owner_biz_toggle_match,owner_biz_toggle_yes_match,
                         owner_reply_match,owner_reply_yes_match))):
        return False
    if not _allowed(platform, platform_user_id, chat_id, send):
        return True
    if action in ("orders","bookings","messages","notifications","stock")+owner_static or order_match or booking_match or owner_order_match or chat_match:typing(platform,chat_id)
    if action == "menu": send_menu(platform, platform_user_id, chat_id, send)
    elif action == "near": send_near_help(chat_id, send)
    elif card_phone_match: send_card_phone(platform,platform_user_id,chat_id,int(card_phone_match.group(1)),send)
    elif action == "account": send_account(platform, platform_user_id, chat_id, send)
    elif action == "orders": send_orders(platform, platform_user_id, chat_id, send)
    elif action == "bookings": send_bookings(platform, platform_user_id, chat_id, send)
    elif action == "notifications": send_notifications(platform,platform_user_id,chat_id,send)
    elif action == "stock": send_stock(platform,platform_user_id,chat_id,send)
    elif action == "favorites": send_favorites(platform,platform_user_id,chat_id,send)
    elif action == "search": send_search_help(chat_id,send)
    elif action == "messages": send_messages(platform,platform_user_id,chat_id,send)
    elif action == "owner":send_owner(platform,platform_user_id,chat_id,send)
    elif action == "owner_orders":send_owner_orders(platform,platform_user_id,chat_id,send)
    elif action == "owner_bookings":send_owner_bookings(platform,platform_user_id,chat_id,send)
    elif action == "owner_messages":send_owner_messages(platform,platform_user_id,chat_id,send)
    elif action == "owner_stock":send_owner_stock(platform,platform_user_id,chat_id,send)
    elif action == "owner_broadcast":send_owner_broadcast(platform,platform_user_id,chat_id,send)
    elif owner_order_match:send_owner_order(platform,platform_user_id,chat_id,int(owner_order_match.group(1)),send)
    elif owner_chat_match:send_owner_chat(platform,platform_user_id,chat_id,int(owner_chat_match.group(1)),send)
    elif owner_action_match:confirm_owner_action(platform,platform_user_id,chat_id,owner_action_match.group(1),int(owner_action_match.group(2)),owner_action_match.group(3),send)
    elif owner_yes_match:execute_owner_action(platform,platform_user_id,chat_id,owner_yes_match.group(1),send)
    elif order_cancel_match:send_order_cancel_reasons(platform,platform_user_id,chat_id,int(order_cancel_match.group(1)),send)
    elif order_cancel_reason_match:execute_order_cancel(platform,platform_user_id,chat_id,int(order_cancel_reason_match.group(1)),order_cancel_reason_match.group(2),send)
    elif action=="owner_cancels":send_owner_cancels(platform,platform_user_id,chat_id,send)
    elif owner_cancel_match:confirm_owner_cancel(platform,platform_user_id,chat_id,int(owner_cancel_match.group(1)),send)
    elif owner_cancel_ok_match:execute_owner_cancel(platform,platform_user_id,chat_id,int(owner_cancel_ok_match.group(1)),True,send)
    elif owner_cancel_no_match:execute_owner_cancel(platform,platform_user_id,chat_id,int(owner_cancel_no_match.group(1)),False,send)
    elif action=="owner_stats":send_owner_stats(platform,platform_user_id,chat_id,send)
    elif action=="owner_biz":send_owner_biz(platform,platform_user_id,chat_id,send)
    elif owner_biz_toggle_match:confirm_owner_biz_toggle(platform,platform_user_id,chat_id,int(owner_biz_toggle_match.group(1)),send)
    elif owner_biz_toggle_yes_match:execute_owner_biz_toggle(platform,platform_user_id,chat_id,int(owner_biz_toggle_yes_match.group(1)),owner_biz_toggle_yes_match.group(2),send)
    elif owner_reply_match:confirm_owner_reply(platform,platform_user_id,chat_id,int(owner_reply_match.group(1)),owner_reply_match.group(2),send)
    elif owner_reply_yes_match:send_owner_reply(platform,platform_user_id,chat_id,owner_reply_yes_match.group(1),send)
    elif order_match: send_order(platform, platform_user_id, chat_id, int(order_match.group(1)), send)
    elif booking_match: send_booking(platform, platform_user_id, chat_id, int(booking_match.group(1)), send)
    elif cancel_match: confirm_booking_cancel(platform, platform_user_id, chat_id, int(cancel_match.group(1)), send)
    elif cancel_yes_match: cancel_booking(platform, platform_user_id, chat_id, int(cancel_yes_match.group(1)), send)
    elif notif_match: toggle_notification(platform,platform_user_id,chat_id,notif_match.group(1),send,msg_id)
    elif stock_cancel_match: confirm_stock_cancel(platform,platform_user_id,chat_id,int(stock_cancel_match.group(1)),send)
    elif stock_cancel_yes_match: cancel_stock(platform,platform_user_id,chat_id,int(stock_cancel_yes_match.group(1)),send)
    elif fav_add_match: add_favorite(platform,platform_user_id,chat_id,int(fav_add_match.group(1)),send)
    elif fav_remove_match: confirm_favorite_remove(platform,platform_user_id,chat_id,int(fav_remove_match.group(1)),send)
    elif fav_remove_yes_match: remove_favorite(platform,platform_user_id,chat_id,int(fav_remove_yes_match.group(1)),send)
    elif chat_match:send_chat(platform,platform_user_id,chat_id,int(chat_match.group(1)),send)
    elif chat_reply_match:confirm_chat_reply(platform,platform_user_id,chat_id,int(chat_reply_match.group(1)),chat_reply_match.group(2),send)
    elif chat_reply_yes_match:send_chat_reply(platform,platform_user_id,chat_id,chat_reply_yes_match.group(1),send)
    elif action == "ai_yes": execute_ai_confirm(platform, platform_user_id, chat_id, True, send)
    elif action == "ai_no": execute_ai_confirm(platform, platform_user_id, chat_id, False, send)
    else: send_help(platform, platform_user_id, chat_id, send)
    return True


def handle_photo(platform, platform_user_id, chat_id, fetch_bytes, send):
    """v207: photo messages are only meaningful for an active registration draft."""
    return REG.handle_photo(platform, platform_user_id, chat_id, fetch_bytes, send)
