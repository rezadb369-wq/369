# -*- coding: utf-8 -*-
"""Official Soroush Plus Bot API transport for auth and notifications."""
import json, os, re, urllib.parse, urllib.request

API_ROOT = os.environ.get("SOROUSH_API_ROOT", "https://api.splus.ir/bot").rstrip("/")
FILE_ROOT = os.environ.get("SOROUSH_FILE_ROOT", "https://api.splus.ir/file/bot").rstrip("/")
BOT_USERNAME = os.environ.get("SOROUSH_BOT_USERNAME", "").strip().lstrip("@")
_username_cache = ""

def token(): return os.environ.get("SOROUSH_BOT_TOKEN", "").strip()
def webhook_secret(): return os.environ.get("SOROUSH_WEBHOOK_SECRET", "").strip()
def enabled(): return bool(token() and webhook_secret())

def _call(method, payload=None):
    if not token(): return {"ok":False,"description":"soroush disabled"}
    req=urllib.request.Request(f"{API_ROOT}{token()}/{method}",
        data=json.dumps(payload or {},ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type":"application/json","User-Agent":"Daastgir/212"},method="POST")
    try:
        with urllib.request.urlopen(req,timeout=8) as r:
            out=json.loads(r.read(262144).decode("utf-8","replace"))
            return out if isinstance(out,dict) else {"ok":False}
    except Exception: return {"ok":False}

def bot_username():
    global _username_cache
    username=BOT_USERNAME or _username_cache
    if not username:
        out=_call("getMe"); result=out.get("result") if isinstance(out.get("result"),dict) else {}
        username=str(result.get("username") or "").strip().lstrip("@")
        if username: _username_cache=username
    return username if re.fullmatch(r"[A-Za-z0-9_]{3,64}",username or "") else ""

def bot_link():
    username=bot_username()
    return f"https://splus.ir/{username}" if username else "https://splus.ir/botfather"

def app_link():
    """Documented-by-device Soroush resolver; contains no login request secret."""
    username=bot_username()
    return ("soroush://resolve?domain=" + urllib.parse.quote(username,safe="")) if username else ""

def send_start_instructions(chat_id):
    return send_message(chat_id,
        "بات دست گیر فعال شد ✅\n\n"
        "اگر با دکمهٔ سایت وارد این گفت‌وگو شده‌اید، کلید ورود از قبل کپی شده است؛ همین‌جا Paste و ارسالش کنید.\n\n"
        "اگر بات را مستقیم Start کرده‌اید:\n"
        "۱) به سایت daastgir.ir و صفحهٔ ورود برگردید.\n"
        "۲) «ادامه با سروش‌پلاس» را بزنید؛ کلید کپی و همین گفت‌وگو مستقیم باز می‌شود.\n"
        "۳) کلید را Paste و ارسال کنید.\n\n"
        "پس از تأیید، مرورگر بازمانده خودکار وارد می‌شود.")

def send_message(chat_id,text,reply_markup=None):
    data={"chat_id":chat_id,"text":str(text)[:4096]}
    if reply_markup:data["reply_markup"]=reply_markup
    return bool(_call("sendMessage",data).get("ok"))

def send_message_id(chat_id,text,reply_markup=None):
    """v212: sendMessage returning the platform message_id (or None)."""
    data={"chat_id":chat_id,"text":str(text)[:4096]}
    if reply_markup:data["reply_markup"]=reply_markup
    out=_call("sendMessage",data)
    result=out.get("result") if out.get("ok") and isinstance(out.get("result"),dict) else {}
    mid=result.get("message_id")
    return mid if isinstance(mid,int) else None

def send_photo(chat_id,photo_url,caption="",reply_markup=None):
    """v212: documented sendPhoto by HTTPS URL (≤10 MB, caption ≤1024)."""
    url=str(photo_url or "")
    if not url.startswith("https://"):return False
    data={"chat_id":chat_id,"photo":url,"caption":str(caption or "")[:1024]}
    if reply_markup:data["reply_markup"]=reply_markup
    return bool(_call("sendPhoto",data).get("ok"))

def send_chat_action(chat_id,action="typing"):
    """v212: sendChatAction is marked «به‌زودی» in the official Soroush docs;
    the call is best-effort and any failure is ignored by callers."""
    return bool(_call("sendChatAction",{"chat_id":chat_id,"action":str(action or "typing")[:24]}).get("ok"))

def edit_message_text(chat_id,message_id,text,reply_markup=None):
    """v212: documented editMessageText (only messages with inline keyboards)."""
    if not isinstance(message_id,int):return False
    data={"chat_id":chat_id,"message_id":message_id,"text":str(text)[:4096]}
    if reply_markup:data["reply_markup"]=reply_markup
    return bool(_call("editMessageText",data).get("ok"))

def set_my_commands(commands):
    """v212: documented setMyCommands {commands ≤100} (default scope)."""
    cmds=[{"command":str(c)[:32],"description":str(d)[:256]} for c,d in commands][:100]
    return bool(_call("setMyCommands",{"commands":cmds}).get("ok"))

def request_signup_contact(chat_id):
    markup={"keyboard":[[{"text":"ارسال شمارهٔ خودم","request_contact":True}]],
            "resize_keyboard":True,"one_time_keyboard":True}
    return send_message(chat_id,
        "برای ثبت‌نام امن، شمارهٔ همین حساب سروش‌پلاس را با دکمهٔ رسمی زیر ارسال کنید. شمارهٔ تایپی یا مخاطب شخص دیگر پذیرفته نمی‌شود.",markup)

def send_approval(chat_id,challenge_token,purpose="login"):
    action="اتصال حساب سروش‌پلاس" if purpose=="link" else "ورود به دست گیر"
    markup={"inline_keyboard":[[{"text":"✅ تأیید "+action,
        "callback_data":f"sp193:{purpose}:{challenge_token}"}],
        [{"text":"❌ لغو","callback_data":f"sp193:cancel:{challenge_token}"}]]}
    return send_message(chat_id,
        f"درخواست {action}\n\nاگر این درخواست متعلق به شماست، تأیید کنید. اعتبار درخواست پنج دقیقه است.",markup)

def send_signup_approval(chat_id,approval_token):
    markup={"inline_keyboard":[[{"text":"✅ تأیید ثبت‌نام و ورود",
        "callback_data":f"sp193:signup:{approval_token}"}],
        [{"text":"❌ لغو","callback_data":f"sp193:signup_cancel:{approval_token}"}]]}
    return send_message(chat_id,
        "شمارهٔ خودتان تأیید شد. اکنون ساخت/اتصال حساب دست گیر و ورود را جداگانه تأیید کنید.",markup)

def remove_keyboard(chat_id,text):
    return send_message(chat_id,text,{"remove_keyboard":True})

def answer_callback(callback_id,text,alert=False):
    return bool(_call("answerCallbackQuery",{"callback_query_id":callback_id,
        "text":str(text)[:200],"show_alert":bool(alert)}).get("ok"))

def send_notification(chat_id,text,url=""):
    markup={"inline_keyboard":[[{"text":"مشاهده در دست گیر","url":url}]]} if url else None
    return send_message(chat_id,"🔔 دست گیر\n\n"+str(text)[:3500],markup)


def download_file(file_id, max_bytes=3*1024*1024+1):
    """v207: getFile → bounded download (official: /file/bot<token>/<file_path>)."""
    if not re.fullmatch(r"[A-Za-z0-9_\-:.]{8,200}", str(file_id or "")): return b""
    info=_call("getFile",{"file_id":file_id})
    path=((info.get("result") or {}).get("file_path") or "") if info.get("ok") else ""
    if not path or ".." in path or path.startswith("/"): return b""
    try:
        with urllib.request.urlopen(f"{FILE_ROOT}{token()}/{path}",timeout=15) as r: return r.read(max_bytes)
    except Exception: return b""
