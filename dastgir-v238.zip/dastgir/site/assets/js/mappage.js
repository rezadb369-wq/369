/* Map wiring: detail page, city map, and the owner's location picker. */
import { mountMap } from './map.js?v216';

const iconBg = (name, size) => {
  const aliases = { store:'business', shopping:'supermarket', briefcase:'business',
    camera:'photography', map:'attraction', compass:'attraction', pin:'attraction', mosque:'attraction' };
  const safe = /^[A-Za-z0-9_-]+$/.test(name || '') ? name : 'business';
  const picked = aliases[safe] || safe;
  return `width:${size}px;height:${size}px;` +
         `background-image:url(/assets/img/cats/${encodeURIComponent(picked)}.webp);` +
         'background-size:cover;background-position:center;';
};

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const HEART_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20s-7.5-4.7-7.5-9.6A4.4 4.4 0 0 1 12 7.4a4.4 4.4 0 0 1 7.5 3c0 4.9-7.5 9.6-7.5 9.6Z"/></svg>';

async function boot() {
  const el = $('[data-map-canvas]');
  if (!el) return;
  // v143: live.js swaps <main> on public pages (/b/...) without a reload.
  // The old mounted map died with the old node; this guard makes boot()
  // safe to re-run on the fresh canvas after the bz:content-updated event.
  if (el.dataset.mapMounted === '1') return;

  const multi = el.hasAttribute('data-multi');
  const pick  = el.hasAttribute('data-pick');
  const lat = parseFloat(el.dataset.lat || '') || undefined;
  const lng = parseFloat(el.dataset.lng || '') || undefined;

  const api = await mountMap(el, { lat, lng, zoom: pick ? 16 : undefined });
  if (!api) return;
  el.dataset.mapMounted = '1';

  /* ---------- city map: every business ---------- */
  if (multi) {
    let data = [];
    try { data = JSON.parse($('#map-data')?.textContent || '[]'); } catch (e) {}
    const byslug = new Map();
    data.forEach(b => {
      const m = api.addMarker({
        lat: b.lat, lng: b.lng, title: b.name, featured: b.featured,
        // the shop's own category icon, so the selected pin becomes the
        // thing it represents rather than a generic dot
        icon: b.icon || '',
        // v118: NO Leaflet popup — picking a pin opens the one, richer
        // .map-selected card below. Two floating info panels (popup + card)
        // overlapped the map and said the same thing twice.
      });
      byslug.set(b.slug, { marker: m, ...b });
    });
    api.fitAll();

    // Selection is shared between the list and the map: picking either one
    // highlights the marker, names it, and marks the list row — so you can
    // always tell which business you are looking at.
    const nameOut = $('[data-map-selected]');
    const setSelected = (slug, { center = true } = {}) => {
      const rec = byslug.get(slug);
      if (!rec) return;
      if (api.select) api.select(rec.marker);
      if (center) api.setCenter(rec.lat, rec.lng, 17);

      $$('.map-item').forEach(el => {
        const on = el.dataset.focus === slug;
        el.classList.toggle('is-selected', on);
        el.setAttribute('aria-current', on ? 'true' : 'false');
      });

      if (nameOut) {
        // The whole business, not just its name. Picking a pin on a map is
        // a question ("what is this place?") and answering with a bare
        // label makes the person open the page just to find the phone
        // number. Everything needed to decide is already in the payload.
        const esc = t => String(t == null ? '' : t)
          .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        const OPEN_CLS = { open: 'badge-open', closing: 'badge-warn',
                           closed: 'badge-closed', unknown: 'badge-neutral' };
        const stars = n => {
          const full = Math.round(n);
          return '★'.repeat(full) + '☆'.repeat(Math.max(0, 5 - full));
        };
        const faNum = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[+d]);

        let head = `<div class="ms-head">
            <span class="ic" style="${iconBg('store', 46)}"></span>
            <div class="ms-title">
              <strong>${esc(rec.name)}</strong>
              <div class="ms-sub">${esc(rec.catname || '')}</div>
            </div>
            <span class="badge ${OPEN_CLS[rec.open] || 'badge-neutral'}"
                  title="${esc(rec.opendetail || '')}">${esc(rec.openlabel || '')}</span>
          </div>`;

        let meta = '<div class="ms-meta">';
        if (rec.nreviews)
          meta += `<span class="ms-stars">${stars(rec.rating)}
                   <b class="nums">${faNum(rec.rating)}</b>
                   <small>(${faNum(rec.nreviews)} نظر)</small></span>`;
        if (rec.verified)
          meta += `<span class="badge badge-info">تأییدشده</span>`;
        if (rec.featured)
          meta += `<span class="badge badge-featured">ویژه</span>`;
        meta += '</div>';

        // ADDRESS FIRST, then a one-line description. The address is the single
        // thing a person looking at a map pin needs; v11 printed the description
        // above it, and on a phone the address slid below the sheet's cap and
        // vanished. (See .ms-descr / .ms-row in mobile-refine.css.)
        const body = (rec.address ? `<div class="ms-row">${esc(rec.address)}</div>` : '') +
          (rec.descr ? `<p class="ms-descr">${esc(rec.descr)}</p>` : '');

        // the actions a person actually wants at this moment
        let acts = '<div class="ms-acts">';
        acts += `<a class="btn btn-primary btn-sm" href="/b/${esc(rec.slug)}">صفحهٔ کامل</a>`;
        if (rec.phone)
          acts += `<a class="btn btn-accent btn-sm" href="tel:${esc(rec.phone)}">تماس</a>`;
        acts += `<a class="btn btn-glass btn-sm" target="_blank" rel="noopener"
                 href="https://www.google.com/maps/dir/?api=1&destination=${rec.lat},${rec.lng}">مسیر</a>`;
        acts += `<button class="btn btn-glass btn-sm favorite-action" type="button"
                 data-fav="${esc(rec.slug)}" data-fav-name="${esc(rec.name)}"
                 aria-pressed="false" aria-label="علاقه‌مندی: ${esc(rec.name)}">
                 ${HEART_ICON}<span data-fav-label>علاقه‌مندی</span></button>`;
        acts += '</div>';

        nameOut.hidden = false;
        nameOut.innerHTML = head + meta + body + acts;
        window.BazarcheFavorites?.paint();
        // v109: the stage knows the sheet is open — legend / «نزدیک من» step
        // aside via CSS instead of being buried under the card.
        const stage = nameOut.closest('[data-map-wrap]');
        if (stage) stage.classList.add('has-card');
        // On a phone the card is a bottom sheet covering part of the map, so
        // there has to be a way out of it that is not "pick something else".
        const close = document.createElement('button');
        close.type = 'button';
        close.className = 'ms-close';
        close.setAttribute('aria-label', 'بستن کارت');
        close.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"'
          + ' stroke-width="2.2" stroke-linecap="round" aria-hidden="true">'
          + '<path d="M18 6 6 18M6 6l12 12"/></svg>';
        close.addEventListener('click', () => {
          nameOut.hidden = true;
          if (stage) stage.classList.remove('has-card');
          $$('.map-item').forEach(el => {
            el.classList.remove('is-selected');
            el.setAttribute('aria-current', 'false');
          });
        });
        nameOut.appendChild(close);
      }
    };

    // clicking the pin itself should select it too
    byslug.forEach((rec, slug) => {
      const m = rec.marker;
      if (!m) return;
      if (api.kind === 'google') {
        m.addListener('click', () => setSelected(slug, { center: false }));
      } else if (m.on) {
        m.on('click', () => setSelected(slug, { center: false }));
      }
    });

    /* ---------------- search + sort + filter (v65) ---------------- */
    const hav = (lat1, lon1, lat2, lon2) => {
      const R = 6371, toR = d => d * Math.PI / 180;
      const dLat = toR(lat2 - lat1), dLon = toR(lon2 - lon1);
      const a = Math.sin(dLat/2)**2 + Math.cos(toR(lat1))*Math.cos(toR(lat2))*Math.sin(dLon/2)**2;
      return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    };

    const searchInput = $('[data-map-search]');
    const suggBox = $('[data-map-sugg]');
    const catSelect = $('[data-map-cat]');
    const countEl = $('[data-map-count]');
    const geoStatus = $('[data-map-geo-status]');
    const listEl = $('[data-map-list]');
    const rows = $$('[data-map-item]');

    let userPos = null;        // {lat, lng} once geolocation is granted
    let geoAsked = false;
    let query = '';
    let sortKey = 'default';
    let catFilter = '';

    const faNum = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[+d]);

    // Location permission is requested the moment the visitor STARTS searching,
    // so "nearest" works without a second tap (and we never nag repeatedly).
    const requestGeo = (then) => {
      if (userPos) { then && then(); return; }
      if (geoAsked) return;
      if (!navigator.geolocation) { return; }
      geoAsked = true;
      if (geoStatus) geoStatus.textContent = 'در حال گرفتن موقعیت…';
      const loc = window.Bazarche?.locatePrecise
        ? window.Bazarche.locatePrecise({ good: 30, max: 8000 })
        : new Promise((ok, no) => navigator.geolocation.getCurrentPosition(p => ok({ lat: p.coords.latitude, lng: p.coords.longitude }), no, { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }));
      loc.then((p) => {
        userPos = { lat: p.lat, lng: p.lng };
        if (geoStatus) geoStatus.textContent = 'موقعیت شما فعال شد — نزدیک‌ترین‌ها اول';
        then && then();
      }).catch(() => {
        if (geoStatus) geoStatus.textContent = 'بدون موقعیت، نتایج به ترتیب پیش‌فرض';
      });
    };
    // ask for location as soon as the person starts typing
    searchInput?.addEventListener('focus', () => requestGeo(() => {
      if (sortKey === 'nearest') applyAll();
    }));

    const byRec = (slug) => byslug.get(slug);

    const applyAll = () => {
      // 1. filter records by category + query
      let recs = data.filter(b => {
        if (catFilter && b.cat !== catFilter) return false;
        if (query) {
          const hay = `${b.name} ${b.address || ''} ${b.catname || ''} ${b.descr || ''}`.toLowerCase();
          if (!hay.includes(query)) return false;
        }
        return true;
      });
      // 2. sort
      if (sortKey === 'nearest' && userPos) {
        recs = recs.slice().sort((a, b) =>
          hav(userPos.lat, userPos.lng, a.lat, a.lng) - hav(userPos.lat, userPos.lng, b.lat, b.lng));
      } else if (sortKey === 'rating') {
        recs = recs.slice().sort((a, b) => (b.rating || 0) - (a.rating || 0));
      } else if (sortKey === 'open') {
        recs = recs.slice().sort((a, b) => (a.open === 'open' ? 0 : 1) - (b.open === 'open' ? 0 : 1));
      }
      // 3. reorder the DOM list to match
      const slugset = new Set(recs.map(r => r.slug));
      const ordered = [];
      rows.forEach(row => {
        const on = slugset.has(row.dataset.focus);
        row.hidden = !on;
        if (on) ordered.push(row);
      });
      ordered.sort((a, b) => {
        const i = recs.findIndex(r => r.slug === a.dataset.focus);
        const j = recs.findIndex(r => r.slug === b.dataset.focus);
        return i - j;
      });
      ordered.forEach(row => listEl.appendChild(row));
      // 4. distance labels when we know the position
      if (userPos) {
        ordered.forEach(row => {
          const rec = byRec(row.dataset.focus);
          if (!rec) return;
          const km = hav(userPos.lat, userPos.lng, rec.lat, rec.lng);
          let tag = row.querySelector('.map-item-dist');
          if (!tag) {
            tag = document.createElement('span');
            tag.className = 'map-item-dist';
            row.appendChild(tag);
          }
          tag.textContent = km < 1 ? Math.round(km*1000) + ' متر' : km.toFixed(1) + ' کیلومتر';
        });
      }
      if (countEl) countEl.textContent = faNum(recs.length);
      if (!recs.length) {
        if (listEl && !$('.map-empty', listEl)) {
          const d = document.createElement('p');
          d.className = 'map-empty text-sm text-muted';
          d.style.padding = '12px';
          d.textContent = 'با این فیلترها نتیجه‌ای پیدا نشد.';
          listEl.appendChild(d);
        }
      } else {
        $('.map-empty', listEl)?.remove();
      }
    };

    // ---- live suggestions (inline, no new page) ----
    const esc = t => String(t == null ? '' : t)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const hideSugg = () => { if (suggBox) suggBox.hidden = true; };
    const renderSugg = (list) => {
      if (!suggBox) return;
      suggBox.textContent = '';
      if (!list.length) {
        const d = document.createElement('div');
        d.className = 'sugg-empty';
        d.textContent = 'موردی پیدا نشد.';
        suggBox.appendChild(d);
        suggBox.hidden = false;
        return;
      }
      list.forEach(r => {
        const btn = document.createElement('button');
        btn.type = 'button';
        const main = document.createElement('span');
        main.className = 'sugg-main';
        const nm = document.createElement('span');
        nm.className = 'sugg-name'; nm.textContent = r.name;
        const sub = document.createElement('span');
        sub.className = 'sugg-sub';
        sub.textContent = [r.catname, r.address].filter(Boolean).join(' · ');
        main.appendChild(nm); main.appendChild(sub);
        btn.appendChild(main);
        btn.addEventListener('click', () => {
          if (searchInput) searchInput.value = r.name;
          query = (r.name || '').toLowerCase();
          applyAll();
          hideSugg();
          pickOnMap(r.slug);
        });
        suggBox.appendChild(btn);
      });
      suggBox.hidden = false;
    };

    // scroll to the map and show the chosen business there
    const pickOnMap = (slug) => {
      const stage = $('[data-map-wrap]');
      if (stage && stage.scrollIntoView) {
        stage.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      setSelected(slug);
    };

    let suggTimer = null;
    searchInput?.addEventListener('input', () => {
      clearTimeout(suggTimer);
      const q = searchInput.value.trim().toLowerCase();
      if (q.length < 2) { hideSugg(); query = ''; applyAll(); return; }
      query = q;
      suggTimer = setTimeout(() => {
        const matches = data.filter(b =>
          `${b.name} ${b.address || ''} ${b.catname || ''}`.toLowerCase().includes(q)).slice(0, 6);
        renderSugg(matches);
        applyAll();
      }, 120);
    });
    searchInput?.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') hideSugg();
      if (e.key === 'Enter') { hideSugg(); applyAll(); }
    });
    document.addEventListener('click', (e) => {
      if (suggBox && !suggBox.hidden && !e.target.closest('[data-map-search]') &&
          !e.target.closest('[data-map-sugg]')) hideSugg();
    });

    // ---- sort chips ----
    $$('[data-map-sort]').forEach(chip => {
      chip.addEventListener('click', () => {
        sortKey = chip.dataset.mapSort;
        $$('[data-map-sort]').forEach(c => c.classList.toggle('is-active', c === chip));
        if (sortKey === 'nearest' && !userPos) {
          requestGeo(applyAll);
        }
        applyAll();
      });
    });
    // ---- category filter ----
    catSelect?.addEventListener('change', () => {
      catFilter = catSelect.value;
      applyAll();
    });

    // clicking a list row scrolls to the map and shows it (v65)
    $$('[data-focus]').forEach(btn => {
      btn.addEventListener('click', () => pickOnMap(btn.dataset.focus));
    });


    // "موقعیت من" — drop a blue pulsing dot on the visitor's own position
    // and centre the map there, so the user sees where they are relative to
    // the shops around them (items: my location on the map page).
    const meBtn = $('[data-map-me]');
    let meCircle = null;
    let meMarker = null;
    const makeMeIcon = () => {
      if (api.kind === 'google' && window.google?.maps) {
        return {
          path: window.google.maps.SymbolPath.CIRCLE, scale: 7.5,
          fillColor: '#2563eb', fillOpacity: 1,
          strokeColor: '#fff', strokeWeight: 3,
        };
      }
      return window.L.divIcon({
        className: 'bz-me',
        html: '<span class="bz-me-dot" style="display:block;width:13px;height:13px;border-radius:50%;' +
              'background:#2563eb;border:2.5px solid #fff;box-shadow:0 0 0 7px rgba(37,99,235,.22),' +
              '0 2px 8px rgba(0,0,0,.4)"></span>',
        iconSize: [13, 13], iconAnchor: [6.5, 6.5],
      });
    };
    meBtn?.addEventListener('click', () => {
      if (!navigator.geolocation) {
        meBtn.classList.remove('is-busy');
        return;
      }
      meBtn.classList.add('is-busy');
      const label = meBtn.querySelector('span');
      if (label) label.textContent = 'در حال گرفتن موقعیت…';
      const place = (la, ln, acc) => {
        userPos = { lat: la, lng: ln };
        if (meMarker) {
          if (api.kind === 'google') meMarker.setPosition({ lat: la, lng: ln });
          else meMarker.setLatLng([la, ln]);
        } else {
          meMarker = api.addMarker({ lat: la, lng: ln, title: 'موقعیت شما' });
          if (meMarker && (api.kind === 'google' || api.kind === 'osm')) meMarker.setIcon(makeMeIcon());
        }
        if (api.kind === 'osm' && api.map && window.L) {
          if (!meCircle) meCircle = window.L.circle([la, ln], { radius: acc || 0, color: '#2563eb', weight: 1, fillOpacity: 0.08 }).addTo(api.map);
          else { meCircle.setLatLng([la, ln]); meCircle.setRadius(acc || 0); }
        }
      };
      const loc = window.Bazarche?.locatePrecise
        ? window.Bazarche.locatePrecise({ good: 20, max: 12000, onProgress: (f) => { place(f.lat, f.lng, f.acc); if (label) label.textContent = `دقیق‌تر می‌شود… (${faNum(f.acc)} متر)`; } })
        : new Promise((ok, no) => navigator.geolocation.getCurrentPosition(p => ok({ lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy }), no, { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }));
      loc.then((f) => {
        place(f.lat, f.lng, f.acc);
        api.setCenter(f.lat, f.lng, f.acc <= 40 ? 17 : 16);
        sortKey = 'nearest';
        $$('[data-map-sort]').forEach(c =>
          c.classList.toggle('is-active', c.dataset.mapSort === 'nearest'));
        applyAll();
        meBtn.classList.remove('is-busy');
        meBtn.classList.add('is-on');
        if (label) label.textContent = 'نزدیک‌ترین‌ها';
        if (f.acc > 120) window.Bazarche?.toast(window.Bazarche.accuracyText(f.acc), 'warn');
      }).catch(async (err) => {
        meBtn.classList.remove('is-busy');
        if (label) label.textContent = 'نزدیک من';
        const msg = await (window.Bazarche && window.Bazarche.geoErrorText
          ? window.Bazarche.geoErrorText(err, 'از جستجو و نقشه استفاده کنید.')
          : Promise.resolve('موقعیت شما پیدا نشد.'));
        window.Bazarche?.toast(msg, 'warn');
      });
    });
    return;
  }

  /* ---------- owner picker ---------- */
  if (pick) {
    // f-lat/f-lng on the edit form, but the submit form names them sb-lat /
    // sb-lng — fall back to [name=lat]/[name=lng] so the same picker serves both.
    const latIn = document.getElementById('f-lat') || document.querySelector('[name="lat"]');
    const lngIn = document.getElementById('f-lng') || document.querySelector('[name="lng"]');
    const write = (a, b) => {
      if (latIn) latIn.value = a.toFixed(6);
      if (lngIn) lngIn.value = b.toFixed(6);
    };
    const marker = api.addMarker({
      lat: lat ?? 32.634, lng: lng ?? 51.367,
      title: 'موقعیت کسب‌وکار', draggable: true, onDrag: write,
    });
    api.onPick((a, b) => {
      write(a, b);
      if (api.kind === 'google') marker.setPosition({ lat: a, lng: b });
      else marker.setLatLng([a, b]);
    });
    // "use my location" button (app.js) fires bz:geo with the GPS coords — drop
    // the marker there and centre the map so the shopkeeper SEES their spot.
    window.addEventListener('bz:geo', (e) => {
      const d = e.detail || {};
      if (d.lat == null || d.lng == null) return;
      write(d.lat, d.lng);
      if (api.kind === 'google') marker.setPosition({ lat: d.lat, lng: d.lng });
      else marker.setLatLng([d.lat, d.lng]);
      api.setCenter(d.lat, d.lng, (d.acc != null && d.acc <= 40) ? 18 : 17);
    });
    return;
  }

  /* ---------- single business ---------- */
  if (lat && lng) {
    api.addMarker({ lat, lng, title: el.dataset.title || '', featured: true });
    api.setCenter(lat, lng, 16);
  }
}

// mount on first paint (or as soon as the DOM is ready)
function tryBoot() {
  boot().catch((e) => {
    // a failed map must never take the page down with it — report, don't crash
    console.warn('bz map mount failed:', e);
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', tryBoot);
} else { tryBoot(); }

// v143: live.js silently swaps <main> every ~10 s on public pages when the
// server-side content changed (page views bump the ETag). The old Leaflet/
// Google node is destroyed by the swap, so re-run boot() on the fresh
// canvas — the mounted-guard above makes this idempotent. /map, /panel and
// /my never swap (live.js SKIP_PATHS), so this only ever re-mounts what
// actually needs it.
window.addEventListener('bz:content-updated', tryBoot);
