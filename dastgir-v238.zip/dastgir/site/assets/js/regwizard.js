/* ==========================================================================
   v208 — registration wizard enhancements (progressive; the forms post fine
   without this file).  • province → city list  • hours presets vs detailed
   grid  • one-shot final submit  • keep the stepper in view on mobile.
   ========================================================================== */
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

function cities() {
  const prov = $('[data-prov]'), sel = $('[data-city-sel]'), inp = $('[data-city-input]');
  const src = $('#rw-cities');
  if (!prov || !sel || !inp || !src) return;
  let map = {};
  try { map = JSON.parse(src.textContent || '{}'); } catch (e) { map = {}; }
  const fill = () => {
    const list = map[prov.value] || [];
    if (!list.length) { sel.hidden = true; inp.hidden = false; return; }
    const cur = inp.value;
    sel.innerHTML = '<option value="">انتخاب کنید…</option>' +
      list.map(c => `<option value="${c}"${c === cur ? ' selected' : ''}>${c}</option>`).join('');
    sel.hidden = false; inp.hidden = true;
    if (!list.includes(cur)) inp.value = '';
  };
  sel.addEventListener('change', () => { inp.value = sel.value; });
  prov.addEventListener('change', fill);
  fill();
}

function hours() {
  const presets = $('[data-hours-presets]'), grid = $('[data-hours-grid]');
  if (!presets || !grid) return;
  const details = grid.closest('details');
  // Choosing a preset clears the detailed grid's "dirty" state so the server
  // reads the preset; editing the grid unchecks the preset.
  presets.addEventListener('change', () => { if (details) details.open = false; });
  grid.addEventListener('input', () => {
    $$('input[type=radio]', presets).forEach(r => { r.checked = false; });
  });
}

function once() {
  $$('form[data-once]').forEach(f => {
    f.addEventListener('submit', () => {
      const b = $('[type=submit]', f);
      if (b) { b.disabled = true; b.innerHTML = '<span class="spinner"></span><span>در حال ثبت…</span>'; }
    });
  });
}

function catgrid() {
  const f = $('form[data-catgrid]'); if (!f) return;
  const sel = $('#rw-cat', f), picked = $('[data-cat-picked]', f), pname = $('[data-cat-picked-name]', f);
  const q = $('[data-cat-search]', f), empty = $('[data-cat-empty]', f);
  const fold = t => String(t || '').toLowerCase().replace(/[\u064A]/g, '\u06CC').replace(/[\u0643]/g, '\u06A9')
    .replace(/[\u200C]/g, ' ').replace(/[\u064B-\u0652\u0640]/g, '').replace(/\s+/g, ' ').trim();
  const choose = (chip) => {
    $$('.rw-chip', f).forEach(c => c.classList.toggle('is-on', c === chip));
    $$('[data-group]', f).forEach(g => g.classList.toggle('is-on', g.contains(chip)));
    sel.value = chip.dataset.cat; pname.textContent = chip.dataset.name; picked.classList.add('is-on');
    sel.dispatchEvent(new Event('change', { bubbles: true }));
  };
  $$('.rw-chip', f).forEach(c => c.addEventListener('click', () => choose(c)));
  f.addEventListener('submit', (e) => {
    if (!sel.value) { e.preventDefault(); q.focus(); picked.classList.add('is-on'); pname.textContent = 'هنوز انتخاب نشده — یکی از شغل‌ها را بزنید'; }
  });
  const filter = () => {
    const nq = fold(q.value); let any = false;
    $$('[data-group]', f).forEach(g => {
      let hit = 0;
      const gname = fold(g.querySelector('.rw-group-name')?.textContent);
      $$('.rw-chip', g).forEach(c => {
        const ok = !nq || fold(c.dataset.name).includes(nq) || gname.includes(nq);
        c.classList.toggle('is-hidden', !ok); if (ok) hit++;
      });
      g.classList.toggle('is-hidden', !hit); if (hit) any = true;
      if (nq && hit) g.open = true; else if (!nq && !g.classList.contains('is-on')) g.open = false;
    });
    empty.hidden = any;
  };
  q.addEventListener('input', filter);
  // native select stays authoritative (JS-off / a11y); mirror if it changes.
  sel.addEventListener('change', () => {
    const chip = $$('.rw-chip', f).find(c => c.dataset.cat === sel.value);
    if (chip && !chip.classList.contains('is-on')) choose(chip);
  });
}

cities(); hours(); once(); catgrid();
