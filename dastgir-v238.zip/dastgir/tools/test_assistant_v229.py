#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v229 «یادآوری نوبت» — customers with a booking tomorrow (Iran time) get
one inbox reminder (prefs/push/messenger aware); web-stored raw dates are
folded, muted customers are skipped (not marked), re-runs are silent.
"""
import datetime, os, subprocess, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v229-')
os.environ['BZ_DATA_DIR'] = TMP
sys.path.insert(0, str(ROOT / 'server')); sys.path.insert(0, str(ROOT / 'tools'))
import db, features as F
from layout import g2j
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
t = db.iran_now().date() + datetime.timedelta(days=1)
ty, tm, td = g2j(t.year, t.month, t.day)
TOM = f"{ty:04d}/{tm:02d}/{td:02d}"
t0 = db.iran_now().date(); y0, m0, d0 = g2j(t0.year, t0.month, t0.day)
TODAY = f"{y0:04d}/{m0:02d}/{d0:02d}"
t2 = db.iran_now().date() + datetime.timedelta(days=2)
LATER = f"{g2j(t2.year, t2.month, t2.day)[0]:04d}/{g2j(t2.year, t2.month, t2.day)[1]:02d}/{g2j(t2.year, t2.month, t2.day)[2]:02d}"
ck(TOM > TODAY and len(TOM) == 10, 'independent oracle: sane Jalali tomorrow')

own = db.owner_by_phone('09120000100', create=True)
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id,booking_on) VALUES(?,?,?,?,?,1)",
            ('rem-shop', 'نوبت‌فروشی یاد', 'services', 'published', own['id']))
con.commit(); con.close()
biz = db.business(slug='rem-shop')
c1 = db.customer_by_phone('09120000241', create=True)
c2 = db.customer_by_phone('09120000242', create=True)
db._run("INSERT INTO notif_prefs(role,user_id,kind,enabled) VALUES('cust',?,'booking',0)", (c2['id'],))
FA = str.maketrans('0123456789', '۰۱۲۳۴۵۶۷۸۹')

# ---- 1. the normalizer folds every stored variant
ck(F._norm_bdate(TOM) == TOM, 'normalized date passes through')
ck(F._norm_bdate(f"{ty}-{tm}-{td}") == TOM, 'web raw Y-M-D folds')
ck(F._norm_bdate(TOM.translate(FA)) == TOM, 'Persian digits fold')
ck(F._norm_bdate('2026/09/10') == '' and F._norm_bdate('garbage') == '' and F._norm_bdate(None) == '', 'non-Jalali/garbage rejected')

# ---- 2. exactly the right customers are reminded
b1 = db.add_booking(biz['id'], 'مشتری یک', '09120000241', TOM, '10:00', '', c1['id'])
b2 = db.add_booking(biz['id'], 'مشتری یک', '09120000241', TOM.translate(FA), '11:00', '', c1['id'])
b3 = db.add_booking(biz['id'], 'مشتری یک', '09120000241', TOM, '12:00', '', c1['id'])
db._run("UPDATE bookings SET status='cancelled' WHERE id=?", (b3,))
db.add_booking(biz['id'], 'مهمان', '09120000299', TOM, '13:00', '', None)
db.add_booking(biz['id'], 'مشتری یک', '09120000241', TODAY, '14:00', '', c1['id'])
db.add_booking(biz['id'], 'مشتری دو', '09120000242', TOM, '15:00', '', c2['id'])
db.add_booking(biz['id'], 'مشتری یک', '09120000241', LATER, '16:00', '', c1['id'])
ck(F.booking_reminders() == 2, 'only the two live customer bookings for tomorrow')
rows = db._rows("SELECT kind,text,link FROM notifications WHERE customer_id=? AND text LIKE '⏰ یادآوری:%' ORDER BY id", (c1['id'],))
ck(len(rows) == 2 and all(r['kind'] == 'booking' and r['link'] == '/b/rem-shop' for r in rows), 'two reminder rows, deep-linked')
ck(all('نوبت‌فروشی یاد' in r['text'] for r in rows), 'reminder text names the shop')
ck(db._rows("SELECT 1 x FROM notifications WHERE customer_id=?", (c2['id'],)) == [], 'muted customer skipped')
ck(db._one("SELECT reminded r FROM bookings WHERE id=?", (b1,))['r'] == TOM, 'sent booking marked')
ck(db._one("SELECT reminded r FROM bookings WHERE id=?", (b2,))['r'] == TOM, 'raw-format booking marked normalized')
ck(F.booking_reminders() == 0, 're-run is silent (idempotent)')
db._run("UPDATE bookings SET date='bogus' WHERE id=?", (b1,))
ck(F.booking_reminders() == 0, 'marker + date re-check keeps garbage quiet')

# ---- 3. an old database gains the column on boot (legacy migration)
old = tempfile.mkdtemp(prefix='ai-v229-old-')
sub = subprocess.run([sys.executable, '-c',
    "import sqlite3, sys; sys.path.insert(0, %r); import db; "
    "db.init(); "
    "con = db.connect(); con.execute('ALTER TABLE bookings RENAME TO bookings_new'); "
    "con.execute('CREATE TABLE bookings(id INTEGER PRIMARY KEY AUTOINCREMENT, biz_id INTEGER NOT NULL, ' "
    "'name TEXT NOT NULL, phone TEXT NOT NULL, date TEXT NOT NULL, time TEXT NOT NULL, ' "
    "'note TEXT DEFAULT \\'\\', status TEXT DEFAULT \\'new\\', customer_id INTEGER, ' "
    "'created TEXT DEFAULT (datetime(\\'now\\')))'); "
    "con.execute('DROP TABLE bookings_new'); con.commit(); con.close(); "
    "db.init(); "
    "cols = {r['name'] for r in db._rows(\"PRAGMA table_info(bookings)\")}; "
    "print('MIG-OK' if 'reminded' in cols else 'MIG-FAIL')" % str(ROOT / 'server')],
    capture_output=True, text=True, env={**os.environ, 'BZ_DATA_DIR': old})
ck('MIG-OK' in sub.stdout, f'legacy bookings table gains reminded ({sub.stdout.strip()} {sub.stderr.strip()[:120]})')

print(f"v229: {n} checks passed")
