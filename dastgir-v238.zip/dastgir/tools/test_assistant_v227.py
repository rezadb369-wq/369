#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v227 «فعالیت دستیار برای مالک» — /my/assistant shows what the assistant
did for one owner's shops (parsed from the audit trail, ownership-checked),
open cancel requests, 7-day counts and the owner's own quota. Malformed or
foreign rows never break it.
"""
import os, sys, tempfile, datetime
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v227-')
os.environ['BZ_DATA_DIR'] = TMP
sys.path.insert(0, str(ROOT / 'server')); sys.path.insert(0, str(ROOT / 'tools'))
import db, assistant as A
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
o1 = db.owner_by_phone("09120000121", create=True)
o2 = db.owner_by_phone("09120000122", create=True)
o3 = db.owner_by_phone("09120000123", create=True)   # no shops
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id,booking_on) VALUES(?,?,?,?,?,?)",
            ("biz-a", "دکان الف", "services", "published", o1["id"], 1))
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id,booking_on) VALUES(?,?,?,?,?,?)",
            ("biz-b", "دکان ب", "services", "published", o2["id"], 1))
con.commit(); con.close()
biz_a = db.business(slug="biz-a")
c1 = db.customer_by_phone("09120000124", create=True)
db._run("UPDATE customers SET name='مشتری یک' WHERE id=?", (c1["id"],))
c1 = db._one("SELECT * FROM customers WHERE id=?", (c1["id"],))
c2 = db.customer_by_phone("09120000125", create=True)   # nameless → masked phone
t = datetime.date.today()
from layout import g2j
VALID = f"{g2j(t.year, t.month, t.day)[0] + 1}/03/15"
con = db.connect()
con.execute("INSERT INTO bookings(biz_id,name,phone,date,time,status,customer_id) VALUES(?,?,?,?,?,?,?)",
            (biz_a["id"], "x", c1["phone"], "2026-10-03", "10:00", "new", c1["id"]))
b1 = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
con.commit(); con.close()
o_stale = db.create_order(biz_a["id"], c1["id"], "x", c1["phone"], "نشانی", "", [{"title": "ک", "price": 1000, "qty": 1}])
db._run("UPDATE orders SET created='2026-09-01 10:00:00' WHERE id=?", (o_stale,))

ctx1 = {"channel": "web", "user_key": f"cust:{c1['id']}", "customer": c1, "owner": None}
ctx2 = {"channel": "web", "user_key": f"cust:{c2['id']}", "customer": c2, "owner": None}
ck(A.tool_execute("favorite", {"slug": "biz-a"}, ctx1)[0], 'seed: favorite on')
ck(A.tool_execute("book", {"slug": "biz-a", "date": VALID, "time": "10:00"}, ctx1)[0], 'seed: book')
ck(A.tool_execute("review", {"slug": "biz-a", "body": "خوب بود"}, ctx1)[0], 'seed: review')
ck(A.tool_execute("cancel_booking", {"id": b1}, ctx1)[0], 'seed: cancel booking')
ck(A.tool_execute("cancel_order", {"id": o_stale}, ctx1)[0], 'seed: cancel order (requested)')
ck(A.tool_execute("favorite", {"slug": "biz-b"}, ctx1)[0], "seed: favorite on the other owner's shop")
ck(A.tool_execute("favorite", {"slug": "biz-a"}, ctx1)[0], 'seed: favorite off')
ck(A.tool_execute("favorite", {"slug": "biz-a"}, ctx2)[0], 'seed: nameless favorite')
db.log("assistant_tool", "garbage [[[" + "x" * 50)
db.log("something_else", "favorite user=cust:1 biz=1 on=1")

# ---- 1. ownership-checked rows, newest first
d1 = A.owner_assistant_data(o1["id"])
ck(len(d1["rows"]) == 7, 'seven own events (foreign favorite excluded)')
ck("ذخیره کرد" in d1["rows"][0]["text"] and "برداشت" in d1["rows"][1]["text"], 'newest first')
texts = " | ".join(r["text"] for r in d1["rows"])
for bit in ("ذخیره کرد", "نوبت تازه", "نظر تازه", "را لغو کرد", "نیاز به تصمیم شما", "مشتری یک", "••••"):
    assert bit in texts, bit
ck(True, 'every tool rendered in plain Persian, named + masked customers')
links = {r["tool"]: r["link"] for r in d1["rows"]}
ck(links["favorite"] == "/b/biz-a" and links["book"] == "/my/bookings" and links["review"] == "/my/reviews"
   and links["cancel_booking"] == "/my/bookings" and links["cancel_order"] == "/my/orders", 'each tool links its page')
ck(all(r["created"] for r in d1["rows"]), 'timestamps pass through')
d2 = A.owner_assistant_data(o2["id"])
ck(len(d2["rows"]) == 1 and d2["rows"][0]["tool"] == "favorite", 'other owner sees only their own event')

# ---- 2. 7-day counts + open requests + empty states
ck(d1["counts"] == {"favorite": 3, "cancel_booking": 1, "cancel_order": 1, "book": 1, "review": 1}, '7-day per-tool counts')
db._run("UPDATE audit SET created='2026-08-01 10:00:00' WHERE detail LIKE 'book user=%'")
d1b = A.owner_assistant_data(o1["id"])
ck(d1b["counts"]["book"] == 0 and len(d1b["rows"]) == 7, 'aged-out event leaves counts, stays in latest rows')
ck(d1["pending_cancels"] == 1, 'open cancel request counted')
d3 = A.owner_assistant_data(o3["id"])
ck(d3["rows"] == [] and d3["pending_cancels"] == 0 and set(d3["counts"]) == set(A.TOOLS), 'shopless owner: empty, no crash')
ck(A.owner_assistant_data("x")["rows"] == [] and A.owner_assistant_data(None)["counts"]["book"] == 0, 'bad owner id: empty, no crash')

# ---- 3. the page
import views_owner as O
from ui import OWNER_AREA_NAV
html = O.owner_assistant(db.get_settings(), o1, {})
for bit in ("فعالیت دستیار", "دکان الف", "درخواست لغو", "سهمیه", "/my/orders", "/assistant", "مشتری یک"):
    assert bit in html, bit
ck(True, 'page: title, shop, needs-you box, quota strip, links')
html3 = O.owner_assistant(db.get_settings(), o3, {})
ck("اقدامی ثبت نشده" in html3 and "درخواست لغو" not in html3, 'empty page renders the empty state, no box')
ck(("/my/assistant", "فعالیت دستیار", "activity") in OWNER_AREA_NAV, 'dashboard tile registered')

print(f"v227: {n} checks passed")
