#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v228 «تمیزکاری» — the dead intent classifier is gone (llm_intent had no
callers; system_prompt() survives only as a faqs() shim pinned by v218),
and audit_log() escapes LIKE metacharacters instead of stripping them, so
filtering for 'assistant_tool' finally matches.
"""
import os, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v228-')
os.environ['BZ_DATA_DIR'] = TMP
sys.path.insert(0, str(ROOT / 'server'))
import db, assistant as A
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()

# ---- 1. dead code removed, live knowledge intact
ck(not hasattr(A, "llm_intent"), 'llm_intent gone')
ck(not hasattr(A, "SYSTEM_PROMPT") and not hasattr(A, "_SYSTEM_HEAD"), 'dead prompt machinery gone')
ck(callable(getattr(A, "system_prompt", None)), 'system_prompt shim kept')
ck("حساب مشتری" in A.system_prompt(), 'shim still serves the knowledge')
ck(callable(getattr(A, "parse_model_json", None)) and A.KNOWLEDGE and A.faqs(), 'tested utility + knowledge list intact')

# ---- 2. audit_log filters match literally
db.log("assistant_tool", "favorite user=cust:1 biz=1 on=1")
db.log("assistant_toolx", "prefix decoy")
db.log("other", "plain row")
db.log("other", "100%_sure")
db.log("old_action", "aged out")
db._run("UPDATE audit SET created='2026-08-01 10:00:00' WHERE action='old_action'")
got = [r["action"] for r in db.audit_log(10, action="assistant_tool")]
ck("assistant_tool" in got, 'underscore action matches (the bug)')
ck(got == ["assistant_toolx", "assistant_tool"], 'prefix semantics kept, newest first')
ck([r["detail"] for r in db.audit_log(10, detail="100%_sure")] == ["100%_sure"], 'literal % and _ match')
ck([r["detail"] for r in db.audit_log(10, detail="%")] == ["100%_sure"], 'bare % is literal, not a wildcard')
ck([r["detail"] for r in db.audit_log(10, detail="_")] == ["100%_sure"], 'bare _ is literal, not a wildcard')
ck(all(r["action"] != "old_action" for r in db.audit_log(10, days=7)), 'days horizon still applies')
ck(any(r["action"] == "old_action" for r in db.audit_log(10)), 'days=0 still sees everything')
ck(len(db.audit_log(2)) == 2, 'limit respected')
ck(db.audit_log(10, action="assistant_tool', 'x") == [], 'quote input matches nothing, breaks nothing')

print(f"v228: {n} checks passed")
