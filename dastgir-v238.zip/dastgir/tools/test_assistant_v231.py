#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v231 «خلاصهٔ کامل‌تر» — the owner morning digest gains the assistant
dimension (24h tool events + open cancel requests), and today_bookings
counts raw web dates (unpadded) via _norm_bdate. Idempotency kept.
"""
import datetime, os, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v231-')
os.environ['BZ_DATA_DIR'] = TMP
sys.path.insert(0, str(ROOT / 'server')); sys.path.insert(0, str(ROOT / 'tools'))
import db, features as F, assistant as A
from layout import g2j
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
own = db.owner_by_phone('09120000120', create=True)
lazy = db.owner_by_phone('09120000121', create=True)
blocked = db.owner_by_phone('09120000122', create=True)
db._run("UPDATE owners SET status='blocked' WHERE id=?", (blocked['id'],))
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id,booking_on) VALUES(?,?,?,?,?,1)",
            ('dig-shop', 'مغازه خلاصه', 'services', 'published', own['id']))
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id) VALUES(?,?,?,?,?)",
            ('ban-shop', 'مغازه مسدود', 'services', 'published', blocked['id']))
con.commit(); con.close()
biz = db.business(slug='dig-shop')
cust = db.customer_by_phone('09120000123', create=True)
t0 = db.iran_now().date(); jy, jm, jd = g2j(t0.year, t0.month, t0.day)
TODAY = f"{jy:04d}/{jm:02d}/{jd:02d}"

# ---- 1. assistant numbers feed the summary
ctx = {"channel": "web", "user_key": f"cust:{cust['id']}", "customer": cust, "owner": None}
ck(A.tool_execute("favorite", {"slug": "dig-shop"}, ctx)[0] is True, 'real tool event seeded')
oid = db.create_order(biz["id"], cust["id"], "کیوای", cust["phone"], "نشانی", "",
                      [{"title": "کالا", "price": 1000, "qty": 1}])
db._run("UPDATE orders SET created='2026-09-01 10:00:00' WHERE id=?", (oid,))
ck(db.request_order_cancel(oid, cust["id"])["result"] == "requested", 'open cancel seeded')
dc = A.digest_counts(own["id"])
ck(dc == {"tool_events": 1, "open_cancels": 1}, f'digest_counts exact {dc}')
ck(A.digest_counts("xx") == {"tool_events": 0, "open_cancels": 0}, 'bad owner id → zeros, never raises')
s = F.owner_bot_summary(own["id"])
ck(s["assistant_events"] == 1 and s["open_cancels"] == 1, 'summary carries the assistant bits')
ck(s["businesses"] == 1, 'business count intact')
ck(F.owner_bot_summary(lazy["id"])["assistant_events"] == 0, 'biz-less owner → zeros')

# ---- 2. today_bookings counts raw web dates too
db.add_booking(biz["id"], "ن", "09120000123", TODAY, "10:00", "", cust["id"])
db.add_booking(biz["id"], "ن", "09120000123", f"{jy}-{jm}-{jd}", "11:00", "", cust["id"])
ck(F.owner_bot_summary(own["id"])["today_bookings"] == 2, 'padded + raw today bookings counted')

# ---- 3. the digest: content, gating, idempotency
ck(F.send_owner_daily_summaries('2099-01-03') == 1, 'one digest (blocked + biz-less skipped)')
note = db._one("SELECT kind,text,link FROM owner_notifications WHERE owner_id=? ORDER BY id DESC", (own["id"],))
ck(note["kind"] == "summary" and note["link"] == "/my", 'kind + link unchanged')
ck("دستیار (۲۴ساعت): 1" in note["text"] and "درخواست لغو باز: 1" in note["text"], 'assistant line present')
ck("نوبت امروز: 2" in note["text"] and len(note["text"]) <= 200, 'bookings fixed, fits the trim')
ck(F.send_owner_daily_summaries('2099-01-03') == 0, 'same day → silent (idempotent)')
ck(F.send_owner_daily_summaries('2099-01-04') == 1, 'next day → sends again')
ck(db._rows("SELECT 1 x FROM owner_notifications WHERE owner_id=?", (blocked["id"],)) == [], 'blocked owner paged never')

print(f"v231: {n} checks passed")
