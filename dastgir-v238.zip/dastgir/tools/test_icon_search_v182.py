#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Browser regression for searchable category-icon selectors. Requires run.py."""
from __future__ import annotations
import os
from pathlib import Path
import sys
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))
import db

BASE = os.environ.get("BZ", "http://127.0.0.1:8080")


def check(ok, label):
    if not ok: raise AssertionError(label)
    print("✓", label)


def exercise(page, search_sel, select_sel):
    search = page.locator(search_sel)
    select = page.locator(select_sel)
    check(search.count() == 1 and select.count() == 1, "search and icon select are present")
    check(search.evaluate("e => e.getBoundingClientRect().height >= 40"),
          "search field has a mobile-friendly touch height")

    search.fill("رستوران")
    visible = select.locator("option").evaluate_all(
        "opts => opts.filter(o => !o.hidden).map(o => o.value)")
    check("restaurant" in visible and "آیکون پیدا شد" in
          page.locator(search_sel + " + [data-icon-search-status]").inner_text(),
          "Persian search finds restaurant icon")
    check(select.get_attribute("size") != "1", "results expand into a selectable list")
    select.select_option("restaurant")
    check("restaurant.webp" in page.locator(select_sel + " ~ [data-icon-preview] .ic").get_attribute("style"),
          "choosing a result updates the visual preview")

    search.fill("هیچ-نتیجه-ای-نیست")
    form_value = select.evaluate("e => new FormData(e.form).get('icon')")
    check(select.input_value() == "restaurant" and form_value == "restaurant",
          "no-result search preserves the selected submitted value")
    check("پیدا نشد" in page.locator(search_sel + " + [data-icon-search-status]").inner_text(),
          "no-result state is announced clearly")

    search.press("Escape")
    check(search.input_value() == "" and select.get_attribute("size") == "1" and
          select.locator("option").evaluate_all("opts => opts.every(o => !o.hidden)"),
          "Escape clears search and restores the complete list")

    search.fill("cafe")
    visible = select.locator("option").evaluate_all(
        "opts => opts.filter(o => !o.hidden).map(o => o.value)")
    check("cafe" in visible, "Latin search finds cafe icon")


def main():
    token = db.owner_token()
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--no-sandbox"])
        page = browser.new_page(viewport={"width": 390, "height": 844}, locale="fa-IR")
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.goto(f"{BASE}/panel/categories?key={token}", wait_until="networkidle")
        exercise(page, "#nc-icon-search", "#nc-icon")
        check(page.evaluate("document.documentElement.scrollWidth <= innerWidth"),
              "new-category picker has no horizontal overflow at 390px")

        cid = db.categories(only_active=False)[0]["id"]
        page.goto(f"{BASE}/panel/category/{cid}?key={token}", wait_until="networkidle")
        exercise(page, "#c-icon-search", "#c-icon")
        check(page.evaluate("document.documentElement.scrollWidth <= innerWidth"),
              "edit-category picker has no horizontal overflow at 390px")
        check(not errors, "no browser page errors")
        browser.close()
    print("\nهمهٔ آزمون‌های جست‌وجوی آیکون v182 موفق بودند.")


if __name__ == "__main__":
    main()
