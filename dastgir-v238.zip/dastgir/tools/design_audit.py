#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
design_audit.py — ممیزی جامع دیزاین «دست گیر» (موبایل + دسکتاپ)
=====================================================================
هر صفحه از ۴ گروه (پنل مدیریت / پنل دکان‌دار / پنل مشتری / عمومی) را در ۷
عرض دستگاه (اندروید ۳۲۰/۳۶۰/۳۹۰/۴۱۲ و دسکتاپ ۱۳۶۶/۱۴۴۰/۱۹۲۰) باز می‌کند،
اسکرین‌شات تمام‌صفحه می‌گیرد و سنجه‌های DOM را اندازه می‌گیرد:

  · سرریز افقی (overflow-x) + عنصرهای مقصر
  · هدف لمسی < 44px (موبایل)
  · متن < 12px
  · تصویر بدون alt
  · دکمهٔ فقط-آیکون بدون نام در دسترس
  · خطاهای کنسول / خطای صفحه / وضعیت HTTP
  · متای viewport

خروجی (پیش‌فرض /home/user/audit-design/):
  shots/<group>/<page>@<viewport>.webp   اسکرین‌شات‌های کامل
  data.json                              همهٔ سنجه‌ها
  report.html                            گزارش خودکفا با ریشه‌یابی و تصویر
  gallery-*.html                         گالری کامل هر گروه (تصویر توکار)

اجرا:
  BZ=http://127.0.0.1:8080 python3 tools/design_audit.py
  python3 tools/design_audit.py --groups public --viewports m390 d1440
  python3 tools/design_audit.py --smoke            # فقط ۳ صفحه برای تست
  python3 tools/design_audit.py --resume           # ادامه از جایی که ماند
  python3 tools/design_audit.py --skip-shots       # فقط سنجه، بدون عکس

وابستگی (فقط سندباکس — به بستهٔ سایت اضافه نمی‌شود): playwright + pillow
"""
import argparse
import base64
import io
import json
import os
import re
import sys
import threading
import time
import traceback
import urllib.error
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
ROOT = Path(__file__).resolve().parent.parent
CSS_DIR = ROOT / "site" / "assets" / "css"
JS_DIR = ROOT / "site" / "assets" / "js"
DEFAULT_OUT = "/home/user/audit-design"

try:
    from playwright.async_api import async_playwright
except ImportError:
    sys.exit("playwright نصب نیست:  python3 -m playwright install --with-deps chromium")

try:
    from PIL import Image
except ImportError:
    sys.exit("pillow نصب نیست:  pip install pillow")

# ---------------------------------------------------------------- viewports
VIEWPORTS = [
    ("m320", 320, 568, 2),    # اندروید کوچک (مرزی)
    ("m360", 360, 800, 2),    # اندروید رایج
    ("m390", 390, 844, 2),    # پیکسل/سامسونگ رایج
    ("m412", 412, 915, 2),    # اندروید بزرگ
    ("d1366", 1366, 768, 1),  # لپ‌تاپ رایج
    ("d1440", 1440, 900, 1),  # دسکتاپ استاندارد
    ("d1920", 1920, 1080, 1), # فول‌اچ‌دی
]
MOBILE = {"m320", "m360", "m390", "m412"}
DESKTOP = {"d1366", "d1440", "d1920"}

# ---------------------------------------------------------------- pages
PUBLIC_PAGES = [
    ("home", "/"),
    ("businesses", "/businesses"),
    ("biz-detail", "/b/kbaby-bradran-hydry"),
    ("catalog", "/catalog"),
    ("map", "/map"),
    ("blog", "/blog"),
    ("events", "/events"),
    ("compare", "/compare"),
    ("nearby", "/nearby"),
    ("lists", "/lists"),
    ("deals", "/deals"),
    ("favorites", "/favorites"),
    ("contact", "/contact"),
    ("register", "/register-business"),
    ("cities", "/cities"),
    ("areas", "/areas"),
    ("categories", "/categories"),
    ("cart", "/cart"),
    ("order-ok", "/order/ok"),
    ("pricing", "/pricing"),
    ("features", "/features"),
    ("login", "/login"),
    ("me-login", "/me/login"),
    ("about", "/about"),
    ("rules", "/rules"),
]

PANEL_PAGES = [
    ("panel", "/panel"),
    ("businesses", "/panel/businesses"),
    ("categories", "/panel/categories"),
    ("reviews", "/panel/reviews"),
    ("reports", "/panel/reports"),
    ("tickets", "/panel/tickets"),
    ("trash", "/panel/trash"),
    ("traffic", "/panel/traffic"),
    ("analytics", "/panel/analytics"),
    ("chats", "/panel/chats"),
    ("messages", "/panel/messages"),
    ("orders", "/panel/orders"),
    ("ads", "/panel/ads"),
    ("badges", "/panel/badges"),
    ("plans", "/panel/plans"),
    ("subscriptions", "/panel/subscriptions"),
    ("events", "/panel/events"),
    ("edits", "/panel/edits"),
    ("alerts", "/panel/alerts"),
    ("insights", "/panel/insights"),
    ("inbox", "/panel/inbox"),
    ("features", "/panel/features"),
    ("lists", "/panel/lists"),
    ("deals", "/panel/deals"),
    ("stories", "/panel/stories"),
    ("editor", "/panel/editor"),
    ("audit", "/panel/audit"),
    ("customers", "/panel/customers"),
    ("broadcast", "/panel/broadcast"),
    ("follows", "/panel/follows"),
    ("areas", "/panel/areas"),
    ("demo", "/panel/demo"),
    ("backup", "/panel/backup"),
    ("media", "/panel/media"),
    ("settings", "/panel/settings"),
    ("appearance", "/panel/appearance"),
    ("search", "/panel/search"),
    ("moderation", "/panel/moderation"),
    ("owners", "/panel/owners"),
    ("pages", "/panel/pages"),
    ("posts", "/panel/posts"),
    ("qa", "/panel/qa"),
    ("claims", "/panel/claims"),
    ("inquiries", "/panel/inquiries"),
    ("bookings", "/panel/bookings"),
]

OWNER_PAGES = [
    ("my", "/my"),
    ("account", "/my/account"),
    ("businesses", "/my/businesses"),
    ("chats", "/my/chats"),
    ("orders", "/my/orders"),
    ("stories", "/my/stories"),
    ("trash", "/my/trash"),
    ("reviews", "/my/reviews"),
    ("bookings", "/my/bookings"),
    ("inquiries", "/my/inquiries"),
    ("claim", "/my/claim"),
    ("questions", "/my/questions"),
    ("offers", "/my/offers"),
    ("tickets", "/my/tickets"),
    ("plan", "/my/plan"),
    ("export", "/my/export"),
]

CUSTOMER_PAGES = [
    ("me", "/me"),
    ("profile", "/me/profile"),
    ("chats", "/me/chats"),
    ("orders", "/me/orders"),
    ("favorites", "/me/favorites"),
    ("account", "/me/account"),
    ("notifications", "/me/notifications"),
    ("following", "/me/following"),
]

GROUPS = {
    "public": PUBLIC_PAGES,
    "panel": PANEL_PAGES,
    "owner": OWNER_PAGES,
    "customer": CUSTOMER_PAGES,
}

# ---------------------------------------------------------------- metrics JS
METRICS_JS = r"""
(() => {
  const vw = innerWidth, vh = innerHeight, de = document.documentElement;
  if (!de || !document.body) {
    return { vw, vh, sw: 0, sh: 0, title: document.title, textLen: 0,
             viewportMeta: false, empty: true };
  }
  const res = { vw, vh, sw: de.scrollWidth, sh: de.scrollHeight,
                title: document.title, textLen: (document.body ? document.body.innerText.length : 0),
                viewportMeta: !!document.querySelector('meta[name="viewport"]') };
  const vis = el => { const cs = getComputedStyle(el);
    return cs.display !== 'none' && cs.visibility !== 'hidden' && parseFloat(cs.opacity) > 0.01; };
  const clsOf = el => (typeof el.className === 'string' ? el.className : '').trim().slice(0, 90);

  // --- horizontal overflow ---
  res.overflow = Math.max(0, de.scrollWidth - vw);
  if (res.overflow > 1) {
    const off = [];
    for (const el of document.querySelectorAll('body *')) {
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) continue;
      const cs = getComputedStyle(el);
      if (cs.position === 'fixed' || cs.overflow === 'hidden') continue;
      const overR = r.right - vw, overL = -r.left;
      if (overR > 1 || overL > 1) {
        off.push({ t: el.tagName.toLowerCase(), c: clsOf(el), i: el.id || '',
                   r: Math.round(overR), l: Math.round(overL), w: Math.round(r.width) });
      }
    }
    off.sort((a, b) => Math.max(b.r, b.l) - Math.max(a.r, a.l));
    res.overflowEls = off.slice(0, 8);
  }

  // --- tap targets < 44 (mobile) ---
  const tap = [];
  for (const el of document.querySelectorAll('a,button,input,select,textarea,summary,[role="button"],[tabindex]')) {
    const r = el.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) continue;
    if (!vis(el) || el.disabled) continue;
    const cs = getComputedStyle(el);
    if (cs.pointerEvents === 'none') continue;
    // Leaflet controls are intentionally small (design decision, v118):
    // zoom buttons, the attribution link, and the compact «نزدیک من» chip
    if (el.classList.contains('leaflet-control-zoom-in') ||
        el.classList.contains('leaflet-control-zoom-out') ||
        el.classList.contains('map-me') ||
        el.closest('.leaflet-control-attribution')) continue;
    // a small input inside a big clickable wrapper (label/chip) is fine —
    // the tap lands on the wrapper
    const pr = el.closest('a,button,label,[role="button"]');
    if (pr && pr !== el) { const prr = pr.getBoundingClientRect();
      if (prr.height >= 44 && prr.width >= 44) continue; }
    // any element with a pseudo-element hit-area (::after inset trick —
    // .check inputs, map pins .bz-pin / .leaflet-marker-icon) measures
    // small but taps big
    let effW = r.width, effH = r.height;
    const ps = getComputedStyle(el, '::after');
    if (ps.content && ps.content !== 'none' && ps.position === 'absolute') {
      const m = /-?(\d+)px/.exec(ps.inset || '');
      const ext = m ? parseInt(m[1], 10) : 0;
      if (ext > 0) { effW = r.width + ext * 2; effH = r.height + ext * 2; }
    }
    if (effW >= 44 && effH >= 44) continue;
    if (r.width < 44 || r.height < 44) {
      const aName = (el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
      const txt = (el.innerText || '').replace(/\s+/g, ' ').trim();
      tap.push({ t: el.tagName.toLowerCase(), c: clsOf(el), i: el.id || '',
                 w: Math.round(r.width), h: Math.round(r.height),
                 name: aName || txt.slice(0, 30) });
    }
  }
  res.tapSmall = tap.slice(0, 14);

  // --- fonts < 12px ---
  const fonts = [];
  const seen = new Set();
  if (!document.body) return res;
  const tw = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = tw.nextNode()) && fonts.length < 12) {
    const t = (n.textContent || '').trim();
    if (!t) continue;
    const p = n.parentElement;
    if (!p || !vis(p)) continue;
    const fs = parseFloat(getComputedStyle(p).fontSize);
    if (fs > 0 && fs < 12) {
      const key = p.tagName + '.' + clsOf(p);
      if (seen.has(key)) continue;
      seen.add(key);
      fonts.push({ t: p.tagName.toLowerCase(), c: clsOf(p), i: p.id || '',
                   fs: fs, txt: t.slice(0, 40) });
    }
  }
  res.smallFonts = fonts;

  // --- images without alt ---
  // alt="" on a decorative image is the WCAG-correct solution, not a defect;
  // map tiles are decorative by nature (the map carries the meaning). Only a
  // MISSING alt attribute is reported.
  const imgs = [];
  for (const im of document.images) {
    if (!vis(im)) continue;
    if (im.classList.contains('leaflet-tile')) continue;
    if (!im.hasAttribute('alt')) {
      imgs.push({ src: (im.getAttribute('src') || '').slice(0, 70),
                  w: Math.round(im.getBoundingClientRect().width) });
      if (imgs.length >= 10) break;
    }
  }
  res.imgsNoAlt = imgs;

  // --- icon-only interactive without accessible name ---
  const iconOnly = [];
  for (const el of document.querySelectorAll('a,button,[role="button"]')) {
    const r = el.getBoundingClientRect();
    if (r.width < 4 || r.height < 4 || !vis(el) || el.disabled) continue;
    const aName = (el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
    const txt = (el.innerText || '').replace(/\s+/g, '');
    if (!aName && !txt) {
      iconOnly.push({ t: el.tagName.toLowerCase(), c: clsOf(el), i: el.id || '',
                      w: Math.round(r.width), h: Math.round(r.height) });
      if (iconOnly.length >= 10) break;
    }
  }
  res.iconOnly = iconOnly;

  // --- text cut off (overflow hidden without ellipsis) ---
  const clipped = [];
  for (const el of document.querySelectorAll('body *')) {
    const r = el.getBoundingClientRect();
    if (r.width < 4 || r.height < 4 || !vis(el)) continue;
    if (el.children.length !== 0) continue;              // فقط گرهٔ متنی ساده
    const txt = (el.innerText || '').trim();
    if (txt.length < 2) continue;
    const cs = getComputedStyle(el);
    // -webkit-line-clamp is a deliberate, ellipsis-capable truncation
    const clamped = cs.webkitLineClamp && cs.webkitLineClamp !== 'none';
    if (clamped) continue;
    if (cs.overflowX === 'hidden' && cs.textOverflow !== 'ellipsis' &&
        el.scrollWidth > el.clientWidth + 3) {
      clipped.push({ t: el.tagName.toLowerCase(), c: clsOf(el), i: el.id || '',
                     txt: txt.slice(0, 28), sw: el.scrollWidth, cw: el.clientWidth });
      if (clipped.length >= 8) break;
    }
  }
  res.clipped = clipped;

  // --- overlapping interactive elements ---
  // عناصر fixed عمداً روی محتوا هستند؛ عناصر کلیپ‌شده (خارج از box جدِ overflow-hidden)
  // هم دیده و هم کلیک نمی‌شوند → هر دو حذف، تا فقط تداخل واقعی گزارش شود.
  const clippedByAncestor = el => {
    let n = el.parentElement;
    const r0 = el.getBoundingClientRect();
    while (n) {
      const cs = getComputedStyle(n);
      if (cs.overflow !== 'visible') {
        const r = n.getBoundingClientRect();
        if (r0.top < r.top - 1 || r0.bottom > r.bottom + 1 ||
            r0.left < r.left - 1 || r0.right > r.right + 1) return true;
      }
      n = n.parentElement;
    }
    return false;
  };
  const inFixed = el => {
    let n = el.parentElement;
    while (n) {
      if (getComputedStyle(n).position === 'fixed') return true;
      n = n.parentElement;
    }
    return false;
  };
  const overlaps = [];
  const inter = [...document.querySelectorAll('a,button,[role="button"],input,select,summary')]
    .filter(el => vis(el) && getComputedStyle(el).position !== 'fixed' && !inFixed(el) && !clippedByAncestor(el));
  for (let i = 0; i < inter.length && overlaps.length < 6; i++) {
    for (let j = i + 1; j < inter.length; j++) {
      const a = inter[i], b = inter[j];
      if (a.contains(b) || b.contains(a)) continue;
      const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
      if (ra.width < 4 || rb.width < 4 || ra.height < 4 || rb.height < 4) continue;
      const ix = Math.max(0, Math.min(ra.right, rb.right) - Math.max(ra.left, rb.left));
      const iy = Math.max(0, Math.min(ra.bottom, rb.bottom) - Math.max(ra.top, rb.top));
      const area = ix * iy;
      const minA = Math.min(ra.width * ra.height, rb.width * rb.height);
      if (minA > 100 && area / minA > 0.35) {
        overlaps.push({ a: a.tagName.toLowerCase() + '.' + clsOf(a).slice(0, 22),
                        b: b.tagName.toLowerCase() + '.' + clsOf(b).slice(0, 22),
                        pct: Math.round(area / minA * 100) });
        break;
      }
    }
  }
  res.overlaps = overlaps;
  return res;
})()
"""

CSS_ORDER = ["tokens.css", "main.css", "pages.css", "mobile-refine.css",
             "mobile-standard.css", "theme-night.css", "theme-light.css"]


def css_lookup(tokens, limit=3):
    """ریشه‌یابی: کدام فایل/خط CSS این کلاس(ها) را تعریف کرده؟"""
    hits = []
    for tok in tokens:
        if not tok or len(tok) < 2:
            continue
        # فقط توکن‌های شبیه کلاس را در نظر بگیر
        for name in tok.split():
            if not (name.startswith(".") or name.startswith("#")):
                name = "." + name
            name = re.escape(name)
            for fname in CSS_ORDER:
                fp = CSS_DIR / fname
                if not fp.exists():
                    continue
                try:
                    lines = fp.read_text(encoding="utf-8", errors="ignore").splitlines()
                except OSError:
                    continue
                for i, line in enumerate(lines, 1):
                    if re.search(r"\{\s*$", line) and re.search(name, line):
                        hits.append(f"{fname}:{i}  {line.strip()[:52]}")
                        break
                if len(hits) >= limit:
                    return hits
    return hits


# ---------------------------------------------------------------- helpers
def owner_key():
    """کلید پنل مالک (بدون افشای آن در گزارش‌ها)."""
    sys.path.insert(0, str(ROOT / "server"))
    import db
    db.init()
    return db.owner_token()


def otp_code_from_html(html):
    m = re.search(r'letter-spacing:\.2em">\s*(\d{5})\s*</strong>', html)
    if m:
        return m.group(1)
    m = re.search(r'<strong[^>]*class="nums"[^>]*>\s*(\d{5})\s*</strong>', html)
    return m.group(1) if m else None


def clear_audit_ratelimit():
    """پاک‌کردن سهمیه‌های ورود آزمایشی (فقط محیط سندباکس؛ کلیدهای مخصوص همین تست)."""
    sys.path.insert(0, str(ROOT / "server"))
    import db
    db.init()
    con = db.connect()
    for prefix in ("pw:", "otp:", "otpip:"):
        con.execute("DELETE FROM ratelimit WHERE bucket LIKE ?", (prefix + "%",))
    con.commit()


def http_login(phone=None, username=None, password=None):
    """ورود دکان‌دار (ترجیحاً با نام کاربری/رمز — بدون سهمیهٔ OTP). برمی‌گرداند فهرست کوکی."""
    import http.cookiejar
    import urllib.request
    clear_audit_ratelimit()
    cj = http.cookiejar.CookieJar()
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    if username and password:
        req = urllib.request.Request(
            f"{BASE}/login/password",
            data=urllib.parse.urlencode({"username": username, "password": password}).encode(),
            headers={"Content-Type": "application/x-www-form-urlencoded"})
        try:
            op.open(req, timeout=15)
        except urllib.error.HTTPError as e:
            if e.code not in (302, 303):
                raise RuntimeError(f"ورود با رمز نشد: HTTP {e.code}")
    else:
        if not phone:
            raise RuntimeError("برای ورود یا username/password بده یا phone")
        req = urllib.request.Request(
            f"{BASE}/login",
            data=urllib.parse.urlencode({"phone": phone}).encode(),
            headers={"Content-Type": "application/x-www-form-urlencoded"})
        html = op.open(req, timeout=15).read().decode("utf-8", "ignore")
        code = otp_code_from_html(html)
        if not code:
            raise RuntimeError("کد OTP در پاسخ پیدا نشد — شاید سهمیه پر است یا site_url تنظیم شده")
        req2 = urllib.request.Request(
            f"{BASE}/login/verify",
            data=urllib.parse.urlencode({"phone": phone, "code": code}).encode(),
            headers={"Content-Type": "application/x-www-form-urlencoded"})
        op.open(req2, timeout=15)
    out = []
    for c in cj:
        out.append({"name": c.name, "value": c.value,
                    "domain": "127.0.0.1", "path": c.path or "/"})
    if not out:
        raise RuntimeError("ورود انجام نشد — کوکی‌ای ساخته نشد")
    return out


def http_admin_cookies(key):
    """ورود پنل با کلید → کوکی bzv2_admin."""
    import http.cookiejar
    import urllib.request
    cj = http.cookiejar.CookieJar()
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    try:
        op.open(f"{BASE}/panel?key={key}", timeout=15)
    except urllib.error.HTTPError as e:
        if e.code not in (302, 303):
            raise
    return [{"name": c.name, "value": c.value,
             "domain": "127.0.0.1", "path": c.path or "/"} for c in cj]


def new_context(browser, group, key, owner_phone):
    """ساخت context با کوکی‌های احراز لازم برای هر گروه (ورود با urllib، بدون race).
    NOTE: در نسخهٔ async فقط کوکی‌ها را از اینجا می‌گیریم؛ ساخت context در کالر async است."""
    cookies = []
    if group == "panel":
        cookies = http_admin_cookies(key)
    elif group in ("owner", "customer"):
        cookies = http_login(username=os.environ.get("BZ_USER", "audit"),
                             password=os.environ.get("BZ_PASS", "Audit123!"))
    return cookies


def stitch_and_save(chunks, path, max_side=6000, quality=62):
    """دوختن برش‌های اسکرین‌شات و ذخیرهٔ webp (برای صفحات خیلی بلند)."""
    if len(chunks) == 1:
        img = chunks[0]
    else:
        w = chunks[0].width
        h = sum(c.height for c in chunks)
        img = Image.new("RGB", (w, h), "white")
        y = 0
        for c in chunks:
            img.paste(c, (0, y))
            y += c.height
            c.close()
    if max(img.size) > max_side:
        img.thumbnail((max_side, max_side), Image.LANCZOS)
    img.save(path, "WEBP", quality=quality, method=4)
    return img.size


def thumb_b64(path, width=360, quality=58):
    img = Image.open(path).convert("RGB")
    img.thumbnail((width, width), Image.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, "WEBP", quality=quality, method=4)
    return "data:image/webp;base64," + base64.b64encode(buf.getvalue()).decode()


class AuditRunner:
    def __init__(self, out_dir, viewports, want_shots=True, resume=False):
        self.out = Path(out_dir)
        self.shots_dir = self.out / "shots"
        self.tasks_dir = self.out / "tasks"
        self.shots_dir.mkdir(parents=True, exist_ok=True)
        self.tasks_dir.mkdir(parents=True, exist_ok=True)
        self.viewports = [v for v in VIEWPORTS if v[0] in viewports]
        self.want_shots = want_shots
        self.resume = resume
        self.key = owner_key()
        self.owner_phone = os.environ.get("BZ_OWNER", "09120000001")

    async def _shot_page(self, page, path):
        """اسکرین‌شات تمام‌صفحه با اسکرول+دوختن (مقاوم در RAM کم؛ کرومیوم برای
        ناحیهٔ خارج از viewport تایل رندر نمی‌کند، پس همیشه از viewport عکس می‌گیریم)."""
        size_js = ("() => Math.max(document.body ? document.body.scrollHeight : 0, "
                   "document.documentElement.scrollHeight)")
        h = int(await page.evaluate(size_js) or 0)
        if h < 200:                                # صفحه هنوز خالی است → صبر و تلاش دوباره
            await page.wait_for_timeout(900)
            h = int(await page.evaluate(size_js) or 0)
        if h < 200:
            raise RuntimeError(f"صفحه هنوز خالی (h={h}) — عکس گرفته نشد")
        await page.evaluate("window.scrollTo(0, 0)")
        chunks = []
        y = 0
        guard = 0
        bottom_stable = 0
        last_sy = -1
        stuck = 0
        while guard < 40:
            await page.evaluate(f"window.scrollTo(0, {y})")
            await page.wait_for_timeout(60)        # اجازهٔ paint
            sy = int(await page.evaluate("window.scrollY") or 0)
            if sy <= last_sy:
                stuck += 1
            else:
                stuck = 0
            last_sy = sy
            raw = await page.screenshot(type="jpeg", quality=85)   # فقط viewport
            im = Image.open(io.BytesIO(raw)).convert("RGB")
            chunks.append(im)
            y += im.height
            guard += 1
            cur = int(await page.evaluate(size_js) or 0)
            if sy + im.height >= cur:              # ته صفحه دیده شد
                bottom_stable += 1
                if bottom_stable >= 2:             # دو بار پیاپی = رشد دیرهنگام جذب شد
                    break
            else:
                bottom_stable = 0
            if stuck >= 2:                         # اسکرول جلو نمی‌رود (ته یا اسکرول داخلی)
                break
        if not chunks:
            raise RuntimeError("چانکی ساخته نشد")
        h = int(await page.evaluate(size_js) or 0) or y
        # حذف نوار سفیدِ اضافهٔ انتهای چانک آخر (چون اسکرول بیش از سقف می‌رود)
        total = sum(c.height for c in chunks)
        if total > h:
            over = min(total - h, chunks[-1].height - 1)
            if over > 0:
                last = chunks[-1]
                chunks[-1] = last.crop((0, 0, last.width, last.height - over))
                last.close()
        return stitch_and_save(chunks, path)

    async def _make_context(self, browser, group):
        ctx = await browser.new_context(
            viewport={"width": 390, "height": 844},
            locale="fa-IR",
            device_scale_factor=1,
            reduced_motion="reduce",
        )
        await ctx.add_init_script("""
          // توجه: در لحظهٔ اجرای init script هنوز documentElement ساخته نشده است
          // (readyState=loading و head=null)؛ پس تزریق را تا DOMContentLoaded به تعویق می‌اندازیم.
          window.__AUDIT_INIT = true;
          const __auditInject = () => {
            const st = document.createElement('style');
            // مرورگرِ ممیزی (Chromium 151) بسته‌شدن <details> را اعمال نمی‌کند؛
            // رفتار مرورگر واقعی را بازمی‌گردانیم تا شات/متریک‌ها با واقعیت یکی باشد.
            st.textContent = '*{animation:none !important;transition:none !important;scroll-behavior:auto !important}' +
              'details:not([open]) > :not(summary){display:none !important}';
            document.documentElement.appendChild(st);
          };
          if (document.documentElement) __auditInject();
          else document.addEventListener('DOMContentLoaded', __auditInject, { once: true });
        """)
        auth = "panel" if group == "panel" else group
        cookies = new_context(None, auth, self.key, self.owner_phone)  # فقط کوکی‌ها
        if cookies:
            await ctx.add_cookies(cookies)
        return ctx

    # ---- یک صفحه × همهٔ عرض‌ها (هر تسک یک context مستقل دارد) ----
    async def audit_page(self, ctx, group, name, path, shot_lock):
        task_key = f"{group}/{name}"
        result = {"group": group, "name": name, "path": path, "views": {}, "error": None}
        saved_path = self.tasks_dir / (task_key.replace("/", "__") + ".json")
        if self.resume and saved_path.exists():
            return json.loads(saved_path.read_text(encoding="utf-8"))

        page = await ctx.new_page()
        page.set_default_timeout(20000)
        bag = {"msgs": []}
        page.on("console", lambda m: bag["msgs"].append(m.text[:160]) if m.type == "error" else None)
        page.on("pageerror", lambda e: bag["msgs"].append(str(e)[:160]))
        try:
            for vp, w, h, dsf in self.viewports:
                view = {"status": None, "final_url": None, "metrics": None,
                        "console": [], "shot": None, "err": None}
                await page.set_viewport_size({"width": w, "height": h})
                bag["msgs"].clear()
                try:
                    resp = await page.goto(BASE + path, wait_until="domcontentloaded", timeout=20000)
                    await page.wait_for_timeout(350)
                    view["status"] = resp.status if resp else -1
                    view["final_url"] = page.url
                    # فونت‌ها باید کامل لود شوند تا چیدمان پایدار شود؛ وگرنه متریک‌های
                    # هم‌پوشانی/بریدگی روی حالت موقتِ mid-load خطای کاذب می‌دهند.
                    try:
                        await page.evaluate("Promise.race([document.fonts.ready.then(()=>true), new Promise(r=>setTimeout(()=>r(false),2500))])")
                    except Exception:
                        pass
                    try:
                        view["metrics"] = await page.evaluate(METRICS_JS)
                    except Exception:
                        # فلک: context وسط اندازه‌گیری از بین رفت → یک بار دیگر
                        await page.wait_for_timeout(700)
                        view["metrics"] = await page.evaluate(METRICS_JS)
                    # ضد باگ «صفحهٔ خالی» در همروندی: یک بار دیگر اندازه بگیر
                    if view["metrics"] and view["metrics"].get("textLen", 0) < 60:
                        await page.wait_for_timeout(800)
                        view["metrics"] = await page.evaluate(METRICS_JS)
                    view["console"] = list(bag["msgs"])
                    if self.want_shots:
                        try:
                            shots_path = self.shots_dir / group / f"{name}@{vp}.webp"
                            shots_path.parent.mkdir(parents=True, exist_ok=True)
                            # صفحات خیلی بلند → اسکرین‌شات چانکی (برش ۴۰۰۰px + دوختن)
                            # تا renderer در RAM کم سندباکس کرش نکند
                            async with shot_lock:
                                dims = await self._shot_page(page, shots_path)
                            view["shot"] = str(shots_path.relative_to(self.out))
                            view["shot_dims"] = dims
                        except Exception as e:
                            view["shot_err"] = f"{type(e).__name__}: {e}"
                except Exception as e:
                    view["err"] = f"{type(e).__name__}: {str(e)[:200]}"
                result["views"][vp] = view
                print(f"  {task_key} @{vp} status={view['status']} "
                      f"overflow={view['metrics']['overflow'] if view['metrics'] else '?'} "
                      f"tap={len(view['metrics']['tapSmall']) if view['metrics'] else '?'}", flush=True)
        except Exception as e:
            result["error"] = f"{type(e).__name__}: {str(e)[:200]}"
            print(f"  !! {task_key}: {result['error']}", flush=True)
        finally:
            await page.close()
        saved_path.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
        return result

    async def _run_async(self, groups, max_pages, workers):
        import asyncio
        # هر گروه یک context (پنل هم یک شارد — حافظهٔ سندباکس محدود است)
        spec = {}
        for g in groups:
            pages = list(GROUPS[g])
            if max_pages:
                pages = pages[:max_pages]
            spec[g] = (pages, 1)
        tasks = []
        for g, (pages, nsh) in spec.items():
            for s in range(nsh):
                for i, (name, path) in enumerate(pages):
                    if i % nsh == s:
                        tasks.append(((g, s), name, path))
        print(f"📸 شروع ممیزی: {len(tasks)} صفحه × {len(self.viewports)} عرض = "
              f"{len(tasks) * len(self.viewports)} اسکرین‌شات", flush=True)
        t0 = time.time()
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(
                headless=True,
                args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu", "--disable-extensions",
                      "--js-flags=--max-old-space-size=512"])
            contexts = {}
            remaining = {g: sum(1 for (gg, _s), _n, _p in tasks if gg == g) for g in spec}
            ctx_guard = asyncio.Lock()
            ctx_locks = {g: asyncio.Lock() for g in spec}   # هر context فقط یک task هم‌زمان
            shot_lock = asyncio.Lock()
            sem = asyncio.Semaphore(max(1, workers))

            async def get_ctx(g):
                async with ctx_guard:
                    if g not in contexts:
                        contexts[g] = await self._make_context(browser, g)
                    return contexts[g]

            async def worker(t):
                (g, s), name, path = t
                async with sem:
                    ctx = await get_ctx(g)
                    async with ctx_locks[g]:
                        try:
                            return await self.audit_page(ctx, g, name, path, shot_lock)
                        finally:
                            # بستن context گروه وقتی همهٔ صفحه‌هایش تمام شد (صرفه‌جویی RAM)
                            async with ctx_guard:
                                remaining[g] -= 1
                                if remaining[g] <= 0 and g in contexts:
                                    await contexts.pop(g).close()

            results = await asyncio.gather(*(worker(t) for t in tasks),
                                           return_exceptions=True)
            for c in contexts.values():
                try:
                    await c.close()
                except Exception:
                    pass
            await browser.close()
        out = []
        for t, r in zip(tasks, results):
            (g, s), name, path = t
            if isinstance(r, Exception):
                out.append({"group": g, "name": name, "path": path, "views": {},
                            "error": f"{type(r).__name__}: {r}"})
                print(f"  !! task {g}/{name} crashed: {r}", flush=True)
            else:
                out.append(r)
        print(f"⏱ ممیزی در {time.time() - t0:.0f} ثانیه تمام شد.", flush=True)
        return out

    def run(self, groups, max_pages=None, workers=2):
        import asyncio
        return asyncio.run(self._run_async(groups, max_pages, workers))


# ---------------------------------------------------------------- report
SEV_ORDER = {"err": 0, "warn": 1, "info": 2}
SEV_FA = {"err": "خطا", "warn": "هشدار", "info": "اطلاع"}


def analyze(results):
    """تبدیل نتایج به فهرست مشکلات با شدت و ریشه‌یابی."""
    issues = []  # هر مورد: {sev, group, page, path, vp, metric, detail, fix, css}
    per_page = {}
    for r in results:
        pp = per_page.setdefault(r["group"] + "/" + r["name"],
                                 {"group": r["group"], "name": r["name"], "path": r.get("path", ""),
                                  "views": {}, "issues": []})
        for vp, v in r.get("views", {}).items():
            m = v.get("metrics") or {}
            pp["views"][vp] = {"status": v.get("status"), "final_url": v.get("final_url")}
            if v.get("err"):
                issues.append(dict(sev="err", group=r["group"], page=r["name"], path=r.get("path"),
                                   vp=vp, metric="load", detail=v["err"], fix="بررسی دستی — صفحه بارگذاری نشد", css=[]))
            st = v.get("status") or 0
            if st >= 500:
                issues.append(dict(sev="err", group=r["group"], page=r["name"], path=r.get("path"),
                                   vp=vp, metric="http", detail=f"HTTP {st}",
                                   fix="باگ سرور — traceback در کنسول سرور", css=[]))
            elif st == 404:
                issues.append(dict(sev="warn", group=r["group"], page=r["name"], path=r.get("path"),
                                   vp=vp, metric="http", detail="HTTP 404 — صفحه وجود ندارد",
                                   fix="مسیر را در app.py چک کن یا از فهرست حذف کن", css=[]))
            if m.get("overflow", 0) > 1:
                is_mob = vp in MOBILE
                sev = "err" if is_mob else "warn"
                els = m.get("overflowEls", [])[:4]
                detail = f"سرریز افقی {m['overflow']}px" + ("".join(
                    f" | {e['t']}.{e['c'][:40]} (right+{e['r']}px, w={e['w']})" for e in els))
                css = css_lookup([e["c"] for e in els])
                issues.append(dict(sev=sev, group=r["group"], page=r["name"], path=r.get("path"),
                                   vp=vp, metric="overflow", detail=detail,
                                   fix="عرض مقصر را محدود کن (max-width:100%) یا از inset-inline/چیدمان RTL درست استفاده کن",
                                   css=css))
            if vp in MOBILE and m.get("tapSmall"):
                small = [t for t in m["tapSmall"] if t["h"] < 32 or t["w"] < 32]
                sev = "err" if small else "warn"
                detail = "؛ ".join(f"{t['t']}.{t['c'][:34]} {t['w']}×{t['h']}px ({t['name'][:20]})" for t in m["tapSmall"][:5])
                css = css_lookup([t["c"] for t in m["tapSmall"]])
                issues.append(dict(sev=sev, group=r["group"], page=r["name"], path=r.get("path"),
                                   vp=vp, metric="tap", detail=detail,
                                   fix="هدف لمسی را ≥44px کن (padding/min-height/مین‌موم 44×44؛ الگوی کنترل شبح مجاز)",
                                   css=css))
            if m.get("smallFonts"):
                detail = "؛ ".join(f"{f['t']}.{f['c'][:34]} {f['fs']}px «{f['txt'][:22]}»" for f in m["smallFonts"][:5])
                css = css_lookup([f["c"] for f in m["smallFonts"]])
                issues.append(dict(sev="warn", group=r["group"], page=r["name"], path=r.get("path"),
                                   vp=vp, metric="font", detail=detail,
                                   fix="کف متن ۱۲px — فونت‌سایز را بالا بیاور (11→12px یا بیشتر)",
                                   css=css))
            if m.get("imgsNoAlt"):
                detail = "؛ ".join(i["src"][-44:] for i in m["imgsNoAlt"][:5])
                issues.append(dict(sev="warn", group=r["group"], page=r["name"], path=r.get("path"),
                                   vp=vp, metric="alt", detail=f"{len(m['imgsNoAlt'])} تصویر بدون alt: {detail}",
                                   fix="alt توصیفی کوتاه به img بده (یا alt=\"\" برای تزئینی)", css=[]))
            if m.get("iconOnly"):
                detail = "؛ ".join(f"{i['t']}.{i['c'][:34]} {i['w']}×{i['h']}" for i in m["iconOnly"][:5])
                css = css_lookup([i["c"] for i in m["iconOnly"]])
                issues.append(dict(sev="warn", group=r["group"], page=r["name"], path=r.get("path"),
                                   vp=vp, metric="a11y", detail=f"دکمهٔ فقط-آیکون بدون نام: {detail}",
                                   fix="aria-label یا title یا متن داخل دکمه اضافه کن (استاندارد a11y)",
                                   css=css))
            if m.get("textLen", 1) < 60:
                issues.append(dict(sev="warn", group=r["group"], page=r["name"], path=r.get("path"),
                                   vp=vp, metric="blank", detail="صفحه تقریباً خالی است",
                                   fix="بررسی کن محتوا چرا رندر نمی‌شود (دیتا/مجوز/خطای JS)", css=[]))
            if m.get("clipped"):
                detail = "؛ ".join(f"{c['t']}.{c['c'][:30]} «{c['txt'][:18]}» ({c['cw']}<{c['sw']})" for c in m["clipped"][:4])
                css = css_lookup([c["c"] for c in m["clipped"]])
                issues.append(dict(sev="warn", group=r["group"], page=r["name"], path=r.get("path"),
                                   vp=vp, metric="clip", detail="متن بریده‌شده (بدون …): " + detail,
                                   fix="عرض/پدینگ عنصر را زیاد کن یا text-overflow:ellipsis بگذار",
                                   css=css))
            if m.get("overlaps"):
                detail = "؛ ".join(f"{o['a']} ⨯ {o['b']} ({o['pct']}%)" for o in m["overlaps"][:4])
                ov = m["overlaps"][0]
                css = css_lookup([ov["a"].split(".")[1] if "." in ov["a"] else "",
                                  ov["b"].split(".")[1] if "." in ov["b"] else ""])
                issues.append(dict(sev="warn", group=r["group"], page=r["name"], path=r.get("path"),
                                   vp=vp, metric="overlap", detail="تداخل عناصر تعاملی: " + detail,
                                   fix="موقعیت/حاشیهٔ دو عنصر را جدا کن (z-index/inset/فاصله)", css=css))
            if v.get("console"):
                detail = " | ".join(v["console"][:3])
                issues.append(dict(sev="warn", group=r["group"], page=r["name"], path=r.get("path"),
                                   vp=vp, metric="console", detail=detail,
                                   fix="خطای JS را رفع کن (با node --check و کنسول مرورگر)", css=[]))
        for it in issues:
            if it["page"] == pp["name"] and it["group"] == pp["group"]:
                pp["issues"].append(it)
    return issues, per_page


def build_report(out_dir, results, issues, per_page, duration):
    out = Path(out_dir)
    total_shots = sum(len(r.get("views", {})) for r in results)
    n_err = sum(1 for i in issues if i["sev"] == "err")
    n_warn = sum(1 for i in issues if i["sev"] == "warn")
    pages_with_issue = sorted({i["group"] + "/" + i["page"] for i in issues})

    groups_fa = {"public": "عمومی", "panel": "پنل مدیریت", "owner": "پنل دکان‌دار", "customer": "پنل مشتری"}
    vp_fa = {"m320": "۳۲۰", "m360": "۳۶۰", "m390": "۳۹۰", "m412": "۴۱۲",
             "d1366": "۱۳۶۶", "d1440": "۱۴۴۰", "d1920": "۱۹۲۰"}

    def sev_cls(s):
        return {"err": "se-err", "warn": "se-warn", "info": "se-info"}[s]

    def shot_b64(group, page, vp):
        p = out / "shots" / group / f"{page}@{vp}.webp"
        if p.exists():
            try:
                return thumb_b64(p, width=330)
            except Exception:
                return None
        return None

    cards = ""
    for g in GROUPS:
        n_pages = sum(1 for r in results if r["group"] == g)
        n_iss = sum(1 for i in issues if i["group"] == g)
        cards += (f'<div class="card"><div class="card-n">{n_pages}</div>'
                  f'<div class="card-t">{groups_fa[g]}</div>'
                  f'<div class="card-s {"bad" if n_iss else "ok"}">{n_iss} مشکل</div></div>')

    # جدول وضعیت هر صفحه
    rows = ""
    for g in GROUPS:
        gres = [r for r in results if r["group"] == g]
        if not gres:
            continue
        rows += f'<tr class="grp"><td colspan="{2 + len(VIEWPORTS)}">{groups_fa[g]}</td></tr>'
        for r in sorted(gres, key=lambda x: x["name"]):
            st_tds = ""
            for vp, _, _, _ in VIEWPORTS:
                v = r.get("views", {}).get(vp)
                if not v:
                    st_tds += '<td class="st st-na">—</td>'
                    continue
                st = v.get("status")
                m = (v.get("metrics") or {})
                cls = "st-ok"
                if v.get("err") or (st or 0) >= 500:
                    cls = "st-err"
                elif st == 404 or m.get("overflow", 0) > 1 or (vp in MOBILE and m.get("tapSmall")):
                    cls = "st-warn"
                elif m.get("smallFonts") or v.get("console") or m.get("iconOnly") or m.get("imgsNoAlt"):
                    cls = "st-warn"
                st_tds += f'<td class="st {cls}" title="{st}">{st or "?"}</td>'
            nm = r["name"]
            n_iss = sum(1 for i in issues if i["group"] == g and i["page"] == r["name"])
            rows += (f'<tr><td class="pname"><a href="#iss-{g}-{nm}">{nm}</a>'
                     f'</td><td class="pcount {"bad" if n_iss else "ok"}">{n_iss}</td>{st_tds}</tr>')

    # کارت‌های مشکل
    iss_html = ""
    for i, it in enumerate(sorted(issues, key=lambda x: (SEV_ORDER[x["sev"]], x["group"], x["page"]))):
        vp_label = vp_fa.get(it["vp"], it["vp"])
        css_txt = ""
        if it.get("css"):
            css_txt = '<div class="css">🎯 ریشه: ' + " · ".join(f"<code>{c}</code>" for c in it["css"][:2]) + "</div>"
        thumb = shot_b64(it["group"], it["page"], it["vp"])
        img = f'<img src="{thumb}" alt="screen {it["group"]}/{it["page"]}">' if thumb else ""
        iss_html += f'''
        <div class="issue" id="iss-{it["group"]}-{it["page"]}">
          <div class="iss-head"><span class="sev {sev_cls(it["sev"])}">{SEV_FA[it["sev"]]}</span>
            <span class="iss-where">{groups_fa[it["group"]]} · {it["page"]} · {vp_label}px</span>
            <span class="iss-metric">{it["metric"]}</span></div>
          <div class="iss-body"><div class="iss-detail">{it["detail"]}</div>
            {css_txt}
            <div class="iss-fix">🔧 پیشنهاد: {it["fix"]}</div></div>
          <div class="iss-shot">{img}</div>
        </div>'''

    html = f"""<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ممیزی دیزاین دست گیر — {time.strftime('%Y-%m-%d')}</title>
<style>
  :root{{--bg:#f4f6f8;--card:#fff;--ink:#1c2530;--mut:#5b6b7b;--line:#dfe5ea;
        --blue:#1a5fb4;--err:#c0392b;--warn:#b9770e;--ok:#1e8449}}
  *{{box-sizing:border-box}} body{{margin:0;background:var(--bg);color:var(--ink);
        font:14px/1.7 Vazirmatn, Tahoma, sans-serif}}
  .wrap{{max-width:1100px;margin:0 auto;padding:24px}}
  h1{{font-size:22px;margin:0 0 4px}} .sub{{color:var(--mut);font-size:13px;margin-bottom:18px}}
  .cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:18px 0}}
  .card{{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px;text-align:center}}
  .card-n{{font-size:26px;font-weight:700}} .card-t{{color:var(--mut);font-size:12px}}
  .card-s{{font-size:12px;margin-top:4px}} .card-s.bad{{color:var(--err)}} .card-s.ok{{color:var(--ok)}}
  table{{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);
        border-radius:12px;overflow:hidden;font-size:12px}}
  th,td{{padding:5px 8px;border-bottom:1px solid var(--line);text-align:center}}
  tr.grp td{{background:#e8eef5;font-weight:700;text-align:right;font-size:12px}}
  td.pname{{text-align:right;font-weight:600;max-width:170px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}
  td.pcount{{font-weight:700}} td.pcount.bad{{color:var(--err)}} td.pcount.ok{{color:var(--ok)}}
  .st{{font-size:11px}} .st-ok{{color:var(--ok)}} .st-warn{{color:var(--warn)}} .st-err{{color:var(--err);font-weight:700}}
  .st-na{{color:#b3bcc4}}
  h2{{font-size:17px;margin:26px 0 10px}}
  .issue{{background:var(--card);border:1px solid var(--line);border-radius:12px;margin:10px 0;padding:12px}}
  .iss-head{{display:flex;gap:8px;align-items:center;flex-wrap:wrap}}
  .sev{{font-size:11px;font-weight:700;padding:2px 10px;border-radius:99px;color:#fff}}
  .se-err{{background:var(--err)}} .se-warn{{background:var(--warn)}} .se-info{{background:var(--blue)}}
  .iss-where{{font-weight:700;font-size:13px}} .iss-metric{{background:#eef2f6;border-radius:6px;
        padding:1px 8px;font-size:11px;color:var(--mut)}}
  .iss-body{{margin-top:8px;font-size:13px}} .iss-detail{{direction:ltr;text-align:left;font-size:12px;
        background:#fafbfc;border:1px dashed var(--line);border-radius:8px;padding:8px;overflow-x:auto}}
  .css{{margin-top:6px;font-size:12px;color:var(--blue)}} .css code{{background:#eef2f6;border-radius:4px;padding:1px 5px}}
  .iss-fix{{margin-top:6px;font-size:12px;color:#14532d}}
  .iss-shot img{{width:100%;max-width:330px;border:1px solid var(--line);border-radius:8px;margin-top:8px}}
  .foot{{color:var(--mut);font-size:12px;margin:24px 0}}
</style></head>
<body><div class="wrap">
  <h1>📐 ممیزی جامع دیزاین — «دست گیر»</h1>
  <div class="sub">{time.strftime('%Y-%m-%d %H:%M')} · سرور: <code>{BASE}</code> · {len(results)} صفحه · {total_shots} اسکرین‌شات · {duration:.0f} ثانیه</div>
  <div class="cards">{cards}
    <div class="card"><div class="card-n" style="color:var(--err)">{n_err}</div><div class="card-t">خطا</div></div>
    <div class="card"><div class="card-n" style="color:var(--warn)">{n_warn}</div><div class="card-t">هشدار</div></div>
    <div class="card"><div class="card-n">{len(pages_with_issue)}</div><div class="card-t">صفحهٔ دارای مشکل</div></div>
  </div>
  <h2>وضعیت هر صفحه (کد وضعیت HTTP در هر عرض؛ رنگی = مشکل)</h2>
  <table><thead><tr><th>صفحه</th><th>مشکل</th>
    {"".join(f"<th>{vp_fa[v]}</th>" for v, _, _, _ in VIEWPORTS)}</tr></thead>
  <tbody>{rows}</tbody></table>
  <h2>مشکلات ({len(issues)}) — با ریشه‌یابی و پیشنهاد</h2>
  {iss_html}
  <div class="foot">گالری کامل: gallery-public.html · gallery-panel.html · gallery-owner.html · gallery-customer.html
  — اسکرین‌شات‌های تمام‌اندازه: پوشهٔ shots/ — دادهٔ خام: data.json</div>
</div></body></html>"""
    (out / "report.html").write_text(html, encoding="utf-8")
    return len(html)


def build_gallery(out_dir, results, group):
    out = Path(out_dir)
    groups_fa = {"public": "عمومی", "panel": "پنل مدیریت", "owner": "پنل دکان‌دار", "customer": "پنل مشتری"}
    vp_fa = {"m320": "۳۲۰", "m360": "۳۶۰", "m390": "۳۹۰", "m412": "۴۱۲",
             "d1366": "۱۳۶۶", "d1440": "۱۴۴۰", "d1920": "۱۹۲۰"}
    blocks = ""
    for r in sorted([x for x in results if x["group"] == group], key=lambda x: x["name"]):
        cells = ""
        for vp, _, _, _ in VIEWPORTS:
            p = out / "shots" / group / f"{r['name']}@{vp}.webp"
            if p.exists():
                try:
                    cells += (f'<figure><img src="{thumb_b64(p, width=300, quality=55)}" '
                              f'alt="{r["name"]} {vp}"><figcaption>{vp_fa[vp]}</figcaption></figure>')
                except Exception:
                    cells += f'<figure><figcaption>{vp_fa[vp]} — خطا</figcaption></figure>'
            else:
                cells += f'<figure><figcaption>{vp_fa[vp]} — ندارد</figcaption></figure>'
        blocks += f'<div class="page"><h3>{r["name"]} <small>{r.get("path","")}</small></h3><div class="shots">{cells}</div></div>'
    html = f"""<!DOCTYPE html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>گالری {groups_fa[group]} — ممیزی دیزاین</title>
<style>
  body{{margin:0;background:#f4f6f8;color:#1c2530;font:14px/1.7 Vazirmatn,Tahoma,sans-serif}}
  .wrap{{max-width:1200px;margin:0 auto;padding:20px}}
  h1{{font-size:20px}} .page{{background:#fff;border:1px solid #dfe5ea;border-radius:12px;margin:14px 0;padding:12px}}
  h3{{margin:0 0 8px;font-size:15px}} h3 small{{color:#5b6b7b;font-size:11px;direction:ltr;unicode-bidi:embed}}
  .shots{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}}
  figure{{margin:0;text-align:center}} img{{width:100%;border:1px solid #dfe5ea;border-radius:8px}}
  figcaption{{font-size:11px;color:#5b6b7b;margin-top:4px}}
</style></head><body><div class="wrap">
<h1>🖼 گالری {groups_fa[group]} — {len([r for r in results if r['group'] == group])} صفحه × ۷ عرض</h1>
{blocks}
</div></body></html>"""
    (out / f"gallery-{group}.html").write_text(html, encoding="utf-8")


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description="ممیزی جامع دیزاین دست گیر")
    ap.add_argument("--out", default=DEFAULT_OUT, help=f"پوشهٔ خروجی (پیش‌فرض {DEFAULT_OUT})")
    ap.add_argument("--groups", default="public,panel,owner,customer")
    ap.add_argument("--viewports", default="m320,m360,m390,m412,d1366,d1440,d1920")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--smoke", action="store_true", help="فقط ۳ صفحهٔ اول هر گروه")
    ap.add_argument("--max-pages", type=int, default=None)
    ap.add_argument("--resume", action="store_true", help="ادامه از نتایج ذخیره‌شده")
    ap.add_argument("--skip-shots", action="store_true", help="فقط سنجه بدون عکس")
    args = ap.parse_args()

    groups = [g.strip() for g in args.groups.split(",") if g.strip() in GROUPS]
    viewports = set(v.strip() for v in args.viewports.split(",") if v.strip())
    viewports = [v for v, _, _, _ in VIEWPORTS if v in viewports]
    if not viewports:
        sys.exit("عرض معتبر نیست")
    if args.smoke:
        args.max_pages = 3

    runner = AuditRunner(args.out, viewports, want_shots=not args.skip_shots, resume=args.resume)
    t0 = time.time()
    results = runner.run(groups, max_pages=args.max_pages)

    # گزارش حتی با خطا
    issues, per_page = analyze(results)
    build_report(args.out, results, issues, per_page, time.time() - t0)
    for g in groups:
        build_gallery(args.out, results, g)
    (Path(args.out) / "data.json").write_text(
        json.dumps({"results": results, "issues": issues}, ensure_ascii=False, indent=1),
        encoding="utf-8")

    n_err = sum(1 for i in issues if i["sev"] == "err")
    n_warn = sum(1 for i in issues if i["sev"] == "warn")
    print("\n" + "=" * 60)
    print(f"✅ ممیزی تمام شد: {len(results)} صفحه، {n_err} خطا، {n_warn} هشدار")
    print(f"📄 گزارش: {args.out}/report.html")
    print("=" * 60)


if __name__ == "__main__":
    main()
