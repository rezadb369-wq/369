#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Audit: find UI that LOOKS interactive but is not wired to anything.
Scans every rendered page for buttons/forms/links and checks whether the
action they claim to perform actually has a route behind it.
"""

import os
import re
import sys
import urllib.parse
import urllib.request
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db

BASE = os.environ.get("BZ", "http://127.0.0.1:8080")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


class C:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        self.op = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.jar), NoRedirect())

    def get(self, p):
        try:
            r = self.op.open(urllib.request.Request(BASE + p), timeout=20)
            return r.getcode(), r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")
        except Exception as e:
            return 0, str(e)

    def post(self, p, d):
        body = urllib.parse.urlencode(d, doseq=True).encode()
        req = urllib.request.Request(BASE + p, data=body, headers={
            "Content-Type": "application/x-www-form-urlencoded"})
        try:
            r = self.op.open(req, timeout=20)
            return r.getcode(), r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")
        except Exception as e:
            return 0, str(e)


def code_for(phone):
    con = db.connect()
    r = con.execute("SELECT code FROM otp WHERE phone=?",
                    (db.norm_phone(phone),)).fetchone()
    con.close()
    return r["code"] if r else ""


DEAD = []
LIVE = []


def scan(html, page):
    """Find controls with no destination."""
    # buttons that are type=button, outside a form, with no data-* handler
    for m in re.finditer(r'<button\b([^>]*)>(.*?)</button>', html, re.S):
        attrs, inner = m.group(1), m.group(2)
        txt = re.sub(r"<[^>]+>", "", inner).strip()[:34]
        if 'type="submit"' in attrs:
            continue
        has_hook = any(k in attrs for k in (
            "data-", "onclick", "aria-controls", "data-modal-open"))
        if not has_hook and 'type="button"' in attrs:
            DEAD.append((page, "button", txt or "(بی‌متن)"))

    # links pointing nowhere
    for m in re.finditer(r'<a\b[^>]*href="(#|javascript:void\(0\)|)"[^>]*>(.*?)</a>',
                         html, re.S):
        txt = re.sub(r"<[^>]+>", "", m.group(2)).strip()[:34]
        DEAD.append((page, "link", txt or "(بی‌متن)"))

    # forms with no action
    for m in re.finditer(r'<form\b([^>]*)>', html):
        if "action=" not in m.group(1):
            DEAD.append((page, "form", "بدون action"))


def main():
    tok = db.owner_token()
    a = C()          # admin
    g = C()          # guest
    o = C()          # shop owner

    # seed data so pages are not empty
    a.post("/panel/business/new", {
        "key": tok, "name": "کبابی آزمون", "cat_slug": "restaurant",
        "descr": "برای ممیزی رابط کاربری.", "phone": "03142600000",
        "address": "خیابان تست", "status": "published",
        "h_sat_open": "10:00", "h_sat_close": "22:00"})
    biz = db.businesses(status=None)
    bid = biz[0]["id"] if biz else 0
    slug = biz[0]["slug"] if biz else ""
    a.post(f"/panel/catalog/{bid}/item/new", {
        "key": tok, "kind": "product", "title": "کالای آزمون",
        "price_type": "fixed", "price": "100000", "available": "on"})
    g.post(f"/b/{slug}/review", {"author": "ممیز", "rating": "5",
                                 "body": "متن نظر برای آزمون رابط."})
    g.post("/contact", {"name": "ممیز", "email": "a@b.ir",
                        "subject": "تست", "body": "متن پیام برای آزمون."})
    a.post("/panel/post/new", {"key": tok, "title": "خبر آزمون",
                               "excerpt": "خلاصه", "body": "متن خبر."})

    PH = "09121110000"
    # v208: ورود پیام‌رسانی + ثبت از ویزارد؛ نشست و رکورد مستقیم ساخته می‌شوند
    _own = db.owner_by_phone(PH, create=True); db.customer_by_phone(PH, create=True)
    import http.cookiejar as _cj
    o.jar.set_cookie(_cj.Cookie(0, "bzv2_sess", db.session_new(_own["id"]), None, False, "127.0.0.1", False, False,
                                "/", True, False, None, False, None, None, {}))
    if not db.businesses_of(_own["id"]):
        db.save_business({"name": "دکانٔ ممیز", "cat_slug": "shopping", "descr": "برای ممیزی پنل فروشنده ساخته شد.",
                          "phone": PH, "address": "نشانی ممیزی", "status": "pending", "owner_id": _own["id"]})
    mine = db.businesses_of(_own["id"]) if _own else []
    obid = mine[0]["id"] if mine else 0

    pages = [
        ("سایت: خانه", g, "/"),
        ("سایت: کسب‌وکارها", g, "/businesses"),
        ("سایت: صفحهٔ کسب‌وکار", g, f"/b/{slug}"),
        ("سایت: کاتالوگ", g, "/catalog"),
        ("سایت: نقشه", g, "/map"),
        ("سایت: وبلاگ", g, "/blog"),
        ("سایت: تعرفه", g, "/pricing"),
        ("سایت: نزدیک من", g, "/nearby"),
        ("سایت: رویدادها", g, "/events"),
        ("سایت: مقایسه", g, "/compare"),
        ("سایت: تماس", g, "/contact"),
        ("سایت: ثبت", g, "/register-business"),
        ("سایت: ورود", g, "/login"),
        ("سایت: علاقه‌مندی", g, "/favorites"),
        ("مدیر: داشبورد", a, f"/panel?key={tok}"),
        ("مدیر: کسب‌وکارها", a, f"/panel/businesses?key={tok}"),
        ("مدیر: ویرایش کسب‌وکار", a, f"/panel/business/{bid}?key={tok}"),
        ("مدیر: دسته‌ها", a, f"/panel/categories?key={tok}"),
        ("مدیر: نظرات", a, f"/panel/reviews?key={tok}"),
        ("مدیر: تصاحب", a, f"/panel/claims?key={tok}"),
        ("مدیر: صاحبان", a, f"/panel/owners?key={tok}"),
        ("مدیر: استعلام", a, f"/panel/inquiries?key={tok}"),
        ("مدیر: نوبت‌ها", a, f"/panel/bookings?key={tok}"),
        ("مدیر: مطالب", a, f"/panel/posts?key={tok}"),
        ("مدیر: پیام‌ها", a, f"/panel/messages?key={tok}"),
        ("مدیر: صفحات", a, f"/panel/pages?key={tok}"),
        ("مدیر: ظاهر", a, f"/panel/appearance?key={tok}"),
        ("مدیر: تنظیمات", a, f"/panel/settings?key={tok}"),
        ("مدیر: پشتیبان", a, f"/panel/backup?key={tok}"),
        ("مدیر: گالری", a, f"/panel/gallery/{bid}?key={tok}"),
        ("مدیر: کاتالوگ", a, f"/panel/catalog/{bid}?key={tok}"),
        ("فروشنده: داشبورد", o, "/my"),
        ("فروشنده: کسب‌وکارها", o, "/my/businesses"),
        ("فروشنده: ویرایش", o, f"/my/business/{obid}"),
        ("فروشنده: گالری", o, f"/my/gallery/{obid}"),
        ("فروشنده: کاتالوگ", o, f"/my/catalog/{obid}"),
        ("فروشنده: افزودن کالا", o, f"/my/catalog/{obid}/item/new"),
        ("فروشنده: آمار", o, f"/my/stats/{obid}"),
        ("فروشنده: نظرات", o, "/my/reviews"),
        ("فروشنده: نوبت‌ها", o, "/my/bookings"),
        ("فروشنده: استعلام", o, "/my/inquiries"),
        ("فروشنده: تصاحب", o, "/my/claim"),
        ("فروشنده: پرسش و پاسخ", o, "/my/questions"),
        ("فروشنده: اشتراک من", o, "/my/plan"),
    ]

    print("\n" + "═" * 66)
    print("  ممیزی: کنترل‌هایی که کار نمی‌کنند")
    print("═" * 66)
    for name, cli, path in pages:
        code, html = cli.get(path)
        if code != 200:
            DEAD.append((name, "PAGE", f"HTTP {code}"))
            print(f"  ✗ {name}  HTTP {code}")
            continue
        n_before = len(DEAD)
        scan(html, name)
        found = len(DEAD) - n_before
        LIVE.append(name)
        if found:
            print(f"  ! {name:26} {found} کنترل بی‌عمل")

    print("\n" + "═" * 66)
    print("  جزئیات")
    print("═" * 66)
    if not DEAD:
        print("  ✓ هیچ کنترل بی‌عملی پیدا نشد")
    else:
        cur = None
        for page, kind, txt in DEAD:
            if page != cur:
                print(f"\n  ── {page}")
                cur = page
            print(f"     [{kind}] {txt}")

    print(f"\n  صفحات بررسی‌شده: {len(LIVE)}   کنترل بی‌عمل: {len(DEAD)}")
    return DEAD


if __name__ == "__main__":
    main()
