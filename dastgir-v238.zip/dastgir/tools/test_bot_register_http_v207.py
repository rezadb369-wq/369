#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v207 — real HTTP webhook flow of staged business registration on BOTH
Bale and Soroush against a local fake API (sendMessage/getFile/file download).
Checks parity, private-chat, rate limit, forged callbacks, photo intake,
hash-only confirm, replay and pending-only result."""
import http.server, json, os, re, shutil, subprocess, sys, tempfile, threading, time, urllib.error, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="dastgir-reg-http-")
PORT, FAKE = 8091, 8092
BSEC, SSEC = "B" * 43, "S" * 43
PNG = bytes.fromhex('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000154a24f5d0000000049454e44ae426082')
sent = []          # (platform, chat_id, text, markup)
getfile_calls = []

class Fake(http.server.BaseHTTPRequestHandler):
    def _plat(self): return "bale" if self.path.startswith("/bale") else "soroush"
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0)); body = json.loads(self.rfile.read(n) or b"{}")
        if self.path.endswith("/sendMessage"):
            sent.append((self._plat(), str(body.get("chat_id")), body.get("text", ""), body.get("reply_markup") or {}))
            out = b'{"ok":true,"result":{"message_id":1}}'
        elif self.path.endswith("/getFile"):
            getfile_calls.append((self._plat(), body.get("file_id")))
            fid = body.get("file_id", "")
            if fid == "bad-id-000000": out = b'{"ok":false}'
            elif fid == "evil-path-0000": out = b'{"ok":true,"result":{"file_path":"../../etc/passwd"}}'
            else: out = json.dumps({"ok": True, "result": {"file_path": f"photos/{fid}.png"}}).encode()
        else:
            out = b'{"ok":true,"result":true}'
        self.send_response(200); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out))); self.end_headers(); self.wfile.write(out)
    def do_GET(self):
        # file download endpoint: /<plat>file/bot<token>/photos/<id>.png
        if "/photos/" in self.path:
            data = b"%PDF-1.4 definitely not an image" if "notimg" in self.path else PNG
            self.send_response(200); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
        else:
            self.send_response(404); self.end_headers()
    def log_message(self, *a): pass

fake = http.server.ThreadingHTTPServer(("127.0.0.1", FAKE), Fake)
threading.Thread(target=fake.serve_forever, daemon=True).start()
env = dict(os.environ, BZ_DATA_DIR=TMP, PORT=str(PORT),
           BALE_BOT_TOKEN="unit-test-token", BALE_WEBHOOK_SECRET=BSEC,
           BALE_API_ROOT=f"http://127.0.0.1:{FAKE}/bale/bot", BALE_FILE_ROOT=f"http://127.0.0.1:{FAKE}/balefile/bot",
           SOROUSH_BOT_TOKEN="unit-test-token", SOROUSH_WEBHOOK_SECRET=SSEC, SOROUSH_BOT_USERNAME="dastgirbot",
           SOROUSH_API_ROOT=f"http://127.0.0.1:{FAKE}/soroush/bot", SOROUSH_FILE_ROOT=f"http://127.0.0.1:{FAKE}/soroushfile/bot")
sys.path.insert(0, str(ROOT / "server")); os.environ["BZ_DATA_DIR"] = TMP
import db  # noqa
db.init()
c_b = db.customer_by_phone("09125550001", create=True); c_s = db.customer_by_phone("09125550002", create=True)
con = db.connect()
con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,'bale','1001','1001')", (c_b["id"],))
con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,'soroush','2002','2002')", (c_s["id"],))
con.commit(); con.close()
proc = subprocess.Popen([sys.executable, str(ROOT / "run.py")], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

npass = 0
def check(ok, label):
    global npass
    if not ok: raise AssertionError(label)
    npass += 1; print("  ✓", label)

uid_counter = [5000]
def hook(plat, payload):
    uid_counter[0] += 1; payload = dict(payload, update_id=uid_counter[0])
    sec = BSEC if plat == "bale" else SSEC
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}/api/{plat}/webhook/{sec}", data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"})
    try: r = urllib.request.urlopen(req, timeout=10); return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e: return e.code, {}

def msg(plat, user, text=None, photo=None, chat_type="private"):
    m = {"from": {"id": int(user)}, "chat": {"id": int(user), "type": chat_type}}
    if text is not None: m["text"] = text
    if photo: m["photo"] = [{"file_id": "small-" + photo, "width": 10, "height": 10}, {"file_id": photo, "width": 100, "height": 100}]
    return hook(plat, {"message": m})

def cb(plat, user, data, chat_type="private"):
    return hook(plat, {"callback_query": {"id": "cbq", "data": data, "from": {"id": int(user)}, "message": {"chat": {"id": int(user), "type": chat_type}}}})

def last(plat):
    for p, c, t, k in reversed(sent):
        if p == plat: return t, k
    return "", {}

def buttons(markup):
    return [b for row in (markup or {}).get("inline_keyboard", []) for b in row]

def find_cb(markup, prefix):
    for b in buttons(markup):
        if str(b.get("callback_data", "")).startswith(prefix): return b["callback_data"]
    return None

try:
    for _ in range(80):
        try:
            if urllib.request.urlopen(f"http://127.0.0.1:{PORT}/healthz", timeout=.3).status == 200: break
        except Exception: time.sleep(.1)
    for plat, user in (("bale", "1001"), ("soroush", "2002")):
        sent.clear()
        # unlinked user cannot start
        msg(plat, "9999", "/register_business")
        t, k = last(plat); check("ابتدا از سایت وارد" in t and not find_cb(k, "dg198:reg_"), f"[{plat}] unlinked user is refused with login link")
        # group chat is ignored
        n0 = len(sent); msg(plat, user, "/register_business", chat_type="group"); check(len(sent) == n0, f"[{plat}] group chat is silently ignored")
        # menu shows the button
        msg(plat, user, "/menu"); t, k = last(plat); check(find_cb(k, "dg198:reg_start"), f"[{plat}] linked menu shows ثبت کسب‌وکار button")
        # start → category prompt with active categories
        msg(plat, user, "/register_business"); t, k = last(plat)
        cats = [b for b in buttons(k) if str(b.get("callback_data", "")).startswith("dg198:reg_cat:")]
        check("مرحلهٔ ۱ از ۹" in t and cats and all(len(b["callback_data"].encode()) <= 64 for b in buttons(k)), f"[{plat}] category prompt; all callbacks ≤64 bytes")
        # forged / out-of-step callbacks are harmless
        cb(plat, user, "dg198:reg_phone:pub"); t, k = last(plat); check("مرحلهٔ ۱ از ۹" in t, f"[{plat}] out-of-step callback re-renders current step (no jump)")
        cb(plat, user, "dg198:reg_cat:nope-nope"); t, _ = last(plat); check("معتبر نیست" in t, f"[{plat}] forged category slug rejected")
        # search by text
        msg(plat, user, "خدم"); t, k = last(plat); check("نتایج جست‌وجوی دسته" in t and find_cb(k, "dg198:reg_cat:"), f"[{plat}] typing searches categories")
        cb(plat, user, "dg198:reg_cat:services"); t, _ = last(plat); check("مرحلهٔ ۲ از ۹" in t, f"[{plat}] category chosen → name step")
        msg(plat, user, "x"); t, _ = last(plat); check("⚠️" in t and "مرحلهٔ ۲ از ۹" in t, f"[{plat}] invalid name shows error and stays")
        name = "کافه بات " + plat
        msg(plat, user, name); t, _ = last(plat); check("مرحلهٔ ۳ از ۹" in t, f"[{plat}] name accepted → city")
        msg(plat, user, "نجف‌آباد"); cb(plat, user, "dg198:reg_back"); t, _ = last(plat); check("مرحلهٔ ۳ از ۹" in t, f"[{plat}] back returns to city")
        msg(plat, user, "نجف‌آباد"); cb(plat, user, "dg198:reg_skip"); t, _ = last(plat); check("مرحلهٔ ۵ از ۹" in t, f"[{plat}] area skipped → address")
        msg(plat, user, "خیابان شریعتی، پلاک ۱۰"); msg(plat, user, "قهوهٔ تازه"); t, k = last(plat)
        check("مرحلهٔ ۷ از ۹" in t and "••••" in t and "قابل تغییر از بات نیست" in t, f"[{plat}] phone step shows masked account phone, not editable")
        msg(plat, user, "09121234567"); t, _ = last(plat); check("از دکمه‌ها استفاده کنید" in t, f"[{plat}] typed phone is ignored")
        cb(plat, user, "dg198:reg_phone:prv"); t, k = last(plat); check("مرحلهٔ ۸ از ۹" in t and find_cb(k, "dg198:reg_hours:"), f"[{plat}] phone privacy chosen → hours")
        cb(plat, user, "dg198:reg_hours:allday"); t, _ = last(plat); check("مرحلهٔ ۹ از ۹" in t and "0 از 3" in t, f"[{plat}] hours preset → images")
        # photos through real getFile + download
        msg(plat, user, photo="bad-id-000000"); t, _ = last(plat); check("ناموفق" in t, f"[{plat}] getFile failure handled")
        msg(plat, user, photo="evil-path-0000"); t, _ = last(plat); check("ناموفق" in t, f"[{plat}] traversal file_path refused")
        msg(plat, user, photo="notimg-AgACAgQAAxkBAAI"); t, _ = last(plat); check("معتبر نیست" in t, f"[{plat}] non-image bytes rejected by magic sniff")
        msg(plat, user, photo="AgACAgQAAxkBAAIpic1"); t, _ = last(plat); check("ذخیره شد" in t and "1 از 3" in t, f"[{plat}] valid photo stored (largest size requested)")
        check(getfile_calls[-1] == (plat, "AgACAgQAAxkBAAIpic1"), f"[{plat}] largest photo file_id was used")
        cb(plat, user, "dg198:reg_imgdone"); t, k = last(plat)
        check("پیش‌نمایش" in t and "منتشر نمی‌شود تا تأیید شود" in t and "1 عدد" in t and find_cb(k, "dg198:reg_confirm"), f"[{plat}] preview rendered with pending notice")
        cb(plat, user, "dg198:reg_confirm"); t, k = last(plat); tok_cb = find_cb(k, "dg198:reg_yes:")
        check(tok_cb and len(tok_cb.encode()) <= 64, f"[{plat}] one-use confirm button issued")
        raw = tok_cb.split(":", 2)[2]
        row = db._one("SELECT token FROM bot_confirmations WHERE action='biz_register' ORDER BY rowid DESC LIMIT 1")
        check(row and row["token"] != raw and len(row["token"]) == 64, f"[{plat}] DB holds only the SHA-256 of the confirm token")
        other = "2002" if plat == "bale" else "1001"; other_plat = "soroush" if plat == "bale" else "bale"
        cb(other_plat, other, tok_cb); check(db._one("SELECT COUNT(*) c FROM businesses WHERE name=?", (name,))["c"] == 0, f"[{plat}] another user's replay of the token creates nothing")
        cb(plat, user, tok_cb); t, k = last(plat); check("✅ ثبت شد" in t, f"[{plat}] owner submits successfully")
        b = db._one("SELECT * FROM businesses WHERE name=?", (name,))
        check(b and b["status"] == "pending" and b["phone_public"] == 0, f"[{plat}] business is pending with private phone")
        phone = "09125550001" if plat == "bale" else "09125550002"
        check(b["phone"] == phone and db.owner_by_phone(phone)["id"] == b["owner_id"], f"[{plat}] phone + owner bound to verified account")
        cb(plat, user, tok_cb); check(db._one("SELECT COUNT(*) c FROM businesses WHERE name=?", (name,))["c"] == 1, f"[{plat}] token replay after submit creates no duplicate")
        # public page hides phone while pending? (pending is not public at all)
        code = urllib.request.urlopen(f"http://127.0.0.1:{PORT}/b/{b['slug']}", timeout=5).status if False else None
        # rate limit independent bucket
        db.rate_clear(); hits = 0
        for i in range(45):
            msg(plat, user, "/register_business"); hits += 1
        t, _ = last(plat); check("زیاد است" in t, f"[{plat}] rate limit trips after quota (menu limiter first, registration bucket behind it)")
        db.rate_clear()
    # publish via admin path → public page honours phone_public=0
    b = db._one("SELECT * FROM businesses WHERE name='کافه بات bale'")
    db._run("UPDATE businesses SET status='published' WHERE id=?", (b["id"],)); db._pagecache_drop()
    html = urllib.request.urlopen(f"http://127.0.0.1:{PORT}/b/{b['slug']}", timeout=5).read().decode()
    check("09125550001" not in html and "کافه بات bale" in html, "published page hides phone when phone_public=0")
    db._run("UPDATE businesses SET phone_public=1 WHERE id=?", (b["id"],)); time.sleep(8.5)  # server-side page cache TTL (8s) lives in the other process
    html = urllib.request.urlopen(f"http://127.0.0.1:{PORT}/b/{b['slug']}", timeout=5).read().decode()
    check("09125550001" in html, "public page shows phone when phone_public=1")
    # existing menu still works (regression smoke)
    msg("bale", "1001", "/orders"); t, _ = last("bale"); check("سفارش" in t, "existing /orders still routed")
    print(f"\nAll {npass} bot-register HTTP v207 checks passed.")
finally:
    proc.terminate()
    try: proc.wait(timeout=5)
    except Exception: proc.kill()
    fake.shutdown(); shutil.rmtree(TMP, ignore_errors=True)
    import uploads
    for f in Path(uploads.UPLOAD_DIR).glob('bizreg-*'): f.unlink()
