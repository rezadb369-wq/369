#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v209 — owner lifecycle of a registered business + wizard category grid.

Spins up its own server on a scratch data dir. Covers: withdraw / resubmit /
hide / show state machine (compare-and-set, published_once gate), name-confirmed
soft delete → recycle bin → restore (back to pending, slug collision safe),
cross-owner 403, rate limit, trash page listing, and — with Playwright — the
visual category picker posting the right slug and the delete dialog gate.
"""
import http.cookiejar, json, os, re, shutil, subprocess, sys, tempfile, time, urllib.error, urllib.parse, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="dastgir-lc-")
PORT = 8094
env = dict(os.environ, BZ_DATA_DIR=TMP, PORT=str(PORT))
sys.path.insert(0, str(ROOT / "server")); os.environ["BZ_DATA_DIR"] = TMP
import db, bot_register as R  # noqa
db.init()
PH, PH2 = "09125550200", "09125550201"
owner = db.owner_by_phone(PH, create=True); db.customer_by_phone(PH, create=True)
other = db.owner_by_phone(PH2, create=True)
SESS, SESS2 = db.session_new(owner["id"]), db.session_new(other["id"])
proc = subprocess.Popen([sys.executable, str(ROOT / "run.py")], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

npass = 0
def check(ok, label):
    global npass
    if not ok: raise AssertionError(label)
    npass += 1; print("  ✓", label)

class NR(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k): return None
opener = urllib.request.build_opener(NR)

def req(path, data=None, sess=SESS):
    body = urllib.parse.urlencode(data).encode() if data is not None else None
    r = urllib.request.Request(f"http://127.0.0.1:{PORT}{path}", data=body)
    if sess: r.add_header("Cookie", "bzv2_sess=" + sess)
    try:
        x = opener.open(r, timeout=10); return x.status, x.read().decode(), urllib.parse.unquote(x.headers.get("Location", ""))
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode(), urllib.parse.unquote(e.headers.get("Location", ""))

def status(bid):
    b = db.business(bid=bid); return b["status"] if b else None

try:
    for _ in range(80):
        try:
            if urllib.request.urlopen(f"http://127.0.0.1:{PORT}/healthz", timeout=.3).status == 200: break
        except Exception: time.sleep(.1)

    # ---- schema
    cols = {r["name"] for r in db.connect().execute("PRAGMA table_info(businesses)")}
    check("published_once" in cols, "businesses.published_once migrated in")
    check(db.TRASH_RETENTION.get("business") == 30 * 86400, "business rows keep 30 days in the bin")

    bid = db.save_business({"name": "کافه چرخه", "cat_slug": "coffeeshop", "phone": PH, "address": "خیابان شریعتی ۱۰",
                            "status": "pending", "owner_id": owner["id"]})
    # ---- list page shows controls per status
    c, b, _ = req("/my/businesses")
    check(c == 200 and f"/my/business/{bid}/withdraw" in b and f'data-dialog-open="lc-del-{bid}"' in b, "pending card: withdraw + delete controls")
    check(f'data-must-equal="کافه چرخه"' in b and "<dialog" in b, "delete dialog requires typing the name")

    # ---- state machine
    c, _, l = req(f"/my/business/{bid}/withdraw", {}); check(c == 303 and status(bid) == "hidden" and "لغو شد" in l, "withdraw: pending → hidden")
    c, _, l = req(f"/my/business/{bid}/withdraw", {}); check(c == 303 and "ممکن نیست" in l and status(bid) == "hidden", "withdraw twice: CAS rejects, state unchanged")
    c, _, l = req(f"/my/business/{bid}/show", {}); check("ممکن نیست" in l and status(bid) == "hidden", "show: refused for a never-published shop")
    c, b, _ = req("/my/businesses"); check(f"/my/business/{bid}/resubmit" in b and "پیش‌نویس — ارسال نشده" in b, "hidden (never published) card offers resubmit")
    c, _, l = req(f"/my/business/{bid}/resubmit", {}); check(c == 303 and status(bid) == "pending", "resubmit: hidden → pending")
    check(db._one("SELECT action FROM audit ORDER BY id DESC LIMIT 1")["action"] == "business.owner-resubmit", "transitions are audited")

    db.save_business({"status": "published"}, bid)
    check(db.business(bid=bid)["published_once"] == 1, "admin publish sets published_once")
    c, _, _ = req(f"/my/business/{bid}/hide", {}); check(c == 303 and status(bid) == "hidden", "hide: published → hidden")
    c, b, _ = req("/my/businesses"); check(f"/my/business/{bid}/show" in b and "پنهان از سایت" in b, "hidden (once published) card offers show")
    c, _, _ = req(f"/my/business/{bid}/show", {}); check(c == 303 and status(bid) == "published", "show: hidden → published without moderation")
    c, b, _ = req("/my/businesses"); check(f"/my/business/{bid}/hide" in b and "/withdraw" not in b, "published card: hide only (no withdraw)")

    # ---- bulk admin path also marks published_once
    bid2 = db.save_business({"name": "نانوایی مهر", "cat_slug": "bakery", "phone": PH, "address": "x", "status": "pending", "owner_id": owner["id"]})
    db.bulk_business([bid2], "status", "published")
    check(db.business(bid=bid2)["published_once"] == 1, "bulk publish sets published_once")

    # ---- security
    c, _, _ = req(f"/my/business/{bid}/hide", {}, sess=SESS2); check(c == 403 and status(bid) == "published", "another owner gets 403, no change")
    c, _, l = req(f"/my/business/{bid}/hide", {}, sess=None); check(c == 303 and "/login" in l, "guest is sent to login")
    c, _, l = req(f"/my/business/{bid}/bogus", {}); check(c in (403, 404), "unknown action is not routed")

    # ---- delete: name gate → bin → restore
    c, _, l = req(f"/my/business/{bid}/delete", {"confirm_name": "کافه"}); check("دقیقاً" in l and status(bid) == "published", "delete with wrong name refused")
    c, _, l = req(f"/my/business/{bid}/delete", {"confirm_name": "كافه چرخه"})   # Arabic kaf → folded
    check(c == 303 and status(bid) is None and "۳۰ روز" in l, "delete with (folded) exact name → row gone, message mentions 30 days")
    row = db._one("SELECT * FROM trash WHERE entity='business' AND ref_id=?", (bid,))
    check(row and json.loads(row["payload"])["owner_id"] == owner["id"] and row["title"] == "کافه چرخه", "snapshot in recycle bin with owner_id")
    c, b, _ = req("/my/trash"); check(c == 200 and "کافه چرخه" in b and f"/my/trash/{row['id']}/restore" in b, "owner's bin lists the deleted shop with restore")
    c, b, _ = req("/my/trash", sess=SESS2); check("کافه چرخه" not in b, "another owner's bin does not list it")
    c, _, l = req(f"/my/trash/{row['id']}/restore", {}, sess=SESS2); check("معتبر نیست" in l and status(bid) is None, "another owner cannot restore it")
    c, _, l = req(f"/my/trash/{row['id']}/restore", {}); check(c == 303 and status(bid) == "pending" and "بررسی دوباره" in l, "restore → back as pending (was published)")
    check(db._one("SELECT COUNT(*) c FROM trash WHERE entity='business' AND ref_id=?", (bid,))["c"] == 0, "bin row consumed")

    # ---- slug collision on restore
    slug = db.business(bid=bid)["slug"]
    req(f"/my/business/{bid}/delete", {"confirm_name": "کافه چرخه"})
    bid3 = db.save_business({"name": "کافه چرخه", "cat_slug": "coffeeshop", "phone": "09120000002", "address": "z", "status": "published"})
    db._run("UPDATE businesses SET slug=? WHERE id=?", (slug, bid3))
    row = db._one("SELECT id FROM trash WHERE entity='business' AND ref_id=?", (bid,))
    c, _, _ = req(f"/my/trash/{row['id']}/restore", {})
    check(status(bid) == "pending" and db.business(bid=bid)["slug"] != slug, "restore avoids slug collision")

    # ---- rate limit
    hits = [req(f"/my/business/{bid}/show", {})[0] for _ in range(22)]   # CAS-rejected but counted
    c, _, l = req(f"/my/business/{bid}/hide", {}); check("زیاد است" in l, "per-owner rate limit on lifecycle actions")

    # ---- wizard category grid (markup)
    R.cancel(db.customer_by_phone(PH)["id"]); req("/register-business")
    c, b, _ = req("/register-business/category")
    check(c == 200 and "data-catgrid" in b and 'data-cat="coffeeshop"' in b and 'name="cat_slug"' in b and "data-cat-search" in b, "category step renders visual grid + native select fallback")
    check("rw-ring" in b and "rw-summary" in b and 'class="rw-dot"' in b, "wizard shell: progress ring, side summary, numbered stepper")
    c, _, l = req("/register-business/category", {"cat_slug": "coffeeshop"}); check(c == 303 and l.endswith("/identity"), "posting the native field still works (JS off)")
    c, b, _ = req("/register-business/category"); check("<noscript>" in b and "rw-native-wrap" in b, "no-JS fallback: native select shown only via noscript")

    # ---- browser
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            br = p.chromium.launch(); ctx = br.new_context(viewport={"width": 390, "height": 844}, locale="fa-IR")
            ctx.add_cookies([{"name": "bzv2_sess", "value": SESS, "domain": "127.0.0.1", "path": "/"}])
            pg = ctx.new_page(); jserr = []; pg.on("pageerror", lambda e: jserr.append(str(e)))
            R.cancel(db.customer_by_phone(PH)["id"]); R.start(db.customer_by_phone(PH)["id"], "web")
            pg.goto(f"http://127.0.0.1:{PORT}/register-business/category", wait_until="networkidle")
            pg.fill("[data-cat-search]", "نانوا"); pg.wait_for_timeout(150)
            vis = pg.locator(".rw-chip:not(.is-hidden)").count()
            check(0 < vis < 10, f"search narrows chips ({vis})")
            check(pg.locator("form[data-catgrid] select").count() == 1 and not pg.locator("#rw-cat").is_visible(), "v210: only ONE category field visible (native select hidden with JS)")
            check(pg.locator("[data-group]:not(.is-hidden)").count() >= 1 and pg.evaluate("document.querySelector('[data-group]:not(.is-hidden)').open") is True, "v210: matching group auto-opens while typing")
            pg.click(".rw-next"); pg.wait_for_timeout(150)
            check(pg.url.endswith("/category") and "هنوز انتخاب نشده" in pg.locator(".rw-picked").inner_text(), "v210: continue without a pick is blocked client-side")
            pg.click(".rw-chip:not(.is-hidden)")
            check(pg.evaluate("document.querySelector('#rw-cat').value") == "breadshop" and pg.locator(".rw-picked.is-on").is_visible(), "tapping a chip sets the hidden select + shows the pick")
            with pg.expect_navigation(): pg.click(".rw-next")
            check(pg.url.endswith("/identity") and R.get(db.customer_by_phone(PH)["id"])["data"]["cat_slug"] == "breadshop", "continue posts the chosen slug")
            # dashboard (/my) carries the same controls and separates the section
            pg.goto(f"http://127.0.0.1:{PORT}/my", wait_until="networkidle")
            html = pg.content()
            check(f"/my/business/{bid2}/hide" in html and f'data-dialog-open="lc-del-{bid2}"' in html, "v210: dashboard cards have lifecycle + delete")
            gap = pg.evaluate("(()=>{const s=document.querySelector('.biz-own-section');return s.nextElementSibling.getBoundingClientRect().top-s.getBoundingClientRect().bottom})()")
            check(gap >= 24, f"v210: businesses section separated from the next block ({int(gap)}px)")
            # delete dialog gate
            pg.goto(f"http://127.0.0.1:{PORT}/my/businesses", wait_until="networkidle")
            pg.click(f'[data-dialog-open="lc-del-{bid2}"]'); pg.wait_for_timeout(200)
            check(pg.evaluate(f"document.querySelector('#lc-del-{bid2}').open") is True, "delete dialog opens as modal")
            check(pg.evaluate(f"document.querySelector('#lc-del-{bid2} [type=submit]').disabled") is True, "submit disabled until name typed")
            pg.fill(f"#lc-del-{bid2}-n", "نانوایی مهر")
            check(pg.evaluate(f"document.querySelector('#lc-del-{bid2} [type=submit]').disabled") is False, "exact name enables submit")
            r = pg.evaluate(f"(()=>{{const r=document.querySelector('#lc-del-{bid2}').getBoundingClientRect();return r.top>40 && r.bottom<innerHeight-40}})()")
            check(r, "dialog is centred in the viewport")
            check(not jserr, "no JS errors")
            br.close()
    except ImportError:
        print("  ! playwright not installed — browser checks skipped")

    print(f"\nAll {npass} owner-lifecycle v209 checks passed.")
finally:
    proc.terminate()
    try: proc.wait(timeout=5)
    except Exception: proc.kill()
    shutil.rmtree(TMP, ignore_errors=True)
