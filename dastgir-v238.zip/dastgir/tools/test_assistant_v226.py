#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v226 «دکمهٔ تأیید در بات» — tool proposals in Bale/Soroush grow ✅/❌
inline buttons; pressing one behaves exactly like typing «بله»/«نه»
(same free confirm path, same thread, same render). Typed replies keep
working; both bots share the dispatcher, so both get it.
"""
import os, sys, tempfile, json, datetime
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v226-')
os.environ['BZ_DATA_DIR'] = TMP
for k in ('AI_BASE_URL', 'AI_API_KEY', 'AI_MODEL', 'AI_MODEL_SMART', 'AI_FALLBACK_BASE_URL', 'AI_FALLBACK_API_KEY', 'AI_FALLBACK_MODEL'):
    os.environ.pop(k, None)
sys.path.insert(0, str(ROOT / 'server')); sys.path.insert(0, str(ROOT / 'tools'))
import db, assistant as A, bot_menu
from layout import g2j
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
db.set_settings({"ai_quota_free": "100"})
own = db.owner_by_phone("09120000111", create=True)
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id,booking_on) VALUES(?,?,?,?,?,?)",
            ("bot-shop", "مغازه باتی", "services", "published", own["id"], 1))
con.commit(); con.close()
biz = db.business(slug="bot-shop")
c1 = db.customer_by_phone("09120000112", create=True)
db._run("UPDATE customers SET name='کاربر بله' WHERE id=?", (c1["id"],))
c2 = db.customer_by_phone("09120000113", create=True)
con = db.connect()
bids = []
for i in range(5):
    con.execute("INSERT INTO bookings(biz_id,name,phone,date,time,status,customer_id) VALUES(?,?,?,?,?,?,?)",
                (biz["id"], "ت", c1["phone"], "2026-10-01", f"1{i}:00", "new", c1["id"]))
    bids.append(con.execute("SELECT last_insert_rowid() i").fetchone()["i"])
con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,?,?,?)",
            (c1["id"], "bale", "111", "90"))
con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,?,?,?)",
            (c2["id"], "bale", "222", "92"))
con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,?,?,?)",
            (c1["id"], "soroush", "333", "93"))
con.commit(); con.close()
ckey1 = f"cust:{c1['id']}"

t = datetime.date.today()
jy = g2j(t.year, t.month, t.day)[0]
VALID = f"{jy + 1}/03/15"

def fake_chat(base, key, model, messages, timeout, max_tokens=220):
    import re as _re
    q = str(messages[-1].get("content") or "")
    tc = None
    m = _re.search(r"CX([1-5])", q)
    if m: tc = {"name": "cancel_booking", "args": {"id": bids[int(m.group(1)) - 1]}}
    elif "FAV" in q: tc = {"name": "favorite", "args": {"slug": "bot-shop"}}
    elif "BOOKX" in q: tc = {"name": "book", "args": {"slug": "bot-shop", "date": VALID, "time": "09:15"}}
    return json.dumps({"answer": "مدل.", "links": [], "scope": True, "intent": "booking", "tool_call": tc}, ensure_ascii=False), 10
A._chat = fake_chat
os.environ.update(AI_BASE_URL="https://api.example.invalid/v1", AI_API_KEY="test-key-not-real", AI_MODEL="fake-lite")

sent = []
send = lambda c, t, m=None: sent.append((c, t, m))
kb = lambda: json.dumps(sent[-1][2], ensure_ascii=False)

# ---- 1. proposal grows ✅/❌ buttons
ck(bot_menu.handle_message("bale", "111", "90", "CX1 لطفا", send), 'free text consumed')
ck("dg198:ai_yes" in kb() and "dg198:ai_no" in kb(), 'proposal carries confirm buttons')
ck(kb().index("ai_yes") < kb().index("dg198:menu"), 'buttons sit before the menu row')
ck("پاسخ هوشمند" in sent[-1][1] and A.pending_get(ckey1)["tool"] == "cancel_booking", 'footer intact, pending stored')
r = A.answer("CX1 دوباره", {"channel": "web", "user_key": ckey1, "customer": c1, "owner": None})
ck(r.get("pending_tool") == "cancel_booking", 'answer() flags the proposal')
ck(not A.answer("هوا چطوره", {"channel": "web", "user_key": ckey1, "customer": c1, "owner": None}).get("pending_tool"), 'plain answers carry no flag')

# ---- 2. ✅ executes exactly like typed «بله»
q0 = A.quota_used_today(ckey1)
ck(bot_menu.handle_callback("bale", "111", "90", "dg198:ai_yes", send) is True, 'callback consumed')
ck(db._one("SELECT status s FROM bookings WHERE id=?", (bids[0],))["s"] == "cancelled", 'booking cancelled')
ck("لغو شد" in sent[-1][1] and "dg198:menu" in kb(), 'result rendered with menu')
ck(A.quota_used_today(ckey1) == q0 and A.pending_get(ckey1) is None, 'button confirm free, pending consumed')
ck(any("لغو شد" in m["text"] for m in A.thread_get(ckey1)), 'execution lands in the account thread')

# ---- 3. ❌ discards; stale buttons fail gentle
bot_menu.handle_message("bale", "111", "90", "CX2 لطفا", send)
ck(bot_menu.handle_callback("bale", "111", "90", "dg198:ai_no", send) is True, 'decline consumed')
ck("انجام نشد" in sent[-1][1] and db._one("SELECT status s FROM bookings WHERE id=?", (bids[1],))["s"] == "new", 'declined, booking intact')
ck(bot_menu.handle_callback("bale", "111", "90", "dg198:ai_yes", send) is True, 'stale press consumed')
ck("گذشت" in sent[-1][1], 'stale press → gentle expiry note, no model fallthrough')
ck(bot_menu.handle_callback("bale", "999", "91", "dg198:ai_yes", send) is True, 'unlinked press consumed')
ck("گذشت" in sent[-1][1], 'unlinked press → gentle, no crash')

# ---- 4. isolation across bot users; typed «بله» still works
bot_menu.handle_message("bale", "111", "90", "CX3 لطفا", send)
ck(bot_menu.handle_callback("bale", "222", "92", "dg198:ai_yes", send) is True, 'other user press consumed')
ck("گذشت" in sent[-1][1] and db._one("SELECT status s FROM bookings WHERE id=?", (bids[2],))["s"] == "new", '…cannot touch my pending')
ck(A.pending_get(ckey1) is not None, 'my pending survives their press')
bot_menu.handle_callback("bale", "111", "90", "dg198:ai_yes", send)
ck(db._one("SELECT status s FROM bookings WHERE id=?", (bids[2],))["s"] == "cancelled", 'my own press executes')
bot_menu.handle_message("bale", "111", "90", "CX4 لطفا", send)
bot_menu.handle_message("bale", "111", "90", "بله", send)
ck(db._one("SELECT status s FROM bookings WHERE id=?", (bids[3],))["s"] == "cancelled", 'typed «بله» fallback intact')

# ---- 5. no buttons without a proposal; dispatcher intact
bot_menu.handle_message("bale", "111", "90", "FAV لطفا", send)
ck("ai_yes" not in kb(), 'immediate favorite grows no buttons')
bot_menu.handle_message("bale", "111", "90", "ساعت کاری چنده", send)
ck("ai_yes" not in kb(), 'plain answers grow no buttons')
ck(bot_menu.handle_callback("bale", "111", "90", "dg198:xxx", send) is False, 'unknown callbacks still rejected')

# ---- 6. booking via buttons + Soroush shares the account pending
bot_menu.handle_message("bale", "111", "90", "BOOKX لطفا", send)
ck("ai_yes" in kb(), 'book proposal has buttons')
bot_menu.handle_callback("bale", "111", "90", "dg198:ai_yes", send)
ck(db._one("SELECT COUNT(*) c FROM bookings WHERE time='09:15' AND customer_id=?", (c1["id"],))["c"] == 1, 'book executed from the button')
bot_menu.handle_message("bale", "111", "90", "CX5 لطفا", send)
ck(bot_menu.handle_callback("soroush", "333", "93", "dg198:ai_yes", send) is True, 'same account on Soroush presses')
ck(db._one("SELECT status s FROM bookings WHERE id=?", (bids[4],))["s"] == "cancelled", '…and the shared pending executes')

print(f"v226: {n} checks passed")
