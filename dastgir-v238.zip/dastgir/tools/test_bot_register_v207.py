#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""v207 section 1 — staged bot business registration: schema, state machine,
validation, ownership, hash-only confirmation, pending-only submit."""
import os, sys, tempfile, shutil, hashlib, json, time, sqlite3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='bot-register-v207-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_' + 'BOT_TOKEN'] = ''; os.environ['SOROUSH_' + 'BOT_TOKEN'] = ''
sys.path.insert(0, str(ROOT / 'server'))
import db, bot_register as R, uploads
n = 0
def ck(v, label):
    global n
    assert v, label; n += 1; print('  ✓', label)
PNG = bytes.fromhex('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000154a24f5d0000000049454e44ae426082')
try:
    db.init()
    cols = {r[1] for r in db.connect().execute('PRAGMA table_info(biz_reg_drafts)')}
    ck({'customer_id', 'platform', 'step', 'payload', 'expires'} <= cols, 'fresh schema has biz_reg_drafts')
    ck('phone_public' in {r[1] for r in db.connect().execute('PRAGMA table_info(businesses)')}, 'fresh schema has businesses.phone_public')
    # ---- migration: old DB without the column/table gets both on init()
    con = db.connect(); con.execute('DROP TABLE biz_reg_drafts'); con.execute('ALTER TABLE businesses DROP COLUMN phone_public'); con.commit(); con.close()
    db.init()
    ck('phone_public' in {r[1] for r in db.connect().execute('PRAGMA table_info(businesses)')}, 'old DB gains phone_public via _reconcile_schema')
    ck(db._one("SELECT name FROM sqlite_master WHERE name='biz_reg_drafts'"), 'old DB gains biz_reg_drafts table')
    c1 = db.customer_by_phone('09121110001', create=True); c2 = db.customer_by_phone('09121110002', create=True)
    # ---- start / resume / platform guard
    ck(R.start(c1['id'], 'rubika') is None, 'inactive platform cannot open a draft')
    d = R.start(c1['id'], 'bale'); ck(d and d['step'] == 'category', 'draft starts at category')
    d2 = R.start(c1['id'], 'soroush'); ck(d2['id'] == d['id'] and d2['platform'] == 'bale', 'second start resumes the same draft (cross-messenger)')
    ck(R.get(c2['id']) is None, 'another customer sees no draft')
    # ---- category
    ok, err = R.set_text(c1['id'], 'زودتر'); ck(not ok, 'text rejected while category step is active')
    ok, err = R.set_category(c1['id'], 'does-not-exist'); ck(not ok, 'unknown category slug rejected')
    db._run("UPDATE categories SET active=0 WHERE slug='services'")
    ok, err = R.set_category(c1['id'], 'services'); ck(not ok, 'inactive category rejected even with valid slug')
    db._run("UPDATE categories SET active=1 WHERE slug='services'")
    hits = R.search_categories('خدم'); ck(hits and all('slug' in h for h in hits) and len(hits) <= 6, 'category search returns bounded active hits')
    ck(not [h for h in R.search_categories('') if h['parent']], 'empty query lists top-level only')
    ok, err = R.set_category(c1['id'], 'services'); ck(ok and R.get(c1['id'])['step'] == 'name', 'valid category advances to name')
    ok, err = R.set_category(c1['id'], 'services'); ck(not ok, 'category cannot be re-set out of step (CAS)')
    # ---- name validation
    ck(not R.set_text(c1['id'], 'ا')[0], 'name too short rejected')
    ck(not R.set_text(c1['id'], 'x' * 61)[0], 'name too long rejected')
    ck(not R.set_text(c1['id'], 'دکان www.site.ir')[0], 'name with URL rejected')
    ck(not R.set_text(c1['id'], 'دکان 09121234567')[0], 'name with phone rejected')
    ck(not R.set_text(c1['id'], 'الف\nب')[0], 'multi-line name rejected')
    con = db.connect(); con.execute("INSERT INTO businesses(slug,name,cat_slug,status) VALUES('dup-x','نانوایی برکت','services','published')"); con.commit(); con.close()
    ck(not R.set_text(c1['id'], 'نانوایی برکت')[0], 'exact duplicate name rejected')
    ck(R.set_text(c1['id'], '  نانوایی\u200cبرکت  محله  ')[0] and R.get(c1['id'])['data']['name'] == 'نانوایی\u200cبرکت محله', 'name cleaned + stored')
    ck(R.get(c1['id'])['step'] == 'city', 'advanced to city')
    ck(R.set_text(c1['id'], 'نجف‌آباد')[0], 'city accepted')
    # ---- back / optional
    ck(R.go_back(c1['id'])['step'] == 'city', 'go_back returns to previous step without data loss')
    ck(R.get(c1['id'])['data']['city'] == 'نجف‌آباد', 'back keeps stored city')
    ck(R.set_text(c1['id'], 'نجف‌آباد')[0] and R.get(c1['id'])['step'] == 'area', 'city re-entered')
    ck(R.skip_optional(c1['id']) and R.get(c1['id'])['step'] == 'address', 'area is skippable')
    ck(not R.skip_optional(c1['id']), 'address is NOT skippable')
    ck(not R.set_text(c1['id'], 'کوچه')[0], 'address too short rejected')
    ck(R.set_text(c1['id'], 'خیابان امام، کوچهٔ ۱۲، پلاک ۳')[0], 'address accepted')
    ck(not R.set_text(c1['id'], 'ببینید https://x.ir')[0], 'descr with link rejected')
    ck(R.set_text(c1['id'], 'نان تازه و داغ' + '\x00')[0] and '\x00' not in R.get(c1['id'])['data']['descr'], 'descr control chars stripped')
    # ---- phone_public / hours ordering enforced
    ck(not R.set_hours(c1['id'], 'allday'), 'hours cannot be set before phone_public')
    ck(R.set_phone_public(c1['id'], False), 'phone_public choice stored')
    ck(not R.set_hours(c1['id'], 'evil'), 'unknown hours preset rejected')
    ck(R.set_hours(c1['id'], 'split') and R.get(c1['id'])['data']['hours']['sat'] == [['09:00', '13:00'], ['16:00', '21:00']], 'hours preset stored as site-compatible JSON')
    # ---- images (magic bytes, count, step)
    ok, msg, cnt = R.add_image(c1['id'], b'not an image at all'); ck(not ok and cnt == 0, 'non-image bytes rejected')
    ok, msg, cnt = R.add_image(c1['id'], b'\x00' * (3 * 1024 * 1024 + 1)); ck(not ok, 'oversize rejected')
    for i in range(3):
        ok, msg, cnt = R.add_image(c1['id'], PNG); assert ok, msg
    ck(cnt == 3, 'three valid images stored')
    ok, msg, cnt = R.add_image(c1['id'], PNG); ck(not ok and cnt == 3, 'fourth image refused (MAX_IMAGES)')
    ck(all(p.startswith('/assets/img/uploads/bizreg-') for p in R.get(c1['id'])['data']['images']), 'image paths are in uploads dir with bizreg prefix')
    ck(R.finish_images(c1['id']) and R.get(c1['id'])['step'] == 'preview', 'images done → preview')
    ck(not R.add_image(c1['id'], PNG)[0], 'no image accepted after preview')
    # ---- preview + confirmation
    pv = R.preview_text(c1['id'], '0912••••001'); ck('نانوایی' in pv and 'فقط برای سایت و مدیر' in pv and 'در انتظار بررسی مدیر' in pv, 'preview shows masked phone + pending notice')
    tok = R.prepare_confirm(c1['id']); ck(tok, 'confirmation issued')
    stored = db._one("SELECT token,action FROM bot_confirmations WHERE customer_id=?", (c1['id'],))
    ck(stored['token'] == hashlib.sha256(tok.encode()).hexdigest() and stored['action'] == 'biz_register', 'confirmation stored hash-only')
    ck(R.submit(c2['id'], tok, '09121110002')[0] is None, 'confirmation is customer-bound')
    ck(R.submit(c1['id'], 'x' * 30, '09121110001')[0] is None, 'malformed token rejected')
    ck(R.submit(c1['id'], tok, '0912')[0] is None, 'invalid account phone rejected')
    bid, err = R.submit(c1['id'], tok, '09121110001'); ck(bid and not err, 'submit succeeds once')
    ck(R.submit(c1['id'], tok, '09121110001')[0] is None, 'replay of same token fails')
    b = db.business(bid=bid)
    ck(b['status'] == 'pending', 'created business is pending (never published)')
    ck(b['phone'] == '09121110001' and int(b['phone_public']) == 0, 'phone bound to verified account; public flag off')
    o = db.owner_by_phone('09121110001'); ck(o and b['owner_id'] == o['id'], 'business owner-bound to the customer phone owner')
    ck(b['cat_slug'] == 'services' and b['city'] == 'نجف‌آباد' and len(b['images']) == 3 and b['hours_map']['sat'], 'fields persisted')
    ck(R.get(c1['id']) is None, 'draft removed after submit')
    ck(len([x for x in db.businesses(status='pending') if x['id'] == bid]) == 1, 'appears in admin pending list')
    # ---- public phone mask
    import views_public as V
    ck(V._public_phone_mask(b)['phone'] == '' and V._public_phone_mask(dict(b, phone_public=1))['phone'] == '09121110001', 'public projection blanks phone only when phone_public=0')
    # ---- expiry + cancel
    R.start(c2['id'], 'soroush'); db._run("UPDATE biz_reg_drafts SET expires=? WHERE customer_id=?", (time.time() - 1, c2['id']))
    ck(R.get(c2['id']) is None, 'expired draft is invisible')
    d = R.start(c2['id'], 'soroush'); ck(d and d['step'] == 'category', 'new draft replaces expired one')
    ck(R.cancel(c2['id']) and R.get(c2['id']) is None and not R.cancel(c2['id']), 'cancel deletes; second cancel is a no-op')
    ck(not R.prepare_confirm(c2['id']), 'no confirmation without complete preview draft')
    # ---- blocked owner
    db._run("UPDATE owners SET status='blocked' WHERE phone='09121110001'")
    R.start(c1['id'], 'bale'); R.set_category(c1['id'], 'services'); R.set_text(c1['id'], 'قنادی گل'); R.set_text(c1['id'], 'اصفهان'); R.skip_optional(c1['id']); R.set_text(c1['id'], 'خیابان چهارباغ پلاک ۱'); R.skip_optional(c1['id']); R.set_phone_public(c1['id'], True); R.set_hours(c1['id'], 'skip'); R.finish_images(c1['id'])
    t2 = R.prepare_confirm(c1['id']); bid2, err2 = R.submit(c1['id'], t2, '09121110001')
    ck(bid2 is None and 'مسدود' in err2, 'blocked owner cannot submit')
    ck(R.get(c1['id']) and R.get(c1['id'])['step'] == 'preview', 'draft kept after refused submit')
    ck(db._one("SELECT COUNT(*) c FROM bot_confirmations WHERE customer_id=? AND action='biz_register' AND used=0", (c1['id'],))['c'] == 0, 'refused submit still burned the token (no replay window)')
    print(f'\nAll {n} bot-register v207 checks passed.')
finally:
    shutil.rmtree(TMP, ignore_errors=True)
    for f in Path(uploads.UPLOAD_DIR).glob('bizreg-*'):
        f.unlink()
