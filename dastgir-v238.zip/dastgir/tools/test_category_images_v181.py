#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Live CRUD regression for mobile category-image uploads. Requires run.py."""
from __future__ import annotations

import io
import os
from pathlib import Path
import sys
from PIL import Image, ImageDraw
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))
import db

BASE = os.environ.get("BZ", "http://127.0.0.1:8080")
NAME = "دسته تصویر موبایل ۱۸۱"


def png(color, mark):
    im = Image.new("RGB", (320, 180), color)
    ImageDraw.Draw(im).rectangle((40, 35, 280, 145), outline="white", width=12)
    ImageDraw.Draw(im).text((145, 75), mark, fill="white")
    out = io.BytesIO(); im.save(out, "PNG"); return out.getvalue()


def check(ok, label):
    if not ok: raise AssertionError(label)
    print("✓", label)


def upload(req, path, fields, data=None, filename="cat.png"):
    body = dict(fields)
    if data is not None:
        body["image"] = {"name": filename, "mimeType": "image/png", "buffer": data}
    return req.post(BASE + path, multipart=body)


def main():
    token = db.owner_token()
    # Clean only this test fixture if an interrupted run left it behind.
    old = next((c for c in db.categories(only_active=False) if c["name"] == NAME), None)
    if old:
        p = old.get("image") or ""
        db.delete_category(old["id"])
        if p.startswith("/assets/img/uploads/"):
            import uploads; uploads.delete_image(p)

    one, two, three = png("#0b6059", "1"), png("#173f70", "2"), png("#8a3d17", "3")
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--no-sandbox"])
        ctx = browser.new_context(viewport={"width": 390, "height": 844}, locale="fa-IR")
        pg = ctx.new_page()
        pg.goto(f"{BASE}/panel/categories?key={token}", wait_until="networkidle")
        form = pg.locator('form[action="/panel/category/new"]')
        check(form.get_attribute("enctype") == "multipart/form-data",
              "new-category form is multipart")
        check(form.locator('[data-imagefield][data-name="image"]').count() == 1,
              "new-category form exposes gallery/camera image field")

        unauth = p.request.new_context().post(BASE + "/panel/category/new",
            multipart={"name": "نباید ساخته شود", "image": {
                "name": "x.png", "mimeType": "image/png", "buffer": one}})
        check(unauth.status == 403, "unauthenticated image upload is rejected")

        r = upload(ctx.request, "/panel/category/new",
                   {"key": token, "name": NAME, "icon": "store",
                    "parent": "", "blurb": "آزمون تصویر موبایل", "image_keep": "[]"}, one)
        check(r.ok, "category with uploaded image is created")
        cat = next(c for c in db.categories(only_active=False) if c["name"] == NAME)
        first = cat["image"]
        check(first.startswith("/assets/img/uploads/category-") and
              (ROOT / "site" / first.lstrip("/")).is_file(), "uploaded image is stored and linked")
        public = ctx.request.get(BASE + "/categories").text()
        check(first in public, "uploaded image is rendered on public categories page")

        pg.goto(f"{BASE}/panel/category/{cat['id']}?key={token}", wait_until="networkidle")
        edit = pg.locator(f'form[action="/panel/category/{cat["id"]}"]')
        check(edit.get_attribute("enctype") == "multipart/form-data" and
              edit.locator('[data-imagefield][data-name="image"]').count() == 1,
              "edit form exposes current image with mobile picker")

        common = {"key": token, "name": NAME, "icon": "store", "parent": "",
                  "blurb": "جایگزین", "sort": "0", "active": "on"}
        r = upload(ctx.request, f"/panel/category/{cat['id']}",
                   {**common, "image_keep": f'["{first}"]'}, two, "replacement.png")
        second = db.category_by_id(cat["id"])["image"]
        check(r.ok and second != first and not (ROOT / "site" / first.lstrip("/")).exists(),
              "replacement stores new image and removes superseded upload")

        r = upload(ctx.request, f"/panel/category/{cat['id']}",
                   {**common, "image_keep": "[]"})
        check(r.ok and db.category_by_id(cat["id"])["image"] == "-" and
              not (ROOT / "site" / second.lstrip("/")).exists(),
              "delete removes upload and suppresses packaged fallback")
        check(second not in ctx.request.get(BASE + "/categories").text(),
              "deleted image disappears from public page")

        r = upload(ctx.request, f"/panel/category/{cat['id']}",
                   {**common, "image_keep": "[]"}, three, "after-delete.png")
        third = db.category_by_id(cat["id"])["image"]
        check(r.ok and third.startswith("/assets/img/uploads/category-"),
              "image can be uploaded again after deletion")
        check(third in db.all_upload_refs(), "media GC protects category image")

        # Existing packaged photos can also be hidden from the same mobile UI.
        packaged = next(c for c in db.categories(only_active=False)
                        if (ROOT / "site/assets/img/cats" / f"{c['slug']}.webp").is_file())
        original_image = packaged.get("image") or ""
        packaged_url = f"/assets/img/cats/{packaged['slug']}.webp"
        pfields = {"key": token, "name": packaged["name"], "icon": packaged["icon"],
                   "parent": packaged.get("parent") or "", "blurb": packaged.get("blurb") or "",
                   "sort": str(packaged.get("sort") or 0), "image_keep": "[]"}
        if packaged.get("active"):
            pfields["active"] = "on"
        r = upload(ctx.request, f"/panel/category/{packaged['id']}", pfields)
        check(r.ok and db.category_by_id(packaged["id"])["image"] == "-" and
              packaged_url not in ctx.request.get(BASE + "/categories").text(),
              "admin can remove an existing packaged category photo")
        db.save_category({"name": packaged["name"], "icon": packaged["icon"],
                          "image": original_image, "parent": packaged.get("parent") or "",
                          "blurb": packaged.get("blurb") or "", "sort": packaged.get("sort") or 0,
                          "active": packaged.get("active") or 0}, packaged["id"])

        r = ctx.request.post(BASE + f"/panel/category/{cat['id']}/delete",
                             form={"key": token})
        check(r.ok and db.category_by_id(cat["id"]) is None and
              not (ROOT / "site" / third.lstrip("/")).exists(),
              "deleting category also removes its uploaded file")
        check(pg.evaluate("document.documentElement.scrollWidth <= innerWidth"),
              "panel has no horizontal overflow at 390px")
        ctx.close(); browser.close()

    print("\nهمهٔ آزمون‌های تصویر دسته‌بندی v181 موفق بودند.")


if __name__ == "__main__":
    main()
