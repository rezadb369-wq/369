#!/usr/bin/env python3
"""Send the idempotent owner daily digest. Intended for systemd timer."""
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'server'))
import db
if __name__=='__main__':
    db.init()
    print(f"owner daily summaries: {db.send_owner_daily_summaries()} delivered")
