#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""Final cross-role, replay, rate, webhook and one-use-action audit for v206."""
import os,sys,tempfile,shutil,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];TMP=tempfile.mkdtemp(prefix='bot-security-v206-')
os.environ['BZ_DATA_DIR']=TMP
os.environ['BALE_'+'BOT_TOKEN']='';os.environ['SOROUSH_'+'BOT_TOKEN']=''
sys.path.insert(0,str(ROOT/'server'))
import db,bot_menu,bale,soroush
n=0
def ck(v,label):
 global n
 assert v,label;n+=1;print('  ✓',label)
try:
 db.init();c1=db.customer_by_phone('09120000001',create=True);c2=db.customer_by_phone('09120000002',create=True);o1=db.owner_by_phone('09120000001',create=True);o2=db.owner_by_phone('09120000002',create=True)
 con=db.connect();con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id) VALUES('secure-a','دکان الف','services','published',?)",(o1['id'],));con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id) VALUES('secure-b','دکان ب','services','published',?)",(o2['id'],));con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,'bale','u1','c1')",(c1['id'],));con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,'soroush','u1s','c1s')",(c1['id'],));con.commit();con.close();b1=db.business(slug='secure-a');b2=db.business(slug='secure-b')
 oid1=db.create_order(b1['id'],c1['id'],'یک','','','private',[{'title':'الف','price':1,'qty':1}]);oid2=db.create_order(b2['id'],c2['id'],'دو','','','private2',[{'title':'ب','price':1,'qty':1}])
 ck(db.customer_order_detail(c1['id'],oid1) and not db.customer_order_detail(c1['id'],oid2),'customer order projection enforces id+customer')
 ck(db.owner_order_detail(o1['id'],oid1) and not db.owner_order_detail(o1['id'],oid2),'owner order projection enforces id+owner business')
 k1=db.add_booking(b1['id'],'یک','09120000001','2099-01-01','10:00','secret',c1['id']);k2=db.add_booking(b2['id'],'دو','09120000002','2099-01-01','11:00','secret2',c2['id'])
 ck(db.customer_booking_detail(c1['id'],k1) and not db.customer_booking_detail(c1['id'],k2),'booking projection cannot cross customer role')
 t1=db.chat_start(b1['id'],c1['id']);t2=db.chat_start(b2['id'],c2['id']);db.chat_send(t1,'owner','one');db.chat_send(t2,'owner','two')
 ck(db.customer_chat_detail(c1['id'],t1) and not db.customer_chat_detail(c1['id'],t2),'chat projection cannot cross customer role')
 ck(db.owner_chat_detail(o1['id'],t1) and not db.owner_chat_detail(o1['id'],t2),'chat projection cannot cross owner role')
 raw=db.customer_chat_reply_prepare(c1['id'],t1,'پاسخ امن');stored=db._one('SELECT token FROM bot_confirmations WHERE customer_id=?',(c1['id'],))['token']
 ck(raw!=stored and stored==hashlib.sha256(raw.encode()).hexdigest(),'customer confirmation stores hash, never bearer token')
 ck(db.customer_chat_reply_confirmed(c2['id'],raw) is None,'customer confirmation is identity-bound')
 ck(db.customer_chat_reply_confirmed(c1['id'],raw) and db.customer_chat_reply_confirmed(c1['id'],raw) is None,'customer confirmation is atomically one-use')
 expired=db.customer_chat_reply_prepare(c1['id'],t1,'منقضی');db._run('UPDATE bot_confirmations SET expires=0 WHERE token=?',(hashlib.sha256(expired.encode()).hexdigest(),));ck(db.customer_chat_reply_confirmed(c1['id'],expired) is None,'expired customer action is rejected')
 own=db.owner_bot_action_prepare(o1['id'],'order_status',oid1,'confirmed');oh=db._one('SELECT token FROM owner_bot_confirmations WHERE owner_id=?',(o1['id'],))['token'];ck(oh==hashlib.sha256(own.encode()).hexdigest() and own!=oh,'owner confirmation bearer is hash-only at rest')
 ck(db.owner_bot_action_confirm(o2['id'],own) is None and db.order(oid1)['status']=='new','owner token cannot cross ownership boundary')
 ck(db.owner_bot_action_confirm(o1['id'],own)['ok'] and db.order(oid1)['status']=='confirmed','owner transition confirms once')
 ck(db.owner_bot_action_confirm(o1['id'],own) is None,'owner transition replay is rejected')
 ck(not db.owner_bot_action_prepare(o1['id'],'order_status',oid1,'done'),'owner cannot skip order transition')
 ck(not db.owner_bot_action_prepare(o1['id'],'booking_status',k2,'confirmed'),'owner cannot act on foreign appointment')
 con=db.connect();con.execute("INSERT INTO items(biz_id,title,available) VALUES(?,'کالا',0)",(b2['id'],));iid=con.execute('SELECT last_insert_rowid()').fetchone()[0];con.commit();con.close();db.stock_request_add(b2['id'],iid,c2['id']);rid=db.customer_stock_requests(c2['id'])[0]['id']
 ck(not db.owner_bot_action_prepare(o1['id'],'stock_fulfill',rid,'yes'),'owner cannot fulfill foreign stock request')
 sent=[];rb,rs=bale.send_notification,soroush.send_notification;bale.send_notification=lambda *a,**k:(sent.append('bale') or True);soroush.send_notification=lambda *a,**k:(sent.append('soroush') or True);db.set_customer_pref(c1['id'],'chat',False);ck(not db.notify_customer(c1['id'],'chat','muted','/me') and not sent,'customer notification preference blocks all channels');db.set_customer_pref(c1['id'],'chat',True);db.notify_customer(c1['id'],'chat','active','/me');bale.send_notification,soroush.send_notification=rb,rs;ck(set(sent)=={'bale','soroush'},'enabled notification reaches both linked platforms')
 ck(all(db.rate_ok('final-rate',limit=3,window=60,always=True) for _ in range(3)) and not db.rate_ok('final-rate',limit=3,window=60,always=True),'persistent rate limiter enforces exact boundary')
 ck(db.messenger_update_claim('bale',9001) and not db.messenger_update_claim('bale',9001) and db.messenger_update_claim('soroush',9001),'replay claim is atomic and platform-separated')
 src=(ROOT/'server/app.py').read_text();ck(src.count('secrets.compare_digest')>=2 and src.count('messenger_update_claim(')>=2,'both webhooks use constant-time secret and persistent replay claim')
 ck(src.count("chat.get(\"type\") == \"private\"")>=2 and src.count('and private and data.startswith(bot_menu.CALLBACK_PREFIX)')==2,'both bot menus and callbacks require private chat')
 ck('def read_json(self, max_bytes=262144)' in src and src.count('return self.json_out({"ok": False}, 429)')>=1,'webhook body and request rates are bounded')
 ck(not any('rubika' in x.lower() for x in (' '.join(p.name for p in (ROOT/'server').iterdir()),)),'Rubika has no active server module')
 day='2099-12-31';first=db.send_owner_daily_summaries(day);second=db.send_owner_daily_summaries(day);ck(first in (0,1,2) and second==0,'daily summary dedup is owner/day idempotent')
 print(f'\nAll {n} final bot-security v206 checks passed.')
finally:shutil.rmtree(TMP,ignore_errors=True)
