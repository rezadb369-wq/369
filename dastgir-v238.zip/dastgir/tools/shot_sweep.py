#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
shot_sweep.py — جاروی بصری/سلامتِ کل سایت (ممیزی v77)

چرا این ابزار؟ کاربر خواست «همهٔ قسمت‌های سایت، همهٔ آیکون‌ها و همهٔ امکانات»
واقعاً دیده و سنجیده شوند، نه اینکه فقط تست‌ها سبز باشند. این ابزار هر صفحهٔ
قابل‌GET را با چهار نقش (مهمان/مشتری/دکان‌دار/مدیر) باز می‌کند و برای هرکدام
عدد ثبت می‌کند:

  · کد وضعیت HTTP (۲۰۰ یا خطا)
  · خطاهای کنسول مرورگر و درخواست‌های شکست‌خورده (۴۰۴/۵۰۰)
  · تصویرهای شکسته (naturalWidth==0) → یعنی آیکون/عکس گم شده
  · سرریز افقی، کوچک‌ترین فونت، هدف لمسی زیر ۴۴px
  · دسترسی‌پذیری: img بدون alt، ورودی بدون label، دکمه بدون نام
  · زمان بارگذاری و حجم transfer
  + اسکرین‌شات واقعی ذخیره می‌شود (shots/v77-audit/…)

    python3 run.py            # سرور را بالا بیاور
    BZ=http://127.0.0.1:8080 python3 tools/shot_sweep.py
"""

import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa: E402

from playwright.sync_api import sync_playwright  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
OUT = os.path.join(HERE, "..", "shots", "v77-audit")
os.makedirs(OUT, exist_ok=True)

HOST = urllib.parse.urlparse(BASE).netloc

# مسیرهایی که POST-only یا اکشن‌اند (باز کردنشان با GET معنا ندارد)
SKIP = re.compile(
    r"^(?:/api/|/assets/|/login/verify|/me/login/verify|/login/password|"
    r"/me/login/password|/me/logout|/my/logout|/panel/logout|"
    r"/panel/rotate-token|/panel/searches/clear|/panel/backup/export|"
    r"/panel/backup/full|/panel/backup/import|/panel/media/delete|"
    r"/panel/media/gc|/panel/businesses/bulk|/panel/businesses/export|"
    r"/panel/businesses/import|/panel/inline-edit|/panel/edits/toggle|"
    r"/panel/areas/rename|/panel/badges/auto|/panel/badges/grant|"
    r"/panel/plans/payment|/panel/unlocks/founder|"
    r"/order/create|/order/ok|/me/notifications/read|"
    r"/my/export|/subscribe|/me/name|/prices/alert)"
)
NEW_FORMS = re.compile(r"/(new)$")  # فرم‌های ساخت — با GET باز می‌شوند

# --------------------------------------------------------------- مسیرها
PUBLIC = ["/", "/businesses", "/catalog", "/map", "/pricing", "/deals",
          "/lists", "/features", "/events", "/blog", "/categories", "/cities",
          "/areas", "/nearby", "/contact", "/favorites", "/about",
          "/rules", "/register-business", "/login", "/cart", "/prices",
          "/robots.txt", "/sitemap.xml", "/manifest.webmanifest"]
OWNER = ["/my", "/my/account", "/my/businesses", "/my/orders", "/my/chats",
         "/my/stories", "/my/offers", "/my/bookings",
         "/my/inquiries", "/my/questions", "/my/reviews", "/my/plan",
         "/my/tickets", "/my/claim"]
CUSTOMER = ["/me", "/me/account", "/me/orders", "/me/chats", "/me/favorites",
            "/me/following", "/me/notifications", "/me/profile",
            "/me/login"]
PANEL = ["/panel", "/panel/businesses", "/panel/categories", "/panel/customers",
         "/panel/orders", "/panel/chats", "/panel/tickets", "/panel/media",
         "/panel/appearance", "/panel/settings", "/panel/audit",
         "/panel/insights", "/panel/features", "/panel/lists", "/panel/deals",
         "/panel/stories", "/panel/events",
         "/panel/posts", "/panel/pages", "/panel/ads", "/panel/plans",
         "/panel/subscriptions", "/panel/badges", "/panel/areas", "/panel/owners",
         "/panel/claims", "/panel/inquiries", "/panel/reports", "/panel/reviews",
         "/panel/qa", "/panel/bookings", "/panel/edits", "/panel/inbox",
         "/panel/messages", "/panel/follows", "/panel/alerts", "/panel/unlocks",
         "/panel/backup", "/panel/editor", "/panel/demo", "/panel/business/new",
         "/panel/broadcast"]

A11Y_JS = """() => {
  const out = {imgNoAlt:0, brokenImg:[], btnNoName:0, inputNoLabel:0,
               smallTap:0, minFont:999, overflow:0, h:0, fonts:[]};
  out.overflow = document.documentElement.scrollWidth - window.innerWidth;
  out.h = document.documentElement.scrollHeight;
  document.querySelectorAll('img').forEach(i => {
    if (!i.hasAttribute('alt')) out.imgNoAlt++;
    if (i.complete && i.naturalWidth === 0) out.brokenImg.push(i.getAttribute('src')||'(no src)');
  });
  document.querySelectorAll('button, a[href]').forEach(b => {
    const t = (b.innerText||'').trim();
    if (!t && !b.getAttribute('aria-label') && !b.getAttribute('title')) out.btnNoName++;
  });
  document.querySelectorAll('input,select,textarea').forEach(i => {
    if (i.type === 'hidden') return;
    const lab = i.id && document.querySelector(`label[for="${i.id}"]`);
    if (!lab && !i.getAttribute('aria-label') && !i.closest('label')) out.inputNoLabel++;
  });
  document.querySelectorAll('button, a[href], input[type=checkbox]').forEach(el => {
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return;
    if (el.closest('.leaflet-control-attribution')) return;
    if (el.tagName==='A' && /^(P|SPAN|LI|LABEL|SMALL|TD)$/.test((el.parentElement||{}).tagName||'')) return;
    if (r.height < 44 || r.width < 44) out.smallTap++;
  });
  document.querySelectorAll('body *').forEach(el => {
    if (!el.textContent || !el.textContent.trim()) return;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none') return;
    const fs = parseFloat(cs.fontSize);
    if (fs > 0 && fs < out.minFont) { out.minFont = fs; out.fonts.push((el.className||el.tagName)+'='+fs); }
  });
  return out;
}"""


def session():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)), jar


def req(op, path, data=None):
    url = BASE + path
    body = urllib.parse.urlencode(data).encode() if data else None
    r = urllib.request.Request(url, data=body, headers={
        "Content-Type": "application/x-www-form-urlencoded"})
    try:
        with op.open(r, timeout=30) as resp:
            return resp.status, resp.read()[:200]
    except urllib.error.HTTPError as e:
        return e.code, b""
    except Exception as e:  # noqa: BLE001
        return 0, str(e).encode()[:200]


def otp_login(op, phone):
    req(op, "/login", {"phone": phone})
    row = db._one("SELECT code FROM otp WHERE phone=?", (db.norm_phone(phone),))
    if not row:
        return False
    code, _ = req(op, "/login/verify", {"phone": phone, "code": row["code"]})
    return code in (200, 303)


def cookies_for(jar):
    out = []
    for c in jar:
        out.append({"name": c.name, "value": c.value, "domain": c.domain or HOST,
                    "path": c.path or "/"})
    return out


def slugify(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:60] or "root"


def main():
    tok = db.owner_token()

    # نقش‌ها
    P_OWNER, P_CUST = "09135559001", "09135559002"
    ow = db.owner_by_phone(P_OWNER, create=True)
    # پنل دکان‌دار بدون کسب‌وکار، فقط حالت خالی نشان می‌دهد؛ برای ممیزیِ واقعی
    # یک کسب‌وکار آزمون به همین مالک وصل می‌کنیم (بعد از ممیزی پاک می‌شود).
    if ow and not db.businesses_for_phone(P_OWNER):
        try:
            cats = db.categories()
            db.save_business({
                "name": "کسب‌وکار نمونهٔ ممیزی", "cat_slug": cats[0]["slug"],
                "descr": "برای جاروی بصری tools/shot_sweep.py ساخته شده.",
                "phone": P_OWNER, "status": "published", "owner_id": ow["id"]})
            print("یک کسب‌وکار آزمون برای مالک ممیزی ساخته شد")
        except Exception as e:  # noqa: BLE001
            print("ساخت کسب‌وکار آزمون ناموفق:", str(e)[:80])
    op_owner, jar_owner = session()
    # محدودساز نرخ OTP سشن‌آگاه نیست و بر اساس IP است؛ اجرای پیاپیِ آزمون‌ها
    # سهمیه را پر می‌کند. فقط برای ممیزی، سطل‌های OTP را خالی می‌کنیم.
    def reset_otp_rate():
        con = db.connect()
        con.execute("DELETE FROM ratelimit WHERE bucket LIKE 'otp:%'")
        con.commit(); con.close()

    reset_otp_rate()
    ok_owner = otp_login(op_owner, P_OWNER)
    op_cust, jar_cust = session()
    reset_otp_rate()
    req(op_cust, "/me/login", {"phone": P_CUST})
    row = db._one("SELECT code FROM otp WHERE phone=?", (db.norm_phone(P_CUST),))
    ok_cust = False
    if row:
        code, _ = req(op_cust, "/me/login/verify", {"phone": P_CUST, "code": row["code"]})
        ok_cust = code in (200, 303)
    print(f"ورود دکان‌دار: {'✓' if ok_owner else '✗'} | ورود مشتری: {'✓' if ok_cust else '✗'}")

    biz = db.businesses(limit=1)
    bslug = biz[0]["slug"] if biz else None

    roles = [("guest", [], PUBLIC),
             ("owner", cookies_for(jar_owner), OWNER),
             ("customer", cookies_for(jar_cust), CUSTOMER),
             ("admin", [], [p + ("&" if "?" in p else "?") + "key=" + tok for p in PANEL])]

    widths = [(390, "m390"), (1440, "d1440")]
    rows = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        for role, cks, pages in roles:
            print(f"\n── نقش: {role} — {len(pages)} صفحه ──")
            for w, wname in widths:
                if w != 390 and role != "guest":
                    continue  # دسکتاپ فقط برای سایت عمومی
                ctx = browser.new_context(viewport={"width": w, "height": 900},
                                          device_scale_factor=2)
                if cks:
                    ctx.add_cookies(cks)
                for path in pages:
                    if SKIP.match(path):
                        continue
                    full = path
                    if role == "guest" and path == "/b/":
                        continue
                    # یک صفحهٔ تازه برای هر مسیر: اگر شنونده‌ها روی یک صفحهٔ
                    # مشترک بمانند، خطای صفحهٔ قبلی به رکورد بعدی نسبت داده می‌شود.
                    pg = ctx.new_page()
                    rec = {"role": role, "w": w, "path": path, "console": [],
                           "failed": [], "status": 0}
                    pg.on("console", lambda m, r=rec: r["console"].append(
                        f"{m.type}: {m.text[:120]}") if m.type in ("error", "warning") else None)
                    pg.on("requestfailed", lambda rq, r=rec: r["failed"].append(
                        f"{rq.url.split(HOST)[-1][:70]}"))
                    pg.on("response", lambda rs, r=rec: r["failed"].append(
                        f"HTTP{rs.status} {rs.url.split(HOST)[-1][:70]}")
                        if rs.status >= 400 and "tile" not in rs.url else None)
                    t0 = time.time()
                    try:
                        resp = pg.goto(BASE + full, wait_until="load", timeout=45000)
                        rec["status"] = resp.status if resp else 0
                    except Exception as e:  # noqa: BLE001
                        rec["status"] = -1
                        rec["console"].append(f"nav: {str(e)[:80]}")
                    rec["ms"] = int((time.time() - t0) * 1000)
                    try:
                        rec["bytes"] = int(pg.evaluate(
                            "performance.getEntriesByType('navigation')[0].encodedBodySize"))
                    except Exception:  # noqa: BLE001
                        rec["bytes"] = 0
                    try:
                        rec.update(pg.evaluate(A11Y_JS))
                    except Exception as e:  # noqa: BLE001
                        rec["a11y_err"] = str(e)[:60]
                    name = f"{role}-{wname}-{slugify(path)}.png"
                    try:
                        h = rec.get("h") or 900
                        if h <= 3200:
                            pg.screenshot(path=os.path.join(OUT, name), full_page=True,
                                          timeout=20000, animations="disabled")
                        else:
                            pg.screenshot(path=os.path.join(OUT, name),
                                          clip={"x": 0, "y": 0, "width": w, "height": 3200},
                                          timeout=20000, animations="disabled")
                        rec["shot"] = name
                    except Exception as e:  # noqa: BLE001
                        rec["shot_err"] = str(e)[:60]
                    rec["console"] = rec["console"][:6]
                    rec["failed"] = rec["failed"][:8]
                    rows.append(rec)
                    flag = "✓" if rec["status"] == 200 else "✗"
                    extra = ""
                    if rec.get("brokenImg"):
                        extra += f" آیکون‌شکسته:{len(rec['brokenImg'])}"
                    if rec.get("overflow"):
                        extra += f" سرریز:{rec['overflow']}"
                    if rec["failed"]:
                        extra += f" خطا-درخواست:{len(rec['failed'])}"
                    if rec["console"]:
                        extra += f" کنسول:{len(rec['console'])}"
                    print(f"  {flag} {w}px {path:<34} {rec['status']} "
                          f"{rec['ms']}ms{extra}")
                    pg.close()
                ctx.close()
        browser.close()

    # یک صفحهٔ کسب‌وکار و یک محصول هم (مسیر پویا)
    extra_pages = []
    if bslug:
        extra_pages.append(f"/b/{bslug}")
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        for path in extra_pages:
            ctx = browser.new_context(viewport={"width": 390, "height": 900},
                                      device_scale_factor=2)
            pg = ctx.new_page()
            rec = {"role": "guest", "w": 390, "path": path, "console": [], "failed": []}
            pg.on("console", lambda m, r=rec: r["console"].append(f"{m.type}: {m.text[:120]}")
                  if m.type in ("error", "warning") else None)
            pg.on("response", lambda rs, r=rec: r["failed"].append(
                f"HTTP{rs.status} {rs.url.split(HOST)[-1][:70]}") if rs.status >= 400 else None)
            try:
                resp = pg.goto(BASE + path, wait_until="domcontentloaded", timeout=30000)
                rec["status"] = resp.status if resp else 0
            except Exception as e:  # noqa: BLE001
                rec["status"] = -1
                rec["console"].append(f"nav: {str(e)[:80]}")
            try:
                pg.wait_for_timeout(2500)
                rec.update(pg.evaluate(A11Y_JS))
            except Exception as e:  # noqa: BLE001
                rec["a11y_err"] = str(e)[:60]
            name = f"guest-m390-{slugify(path)}.png"
            # صفحهٔ کسب‌وکار بلند است و کاشی نقشه در محیط آفلاین هرگز کامل نمی‌شود؛
            # به‌جای full_page، فقط ۳۲۰۰ پیکسل اول را می‌گیریم.
            try:
                pg.screenshot(path=os.path.join(OUT, name),
                              clip={"x": 0, "y": 0, "width": 390, "height": 3200},
                              timeout=20000, animations="disabled")
                rec["shot"] = name
            except Exception as e:  # noqa: BLE001
                rec["shot_err"] = str(e)[:60]
            rows.append(rec)
            print(f"  {'✓' if rec['status']==200 else '✗'} 390px {path} {rec['status']}"
                  f" shot={'✓' if rec.get('shot') else '✗'}")
            ctx.close()
        browser.close()

    with open(os.path.join(OUT, "sweep.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=1)

    # خلاصه
    bad_status = [r for r in rows if r["status"] != 200]
    broken = [r for r in rows if r.get("brokenImg")]
    overflow = [r for r in rows if r.get("overflow", 0) > 0]
    smallfont = [r for r in rows if 0 < (r.get("minFont") or 999) < 12]
    smalltap = [r for r in rows if r.get("smallTap")]
    noalt = [r for r in rows if r.get("imgNoAlt")]
    nolabel = [r for r in rows if r.get("inputNoLabel")]
    errs = [r for r in rows if r["console"]]
    failed = [r for r in rows if r["failed"]]
    print("\n" + "=" * 62)
    print(f"  صفحه‌های بررسی‌شده : {len(rows)}")
    print(f"  اسکرین‌شات         : {len([r for r in rows if r.get('shot')])} → shots/v77-audit/")
    print(f"  وضعیت غیر ۲۰۰     : {len(bad_status)}")
    print(f"  تصویر/آیکون شکسته : {len(broken)}")
    print(f"  سرریز افقی        : {len(overflow)}")
    print(f"  فونت زیر ۱۲px     : {len(smallfont)}")
    print(f"  هدف لمسی < ۴۴px   : {len(smalltap)}")
    print(f"  img بدون alt      : {len(noalt)}")
    print(f"  ورودی بدون label  : {len(nolabel)}")
    print(f"  خطای کنسول        : {len(errs)}")
    print(f"  درخواست شکست‌خورده: {len(failed)}")
    print("=" * 62)
    for label, group in (("غیر۲۰۰", bad_status), ("شکسته", broken), ("سرریز", overflow),
                         ("فونت<12", smallfont), ("لمسی<44", smalltap),
                         ("alt", noalt), ("label", nolabel), ("کنسول", errs),
                         ("درخواست", failed)):
        if group:
            print(f"\n[{label}]")
            for r in group[:25]:
                detail = ""
                if label == "شکسته":
                    detail = " " + ", ".join(r["brokenImg"][:3])
                if label == "کنسول":
                    detail = " " + r["console"][0][:90]
                if label == "درخواست":
                    detail = " " + ", ".join(r["failed"][:2])
                if label == "لمسی<44":
                    detail = f" {r['smallTap']}"
                if label == "فونت<12":
                    detail = f" {r.get('minFont')}px"
                print(f"  {r['role']}/{r['w']}px {r['path']}{detail}")


if __name__ == "__main__":
    main()
