#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build a full release ZIP with one ``dastgir/`` root and no runtime data."""
import os
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERSION = (ROOT / "VERSION.txt").read_text().strip()
OUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT.parent / f"dastgir-v{VERSION}.zip"

EXCLUDE_DIRS = {"__pycache__", "data", "raw", "shots", "qa", ".git", "node_modules",
                ".arena", ".cache", "dist", "build", "target", "out", ".qa-v185",
                ".qa-browser-v185"}
EXCLUDE_PREFIX = ("site/assets/img/uploads",)
EXCLUDE_EXT = {".db", ".db-wal", ".db-shm", ".log", ".zip", ".pyc"}


def keep(rel):
    parts = rel.split("/")
    if any(p in EXCLUDE_DIRS for p in parts):
        return False
    if rel.startswith(EXCLUDE_PREFIX):
        return False
    return Path(rel).suffix.lower() not in EXCLUDE_EXT


n = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for dirpath, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for name in sorted(files):
            full = Path(dirpath) / name
            rel = full.relative_to(ROOT).as_posix()
            if not keep(rel):
                continue
            z.write(full, "dastgir/" + rel)
            n += 1

with zipfile.ZipFile(OUT) as z:
    names = z.namelist()
    bad = [x for x in names if not x.startswith("dastgir/") or
           any(part in EXCLUDE_DIRS for part in x.split("/")) or
           Path(x).suffix.lower() in EXCLUDE_EXT]
    if bad:
        raise SystemExit("excluded/path violations: " + repr(bad[:5]))
print(f"wrote {OUT}: {n} files, {OUT.stat().st_size:,} bytes")
print("excluded/path violations: none")
