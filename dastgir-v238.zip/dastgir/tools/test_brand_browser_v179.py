#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Live browser checks for the v179 fixed public name. Requires run.py."""

import os
from pathlib import Path
import sys
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "server"))
import db

BASE = os.environ.get("BZ", "http://127.0.0.1:8080")
BRAND = "دست گیر"
HOSTILE = "برند جعلی مرورگر"


def check(value, label):
    if not value:
        raise AssertionError(label)
    print("✓", label)


def main():
    token = db.owner_token()
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--no-sandbox"])
        context = browser.new_context(viewport={"width": 390, "height": 844}, locale="fa-IR")
        page = context.new_page()
        errors = []
        page.on("pageerror", lambda exc: errors.append(str(exc)))

        page.goto(f"{BASE}/panel/settings?key={token}", wait_until="networkidle")
        inp = page.locator("#g-n")
        check(inp.input_value() == BRAND and inp.get_attribute("readonly") is not None,
              "settings panel exposes the exact name as read-only")
        check(inp.get_attribute("name") is None, "settings name is omitted from submission")

        # Submit a hostile value despite the UI. Server-side filtering must win.
        status = page.evaluate("""async ([url, hostile]) => {
          const form = document.querySelector('form[action="/panel/settings"]');
          const body = new URLSearchParams(new FormData(form));
          body.set('site_name', hostile);
          const r = await fetch(url, {method:'POST', body, redirect:'manual'});
          return r.status;
        }""", [f"/panel/settings?key={token}", HOSTILE])
        check(status in (0, 200, 302, 303), "crafted settings POST is handled")

        page.goto(f"{BASE}/panel/editor?key={token}", wait_until="networkidle")
        einp = page.locator("#e-name")
        check(einp.input_value() == BRAND and einp.get_attribute("readonly") is not None,
              "editor exposes the exact name as read-only")
        check(einp.get_attribute("name") is None, "editor name is omitted from submission")

        status = page.evaluate("""async ([url, hostile]) => {
          const form = document.querySelector('form[action="/panel/editor"]');
          const body = new URLSearchParams(new FormData(form));
          body.set('site_name', hostile);
          const r = await fetch(url, {method:'POST', body, redirect:'manual'});
          return r.status;
        }""", [f"/panel/editor?key={token}", HOSTILE])
        check(status in (0, 200, 302, 303), "crafted editor POST is handled")

        for path in ("/", "/businesses", "/about", "/offline.html"):
            page.goto(BASE + path, wait_until="networkidle")
            check(HOSTILE not in page.content(), f"hostile name absent from {path}")
            if path != "/offline.html":
                check(page.locator(".brand-text").first.inner_text().splitlines()[0].strip() == BRAND,
                      f"header name is exact on {path}")
                check(page.title().endswith("| " + BRAND), f"document title is exact on {path}")
            else:
                check(BRAND in page.content(), "offline page contains the exact name")
            check(page.evaluate("document.documentElement.scrollWidth <= innerWidth"),
                  f"no horizontal overflow on {path} at 390px")

        manifest = context.request.get(BASE + "/manifest.webmanifest").json()
        check(manifest.get("name") == BRAND and manifest.get("short_name") == BRAND,
              "live PWA manifest names are exact")
        check(db.get_settings()["site_name"] == BRAND,
              "database-facing setting remains canonical after hostile POSTs")
        check(not errors, "no browser page errors")
        context.close()
        browser.close()

    print("\nهمهٔ بررسی‌های مرورگری برند v179 موفق بودند.")


if __name__ == "__main__":
    main()
