#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v232 «تمیزکاری نهایی» — global_today (dead since the v219 quota/cap
split) is gone; the live quota path is untouched; the knowledge doc covers
v223-v232.
"""
import os, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v232-')
os.environ['BZ_DATA_DIR'] = TMP
sys.path.insert(0, str(ROOT / 'server'))
import db, assistant as A
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
src = (ROOT / 'server' / 'assistant.py').read_text(encoding='utf-8')

# ---- 1. the dead counter is gone, the live quota path intact
ck('global_today' not in src.replace('global_quota_today', 'LIVE'), 'no global_today left in source')
ck(not hasattr(A, 'global_today'), 'no global_today in module')
ck(all(callable(getattr(A, f, None)) for f in ('global_quota_today', 'global_cap', 'remaining', 'digest_counts')), 'live quota/digest API intact')
ck(A.global_quota_today() == 0 and isinstance(A.global_cap(), int), 'quota counters sane on a fresh db')
ck(isinstance(A.remaining('anon', A.tier_of(None, None)), int), 'remaining() answers')

# ---- 2. the knowledge doc caught up (v223-v232)
doc = (ROOT / 'docs' / 'collaboration' / 'KNOWLEDGE.md').read_text(encoding='utf-8')
ck(all(f'## §{i}' in doc for i in (43, 44, 45)), '§43-§45 present')
ck('v232 تمیزکاری نهایی' in doc and 'booking_reminders' in doc and 'digest_counts' in doc, 'phase-3 landmarks documented')
ck('ادیت موازی هم‌فایل race می‌کند' in doc, 'the v229 race lesson recorded')

print(f"v232: {n} checks passed")
