#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v218 «دانش صحیح ورود + دانش قابل‌ویرایش» — offline tests.

1. No SMS-login claims anywhere in the assistant's knowledge (login is
   Bale/Soroush-only since v186); users asking about SMS codes get corrected.
2. ai_faq table: first-use seeding, edit/deactivate/delete flow through the
   rules, the model prompts and the context pack; backup round-trip.
"""
import os, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v218-')
os.environ['BZ_DATA_DIR'] = TMP
for k in ('AI_BASE_URL', 'AI_API_KEY', 'AI_MODEL', 'AI_MODEL_SMART', 'AI_FALLBACK_BASE_URL', 'AI_FALLBACK_API_KEY', 'AI_FALLBACK_MODEL'):
    os.environ.pop(k, None)
sys.path.insert(0, str(ROOT / 'server'))
import db, assistant as A
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
ctx = lambda key, **kw: dict({"channel": "web", "user_key": key, "customer": None, "owner": None}, **kw)

# ---- 1. login knowledge: Bale/Soroush-only, no SMS-login claim anywhere
r = A.answer("ورود", ctx("u1"))
ck(r["intent"] == "login" and "سروش" in r["text"] and "بله" in r["text"], 'login rule mentions Bale/Soroush')
ck("پیامک" not in r["text"] and "موبایل" not in r["text"], 'login rule makes no SMS claim')
r = A.answer("کد پیامک نیومده", ctx("u2"))
ck(r["intent"] == "login" and "بله" in r["text"], 'SMS-code question routes to login and gets corrected')
facts = " ".join(A._site_facts())
ck("ورود با پیامک" not in facts and "/login" in facts, 'site facts no longer say login-by-SMS')
bad = [a for _, a in A.KNOWLEDGE
       if "با شمارهٔ موبایل و کد" in a or "ورود با پیامک" in a
       or "با پیامک است" in a or "/login با پیامک" in a]
ck(not bad, 'no KNOWLEDGE entry claims SMS login')
reg = [a for q, a in A.KNOWLEDGE if "ثبت" in q][0]
acc = [a for q, a in A.KNOWLEDGE if q == "حساب مشتری"][0]
ck("بله" in reg and "سروش" in reg and "بله" in acc, 'register/account entries teach messenger login')

# ---- 2. first use seeds ai_faq from KNOWLEDGE, exactly once
ck(db._one("SELECT COUNT(*) n FROM ai_faq")["n"] == 0, 'ai_faq starts empty')
pairs = A.faqs()
ck(len(pairs) == len(A.KNOWLEDGE), 'faqs() seeds and returns the built-in list')
ck(db._one("SELECT COUNT(*) n FROM ai_faq")["n"] == len(A.KNOWLEDGE), 'seed rows persisted')
A.faqs()
ck(db._one("SELECT COUNT(*) n FROM ai_faq")["n"] == len(A.KNOWLEDGE), 'second call does not duplicate')
ck(db.ai_faq_seed([("x", "y")]) == 0, 'explicit re-seed refuses a non-empty table')

# ---- 3. an admin edit flows to rules, prompts and the context pack
row = [x for x in db.ai_faq_list(active_only=False) if x["q"] == "حساب مشتری"][0]
edited = "متن تستی ویرایش‌شدهٔ ۱۲۳ برای حساب مشتری"
db.ai_faq_upsert(row["id"], row["q"], edited, 1, row["ord"])
ck(any(a == edited for _, a in A.faqs()), 'edited answer visible in faqs()')
ck(edited in A.system_prompt(), 'edited answer visible in the intent prompt')
ck(A._faq_answer("حساب مشتری", "")["text"] == edited, 'rule-based faq answer uses the edited text')
ck(edited in A.build_context("حساب مشتری", "", ctx("u3")), 'context pack carries the edited text')

# ---- 4. deactivation hides the row everywhere; deletion removes it
tmp = db.ai_faq_upsert(None, "سؤال تستی موقت", "پاسخ تستی موقت", 1, 999)
ck(any(q == "سؤال تستی موقت" for q, _ in A.faqs()), 'new row appears in faqs()')
db.ai_faq_upsert(tmp, "سؤال تستی موقت", "پاسخ تستی موقت", 0, 999)
ck(all(q != "سؤال تستی موقت" for q, _ in A.faqs()), 'deactivated row hidden from faqs()')
ck("پاسخ تستی موقت" not in A.system_prompt(), 'deactivated row hidden from the intent prompt')
db.ai_faq_delete(tmp)
ck(db.ai_faq_get(tmp) is None, 'deleted row is gone')

# ---- 5. all-muted is respected (empty knowledge, no silent fallback)
con = db.connect(); con.execute("UPDATE ai_faq SET active=0"); con.commit(); con.close()
ck(A.faqs() == [], 'every row muted → faqs() is empty')
ck("حساب مشتری" in A.system_prompt(), 'empty table still yields a safe fallback prompt')
con = db.connect(); con.execute("UPDATE ai_faq SET active=1"); con.commit(); con.close()
ck(len(A.faqs()) == len(A.KNOWLEDGE), 're-enabling restores the rows')

# ---- 6. backup round-trip keeps the knowledge (with the admin edit)
payload = db.export_all()
ck("ai_faq" in payload and any(r["a"] == edited for r in payload["ai_faq"]), 'export_all includes ai_faq with edits')
con = db.connect(); con.execute("DELETE FROM ai_faq"); con.commit(); con.close()
ck(A.faqs() != [], 'wiped table re-seeds on next use (built-in text)')
db.import_all(payload)
ck(any(r["a"] == edited for r in db.ai_faq_list(active_only=False)), 'import_all restores ai_faq with edits')

# ---- 7. panel page renders the knowledge editor
import views_panel2 as P
html = P.assistant_page(db.get_settings(), "tok", {})
ck("دانش دستیار" in html and "faq_save" in html and "faq_delete" in html, 'panel assistant page shows the FAQ editor')
ck("حساب مشتری" in html, 'panel editor lists the seeded questions')

print(f"v218: {n} checks passed")
