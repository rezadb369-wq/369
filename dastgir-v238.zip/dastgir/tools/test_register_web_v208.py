#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v208 — staged business registration on the site, over real HTTP.

Boots run.py on a scratch data dir, mints a real owner session and walks the
seven-page wizard: guards (guest, reg_open, page reachability), server-side
validation of every page, multipart image intake (magic sniff, cap, remove),
hash-only one-use confirmation, pending-only result, legacy /submit retire,
cross-channel draft sharing with the bot core, owner-panel resume banner and
public phone masking."""
import json, os, re, shutil, subprocess, sys, tempfile, time, urllib.error, urllib.parse, urllib.request, uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TMP = tempfile.mkdtemp(prefix="dastgir-regweb-")
PORT = 8093
PNG = bytes.fromhex('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000154a24f5d0000000049454e44ae426082')
env = dict(os.environ, BZ_DATA_DIR=TMP, PORT=str(PORT))
sys.path.insert(0, str(ROOT / "server")); os.environ["BZ_DATA_DIR"] = TMP
import db, bot_register as R  # noqa
db.init()
owner = db.owner_by_phone("09125550100", create=True)
SESS = db.session_new(owner["id"])
blocked = db.owner_by_phone("09125550199", create=True); db._run("UPDATE owners SET status='blocked' WHERE id=?", (blocked["id"],))
BSESS = db.session_new(blocked["id"])
proc = subprocess.Popen([sys.executable, str(ROOT / "run.py")], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

npass = 0
def check(ok, label):
    global npass
    if not ok: raise AssertionError(label)
    npass += 1; print("  ✓", label)

class NR(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k): return None
opener = urllib.request.build_opener(NR)

def req(path, data=None, raw=None, ctype=None, sess=SESS):
    body = urllib.parse.urlencode(data).encode() if isinstance(data, dict) else raw
    r = urllib.request.Request(f"http://127.0.0.1:{PORT}{path}", data=body)
    if sess: r.add_header("Cookie", "bzv2_sess=" + sess)
    if ctype: r.add_header("Content-Type", ctype)
    try:
        x = opener.open(r, timeout=10); return x.status, x.read().decode(), x.headers.get("Location", "")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode(), e.headers.get("Location", "")

def multipart(parts):
    bd = uuid.uuid4().hex; out = b""
    for name, fn, data, ct in parts:
        out += (f'--{bd}\r\nContent-Disposition: form-data; name="{name}"; filename="{fn}"\r\nContent-Type: {ct}\r\n\r\n').encode() + data + b"\r\n"
    return out + f"--{bd}--\r\n".encode(), f"multipart/form-data; boundary={bd}"

def errs(html): return re.findall(r'<ul class="rw-errs">(.*?)</ul>', html, re.S)
B = "/register-business"
try:
    for _ in range(80):
        try:
            if urllib.request.urlopen(f"http://127.0.0.1:{PORT}/healthz", timeout=.3).status == 200: break
        except Exception: time.sleep(.1)

    # ---- entry / guards
    c, b, l = req("/submit", sess=None); check(c == 303 and l.endswith(B), "legacy GET /submit redirects to the wizard")
    c, b, l = req("/submit", {"name": "x", "cat_slug": "services", "phone": "09120000000"}, sess=None)
    check(c == 303 and db._one("SELECT COUNT(*) c FROM businesses")["c"] == 0, "legacy POST /submit no longer creates anything")
    c, b, l = req(B, sess=None); check(c == 200 and "ورود و شروع ثبت" in b and 'href="/login?next=/register-business"' in b, "guest sees intro with sign-in CTA")
    c, b, l = req(B + "/identity", sess=None); check(c == 303 and "/login?next=" in l, "guest cannot open a step page")
    c, b, l = req(B + "/category", {"cat_slug": "services"}, sess=None); check(c == 303 and "/login" in l and db._one("SELECT COUNT(*) c FROM biz_reg_drafts")["c"] == 0, "guest POST creates no draft")
    c, b, l = req(B + "/category", sess=BSESS); check(c == 303 and "/login" in l, "blocked owner session is treated as guest")
    db._run("UPDATE settings SET value='0' WHERE key='reg_open'"); db._pagecache_drop()
    c, b, l = req(B); check(c == 200 and "موقتاً بسته" in b, "reg_open=0 closes the wizard")
    c, b, l = req(B + "/category", {"cat_slug": "services"}); check(c == 303 and db._one("SELECT COUNT(*) c FROM biz_reg_drafts")["c"] == 0, "reg_open=0 blocks POST too")
    db._run("UPDATE settings SET value='1' WHERE key='reg_open'"); db._pagecache_drop()

    # ---- category
    c, b, l = req(B); check(c == 303 and l.endswith("/category"), "signed-in owner is sent to step 1")
    c, b, l = req(B + "/category"); check(c == 200 and "مرحلهٔ ۱ از ۷" in b and "data-catgrid" in b and 'class="rw-step is-locked"' in b, "step 1 renders with stepper; later steps locked")
    c, b, l = req(B + "/preview"); check(c == 303 and l.endswith("/category"), "jumping ahead is redirected to the first incomplete page")
    c, b, l = req(B + "/contact", {"phone_public": "1"}); check(c == 303 and l.endswith("/category"), "POST to an unreachable page is refused")
    c, b, l = req(B + "/category", {"cat_slug": "does-not-exist"}); check(c == 200 and "معتبر نیست" in b, "unknown category rejected")
    db._run("UPDATE categories SET active=0 WHERE slug='services'")
    c, b, l = req(B + "/category", {"cat_slug": "services"}); check(c == 200 and "معتبر نیست" in b, "inactive category rejected")
    db._run("UPDATE categories SET active=1 WHERE slug='services'")
    c, b, l = req(B + "/category", {"cat_slug": "services"}); check(c == 303 and l.endswith("/identity"), "category saved → identity")

    # ---- identity
    c, b, l = req(B + "/identity", {"name": "x"}); check(c == 200 and "حداقل" in b, "name too short")
    c, b, l = req(B + "/identity", {"name": "کافه 09121234567"}); check(c == 200 and "لینک یا شماره" in b, "phone inside name rejected")
    c, b, l = req(B + "/identity", {"name": "کافه وب", "descr": "ببینید www.site.com"}); check(c == 200 and "لینک" in b, "link in description rejected")
    c, b, l = req(B + "/identity", {"name": "کافه وب موقت", "descr": "ق" * 5000}); check(c == 303 and len(R.get(db.customer_by_phone("09125550100")["id"])["data"]["descr"]) <= 2000, "over-long description is capped (global clip_form + LIMITS_WEB)")
    db._run("INSERT INTO businesses(slug,name,cat_slug,status) VALUES('dup-x','کافه تکراری','services','published')")
    c, b, l = req(B + "/identity", {"name": "کافه تکراری"}); check(c == 200 and "قبلاً ثبت شده" in b, "exact duplicate name blocked (server side)")
    NAME = "کافه وب ۲۰۸"
    c, b, l = req(B + "/identity", {"name": NAME, "descr": "قهوهٔ تازه\n\n\n\nدمی", "tags": "قهوه، دمی"}); check(c == 303 and l.endswith("/location"), "identity saved → location")
    d = R.get(db.customer_by_phone("09125550100")["id"]); check(d["data"]["descr"] == "قهوهٔ تازه\n\nدمی" and d["platform"] == "web", "text normalised; draft platform=web")
    c, b, l = req(B + "/identity"); check(c == 200 and f'value="{NAME}"' in b, "completed page is revisitable with saved values")

    # ---- location
    c, b, l = req(B + "/location", {"city": "نجف‌آباد", "address": "کوچه"}); check(c == 200 and "نشانی" in "".join(errs(b)), "address too short")
    c, b, l = req(B + "/location", {"city": "نجف‌آباد", "address": "خیابان شریعتی ۱۰", "lat": "99", "lng": "1"}); check(c == 200 and "محدوده" in b, "coordinates outside Iran rejected")
    c, b, l = req(B + "/location", {"city": "نجف‌آباد", "address": "خیابان شریعتی ۱۰", "lat": "32.6"}); check(c == 200 and "مختصات" in b, "half a coordinate rejected")
    c, b, l = req(B + "/location", {"province": "ناکجا", "city": "نجف‌آباد", "address": "خیابان شریعتی ۱۰"}); check(c == 200 and "استان معتبر نیست" in b, "unknown province rejected")
    c, b, l = req(B + "/location", {"province": "اصفهان", "city": "نجف‌آباد", "area": "ویلاشهر", "address": "خیابان شریعتی، پلاک ۱۰", "lat": "۳۲٫۶۳", "lng": "51.36"})
    check(c == 303 and l.endswith("/contact"), "location saved (Persian digits + ٫ separator accepted) → contact")

    # ---- contact
    c, b, l = req(B + "/contact"); check(c == 200 and 'value="09125550100" readonly' in b and 'name="phone_public"' in b, "phone is read-only account phone with public toggle")
    c, b, l = req(B + "/contact", {"whatsapp": "0913abc", "website": "ftp://x", "instagram": "bad name!"}); e = "".join(errs(b))
    check(c == 200 and "واتساپ" in e and "وب‌سایت" in e and "اینستاگرام" in e, "contact fields validated individually")
    c, b, l = req(B + "/contact", {"whatsapp": "۰۹۱۳۱۲۳۴۵۶۷", "website": "https://cafe.ir", "instagram": "https://instagram.com/cafe.web/", "telegram": "@cafeweb"})
    check(c == 303 and l.endswith("/hours"), "contact saved (phone_public unchecked = private) → hours")
    d = R.get(db.customer_by_phone("09125550100")["id"]); check(d["data"]["whatsapp"] == "989131234567" and d["data"]["instagram"] == "cafe.web" and d["data"]["telegram"] == "cafeweb" and d["data"]["phone_public"] is False, "contact values normalised")
    # v211: Iranian messengers
    c, b, l = req(B + "/contact"); check(c == 200 and all(f'name="{k}"' in b for k in ("eitaa", "bale", "soroush", "rubika")) and "#i-eitaa" in b, "v211: contact step offers eitaa/bale/soroush/rubika with icons")
    c, b, l = req(B + "/contact", {"rubika": "bad name!"}); check(c == 200 and "روبیکا" in "".join(errs(b)), "v211: invalid messenger id rejected with its own label")
    c, b, l = req(B + "/contact", {"whatsapp": "۰۹۱۳۱۲۳۴۵۶۷", "website": "https://cafe.ir", "instagram": "cafe.web", "telegram": "cafeweb", "eitaa": "https://eitaa.com/cafe_web/", "bale": "@cafeweb", "soroush": "https://splus.ir/cafe.s", "rubika": "cafe_r"})
    d = R.get(db.customer_by_phone("09125550100")["id"]); check(c == 303 and d["data"]["eitaa"] == "cafe_web" and d["data"]["bale"] == "cafeweb" and d["data"]["soroush"] == "cafe.s" and d["data"]["rubika"] == "cafe_r", "v211: messenger ids normalised (url/@ stripped)")

    # ---- hours
    c, b, l = req(B + "/hours", {}); check(c == 200 and "یک گزینه" in b, "hours require a choice")
    c, b, l = req(B + "/hours", {"h_sat_open": "08:00", "h_sat_close": "22:00", "h_sun_open": "25:99", "h_sun_close": "10:00"}); check(c == 200 and "یک‌شنبه" in "".join(errs(b)), "invalid time rejected per day")
    c, b, l = req(B + "/hours", {"h_sat_open": "08:00", "h_sat_close": "22:00", "h_fri_closed": "on", "h_sun_open": "09:00", "h_sun_close": "20:00"}); check(c == 303 and l.endswith("/images"), "detailed hours saved")
    d = R.get(db.customer_by_phone("09125550100")["id"]); check(d["data"]["hours"].get("sat") == [["08:00", "22:00"]] and "fri" not in d["data"]["hours"], "detailed hours stored like the edit page")
    c, b, l = req(B + "/hours", {"preset": "split"}); check(c == 303 and "sat" in R.get(d["customer_id"])["data"]["hours"] and len(R.get(d["customer_id"])["data"]["hours"]["sat"]) == 2, "preset overrides detailed hours")

    # ---- images
    c, b, l = req(B + "/images"); check(c == 200 and "۰ از ۶" in b and "data-imagefield" in b, "images page: 0/6, picker present")
    body, ct = multipart([("images", "a.png", PNG, "image/png"), ("images", "b.pdf", b"%PDF-1.4 nope", "application/pdf")])
    c, b, l = req(B + "/images", raw=body, ctype=ct); check(c == 200 and "تصویر معتبر نیست" in b and "۱ از ۶" in b, "mixed upload: image kept, non-image refused by magic sniff")
    body, ct = multipart([("images", f"{i}.png", PNG, "image/png") for i in range(7)])
    c, b, l = req(B + "/images", raw=body, ctype=ct); check(c == 200 and "حداکثر 6" in b and "۶ از ۶" in b, "cap of 6 enforced server-side")
    imgs = R.get(d["customer_id"])["data"]["images"]; check(len(imgs) == 6 and all(p.startswith("/assets/img/uploads/bizreg-") for p in imgs), "6 images stored under bizreg prefix")
    c, b, l = req(B + "/images/remove", {"src": imgs[-1]}); check(c == 303 and len(R.get(d["customer_id"])["data"]["images"]) == 5 and not (ROOT / "site" / imgs[-1].lstrip("/")).exists(), "remove deletes from draft and disk")
    c, b, l = req(B + "/images/remove", {"src": "/assets/img/uploads/other.png"}); check(c == 303 and len(R.get(d["customer_id"])["data"]["images"]) == 5, "removing a foreign path is a no-op")
    c, b, l = req(B + "/images/done", {}); check(c == 303 and l.endswith("/preview"), "images done → preview")

    # ---- preview + submit
    c, b, l = req(B + "/preview"); tok = re.search(r'name="confirm" value="([A-Za-z0-9_-]+)"', b)
    check(c == 200 and tok and NAME in b and "0912•••0100" in b and "فقط شما و مدیر" in b and "biz-card" in b, "preview shows card, masked phone, privacy choice, confirm token")
    row = db._one("SELECT token FROM bot_confirmations WHERE action='biz_register' ORDER BY rowid DESC LIMIT 1"); check(row["token"] != tok.group(1) and len(row["token"]) == 64, "confirmation stored hash-only")
    c, b, l = req(B + "/submit", {"confirm": tok.group(1)}); check(c == 200 and "پذیرش قوانین" in b, "rules acceptance required")
    c, b, l = req(B + "/submit", {"confirm": "AAAAAAAAAAAA", "accept": "1"}); check(c == 200 and ("منقضی" in b or "نامعتبر" in b) and db._one("SELECT COUNT(*) c FROM businesses WHERE name=?", (NAME,))["c"] == 0, "forged token refused")
    tok = re.search(r'name="confirm" value="([A-Za-z0-9_-]+)"', b)
    c, b, l = req(B + "/submit", {"confirm": tok.group(1), "accept": "1"}); m = re.search(r"/done/(\d+)$", l or "")
    check(c == 303 and m, "submit accepted → done page")
    _nb = db._one("SELECT eitaa,bale,soroush,rubika FROM businesses WHERE id=?", (int(m.group(1)),)) if m else None
    check(bool(_nb) and _nb["eitaa"] == "cafe_web" and _nb["rubika"] == "cafe_r", "v211: messengers persisted on the created business")
    _pub = req(f"/b/{db.business(bid=int(m.group(1)))['slug']}", sess=None)[1] if m else ""
    check('data-track="eitaa"' not in _pub or "https://eitaa.com/cafe_web" in _pub, "v211: public page links messengers to their profile URL (when visible)")
    biz = db._one("SELECT * FROM businesses WHERE name=?", (NAME,))
    check(biz["status"] == "pending" and biz["owner_id"] == owner["id"] and biz["phone"] == "09125550100" and biz["phone_public"] == 0, "row is pending, owner-bound, verified phone, private")
    check(biz["province"] == "اصفهان" and biz["area"] == "ویلاشهر" and biz["whatsapp"] == "989131234567" and biz["website"] == "https://cafe.ir" and abs(biz["lat"] - 32.63) < 1e-6 and json.loads(biz["images"]) == R_imgs if (R_imgs := imgs[:5]) else False, "all wizard fields persisted (province, area, socials, coords, 5 images)")
    check(db._one("SELECT COUNT(*) c FROM biz_reg_drafts")["c"] == 0, "draft removed after submit")
    c, b, l = req(l); check(c == 200 and "در صف بررسی" in b, "done page renders for the owner")
    c, b, l = req(B + "/submit", {"confirm": tok.group(1), "accept": "1"}); check(db._one("SELECT COUNT(*) c FROM businesses WHERE name=?", (NAME,))["c"] == 1, "token replay creates no duplicate")
    c, b, l = req(f"{B}/done/{biz['id']}", sess=db.session_new(db.owner_by_phone('09125550177', create=True)['id'])); check(c == 303 and l.endswith("/my/businesses"), "done page of someone else's business is not shown")
    c, b, l = req(f"/b/{biz['slug']}", sess=None); check(c == 404 or c == 403 or "کافه وب ۲۰۸" not in b, "pending business is not public")
    db._run("UPDATE businesses SET status='published' WHERE id=?", (biz["id"],)); db._pagecache_drop()
    c, b, l = req(f"/b/{biz['slug']}", sess=None); check(c == 200 and "09125550100" not in b, "published with phone_public=0 → phone hidden on public page")

    # ---- panel banner + cross-channel + cancel
    c, b, l = req("/my/businesses"); check(c == 200 and "ثبت کسب‌وکار ناتمام" not in b, "no draft → no resume banner")
    cid = db.customer_by_phone("09125550100")["id"]
    R.start(cid, "soroush"); R.set_category(cid, "services"); R.set_text(cid, "نانوایی از سروش")
    c, b, l = req("/my/businesses"); check(c == 200 and "ثبت کسب‌وکار ناتمام" in b and "نانوایی از سروش" in b, "bot-started draft shows resume banner in the owner panel")
    c, b, l = req(B); check(c == 200 and "ادامهٔ ثبت" in b and f'href="{B}/location"' in b, "wizard resume page points at the first incomplete web step (location)")
    c, b, l = req(B + "/location", {"city": "نجف‌آباد", "address": "خیابان امام ۵"}); check(c == 303, "web continues the bot draft")
    check(R.get(cid)["step"] == "descr", "bot core step re-derived after web save (descr next in bot order)")
    ok, _ = R.set_text(cid, "توضیح از بات"); check(ok and R.get(cid)["step"] == "phone_public", "bot continues seamlessly after web input")
    c, b, l = req(B + "/cancel", {}); check(c == 303 and R.get(cid) is None, "cancel deletes the shared draft")
    c, b, l = req(B + "/cancel", {"restart": "1"}); check(c == 303 and l.endswith("/category") and R.get(cid) is not None, "restart creates a fresh draft")

    # ---- rate limit (separate bucket, always on)
    db.rate_clear(); hits = 0
    for i in range(65):
        c, b, l = req(B + "/category", {"cat_slug": "services"})
        if c == 303 and "/my/businesses?err=" in l: hits += 1
    check(hits >= 1, "wizard POST rate limit trips after quota")
    db.rate_clear()

    # ---- real browser: the shared image picker posts through the wizard
    try:
        from playwright.sync_api import sync_playwright
        from PIL import Image
        Image.new("RGB", (640, 480), (30, 120, 110)).save(TMP + "/real.jpg", quality=85)
        R.cancel(cid); R.start(cid, "web"); R.set_category(cid, "services")
        R.web_save(cid, {"name": "کافه مرورگر", "descr": "", "tags": ""}); R.web_save(cid, {"city": "نجف‌آباد", "area": "", "address": "خیابان شریعتی ۱۰"})
        R.web_save(cid, {"phone_public": True}); R.web_save(cid, {"hours": {}, "hours_label": "x"})
        with sync_playwright() as p:
            br = p.chromium.launch(); ctx = br.new_context(viewport={"width": 390, "height": 800}, locale="fa-IR")
            ctx.add_cookies([{"name": "bzv2_sess", "value": SESS, "domain": "127.0.0.1", "path": "/"}])
            pg = ctx.new_page(); jserr = []; pg.on("pageerror", lambda e: jserr.append(str(e)))
            pg.goto(f"http://127.0.0.1:{PORT}{B}/images", wait_until="networkidle")
            pg.set_input_files("[data-imagefield] input[data-input]", TMP + "/real.jpg")
            pg.wait_for_selector(".imgedit-overlay [data-apply]", timeout=10000); pg.click(".imgedit-overlay [data-apply]")
            pg.wait_for_selector("[data-imagefield] .imgf-item", timeout=10000)
            with pg.expect_navigation(timeout=15000): pg.click("form[enctype] button[type=submit]")
            pg.wait_for_load_state("networkidle")
            check(pg.url.endswith(B + "/images") and pg.locator(".rw-thumb").count() == 1 and not jserr, "browser: picker → editor → XHR upload → thumbnail, no JS errors")
            pg.goto(f"http://127.0.0.1:{PORT}{B}/location", wait_until="networkidle")
            pg.select_option("[data-prov]", "اصفهان"); pg.wait_for_timeout(200)
            check(pg.locator("[data-city-sel]").is_visible() and pg.locator("[data-city-sel] option").count() > 1, "browser: province select populates city list")
            br.close()
        R.cancel(cid)
    except ImportError:
        print("  ! playwright/PIL not installed — browser checks skipped")

    # ---- v208 re-review: discarded drafts must not leave orphan files
    if not os.path.exists(TMP + "/real.jpg"):
        from PIL import Image
        Image.new("RGB", (640, 480), (30, 120, 110)).save(TMP + "/real.jpg", quality=85)
    R.cancel(cid); R.start(cid, "web"); R.set_category(cid, "services")
    ok_, _e, _n = R.add_image(cid, open(TMP + "/real.jpg", "rb").read(), cap=R.MAX_IMAGES_WEB, require_step=False)
    _p = (R.get(cid)["data"].get("images") or [""])[-1]
    _disk = os.path.join(str(ROOT), "site", "assets", "img", "uploads", os.path.basename(_p))
    check(ok_ and os.path.exists(_disk), "orphan check: image stored on disk")
    R.cancel(cid)
    check(not os.path.exists(_disk), "cancel removes the draft's images from disk")
    R.start(cid, "web"); R.set_category(cid, "services")
    ok_, _e, _n = R.add_image(cid, open(TMP + "/real.jpg", "rb").read(), cap=R.MAX_IMAGES_WEB, require_step=False)
    _p = (R.get(cid)["data"].get("images") or [""])[-1]
    _disk = os.path.join(str(ROOT), "site", "assets", "img", "uploads", os.path.basename(_p))
    db._run("UPDATE biz_reg_drafts SET expires=? WHERE customer_id=?", (0, cid))
    check(R.get(cid) is None and not os.path.exists(_disk), "expiry GC removes the draft's images from disk")

    # ---- no legacy references left
    src = "".join((ROOT / "server" / f).read_text() for f in ("ui.py", "views_public.py", "views_public2.py", "views_owner.py"))
    check('href="/submit"' not in src, "no template still links to the retired /submit form")
    print(f"\nAll {npass} register-web v208 checks passed.")
finally:
    proc.terminate()
    try: proc.wait(timeout=5)
    except Exception: proc.kill()
    shutil.rmtree(TMP, ignore_errors=True)
    for f in (ROOT / "site/assets/img/uploads").glob("bizreg-*"): f.unlink()
