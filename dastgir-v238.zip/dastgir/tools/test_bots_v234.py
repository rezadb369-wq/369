#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v234 both-bots upgrade -- offline tests.

Public bot: guest (unlinked) search + near get public cards; notification
toggle edits the same message in place (fallback: new message); media-only
messages get a gentle hint instead of a bare menu. Admin bot: Jalali report
dates, week-new customers, queue viewer, active-alert line, weekly deep audit.
No network: typing/fetch/cert are stubbed, sqlite runs in a temp dir.
"""
import os, sys, tempfile, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='bots-v234-')
os.environ['BZ_DATA_DIR'] = TMP
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'
os.environ['BALE_ADMIN_SECRET'] = 's' * 40
os.environ['BALE_ADMIN_CHAT'] = '893219571'
os.environ['ADMINBOT_QUEUE'] = os.path.join(TMP, 'q')
os.environ['ADMINBOT_PENDING'] = os.path.join(TMP, 'pending.json')
os.environ['ADMINBOT_AUDIT'] = os.path.join(TMP, 'audit.json')
os.environ['ADMINBOT_WATCHDOG_STATE'] = os.path.join(TMP, 'watch.state')
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, bot_menu as M, adminbot as A, notifmeta
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

M.typing = lambda *a: True
A._fetch_url = lambda url, timeout=10: '{"ok": true}'
A.g_cert = lambda: '42'
A.NGINX_ACCESS = os.path.join(TMP, 'no-access.log')
A.NGINX_ERROR = os.path.join(TMP, 'no-error.log')
A.OFFSITE_LOG = os.path.join(TMP, 'no-offsite.log')
A.WATCHDOG_LOG = os.path.join(TMP, 'no-watchdog.log')
db.init()

sent = []
def send(cid, text, markup=None):
    sent.append((str(cid), text, markup)); return True

c = db.customer_by_phone('09120000001', create=True)
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,address,lat,lng) VALUES('t-shop','تعمیر موبایل تستی','services','published','خیابان آزمون',35.7001,51.4002)")
con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,?,?,?)", (c['id'], 'bale', 'u-link', '700'))
con.commit(); con.close()

# ---- 1. guest search gets public cards, no fav button
sent.clear()
ck(M.handle_message('bale', 'guest1', '900', '/search موبایل', send), 'guest search consumed')
blob = str(sent)
ck('تعمیر موبایل تستی' in blob and 'fav_add' not in blob, 'guest sees the card but no save button')
ck(not any('متصل کنید' in t for _, t, _ in sent), 'guest search no longer gated')

# ---- 2. guest near: keyboard + located cards
sent.clear()
M.send_near_help('901', send)
ck('نزدیک من' in sent[-1][1] and 'request_location' in str(sent[-1][2]), 'guest gets the location keyboard')
sent.clear()
M.handle_location('bale', 'guest2', '902', 35.7005, 51.4005, send)
ck(any('تعمیر موبایل تستی' in t for _, t, _ in sent), 'guest location returns nearby cards')

# ---- 3. linked search still fine (regression)
sent.clear()
M.handle_message('bale', 'u-link', '700', '/search موبایل', send)
ck('fav_add' in str(sent), 'linked search keeps the save button')

# ---- 4. toggle edits in place; fallback sends new
class FakeT:
    def __init__(self, ok): self.ok = ok; self.edits = []
    def edit_message_text(self, cid, mid, text, markup=None):
        self.edits.append((cid, mid, text)); return self.ok
real_transport = M._transport
kind = notifmeta.kinds('cust')[0]
fake_ok = FakeT(True)
M._transport = lambda p: fake_ok
sent.clear()
M.handle_callback('bale', 'u-link', '700', M.CALLBACK_PREFIX + 'notif:' + kind, send, msg_id=77)
ck(fake_ok.edits and fake_ok.edits[0][1] == 77 and not sent, 'toggle edits message 77 in place')
fake_no = FakeT(False)
M._transport = lambda p: fake_no
sent.clear()
M.handle_callback('bale', 'u-link', '700', M.CALLBACK_PREFIX + 'notif:' + kind, send, msg_id=77)
ck(sent and 'تنظیم اعلان' in sent[-1][1], 'failed edit falls back to a new message')
M._transport = real_transport

# ---- 5. media-only messages get a hint, not a bare menu
sent.clear()
ck(M.handle_message('bale', 'guest3', '903', '', send) is True, 'empty text is consumed')
ck('فقط متن' in sent[-1][1], 'media hint explains text-only support')

# ---- 6. admin Jalali dates
parts = A.fa_today().split()
ck(len(parts) == 3 and parts[2] in A._J_MONTHS, 'fa_today renders weekday/day/month')
t, _ = A.handle_text('u1', '893219571', 'گزارش')
ck(any(m in t for m in A._J_MONTHS if m), 'report header uses the Jalali date')

# ---- 7. week-new customers + queue viewer
t, _ = A.handle_text('u1', '893219571', 'دیتابیس')
ck('این هفته' in t and '(1 این هفته)' in t, 'fresh customer counted as week-new')
t, _ = A.handle_text('u1', '893219571', 'صف')
ck('خالی' in t, 'empty queue renders clean')
A.queue_write('backup')
t, _ = A.handle_text('u1', '893219571', 'صف')
ck('backup' in t and 'دقیقه در صف' in t, 'queued backup listed with age')

# ---- 8. active-alert line in status
t, _ = A.handle_text('u1', '893219571', 'وضعیت')
ck('هشدار فعال' not in t, 'no alert line when watchdog state missing')
Path(os.environ['ADMINBOT_WATCHDOG_STATE']).write_text('backup\ndisk\n')
t, _ = A.handle_text('u1', '893219571', 'وضعیت')
ck('هشدار فعال: backup, disk' in t, 'active alerts shown in status')

# ---- 9. weekly traffic parser over fixture logs
import datetime as _dt
today = _dt.date.today()
line = lambda d, code: f'1.2.3.4 - - [{d:%d/%b/%Y}:10:00:00 +0000] "GET / HTTP/1.1" {code} 10\n'
fx = Path(TMP, 'access.log'); fx.write_text(line(today, 200) + line(today, 500) + line(today - _dt.timedelta(days=9), 200))
real_glob = A.glob.glob
A.glob.glob = lambda p: [str(fx)]
try:
    ck(A._week_traffic() == (2, 1, 1), 'week parser counts hits/5xx inside 7 days only')
finally:
    A.glob.glob = real_glob
ck(A._week_traffic() == (0, 0, 0), 'missing nginx logs parse as zeros')

# ---- 10. deep audit + snapshot + weekly send
real_run = A._run
A._run = lambda *a, **k: ''
try:
    txt = A.deep_audit_text()
finally:
    A._run = real_run
ck('بررسی هفتگی' in txt and 'پیشنهاد' in txt and len(txt) <= 3500, 'audit composes bounded sections')
snap = json.loads(Path(os.environ['ADMINBOT_AUDIT']).read_text())
ck(isinstance(snap.get('disk_pct'), int), 'audit snapshot stores disk pct')
real_run2 = A._run
A._run = lambda *a, **k: ''
try:
    txt2 = A.deep_audit_text()
finally:
    A._run = real_run2
ck('بدون تغییر' in txt2, 'second run diffs against the snapshot')
calls = []
A.send_message = lambda cid, text, markup=None: calls.append(text) or True
ck(A.run_weekly_audit() is True and len(calls) == 1, 'weekly audit sends once to the owner')
os.environ['BALE_ADMIN_TOKEN'] = ''
ck(A.run_weekly_audit() is False, 'weekly audit skips without a token')
os.environ['BALE_ADMIN_TOKEN'] = 'test-token-not-real'

print(f'v234: {n} checks passed')
