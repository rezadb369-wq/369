#!/usr/bin/env python3
import os,sys,tempfile,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];TMP=tempfile.mkdtemp(prefix='soroush-v206-')
os.environ.update(BZ_DATA_DIR=TMP,SOROUSH_BOT_TOKEN='fake',SOROUSH_WEBHOOK_SECRET='s'*43,SOROUSH_BOT_USERNAME='dastgirbot')
sys.path.insert(0,str(ROOT/'server'))
import db,soroush,views_owner as O,views_customer as C
n=0
def ck(x,s):
 global n
 assert x,s;n+=1;print('  ✓',s)
try:
 db.init();c=db.customer_by_phone('09135550000',create=True)
 ch=db.messenger_challenge_new('login',platform='soroush')
 ck(db.messenger_signup_bind(ch['request_token'],'7001','8001','soroush'),'Soroush challenge binds to sender/chat')
 ok,_,a=db.messenger_signup_prepare('7001','8001','09135550000','soroush');ck(ok and a,'verified contact prepares separate approval')
 ok,_=db.messenger_signup_approve(a,'7001','8001','soroush');ck(ok,'separate Soroush approval succeeds')
 ck(db.messenger_account_by_platform('soroush','7001')['customer_id']==c['id'],'same phone maps to existing account')
 calls=[];real=soroush._call;soroush._call=lambda m,p=None:(calls.append((m,p)) or {'ok':True})
 soroush.request_signup_contact('8002')
 ck(calls[-1][1]['reply_markup']['keyboard'][0][0]['request_contact'] is True,'official request_contact button is used')
 soroush.send_approval('8002','y'*24)
 data=calls[-1][1]['reply_markup']['inline_keyboard'][0][0]['callback_data']
 ck(data.startswith('sp193:login:') and len(data.encode())<=64,'explicit callback respects 64-byte limit')
 soroush.answer_callback('cb','ok');ck(calls[-1][0]=='answerCallbackQuery','callback query is always answered')
 soroush.send_start_instructions('8002');ck('به سایت daastgir.ir' in calls[-1][1]['text'] and 'کلید ورود از قبل کپی شده' in calls[-1][1]['text'] and 'همین گفت‌وگو مستقیم باز می‌شود' in calls[-1][1]['text'],'bot /start instructions support both direct-link and manual-start flows')
 ck(soroush.app_link()=='soroush://resolve?domain=dastgirbot','official Soroush resolver opens the configured bot directly without a login secret')
 soroush._call=real
 html=O.login_unified(db.get_settings());ck('/auth/bale' in html and '/auth/soroush' in html and 'روبیکا' not in html,'Soroush fully replaces Rubika in login')
 settings=C.notif_settings_page(db.get_settings(),c);ck('سروش‌پلاس متصل است' in settings and '/me/soroush/unlink' in settings,'connected Soroush is manageable')
 src=(ROOT/'server/app.py').read_text();ck('/api/soroush/webhook/' in src and 'messenger_update_claim("soroush"' in src,'secret webhook has persistent replay claim')
 calls=[];real=soroush.send_notification;soroush.send_notification=lambda chat,text,url='':(calls.append((chat,text,url)) or True)
 db.notify_customer(c['id'],'order','سفارش تازه','/me/orders');soroush.send_notification=real
 ck(calls and calls[0][0]=='8001','notification core fans out to linked Soroush chat')
 print(f'\nAll {n} Soroush v206 checks passed.')
finally:shutil.rmtree(TMP,ignore_errors=True)
