#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v235 bot panels -- offline tests.

Customer: order-cancel request flow (direct within the window, requested
after it, pending marker + detail state, access control). Owner: cancel
queue + approve/reject, 7-day sales stats, chat quick-replies, business
hide/show toggle, panel badge. No network: sqlite runs in a temp dir.
"""
import os, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='panels-v235-')
os.environ['BZ_DATA_DIR'] = TMP
sys.path.insert(0, str(ROOT / 'server'))
import db, bot_menu as M
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

M.typing = lambda *a: True
db.init()

sent, callbacks = [], []
def send(cid, text, markup=None):
    sent.append((str(cid), text, markup))
    if isinstance(markup, dict):
        for row in markup.get('inline_keyboard', []) or []:
            for b in row:
                if isinstance(b, dict) and b.get('callback_data'):
                    callbacks.append(b['callback_data'])
    return True

# ---- seed: helpers first, then raw SQL + single commit (v109 gotcha) ----
buyer = db.customer_by_phone('09120000035', create=True)
stranger = db.customer_by_phone('09120000036', create=True)
owner = db.owner_by_phone('09120000037', create=True)
owner_cust = db.customer_by_phone('09120000037', create=True)
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id,address,published_once) VALUES('o-shop','فروشگاه مالک','services','published',?,'آدرس',1)",
            (owner['id'],))
con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,?,?,?)",
            (buyer['id'], 'bale', 'u-buyer', '710'))
con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,?,?,?)",
            (stranger['id'], 'bale', 'u-stranger', '711'))
con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,?,?,?)",
            (owner_cust['id'], 'bale', 'u-owner', '712'))
con.commit(); con.close()
biz = db.businesses_of(owner['id'])[0]['id']

def mk_order(cid, name='خریدار', phone='09120000035', total=1000):
    return db.create_order(biz, cid, name, phone, 'آدرس', '',
                           [{'item_id': None, 'title': 'کالا', 'price': total, 'qty': 1}])
o_direct = mk_order(buyer['id'])
o_req = mk_order(buyer['id'])
o_req2 = mk_order(buyer['id'])
o_done = mk_order(buyer['id'])
o_open = mk_order(buyer['id'])
o_alien = mk_order(stranger['id'], name='غریبه', phone='09120000036')
con = db.connect()
con.execute("UPDATE orders SET created='2020-01-01 00:00:00' WHERE id IN (?,?)", (o_req, o_req2))
con.execute("UPDATE orders SET status='done' WHERE id=?", (o_done,))
con.execute("INSERT INTO bookings(biz_id,name,phone,date,time,note,customer_id) VALUES(?,?,?,?,?,?,?)",
            (biz, 'خریدار', '09120000035', db.iran_now().strftime('%Y/%m/%d'), '10:00', '', buyer['id']))
con.commit(); con.close()
tid = db.chat_start(biz, buyer['id'])
db.chat_send(tid, 'customer', 'سلام، سفارشم کی می‌رسد؟')

P = M.CALLBACK_PREFIX

# ---- C1.1 detail of a fresh order offers the cancel button ----
sent.clear()
def all_cbs(markup):
    out = []
    for row in (markup or {}).get('inline_keyboard', []) or []:
        for b in row or []:
            if isinstance(b, dict) and b.get('callback_data'):
                out.append(b['callback_data'])
    return out
ck(M.send_order('bale', 'u-buyer', '710', o_direct, send), 'order detail renders')
ck(P + f'order_cancel:{o_direct}' in all_cbs(sent[-1][2]), 'fresh order detail has the cancel button')

# ---- C1.2 reason screen ----
sent.clear()
M.send_order_cancel_reasons('bale', 'u-buyer', '710', o_direct, send)
blob = str(sent)
ck('دلیل لغو' in blob and all(f'order_cancel_reason:{o_direct}:{i}' in blob for i in range(3)), 'reason screen lists 3 preset reasons')

# ---- C1.3 direct cancel inside the window ----
sent.clear()
M.execute_order_cancel('bale', 'u-buyer', '710', o_direct, '0', send)
ck('لغو شد' in sent[-1][1], 'fresh order cancels directly')
ck(db.order(o_direct)['status'] == 'cancelled', 'db: direct cancel flips status')

# ---- C1.4 old order becomes a request, with pending state ----
sent.clear()
M.execute_order_cancel('bale', 'u-buyer', '710', o_req, '1', send)
ck('درخواست لغو ثبت شد' in sent[-1][1] and 'دقیقه' in sent[-1][1], 'old order files a request with the window note')
ck(db.order(o_req)['cancel_requested'] == 1, 'db: request flag set')
sent.clear()
M.send_order('bale', 'u-buyer', '710', o_req, send)
ck('⏳' in sent[-1][1] and f'order_cancel:{o_req}' not in str(sent[-1][2]), 'pending detail shows the state line, hides the button')
sent.clear()
M.send_orders('bale', 'u-buyer', '710', send)
ck('⏳' in sent[-1][1], 'orders list marks the pending request')

# ---- C1.5 access control ----
sent.clear()
M.execute_order_cancel('bale', 'u-stranger', '711', o_open, '0', send)
ck('حساب شما نیست' in sent[-1][1], 'stranger cannot cancel another order')
sent.clear()
M.send_order_cancel_reasons('bale', 'u-buyer', '710', o_done, send)
ck('قابل لغو نیست' in sent[-1][1], 'done order refuses the reason screen')
sent.clear()
M.send_order('bale', 'u-buyer', '710', o_done, send)
ck(f'order_cancel:{o_done}' not in str(sent[-1][2]), 'done order detail has no cancel button')

# ---- O0 owner panel badge + new buttons ----
sent.clear()
M.execute_order_cancel('bale', 'u-buyer', '710', o_req2, '2', send)
M.send_owner('bale', 'u-owner', '712', send)
blob = str(sent)
ck('⏳ لغو در انتظار' in blob, 'owner panel shows the cancel badge')
ck(all(k in blob for k in ('owner_cancels', 'owner_stats', 'owner_biz')), 'owner panel links cancels/stats/biz')
sent.clear()
M.send_help('bale', 'u-buyer', '710', send)
ck('آمار فروش' in sent[-1][1], 'help advertises the owner panel')

# ---- O3 owner cancel queue ----
sent.clear()
M.send_owner_cancels('bale', 'u-owner', '712', send)
blob = str(sent)
ck(f'owner_cancel:{o_req}' in blob and f'owner_cancel:{o_req2}' in blob, 'queue lists both pending requests')
ck('اشتباه ثبت کردم' in blob and 'زمان تحویل' in blob, 'queue shows each chosen reason')
sent.clear()
M.confirm_owner_cancel('bale', 'u-owner', '712', o_req, send)
blob = str(sent)
ck(f'owner_cancel_ok:{o_req}' in blob and f'owner_cancel_no:{o_req}' in blob, 'review screen has approve + reject')
sent.clear()
M.send_owner_cancels('bale', 'u-buyer', '710', send)
ck('دسترسی مالک' in sent[-1][1], 'non-owner is denied the queue')

# ---- O3 approve + double-tap + reject ----
sent.clear()
M.execute_owner_cancel('bale', 'u-owner', '712', o_req, True, send)
ck('لغو شد' in sent[-1][1], 'approve cancels the order')
ck(db.order(o_req)['status'] == 'cancelled' and db.order(o_req)['cancel_requested'] == 0, 'db: approve flips status, clears flag')
sent.clear()
M.execute_owner_cancel('bale', 'u-owner', '712', o_req, True, send)
ck('قبلاً بررسی' in sent[-1][1], 'double-tap approve is safe')
sent.clear()
M.execute_owner_cancel('bale', 'u-owner', '712', o_req2, False, send)
ck('رد شد' in sent[-1][1], 'reject keeps the order alive')
ck(db.order(o_req2)['status'] == 'new' and db.order(o_req2)['cancel_requested'] == 0, 'db: reject clears flag only')

# ---- O1 sales stats ----
s = db.owner_sales_summary(owner['id'])
ck(s['rev7'] >= 1000 and s['rev7_count'] >= 1, 'summary counts the done order revenue')
ck(s['open_count'] >= 2 and s['bookings7'] >= 1 and s['cancel_pending'] == 0, 'summary counts open/bookings/pending')
ck(db.owner_sales_summary(999999) == {"rev7": 0, "rev7_count": 0, "open_value": 0, "open_count": 0, "bookings7": 0, "cancel_pending": 0},
   'summary is zero-safe for unknown owners')
sent.clear()
M.send_owner_stats('bale', 'u-owner', '712', send)
blob = str(sent)
ck('📊' in blob and '۷ روز' in blob and 'نوبت ۷ روز' in blob, 'stats screen renders all four lines')

# ---- O2 owner quick replies ----
sent.clear()
M.send_owner_chat('bale', 'u-owner', '712', tid, send)
blob = str(sent)
ck(f'owner_reply:{tid}:thanks' in blob and f'owner_reply:{tid}:busy' in blob, 'open thread offers quick replies')
sent.clear()
M.confirm_owner_reply('bale', 'u-owner', '712', tid, 'thanks', send)
tok = None
for _, _, m in sent:
    for row in (m or {}).get('inline_keyboard', []) or []:
        for b in row:
            if (b.get('callback_data') or '').startswith(P + 'owner_reply_yes:'):
                tok = b['callback_data'].split(':')[-1]
ck(bool(tok) and 8 <= len(tok) <= 24, 'confirm step mints a token callback')
sent.clear()
M.send_owner_reply('bale', 'u-owner', '712', tok, send)
ck('ارسال شد' in sent[-1][1], 'owner reply sends')
last = db.owner_chat_detail(owner['id'], tid)['messages'][-1]
ck(last['body'] == M.OWNER_CHAT_REPLIES['thanks'] and last['sender'] == 'owner', 'db: reply stored with owner sender')
sent.clear()
M.send_owner_reply('bale', 'u-owner', '712', tok, send)
ck('منقضی یا قبلاً' in sent[-1][1], 'token replay is rejected')
ck(db.owner_chat_reply_prepare(owner['id'], 999999, 'x') == '', 'prepare refuses unknown threads')
ck(db.owner_chat_reply_prepare(999999, tid, 'x') == '', 'prepare refuses foreign owners')

# ---- O4 hide/show toggle ----
sent.clear()
M.send_owner_biz('bale', 'u-owner', '712', send)
blob = str(sent)
ck('فروشگاه مالک' in blob and '🟢 منتشر' in blob and f'owner_biz_toggle:{biz}' in blob, 'biz list shows status + toggle')
sent.clear()
M.confirm_owner_biz_toggle('bale', 'u-owner', '712', biz, send)
ck(str(sent).find(f'owner_biz_toggle_yes:{biz}:hide') != -1, 'published shop confirms hide')
sent.clear()
M.execute_owner_biz_toggle('bale', 'u-owner', '712', biz, 'hide', send)
ck('بسته شد' in sent[-1][1], 'hide executes')
ck(db.business(bid=biz)['status'] == 'hidden', 'db: status is hidden')
sent.clear()
M.execute_owner_biz_toggle('bale', 'u-owner', '712', biz, 'hide', send)
ck('انجام نشد' in sent[-1][1], 'stale hide callback fails safe (no flip-flop)')
sent.clear()
M.confirm_owner_biz_toggle('bale', 'u-owner', '712', biz, send)
ck(f'owner_biz_toggle_yes:{biz}:show' in str(sent), 'hidden shop confirms show')
sent.clear()
M.execute_owner_biz_toggle('bale', 'u-owner', '712', biz, 'show', send)
ck('منتشر شد' in sent[-1][1] and db.business(bid=biz)['status'] == 'published', 'show republishes')

# ---- dispatch wires every new callback through handle_callback ----
sent.clear()
for cb in (f'order_cancel:{o_open}', f'owner_cancels', 'owner_stats', 'owner_biz',
           f'owner_biz_toggle:{biz}', f'owner_reply:{tid}:site'):
    ck(M.handle_callback('bale', 'u-buyer' if cb.startswith('order_cancel:') else 'u-owner',
                         '710' if cb.startswith('order_cancel:') else '712', P + cb, send),
       f'dispatch accepts {cb.split(":")[0]}')

# ---- every callback minted in this session fits the 64-byte cap ----
bad = [c for c in callbacks if len(c.encode()) > 64]
ck(not bad, f'all {len(callbacks)} callbacks fit 64 bytes')

print(f'v235 panels: {n} checks green')
