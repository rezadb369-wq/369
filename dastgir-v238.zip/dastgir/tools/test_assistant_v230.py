#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v230 «پیامک درخواست لغو» — a cancel request pages the shop's own phone
(SMS), once per request: re-requests stay silent, direct cancels stay
inbox-only, and a shop without a phone still gets its in-app note.
"""
import os, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v230-')
os.environ['BZ_DATA_DIR'] = TMP
sys.path.insert(0, str(ROOT / 'server'))
import db, sms
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
own = db.owner_by_phone('09120000110', create=True)
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id,phone) VALUES(?,?,?,?,?,?)",
            ('sms-shop', 'مغازه پیامکی', 'services', 'published', own['id'], '09120000111'))
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id) VALUES(?,?,?,?,?)",
            ('nosms-shop', 'مغازه بی‌تلفن', 'services', 'published', own['id']))
con.commit(); con.close()
biz = db.business(slug='sms-shop'); biz2 = db.business(slug='nosms-shop')
cust = db.customer_by_phone('09120000112', create=True)
custB = db.customer_by_phone('09120000113', create=True)
mk = lambda b: db.create_order(b["id"], cust["id"], "کیوای", cust["phone"], "نشانی", "",
                               [{"title": "کالا", "price": 9000, "qty": 1}])
o_stale, o_fresh, o_nophone, o_done = mk(biz), mk(biz), mk(biz2), mk(biz)
db._run("UPDATE orders SET created='2026-09-01 10:00:00' WHERE id IN (?,?,?)", (o_stale, o_nophone, o_done))
db._run("UPDATE orders SET status='done' WHERE id=?", (o_done,))
notes = lambda: db._rows("SELECT owner_id, kind, text, link FROM owner_notifications ORDER BY id")

calls = []
real_notify = sms.notify
sms.notify = lambda s, p, t: calls.append((p, t)) or True
try:
    # ---- 1. requested → one SMS to the shop; re-request silent
    r = db.request_order_cancel(o_stale, cust["id"], "نمی‌خوام")
    ck(r["result"] == "requested", 'stale order → requested')
    ck(len(calls) == 1 and calls[0][0] == "09120000111", 'exactly one SMS to the shop phone')
    ck(f"#{o_stale}" in calls[0][1] and "تأیید یا رد" in calls[0][1], 'SMS names the order and the action')
    db.request_order_cancel(o_stale, cust["id"], "باز هم نمی‌خوام")
    ck(len(calls) == 1, 're-request pages nobody (exactly-once)')

    # ---- 2. direct cancel / errors never page
    ck(db.request_order_cancel(o_fresh, cust["id"])["result"] == "cancelled", 'fresh order → cancelled')
    ck(len(calls) == 1, 'direct cancel stays inbox-only')
    ck(db.request_order_cancel(o_done, cust["id"]) == {"ok": False, "error": "final"}, 'done → final')
    ck(db.request_order_cancel(o_stale, custB["id"]) == {"ok": False, "error": "access"}, "stranger → access")
    ck(len(calls) == 1, 'errors page nobody')

    # ---- 3. a fresh decision needed → paged again
    ck(db.decide_order_cancel(o_stale, approve=False) is True, 'owner rejects the request')
    db.request_order_cancel(o_stale, cust["id"], "نظرم عوض نشد")
    ck(len(calls) == 2 and f"#{o_stale}" in calls[1][1], 'request after reject pages again')

    # ---- 4. no shop phone → inbox only, nothing breaks
    n0 = len(notes())
    ck(db.request_order_cancel(o_nophone, cust["id"])["result"] == "requested", 'phoneless shop → requested')
    ck(len(calls) == 2, 'no SMS without a shop phone')
    ck(len(notes()) == n0 + 1 and notes()[-1]["link"] == "/my/orders", 'inbox note still delivered')
finally:
    sms.notify = real_notify

# ---- 5. the real sender without a key: silent False, no HTTP, no raise
ck(sms.notify(db.get_settings(), "09120000111", "تست") is False, 'no sms_key → False, never raises')

print(f"v230: {n} checks passed")
