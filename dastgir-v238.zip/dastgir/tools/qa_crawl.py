#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""خزندهٔ کامل QA v160 — کل صفحات سایت با ۴ هویت + گیت پنل با کلید واقعی"""
import re, sys, json, sqlite3, collections, threading, urllib.request, urllib.parse, http.cookiejar, urllib.error

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

PANEL_KEY = DBM.owner_token()

def make_session():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def open_it(op, path, data=None, headers=None):
    safe = urllib.parse.quote(path, safe="/?&=%+:.,-_~!$'()*;@")
    req = urllib.request.Request(BASE + safe, data=data, headers=headers or {})
    try:
        r = op.open(req, timeout=20)
        return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()

def otp_code(phone):
    conn = sqlite3.connect("data/bazarche.db")
    row = conn.execute("select code from otp where phone=? order by rowid desc limit 1", (phone,)).fetchone()
    conn.close()
    return row[0] if row else None

def login_owner(op, phone):
    open_it(op, "/login")
    open_it(op, "/login", data=urllib.parse.urlencode({"phone": phone}).encode(),
            headers={"Content-Type": "application/x-www-form-urlencoded"})
    code = otp_code(phone)
    if code:
        open_it(op, "/login/verify", data=urllib.parse.urlencode({"phone": phone, "code": code}).encode(),
                headers={"Content-Type": "application/x-www-form-urlencoded"})
    # گیت پنل با کلید (کوکی ادمین ضرب می‌شود)
    open_it(op, "/panel?key=" + PANEL_KEY)

def login_me(op, phone):
    open_it(op, "/me/login")
    open_it(op, "/me/login", data=urllib.parse.urlencode({"phone": phone}).encode(),
            headers={"Content-Type": "application/x-www-form-urlencoded"})
    code = otp_code(phone)
    if code:
        open_it(op, "/me/login/verify", data=urllib.parse.urlencode({"phone": phone, "code": code}).encode(),
                headers={"Content-Type": "application/x-www-form-urlencoded"})

SKIP = re.compile(r"\.(css|js|png|jpg|jpeg|webp|gif|svg|woff2?|ico|webmanifest|txt|xml|csv|mp4)(\?|$)|^/assets/|^/chat-file/|^/ticket-file/|^/healthz|^/qr/|^/logout")
def crawl(op, seeds, max_pages=2500):
    seen, results, q = set(), {}, collections.deque(seeds)
    while q and len(seen) < max_pages:
        path = q.popleft()
        if path in seen or SKIP.search(path):
            continue
        seen.add(path)
        st, body = open_it(op, path)
        results[path] = (st, len(body))
        if st == 200:
            html = body.decode("utf-8", "replace")
            for href in re.findall(r'href="(/[^"#]*)"', html):
                href = urllib.parse.unquote(href)
                if href.startswith("/") and not SKIP.search(href) and href not in seen:
                    q.append(href)
    return results

def main():
    out = {}
    anon = make_session()
    out["anon"] = crawl(anon, ["/", "/categories", "/businesses", "/map", "/blog", "/pricing",
                               "/contact", "/register-business", "/lists", "/deals", "/cities", "/areas", "/cart"])
    cust = make_session(); login_me(cust, "09361112233")
    out["customer"] = crawl(cust, ["/me", "/cart", "/", "/favorites"])
    shop = make_session(); login_me(shop, "09352223344")
    out["shop"] = crawl(shop, ["/my"])
    adm = make_session(); login_owner(adm, "09131110011")
    out["owner"] = crawl(adm, ["/panel", "/my"])

    json.dump({r: {p: {"s": s, "b": n} for p, (s, n) in sorted(pages.items())} for r, pages in out.items()},
              open("/tmp/qa-crawl.json", "w"), ensure_ascii=False, indent=1)
    print("── شمار صفحه در هر نقش:", {r: len(p) for r, p in out.items()})
    problems = [(r, p, s, n) for r, pages in out.items() for p, (s, n) in pages.items() if s != 200]
    print("── غیر 200:")
    print("  هیچ ✔" if not problems else "\n".join(f"  [{r}] {p} → {s} ({n}b)" for r, p, s, n in problems))

if __name__ == "__main__":
    main()
