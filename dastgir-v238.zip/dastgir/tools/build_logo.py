#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""سازندهٔ تکرارپذیر لوگوی تأییدشدهٔ کاربر برای «دست گیر» (v179).

منبع قطعی:
  site/assets/img/logo-source.png

رابط سایت خودِ PNG اصلی ۷۶۸px را نمایش می‌دهد تا کیفیت کامل ثابت بماند. فایل‌های
SVG مستقل، مشتق ۲۵۶px بدون فشرده‌سازی اتلافی‌اند (بالاتر از بیشترین اندازهٔ مصرف
رابط و مناسب HiDPI) تا چهار کپی ۳۴۲KB تکرار نشود. فاویکون مستقل ۱۲۸px است؛
این اندازه از بیشترین اندازهٔ نمایش favicon بزرگ‌تر است.
"""

from __future__ import annotations

import base64
import io
from pathlib import Path

from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
IMG = ROOT / "site" / "assets" / "img"
ICONS = IMG / "icons"
SOURCE = IMG / "logo-source.png"


def png_data(im: Image.Image) -> str:
    """PNG بهینه و مستقل برای فاویکون، بدون فشرده‌سازی اتلافی."""
    buf = io.BytesIO()
    if im.mode == "RGB":
        im = im.quantize(colors=128, method=Image.Quantize.MEDIANCUT,
                         dither=Image.Dither.NONE)
    im.save(buf, "PNG", optimize=True)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def svg_display(src: Image.Image, *, label: str = "نشان دست گیر") -> str:
    """نسخهٔ مستقل ۲۵۶px؛ برای نمایش‌های رابط تا ۱۵۰px و HiDPI کافی است."""
    display = src.resize((256, 256), Image.Resampling.LANCZOS)
    data = png_data(display)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" '
            f'role="img" aria-label="{label}">'
            f'<image width="256" height="256" href="data:image/png;base64,{data}"/></svg>')


def svg_favicon(src: Image.Image) -> str:
    """فاویکون مستقل و target-sized برای سازگاری کامل مرورگرها."""
    small = src.resize((128, 128), Image.Resampling.LANCZOS)
    data = png_data(small)
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" '
            'role="img" aria-label="نشان دست گیر">'
            '<defs><clipPath id="c"><rect width="128" height="128" rx="16"/>'
            '</clipPath></defs><image width="128" height="128" '
            f'href="data:image/png;base64,{data}" clip-path="url(#c)"/></svg>')


def fit_icon(src: Image.Image, size: int, scale: float, rounded: bool) -> Image.Image:
    canvas = Image.new("RGB", (size, size), "white")
    side = max(1, round(size * scale))
    mark = src.resize((side, side), Image.Resampling.LANCZOS)
    canvas.paste(mark, ((size - side) // 2, (size - side) // 2))
    if rounded:
        mask = Image.new("L", (size, size), 0)
        ImageDraw.Draw(mask).rounded_rectangle((0, 0, size - 1, size - 1),
                                               radius=round(size * 0.20), fill=255)
        out = Image.new("RGBA", (size, size), (255, 255, 255, 0))
        out.paste(canvas, (0, 0), mask)
        return out
    return canvas


def main() -> None:
    if not SOURCE.exists():
        raise SystemExit(f"منبع لوگو پیدا نشد: {SOURCE}")
    ICONS.mkdir(parents=True, exist_ok=True)
    src = Image.open(SOURCE).convert("RGB")
    if src.size != (768, 768):
        raise SystemExit(f"logo-source.png باید 768×768 باشد، نه {src.size}")

    normal = svg_display(src)
    (IMG / "logo.svg").write_text(normal, encoding="utf-8")
    (IMG / "logo-mark.svg").write_text(normal, encoding="utf-8")
    (IMG / "favicon.svg").write_text(svg_favicon(src), encoding="utf-8")
    (IMG / "logo-lockup.svg").write_text(svg_display(src, label="دست گیر"), encoding="utf-8")
    # v183: نسخهٔ مخصوص هدر/فوتر. ۱۹۲px برای نمایش ۳۸px حتی روی DPR=5
    # کافی است و به‌جای دانلود منبع ۷۶۸px، بیش از ۸۰٪ انتقال را کم می‌کند.
    src.resize((192, 192), Image.Resampling.LANCZOS).save(
        IMG / "logo-display.png", "PNG", optimize=True)

    fit_icon(src, 192, 0.90, True).save(ICONS / "app-192.png", optimize=True)
    fit_icon(src, 512, 0.90, True).save(ICONS / "app-512.png", optimize=True)
    # ناحیهٔ امن maskable: نقش اصلی در ۶۶٪ بوم قرار می‌گیرد.
    fit_icon(src, 512, 0.66, False).save(ICONS / "maskable-512.png", optimize=True)

    for p in (IMG / "logo.svg", IMG / "logo-mark.svg", IMG / "favicon.svg",
              IMG / "logo-lockup.svg", IMG / "logo-display.png", ICONS / "app-192.png",
              ICONS / "app-512.png", ICONS / "maskable-512.png"):
        print(f"✓ {p.relative_to(ROOT)} ({p.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
