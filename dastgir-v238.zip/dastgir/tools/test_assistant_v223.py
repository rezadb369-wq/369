#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v223 «ابزار امن مدل» — offline tests with a programmable fake model.

The model only PROPOSES (favorite/cancel_booking/cancel_order); the server
validates (login, schema, ownership, live policy), executes through the
site's own functions and audit-logs. favorite runs at once (+ undo hint);
cancellations need a «بله» turn within 10 minutes. Tool answers are never
cached; «بله» with nothing pending keeps its faq meaning.
"""
import os, sys, tempfile, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v223-')
os.environ['BZ_DATA_DIR'] = TMP
for k in ('AI_BASE_URL', 'AI_API_KEY', 'AI_MODEL', 'AI_MODEL_SMART', 'AI_FALLBACK_BASE_URL', 'AI_FALLBACK_API_KEY', 'AI_FALLBACK_MODEL'):
    os.environ.pop(k, None)
sys.path.insert(0, str(ROOT / 'server'))
import db, assistant as A
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
db.set_settings({"ai_quota_free": "100"})
ctx = lambda key, **kw: dict({"channel": "web", "user_key": key, "customer": None, "owner": None}, **kw)

own = db.owner_by_phone("09120000081", create=True)
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id) VALUES(?,?,?,?,?)",
            ("tool-shop", "مغازه ابزاری", "services", "published", own["id"]))
con.commit(); con.close()
biz = db.business(slug="tool-shop")
cust = db.customer_by_phone("09120000082", create=True)
ckey = f"cust:{cust['id']}"
cc = lambda: ctx(ckey, customer=cust)
con = db.connect()
con.execute("INSERT INTO bookings(biz_id,name,phone,date,time,status,customer_id) VALUES(?,?,?,?,?,?,?)",
            (biz["id"], "تست", cust["phone"], "2026-09-10", "10:00", "new", cust["id"]))
con.execute("INSERT INTO bookings(biz_id,name,phone,date,time,status,customer_id) VALUES(?,?,?,?,?,?,?)",
            (biz["id"], "تست", cust["phone"], "2026-09-11", "11:00", "confirmed", cust["id"]))
con.execute("INSERT INTO bookings(biz_id,name,phone,date,time,status,customer_id) VALUES(?,?,?,?,?,?,?)",
            (biz["id"], "تست", cust["phone"], "2026-09-01", "09:00", "done", cust["id"]))
con.commit(); con.close()
b_new, b_conf, b_done = [r["id"] for r in db._rows(
    "SELECT id FROM bookings WHERE customer_id=? ORDER BY id", (cust["id"],))]
oid = db.create_order(biz["id"], cust["id"], "کاربر", cust["phone"], "نشانی", "", [{"title": "کالا", "price": 5000, "qty": 1}])
oid_old = db.create_order(biz["id"], cust["id"], "کاربر", cust["phone"], "نشانی", "", [{"title": "کالا", "price": 5000, "qty": 1}])
oid_done = db.create_order(biz["id"], cust["id"], "کاربر", cust["phone"], "نشانی", "", [{"title": "کالا", "price": 5000, "qty": 1}])
db._run("UPDATE orders SET created='2026-09-01 10:00:00' WHERE id=?", (oid_old,))
db._run("UPDATE orders SET status='done' WHERE id=?", (oid_done,))
custB = db.customer_by_phone("09120000083", create=True)
ckeyB = f"cust:{custB['id']}"

calls = []
def fake_chat(base, key, model, messages, timeout, max_tokens=220):
    calls.append(messages[-1]["content"])
    txt = messages[-1]["content"]
    tc = None
    if "FAV-EVIL" in txt: tc = {"name": "favorite", "args": {"slug": "nope-missing"}}
    elif "FAV" in txt: tc = {"name": "favorite", "args": {"slug": "tool-shop"}}
    elif "BOOK" in txt: tc = {"name": "cancel_booking", "args": {"id": int(txt.split("BOOK")[1].split()[0])}}
    elif "ORD-OLD" in txt: tc = {"name": "cancel_order", "args": {"id": oid_old}}
    elif "ORD-DONE" in txt: tc = {"name": "cancel_order", "args": {"id": oid_done}}
    elif "ORD" in txt: tc = {"name": "cancel_order", "args": {"id": oid}}
    elif "WEIRD" in txt: tc = {"name": "delete_all", "args": {}}
    elif "BADARGS" in txt: tc = {"name": "favorite", "args": {}}
    ans = {"answer": "مدل: " + txt[:30], "links": [], "scope": True, "intent": "orders",
           "tool_call": tc}
    return json.dumps(ans, ensure_ascii=False), 100
A._chat = fake_chat
os.environ.update(AI_BASE_URL="https://api.example.invalid/v1", AI_API_KEY="test-key-not-real",
                  AI_MODEL="fake-lite")

# ---- 1. strict parsing: unknown tools and bad shapes never pass
ck(A.parse_tool_call({"name": "favorite", "args": {"slug": "a-b"}}) == ("favorite", {"slug": "a-b"}), 'favorite parses')
ck(A.parse_tool_call({"name": "cancel_booking", "args": {"id": "12"}}) == ("cancel_booking", {"id": 12}), 'string id coerced')
for junk in ({"name": "delete_all", "args": {}}, {"name": "favorite", "args": {}},
             {"name": "favorite", "args": {"slug": "a b"}}, {"name": "favorite", "args": {"slug": "a/b"}},
             {"name": "cancel_order", "args": {"id": "abc"}}, {"name": "cancel_order", "args": {"id": 0}},
             {"name": "cancel_order", "args": {"id": -3}}, "x", None, {"name": "favorite"}):
    assert A.parse_tool_call(junk) == (None, {}), junk
ck(True, 'unknown tools / bad shapes / bad ids rejected')
ck(A.parse_answer_json('{"answer":"x","tool_call":{"name":"favorite","args":{"slug":"s"}}}')["tool_call"] == {"name": "favorite", "args": {"slug": "s"}}, 'answer parser keeps valid tool_call')
ck(A.parse_answer_json('{"answer":"x","tool_call":123}')["tool_call"] is None, 'answer parser drops junk tool_call, keeps answer')

# ---- 2. favorite: immediate, reversible, honest
r = A.answer("FAV لطفا", cc())
ck(r["source"] == "llm" and "مغازه ابزاری" in r["text"] and "ذخیره شد" in r["text"], 'favorite executes at once with the live name')
ck(db._one("SELECT COUNT(*) c FROM favorites WHERE customer_id=?", (cust["id"],))["c"] == 1, 'fav row written')
ck("/me/favorites" in [h for _, h in r["links"]], 'undo path linked')
r = A.answer("FAV دوباره", cc())
ck("برداشته شد" in r["text"] and db._one("SELECT COUNT(*) c FROM favorites WHERE customer_id=?", (cust["id"],))["c"] == 0, 'second call toggles back off')
r = A.answer("FAV-EVIL لطفا", cc())
ck("پیدا نکردم" in r["text"] and r["ok"], 'invented slug rejected gracefully')
r = A.answer("FAV لطفا", ctx("guest1"))
ck("/login" in [h for _, h in r["links"]] and db._one("SELECT COUNT(*) c FROM favorites WHERE customer_id=?", (cust["id"],))["c"] == 0, 'guests get a login nudge, nothing executes')
r = A.answer("WEIRD کن", cc())
ck("⚠️" not in r["text"] and A.pending_get(ckey) is None, 'unknown tool ignored, no pending')
r = A.answer("BADARGS کن", cc())
ck("⚠️" not in r["text"] and A.pending_get(ckey) is None, 'malformed tool ignored, no pending')

# ---- 3. booking cancel: propose → pending → «بله» executes (free)
r = A.answer(f"BOOK{b_new} لطفا", cc())
ck("⚠️" in r["text"] and "(بله / نه)" in r["text"] and "مغازه ابزاری" in r["text"], 'proposal asks for confirmation with live details')
ck(A.pending_get(ckey)["tool"] == "cancel_booking", 'pending row stored')
ck(db._one("SELECT status s FROM bookings WHERE id=?", (b_new,))["s"] == "new", 'nothing executed before confirmation')
q_before = A.quota_used_today(ckey)
r = A.answer("بله", cc())
ck(r["intent"] == "confirm" and r["source"] == "rule" and "لغو شد" in r["text"], '«بله» executes via free rules')
ck(db._one("SELECT status s FROM bookings WHERE id=?", (b_new,))["s"] == "cancelled", 'booking cancelled')
ck(A.quota_used_today(ckey) == q_before and A.pending_get(ckey) is None, 'confirm costs no quota, pending consumed')
r = A.answer(f"BOOK{b_new} دوباره", cc())
ck("نهایی" in r["text"] and A.pending_get(ckey) is None, 're-proposing a final booking explains at once, no pending')
ck(A.answer("آره", cc())["text"].startswith("چیزی در انتظار") and A.answer("نه", cc())["text"].startswith("چیزی برای لغو"), 'confirm/decline with nothing pending → gentle notes')
r = A.answer("بله", cc())
ck(r["intent"] != "confirm" and "مدل: بله" in r["text"], 'bare «بله» falls through to the model, no confirm hijack')
os.environ.pop("AI_BASE_URL", None); os.environ.pop("AI_API_KEY", None)
r = A.answer("بله", cc())
ck(r["intent"] == "faq" and r["source"] == "rule", 'bare «بله» keeps its legacy faq meaning when AI is off')
os.environ.update(AI_BASE_URL="https://api.example.invalid/v1", AI_API_KEY="test-key-not-real")

# ---- 4. isolation, expiry, latest-wins, long-text safety
con = db.connect()
con.execute("INSERT INTO bookings(biz_id,name,phone,date,time,status,customer_id) VALUES(?,?,?,?,?,?,?)",
            (biz["id"], "تست", cust["phone"], "2026-09-12", "12:00", "new", cust["id"]))
nb = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
con.commit(); con.close()
A.answer(f"BOOK{b_conf} لطفا", cc())
ck(A.answer("بله", ctx(ckeyB, customer=custB))["intent"] != "confirm", 'another user cannot confirm my pending')
ck(db._one("SELECT status s FROM bookings WHERE id=?", (b_conf,))["s"] == "confirmed", '...and nothing executed for them')
r = A.answer("اپ بله چطور نصب میشه", cc())
ck(r["intent"] != "confirm" and A.pending_get(ckey) is not None, 'long «بله…» text does not touch the pending')
db._run("UPDATE ai_tool_pending SET expires=1 WHERE user_key=?", (ckey,))
r = A.answer("بله", cc())
ck(r["intent"] != "confirm" and db._one("SELECT status s FROM bookings WHERE id=?", (b_conf,))["s"] == "confirmed", 'expired pending cannot execute')
A.answer(f"BOOK{nb} لطفا", cc())
A.answer(f"BOOK{b_conf} لطفا", cc())
A.answer("تأیید می‌کنم", cc())
ck(db._one("SELECT status s FROM bookings WHERE id=?", (b_conf,))["s"] == "cancelled"
   and db._one("SELECT status s FROM bookings WHERE id=?", (nb,))["s"] == "new",
   'latest proposal wins, earlier one dropped')
r = A.answer("نه", cc())
ck(r["text"].startswith("چیزی برای لغو"), 'pending already consumed → gentle')
A.answer(f"BOOK{nb} لطفا", cc())
ck(A.answer("نه ممنون", cc())["text"].startswith("باشه") and db._one("SELECT status s FROM bookings WHERE id=?", (nb,))["s"] == "new", 'decline discards, booking untouched')

# ---- 5. order cancel: window vs approval-request vs final
r = A.answer("ORD لطفا", cc())
ck("⚠️" in r["text"] and f"#{oid}" in r["text"], 'order proposal names the live order')
A.answer("بله", cc())
ck(db._one("SELECT status s FROM orders WHERE id=?", (oid,))["s"] == "cancelled", 'fresh order cancelled directly')
r = A.answer("ORD-OLD لطفا", cc())
r2 = A.answer("بله", cc())
o = db._one("SELECT status, cancel_requested FROM orders WHERE id=?", (oid_old,))
ck(o["status"] != "cancelled" and o["cancel_requested"] == 1, 'stale order → approval request to the owner, not silent cancel')
ck("دکان‌دار" in r2["text"], 'user told the request went to the shopkeeper')
r = A.answer("ORD-DONE لطفا", cc())
ck("نهایی" in r["text"] and A.pending_get(ckey) is None, 'final order refused at propose time, no pending')

# ---- 6. tool answers never cached; audit + threads
n_calls = len(calls)
A.answer("FAV کش؟", cc())
A.answer("FAV کش؟", cc())
ck(len(calls) == n_calls + 2, 'identical tool questions reach the model twice (no cache)')
norms = [r["q_norm"] for r in db._rows("SELECT q_norm FROM ai_cache")]
ck(not any("یید" in q or "ممنون" in q for q in norms), 'confirm/decline turns never cached')
audit = db._rows("SELECT detail FROM audit WHERE action='assistant_tool' ORDER BY id")
ck(len(audit) >= 4 and all(f"cust:{cust['id']}" in (r["detail"] or "") for r in audit), 'every execution audit-logged with the user')
ck(any("برداشته شد" in m["text"] for m in A.thread_get(ckey)), 'latest execution result persisted in the thread')

# ---- 7. prompt + context carry what the model needs
ck("tool_call" in A.ANSWER_PROMPT and "cancel_booking" in A.ANSWER_PROMPT, 'prompt documents the tool protocol')
ck("نوبت #" in A.build_context("x", "", cc()), 'context exposes booking ids')
ck("ai_tool_pending" not in db.export_all(), 'transient pendings excluded from backups')

print(f"v223: {n} checks passed")
