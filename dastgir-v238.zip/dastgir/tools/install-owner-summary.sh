#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${APP_DIR:-/opt/dastgir}"
PYTHON="${PYTHON:-/usr/bin/python3}"
[ "$(id -u)" -eq 0 ] || { echo 'این نصب‌کننده باید با sudo اجرا شود.' >&2; exit 1; }
[ -f "$APP_DIR/tools/send-owner-summaries.py" ] || { echo "پروژه در $APP_DIR پیدا نشد." >&2; exit 1; }
cat >/etc/systemd/system/dastgir-owner-summary.service <<EOF
[Unit]
Description=Dastgir owner daily bot summary
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=www-data
Group=www-data
WorkingDirectory=$APP_DIR
EnvironmentFile=-/etc/dastgir-secrets.env
ExecStart=$PYTHON $APP_DIR/tools/send-owner-summaries.py
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=$APP_DIR/data
EOF
cat >/etc/systemd/system/dastgir-owner-summary.timer <<'EOF'
[Unit]
Description=Send Dastgir owner digest every morning

[Timer]
OnCalendar=*-*-* 09:00:00 Asia/Tehran
Persistent=true
RandomizedDelaySec=180
Unit=dastgir-owner-summary.service

[Install]
WantedBy=timers.target
EOF
systemctl daemon-reload
systemctl enable --now dastgir-owner-summary.timer
systemctl list-timers dastgir-owner-summary.timer --no-pager
