#!/usr/bin/env bash
# Atomic-style clean update from a full Dastgir ZIP; runtime data is preserved.
set -euo pipefail
ZIP="${1:-}";APP=/opt/dastgir;BACKUPS=/var/backups/dastgir
[ "$(id -u)" -eq 0 ] || { echo 'با sudo اجرا کنید.' >&2;exit 1; }
[ -f "$ZIP" ] || { echo 'روش: sudo bash /opt/dastgir/deploy/update.sh /tmp/dastgir-vNNN.zip' >&2;exit 1; }
for x in unzip rsync python3;do command -v "$x" >/dev/null || { echo "$x نصب نیست." >&2;exit 1; };done
TMP=$(mktemp -d /tmp/dastgir-update.XXXXXX);stopped=0
cleanup(){ rm -rf "$TMP";if [ "$stopped" = 1 ];then systemctl start bazarche >/dev/null 2>&1 || true;fi; }
trap cleanup EXIT
unzip -q "$ZIP" -d "$TMP"
[ -f "$TMP/dastgir/run.py" ] && [ -f "$TMP/dastgir/VERSION.txt" ] || { echo 'ساختار ZIP نامعتبر است.' >&2;exit 1; }
unzip -t "$ZIP" >/dev/null
mkdir -p "$BACKUPS" "$APP/data" "$APP/site/assets/img/uploads"
if [ -f "$APP/tools/backup.py" ] && [ -f "$APP/data/bazarche.db" ];then
  python3 "$APP/tools/backup.py" --dir "$BACKUPS" --no-rotate
fi
systemctl stop bazarche;stopped=1
rsync -a --delete \
  --exclude '/data/' --exclude '/site/assets/img/uploads/' --exclude '/site/assets/chat-files/' \
  "$TMP/dastgir/" "$APP/"
mkdir -p "$APP/data/chat-files" "$APP/site/assets/img/uploads"
chown -R www-data:www-data "$APP"
install -m 0644 "$APP/deploy/bazarche.service" /etc/systemd/system/bazarche.service
systemctl daemon-reload
systemctl start bazarche;stopped=0
sleep 2
systemctl is-active --quiet bazarche
curl -fsS http://127.0.0.1:8080/healthz >/dev/null
echo "نسخه $(cat "$APP/VERSION.txt") با موفقیت نصب شد."
