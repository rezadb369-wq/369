# فعال‌سازی امن سروش‌پلاس در v195

سروش‌پلاس در v195 کاملاً جایگزین Rubika شده است. توکن و راز webhook فقط در `/etc/dastgir-secrets.env` با `root:root/600` می‌مانند.

## متغیرها

- `SOROUSH_BOT_TOKEN`: توکن BotFather؛ هرگز در چت، ZIP یا خروجی چاپ نشود.
- `SOROUSH_WEBHOOK_SECRET`: حداقل ۴۳ کاراکتر تصادفی URL-safe.
- `SOROUSH_BOT_USERNAME`: اختیاری؛ اگر خالی باشد برنامه آن را با `getMe` می‌گیرد.

## ثبت webhook

پس از نصب و healthcheck:

```bash
set -a; . /etc/dastgir-secrets.env; set +a
BASE="https://api.splus.ir/bot${SOROUSH_BOT_TOKEN}"
HOOK="https://daastgir.ir/api/soroush/webhook/${SOROUSH_WEBHOOK_SECRET}"
curl -fsS -X POST "$BASE/setWebhook" -H 'Content-Type: application/json' \
  --data "{\"url\":\"$HOOK\",\"allowed_updates\":[\"message\",\"callback_query\"],\"drop_pending_updates\":false}"
curl -fsS -X POST "$BASE/getWebhookInfo"
unset SOROUSH_BOT_TOKEN SOROUSH_WEBHOOK_SECRET BASE HOOK
```

طبق مستندات رسمی، هنگام فعال بودن webhook نباید getUpdates اجرا شود. برنامه هیچ poller سروش راه‌اندازی نمی‌کند. webhook فقط `update_id` عددی، پیام خصوصی، contact مالک‌دار و callback محدود را پردازش می‌کند.

## اجرای مستقیم اپ اندروید بدون صفحهٔ واسط

دکمهٔ اصلی ابتدا درخواست کوتاه‌عمر را در همان click کپی می‌کند و سپس Intent استاندارد `MAIN`/`LAUNCHER` محدود به package رسمی `mobi.mmdt.ottplus` را اجرا می‌کند. لینک HTTPS بات به Intent داده نمی‌شود و browser fallback نیز در آن نیست؛ بنابراین شکست launch کاربر را ناخواسته به splus.ir نمی‌فرستد. لینک رسمی وب یک دکمهٔ مستقل است. اپ ممکن است صفحهٔ اصلی/آخرین صفحه را باز کند؛ کاربر گفت‌وگوی بات دست گیر را باز و درخواست را Paste می‌کند.
