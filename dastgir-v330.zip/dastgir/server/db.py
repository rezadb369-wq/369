# -*- coding: utf-8 -*-
"""
SQLite data layer for Bazarche Najafabad.
Standard library only — no pip install needed (works inside Pydroid 3).
"""

import os
import re
import sys
import json
import sqlite3
import threading
import math
import time
import hashlib
import secrets
import hashlib
import datetime

# v211 — Iranian messengers a business can list (key → public profile prefix,
# Persian label, sprite icon). Telegram/Instagram keep their legacy columns.
MESSENGERS = {
    "eitaa":   ("https://eitaa.com/",  "ایتا",   "eitaa"),
    "bale":    ("https://ble.ir/",     "بله",    "bale"),
    "soroush": ("https://splus.ir/",   "سروش",   "soroush"),
    "rubika":  ("https://rubika.ir/",  "روبیکا", "rubika"),
}
MESSENGER_KEYS = tuple(MESSENGERS)
SOCIAL_KEYS = ("instagram", "telegram") + MESSENGER_KEYS + ("website",)

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = (os.environ.get("BZ_DATA_DIR")             # v117/M3: bench/isolation
            or os.path.join(HERE, "..", "data"))
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "bazarche.db")

SCHEMA = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS categories (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  slug      TEXT UNIQUE NOT NULL,
  name      TEXT NOT NULL,
  icon      TEXT NOT NULL DEFAULT 'store',
  image     TEXT DEFAULT '',            -- uploaded override; '-' hides packaged fallback
  blurb     TEXT DEFAULT '',
  sort      INTEGER DEFAULT 0,
  active    INTEGER DEFAULT 1,
  parent    TEXT DEFAULT ''          -- slug of the parent category, '' = top level
);
-- NOTE: the index on `parent` is created in init(), after the ALTER TABLE that
-- adds the column to databases made before this version. Creating it here would
-- run against the old table on those installs and abort the whole script.

CREATE TABLE IF NOT EXISTS businesses (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  slug        TEXT UNIQUE NOT NULL,
  name        TEXT NOT NULL,
  cat_slug    TEXT NOT NULL,
  descr       TEXT DEFAULT '',
  slogan      TEXT DEFAULT '',        -- v285: business tagline shown in «درباره»
  phone       TEXT DEFAULT '',
  whatsapp    TEXT DEFAULT '',
  address     TEXT DEFAULT '',
  lat         REAL,
  lng         REAL,
  hours       TEXT DEFAULT '',          -- JSON: {"sat":[["09:00","22:00"]], ...}
  tags        TEXT DEFAULT '',          -- comma separated
  images      TEXT DEFAULT '[]',        -- JSON list of asset paths
  featured    INTEGER DEFAULT 0,
  verified    INTEGER DEFAULT 0,
  status      TEXT DEFAULT 'published', -- published | pending | hidden
  views       INTEGER DEFAULT 0,        -- v177: بازدیدکنندهٔ واقعی (یکتا در روز)
  legacy_views INTEGER DEFAULT 0,       -- v177: بایگانی شمارندهٔ قدیمیِ متورم
  instagram   TEXT DEFAULT '',
  telegram    TEXT DEFAULT '',
  eitaa       TEXT DEFAULT '',          -- v211: Iranian messengers (username / id)
  bale        TEXT DEFAULT '',
  soroush     TEXT DEFAULT '',
  rubika      TEXT DEFAULT '',
  website     TEXT DEFAULT '',
  booking_on  INTEGER DEFAULT 0,
  owner_id    INTEGER REFERENCES owners(id) ON DELETE SET NULL,
  phone_public INTEGER DEFAULT 1,      -- v207: bot registration lets the owner hide the phone publicly
  created     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS reviews (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id   INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  author   TEXT NOT NULL,
  rating   INTEGER NOT NULL,
  body     TEXT NOT NULL,
  reply    TEXT DEFAULT '',
  image    TEXT DEFAULT '',          -- optional single photo (public path)
  status   TEXT DEFAULT 'pending',   -- pending | approved | rejected
  spam_flag INTEGER DEFAULT 0,   -- v276: held by content anti-spam
  customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL,  -- v142: notify logged-in author on reply
  created  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS bookings (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id    INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name      TEXT NOT NULL,
  phone     TEXT NOT NULL,
  date      TEXT NOT NULL,
  time      TEXT NOT NULL,
  note      TEXT DEFAULT '',
  status    TEXT DEFAULT 'new',       -- new | confirmed | done | cancelled
  customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  reminded  TEXT DEFAULT '',          -- v229: YYYY/MM/DD last reminded for
  created   TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS coupons (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id    INTEGER REFERENCES businesses(id) ON DELETE CASCADE,
  code      TEXT NOT NULL,
  title     TEXT NOT NULL,
  percent   INTEGER DEFAULT 0,
  expires   TEXT DEFAULT '',
  active    INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS posts (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  slug      TEXT UNIQUE NOT NULL,
  title     TEXT NOT NULL,
  excerpt   TEXT DEFAULT '',
  body      TEXT DEFAULT '',
  cover     TEXT DEFAULT '',
  video     TEXT DEFAULT '',              -- v285: uploaded path or embed URL
  status    TEXT DEFAULT 'published',
  created   TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS messages (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  name      TEXT, email TEXT, subject TEXT, body TEXT,
  kind      TEXT DEFAULT 'contact',   -- contact | order
  meta      TEXT DEFAULT '{}',
  status    TEXT DEFAULT 'new',
  created   TEXT DEFAULT (datetime('now'))
);

-- ================================================================
--  TICKETS  --  a real two-way conversation with the admin
--
--  The contact form was one-way: a shopkeeper sent a message into a void
--  and had no way to see a reply or continue the thread. A ticket is the
--  same message plus (a) a status the person can watch, (b) replies from
--  both sides in order, and (c) a private token so somebody who is not
--  logged in can still follow their own thread.
-- ================================================================
CREATE TABLE IF NOT EXISTS tickets (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id  INTEGER REFERENCES owners(id) ON DELETE SET NULL,
  biz_id    INTEGER REFERENCES businesses(id) ON DELETE SET NULL,
  name      TEXT DEFAULT '',
  phone     TEXT DEFAULT '',
  subject   TEXT DEFAULT '',
  topic     TEXT DEFAULT 'other',   -- payment|unlock|bug|edit|other
  status    TEXT DEFAULT 'open',    -- open|answered|waiting|closed
  priority  TEXT DEFAULT 'normal',  -- low|normal|high
  spam_flag INTEGER DEFAULT 0,   -- v276: held by content anti-spam
  token     TEXT DEFAULT '',
  unread_admin INTEGER DEFAULT 1,   -- badge for the admin panel
  unread_user  INTEGER DEFAULT 0,   -- badge for the shopkeeper
  created   TEXT DEFAULT (datetime('now')),
  updated   TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ticket_owner ON tickets(owner_id);
CREATE INDEX IF NOT EXISTS idx_ticket_token ON tickets(token);
CREATE INDEX IF NOT EXISTS idx_ticket_status ON tickets(status);

CREATE TABLE IF NOT EXISTS ticket_msgs (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  side      TEXT DEFAULT 'user',    -- user | admin
  body      TEXT NOT NULL,
  created   TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_tmsg_ticket ON ticket_msgs(ticket_id);

CREATE TABLE IF NOT EXISTS ticket_attachments (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  msg_id        INTEGER NOT NULL REFERENCES ticket_msgs(id) ON DELETE CASCADE,
  stored_name   TEXT NOT NULL UNIQUE,
  original_name TEXT NOT NULL,
  mime          TEXT NOT NULL,
  size          INTEGER NOT NULL,
  kind          TEXT NOT NULL,
  created       TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_tatt_msg ON ticket_attachments(msg_id);

CREATE TABLE IF NOT EXISTS pages (
  slug      TEXT PRIMARY KEY,         -- about | rules
  title     TEXT,
  body      TEXT
);

CREATE TABLE IF NOT EXISTS audit (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  action    TEXT, detail TEXT,
  created   TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS owners (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  phone      TEXT UNIQUE NOT NULL,
  name       TEXT DEFAULT '',
  username   TEXT DEFAULT '',
  pass_hash  TEXT DEFAULT '',
  status     TEXT DEFAULT 'active',      -- active | blocked
  created    TEXT DEFAULT (datetime('now')),
  last_login TEXT
);

CREATE TABLE IF NOT EXISTS customers (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  phone      TEXT UNIQUE NOT NULL,
  name       TEXT DEFAULT '',
  username   TEXT DEFAULT '',
  pass_hash  TEXT DEFAULT '',
  status     TEXT DEFAULT 'active',     -- active | blocked
  created    TEXT DEFAULT (datetime('now')),
  last_login TEXT
);

CREATE TABLE IF NOT EXISTS customer_sessions (
  token       TEXT PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  expires     REAL NOT NULL,
  created     TEXT DEFAULT (datetime('now'))
);

-- v185: a Bale identity is linked only after an authenticated customer
-- confirms inside the bot. Login challenges store hashes, never bearer values.
CREATE TABLE IF NOT EXISTS messenger_accounts (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id      INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  platform         TEXT NOT NULL DEFAULT 'bale',
  platform_user_id TEXT NOT NULL,
  chat_id          TEXT NOT NULL,
  active           INTEGER NOT NULL DEFAULT 1,
  linked_at        TEXT DEFAULT (datetime('now')),
  UNIQUE(customer_id, platform),
  UNIQUE(platform, platform_user_id)
);

CREATE TABLE IF NOT EXISTS messenger_challenges (
  id            TEXT PRIMARY KEY,
  request_hash  TEXT UNIQUE NOT NULL,
  browser_hash  TEXT NOT NULL,
  purpose       TEXT NOT NULL,
  platform      TEXT NOT NULL DEFAULT 'bale',
  customer_id   INTEGER REFERENCES customers(id) ON DELETE CASCADE,
  approved_id   INTEGER REFERENCES customers(id) ON DELETE CASCADE,
  platform_user_id TEXT,
  chat_id       TEXT,
  approval_hash TEXT,
  expires       REAL NOT NULL,
  approved_at   REAL,
  used_at       REAL,
  created       TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_msgchallenge_exp ON messenger_challenges(expires);

-- v284: fallback login keys («روش دوم»): a strong one-time key shown in the
-- browser when the messenger round-trip did not complete. Hash-only storage,
-- single use, short TTL, bound to one login challenge.
CREATE TABLE IF NOT EXISTS messenger_login_keys(
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  key_hash      TEXT UNIQUE NOT NULL,
  challenge_id  TEXT NOT NULL,
  platform      TEXT NOT NULL DEFAULT 'bale',
  chat_id       TEXT,
  platform_user_id TEXT,
  phone         TEXT,
  status        TEXT NOT NULL DEFAULT 'issued',
  tries         INTEGER NOT NULL DEFAULT 0,
  created       REAL NOT NULL,
  expires       REAL NOT NULL,
  done_at       REAL
);
CREATE INDEX IF NOT EXISTS idx_loginkey_exp ON messenger_login_keys(expires);
CREATE INDEX IF NOT EXISTS idx_loginkey_chat ON messenger_login_keys(chat_id, status);

-- v212: one live "receipt" message per (order, platform); later status
-- changes edit this message in place instead of sending a new one.
CREATE TABLE IF NOT EXISTS order_receipts (
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  platform   TEXT NOT NULL,
  chat_id    TEXT NOT NULL,
  message_id INTEGER NOT NULL,
  updated    TEXT DEFAULT (datetime('now')),
  PRIMARY KEY(order_id, platform)
);

-- v213: assistant usage — one row per (day, person); the daily quota and the
-- admin counter both read this. No message text is ever stored.
CREATE TABLE IF NOT EXISTS ai_usage (
  day       TEXT NOT NULL,
  user_key  TEXT NOT NULL,
  channel   TEXT NOT NULL DEFAULT 'web',
  n         INTEGER NOT NULL DEFAULT 0,
  llm_calls INTEGER NOT NULL DEFAULT 0,
  tokens    INTEGER NOT NULL DEFAULT 0,
  q         INTEGER NOT NULL DEFAULT 0,    -- v219: model-backed answers (the only quota that counts)
  smart_calls INTEGER NOT NULL DEFAULT 0,  -- v219: answers written by AI_MODEL_SMART
  PRIMARY KEY(day, user_key)
);
CREATE TABLE IF NOT EXISTS ai_intents (
  day     TEXT NOT NULL,
  intent  TEXT NOT NULL,
  n       INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(day, intent)
);
-- v218: assistant knowledge base — admin-editable FAQ that seeds from the
-- assistant's built-in list on first use. Active rows (ord, id) are what the
-- rules and the model see; the model may only paraphrase them.
CREATE TABLE IF NOT EXISTS ai_faq (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  q       TEXT NOT NULL,
  a       TEXT NOT NULL,
  active  INTEGER NOT NULL DEFAULT 1,
  ord     INTEGER NOT NULL DEFAULT 0,
  updated TEXT NOT NULL DEFAULT ''
);
-- v220: semantic answer cache — model-written answers to repeated public
-- (guest, history-less) questions. Transient by design: never backed up,
-- refills itself. tokens = space-joined normalized token set for Jaccard.
CREATE TABLE IF NOT EXISTS ai_cache (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  q_norm  TEXT NOT NULL,
  tokens  TEXT NOT NULL,
  answer  TEXT NOT NULL,
  links   TEXT NOT NULL DEFAULT '[]',
  intent  TEXT NOT NULL DEFAULT '',
  model   TEXT NOT NULL DEFAULT '',
  mtokens INTEGER NOT NULL DEFAULT 0,
  hits    INTEGER NOT NULL DEFAULT 0,
  created INTEGER NOT NULL DEFAULT 0,
  expires INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_ai_cache_expires ON ai_cache(expires);
-- v221: persistent conversation threads (bots + signed-in web). Short-lived
-- operational data: 48h TTL, 20 msgs/thread, never backed up. Guests (ip:*)
-- are never persisted. tkey = cust:<id> (cross-channel) or <platform>:<uid>.
CREATE TABLE IF NOT EXISTS ai_threads (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  tkey    TEXT NOT NULL,
  role    TEXT NOT NULL DEFAULT 'user',
  text    TEXT NOT NULL,
  created INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_ai_threads_key ON ai_threads(tkey, id);
-- v223: pending tool confirmations (10-min TTL, one outstanding per user).
-- Transient: never backed up. The model only PROPOSES; execution re-validates
-- ownership + policy and is audit-logged.
CREATE TABLE IF NOT EXISTS ai_tool_pending (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  user_key TEXT NOT NULL,
  tool     TEXT NOT NULL,
  args     TEXT NOT NULL DEFAULT '{}',
  created  INTEGER NOT NULL DEFAULT 0,
  expires  INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_ai_tool_pending_user ON ai_tool_pending(user_key);

-- Persistent replay wall: Bale may retry the same webhook update.
CREATE TABLE IF NOT EXISTS messenger_updates (
  platform  TEXT NOT NULL,
  update_id TEXT NOT NULL,
  received  REAL NOT NULL,
  PRIMARY KEY(platform, update_id)
);
CREATE INDEX IF NOT EXISTS idx_msgupdates_received ON messenger_updates(received);

CREATE TABLE IF NOT EXISTS chat_threads (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id           INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  customer_id      INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  subject          TEXT DEFAULT '',
  status           TEXT DEFAULT 'open',      -- open | closed
  last_activity    REAL NOT NULL,
  customer_read_to INTEGER DEFAULT 0,
  owner_read_to    INTEGER DEFAULT 0,
  admin_read_to    INTEGER DEFAULT 0,
  created          TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS chat_messages (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id INTEGER NOT NULL REFERENCES chat_threads(id) ON DELETE CASCADE,
  sender    TEXT NOT NULL,                -- customer | owner | admin
  body      TEXT NOT NULL DEFAULT '',
  created   TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS chat_attachments (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  message_id    INTEGER NOT NULL REFERENCES chat_messages(id) ON DELETE CASCADE,
  stored_name   TEXT NOT NULL UNIQUE,
  original_name TEXT NOT NULL,
  mime          TEXT NOT NULL,
  size          INTEGER NOT NULL,
  kind          TEXT NOT NULL,             -- image | file
  created       TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS orders (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id      INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  name        TEXT NOT NULL,
  phone       TEXT NOT NULL,
  address     TEXT DEFAULT '',
  note        TEXT DEFAULT '',
  total       INTEGER DEFAULT 0,
  status      TEXT DEFAULT 'new',         -- new | confirmed | ready | done | cancelled
  share_phone INTEGER DEFAULT 0,
  cancel_requested INTEGER DEFAULT 0,
  cancel_reason TEXT DEFAULT '',
  cancel_requested_at TEXT DEFAULT '',
  cancel_decided_at TEXT DEFAULT '',
  created     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS order_items (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  item_id  INTEGER REFERENCES items(id) ON DELETE SET NULL,
  title    TEXT NOT NULL,
  price    INTEGER DEFAULT 0,
  qty      INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS favorites (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  biz_id      INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS toplists (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  slug    TEXT UNIQUE NOT NULL,
  title   TEXT NOT NULL,
  descr   TEXT DEFAULT '',
  kind    TEXT DEFAULT 'manual',   -- manual | auto_rating | auto_views | auto_featured | auto_new
  items   TEXT DEFAULT '[]',       -- JSON list of biz ids (manual lists)
  limit_n INTEGER DEFAULT 10,
  sort    INTEGER DEFAULT 0,
  active  INTEGER DEFAULT 1,
  created TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS flashdeals (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id   INTEGER REFERENCES businesses(id) ON DELETE CASCADE,
  title    TEXT NOT NULL,
  descr    TEXT DEFAULT '',
  percent  INTEGER DEFAULT 0,      -- discount percentage
  starts   TEXT DEFAULT '',
  ends     TEXT NOT NULL,          -- ISO datetime; filtered by active window
  active   INTEGER DEFAULT 1,
  created  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS points (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  amount      INTEGER NOT NULL,
  reason      TEXT DEFAULT '',
  created     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS redemptions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id  INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  code         TEXT UNIQUE NOT NULL,
  percent      INTEGER DEFAULT 10,
  points_spent INTEGER DEFAULT 0,
  used         INTEGER DEFAULT 0,
  created      TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS stories (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id  INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  image   TEXT NOT NULL,
  kind    TEXT DEFAULT 'image',       -- image | video
  caption TEXT DEFAULT '',
  created TEXT DEFAULT (datetime('now')),
  expires REAL NOT NULL,
  duration REAL DEFAULT 0             -- v101: seconds, so the viewer plays the full clip
);

-- v177: story view — one row per real viewer (bz_cid), UNIQUE per story.
-- The pre-v177 inflated table is archived as story_views_legacy at boot.
CREATE TABLE IF NOT EXISTS story_views (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  story_id INTEGER NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
  viewer   TEXT NOT NULL DEFAULT '',
  ts       REAL NOT NULL,
  UNIQUE(story_id, viewer)
);
CREATE INDEX IF NOT EXISTS idx_sview_story ON story_views(story_id, ts);

-- v177: real page-view dedupe — one counted view per viewer per day per
-- entity (biz | item). viewer = random bz_cid cookie (no IP/identity).
CREATE TABLE IF NOT EXISTS page_viewers (
  entity TEXT NOT NULL,
  eid    INTEGER NOT NULL,
  viewer TEXT NOT NULL,
  day    TEXT NOT NULL,
  ts     REAL NOT NULL,
  UNIQUE(entity, eid, viewer, day)
);
CREATE INDEX IF NOT EXISTS idx_pageview_ent ON page_viewers(entity, eid, day);

-- v176: one helpful vote per visitor per review. voter = "c<customer_id>"
-- for signed-in accounts, or an anonymised sha256(16) of the client key for
-- guests — same privacy stance as story_views: no raw IP/identity stored.
CREATE TABLE IF NOT EXISTS review_votes (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  review_id  INTEGER NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
  voter      TEXT NOT NULL,
  created    REAL NOT NULL,
  UNIQUE(review_id, voter)
);
CREATE INDEX IF NOT EXISTS idx_rvote_review ON review_votes(review_id);

-- v276: one helpful-vote per visitor on a question (mirrors review_votes)
CREATE TABLE IF NOT EXISTS question_votes (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  question_id INTEGER NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  voter      TEXT NOT NULL,
  created    REAL NOT NULL,
  UNIQUE(question_id, voter)
);
CREATE INDEX IF NOT EXISTS idx_qvote_question ON question_votes(question_id);

-- v114: real-visit analytics. One row per public page view carrying the real
-- visitor identity: IP, UA/device, first-party visitor cookie (bz_cid) and a
-- rolling 30-minute session (bz_sid), plus referrer. Bots/crawlers are still
-- recorded (bot=1) so the panel shows the true traffic picture, but they are
-- excluded from the public counters and the "real visitors" numbers.
CREATE TABLE IF NOT EXISTS visits (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  ts       REAL NOT NULL,
  path     TEXT NOT NULL,
  kind     TEXT NOT NULL,              -- home|listing|business|item|blog|...|story
  biz_id   INTEGER,
  item_id  INTEGER,
  story_id INTEGER,
  ip       TEXT NOT NULL DEFAULT '',
  ua       TEXT NOT NULL DEFAULT '',
  dev      TEXT NOT NULL DEFAULT '',   -- mobile|tablet|desktop|bot
  cid      TEXT NOT NULL DEFAULT '',   -- bz_cid cookie = one real person
  sid      TEXT NOT NULL DEFAULT '',   -- rolling 30-min session
  ref      TEXT NOT NULL DEFAULT '',
  bot      INTEGER NOT NULL DEFAULT 0,
  prov     TEXT NOT NULL DEFAULT '',   -- v115: offline GeoIP (DB-IP lite, IR)
  city     TEXT NOT NULL DEFAULT '',
  utm      TEXT NOT NULL DEFAULT ''    -- v115: "source|medium|campaign"
);
CREATE INDEX IF NOT EXISTS idx_visits_ts ON visits(ts);
CREATE INDEX IF NOT EXISTS idx_visits_kind ON visits(kind, ts);
CREATE INDEX IF NOT EXISTS idx_visits_biz ON visits(biz_id, ts);
CREATE INDEX IF NOT EXISTS idx_visits_cid ON visits(cid);
CREATE INDEX IF NOT EXISTS idx_visits_story ON visits(story_id, ts);

-- v105: soft-delete recycle bin. When a story/item/review/report is deleted we
-- snapshot the full row here for 7 days (trackable + restorable in the panels),
-- then hard-purge. Public pages never see deleted rows because they are removed
-- from the live tables; the panels read this bin instead.
CREATE TABLE IF NOT EXISTS trash (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  entity     TEXT NOT NULL,          -- story | item | review | report
  ref_id     INTEGER NOT NULL,
  biz_id     INTEGER DEFAULT 0,
  title      TEXT DEFAULT '',
  payload    TEXT NOT NULL,          -- JSON of the full original row
  deleted_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_trash_recent ON trash(deleted_at);

CREATE TABLE IF NOT EXISTS cities (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  province TEXT NOT NULL,
  name     TEXT NOT NULL,
  is_capital INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS follows (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  biz_id      INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  created     TEXT DEFAULT (datetime('now'))
);

-- v156: فراخوان دکان — خبرهای دکان‌دار برای دنبال‌کننده‌ها (موجود شد/ارزان شد/…)
CREATE TABLE IF NOT EXISTS broadcasts (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id     INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  kind       TEXT DEFAULT 'news',     -- restock | price_drop | ending | news
  text       TEXT DEFAULT '',
  item_id    INTEGER,
  recipients INTEGER DEFAULT 0,
  created    TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_bcast_biz ON broadcasts(biz_id, id);

-- v156: «موجود شد خبرم کن» — درخواست مشتری از صفحهٔ کالا یا گفتگو
CREATE TABLE IF NOT EXISTS stock_requests (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id      INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  item_id     INTEGER,
  customer_id INTEGER REFERENCES customers(id) ON DELETE CASCADE,
  source      TEXT DEFAULT 'item',    -- item | chat
  qty         INTEGER DEFAULT 1,      -- v177: چند عدد می‌خواهد
  note        TEXT DEFAULT '',        -- v177: یادداشت اختیاری (≤140)
  status      TEXT DEFAULT 'open',    -- open | fulfilled | dismissed
  created     TEXT DEFAULT (datetime('now')),
  fulfilled   TEXT DEFAULT ''
);
-- یک مشتری برای هر (دکان، کالا) فقط یک درخواست باز؛ درخواستِ گفتگو item ندارد
CREATE UNIQUE INDEX IF NOT EXISTS idx_stockreq_uniq
  ON stock_requests(biz_id, IFNULL(item_id, 0), customer_id);
CREATE INDEX IF NOT EXISTS idx_stockreq_biz ON stock_requests(biz_id, status);
CREATE INDEX IF NOT EXISTS idx_stockreq_customer ON stock_requests(customer_id, id);

CREATE TABLE IF NOT EXISTS notifications (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  kind        TEXT DEFAULT 'info',     -- order | chat | reply | info
  text        TEXT NOT NULL,
  link        TEXT DEFAULT '',
  read        INTEGER DEFAULT 0,
  created     TEXT DEFAULT (datetime('now'))
);

-- v142: in-app notifications for shopkeepers (owners) + per-kind preferences
CREATE TABLE IF NOT EXISTS owner_notifications (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id    INTEGER NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
  kind        TEXT DEFAULT 'info',     -- sub | biz | chat | order | social | ticket
  text        TEXT NOT NULL,
  link        TEXT DEFAULT '',
  read        INTEGER DEFAULT 0,
  created     TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_on_owner ON owner_notifications(owner_id, id);
CREATE TABLE IF NOT EXISTS notif_prefs (
  role     TEXT NOT NULL,              -- 'owner' | 'cust'
  user_id  INTEGER NOT NULL,
  kind     TEXT NOT NULL,
  enabled  INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY (role, user_id, kind)
);

-- v142: web-push subscriptions (Chrome/FCM) per role+user. One browser
-- token may serve both roles of the same person, so uniqueness is per row.
CREATE TABLE IF NOT EXISTS push_subs (
  role      TEXT NOT NULL,             -- 'owner' | 'cust'
  user_id   INTEGER NOT NULL,
  token     TEXT NOT NULL,             -- FCM registration token (endpoint tail)
  sub       TEXT NOT NULL,             -- full JSON subscription (endpoint/keys)
  created   TEXT DEFAULT (datetime('now')),
  PRIMARY KEY (role, user_id, token)
);

CREATE TABLE IF NOT EXISTS price_history (   -- v68: torob-style price memory
  item_id  INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
  price    INTEGER NOT NULL,
  ts       REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ph_item ON price_history(item_id, ts);

CREATE TABLE IF NOT EXISTS price_alerts (    -- v68: "tell me when it's cheaper"
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  group_key   TEXT NOT NULL,
  title       TEXT DEFAULT '',
  created     TEXT DEFAULT (datetime('now')),
  UNIQUE(customer_id, group_key)
);

CREATE TABLE IF NOT EXISTS otp (
  phone   TEXT PRIMARY KEY,
  code    TEXT NOT NULL,
  tries   INTEGER DEFAULT 0,
  expires REAL NOT NULL
);

-- v298: email login — like modern agent login agent requires email
CREATE TABLE IF NOT EXISTS email_otps (
  email   TEXT PRIMARY KEY,
  code    TEXT NOT NULL,
  tries   INTEGER DEFAULT 0,
  expires REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token    TEXT PRIMARY KEY,
  owner_id INTEGER NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
  expires  REAL NOT NULL,
  created  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS admin_sessions (
  token    TEXT PRIMARY KEY,
  expires  REAL NOT NULL,
  created  TEXT DEFAULT (datetime('now')),
  locked   INTEGER NOT NULL DEFAULT 0   -- v117/M1: 1 = key-only (password not entered)
);

-- v293: تأیید ورود به پنل از ربات بله (لایهٔ سوم امنیت ورود).
-- چالِنج یک‌بارمصرف با کد ۶رقمی؛ تنها ۵ دقیقه اعتبار دارد و پس از تصمیم
-- (تأیید/رد) یا انقضا دیگر مصرف نمی‌شود.
CREATE TABLE IF NOT EXISTS panel_approvals (
  code      TEXT PRIMARY KEY,
  sess_hash TEXT NOT NULL,
  status    TEXT NOT NULL DEFAULT 'pending',   -- pending|approved|rejected
  ip        TEXT DEFAULT '',
  created   TEXT DEFAULT (datetime('now')),
  expires   REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_panelappr_exp ON panel_approvals(expires);

-- v300: پنل ایجنت کاملاً خصوصی — کلید فقط از ربات بله مدیر
CREATE TABLE IF NOT EXISTS agent_keys (
  token_hash TEXT PRIMARY KEY,
  token      TEXT DEFAULT '',  -- only for dev, never shown in prod
  expires    REAL NOT NULL,
  created    REAL NOT NULL,
  used       INTEGER DEFAULT 0,
  ip         TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_agentkeys_exp ON agent_keys(expires);

-- v300: صف دسته‌ای ایجنت — چند ابزار را جمع کن، با یک دستور روی سایت اصلی اعمال کن
CREATE TABLE IF NOT EXISTS agent_batches (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  tool       TEXT NOT NULL,
  args       TEXT NOT NULL,
  report     TEXT DEFAULT '',
  snapshot   TEXT DEFAULT '',
  status     TEXT DEFAULT 'staged', -- staged | applied | failed | cancelled
  created    REAL NOT NULL,
  applied_at REAL
);

CREATE TABLE IF NOT EXISTS claims (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id   INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  owner_id INTEGER NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
  note     TEXT DEFAULT '',
  status   TEXT DEFAULT 'pending',       -- pending | approved | rejected
  created  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS events (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id  INTEGER REFERENCES businesses(id) ON DELETE CASCADE,
  kind    TEXT NOT NULL,                 -- view | phone | whatsapp | route | share
  day     TEXT NOT NULL,                 -- YYYY-MM-DD
  n       INTEGER DEFAULT 0,
  UNIQUE(biz_id, kind, day)
);

CREATE TABLE IF NOT EXISTS items (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id     INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  kind       TEXT DEFAULT 'product',   -- product | service | custom
  title      TEXT NOT NULL,
  descr      TEXT DEFAULT '',
  price      INTEGER DEFAULT 0,        -- toman; 0 when not applicable
  price_type TEXT DEFAULT 'fixed',     -- fixed | from | call | free
  unit       TEXT DEFAULT '',          -- «هر عدد», «هر متر», «هر جلسه»…
  duration   TEXT DEFAULT '',          -- services: «۴۵ دقیقه»
  image      TEXT DEFAULT '',          -- cover (kept for compatibility)
  images     TEXT DEFAULT '[]',        -- JSON list, first item is the cover
  old_price  INTEGER DEFAULT 0,        -- crossed-out "was" price
  stock      INTEGER DEFAULT -1,       -- -1 = not tracked
  code       TEXT DEFAULT '',          -- SKU / internal code
  min_order  TEXT DEFAULT '',          -- «حداقل ۲ عدد»
  options    TEXT DEFAULT '',          -- «کوچک، متوسط، بزرگ»
  note       TEXT DEFAULT '',          -- delivery / preparation note
  tags       TEXT DEFAULT '',
  available  INTEGER DEFAULT 1,
  featured   INTEGER DEFAULT 0,
  sort       INTEGER DEFAULT 0,
  spam_flag  INTEGER DEFAULT 0,   -- v278: عنوان تکراری => نگه برای بررسی
  created    TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS inquiries (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id   INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  item_id  INTEGER REFERENCES items(id) ON DELETE SET NULL,
  name     TEXT NOT NULL,
  phone    TEXT DEFAULT '',            -- v65: optional — customer contact is private
  body     TEXT DEFAULT '',
  budget   TEXT DEFAULT '',
  quote    TEXT DEFAULT '',
  status   TEXT DEFAULT 'new',         -- new | quoted | won | lost
  created  TEXT DEFAULT (datetime('now'))
);

-- ================================================================
--  چانه‌زنی — haggling, the way an Iranian bazaar actually works
--
--  Basalam has a "گفت‌وگو" thread; nobody has a structured OFFER with a
--  price on it that the shopkeeper accepts, refuses, or answers with a
--  counter-price. That back-and-forth is how business is really done in a
--  bazaar, and it is exactly the part every Iranian marketplace app drops.
--
--  One row per round. `parent` chains a counter-offer to the offer it
--  answers, so the whole negotiation is one readable thread and neither
--  side can quietly rewrite an earlier number.
-- ================================================================
CREATE TABLE IF NOT EXISTS haggles (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id    INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  item_id   INTEGER REFERENCES items(id) ON DELETE CASCADE,
  parent    INTEGER REFERENCES haggles(id) ON DELETE CASCADE,
  side      TEXT DEFAULT 'buyer',      -- buyer | seller
  name      TEXT DEFAULT '',
  phone     TEXT DEFAULT '',
  customer_id INTEGER,                  -- v142: logged-in buyer (reply notifications)
  offer     INTEGER DEFAULT 0,         -- the price being proposed, toman
  qty       INTEGER DEFAULT 1,
  note      TEXT DEFAULT '',
  status    TEXT DEFAULT 'open',       -- open | countered | accepted | declined | expired
  token     TEXT DEFAULT '',           -- lets a buyer follow their own thread
  expires   TEXT DEFAULT '',
  created   TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_haggle_biz ON haggles(biz_id);
CREATE INDEX IF NOT EXISTS idx_haggle_item ON haggles(item_id);
CREATE INDEX IF NOT EXISTS idx_haggle_token ON haggles(token);

-- ================================================================
--  WORLD-CLASS DIRECTORY FEATURES (v3)
-- ================================================================

-- Public Q&A on a business page (Google Business Profile pattern)
CREATE TABLE IF NOT EXISTS questions (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id    INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  asker     TEXT NOT NULL,
  customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL,  -- v142: notify logged-in asker on answer
  body      TEXT NOT NULL,
  answer    TEXT DEFAULT '',
  answered_by TEXT DEFAULT '',            -- owner | admin
  status    TEXT DEFAULT 'pending',       -- pending | published | rejected
  helpful   INTEGER DEFAULT 0,
  spam_flag INTEGER DEFAULT 0,   -- v276: held by content anti-spam
  created   TEXT DEFAULT (datetime('now')),
  answered  TEXT,
  edited TEXT DEFAULT '',           -- v285: question edit timestamp
  answer_edited TEXT DEFAULT ''     -- v285: answer edit timestamp
);

-- Abuse / wrong-info reports (Yelp + Google pattern)
CREATE TABLE IF NOT EXISTS reports (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  kind      TEXT NOT NULL DEFAULT 'business',  -- business | review | item | question
  target_id INTEGER NOT NULL,
  biz_id    INTEGER REFERENCES businesses(id) ON DELETE CASCADE,
  reason    TEXT NOT NULL,
  body      TEXT DEFAULT '',
  reporter  TEXT DEFAULT '',
  status    TEXT DEFAULT 'open',          -- open | resolved | dismissed
  note      TEXT DEFAULT '',
  created   TEXT DEFAULT (datetime('now'))
);

-- Custom badges the admin defines and pins onto businesses
CREATE TABLE IF NOT EXISTS badges (
  id     INTEGER PRIMARY KEY AUTOINCREMENT,
  slug   TEXT UNIQUE NOT NULL,
  name   TEXT NOT NULL,
  icon   TEXT DEFAULT 'award',
  color  TEXT DEFAULT '#059669',
  descr  TEXT DEFAULT '',
  sort   INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS biz_badges (
  biz_id   INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  badge_id INTEGER NOT NULL REFERENCES badges(id) ON DELETE CASCADE,
  granted  TEXT DEFAULT (datetime('now')),
  PRIMARY KEY (biz_id, badge_id)
);

-- Subscription plans + real subscriptions with expiry
CREATE TABLE IF NOT EXISTS plans (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  slug      TEXT UNIQUE NOT NULL,
  name      TEXT NOT NULL,
  tagline   TEXT DEFAULT '',
  price     INTEGER DEFAULT 0,            -- toman per period
  months    INTEGER DEFAULT 12,
  featured_slots INTEGER DEFAULT 0,       -- how many featured placements
  max_items INTEGER DEFAULT 10,
  max_photos INTEGER DEFAULT 6,
  perks     TEXT DEFAULT '',              -- newline separated
  features  TEXT DEFAULT '',              -- comma separated feature keys, or * for all
  badge_slug TEXT DEFAULT '',
  ai_daily   INTEGER DEFAULT -1,        -- v285: daily AI messages (-1 = tier default)
  sort      INTEGER DEFAULT 0,
  active    INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS subscriptions (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id    INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  plan_slug TEXT NOT NULL,
  status    TEXT DEFAULT 'pending',       -- pending | active | expired | cancelled
  starts    TEXT,
  expires   TEXT,
  amount    INTEGER DEFAULT 0,
  months    INTEGER DEFAULT 0,            -- billing period chosen (1/3/6/12); 0 = plan's own months
  method    TEXT DEFAULT 'manual',        -- manual | card | gateway
  ref       TEXT DEFAULT '',              -- payment reference the owner typed (tracking code)
  receipt   TEXT DEFAULT '',              -- uploaded bank receipt image (public path)
  note      TEXT DEFAULT '',
  created   TEXT DEFAULT (datetime('now'))
);

-- Advertising slots with real impression/click counters
CREATE TABLE IF NOT EXISTS ads (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  title     TEXT NOT NULL,
  body      TEXT DEFAULT '',
  image     TEXT DEFAULT '',
  url       TEXT DEFAULT '',
  slot      TEXT DEFAULT 'home',          -- home | directory | business | sidebar
  biz_id    INTEGER REFERENCES businesses(id) ON DELETE SET NULL,
  starts    TEXT DEFAULT '',
  ends      TEXT DEFAULT '',
  active    INTEGER DEFAULT 1,
  weight    INTEGER DEFAULT 1,
  views     INTEGER DEFAULT 0,
  clicks    INTEGER DEFAULT 0,
  created   TEXT DEFAULT (datetime('now'))
);

-- City events (city-directory pattern)
CREATE TABLE IF NOT EXISTS cityevents (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  slug      TEXT UNIQUE NOT NULL,
  title     TEXT NOT NULL,
  descr     TEXT DEFAULT '',
  place     TEXT DEFAULT '',
  date      TEXT DEFAULT '',              -- YYYY-MM-DD
  time      TEXT DEFAULT '',
  biz_id    INTEGER REFERENCES businesses(id) ON DELETE SET NULL,
  image     TEXT DEFAULT '',
  video     TEXT DEFAULT '',              -- v285: uploaded path or embed URL
  status    TEXT DEFAULT 'published',
  created   TEXT DEFAULT (datetime('now'))
);

-- Multi-criteria review scores (Directorist / Tripadvisor pattern)
CREATE TABLE IF NOT EXISTS review_scores (
  review_id INTEGER NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
  criterion TEXT NOT NULL,                -- quality | price | speed | behaviour
  score     INTEGER NOT NULL,
  PRIMARY KEY (review_id, criterion)
);

-- Owner-requested profile edits that need admin approval
CREATE TABLE IF NOT EXISTS edits (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_id   INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  owner_id INTEGER REFERENCES owners(id) ON DELETE SET NULL,
  payload  TEXT NOT NULL,                 -- JSON of changed fields
  status   TEXT DEFAULT 'pending',        -- pending | approved | rejected
  created  TEXT DEFAULT (datetime('now'))
);

-- Saved searches -> alerts when a matching business appears
CREATE TABLE IF NOT EXISTS alerts (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  phone    TEXT NOT NULL,
  term     TEXT DEFAULT '',
  cat_slug TEXT DEFAULT '',
  active   INTEGER DEFAULT 1,
  sent     INTEGER DEFAULT 0,
  created  TEXT DEFAULT (datetime('now'))
);

-- Rate limiting bucket (spam protection on every public form)
-- Features the admin unlocked by hand for one shop. This is the "key" the
-- site owner holds: a shopkeeper pays outside the site, and the admin flips
-- the switch here. Separate from plans so a manual grant survives a plan
-- change and can never be revoked by an expiry job.
CREATE TABLE IF NOT EXISTS biz_features (
  biz_id   INTEGER PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  unlocked TEXT DEFAULT '',          -- comma separated feature keys
  updated  TEXT DEFAULT (datetime('now'))
);

-- What people typed into the search box, and whether they found anything.
-- Zero-result searches are the single most useful signal a city directory
-- has: they say exactly which trade is missing from the site.
CREATE TABLE IF NOT EXISTS searches (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  term    TEXT NOT NULL,
  norm    TEXT NOT NULL,             -- normalised, for grouping
  cat     TEXT DEFAULT '',
  results INTEGER DEFAULT 0,
  day     TEXT NOT NULL,
  created TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_search_norm ON searches(norm);
CREATE INDEX IF NOT EXISTS idx_search_day ON searches(day);

CREATE TABLE IF NOT EXISTS ratelimit (
  bucket  TEXT PRIMARY KEY,
  n       INTEGER DEFAULT 0,
  window  REAL NOT NULL
);

-- v275: لایهٔ ضداسپم ماندگار — رویدادها گذرا (هرس ۷روزه/۵۰)، banها ماندگار و در بکاپ
CREATE TABLE IF NOT EXISTS spam_events (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  ts      REAL NOT NULL,
  ident   TEXT DEFAULT '',
  actor   TEXT DEFAULT '',
  action  TEXT DEFAULT '',
  verdict TEXT DEFAULT '',
  gate    TEXT DEFAULT '',
  detail  TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_spam_events_ts ON spam_events(ts);

CREATE TABLE IF NOT EXISTS spam_bans (
  ident   TEXT PRIMARY KEY,
  reason  TEXT DEFAULT '',
  until   REAL NOT NULL,
  by      TEXT DEFAULT 'auto',
  created REAL NOT NULL
);

-- v277 (فاز۳): قفل تأیید ورود — شمارش تلاش ناموفق per-کلید (جفت شماره|IP)
CREATE TABLE IF NOT EXISTS login_fails (
  key          TEXT PRIMARY KEY,
  fails        INTEGER DEFAULT 0,
  locked_until REAL DEFAULT 0,
  updated      REAL DEFAULT 0
);

-- v277 (فاز۳): تنوع شماره per-IP (ضد enumeration)
CREATE TABLE IF NOT EXISTS spam_divers (
  ident TEXT NOT NULL,
  value TEXT NOT NULL,
  ts    REAL NOT NULL,
  UNIQUE(ident, value)
);
CREATE INDEX IF NOT EXISTS idx_spam_divers_ts ON spam_divers(ts);

CREATE INDEX IF NOT EXISTS idx_q_biz ON questions(biz_id, status);
CREATE INDEX IF NOT EXISTS idx_rep_status ON reports(status);
CREATE INDEX IF NOT EXISTS idx_sub_biz ON subscriptions(biz_id, status);
CREATE INDEX IF NOT EXISTS idx_ads_slot ON ads(slot, active);
CREATE INDEX IF NOT EXISTS idx_ev_date ON cityevents(date);
CREATE INDEX IF NOT EXISTS idx_questions_status ON questions(status);   -- v285
CREATE INDEX IF NOT EXISTS idx_items_biz_feat ON items(biz_id,available,featured);  -- v285
CREATE INDEX IF NOT EXISTS idx_edit_status ON edits(status);
CREATE INDEX IF NOT EXISTS idx_item_biz ON items(biz_id);
CREATE INDEX IF NOT EXISTS idx_inq_biz ON inquiries(biz_id);
CREATE INDEX IF NOT EXISTS idx_sess_owner ON sessions(owner_id);
CREATE INDEX IF NOT EXISTS idx_claim_biz ON claims(biz_id);
CREATE INDEX IF NOT EXISTS idx_ev_biz ON events(biz_id, day);
CREATE INDEX IF NOT EXISTS idx_biz_cat ON businesses(cat_slug);
CREATE INDEX IF NOT EXISTS idx_biz_status ON businesses(status);
CREATE INDEX IF NOT EXISTS idx_rev_biz ON reviews(biz_id);
CREATE INDEX IF NOT EXISTS idx_book_biz ON bookings(biz_id);
CREATE INDEX IF NOT EXISTS idx_chat_thread_activity ON chat_threads(last_activity DESC);
CREATE INDEX IF NOT EXISTS idx_chat_msg_thread ON chat_messages(thread_id, id);
CREATE TABLE IF NOT EXISTS bot_confirmations (
  token TEXT PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  action TEXT NOT NULL,
  target_id INTEGER NOT NULL,
  value TEXT DEFAULT '',
  expires REAL NOT NULL,
  used INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_bot_confirm_exp ON bot_confirmations(expires);
CREATE TABLE IF NOT EXISTS owner_bot_confirmations (
  token TEXT PRIMARY KEY,
  owner_id INTEGER NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
  action TEXT NOT NULL,
  target_id INTEGER NOT NULL,
  value TEXT DEFAULT '',
  expires REAL NOT NULL,
  used INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_owner_bot_confirm_exp ON owner_bot_confirmations(expires);
CREATE TABLE IF NOT EXISTS owner_daily_summaries (
  owner_id INTEGER NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
  day TEXT NOT NULL,
  sent_at REAL NOT NULL,
  PRIMARY KEY(owner_id,day)
);
-- v207: staged business registration inside the Bale/Soroush bots.
-- One live draft per customer; `step` is authoritative server-side state and
-- `payload` is validated JSON. Expired drafts are garbage-collected lazily.
CREATE TABLE IF NOT EXISTS biz_reg_drafts (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL UNIQUE REFERENCES customers(id) ON DELETE CASCADE,
  platform    TEXT NOT NULL DEFAULT 'bale',
  step        TEXT NOT NULL DEFAULT 'category',
  payload     TEXT NOT NULL DEFAULT '{}',
  created     REAL NOT NULL,
  updated     REAL NOT NULL,
  expires     REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_bizreg_expires ON biz_reg_drafts(expires);
CREATE INDEX IF NOT EXISTS idx_chat_att_message ON chat_attachments(message_id);
"""

# ------------------------------------------------------------------ defaults
# نام عمومی محصول قرارداد برند است، نه تنظیم white-label. شناسه‌های داخلیِ
# لاتین (نام DB/کش/service/.bz-*) عمداً دست‌نخورده می‌مانند.
BRAND_NAME = "دست گیر"

DEFAULT_SETTINGS = {
    # Public address of the site. Empty means "work it out from the request",
    # which is right while it runs on a phone. Fill it in from the panel once
    # a real domain exists, and every QR code, sitemap entry and share link
    # switches to it at once instead of baking in 127.0.0.1.
    "site_url":      "",
    "site_name":     BRAND_NAME,
    "tagline":       "یارِ خرید و فروشِ محلی",
    "description":   "دست گیر یعنی دست گرفتن و یاری رساندن؛ راهنمای زندهٔ کسب‌وکارهای سراسر ایران با نقشه، ساعت کاری، نظرات واقعی و سفارش آنلاین.",
    "phone":         "۰۲۱-۹۱۰۰۰۰۰۰",
    "phone_raw":     "02191000000",
    "email":         "info@dastgir.ir",
    "address":       "تهران، خیابان ولیعصر",
    "instagram":     "https://instagram.com/",
    "telegram":      "https://t.me/",
    "whatsapp":      "https://wa.me/989130000000",
    "eitaa":         "",   # v211: site's own Iranian-messenger channels (full URL)
    "bale":          "",
    "soroush":       "",
    "rubika":        "",

    "hero_title":    "دستتان را می‌گیریم؛\nهر چه می‌خواهید، همین نزدیکی است",
    "hero_lead":     "دست گیر یعنی دست گرفتن و یاری رساندن. راهنمای زندهٔ کسب‌وکارهای شهر شما — با ساعت کاری لحظه‌ای، نقشه، نظرات واقعی مشتریان و سفارش آنلاین؛ راحت و بی‌دردسر.",
    "hero_cta":      "ثبت رایگان کسب‌وکار",
    "footer_note":   "ساخته‌شده با مهر، برای کسب‌وکارهای ایران",

    # Theme: «فیروزه و زعفران» — دست گیر's brand teal stays the primary, while
    # the accent is a warm Persian saffron so the whole site feels alive and
    # welcoming, not cold. These four values feed the DAY theme only (see
    # ui.theme_css); the night theme keeps its own tokens so night readability
    # can never be broken from the admin panel.
    "color_primary":    "#0b6059",   # دست گیر teal (5.4:1 on white)
    "color_accent":     "#b45309",   # زعفرانی گرم (5.0:1 with white text)
    "color_background": "#f7f3ec",   # warm ivory — soft, not sterile gray
    "color_foreground": "#241d14",   # warm espresso ink (14:1 on white)

    # map
    "map_provider":   "osm",         # osm (پیش‌فرض، محلی/بدون توکن) | google | auto
    "gmaps_key":      "",
    "map_lat":        "32.6340",
    "map_lng":        "51.3670",
    "map_zoom":       "14",

    # toggles
    "reg_open":          "1",
    "reviews_moderated": "1",
    "booking_enabled":   "1",
    "blog_enabled":      "1",
    "maintenance":       "0",
    "claims_enabled":    "1",
    "catalog_enabled":   "1",
    # v154 user decision (reverses v75): product prices and online ordering
    # start ON. The admin can still turn them off in /panel/settings; the
    # one-time migration below upgrades existing installs the same way.
    "prices_enabled":    "1",
    "price_orders_v154": "0",      # one-time migration marker (v154)
    "site_logo":         "",
    "inquiry_enabled":   "1",
    "owner_login":       "1",

    # SMS (Kavenegar-compatible). Empty key => codes are shown on screen instead.
    "sms_key":           "",
    "sms_sender":        "",
    "sms_template":      "",

    # v298: Email login — SMTP for sending OTP codes (like modern agent login agent)
    "smtp_host":         "",
    "smtp_port":         "587",
    "smtp_user":         "",
    "smtp_pass":         "",
    "smtp_from":         "",
    "smtp_tls":          "1",

    # Telegram notifications (optional free channel for owner alerts).
    # Create a bot with @BotFather, set tg_token, and put your numeric chat id
    # in tg_chat_id (find it via @userinfobot). Empty => disabled.
    "tg_token":          "",
    "tg_chat_id":        "",

    # Housekeeping bookmarks.
    "last_backup_at":    "",   # ISO timestamp of the last manual backup

    # ---- v3 world-class feature toggles
    "haggle_enabled":    "0",    # چانه‌زنی — خاموش به‌صورت پیش‌فرض (مدیر فعال می‌کند)
    "qa_enabled":        "1",    # public questions & answers
    "reports_enabled":   "1",    # abuse / wrong-info reporting
    "nearby_enabled":    "1",    # radius search "near me"
    "events_enabled":    "1",    # city events
    "ads_enabled":       "1",    # advertising slots
    "plans_enabled":     "1",    # real subscriptions
    "alerts_enabled":    "1",    # saved search alerts
    "multicriteria":     "1",    # multi-criteria review scores
    "edit_approval":     "0",    # owner edits need admin approval
    "qa_moderated":      "1",    # questions need approval before showing
    "seo_schema":        "1",    # JSON-LD structured data
    "ratelimit_on":      "1",    # spam protection
    "ratelimit_n":       "8",    # max submissions
    "ratelimit_win":     "600",  # per this many seconds

    # ---- floating support widget
    "support_widget":    "1",
    "support_delay":     "60",   # seconds before it appears

    # ---- founding-member window (the doorstep promise)
    "founder_limit":     "100",   # first N shops keep the generous set free
    "founder_max_items": "10",
    "founder_max_photos": "6",
    "free_max_items":    "3",     # everyone after them
    "free_max_photos":   "3",

    # ---- v31 desirability features (each toggle also lives in /panel/features)
    "lists_enabled":      "1",    # برترین‌های شهر
    "deals_enabled":      "1",    # پیشنهاد روز / فلش‌سیل
    "stories_enabled":    "1",    # استوری ۲۴ ساعته
    "shop_account":       "1",    # حساب مشتری (ورود OTP)
    "orders_enabled":     "1",    # سبد خرید و سفارش آنلاین
    "order_cancel_minutes": "30", # لغو مستقیم؛ بعدش درخواست تأیید دکان‌دار
    "chat_enabled":       "1",    # گفتگوی مشتری و دکان‌دار
    "follow_enabled":     "1",    # دنبال‌کردن کسب‌وکار
    "notif_enabled":      "1",    # مرکز اعلان‌های مشتری
    # v213: دستیار هوشمند — سهمیهٔ روزانه بر اساس اشتراک + سقف کل روزانه
    "ai_enabled":         "1",
    "ai_quota_free":      "5",
    "ai_quota_plus":      "20",
    "ai_quota_pro":       "50",
    "ai_daily_cap":       "2000",
    # v259 (دستور مدیر: توکن فقط برای پنل کاربری و مدیرتیم): مدل برای
    # مهمان‌ها خاموش است — فقط واردشده‌ها پاسخ هوشمند می‌گیرند.
    "ai_guest_model":     "0",

    # ---- payment (manual card transfer works out of the box)
    "pay_method":        "manual",   # manual | zarinpal
    "pay_card":          "",         # card number for manual transfers
    "pay_card_name":     "",         # card holder name
    "pay_bank":          "",         # bank name shown next to the card
    "zarinpal_merchant": "",
}

def _taxonomy_rows():
    """The two-level category tree, loaded from tools/taxonomy.py.

    Kept in its own module because it is data, not logic — you can read and
    edit the whole tree there without scrolling past SQL. Falls back to the
    original flat list if that file is ever missing, so the site still boots.
    """
    try:
        sys.path.insert(0, os.path.join(HERE, "..", "tools"))
        import taxonomy
        return taxonomy.flatten()
    except Exception:
        return [(s, n, i, b, "", k)
                for k, (s, n, i, b) in enumerate(DEFAULT_CATEGORIES)]


DEFAULT_BADGES = [
    ("founder",       "بنیان‌گذار",          "star",    "#b45309",
     "از دکان‌های نخست دست گیر؛ پنل فراخوان برای همیشه باز است."),
    ("verified-shop", "فروشگاه احراز‌شده", "shield",  "#059669",
     "هویت و نشانی این کسب‌وکار توسط دست گیر بررسی شده است."),
    ("top-rated",     "برترین امتیاز",      "award",   "#ea580c",
     "امتیاز بالای ۵٫۴ از ۶ با دست‌کم ۱۰ نظر تأییدشده."),
    ("fast-reply",    "پاسخ‌گوی سریع",      "zap",     "#0284c7",
     "به پیام‌های مشتریان در کمتر از یک روز پاسخ می‌دهد."),
    ("old-shop",      "قدیمی و باسابقه",    "clock",   "#7c3aed",
     "بیش از ده سال سابقهٔ فعالیت در شهر نجف‌آباد."),
    ("family",        "کسب‌وکار خانوادگی",  "users",   "#be185d",
     "توسط یک خانوادهٔ نجف‌آبادی اداره می‌شود."),
]

DEFAULT_PLANS = [
    ("free", "پایه", 0, 12, 0, 3, 3,
     "صفحهٔ اختصاصی کسب‌وکار\nنمایش روی نقشه\nدریافت نظر مشتریان\nساعت کاری زنده", "",
     "برای شروع و معرفی اولیه", ""),
    ("plus", "حرفه‌ای", 1200000, 12, 1, 60, 20,
     "همهٔ امکانات پایه\nنشان «ویژه» و بالاتر بودن در فهرست\nتا ۶۰ محصول یا خدمت\nتا ۲۰ تصویر در گالری\nآمار بازدید و تماس\nپاسخ به نظرات", "verified-shop",
     "مناسب کسب‌وکارهای فعال شهر",
     "gallery,catalog,booking,stats,reply,qa,inquiry,social,featured"),
    ("pro", "ویژهٔ دست گیر", 2900000, 12, 3, 300, 40,
     "همهٔ امکانات حرفه‌ای\nجایگاه ثابت در صفحهٔ نخست\nبنر تبلیغاتی اختصاصی\nمحصولات نامحدود عملی (۳۰۰ مورد)\nپشتیبانی مستقیم", "top-rated",
     "برای برندها و مجموعه‌های بزرگ", "*"),
]

# v151: review criteria are no longer a global fixed list — each business is
# scored only on the criteria its real facilities allow (see biz_criteria).
# quality/behaviour: every shop. price/speed: only with a live catalogue
# (>=1 available item). booking: only when online booking is switched on.
REVIEW_ALLOWED = {"quality", "price", "speed", "booking", "behaviour"}

def biz_criteria(biz_id):
    """(code, label) list this business may be scored on, from its facilities."""
    con = connect()
    row = con.execute(
        "SELECT booking_on, "
        "(SELECT COUNT(*) FROM items WHERE biz_id=? AND available=1) ncat "
        "FROM businesses WHERE id=?", (biz_id, biz_id)).fetchone()
    con.close()
    if not row:
        return [("quality", "کیفیت کار"), ("behaviour", "برخورد و راهنمایی")]
    out = [("quality", "کیفیت کار")]
    if (row["ncat"] or 0) > 0:
        out += [("price", "قیمت منصفانه"), ("speed", "سرعت و به‌موقع بودن")]
    if row["booking_on"]:
        out.append(("booking", "وقت‌شناسی و پایبندی به نوبت"))
    out.append(("behaviour", "برخورد و راهنمایی"))
    return out

def rating_stats(con, biz_id):
    """(avg, nrated, nreviews) for one business, using one open connection."""
    a = con.execute("SELECT AVG(rating) a, COUNT(*) c FROM reviews "
                    "WHERE biz_id=? AND status='approved' AND rating>0",
                    (biz_id,)).fetchone()
    n = con.execute("SELECT COUNT(*) c FROM reviews "
                    "WHERE biz_id=? AND status='approved'", (biz_id,)).fetchone()
    return (round(a["a"], 1) if a["a"] else 0, a["c"] or 0, n["c"] or 0)

REPORT_REASONS = [
    ("closed",   "این کسب‌وکار تعطیل شده است"),
    ("wrong",    "اطلاعات نادرست است (تلفن، نشانی، ساعت)"),
    ("duplicate","تکراری است"),
    ("spam",     "تبلیغ یا محتوای نامناسب"),
    ("notmine",  "بدون اجازهٔ من ثبت شده"),
    ("other",    "دلیل دیگر"),
]

DEFAULT_CATEGORIES = [
    ("restaurant",    "رستوران و غذا",   "restaurant",    "غذای ایرانی، فست‌فود، بیرون‌بر و تالار پذیرایی"),
    ("cafe",          "کافه و قهوه",      "cafe",          "کافی‌شاپ، قهوهٔ تخصصی، صبحانه و دورهمی"),
    ("bakery",        "نانوایی",          "bakery",        "سنگک، بربری، تافتون و نان فانتزی"),
    ("confectionery", "شیرینی و قنادی",   "confectionery", "کیک سفارشی، شیرینی‌تر و خشک، دسر"),
    ("shopping",      "خرید و سوپرمارکت", "shopping",      "هایپرمارکت، خواربار، میوه و تره‌بار"),
    ("clothing",      "پوشاک",            "clothing",      "بوتیک زنانه و مردانه، کفش و کیف"),
    ("jewellery",     "طلا و جواهر",      "jewellery",     "طلافروشی، نقره، ساعت و بدلیجات"),
    ("medical",       "پزشکی و سلامت",    "medical",       "مطب، داروخانه، آزمایشگاه و دندان‌پزشکی"),
    ("auto",          "خودرو و تعمیرگاه", "auto",          "مکانیکی، صافکاری، لوازم یدکی و کارواش"),
    ("realestate",    "املاک",            "realestate",    "خرید، فروش، رهن و اجارهٔ ملک"),
    ("barber",        "آرایش و زیبایی",   "barber",        "سالن زیبایی، پیرایش مردانه، اسپا"),
    ("education",     "آموزش",            "education",     "آموزشگاه زبان، کنکور، هنر و موسیقی"),
    ("mobile",        "موبایل و دیجیتال", "mobile",        "گوشی، لپ‌تاپ، لوازم جانبی و تعمیرات"),
    ("gym",           "ورزش و باشگاه",    "gym",           "بدنسازی، آمادگی جسمانی، رزمی و استخر"),
    ("homeservice",   "خدمات ساختمان",    "homeservice",   "نقاشی، برق‌کاری، لوله‌کشی و کابینت"),
    ("flowers",       "گل و گیاه",        "flowers",       "گل‌فروشی، گیاه آپارتمانی و باغبانی"),
    ("photography",   "عکاسی و فیلم",     "photography",   "آتلیه، عکاسی صنعتی و فیلم‌برداری مراسم"),
]

# v285: متن کامل قوانین بر مبنای قوانین جمهوری اسلامی ایران؛ _RULES_V1 متن
# پیشین است و فقط برای مهاجرت محافظه‌کارانه (بدون بازنویسی ویرایش ادمین) نگه
# داشته می‌شود.
_RULES_BODY_V285 = "## پذیرش و مبنای قانونی\nاستفاده از سایت «دست گیر» (نشانی daastgir.ir و زیردامنه‌های آن) به‌منزلهٔ پذیرش کامل قوانین و مقررات زیر است. این مقررات بر پایهٔ قوانین جمهوری اسلامی ایران، از جمله قانون تجارت الکترونیکی (مصوب ۱۳۸۲/۱/۱۷)، قانون حمایت از امضای الکترونیکی (مصوب ۱۳۸۲)، قانون حمایت از حقوق مصرف‌کنندگان (مصوب ۱۳۸۸/۵/۲۳)، قانون جرایم رایانه‌ای (مصوب ۱۳۸۸/۵/۵)، قانون مجازات اسلامی، قانون مدنی (به‌ویژه مواد ۱۰، ۱۹۰ و ۳۳۸ به بعد) و ضوابط و دستورالعمل‌های نماد اعتماد الکترونیکی (اینماد) تدوین شده است. اگر با بخشی از این مقررات موافق نیستید، از استفاده از سایت خودداری کنید.\n## مادهٔ ۱ — تعاریف\n«سایت/بستر»: پایگاه اینترنتی دست گیر. «گرداننده»: تیم اداره‌کنندهٔ سایت. «کاربر»: هر شخص حقیقی یا حقوقی که از سایت استفاده می‌کند. «مشتری»: کاربری که کالا یا خدمتی را جست‌وجو، سفارش یا نوبت‌گیری می‌کند. «دکان‌دار/صاحب کسب‌وکار»: کاربری که ویترین کسب‌وکارش را در سایت ثبت یا تصاحب کرده است. «ویترین»: صفحهٔ اختصاصی کسب‌وکار شامل نام، نشانی، ساعت کاری، محصولات، خدمات و نظرات. «سفارش»: درخواست خرید کالا یا خدمت از طریق ابزارهای سایت. «نوبت»: رزرو زمانی برای دریافت خدمت حضوری یا غیرحضوری. «دستیار هوشمند»: سامانهٔ پاسخ‌گوی خودکار مبتنی بر هوش مصنوعی. «محتوای کاربر»: هر متن، تصویر، ویدیو، نظر یا پرسشی که کاربر در سایت ثبت می‌کند.\n## مادهٔ ۲ — ماهیت بستر و حدود مسئولیت\nدست گیر یک بستر معرفی و تسهیل‌گر الکترونیکی است و به استثنای مواردی که صریحاً پذیرفته باشد، «طرف معامله» میان مشتری و کسب‌وکار نیست؛ مسئولیت کیفیت کالا یا خدمت، قیمت‌گذاری، تأمین، گارانتی و خدمات پس از فروش مستقیماً بر عهدهٔ کسب‌وکار ارائه‌دهنده است (مادهٔ ۲ قانون تجارت الکترونیکی و مادهٔ ۱۰ قانون مدنی). گرداننده تلاش می‌کند اطلاعات ویترین‌ها راستی‌آزمایی شود، اما صحت لحظه‌ای داده‌ها (مانند ساعت کاری یا موجودی) بر عهدهٔ صاحب کسب‌وکار است. این محدودیت مسئولیت، تعهدات قانونی غیرقابل‌اسقاط گرداننده را منتفی نمی‌کند.\n## مادهٔ ۳ — شرایط عمومی استفاده\nکاربر باید دارای اهلیت قانونی (۱۸ سال تمام یا مجاز از سوی ولی/قیم) باشد. استفاده با هویت جعلی، انتشار محتوای خلاف عفت عمومی، نقض حقوق اشخاص، اختلال در عملکرد سایت (از جمله حملهٔ محروم‌سازی، خزش مخرب یا بارگذاری بدافزار) و هر استفادهٔ تجاری غیرمجاز از داده‌های سایت ممنوع است و پیگرد قانونی دارد (مواد ۷۲۹ به بعد قانون مجازات اسلامی و قانون جرایم رایانه‌ای).\n## مادهٔ ۴ — ثبت و ادارهٔ کسب‌وکار\nصاحب کسب‌وکار متعهد است اطلاعات هویتی، نشانی، شمارهٔ تماس، ساعت کاری، فهرست محصولات/خدمات و قیمت‌ها را دقیق، به‌روز و منطبق با واقعیت ثبت کند. داشتن مجوزهای قانونی لازم برای فعالیت (پروانهٔ کسب، مجوز بهداشت و مانند آن حسب مورد) بر عهدهٔ خود کسب‌وکار است و گرداننده حق دارد در هر زمان مستند آن را درخواست و در صورت عدم ارائه، ویترین را تعلیق کند. مسئولیت حقوقی محتوای ویترین (تصاویر، شعار، توصیف‌ها) با صاحب کسب‌وکار است. هرگونه تغییر مالکیت یا تعطیلی باید بی‌درنگ به پشتیبانی اطلاع داده شود. ثبت اطلاعات کسب‌وکار دیگران بدون اجازه، تخلف و موجب حذف و مسدودسازی است.\n## مادهٔ ۵ — سفارش‌ها و تراکنش‌های مالی\nثبت سفارش توسط مشتری به منزلهٔ «ایجاب» و تأیید آن توسط کسب‌وکار به منزلهٔ «قبول» است و عقد فروش طبق مواد ۳۳۸ و ۳۳۹ قانون مدنی و مواد ۳۳ تا ۳۸ قانون تجارت الکترونیکی شکل می‌گیرد. قیمت نهایی، همان مبلغ درج‌شده در ویترین هنگام ثبت سفارش است؛ کسب‌وکار حق ندارد پس از تأیید، مبلغ را یک‌طرفه تغییر دهد. داده‌نوشتهٔ رسید سفارش و پیامک/پیام تأیید، در حکم اسناد الکترونیکی معتبرند (قانون حمایت از امضای الکترونیکی). در صورت عدم تحویل کالا یا خدمت مطابق سفارش، مشتری مطابق مادهٔ ۷ قانون حمایت از حقوق مصرف‌کنندگان حق استرداد وجه یا جایگزینی دارد؛ مسئولیت اجرا بر عهدهٔ کسب‌وکار است و گرداننده در صورت درخواست، همکاری لازم برای پیگیری را انجام می‌دهد. روش‌های پرداخت فعال (درگاه بانکی دارای نماد، کارت‌به‌کارت و مانند آن) در صفحهٔ سفارش اعلام می‌شود.\n## مادهٔ ۶ — نوبت‌دهی آنلاین\nنوبت اینترنتی یک «رزرو مقدماتی» است و قطعی‌شدن آن به تأیید کسب‌وکار وابسته است (مگر آنکه در صفحه نوبت، قطعی بودن اعلام شود). کاربر موظف است در زمان تعیین‌شده مراجعه کند یا پیش از آن نوبت را لغو نماید؛ لغو دیرهنگام مکرر می‌تواند به محدود شدن دسترسی کاربر به نوبت‌گیری بینجامد. کسب‌وکار مسئول مدیریت ظرفیت و زمان‌بندی خود است.\n## مادهٔ ۷ — نظرات، امتیازها و محتوای کاربر\nنظر باید بر تجربهٔ واقعی کاربر از همان کسب‌وکار استوار باشد. انتشار مطلب توهین‌آمیز، افتراآمیز (مادهٔ ۶۹۷ قانون مجازات اسلامی و مواد ۶ و ۱۷ قانون جرایم رایانه‌ای)، نقض حریم خصوصی اشخاص، تبلیغ کسب‌وکار رقیب، درج قیمت یا ادعای کذب، و هر محتوای مغایر قوانین جمهوری اسلامی ممنوع است. گرداننده حق بررسی، انتشار مشروط، ویرایش فنی (بدون تغییر محتوا)، حذف و ارجاع موارد مجرمانه به مراجع قضایی (پلیس فتا و دادسرای جرایم رایانه‌ای) را دارد. مسئولیت مدنی و کیفری محتوای ثبت‌شده مستقیماً با کاربر منتشرکننده است.\n## مادهٔ ۸ — پرسش و پاسخ؛ ویرایش و حذف پیام\nدر بخش پرسش‌وپاسخ و گفت‌وگوها، هر طرف صرفاً مجاز به ویرایش یا حذف پیام خودش است. ویرایش پرسش تنها تا ۱۵ دقیقه پس از ثبت ممکن است و پس از آن فقط حذف می‌شود؛ پیام ویرایش‌شده با برچسب «ویرایش شده» نمایش داده می‌شود و مسئولیت محتوای جدید با ویرایش‌کننده است. حذف پرسش توسط پرسشگر، پاسخ‌های پیوست به آن را نیز از نمایش عمومی خارج می‌کند. پاسخ صاحب کسب‌وکار صرفاً توسط خودش یا مدیر سایت قابل ویرایش/حذف است.\n## مادهٔ ۹ — حریم خصوصی و داده‌های شخصی\nگرداننده مطابق اصول ۲۲ و ۲۵ قانون اساسی و مواد ۵۷ تا ۶۰ قانون تجارت الکترونیکی از داده‌های کاربران حفاظت می‌کند. اطلاعات شخصی (نام، شمارهٔ تماس، نشانی، سفارش‌ها) هرگز به اشخاص ثالث فروخته نمی‌شود و تنها در حد ضرورت اجرای سفارش/نوبت در اختیار همان کسب‌وکار مرتبط قرار می‌گیرد. شمارهٔ تماس کاربر فقط با تأیید و اقدام خودش (مانند ورود با پیام‌رسان یا ثبت سفارش) پردازش می‌شود. داده‌ها با رمزنگاری/هش استاندارد نگهداری می‌شوند و کاربر هر زمان می‌تواند درخواست حذف حساب و داده‌های شخصی خود را از پشتیبانی پیگیری کند، مگر داده‌هایی که نگهداری آن‌ها به حکم قانون یا مقام قضایی الزامی است. استفاده از کوکی و حافظهٔ مرورگر صرفاً برای بهبود تجربه و امنیت نشست‌هاست.\n## مادهٔ ۱۰ — دستیار هوشمند (هوش مصنوعی)\nپاسخ‌های دستیار هوشمند به‌صورت خودکار تولید می‌شوند و ممکن است با وجود تلاش برای دقت، دارای خطا باشند؛ ملاک نهایی در قیمت، موجودی، ساعت کاری و شرایط، اطلاعات تأییدشدهٔ ویترین و تأیید خود کسب‌وکار است. سهمیهٔ استفادهٔ روزانه برای جلوگیری از سوءاستفاده محدود است و در صفحهٔ تعرفه‌ها اعلام می‌شود. استفاده از دستیار برای تولید محتوای غیرقانونی، فریب‌کارانه یا مغایر اخلاق عمومی ممنوع است. تصمیم‌گیری نهایی کاربر بر پایهٔ خروجی دستیار، با مسئولیت خود اوست.\n## مادهٔ ۱۱ — مالکیت فکری\nطراحی، نشان، متن‌ها، کدها و داده‌های تجمیعی سایت متعلق به گرداننده است و هرگونه کپی‌برداری، بازمهندسی، خزش سیستماتیک یا استفادهٔ تجاری بدون اجازهٔ کتبی ممنوع است. محتوای ویترین متعلق به کسب‌وکار و محتوای کاربر متعلق به خود کاربر است؛ کاربر با ثبت محتوا، حق نمایش، انتشار و نمایه‌سازی آن را در چارچوب فعالیت سایت به گرداننده اعطا می‌کند. تصاویر بارگذاری‌شده باید دارای مجوز قانونی باشند.\n## مادهٔ ۱۲ — اشتراک‌ها، پلن‌ها و تعرفه‌ها\nپلن‌ها، قیمت‌ها، مدت اشتراک و سهمیه‌ها (از جمله تعداد پیام روزانهٔ دستیار هوشمند، سقف محصول و تصویر) دقیقاً مطابق صفحهٔ «تعرفه‌ها» و زمان خرید است. اشتراک پس از پرداخت و تأیید گرداننده فعال می‌شود. به‌استثنای موارد پیش‌بینی‌شده در قانون حمایت از حقوق مصرف‌کنندگان، وجه اشتراکِ دورهٔ آغازشده مسترد نمی‌شود؛ تغییر پلن در میانهٔ دوره به نسبت زمان باقی‌مانده محاسبه می‌گردد. گرداننده می‌تواند تعرفه‌ها را برای دوره‌های بعدی تغییر دهد؛ تغییر، عطف‌به‌ماسبق نمی‌شود و بر اشتراک‌های فعال اثر ندارد.\n## مادهٔ ۱۳ — تخلفات، تعلیق و مسدودسازی\nدر صورت نقض این مقررات، ثبت اطلاعات کذب، کلاهبرداری یا رفتار مخرب، گرداننده می‌تواند حسب مورد اخطار، محدودسازی موقت، حذف محتوا یا مسدودسازی دائم حساب و ویترین اعمال کند؛ این اقدام مانع پیگرد قانونی از طریق مراجع قضایی نیست. کاربر معترض می‌تواند از طریق پشتیبانی درخواست بازبینی دهد و گرداننده موظف است در مهلت معقول (حداکثر ۷ روز کاری) پاسخ دهد.\n## مادهٔ ۱۴ — فورس ماژور\nدر حوادث خارج از کنترل (بلایای طبیعی، قطع سراسری اینترنت یا برق، حملات سایبری گسترده، مقررات حاکمیتی) اجرای تعهدات تا رفع مانع به حالت تعلیق درمی‌آید؛ سفارش‌ها و نوبت‌های متضرر در اولین فرصت تعیین‌تکلیف و در صورت لزوم وجه مسترد می‌شود.\n## مادهٔ ۱۵ — حل اختلاف\nاختلافات ابتدا از طریق پشتیبانی سایت (تیکت، تماس یا پیام‌رسان‌های رسمی) حل‌وفصل می‌شود. در صورت عدم حصول نتیجه، مرجع رسیدگی، شوراهای حل اختلاف و دادگاه‌های صالح جمهوری اسلامی ایران حسب مورد است و قانون حاکم، قانون ایران می‌باشد. این شرط، حقوق مصرف‌کننده برای مراجعهٔ مستقیم به مراجع قانونی (از جمله سازمان تعزیرات حکومتی و سامانهٔ ۱۲۴) را محدود نمی‌کند.\n## مادهٔ ۱۶ — اینماد و نشان اعتماد\nسایت دارای نشان اعتماد الکترونیکی (اینماد) است؛ وضعیت اعتبار نشان به‌صورت زنده از سامانهٔ اینماد قابل استعلام است. ثبت شکایت از کسب‌وکارهای دارای نماد نیز از طریق سامانهٔ اینماد ممکن است.\n## مادهٔ ۱۷ — تغییرات مقررات\nگرداننده ممکن است این مقررات را به‌روزرسانی کند؛ نسخهٔ جاری همیشه در همین صفحه منتشر می‌شود و تاریخ آخرین به‌روزرسانی در بالا درج می‌گردد. ادامهٔ استفاده از سایت پس از انتشار تغییرات، به منزلهٔ پذیرش آن است؛ تغییرات اساسی از طریق اعلان در سایت یا پیام به کاربران اطلاع‌رسانی می‌شود.\n## مادهٔ ۱۸ — راه‌های ارتباطی\nارتباط رسمی با گرداننده از طریق صفحهٔ «تماس با ما»، تیکت پشتیبانی در پنل کاربری و پیام‌رسان‌های معرفی‌شده در سایت انجام می‌شود. مکاتبات الکترونیکی از همین راه‌ها، در حکم مکاتبهٔ معتبر و قابل استناد است."
_RULES_V1 = "استفاده از سایت دست گیر به‌منزلهٔ پذیرش قوانین زیر است.\n\n۱. اطلاعات ثبت‌شده باید دقیق و متعلق به کسب‌وکار واقعی باشد.\n۲. نظرات باید بر تجربهٔ واقعی مشتری استوار باشد.\n۳. اطلاعات شخصی کاربران هرگز به اشخاص ثالث فروخته نمی‌شود.\n۴. دست گیر بستر معرفی است و طرف معاملهٔ بین کاربر و کسب‌وکار نیست."


DEFAULT_PAGES = {
    "about": ("درباره ما",
              "دست گیر یعنی «دست گرفتن و یاری رساندن» — نام ما هم از همین ریشه آمده.\n\n"
              "ما یک تیم محلی هستیم که باور داریم کسب‌وکارهای شهرمان لایق دیده‌شدن‌اند. "
              "به‌جای آنکه برای پیدا کردن یک نانوایی، یک تعمیرکار یا یک مطب خوب، سراغ ده‌ها "
              "منبع پراکنده بروید، ما همه را یک‌جا و راستی‌آزمایی‌شده کنار هم آورده‌ایم: نام، "
              "آدرس، ساعت کاری زنده، نقشه، شمارهٔ تماس و نظرهای واقعی مشتریان.\n\n"
              "برای مشتری، دست گیر یعنی پیدا کردن سریعِ همان کسی که امروز به آن نیاز دارد؛ "
              "برای دکان‌دار، یعنی ویترینی که همیشه باز است — حتی وقتی خودش خواب است.\n\n"
              "ما کنار کسب‌وکار محلی می‌ایستیم، چون رشدِ شهر از رشد همین دکان‌های کوچک "
              "شروع می‌شود."),
    "rules": ("قوانین و مقررات", _RULES_BODY_V285),
}


# ------------------------------------------------------------------ core
class _PersistentCon:
    """Wrapper that makes close() a no-op so a per-thread connection can be
    reused by every query in the request instead of being opened/closed dozens
    of times. All attribute access passes through to the real connection."""
    __slots__ = ("_c",)

    def __init__(self, con):
        self._c = con

    def close(self):  # keep the shared connection alive
        pass

    def __getattr__(self, name):
        return getattr(self._c, name)


_thread_local = threading.local()


def connect():
    """One SQLite connection per thread, reused for the whole request.

    v107 perf: the home page used to open ~67 separate connections (one per
    query), each paying the open+schema+close cost. On the phone that runs the
    server (Pydroid) that overhead is what made the site feel slow. A per-thread
    connection collapses those 67 opens into one; close() is neutralised via
    _PersistentCon so the hundreds of existing `con.close()` calls keep working.

    v109 hardening: if this thread's connection was left holding an OPEN write
    transaction (a handler crashed between an execute() and its commit — for
    example while an external tool held the DB), the very next acquire rolls
    the dangling transaction back. Left alone, that half-open transaction
    holds SQLite's writer lock and every later write on the site fails with
    «database is locked» until restart.
    """
    con = getattr(_thread_local, "con", None)
    if con is None:
        con = sqlite3.connect(DB_PATH, timeout=15, check_same_thread=False)
        con.row_factory = sqlite3.Row
        # v116-perf: with WAL, synchronous=FULL fsyncs on EVERY commit — and
        # since v114 every single page view commits (the visits row), which
        # capped throughput. NORMAL is the standard WAL pairing: no
        # corruption risk, only the last transactions are lost on a crash.
        con.execute("PRAGMA synchronous = NORMAL")
        # v116-perf: default page cache is 2MB per connection; with the
        # capped worker pool that is 128MB worst case on a phone. 1MB is
        # plenty for this schema and halves that.
        con.execute("PRAGMA cache_size = -1000")
        con.execute("PRAGMA foreign_keys = ON")
        _thread_local.con = con
    else:
        try:
            if con.in_transaction:
                con.rollback()          # v109: never inherit a dangling txn
        except sqlite3.Error:
            pass
    return _PersistentCon(con)


def _reconcile_schema(con):
    """v116-audit: columns added to CREATE TABLE over time reach FRESH
    databases only — an old install silently lacked them (caught live:
    businesses.views was in SCHEMA but had no hand-written ALTER, so a
    pre-views DB would crash every query touching it). Parse SCHEMA
    itself and ALTER-ADD any plain column an existing table is missing.
    Columns SQLite cannot ALTER in (PK/UNIQUE/AUTOINCREMENT/NOT NULL
    without DEFAULT) are skipped — those only ever existed on fresh
    tables anyway."""
    for m in re.finditer(r"CREATE TABLE IF NOT EXISTS\s+(\w+)\s*\((.*?)\n\);",
                         SCHEMA, re.S):
        table, body = m.group(1), m.group(2)
        have = {r[1] for r in con.execute(f"PRAGMA table_info({table})")}
        if not have:
            continue
        for line in body.splitlines():
            line = line.split("--")[0].strip().rstrip(",")
            if not line:
                continue
            parts = line.split()
            col = parts[0]
            if not re.fullmatch(r"[a-z_][a-z0-9_]*", col) or col in have:
                continue
            rest = " ".join(parts[1:]).upper()
            if ("PRIMARY KEY" in rest or "UNIQUE" in rest
                    or "AUTOINCREMENT" in rest
                    or ("NOT NULL" in rest and "DEFAULT" not in rest)):
                continue
            try:
                con.execute(f"ALTER TABLE {table} ADD COLUMN {col} "
                            + " ".join(parts[1:]))
            except sqlite3.OperationalError:
                pass


def _heal_categories(con):
    """v147: دو گروه بالای صفحهٔ کسب‌وکارها آیکون یکسان داشتند («خانه و
    دکوراسیون» و «خدمات منزل» هر دو homeservice.webp) — در ردیف چیپ‌های
    فیلتر دو آیکون یکسان کنار هم دیده می‌شد. خانه به آیکون مجزای homecare
    مهاجرت می‌کند؛ idempotent و هر بار بوت اجرا می‌شود تا دیتابیس‌های قدیمی
    هم درمان شوند (سید تازه در tools/taxonomy.py اصلاح شده)."""
    try:
        con.execute("UPDATE categories SET icon='homecare' "
                    "WHERE slug='home' AND icon='homeservice'")
    except sqlite3.OperationalError:
        pass


def _migrate_ratings(con):
    """v151: a review's stored rating must match the mean of the criteria its
    business is *allowed* today. Older rows stored an independent rating and,
    for plain-info shops, criteria (price/speed) that are no longer offered.
    Idempotent — recomputing twice yields the same number."""
    rows = con.execute(
        "SELECT rs.review_id rid, rs.criterion code, rs.score, r.biz_id "
        "FROM review_scores rs JOIN reviews r ON r.id=rs.review_id "
        "ORDER BY rs.review_id").fetchall()
    cur_rid, buf, bid = None, [], None
    def flush():
        if buf is not None and bid is not None and buf:
            b = con.execute("SELECT booking_on, (SELECT COUNT(*) FROM items "
                            "WHERE biz_id=? AND available=1) ncat "
                            "FROM businesses WHERE id=?", (bid, bid)).fetchone()
            if b:
                allow = {"quality", "behaviour"}
                if (b["ncat"] or 0) > 0:
                    allow |= {"price", "speed"}
                if b["booking_on"]:
                    allow.add("booking")
                vals = [v for c, v in buf if c in allow]
                if vals:
                    con.execute("UPDATE reviews SET rating=? WHERE id=?",
                                (int(sum(vals) / len(vals) + 0.5), cur_rid))
    for r in rows:
        if r["rid"] != cur_rid:
            flush(); cur_rid, buf, bid = r["rid"], [], r["biz_id"]
        buf.append((r["code"], r["score"]))
    flush()


def init():
    """Create schema and seed defaults. Idempotent."""
    con = connect()
    con.executescript(SCHEMA)
    _reconcile_schema(con)
    _heal_categories(con)
    _migrate_ratings(con)

    cur = con.execute("SELECT COUNT(*) c FROM settings")
    if cur.fetchone()["c"] == 0:
        for k, v in DEFAULT_SETTINGS.items():
            con.execute("INSERT INTO settings(key,value) VALUES(?,?)", (k, v))
        # owner access token, generated once
        con.execute("INSERT INTO settings(key,value) VALUES(?,?)",
                    ("owner_token", secrets.token_urlsafe(16)))
        con.execute("INSERT INTO settings(key,value) VALUES(?,?)",
                    ("owner_pass_hash", ""))

    # make sure newly added defaults land in existing databases too
    have = {r["key"] for r in con.execute("SELECT key FROM settings")}
    for k, v in DEFAULT_SETTINGS.items():
        if k not in have:
            con.execute("INSERT INTO settings(key,value) VALUES(?,?)", (k, v))
    # v251: نام سایت دیگر در هر بوت به برند برنمی‌گردد — انتخاب مدیر می‌ماند.
    # (پیش‌فرض برند برای دیتابیس تازه از DEFAULT_SETTINGS می‌آید.)
    if "owner_token" not in have:
        con.execute("INSERT INTO settings(key,value) VALUES(?,?)",
                    ("owner_token", secrets.token_urlsafe(16)))

    # ---- migration: the old default primary #059669 was only ~3.5:1 as
    # text. Upgrade databases still on the untouched default to brand-700;
    # a custom colour the owner actually chose is left alone.
    cur = con.execute("SELECT value FROM settings WHERE key='color_primary'")
    row = cur.fetchone()
    if row and row["value"] == "#059669":
        con.execute("UPDATE settings SET value='#047857' WHERE key='color_primary'")

    # ---- migration v65: dark green theme needs a LIGHT primary colour. The
    # factory value from the light-theme era (#047857) is far too dark against
    # the new #162019 background; upgrade it once. A custom choice is respected.
    row = con.execute("SELECT value FROM settings WHERE key='color_primary'").fetchone()
    if row and row["value"] == "#047857":
        con.execute("UPDATE settings SET value='#34d399' WHERE key='color_primary'")

    # ---- migration v60: warm film grading. The old mint-tinted background
    # and green-black text read as cold; warm them once, but only when the
    # owner is still on the factory value (a custom choice is respected).
    _warm = (("color_background", "#f4f8f7", "#faf6ef"),
             ("color_foreground", "#0b1f1a", "#241c13"))
    for key, old, new in _warm:
        r = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        if r and r["value"] == old:
            con.execute("UPDATE settings SET value=? WHERE key=?", (new, key))

    # ---- migration v111: the luxury «Gilded Lapis» identity is retired.
    # Databases still sitting on ANY factory colour from earlier eras are moved
    # to the formal neutral defaults once. A colour the owner picked himself is
    # left untouched (it is not in the factory list, so the check below skips
    # it). Night-mode colours are never stored here, so night is unaffected.
    _v111 = (
        ("color_primary",    ("#059669", "#047857", "#34d399", "#d9b25c"), "#23559f"),
        ("color_accent",     ("#059669", "#047857", "#34d399", "#e6c76a"), "#23559f"),
        ("color_background", ("#faf6ef",),                                "#f0f2f4"),
        ("color_foreground", ("#241c13",),                                "#1b1f25"),
    )
    for key, olds, new in _v111:
        r = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        if r and r["value"] in olds:
            con.execute("UPDATE settings SET value=? WHERE key=?", (new, key))

    # ---- migration v119: «سبز روشن» identity. Databases still on the
    # v111 factory blue are moved to the green factory values once; a colour
    # the owner chose himself is untouched.
    _v119 = (
        ("color_primary",    ("#23559f", "#14894f"), "#0f7d46"),
        ("color_accent",     ("#23559f", "#14894f"), "#0f7d46"),
        ("color_background", ("#f0f2f4",), "#f2faf5"),
        ("color_foreground", ("#1b1f25",), "#0d2b1c"),
    )
    for key, olds, new in _v119:
        r = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        if r and r["value"] in olds:
            con.execute("UPDATE settings SET value=? WHERE key=?", (new, key))

    # ---- v154 user decision: ordering with a real cart is ON. The v75 era
    # forced prices OFF once (its marker keyed price_visibility_v75); the
    # recorded user decision in v152-4 reversed that, so existing installs
    # get prices/ordering turned ON exactly once here. Afterwards the admin
    # can still switch prices off in /panel/settings and it stays off.
    marker = con.execute(
        "SELECT value FROM settings WHERE key='price_orders_v154'").fetchone()
    if not marker or marker["value"] != "1":
        con.execute("INSERT INTO settings(key,value) VALUES('prices_enabled','1') "
                    "ON CONFLICT(key) DO UPDATE SET value='1'")
        con.execute("INSERT INTO settings(key,value) VALUES('price_orders_v154','1') "
                    "ON CONFLICT(key) DO UPDATE SET value='1'")

    # v170/#23: یکسان‌سازی قالب تاریخ فلش‌سیل‌های قدیمی (Tدار/بی‌ثانیه →
    # «YYYY-MM-DD HH:MM:SS») تا فیلتر پنجرهٔ زنده همیشه درست مقایسه کند.
    con.execute("UPDATE flashdeals SET ends=replace(ends,'T',' ') WHERE ends LIKE '%T%'")
    con.execute("UPDATE flashdeals SET starts=replace(starts,'T',' ') WHERE starts LIKE '%T%'")
    con.execute("UPDATE flashdeals SET ends=ends||':00' "
                "WHERE ends GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9] [0-9][0-9]:[0-9][0-9]' "
                "AND length(ends)=16")
    con.execute("UPDATE flashdeals SET starts=starts||':00' "
                "WHERE starts GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9] [0-9][0-9]:[0-9][0-9]' "
                "AND length(starts)=16")

    cur = con.execute("SELECT COUNT(*) c FROM categories")
    if cur.fetchone()["c"] == 0:
        for slug, name, icon, blurb, parent, sort in _taxonomy_rows():
            con.execute(
                "INSERT INTO categories(slug,name,icon,blurb,parent,sort) "
                "VALUES(?,?,?,?,?,?)", (slug, name, icon, blurb, parent, sort))

    # ---- migrations for databases created by an earlier version
    cols = {r["name"] for r in con.execute("PRAGMA table_info(businesses)")}
    if "owner_id" not in cols:
        con.execute("ALTER TABLE businesses ADD COLUMN owner_id INTEGER REFERENCES owners(id)")
    # index only after the column is guaranteed to exist
    con.execute("CREATE INDEX IF NOT EXISTS idx_biz_owner ON businesses(owner_id)")

    pcols = {r["name"] for r in con.execute("PRAGMA table_info(plans)")}
    if pcols and "tagline" not in pcols:
        con.execute("ALTER TABLE plans ADD COLUMN tagline TEXT DEFAULT ''")

    if pcols and "features" not in pcols:
        con.execute("ALTER TABLE plans ADD COLUMN features TEXT DEFAULT ''")
        # seed sensible defaults so an upgraded install is not left with
        # every tier granting nothing
        con.execute("UPDATE plans SET features='' WHERE slug='free'")
        con.execute("UPDATE plans SET features=? WHERE slug='plus'",
                    ("gallery,catalog,booking,stats,reply,qa,inquiry,social,featured",))
        con.execute("UPDATE plans SET features='*' WHERE slug='pro'")

    ccols = {r["name"] for r in con.execute("PRAGMA table_info(categories)")}
    if ccols and "parent" not in ccols:
        con.execute("ALTER TABLE categories ADD COLUMN parent TEXT DEFAULT ''")
    con.execute("CREATE INDEX IF NOT EXISTS idx_cat_parent ON categories(parent)")

    # the shop's own banner image, shown behind its page header
    bcols2 = {r["name"] for r in con.execute("PRAGMA table_info(businesses)")}
    if "cover" not in bcols2:
        con.execute("ALTER TABLE businesses ADD COLUMN cover TEXT DEFAULT ''")
    if "published_once" not in bcols2:
        # v209: lets the owner re-show a shop they hid themselves, while a
        # never-approved (withdrawn) one still has to go through moderation.
        con.execute("ALTER TABLE businesses ADD COLUMN published_once INTEGER DEFAULT 0")
        con.execute("UPDATE businesses SET published_once=1 WHERE status='published'")
    if "area" not in bcols2:
        con.execute("ALTER TABLE businesses ADD COLUMN area TEXT DEFAULT ''")
    if "city" not in bcols2:
        con.execute("ALTER TABLE businesses ADD COLUMN city TEXT DEFAULT ''")
    if "province" not in bcols2:
        con.execute("ALTER TABLE businesses ADD COLUMN province TEXT DEFAULT ''")
    # v211: Iranian messengers on the business profile
    for _mcol in MESSENGER_KEYS:
        if _mcol not in bcols2:
            con.execute(f"ALTER TABLE businesses ADD COLUMN {_mcol} TEXT DEFAULT ''")

    # review photo (v28) + helpful votes (v32)
    rcols = {r["name"] for r in con.execute("PRAGMA table_info(reviews)")}
    if rcols and "image" not in rcols:
        con.execute("ALTER TABLE reviews ADD COLUMN image TEXT DEFAULT ''")
    if rcols and "helpful" not in rcols:
        con.execute("ALTER TABLE reviews ADD COLUMN helpful INTEGER DEFAULT 0")

    # story media kind (v37): image | video
    scols = {r["name"] for r in con.execute("PRAGMA table_info(stories)")}
    if scols and "kind" not in scols:
        con.execute("ALTER TABLE stories ADD COLUMN kind TEXT DEFAULT 'image'")
    # story duration in seconds (v101): lets the viewer play the full clip
    if scols and "duration" not in scols:
        con.execute("ALTER TABLE stories ADD COLUMN duration REAL DEFAULT 0")

    # customer moderation (v34)
    ccols = {r["name"] for r in con.execute("PRAGMA table_info(customers)")}
    if ccols and "status" not in ccols:
        con.execute("ALTER TABLE customers ADD COLUMN status TEXT DEFAULT 'active'")
    # v298: email login — customers can login with email like modern agent login
    if ccols and "email" not in ccols:
        con.execute("ALTER TABLE customers ADD COLUMN email TEXT DEFAULT ''")
    con.execute("CREATE INDEX IF NOT EXISTS idx_customers_email ON customers(email)")
    # owners email too
    ocols_email = {r["name"] for r in con.execute("PRAGMA table_info(owners)")}
    if ocols_email and "email" not in ocols_email:
        con.execute("ALTER TABLE owners ADD COLUMN email TEXT DEFAULT ''")
    con.execute("CREATE INDEX IF NOT EXISTS idx_owners_email ON owners(email)")

    # ---- favourites are a set, not a bag (v74). Older builds had no UNIQUE
    # constraint, so deduplicate once before creating the durable guard.
    con.execute("DELETE FROM favorites WHERE id NOT IN "
                "(SELECT MIN(id) FROM favorites GROUP BY customer_id,biz_id)")
    con.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_fav_customer_biz "
                "ON favorites(customer_id,biz_id)")

    # ---- messenger read cursors (v73). SCHEMA creates these for a fresh
    # database; guarded ALTERs upgrade every existing installation in place.
    chat_cols = {r["name"] for r in con.execute("PRAGMA table_info(chat_threads)")}
    for col in ("customer_read_to", "owner_read_to", "admin_read_to"):
        if chat_cols and col not in chat_cols:
            con.execute(f"ALTER TABLE chat_threads ADD COLUMN {col} INTEGER DEFAULT 0")

    # ---- order privacy + two-stage cancellation (v76)
    order_cols={r["name"] for r in con.execute("PRAGMA table_info(orders)")}
    for col,ddl in (("share_phone","INTEGER DEFAULT 0"),("cancel_requested","INTEGER DEFAULT 0"),
                    ("cancel_reason","TEXT DEFAULT ''"),("cancel_requested_at","TEXT DEFAULT ''"),
                    ("cancel_decided_at","TEXT DEFAULT ''")):
        if order_cols and col not in order_cols: con.execute(f"ALTER TABLE orders ADD COLUMN {col} {ddl}")

    # ---- booking-day reminders (v229)
    bk_cols = {r["name"] for r in con.execute("PRAGMA table_info(bookings)")}
    if bk_cols and "reminded" not in bk_cols:
        con.execute("ALTER TABLE bookings ADD COLUMN reminded TEXT DEFAULT ''")

    # ---- username + password login (v57): a returning user sets a
    # username/password after OTP so they can sign in without SMS next time.
    ocols = {r["name"] for r in con.execute("PRAGMA table_info(owners)")}
    if ocols and "username" not in ocols:
        con.execute("ALTER TABLE owners ADD COLUMN username TEXT DEFAULT ''")
    if ocols and "pass_hash" not in ocols:
        con.execute("ALTER TABLE owners ADD COLUMN pass_hash TEXT DEFAULT ''")
    cc2 = {r["name"] for r in con.execute("PRAGMA table_info(customers)")}
    if cc2 and "username" not in cc2:
        con.execute("ALTER TABLE customers ADD COLUMN username TEXT DEFAULT ''")
    if cc2 and "pass_hash" not in cc2:
        con.execute("ALTER TABLE customers ADD COLUMN pass_hash TEXT DEFAULT ''")
    con.execute("CREATE INDEX IF NOT EXISTS idx_owners_username ON owners(username)")
    con.execute("CREATE INDEX IF NOT EXISTS idx_customers_username ON customers(username)")

    # ---- privacy (v65): a family/last name alongside the first name.
    # The first name is REQUIRED (site-wide), the last name is optional.
    if ocols and "family" not in ocols:
        con.execute("ALTER TABLE owners ADD COLUMN family TEXT DEFAULT ''")
    if cc2 and "family" not in cc2:
        con.execute("ALTER TABLE customers ADD COLUMN family TEXT DEFAULT ''")

    icols = {r["name"] for r in con.execute("PRAGMA table_info(items)")}
    for col, ddl in (("images", "TEXT DEFAULT '[]'"), ("old_price", "INTEGER DEFAULT 0"),
                     ("stock", "INTEGER DEFAULT -1"), ("code", "TEXT DEFAULT ''"),
                     ("min_order", "TEXT DEFAULT ''"), ("options", "TEXT DEFAULT ''"),
                     ("note", "TEXT DEFAULT ''"),
                     # ---- shop-window fields (Basalam / Torob / Digikala parity)
                     ("brand", "TEXT DEFAULT ''"),
                     ("warranty", "TEXT DEFAULT ''"),      # گارانتی / ضمانت
                     ("prep_days", "TEXT DEFAULT ''"),     # آماده‌سازی: «۲ روز کاری»
                     ("delivery", "TEXT DEFAULT ''"),      # ارسال: پیک، پست، حضوری
                     ("handmade", "INTEGER DEFAULT 0"),    # دست‌ساز — پرچم باسلام
                     ("returnable", "INTEGER DEFAULT 0"),  # مرجوعی — پرچم دیجی‌کالا
                     ("bulk_price", "TEXT DEFAULT ''"),    # قیمت عمده
                     ("video", "TEXT DEFAULT ''"),         # لینک ویدئوی کوتاه
                     ("spec", "TEXT DEFAULT ''"),          # مشخصات: «رنگ=قرمز؛ وزن=۲کیلو»
                     ("weight", "TEXT DEFAULT ''"),
                     # ---- چانه‌زنی: per-product, opt-in, with a private floor
                     ("haggle", "INTEGER DEFAULT 0"),      # آیا چانه‌زنی باز است
                     ("floor_price", "INTEGER DEFAULT 0"), # کف قیمت — فقط فروشنده
                     ("views", "INTEGER DEFAULT 0")):
        if col not in icols:
            con.execute(f"ALTER TABLE items ADD COLUMN {col} {ddl}")

    # ---- v114 one-time: zero every visit counter so that from this moment
    # only REAL, identity-backed visits (server/analytics.py) are counted.
    # User decision for v114: the demo/seeded numbers go; truth stays.
    if con.execute("SELECT 1 FROM settings WHERE key='analytics_reset_v114'"
                   ).fetchone() is None:
        con.execute("UPDATE businesses SET views=0")
        con.execute("UPDATE items SET views=0")
        con.execute("UPDATE ads SET views=0")
        con.execute("DELETE FROM story_views")
        con.execute("DELETE FROM events WHERE kind='view'")
        con.execute("INSERT OR REPLACE INTO settings(key,value) "
                    "VALUES('analytics_reset_v114','1')")

    # ---- v177: شمارش واقعیِ بازدید — یک بازدید به‌ازای هر بازدیدکننده در روز
    # (صفحهٔ دکان/کالا) و یک بازدید به‌ازای هر بازدیدکننده برای هر استوری.
    # شمارنده‌های قدیمیِ متورم حذف نمی‌شوند؛ به legacy_views بایگانی می‌شوند
    # (سطل تاریخچه) و شمارندهٔ نمایشی از صفرِ واقعی ادامه می‌دهد.
    bcols = {r[1] for r in con.execute("PRAGMA table_info(businesses)")}
    icols2 = {r[1] for r in con.execute("PRAGMA table_info(items)")}
    if "legacy_views" not in bcols:
        con.execute("ALTER TABLE businesses ADD COLUMN legacy_views INTEGER DEFAULT 0")
    if "legacy_views" not in icols2:
        con.execute("ALTER TABLE items ADD COLUMN legacy_views INTEGER DEFAULT 0")
    if con.execute("SELECT 1 FROM settings WHERE key='views_reset_v177'"
                   ).fetchone() is None:
        con.execute("UPDATE businesses SET legacy_views=views, views=0")
        con.execute("UPDATE items SET legacy_views=views, views=0")
        con.execute("INSERT OR REPLACE INTO settings(key,value) "
                    "VALUES('views_reset_v177','1')")
    # story_views به شکل یکتا (story_id, viewer) — جدول قدیمی بایگانی می‌شود.
    # ⚠️ ملاک فقط presence ستون viewer نیست: _reconcile_schema ممکن است ستون را
    # بدون قید UNIQUE اضافه کرده باشد؛ وجود ایندکس یکتا ملاک است.
    uq = [r for r in con.execute("PRAGMA index_list(story_views)") if r[2]]
    if not uq:
        con.execute("DROP TABLE IF EXISTS story_views_legacy")
        con.execute("ALTER TABLE story_views RENAME TO story_views_legacy")
        con.execute("""CREATE TABLE story_views (
                         id       INTEGER PRIMARY KEY AUTOINCREMENT,
                         story_id INTEGER NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
                         viewer   TEXT NOT NULL DEFAULT '',
                         ts       REAL NOT NULL,
                         UNIQUE(story_id, viewer))""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_sview_story ON story_views(story_id, ts)")
    # دکمهٔ یکتاسازی روزانهٔ صفحات: biz/item × بازدیدکننده × روز
    con.execute("""CREATE TABLE IF NOT EXISTS page_viewers (
                     entity TEXT NOT NULL,
                     eid    INTEGER NOT NULL,
                     viewer TEXT NOT NULL,
                     day    TEXT NOT NULL,
                     ts     REAL NOT NULL,
                     UNIQUE(entity, eid, viewer, day))""")
    con.execute("CREATE INDEX IF NOT EXISTS idx_pageview_ent ON page_viewers(entity, eid, day)")

    # ---- v115: city + campaign columns on visits (offline GeoIP + UTM)
    vcols = {r["name"] for r in con.execute("PRAGMA table_info(visits)")}
    for col, ddl in (("prov", "TEXT NOT NULL DEFAULT ''"),
                     ("city", "TEXT NOT NULL DEFAULT ''"),
                     ("utm", "TEXT NOT NULL DEFAULT ''")):
        if col not in vcols:
            con.execute(f"ALTER TABLE visits ADD COLUMN {col} {ddl}")
    # ---- v117/فاز۶: retention moved to retention_purge() — boot AND hourly.
    retention_purge(con=con)

    for slug, (title, body) in DEFAULT_PAGES.items():
        con.execute("INSERT OR IGNORE INTO pages(slug,title,body) VALUES(?,?,?)",
                    (slug, title, body))

    # v285: اگر متن «قوانین» هنوز همان پیش‌فرض قدیمی چهار بندی است (ادمین آن
    # را ویرایش نکرده)، با متن کامل قانونی جایگزین می‌شود؛ ویرایش ادمین محترم است.
    try:
        _r = con.execute("SELECT title, body FROM pages WHERE slug='rules'").fetchone()
        if _r and (_r["body"] or "").strip() == _RULES_V1.strip():
            con.execute("UPDATE pages SET title=?, body=? WHERE slug='rules'",
                        ("قوانین و مقررات", _RULES_BODY_V285))
    except sqlite3.OperationalError:
        pass

    # ---- seed all Iranian provinces & cities (idempotent)
    if con.execute("SELECT COUNT(*) c FROM cities").fetchone()["c"] == 0:
        try:
            import sys as _s
            _s.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tools"))
            from cities import PROVINCES, CITIES
            for province, capital in PROVINCES:
                for cname in CITIES.get(province, [capital]):
                    con.execute("INSERT OR IGNORE INTO cities(province,name,is_capital) "
                                "VALUES(?,?,?)", (province, cname, 1 if cname == capital else 0))
        except Exception:
            pass

    # ---- v3 seeds: badges and plans (idempotent, admin can edit/delete)
    # v156: بدون گاردِ «فبار اول» — نشان تازهٔ اضافه‌شده به نصب‌های موجود هم
    # می‌رسد (ON CONFLICT DO NOTHING؛ ویرایش‌های مدیر دست‌نخورده می‌ماند).
    for i, (slug, name, ic, color, descr) in enumerate(DEFAULT_BADGES):
        con.execute("INSERT INTO badges(slug,name,icon,color,descr,sort) "
                    "VALUES(?,?,?,?,?,?) ON CONFLICT(slug) DO NOTHING",
                    (slug, name, ic, color, descr, i))
    if con.execute("SELECT COUNT(*) c FROM plans").fetchone()["c"] == 0:
        for i, (slug, name, price, months, fs, mi, mp, perks, badge, tag, feats) in enumerate(DEFAULT_PLANS):
            con.execute(
                "INSERT INTO plans(slug,name,tagline,price,months,featured_slots,max_items,"
                "max_photos,perks,badge_slug,features,sort) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (slug, name, tag, price, months, fs, mi, mp, perks, badge, feats, i))

    # ---- audit F-015 (gen-2, phase 4): hot paths on growing tables were full
    # table scans — proven with EXPLAIN on a 30k-order / 200k-notification DB:
    # every customer page navigation counted its unread notifications by
    # scanning ALL rows (8.7ms @200k), orders/story/follow lookups likewise.
    # These cover exactly the WHERE clauses the code issues; IF NOT EXISTS
    # makes the migration idempotent on existing databases.
    for stmt in (
        "CREATE INDEX IF NOT EXISTS idx_order_biz ON orders(biz_id)",
        "CREATE INDEX IF NOT EXISTS idx_order_customer ON orders(customer_id)",
        "CREATE INDEX IF NOT EXISTS idx_order_item_order ON order_items(order_id)",
        "CREATE INDEX IF NOT EXISTS idx_notif_customer ON notifications(customer_id, read)",
        "CREATE INDEX IF NOT EXISTS idx_follow_customer_biz ON follows(customer_id, biz_id)",
        "CREATE INDEX IF NOT EXISTS idx_follow_biz ON follows(biz_id)",
        "CREATE INDEX IF NOT EXISTS idx_story_biz ON stories(biz_id)",
        # v184: live panel pills/dashboard filter directly by these statuses.
        # Existing installations receive covering lookup indexes at boot.
        # status-first composite also serves status-only counts without making
        # per-business rating subqueries scan every review of that status.
        "CREATE INDEX IF NOT EXISTS idx_rev_status_biz ON reviews(status, biz_id)",
        "CREATE INDEX IF NOT EXISTS idx_book_status ON bookings(status)",
        "CREATE INDEX IF NOT EXISTS idx_book_customer ON bookings(customer_id, id)",
        "CREATE INDEX IF NOT EXISTS idx_msg_status ON messages(status)",
        "CREATE INDEX IF NOT EXISTS idx_question_status ON questions(status)",
        "CREATE INDEX IF NOT EXISTS idx_claim_status ON claims(status)",
        "CREATE INDEX IF NOT EXISTS idx_sub_status ON subscriptions(status)",
        "CREATE INDEX IF NOT EXISTS idx_cat_active ON categories(active)",
    ):
        try:
            con.execute(stmt)
        except sqlite3.OperationalError:
            pass          # e.g. table not present in a half-migrated db

    con.commit()
    con.close()
    expire_subscriptions()
    if _fts_ensure():
        # Seed the index once per start so search is accurate even before the
        # first write. Cheap for a directory-sized table.
        try:
            _fts_rebuild()
        except Exception:
            pass
    _fts_sync_if_needed()
    maintenance()


def retention_purge(con=None):
    """v117/فاز۶: data-retention sweep — was boot-only, now hourly too.

    A phone server can stay up for months; privacy promises (IPs blanked
    after 90 days, history dropped after 2 years) must not depend on a
    restart. Idempotent, indexed on ts/created."""
    own = con is None
    con = con or connect()
    try:
        con.execute("UPDATE visits SET ip='', prov='', city='' "
                    "WHERE ip != '' AND ts < ?", (time.time() - 90 * 86400,))
        con.execute("DELETE FROM visits WHERE ts < ?",
                    (time.time() - 730 * 86400,))
        con.execute("DELETE FROM audit WHERE created < datetime('now','-730 days')")
        con.execute("DELETE FROM searches WHERE created < datetime('now','-730 days')")
        if own:
            con.commit()
    finally:
        if own:
            con.close()


def customer_export_csv(cid):
    """v117/فاز۶: a customer's own data, portable (data-portability right).

    Only rows attributable by customer_id are included — guest-era rows
    keyed by phone/name (e.g. old reviews) are honestly omitted."""
    import csv as _csv
    import io as _io
    buf = _io.StringIO()
    buf.write("\ufeff")            # Excel opens the Persian text correctly
    w = _csv.writer(buf)
    w.writerow(["بخش", "مورد", "جزئیات", "زمان"])
    me = _one("SELECT * FROM customers WHERE id=?", (cid,))
    if me:
        w.writerow(["پروفایل", "نام", me["name"], ""])
        w.writerow(["پروفایل", "شمارهٔ موبایل", me["phone"], ""])
        w.writerow(["پروفایل", "نام کاربری", me["username"] or "", ""])
        w.writerow(["پروفایل", "تاریخ عضویت", me["created"], ""])
    for r in _rows(
            "SELECT o.id, o.total, o.status, o.created, o.name, o.phone, "
            "o.address, o.note, b.name biz FROM orders o "
            "LEFT JOIN businesses b ON b.id=o.biz_id "
            "WHERE o.customer_id=? ORDER BY o.id", (cid,)):
        parts = [p for p in (r["biz"] or "", r["name"] or "",
                             r["phone"] or "", r["address"] or "",
                             r["note"] or "") if p]
        w.writerow(["سفارش", f"#{r['id']}",
                    " — ".join(parts) + f" — {r['total'] or 0} تومان — {r['status']}",
                    r["created"]])
    for r in _rows(
            "SELECT b.name, f.id FROM favorites f JOIN businesses b "
            "ON b.id=f.biz_id WHERE f.customer_id=? ORDER BY f.id", (cid,)):
        w.writerow(["علاقه‌مندی", r["name"], "", ""])
    for r in _rows(
            "SELECT b.name, f.created FROM follows f JOIN businesses b "
            "ON b.id=f.biz_id WHERE f.customer_id=? ORDER BY f.id", (cid,)):
        w.writerow(["دنبال‌شده", r["name"], "", r["created"]])
    for r in _rows(
            "SELECT group_key, title, created FROM price_alerts "
            "WHERE customer_id=? ORDER BY created", (cid,)):
        w.writerow(["هشدار قیمت", r["title"], r["group_key"], r["created"]])
    for r in _rows(
            "SELECT id, biz_id, subject, status, created FROM chat_threads "
            "WHERE customer_id=? ORDER BY id", (cid,)):
        w.writerow(["گفت‌وگو", f"#{r['id']}",
                    f"کسب‌وکار {r['biz_id']} — {r['subject'] or ''} — {r['status']}",
                    r["created"]])
    for r in _rows(
            "SELECT kind, text, link, read, created FROM notifications "
            "WHERE customer_id=? ORDER BY id DESC LIMIT 500", (cid,)):
        w.writerow(["اعلان", r["kind"], r["text"],
                    f"{r['created']}{' — خوانده‌شده' if r['read'] else ''}"])
    try:   # v221: assistant transcripts (48h TTL; wiped with the account)
        for r in _rows(
                "SELECT role, text, created FROM ai_threads "
                "WHERE tkey=? ORDER BY id", (f"cust:{cid}",)):
            when = datetime.datetime.fromtimestamp(
                int(r["created"] or 0)).strftime("%Y-%m-%d %H:%M")
            w.writerow(["دستیار هوشمند",
                        "شما" if r["role"] == "user" else "دستیار",
                        r["text"], when])
    except Exception:
        pass
    return buf.getvalue()


def maintenance():
    """Opportunistic housekeeping on every server start: prune expired OTPs,
    expired sessions (owner + admin) and rate-limit buckets idle over a week.
    Cheap, idempotent, and keeps the temporary tables from growing forever."""
    now = time.time()
    con = connect()
    try:
        con.execute("DELETE FROM otp WHERE expires < ?", (now,))
        con.execute("DELETE FROM sessions WHERE expires < ?", (now,))
        con.execute("DELETE FROM admin_sessions WHERE expires < ?", (now,))
        con.execute("DELETE FROM ratelimit WHERE window < ?", (now - 7 * 86400,))
        # v277: verify-lock counters + enumeration-diversity rows are transient
        con.execute("DELETE FROM login_fails WHERE updated < ?", (now - 7 * 86400,))
        con.execute("DELETE FROM spam_divers WHERE ts < ?", (now - 86400,))
        # v221: expired assistant transcripts + cache rows (also pruned on write).
        try:
            con.execute("DELETE FROM ai_threads WHERE created < ?", (now - 48 * 3600,))
            con.execute("DELETE FROM ai_cache WHERE expires < ?", (now,))
        except Exception:
            pass
        con.commit()
    finally:
        con.close()


# ------------------------------------------------------------------ settings
def get_settings():
    con = connect()
    rows = con.execute("SELECT key,value FROM settings").fetchall()
    con.close()
    settings = {r["key"]: r["value"] for r in rows}
    # v251: نام سایت به انتخاب مدیر است (پیش‌فرض برند فقط در دیتابیس تازه).
    return settings


def page_fingerprint():
    """v117/کارایی: اثرانگشت ارزانِ محتوای عمومی — یک SELECT.

    کشِ صفحات مهمان به این مقدار گره خورده؛ هر تغییر محتوا (از هر
    فرایندی: POST پنل، تست، CLI) اثرانگشت را عوض می‌کند و کلید کش
    تازه می‌سازد. ستون‌هایی که هر بازدید عوض می‌شوند (businesses.views،
    items.views، visits، …) عمداً بیرون‌اند تا کش گرم بماند.
    """
    con = connect()
    row = con.execute(
        "SELECT "
        "(SELECT group_concat(k, '=') FROM "
        "  (SELECT key || '.' || value k FROM settings ORDER BY key)) || '|' || "
        "(SELECT group_concat(b, '~') FROM "
        "  (SELECT id || '.' || status || '.' || COALESCE(featured, 0) || '.' || "
        "     COALESCE(hours, '') || '.' || COALESCE(phone, '') b "
        "   FROM businesses ORDER BY id)) || '|' || "
        "(SELECT COUNT(*) || '.' || COALESCE(MAX(rowid), 0) || '.' || "
        "   COALESCE(SUM(length(COALESCE(title, ''))), 0) FROM items) || '|' || "
        "(SELECT COUNT(*) || '.' || COALESCE(MAX(rowid), 0) || '.' || "
        "   COALESCE(SUM(status = 'approved'), 0) || '.' || "
        "   COALESCE(SUM(status = 'pending'), 0) FROM reviews) || '|' || "
        "(SELECT COUNT(*) || '.' || COALESCE(MAX(rowid), 0) FROM toplists) || '|' || "
        "(SELECT COUNT(*) || '.' || COALESCE(MAX(rowid), 0) FROM flashdeals) || '|' || "
        "(SELECT COUNT(*) || '.' || COALESCE(MAX(rowid), 0) FROM posts) || '|' || "
        "(SELECT COUNT(*) || '.' || COALESCE(MAX(rowid), 0) FROM stories) || '|' || "
        "(SELECT group_concat(p, '~') FROM "
        "  (SELECT id || '.' || name || '.' || price || '.' || months || '.' || "
        "     active || '.' || COALESCE(features, '') p FROM plans ORDER BY id))"
    ).fetchone()
    con.close()
    return hashlib.md5((row[0] or "").encode("utf-8", "replace")).hexdigest()[:10]


def _pagecache_drop():
    """v117/کارایی: کشِ صفحات عمومی را باطل می‌کند (تنها یک import دیرهنگام
    تا حلقهٔ import نشود). ست‌کننده‌های محتوایی آن را صدا می‌زنند تا
    نوشتنِ بیرون از POST (تست/CLI) هم فوراً دیده شود."""
    try:
        import pagecache
        pagecache.clear()
    except Exception:
        pass


def set_setting(key, value):
    access_cache_clear()
    _pagecache_drop()
    con = connect()
    con.execute(
        "INSERT INTO settings(key,value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))
    con.commit()
    con.close()


def set_settings(d):
    access_cache_clear()
    _pagecache_drop()
    con = connect()
    for k, v in d.items():
        con.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v)))
    con.commit()
    con.close()


def owner_token():
    return get_settings().get("owner_token", "")


def rotate_owner_token():
    t = secrets.token_urlsafe(16)
    set_setting("owner_token", t)
    # v117/M1: a rotated key must immediately end every panel session —
    # otherwise an old cookie keeps the panel open past the rotation.
    con = connect()
    con.execute("DELETE FROM admin_sessions")
    con.commit()
    con.close()
    return t


# ----------------------------------------------------------------- admin auth
# The panel was reachable by token-in-URL alone, which leaks through browser
# history, screenshots and server logs. Adding an optional password means the
# URL token identifies the admin while the password (stored only as a salted
# PBKDF2 hash) is what actually unlocks the panel.
PBKDF2_ITERS = 600_000      # v117/F-010: OWASP 2023 floor for PBKDF2-SHA256
ADMIN_SESSION_TTL = 60 * 60 * 24 * 7         # v117/M1: 7-day admin session (was 30)


def _hash_password(pw, salt_hex):
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"),
                             bytes.fromhex(salt_hex), PBKDF2_ITERS)
    return f"pbkdf2${PBKDF2_ITERS}${salt_hex}${dk.hex()}"


def set_owner_pass(pw):
    """Set (or clear, when empty) the panel password."""
    if not pw:
        set_setting("owner_pass_hash", "")
        return
    set_setting("owner_pass_hash", _hash_password(pw, secrets.token_hex(8)))


def owner_pass_set():
    return bool((get_settings().get("owner_pass_hash") or "").strip())


def check_owner_pass(pw):
    stored = (get_settings().get("owner_pass_hash") or "").strip()
    if not stored or not pw:
        return False
    try:
        _algo, iters, salt, hx = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"),
                                 bytes.fromhex(salt), int(iters))
        if not secrets.compare_digest(dk.hex(), hx):
            return False
        # v117/F-010: transparent upgrade — a hash from the cheaper era is
        # re-hashed at today's cost the first time its owner logs in.
        if int(iters) < PBKDF2_ITERS:
            set_setting("owner_pass_hash",
                        _hash_password(pw, salt))
        return True
    except (ValueError, TypeError):
        return False


# ==========================================================================
#  USERNAME + PASSWORD login (v57)  —  the SMS-saving alternative
#
#  A returning owner/customer signs in with phone+OTP once, sets a username
#  and password, and thereafter signs in with those — no SMS cost. Passwords
#  are PBKDF2-salted (same 120k iterations as the panel), compared in
#  constant time, and every password attempt is rate-limited at the route.
# ==========================================================================

def hash_password(pw):
    """Salted PBKDF2-SHA256 hash: "pbkdf2$iters$salt$hex". Generic — used for
    owner and customer credentials alike."""
    return _hash_password(pw, secrets.token_hex(8))


def verify_password(pw, stored):
    """Constant-time check of a hash produced by hash_password()."""
    if not stored or not pw:
        return False
    try:
        _algo, iters, salt, hx = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"),
                                 bytes.fromhex(salt), int(iters))
        return secrets.compare_digest(dk.hex(), hx)
    except (ValueError, TypeError):
        return False


# Username: 3–24 chars, Persian/Latin letters, digits, underscore, dot or
# hyphen. No spaces — a username must be typeable and unambiguous.
_USERNAME_RE = re.compile(r"^[\u0600-\u06FF\u0621-\u064Aa-zA-Z0-9._-]{3,24}$")


def valid_username(u):
    u = (u or "").strip()
    return bool(_USERNAME_RE.match(u)) and " " not in u


def _username_taken(table, username, exclude_id=None):
    con = connect()
    q = f"SELECT 1 FROM {table} WHERE username=? AND username<>''"
    p = [username]
    if exclude_id:
        q += " AND id<>?"
        p.append(exclude_id)
    r = con.execute(q, p).fetchone()
    con.close()
    return bool(r)


def owner_set_credentials(owner_id, username, password):
    """(ok: bool, msg: str). Sets or updates an owner's username+password."""
    username = (username or "").strip()
    if not valid_username(username):
        return False, "نام کاربری باید ۳ تا ۲۴ نویسه (حروف، عدد، _ . -) و بدون فاصله باشد."
    if _username_taken("owners", username, owner_id):
        return False, "این نام کاربری قبلاً گرفته شده است."
    if not password or len(password) < 6:
        return False, "رمز عبور باید دست‌کم ۶ نویسه باشد."
    con = connect()
    con.execute("UPDATE owners SET username=?, pass_hash=? WHERE id=?",
                (username, hash_password(password), owner_id))
    con.commit()
    con.close()
    return True, "نام کاربری و رمز عبور ذخیره شد."


def owner_by_username(username):
    username = (username or "").strip()
    if not username:
        return None
    con = connect()
    r = con.execute("SELECT * FROM owners WHERE username=? AND username<>''",
                    (username,)).fetchone()
    con.close()
    return dict(r) if r else None


def owner_has_password(owner_id):
    con = connect()
    r = con.execute("SELECT pass_hash FROM owners WHERE id=?",
                    (owner_id,)).fetchone()
    con.close()
    return bool(r and (r["pass_hash"] or "").strip())


def owner_check_password(owner_id, password):
    con = connect()
    r = con.execute("SELECT pass_hash FROM owners WHERE id=?",
                    (owner_id,)).fetchone()
    con.close()
    return verify_password(password, r["pass_hash"] if r else "")


def admin_session_new(locked=False):
    """Mint an admin session. locked=True marks a session that only proves
    the URL key — when a panel password is set, such a session shows the
    password gate until a successful login replaces it (v117/M1: the key
    alone must never satisfy the second factor)."""
    tok = secrets.token_urlsafe(24)
    con = connect()
    con.execute("DELETE FROM admin_sessions WHERE expires < ?", (time.time(),))
    con.execute("INSERT INTO admin_sessions(token,expires,locked) VALUES(?,?,?)",
                (tok, time.time() + ADMIN_SESSION_TTL, 1 if locked else 0))
    con.commit()
    con.close()
    return tok


def admin_session_ok(token, unlocked_only=False):
    if not token:
        return False
    con = connect()
    sql = "SELECT locked FROM admin_sessions WHERE token=? AND expires > ?"
    r = con.execute(sql, (token, time.time())).fetchone()
    con.close()
    if not r:
        return False
    if unlocked_only and (r["locked"] or 0):
        return False
    return True


def admin_session_kill(token):
    if not token:
        return
    con = connect()
    con.execute("DELETE FROM admin_sessions WHERE token=?", (token,))
    con.commit()
    con.close()


def admin_session_unlock(token):
    """v293: unlock a locked (pending-approval) admin session once the Bale
    bot confirms the login. No-op when the session does not exist."""
    if not token:
        return
    con = connect()
    con.execute("UPDATE admin_sessions SET locked=0 WHERE token=? AND expires>?",
                (token, time.time()))
    con.commit()
    con.close()


# ------------------------------------------------- v293 panel login approval
def panel_approval_new(sess_token, ip=""):
    """Create a one-time 6-digit approval challenge bound to one (locked)
    admin session. Returns the code to be sent to the owner's Bale bot."""
    code = "%06d" % secrets.randbelow(1_000_000)
    h = hashlib.sha256(sess_token.encode("utf-8")).hexdigest()[:32]
    con = connect()
    con.execute("DELETE FROM panel_approvals WHERE expires < ?", (time.time(),))
    con.execute("DELETE FROM panel_approvals WHERE sess_hash=?", (h,))
    con.execute("INSERT INTO panel_approvals(code,sess_hash,ip,expires) "
                "VALUES(?,?,?,?)",
                (code, h, (ip or "")[:45], time.time() + 300))
    con.commit()
    con.close()
    return code


def panel_approval_status(sess_token):
    """pending | approved | rejected | None(expired/absent)."""
    if not sess_token:
        return None
    h = hashlib.sha256(sess_token.encode("utf-8")).hexdigest()[:32]
    con = connect()
    r = con.execute("SELECT status FROM panel_approvals "
                    "WHERE sess_hash=? AND expires>?",
                    (h, time.time())).fetchone()
    con.close()
    return r["status"] if r else None


def panel_approval_decide(code, approve):
    """The bot decides. Returns True only when a live pending challenge with
    this exact code existed (no fake 'decided' for stale/wrong codes)."""
    c = str(code or "")
    if not re.fullmatch(r"\d{6}", c):
        return False
    con = connect()
    r = con.execute("SELECT sess_hash FROM panel_approvals "
                    "WHERE code=? AND status='pending' AND expires>?",
                    (c, time.time())).fetchone()
    if not r:
        con.close()
        return False
    con.execute("UPDATE panel_approvals SET status=? WHERE sess_hash=?",
                ("approved" if approve else "rejected", r["sess_hash"]))
    con.commit()
    con.close()
    return True


# ------------------------------------------------- v300 agent panel keys — private, only via Bale bot
def agent_key_new(ip="", ttl=3600):
    """Create one-time agent panel key. Returns (token, expires_ts). Token is shown only once via Bale bot."""
    token = secrets.token_urlsafe(32)  # 43 chars
    h = hashlib.sha256(token.encode()).hexdigest()
    now = time.time()
    con = connect()
    con.execute("DELETE FROM agent_keys WHERE expires < ?", (now,))
    # keep only last 5 keys to avoid spam
    con.execute("INSERT INTO agent_keys(token_hash, token, expires, created, ip) VALUES(?,?,?,?,?)",
                (h, token[:8]+"...", now+ttl, now, (ip or "")[:45]))
    con.commit()
    con.close()
    return token, now+ttl

def agent_key_check(token):
    """Check if token is valid (not expired). Does NOT consume. Returns bool."""
    if not token or len(token) < 20:
        return False
    h = hashlib.sha256(token.encode()).hexdigest()
    con = connect()
    r = con.execute("SELECT expires FROM agent_keys WHERE token_hash=? AND expires>?", (h, time.time())).fetchone()
    con.close()
    return bool(r)

def agent_key_consume(token, ip=""):
    """Consume token (mark used) after successful login. Returns bool."""
    if not token:
        return False
    h = hashlib.sha256(token.encode()).hexdigest()
    con = connect()
    r = con.execute("SELECT expires FROM agent_keys WHERE token_hash=? AND expires>?", (h, time.time())).fetchone()
    if not r:
        con.close()
        return False
    con.execute("UPDATE agent_keys SET used=1, ip=? WHERE token_hash=?", ((ip or "")[:45], h))
    con.commit()
    con.close()
    return True

def agent_key_list(limit=10):
    con = connect()
    rows = con.execute("SELECT token, expires, created, used, ip FROM agent_keys ORDER BY created DESC LIMIT ?", (limit,)).fetchall()
    con.close()
    return [dict(r) for r in rows]

# v300 agent batch queue
def agent_batch_add(tool, args):
    con = connect()
    now = time.time()
    try:
        report = ""
        snap = ""
        try:
            try:
                import server.adminbot_content as CT
            except ImportError:
                import adminbot_content as CT
            report = CT.tool_report(tool, args)[:4000]
            snap_obj = CT.tool_snapshot(tool, args)
            import json as _js
            snap = _js.dumps(snap_obj, ensure_ascii=False)[:8000] if snap_obj else ""
        except Exception:
            pass
        cur = con.execute("INSERT INTO agent_batches(tool,args,report,snapshot,status,created) VALUES(?,?,?,?,?,?)",
                          (tool, json.dumps(args, ensure_ascii=False), report, snap, "staged", now))
        bid = cur.lastrowid
        con.commit()
        con.close()
        return bid
    except Exception:
        con.close()
        return 0

def agent_batch_list(status=None):
    con = connect()
    if status:
        rows = con.execute("SELECT * FROM agent_batches WHERE status=? ORDER BY id DESC", (status,)).fetchall()
    else:
        rows = con.execute("SELECT * FROM agent_batches ORDER BY id DESC LIMIT 100").fetchall()
    con.close()
    return [dict(r) for r in rows]

def agent_batch_get(bid):
    con = connect()
    r = con.execute("SELECT * FROM agent_batches WHERE id=?", (bid,)).fetchone()
    con.close()
    return dict(r) if r else None

def agent_batch_remove(bid):
    con = connect()
    con.execute("DELETE FROM agent_batches WHERE id=? AND status='staged'", (bid,))
    con.commit()
    con.close()

def agent_batch_clear():
    con = connect()
    con.execute("DELETE FROM agent_batches WHERE status='staged'")
    con.commit()
    con.close()

def agent_batch_apply_all(client_ip=""):
    """Apply all staged batches in order. Returns list of {id, tool, ok, msg}."""
    rows = agent_batch_list(status="staged")
    rows = sorted(rows, key=lambda x: x["id"])
    results = []
    for r in rows:
        try:
            try:
                import server.adminbot_content as CT
            except ImportError:
                import adminbot_content as CT
            import json as _js
            args = _js.loads(r["args"]) if r["args"] else {}
            exec_res = CT.tool_execute(r["tool"], args)
            # tool_execute returns (ok, msg) or dict
            if isinstance(exec_res, tuple) and len(exec_res) == 2:
                ok, msg = exec_res
            elif isinstance(exec_res, dict):
                ok = exec_res.get("ok", True)
                msg = exec_res.get("message") or exec_res.get("msg") or str(exec_res)[:300]
            else:
                ok = bool(exec_res)
                msg = str(exec_res)[:300]
            con = connect()
            if ok:
                con.execute("UPDATE agent_batches SET status='applied', applied_at=? WHERE id=?", (time.time(), r["id"]))
            else:
                con.execute("UPDATE agent_batches SET status='failed' WHERE id=?", (r["id"],))
            con.commit()
            con.close()
            results.append({"id": r["id"], "tool": r["tool"], "ok": bool(ok), "msg": str(msg)[:500]})
        except Exception as e:
            results.append({"id": r["id"], "tool": r["tool"], "ok": False, "msg": str(e)[:500]})
            try:
                con = connect()
                con.execute("UPDATE agent_batches SET status='failed' WHERE id=?", (r["id"],))
                con.commit()
                con.close()
            except Exception:
                pass
    try:
        log("agent.apply_all", f"ip={client_ip} count={len(results)} ok={sum(1 for x in results if x['ok'])}")
    except Exception:
        pass
    return results


# ---------------------------------------------------------- v185 Bale auth
def messenger_update_claim(platform, update_id):
    """Atomically claim one webhook update; False means malformed or replay."""
    value = str(update_id) if update_id is not None else ""
    if not re.fullmatch(r"[A-Za-z0-9:_-]{1,128}", value):
        return False
    con = connect()
    con.execute("DELETE FROM messenger_updates WHERE received<?",
                (time.time() - 14 * 86400,))
    cur = con.execute("INSERT OR IGNORE INTO messenger_updates(platform,update_id,received) "
                      "VALUES(?,?,?)", (str(platform), value, time.time()))
    claimed = cur.rowcount == 1
    con.commit(); con.close()
    return claimed


def _secret_hash(value):
    return hashlib.sha256(str(value or "").encode("utf-8")).hexdigest()


def messenger_challenge_new(purpose="login", customer_id=None, ttl=120, platform="bale"):
    """Return public challenge values; persist hashes only."""
    cid = secrets.token_urlsafe(12)
    request_token = secrets.token_urlsafe(18)
    browser_token = secrets.token_urlsafe(24)
    now = time.time()
    con = connect()
    con.execute("DELETE FROM messenger_challenges WHERE expires < ? OR used_at IS NOT NULL",
                (now - 86400,))
    con.execute("INSERT INTO messenger_challenges"
                "(id,request_hash,browser_hash,purpose,platform,customer_id,expires) "
                "VALUES(?,?,?,?,?,?,?)",
                (cid, _secret_hash(request_token), _secret_hash(browser_token),
                 purpose, platform, customer_id, now + max(30, min(int(ttl), 300))))
    con.commit(); con.close()
    return {"id": cid, "request_token": request_token,
            "browser_token": browser_token, "expires": now + ttl}


def messenger_challenge_by_request(request_token):
    if not request_token:
        return None
    r = _one("SELECT * FROM messenger_challenges WHERE request_hash=? AND expires>? "
             "AND used_at IS NULL", (_secret_hash(request_token), time.time()))
    return dict(r) if r else None


# ---------------------------------------------------------------- v284
# Fallback login keys («روش دوم» when the messenger round-trip stalls).
# Security model:
#   · the key is 96-bit random, shown ONCE in the owning browser (issuance
#     requires the challenge's browser cookie), stored only as a hash;
#   · single use, 5-minute TTL, max 5 redeem tries, bound to ONE challenge;
#   · redeem needs a platform-verified own-contact share (contact.user_id
#     == sender, enforced by the webhook) — a typed/forwarded number fails;
#   · identity conflicts are refused both ways (messenger account linked to
#     another customer, or the phone already linked to another messenger id);
#   · blocked customers are refused; every redeem is audit-logged WITHOUT
#     the key and WITHOUT the full phone.
LOGIN_KEY_RE = None  # compiled in app/webhook layer


def messenger_login_key_new(challenge_id, platform="bale", ttl=300):
    """Issue (or re-issue) a one-time login key for a login challenge.
    Returns the raw key once; only its hash is stored."""
    key = secrets.token_urlsafe(12)
    now = time.time()
    con = connect()
    con.execute("UPDATE messenger_login_keys SET status='dead' "
                "WHERE challenge_id=? AND status IN ('issued','need_contact','contact_ready')",
                (challenge_id,))
    con.execute("DELETE FROM messenger_login_keys WHERE expires < ?", (now - 86400,))
    con.execute("INSERT INTO messenger_login_keys"
                "(key_hash,challenge_id,platform,status,created,expires) "
                "VALUES(?,?,?,?,?,?)",
                (_secret_hash(key), challenge_id, platform, "issued",
                 now, now + max(60, min(int(ttl), 300))))
    con.commit(); con.close()
    return key


def messenger_login_key_lookup(key):
    if not key:
        return None
    r = _one("SELECT * FROM messenger_login_keys WHERE key_hash=? AND expires>? "
             "AND status IN ('issued','need_contact','contact_ready')",
             (_secret_hash(key), time.time()))
    return dict(r) if r else None


def _login_key_fail(row, note):
    con = connect()
    con.execute("UPDATE messenger_login_keys SET tries=tries+1, "
                "status=CASE WHEN tries+1>=5 THEN 'dead' ELSE status END WHERE id=?",
                (row["id"],))
    con.commit(); con.close()
    return False, note


def _login_key_redeem(row, phone, platform, uid, chat_id):
    """Core redeem: verified contact + valid key -> approve the challenge."""
    if row["tries"] >= 5:
        return False, "این کلید غیرفعال شده است؛ از سایت کلید تازه بگیرید."
    phone = norm_phone(phone or "")
    if not valid_phone(phone):
        return _login_key_fail(row, "شمارهٔ تأییدشده معتبر نیست.")
    uid, chat_id = str(uid), str(chat_id)
    con = connect()
    # conflict A: this messenger identity already belongs to another customer
    mine = con.execute("SELECT customer_id FROM messenger_accounts "
                       "WHERE platform=? AND platform_user_id=? AND active=1",
                       (platform, uid)).fetchone()
    cust = customer_by_phone(phone, create=True)
    if not cust or cust.get("status") == "blocked":
        con.close()
        return _login_key_fail(row, "این حساب اجازهٔ ورود ندارد.")
    if mine and mine["customer_id"] != cust["id"]:
        con.close()
        return _login_key_fail(row, "این حساب پیام‌رسان به حساب دیگری متصل است؛ "
                                    "روش معمول ورود را انجام دهید.")
    # conflict B: the phone is already linked to a different messenger identity
    theirs = con.execute("SELECT platform_user_id FROM messenger_accounts "
                         "WHERE platform=? AND customer_id=? AND active=1",
                         (platform, cust["id"])).fetchone()
    if theirs and str(theirs["platform_user_id"]) != uid:
        con.close()
        return _login_key_fail(row, "این شماره قبلاً به حساب پیام‌رسان دیگری "
                                    "متصل شده است؛ با همان حساب وارد شوید.")
    ch = con.execute("SELECT * FROM messenger_challenges WHERE id=? AND purpose='login' "
                     "AND expires>? AND used_at IS NULL AND approved_at IS NULL",
                     (row["challenge_id"], time.time())).fetchone()
    if not ch:
        con.close()
        return _login_key_fail(row, "درخواست ورود منقضی شده؛ از سایت دوباره شروع کنید.")
    con.execute("UPDATE messenger_challenges SET approved_id=?, approved_at=? "
                "WHERE id=? AND approved_at IS NULL AND used_at IS NULL",
                (cust["id"], time.time(), ch["id"]))
    con.execute("INSERT INTO messenger_accounts"
                "(customer_id,platform,platform_user_id,chat_id,active) VALUES(?,?,?,?,1) "
                "ON CONFLICT(customer_id,platform) DO UPDATE SET "
                "platform_user_id=excluded.platform_user_id,chat_id=excluded.chat_id,active=1",
                (cust["id"], platform, uid, chat_id))
    con.execute("UPDATE messenger_login_keys SET status='done', done_at=?, phone=? "
                "WHERE id=? AND status!='done'", (time.time(), phone, row["id"]))
    con.commit(); con.close()
    log("messenger_login_key", f"redeem platform={platform} cust={cust['id']}")
    return True, "✅ ورود با شمارهٔ شما تأیید شد؛ به سایت برگردید."


def messenger_login_key_claim(key, platform, uid, chat_id):
    """Bot: the visitor pasted/sent the one-time key. Bind it to this chat;
    if a verified contact was stashed here already, redeem at once."""
    row = messenger_login_key_lookup(key)
    if not row or row["platform"] != platform:
        return False, "", False
    con = connect()
    con.execute("UPDATE messenger_login_keys SET chat_id=?, platform_user_id=?, "
                "status='need_contact' WHERE id=? AND status IN ('issued','need_contact')",
                (str(chat_id), str(uid), row["id"]))
    st = con.execute("SELECT * FROM messenger_login_keys WHERE chat_id=? AND platform=? "
                     "AND status='contact_ready' AND expires>?",
                     (str(chat_id), platform, time.time())).fetchone()
    con.commit(); con.close()
    row = messenger_login_key_lookup(key) or row
    if st:
        ok, note = _login_key_redeem(row, st["phone"], platform, uid, chat_id)
        return ok, note, False
    return True, ("🔑 کلید یک‌بارمصرف ثبت شد.\n"
                  "حالا دکمهٔ «ارسال شمارهٔ خودم» را بزنید تا ورود تأیید شود."), True


def messenger_login_key_redeem_contact(platform, uid, chat_id, phone):
    """Bot: verified own-contact arrived while a key waits in this chat.
    Returns None when no key is waiting (caller falls back to signup flow)."""
    row = _one("SELECT * FROM messenger_login_keys WHERE chat_id=? AND platform=? "
               "AND status='need_contact' AND expires>?",
               (str(chat_id), platform, time.time()))
    if not row:
        return None
    return _login_key_redeem(dict(row), phone, platform, uid, chat_id)


def messenger_login_key_stash_contact(platform, uid, chat_id, phone):
    """Bot: verified contact arrived BEFORE the key — remember it 5 minutes
    so the key (sent next) can redeem at once."""
    phone = norm_phone(phone or "")
    if not valid_phone(phone):
        return False
    now = time.time()
    con = connect()
    con.execute("UPDATE messenger_login_keys SET status='dead' "
                "WHERE chat_id=? AND platform=? AND status='contact_ready'",
                (str(chat_id), platform))
    con.execute("INSERT INTO messenger_login_keys"
                "(key_hash,challenge_id,platform,chat_id,platform_user_id,phone,"
                "status,created,expires) VALUES(?,?,?,?,?,?,?,?,?)",
                (_secret_hash(secrets.token_urlsafe(12)), "", platform,
                 str(chat_id), str(uid), phone, "contact_ready", now, now + 300))
    con.commit(); con.close()
    return True


def messenger_signup_bind(request_token, platform_user_id, chat_id, platform="bale"):
    """Bind an unlinked login challenge to the Bale user who opened it."""
    con = connect()
    cur = con.execute("UPDATE messenger_challenges SET platform_user_id=?,chat_id=? "
                      "WHERE request_hash=? AND purpose='login' AND platform=? AND expires>? "
                      "AND approved_at IS NULL AND used_at IS NULL",
                      (str(platform_user_id), str(chat_id), _secret_hash(request_token), platform, time.time()))
    con.commit(); con.close()
    return cur.rowcount == 1


def messenger_signup_prepare(platform_user_id, chat_id, phone, platform="bale"):
    """Accept only a Bale-verified own contact, then issue a separate approval."""
    phone = norm_phone(phone)
    if not valid_phone(phone):
        return False, "شمارهٔ تأییدشده معتبر نیست.", ""
    con = connect()
    ch = con.execute("SELECT * FROM messenger_challenges WHERE purpose='login' AND platform=? "
                     "AND platform_user_id=? AND chat_id=? AND expires>? "
                     "AND approved_at IS NULL AND used_at IS NULL "
                     "ORDER BY created DESC LIMIT 1",
                     (platform, str(platform_user_id), str(chat_id), time.time())).fetchone()
    con.close()
    if not ch:
        return False, "درخواست ثبت‌نام منقضی شده؛ دوباره از سایت آغاز کنید.", ""
    cust = customer_by_phone(phone, create=True)
    if not cust or cust.get("status") == "blocked":
        return False, "این حساب اجازهٔ ورود ندارد.", ""
    approval_token = secrets.token_urlsafe(18)
    con = connect()
    cur = con.execute("UPDATE messenger_challenges SET customer_id=?,approval_hash=? "
                      "WHERE id=? AND approved_at IS NULL AND used_at IS NULL AND expires>?",
                      (cust["id"], _secret_hash(approval_token), ch["id"], time.time()))
    con.commit(); con.close()
    if cur.rowcount != 1:
        return False, "درخواست ثبت‌نام منقضی شده؛ دوباره تلاش کنید.", ""
    return True, "شماره تأیید شد؛ اکنون ثبت‌نام و ورود را تأیید کنید.", approval_token


def messenger_signup_approve(approval_token, platform_user_id, chat_id, platform="bale"):
    """Atomically create the Bale mapping and approve after a separate click."""
    if not approval_token:
        return False, "درخواست نامعتبر است."
    con = connect(); con.execute("BEGIN IMMEDIATE")
    ch = con.execute("SELECT * FROM messenger_challenges WHERE approval_hash=? "
                     "AND platform_user_id=? AND chat_id=? AND purpose='login' AND platform=? "
                     "AND customer_id IS NOT NULL AND expires>? AND approved_at IS NULL "
                     "AND used_at IS NULL",
                     (_secret_hash(approval_token), str(platform_user_id), str(chat_id),
                      platform, time.time())).fetchone()
    if not ch:
        con.rollback(); con.close(); return False, "درخواست منقضی یا استفاده شده است."
    other = con.execute("SELECT customer_id FROM messenger_accounts "
                        "WHERE platform=? AND platform_user_id=?",
                        (platform, str(platform_user_id))).fetchone()
    if other and other["customer_id"] != ch["customer_id"]:
        con.rollback(); con.close(); return False, "این حساب پیام‌رسان قبلاً متصل شده است."
    con.execute("INSERT INTO messenger_accounts"
                "(customer_id,platform,platform_user_id,chat_id,active) VALUES(?,?,?,?,1) "
                "ON CONFLICT(customer_id,platform) DO UPDATE SET "
                "platform_user_id=excluded.platform_user_id,chat_id=excluded.chat_id,"
                "active=1,linked_at=datetime('now')",
                (ch["customer_id"], platform, str(platform_user_id), str(chat_id)))
    cur = con.execute("UPDATE messenger_challenges SET approved_id=customer_id,approved_at=?,"
                      "approval_hash=NULL WHERE id=? AND approved_at IS NULL AND used_at IS NULL",
                      (time.time(), ch["id"]))
    if cur.rowcount != 1:
        con.rollback(); con.close(); return False, "درخواست قبلاً پردازش شده است."
    con.commit(); con.close()
    return True, "ثبت‌نام و ورود تأیید شد؛ به سایت برگردید."


def messenger_account_by_platform(platform, platform_user_id):
    r = _one("SELECT m.*,c.status customer_status FROM messenger_accounts m "
             "JOIN customers c ON c.id=m.customer_id "
             "WHERE m.platform=? AND m.platform_user_id=? AND m.active=1",
             (platform, str(platform_user_id)))
    return dict(r) if r else None


def messenger_account_for_customer(customer_id, platform="bale"):
    r = _one("SELECT * FROM messenger_accounts WHERE customer_id=? AND platform=? AND active=1",
             (customer_id, platform))
    return dict(r) if r else None


def messenger_challenge_approve(request_token, platform_user_id, chat_id):
    """Atomically link/approve as the Bale identity that clicked callback."""
    if not request_token:
        return False, "درخواست منقضی یا استفاده شده است."
    con = connect()
    con.execute("BEGIN IMMEDIATE")
    ch = con.execute("SELECT * FROM messenger_challenges WHERE request_hash=? "
                     "AND expires>? AND used_at IS NULL AND approved_at IS NULL",
                     (_secret_hash(request_token), time.time())).fetchone()
    if not ch:
        con.rollback(); con.close()
        return False, "درخواست منقضی یا استفاده شده است."
    platform = ch["platform"] or "bale"
    if ch["purpose"] == "link":
        customer_id = ch["customer_id"]
        if not customer_id:
            con.rollback(); con.close(); return False, "حساب مقصد پیدا نشد."
        other = con.execute("SELECT customer_id FROM messenger_accounts "
                            "WHERE platform=? AND platform_user_id=?",
                            (platform, str(platform_user_id))).fetchone()
        if other and other["customer_id"] != customer_id:
            con.rollback(); con.close(); return False, "این حساب پیام‌رسان قبلاً متصل شده است."
        con.execute("INSERT INTO messenger_accounts"
                    "(customer_id,platform,platform_user_id,chat_id,active) VALUES(?,?,?,?,1) "
                    "ON CONFLICT(customer_id,platform) DO UPDATE SET "
                    "platform_user_id=excluded.platform_user_id,chat_id=excluded.chat_id,"
                    "active=1,linked_at=datetime('now')",
                    (customer_id, platform, str(platform_user_id), str(chat_id)))
    else:
        acc = con.execute("SELECT m.*,c.status customer_status FROM messenger_accounts m "
                          "JOIN customers c ON c.id=m.customer_id WHERE m.platform=? "
                          "AND m.platform_user_id=? AND m.active=1",
                          (platform, str(platform_user_id))).fetchone()
        if not acc or acc["customer_status"] == "blocked":
            con.rollback(); con.close()
            return False, "این حساب بله هنوز به دست گیر متصل نشده است."
        customer_id = acc["customer_id"]
        con.execute("UPDATE messenger_accounts SET chat_id=? WHERE id=?",
                    (str(chat_id), acc["id"]))
    cur = con.execute("UPDATE messenger_challenges SET approved_id=?,approved_at=? "
                      "WHERE id=? AND approved_at IS NULL AND used_at IS NULL",
                      (customer_id, time.time(), ch["id"]))
    if cur.rowcount != 1:
        con.rollback(); con.close()
        return False, "درخواست قبلاً پردازش شده است."
    con.commit(); con.close()
    return True, "تأیید شد؛ به سایت برگردید."


def messenger_challenge_cancel(request_token, approval=False):
    column = "approval_hash" if approval else "request_hash"
    _run(f"UPDATE messenger_challenges SET used_at=? WHERE {column}=? AND used_at IS NULL",
         (time.time(), _secret_hash(request_token)))


def messenger_challenge_status(cid, browser_token, consume=False):
    if not cid or not browser_token:
        return None
    con = connect()
    r = con.execute("SELECT * FROM messenger_challenges WHERE id=? AND browser_hash=?",
                    (cid, _secret_hash(browser_token))).fetchone()
    if not r or r["expires"] < time.time() or r["used_at"] is not None:
        con.close(); return None
    out = dict(r)
    if consume and r["approved_id"]:
        cur = con.execute("UPDATE messenger_challenges SET used_at=? "
                          "WHERE id=? AND used_at IS NULL AND expires>=?",
                          (time.time(), cid, time.time()))
        con.commit()
        if cur.rowcount != 1:
            con.close(); return None
    con.close()
    return out


def messenger_unlink(customer_id, platform="bale"):
    _run("DELETE FROM messenger_accounts WHERE customer_id=? AND platform=?",
         (customer_id, platform))


def messenger_chat_for(role, user_id, platform="bale"):
    if role == "cust":
        acc = messenger_account_for_customer(user_id, platform)
    else:
        r = _one("SELECT c.id FROM owners o JOIN customers c ON c.phone=o.phone WHERE o.id=?",
                 (user_id,))
        acc = messenger_account_for_customer(r["id"], platform) if r else None
    return acc.get("chat_id") if acc else ""


def bale_chat_for(role, user_id):
    return messenger_chat_for(role, user_id, "bale")


# ------------------------------------------------------------------ helpers
# Persian/Arabic -> Latin, so public URLs stay clean and SEO-friendly
_TRANS = {
    "ا":"a","آ":"a","أ":"a","إ":"e","ب":"b","پ":"p","ت":"t","ث":"s","ج":"j",
    "چ":"ch","ح":"h","خ":"kh","د":"d","ذ":"z","ر":"r","ز":"z","ژ":"zh","س":"s",
    "ش":"sh","ص":"s","ض":"z","ط":"t","ظ":"z","ع":"a","غ":"gh","ف":"f","ق":"gh",
    "ک":"k","ك":"k","گ":"g","ل":"l","م":"m","ن":"n","و":"v","ه":"h","ی":"y",
    "ي":"y","ة":"h","ؤ":"o","ئ":"y","ء":"","َ":"a","ِ":"e","ُ":"o","ّ":"","ْ":"",
    "ً":"","ٍ":"","ٌ":"","ـ":"",
    "۰":"0","۱":"1","۲":"2","۳":"3","۴":"4","۵":"5","۶":"6","۷":"7","۸":"8","۹":"9",
    "٠":"0","١":"1","٢":"2","٣":"3","٤":"4","٥":"5","٦":"6","٧":"7","٨":"8","٩":"9",
}


def translit(text):
    return "".join(_TRANS.get(ch, ch) for ch in (text or ""))


def slugify(text, fallback="item"):
    s = translit((text or "").strip().lower())
    s = re.sub(r"[\s_]+", "-", s)
    s = re.sub(r"[^a-z0-9\-]", "", s)
    s = re.sub(r"-{2,}", "-", s).strip("-")
    return s or fallback


def unique_slug(table, base):
    con = connect()
    slug, i = base, 2
    while con.execute(f"SELECT 1 FROM {table} WHERE slug=?", (slug,)).fetchone():
        slug = f"{base}-{i}"
        i += 1
    con.close()
    return slug


def system_status():
    """v119: وضعیت فنی برای داشبورد پنل — حجم DB، فعالیت امروز، سپر."""
    import time as _t
    con = connect()
    today = _t.strftime("%Y-%m-%d")
    try:
        audit_today = con.execute(
            "SELECT COUNT(*) FROM audit WHERE created LIKE ?", (today + "%",)
        ).fetchone()[0]
        db_size = os.path.getsize(DB_PATH) if os.path.exists(DB_PATH) else 0
    finally:
        con.close()
    return {"audit_today": audit_today, "db_size": db_size}


def log(action, detail=""):
    con = connect()
    con.execute("INSERT INTO audit(action,detail) VALUES(?,?)", (action, detail))
    con.commit()
    con.close()


# ------------------------------------------------------------------ categories
def categories(only_active=True, parent=None, top_only=False):
    """Categories with a live business count.

    `count`      businesses filed directly under this slug
    `total`      count plus everything in its children (what a parent shows)
    `children`   the child rows, already counted

    Pass parent="" for top level only, parent="food" for one branch's
    children, or top_only=True as a readable alias for the first.
    """
    con = connect()
    q = "SELECT * FROM categories"
    where, p = [], []
    if only_active:
        where.append("active=1")
    if top_only:
        parent = ""
    if parent is not None:
        where.append("COALESCE(parent,'')=?")
        p.append(parent)
    if where:
        q += " WHERE " + " AND ".join(where)
    q += " ORDER BY sort, id"
    rows = [dict(r) for r in con.execute(q, p)]

    counts = {r["cat_slug"]: r["c"] for r in con.execute(
        "SELECT cat_slug, COUNT(*) c FROM businesses "
        "WHERE status='published' GROUP BY cat_slug")}
    kids = {}
    for r in con.execute("SELECT * FROM categories WHERE COALESCE(parent,'')<>''"
                         + (" AND active=1" if only_active else "")
                         + " ORDER BY sort, id"):
        d = dict(r)
        d["count"] = counts.get(d["slug"], 0)
        d["total"] = d["count"]
        kids.setdefault(d["parent"], []).append(d)
    con.close()

    for r in rows:
        r["count"] = counts.get(r["slug"], 0)
        r["children"] = kids.get(r["slug"], [])
        r["total"] = r["count"] + sum(k["count"] for k in r["children"])
    return rows


def category_tree(only_active=True):
    """Top-level categories, each carrying its children. The shape every
    public page and the submit form want."""
    return categories(only_active=only_active, top_only=True)


def category_children(slug, only_active=True):
    return categories(only_active=only_active, parent=slug)


def category_family(slug):
    """[slug] plus every child slug — used to widen a filter so that clicking
    a parent shows the businesses filed under its children too."""
    con = connect()
    kids = [r["slug"] for r in con.execute(
        "SELECT slug FROM categories WHERE parent=?", (slug,))]
    con.close()
    return [slug] + kids


def category_path(slug):
    """[parent, child] or [top] — for breadcrumbs."""
    c = category(slug)
    if not c:
        return []
    if c.get("parent"):
        p = category(c["parent"])
        return [p, c] if p else [c]
    return [c]


def category(slug):
    con = connect()
    r = con.execute("SELECT * FROM categories WHERE slug=?", (slug,)).fetchone()
    con.close()
    return dict(r) if r else None


def category_by_id(cid):
    con = connect()
    r = con.execute("SELECT * FROM categories WHERE id=?", (cid,)).fetchone()
    con.close()
    if not r:
        return None
    d = dict(r)
    con = connect()
    d["count"] = con.execute(
        "SELECT COUNT(*) c FROM businesses WHERE cat_slug=? AND status='published'",
        (d["slug"],)).fetchone()["c"]
    con.close()
    return d


def save_category(data, cid=None):
    con = connect()
    parent = (data.get("parent") or "").strip()
    if cid:
        # a category may not be its own parent, nor a parent of its parent
        cur = con.execute("SELECT slug,image FROM categories WHERE id=?", (cid,)).fetchone()
        if cur and parent == cur["slug"]:
            parent = ""
        image = data["image"] if "image" in data else (cur["image"] if cur else "")
        con.execute("""UPDATE categories SET name=?, icon=?, image=?, blurb=?, sort=?,
                       active=?, parent=? WHERE id=?""",
                    (data["name"], data["icon"], image, data.get("blurb", ""),
                     int(data.get("sort", 0)), int(data.get("active", 1)),
                     parent, cid))
    else:
        slug = data.get("slug") or slugify(data["name"], "cat")
        slug = unique_slug("categories", slug)
        con.execute("""INSERT INTO categories(slug,name,icon,image,blurb,sort,active,parent)
                       VALUES(?,?,?,?,?,?,?,?)""",
                    (slug, data["name"], data.get("icon", "store"),
                     data.get("image", ""), data.get("blurb", ""),
                     int(data.get("sort", 0)),
                     int(data.get("active", 1)), parent))
        cid = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
    con.commit()
    con.close()
    return cid


def delete_category(cid):
    con = connect()
    row = con.execute("SELECT slug FROM categories WHERE id=?", (cid,)).fetchone()
    if row:
        n = con.execute("SELECT COUNT(*) c FROM businesses WHERE cat_slug=?",
                        (row["slug"],)).fetchone()["c"]
        if n:
            con.close()
            return False, f"این دسته {n} کسب‌وکار دارد؛ ابتدا آن‌ها را جابه‌جا کنید."
        # A parent with children would orphan them into an unreachable state,
        # so refuse and say exactly what to do first.
        k = con.execute("SELECT COUNT(*) c FROM categories WHERE parent=?",
                        (row["slug"],)).fetchone()["c"]
        if k:
            con.close()
            return False, f"این دسته {k} زیردسته دارد؛ ابتدا زیردسته‌ها را حذف یا جابه‌جا کنید."
    con.execute("DELETE FROM categories WHERE id=?", (cid,))
    con.commit()
    con.close()
    return True, "حذف شد."


# ------------------------------------------------------------------ businesses
def _biz_row(r):
    d = dict(r)
    try:
        d["images"] = json.loads(d.get("images") or "[]")
    except Exception:
        d["images"] = []
    try:
        d["hours_map"] = json.loads(d.get("hours") or "{}")
    except Exception:
        d["hours_map"] = {}
    d["tag_list"] = [t.strip() for t in (d.get("tags") or "").split("،") if t.strip()] \
        or [t.strip() for t in (d.get("tags") or "").split(",") if t.strip()]
    return d


def businesses(status="published", cat=None, limit=None, order="featured", city=None):
    con = connect()
    q = "SELECT b.*, (SELECT AVG(rating) FROM reviews WHERE biz_id=b.id AND status='approved' AND rating>0) rating, " \
        "(SELECT COUNT(*) FROM reviews WHERE biz_id=b.id AND status='approved') nreviews, " \
        "(SELECT COUNT(*) FROM reviews WHERE biz_id=b.id AND status='approved' AND rating>0) nrated " \
        "FROM businesses b WHERE 1=1"
    p = []
    if status:
        q += " AND b.status=?"
        p.append(status)
    if cat:
        # clicking a parent should show everything beneath it, not an empty page
        fam = category_family(cat)
        q += " AND b.cat_slug IN (%s)" % ",".join("?" * len(fam))
        p.extend(fam)
    if city:
        q += " AND b.city=?"
        p.append(city)
    order_sql = {
        "featured": " ORDER BY b.featured DESC, rating DESC NULLS LAST, b.id DESC",
        "newest":   " ORDER BY b.id DESC",
        "rating":   " ORDER BY rating DESC NULLS LAST",
        "name":     " ORDER BY b.name",
        "views":    " ORDER BY b.views DESC",
    }.get(order, " ORDER BY b.id DESC")
    q += order_sql
    if limit:
        q += f" LIMIT {int(limit)}"
    rows = [_biz_row(r) for r in con.execute(q, p)]
    con.close()
    return annotate_stories(rows)


def business(slug=None, bid=None):
    con = connect()
    if slug:
        r = con.execute("SELECT * FROM businesses WHERE slug=?", (slug,)).fetchone()
    else:
        r = con.execute("SELECT * FROM businesses WHERE id=?", (bid,)).fetchone()
    if not r:
        con.close()
        return None
    d = _biz_row(r)
    d["rating"], d["nrated"], d["nreviews"] = rating_stats(con, d["id"])
    d["has_story"] = d["id"] in stories_active_ids()
    con.close()
    return d


def save_business(data, bid=None):
    _pagecache_drop()
    con = connect()
    fields = ("name", "cat_slug", "descr", "slogan", "phone", "whatsapp", "address",
              "lat", "lng", "hours", "tags", "images", "featured", "verified",
              "status", "instagram", "telegram", "eitaa", "bale", "soroush", "rubika", "website", "booking_on",
              "owner_id", "cover", "area", "city", "province", "phone_public")
    vals = {}
    for f in fields:
        if f in data:
            v = data[f]
            if f in ("featured", "verified", "booking_on", "phone_public"):
                v = int(bool(int(v or 0)))
            if f in ("lat", "lng"):
                v = float(v) if str(v).strip() not in ("", "None") else None
            if f == "images" and not isinstance(v, str):
                v = json.dumps(v, ensure_ascii=False)
            if f == "hours" and not isinstance(v, str):
                v = json.dumps(v, ensure_ascii=False)
            vals[f] = v

    if bid:
        sets = ", ".join(f"{k}=?" for k in vals)
        con.execute(f"UPDATE businesses SET {sets} WHERE id=?",
                    list(vals.values()) + [bid])
    else:
        base = slugify(data.get("slug") or data.get("name"), "biz")
        vals["slug"] = unique_slug("businesses", base)
        cols = ", ".join(vals)
        qs = ", ".join("?" * len(vals))
        con.execute(f"INSERT INTO businesses({cols}) VALUES({qs})", list(vals.values()))
        bid = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
    if vals.get("status") == "published":
        con.execute("UPDATE businesses SET published_once=1 WHERE id=?", (bid,))   # v209
    con.commit()
    con.close()
    _fts_mark_dirty()
    return bid


def delete_business(bid):
    _pagecache_drop()
    con = connect()
    con.execute("DELETE FROM businesses WHERE id=?", (bid,))
    con.commit()
    con.close()
    _fts_mark_dirty()


# v209: owner-side lifecycle. Every transition is a compare-and-set on
# (id, owner_id, current status) so a stale/duplicate form cannot regress.
OWNER_BIZ_TRANSITIONS = {
    "withdraw": ("pending", "hidden"),     # cancel the review request
    "resubmit": ("hidden", "pending"),     # ask for review again
    "hide":     ("published", "hidden"),   # temporarily off the site
    "show":     ("hidden", "published"),   # only if it had been published before
}


def owner_biz_transition(owner_id, bid, action):
    """Returns (ok, new_status). `show` is allowed only for rows that were
    published once (approved_at set) — a withdrawn draft can't self-publish."""
    if action not in OWNER_BIZ_TRANSITIONS:
        return False, None
    frm, to = OWNER_BIZ_TRANSITIONS[action]
    con = connect()
    try:
        extra = " AND published_once=1" if action == "show" else ""
        n = con.execute(f"UPDATE businesses SET status=? WHERE id=? AND owner_id=? AND status=?{extra}",
                        (to, int(bid), int(owner_id), frm)).rowcount
        con.commit()
    finally:
        con.close()
    if n:
        _pagecache_drop(); _fts_mark_dirty()
        log(f"business.owner-{action}", f"{bid} by owner {owner_id}")
    return bool(n), (to if n else None)


def owner_delete_business(owner_id, bid):
    """Soft delete: the full row goes to the recycle bin (30 days, restorable
    from /my/trash) and is removed from `businesses`. Children (orders,
    bookings, reviews…) cascade away with the row, which is why this is a
    deliberate, name-confirmed action in the UI."""
    con = connect()
    r = con.execute("SELECT * FROM businesses WHERE id=? AND owner_id=?", (int(bid), int(owner_id))).fetchone()
    if not r:
        con.close()
        return False
    row = dict(r)
    trash_put("business", row["id"], row["id"], row.get("name") or "", row)
    con.execute("DELETE FROM businesses WHERE id=? AND owner_id=?", (int(bid), int(owner_id)))
    con.commit(); con.close()
    _pagecache_drop(); _fts_mark_dirty()
    log("business.owner-delete", f"{bid} «{row.get('name','')}» by owner {owner_id}")
    return True


def all_upload_refs():
    """Every public upload path still referenced by live data (business
    galleries and covers, item images, the site logo). The orphan-file GC and
    the media manager both use this as the "still wanted" set."""
    def _paths(v):
        out = []
        if not isinstance(v, str) or not v:
            return out
        try:
            parsed = json.loads(v)
            if isinstance(parsed, list):
                return [p for p in parsed if isinstance(p, str) and p]
        except Exception:
            pass
        return [v]

    refs = set()
    con = connect()
    for r in con.execute("SELECT images, cover FROM businesses"):
        for v in (r["images"], r["cover"]):
            refs.update(_paths(v))
    for r in con.execute("SELECT image, images FROM items"):
        for v in (r["image"], r["images"]):
            refs.update(_paths(v))
    # v181: تصویر سفارشی دسته نباید توسط پاک‌ساز رسانه یتیم فرض شود.
    try:
        for r in con.execute("SELECT image FROM categories WHERE image LIKE '/assets/%'"):
            refs.add(r["image"])
    except sqlite3.OperationalError:
        pass
    # v177: عکس استوری‌ها و نظراتِ زنده هم «خواسته» است — قبلاً دکمهٔ پاک‌سازی
    # فایل‌های بی‌استفاده در /panel/media می‌توانست عکس استوری زنده و عکس نظر
    # را حذف کند (باگ واقعی که در کارِ «بازیابی فایل‌ها» لو رفت).
    try:
        for r in con.execute("SELECT image FROM stories WHERE image LIKE '/assets/%'"):
            refs.add(r["image"])
    except sqlite3.OperationalError:
        pass
    try:
        for r in con.execute("SELECT image FROM reviews WHERE image LIKE '/assets/%'"):
            refs.add(r["image"])
    except sqlite3.OperationalError:
        pass
    # عکس ردیف‌های «بازیابی فایل‌ها» (سطل) — پیش‌نمایش و بازیابی به فایل نیاز دارند
    try:
        for r in con.execute("SELECT payload FROM trash"):
            try:
                row = json.loads(r["payload"])
            except Exception:
                continue
            img = row.get("image") if isinstance(row, dict) else None
            if isinstance(img, str) and img.startswith("/assets/"):
                refs.add(img)
            ims = row.get("images") if isinstance(row, dict) else None
            if isinstance(ims, list):
                refs.update(p for p in ims if isinstance(p, str) and p.startswith("/assets/"))
    except sqlite3.OperationalError:
        pass
    con.close()
    logo = (get_settings().get("site_logo") or "").strip()
    if logo:
        refs.add(logo)
    return refs


def bump_views(bid, viewer=""):
    """Count ONE real view: unique visitor (bz_cid) per day per business.

    Pre-v177 this bumped on every page load, so a refresh inflated the
    counter. Now the dedupe lives in `page_viewers`; only the first visit of
    a viewer on a given day moves `businesses.views` AND the daily `events`
    series, so the lifetime counter and the chart can never contradict.
    """
    day = datetime.date.today().isoformat()
    viewer = (viewer or "").strip() or "anon"
    con = connect()
    cur = con.execute(
        "INSERT OR IGNORE INTO page_viewers(entity,eid,viewer,day,ts) "
        "VALUES('biz',?,?,?,?)", (bid, viewer, day, time.time()))
    if cur.rowcount:
        con.execute("UPDATE businesses SET views=views+1 WHERE id=?", (bid,))
        con.execute("""INSERT INTO events(biz_id,kind,day,n) VALUES(?,'view',?,1)
                       ON CONFLICT(biz_id,kind,day) DO UPDATE SET n = n + 1""",
                    (bid, day))
    con.commit()
    con.close()


def count_item_view(iid, viewer=""):
    """v177 sibling of bump_views for catalog items (unique viewer/day)."""
    day = datetime.date.today().isoformat()
    viewer = (viewer or "").strip() or "anon"
    con = connect()
    cur = con.execute(
        "INSERT OR IGNORE INTO page_viewers(entity,eid,viewer,day,ts) "
        "VALUES('item',?,?,?,?)", (iid, viewer, day, time.time()))
    if cur.rowcount:
        con.execute("UPDATE items SET views=views+1 WHERE id=?", (iid,))
    con.commit()
    con.close()


# ==========================================================================
#  "OPEN NOW" — the question every customer actually has
#
#  A directory that lists a closed shop as if it were open wastes a trip.
#  Everything here is computed from the shop's own hours table, in Iran local
#  time, with no network call and no third-party service — so it keeps working
#  on a phone with no data and inside Pydroid.
#
#  Week keys match the hours editor: sat..fri. Python's weekday() is
#  Monday=0..Sunday=6, hence the lookup table below.
# ==========================================================================
DAY_KEYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]   # by weekday()
DAY_FA = {"sat": "شنبه", "sun": "یک‌شنبه", "mon": "دوشنبه", "tue": "سه‌شنبه",
          "wed": "چهارشنبه", "thu": "پنج‌شنبه", "fri": "جمعه"}

# Iran is UTC+3:30 and has not observed DST since 1401/2022, so a fixed
# offset is correct and avoids depending on the device's timezone being set.
IRAN_OFFSET_MIN = 210

_FA_TRANS = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")


def _fa(n):
    """Persian digits. db.py deliberately keeps its own tiny copy rather than
    importing the one in layout.py, which would drag the whole static-site
    module (and its data.py) into the server for the sake of ten characters."""
    return str(n).translate(_FA_TRANS)


def iran_now():
    """Current wall-clock time in Iran, independent of the device setting."""
    return datetime.datetime.now(datetime.timezone.utc) + \
        datetime.timedelta(minutes=IRAN_OFFSET_MIN)


def _hhmm(s):
    """'09:30' -> 570 minutes. Returns None when unparseable."""
    try:
        h, m = str(s).strip().split(":")[:2]
        h, m = int(h), int(m)
    except Exception:
        return None
    if not (0 <= h <= 24 and 0 <= m < 60):
        return None
    return h * 60 + m


def open_state(b, now=None):
    """What is this shop's status right now?

    Returns a dict every caller can render directly:
      state    'open' | 'closing' | 'closed' | 'unknown'
      label    a short Persian phrase
      detail   the useful extra ('تا ۲۱:۰۰', 'شنبه ۹:۰۰ باز می‌شود')
      minutes  minutes until it closes, when state is open/closing

    'unknown' is deliberate and honest: a shop that never filled in its hours
    must not be claimed to be open, nor be hidden as if it were closed.
    """
    hm = b.get("hours_map") or {}

    # A shop counts as having hours only if at least one range actually
    # parses. Hours that are present but entirely unreadable are 'unknown',
    # not 'closed' — reporting a shop shut because of a malformed field would
    # cost a real shopkeeper real customers.
    def _valid(k):
        v = hm.get(k)
        if not isinstance(v, (list, tuple)):
            return False
        return any(isinstance(r, (list, tuple)) and len(r) == 2
                   and _hhmm(r[0]) is not None and _hhmm(r[1]) is not None
                   for r in v)

    if not any(_valid(k) for k in DAY_KEYS):
        return {"state": "unknown", "label": "ساعت کاری ثبت نشده",
                "detail": "", "minutes": None}

    now = now or iran_now()
    today = DAY_KEYS[now.weekday()]
    cur = now.hour * 60 + now.minute

    # --- is it inside one of today's ranges?
    for rng in (hm.get(today) or []):
        if len(rng) != 2:
            continue
        o, c = _hhmm(rng[0]), _hhmm(rng[1])
        if o is None or c is None:
            continue
        # a range ending past midnight (e.g. 20:00–02:00) wraps to the next day
        wraps = c <= o
        inside = (o <= cur < c) if not wraps else (cur >= o or cur < c)
        if inside:
            left = (c - cur) if not wraps else ((c + 1440 - cur) % 1440)
            if left <= 60:
                return {"state": "closing",
                        "label": f"تا {_fa(left)} دقیقهٔ دیگر می‌بندد",
                        "detail": f"تا ساعت {_fa(rng[1])}", "minutes": left}
            return {"state": "open", "label": "الان باز است",
                    "detail": f"تا ساعت {_fa(rng[1])}", "minutes": left}

    # --- closed: find the next opening, looking up to a week ahead
    for step in range(0, 8):
        d = DAY_KEYS[(now.weekday() + step) % 7]
        for rng in sorted(hm.get(d) or [], key=lambda r: _hhmm(r[0]) or 0):
            if len(rng) != 2:
                continue
            o = _hhmm(rng[0])
            if o is None:
                continue
            if step == 0 and o <= cur:
                continue          # already passed today
            if step == 0:
                mins = o - cur
                if mins <= 90:
                    return {"state": "closed",
                            "label": f"تا {_fa(mins)} دقیقهٔ دیگر باز می‌شود",
                            "detail": f"ساعت {_fa(rng[0])}", "minutes": None}
                return {"state": "closed", "label": "الان بسته است",
                        "detail": f"امروز ساعت {_fa(rng[0])} باز می‌شود",
                        "minutes": None}
            when = "فردا" if step == 1 else DAY_FA.get(d, d)
            return {"state": "closed", "label": "الان بسته است",
                    "detail": f"{when} ساعت {_fa(rng[0])} باز می‌شود",
                    "minutes": None}

    return {"state": "closed", "label": "الان بسته است", "detail": "",
            "minutes": None}


def is_open_now(b, now=None):
    return open_state(b, now)["state"] in ("open", "closing")


def annotate_open(rows, now=None):
    """Stamp every row with its live status once, so templates never recompute."""
    now = now or iran_now()
    for b in rows:
        b["open_state"] = open_state(b, now)
    return rows


# ---------------------------------------------------------------- full-text
# SQLite FTS5, when the device's sqlite has it (desktop always does; some
# Android/Pydroid builds don't). When it is missing we transparently fall
# back to the in-memory filter, so search keeps working everywhere.
FTS_OK = False


def _fts_ensure():
    """Create the FTS table if possible. Returns True when usable."""
    global FTS_OK
    try:
        con = connect()
        con.execute("CREATE VIRTUAL TABLE IF NOT EXISTS businesses_fts "
                    "USING fts5(name, descr, tags, address)")
        con.commit()
        con.close()
        FTS_OK = True
    except Exception:
        FTS_OK = False
    return FTS_OK


def _fts_rebuild():
    """Repopulate the FTS index from the live businesses table."""
    con = connect()
    try:
        con.execute("DELETE FROM businesses_fts")
        for r in con.execute("SELECT id,name,descr,tags,address FROM businesses "
                             "WHERE status='published'"):
            con.execute(
                "INSERT INTO businesses_fts(rowid,name,descr,tags,address) "
                "VALUES(?,?,?,?,?)",
                (r["id"], r["name"], r["descr"] or "", r["tags"] or "",
                 r["address"] or ""))
        con.commit()
    finally:
        con.close()


def _fts_mark_dirty():
    set_setting("fts_dirty", "1")


def _fts_sync_if_needed():
    if get_settings().get("fts_dirty") != "1":
        return
    if _fts_ensure():
        try:
            _fts_rebuild()
        except Exception:
            pass
    set_setting("fts_dirty", "0")


def _fts_query(term):
    """Safe MATCH expression: every token quoted, joined with AND. Persian
    text tokenises on spaces; each token is wrapped so user input can never
    break the FTS syntax."""
    toks = [t for t in normalize_fa(term).split() if t]
    if not toks:
        return None
    quoted = " AND ".join('"' + t.replace('"', '""') + '"' for t in toks)
    con = connect()
    try:
        ids = [r["rowid"] for r in con.execute(
            "SELECT rowid FROM businesses_fts WHERE businesses_fts MATCH ?",
            (quoted,))]
    except Exception:
        ids = []
    con.close()
    return ids


def search(term="", cat="", open_now=False, sort="featured", tag="", city=None):
    rows = businesses(status="published", cat=cat or None, order=sort, city=city)
    if term:
        t = normalize_fa(term)
        if FTS_OK:
            ids = _fts_query(term)
            if ids:
                idset = set(ids)
                rows = [r for r in rows if r["id"] in idset]
            else:
                # no FTS hit — still run the substring filter as a safety net
                # for terms the tokeniser split differently (e.g. ZWNJ).
                rows = [r for r in rows
                        if t in normalize_fa(f"{r['name']} {r['descr']} {r['tags']} {r['address']}")]
        else:
            rows = [r for r in rows
                    if t in normalize_fa(f"{r['name']} {r['descr']} {r['tags']} {r['address']}")]
    if tag:
        rows = [r for r in rows if tag in (r.get("tags") or "")]
    if open_now:
        # This parameter used to be accepted and silently ignored — the filter
        # simply did not exist. Shops with no hours on file are kept, because
        # excluding them would punish a shopkeeper for a blank field rather
        # than for being closed.
        _n = iran_now()
        rows = [r for r in rows
                if open_state(r, _n)["state"] in ("open", "closing", "unknown")]
    return rows


def search_business_summaries(term, limit=5):
    """Bounded bot projection: authoritative Persian matching without page decoration."""
    term = str(term or "").strip()[:60]
    limit = max(1, min(int(limit or 5), 10))
    if len(normalize_fa(term)) < 2:
        return []
    ids = _fts_query(term) if FTS_OK else []
    con = connect()
    if ids:
        ids = ids[:500]
        marks = ",".join("?" * len(ids))
        rows = [dict(r) for r in con.execute(
            f"SELECT id,slug,name,cat_slug,address,phone,lat,lng,verified FROM businesses "
            f"WHERE status='published' AND id IN ({marks}) "
            "ORDER BY featured DESC,verified DESC,id DESC LIMIT ?", ids + [limit])]
    else:
        # Same normalized fallback as public search, but project only fields the bot uses.
        candidates = [dict(r) for r in con.execute(
            "SELECT id,slug,name,cat_slug,address,phone,lat,lng,verified,descr,tags "
            "FROM businesses WHERE status='published' ORDER BY featured DESC,id DESC")]
        needle = normalize_fa(term)
        rows = [r for r in candidates if needle in normalize_fa(
            f"{r['name']} {r['descr']} {r['tags']} {r['address']}")][:limit]
        for row in rows:
            row.pop("descr", None); row.pop("tags", None)
    con.close()
    return rows


def normalize_fa(s):
    """Fold the spelling variations Persian typists actually produce.

    The zero-width non-joiner matters most: «گل‌محمدی» and «گل محمدی» are the
    same name to a human, but as raw text one is a single token and the other
    is two, so similarity scored 0.5 and duplicate detection missed it. Treat
    the ZWNJ as a space and the two forms tokenise identically.
    """
    s = (s or "").lower()
    for a, b in (("ي", "ی"), ("ك", "ک"), ("ﻻ", "لا"),
                 ("\u200c", " "),   # ZWNJ (نیم‌فاصله)
                 ("\u200f", " "), ("\u200e", " "),   # bidi marks
                 ("\u00a0", " "),   # non-breaking space
                 ("ۀ", "ه"), ("ة", "ه"), ("أ", "ا"), ("إ", "ا"), ("آ", "ا"),
                 ("ؤ", "و"), ("ئ", "ی"), ("ء", "")):
        s = s.replace(a, b)
    s = re.sub(r"[ًٌٍَُِّْـ]", "", s)
    trans = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
    s = s.translate(trans)
    return re.sub(r"\s+", " ", s).strip()


# ------------------------------------------------------------------ reviews
def _page_result(con, q, p, page, per):
    """v117/M3: window any SELECT into a page (COUNT wrapper + LIMIT)."""
    page = min(max(1, int(page)), 1_000_000)   # giant ?page= must not overflow
    total = con.execute(f"SELECT COUNT(*) FROM ({q})", p).fetchone()[0]
    rows = con.execute(q + " LIMIT ? OFFSET ?",
                       list(p) + [per, max(0, (int(page) - 1) * per)]).fetchall()
    return {"rows": [dict(r) for r in rows], "total": total,
            "pages": max(1, -(-total // per)), "page": int(page)}


def _page_slice(rows, page, per):
    """v117/M3: python-side window for lists filtered outside SQL."""
    page = min(max(1, int(page)), 1_000_000)
    total = len(rows)
    return {"rows": rows[max(0, (int(page) - 1) * per):int(page) * per],
            "total": total, "pages": max(1, -(-total // per)), "page": int(page)}


def reviews(biz_id=None, status=None, page=None, per=50):
    con = connect()
    q = "SELECT r.*, b.name bizname, b.slug bizslug FROM reviews r " \
        "JOIN businesses b ON b.id=r.biz_id WHERE 1=1"
    p = []
    if biz_id:
        q += " AND r.biz_id=?"; p.append(biz_id)
    if status:
        q += " AND r.status=?"; p.append(status)
    q += " ORDER BY r.id DESC"
    if page is not None:                      # v117/M3
        out = _page_result(con, q, p, page, per)
        con.close()
        return out
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()
    return rows


def add_review(biz_id, author, rating, body, auto_approve=False):
    con = connect()
    con.execute("INSERT INTO reviews(biz_id,author,rating,body,status) VALUES(?,?,?,?,?)",
                (biz_id, author, int(rating), body,
                 "approved" if auto_approve else "pending"))
    con.commit()
    con.close()


def review_reject_notify(rid):
    """v146: when a moderator rejects a review, its author (a known
    customer) is told — otherwise their review would silently never show up.
    Deletions stay silent (that path is for abuse)."""
    r = _one("SELECT * FROM reviews WHERE id=?", (rid,))
    if not r or not r.get("customer_id"):
        return
    b = business(bid=r.get("biz_id")) or {}
    # Pydroid runs Python 3.11 — a backslash inside an f-string expression
    # part is a SyntaxError there (PEP 701 relaxed it only in 3.12).
    _bn = b.get("name") or "این کسب\u200cوکار"
    _bslug = b.get("slug") or ""
    notify_customer(r["customer_id"], "reply",
                    f"نظر شما درباره\u200cی «{_bn}» تأیید نشد و در سایت نمایش داده نمی\u200cشود.",
                    f"/b/{_bslug}" if _bslug else "")


def update_review(rid, **kw):
    if not kw:
        return
    con = connect()
    sets = ", ".join(f"{k}=?" for k in kw)
    con.execute(f"UPDATE reviews SET {sets} WHERE id=?", list(kw.values()) + [rid])
    con.commit()
    con.close()
    if kw.get("reply"):
        r = _one("SELECT * FROM reviews WHERE id=?", (rid,))
        if r and r.get("customer_id"):
            b = business(bid=r["biz_id"]) or {}
            notify_customer(r["customer_id"], "reply",
                            f"«{b.get('name', 'کسب‌وکار')}» به نظر شما پاسخ داد.",
                            f"/b/{b.get('slug', '')}#reviews")


def delete_review(rid):
    row = _one("SELECT * FROM reviews WHERE id=?", (rid,))
    if row:
        trash_put("review", rid, row["biz_id"],
                  (row["author"] or "") + ": " + (row["body"] or "")[:40], dict(row))
    con = connect()
    con.execute("DELETE FROM reviews WHERE id=?", (rid,))
    con.commit()
    con.close()


# ------------------------------------------------------------------ bookings
def bookings(status=None, page=None, per=50, q=None):
    con = connect()
    sql = "SELECT k.*, b.name bizname FROM bookings k JOIN businesses b ON b.id=k.biz_id"
    p = []
    if status:
        sql += " WHERE k.status=?"; p.append(status)
    if q:                                       # v296: جستجوی نام/تلفن مشتری
        like = f"%{q}%"
        sql += (" AND" if status else " WHERE") + " (k.name LIKE ? OR k.phone LIKE ?)"
        p += [like, like]
    sql += " ORDER BY k.id DESC"
    if page is not None:                      # v117/M3
        out = _page_result(con, sql, p, page, per)
        con.close()
        return out
    rows = [dict(r) for r in con.execute(sql, p)]
    con.close()
    return rows


def add_booking(biz_id, name, phone, date, time_, note="", customer_id=None):
    con = connect()
    con.execute("""INSERT INTO bookings(biz_id,name,phone,date,time,note,customer_id)
                   VALUES(?,?,?,?,?,?,?)""", (biz_id, name, norm_phone(phone), date,
                                               time_, note, customer_id))
    kid = con.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
    con.commit()
    con.close()
    _owner_notify_biz(biz_id, "order", f"🗓 نوبت تازه ثبت شد: {name} — {date}", "/my/bookings")
    if customer_id:
        biz = business(bid=biz_id) or {}
        notify_customer(customer_id, "booking",
            f"یادآوری نوبت شما در «{biz.get('name','کسب‌وکار')}»: {date} ساعت {time_}",
            f"/b/{biz.get('slug','')}" if biz.get("slug") else "/me")
    return kid


# v171: وضعیت‌های شناخته‌شدهٔ نوبت — هم‌قاعده با سفارش‌ها؛ POST دستکاری‌شده
# با وضعیت دلخواه نباید فیلترها/برچسب‌ها را خراب کند.
BOOKING_STATUSES = ("new", "confirmed", "done", "cancelled")


BOOKING_LABELS = {"new":"جدید", "confirmed":"تأیید شده",
                  "done":"انجام شده", "cancelled":"لغو شده"}


def update_booking(kid, **kw):
    if "status" in kw and kw["status"] not in BOOKING_STATUSES:
        return False
    con = connect()
    before = con.execute("SELECT * FROM bookings WHERE id=?", (kid,)).fetchone()
    if not before or not kw:
        con.close(); return False
    sets = ", ".join(f"{k}=?" for k in kw)
    con.execute(f"UPDATE bookings SET {sets} WHERE id=?", list(kw.values()) + [kid])
    con.commit(); con.close()
    new_status = kw.get("status")
    if new_status and new_status != before["status"] and before["customer_id"]:
        biz = business(bid=before["biz_id"]) or {}
        notify_customer(before["customer_id"], "booking",
            f"وضعیت نوبت شما در «{biz.get('name','کسب‌وکار')}» برای {before['date']} ساعت {before['time']} به «{BOOKING_LABELS[new_status]}» تغییر کرد.",
            f"/b/{biz.get('slug','')}" if biz.get("slug") else "/me")
    return True


def customer_booking_summaries(customer_id, limit=5):
    limit = max(1, min(int(limit or 5), 10))
    rows = _rows(
        "SELECT k.id,k.date,k.time,k.status,k.created,b.name AS bizname,b.slug AS bizslug "
        "FROM bookings k JOIN businesses b ON b.id=k.biz_id "
        "WHERE k.customer_id=? ORDER BY k.id DESC LIMIT ?", (int(customer_id), limit))
    for row in rows: row["status_label"] = BOOKING_LABELS.get(row["status"], row["status"])
    return rows


def customer_booking_detail(customer_id, booking_id):
    row = _one(
        "SELECT k.id,k.date,k.time,k.status,k.created,b.name AS bizname,b.slug AS bizslug "
        "FROM bookings k JOIN businesses b ON b.id=k.biz_id "
        "WHERE k.id=? AND k.customer_id=?", (int(booking_id), int(customer_id)))
    if not row: return None
    out = dict(row); out["status_label"] = BOOKING_LABELS.get(out["status"], out["status"])
    return out


def customer_booking_cancel(customer_id, booking_id):
    """Cancel only an owned active booking; caller must have asked for confirmation."""
    con = connect(); con.execute("BEGIN IMMEDIATE")
    row = con.execute("SELECT id,biz_id,status FROM bookings WHERE id=? AND customer_id=?",
                      (int(booking_id), int(customer_id))).fetchone()
    if not row:
        con.rollback(); con.close(); return "missing"
    if row["status"] not in ("new", "confirmed"):
        con.rollback(); con.close(); return "final"
    cur = con.execute("UPDATE bookings SET status='cancelled' WHERE id=? AND customer_id=? "
                      "AND status IN ('new','confirmed')", (int(booking_id), int(customer_id)))
    con.commit(); con.close()
    if cur.rowcount != 1: return "final"
    _owner_notify_biz(row["biz_id"], "order", "🗓 مشتری نوبت خود را لغو کرد.", "/my/bookings")
    return "cancelled"


# ------------------------------------------------------------------ posts
def posts(status="published", limit=None):
    con = connect()
    q = "SELECT * FROM posts"
    p = []
    if status:
        q += " WHERE status=?"; p.append(status)
    q += " ORDER BY id DESC"
    if limit:
        q += f" LIMIT {int(limit)}"
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()
    return rows


def post(slug):
    con = connect()
    r = con.execute("SELECT * FROM posts WHERE slug=?", (slug,)).fetchone()
    con.close()
    return dict(r) if r else None


def post_by_id(pid):
    """v170/A5: ویرایش مقاله در پنل — یافتن ردیف با شناسه."""
    con = connect()
    r = con.execute("SELECT * FROM posts WHERE id=?", (pid,)).fetchone()
    con.close()
    return dict(r) if r else None


def save_post(data, pid=None):
    con = connect()
    if pid:
        con.execute("""UPDATE posts SET title=?, excerpt=?, body=?, cover=?, video=?,
                       status=? WHERE id=?""",
                    (data["title"], data.get("excerpt", ""), data.get("body", ""),
                     data.get("cover", ""), data.get("video", ""),
                     data.get("status", "published"), pid))
    else:
        slug = unique_slug("posts", slugify(data.get("slug") or data["title"], "post"))
        con.execute("""INSERT INTO posts(slug,title,excerpt,body,cover,video,status)
                       VALUES(?,?,?,?,?,?,?)""",
                    (slug, data["title"], data.get("excerpt", ""),
                     data.get("body", ""), data.get("cover", ""), data.get("video", ""),
                     data.get("status", "published")))
    con.commit()
    con.close()


def delete_post(pid):
    con = connect()
    con.execute("DELETE FROM posts WHERE id=?", (pid,))
    con.commit()
    con.close()


# ------------------------------------------------------------------ pages
def get_page(slug):
    con = connect()
    r = con.execute("SELECT * FROM pages WHERE slug=?", (slug,)).fetchone()
    con.close()
    return dict(r) if r else {"slug": slug, "title": "", "body": ""}


def save_page(slug, title, body):
    con = connect()
    con.execute("""INSERT INTO pages(slug,title,body) VALUES(?,?,?)
                   ON CONFLICT(slug) DO UPDATE SET title=excluded.title,
                   body=excluded.body""", (slug, title, body))
    con.commit()
    con.close()


# ------------------------------------------------------------------ messages
def messages(status=None, kind=None, page=None, per=50):
    con = connect()
    q = "SELECT * FROM messages WHERE 1=1"
    p = []
    if status:
        q += " AND status=?"; p.append(status)
    if kind:
        q += " AND kind=?"; p.append(kind)
    q += " ORDER BY id DESC"
    if page is not None:                      # v117/M3
        out = _page_result(con, q, p, page, per)
        con.close()
        return out
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()
    return rows


def add_message(name, email, subject, body, kind="contact", meta=None):
    con = connect()
    con.execute("""INSERT INTO messages(name,email,subject,body,kind,meta)
                   VALUES(?,?,?,?,?,?)""",
                (name, email, subject, body, kind,
                 json.dumps(meta or {}, ensure_ascii=False)))
    con.commit()
    con.close()


def update_message(mid, **kw):
    con = connect()
    sets = ", ".join(f"{k}=?" for k in kw)
    con.execute(f"UPDATE messages SET {sets} WHERE id=?", list(kw.values()) + [mid])
    con.commit()
    con.close()


def delete_message(mid):
    con = connect()
    con.execute("DELETE FROM messages WHERE id=?", (mid,))
    con.commit()
    con.close()


# ------------------------------------------------------------------ stats
def stats():
    """Dashboard totals from one SQLite statement (v184).

    The keys and values intentionally match the historical contract. Scalar
    subqueries keep each total independent while avoiding fourteen Python-to-
    SQLite execute round trips on every dashboard request.
    """
    con = connect()
    row = con.execute("""
        SELECT
          (SELECT COUNT(*) FROM businesses WHERE status='published') businesses,
          (SELECT COUNT(*) FROM businesses WHERE status='pending') pending_biz,
          (SELECT COUNT(*) FROM categories WHERE active=1) categories,
          (SELECT COUNT(*) FROM reviews WHERE status='approved') reviews,
          (SELECT COUNT(*) FROM reviews WHERE status='pending') pending_reviews,
          (SELECT COUNT(*) FROM bookings) bookings,
          (SELECT COUNT(*) FROM bookings WHERE status='new') new_bookings,
          (SELECT COUNT(*) FROM messages) messages,
          (SELECT COUNT(*) FROM messages WHERE status='new') new_messages,
          (SELECT COUNT(*) FROM questions WHERE status='pending') pending_questions,
          (SELECT COUNT(*) FROM reports WHERE status='open') open_reports,
          (SELECT COUNT(*) FROM subscriptions WHERE status='pending') pending_subs,
          (SELECT COALESCE(SUM(views),0) FROM businesses) views,
          (SELECT COUNT(*) FROM posts) posts
    """).fetchone()
    con.close()
    return {key: row[key] for key in (
        "businesses", "pending_biz", "categories", "reviews",
        "pending_reviews", "bookings", "new_bookings", "messages",
        "new_messages", "pending_questions", "open_reports", "pending_subs",
        "views", "posts",
    )}


def asset_weights():
    """Site storage / asset weight for the dashboard health card (v53).

    A directory owner should be able to see at a glance how heavy the site is
    — that is what drives load time on a phone, not the server. Sizes are
    returned in whole kilobytes, so the panel can render Persian numbers.
    """
    import os
    HERE = os.path.dirname(os.path.abspath(__file__))
    SITE = os.path.abspath(os.path.join(HERE, "..", "site", "assets"))

    def kb(path):
        try:
            return os.path.getsize(path) // 1024
        except OSError:
            return 0

    uploads_dir = os.path.join(SITE, "img", "uploads")
    cats_dir = os.path.join(SITE, "img", "cats")
    up_files = up_bytes = 0
    for f in os.listdir(uploads_dir):
        if f == ".gitkeep":
            continue
        p = os.path.join(uploads_dir, f)
        if os.path.isfile(p):
            up_files += 1
            up_bytes += os.path.getsize(p)
    cat_files = cat_bytes = 0
    for f in os.listdir(cats_dir):
        p = os.path.join(cats_dir, f)
        if os.path.isfile(p):
            cat_files += 1
            cat_bytes += os.path.getsize(p)
    return {
        "uploads": up_bytes // 1024,
        "upload_files": up_files,
        "cats": cat_bytes // 1024,
        "cat_files": cat_files,
        "video": 0,   # v75 removed the hero movie/poster entirely
        "sprite": 0,  # v75 replaced the all-in-one sheet with lazy WebP files
    }


# v218: admin-editable assistant knowledge (see server/assistant.py faqs()).
def ai_faq_list(active_only=True):
    q = "SELECT * FROM ai_faq"
    if active_only:
        q += " WHERE active=1"
    return _rows(q + " ORDER BY ord, id")


def ai_faq_get(fid):
    return _one("SELECT * FROM ai_faq WHERE id=?", (fid,))


def ai_faq_upsert(fid, q, a, active=1, ord=0):
    con = connect()
    if fid and _one("SELECT id FROM ai_faq WHERE id=?", (fid,)):
        con.execute("UPDATE ai_faq SET q=?, a=?, active=?, ord=?, updated=? WHERE id=?",
                    (q, a, 1 if active else 0, ord,
                     iran_now().strftime("%Y-%m-%d %H:%M"), fid))
    else:
        cur = con.execute("INSERT INTO ai_faq(q,a,active,ord,updated) VALUES(?,?,?,?,?)",
                          (q, a, 1 if active else 0, ord,
                           iran_now().strftime("%Y-%m-%d %H:%M")))
        fid = cur.lastrowid
    con.commit()
    con.close()
    return fid


def ai_faq_delete(fid):
    con = connect()
    con.execute("DELETE FROM ai_faq WHERE id=?", (fid,))
    con.commit()
    con.close()


def ai_faq_seed(pairs):
    """Insert built-in (q, a) rows only when the table is empty. Returns n."""
    if _one("SELECT COUNT(*) n FROM ai_faq")["n"]:
        return 0
    con = connect()
    for i, (q, a) in enumerate(pairs):
        con.execute("INSERT INTO ai_faq(q,a,active,ord,updated) VALUES(?, ?, 1, ?, ?)",
                    (q, a, i, iran_now().strftime("%Y-%m-%d %H:%M")))
    con.commit()
    con.close()
    return len(pairs)


# ------------------------------------------------------------------ backup
def export_all():
    con = connect()
    out = {"_meta": {"exported": datetime.datetime.now().isoformat(), "version": 1}}
    for t in ("settings", "categories", "businesses", "reviews", "bookings",
              "coupons", "posts", "messages", "pages",
              "items", "inquiries", "owners", "customers",
              "messenger_accounts", "claims", "events",
              "chat_threads", "chat_messages", "chat_attachments",
              "tickets", "ticket_msgs", "ticket_attachments",
              "badges", "biz_badges", "plans", "subscriptions", "ads",
              "cityevents", "questions", "reports", "review_scores",
              "edits", "alerts", "biz_features",
              # v116-audit: these held real user data but were missing from
              # the "complete" backup — restoring would have silently lost
              # orders, stories, favourites, points and the analytics trail.
              "orders", "order_items", "stories", "story_views",
              "favorites", "follows", "haggles", "notifications",
              # v153: جداول اعلان‌ها در پشتیبان جا مانده بودند — با بازگردانی،
              # صندوق اعلان دکان‌دار/تنظیم‌ها/اشتراک پوش بی‌صدا از دست می‌رفت.
              "owner_notifications", "notif_prefs", "push_subs",
              # v156: فراخوان‌ها و درخواست‌های موجودی — بدون آن‌ها پشتیبانِ
              # «کامل» صندوق درخواست و آرشیو فراخوان را از دست می‌داد.
              "broadcasts", "stock_requests",
              # v178: دو جدولِ v176/v177 در پشتیبان «کامل» جا مانده بودند —
              # review_votes (دِدوپ یک‌رأیِ «مفید بود») و page_viewers (کلیدِ
              # روزانهٔ بازدیدکنندهٔ یکتا). بدون آن‌ها بازگردانی، رأی‌های
              # یکتا و شمارش بازدید واقعی را بی‌صدا صفر می‌کرد.
              "review_votes", "page_viewers",
              # v276: دایدپ رأی «مفید» پرسش — فرزند questions
              "question_votes",
              "points", "redemptions", "price_alerts", "price_history",
              "flashdeals", "toplists", "trash", "visits", "searches",
              # v208: پیش‌نویس‌های ثبت مرحله‌ای (بات/وب) و کلید روزانهٔ خلاصهٔ
              # دکان‌دار. جدول‌های امنیتیِ گذرا (challenges/confirmations/
              # updates) عمداً بیرون می‌مانند — مثل sessions و otp.
              "biz_reg_drafts", "owner_daily_summaries",
              # v212: شناسهٔ پیام «رسید زندهٔ سفارش» در بله/سروش — فرزند orders.
              "order_receipts",
              # v213: شمارندهٔ دستیار هوشمند (بدون متن پیام)
              "ai_usage", "ai_intents",
              "ai_faq",   # v218: دانش قابل‌ویرایش دستیار
              # v275: فهرست banهای ضداسپم ماندگار است (رویدادها عمداً گذرا)
              "spam_bans",
              "audit"):
        out[t] = [dict(r) for r in con.execute(f"SELECT * FROM {t}")]
    con.close()
    return out


# Parents must be written before children, and wiped in reverse, or the
# foreign keys reject the restore.
_RESTORE_ORDER = ("settings", "pages", "categories", "owners", "customers",
                  "messenger_accounts", "badges",
                  "plans", "businesses", "items", "reviews", "review_scores",
                  # v178: review_votes فرزندِ reviews است (ON DELETE CASCADE) —
                  # باید بعد از والد نوشته شود و در وایپِ معکوس زودتر بمیرد.
                  "review_votes",
                  "question_votes",   # v276: after questions parent
                  "bookings", "coupons", "posts", "messages", "inquiries",
                  "claims", "events", "chat_threads", "chat_messages", "chat_attachments",
                  "tickets", "ticket_msgs", "ticket_attachments", "biz_badges", "subscriptions", "ads", "cityevents", "questions",
                  "reports", "edits", "alerts", "biz_features",
                  # v116-audit: real-data tables that the backup previously
                  # dropped. Parents before children (FKs); the wiper runs
                  # this list in reverse so children die first.
                  "orders", "order_items", "stories", "story_views",
                  "favorites", "follows", "haggles", "notifications",
                  # v153: هم‌تراز با export — جداول اعلان‌ها (فرزند؛ در وایپِ
                  # معکوس زودتر از والدین پاک می‌شوند).
                  "owner_notifications", "notif_prefs", "push_subs",
              # v156: فراخوان‌ها و درخواست‌های موجودی — بدون آن‌ها پشتیبانِ
              # «کامل» صندوق درخواست و آرشیو فراخوان را از دست می‌داد.
              "broadcasts", "stock_requests",
                  "points", "redemptions", "price_alerts", "price_history",
                  "flashdeals", "toplists", "trash",
                  # v178: کلید روزانهٔ بازدید یکتا (بدون FK؛ کنار آمار)
                  "page_viewers", "visits", "searches",
                  # v208: فرزندِ customers / owners — پس از والدها
                  "biz_reg_drafts", "owner_daily_summaries",
                  "order_receipts",   # v212: after orders (FK), wiped before it
                  "ai_usage", "ai_intents",   # v213: no FK
                  "ai_faq",   # v218: no FK
                  "spam_bans",   # v275: no FK — bans survive restore
                  "audit")


def import_all(payload):
    con = connect()
    con.execute("PRAGMA foreign_keys = OFF")
    try:
        for t in reversed(_RESTORE_ORDER):
            if t in payload:
                con.execute(f"DELETE FROM {t}")
        for t in _RESTORE_ORDER:
            if t not in payload:
                continue
            for row in payload[t]:
                # Only real SQL identifiers may become column names: the keys
                # come from an uploaded file, so a crafted key must never reach
                # the statement text. `t` itself is from the fixed list above.
                keys = [k for k in row.keys()
                        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", str(k))]
                if not keys:
                    continue
                cols = ", ".join(keys)
                qs = ", ".join("?" * len(keys))
                con.execute(f"INSERT OR REPLACE INTO {t}({cols}) VALUES({qs})",
                            [row[k] for k in keys])
        # v251: پشتیبان همان نامی را برمی‌گرداند که در لحظهٔ پشتیبان‌گیری بوده است.
        con.commit()
    finally:
        con.execute("PRAGMA foreign_keys = ON")
        con.close()


if __name__ == "__main__":
    init()
    print("database ready at", DB_PATH)
    print("owner token:", owner_token())


# ==========================================================================
#  OWNER ACCOUNTS  ·  OTP LOGIN  ·  SESSIONS
# ==========================================================================
import time as _time


def norm_phone(p):
    """0912 345 6789 / ۰۹۱۲... / +989... -> 09123456789"""
    p = translit(str(p or "")).strip()
    p = re.sub(r"[^\d+]", "", p)
    if p.startswith("+98"):
        p = "0" + p[3:]
    elif p.startswith("0098"):
        p = "0" + p[4:]
    elif p.startswith("98") and len(p) == 12:
        p = "0" + p[2:]
    return p


def valid_phone(p):
    p = norm_phone(p)
    return bool(re.fullmatch(r"09\d{9}", p))


def owner_by_phone(phone, create=False):
    phone = norm_phone(phone)
    con = connect()
    r = con.execute("SELECT * FROM owners WHERE phone=?", (phone,)).fetchone()
    if not r and create:
        con.execute("INSERT INTO owners(phone) VALUES(?)", (phone,))
        con.commit()
        r = con.execute("SELECT * FROM owners WHERE phone=?", (phone,)).fetchone()
    con.close()
    return dict(r) if r else None


def owner_by_id(oid):
    con = connect()
    r = con.execute("SELECT * FROM owners WHERE id=?", (oid,)).fetchone()
    con.close()
    return dict(r) if r else None


def owner_business_count(owner_id):
    r = _one("SELECT COUNT(*) AS n FROM businesses WHERE owner_id=?", (owner_id,))
    return int(r["n"] or 0) if r else 0


def owners(page=None, per=50):
    con = connect()
    sql = "SELECT * FROM owners ORDER BY id DESC"
    if page is not None:                      # v117/M3 (also kills the N+1)
        out = _page_result(con, sql, [], page, per)
        for o in out["rows"]:
            o["n_biz"] = con.execute(
                "SELECT COUNT(*) c FROM businesses WHERE owner_id=?",
                (o["id"],)).fetchone()["c"]
        con.close()
        return out
    rows = [dict(r) for r in con.execute(sql)]
    for o in rows:
        o["n_biz"] = con.execute("SELECT COUNT(*) c FROM businesses WHERE owner_id=?",
                                 (o["id"],)).fetchone()["c"]
    con.close()
    return rows


def delete_owner(oid):
    """Remove an account without touching their shops.

    Databases migrated from an early build have `owner_id` without an
    ON DELETE clause, so a plain DELETE trips the foreign key. Detach the
    businesses first and the operation is safe on every schema version.
    """
    con = connect()
    con.execute("UPDATE businesses SET owner_id=NULL WHERE owner_id=?", (oid,))
    con.execute("DELETE FROM claims WHERE owner_id=?", (oid,))
    con.execute("DELETE FROM sessions WHERE owner_id=?", (oid,))
    con.execute("UPDATE edits SET owner_id=NULL WHERE owner_id=?", (oid,))
    con.execute("DELETE FROM owners WHERE id=?", (oid,))
    con.commit()
    con.close()
    return True


def set_owner_status(oid, status):
    con = connect()
    con.execute("UPDATE owners SET status=? WHERE id=?", (status, oid))
    con.commit()
    con.close()


# ---------------------------------------------------------------- OTP
OTP_TTL = 180          # seconds a code stays valid
OTP_MAX_TRIES = 5


def otp_issue(phone):
    """Create (or reuse) a code. Returns (code, seconds_left, throttled)."""
    phone = norm_phone(phone)
    now = time.time()
    con = connect()
    con.execute("DELETE FROM otp WHERE expires < ?", (now,))
    row = con.execute("SELECT * FROM otp WHERE phone=?", (phone,)).fetchone()
    if row:
        # still valid -> do not send a second SMS, just report the wait
        con.close()
        return row["code"], int(row["expires"] - now), True
    code = "".join(secrets.choice("0123456789") for _ in range(5))
    con.execute("INSERT INTO otp(phone,code,tries,expires) VALUES(?,?,0,?)",
                (phone, code, now + OTP_TTL))
    con.commit()
    con.close()
    return code, OTP_TTL, False


def otp_check(phone, code):
    """-> (ok, message)"""
    phone = norm_phone(phone)
    now = time.time()
    con = connect()
    row = con.execute("SELECT * FROM otp WHERE phone=?", (phone,)).fetchone()
    if not row or row["expires"] < now:
        con.close()
        return False, "کد منقضی شده است. دوباره درخواست دهید."
    if row["tries"] >= OTP_MAX_TRIES:
        con.execute("DELETE FROM otp WHERE phone=?", (phone,))
        con.commit(); con.close()
        return False, "تعداد تلاش بیش از حد. دوباره درخواست دهید."
    if str(row["code"]) != str(code).strip():
        con.execute("UPDATE otp SET tries=tries+1 WHERE phone=?", (phone,))
        con.commit(); con.close()
        return False, "کد واردشده درست نیست."
    con.execute("DELETE FROM otp WHERE phone=?", (phone,))
    con.commit()
    con.close()
    return True, "ok"


# ---------------------------------------------------------------- v298 email OTP — like modern agent login agent requires email
EMAIL_OTP_TTL = 300

def _norm_email(e):
    return str(e or "").strip().lower()[:120]

def valid_email(e):
    e = _norm_email(e)
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", e)) and len(e) <= 120

def email_otp_issue(email):
    """Create (or reuse) a code for email. Returns (code, seconds_left, throttled)."""
    email = _norm_email(email)
    now = time.time()
    con = connect()
    con.execute("DELETE FROM email_otps WHERE expires < ?", (now,))
    row = con.execute("SELECT * FROM email_otps WHERE email=?", (email,)).fetchone()
    if row:
        con.close()
        return row["code"], int(row["expires"] - now), True
    code = "".join(secrets.choice("0123456789") for _ in range(6))
    con.execute("INSERT INTO email_otps(email,code,tries,expires) VALUES(?,?,0,?)",
                (email, code, now + EMAIL_OTP_TTL))
    con.commit()
    con.close()
    return code, EMAIL_OTP_TTL, False

def email_otp_check(email, code):
    """-> (ok, message)"""
    email = _norm_email(email)
    now = time.time()
    con = connect()
    row = con.execute("SELECT * FROM email_otps WHERE email=?", (email,)).fetchone()
    if not row or row["expires"] < now:
        con.close()
        return False, "کد منقضی شده است. دوباره درخواست دهید."
    if row["tries"] >= OTP_MAX_TRIES:
        con.execute("DELETE FROM email_otps WHERE email=?", (email,))
        con.commit(); con.close()
        return False, "تعداد تلاش بیش از حد. دوباره درخواست دهید."
    if str(row["code"]) != str(code).strip():
        con.execute("UPDATE email_otps SET tries=tries+1 WHERE email=?", (email,))
        con.commit(); con.close()
        return False, "کد واردشده درست نیست."
    con.execute("DELETE FROM email_otps WHERE email=?", (email,))
    con.commit()
    con.close()
    return True, "ok"

def customer_by_email(email):
    email = _norm_email(email)
    if not email:
        return None
    con = connect()
    r = con.execute("SELECT * FROM customers WHERE email=? AND email<>''", (email,)).fetchone()
    con.close()
    return dict(r) if r else None

def customer_by_phone(phone):
    phone = norm_phone(phone)
    if not phone:
        return None
    con = connect()
    r = con.execute("SELECT * FROM customers WHERE phone=?", (phone,)).fetchone()
    con.close()
    return dict(r) if r else None

def customer_by_email_create(email, name=""):
    """Find or create customer by email — for email login like modern agent login"""
    email = _norm_email(email)
    if not valid_email(email):
        return None
    existing = customer_by_email(email)
    if existing:
        return existing
    # create with fake phone to satisfy UNIQUE, store real email
    fake_phone = "e_" + hashlib.sha256(email.encode()).hexdigest()[:16]
    con = connect()
    try:
        con.execute("INSERT INTO customers(phone,email,name) VALUES(?,?,?)",
                    (fake_phone, email, (name or email.split("@")[0])[:60]))
        con.commit()
        r = con.execute("SELECT * FROM customers WHERE email=?", (email,)).fetchone()
        con.close()
        return dict(r) if r else None
    except sqlite3.IntegrityError:
        con.close()
        return customer_by_email(email)

def customer_set_email(cid, email):
    email = _norm_email(email)
    if not valid_email(email):
        return False
    con = connect()
    try:
        con.execute("UPDATE customers SET email=? WHERE id=?", (email, cid))
        con.commit()
        con.close()
        return True
    except sqlite3.IntegrityError:
        con.close()
        return False

def owner_by_email(email):
    email = _norm_email(email)
    if not email:
        return None
    con = connect()
    r = con.execute("SELECT * FROM owners WHERE email=? AND email<>''", (email,)).fetchone()
    con.close()
    return dict(r) if r else None


# ------------------------------------------------- v277: login verify lock
LOGIN_FAIL_LIMIT = 5          # تلاش ناموفق روی یک کلید => قفل
LOGIN_LOCK_SECS = 900.0       # ۱۵ دقیقه
LOGIN_FAIL_IP_LIMIT = 20      # سقف جدا برای کلید فقط-IP (ضد چرخش منبع)


def login_fail(key, limit=None):
    """Record one failed login verification for `key`.

    Returns (locked, fails). Always-on: the admin spam switch never weakens
    brute-force walls (same contract as rate_ok(always=True))."""
    limit = int(limit or LOGIN_FAIL_LIMIT)
    now = time.time()
    con = connect()
    try:
        r = con.execute("SELECT fails, locked_until FROM login_fails WHERE key=?",
                        (key,)).fetchone()
        fails = (r["fails"] if r else 0) + 1
        locked = now + LOGIN_LOCK_SECS if fails >= limit else                  (r["locked_until"] if r else 0)
        con.execute("INSERT INTO login_fails(key,fails,locked_until,updated)"
                    " VALUES(?,?,?,?)"
                    " ON CONFLICT(key) DO UPDATE SET fails=excluded.fails,"
                    " locked_until=excluded.locked_until, updated=excluded.updated",
                    (key, fails, locked, now))
        con.commit()
        return locked > now, fails
    finally:
        con.close()


def login_locked(key):
    """True when this key is inside its 15-minute verify lock."""
    try:
        r = _one("SELECT locked_until FROM login_fails WHERE key=?", (key,))
        return bool(r and r["locked_until"] > time.time())
    except Exception:
        return False


def login_fail_clear(key):
    _run("DELETE FROM login_fails WHERE key=?", (key,))


# ---------------------------------------------------------------- sessions
SESSION_TTL = 60 * 60 * 24 * 30       # 30 days


def session_new(owner_id):
    tok = secrets.token_urlsafe(24)
    con = connect()
    con.execute("DELETE FROM sessions WHERE expires < ?", (time.time(),))
    con.execute("INSERT INTO sessions(token,owner_id,expires) VALUES(?,?,?)",
                (tok, owner_id, time.time() + SESSION_TTL))
    con.execute("UPDATE owners SET last_login=datetime('now') WHERE id=?", (owner_id,))
    con.commit()
    con.close()
    return tok


def session_owner(token):
    if not token:
        return None
    con = connect()
    r = con.execute(
        "SELECT o.* FROM sessions s JOIN owners o ON o.id=s.owner_id "
        "WHERE s.token=? AND s.expires > ?", (token, time.time())).fetchone()
    con.close()
    if not r:
        return None
    d = dict(r)
    return None if d.get("status") == "blocked" else d


def session_kill(token):
    con = connect()
    con.execute("DELETE FROM sessions WHERE token=?", (token,))
    con.commit()
    con.close()


# ==========================================================================
#  OWNERSHIP  ·  CLAIMS
# ==========================================================================
def businesses_of(owner_id):
    """Every business owned by this account — including ones still waiting
    for admin approval, so the owner can see their submission was received."""
    con = connect()
    rows = [_biz_row(r) for r in con.execute(
        "SELECT * FROM businesses WHERE owner_id=? ORDER BY id DESC", (owner_id,))]
    for b in rows:
        b["rating"], b["nrated"], b["nreviews"] = rating_stats(con, b["id"])
    con.close()
    return rows


def owns(owner_id, biz_id):
    con = connect()
    r = con.execute("SELECT 1 FROM businesses WHERE id=? AND owner_id=?",
                    (biz_id, owner_id)).fetchone()
    con.close()
    return bool(r)


def set_business_owner(biz_id, owner_id):
    con = connect()
    con.execute("UPDATE businesses SET owner_id=? WHERE id=?", (owner_id, biz_id))
    con.commit()
    con.close()


def claim_add(biz_id, owner_id, note=""):
    # v172/#29: دکانِ ناموجود قبلاً FK → 500 می‌داد؛ حالا پیام تمیز.
    if not _rows("SELECT id FROM businesses WHERE id=?", (biz_id,)):
        return False, "این کسب‌وکار در سایت نیست."
    con = connect()
    dup = con.execute("SELECT 1 FROM claims WHERE biz_id=? AND owner_id=? AND status='pending'",
                      (biz_id, owner_id)).fetchone()
    if dup:
        con.close()
        return False, "درخواست شما قبلاً ثبت شده و در حال بررسی است."
    taken = con.execute("SELECT owner_id FROM businesses WHERE id=?", (biz_id,)).fetchone()
    if taken and taken["owner_id"]:
        con.close()
        return False, "این کسب‌وکار قبلاً توسط مالک دیگری تأیید شده است."
    con.execute("INSERT INTO claims(biz_id,owner_id,note) VALUES(?,?,?)",
                (biz_id, owner_id, note))
    con.commit()
    con.close()
    return True, "درخواست شما ثبت شد و پس از بررسی اطلاع‌رسانی می‌شود."


def claims(status=None, page=None, per=50):
    con = connect()
    q = ("SELECT c.*, b.name bizname, b.slug bizslug, o.phone, o.name ownername "
         "FROM claims c JOIN businesses b ON b.id=c.biz_id "
         "JOIN owners o ON o.id=c.owner_id")
    p = []
    if status:
        q += " WHERE c.status=?"
        p.append(status)
    q += " ORDER BY c.id DESC"
    if page is not None:                      # v117/M3
        out = _page_result(con, q, p, page, per)
        con.close()
        return out
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()
    return rows


def claim_decide(cid, approve):
    con = connect()
    r = con.execute("SELECT * FROM claims WHERE id=?", (cid,)).fetchone()
    if not r:
        con.close()
        return False
    if approve:
        con.execute("UPDATE businesses SET owner_id=? WHERE id=?", (r["owner_id"], r["biz_id"]))
        con.execute("UPDATE claims SET status='approved' WHERE id=?", (cid,))
        con.execute("UPDATE claims SET status='rejected' WHERE biz_id=? AND id<>? AND status='pending'",
                    (r["biz_id"], cid))
    else:
        con.execute("UPDATE claims SET status='rejected' WHERE id=?", (cid,))
    con.commit()
    con.close()
    b = business(bid=r["biz_id"]) or {}
    bname = b.get("name", "کسب‌وکار")
    if approve:
        owner_notify(r["owner_id"], "biz",
                     f"🎉 ادعای مالکیت «{bname}» تأیید شد؛ مدیریت آن با شماست.", "/my/businesses")
    else:
        owner_notify(r["owner_id"], "biz",
                     f"درخواست مالکیت «{bname}» رد شد. برای پیگیری تیکت بزنید.", "/my/tickets")
    return True


# ==========================================================================
#  ANALYTICS  (daily counters, tiny footprint)
# ==========================================================================
def track(biz_id, kind):
    if not biz_id:
        return
    day = datetime.date.today().isoformat()
    con = connect()
    con.execute("""INSERT INTO events(biz_id,kind,day,n) VALUES(?,?,?,1)
                   ON CONFLICT(biz_id,kind,day) DO UPDATE SET n = n + 1""",
                (biz_id, kind, day))
    con.commit()
    con.close()


def stats_for(biz_id, days=30):
    """Totals + a daily series ready to plot."""
    since = (datetime.date.today() - datetime.timedelta(days=days - 1)).isoformat()
    con = connect()
    tot = {r["kind"]: r["s"] for r in con.execute(
        "SELECT kind, SUM(n) s FROM events WHERE biz_id=? AND day>=? GROUP BY kind",
        (biz_id, since))}
    rows = {r["day"]: r["s"] for r in con.execute(
        "SELECT day, SUM(n) s FROM events WHERE biz_id=? AND kind='view' AND day>=? "
        "GROUP BY day", (biz_id, since))}
    con.close()
    series = []
    for i in range(days):
        d = (datetime.date.today() - datetime.timedelta(days=days - 1 - i)).isoformat()
        series.append((d, rows.get(d, 0)))
    return {
        "view": tot.get("view", 0), "phone": tot.get("phone", 0),
        "whatsapp": tot.get("whatsapp", 0), "route": tot.get("route", 0),
        "share": tot.get("share", 0), "series": series,
    }


def stats_totals(days=30):
    since = (datetime.date.today() - datetime.timedelta(days=days - 1)).isoformat()
    con = connect()
    tot = {r["kind"]: r["s"] for r in con.execute(
        "SELECT kind, SUM(n) s FROM events WHERE day>=? GROUP BY kind", (since,))}
    top = [dict(r) for r in con.execute(
        """SELECT b.name, b.slug, SUM(e.n) v FROM events e
           JOIN businesses b ON b.id=e.biz_id
           WHERE e.kind='view' AND e.day>=? GROUP BY e.biz_id
           ORDER BY v DESC LIMIT 8""", (since,))]
    con.close()
    tot["top"] = top
    return tot


# ==========================================================================
#  IMAGES
# ==========================================================================
def biz_images(biz_id):
    b = business(bid=biz_id)
    return b["images"] if b else []


def biz_images_set(biz_id, images):
    con = connect()
    con.execute("UPDATE businesses SET images=? WHERE id=?",
                (json.dumps(images, ensure_ascii=False), biz_id))
    con.commit()
    con.close()


# ==========================================================================
#  CATALOG  —  products, services, and custom/bespoke work
# ==========================================================================
KIND_LABEL = {"product": "محصول", "service": "خدمت", "custom": "کار سفارشی"}
PRICE_TYPE_LABEL = {"fixed": "قیمت ثابت", "from": "شروع از",
                    "call": "تماس بگیرید", "free": "رایگان"}


def item_price_text(it):
    """Human-readable price honouring the pricing mode."""
    pt = it.get("price_type") or "fixed"
    if pt == "call":
        return "قیمت با تماس"
    if pt == "free":
        return "رایگان"
    p = int(it.get("price") or 0)
    if p <= 0:
        return "قیمت با تماس"
    txt = fa_money(p) + " تومان"
    if it.get("unit"):
        txt += " / " + it["unit"]
    return ("از " + txt) if pt == "from" else txt


_FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹"


def fa_money(n):
    return f"{int(n):,}".replace(",", "٬").translate(
        str.maketrans("0123456789", _FA_DIGITS))


def parse_spec(raw):
    """«رنگ=قرمز؛ وزن=۲ کیلو» -> [(label, value), ...]

    Shopkeepers type this by hand on a phone, so accept both Persian and
    Latin separators and tolerate stray spaces."""
    out = []
    for part in re.split(r"[؛;\n]+", raw or ""):
        part = part.strip()
        if not part:
            continue
        if "=" in part:
            k, v = part.split("=", 1)
        elif ":" in part:
            k, v = part.split(":", 1)
        else:
            k, v = part, ""
        k, v = k.strip(), v.strip()
        if k:
            out.append((k, v))
    return out[:12]


def item_flags(d):
    """The little trust badges under a product — the thing Basalam and
    Digikala lean on hardest."""
    out = []
    if d.get("handmade"):
        out.append(("دست‌ساز", "award"))
    if d.get("returnable"):
        out.append(("قابل مرجوع", "refresh"))
    if d.get("warranty"):
        out.append((d["warranty"], "shield"))
    if d.get("prep_days"):
        out.append((f"آماده‌سازی {d['prep_days']}", "clock"))
    if d.get("delivery"):
        out.append((d["delivery"], "send"))
    return out


def bump_item_views(iid):
    _run("UPDATE items SET views=views+1 WHERE id=?", (iid,))


def _decorate_item(d):
    d["spec_list"] = parse_spec(d.get("spec"))
    d["flags"] = item_flags(d)
    """Attach everything the templates need, tolerating older rows."""
    try:
        imgs = json.loads(d.get("images") or "[]")
    except Exception:
        imgs = []
    if not imgs and d.get("image"):
        imgs = [d["image"]]
    d["image_list"] = imgs
    d["cover"] = imgs[0] if imgs else ""
    d["price_text"] = item_price_text(d)
    d["kind_label"] = KIND_LABEL.get(d.get("kind"), d.get("kind"))
    d["tag_list"] = [t.strip() for t in re.split(r"[،,]", d.get("tags") or "") if t.strip()]
    d["option_list"] = [t.strip() for t in re.split(r"[،,]", d.get("options") or "") if t.strip()]

    op = int(d.get("old_price") or 0)
    pr = int(d.get("price") or 0)
    d["has_discount"] = bool(op and pr and op > pr and d.get("price_type") in ("fixed", "from"))
    d["old_price_text"] = fa_money(op) + " تومان" if d["has_discount"] else ""
    d["discount_pct"] = round((op - pr) / op * 100) if d["has_discount"] else 0

    st = int(d.get("stock") if d.get("stock") is not None else -1)
    d["stock_tracked"] = st >= 0
    d["in_stock"] = (not d["stock_tracked"]) or st > 0
    return d


# ==========================================================================
#  LOCAL PRICE COMPARISON
#
#  Torob compares prices across national online shops. Nobody compares the
#  shops on your own street, because nobody has the data. A town directory
#  does — the same goods really are sold by several shops in one small place.
#
#  Matching is by normalised title, deliberately: shopkeepers will not type
#  barcodes or pick from a catalogue, but they do type the product name. The
#  normaliser folds Persian spelling variants, so «پنیر لیقوان» and
#  «پنیر لیقوان» with a different ZWNJ land in the same group.
#
#  Only 'product' items with a real fixed price take part. A service quoted
#  "from" or "on request" is not comparable and pretending otherwise would
#  produce a ranking that misleads.
# ==========================================================================
_PRICE_STOPWORDS = {
    "یک", "یه", "عدد", "بسته", "کیلو", "کیلویی", "گرم", "گرمی", "لیتر",
    "لیتری", "تایی", "عددی", "جعبه", "کارتن", "دانه", "کالای", "کالا",
    "محصول", "اصل", "اصلی", "درجه", "ویژه", "فروش", "قیمت", "تومان",
}


def price_key(title):
    """The grouping key two shops must agree on for a comparison to be fair.

    Filler words that shopkeepers sprinkle differently ('یک عدد', 'ویژه')
    are dropped, and the remaining words are sorted so word order does not
    split a group. Returns '' when nothing meaningful is left.
    """
    t = normalize_fa(title or "")
    t = re.sub(r"[^\w\s]", " ", t)
    words = [w for w in t.split() if w and w not in _PRICE_STOPWORDS]
    if not words:
        return ""
    return " ".join(sorted(words))


# --------------------------------------------------------------------------
#  v68: price memory + drop alerts (torob-style, stdlib-only)
# --------------------------------------------------------------------------
def _log_price(iid, price):
    con = connect()
    con.execute("INSERT INTO price_history(item_id, price, ts) VALUES(?,?,?)",
                (iid, int(price or 0), time.time()))
    # keep the trail short — 60 points is plenty for a sparkline
    con.execute("DELETE FROM price_history WHERE item_id=? AND ts NOT IN "
                "(SELECT ts FROM price_history WHERE item_id=? "
                " ORDER BY ts DESC LIMIT 60)", (iid, iid))
    con.commit()
    con.close()


def price_history(iid, n=24):
    con = connect()
    rows = con.execute("SELECT price, ts FROM price_history WHERE item_id=? "
                       "ORDER BY ts DESC LIMIT ?", (iid, n)).fetchall()
    con.close()
    return [(r["price"], r["ts"]) for r in reversed(rows)]


def price_trend(iid):
    """Percent change first->last over the stored trail; None when <2 pts."""
    h = price_history(iid)
    if len(h) < 2 or not h[0][0]:
        return None
    return round((h[-1][0] - h[0][0]) / h[0][0] * 100)


def sparkline_svg(values, w=132, h=34):
    """Dependency-free inline SVG polyline of a price trail."""
    values = [v for v in (values or []) if v is not None]   # F-017
    if len(values) < 2:
        return ""
    lo, hi = min(values), max(values)
    span = (hi - lo) or 1
    pts = []
    for i, v in enumerate(values):
        x = round(i * (w - 4) / (len(values) - 1)) + 2
        y = round(h - 4 - (v - lo) * (h - 8) / span)
        pts.append(f"{x},{y}")
    # v113: the trail colour follows the theme tokens via a class; a baked hex
    # here was exactly how one of the two modes ended up with a faint line.
    cls = "spark down" if values[-1] < values[0] else "spark up"
    return (f'<svg class="{cls}" viewBox="0 0 {w} {h}" width="{w}" height="{h}" '
            f'aria-hidden="true"><polyline points="{" ".join(pts)}" fill="none" '
            f'stroke="currentColor" stroke-width="2" stroke-linecap="round" '
            f'stroke-linejoin="round"/></svg>')


def alert_set(customer_id, key, title="", on=True):
    con = connect()
    if on:
        con.execute("INSERT OR IGNORE INTO price_alerts(customer_id, group_key, title) "
                    "VALUES(?,?,?)", (customer_id, key, title))
    else:
        con.execute("DELETE FROM price_alerts WHERE customer_id=? AND group_key=?",
                    (customer_id, key))
    con.commit()
    con.close()


def alert_keys(customer_id):
    con = connect()
    rows = con.execute("SELECT group_key FROM price_alerts WHERE customer_id=?",
                       (customer_id,)).fetchall()
    con.close()
    return {r["group_key"] for r in rows}


def _fire_price_alerts(key, title, new_price, old_price):
    if not key:
        return
    con = connect()
    subs = con.execute("SELECT customer_id FROM price_alerts WHERE group_key=?",
                       (key,)).fetchall()
    if subs:
        drop_pct = round((old_price - new_price) / old_price * 100) if old_price else 0
        text = (f"قیمت «{title}» {_fa(drop_pct)}٪ ارزان‌تر شد: "
                f"{fa_money(new_price)} تومان")
        for s in subs:
            con.execute("INSERT INTO notifications(customer_id, kind, text, link) "
                        "VALUES(?,?,?,?)",
                        (s["customer_id"], "info", text, f"/prices?key={key}"))
        con.execute("DELETE FROM price_alerts WHERE group_key=?", (key,))
        con.commit()
    con.close()


def comparable_items(min_shops=2, cat=None, term=""):
    """Group products sold by more than one shop, cheapest first.

    Returns a list of groups:
      {key, title, n, min, max, spread, spread_pct, offers[...]}
    where each offer carries the shop, its price and how far above the
    cheapest it sits.
    """
    con = connect()
    q = ("SELECT i.*, b.name bizname, b.slug bizslug, b.cat_slug, b.status "
         "FROM items i JOIN businesses b ON b.id=i.biz_id "
         "WHERE b.status='published' AND i.available=1 AND i.kind='product' "
         "AND IFNULL(i.spam_flag,0)=0 "
         "AND i.price_type='fixed' AND i.price > 0")
    p = []
    if cat:
        fam = category_family(cat)
        q += " AND b.cat_slug IN (%s)" % ",".join("?" * len(fam))
        p.extend(fam)
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()

    if term:
        t = normalize_fa(term)
        rows = [r for r in rows if t in normalize_fa(r["title"])]

    groups = {}
    for r in rows:
        k = price_key(r["title"])
        if not k:
            continue
        groups.setdefault(k, []).append(r)

    out = []
    for k, offers in groups.items():
        # one shop listing the same thing twice is not a comparison
        if len({o["biz_id"] for o in offers}) < min_shops:
            continue
        best_per_shop = {}
        for o in offers:
            cur = best_per_shop.get(o["biz_id"])
            if cur is None or o["price"] < cur["price"]:
                best_per_shop[o["biz_id"]] = o
        offers = sorted(best_per_shop.values(), key=lambda o: o["price"])

        lo = offers[0]["price"]
        hi = offers[-1]["price"]
        for o in offers:
            o["over_min"] = o["price"] - lo
            o["over_pct"] = round((o["price"] - lo) / lo * 100) if lo else 0
            o["is_cheapest"] = o["price"] == lo
            o["price_text"] = fa_money(o["price"]) + " تومان"
        out.append({
            "key": k,
            # the longest title reads best as a heading; the short ones are
            # usually abbreviations of the same thing
            "title": max((o["title"] for o in offers), key=len),
            "n": len(offers),
            "min": lo, "max": hi,
            "min_text": fa_money(lo) + " تومان",
            "max_text": fa_money(hi) + " تومان",
            "spread": hi - lo,
            "spread_text": fa_money(hi - lo) + " تومان",
            "spread_pct": round((hi - lo) / lo * 100) if lo else 0,
            "unit": offers[0].get("unit") or "",
            "offers": offers,
        })

    # biggest saving first — that is the number a shopper cares about
    out.sort(key=lambda g: (-g["spread"], -g["n"]))
    return out


def price_group(key):
    """One comparison group by its key, or None."""
    for g in comparable_items():
        if g["key"] == key:
            return g
    return None


def price_stats():
    groups = comparable_items()
    return {
        "groups": len(groups),
        "offers": sum(g["n"] for g in groups),
        "best_saving": max((g["spread"] for g in groups), default=0),
        "best_saving_text": fa_money(max((g["spread"] for g in groups),
                                         default=0)) + " تومان",
    }


def items(biz_id=None, kind=None, only_available=False, include_flagged=False):
    # v278: آیتم‌های spam_flag=1 از دید عمومی پنهان‌اند (نگه برای بررسی)؛
    # کاتالوگ مالک/مدیر با include_flagged=True همه را می‌بیند.
    con = connect()
    q = ("SELECT i.*, b.name bizname, b.slug bizslug FROM items i "
         "JOIN businesses b ON b.id=i.biz_id WHERE 1=1")
    if not include_flagged:
        q += " AND IFNULL(i.spam_flag,0)=0"
    p = []
    if biz_id:
        q += " AND i.biz_id=?"; p.append(biz_id)
    if kind:
        q += " AND i.kind=?"; p.append(kind)
    if only_available:
        q += " AND i.available=1"
    q += " ORDER BY i.featured DESC, i.sort, i.id DESC"
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()
    return [_decorate_item(r) for r in rows]


# ==========================================================================
#  چانه‌زنی — structured haggling
#
#  The rules encoded here are the ones a bazaar already runs on:
#   · the shopkeeper opts in per product, and sets a private floor
#   · an offer at or above the floor can be accepted instantly, which is
#     what makes this worth a shopkeeper's time
#   · an offer below the floor is not rejected outright — it is countered,
#     because "no" ends a sale and a counter-price continues it
#   · every round is a row, so nobody can quietly change an earlier number
#   · offers expire, so a shopkeeper is not held to last month's price
# ==========================================================================
HAGGLE_TTL_HOURS = 48
HAGGLE_MAX_ROUNDS = 6


def haggle_settings():
    s = get_settings()
    def _i(k, d):
        try:
            return int(s.get(k, d))
        except Exception:
            return d
    return {
        # v65: haggling is OFF by default — the owner turns it on from the
        # panel when they actually want it. Nothing is deleted, the UI just
        # stops offering it until it is enabled again.
        "enabled": s.get("haggle_enabled", "0") == "1",
        "ttl": _i("haggle_ttl_hours", HAGGLE_TTL_HOURS),
        "max_rounds": _i("haggle_max_rounds", HAGGLE_MAX_ROUNDS),
        "min_pct": _i("haggle_min_pct", 50),   # refuse insulting lowballs
    }


def haggle_allowed(it):
    """Is this product open to offers? Needs a real price to haggle against."""
    if not it:
        return False
    if not haggle_settings()["enabled"]:
        return False
    return bool(it.get("haggle")) and it.get("price_type") == "fixed" \
        and int(it.get("price") or 0) > 0 and int(it.get("available") or 0) == 1


def _haggle_row(r):
    d = dict(r)
    d["offer_text"] = fa_money(d.get("offer") or 0) + " تومان"
    d["is_buyer"] = d.get("side") == "buyer"
    return d


def haggle_thread(token=None, root_id=None):
    """A whole negotiation, oldest first."""
    con = connect()
    if token:
        root = con.execute("SELECT * FROM haggles WHERE token=? AND parent IS NULL",
                           (token,)).fetchone()
    else:
        root = con.execute("SELECT * FROM haggles WHERE id=?", (root_id,)).fetchone()
    if not root:
        con.close()
        return []
    rows = [dict(root)]
    frontier = [root["id"]]
    seen = {root["id"]}
    while frontier:
        marks = ",".join("?" * len(frontier))
        kids = con.execute(
            f"SELECT * FROM haggles WHERE parent IN ({marks}) ORDER BY id", frontier).fetchall()
        frontier = []
        for k in kids:
            if k["id"] in seen:
                continue
            seen.add(k["id"])
            rows.append(dict(k))
            frontier.append(k["id"])
    con.close()
    rows.sort(key=lambda r: r["id"])
    return [_haggle_row(r) for r in rows]


def haggles(biz_id=None, status=None, item_id=None, roots_only=True):
    con = connect()
    q = ("SELECT h.*, b.name bizname, b.slug bizslug, i.title itemtitle, "
         "i.price itemprice, i.floor_price "
         "FROM haggles h JOIN businesses b ON b.id=h.biz_id "
         "LEFT JOIN items i ON i.id=h.item_id WHERE 1=1")
    p = []
    if biz_id:
        q += " AND h.biz_id=?"; p.append(biz_id)
    if item_id:
        q += " AND h.item_id=?"; p.append(item_id)
    if status:
        q += " AND h.status=?"; p.append(status)
    if roots_only:
        q += " AND h.parent IS NULL"
    q += " ORDER BY h.id DESC"
    rows = [_haggle_row(r) for r in con.execute(q, p)]
    con.close()
    return rows


def haggle(hid):
    con = connect()
    r = con.execute(
        "SELECT h.*, b.name bizname, b.slug bizslug, b.owner_id, "
        "i.title itemtitle, i.price itemprice, i.floor_price "
        "FROM haggles h JOIN businesses b ON b.id=h.biz_id "
        "LEFT JOIN items i ON i.id=h.item_id WHERE h.id=?", (hid,)).fetchone()
    con.close()
    return _haggle_row(r) if r else None


def expire_haggles():
    """Offers past their window stop being binding."""
    con = connect()
    con.execute("UPDATE haggles SET status='expired' "
                "WHERE status IN ('open','countered') AND expires<>'' "
                "AND expires < datetime('now')")
    n = con.total_changes
    con.commit()
    con.close()
    return n


def make_offer(biz_id, item_id, name, phone, offer, qty=1, note="",
               parent=None, side="buyer", customer_id=None):
    """Record one round. Returns (id, token, verdict) where verdict is what
    the system did automatically: 'accepted', 'countered' or 'pending'.

    The auto-accept is the point of the whole feature. A shopkeeper who has
    already said "I'll take 90,000 for this" should not have to be at their
    phone for the sale to happen.
    """
    cfg = haggle_settings()
    it = item(item_id) if item_id else None
    offer = int(offer or 0)

    token = secrets.token_urlsafe(12) if parent is None else ""
    if parent is not None:
        root = haggle(parent)
        while root and root.get("parent"):
            root = haggle(root["parent"])
        token = (root or {}).get("token", "")

    expires = None
    con = connect()
    cur = con.execute(
        "INSERT INTO haggles(biz_id,item_id,parent,side,name,phone,offer,qty,note,"
        "token,expires,customer_id) VALUES(?,?,?,?,?,?,?,?,?,?,"
        "datetime('now', ?),?)",
        (biz_id, item_id or None, parent, side, name, phone, offer,
         max(1, int(qty or 1)), note, token, f"+{cfg['ttl']} hours", customer_id))
    hid = cur.lastrowid
    con.commit()
    con.close()

    verdict = "pending"
    if side == "buyer" and it:
        floor = int(it.get("floor_price") or 0)
        listed = int(it.get("price") or 0)
        if floor and offer >= floor:
            set_haggle_status(hid, "accepted")
            verdict = "accepted"
        elif floor and listed and offer < listed * cfg["min_pct"] / 100:
            # too low to be a serious offer; counter at the floor rather than
            # slam the door — a counter keeps the conversation alive
            set_haggle_status(hid, "countered")
            make_offer(biz_id, item_id, "", "", floor, qty,
                       "پیشنهاد فروشنده (خودکار): کمترین قیمت ممکن برای این کالا.",
                       parent=hid, side="seller")
            verdict = "countered"

    if side == "buyer" and parent is None and verdict == "pending":
        _owner_notify_biz(biz_id, "social",
                          "🤝 پیشنهاد چانهٔ جدیدی برای کالای شما ثبت شد.", "/my/offers")
    log("haggle.offer", f"biz {biz_id} item {item_id}: {offer} -> {verdict}")
    return hid, token, verdict


def set_haggle_status(hid, status):
    con = connect()
    con.execute("UPDATE haggles SET status=? WHERE id=?", (status, hid))
    con.commit()
    con.close()
    log("haggle.status", f"{hid}: {status}")


def haggle_stats(biz_id=None):
    con = connect()
    q = "SELECT status, COUNT(*) c FROM haggles WHERE parent IS NULL"
    p = []
    if biz_id:
        q += " AND biz_id=?"; p.append(biz_id)
    q += " GROUP BY status"
    by = {r["status"]: r["c"] for r in con.execute(q, p)}
    con.close()
    total = sum(by.values())
    won = by.get("accepted", 0)
    return {"total": total, "open": by.get("open", 0),
            "countered": by.get("countered", 0), "accepted": won,
            "declined": by.get("declined", 0), "expired": by.get("expired", 0),
            "rate": round(won / total * 100) if total else 0}


def item(iid):
    con = connect()
    r = con.execute("SELECT i.*, b.name bizname, b.slug bizslug, b.owner_id "
                    "FROM items i JOIN businesses b ON b.id=i.biz_id "
                    "WHERE i.id=?", (iid,)).fetchone()
    con.close()
    if not r:
        return None
    return _decorate_item(dict(r))


def item_title_dup(biz_id, title, exclude_id=None):
    """v278: آیا عنوان (نرمال‌شده) در همین کسب‌وکار تکراری است؟"""
    _fa = "۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩"
    def norm(t):
        t = (t or "").replace("\u200c", " ").lower()
        t = t.translate({ord(c): ord("0") + (i % 10) for i, c in enumerate(_fa)})
        return re.sub(r"\s+", " ", t).strip()
    n = norm(title)
    if len(n) < 3:
        return False
    con = connect()
    rows = con.execute("SELECT id,title FROM items WHERE biz_id=?",
                       (int(biz_id),)).fetchall()
    con.close()
    for r in rows:
        if exclude_id and r["id"] == int(exclude_id):
            continue
        if norm(r["title"]) == n:
            return True
    return False


def item_set_spam_flag(iid, flag):
    _run("UPDATE items SET spam_flag=? WHERE id=?", (1 if flag else 0, int(iid)))


def save_item(data, iid=None, dup_hold=False):
    _pagecache_drop()
    fields = ("biz_id", "kind", "title", "descr", "price", "price_type",
              "unit", "duration", "image", "images", "old_price", "stock",
              "code", "min_order", "options", "note",
              "brand", "warranty", "prep_days", "delivery", "handmade",
              "returnable", "bulk_price", "video", "spec", "weight",
              "haggle", "floor_price",
              "tags", "available", "featured", "sort")
    vals = {}
    for f in fields:
        if f not in data:
            continue
        v = data[f]
        if f in ("available", "featured", "handmade", "returnable", "haggle"):
            v = int(bool(int(v or 0)))
        elif f in ("price", "sort", "biz_id", "old_price", "floor_price"):
            v = int(re.sub(r"[^\d]", "", str(v) or "0") or 0)
        elif f == "stock":
            raw = str(v).strip()
            v = -1 if raw == "" else int(re.sub(r"[^\d]", "", raw) or 0)
        elif f == "images" and not isinstance(v, str):
            v = json.dumps(v, ensure_ascii=False)
        vals[f] = v
    old_price = None
    if iid:
        con = connect()
        row = con.execute("SELECT price, title FROM items WHERE id=?", (iid,)).fetchone()
        old_price = row["price"] if row else None
        title = row["title"] if row else ""
        con.close()
    if dup_hold and not iid and item_title_dup(vals.get("biz_id"), vals.get("title")):
        vals["spam_flag"] = 1          # v278: عنوان تکراری => نگه برای بررسی
    con = connect()
    if iid:
        sets = ", ".join(f"{k}=?" for k in vals)
        con.execute(f"UPDATE items SET {sets} WHERE id=?", list(vals.values()) + [iid])
    else:
        cols = ", ".join(vals)
        qs = ", ".join("?" * len(vals))
        con.execute(f"INSERT INTO items({cols}) VALUES({qs})", list(vals.values()))
        iid = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
        title = vals.get("title", "")
    con.commit()
    con.close()
    # v68: price memory + drop alerts (torob-style)
    new_price = vals.get("price")
    if new_price is not None:
        if old_price is None:
            _log_price(iid, new_price)          # first sighting
        elif new_price != old_price:
            _log_price(iid, new_price)
            if new_price < old_price and title:
                _fire_price_alerts(price_key(title), title, new_price, old_price)
    return iid


def delete_item(iid):
    _pagecache_drop()
    row = _one("SELECT * FROM items WHERE id=?", (iid,))
    if row:
        trash_put("item", iid, row["biz_id"], row["title"] or "", dict(row))
    con = connect()
    con.execute("DELETE FROM items WHERE id=?", (iid,))
    con.commit()
    con.close()


def items_count(biz_id, featured_only=False):
    con = connect()
    q = "SELECT COUNT(*) c FROM items WHERE biz_id=?"
    if featured_only:
        q += " AND featured=1 AND available=1"
    n = con.execute(q, (biz_id,)).fetchone()["c"]
    con.close()
    return n


def search_items(term="", kind=""):   # v278: spam_flag excluded below
    rows = items(kind=kind or None, only_available=True)
    if term:
        t = normalize_fa(term)
        rows = [r for r in rows
                if t in normalize_fa(f"{r['title']} {r['descr']} {r['tags']} {r['bizname']}")]
    return rows


# ---------------------------------------------------------------- inquiries
def inquiries(biz_id=None, status=None, page=None, per=50):
    con = connect()
    q = ("SELECT q.*, b.name bizname, b.slug bizslug, i.title itemtitle "
         "FROM inquiries q JOIN businesses b ON b.id=q.biz_id "
         "LEFT JOIN items i ON i.id=q.item_id WHERE 1=1")
    p = []
    if biz_id:
        q += " AND q.biz_id=?"; p.append(biz_id)
    if status:
        q += " AND q.status=?"; p.append(status)
    q += " ORDER BY q.id DESC"
    if page is not None:                      # v117/M3
        out = _page_result(con, q, p, page, per)
        con.close()
        return out
    rows = [dict(r) for r in con.execute(q, p)]
    con.close()
    return rows


def inquiry(qid):
    """Single inquiry row (id -> biz_id), so access checks are one lookup."""
    con = connect()
    r = con.execute("SELECT * FROM inquiries WHERE id=?", (qid,)).fetchone()
    con.close()
    return dict(r) if r else None


def add_inquiry(biz_id, name, phone="", body="", item_id=None, budget=""):
    con = connect()
    con.execute("""INSERT INTO inquiries(biz_id,item_id,name,phone,body,budget)
                   VALUES(?,?,?,?,?,?)""",
                (biz_id, item_id or None, name, phone or "", body, budget))
    con.commit()
    con.close()
    _owner_notify_biz(biz_id, "order", f"درخواست قیمت تازه ثبت شد: {name}.", "/my/inquiries")


def update_inquiry(qid, **kw):
    if not kw:
        return
    con = connect()
    sets = ", ".join(f"{k}=?" for k in kw)
    con.execute(f"UPDATE inquiries SET {sets} WHERE id=?", list(kw.values()) + [qid])
    con.commit()
    con.close()


def delete_inquiry(qid):
    con = connect()
    con.execute("DELETE FROM inquiries WHERE id=?", (qid,))
    con.commit()
    con.close()


def item_images(iid):
    it = item(iid)
    return it["image_list"] if it else []


def item_images_set(iid, images):
    con = connect()
    con.execute("UPDATE items SET images=?, image=? WHERE id=?",
                (json.dumps(images, ensure_ascii=False),
                 images[0] if images else "", iid))
    con.commit()
    con.close()


# ==========================================================================
#  DUPLICATE DETECTION
#  Warn the applicant *while they type* that a business already exists,
#  so the same shop is not submitted over and over.
# ==========================================================================
def _digits_only(v):
    return re.sub(r"\D", "", translit(str(v or "")))


# Words that appear in half the shop names in town. Counting them as a match
# made "نانوایی سحر" look like "نانوایی رضا", so they are ignored when there
# is anything distinctive left to compare.
_STOPWORDS = {
    "فروشگاه", "فروشگاهی", "شرکت", "گروه", "مرکز", "مجتمع", "بازار", "بازارچه",
    "شعبه", "نمایندگی", "کارگاه", "خدمات", "تولیدی", "صنایع", "بنگاه",
    "سوپر", "سوپرمارکت", "رستوران", "کافه", "قنادی", "نانوایی", "تعمیرگاه",
    "املاک", "داروخانه", "آرایشگاه", "پیرایش", "کلینیک", "مطب", "دفتر",
    "نجف", "نجفاباد", "اباد", "ایران", "اصفهان", "شهر", "و", "در", "با",
}


def _sim(a, b):
    """
    Token similarity tolerant of Persian spelling, 0..1.
    Uses the *smaller* token set as the denominator so that
    «سوپرمارکت ولیعصر شعبه دو» still matches «سوپرمارکت ولیعصر».
    """
    ta = {t for t in normalize_fa(a).split() if len(t) > 1}
    tb = {t for t in normalize_fa(b).split() if len(t) > 1}
    if not ta or not tb:
        return 0.0
    # Drop the generic words, but only while a distinctive part survives on
    # both sides — otherwise «نانوایی» vs «نانوایی» would score zero.
    sa, sb = ta - _STOPWORDS, tb - _STOPWORDS
    if sa and sb:
        ta, tb = sa, sb
    return len(ta & tb) / min(len(ta), len(tb))


def find_duplicates(name="", phone="", address="", exclude_id=None,
                        exclude_ids=None):
    """
    Return [{business, reason, field, strength}] for anything that looks like
    the same shop. `strength` is 'exact' (block) or 'maybe' (warn).
    """
    con = connect()
    rows = [_biz_row(r) for r in con.execute("SELECT * FROM businesses")]
    con.close()

    nname = normalize_fa(name)
    nphone = _digits_only(phone)
    naddr = normalize_fa(address)

    out = []
    _skip = set(exclude_ids or [])
    for b in rows:
        if exclude_id and b["id"] == exclude_id:
            continue
        # v152: دکان‌های خودِ کاربرِ واردشده هرگز «تکرار» حساب نمی‌شوند — یک
        # مالک می‌تواند چند دکان با یک شماره داشته باشد (logins پیوند میدهند).
        if b["id"] in _skip:
            continue

        # Report EVERY field that matches, so the warning appears under each
        # one the applicant is typing in — not just the first hit.
        matches = []
        if nphone and len(nphone) >= 7:
            if _digits_only(b.get("phone")) == nphone:
                matches.append(("این شمارهٔ تماس قبلاً ثبت شده است.", "phone", "exact"))
            elif _digits_only(b.get("whatsapp")) == nphone:
                matches.append(("این شماره به‌عنوان واتساپ ثبت شده است.", "phone", "exact"))

        if nname:
            if normalize_fa(b["name"]) == nname:
                matches.append(("کسب‌وکاری دقیقاً با همین نام وجود دارد.", "name", "exact"))
            elif _sim(name, b["name"]) >= 0.75:
                matches.append(("نام بسیار شبیه یک کسب‌وکار ثبت‌شده است.", "name", "maybe"))

        if naddr and len(naddr) > 12 and _sim(address, b.get("address") or "") >= 0.7:
            matches.append(("نشانی بسیار شبیه یک کسب‌وکار ثبت‌شده است.", "address", "maybe"))

        for reason, field, strength in matches:
            out.append({
                "id": b["id"], "name": b["name"], "slug": b["slug"],
                "address": b.get("address") or "", "phone": b.get("phone") or "",
                "status": b["status"], "claimed": bool(b.get("owner_id")),
                "reason": reason, "field": field, "strength": strength,
            })

    out.sort(key=lambda x: 0 if x["strength"] == "exact" else 1)
    return out


def businesses_for_phone(phone):
    """Everything registered with this number — used to auto-link on login."""
    nphone = _digits_only(phone)
    if not nphone or len(nphone) < 7:
        return []
    con = connect()
    rows = [_biz_row(r) for r in con.execute("SELECT * FROM businesses")]
    con.close()
    return [b for b in rows
            if _digits_only(b.get("phone")) == nphone
            or _digits_only(b.get("whatsapp")) == nphone]


def link_orphans_to_owner(owner_id, phone):
    """
    When someone logs in, attach any unclaimed business submitted with their
    phone number. This is what makes 'I registered but see nothing' go away.
    """
    linked = 0
    con = connect()
    for b in businesses_for_phone(phone):
        if not b.get("owner_id"):
            con.execute("UPDATE businesses SET owner_id=? WHERE id=?", (owner_id, b["id"]))
            linked += 1
    con.commit()
    con.close()
    return linked


# ==========================================================================
#  ADMIN LISTING  —  search + sort + pagination
# ==========================================================================
def admin_businesses(q="", status="", cat="", page=1, per=25, sort="newest"):
    """Server-side search/filter/paging so the panel stays fast at scale."""
    con = connect()
    where, params = ["1=1"], []
    if status:
        where.append("b.status=?"); params.append(status)
    if cat:
        fam = category_family(cat)
        where.append("b.cat_slug IN (%s)" % ",".join("?" * len(fam)))
        params.extend(fam)

    sql_from = "FROM businesses b WHERE " + " AND ".join(where)
    rows = [_biz_row(r) for r in con.execute(f"SELECT b.* {sql_from}", params)]

    if q:
        t = normalize_fa(q)
        rows = [r for r in rows if t in normalize_fa(
            f"{r['name']} {r.get('descr','')} {r.get('address','')} "
            f"{r.get('phone','')} {r.get('tags','')}")]

    for r in rows:
        r["rating"], r["nrated"], r["nreviews"] = rating_stats(con, r["id"])
    con.close()

    keys = {
        "newest": lambda r: -r["id"],
        "oldest": lambda r: r["id"],
        "name":   lambda r: r["name"] or "",
        "views":  lambda r: -(r["views"] or 0),
        "rating": lambda r: -(r["rating"] or 0),
    }
    rows.sort(key=keys.get(sort, keys["newest"]))

    total = len(rows)
    pages = max(1, (total + per - 1) // per)
    page = max(1, min(page, pages))
    start = (page - 1) * per
    return {"rows": rows[start:start + per], "total": total,
            "page": page, "pages": pages, "per": per}


def bulk_business(ids, action, value=""):
    """Apply one action to many businesses at once."""
    _pagecache_drop()
    if not ids:
        return 0
    con = connect()
    marks = ",".join("?" * len(ids))
    n = 0
    if action == "status" and value in ("published", "pending", "hidden", "rejected"):
        con.execute(f"UPDATE businesses SET status=?, published_once=CASE WHEN ?='published' THEN 1 ELSE published_once END WHERE id IN ({marks})",
                    [value, value] + list(ids))
        n = len(ids)
    elif action in ("featured", "verified"):
        con.execute(f"UPDATE businesses SET {action}=? WHERE id IN ({marks})",
                    [1 if value == "1" else 0] + list(ids))
        n = len(ids)
    elif action == "category" and value:
        con.execute(f"UPDATE businesses SET cat_slug=? WHERE id IN ({marks})",
                    [value] + list(ids))
        n = len(ids)
    elif action == "delete":
        con.execute(f"DELETE FROM businesses WHERE id IN ({marks})", list(ids))
        n = len(ids)
    con.commit()
    con.close()
    return n


# ---------------------------------------------------------------- CSV
CSV_COLUMNS = ["name", "cat_slug", "descr", "phone", "whatsapp", "address",
               "lat", "lng", "tags", "instagram", "telegram", "eitaa", "bale", "soroush", "rubika", "website",
               "status", "featured", "verified"]


def _csv_cell(v):
    """Neutralise spreadsheet formula injection. A cell whose first character
    makes Excel/Sheets treat it as a formula (= + - @ tab CR) is prefixed with
    a single quote so it stays inert text. (Security fix.)"""
    s = "" if v is None else str(v)
    if s and (s[0] in ("=", "+", "-", "@") or s[0] in ("\t", "\r", "\n")):
        return "'" + s
    return s


def export_csv():
    import csv, io
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(CSV_COLUMNS)
    for b in businesses(status=None, order="newest"):
        w.writerow([_csv_cell(b.get(c, "")) for c in CSV_COLUMNS])
    return "\ufeff" + buf.getvalue()          # BOM so Excel reads Persian


# ==========================================================================
#  TICKETS  --  two-way support conversations
#
#  The old contact form posted into a void: no status, no reply, no thread.
#  A shopkeeper who had paid and was waiting for a feature to be unlocked
#  had no way to ask "did you get my money?" except phoning. That is the
#  single most common real question this directory will receive, so it
#  deserves a real inbox on both sides.
# ==========================================================================
TICKET_TOPICS = [
    ("payment", "پرداخت و اشتراک"),
    ("unlock",  "باز کردن قابلیت"),
    ("edit",    "ویرایش اطلاعات کسب‌وکار"),
    ("bug",     "مشکل فنی سایت"),
    ("other",   "موضوع دیگر"),
]
TICKET_STATUS = {
    "open":     ("badge-warn",    "باز — در انتظار پاسخ"),
    "answered": ("badge-info",    "پاسخ داده شد"),
    "waiting":  ("badge-neutral", "در انتظار شما"),
    "closed":   ("badge-open",    "بسته شد"),
}
TICKET_PRIORITY = {"low": "کم", "normal": "عادی", "high": "فوری"}


def _ticket_row(r):
    d = dict(r)
    d["topic_label"] = dict(TICKET_TOPICS).get(d.get("topic"), d.get("topic"))
    cls, lbl = TICKET_STATUS.get(d.get("status"), ("badge-neutral", d.get("status")))
    d["status_cls"], d["status_label"] = cls, lbl
    d["priority_label"] = TICKET_PRIORITY.get(d.get("priority"), d.get("priority"))
    return d


def create_ticket(subject, body, name="", phone="", owner_id=None,
                  biz_id=None, topic="other", priority="normal", attachment=None,
                  spam_flag=0):
    """Open a ticket and store its first text and/or private attachment."""
    text = (body or "").strip()
    if not text and not attachment:
        return None, None
    token = secrets.token_urlsafe(12)
    con = connect()
    try:
        cur = con.execute(
            "INSERT INTO tickets(owner_id,biz_id,name,phone,subject,topic,priority,token,spam_flag) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (owner_id,biz_id,name,phone,subject.strip()[:160],topic,priority,token,spam_flag))
        tid=cur.lastrowid
        cur=con.execute("INSERT INTO ticket_msgs(ticket_id,side,body) VALUES(?,'user',?)",(tid,text))
        mid=cur.lastrowid
        if attachment:
            con.execute("INSERT INTO ticket_attachments(msg_id,stored_name,original_name,mime,size,kind) VALUES(?,?,?,?,?,?)",
                        (mid,attachment['stored_name'],attachment['original_name'][:120],attachment['mime'],int(attachment['size']),attachment['kind']))
        con.commit()
    except Exception:
        con.rollback(); con.close(); return None,None
    con.close(); log("ticket.new",f"{tid}: {subject[:50]}"); return tid,token


def ticket(tid=None, token=None):
    con = connect()
    if token:
        r = con.execute(
            "SELECT t.*, b.name bizname, b.slug bizslug, o.phone ownerphone "
            "FROM tickets t LEFT JOIN businesses b ON b.id=t.biz_id "
            "LEFT JOIN owners o ON o.id=t.owner_id WHERE t.token=?",
            (token,)).fetchone()
    else:
        r = con.execute(
            "SELECT t.*, b.name bizname, b.slug bizslug, o.phone ownerphone "
            "FROM tickets t LEFT JOIN businesses b ON b.id=t.biz_id "
            "LEFT JOIN owners o ON o.id=t.owner_id WHERE t.id=?",
            (tid,)).fetchone()
    con.close()
    return _ticket_row(r) if r else None


def tickets(owner_id=None, status=None, topic=None, q="", page=None, per=50):
    con = connect()
    sql = ("SELECT t.*, b.name bizname, "
           "(SELECT COUNT(*) FROM ticket_msgs WHERE ticket_id=t.id) nmsg "
           "FROM tickets t LEFT JOIN businesses b ON b.id=t.biz_id WHERE 1=1")
    p = []
    if owner_id:
        sql += " AND t.owner_id=?"; p.append(owner_id)
    if status:
        sql += " AND t.status=?"; p.append(status)
    if topic:
        sql += " AND t.topic=?"; p.append(topic)
    # open first, then most recently touched
    sql += (" ORDER BY CASE t.status WHEN 'open' THEN 0 WHEN 'waiting' THEN 1 "
            "WHEN 'answered' THEN 2 ELSE 3 END, t.updated DESC")
    rows = [_ticket_row(r) for r in con.execute(sql, p)]
    con.close()
    if q:
        nq = normalize_fa(q)
        rows = [r for r in rows
                if nq in normalize_fa(f"{r['subject']} {r.get('name','')} "
                                      f"{r.get('phone','')} {r.get('bizname') or ''}")]
    if page is not None:                      # v117/M3
        return _page_slice(rows, page, per)
    return rows


def ticket_msgs(tid):
    con=connect(); rows=[dict(r) for r in con.execute(
      "SELECT m.*,a.id attachment_id,a.original_name file_name,a.mime file_type,a.size file_size,a.kind file_kind "
      "FROM ticket_msgs m LEFT JOIN ticket_attachments a ON a.msg_id=m.id WHERE m.ticket_id=? ORDER BY m.id",(tid,))];con.close();return rows


def ticket_attachment(aid):
    con=connect();r=con.execute("SELECT a.*,m.ticket_id,t.owner_id,t.token FROM ticket_attachments a JOIN ticket_msgs m ON m.id=a.msg_id JOIN tickets t ON t.id=m.ticket_id WHERE a.id=?",(aid,)).fetchone();con.close();return dict(r) if r else None


def ticket_attachment_names():
    con=connect();rows=[r['stored_name'] for r in con.execute("SELECT stored_name FROM ticket_attachments")];con.close();return rows


def ticket_reply(tid, body, side="admin", attachment=None):
    """Add text/file; return message id. The other side receives unread."""
    text=(body or '').strip()
    if not text and not attachment:return False
    con=connect()
    try:
        cur=con.execute("INSERT INTO ticket_msgs(ticket_id,side,body) VALUES(?,?,?)",(tid,side,text));mid=cur.lastrowid
        if attachment:
            con.execute("INSERT INTO ticket_attachments(msg_id,stored_name,original_name,mime,size,kind) VALUES(?,?,?,?,?,?)",
                        (mid,attachment['stored_name'],attachment['original_name'][:120],attachment['mime'],int(attachment['size']),attachment['kind']))
        if side=='admin': con.execute("UPDATE tickets SET status='answered',unread_user=1,unread_admin=0,updated=datetime('now') WHERE id=?",(tid,))
        else: con.execute("UPDATE tickets SET status='open',unread_admin=1,unread_user=0,updated=datetime('now') WHERE id=?",(tid,))
        con.commit()
    except Exception: con.rollback();con.close();return False
    con.close();log('ticket.reply',f'{tid} by {side}')
    if side == 'admin':
        t = _one("SELECT owner_id, subject FROM tickets WHERE id=?", (tid,))
        if t and t.get("owner_id"):
            owner_notify(t["owner_id"], "ticket",
                         f"پاسخ پشتیبانی به تیکت «{str(t.get('subject') or '')[:40]}»", "/my/tickets")
    return mid


def set_ticket(tid, **kw):
    fields = {k: v for k, v in kw.items()
              if k in ("status", "priority", "topic", "unread_admin", "unread_user")}
    if not fields:
        return
    con = connect()
    sets = ", ".join(f"{k}=?" for k in fields)
    con.execute(f"UPDATE tickets SET {sets}, updated=datetime('now') WHERE id=?",
                list(fields.values()) + [tid])
    con.commit()
    con.close()


def delete_ticket(tid):
    con = connect()
    con.execute("DELETE FROM ticket_msgs WHERE ticket_id=?", (tid,))
    con.execute("DELETE FROM tickets WHERE id=?", (tid,))
    con.commit()
    con.close()
    log("ticket.delete", str(tid))


def ticket_stats():
    con = connect()
    by = {r["status"]: r["c"] for r in con.execute(
        "SELECT status, COUNT(*) c FROM tickets GROUP BY status")}
    unread = con.execute(
        "SELECT COUNT(*) c FROM tickets WHERE unread_admin=1").fetchone()["c"]
    con.close()
    return {"total": sum(by.values()), "open": by.get("open", 0),
            "answered": by.get("answered", 0), "closed": by.get("closed", 0),
            "unread": unread}


# ==========================================================================
#  INBOX  --  everything that is waiting for the admin, in one place
#
#  Approvals were spread across nine separate pages: businesses, reviews,
#  questions, claims, edits, subscriptions, reports, messages, tickets. To
#  find out whether anything needed doing you had to visit all nine. That is
#  how a pending shop sits unapproved for a week and the shopkeeper decides
#  the site is dead.
#
#  Each entry carries a direct link, so the inbox is a to-do list, not just
#  a set of counters.
# ==========================================================================
def inbox(limit_each=8):
    """-> {'total': n, 'groups': [ {key,label,icon,n,href,items[]}, ... ]}"""
    g = []

    def add(key, label, icon_name, rows, href, fmt):
        rows = list(rows)
        if not rows:
            return
        g.append({
            "key": key, "label": label, "icon": icon_name,
            "n": len(rows), "href": href,
            "items": [fmt(r) for r in rows[:limit_each]],
        })

    add("business", "کسب‌وکار در انتظار تأیید", "store",
        businesses(status="pending"), "/panel/businesses?status=pending",
        lambda b: {"title": b["name"],
                   "sub": b.get("address") or b.get("phone") or "",
                   "when": str(b.get("created") or "")[:16],
                   "href": f"/panel/business/{b['id']}"})

    add("review", "نظر در انتظار بررسی", "message",
        reviews(status="pending"), "/panel/reviews",
        lambda r: {"title": f"{r['author']}: {r['body'][:48]}",
                   "sub": r.get("bizname") or "",
                   "when": str(r.get("created") or "")[:16],
                   "href": "/panel/reviews"})

    add("question", "پرسش در انتظار انتشار", "help",
        questions(status="pending"), "/panel/qa",
        lambda q: {"title": q["body"][:56],
                   "sub": q.get("bizname") or "",
                   "when": str(q.get("created") or "")[:16],
                   "href": "/panel/qa"})

    add("claim", "درخواست تصاحب کسب‌وکار", "shield",
        claims(status="pending"), "/panel/claims",
        lambda c: {"title": c.get("bizname") or "—",
                   "sub": c.get("ownerphone") or c.get("phone") or "",
                   "when": str(c.get("created") or "")[:16],
                   "href": "/panel/claims"})

    add("edit", "ویرایش در انتظار تأیید", "edit",
        pending_edits(), "/panel/edits",
        lambda e: {"title": e.get("bizname") or "—",
                   "sub": "تغییر اطلاعات کسب‌وکار",
                   "when": str(e.get("created") or "")[:16],
                   "href": "/panel/edits"})

    add("subscription", "پرداخت در انتظار تأیید", "wallet",
        subscriptions(status="pending"), "/panel/subscriptions",
        lambda x: {"title": x.get("bizname") or "—",
                   "sub": f"{fa_money(x.get('amount') or 0)} تومان — "
                          f"{x.get('planname') or x.get('plan_slug')}",
                   "when": str(x.get("created") or "")[:16],
                   "href": "/panel/subscriptions"})

    add("ticket", "تیکت بی‌پاسخ", "message",
        [t for t in tickets() if t.get("unread_admin")], "/panel/tickets",
        lambda t: {"title": t["subject"],
                   "sub": f"{t.get('name') or ''} {t.get('phone') or ''}".strip(),
                   "when": str(t.get("updated") or "")[:16],
                   "href": f"/panel/ticket/{t['id']}"})

    add("report", "گزارش تخلف", "alert",
        [r for r in reports() if r.get("status") == "open"], "/panel/reports",
        lambda r: {"title": r.get("reason") or "گزارش",
                   "sub": r.get("bizname") or "",
                   "when": str(r.get("created") or "")[:16],
                   "href": "/panel/reports"})

    add("message", "پیام تماس خوانده‌نشده", "mail",
        messages(status="new"), "/panel/messages",
        lambda m: {"title": m.get("subject") or (m.get("body") or "")[:48],
                   "sub": f"{m.get('name') or ''} {m.get('email') or ''}".strip(),
                   "when": str(m.get("created") or "")[:16],
                   "href": "/panel/messages"})

    return {"total": sum(x["n"] for x in g), "groups": g}


def owner_badges(owner_id):
    """Unread/pending counts for one shopkeeper's sidebar.

    Written because SMS is not configured yet: sms.notify() is called in
    six places but silently does nothing without an API key, so a booking
    could sit unseen for a week. These numbers make the panel itself the
    notification channel, and they stay useful after SMS is switched on.
    """
    ids = [b["id"] for b in businesses_of(owner_id)]
    if not ids:
        return {"total": 0}
    marks = ",".join("?" * len(ids))
    con = connect()

    def one(sql, extra=()):
        r = con.execute(sql, list(ids) + list(extra)).fetchone()
        return r["c"] if r else 0

    out = {
        "bookings": one(f"SELECT COUNT(*) c FROM bookings "
                        f"WHERE biz_id IN ({marks}) AND status='new'"),
        "questions": one(f"SELECT COUNT(*) c FROM questions "
                         f"WHERE biz_id IN ({marks}) AND (answer IS NULL OR answer='')"),
        "inquiries": one(f"SELECT COUNT(*) c FROM inquiries "
                         f"WHERE biz_id IN ({marks}) AND status='new'"),
        "reviews": one(f"SELECT COUNT(*) c FROM reviews "
                       f"WHERE biz_id IN ({marks}) AND status='approved' "
                       f"AND (reply IS NULL OR reply='')"),
    }
    r = con.execute("SELECT COUNT(*) c FROM tickets WHERE owner_id=? "
                    "AND unread_user=1", (owner_id,)).fetchone()
    out["tickets"] = r["c"] if r else 0
    con.close()
    out["total"] = sum(v for k, v in out.items() if k != "total")
    return out


def vcard(b):
    """A .vcf the phone's Contacts app understands.

    "Save to contacts" is the single most useful thing a person can do with
    a shop they intend to use again, and on a phone the alternative is
    copying four fields by hand. vCard 3.0 is chosen deliberately: 4.0 is
    newer but older Android dialers still choke on it.
    """
    def esc_v(t):
        return str(t or "").replace("\\", "\\\\").replace(";", "\\;") \
                           .replace(",", "\\,").replace("\n", "\\n")

    name = esc_v(b.get("name"))
    lines = ["BEGIN:VCARD", "VERSION:3.0",
             f"N:{name};;;;", f"FN:{name}"]
    if b.get("cat_name"):
        lines.append(f"ORG:{esc_v(b['cat_name'])}")
    if b.get("phone"):
        lines.append(f"TEL;TYPE=WORK,VOICE:{esc_v(b['phone'])}")
    if b.get("whatsapp"):
        lines.append(f"TEL;TYPE=CELL:{esc_v(b['whatsapp'])}")
    if b.get("address"):
        lines.append(f"ADR;TYPE=WORK:;;{esc_v(b['address'])};نجف‌آباد;اصفهان;;ایران")
    if b.get("website"):
        lines.append(f"URL:{esc_v(b['website'])}")
    if b.get("descr"):
        lines.append(f"NOTE:{esc_v(b['descr'][:200])}")
    if b.get("lat") and b.get("lng"):
        lines.append(f"GEO:{b['lat']};{b['lng']}")
    lines += ["END:VCARD"]
    return "\r\n".join(lines) + "\r\n"


def owner_export_csv(owner_id, kind="customers"):
    """A shopkeeper's own data, in a file they can open in Excel.

    This is the `export` paid feature. Callers must have already checked
    can(biz_id, "export") — this function only assembles the rows, and it
    scopes strictly to businesses the owner actually owns so one shopkeeper
    can never export another's customer list.
    """
    import csv, io as _io
    mine = businesses_of(owner_id)
    ids = {b["id"]: b["name"] for b in mine}
    if not ids:
        return "\ufeff"

    buf = _io.StringIO()
    _w = csv.writer(buf)

    def writerow(row):
        # Every cell passes through _csv_cell so a customer name or phone
        # that starts with = + - @ cannot become a live formula in Excel.
        # (Security fix.)
        _w.writerow([_csv_cell(x) for x in row])

    w = type("_SafeCSV", (), {"writerow": staticmethod(writerow)})()

    if kind == "bookings":
        w.writerow(["کسب‌وکار", "نام مشتری", "تاریخ", "ساعت",
                    "وضعیت", "یادداشت", "ثبت"])
        for k in bookings():
            if k["biz_id"] in ids:
                w.writerow([ids[k["biz_id"]], k.get("name", ""),
                            k.get("date", ""), k.get("time", ""), k.get("status", ""),
                            k.get("note", ""), str(k.get("created", ""))[:16]])

    elif kind == "inquiries":
        w.writerow(["کسب‌وکار", "نام", "مورد", "درخواست",
                    "بودجه", "پاسخ شما", "وضعیت", "ثبت"])
        for r in inquiries():
            if r["biz_id"] in ids:
                w.writerow([ids[r["biz_id"]], r.get("name", ""),
                            r.get("itemtitle", ""), r.get("body", ""),
                            r.get("budget", ""), r.get("quote", ""),
                            r.get("status", ""), str(r.get("created", ""))[:16]])

    elif kind == "items":
        w.writerow(["کسب‌وکار", "عنوان", "نوع", "قیمت", "تخفیف", "موجود",
                    "ویژه", "برند", "گارانتی", "بازدید"])
        for b in mine:
            for it in items(biz_id=b["id"]):
                w.writerow([b["name"], it.get("title", ""), it.get("kind", ""),
                            it.get("price", "") or "", it.get("sale_price", "") or "",
                            "بله" if it.get("available") else "خیر",
                            "بله" if it.get("featured") else "خیر",
                            it.get("brand", ""), it.get("warranty", ""),
                            it.get("views", 0)])

    else:   # customers — everyone who ever reached out, de-duplicated by name.
            # (v65: phone numbers are private to the site admin and are not exported.)
        seen = {}
        for k in bookings():
            if k["biz_id"] in ids and k.get("name"):
                seen.setdefault(k["name"], [ids[k["biz_id"]],
                                            "نوبت", str(k.get("created", ""))[:10]])
        for r in inquiries():
            if r["biz_id"] in ids and r.get("name"):
                seen.setdefault(r["name"], [ids[r["biz_id"]],
                                            "پیام", str(r.get("created", ""))[:10]])
        w.writerow(["نام", "کسب‌وکار", "از طریق", "تاریخ"])
        for nm, (bn, via, dt) in seen.items():
            w.writerow([nm, bn, via, dt])

    return "\ufeff" + buf.getvalue()


def import_csv(text):
    """-> (added, updated, errors[])"""
    import csv, io
    text = text.lstrip("\ufeff")
    rdr = csv.DictReader(io.StringIO(text))
    cats = {c["slug"] for c in categories(only_active=False)}
    added = updated = 0
    errors = []
    for i, row in enumerate(rdr, start=2):
        name = (row.get("name") or "").strip()
        if not name:
            errors.append(f"سطر {i}: نام خالی است")
            continue
        cat = (row.get("cat_slug") or "").strip()
        if cat not in cats:
            errors.append(f"سطر {i}: دستهٔ «{cat}» وجود ندارد")
            continue
        data = {k: (row.get(k) or "").strip() for k in CSV_COLUMNS if k in row}
        data["name"] = name
        data["cat_slug"] = cat
        data.setdefault("status", "published")
        if data.get("status") not in ("published", "pending", "hidden", "rejected"):
            data["status"] = "published"
        for f in ("featured", "verified"):
            data[f] = 1 if str(data.get(f, "")).strip() in ("1", "بله", "true", "yes") else 0

        dup = find_duplicates(name=name, phone=data.get("phone", ""))
        exact = [d for d in dup if d["strength"] == "exact"]
        if exact:
            save_business(data, exact[0]["id"])
            updated += 1
        else:
            save_business(data)
            added += 1
    return added, updated, errors


# ==========================================================================
#  v3 — WORLD-CLASS DIRECTORY FEATURES
#  Every function here is reachable from a real page and a real panel screen.
# ==========================================================================

def request_done():
    """End-of-request hygiene for the pooled per-thread connection (v109).

    A handler that dies between an execute() and its commit() would leave
    this thread's connection holding SQLite's writer lock FOREVER — every
    other writer (and every external tool like the test suites) then fails
    with «database is locked» until the server restarts. The pooled close()
    is a no-op since v107, so nothing used to roll the dangling txn back.
    Called from the request finally-block in app.py, next to clear_context.
    """
    con = getattr(_thread_local, "con", None)
    if con is not None:
        try:
            if con.in_transaction:
                con.rollback()
            # v174: keep the WAL small. The auto-checkpoint only runs right
            # after a commit, so a write burst (demo seed, batteries, crawler)
            # can grow the WAL to several MB; every later commit then pays a
            # multi-MB checkpoint + fsync WHILE holding SQLite's writer lock —
            # on phone storage that is seconds of "database is locked" for
            # every other writer. A cheap truncate attempt per request end
            # (it simply returns busy when a reader is active) bounds the WAL
            # and keeps commits fast.
            try:
                if os.path.getsize(DB_PATH + "-wal") > 1_500_000:
                    con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            except Exception:
                pass
        except sqlite3.Error:
            pass


def _rows(sql, params=()):
    con = connect()
    out = [dict(r) for r in con.execute(sql, params)]
    con.close()
    return out


def _one(sql, params=()):
    con = connect()
    r = con.execute(sql, params).fetchone()
    con.close()
    return dict(r) if r else None


def _all(sql, params=()):
    """v320: list-fetch matching _one (dict rows). Used by agent tools."""
    con = connect()
    rows = con.execute(sql, params).fetchall()
    con.close()
    return [dict(r) for r in rows]


def _run(sql, params=()):
    con = connect()
    cur = con.execute(sql, params)
    rid = cur.lastrowid
    con.commit()
    con.close()
    return rid


def _upd(table, rowid, **kw):
    kw = {k: v for k, v in kw.items() if v is not None}
    if not kw:
        return 0
    con = connect()
    sets = ", ".join(f"{k}=?" for k in kw)
    cur = con.execute(f"UPDATE {table} SET {sets} WHERE id=?",
                      list(kw.values()) + [rowid])
    n = cur.rowcount
    con.commit()
    con.close()
    return n


# ------------------------------------------------------------- rate limiting
def rate_ok(bucket, limit=None, window=None, always=False):
    """Fixed-window bucket counter. Returns True when the action is allowed.

    The admin's anti-spam switch (`ratelimit_on`) disables the *spam* quotas
    (forms, comments, …) — but security-critical buckets (OTP issue/verify,
    password attempts) must never follow it: they pass always=True so turning
    the spam switch off can never remove the brute-force walls."""
    if not always:
        s = get_settings()
        if s.get("ratelimit_on") != "1":
            return True
    limit = int(limit or s.get("ratelimit_n", "8") or 8)
    window = float(window or s.get("ratelimit_win", "600") or 600)
    now = time.time()
    con = connect()
    r = con.execute("SELECT n, window FROM ratelimit WHERE bucket=?", (bucket,)).fetchone()
    if not r or now - r["window"] > window:
        con.execute("INSERT INTO ratelimit(bucket,n,window) VALUES(?,1,?) "
                    "ON CONFLICT(bucket) DO UPDATE SET n=1, window=excluded.window",
                    (bucket, now))
        con.commit(); con.close()
        return True
    if r["n"] >= limit:
        con.close()
        return False
    con.execute("UPDATE ratelimit SET n=n+1 WHERE bucket=?", (bucket,))
    con.commit(); con.close()
    return True


def rate_clear():
    _run("DELETE FROM ratelimit")


# ------------------------------------------------------------------ Q & A
def questions(biz_id=None, status=None, limit=None):
    q = ("SELECT q.*, b.name bizname, b.slug bizslug FROM questions q "
         "JOIN businesses b ON b.id=q.biz_id WHERE 1=1")
    p = []
    if biz_id:
        q += " AND q.biz_id=?"; p.append(biz_id)
    if status:
        q += " AND q.status=?"; p.append(status)
    else:
        q += " AND q.status!='deleted'"   # v285: soft-deleted never leaks
    q += " ORDER BY q.helpful DESC, q.id DESC"
    if limit:
        q += f" LIMIT {int(limit)}"
    return _rows(q, p)


def question(qid):
    return _one("SELECT q.*, b.name bizname, b.slug bizslug FROM questions q "
                "JOIN businesses b ON b.id=q.biz_id WHERE q.id=?", (qid,))


def add_question(biz_id, asker, body, auto_publish=False, customer_id=None,
                 spam_flag=0):
    if spam_flag:
        auto_publish = False   # v276: held content never auto-publishes
    qid = _run("INSERT INTO questions(biz_id,asker,body,status,customer_id,spam_flag) VALUES(?,?,?,?,?,?)",
               (biz_id, asker.strip(), body.strip(),
                "published" if auto_publish else "pending", customer_id, spam_flag))
    _owner_notify_biz(biz_id, "social", "❓ پرسش تازه‌ای دربارهٔ کسب‌وکار شما ثبت شد.", "/my/questions")
    return qid


def answer_question(qid, answer, by="owner"):
    q = _one("SELECT * FROM questions WHERE id=?", (qid,))
    # v285: re-saving over an existing different answer marks it «edited».
    prev = (q["answer"] or "").strip() if q else ""
    new = answer.strip()
    _extra = {}
    if prev and prev != new:
        _extra["answer_edited"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    res = _upd("questions", qid, answer=new, answered_by=by,
               status="published",
               answered=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
               **_extra)
    if q and q.get("customer_id"):
        b = business(bid=q["biz_id"]) or {}
        notify_customer(q["customer_id"], "reply",
                        f"«{b.get('name', 'کسب‌وکار')}» به پرسش شما پاسخ داد.",
                        f"/b/{b.get('slug', '')}#qa")
    return res


# ---- v285: پرسش‌وپاسخ — ویرایش/حذف فقط پیام خودی ----
QA_EDIT_WINDOW = 15 * 60   # seconds


def question_set_body(qid, body):
    """Asker edits their own question inside the edit window; marks «edited»."""
    return _upd("questions", qid, body=body.strip(),
                edited=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


def question_soft_delete(qid):
    """Asker deletes their own question (soft — kept for audit, hidden publicly)."""
    return _upd("questions", qid, status="deleted")


def answer_set(qid, answer):
    """Owner/admin edits the answer; marks answer_edited."""
    return _upd("questions", qid, answer=answer.strip(),
                answer_edited=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


def answer_clear(qid):
    """Owner deletes their own answer — question goes back to «unanswered».
    Direct SQL because _upd drops None values and `answered` must become NULL."""
    con = connect()
    con.execute("UPDATE questions SET answer='', answered=NULL, answered_by='', "
                "answer_edited='' WHERE id=?", (qid,))
    con.commit(); con.close()
    return 1


def _qa_ts(val, utc=False):
    """Parse a questions timestamp -> epoch seconds or None.

    `created` comes from sqlite's datetime('now') which is UTC; `answered`/
    `edited` come from python's local now(). Callers pass utc=True for the
    sqlite-generated columns so the 15-minute window is exact."""
    if not val:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            d = datetime.datetime.strptime(str(val)[:len("2000-01-01 00:00:00") if " " in str(val) else 10], fmt)
            if utc:
                return d.replace(tzinfo=datetime.timezone.utc).timestamp()
            return d.timestamp()
        except ValueError:
            continue
    return None


def set_question_status(qid, status):
    return _upd("questions", qid, status=status)


def delete_question(qid):
    return _run("DELETE FROM questions WHERE id=?", (qid,))


def question_helpful(qid, voter=""):
    # v276 G10: one vote per visitor (mirror of review_votes) — repeats return
    # the current count without inflating it.
    import time as _t
    if voter:
        _run("INSERT OR IGNORE INTO question_votes(question_id,voter,created) VALUES(?,?,?)",
             (qid, voter, _t.time()))
        r = _one("SELECT COUNT(*) c FROM question_votes WHERE question_id=?", (qid,))
        n = r["c"] if r else 0
        _run("UPDATE questions SET helpful=? WHERE id=?", (n, qid))
        return n
    _run("UPDATE questions SET helpful=helpful+1 WHERE id=?", (qid,))
    r = _one("SELECT helpful FROM questions WHERE id=?", (qid,))
    return r["helpful"] if r else 0


def questions_count(biz_id=None, status=None):
    return len(questions(biz_id=biz_id, status=status))


# ------------------------------------------------------------------ reports
def reports(status=None, kind=None, page=None, per=50):
    q = ("SELECT r.*, b.name bizname, b.slug bizslug FROM reports r "
         "LEFT JOIN businesses b ON b.id=r.biz_id WHERE 1=1")
    p = []
    if status:
        q += " AND r.status=?"; p.append(status)
    if kind:
        q += " AND r.kind=?"; p.append(kind)
    q += " ORDER BY (r.status='open') DESC, r.id DESC"
    if page is not None:                      # v117/M3
        con = connect()
        out = _page_result(con, q, p, page, per)
        con.close()
        return out
    return _rows(q, p)


def add_report(kind, target_id, reason, body="", reporter="", biz_id=None):
    if kind == "business" and biz_id is None:
        biz_id = target_id
    # v171: دلیل فقط از فهرست شناخته‌شده — مقدار دستکاری‌شده به‌جای نمایش
    # خام، «دلیل دیگر» ثبت می‌شود.
    if str(reason) not in dict(REPORT_REASONS):
        reason = "other"
    return _run("INSERT INTO reports(kind,target_id,biz_id,reason,body,reporter) "
                "VALUES(?,?,?,?,?,?)",
                (kind, int(target_id), biz_id, reason, body.strip(), reporter.strip()))


def resolve_report(rid, status="resolved", note=""):
    return _upd("reports", rid, status=status, note=note)


def delete_report(rid):
    row = _one("SELECT * FROM reports WHERE id=?", (rid,))
    if row:
        trash_put("report", rid, row["biz_id"] or 0,
                  (row["reason"] or "") + " " + (row["body"] or "")[:40], dict(row))
    return _run("DELETE FROM reports WHERE id=?", (rid,))


# ---- v105/v109: soft-delete recycle bin (restorable + trackable) ----
# v109 retention per entity, per the owner's rule:
#   story  → 7 days   (a story disappears after its 24h life or on delete;
#                      the shopkeeper and the admin can still trace/restore
#                      it for a full week if a complaint arrives)
#   item / review / report → 24 hours (enough to undo an accident or
#                      follow up a same-day report, without hoarding rows)
TRASH_DAYS = 7   # kept for compatibility; the map below is the real source
# v177: استاندارد واقعیِ بازیابی = ۳۰ روز (Gmail/Google Photos/Instagram).
# قبلاً کالا/نظر فقط ۲۴ ساعت بود — یعنی عملاً هیچ بازیابی. گزارش مدیر ۷ روز.
TRASH_RETENTION = {"story": 30 * 86400, "item": 30 * 86400,
                   "review": 30 * 86400, "report": 7 * 86400,
                   # v209: whole businesses deleted by their owner
                   "business": 30 * 86400}


def trash_cutoff(entity=None):
    """Unix timestamp below which rows of `entity` are permanently purged."""
    days = (TRASH_RETENTION.get(entity, TRASH_DAYS * 86400) if entity
            else TRASH_DAYS * 86400)
    return time.time() - days


def trash_put(entity, ref_id, biz_id, title, row):
    _run("INSERT INTO trash(entity,ref_id,biz_id,title,payload,deleted_at) VALUES(?,?,?,?,?,?)",
         (entity, int(ref_id), int(biz_id or 0), (title or "")[:120],
          json.dumps(row, ensure_ascii=False, default=str), time.time()))


def trash_list(entities=None, biz_ids=None):
    """Live bin rows. Each entity is kept for ITS OWN retention window, so a
    3-day-old story is still listed while a 3-day-old product is long gone."""
    ents = list(entities) if entities else list(TRASH_RETENTION.keys())
    q = "SELECT * FROM trash WHERE ("
    q += " OR ".join("(entity=? AND deleted_at>=?)" for _ in ents) + ")"
    p = []
    for e in ents:
        p += [e, trash_cutoff(e)]
    if biz_ids:
        q += " AND biz_id IN (%s)" % ",".join("?" * len(biz_ids)); p += list(biz_ids)
    q += " ORDER BY deleted_at DESC LIMIT 200"
    return _rows(q, p)

def trash_restore(tid):
    r = _one("SELECT * FROM trash WHERE id=?", (tid,))
    if not r:
        return False
    table = {"story": "stories", "item": "items", "review": "reviews",
             "report": "reports", "business": "businesses"}.get(r["entity"])
    if not table:
        return False
    row = json.loads(r["payload"])
    if r["entity"] == "business":
        # v209: a restored shop goes back through moderation unless it was
        # merely hidden; and it must not collide with a slug reused meanwhile.
        if row.get("status") == "published":
            row["status"] = "pending"
        if _one("SELECT 1 FROM businesses WHERE slug=? AND id<>?", (row.get("slug"), row["id"])):
            row["slug"] = f"{row.get('slug') or 'biz'}-{int(time.time()) % 100000}"
        _pagecache_drop(); _fts_mark_dirty()
    # v109: a restored STORY that had already expired (or was binned by its
    # 24h life) would be re-purged by the next sweep instantly. Restoring
    # means "make it live again", so give it a fresh 24-hour life.
    if r["entity"] == "story":
        try:
            row["expires"] = time.time() + 24 * 3600
        except Exception:
            pass
    cols = list(row.keys())
    con = connect()
    con.execute("INSERT OR REPLACE INTO %s (%s) VALUES (%s)"
                % (table, ",".join(cols), ",".join("?" * len(cols))),
                [row[c] for c in cols])
    con.commit(); con.close()
    _run("DELETE FROM trash WHERE id=?", (tid,))
    return True

def trash_purge():
    # v109: per-entity retention — each row is compared against ITS OWN cutoff
    for entity, keep in TRASH_RETENTION.items():
        _run("DELETE FROM trash WHERE entity=? AND deleted_at < ?",
             (entity, time.time() - keep))


def trash_left_seconds(r):
    """Seconds of bin life left for a trash row (>=0)."""
    keep = TRASH_RETENTION.get(r["entity"], TRASH_DAYS * 86400)
    return max(0, int(r["deleted_at"] + keep - time.time()))


def reason_label(code):
    return dict(REPORT_REASONS).get(code, code)


# ------------------------------------------------------------------ badges
def badges(only_active=True):
    q = "SELECT * FROM badges"
    if only_active:
        q += " WHERE active=1"
    q += " ORDER BY sort, id"
    rows = _rows(q)
    con = connect()
    for r in rows:
        r["count"] = con.execute("SELECT COUNT(*) c FROM biz_badges WHERE badge_id=?",
                                 (r["id"],)).fetchone()["c"]
    con.close()
    return rows


def badge(bid=None, slug=None):
    if slug:
        return _one("SELECT * FROM badges WHERE slug=?", (slug,))
    return _one("SELECT * FROM badges WHERE id=?", (bid,))


def save_badge(data, bid=None):
    if bid:
        return _upd("badges", bid,
                    name=data.get("name"), icon=data.get("icon"),
                    color=data.get("color"), descr=data.get("descr"),
                    sort=int(data.get("sort") or 0),
                    active=int(bool(int(data.get("active") or 0))))
    slug = data.get("slug") or unique_slug("badges", slugify(data.get("name"), "badge"))
    return _run("INSERT INTO badges(slug,name,icon,color,descr,sort,active) "
                "VALUES(?,?,?,?,?,?,?)",
                (slug, data.get("name", ""), data.get("icon", "award"),
                 data.get("color", "#059669"), data.get("descr", ""),
                 int(data.get("sort") or 0), int(bool(int(data.get("active") or 1)))))


def delete_badge(bid):
    return _run("DELETE FROM badges WHERE id=?", (bid,))


def biz_badges(biz_id):
    return _rows("SELECT bg.* FROM biz_badges bb JOIN badges bg ON bg.id=bb.badge_id "
                 "WHERE bb.biz_id=? AND bg.active=1 ORDER BY bg.sort", (biz_id,))


def badges_map(biz_ids=None):
    """{biz_id: [badge, ...]} in one query — used by list pages."""
    con = connect()
    rows = con.execute(
        "SELECT bb.biz_id, bg.* FROM biz_badges bb JOIN badges bg ON bg.id=bb.badge_id "
        "WHERE bg.active=1 ORDER BY bg.sort").fetchall()
    con.close()
    out = {}
    for r in rows:
        d = dict(r)
        out.setdefault(d["biz_id"], []).append(d)
    if biz_ids is not None:
        ids = set(biz_ids)
        out = {k: v for k, v in out.items() if k in ids}
    return out


def grant_badge(biz_id, badge_id):
    return _run("INSERT OR IGNORE INTO biz_badges(biz_id,badge_id) VALUES(?,?)",
                (biz_id, badge_id))


def revoke_badge(biz_id, badge_id):
    return _run("DELETE FROM biz_badges WHERE biz_id=? AND badge_id=?",
                (biz_id, badge_id))


def set_biz_badges(biz_id, badge_ids):
    con = connect()
    con.execute("DELETE FROM biz_badges WHERE biz_id=?", (biz_id,))
    for b in badge_ids:
        con.execute("INSERT OR IGNORE INTO biz_badges(biz_id,badge_id) VALUES(?,?)",
                    (biz_id, int(b)))
    con.commit(); con.close()
    return len(badge_ids)


def auto_badges():
    """Grant/revoke the automatic badges from real data. Runs on demand from
    the panel so the admin can see exactly how many changed."""
    top = badge(slug="top-rated")
    changed = 0
    if not top:
        return 0
    con = connect()
    rows = con.execute(
        "SELECT b.id, (SELECT AVG(rating) FROM reviews WHERE biz_id=b.id "
        "AND status='approved' AND rating>0) r, "
        "(SELECT COUNT(*) FROM reviews WHERE biz_id=b.id AND status='approved' "
        "AND rating>0) n FROM businesses b").fetchall()
    for r in rows:
        deserves = bool(r["r"] and r["r"] >= 5.4 and r["n"] >= 10)   # ۹۰٪ مقیاس شش‌ستاره
        has = con.execute("SELECT 1 FROM biz_badges WHERE biz_id=? AND badge_id=?",
                          (r["id"], top["id"])).fetchone() is not None
        if deserves and not has:
            con.execute("INSERT INTO biz_badges(biz_id,badge_id) VALUES(?,?)",
                        (r["id"], top["id"])); changed += 1
        elif has and not deserves:
            con.execute("DELETE FROM biz_badges WHERE biz_id=? AND badge_id=?",
                        (r["id"], top["id"])); changed += 1
    con.commit(); con.close()
    return changed


# ------------------------------------------------------------------ plans
def plans(only_active=True):
    q = "SELECT * FROM plans"
    if only_active:
        q += " WHERE active=1"
    q += " ORDER BY sort, price"
    rows = _rows(q)
    for r in rows:
        r["perk_list"] = [x.strip() for x in (r.get("perks") or "").split("\n") if x.strip()]
    return rows


def plan(slug=None, pid=None):
    r = _one("SELECT * FROM plans WHERE slug=?", (slug,)) if slug else \
        _one("SELECT * FROM plans WHERE id=?", (pid,))
    if r:
        r["perk_list"] = [x.strip() for x in (r.get("perks") or "").split("\n") if x.strip()]
    return r


def save_plan(data, pid=None):
    _pagecache_drop()
    vals = dict(
        name=data.get("name", ""),
        tagline=data.get("tagline", ""),
        price=int(str(data.get("price") or 0).replace(",", "") or 0),
        months=int(data.get("months") or 12),
        featured_slots=int(data.get("featured_slots") or 0),
        max_items=int(data.get("max_items") or 10),
        max_photos=int(data.get("max_photos") or 6),
        perks=data.get("perks", ""),
        features=data.get("features", ""),
        badge_slug=data.get("badge_slug", ""),
        sort=int(data.get("sort") or 0),
        active=int(bool(int(data.get("active") or 0))))
    # v285: سهمیهٔ پیام هوشمند روزانهٔ پلن (-1 = پیش‌فرض سطح)
    _aid = str(data.get("ai_daily", "") or "").strip()
    vals["ai_daily"] = int(_aid) if _aid.lstrip("-").isdigit() else -1
    if pid:
        return _upd("plans", pid, **vals)
    slug = data.get("slug") or unique_slug("plans", slugify(vals["name"], "plan"))
    cols = ", ".join(["slug"] + list(vals))
    qs = ", ".join("?" * (len(vals) + 1))
    return _run(f"INSERT INTO plans({cols}) VALUES({qs})", [slug] + list(vals.values()))


def delete_plan(pid):
    p = plan(pid=pid)
    if p and subscriptions(plan_slug=p["slug"]):
        return False, "این پلن اشتراک فعال دارد و حذف نمی‌شود."
    _run("DELETE FROM plans WHERE id=?", (pid,))
    return True, "پلن حذف شد."


# --------------------------------------------------------- subscriptions
def _subscription_enrich(rows):
    today = datetime.date.today().isoformat()
    for r in rows:
        r["days_left"] = None
        if r.get("expires"):
            try:
                d = (datetime.date.fromisoformat(r["expires"][:10])
                     - datetime.date.today()).days
                r["days_left"] = d
            except Exception:
                pass
        r["is_live"] = r["status"] == "active" and (not r.get("expires") or r["expires"] >= today)
        # effective billing period: what the row stores, else the plan's own.
        r["months_eff"] = int(r.get("months") or 0) or int(r.get("plan_months") or 12)


def subscriptions(status=None, biz_id=None, plan_slug=None, page=None, per=50):
    q = ("SELECT s.*, b.name bizname, b.slug bizslug, p.name planname, "
         "p.months plan_months "
         "FROM subscriptions s JOIN businesses b ON b.id=s.biz_id "
         "LEFT JOIN plans p ON p.slug=s.plan_slug WHERE 1=1")
    p = []
    if status:
        q += " AND s.status=?"; p.append(status)
    if biz_id:
        q += " AND s.biz_id=?"; p.append(biz_id)
    if plan_slug:
        q += " AND s.plan_slug=?"; p.append(plan_slug)
    q += " ORDER BY (s.status='pending') DESC, s.id DESC"
    if page is not None:                      # v117/M3
        con = connect()
        out = _page_result(con, q, p, page, per)
        con.close()
        _subscription_enrich(out["rows"])
        return out
    rows = _rows(q, p)
    _subscription_enrich(rows)
    return rows


def subscription_of(biz_id):
    """The one that matters right now."""
    live = [s for s in subscriptions(biz_id=biz_id) if s["is_live"]]
    return live[0] if live else None


def request_subscription(biz_id, plan_slug, ref="", method="manual", note="", months=None, receipt=""):
    p = plan(slug=plan_slug)
    if not p:
        return None, "پلن یافت نشد."
    # optional billing period override (1/3/6/12). The amount is prorated from
    # the plan's own monthly rate so a shorter period costs proportionally less.
    m = p["months"]
    if months and str(months).isdigit() and int(months) in (1, 3, 6, 12):
        m = int(months)
    # v136: prorate with rounding (not floor division) so 3/6-month amounts
    # are exact halves/quarters and never drift a few toman off.
    amount = (int((p["price"] * m / p["months"]) + 0.5)
              if (p["price"] and p["months"]) else 0)
    if p["price"] == 0:
        # free plan activates immediately
        sid = _run("INSERT INTO subscriptions(biz_id,plan_slug,status,starts,expires,"
                   "amount,months,method,ref,receipt,note) VALUES(?,?,'active',?,?,?,?,?,?,?,?)",
                   (biz_id, plan_slug, datetime.date.today().isoformat(),
                    (datetime.date.today() + datetime.timedelta(days=30 * m)).isoformat(),
                    0, m, method, ref, receipt, note))
        apply_plan(biz_id, plan_slug)
        _owner_notify_biz(biz_id, "sub",
                          f"🎉 تعرفهٔ «{p['name']}» برای کسب‌وکار شما فعال شد.", "/my/plan")
        return sid, "پلن رایگان فعال شد."
    sid = _run("INSERT INTO subscriptions(biz_id,plan_slug,status,amount,months,method,ref,receipt,note) "
               "VALUES(?,?,'pending',?,?,?,?,?,?)",
               (biz_id, plan_slug, amount, m, method, ref, receipt, note))
    _owner_notify_biz(biz_id, "sub",
                      f"درخواست تعرفهٔ «{p['name']}» ثبت شد و پس از تأیید مدیر فعال می‌شود.",
                      "/my/plan", push=False)   # v142 matrix: push خاموش برای رویداد خودِ کاربر
    return sid, "درخواست ثبت شد و پس از تأیید پرداخت فعال می‌شود."


def activate_subscription(sid, months=None):
    access_cache_clear()
    s = _one("SELECT * FROM subscriptions WHERE id=?", (sid,))
    if not s:
        return False
    p = plan(slug=s["plan_slug"])
    # the period the customer actually paid for (stored on the row) wins;
    # the caller may override it explicitly (admin picker).
    m = int(months or 0) or int(s.get("months") or 0) or (p["months"] if p else 12)
    if m not in (1, 3, 6, 12):
        m = p["months"] if p else 12
    start = datetime.date.today()
    # stack on top of a still-running subscription instead of losing days
    live = subscription_of(s["biz_id"])
    if live and live.get("expires"):
        try:
            e = datetime.date.fromisoformat(live["expires"][:10])
            if e > start:
                start = e
        except Exception:
            pass
    end = start + datetime.timedelta(days=30 * m)
    _upd("subscriptions", sid, status="active", starts=start.isoformat(),
         expires=end.isoformat(), months=m)
    apply_plan(s["biz_id"], s["plan_slug"])
    log("subscription.activate", f"{s['biz_id']} {s['plan_slug']} -> {end}")
    _owner_notify_biz(s["biz_id"], "sub",
                      f"🎉 تعرفهٔ «{p['name'] if p else 'انتخابی'}» فعال شد (برای {m} ماه).",
                      "/my/plan")
    return True


def cancel_subscription(sid):
    access_cache_clear()
    s = _one("SELECT * FROM subscriptions WHERE id=?", (sid,))
    _upd("subscriptions", sid, status="cancelled")
    if s:
        revoke_plan(s["biz_id"], s["plan_slug"])
    return True


def delete_subscription(sid):
    return _run("DELETE FROM subscriptions WHERE id=?", (sid,))


def reject_subscription(sid):
    """v139: manager rejects a pending manual (card-to-card) payment request."""
    s = _one("SELECT * FROM subscriptions WHERE id=?", (sid,))
    res = _run("UPDATE subscriptions SET status='rejected' WHERE id=? AND status='pending'", (sid,))
    if res and s:
        _owner_notify_biz(s["biz_id"], "sub",
                          "درخواست تعرفهٔ شما رد شد. برای پیگیری تیکت بزنید.", "/my/tickets")
    return res


def apply_plan(biz_id, plan_slug):
    """A paid plan really changes the listing: featured flag + badge."""
    p = plan(slug=plan_slug)
    if not p:
        return
    if p["featured_slots"] > 0:
        save_business({"featured": 1}, biz_id)
    if p.get("badge_slug"):
        bg = badge(slug=p["badge_slug"])
        if bg:
            grant_badge(biz_id, bg["id"])


def revoke_plan(biz_id, plan_slug):
    access_cache_clear()
    p = plan(slug=plan_slug)
    if not p:
        return
    if p["featured_slots"] > 0:
        save_business({"featured": 0}, biz_id)
    if p.get("badge_slug"):
        bg = badge(slug=p["badge_slug"])
        if bg:
            revoke_badge(biz_id, bg["id"])


def expire_subscriptions():
    access_cache_clear()
    """Called on boot and from the panel. Returns how many expired.

    SOFT EXPIRY: only the status flag is flipped here. The plan's features are
    NOT revoked — access() keeps them alive after expiry so a late payment
    never hides a shop's photos, catalogue or badges. Only the add-quota
    reverts, which access() derives from the live subscription."""
    today = datetime.date.today().isoformat()
    con = connect()
    rows = con.execute("SELECT * FROM subscriptions WHERE status='active' "
                       "AND expires IS NOT NULL AND expires < ?", (today,)).fetchall()
    for r in rows:
        con.execute("UPDATE subscriptions SET status='expired' WHERE id=?", (r["id"],))
    con.commit(); con.close()
    for r in rows:
        _owner_notify_biz(r["biz_id"], "sub",
                          "تعرفهٔ کسب‌وکار شما تمام شد؛ امکانات ویژه غیرفعال شد.", "/my/plan")
    return len(rows)


def expiring_soon(days=14):
    out = []
    for s in subscriptions(status="active"):
        if s.get("days_left") is not None and 0 <= s["days_left"] <= days:
            out.append(s)
    return out


def plan_limits(biz_id):
    """What this business is allowed to do right now."""
    sub = subscription_of(biz_id)
    p = plan(slug=sub["plan_slug"]) if sub else plan(slug="free")
    if not p:
        return {"plan": "free", "name": "پایه", "max_items": 10, "max_photos": 6}
    return {"plan": p["slug"], "name": p["name"],
            "max_items": p["max_items"], "max_photos": p["max_photos"],
            "expires": sub.get("expires") if sub else None,
            "days_left": sub.get("days_left") if sub else None}


# ------------------------------------------------------------------ ads
def ads(slot=None, active_only=False):
    q = ("SELECT a.*, b.name bizname, b.slug bizslug FROM ads a "
         "LEFT JOIN businesses b ON b.id=a.biz_id WHERE 1=1")
    p = []
    if slot:
        q += " AND a.slot=?"; p.append(slot)
    if active_only:
        today = datetime.date.today().isoformat()
        q += (" AND a.active=1 AND (a.starts='' OR a.starts<=?) "
              "AND (a.ends='' OR a.ends>=?)")
        p += [today, today]
    q += " ORDER BY a.weight DESC, a.id DESC"
    rows = _rows(q, p)
    for r in rows:
        r["ctr"] = round(r["clicks"] * 100.0 / r["views"], 1) if r["views"] else 0.0
    return rows


def ad(aid):
    return _one("SELECT * FROM ads WHERE id=?", (aid,))


def pick_ad(slot):
    """Weighted pick among the live ads for a slot, and count the impression."""
    live = ads(slot=slot, active_only=True)
    if not live:
        return None
    pool = []
    for a in live:
        pool += [a] * max(1, int(a["weight"] or 1))
    chosen = pool[secrets.randbelow(len(pool))]
    _run("UPDATE ads SET views=views+1 WHERE id=?", (chosen["id"],))
    return chosen


def ad_click(aid):
    _run("UPDATE ads SET clicks=clicks+1 WHERE id=?", (aid,))
    return ad(aid)


def save_ad(data, aid=None):
    vals = dict(title=data.get("title", ""), body=data.get("body", ""),
                image=data.get("image", ""), url=data.get("url", ""),
                slot=data.get("slot", "home"),
                biz_id=(int(data["biz_id"]) if str(data.get("biz_id") or "").isdigit() else None),
                starts=data.get("starts", ""), ends=data.get("ends", ""),
                weight=int(data.get("weight") or 1),
                active=int(bool(int(data.get("active") or 0))))
    if aid:
        con = connect()
        sets = ", ".join(f"{k}=?" for k in vals)
        con.execute(f"UPDATE ads SET {sets} WHERE id=?", list(vals.values()) + [aid])
        con.commit(); con.close()
        return aid
    cols = ", ".join(vals)
    qs = ", ".join("?" * len(vals))
    return _run(f"INSERT INTO ads({cols}) VALUES({qs})", list(vals.values()))


def delete_ad(aid):
    return _run("DELETE FROM ads WHERE id=?", (aid,))


def reset_ad_stats(aid):
    return _run("UPDATE ads SET views=0, clicks=0 WHERE id=?", (aid,))


# ------------------------------------------------------------------ events
def cityevents(status="published", upcoming_only=False, limit=None):
    q = ("SELECT e.*, b.name bizname, b.slug bizslug FROM cityevents e "
         "LEFT JOIN businesses b ON b.id=e.biz_id WHERE 1=1")
    p = []
    if status:
        q += " AND e.status=?"; p.append(status)
    if upcoming_only:
        q += " AND (e.date='' OR e.date>=?)"; p.append(datetime.date.today().isoformat())
    q += " ORDER BY (e.date='') , e.date, e.id DESC"
    if limit:
        q += f" LIMIT {int(limit)}"
    rows = _rows(q, p)
    today = datetime.date.today().isoformat()
    for r in rows:
        r["past"] = bool(r.get("date")) and r["date"] < today
    return rows


def cityevent(slug=None, eid=None):
    if slug:
        return _one("SELECT e.*, b.name bizname, b.slug bizslug FROM cityevents e "
                    "LEFT JOIN businesses b ON b.id=e.biz_id WHERE e.slug=?", (slug,))
    return _one("SELECT * FROM cityevents WHERE id=?", (eid,))


def save_cityevent(data, eid=None):
    _pagecache_drop()          # v285: رویدادها روی صفحهٔ کش‌شدهٔ /events هستند
    vals = dict(title=data.get("title", ""), descr=data.get("descr", ""),
                place=data.get("place", ""), date=data.get("date", ""),
                time=data.get("time", ""),
                biz_id=(int(data["biz_id"]) if str(data.get("biz_id") or "").isdigit() else None),
                image=data.get("image", ""),
                video=data.get("video", ""),
                status=data.get("status", "published"))
    if eid:
        con = connect()
        sets = ", ".join(f"{k}=?" for k in vals)
        con.execute(f"UPDATE cityevents SET {sets} WHERE id=?", list(vals.values()) + [eid])
        con.commit(); con.close()
        return eid
    slug = unique_slug("cityevents", slugify(vals["title"], "event"))
    cols = ", ".join(["slug"] + list(vals))
    qs = ", ".join("?" * (len(vals) + 1))
    return _run(f"INSERT INTO cityevents({cols}) VALUES({qs})",
                [slug] + list(vals.values()))


def delete_cityevent(eid):
    _pagecache_drop()          # v285
    return _run("DELETE FROM cityevents WHERE id=?", (eid,))


# --------------------------------------------------- multi-criteria reviews
def set_review_scores(review_id, scores):
    """scores: {criterion: 1..6} — only criteria allowed for this business are
    stored (the caller passes them pre-filtered; this is the last guard).
    v160-fix: مقیاس رسمی ۶ستونه (v157) — قبلاً اینجا به ۵ بریده می‌شد و
    ستارهٔ ششمِ مشتری بی‌صدا گم می‌شد."""
    con = connect()
    con.execute("DELETE FROM review_scores WHERE review_id=?", (review_id,))
    for k, v in (scores or {}).items():
        if k not in REVIEW_ALLOWED:
            continue
        try:
            n = max(1, min(6, int(v)))
        except Exception:
            continue
        con.execute("INSERT INTO review_scores(review_id,criterion,score) "
                    "VALUES(?,?,?)", (review_id, k, n))
    con.commit(); con.close()


def review_scores(review_id):
    return {r["criterion"]: r["score"] for r in
            _rows("SELECT criterion,score FROM review_scores WHERE review_id=?",
                  (review_id,))}


def criteria_averages(biz_id):
    """Average per allowed criterion across approved reviews — the bars. Only
    the criteria this business's facilities allow are ever shown."""
    rows = _rows(
        "SELECT rs.criterion, AVG(rs.score) a, COUNT(*) n FROM review_scores rs "
        "JOIN reviews r ON r.id=rs.review_id "
        "WHERE r.biz_id=? AND r.status='approved' GROUP BY rs.criterion", (biz_id,))
    have = {r["criterion"]: (round(r["a"], 1), r["n"]) for r in rows}
    out = []
    for code, label in biz_criteria(biz_id):
        if code in have:
            out.append({"code": code, "label": label,
                        "avg": have[code][0], "n": have[code][1]})
    return out


def _allowed_scores(biz_id, scores):
    """Only the criteria this business may be scored on (v151)."""
    allowed = {c for c, _l in biz_criteria(biz_id)}
    return {k: v for k, v in (scores or {}).items() if k in allowed}


def add_review_full(biz_id, author, rating, body, scores=None, auto_approve=False, image="", customer_id=None, spam_flag=0):
    # v151: a review's rating is no longer an independent free number — when
    # criteria are given, it is the mean of the *allowed* criteria (half up).
    # 0 means "text review, no stars" and stays out of every average.
    allowed = _allowed_scores(biz_id, scores)
    if allowed:
        rating = int((sum(allowed.values()) / len(allowed)) + 0.5)
    else:
        rating = int(max(0, min(6, int(rating or 0))))   # v160-fix: مقیاس ۶ستونه
    if spam_flag:
        auto_approve = False   # v276: held content never auto-approves
    rid = _run("INSERT INTO reviews(biz_id,author,rating,body,status,image,customer_id,spam_flag) "
               "VALUES(?,?,?,?,?,?,?,?)",
               (biz_id, author, rating, body,
                "approved" if auto_approve else "pending", image or "", customer_id, spam_flag))
    if allowed:
        set_review_scores(rid, allowed)
    _owner_notify_biz(biz_id, "social", "⭐ نظر تازه‌ای روی کسب‌وکار شما ثبت شد.", "/my/reviews")
    return rid


def customer_rated_review(biz_id, customer_id):
    """Existing scored review by this account for this business (any status),
    or None — one star per customer per shop."""
    if not customer_id:
        return None
    return _one("SELECT id FROM reviews WHERE biz_id=? AND customer_id=? "
                "AND rating>0 ORDER BY id DESC LIMIT 1", (biz_id, customer_id))


# ----------------------------------------------------------- edit approval
def pending_edits(status="pending", page=None, per=50):
    q = ("SELECT e.*, b.name bizname, b.slug bizslug, o.phone ownerphone "
         "FROM edits e JOIN businesses b ON b.id=e.biz_id "
         "LEFT JOIN owners o ON o.id=e.owner_id WHERE 1=1")
    p = []
    if status:
        q += " AND e.status=?"; p.append(status)
    q += " ORDER BY e.id DESC"
    if page is not None:                      # v117/M3
        con = connect()
        out = _page_result(con, q, p, page, per)
        con.close()
        for r in out["rows"]:
            try:
                r["fields"] = json.loads(r["payload"])
            except Exception:
                r["fields"] = {}
        return out
    rows = _rows(q, p)
    for r in rows:
        try:
            r["fields"] = json.loads(r["payload"])
        except Exception:
            r["fields"] = {}
    return rows


FIELD_LABELS = {
    "name": "نام", "cat_slug": "دسته", "descr": "توضیحات", "phone": "تلفن",
    "whatsapp": "واتساپ", "address": "نشانی", "tags": "برچسب‌ها",
    "instagram": "اینستاگرام", "telegram": "تلگرام", "eitaa": "ایتا", "bale": "بله",
    "soroush": "سروش", "rubika": "روبیکا", "website": "وب‌سایت",
    "lat": "عرض جغرافیایی", "lng": "طول جغرافیایی", "hours": "ساعت کاری",
    "booking_on": "نوبت‌دهی",
}


def queue_edit(biz_id, owner_id, data):
    changed = {}
    cur = business(bid=biz_id) or {}
    for k, v in data.items():
        if str(cur.get(k) or "") != str(v or ""):
            changed[k] = v
    if not changed:
        return None
    # v175 (تلفیق فاز ۱۵): a re-submitted identical change must not stack
    # another pending row on the admin queue — the second row was review
    # noise and approving the stale one was a silent no-op. Same biz with
    # the exact same pending diff → reuse the existing row.
    payload = json.dumps(changed, ensure_ascii=False)
    old = _one(
        "SELECT id FROM edits WHERE biz_id=? AND status='pending' AND payload=? "
        "ORDER BY id DESC LIMIT 1", (biz_id, payload))
    if old:
        return old["id"]
    return _run("INSERT INTO edits(biz_id,owner_id,payload) VALUES(?,?,?)",
                (biz_id, owner_id, payload))


def decide_edit(eid, approve):
    e = _one("SELECT * FROM edits WHERE id=?", (eid,))
    if not e:
        return False
    if approve:
        try:
            save_business(json.loads(e["payload"]), e["biz_id"])
        except Exception:
            return False
    _upd("edits", eid, status="approved" if approve else "rejected")
    b = business(bid=e["biz_id"]) or {}
    bname = b.get("name", "کسب‌وکار")
    if approve:
        owner_notify(e.get("owner_id"), "biz",
                     f"تغییرات «{bname}» تأیید و منتشر شد.", f"/b/{b.get('slug', '')}",
                     push=False)   # v142 matrix: push خاموش برای ویرایش‌های خودِ دکان‌دار
    else:
        owner_notify(e.get("owner_id"), "biz",
                     f"تغییرات پیشنهادی «{bname}» رد شد.", "/my/businesses",
                     push=False)   # v142 matrix: push خاموش برای ویرایش‌های خودِ دکان‌دار
    return True


# ------------------------------------------------------------ saved alerts
def alerts(active_only=False, page=None, per=50):
    q = "SELECT * FROM alerts"
    if active_only:
        q += " WHERE active=1"
    q += " ORDER BY id DESC"
    if page is not None:                      # v117/M3
        con = connect()
        out = _page_result(con, q, [], page, per)
        con.close()
        return out
    return _rows(q)


def add_alert(phone, term="", cat_slug=""):
    phone = norm_phone(phone)
    if not valid_phone(phone):
        return None, "شمارهٔ موبایل معتبر نیست."
    if not term and not cat_slug:
        return None, "دست‌کم یک عبارت یا دسته لازم است."
    dup = _one("SELECT id FROM alerts WHERE phone=? AND term=? AND cat_slug=?",
               (phone, term, cat_slug))
    if dup:
        return dup["id"], "این هشدار قبلاً ثبت شده است."
    aid = _run("INSERT INTO alerts(phone,term,cat_slug) VALUES(?,?,?)",
               (phone, term, cat_slug))
    return aid, "هشدار ثبت شد. وقتی کسب‌وکار مطابقی اضافه شود پیامک می‌شود."


def delete_alert(aid):
    return _run("DELETE FROM alerts WHERE id=?", (aid,))


def toggle_alert(aid, active):
    return _upd("alerts", aid, active=int(bool(active)))


def matching_alerts(biz):
    """Who asked to be told about a business like this one?"""
    out = []
    hay = normalize_fa(f"{biz.get('name','')} {biz.get('descr','')} "
                       f"{biz.get('tags','')} {biz.get('address','')}")
    for a in alerts(active_only=True):
        if a["cat_slug"] and a["cat_slug"] != biz.get("cat_slug"):
            continue
        if a["term"] and normalize_fa(a["term"]) not in hay:
            continue
        out.append(a)
    return out


def mark_alert_sent(aid):
    return _run("UPDATE alerts SET sent=sent+1 WHERE id=?", (aid,))


# ------------------------------------------------------- geo / radius search
def haversine_km(lat1, lng1, lat2, lng2):
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = (math.sin(dp / 2) ** 2 +
         math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2)
    return 2 * R * math.asin(math.sqrt(a))


def nearby(lat, lng, radius_km=3.0, cat="", term="", limit=60):
    rows = businesses(status="published", cat=cat or None, order="featured")
    out = []
    t = normalize_fa(term) if term else ""
    for b in rows:
        if b.get("lat") is None or b.get("lng") is None:
            continue
        if t and t not in normalize_fa(f"{b['name']} {b['descr']} {b['tags']} {b['address']}"):
            continue
        d = haversine_km(float(lat), float(lng), float(b["lat"]), float(b["lng"]))
        if d <= radius_km:
            b["distance_km"] = round(d, 2)
            out.append(b)
    out.sort(key=lambda x: x["distance_km"])
    return out[:limit]


# ------------------------------------------------------------ site insights
def site_insights(days=30):
    """Whole-site analytics — the thing the panel had no screen for."""
    con = connect()
    since = (datetime.date.today() - datetime.timedelta(days=days - 1)).isoformat()
    series = {}
    for r in con.execute("SELECT day, kind, SUM(n) t FROM events WHERE day>=? "
                         "GROUP BY day, kind", (since,)):
        series.setdefault(r["day"], {})[r["kind"]] = r["t"]
    days_list = [(datetime.date.today() - datetime.timedelta(days=i)).isoformat()
                 for i in range(days - 1, -1, -1)]
    KINDS = ("view", "phone", "whatsapp", "route", "share")
    daily = [{"day": d, **{k: series.get(d, {}).get(k, 0) for k in KINDS}}
             for d in days_list]
    totals = {k: sum(x[k] for x in daily) for k in KINDS}

    top = [dict(r) for r in con.execute(
        "SELECT b.id, b.name, b.slug, COALESCE(SUM(e.n),0) t FROM businesses b "
        "LEFT JOIN events e ON e.biz_id=b.id AND e.day>=? AND e.kind='view' "
        "GROUP BY b.id ORDER BY t DESC, b.views DESC LIMIT 10", (since,))]
    cats_ = [dict(r) for r in con.execute(
        "SELECT c.name, c.slug, COUNT(b.id) n FROM categories c "
        "LEFT JOIN businesses b ON b.cat_slug=c.slug AND b.status='published' "
        "GROUP BY c.id ORDER BY n DESC LIMIT 10")]
    growth = [dict(r) for r in con.execute(
        "SELECT substr(created,1,7) m, COUNT(*) n FROM businesses "
        "GROUP BY m ORDER BY m DESC LIMIT 12")]
    con.close()

    counts = {
        "questions_open": len(questions(status="pending")),
        "reports_open": len(reports(status="open")),
        "subs_pending": len(subscriptions(status="pending")),
        "subs_active": len([s for s in subscriptions(status="active") if s["is_live"]]),
        "edits_pending": len(pending_edits()),
        "alerts": len(alerts(active_only=True)),
        "events": len(cityevents(upcoming_only=True)),
        "ads": len(ads(active_only=True)),
    }
    revenue = sum(s["amount"] for s in subscriptions(status="active"))
    return {"daily": daily, "totals": totals, "top": top, "cats": cats_,
            "growth": list(reversed(growth)), "counts": counts, "revenue": revenue,
            "days": days}


# ------------------------------------------------------------ JSON-LD / SEO
def jsonld_business(b, base_url=""):
    """Schema.org LocalBusiness so Google shows stars, hours and address.

    The directory went nationwide (31 provinces / 353 cities) in v37, so the
    locality/region come from the business's OWN city/province — never a
    hard-coded "نجف‌آباد" that would pin every shop to one town and poison
    local search. Empty values fall back to the original hometown so older
    rows without a city still produce valid schema. (Security/SEO fix.)
    """
    DAY = {"sat": "Saturday", "sun": "Sunday", "mon": "Monday", "tue": "Tuesday",
           "wed": "Wednesday", "thu": "Thursday", "fri": "Friday"}
    spec = []
    for k, ranges in (b.get("hours_map") or {}).items():
        for r in ranges:
            if len(r) == 2:
                spec.append({"@type": "OpeningHoursSpecification",
                             "dayOfWeek": DAY.get(k, k),
                             "opens": r[0], "closes": r[1]})
    locality = (b.get("city") or "").strip() or "نجف‌آباد"
    region = (b.get("province") or "").strip() or "اصفهان"
    d = {
        "@context": "https://schema.org",
        "@type": "LocalBusiness",
        "name": b.get("name"),
        "description": b.get("descr") or "",
        "url": f"{base_url}/b/{b.get('slug')}",
        "address": {"@type": "PostalAddress",
                    "streetAddress": b.get("address") or "",
                    "addressLocality": locality,
                    "addressRegion": region,
                    "addressCountry": "IR"},
    }
    if b.get("phone"):
        d["telephone"] = b["phone"]
    if b.get("lat") and b.get("lng"):
        d["geo"] = {"@type": "GeoCoordinates",
                    "latitude": b["lat"], "longitude": b["lng"]}
    if spec:
        d["openingHoursSpecification"] = spec
    if b.get("images"):
        d["image"] = [f"{base_url}{i}" if i.startswith("/") else i
                      for i in b["images"][:5]]
    if b.get("nreviews"):
        d["aggregateRating"] = {"@type": "AggregateRating",
                                "ratingValue": b.get("rating") or 0,
                                "reviewCount": b["nreviews"],
                                "bestRating": 6, "worstRating": 1}
    # Every public profile helps Google tie the entity together (Local SEO).
    # Website, Instagram and Telegram are all real signals; only present
    # ones are listed, and a bare/relative value is skipped.
    same_as = []

    def _add(v, pref):
        v = (v or "").strip()
        if not v:
            return
        if v.startswith(("http://", "https://")):
            same_as.append(v)
        elif pref:
            # '@channel' or 'channel' both become the profile URL
            same_as.append(pref + v.lstrip("@"))

    _add(b.get("website"), "https://")
    _add(b.get("instagram"), "https://instagram.com/")
    _add(b.get("telegram"), "https://t.me/")
    for _k, (_pref, _lbl, _ic) in MESSENGERS.items():
        _add(b.get(_k), _pref)
    if same_as:
        d["sameAs"] = same_as
    return d


def jsonld_product(it, biz, base_url=""):
    """Schema.org Product for a catalogue item (E-Commerce SEO). Google uses
    Offer.price to render rich results; a call-for-price item omits the offer
    rather than advertising a wrong number."""
    if not it or it.get("kind") not in ("product", "custom"):
        return None
    d = {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": it.get("title"),
        "description": it.get("descr") or "",
        "url": f"{base_url}/b/{biz.get('slug')}",
    }
    if it.get("brand"):
        d["brand"] = {"@type": "Brand", "name": it["brand"]}
    if it.get("cover"):
        d["image"] = [f"{base_url}{it['cover']}" if it["cover"].startswith("/")
                      else it["cover"]]
    agg = it.get("rating") or it.get("avg_rating")
    if agg:
        d["aggregateRating"] = {"@type": "AggregateRating",
                                "ratingValue": agg,
                                "reviewCount": it.get("nreviews") or 1,
                                "bestRating": 6, "worstRating": 1}
    price = int(it.get("price") or 0)
    if price and it.get("price_type") in ("fixed", "from"):
        off = {"@type": "Offer",
               "price": str(price),
               "priceCurrency": "IRR",
               "availability": ("https://schema.org/InStock" if it.get("in_stock")
                                else "https://schema.org/OutOfStock"),
               "url": f"{base_url}/b/{biz.get('slug')}"}
        old = int(it.get("old_price") or 0)
        if old and old > price:
            off["priceValidUntil"] = (datetime.date.today() +
                                      datetime.timedelta(days=30)).isoformat()
        d["offers"] = off
    return d


def jsonld_website(s, base_url=""):
    """Schema.org WebSite + SearchAction sitelinks box (technical SEO)."""
    d = {"@context": "https://schema.org",
         "@type": "WebSite",
         "name": s.get("site_name"),
         "url": base_url or "/",
         "inLanguage": "fa-IR"}
    if base_url:
        d["potentialAction"] = {
            "@type": "SearchAction",
            "target": {"@type": "EntryPoint",
                       "urlTemplate": f"{base_url}/businesses?q={{search_term_string}}"},
            "query-input": "required name=search_term_string"}
    return d


def jsonld_breadcrumb(items, base_url=""):
    return {"@context": "https://schema.org", "@type": "BreadcrumbList",
            "itemListElement": [
                {"@type": "ListItem", "position": i + 1, "name": n,
                 "item": f"{base_url}{u}" if u else None}
                for i, (n, u) in enumerate(items)]}


def jsonld_org(s, base_url=""):
    same = []
    for k, pre in (("instagram", "https://instagram.com/"), ("telegram", "https://t.me/"), ("eitaa", "https://eitaa.com/"),
                   ("bale", "https://ble.ir/"), ("soroush", "https://splus.ir/"), ("rubika", "https://rubika.ir/")):
        v = (s.get(k) or "").strip()
        if v and v.rstrip("/") != pre.rstrip("/"):
            same.append(v if v.startswith("http") else pre + v.lstrip("@"))
    d = {"@context": "https://schema.org", "@type": "Organization",
         "name": s.get("site_name"), "alternateName": "Dastgir", "url": base_url or "/",
         "logo": (base_url or "") + "/assets/img/icons/app-512.png",
         "description": s.get("description"),
         "email": s.get("email"), "telephone": s.get("phone_raw"),
         "address": {"@type": "PostalAddress",
                     "streetAddress": s.get("address"),
                     "addressLocality": "نجف‌آباد", "addressCountry": "IR"}}
    if same:
        d["sameAs"] = same
    return d


def jsonld_article(p, s, base_url=""):
    """v217: مقالهٔ وبلاگ → Article (نویسنده = سازمان)."""
    d = {"@context": "https://schema.org", "@type": "Article",
         "headline": (p.get("title") or "")[:110],
         "description": p.get("excerpt") or "",
         "datePublished": str(p.get("created") or "")[:19].replace(" ", "T"),
         "inLanguage": "fa-IR",
         "mainEntityOfPage": f"{base_url}/blog/{p.get('slug')}",
         "author": {"@type": "Organization", "name": s.get("site_name")},
         "publisher": {"@type": "Organization", "name": s.get("site_name"),
                       "logo": {"@type": "ImageObject", "url": f"{base_url}/assets/img/icons/app-512.png"}}}
    if p.get("updated"):
        d["dateModified"] = str(p["updated"])[:19].replace(" ", "T")
    if p.get("image"):
        d["image"] = [base_url + p["image"] if str(p["image"]).startswith("/") else p["image"]]
    return d


def jsonld_biz_list(rows, base_url="", name=""):
    """v217: فهرست کسب‌وکارها (دسته/شهر) → ItemList برای سایت‌لینک و rich results."""
    if not rows:
        return None
    return {"@context": "https://schema.org", "@type": "ItemList", "name": name or "کسب‌وکارها",
            "numberOfItems": len(rows),
            "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": r.get("name"),
                                 "url": f"{base_url}/b/{r.get('slug')}"} for i, r in enumerate(rows[:30])]}


def jsonld_faq(qs):
    published = [q for q in qs if q.get("answer")]
    if not published:
        return None
    return {"@context": "https://schema.org", "@type": "FAQPage",
            "mainEntity": [{"@type": "Question", "name": q["body"],
                            "acceptedAnswer": {"@type": "Answer", "text": q["answer"]}}
                           for q in published[:20]]}


def jsonld_event(e, base_url=""):
    d = {"@context": "https://schema.org", "@type": "Event",
         "name": e.get("title"), "description": e.get("descr") or "",
         "url": f"{base_url}/events/{e.get('slug')}",
         "location": {"@type": "Place", "name": e.get("place") or "نجف‌آباد",
                      "address": e.get("place") or "نجف‌آباد، اصفهان، ایران"}}
    if e.get("date"):
        d["startDate"] = f"{e['date']}T{e.get('time') or '00:00'}"
    return d


# ==========================================================================
#  SEARCH ANALYTICS  —  what the city is looking for
# ==========================================================================
def log_search(term, cat="", results=0):
    """Record a search. Zero-result terms tell you which trade to recruit."""
    term = (term or "").strip()
    if not term or len(term) > 120:
        return
    _run("INSERT INTO searches(term,norm,cat,results,day) VALUES(?,?,?,?,?)",
         (term, normalize_fa(term), cat or "",
          int(results), datetime.date.today().isoformat()))


def top_searches(days=30, limit=20, zero_only=False):
    since = (datetime.date.today() - datetime.timedelta(days=days - 1)).isoformat()
    q = ("SELECT norm, MIN(term) term, COUNT(*) n, "
         "SUM(CASE WHEN results=0 THEN 1 ELSE 0 END) zero, "
         "MAX(results) best "
         "FROM searches WHERE day>=? GROUP BY norm")
    if zero_only:
        q += " HAVING best=0"
    q += f" ORDER BY n DESC LIMIT {int(limit)}"
    return _rows(q, (since,))


def search_totals(days=30):
    since = (datetime.date.today() - datetime.timedelta(days=days - 1)).isoformat()
    r = _one("SELECT COUNT(*) total, "
             "SUM(CASE WHEN results=0 THEN 1 ELSE 0 END) zero "
             "FROM searches WHERE day>=?", (since,)) or {}
    total = r.get("total") or 0
    zero = r.get("zero") or 0
    return {"total": total, "zero": zero,
            "hit_rate": round((total - zero) * 100.0 / total, 1) if total else 0.0}


def clear_searches():
    return _run("DELETE FROM searches")


# ==========================================================================
#  FEATURE GATING  —  what a free shop gets, what stays locked
#  Research-backed: gate AFTER the aha moment, never before. Locked features
#  stay VISIBLE but blurred, because showing what is missing converts far
#  better than hiding it.
# ==========================================================================

# Every gateable capability, in the order it appears in the owner panel.
# `founder` = also unlocked for the first N shops (the founding-member promise).
FEATURES = [
    # key            label                        icon         founder  why it is worth paying for
    ("gallery",      "گالری تصاویر کامل",         "image",     True,
     "تا ۲۰ عکس از دکان، محصولات و نمونه‌کارها"),
    ("catalog",      "کاتالوگ نامحدود",           "shopping",  True,
     "همهٔ محصولات و خدمات با قیمت، تخفیف و عکس"),
    ("booking",      "نوبت‌دهی آنلاین",            "calendar",  True,
     "مشتری بدون تماس نوبت می‌گیرد؛ دفتر نوبت کاغذی حذف می‌شود"),
    ("stats",        "آمار بازدید و تماس",         "chart",     True,
     "ببینید چند نفر صفحه‌تان را دیدند و شماره‌تان را گرفتند"),
    ("reply",        "پاسخ به نظرات",              "message",   True,
     "زیر هر نظر پاسخ رسمی بگذارید"),
    ("qa",           "پاسخ به پرسش‌ها",            "help",      True,
     "به سؤال مشتریان جواب دهید و اعتماد بسازید"),
    ("inquiry",      "دریافت پیام مشتری",          "message",   True,
     "مشتری بدون نیاز به شمارهٔ تلفن پیام می‌دهد"),
    ("broadcast",    "پنل فراخوان دکان",           "bell",      True,
     "«موجود شد» و خبرهای دکان را به دنبال‌کننده‌ها برسانید"),
    ("social",       "لینک اینستاگرام، تلگرام و پیام‌رسان‌های ایرانی", "instagram", True,
     "شبکه‌های اجتماعی‌تان روی صفحه دیده شود"),
    ("featured",     "جایگاه ویژه در فهرست",       "sparkles",  False,
     "بالای نتایج جست‌وجو، پیش از رقبا"),
    ("homepage",     "نمایش در صفحهٔ نخست",        "star",      False,
     "در بخش «کسب‌وکارهای ویژهٔ شهر» صفحهٔ اصلی"),
    ("banner",       "بنر تبلیغاتی",               "zap",       False,
     "بنر شما در صفحهٔ اصلی و فهرست‌ها نمایش داده می‌شود"),
    ("event",        "ثبت رویداد و مناسبت",        "calendar",  False,
     "حراج، افتتاحیه و جشنواره‌تان را اعلام کنید"),
    ("export",       "خروجی اکسل مشتریان",         "download",  False,
     "فهرست نوبت‌ها و درخواست‌ها را دانلود کنید"),
]

FEATURE_LABELS = {k: lbl for k, lbl, _i, _f, _w in FEATURES}
FEATURE_ICONS = {k: ic for k, _l, ic, _f, _w in FEATURES}
FEATURE_WHY = {k: why for k, _l, _i, _f, why in FEATURES}
FOUNDER_FEATURES = [k for k, _l, _i, f, _w in FEATURES if f]

# The founding-member promise: the first N shops keep the generous set for
# free, forever. Everyone after them gets the medium set.
FOUNDER_LIMIT_KEY = "founder_limit"       # how many shops count as founders
FOUNDER_ITEMS_KEY = "founder_max_items"
FOUNDER_PHOTOS_KEY = "founder_max_photos"


def founder_settings():
    s = get_settings()
    def _i(k, d):
        try:
            return int(s.get(k, d))
        except Exception:
            return d
    return {
        "limit": _i(FOUNDER_LIMIT_KEY, 100),
        "items": _i(FOUNDER_ITEMS_KEY, 10),
        "photos": _i(FOUNDER_PHOTOS_KEY, 6),
        "plain_items": _i("free_max_items", 3),
        "plain_photos": _i("free_max_photos", 3),
    }


def founder_rank(biz_id):
    """1-based position among all shops, oldest first. Used to decide who is
    inside the founding-member window. Returns None if the shop is gone."""
    r = _one("SELECT COUNT(*) n FROM businesses WHERE id <= ? ", (biz_id,))
    return r["n"] if r else None


def is_founder(biz_id):
    """The promise made on the doorstep: 'you are shop number 23, the first
    100 keep these features free forever'. Rank is by id, so it can never be
    taken away by later signups."""
    cfg = founder_settings()
    if cfg["limit"] <= 0:
        return False
    rank = founder_rank(biz_id)
    return bool(rank and rank <= cfg["limit"])


def founders_left():
    cfg = founder_settings()
    n = _one("SELECT COUNT(*) c FROM businesses")["c"]
    return max(0, cfg["limit"] - n)


def _manual_grants(biz_id):
    """Features the admin unlocked by hand for this shop — the key you hold."""
    r = _one("SELECT unlocked FROM biz_features WHERE biz_id=?", (biz_id,))
    if not r or not r["unlocked"]:
        return set()
    return {x for x in r["unlocked"].split(",") if x}


def set_manual_grants(biz_id, keys):
    access_cache_clear()
    keys = [k for k in keys if k in FEATURE_LABELS]
    _run("INSERT INTO biz_features(biz_id,unlocked) VALUES(?,?) "
         "ON CONFLICT(biz_id) DO UPDATE SET unlocked=excluded.unlocked",
         (biz_id, ",".join(keys)))
    log("feature.grant", f"{biz_id}: {','.join(keys) or '(none)'}")
    return len(keys)


def grant_feature(biz_id, key):
    access_cache_clear()
    cur = _manual_grants(biz_id)
    cur.add(key)
    return set_manual_grants(biz_id, list(cur))


def revoke_feature(biz_id, key):
    access_cache_clear()
    cur = _manual_grants(biz_id)
    cur.discard(key)
    return set_manual_grants(biz_id, list(cur))


def plan_features(plan_slug):
    """Which feature keys a plan includes. Stored as a comma list on the plan
    so you can change what each tier offers from the panel, without code."""
    p = plan(slug=plan_slug)
    if not p:
        return set()
    raw = (p.get("features") or "").strip()
    if raw == "*":
        return set(FEATURE_LABELS)
    return {x.strip() for x in raw.split(",") if x.strip()}


def latest_subscription(biz_id):
    """Most recent real subscription of any status — used for soft expiry so a
    lapsed paid plan keeps its features instead of gutting the shop overnight."""
    rows = [r for r in subscriptions(biz_id=biz_id)
            if r["status"] in ("active", "expired", "cancelled")]
    return max(rows, key=lambda r: r["id"]) if rows else None


def access_cache_clear():
    """Compatibility no-op. Global memoisation was removed: a module-level
    cache cannot see mutations made by ANOTHER process (the HTTP server and
    test/CLI runs each have their own memory), which produced stale access()
    results. apply_promotion() memoises locally instead."""
    pass


def access(biz_id):
    """The single source of truth for what one shop may do right now.

    SOFT EXPIRY: a lapsed paid plan KEEPS its features (photos, catalogue,
    badges, placement) so a late payment never wrecks a live business. Only
    the ADD-quota (max_items / max_photos) reverts to the free tier — the shop
    cannot add NEW things past the free cap, but nothing it already has is
    taken away and editing stays free. Renewing restores the full quota.

    Precedence for the feature keys (most permissive wins):
      1. a live paid subscription  — or a lapsed one, for soft expiry
      2. a manual unlock by the admin  (your key)
      3. the founding-member window    (first N shops)
      4. the plain free tier

    Results are memoised for a few seconds: a page render calls this many
    times per shop (list + gates), and the data cannot change mid-request.
    """
    cfg = founder_settings()
    sub = subscription_of(biz_id)           # live only
    latest = latest_subscription(biz_id)    # most recent, any status
    manual = _manual_grants(biz_id)
    founder = is_founder(biz_id)

    keys = set(manual)
    source = {k: "manual" for k in manual}

    if founder:
        for k in FOUNDER_FEATURES:
            keys.add(k)
            source.setdefault(k, "founder")

    # Which plan's FEATURES stay active: the live sub, or — on soft expiry —
    # the most recent paid plan that has since lapsed.
    feat_slug = None
    expired = False
    if sub:
        feat_slug = sub["plan_slug"]
    elif latest and latest["status"] == "expired":
        lp = plan(slug=latest["plan_slug"])
        if lp and lp["price"] > 0:
            feat_slug = latest["plan_slug"]
            expired = True
    if feat_slug:
        for k in plan_features(feat_slug):
            keys.add(k)
            source.setdefault(k, "plan-expired" if expired else "plan")

    # Quotas follow the LIVE subscription only. Expired -> free quotas, so the
    # shop can keep and edit everything it has but cannot add past the free cap.
    p = plan(slug=sub["plan_slug"]) if sub else None
    if p:
        max_items, max_photos = p["max_items"], p["max_photos"]
        plan_name = p["name"]
    elif founder:
        max_items, max_photos = cfg["items"], cfg["photos"]
        plan_name = "بنیان‌گذار"
    else:
        max_items, max_photos = cfg["plain_items"], cfg["plain_photos"]
        plan_name = "پایه (رایگان)"

    result = {
        "keys": keys,
        "source": source,
        "founder": founder,
        "rank": founder_rank(biz_id),
        "plan": (p or {}).get("slug", "free"),
        "plan_name": plan_name,
        "paid": bool(p and p.get("price")),
        "expired": expired,
        "expires": sub.get("expires") if sub else (latest.get("expires") if latest else None),
        "days_left": sub.get("days_left") if sub else (latest.get("days_left") if latest else None),
        "max_items": max_items,
        "max_photos": max_photos,
    }
    return result


def can(biz_id, key):
    """Server-side check. Never trust the UI — every gated route calls this."""
    return key in access(biz_id)["keys"]


def locked_features(biz_id):
    a = access(biz_id)
    return [k for k, _l, _i, _f, _w in FEATURES if k not in a["keys"]]


# --------------------------------------------------------------------------
#  Applying the gate to placement features
#
#  `featured` (top of listings), `homepage` (front-page strip) and `banner`
#  are things the admin flips on a business, but they are also things people
#  pay for. Both must be true at once: the admin said yes AND the shop holds
#  the feature. Enforcing it here rather than in each template means a lapsed
#  subscription silently stops the promotion everywhere, with no stale flag
#  left behind in the businesses table to clean up.
# --------------------------------------------------------------------------
def is_promoted(b, key="featured"):
    """Does this business row genuinely get the placement `key` right now?"""
    if not b or not b.get("id"):
        return False
    if key == "featured" and not b.get("featured"):
        return False
    return can(b["id"], key)


def apply_promotion(rows):
    """Strip the `featured` flag from any row that no longer pays for it, and
    stamp `on_homepage` so callers do not each re-query access().

    One access() call per row (was two), and access() itself is TTL-cached,
    so listing 500 shops costs ~1 query per shop instead of ~10. (Perf fix.)"""
    local = {}
    for b in rows:
        acc = local.get(b["id"]) or access(b["id"])
        local[b["id"]] = acc
        keys = acc["keys"]
        if b.get("featured") and "featured" not in keys:
            b["featured"] = 0
        b["on_homepage"] = "homepage" in keys
    return rows


def homepage_businesses(limit=6):
    """The front-page strip. Only shops holding `homepage` may appear; if too
    few qualify, the remainder is filled with the best-rated shops so the
    section is never a sad half-empty row on a young directory."""
    rows = apply_promotion(businesses(status="published", order="featured"))
    picked = [b for b in rows if b.get("on_homepage")][:limit]
    if len(picked) < limit:
        have = {b["id"] for b in picked}
        for b in rows:
            if b["id"] not in have:
                picked.append(b)
                if len(picked) >= limit:
                    break
    return picked[:limit]

# ==========================================================================
#  FEATURES — customers, chat, orders, areas, favourites, toplists, deals,
#  stories, follows, notifications, moderation  (v28→v34)
#  Moved to server/features.py (architecture: keep this file a focused data
#  layer). Re-exported here so every existing `db.<name>` call site still
#  works unchanged.
# ==========================================================================
from features import *  # noqa: F401,F403


# ==========================================================================
#  CITIES  (v37 — nationwide: all Iranian provinces & cities)
# ==========================================================================
def provinces():
    return [r["province"] for r in _rows(
        "SELECT province FROM cities GROUP BY province ORDER BY province")]


def cities_in(province):
    return _rows("SELECT * FROM cities WHERE province=? ORDER BY is_capital DESC, name",
                 (province,))


def city_province(city):
    r = _one("SELECT province FROM cities WHERE name=?", (city,))
    return r["province"] if r else ""


def cities_all():
    return _rows("SELECT * FROM cities ORDER BY province, is_capital DESC, name")


def businesses_city_counts():
    return _rows(
        "SELECT COALESCE(city,'') city, COUNT(*) c FROM businesses "
        "WHERE status='published' GROUP BY city ORDER BY c DESC")


# ==========================================================================
#  v142 NOTIFICATION CORE — one source of truth for in-app notifications
#  (owner_notifications table + notif_prefs + customer notify via prefs)
# ==========================================================================

OWNER_KINDS = ("sub", "biz", "chat", "order", "social", "ticket", "summary")
CUST_KINDS = ("chat", "order", "booking", "reply", "haggle", "price", "news", "broadcast")
CUST_OFF_DEFAULT = {"follow"}          # kinds a customer must opt into


def _kind_enabled(role, user_id, kind):
    """No pref row -> the kind's default. A row stores the user's choice."""
    if kind in CUST_OFF_DEFAULT and role == "cust":
        default = 0
    else:
        default = 1
    r = _one("SELECT enabled FROM notif_prefs WHERE role=? AND user_id=? AND kind=?",
             (role, user_id, kind))
    if r is None:
        return bool(default)
    return bool(r["enabled"])


def notify_customer(customer_id, kind, text, link="", push=True):
    """v142 core for customer notifications (replaces features.notify body).
    Respects the customer's per-kind preference; trims like the old helper.
    push=False silences the web-push layer for low-value events."""
    if not customer_id:
        return False
    if not _kind_enabled("cust", customer_id, kind):
        return False
    _run("INSERT INTO notifications(customer_id,kind,text,link) VALUES(?,?,?,?)",
         (customer_id, kind, str(text)[:200], str(link)[:200]))
    _maybe_messenger("cust", customer_id, text, link)
    if push:
        _maybe_push("cust", customer_id, text, link)
    return True


def owner_notify(owner_id, kind, text, link="", push=True):
    """Insert one in-app notification for a shopkeeper, if the site-wide
    notifications key is on and the owner has not muted this kind.
    push=False silences the web-push layer for low-value events."""
    if not owner_id:
        return False
    st = get_settings()
    if st.get("notif_enabled", "1") != "1":
        return False
    if not _kind_enabled("owner", owner_id, kind):
        return False
    _run("INSERT INTO owner_notifications(owner_id,kind,text,link) VALUES(?,?,?,?)",
         (owner_id, kind, str(text)[:200], str(link)[:200]))
    _maybe_messenger("owner", owner_id, text, link)
    if push:
        _maybe_push("owner", owner_id, text, link)
    return True


def _maybe_push(role, user_id, text, link):
    """v142 web-push layer (FCM v1). Fully optional: without configuration or
    on any error the in-app row already saved is the source of truth and the
    push attempt is swallowed after one log line (never a server error)."""
    try:
        import fcm
        fcm.push_for(role, user_id, text, link)
    except Exception:
        import traceback
        traceback.print_exc()


def _maybe_messenger(role, user_id, text, link):
    """Best-effort bot delivery is independent from optional FCM web push."""
    for platform in ("bale", "soroush"):
        try:
            chat_id = messenger_chat_for(role, user_id, platform)
            if chat_id:
                transport = __import__(platform)
                base = (get_settings().get("site_url") or "").strip().rstrip("/")
                url = (base + link) if (base.startswith("https://") and
                                        str(link).startswith("/")) else ""
                if role == "cust" and _live_order_receipt(platform, transport, user_id, chat_id, link, url, text):
                    continue
                transport.send_notification(chat_id, text, url)
        except Exception:
            pass


# ------------------------------------------------------------ v212 live receipt
_ORDER_STEPS = (("new", "ثبت شد"), ("confirmed", "تأیید شد"),
                ("ready", "آمادهٔ تحویل"), ("done", "تحویل شد"))


def order_receipt_text(order_id, note=""):
    """Persian, customer-safe status card for one order (no address/note).
    `note` is the latest notification sentence (kept so information beyond
    the bare status — e.g. a rejected cancel request — is never lost).
    Returns "" when the order does not exist."""
    o = _one("SELECT o.id,o.status,o.total,o.created,b.name bizname,b.slug "
             "FROM orders o JOIN businesses b ON b.id=o.biz_id WHERE o.id=?", (int(order_id),))
    if not o:
        return ""
    fa = lambda v: str(int(v or 0)).translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))
    status = o["status"]
    lines = [f"🧾 رسید سفارش #{fa(o['id'])}", f"کسب‌وکار: {str(o['bizname'] or '')[:80]}", ""]
    if status == "cancelled":
        lines.append("❌ این سفارش لغو شد.")
    else:
        idx = [k for k, _ in _ORDER_STEPS].index(status) if status in dict(_ORDER_STEPS) else 0
        for i, (_, label) in enumerate(_ORDER_STEPS):
            mark = "✅" if i < idx else ("🔵" if i == idx else "⚪️")
            lines.append(f"{mark} {label}")
    items = _rows("SELECT title,qty FROM order_items WHERE order_id=? ORDER BY id LIMIT 8", (int(order_id),))
    if items:
        lines.append("")
        lines.extend(f"• {str(it['title'] or '')[:60]} × {fa(it['qty'])}" for it in items)
    if get_settings().get("prices_enabled") == "1" and o.get("total"):
        lines.append(f"\nمجموع: {fa(o['total'])} تومان")
    if note:
        lines.append(f"\n📣 {str(note)[:200]}")
    lines.append(f"\nآخرین به‌روزرسانی: {iran_now().strftime('%H:%M')} · این پیام خودکار به‌روز می‌شود.")
    return "\n".join(lines)[:4096]


def _live_order_receipt(platform, transport, customer_id, chat_id, link, url, note=""):
    """v212: for customer 'order' notifications (link /me/order/<id>) edit the
    stored receipt message via editMessageText; on first use send + store it.
    Returns True when the receipt path fully handled the notification."""
    m = re.fullmatch(r"/me/order/(\d{1,12})", str(link or ""))
    if not m:
        return False
    oid = int(m.group(1))
    o = _one("SELECT customer_id FROM orders WHERE id=?", (oid,))
    if not o or str(o["customer_id"]) != str(customer_id):
        return False
    text = order_receipt_text(oid, note)
    if not text:
        return False
    markup = {"inline_keyboard": [[{"text": "📦 مشاهده در دست گیر", "url": url}]]} if url else \
             {"inline_keyboard": [[{"text": "📦 سفارش‌های من", "callback_data": "dg198:orders"}]]}
    row = _one("SELECT chat_id,message_id FROM order_receipts WHERE order_id=? AND platform=?", (oid, platform))
    if row and str(row["chat_id"]) == str(chat_id):
        if transport.edit_message_text(chat_id, int(row["message_id"]), text, markup):
            _run("UPDATE order_receipts SET updated=datetime('now') WHERE order_id=? AND platform=?", (oid, platform))
            return True
    mid = transport.send_message_id(chat_id, text, markup)
    if isinstance(mid, int):
        _run("INSERT OR REPLACE INTO order_receipts(order_id,platform,chat_id,message_id) VALUES(?,?,?,?)",
             (oid, platform, str(chat_id), mid))
        return True
    return False


def owner_ids_for_biz(biz_id):
    """Owner ids of a business (usually one)."""
    b = business(bid=biz_id)
    if not b or not b.get("owner_id"):
        return []
    return [b["owner_id"]]


def _owner_notify_biz(biz_id, kind, text, link="", push=True):
    """Notify every owner attached to a business. Called from hooks."""
    for oid in owner_ids_for_biz(biz_id):
        owner_notify(oid, kind, text, link, push=push)


def owner_notifications(owner_id, limit=100):
    return _rows("SELECT * FROM owner_notifications WHERE owner_id=? "
                 "ORDER BY id DESC LIMIT ?", (owner_id, int(limit)))


def business_owner_phone(biz_id):
    """Phone of the owner of a business, if any (self-chat guard)."""
    r = _one("SELECT o.phone FROM owners o JOIN businesses b ON b.owner_id=o.id "
             "WHERE b.id=? AND o.phone IS NOT NULL", (biz_id,))
    return r["phone"] if r else None


def customer_phone(customer_id):
    r = _one("SELECT phone FROM customers WHERE id=?", (customer_id,))
    return r["phone"] if r else None


def owner_has_business(owner_id):
    """v146: does this shopkeeper account actually own (or have submitted)
    at least one business? Unified login gives EVERY sign-in an owner
    session, so 'owner session exists' alone must not switch the bell or
    inbox to the shopkeeper view — only real shopkeepers get that."""
    if not owner_id:
        return False
    r = _one("SELECT 1 c FROM businesses WHERE owner_id=? LIMIT 1", (owner_id,))
    return bool(r)


def owner_unread(owner_id):
    if not owner_id:
        return 0
    r = _one("SELECT COUNT(*) c FROM owner_notifications "
             "WHERE owner_id=? AND read=0", (owner_id,))
    return int(r["c"]) if r else 0


def owner_mark_read(owner_id, nid=None):
    if nid:
        _run("UPDATE owner_notifications SET read=1 WHERE owner_id=? AND id=?",
             (owner_id, int(nid)))
    else:
        _run("UPDATE owner_notifications SET read=1 WHERE owner_id=?", (owner_id,))


def customer_mark_read(customer_id, nid=None):
    """v160-fix: همتای customer-sideِ owner_mark_read — قبلاً /me/notif/N/go
    به تابعی فراخوانی می‌کرد که وجود نداشت و 500 می‌داد."""
    if nid:
        _run("UPDATE notifications SET read=1 WHERE customer_id=? AND id=?",
             (customer_id, int(nid)))
    else:
        _run("UPDATE notifications SET read=1 WHERE customer_id=?", (customer_id,))


def owner_prefs(owner_id):
    return {r["kind"]: bool(r["enabled"]) for r in _rows(
        "SELECT kind, enabled FROM notif_prefs WHERE role='owner' AND user_id=?",
        (owner_id,))}


def set_owner_pref(owner_id, kind, on):
    if kind not in OWNER_KINDS:
        return False
    _run("INSERT INTO notif_prefs(role,user_id,kind,enabled) VALUES('owner',?,?,?) "
         "ON CONFLICT(role,user_id,kind) DO UPDATE SET enabled=excluded.enabled",
         (owner_id, kind, 1 if on else 0))
    return True


def customer_prefs(customer_id):
    return {r["kind"]: bool(r["enabled"]) for r in _rows(
        "SELECT kind, enabled FROM notif_prefs WHERE role='cust' AND user_id=?",
        (customer_id,))}


def set_customer_pref(customer_id, kind, on):
    if kind not in CUST_KINDS and kind not in CUST_OFF_DEFAULT:
        return False
    _run("INSERT INTO notif_prefs(role,user_id,kind,enabled) VALUES('cust',?,?,?) "
         "ON CONFLICT(role,user_id,kind) DO UPDATE SET enabled=excluded.enabled",
         (customer_id, kind, 1 if on else 0))
    return True


def kind_enabled(role, user_id, kind):
    """Public read of one kind's current state (settings pages)."""
    return _kind_enabled(role, user_id, kind)


def pref_state(role, user_id, kinds):
    """{kind: bool} for a list of kinds, defaults applied (settings pages)."""
    return {k: bool(_kind_enabled(role, user_id, k)) for k in kinds}


# ------------------------------------------------------------------ v142 web push subscriptions
def push_sub_save(role, user_id, sub):
    """Store one browser push subscription. sub = dict from the browser
    (endpoint + keys). Only the Chrome/FCM endpoint is accepted (v142 scope);
    returns (ok, msg)."""
    if role not in ("owner", "cust") or not user_id:
        return False, "نقش ناشناخته است"
    ep = str((sub or {}).get("endpoint") or "")
    if not ep.startswith("https://fcm.googleapis.com/fcm/send/"):
        return False, ("مرورگر شما push را پشتیبانی نمی‌کند؛ "
                       "اعلان داخل سایت می‌ماند.")
    token = ep.rstrip("/").split("/")[-1]
    if not token:
        return False, "اشتراک معتبر نیست"
    _run("INSERT INTO push_subs(role,user_id,token,sub) VALUES(?,?,?,?) "
         "ON CONFLICT(role,user_id,token) "
         "DO UPDATE SET sub=excluded.sub, created=excluded.created",
         (role, user_id, token, json.dumps(sub, ensure_ascii=False)))
    return True, ""


def push_sub_remove(role, user_id, sub):
    """Remove the subscription whose endpoint matches (role/user scoped)."""
    ep = str((sub or {}).get("endpoint") or "")
    token = ep.rstrip("/").split("/")[-1] if ep.startswith(
        "https://fcm.googleapis.com/fcm/send/") else ""
    if token:
        _run("DELETE FROM push_subs WHERE role=? AND user_id=? AND token=?",
             (role, user_id, token))


def push_tokens(role, user_id):
    return _rows("SELECT token, sub FROM push_subs "
                 "WHERE role=? AND user_id=? ORDER BY rowid", (role, user_id))


def push_prune_token(token):
    """FCM 404 = token died (reinstall/cleared data): drop every row using it."""
    _run("DELETE FROM push_subs WHERE token=?", (token,))


def purge_notifications():
    """Keep the phone small (v142): drop read notifications older than 60 days
    for both roles, then trim each inbox to its newest 200 rows."""
    _run("DELETE FROM notifications WHERE read=1 AND created < "
         "datetime('now', ?)", (f"-{60} days",))
    _run("DELETE FROM owner_notifications WHERE read=1 AND created < "
         "datetime('now', ?)", (f"-{60} days",))
    _run("DELETE FROM notifications WHERE read=1 AND id NOT IN "
         "(SELECT id FROM notifications n2 WHERE n2.customer_id = notifications.customer_id "
         "ORDER BY id DESC LIMIT 200)")
    _run("DELETE FROM owner_notifications WHERE read=1 AND id NOT IN "
         "(SELECT id FROM owner_notifications n2 WHERE n2.owner_id = owner_notifications.owner_id "
         "ORDER BY id DESC LIMIT 200)")
    return True


def sub_expiry_reminders(days=7):
    """Daily-ish reminder: notify each shopkeeper whose plan expires within
    `days`, at most once per calendar day per business."""
    today = datetime.date.today().isoformat()
    soon = datetime.date.today() + datetime.timedelta(days=int(days))
    rows = _rows("SELECT * FROM subscriptions WHERE status='active' "
                 "AND expires IS NOT NULL AND expires > ? AND expires <= ?",
                 (today, soon.isoformat()))
    sent = 0
    for r in rows:
        biz = business(bid=r["biz_id"]) or {}
        for oid in owner_ids_for_biz(r["biz_id"]):
            dup = _one("SELECT 1 x FROM owner_notifications WHERE owner_id=? "
                       "AND kind='sub' AND text LIKE '⏳%' AND created >= date('now')",
                       (oid,))
            if dup:
                continue
            owner_notify(oid, "sub",
                         f"⏳ تعرفهٔ «{biz.get('name', 'کسب‌وکار')}» تا {r['expires'][:10]} فعال است — برای تمدید اقدام کنید.",
                         "/my/plan")
            sent += 1
    return sent


def owner_notification(owner_id, nid):
    """One row of an owner's own inbox (for click-to-read redirects)."""
    return _one("SELECT * FROM owner_notifications WHERE owner_id=? AND id=?",
                (owner_id, int(nid)))


def customer_notification(customer_id, nid):
    return _one("SELECT * FROM notifications WHERE customer_id=? AND id=?",
                (customer_id, int(nid)))


# ==========================================================================
#  v156 BROADCAST (فراخوان دکان) — خبررسانی دنبال‌کننده‌ها + «موجود شد خبرم کن»
#  دسترسی دکان‌دار: db.broadcast_allowed — اشتراکِ دارای پرک broadcast،
#  بنیان‌گذارِ اولین-N، گرهٔ دستی مدیر، یا نشان «founder».
# ==========================================================================
BCAST_KINDS = {
    "restock":    ("box",   "موجود شد"),
    "price_drop": ("tag",   "ارزان شد"),
    "ending":     ("clock", "در حال اتمام"),
    "news":       ("bell",  "خبر دکان"),
}


def biz_has_badge(biz_id, slug):
    r = _one("SELECT 1 AS x FROM biz_badges bb JOIN badges b ON b.id=bb.badge_id "
             "WHERE bb.biz_id=? AND b.slug=? LIMIT 1", (biz_id, slug))
    return bool(r)


def broadcast_allowed(biz_id):
    """چهار مسیر هم‌ارز: پرک اشتراک (پلن/اولین-N/گرهٔ مدیر) یا نشان بنیان‌گذار."""
    if not biz_id:
        return False
    if can(biz_id, "broadcast"):
        return True
    return biz_has_badge(biz_id, "founder")


def biz_followers(biz_id):
    return _rows(
        "SELECT c.id, c.name, c.phone FROM follows f "
        "JOIN customers c ON c.id=f.customer_id "
        "WHERE f.biz_id=? ORDER BY f.created DESC", (biz_id,))


def follower_count(biz_id):
    r = _one("SELECT COUNT(*) AS n FROM follows WHERE biz_id=?", (biz_id,))
    return r["n"] if r else 0


def broadcast_create(biz_id, kind, text, item_id=None):
    """ساخت فراخوان + رساندنش به زنگولهٔ همهٔ دنبال‌کننده‌ها (فقط داخل سایت).
    برمی‌گرداند: (broadcast_id یا None، شمار گیرنده یا پیام خطا)."""
    row = _one("SELECT slug FROM businesses WHERE id=?", (biz_id,))
    if not row:
        return None, "کسب‌وکار نامعتبر است."
    text = (text or "").strip()
    if len(text) < 3:
        return None, "متن فراخوان را کامل بنویسید (حداقل ۳ نویسه)."
    if len(text) > 300:
        text = text[:300]
    kind = kind if kind in BCAST_KINDS else "news"
    followers = biz_followers(biz_id)
    link = f"/item/{int(item_id)}" if item_id else f"/b/{row['slug']}"
    sent = 0
    for c in followers:
        if notify_customer(c["id"], "broadcast", text, link, push=False):
            sent += 1
    new_id = _run("INSERT INTO broadcasts(biz_id,kind,text,item_id,recipients) "
                  "VALUES(?,?,?,?,?)", (biz_id, kind, text, item_id, sent))
    log("broadcast.send", f"biz {biz_id} kind {kind} -> {sent}")
    return new_id, sent


def broadcasts_recent(biz_ids, limit=12):
    """آخرین فراخوان‌های دکان(های) داده‌شده، تازه‌ترین اول."""
    if not biz_ids:
        return []
    marks = ",".join("?" * len(biz_ids))
    return _rows(
        f"SELECT * FROM broadcasts WHERE biz_id IN ({marks}) "
        f"ORDER BY id DESC LIMIT {int(limit)}", tuple(biz_ids))


def stock_request_add(biz_id, item_id, customer_id, source="item", qty=1, note=""):
    """ثبت «موجود شد خبرم کن». درخواستِ بازِ تکراری رد می‌شود؛ پس از
    fulfilled/dismissed درخواست دوباره آزاد است (فعال‌سازی ردیف قبلی).
    v177: qty (۱..۹۹) و یادداشت اختیاری."""
    if not customer_id:
        return False, "برای درخواست خبر، اول وارد حساب خود شوید."
    try:
        qty = max(1, min(99, int(qty or 1)))
    except (TypeError, ValueError):
        qty = 1
    note = (note or "").strip()[:140]
    prev = _one("SELECT id, status, fulfilled FROM stock_requests WHERE biz_id=? AND "
                "IFNULL(item_id,0)=IFNULL(?,0) AND customer_id=? "
                "ORDER BY id DESC LIMIT 1",
                (biz_id, item_id, customer_id))
    if prev and prev["status"] == "open":
        return False, "شما قبلاً برای همین مورد درخواست داده‌اید."
    if prev and (prev["fulfilled"] or "").strip():
        # v278: dedup ۲۴ ساعته — همان مورد بلافاصله پس از fulfillment
        # دوباره باز نمی‌شود (سیل «خبرم کن» به مالک). no-op + رویداد.
        age = _one("SELECT (julianday('now') - julianday(fulfilled)) * 86400.0 age "
                   "FROM stock_requests WHERE id=?", (prev["id"],))
        if age and age["age"] is not None and age["age"] < 86400:
            log("stock.request", f"dedup24h skip prev {prev['id']} biz {biz_id}")
            return False, ("درخواست شما اخیراً ثبت و بررسی شده است؛ اگر کالا دوباره "
                           "ناموجود شد، پس از ۲۴ ساعت مجدداً درخواست دهید. (درگاه: stockdup)")
    if prev:
        _run("UPDATE stock_requests SET status='open', source=?, qty=?, note=?, "
             "created=datetime('now'), fulfilled='' WHERE id=?",
             (source, qty, note, prev["id"]))
        log("stock.request", f"re-open {prev['id']} biz {biz_id} item {item_id}")
        return True, "درخواست شما ثبت شد؛ به‌محض موجودشدن خبرتان می‌کنیم."
    try:
        _run("INSERT INTO stock_requests(biz_id,item_id,customer_id,source,qty,note) "
             "VALUES(?,?,?,?,?,?)",
             (biz_id, int(item_id) if item_id else None, int(customer_id), source,
              qty, note))
    except Exception:
        return False, "شما قبلاً برای همین مورد درخواست داده‌اید."
    log("stock.request", f"biz {biz_id} item {item_id} cust {customer_id} via {source}")
    return True, "درخواست شما ثبت شد؛ به‌محض موجودشدن خبرتان می‌کنیم."


def stock_request_row(rid):
    return _one(
        "SELECT sr.*, c.name AS cust_name, c.phone AS cust_phone, "
        "i.title AS item_title, b.name AS biz_name, b.slug AS biz_slug "
        "FROM stock_requests sr "
        "LEFT JOIN customers c ON c.id=sr.customer_id "
        "LEFT JOIN items i ON i.id=sr.item_id "
        "JOIN businesses b ON b.id=sr.biz_id WHERE sr.id=?", (rid,))


def customer_stock_requests(customer_id, limit=10):
    limit = max(1, min(int(limit or 10), 20))
    return _rows(
        "SELECT sr.id,sr.item_id,sr.qty,sr.status,sr.created,sr.fulfilled,"
        "i.title AS item_title,b.name AS biz_name,b.slug AS biz_slug "
        "FROM stock_requests sr LEFT JOIN items i ON i.id=sr.item_id "
        "JOIN businesses b ON b.id=sr.biz_id WHERE sr.customer_id=? "
        "ORDER BY sr.id DESC LIMIT ?", (int(customer_id), limit))


def customer_stock_request_cancel(customer_id, request_id):
    """Dismiss only this customer's open request; never expose/alter another row."""
    con=connect();con.execute("BEGIN IMMEDIATE")
    row=con.execute("SELECT id,status FROM stock_requests WHERE id=? AND customer_id=?",
                    (int(request_id),int(customer_id))).fetchone()
    if not row:
        con.rollback();con.close();return "missing"
    if row["status"]!="open":
        con.rollback();con.close();return "final"
    cur=con.execute("UPDATE stock_requests SET status='dismissed' WHERE id=? AND customer_id=? AND status='open'",
                    (int(request_id),int(customer_id)))
    con.commit();con.close()
    return "cancelled" if cur.rowcount==1 else "final"


def stock_requests_open(owner_id):
    """درخواست‌های بازِ همهٔ دکان‌های یک دکان‌دار، تازه‌ترین اول."""
    return _rows(
        "SELECT sr.*, c.name AS cust_name, c.phone AS cust_phone, "
        "i.title AS item_title, b.name AS biz_name, b.slug AS biz_slug "
        "FROM stock_requests sr "
        "LEFT JOIN customers c ON c.id=sr.customer_id "
        "LEFT JOIN items i ON i.id=sr.item_id "
        "JOIN businesses b ON b.id=sr.biz_id "
        "WHERE sr.status='open' AND b.owner_id=? "
        "ORDER BY sr.id DESC LIMIT 100", (owner_id,))


def stock_request_owned(rid, owner_id):
    r = stock_request_row(rid)
    if not r:
        return None
    ok = _one("SELECT 1 AS x FROM businesses WHERE id=? AND owner_id=?",
              (r["biz_id"], owner_id))
    return r if ok else None


def stock_request_fulfill(rid, owner_id):
    """دکان‌دار گفت «موجود شد» → اعلان همان مشتری (فقط زنگوله)."""
    r = stock_request_owned(rid, owner_id)
    if not r or r["status"] != "open":
        return False
    _run("UPDATE stock_requests SET status='fulfilled', "
         "fulfilled=datetime('now') WHERE id=?", (rid,))
    link = (f"/item/{r['item_id']}" if r["item_id"] else f"/b/{r['biz_slug']}")
    what = r["item_title"] or "کالای موردنظر شما"
    notify_customer(r["customer_id"], "broadcast",
                    f"«{what}» در «{r['biz_name']}» موجود شد.",
                    link, push=False)
    log("stock.fulfill", f"req {rid} by owner {owner_id}")
    return True


def stock_request_dismiss(rid, owner_id):
    r = stock_request_owned(rid, owner_id)
    if not r or r["status"] != "open":
        return False
    _run("UPDATE stock_requests SET status='dismissed' WHERE id=?", (rid,))
    return True


def stock_request_status(biz_id, item_id, customer_id):
    """وضعیت درخواست مشتری برای یک کالای مشخص (دکمهٔ صفحهٔ کالا)."""
    r = _one("SELECT status FROM stock_requests WHERE biz_id=? AND "
             "IFNULL(item_id,0)=IFNULL(?,0) AND customer_id=? "
             "ORDER BY id DESC LIMIT 1", (biz_id, item_id, customer_id))
    return r["status"] if r else None
