# -*- coding: utf-8 -*-
"""
v311 external web browser + arena.ai bridge + file exchange
Fixes: "این محتوا مسدود شده است" — X-Frame-Options / CSP frame-ancestors blocks live sites in iframe.
Solution: full reverse proxy that strips X-Frame-Options, CSP, rewrites URLs to go through proxy,
injects anti-frame-busting JS, supports arena auth cookie forwarding.

v311 improvements:
- Extract Supabase access_token from arena-auth-prod-v1.0 cookie (base64-JSON) and forward as
  Authorization: Bearer header — arena.ai's frontend uses Supabase JWT, Cookie alone is not enough.
- Add Origin/Referer headers for arena.ai to reduce 403.
- Better 403 diagnostics: detect Cloudflare / Iran block, suggest proxy + fresh cookie.
- Banner shows v311 + token status.
- File exchange unchanged (allowed).

Standard library only — VPN-friendly, proxy-aware.
"""

import os
import re
import json
import time
import html
import base64
import urllib.parse
import urllib.request
import urllib.error
import pathlib

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "..", "data")
ARENA_DIR = os.path.join(DATA_DIR, "arena-bridge")
os.makedirs(ARENA_DIR, exist_ok=True)

DEFAULT_ARENA_URL = "https://arena.ai/agent/01a0acde-4c14-7c72-9934-1df78579ea49"
ALLOWED_HOSTS = {
    "arena.ai",
    "www.arena.ai",
}
BLOCKED_SUBSTR = ("127.0.0.1", "localhost", "0.0.0.0", "::1", "10.", "192.168.", "172.")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

def _is_allowed_url(url: str):
    try:
        u = urllib.parse.urlparse(url)
        if u.scheme not in ("http", "https"):
            return False, "scheme must be http/https"
        host = (u.hostname or "").lower()
        if not host:
            return False, "no host"
        if host in ALLOWED_HOSTS or host.endswith(".arena.ai"):
            return True, ""
        if host.startswith("127.") or host == "localhost" or host.startswith("10.") or host.startswith("192.168."):
            return False, f"blocked private host {host}"
        if host.startswith("172."):
            try:
                second = int(host.split(".")[1])
                if 16 <= second <= 31:
                    return False, f"blocked private host {host}"
            except:
                pass
        if host in ("0.0.0.0", "::1"):
            return False, "loopback blocked"
        return True, ""
    except Exception as e:
        return False, str(e)

def _proxy_env():
    for k in ("ARENA_PROXY", "HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy"):
        v = (os.environ.get(k) or "").strip()
        if v:
            return v
    return ""

def _build_opener():
    proxy = _proxy_env()
    if proxy:
        return urllib.request.build_opener(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
    return urllib.request.build_opener()

def _arena_cookie_path():
    return os.path.join(ARENA_DIR, "arena_cookie.txt")

def get_arena_cookie():
    try:
        p = _arena_cookie_path()
        if os.path.exists(p):
            txt = open(p, "r", encoding="utf-8", errors="ignore").read().strip()
            if txt:
                return txt[:8192]
    except:
        pass
    try:
        v = (os.environ.get("ARENA_COOKIE") or "").strip()
        if v:
            return v[:8192]
    except:
        pass
    return ""

def set_arena_cookie(cookie_str: str):
    try:
        p = _arena_cookie_path()
        open(p, "w", encoding="utf-8").write((cookie_str or "").strip()[:8192])
        return True
    except:
        return False

def _b64_decode_maybe(s: str):
    """Decode base64url/base64 with missing padding, return bytes or None. v312 fix: try multiple variants."""
    try:
        s = (s or "").strip()
        if not s:
            return None
        # unquote first (handle %2B etc)
        try:
            s = urllib.parse.unquote(s)
        except:
            pass
        # remove whitespace/newlines
        s = re.sub(r"\s+", "", s)
        # try url-safe -> standard, and standard as-is
        for variant in (s, s.replace("-", "+").replace("_", "/"), s.replace("+", "-").replace("/", "_")):
            try:
                v = variant.strip()
                # fix padding
                pad = len(v) % 4
                if pad:
                    v += "=" * (4 - pad)
                raw = base64.b64decode(v, validate=False)
                if raw and len(raw) > 10:
                    return raw
            except Exception:
                continue
        return None
    except Exception:
        return None

def _extract_arena_tokens(cookie_str: str):
    """
    Parse the big Cookie header and try to extract Supabase access_token.
    arena-auth-prod-v1.0=base64-<json>  -> json contains access_token, refresh_token
    v313 robust: handles URL-encoded, &amp;, double-encoded, raw JWT, sb-xxx-auth-token
    Returns dict {access_token, refresh_token, raw_len, has_cf, cookie_len}
    """
    out = {"access_token": "", "refresh_token": "", "has_cf": False, "cookie_len": len(cookie_str or "")}
    if not cookie_str:
        return out
    try:
        raw_cookie = cookie_str or ""
        # normalize &amp; and html entities
        try:
            raw_cookie = html.unescape(raw_cookie)
        except:
            pass
        raw_cookie = raw_cookie.replace("&amp;", "&").replace("&quot;", '"')
        # detect Cloudflare
        if "__cf_bm" in raw_cookie or "cf_clearance" in raw_cookie:
            out["has_cf"] = True

        # unquote whole cookie for easier regex (but keep original for kv)
        unquoted = urllib.parse.unquote(raw_cookie)

        # collect candidates for base64 JSON
        candidates = []

        # 1) parse kv pairs
        parts = [p.strip() for p in raw_cookie.split(";")]
        kv = {}
        for p in parts:
            if "=" not in p:
                continue
            k, v = p.split("=", 1)
            kv[k.strip()] = v.strip()
            # also add unquoted version
            try:
                kv[k.strip() + "_unq"] = urllib.parse.unquote(v.strip())
            except:
                pass

        # common keys for supabase auth
        for key in ("arena-auth-prod-v1.0", "sb-arena-auth-token", "sb-access-token", "supabase-auth-token", "arena_auth"):
            if key in kv and kv[key]:
                candidates.append(kv[key])
            if key + "_unq" in kv and kv[key + "_unq"]:
                candidates.append(kv[key + "_unq"])

        # 2) regex for base64-... until ; or " or whitespace
        for pattern in [
            r"arena-auth-prod-v1\.0=base64-([^;\s\"']+)",
            r"base64-([A-Za-z0-9+/=_-]{100,})",
            r"base64-([A-Za-z0-9%+/=_-]{100,})",
        ]:
            for m in re.finditer(pattern, unquoted):
                candidates.append("base64-" + m.group(1))
            for m in re.finditer(pattern, raw_cookie):
                candidates.append("base64-" + m.group(1))

        # 3) if cookie itself is raw base64-... or raw JSON
        stripped = raw_cookie.strip()
        if stripped.startswith("base64-") and len(stripped) > 100:
            candidates.append(stripped)
        if stripped.startswith("eyJ") and len(stripped) > 50:
            # direct JWT
            candidates.append(stripped)

        # 4) try to find JSON containing access_token directly
        # sometimes cookie contains url-encoded JSON
        if "access_token" in unquoted:
            # try to extract JWT via regex from unquoted
            m_jwt = re.search(r'"access_token"\s*:\s*"([^"]+)"', unquoted)
            if m_jwt:
                candidates.append(m_jwt.group(1))

        # deduplicate preserving order
        seen = set()
        uniq_candidates = []
        for c in candidates:
            if not c or len(c) < 20:
                continue
            if c in seen:
                continue
            seen.add(c)
            uniq_candidates.append(c)

        # try each candidate
        for cand in uniq_candidates:
            try:
                b64part = cand.strip()
                # if it's already a JWT (eyJ...), use directly
                if b64part.startswith("eyJ") and b64part.count(".") == 2 and len(b64part) > 50:
                    out["access_token"] = b64part[:2000]
                    break
                if b64part.startswith("base64-"):
                    b64part = b64part[len("base64-"):]

                # remove possible surrounding quotes
                b64part = b64part.strip().strip('"').strip("'")

                raw = _b64_decode_maybe(b64part)
                if not raw:
                    continue
                txt = raw.decode("utf-8", errors="ignore")
                # txt should be JSON with access_token
                if "access_token" in txt:
                    try:
                        j = json.loads(txt)
                        at = j.get("access_token") or j.get("accessToken") or ""
                        rt = j.get("refresh_token") or j.get("refreshToken") or ""
                        if at and len(at) > 20:
                            out["access_token"] = str(at)[:2000]
                            out["refresh_token"] = str(rt)[:2000]
                            break
                    except Exception:
                        # try regex inside txt
                        m_at = re.search(r'"access_token"\s*:\s*"([^"]+)"', txt)
                        if m_at and len(m_at.group(1)) > 20:
                            out["access_token"] = m_at.group(1)[:2000]
                            break
                # if txt itself looks like JWT
                m_j = re.search(r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}", txt)
                if m_j and len(m_j.group(0)) > 50:
                    out["access_token"] = m_j.group(0)[:2000]
                    break
            except Exception:
                continue

        # fallback: find JWT directly in original cookie (most reliable)
        if not out["access_token"]:
            for src in (unquoted, raw_cookie):
                m2 = re.search(r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{20,}", src)
                if m2:
                    tok = m2.group(0)
                    # basic sanity: JWT payload should contain "sub" or "role" or "aud"
                    if len(tok) > 80:
                        out["access_token"] = tok[:2000]
                        break
    except Exception:
        pass
    return out

def fetch_raw(url: str, timeout=15, extra_headers=None):
    """Fetch any URL, return dict with body bytes, content_type, status, headers, error"""
    ok, why = _is_allowed_url(url)
    if not ok:
        return {"ok": False, "error": why, "body": b"", "content_type": "", "status": 0, "headers": {}}
    try:
        hdrs = {
            "User-Agent": UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9,fa;q=0.8",
            "Accept-Encoding": "identity",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        }
        # arena auth cookie forwarding + token extraction v311
        arena_cookie = get_arena_cookie()
        token_info = _extract_arena_tokens(arena_cookie) if arena_cookie else {}
        if arena_cookie:
            if "=" in arena_cookie and ";" in arena_cookie:
                hdrs["Cookie"] = arena_cookie
            elif "=" in arena_cookie:
                hdrs["Cookie"] = arena_cookie
            else:
                hdrs["Cookie"] = arena_cookie
            # v311: if we have access_token, also send as Bearer
            if token_info.get("access_token"):
                hdrs["Authorization"] = f"Bearer {token_info['access_token'][:2000]}"
                # Supabase also likes apikey header = anon key, but we don't have it; Bearer is main
            # Add Origin/Referer for arena.ai to reduce 403
            try:
                if "arena.ai" in url:
                    hdrs["Origin"] = "https://arena.ai"
                    hdrs["Referer"] = "https://arena.ai/"
            except:
                pass
        if extra_headers:
            hdrs.update(extra_headers)

        req = urllib.request.Request(url, headers=hdrs)
        opener = _build_opener()
        with opener.open(req, timeout=timeout) as resp:
            ctype = resp.headers.get("Content-Type", "")
            body = resp.read(5_000_000)
            hdict = {k.lower(): v for k, v in resp.headers.items()}
            return {
                "ok": True,
                "body": body,
                "content_type": ctype,
                "status": getattr(resp, 'status', 200),
                "headers": hdict,
                "url": url,
                "proxy_used": bool(_proxy_env()),
                "cookie_used": bool(arena_cookie),
                "token_used": bool(token_info.get("access_token")),
                "has_cf": bool(token_info.get("has_cf")),
            }
    except urllib.error.HTTPError as e:
        try:
            b = e.read(500_000)
        except:
            b = b""
        return {"ok": False, "error": f"HTTP {e.code}", "code": e.code, "body": b, "content_type": e.headers.get("Content-Type",""), "status": e.code, "headers": {k.lower():v for k,v in e.headers.items()}, "proxy_used": bool(_proxy_env()), "cookie_used": bool(get_arena_cookie())}
    except Exception as e:
        return {"ok": False, "error": str(e)[:500], "body": b"", "content_type": "", "status": 0, "headers": {}, "proxy_used": bool(_proxy_env()), "cookie_used": bool(get_arena_cookie())}

def fetch_url(url: str, timeout=15):
    """Backward compat — returns text summary for diag"""
    r = fetch_raw(url, timeout=timeout)
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error",""), "proxy_used": r.get("proxy_used", False), "code": r.get("code",0), "cookie_used": r.get("cookie_used", False)}
    ctype = r.get("content_type","")
    body = r.get("body", b"")
    charset = "utf-8"
    if "charset=" in ctype:
        try:
            charset = ctype.split("charset=")[-1].split(";")[0].strip()
        except:
            pass
    try:
        text = body.decode(charset, errors="ignore")
    except:
        text = body.decode("utf-8", errors="ignore")
    m = re.search(r"<title[^>]*>(.*?)</title>", text, re.I | re.S)
    title = html.unescape(m.group(1).strip()) if m else url
    title = re.sub(r"\s+", " ", title)[:300]
    txt = re.sub(r"<script.*?</script>", " ", text, flags=re.I | re.S)
    txt = re.sub(r"<style.*?</style>", " ", txt, flags=re.I | re.S)
    txt = re.sub(r"<[^>]+>", " ", txt)
    txt = html.unescape(txt)
    txt = re.sub(r"\s+", " ", txt).strip()[:8000]
    return {"ok": True, "url": url, "status": r.get("status",200), "content_type": ctype, "title": title, "text": txt, "raw_len": len(body), "html": text[:200000], "proxy_used": r.get("proxy_used", False), "cookie_used": r.get("cookie_used", False), "token_used": r.get("token_used", False)}

def _should_proxy_content_type(ctype: str):
    c = (ctype or "").lower()
    return ("text/html" in c) or ("application/xhtml" in c) or (c.strip() == "") or ("text/html" in c)

def _strip_blocking_meta(html_str: str):
    html_str = re.sub(r'<meta[^>]+http-equiv=["\']?x-frame-options["\']?[^>]*>', '', html_str, flags=re.I)
    html_str = re.sub(r'<meta[^>]+http-equiv=["\']?content-security-policy[^>]*>', '', html_str, flags=re.I)
    html_str = re.sub(r'<meta[^>]+http-equiv=["\']?content-security-policy-report-only[^>]*>', '', html_str, flags=re.I)
    return html_str

def rewrite_html(html_str: str, base_url: str):
    """Rewrite HTML to proxy all arena.ai resources and strip frame-blocking, inject anti-bust
    v308 fix: don't rewrite inside <script> tags — otherwise new URL() becomes new url(/proxy...)
    """
    try:
        parsed = urllib.parse.urlparse(base_url)
        origin = f"{parsed.scheme}://{parsed.netloc}"
        proxy_prefix = "/agent/proxy?url="

        def to_proxy_url(target):
            if not target:
                return target
            t = target.strip()
            if not t or t.startswith("#") or t.startswith("data:") or t.startswith("blob:") or t.startswith("javascript:") or t.startswith("mailto:") or t.startswith("tel:"):
                return t
            if t.startswith(proxy_prefix):
                return t
            try:
                abs_url = urllib.parse.urljoin(base_url, t)
                is_relative = not urllib.parse.urlparse(t).netloc
                abs_host = urllib.parse.urlparse(abs_url).hostname or ""
                if is_relative or abs_host.endswith("arena.ai") or abs_host == parsed.hostname:
                    return proxy_prefix + urllib.parse.quote(abs_url, safe="")
                if abs_url.startswith("https://") and len(abs_url) < 800:
                    return proxy_prefix + urllib.parse.quote(abs_url, safe="")
                return abs_url
            except:
                return t

        html_str = _strip_blocking_meta(html_str)

        scripts = []
        def script_placeholder(m):
            scripts.append(m.group(0))
            return f"__DASTGIR_SCRIPT_{len(scripts)-1}__"
        html_no_script = re.sub(r"<script[^>]*>.*?</script>", script_placeholder, html_str, flags=re.I | re.S)

        def repl_attr(m):
            attr = m.group(1)
            quote = m.group(2)
            url = m.group(3)
            if attr.lower() == "srcset":
                parts = []
                for part in url.split(","):
                    part = part.strip()
                    if not part:
                        continue
                    segs = part.split()
                    if segs:
                        segs[0] = to_proxy_url(segs[0])
                        parts.append(" ".join(segs))
                new_url = ", ".join(parts)
                return f'{attr}={quote}{new_url}{quote}'
            else:
                new_url = to_proxy_url(url)
                return f'{attr}={quote}{new_url}{quote}'

        html_no_script = re.sub(r'(href|src|action|poster|data|srcset)\s*=\s*(["\'])(.*?)\2', repl_attr, html_no_script, flags=re.I | re.S)

        def repl_css_url(m):
            full = m.group(0)
            if "__DASTGIR_SCRIPT_" in full:
                return full
            q = m.group(1) or ""
            u = m.group(2)
            uu = u.strip().strip('"\'')
            if uu.startswith("data:") or uu.startswith("blob:") or uu.startswith("__DASTGIR_SCRIPT_"):
                return full
            new_u = to_proxy_url(uu)
            return f"url({q}{new_u}{q})"
        html_no_script = re.sub(r'url\(\s*(["\']?)(.*?)\1\s*\)', repl_css_url, html_no_script, flags=re.I)

        for i, sc in enumerate(scripts):
            html_no_script = html_no_script.replace(f"__DASTGIR_SCRIPT_{i}__", sc)

        html_str = html_no_script

        anti_bust = (
            '<script>\n'
            '// dastgir v313 proxy active - safe for Next.js\n'
            '(function(){\n'
            '  try{ window.addEventListener("beforeunload", function(e){ try{e.stopImmediatePropagation();}catch(_){ } }, true); }catch(e){}\n'
            f'  console.log("[dastgir] v313 proxy active origin={origin}");\n'
            '  const PROXY = "/agent/proxy?url=";\n'
            f'  const ORIGIN = "{origin}";\n'
            '  function toProxy(url){\n'
            '    if(!url) return url;\n'
            '    let s = String(url).trim();\n'
            '    if(!s || s.startsWith("#") || s.startsWith("data:") || s.startsWith("blob:") || s.startsWith("javascript:") || s.startsWith("mailto:") || s.startsWith("tel:") || s.startsWith(PROXY)) return s;\n'
            '    try{\n'
            '      let abs = new URL(s, ORIGIN).href;\n'
            '      let h = new URL(abs).hostname || "";\n'
            '      if(h.endsWith("arena.ai") || abs.startsWith(ORIGIN) || s.startsWith("/")){\n'
            '        return PROXY + encodeURIComponent(abs);\n'
            '      }\n'
            '      if(abs.startsWith("https://")){\n'
            '        return PROXY + encodeURIComponent(abs);\n'
            '      }\n'
            '      return abs;\n'
            '    }catch(e){ return s; }\n'
            '  }\n'
            '  const _fetch = window.fetch;\n'
            '  if(_fetch){\n'
            '    window.fetch = function(input, init){\n'
            '      try{\n'
            '        if(typeof input === "string"){ input = toProxy(input); }\n'
            '        else if(input && input.url){ let nu = toProxy(input.url); if(nu !== input.url){ input = new Request(nu, input); } }\n'
            '      }catch(e){}\n'
            '      return _fetch.call(this, input, init);\n'
            '    };\n'
            '  }\n'
            '  const _open = XMLHttpRequest.prototype.open;\n'
            '  XMLHttpRequest.prototype.open = function(method, url){\n'
            '    try{ arguments[1] = toProxy(url); }catch(e){}\n'
            '    return _open.apply(this, arguments);\n'
            '  };\n'
            '})();\n'
            '</script>\n'
        )
        if re.search(r"<head[^>]*>", html_str, re.I):
            html_str = re.sub(r"(<head[^>]*>)", r"\1" + anti_bust, html_str, count=1, flags=re.I)
        else:
            html_str = anti_bust + html_str

        banner = (
            '<div id="__dastgir_banner" style="position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#111;color:#fff;padding:8px 12px;font-family:Tahoma,sans-serif;font-size:13px;display:flex;gap:10px;align-items:center;border-bottom:1px solid #333">'
            f'  <span>🔗 {html.escape(base_url[:100])}</span>'
            f'  <a href="/agent/browser?url={urllib.parse.quote(base_url)}" style="color:#8cf;text-decoration:none;background:#222;padding:4px 8px;border-radius:6px">بازگشت به پنل</a>'
            f'  <a href="{html.escape(base_url)}" target="_blank" style="color:#8cf;text-decoration:none;background:#222;padding:4px 8px;border-radius:6px">🌐 مستقیم (VPN)</a>'
            f'  <span style="margin-left:auto;opacity:.7;font-size:11px">v313 proxy • {html.escape(_proxy_env()[:30] or "بدون پراکسی")} • cookie:{"yes len="+str(len(get_arena_cookie() or "")) if get_arena_cookie() else "no"} • token:{"yes" if _extract_arena_tokens(get_arena_cookie() or "").get("access_token") else "no"}</span>'
            '</div><div style="height:38px"></div>'
        )
        if re.search(r"<body[^>]*>", html_str, re.I):
            html_str = re.sub(r"(<body[^>]*>)", r"\1" + banner, html_str, count=1, flags=re.I)
        else:
            html_str = banner + html_str

        return html_str
    except Exception as e:
        return f"<!-- rewrite error: {html.escape(str(e)[:200])} -->\n" + html_str

def proxy_fetch(url: str, timeout=15):
    """Main proxy: fetch any URL, return body bytes, content_type, status, rewritten if HTML - v311 improved 403 handling"""
    res = fetch_raw(url, timeout=timeout)
    if not res.get("ok"):
        low = url.lower()
        is_asset = any(low.endswith(ext) for ext in (".js",".css",".png",".jpg",".jpeg",".webp",".svg",".woff",".woff2",".ico",".json")) or "/_next/" in low or "/static/" in low
        if is_asset:
            ctype = "application/javascript" if (".js" in low or "_next" in low) else "text/css" if ".css" in low else "image/png" if ".png" in low else "application/octet-stream"
            return {
                "ok": False,
                "body": b"/* dastgir proxy asset fail - filtered, use VPN direct */",
                "content_type": ctype,
                "status": 200,
                "headers": {},
                "error": res.get("error",""),
                "is_html": False,
                "is_fallback": False,
            }
        proxy_info = _proxy_env() or "بدون پراکسی (مستقیم)"
        cookie_raw = get_arena_cookie() or ""
        cookie_info = f"دارد len={len(cookie_raw)}" if cookie_raw else "ندارد"
        tok_info = _extract_arena_tokens(cookie_raw)
        token_info = "دارد" if tok_info.get("access_token") else "ندارد"
        safe_err = html.escape(res.get("error","unknown"))
        safe_url = html.escape(url)
        # v311: better explanation for 403
        why_html = ""
        code = res.get("code") or res.get("status") or 0
        if code == 403 or "403" in safe_err:
            why_html = """
            <div style="background:#3a1a1a;border:1px solid #a33;border-radius:8px;padding:10px;margin:10px 0">
            <b>🔍 تحلیل 403:</b>
            <ul>
              <li>اگر <code>__cf_bm</code> یا <code>cf_clearance</code> تو کوکی‌ات هست، این کوکی IP-محوره و فقط 10-30 دقیقه عمر می‌کنه — با IP سرور ایران باطل میشه.</li>
              <li>توکن Supabase (arena-auth-prod-v1.0) هر 1 ساعت منقضی میشه — باید تازه کپی کنی.</li>
              <li>سرور شما ایران است (130.185.x) — Cloudflare/Arena ممکنه ایران را بلاک کنه حتی با کوکی.</li>
              <li><b>راه حل قطعی:</b> روی سرور پراکسی خارجی ست کن: <code>export ARENA_PROXY=http://127.0.0.1:8080</code> (اگر v2ray/xray داری) یا از یک VPS خارجی به عنوان پراکسی استفاده کن.</li>
            </ul>
            </div>
            """
        fallback = (
            '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            f'<title>خطا — {safe_url[:60]}</title>'
            '<style>body{font-family:Tahoma,sans-serif;padding:20px;background:#111;color:#eee;line-height:1.8}'
            '.card{background:#1e1e1e;border:1px solid #333;border-radius:12px;padding:16px;max-width:850px;margin:20px auto}'
            '.btn{padding:8px 14px;border-radius:8px;border:0;background:#4f46e5;color:#fff;cursor:pointer;text-decoration:none;display:inline-block;margin:4px}'
            '.btn.ghost{background:#333} code{background:#222;padding:2px 6px;border-radius:6px;direction:ltr;word-break:break-all}'
            'pre{white-space:pre-wrap;background:#222;padding:10px;border-radius:8px;max-height:40vh;overflow:auto}</style></head><body>'
            '<div class="card"><h2>⚠️ سرور نتوانست صفحه را بگیرد — v313</h2>'
            f'<p>آدرس: <code>{safe_url}</code></p>'
            f'<p>خطا: <code>{safe_err}</code> کد:{code}</p>'
            f'<p>پراکسی سرور: <code>{html.escape(proxy_info[:120])}</code></p>'
            f'<p>کوکی آرنا: <code>{html.escape(cookie_info[:120])}</code> — توکن: {token_info} — CF: {"دارد" if tok_info.get("has_cf") else "ندارد"}</p>'
            f'{why_html}'
            '<p>این معمولاً یعنی:</p><ul>'
            '<li>سرور شما در ایران است و <b>arena.ai فیلتر است</b> و پراکسی ندارد</li>'
            '<li>یا <b>arena.ai نیاز به لاگین دارد</b> و کوکی/توکن شما منقضی شده</li>'
            '<li>یا Cloudflare کوکی <code>__cf_bm</code> را به خاطر IP متفاوت رد کرده</li>'
            '</ul>'
            '<h3>راه‌حل فوری:</h3>'
            '<ol>'
            '<li><b>کوکی تازه:</b> با VPN برو arena.ai لاگین کن، تو کنسول (F12) بزن <code>document.cookie</code> کپی کن، تو دستگیر بخش کوکی پیست کن. دقت کن <code>len</code> باید بالای 500 باشه و شامل <code>arena-auth-prod-v1.0</code> باشه.</li>'
            '<li><b>اگر با VPN خودت arena.ai باز می‌شود:</b> دکمه «🌐 باز کردن مستقیم» را بزن — تو تب جدید با VPN باز میشه، بعد با بوکمارکلت محتوا را برگردون.</li>'
            '<li><b>پراکسی روی سرور ست کن (راه حل قطعی برای 403 ایران):</b><br><code>export ARENA_PROXY=http://127.0.0.1:8080</code> سپس <code>sudo systemctl restart bazarche</code><br>اگر روی سرور v2ray/xray داری پورتش را بذار (معمولاً 10808 یا 8080). اگر نداری، یک پراکسی SOCKS/HTTP خارجی بساز.</li>'
            '<li><b>تست سریع:</b> تو ترمینال بله بزن <code>sh curl -I https://arena.ai --proxy http://127.0.0.1:8080</code> ببین 200 میده یا 403.</li>'
            '</ol>'
            f'<p><a class="btn" href="{safe_url}" target="_blank">🌐 باز کردن مستقیم {safe_url[:50]}</a> '
            f'<a class="btn ghost" href="/agent/browser?url={urllib.parse.quote(url)}">بازگشت</a> '
            '<button class="btn ghost" onclick="tryClient()">📥 تلاش با مرورگر من (VPN)</button></p>'
            '<div id="clientBox" style="display:none;margin-top:16px"><h4>تلاش کلاینت:</h4><pre id="clientText"></pre><iframe id="clientFrame" style="width:100%;height:50vh;background:#fff;border:0;border-radius:8px"></iframe></div>'
            '</div>'
            '<script>'
            f'var targetUrl={json.dumps(url)};'
            'async function tryClient(){'
            ' var box=document.getElementById("clientBox"); box.style.display="block";'
            ' var txt=document.getElementById("clientText"); txt.textContent="در حال fetch با مرورگر شما (VPN + کوکی شما)...";'
            ' try{'
            '   var r=await fetch(targetUrl,{credentials:"include"});'
            '   var t=await r.text();'
            '   txt.textContent="وضعیت: "+r.status+" طول: "+t.length+"\\n\\n"+t.substring(0,8000);'
            '   var blob=new Blob([t],{type:"text/html"}); var u=URL.createObjectURL(blob);'
            '   document.getElementById("clientFrame").src=u;'
            ' }catch(e){ txt.textContent="خطای کلاینت: "+e+"\\nCORS جلوی خواندن را گرفته — باید از پراکسی سرور یا کوکی استفاده کنی."; }'
            '}'
            '</script></body></html>'
        )
        return {
            "ok": False,
            "body": fallback.encode("utf-8"),
            "content_type": "text/html; charset=utf-8",
            "status": 200,
            "headers": {},
            "error": res.get("error",""),
            "is_html": True,
            "is_fallback": True,
        }

    body = res.get("body", b"")
    ctype = res.get("content_type", "") or ""
    is_html = _should_proxy_content_type(ctype) or body.lstrip()[:15].lower().startswith(b"<!doctype") or b"<html" in body[:500].lower()
    if is_html:
        charset = "utf-8"
        if "charset=" in ctype:
            try:
                charset = ctype.split("charset=")[-1].split(";")[0].strip()
            except:
                pass
        try:
            text = body.decode(charset, errors="ignore")
        except:
            text = body.decode("utf-8", errors="ignore")
        rewritten = rewrite_html(text, url)
        return {
            "ok": True,
            "body": rewritten.encode("utf-8"),
            "content_type": "text/html; charset=utf-8",
            "status": 200,
            "headers": res.get("headers", {}),
            "is_html": True,
        }
    else:
        return {
            "ok": True,
            "body": body,
            "content_type": ctype or "application/octet-stream",
            "status": 200,
            "headers": res.get("headers", {}),
            "is_html": False,
        }

def proxy_page(url: str):
    r = proxy_fetch(url)
    try:
        return r["body"].decode("utf-8", errors="ignore")
    except:
        return "<html><body>binary content</body></html>"

def _bridge_path(name="latest.json"):
    return os.path.join(ARENA_DIR, name)

def bridge_load():
    try:
        p = _bridge_path()
        if os.path.exists(p):
            return json.loads(open(p, encoding="utf-8").read()[:200000] or "{}")
    except Exception:
        pass
    return {"url": DEFAULT_ARENA_URL, "messages": [], "files": [], "updated": 0, "proxy": _proxy_env(), "arena_cookie": bool(get_arena_cookie())}

def bridge_save(data):
    try:
        data["updated"] = time.time()
        data["proxy"] = _proxy_env()
        data["arena_cookie"] = bool(get_arena_cookie())
        open(_bridge_path(), "w", encoding="utf-8").write(json.dumps(data, ensure_ascii=False, indent=2)[:500000])
        hist = _bridge_path(f"history-{int(time.time())}.json")
        open(hist, "w", encoding="utf-8").write(json.dumps(data, ensure_ascii=False)[:500000])
        return True
    except Exception:
        return False

def bridge_append_message(role, text, files=None):
    d = bridge_load()
    d.setdefault("messages", []).append({
        "ts": time.time(),
        "role": role,
        "text": text[:8000],
        "files": files or []
    })
    if len(d["messages"]) > 200:
        d["messages"] = d["messages"][-200:]
    bridge_save(d)
    return d

EXCHANGE_DIR = os.path.join(DATA_DIR, "agent-exchange")
os.makedirs(EXCHANGE_DIR, exist_ok=True)

def exchange_list():
    out = []
    try:
        for fn in os.listdir(EXCHANGE_DIR):
            fp = os.path.join(EXCHANGE_DIR, fn)
            if not os.path.isfile(fp):
                continue
            st = os.stat(fp)
            out.append({"name": fn, "size": st.st_size, "mtime": st.st_mtime})
    except Exception:
        pass
    out.sort(key=lambda x: x["mtime"], reverse=True)
    return out[:100]

def exchange_save_file(data: bytes, filename: str):
    import re
    filename = re.sub(r"[^A-Za-z0-9._-]", "_", filename)[:120]
    if not filename:
        filename = f"file-{int(time.time())}.bin"
    fp = os.path.join(EXCHANGE_DIR, filename)
    base, ext = os.path.splitext(filename)
    i = 1
    while os.path.exists(fp):
        fp = os.path.join(EXCHANGE_DIR, f"{base}_{i}{ext}")
        i += 1
        if i > 20:
            break
    open(fp, "wb").write(data[:20_000_000])
    bridge_append_message("system", f"file uploaded: {os.path.basename(fp)} ({len(data)} bytes)", files=[os.path.basename(fp)])
    return {"ok": True, "name": os.path.basename(fp), "size": len(data), "path": f"/agent/file/{urllib.parse.quote(os.path.basename(fp))}"}

def browser_html(s, q):
    url = ""
    if isinstance(q, dict):
        v = q.get("url")
        if isinstance(v, list) and v:
            url = v[0]
        elif isinstance(v, str):
            url = v
    if not url:
        url = DEFAULT_ARENA_URL
    bridge = bridge_load()
    msgs = bridge.get("messages", [])[-30:]
    files = exchange_list()

    msgs_html = ""
    clean = []
    for m in msgs:
        t = (m.get("text","") or "")
        # v313: filter any JSON dump of bridge or messages array
        tt = t.strip()
        if tt.startswith("{") and ('"proxy"' in tt or '"arena_cookie"' in tt) and '"updated"' in tt:
            continue
        if tt.startswith("{") and '"ok"' in tt and '"messages"' in tt:
            continue
        if len(tt) > 300 and tt.count('"') > 12 and ('"role"' in tt and '"ts"' in tt):
            # likely a dumped message list, skip
            continue
        if len(tt) > 400 and tt.count('"') > 15 and '"role"' in tt and '"files"' in tt:
            continue
        # skip empty or very short
        if len(tt) < 1:
            continue
        clean.append(m)
    for m in clean[-20:]:
        role = m.get("role","")
        txt_raw = (m.get("text","") or "")[:800]
        # if text itself is JSON with messages, try to extract last user text
        if txt_raw.strip().startswith("{") and '"text"' in txt_raw:
            try:
                # try to salvage
                j_tmp = json.loads(txt_raw)
                if isinstance(j_tmp, dict) and j_tmp.get("text"):
                    txt_raw = str(j_tmp.get("text"))[:800]
                elif isinstance(j_tmp, dict) and j_tmp.get("messages"):
                    # show last message text
                    last = (j_tmp.get("messages") or [])[-1] if j_tmp.get("messages") else {}
                    txt_raw = str(last.get("text",""))[:800] or txt_raw[:200]
            except:
                pass
        txt = html.escape(txt_raw)
        if len(txt) < 2:
            continue
        ts = time.strftime("%H:%M", time.localtime(m.get("ts",0)))
        cls = "user" if role=="user" else "arena" if role=="arena" else "sys"
        msgs_html += f'<div class="msg {cls}"><span class="ts">{ts}</span> <b>{html.escape(role)}</b>: {txt}</div>\n'
    if not msgs_html:
        msgs_html = '<div class="muted">هنوز پیامی نیست — از پایین پیام بده. این بخش فقط پل به arena.ai است؛ برای چت با هوش داخلی (۷۶ ابزار) برو <a href=\"/agent\" style=\"color:#8cf\">/agent</a></div>'

    files_html = ""
    for f in files:
        nm = html.escape(f["name"])
        sz = f["size"]
        qn = urllib.parse.quote(f["name"])
        files_html += f'<div class="file"><a href="/agent/file/{qn}" target="_blank">{nm}</a> <small>{sz}b</small></div>\n'
    if not files_html:
        files_html = '<div class="muted">فایلی نیست.</div>'

    esc_url = html.escape(url)
    proxy_src = "/agent/proxy?url="+urllib.parse.quote(url)
    def_arena_short = html.escape(DEFAULT_ARENA_URL[:60])
    proxy_env = html.escape(_proxy_env() or "بدون پراکسی (مستقیم)")
    has_cookie = bool(get_arena_cookie())
    cookie_raw = get_arena_cookie() or ""
    tok_info = _extract_arena_tokens(cookie_raw)
    cookie_status = f"✅ دارد len={len(cookie_raw)} token={'✅' if tok_info.get('access_token') else '❌'}" if has_cookie else "❌ ندارد — برای arena.ai لاگین‌دار باید ست کنی"
    if has_cookie and len(cookie_raw) < 200:
        cookie_status += " (خیلی کم! باید 500+ باشد)"

    bookmarklet_js = """javascript:(function(){var t=document.documentElement.outerHTML.slice(0,8000);var u=location.href;var c=document.cookie;var payload={text:"[from arena tab] "+u+"\\n"+t.slice(0,3000),cookie:c,url:u};var d=prompt("این را کپی کن و تو دستگیر تو بخش کوکی پیست کن:\\n\\n"+c+"\\n\\nیا بگذار اتومات بفرستم به دستگیر؟");if(d!==null){fetch('https://daastgir.ir/api/agent/arena/bridge',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}).then(r=>r.text()).then(x=>alert('فرستاده شد: '+x)).catch(e=>alert('خطا: '+e));}})();"""

    page = (
        '<!doctype html>\n<html lang="fa" dir="rtl">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width,initial-scale=1">\n'
        f'<title>مرورگر ایجنت - {esc_url[:40]}</title>\n'
        '<style>\n'
        'body{margin:0;font-family:Tahoma,sans-serif;background:#0f0f0f;color:#eee}\n'
        '.bar{display:flex;gap:8px;padding:10px;background:#1a1a1a;border-bottom:1px solid #333;flex-wrap:wrap;align-items:center}\n'
        '.bar input{flex:1;min-width:240px;padding:8px 10px;border-radius:8px;border:1px solid #444;background:#222;color:#fff;direction:ltr}\n'
        '.btn{padding:8px 12px;border-radius:8px;border:0;background:#4f46e5;color:#fff;cursor:pointer;text-decoration:none;display:inline-block}\n'
        '.btn.ghost{background:#333}\n'
        '.layout{display:grid;grid-template-columns:1fr 360px;gap:0;height:calc(100vh - 52px)}\n'
        '@media(max-width:900px){.layout{grid-template-columns:1fr}}\n'
        '.iframe-wrap{position:relative;background:#fff;display:flex;flex-direction:column}\n'
        '.iframe-wrap iframe{width:100%;height:100%;border:0;background:#fff;flex:1}\n'
        '.side{background:#151515;border-left:1px solid #2a2a2a;display:flex;flex-direction:column;overflow:hidden}\n'
        '.side h3{margin:12px 12px 6px;font-size:14px}\n'
        '.msgs{flex:1;overflow:auto;padding:8px 12px;display:flex;flex-direction:column;gap:6px}\n'
        '.msg{padding:6px 8px;border-radius:8px;background:#222;font-size:13px;line-height:1.6}\n'
        '.msg.user{background:#1e293b}\n'
        '.msg.arena{background:#1a2e1a}\n'
        '.msg.sys{background:#2a2a1a;opacity:.8}\n'
        '.ts{opacity:.6;font-size:11px}\n'
        '.muted{opacity:.6;font-size:12px}\n'
        '.chat-box{padding:10px;border-top:1px solid #333;display:flex;gap:6px}\n'
        '.chat-box textarea{flex:1;padding:8px;border-radius:8px;border:1px solid #444;background:#222;color:#fff;min-height:44px;resize:vertical}\n'
        '.files{padding:8px 12px;max-height:180px;overflow:auto;border-top:1px solid #2a2a2a}\n'
        '.file{font-size:12px;padding:2px 0}\n'
        '.drop{border:2px dashed #444;border-radius:10px;padding:10px;margin:8px 12px;text-align:center;cursor:pointer}\n'
        '.drop.dragover{border-color:#4f46e5;background:#1e1e3a}\n'
        '.alert{padding:10px;border-radius:8px;margin:8px 12px;font-size:12px;line-height:1.7}\n'
        '.alert.warn{background:#3a2a00;border:1px solid #665500}\n'
        '.alert.ok{background:#0a2a12;border:1px solid #1a5a2a}\n'
        'code{background:#222;padding:2px 6px;border-radius:6px;direction:ltr;font-size:11px}\n'
        'input.cookie{width:100%;padding:6px 8px;border-radius:6px;border:1px solid #444;background:#222;color:#fff;direction:ltr;font-size:11px}\n'
        '</style>\n</head>\n<body>\n'
        '<div class="bar">\n'
        '  <span>🌐</span>\n'
        f'  <input id="urlInput" value="{esc_url}" placeholder="https://...">\n'
        '  <button class="btn" onclick="go()">برو</button>\n'
        '  <button class="btn ghost" onclick="openProxy()">تب جدید</button>\n'
        '  <a class="btn ghost" href="/agent" style="text-decoration:none">🧠 /agent اصلی (هوش ۷۶ ابزار)</a>\n'
        f'  <span style="margin-left:auto;font-size:11px;opacity:.7">پراکسی: {proxy_env[:40]} | کوکی: {cookie_status[:50]}</span>\n'
        '</div>\n'
        f'<div class="alert ok">✅ v313 — فیکس استخراج توکن (len 7082 → token yes) + فیلتر پیام‌های JSON + راهنمای پراکسی — این صفحه مرورگر خارجی arena.ai است، نه چت هوش داخلی. برای چت با هوش داخلی (۷۶ ابزار، بدون VPN) برو <a href=\"/agent\" style=\"color:#8cf\">/agent</a> یا <a href=\"/panel/agent\" style=\"color:#8cf\">/panel/agent</a>. اگر arena.ai باز نمی‌شود: کوکی تازه (F12 → document.cookie) + پراکسی خارجی (ARENA_PROXY) لازم است.</div>\n'
        '<div class="layout">\n'
        '  <div class="iframe-wrap">\n'
        f'    <iframe id="arenaFrame" src="{proxy_src}" allow="fullscreen; clipboard-read; clipboard-write; autoplay; camera; microphone; geolocation" referrerpolicy="no-referrer"></iframe>\n'
        '  </div>\n'
        '  <div class="side">\n'
        f'    <h3>💬 پل به آرنا — {def_arena_short}</h3>\n'
        f'    <div class="msgs" id="msgs">{msgs_html}</div>\n'
        '    <div class="chat-box">\n'
        '      <textarea id="chatText" placeholder="پیام به ایجنت خارجی arena.ai ..."></textarea>\n'
        '      <button class="btn" onclick="sendArena()">ارسال</button>\n'
        '    </div>\n'
        '    <div style="padding:8px 12px;border-top:1px solid #333">\n'
        '      <b>🍪 کوکی arena.ai (برای لاگین‌دار):</b><br>\n'
        f'      <div style="font-size:11px;opacity:.7;margin:4px 0">وضعیت: {html.escape(cookie_status)}</div>\n'
        '      <input id="cookieInput" class="cookie" placeholder="document.cookie از تب arena.ai را اینجا پیست کن">\n'
        '      <div style="display:flex;gap:6px;margin-top:6px">\n'
        '        <button class="btn ghost" onclick="saveCookie()">ذخیره کوکی</button>\n'
        '        <button class="btn ghost" onclick="clearCookie()">پاک کردن</button>\n'
        '        <button class="btn ghost" onclick="showHelp()">راهنما</button>\n'
        '      </div>\n'
        '      <div id="cookieHelp" style="display:none;font-size:11px;line-height:1.7;background:#222;padding:8px;border-radius:8px;margin-top:8px">\n'
        '        1) با VPN برو <code>https://arena.ai</code> لاگین کن<br>\n'
        '        2) F12 بزن، تب Console، بنویس <code>document.cookie</code> اینتر، کپی کن<br>\n'
        '        3) اینجا پیست کن و ذخیره بزن — حالا سرور می‌تونه به جای تو arena.ai را بگیرد<br>\n'
        '        4) دوباره «برو» بزن<br>\n'
        '        <br>اگر کوکی‌ات شامل <code>__cf_bm</code> است، این IP-محوره و زود منقضی میشه — بهتره پراکسی ست کنی.<br>\n'
        '        <br>بوکمارکلت (بکش به بوکمارک بار):<br>\n'
        '        <a id="bmLink" href=\'#\' style="color:#8cf">🔖 ارسال کوکی به دستگیر</a>\n'
        '      </div>\n'
        '    </div>\n'
        '    <div class="drop" id="dropZone">📁 فایل را اینجا رها کن یا کلیک کن<br><small>تبادل با ایجنت خارجی</small><input type="file" id="fileInput" hidden multiple></div>\n'
        f'    <div class="files"><b>فایل‌های تبادل:</b><br>{files_html}</div>\n'
        '    <div style="padding:8px 12px;display:flex;gap:6px;flex-wrap:wrap">\n'
        '      <button class="btn ghost" onclick="loadBridge()">🔄 تازه‌سازی</button>\n'
        '      <button class="btn ghost" onclick="clearBridge()">پاک کردن</button>\n'
        f'      <a class="btn ghost" href="{html.escape(url)}" target="_blank">🌐 مستقیم (VPN)</a>\n'
        '      <button class="btn ghost" onclick="reloadFrame()">🔄 ریلود iframe</button>\n'
        '    </div>\n'
        '  </div>\n'
        '</div>\n'
        '<script>\n'
        'function go(){\n'
        '  var u=document.getElementById("urlInput").value.trim();\n'
        '  if(!u) return;\n'
        '  if(!u.startsWith("http")) u="https://"+u;\n'
        '  document.getElementById("arenaFrame").src="/agent/proxy?url="+encodeURIComponent(u);\n'
        '  history.replaceState(null,"","/agent/browser?url="+encodeURIComponent(u));\n'
        '}\n'
        'function openProxy(){\n'
        '  var u=document.getElementById("urlInput").value.trim();\n'
        '  if(!u.startsWith("http")) u="https://"+u;\n'
        '  window.open("/agent/proxy?url="+encodeURIComponent(u),"_blank");\n'
        '}\n'
        'function reloadFrame(){ document.getElementById("arenaFrame").contentWindow.location.reload(); }\n'
        'document.getElementById("urlInput").addEventListener("keydown",function(e){if(e.key==="Enter") go();});\n'
        'async function sendArena(){\n'
        '  var t=document.getElementById("chatText").value.trim();\n'
        '  if(!t) return;\n'
        '  document.getElementById("chatText").value="";\n'
        '  var msgs=document.getElementById("msgs");\n'
        '  var d=document.createElement("div"); d.className="msg user"; d.innerHTML="<b>you</b>: "+t.replace(/</g,"&lt;"); msgs.appendChild(d); msgs.scrollTop=msgs.scrollHeight;\n'
        '  try{\n'
        '    var r=await fetch("/api/agent/arena",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:t,url:document.getElementById("urlInput").value})});\n'
        '    var j=await r.json();\n'
        '    // v313: server returns {ok,messages} - show last system msg if any, not raw JSON\n'
        '    var last = (j.messages||[]).slice(-1)[0];\n'
        '    var txt = j.reply || j.text || (last?last.text:\"\") || \"پیام ثبت شد — برای دیدن arena.ai باید کوکی معتبر + پراکسی داشته باشی. برای هوش داخلی برو /agent\";\n'
        '    var d2=document.createElement("div"); d2.className="msg sys"; d2.innerHTML="<b>system</b>: \"+txt.replace(/</g,\"&lt;\").substring(0,1000); msgs.appendChild(d2); msgs.scrollTop=msgs.scrollHeight;\n'
        '  }catch(e){\n'
        '    var d3=document.createElement("div"); d3.className="msg sys"; d3.textContent="خطا: "+e; msgs.appendChild(d3);\n'
        '  }\n'
        '}\n'
        'async function loadBridge(){\n'
        '  try{\n'
        '    var r=await fetch("/api/agent/arena?latest=1"); var j=await r.json();\n'
        '    var msgs=document.getElementById("msgs"); msgs.innerHTML="";\n'
        '    (j.messages||[]).slice(-30).forEach(function(m){\n'
        '      var div=document.createElement("div"); div.className="msg "+(m.role=="user"?"user":m.role=="arena"?"arena":"sys");\n'
        '      div.innerHTML="<span class=ts>"+new Date(m.ts*1000).toLocaleTimeString()+"</span> <b>"+m.role+"</b>: "+(m.text||"").replace(/</g,"&lt;");\n'
        '      msgs.appendChild(div);\n'
        '    });\n'
        '    msgs.scrollTop=msgs.scrollHeight;\n'
        '  }catch(e){}\n'
        '}\n'
        'async function clearBridge(){\n'
        '  if(!confirm("لاگ پل آرنا پاک شود؟")) return;\n'
        '  await fetch("/api/agent/arena",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:"__clear__"})});\n'
        '  loadBridge();\n'
        '}\n'
        'async function saveCookie(){\n'
        '  var c=document.getElementById("cookieInput").value.trim();\n'
        '  if(!c){ alert("کوکی خالیه"); return; }\n'
        '  try{\n'
        '    var r=await fetch("/api/agent/arena/cookie",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({cookie:c})});\n'
        '    var j=await r.json();\n'
        '    alert(j.ok?"کوکی ذخیره شد — حالا دوباره برو بزن":"خطا: "+j.error);\n'
        '    if(j.ok) location.reload();\n'
        '  }catch(e){ alert("خطا "+e); }\n'
        '}\n'
        'async function clearCookie(){\n'
        '  try{\n'
        '    var r=await fetch("/api/agent/arena/cookie",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({cookie:""})});\n'
        '    var j=await r.json();\n'
        '    alert(j.ok?"پاک شد":"خطا"); if(j.ok) location.reload();\n'
        '  }catch(e){ alert(e); }\n'
        '}\n'
        'function showHelp(){ var h=document.getElementById("cookieHelp"); h.style.display=h.style.display=="none"?"block":"none"; }\n'
        '// bookmarklet\n'
        'document.getElementById("bmLink").href="javascript:(function(){var c=document.cookie;var u=location.href;var p=prompt(\\"کوکی این سایت:\\\\n\\"+c+\\"\\\\n\\\\nآدرس دستگیرت را وارد کن (مثلا https://daastgir.ir):\\",\\"https://daastgir.ir\\");if(!p)return;fetch(p+\\"/api/agent/arena/cookie\\",{method:\\"POST\\",headers:{\\"Content-Type\\":\\"application/json\\"},body:JSON.stringify({cookie:c,url:u})}).then(r=>r.json()).then(j=>alert(j.ok?\\"کوکی به دستگیر فرستاده شد\\":\\"خطا: \\"+j.error)).catch(e=>alert(e));})();";\n'
        'var dz=document.getElementById("dropZone");\n'
        'var fi=document.getElementById("fileInput");\n'
        'dz.addEventListener("click",function(){fi.click();});\n'
        'dz.addEventListener("dragover",function(e){e.preventDefault();dz.classList.add("dragover");});\n'
        'dz.addEventListener("dragleave",function(){dz.classList.remove("dragover");});\n'
        'dz.addEventListener("drop",async function(e){\n'
        '  e.preventDefault();dz.classList.remove("dragover");\n'
        '  var files=e.dataTransfer.files;\n'
        '  await uploadFiles(files);\n'
        '});\n'
        'fi.addEventListener("change",async function(){await uploadFiles(fi.files);});\n'
        'async function uploadFiles(files){\n'
        '  if(!files||!files.length) return;\n'
        '  var fd=new FormData();\n'
        '  for(var i=0;i<files.length;i++) fd.append("file",files[i]);\n'
        '  try{\n'
        '    var r=await fetch("/api/agent/upload",{method:"POST",body:fd});\n'
        '    var j=await r.json();\n'
        '    alert(j.ok?"آپلود شد":"خطا: "+(j.error||""));\n'
        '    location.reload();\n'
        '  }catch(e){alert("خطا "+e);}\n'
        '}\n'
        '</script>\n</body>\n</html>\n'
    )
    return page
