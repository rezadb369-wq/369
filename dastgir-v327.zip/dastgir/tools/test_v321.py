# -*- coding: utf-8 -*-
"""v321 — اوپن‌روتر برای مغز/سایت/ایجنت + پنل ایجنت مستقیم از سرور.

اجرا: python3 tools/test_v321.py
"""
import ast
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
G, R, X = "\033[32m", "\033[31m", "\033[0m"
n = 0
fails = []


def ck(ok, label):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        print("  " + R + "✗ " + label + X)


TMP = tempfile.mkdtemp(prefix="v321-")
os.environ["BZ_DATA_DIR"] = os.environ.get("BZ_DATA_DIR", TMP)
os.environ.setdefault("BALE_ADMIN_TOKEN", "test-token-not-real")
os.environ.setdefault("BALE_ADMIN_SECRET", "s" * 40)
os.environ.setdefault("BALE_ADMIN_CHAT", "893219571")
sys.path.insert(0, os.path.join(ROOT, "server"))

import assistant as AI  # noqa: E402
import adminbot as A  # noqa: E402
import adminbot_content as CT  # noqa: E402
import orouter as OR  # noqa: E402
import db  # noqa: E402

db.init()
ver = open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8").read().strip()
sw = open(os.path.join(ROOT, "site", "sw.js"), encoding="utf-8").read()
readme = open(os.path.join(ROOT, "README.md"), encoding="utf-8").read()

print("v321 — پین + اوپن‌روتر + پنل ایجنت")

ck(ver == A.DIAG_LATEST and ver.isdigit() and int(ver) >= 321, "پین نسخه ≥321")
ck(("bazarche-v" + ver) in sw, "sw.js با VERSION")
ck(("دست گیر — v" + ver) in readme, "README با VERSION")
ck(AI.SITE_DEFAULT_BASE.rstrip("/") == "https://openrouter.ai/api/v1",
   "هوش سایت = openrouter.ai")
ck(AI.SITE_DEFAULT_MODEL == OR.OR_DEFAULT, "مدل پیش‌فرض سایت = مدل تست‌شده")
ck(AI.BRAINS["openrouter"][2] == OR.OR_DEFAULT, "مغز چهارم همان مدل تست‌شده")
ck(hasattr(AI, "set_model_override") and hasattr(AI, "model_override"),
   "اوراید مدل هر-درخواست")

src_app = open(os.path.join(ROOT, "server", "app.py"), encoding="utf-8").read()
ck("[:120]" in src_app and 'model") or body.get("mode") or "auto")[:120]' in src_app,
   "model_sel دیگر در ۲۰ حرف بریده نمی‌شود")
ck("/api/agent/models" in src_app and "/api/agent/model-test" in src_app,
   "API فهرست و تست مدل")
ck("_agent_apply_model" in src_app, "شناسهٔ کامل اوپن‌روتر به مغز چهارم می‌رود")

src_vaf = open(os.path.join(ROOT, "server", "views_agent_full.py"), encoding="utf-8").read()
ck("def _v321_guides_html" in src_vaf and "businesses_wipe" in src_vaf,
   "راهنمای ابزار با مثال wipe")
ck("نه بله، نه PhonePilot" in src_vaf or "نه PhonePilot" in src_vaf,
   "بنر هوش مستقیم از سرور")
ck("/api/agent/model-test" in src_vaf and "or-models" in src_vaf,
   "UI فهرست مدل + تست")

brain = open(os.path.join(ROOT, "deploy", "brain.env"), encoding="utf-8").read()
ck("AI_BRAIN_OR_KEY=" in brain and "AI_SITE_API_KEY=" in brain, "کلید در brain.env")
ck("openrouter.ai" in brain, "base اوپن‌روتر در بسته")
ck("sk-or-v1-" in brain, "کلید اوپن‌روتر داخل بسته (دستور مدیر)")

cg = open(os.path.join(ROOT, "deploy", "codeguard.sh"), encoding="utf-8").read()
ck("AI_SITE_API_KEY=" in cg and "openrouter" in cg, "codeguard کلید را به سایت هم می‌نویسد")

ck("businesses_wipe" in CT.TOOLS and "business_delete" in CT.TOOLS,
   "ابزار حذف سر جایش است")
ck("business_save" in CT._CONFIRM_TOOLS, "نوشتن محتوا هنوز تأیید می‌خواهد")

# same-model helper
ck(OR._same_model("openai/gpt-4o-mini", "openai/gpt-4o-mini"), "same model exact")
ck(OR._same_model("nvidia/nemotron-3-ultra-550b-a55b:free",
                  "nvidia/nemotron-3-ultra-550b-a55b:free"), "same :free")
ck(not OR._same_model("openai/gpt-4o-mini", "anthropic/claude-sonnet-5"),
   "مدل دیگر رد")

# no Bale agent token
needle = "55164" + "6991"
hits = []
for dirpath, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ("__pycache__", "data", ".git")]
    for fn in files:
        if fn.endswith((".pyc", ".zip", ".db")):
            continue
        rel = os.path.relpath(os.path.join(dirpath, fn), ROOT)
        if rel.replace("\\", "/").startswith("tools/test_"):
            continue
        fp = os.path.join(dirpath, fn)
        try:
            txt = open(fp, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        if needle in txt:
            hits.append(rel)
ck(not hits, "توکن ایجنت بله در درخت نیست")

for rel in ("server/orouter.py", "server/assistant.py", "server/app.py",
            "server/views_agent_full.py", "server/views_agent_desk.py",
            "server/adminbot.py"):
    ast.parse(open(os.path.join(ROOT, rel), encoding="utf-8").read())
ck(True, "فایل‌های کلیدی parse")

print()
print("موفق: %d   ناموفق: %d" % (n, len(fails)))
if fails:
    for x in fails:
        print("  -", x)
    sys.exit(1)
print("همه موفق — v321 قفل شد.")
