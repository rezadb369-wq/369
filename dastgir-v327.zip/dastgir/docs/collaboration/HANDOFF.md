# HANDOFF — v327 (۲۲/۰۹/۲۰۲۶)

بخوان: `RULES.md` · `CURRENT-STATE.md` · `KNOWLEDGE.md` · `WHATS-NEW.md` · همین فایل.

## الان چیست

- **فاز ۶:** نوبت امروز/گفت‌وگو (`booking_status`) + کارت مغز ربات جدا از چت پنل.
- فاز ۵ محتوا، فاز ۴ دستور، فاز ۳ سیستم، فاز ۲ گفت‌وگو/درآمد، فاز ۱ امروز — سر جایشان.
- `/agent` = `/panel/agent`. فرم نه JSON. هوش از سرور. نه PhonePilot. sqlite نوشتنی ممنوع.

## پین

| فایل | مقدار |
|---|---|
| `VERSION.txt` | `327` |
| `site/sw.js` | `bazarche-v327` |
| `DIAG_LATEST` | `"327"` |

## تست

```
python3 tools/test_v327.py
python3 tools/test_v326.py
python3 tools/test_v318.py
python3 tools/test_security_v318.py
```
