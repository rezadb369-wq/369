# -*- coding: utf-8 -*-
"""v322 agent console helpers — workbench lives in views_agent_desk.py.
One code path for /agent and /panel/agent. Arena stays gone.
"""

import json as _js
import os, time as _t, html as _html
import urllib.parse as _uq
import db

# v316 (دستور مدیر): تمام بخش آرنا پاک شد — فقط ابزارهای مدیریتی داخلی
TOOL_FA = {
    "setting": "⚙️ تنظیمات سایت", "page": "📄 ساخت/ویرایش صفحه",
    "post_save": "📰 ذخیرهٔ مقاله/پست", "post_delete": "🗑️ حذف مقاله",
    "category_save": "🗂️ ذخیرهٔ دسته", "category_delete": "🗑️ حذف دسته",
    "business_save": "🏪 ذخیرهٔ کسب‌وکار", "business_delete": "🗑️ حذف کسب‌وکار", "businesses_wipe": "🗑️ حذف همهٔ کسب‌وکارها", "item_save": "📦 ذخیرهٔ کالا",
    "item_delete": "🗑️ حذف کالا", "review_moderate": "⭐ تعدیل نظر",
    "review_delete": "🗑️ حذف نظر", "biz_moderate": "🚦 تعدیل کسب‌وکار",
    "broadcast": "📣 پیام همگانی", "coupon_save": "🎟️ ذخیرهٔ کد تخفیف",
    "coupon_delete": "🗑️ حذف کد تخفیف", "toplist_save": "🏆 ذخیرهٔ لیست برترین",
    "toplist_delete": "🗑️ حذف لیست برترین", "flashdeal_save": "⚡ ذخیرهٔ پیشنهاد لحظه‌ای",
    "flashdeal_delete": "🗑️ حذف پیشنهاد لحظه‌ای", "event_save": "📅 ذخیرهٔ رویداد",
    "event_delete": "🗑️ حذف رویداد", "ad_save": "🖼️ ذخیرهٔ بنر/تبلیغ",
    "ad_delete": "🗑️ حذف بنر", "plan_save": "💎 ذخیرهٔ پلن اشتراک",
    "plan_delete": "🗑️ حذف پلن", "badge_save": "🎖️ ذخیرهٔ نشان",
    "badge_delete": "🗑️ حذف نشان", "story_add": "📸 افزودن استوری",
    "story_delete": "🗑️ حذف استوری", "claim_moderate": "🔏 تعدیل ادعای مالکیت",
    "ticket_reply": "🎫 پاسخ تیکت", "customer_moderate": "👤 تعدیل مشتری",
    "order_status": "🧾 تغییر وضعیت سفارش", "booking_status": "📆 تغییر وضعیت نوبت",
    "area_rename": "🗺️ ویرایش محله", "trash_restore": "♻️ بازگردانی از سطل بازیافت",
    "code_list": "📁 فهرست فایل‌های کد", "code_read": "📖 خواندن کد",
    "code_edit": "✏️ ویرایش کد", "code_write": "📝 نوشتن فایل تازه",
    "code_revert": "↩️ برگشت تغییر کد", "code_search": "🔍 جست‌وجوی کد",
    "code_status": "🚦 وضعیت صف کد", "ai_setup": "🤖 تنظیم هوش سایت",
    "service_restart": "🔄 ری‌استارت سرویس", "brain_switch": "🧠 سوئیچ مغز مدیر",
    "panel_read": "🔎 خواندن بخش پنل", "panel_sections": "🧭 فهرست بخش‌های پنل",
    "subscription_set": "💳 تنظیم اشتراک", "owner_moderate": "⛔ مسدود/آزادسازی مالک",
    "sec_report": "🛡️ گزارش زندهٔ امنیت", "bulk_approve": "✅ تأیید گروهی",
    "backup_now": "💾 بکاپ فوری", "cache_clear": "🧹 پاک‌سازی کش",
    "seo_check": "🌐 بررسی سئو", "health_check": "❤️ بررسی سلامت",
    "file_list": "📃 فهرست فایل‌های سایت",
    "file_upload": "📤 ارسال فایل", "file_download": "📥 دریافت فایل",
    "shell_exec": "🖥️ اجرای فرمان (ترمینال)",
    "sql_read": "🗄️ پرس‌وجوی خواندنی دیتابیس",
    "log_tail": "📜 لاگ زندهٔ سرویس",
    "sys_info": "🖥️ اطلاعات سیستم",
    "file_read": "📖 خواندن فایل سایت",
    "file_write": "📝 نوشتن فایل سایت",
    "file_edit": "✏️ ویرایش فایل سایت",
    "file_delete": "🗑️ حذف فایل سایت",
    "db_tables": "🗄️ جدول‌ها و تعداد",
    "backup_list": "💾 فهرست بکاپ‌ها",
    "version_info": "🏷️ نسخه و پین‌ها",
}
from ui import av, icon, esc, fa, fa_group, stat_card, empty_state, page as public_page, panel_page
from views_panel import _msg, _pg, panel_pager
from ui import jdate, jdatetime, jdatetime_ts

def _v321_guides_html():
    """v321: هر بخش کنسول — یک خط توضیح + مثال قابل‌کپی."""
    groups = [
        ("فروشگاه — کسب‌وکار و تنظیمات",
         "ساخت/ویرایش/حذف کسب‌وکار و تنظیمات سایت مستقیم از سرور. sqlite و PhonePilot لازم نیست.",
         [("business_save", "کسب‌وکار تازه",
           '{"id":0,"fields":{"name":"نانوایی نمونه","cat_slug":"cafe"}}',
           "id=0 یعنی ساخت. cat_slug باید از دسته‌های موجود باشد (مثلاً cafe)."),
          ("business_save", "ویرایش فیلد",
           '{"id":12,"fields":{"phone":"03112345678"}}',
           "id موجود را بگذار؛ فقط فیلدهایی که می‌خواهی عوض شوند."),
          ("business_delete", "حذف یکی (سطل بازیافت)",
           '{"id":12}', "بعد از اجرا در سطل بازیافت است، نه SQL خام."),
          ("businesses_wipe", "حذف همه",
           '{"confirm":"حذف همه کسب‌وکارها"}',
           "confirm باید دقیقاً همین جمله باشد."),
          ("setting", "نام سایت",
           '{"key":"site_name","value":"دست گیر"}', "یک تنظیم. چندتایی با items."),
          ("page", "صفحه درباره",
           '{"slug":"about","title":"درباره ما","body":"متن صفحه"}', "بازنویسی کامل صفحه.")]),
        ("کالا و سفارش", "کاتالوگ، سفارش و نوبت — همان کار پنل، از ایجنت.",
         [("item_save", "کالای تازه",
           '{"id":0,"biz_id":12,"title":"نان سنگک","price":40000}', "biz_id = شناسه کسب‌وکار."),
          ("order_status", "وضعیت سفارش",
           '{"id":8,"status":"done"}', "status: new/paid/done/cancel و مشابه."),
          ("backup_now", "بکاپ فوری", "{}", "اسناپ‌شات SQLite بدون توقف سایت.")]),
        ("فایل و کد", "خواندن فوری است. نوشتن کد از دیوار تأیید می‌گذرد.",
         [("file_read", "خواندن فایل", '{"path":"VERSION.txt"}', "کل درخت سایت؛ رازها برای مالک."),
          ("code_search", "جستجوی کد", '{"query":"owner_token"}', "grep روی server/site."),
          ("shell_exec", "ترمینال", '{"cmd":"ls -la /opt/dastgir"}',
           "از چت هوش بله می‌خواهد؛ اینجا دکمه = اجرای خودت.")]),
        ("سلامت و امنیت", "گزارش زنده بدون حدس.",
         [("health_check", "سلامت", "{}", "نسخه، دیسک، تنظیمات."),
          ("sec_report", "امنیت", "{}", "ssh/فایروال اگر روی سرور باشد."),
          ("sql_read", "SQL خواندنی",
           '{"q":"SELECT COUNT(*) AS n FROM businesses"}', "فقط SELECT. نوشتن رد می‌شود.")]),
    ]
    html = ['<div class="card glass card-pad mb-lg" id="agent-guides">',
            '<h3 class="card-title mb-sm">بخش‌ها — توضیح + مثال</h3>',
            '<p class="text-sm text-muted mb-md">هر کارت یک کار واقعی است. «پر کردن فرم» مثال را در اجرای فوری می‌گذارد. هوش از <b>سرور</b> است، نه ربات بله و نه PhonePilot.</p>']
    for title, blurb, items in groups:
        html.append('<div class="mb-lg"><h4 class="card-title mb-sm">' + esc(title)
                    + '</h4><p class="text-sm text-muted mb-sm">' + esc(blurb) + '</p>')
        html.append('<div class="table-wrap"><table class="table"><thead><tr>'
                    '<th>ابزار</th><th>مثال JSON</th><th>کاربرد</th><th></th></tr></thead><tbody>')
        for tool, label, args, how in items:
            html.append(
                '<tr><td><b>' + esc(label) + '</b><br><code class="text-xs">' + esc(tool)
                + '</code></td><td><pre class="text-xs" dir="ltr" style="white-space:pre-wrap;max-height:90px;overflow:auto">'
                + esc(args) + '</pre></td><td class="text-sm">' + esc(how)
                + '</td><td><button type="button" class="btn btn-glass btn-sm" data-quick=\''
                + '{"tool":"' + esc(tool) + '","args":' + args + '}\'>پر کردن</button></td></tr>'
            )
        html.append('</tbody></table></div></div>')
    html.append('</div>')
    return "\n".join(html)


def _v321_model_card():
    has = False
    cur = "nvidia/nemotron-3-ultra-550b-a55b:free"
    feat = ""
    try:
        import orouter as _OR
        has = _OR.has_key()
        cur = _OR.OR_DEFAULT
        try:
            cur = ((db.get_settings().get("ai_brain_or_model") or "").strip() or cur)
        except Exception:
            pass
        for mid in _OR.OR_FEATURED:
            feat += '<option value="%s">%s</option>' % (esc(mid), esc(mid))
    except Exception:
        pass
    st = "کلید وصل است" if has else "کلید اوپن‌روتر نیست — پایین بچسبان"
    return (
        '<div class="card glass card-pad mb-lg" style="border:2px solid var(--color-primary)">'
        '<h3 class="card-title mb-sm">هوش مستقیم از سرور — نه بله، نه PhonePilot</h3>'
        '<p class="text-sm text-muted mb-md">چت همین صفحه به OpenRouter روی سرور می‌رود. '
        'مدل انتخابی اول تست می‌شود؛ اگر جواب خالی باشد یا مدل دیگری جواب بدهد، عوض نمی‌شود. '
        'کلید قابل جایگزینی است.</p>'
        '<p class="mb-sm"><span class="badge badge-open" id="or-key-status">' + esc(st)
        + '</span> مدل فعلی: <code dir="ltr" id="or-current">' + esc(cur) + '</code></p>'
        '<div class="grid grid-2" style="align-items:end"><div class="field" style="margin:0">'
        '<label class="field-label">جستجو / انتخاب مدل (فهرست زنده)</label>'
        '<input class="input" id="or-filter" dir="ltr" placeholder="gemini, gpt-4o-mini, claude…">'
        '<select class="select mt-sm" id="or-models" dir="ltr" size="8" style="min-height:160px">'
        + feat + '</select>'
        '<p class="field-hint" id="or-count">ویژهٔ تست‌شده — فهرست کامل بعد از بارگذاری</p></div><div>'
        '<button type="button" class="btn btn-primary btn-block" id="or-test">تست و اعمال این مدل</button>'
        '<pre id="or-test-out" class="text-xs mt-sm" style="min-height:80px;white-space:pre-wrap"></pre>'
        '<hr class="divider"><form method="post" action="/agent/or-key">'
        '<div class="field"><label class="field-label">کلید تازهٔ اوپن‌روتر (sk-or-v1-…)</label>'
        '<input class="input" name="key" dir="ltr" autocomplete="off" placeholder="sk-or-v1-…"></div>'
        '<button class="btn btn-glass btn-block" type="submit">تست کلید و جایگزینی مغز+سایت+ایجنت</button>'
        '</form></div></div></div>'
    )


def _v321_js():
    return """
<script>
(function(){
  var sel = document.getElementById('or-models');
  var filter = document.getElementById('or-filter');
  var out = document.getElementById('or-test-out');
  var curEl = document.getElementById('or-current');
  var countEl = document.getElementById('or-count');
  var all = [];
  var curModel = window.__agentModel || 'auto';
  function fill(list){
    if(!sel) return;
    var q = (filter && filter.value || '').toLowerCase();
    var rows = (list||[]).filter(function(m){ return !q || (m.id+m.name).toLowerCase().indexOf(q)>=0; });
    sel.innerHTML = '';
    rows.slice(0,400).forEach(function(m){
      var o = document.createElement('option');
      o.value = m.id; o.textContent = (m.free?'[free] ':'') + m.id;
      sel.appendChild(o);
    });
    if(countEl) countEl.textContent = rows.length + ' مدل';
  }
  async function loadModels(){
    try{
      var r = await fetch('/api/agent/models', {credentials:'same-origin'});
      var j = await r.json();
      if(j && j.ok){
        all = j.models || [];
        fill(all);
        if(j.current && curEl) curEl.textContent = j.current;
        if(j.current){ curModel = j.current; window.__agentModel = curModel; }
        var badge = document.getElementById('model-current');
        if(badge) badge.textContent = curModel;
        var logm = document.getElementById('log-model');
        if(logm) logm.textContent = curModel;
      }
    }catch(e){ if(out) out.textContent = 'بارگذاری مدل‌ها: '+e; }
  }
  if(filter) filter.addEventListener('input', function(){ fill(all); });
  var testBtn = document.getElementById('or-test');
  if(testBtn) testBtn.addEventListener('click', async function(){
    var mid = sel && sel.value;
    if(!mid){ if(out) out.textContent='مدلی انتخاب نشده'; return; }
    if(out) out.textContent = 'تست زنده '+mid+' …';
    try{
      var r = await fetch('/api/agent/model-test', {method:'POST', credentials:'same-origin',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({model: mid})});
      var j = await r.json();
      if(j.ok){
        curModel = j.used || mid;
        window.__agentModel = curModel;
        if(curEl) curEl.textContent = curModel;
        var badge = document.getElementById('model-current');
        if(badge) badge.textContent = curModel;
        var logm = document.getElementById('log-model');
        if(logm) logm.textContent = curModel;
        out.textContent = 'مدل واقعی: '+ (j.used||mid) +' — '+ (j.ms||'?') +'ms\\n'+ (j.text||'');
      }else{
        out.textContent = 'اعمال نشد: '+(j.error||j.used||'نامشخص')+'\\nمدل قبلی سر جایش است.';
      }
    }catch(e){ out.textContent = 'خطا: '+e; }
  });
  loadModels();
  document.querySelectorAll('#model-switcher .chip').forEach(function(ch){
    ch.addEventListener('click', function(){
      document.querySelectorAll('#model-switcher .chip').forEach(function(x){ x.classList.remove('is-active'); });
      ch.classList.add('is-active');
      curModel = ch.getAttribute('data-model') || 'auto';
      window.__agentModel = curModel;
      var badge = document.getElementById('model-current');
      if(badge) badge.textContent = curModel;
      var logm = document.getElementById('log-model');
      if(logm) logm.textContent = curModel;
    });
  });
  window.__agentModelGet = function(){ return window.__agentModel || curModel || 'auto'; };
})();
</script>
"""


def _live_data():
    import json as _js, pathlib as _pl
    pend_data = {}
    try:
        pf = "/tmp/dastgir-admin-pending.json"
        if _pl.Path(pf).exists():
            pend_data = _js.loads(_pl.Path(pf).read_text(encoding="utf-8")[:8000] or "{}")
    except Exception:
        pend_data = {}
    try:
        batches = db.agent_batch_list()
        staged = [b for b in batches if b["status"]=="staged"]
        applied = [b for b in batches if b["status"]=="applied"]
    except Exception:
        batches, staged, applied = [], [], []
    try:
        last = {}
        lp = "/tmp/dastgir-agent-last-action.json"
        if _pl.Path(lp).exists():
            last = _js.loads(_pl.Path(lp).read_text(encoding="utf-8")[:8000] or "{}")
    except Exception:
        last = {}
    try:
        has_rb = _pl.Path(os.path.join(db.DATA_DIR, "agent-rollback.json")).exists()
    except Exception:
        has_rb = False
    try:
        import adminbot_content as CT
        ok_h, msg_h = CT.tool_execute("health_check", {})
        health_msg = str(msg_h)[:3000]
    except Exception as e:
        health_msg = f"خطا: {e}"
    try:
        import adminbot_content as CT
        tools = list(CT.TOOLS)
    except Exception:
        tools = ["setting","business_save","item_save","backup_now","health_check","seo_check","bulk_approve","cache_clear","code_read","code_search","code_edit","sec_report","panel_read","shell_exec","sql_read","log_tail","file_list","file_upload","file_download","sys_info","db_tables","version_info"]
    return pend_data, batches, staged, applied, last, has_rb, health_msg, tools

def _files_card():
    """v316 صندوق تبادل فایل ایجنت — ارتقا یافته، بدون آرنا"""
    try:
        import agent_browser as _ABX
        files = _ABX.exchange_list()
    except Exception:
        files = []
    rows = ""
    for f in files[:20]:
        try:
            nm = str(f.get("name") or "")
            kb = int(f.get("size") or 0) // 1024
            when = jdatetime_ts(f.get("mtime")) if f.get("mtime") else ""
            rows += ('<tr><td dir="ltr"><code>' + esc(nm) + '</code></td>'
                     '<td class="nums">' + fa(kb) + ' KB</td>'
                     '<td class="nums text-xs">' + esc(str(when)) + '</td>'
                     '<td><a class="btn btn-ghost btn-sm" href="/agent/file/'
                     + _uq.quote(nm) + '">📥 دریافت</a></td></tr>')
        except Exception:
            pass
    if not rows:
        rows = ('<tr><td colspan="4" class="text-center text-muted">'
                'صندوق تبادل خالی است — فایل بفرست تا اینجا فهرست شود.</td></tr>')
    return f"""
<div class="card glass card-pad mb-lg">
  <div class="between mb-md" style="flex-wrap:wrap;gap:10px">
    <h3 class="card-title">📦 تبادل فایل ایجنت — ارسال و دریافت</h3>
    <span class="text-xs text-muted">صندوق: <code>data/agent-exchange/</code> · دانلود فقط با نشست ایجنت/مدیر · v321 سرور مستقیم</span>
  </div>
  <form method="post" action="/agent/upload" enctype="multipart/form-data" class="dir-row mb-md">
    <input class="input" type="file" name="file" required>
    <button class="btn btn-primary" type="submit"><span>📤 ارسال فایل</span></button>
  </form>
  <div class="table-wrap"><table class="table"><thead><tr><th>فایل</th><th>اندازه</th><th>زمان</th><th></th></tr></thead><tbody>{rows}</tbody></table></div>
  <p class="field-hint mt-sm">ایجنت v319 کل سایت را می‌خواند و می‌نویسد (file_read/file_write روی server/docs/site). این صندوق تبادل اختیاری است.</p>
</div>"""

def agent_email_gate(s, token="", next_url="/agent"):
    body = f'''
<div class="container" style="max-width:520px;margin:60px auto">
  <div class="card glass card-pad" style="text-align:center">
    <div class="auth-head"><span class="mark">{icon("mail")}</span>
      <h1>ورود با ایمیل — پنل ایجنت مدیریتی</h1>
      <p class="text-sm text-muted">ایمیلتو وارد کن، کد ۶ رقمی میاد، بعد وارد کنسول همه‌کاره ایجنت مدیریتی میشی — v321 سرور مستقیم، فقط مدیریت داخلی.</p>
    </div>
    <form method="post" action="/login/email" class="mt-lg" style="text-align:start">
      <input type="hidden" name="next" value="{esc(next_url)}">
      <div class="field"><label class="field-label">ایمیل</label>
        <input class="input" name="email" type="email" dir="ltr" placeholder="you@example.com" required></div>
      <button class="btn btn-primary btn-block" type="submit">{icon("mail")}<span>ارسال کد ورود</span></button>
    </form>
    <p class="field-hint mt-md">یا با موبایل: <a href="/login?next={esc(next_url)}">ورود با موبایل</a></p>
  </div>
</div>'''
    return public_page(s, "ورود ایمیلی — ایجنت مدیریتی", body, active="/agent")

def agent_key_gate(s, token="", customer=None, owner=None):
    email = ""
    if customer:
        email = customer.get("email") or customer.get("phone") or f"#{customer.get('id')}"
    elif owner:
        email = owner.get("phone") or f"owner#{owner.get('id')}"
    body = f'''
<div class="container" style="max-width:640px;margin:40px auto">
  <div class="card glass card-pad">
    <h2 class="card-title">{icon("lock")} کلید خصوصی ایجنت لازم است</h2>
    <p class="text-sm text-muted">وارد شدی به عنوان <b>{esc(email)}</b> — برای دسترسی ایجنت مدیریتی یا با ایمیلِ مالک سایت وارد شو (خودکار دسترسی کامل می‌گیری) یا کلید یک‌بارمصرف بگیر.</p>
    <div class="alert alert-info mt-md">{icon("info")}<span>در ربات بله مدیر بزن <code>/agent</code> یا <code>پنل ایجنت</code> — ربات لینک یک‌بارمصرف میده مثل <code>/agent?ak=...</code> — روش بزن تا کوکی ست بشه. v316: بخش مرورگر خارجی آرنا حذف شد.</span></div>
    <div class="cluster mt-md">
      <a class="btn btn-glass" href="/panel/agent">{icon("settings")}<span>رفتن به /panel/agent (ادمین)</span></a>
      <a class="btn btn-ghost" href="/">{icon("store")}<span>سایت اصلی</span></a>
    </div>
  </div>
</div>'''
    if token:
        return panel_page(s, "کلید ایجنت", "کلید خصوصی از ربات بله", body, "/panel/agent", token)
    return public_page(s, "کلید ایجنت", body, active="/agent")

def agent_standalone_page(s, token, q=None, customer=None, owner=None, agent_ok=False):
    """v322: یک میز کار با /panel/agent."""
    from views_agent_desk import render_workbench
    return render_workbench(s, token, q=q, customer=customer, owner=owner,
                            agent_ok=agent_ok, in_panel=False)


def agent_panel_page(s, token, q=None, agent_ok=False):
    """v322: همان میز کار داخل پوست پنل."""
    from views_agent_desk import render_workbench
    return render_workbench(s, token, q=q, agent_ok=agent_ok, in_panel=True)
