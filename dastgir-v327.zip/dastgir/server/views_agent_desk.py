# -*- coding: utf-8 -*-
"""v327 — میز کار ایجنت: امروز/محتوا/گفت‌وگو/درآمد/سیستم/دستور/هوش/ابزار."""
from __future__ import annotations

import json as _js
import os
from pathlib import Path as _Path

import db

from ui import icon, esc, fa, stat_card, page as public_page, panel_page
from views_panel import _msg

_SYS_LAST = "/tmp/dastgir-agent-sys-last.json"
_PLAY_LAST = "/tmp/dastgir-agent-play-last.json"
_PLAY_CONFIRM = "اجرای دستور"
_PLAY_BLOCK = frozenset((
    "shell_exec", "service_restart", "businesses_wipe",
    "file_write", "file_edit", "file_delete",
    "code_write", "code_edit", "code_revert",
))


def _n(sql, params=()):
    try:
        r = db._one(sql, params) or {}
        return int(r.get("n") or 0)
    except Exception:
        return 0


def _today_stats():
    return {
        "biz": _n("SELECT COUNT(*) AS n FROM businesses"),
        "pending": _n("SELECT COUNT(*) AS n FROM businesses WHERE status='pending'"),
        "reviews": _n("SELECT COUNT(*) AS n FROM reviews WHERE status='pending'"),
        "tickets": _n("SELECT COUNT(*) AS n FROM tickets WHERE status='open'"),
        "orders": _n("SELECT COUNT(*) AS n FROM orders WHERE status='new'"),
        "bookings": _n("SELECT COUNT(*) AS n FROM bookings WHERE status='new'"),
    }


def _cat_options():
    try:
        rows = db._all(
            "SELECT slug, name FROM categories WHERE COALESCE(active,1)=1 "
            "ORDER BY name LIMIT 250") or []
    except Exception:
        rows = []
    out = ['<option value="">— انتخاب دسته —</option>']
    for r in rows:
        out.append('<option value="%s">%s</option>' % (
            esc(r.get("slug") or ""), esc(r.get("name") or r.get("slug") or "")))
    return "".join(out)


def _biz_rows():
    try:
        return db._all(
            "SELECT id, name, status, cat_slug, phone FROM businesses "
            "ORDER BY id DESC LIMIT 20") or []
    except Exception:
        return []


def _pending_rows():
    try:
        return db._all(
            "SELECT id, name, cat_slug, status FROM businesses "
            "WHERE status='pending' ORDER BY id DESC LIMIT 20") or []
    except Exception:
        return []


def handle_content(kind, data):
    """فرم‌های تب محتوا → همان ابزارهای موجود. برمی‌گرداند (ok, msg)."""
    import adminbot_content as CT
    kind = (kind or "").strip()
    data = data or {}

    def g(k, n=200):
        return str(data.get(k) or "").strip()[:n]

    try:
        if kind == "biz":
            name = g("name", 80)
            cat = g("cat_slug", 40)
            if not name:
                return False, "نام کسب‌وکار لازم است."
            if not cat:
                return False, "دسته را انتخاب کن."
            fields = {"name": name, "cat_slug": cat}
            phone = g("phone", 20)
            city = g("city", 40)
            if phone:
                fields["phone"] = phone
            if city:
                fields["city"] = city
            return CT.tool_execute("business_save", {"id": 0, "fields": fields})
        if kind == "biz-del":
            bid = int(g("id", 12) or 0)
            if bid <= 0:
                return False, "کسب‌وکار انتخاب نشده."
            return CT.tool_execute("business_delete", {"id": bid})
        if kind == "wipe":
            return CT.tool_execute("businesses_wipe", {"confirm": g("confirm", 80)})
        if kind == "moderate":
            bid = int(g("id", 12) or 0)
            act = g("action", 12)
            if bid <= 0:
                return False, "شناسه نیست."
            if act not in ("approve", "reject", "hide", "show"):
                return False, "عمل نامعتبر."
            return CT.tool_execute("biz_moderate", {"id": bid, "action": act})
        if kind == "bulk":
            rows = db._all("SELECT id FROM businesses WHERE status='pending'") or []
            n = 0
            for r in rows:
                ok, _msg_t = CT.tool_execute(
                    "biz_moderate", {"id": r["id"], "action": "approve"})
                if ok:
                    n += 1
            if not rows:
                return True, "صف تأیید خالی بود."
            return True, "تأیید گروهی: %s کسب‌وکار." % n
        if kind == "setting":
            val = g("value", 80)
            if not val:
                return False, "نام سایت خالی است."
            return CT.tool_execute("setting", {"key": "site_name", "value": val})
        if kind in ("biz-edit", "edit"):
            bid = int(g("id", 12) or 0)
            field = g("field", 20)
            val = g("value", 1500) or g("descr", 1500)
            allowed = ("name", "phone", "city", "descr", "address", "cat_slug")
            if bid <= 0:
                return False, "کسب‌وکار انتخاب نشده."
            if field not in allowed:
                return False, "فیلد نامعتبر."
            if not val:
                return False, "مقدار خالی است."
            return CT.tool_execute("business_save", {"id": bid, "fields": {field: val}})
        if kind == "item":
            bid = int(g("biz_id", 12) or g("id", 12) or 0)
            title = g("title", 120)
            if bid <= 0:
                return False, "کسب‌وکار انتخاب نشده."
            if not title:
                return False, "عنوان کالا لازم است."
            data = {"biz_id": bid, "title": title}
            raw_p = "".join(c for c in g("price", 12) if c.isdigit())
            if raw_p:
                data["price"] = int(raw_p)
            descr = g("descr", 500) or g("body", 500)
            if descr:
                data["descr"] = descr
            return CT.tool_execute("item_save", {"id": 0, "data": data})
        if kind in ("cat", "category"):
            name = g("name", 60)
            if not name:
                return False, "نام دسته لازم است."
            args = {"id": 0, "name": name}
            parent = g("parent", 80)
            if parent:
                args["parent"] = parent
            return CT.tool_execute("category_save", args)
        if kind == "page":
            slug = g("slug", 30)
            title = g("title", 100)
            body = g("body", 4000)
            if slug not in ("about", "rules"):
                return False, "صفحه باید about یا rules باشد."
            if not title or not body:
                return False, "عنوان و متن صفحه لازم است."
            return CT.tool_execute("page", {"slug": slug, "title": title, "body": body})
        if kind == "post":
            title = g("title", 120)
            body = g("body", 8000)
            if not title:
                return False, "عنوان مقاله لازم است."
            args = {"id": 0, "title": title, "body": body or title,
                    "excerpt": g("excerpt", 300), "status": "published"}
            return CT.tool_execute("post_save", args)
        if kind == "color":
            import re as _re
            key = g("key", 24) or "color_primary"
            val = g("value", 20) or g("color", 20)
            allowed_c = ("color_primary", "color_accent",
                         "color_background", "color_foreground")
            if key not in allowed_c:
                return False, "کلید رنگ نامعتبر."
            if not _re.match(r"^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$", val):
                return False, "رنگ باید مثل #0b6059 باشد."
            return CT.tool_execute("setting", {"key": key, "value": val})
        return False, "فرم ناشناخته."
    except Exception as e:
        return False, str(e)[:200]


def _iint(v, default=0):
    try:
        return int(str(v).strip() or default)
    except Exception:
        return default


def handle_talk(kind, data):
    """تب گفت‌وگو → review_moderate / ticket_reply / claim_moderate / …"""
    import adminbot_content as CT
    kind = (kind or "").strip()
    data = data or {}

    def g(k, n=200):
        return str(data.get(k) or "").strip()[:n]

    try:
        if kind == "review":
            rid = _iint(g("id", 12))
            act = g("action", 12)
            if rid <= 0:
                return False, "نظر انتخاب نشده."
            if act not in ("approve", "reject"):
                return False, "عمل نامعتبر."
            return CT.tool_execute("review_moderate", {"id": rid, "action": act})
        if kind == "review-del":
            rid = _iint(g("id", 12))
            if rid <= 0:
                return False, "نظر انتخاب نشده."
            return CT.tool_execute("review_delete", {"id": rid})
        if kind == "review-bulk":
            return CT.tool_execute("bulk_approve", {"kind": "reviews"})
        if kind == "ticket":
            tid = _iint(g("id", 12))
            body = g("body", 2000)
            if tid <= 0:
                return False, "تیکت انتخاب نشده."
            if not body:
                return False, "متن پاسخ خالی است."
            return CT.tool_execute("ticket_reply", {"id": tid, "body": body})
        if kind == "report":
            rid = _iint(g("id", 12))
            act = g("action", 12) or "resolve"
            if rid <= 0:
                return False, "گزارش نیست."
            status = "dismissed" if act in ("dismiss", "dismissed") else "resolved"
            if not db.resolve_report(rid, status=status):
                return False, "گزارش پیدا نشد."
            return True, "گزارش #%s → %s." % (rid, status)
        if kind == "report-bulk":
            return CT.tool_execute("bulk_approve", {"kind": "reports"})
        if kind == "claim":
            cid = _iint(g("id", 12))
            act = g("action", 12)
            if cid <= 0:
                return False, "ادعا انتخاب نشده."
            if act not in ("approve", "reject"):
                return False, "عمل نامعتبر."
            return CT.tool_execute("claim_moderate", {"id": cid, "action": act})
        if kind == "broadcast":
            text = g("text", 500)
            if not text:
                return False, "متن پیام خالی است."
            if g("confirm", 80) != "ارسال همگانی":
                return False, "برای ارسال، confirm باید دقیقاً «ارسال همگانی» باشد."
            return CT.tool_execute("broadcast", {"text": text})
        if kind == "order":
            oid = _iint(g("id", 12))
            status = g("status", 20)
            if oid <= 0:
                return False, "سفارش انتخاب نشده."
            if status not in ("new", "confirmed", "ready", "done", "cancelled"):
                return False, "وضعیت نامعتبر."
            return CT.tool_execute("order_status", {"id": oid, "status": status})
        if kind == "booking":
            kid = _iint(g("id", 12))
            status = g("status", 20)
            if kid <= 0:
                return False, "نوبت انتخاب نشده."
            if status not in ("new", "confirmed", "done", "cancelled"):
                return False, "وضعیت نامعتبر."
            return CT.tool_execute("booking_status", {"id": kid, "status": status})
        return False, "فرم ناشناخته."
    except Exception as e:
        return False, str(e)[:200]


def handle_money(kind, data):
    """تب درآمد → subscription_set / coupon_save / ad_save / flashdeal_save / badge_save."""
    import adminbot_content as CT
    kind = (kind or "").strip()
    data = data or {}

    def g(k, n=200):
        return str(data.get(k) or "").strip()[:n]

    try:
        if kind == "sub":
            bid = _iint(g("biz_id", 12))
            slug = g("plan_slug", 24)
            months = _iint(g("months", 4))
            if bid <= 0:
                return False, "کسب‌وکار انتخاب نشده."
            if not slug:
                return False, "پلن را انتخاب کن."
            args = {"biz_id": bid, "plan_slug": slug}
            if months:
                args["months"] = months
            return CT.tool_execute("subscription_set", args)
        if kind == "coupon":
            code = g("code", 40)
            title = g("title", 120)
            percent = _iint(g("percent", 4), -1)
            if not code or not title:
                return False, "کد و عنوان لازم است."
            if percent < 0 or percent > 99:
                return False, "درصد باید ۰ تا ۹۹ باشد."
            args = {"id": 0, "code": code, "title": title, "percent": percent,
                    "biz_id": _iint(g("biz_id", 12)), "expires": g("expires", 20),
                    "active": 1}
            return CT.tool_execute("coupon_save", args)
        if kind == "ad":
            title = g("title", 120)
            if not title:
                return False, "عنوان بنر لازم است."
            slot = g("slot", 20) or "home"
            args = {"id": 0, "title": title, "body": g("body", 500),
                    "url": g("url", 300), "slot": slot, "image": "",
                    "biz_id": _iint(g("biz_id", 12)), "starts": "", "ends": "",
                    "weight": 1, "active": 1}
            return CT.tool_execute("ad_save", args)
        if kind == "deal":
            bid = _iint(g("biz_id", 12))
            title = g("title", 120)
            percent = _iint(g("percent", 4))
            ends = g("ends", 20)
            if bid <= 0:
                return False, "کسب‌وکار انتخاب نشده."
            if not title or not ends:
                return False, "عنوان و پایان لازم است."
            if not (1 <= percent <= 99):
                return False, "درصد باید ۱ تا ۹۹ باشد."
            args = {"id": 0, "biz_id": bid, "title": title, "descr": g("body", 500),
                    "percent": percent, "starts": "", "ends": ends, "active": 1}
            return CT.tool_execute("flashdeal_save", args)
        if kind == "badge":
            name = g("name", 60)
            if not name:
                return False, "نام نشان لازم است."
            color = g("color", 7) or "#059669"
            args = {"id": 0, "name": name, "slug": "", "icon": g("icon", 40) or "award",
                    "color": color, "descr": g("body", 200), "sort": 0, "active": 1}
            return CT.tool_execute("badge_save", args)
        return False, "فرم ناشناخته."
    except Exception as e:
        return False, str(e)[:200]


def _sys_save(kind, ok, msg):
    text = str(msg)[:12000]
    try:
        _Path(_SYS_LAST).write_text(
            _js.dumps({"kind": kind, "ok": bool(ok), "msg": text},
                      ensure_ascii=False),
            encoding="utf-8")
    except Exception:
        pass
    try:
        _Path("/tmp/dastgir-agent-sys-last.txt").write_text(text, encoding="utf-8")
    except Exception:
        pass


def _sys_load():
    try:
        p = _Path(_SYS_LAST)
        if p.exists():
            return _js.loads(p.read_text(encoding="utf-8")[:13000] or "{}")
    except Exception:
        pass
    return {}


def handle_sys(kind, data):
    """تب سیستم → backup/health/seo/cache/log/sql/shell/sec — خروجی کامل ذخیره می‌شود."""
    import adminbot_content as CT
    kind = (kind or "").strip()
    data = data or {}

    def g(k, n=500):
        return str(data.get(k) or "").strip()[:n]

    def run(tool, args, label=""):
        ok, msg = CT.tool_execute(tool, args)
        _sys_save(label or tool, ok, msg)
        short = str(msg).replace("\n", " ")[:180]
        return ok, short

    try:
        if kind in ("backup", "backup_now"):
            return run("backup_now", {}, "backup_now")
        if kind in ("backups", "backup_list"):
            return run("backup_list", {}, "backup_list")
        if kind in ("health", "health_check"):
            return run("health_check", {}, "health_check")
        if kind in ("seo", "seo_check"):
            return run("seo_check", {}, "seo_check")
        if kind in ("cache", "cache_clear"):
            return run("cache_clear", {}, "cache_clear")
        if kind in ("logs", "log_tail"):
            n = _iint(g("n", 4) or g("lines", 4), 40)
            n = max(1, min(200, n or 40))
            return run("log_tail", {"n": n}, "log_tail")
        if kind in ("sql", "sql_read"):
            q = g("q", 500) or g("query", 500)
            if not q:
                return False, "پرس‌وجو خالی است."
            return run("sql_read", {"q": q}, "sql_read")
        if kind in ("tables", "db_tables"):
            return run("db_tables", {}, "db_tables")
        if kind in ("info", "sys_info"):
            return run("sys_info", {}, "sys_info")
        if kind in ("version", "version_info"):
            return run("version_info", {}, "version_info")
        if kind in ("sec", "sec_report"):
            return run("sec_report", {}, "sec_report")
        if kind in ("shell", "shell_exec"):
            cmd = g("cmd", 500) or g("command", 500)
            if not cmd:
                return False, "فرمان خالی است."
            if g("confirm", 80) != "اجرای فرمان":
                preview = "پیش‌نمایش فرمان (اجرا نشد):\n$ " + cmd
                _sys_save("shell-preview", True, preview)
                return False, "پیش‌نمایش ذخیره شد. برای اجرا عیناً بنویس: اجرای فرمان"
            return run("shell_exec", {"cmd": cmd}, "shell_exec")
        return False, "فرم ناشناخته."
    except Exception as e:
        return False, str(e)[:200]


def _sys_stats():
    nback = 0
    dbkb = 0
    try:
        bdir = os.path.join(db.DATA_DIR, "backups")
        if os.path.isdir(bdir):
            nback = len([x for x in os.listdir(bdir) if not x.startswith(".")])
    except Exception:
        pass
    try:
        dbkb = int(os.path.getsize(db.DB_PATH) // 1024)
    except Exception:
        pass
    return {"backups": nback, "dbkb": dbkb}


def _backup_rows_html():
    try:
        bdir = os.path.join(db.DATA_DIR, "backups")
        if not os.path.isdir(bdir):
            return '<p class="text-sm text-muted">هنوز بکاپی نیست.</p>'
        files = sorted(os.listdir(bdir))[-12:]
        if not files:
            return '<p class="text-sm text-muted">پوشه بکاپ خالی است.</p>'
        rows = []
        for fn in reversed(files):
            fp = os.path.join(bdir, fn)
            try:
                sz = os.path.getsize(fp) // 1024
            except Exception:
                sz = 0
            rows.append('<tr><td dir="ltr">%s</td><td class="nums">%s KB</td></tr>' % (
                esc(fn), sz))
        return ('<div class="table-wrap"><table class="table"><thead><tr>'
                '<th>فایل</th><th>حجم</th></tr></thead><tbody>%s</tbody></table></div>'
                % "".join(rows))
    except Exception:
        return '<p class="text-sm text-muted">خواندن بکاپ ممکن نشد.</p>'


_TOOL_EX = {
    "setting": '{"key":"site_name","value":"دست گیر"}',
    "page": '{"slug":"about","title":"درباره","body":"متن"}',
    "post_save": '{"id":0,"title":"خبر","body":"متن"}',
    "post_delete": '{"id":1}',
    "category_save": '{"id":0,"name":"کافه","slug":"cafe"}',
    "category_delete": '{"id":1}',
    "business_save": '{"id":0,"fields":{"name":"نانوایی نمونه","cat_slug":"cafe"}}',
    "business_delete": '{"id":12}',
    "businesses_wipe": '{"confirm":"حذف همه کسب‌وکارها"}',
    "item_save": '{"id":0,"data":{"biz_id":1,"title":"نان","price":40000}}',
    "item_delete": '{"id":1}',
    "review_moderate": '{"id":1,"action":"approve"}',
    "review_delete": '{"id":1}',
    "biz_moderate": '{"id":1,"action":"approve"}',
    "broadcast": '{"text":"فردا تعطیل هستیم"}',
    "coupon_save": '{"id":0,"code":"SPRING","title":"بهار","percent":20}',
    "coupon_delete": '{"id":1}',
    "toplist_save": '{"id":0,"title":"برترین‌ها","kind":"manual"}',
    "toplist_delete": '{"id":1}',
    "flashdeal_save": '{"id":0,"biz_id":1,"title":"۲۰٪","percent":20,"ends":"2026-12-31 23:59"}',
    "flashdeal_delete": '{"id":1}',
    "event_save": '{"id":0,"title":"جشنواره","date":"2026-10-01"}',
    "event_delete": '{"id":1}',
    "ad_save": '{"id":0,"title":"بنر خانه","url":"/","slot":"home"}',
    "ad_delete": '{"id":1}',
    "plan_save": '{"id":0,"name":"حرفه‌ای","price":0}',
    "plan_delete": '{"id":1}',
    "badge_save": '{"id":0,"name":"ویژه","color":"#059669"}',
    "badge_delete": '{"id":1}',
    "story_add": '{"biz_id":1,"image":"/assets/img/x.jpg"}',
    "story_delete": '{"id":1}',
    "claim_moderate": '{"id":1,"action":"approve"}',
    "ticket_reply": '{"id":1,"body":"سلام، بررسی شد."}',
    "customer_moderate": '{"phone":"09120000000","action":"block"}',
    "order_status": '{"id":1,"status":"confirmed"}',
    "booking_status": '{"id":1,"status":"confirmed"}',
    "area_rename": '{"old":"مرکز","new":"مرکز شهر"}',
    "trash_restore": '{"id":1}',
    "code_list": "{}",
    "code_read": '{"path":"server/app.py"}',
    "code_edit": '{"path":"server/app.py","old":"x","new":"y"}',
    "code_write": '{"path":"docs/note.md","content":"سلام"}',
    "code_revert": '{"path":"server/app.py"}',
    "code_search": '{"pattern":"owner_token"}',
    "code_status": "{}",
    "ai_setup": '{"provider":"openrouter"}',
    "service_restart": "{}",
    "brain_switch": '{"brain":"openrouter"}',
    "panel_read": '{"section":"settings"}',
    "panel_sections": "{}",
    "subscription_set": '{"biz_id":1,"plan_slug":"plus","months":3}',
    "owner_moderate": '{"owner":"09120000000","action":"block"}',
    "sec_report": "{}",
    "bulk_approve": '{"kind":"reviews"}',
    "backup_now": "{}",
    "cache_clear": "{}",
    "seo_check": "{}",
    "health_check": "{}",
    "file_list": '{"path":"server"}',
    "file_upload": "{}",
    "file_download": '{"path":"VERSION.txt"}',
    "shell_exec": '{"cmd":"uname -a"}',
    "sql_read": '{"q":"SELECT COUNT(*) AS n FROM businesses"}',
    "log_tail": '{"n":40}',
    "sys_info": "{}",
    "file_read": '{"path":"VERSION.txt"}',
    "file_write": '{"path":"docs/_note.md","content":"سلام"}',
    "file_edit": '{"path":"docs/_note.md","old":"سلام","new":"درود"}',
    "file_delete": '{"path":"docs/_note.md"}',
    "db_tables": "{}",
    "backup_list": "{}",
    "version_info": "{}",
}


def all_tools_html(tool_fa, tools):
    """راهنمای کامل همهٔ ابزارها — یک خط + مثال."""
    rows = []
    for t in tools:
        lab = tool_fa.get(t, t) if isinstance(tool_fa, dict) else t
        ex = _TOOL_EX.get(t, "{}")
        rows.append(
            '<tr><td><code dir="ltr">%s</code></td><td>%s</td>'
            '<td><pre class="text-xs" dir="ltr" style="white-space:pre-wrap;margin:0">%s</pre></td></tr>'
            % (esc(t), esc(lab), esc(ex)))
    return (
        '<div class="card glass card-pad mb-lg" id="all-tools-guide">'
        '<h3 class="card-title mb-sm">همهٔ ابزارها — %s مورد</h3>'
        '<p class="text-xs text-muted mb-sm">هر ابزار یک مثال دارد. کارهای روزمره را از تب‌های فرم بزن؛ این فهرست برای موارد خاص است.</p>'
        '<div class="table-wrap"><table class="table"><thead><tr>'
        '<th>ابزار</th><th>برچسب</th><th>مثال</th></tr></thead><tbody>%s</tbody></table></div></div>'
        % (fa(len(tools)), "".join(rows)))


_SAMPLE_BIZ = (
    {"name": "نانوایی نمونه دست‌گیر", "cat_slug": "breadshop", "city": "نجف‌آباد",
     "phone": "03142401001", "descr": "نان تازه هر روز از صبح — نمونهٔ میز کار."},
    {"name": "کافه نمونه دست‌گیر", "cat_slug": "cafe", "city": "نجف‌آباد",
     "phone": "03142401002", "descr": "قهوه و صبحانه محلی — نمونهٔ میز کار."},
    {"name": "داروخانه نمونه دست‌گیر", "cat_slug": "pharmacy", "city": "نجف‌آباد",
     "phone": "03142401003", "descr": "دارو و مشاوره — نمونهٔ میز کار."},
    {"name": "تعمیرگاه نمونه دست‌گیر", "cat_slug": "auto", "city": "نجف‌آباد",
     "phone": "03142401004", "descr": "سرویس خودرو — نمونهٔ میز کار."},
    {"name": "گل‌فروشی نمونه دست‌گیر", "cat_slug": "flowershop", "city": "نجف‌آباد",
     "phone": "03142401005", "descr": "گل تازه و دسته‌گل — نمونهٔ میز کار."},
)


def _play_save(obj):
    try:
        _Path(_PLAY_LAST).write_text(
            _js.dumps(obj, ensure_ascii=False)[:20000], encoding="utf-8")
    except Exception:
        pass
    try:
        lines = []
        for st in (obj.get("steps") or []):
            mark = "…"
            if st.get("skip"):
                mark = "↷"
            elif st.get("ok") is True:
                mark = "✓"
            elif st.get("ok") is False:
                mark = "✗"
            lines.append("%s %s" % (mark, st.get("label") or st.get("tool") or ""))
            if st.get("msg"):
                lines.append("    " + str(st["msg"]).replace("\n", " ")[:200])
        _Path("/tmp/dastgir-agent-play-last.txt").write_text(
            "\n".join(lines)[:12000], encoding="utf-8")
    except Exception:
        pass


def _play_load():
    try:
        p = _Path(_PLAY_LAST)
        if p.exists():
            return _js.loads(p.read_text(encoding="utf-8")[:20000] or "{}")
    except Exception:
        pass
    return {}


def _play_label(tool, args):
    try:
        import adminbot_content as CT
        t = CT.tool_report(tool, args or {})
        if t:
            return str(t)[:140]
    except Exception:
        pass
    return tool


def _biz_named(name):
    try:
        return db._one("SELECT id FROM businesses WHERE name=?", (name,))
    except Exception:
        return None


def play_steps(recipe, data=None):
    """لیست کارها — بدون اجرا. recipe: sample5/checkup/queue/sales/compose."""
    data = data or {}
    rec = (recipe or "").strip()
    steps = []

    def add(tool, args, label=None, skip=False):
        steps.append({
            "tool": tool, "args": args or {},
            "label": label or _play_label(tool, args or {}),
            "skip": bool(skip), "ok": None, "msg": "",
        })

    if rec == "sample5":
        for b in _SAMPLE_BIZ:
            if _biz_named(b["name"]):
                add("", {}, "از قبل هست: «%s»" % b["name"], skip=True)
            else:
                add("business_save", {"id": 0, "fields": dict(b)},
                    "ساخت «%s»" % b["name"])
        add("seo_check", {}, "بررسی سئو بعد از نمونه")
        return steps
    if rec == "checkup":
        add("health_check", {}, "سلامت سایت")
        add("seo_check", {}, "بررسی سئو")
        add("sec_report", {}, "گزارش امنیت")
        add("backup_list", {}, "فهرست بکاپ")
        add("version_info", {}, "نسخه")
        return steps
    if rec == "queue":
        add("bulk_approve", {"kind": "businesses"}, "تأیید گروهی کسب‌وکارهای pending")
        add("bulk_approve", {"kind": "reviews"}, "تأیید گروهی نظرات pending")
        return steps
    if rec == "sales":
        add("coupon_save",
            {"id": 0, "code": "PLAY325", "title": "نمونه میز کار", "percent": 10},
            "کد تخفیف PLAY325")
        add("ad_save",
            {"id": 0, "title": "بنر نمونه دستور", "url": "/", "slot": "home"},
            "بنر خانه")
        return steps
    if rec == "compose":
        if str(data.get("p_sample") or "") in ("1", "on"):
            steps.extend(play_steps("sample5", {}))
        if str(data.get("p_health") or "") in ("1", "on"):
            add("health_check", {}, "سلامت")
        if str(data.get("p_seo") or "") in ("1", "on"):
            add("seo_check", {}, "سئو")
        if str(data.get("p_sec") or "") in ("1", "on"):
            add("sec_report", {}, "امنیت")
        if str(data.get("p_backup") or "") in ("1", "on"):
            add("backup_now", {}, "بکاپ حالا")
        if str(data.get("p_biz") or "") in ("1", "on"):
            add("bulk_approve", {"kind": "businesses"}, "تأیید کسب‌وکار pending")
        if str(data.get("p_rev") or "") in ("1", "on"):
            add("bulk_approve", {"kind": "reviews"}, "تأیید نظر pending")
        if str(data.get("p_coupon") or "") in ("1", "on"):
            add("coupon_save",
                {"id": 0, "code": "PLAY325", "title": "نمونه میز کار", "percent": 10},
                "کد تخفیف PLAY325")
        if str(data.get("p_ad") or "") in ("1", "on"):
            add("ad_save",
                {"id": 0, "title": "بنر نمونه دستور", "url": "/", "slot": "home"},
                "بنر خانه")
        raw = str(data.get("steps") or "").strip()
        if raw:
            import adminbot_content as CT
            for line in raw.splitlines():
                name = line.strip().split()[0] if line.strip() else ""
                if not name:
                    continue
                if name not in CT.TOOLS:
                    add("", {}, "ناشناخته: %s" % name[:40], skip=True)
                    continue
                if name in _PLAY_BLOCK:
                    add("", {}, "مسدود در دستور چندمرحله‌ای: %s" % name, skip=True)
                    continue
                add(name, {}, _play_label(name, {}))
        return steps[:12]
    return steps


def handle_play(kind, data):
    """تب دستور — پیش‌نمایش لیست کارها، اجرا فقط با جملهٔ دقیق «اجرای دستور»."""
    import adminbot_content as CT
    kind = (kind or "").strip()
    data = data or {}
    recipe = str(data.get("recipe") or kind or "").strip()
    if recipe in ("run", "preview", "play"):
        recipe = str(data.get("recipe") or "").strip()
    if not recipe:
        return False, "دستور انتخاب نشده."
    if recipe not in ("sample5", "checkup", "queue", "sales", "compose"):
        return False, "دستور ناشناخته."
    steps = play_steps(recipe, data)
    if not steps:
        return False, "این دستور خالی است — حداقل یک کار را تیک بزن."
    confirm = str(data.get("confirm") or "").strip()
    run = confirm == _PLAY_CONFIRM
    if not run:
        _play_save({"recipe": recipe, "phase": "preview", "steps": steps})
        n = sum(1 for st in steps if not st.get("skip"))
        return False, "پیش‌نمایش %s کار (اجرا نشد). برای اجرا عیناً بنویس: اجرای دستور" % n
    ok_n = skip_n = fail_n = 0
    for st in steps:
        if st.get("skip") or not st.get("tool"):
            st["ok"] = True
            st["msg"] = st.get("label") or "رد شد"
            skip_n += 1
            continue
        tool = st["tool"]
        if tool in _PLAY_BLOCK or tool not in CT.TOOLS:
            st["ok"] = False
            st["msg"] = "این ابزار در دستور چندمرحله‌ای اجرا نمی‌شود."
            fail_n += 1
            continue
        try:
            ok, msg = CT.tool_execute(tool, st.get("args") or {})
        except Exception as e:
            ok, msg = False, str(e)[:200]
        st["ok"] = bool(ok)
        st["msg"] = str(msg)[:400]
        if ok:
            ok_n += 1
        else:
            fail_n += 1
    _play_save({"recipe": recipe, "phase": "done", "steps": steps,
                "ok_n": ok_n, "fail_n": fail_n, "skip_n": skip_n})
    short = "انجام شد: %s موفق · %s رد · %s خطا" % (ok_n, skip_n, fail_n)
    return fail_n == 0, short


def _play_last_html():
    last = _play_load()
    steps = last.get("steps") or []
    if not steps:
        return ('<p class="text-sm text-muted mb-lg">'
                "هنوز پیش‌نمایشی نیست — یک دستور را بزن.</p>")
    phase = "انجام‌شده" if last.get("phase") == "done" else "پیش‌نمایش"
    rows = []
    for st in steps:
        if st.get("skip"):
            mark = "↷"
        elif st.get("ok") is True:
            mark = "✓"
        elif st.get("ok") is False:
            mark = "✗"
        else:
            mark = "…"
        msg = str(st.get("msg") or "")[:180]
        rows.append(
            '<tr><td>%s</td><td>%s</td><td class="text-xs">%s</td></tr>' % (
                esc(mark), esc(st.get("label") or st.get("tool") or ""),
                esc(msg)))
    return (
        '<div class="card glass card-pad mb-lg" id="play-last">'
        '<h3 class="card-title mb-sm">آخرین دستور — %s · %s</h3>'
        '<div class="table-wrap"><table class="table"><thead><tr>'
        "<th></th><th>کار</th><th>نتیجه</th></tr></thead>"
        "<tbody>%s</tbody></table></div></div>"
        % (esc(phase), esc(str(last.get("recipe") or "")), "".join(rows)))


def _talk_stats():
    return {
        "reviews": _n("SELECT COUNT(*) AS n FROM reviews WHERE status='pending'"),
        "tickets": _n("SELECT COUNT(*) AS n FROM tickets WHERE status='open'"),
        "reports": _n("SELECT COUNT(*) AS n FROM reports WHERE status='open'"),
        "claims": _n("SELECT COUNT(*) AS n FROM claims WHERE status='pending'"),
        "orders": _n("SELECT COUNT(*) AS n FROM orders WHERE status='new'"),
        "bookings": _n("SELECT COUNT(*) AS n FROM bookings WHERE status='new'"),
    }


def _brain_status_html():
    """مغز ربات بله جدا از چت این صفحه — کلید چاپ نمی‌شود."""
    fa_name = "—"
    model = "—"
    site_model = "—"
    try:
        import assistant as AS
        brain = AS.active_brain()
        fa_name = AS.BRAIN_FA.get(brain, brain)
        cfg = AS.config() or {}
        model = str(cfg.get("model") or "—")[:80]
        sc = AS.site_config() if hasattr(AS, "site_config") else {}
        site_model = str((sc or {}).get("model") or "—")[:80]
    except Exception:
        pass
    return (
        '<div class="card glass card-pad mb-lg" id="brain-status">'
        '<h3 class="card-title mb-sm">مغز ربات بله — جدا از چت این صفحه</h3>'
        '<p class="text-xs text-muted mb-sm">چیپ‌های بالا فقط چت همین میز را عوض می‌کنند. '
        "مغز سراسری ربات با /مغز عوض می‌شود. سوئیچ خودکار نیست.</p>"
        '<p class="text-sm mb-sm">ربات مدیر: <b>%s</b> · مدل: '
        '<code dir="ltr">%s</code></p>'
        '<p class="text-sm">هوش سایت (بازدیدکننده): <code dir="ltr">%s</code></p>'
        "</div>" % (esc(fa_name), esc(model), esc(site_model))
    )


def _money_stats():
    return {
        "coupons": _n("SELECT COUNT(*) AS n FROM coupons WHERE COALESCE(active,1)=1"),
        "ads": _n("SELECT COUNT(*) AS n FROM ads WHERE COALESCE(active,1)=1"),
        "deals": _n("SELECT COUNT(*) AS n FROM flashdeals WHERE COALESCE(active,1)=1"),
        "subs": _n("SELECT COUNT(*) AS n FROM subscriptions WHERE status='active'"),
        "badges": _n("SELECT COUNT(*) AS n FROM badges WHERE COALESCE(active,1)=1"),
    }


def _plan_options():
    try:
        rows = db.plans(only_active=True) or []
    except Exception:
        rows = []
    out = ['<option value="">— پلن —</option>']
    for r in rows:
        out.append('<option value="%s">%s</option>' % (
            esc(r.get("slug") or ""), esc(r.get("name") or r.get("slug") or "")))
    return "".join(out)


def _qall(sql, params=()):
    try:
        return db._all(sql, params) or []
    except Exception:
        return []


def render_workbench(s, token, q=None, customer=None, owner=None,
                     agent_ok=False, in_panel=False):
    """HTML کامل میز کار. in_panel=True → داخل پوست پنل."""
    import views_agent_full as V
    q = q or {}
    prefix = "/panel/agent" if in_panel else "/agent"
    pend_data, batches, staged, applied, last_action, has_rollback, health_msg, tools = V._live_data()
    st = _today_stats()
    ts = _talk_stats()
    ms = _money_stats()
    cats = _cat_options()
    plans = _plan_options()
    bizs = _biz_rows()
    pending = _pending_rows()
    reviews = _qall(
        "SELECT r.id, r.author, r.rating, r.body, r.status, b.name AS bizname "
        "FROM reviews r JOIN businesses b ON b.id=r.biz_id "
        "WHERE r.status='pending' ORDER BY r.id DESC LIMIT 15")
    tickets = _qall(
        "SELECT id, name, subject, status, phone FROM tickets "
        "WHERE status='open' ORDER BY id DESC LIMIT 15")
    reports = _qall(
        "SELECT id, kind, reason, status, target_id FROM reports "
        "WHERE status='open' ORDER BY id DESC LIMIT 15")
    claims = _qall(
        "SELECT c.id, c.status, b.name AS bizname FROM claims c "
        "JOIN businesses b ON b.id=c.biz_id "
        "WHERE c.status='pending' ORDER BY c.id DESC LIMIT 15")
    orders = _qall(
        "SELECT o.id, o.name, o.total, o.status, b.name AS bizname "
        "FROM orders o JOIN businesses b ON b.id=o.biz_id "
        "WHERE o.status='new' ORDER BY o.id DESC LIMIT 15")
    bookings = _qall(
        "SELECT k.id, k.name, k.date, k.time, k.status, b.name AS bizname "
        "FROM bookings k JOIN businesses b ON b.id=k.biz_id "
        "WHERE k.status='new' ORDER BY k.id DESC LIMIT 15")
    coupons = _qall(
        "SELECT id, code, title, percent, active FROM coupons "
        "ORDER BY id DESC LIMIT 8")
    ads = _qall(
        "SELECT id, title, slot, active FROM ads ORDER BY id DESC LIMIT 8")
    raw_tab = q.get("tab")
    if isinstance(raw_tab, list):
        tab = str(raw_tab[0] if raw_tab else "").strip()
    else:
        tab = str(raw_tab or "").strip()
    if tab not in ("today", "content", "talk", "money", "sys", "play", "intel", "tools"):
        tab = "today"

    tool_opts = "".join(
        '<option value="%s">%s — %s</option>' % (
            esc(t), esc(V.TOOL_FA.get(t, t)), esc(t)) for t in tools)

    cust_label = ""
    if customer:
        cust_label = customer.get("email") or customer.get("phone") or "مشتری"
    elif owner:
        cust_label = owner.get("phone") or "مالک"
    elif in_panel:
        cust_label = "مدیر"

    pend_html = ""
    if pend_data and pend_data.get("action") == "agent_confirm":
        try:
            tgt = _js.loads(pend_data.get("target") or "{}")
            pend_html = (
                '<div class="alert alert-warn mb-md"><b>در انتظار تأیید:</b>'
                '<pre style="white-space:pre-wrap;max-height:180px;overflow:auto" dir="ltr">'
                + esc(_js.dumps(tgt, ensure_ascii=False, indent=2)[:2000])
                + '</pre><div class="cluster mt-sm">'
                '<form method="post" action="' + prefix + '/confirm" style="display:inline">'
                '<button class="btn btn-primary btn-sm" type="submit">تأیید و اجرا</button></form>'
                '<form method="post" action="' + prefix + '/cancel" style="display:inline">'
                '<button class="btn btn-glass btn-sm" type="submit">لغو</button></form>'
                '</div></div>')
        except Exception:
            pend_html = ""

    if pending:
        rows = []
        for b in pending:
            rows.append(
                '<tr><td class="nums">#%s</td><td>%s</td><td><code>%s</code></td><td>'
                '<form method="post" action="%s/content/moderate" class="cluster" style="gap:6px">'
                '<input type="hidden" name="tab" value="today">'
                '<input type="hidden" name="id" value="%s">'
                '<button class="btn btn-primary btn-sm" name="action" value="approve" type="submit">تأیید</button>'
                '<button class="btn btn-ghost btn-sm" name="action" value="reject" type="submit">رد</button>'
                '</form></td></tr>' % (
                    b["id"], esc(b.get("name") or ""), esc(b.get("cat_slug") or ""),
                    prefix, b["id"]))
        pending_table = (
            '<div class="table-wrap"><table class="table"><thead><tr>'
            '<th>#</th><th>نام</th><th>دسته</th><th></th></tr></thead><tbody>'
            + "".join(rows) + "</tbody></table></div>")
    else:
        pending_table = '<p class="text-sm text-muted">صف تأیید خالی است.</p>'

    biz_table_rows = []
    biz_opts = ['<option value="">— انتخاب —</option>']
    for b in bizs:
        biz_opts.append('<option value="%s">#%s — %s</option>' % (
            b["id"], b["id"], esc(b.get("name") or "")))
        biz_table_rows.append(
            '<tr><td class="nums">#%s</td><td>%s</td><td><code>%s</code></td>'
            '<td>%s</td><td class="nums" dir="ltr">%s</td></tr>' % (
                b["id"], esc(b.get("name") or ""), esc(b.get("cat_slug") or ""),
                esc(b.get("status") or ""), esc(b.get("phone") or "")))
    biz_table = (
        '<div class="table-wrap"><table class="table"><thead><tr>'
        '<th>#</th><th>نام</th><th>دسته</th><th>وضعیت</th><th>تلفن</th></tr></thead><tbody>'
        + ("".join(biz_table_rows) or
           '<tr><td colspan="5" class="text-muted">هنوز کسب‌وکاری نیست.</td></tr>')
        + "</tbody></table></div>")

    batch_rows = ""
    for b in staged[-20:]:
        try:
            args = _js.loads(b["args"]) if b["args"] else {}
            args_s = _js.dumps(args, ensure_ascii=False)[:300]
        except Exception:
            args_s = (b["args"] or "")[:300]
        batch_rows += (
            '<tr><td class="nums">#%s</td><td><code>%s</code></td>'
            '<td class="text-xs"><pre style="white-space:pre-wrap">%s</pre></td>'
            '<td><form method="post" action="%s/batch/remove" style="display:inline">'
            '<input type="hidden" name="id" value="%s">'
            '<button class="btn btn-ghost btn-sm" type="submit">✕</button></form></td></tr>'
            % (b["id"], esc(b["tool"]), esc(args_s), prefix, b["id"]))
    if not batch_rows:
        batch_rows = '<tr><td colspan="4" class="text-muted">صف خالی است.</td></tr>'

    def vis(name):
        return "" if tab == name else " hidden"

    other = "/panel/agent" if not in_panel else "/agent"
    other_lab = "نسخه پنلی" if not in_panel else "صفحهٔ /agent"
    guides = V._v321_guides_html()
    model_card = V._v321_model_card()
    files_card = V._files_card()
    v321js = V._v321_js()
    health_esc = esc((health_msg or "")[:1800])
    biz_opts_html = "".join(biz_opts)

    def _rev_table():
        if not reviews:
            return '<p class="text-sm text-muted">صف نظر خالی است.</p>'
        rows = []
        for r in reviews:
            rows.append(
                '<tr><td class="nums">#%s</td><td>%s</td><td>%s</td>'
                '<td class="nums">%s</td><td>%s</td><td>'
                '<form method="post" action="%s/talk" class="cluster" style="gap:6px">'
                '<input type="hidden" name="tab" value="talk">'
                '<input type="hidden" name="kind" value="review">'
                '<input type="hidden" name="id" value="%s">'
                '<button class="btn btn-primary btn-sm" name="action" value="approve" type="submit">تأیید</button>'
                '<button class="btn btn-ghost btn-sm" name="action" value="reject" type="submit">رد</button>'
                '</form></td></tr>' % (
                    r["id"], esc(r.get("bizname") or ""), esc(r.get("author") or ""),
                    r.get("rating") or "", esc((r.get("body") or "")[:80]),
                    prefix, r["id"]))
        return ('<div class="table-wrap"><table class="table"><thead><tr>'
                '<th>#</th><th>کسب‌وکار</th><th>نویسنده</th><th>امتیاز</th><th>متن</th><th></th>'
                '</tr></thead><tbody>%s</tbody></table></div>' % "".join(rows))

    def _ticket_table():
        if not tickets:
            return '<p class="text-sm text-muted">تیکت باز نیست.</p>'
        rows = []
        for r in tickets:
            rows.append(
                '<tr><td class="nums">#%s</td><td>%s</td><td>%s</td><td>'
                '<form method="post" action="%s/talk">'
                '<input type="hidden" name="tab" value="talk">'
                '<input type="hidden" name="kind" value="ticket">'
                '<input type="hidden" name="id" value="%s">'
                '<div class="dir-row" style="gap:6px">'
                '<input class="input" name="body" required maxlength="2000" placeholder="پاسخ کوتاه">'
                '<button class="btn btn-primary btn-sm" type="submit">ارسال</button>'
                '</div></form></td></tr>' % (
                    r["id"], esc(r.get("name") or ""), esc(r.get("subject") or ""),
                    prefix, r["id"]))
        return ('<div class="table-wrap"><table class="table"><thead><tr>'
                '<th>#</th><th>نام</th><th>موضوع</th><th>پاسخ</th>'
                '</tr></thead><tbody>%s</tbody></table></div>' % "".join(rows))

    def _report_table():
        if not reports:
            return '<p class="text-sm text-muted">گزارش باز نیست.</p>'
        rows = []
        for r in reports:
            rows.append(
                '<tr><td class="nums">#%s</td><td>%s</td><td>%s</td><td>'
                '<form method="post" action="%s/talk" class="cluster" style="gap:6px">'
                '<input type="hidden" name="tab" value="talk">'
                '<input type="hidden" name="kind" value="report">'
                '<input type="hidden" name="id" value="%s">'
                '<button class="btn btn-primary btn-sm" name="action" value="resolve" type="submit">حل شد</button>'
                '<button class="btn btn-ghost btn-sm" name="action" value="dismiss" type="submit">رد</button>'
                '</form></td></tr>' % (
                    r["id"], esc(r.get("kind") or ""), esc(r.get("reason") or ""),
                    prefix, r["id"]))
        return ('<div class="table-wrap"><table class="table"><thead><tr>'
                '<th>#</th><th>نوع</th><th>دلیل</th><th></th>'
                '</tr></thead><tbody>%s</tbody></table></div>' % "".join(rows))

    def _claim_table():
        if not claims:
            return '<p class="text-sm text-muted">ادعای مالکیت pending نیست.</p>'
        rows = []
        for r in claims:
            rows.append(
                '<tr><td class="nums">#%s</td><td>%s</td><td>'
                '<form method="post" action="%s/talk" class="cluster" style="gap:6px">'
                '<input type="hidden" name="tab" value="talk">'
                '<input type="hidden" name="kind" value="claim">'
                '<input type="hidden" name="id" value="%s">'
                '<button class="btn btn-primary btn-sm" name="action" value="approve" type="submit">واگذاری</button>'
                '<button class="btn btn-ghost btn-sm" name="action" value="reject" type="submit">رد</button>'
                '</form></td></tr>' % (
                    r["id"], esc(r.get("bizname") or ""), prefix, r["id"]))
        return ('<div class="table-wrap"><table class="table"><thead><tr>'
                '<th>#</th><th>کسب‌وکار</th><th></th>'
                '</tr></thead><tbody>%s</tbody></table></div>' % "".join(rows))

    def _order_table():
        if not orders:
            return '<p class="text-sm text-muted">سفارش جدید نیست.</p>'
        rows = []
        for r in orders:
            rows.append(
                '<tr><td class="nums">#%s</td><td>%s</td><td>%s</td><td class="nums">%s</td><td>'
                '<form method="post" action="%s/talk" class="cluster" style="gap:6px">'
                '<input type="hidden" name="tab" value="talk">'
                '<input type="hidden" name="kind" value="order">'
                '<input type="hidden" name="id" value="%s">'
                '<button class="btn btn-primary btn-sm" name="status" value="confirmed" type="submit">تأیید</button>'
                '<button class="btn btn-ghost btn-sm" name="status" value="cancelled" type="submit">لغو</button>'
                '</form></td></tr>' % (
                    r["id"], esc(r.get("bizname") or ""), esc(r.get("name") or ""),
                    r.get("total") or 0, prefix, r["id"]))
        return ('<div class="table-wrap"><table class="table"><thead><tr>'
                '<th>#</th><th>کسب‌وکار</th><th>مشتری</th><th>مبلغ</th><th></th>'
                '</tr></thead><tbody>%s</tbody></table></div>' % "".join(rows))

    def _booking_table(tab_name="talk"):
        if not bookings:
            return '<p class="text-sm text-muted">نوبت جدید نیست.</p>'
        rows = []
        for r in bookings:
            rows.append(
                '<tr><td class="nums">#%s</td><td>%s</td><td>%s</td>'
                '<td class="nums" dir="ltr">%s %s</td><td>'
                '<form method="post" action="%s/talk" class="cluster" style="gap:6px">'
                '<input type="hidden" name="tab" value="%s">'
                '<input type="hidden" name="kind" value="booking">'
                '<input type="hidden" name="id" value="%s">'
                '<button class="btn btn-primary btn-sm" name="status" value="confirmed" type="submit">تأیید</button>'
                '<button class="btn btn-ghost btn-sm" name="status" value="cancelled" type="submit">لغو</button>'
                '</form></td></tr>' % (
                    r["id"], esc(r.get("bizname") or ""), esc(r.get("name") or ""),
                    esc(r.get("date") or ""), esc(r.get("time") or ""),
                    prefix, tab_name, r["id"]))
        return ('<div class="table-wrap"><table class="table"><thead><tr>'
                '<th>#</th><th>کسب‌وکار</th><th>نام</th><th>زمان</th><th></th>'
                '</tr></thead><tbody>%s</tbody></table></div>' % "".join(rows))

    review_table = _rev_table()
    ticket_table = _ticket_table()
    report_table = _report_table()
    claim_table = _claim_table()
    order_table = _order_table()
    booking_table = _booking_table("talk")
    booking_table_today = _booking_table("today")
    coupon_rows = "".join(
        '<tr><td class="nums">#%s</td><td dir="ltr">%s</td><td>%s</td>'
        '<td class="nums">%s٪</td></tr>' % (
            c["id"], esc(c.get("code") or ""), esc(c.get("title") or ""),
            c.get("percent") or 0) for c in coupons) or (
        '<tr><td colspan="4" class="text-muted">کد تخفیفی نیست.</td></tr>')
    ad_rows = "".join(
        '<tr><td class="nums">#%s</td><td>%s</td><td>%s</td></tr>' % (
            a["id"], esc(a.get("title") or ""), esc(a.get("slot") or ""))
        for a in ads) or '<tr><td colspan="3" class="text-muted">بنری نیست.</td></tr>'
    ss = _sys_stats()
    backup_html = _backup_rows_html()
    last_sys = _sys_load()
    if last_sys.get("msg"):
        last_sys_html = (
            '<div class="card glass card-pad mb-lg" id="sys-last">'
            '<h3 class="card-title mb-sm">آخرین خروجی سیستم — %s</h3>'
            '<pre class="text-xs" style="max-height:280px;overflow:auto;white-space:pre-wrap">%s</pre></div>'
            % (esc(str(last_sys.get("kind") or "")),
               esc(str(last_sys.get("msg") or "")[:8000])))
    else:
        last_sys_html = (
            '<p class="text-sm text-muted mb-lg">هنوز خروجی سیستم نیست — یک دکمه بزن.</p>')
    all_tools = all_tools_html(V.TOOL_FA, tools)
    play_last = _play_last_html()
    brain_html = _brain_status_html()

    content = f'''
{_msg(q)}
<div class="between mb-md" style="flex-wrap:wrap;gap:12px">
  <div>
    <h1 style="margin:0">{icon("sparkles")} میز کار ایجنت — v327
      <span class="badge badge-open">{esc(cust_label or "فعال")}</span></h1>
    <p class="text-sm text-muted mt-sm">هوش از سرور است، نه بله و نه PhonePilot.
      خواندن فوری · نوشتن با فرم یا تأیید · sqlite لازم نیست.
      {fa(len(tools))} ابزار.</p>
  </div>
  <div class="cluster">
    <a class="btn btn-glass btn-sm" href="{other}">{icon("settings")}<span>{esc(other_lab)}</span></a>
    <a class="btn btn-ghost btn-sm" href="/panel">{icon("shield")}<span>پنل مدیر — زیر دست ایجنت</span></a>
  </div>
</div>

{pend_html}

<div class="tabs mb-lg" role="tablist">
  <button type="button" data-tab="today" aria-selected="{'true' if tab=='today' else 'false'}">امروز</button>
  <button type="button" data-tab="content" aria-selected="{'true' if tab=='content' else 'false'}">محتوا</button>
  <button type="button" data-tab="talk" aria-selected="{'true' if tab=='talk' else 'false'}">گفت‌وگو</button>
  <button type="button" data-tab="money" aria-selected="{'true' if tab=='money' else 'false'}">درآمد</button>
  <button type="button" data-tab="sys" aria-selected="{'true' if tab=='sys' else 'false'}">سیستم</button>
  <button type="button" data-tab="play" aria-selected="{'true' if tab=='play' else 'false'}">دستور</button>
  <button type="button" data-tab="intel" aria-selected="{'true' if tab=='intel' else 'false'}">هوش</button>
  <button type="button" data-tab="tools" aria-selected="{'true' if tab=='tools' else 'false'}">ابزار</button>
</div>

<section class="tab-panel" id="tab-today"{vis('today')} role="tabpanel">
  <p class="text-sm text-muted mb-md">عددها زنده از دیتابیس همین سرور است. سفارش و نوبت امروز اینجاست. مثال: نوبت جدید را تأیید کن.</p>
  <div class="grid grid-4 mb-lg">
    {stat_card("store", st["biz"], "کسب‌وکار")}
    {stat_card("shield", st["pending"], "در انتظار تأیید")}
    {stat_card("cart", st["orders"], "سفارش جدید")}
    {stat_card("clock", st["bookings"], "نوبت جدید")}
  </div>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <div class="between mb-sm">
        <h3 class="card-title">صف تأیید کسب‌وکار</h3>
        <form method="post" action="{prefix}/content/bulk">
          <input type="hidden" name="tab" value="today">
          <button class="btn btn-glass btn-sm" type="submit">تأیید همهٔ pending</button>
        </form>
      </div>
      <p class="text-xs text-muted mb-sm">ابزار: biz_moderate — بدون SQL.</p>
      {pending_table}
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">سلامت</h3>
      <p class="text-xs text-muted mb-sm">تیکت باز: {fa(st["tickets"])} · rollback: {fa(1 if has_rollback else 0)}</p>
      <pre class="text-xs" style="max-height:220px;overflow:auto;white-space:pre-wrap">{health_esc}</pre>
      <div class="cluster mt-md">
        <form method="post" action="{prefix}/exec"><input type="hidden" name="tool" value="backup_now"><input type="hidden" name="args" value="{{}}"><button class="btn btn-glass btn-sm" type="submit">بکاپ فوری</button></form>
        <form method="post" action="{prefix}/exec"><input type="hidden" name="tool" value="health_check"><input type="hidden" name="args" value="{{}}"><button class="btn btn-glass btn-sm" type="submit">تازه کردن سلامت</button></form>
      </div>
    </div>
  </div>
  <div class="card glass card-pad mb-lg">
    <h3 class="card-title mb-sm">نوبت جدید</h3>
    <p class="text-xs text-muted mb-sm">ابزار: booking_status — تأیید یا لغو. مثال: نوبت امروز را از همین‌جا تأیید کن.</p>
    {booking_table_today}
  </div>
  <div class="card glass card-pad mb-lg">
    <h3 class="card-title mb-sm">۲۰ کسب‌وکار اخیر</h3>
    {biz_table}
  </div>
</section>

<section class="tab-panel" id="tab-content"{vis('content')} role="tabpanel">
  <p class="text-sm text-muted mb-md">فرم است، JSON لازم نیست. کسب‌وکار، کالا، دسته، صفحه، مقاله، رنگ. پشت صحنه همان ابزارهاست. حذف همه فقط با جملهٔ دقیق تأیید.</p>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">کسب‌وکار تازه</h3>
      <p class="text-xs text-muted mb-sm">مثال: نام «نانوایی نمونه»، دسته cafe، تلفن ۱۱ رقمی.</p>
      <form method="post" action="{prefix}/content/biz">
        <input type="hidden" name="tab" value="content">
        <div class="field"><label class="field-label">نام</label>
          <input class="input" name="name" required maxlength="80" placeholder="نانوایی نمونه"></div>
        <div class="field"><label class="field-label">دسته</label>
          <select class="select" name="cat_slug" required>{cats}</select></div>
        <div class="field"><label class="field-label">تلفن</label>
          <input class="input" name="phone" dir="ltr" maxlength="20" placeholder="03112345678"></div>
        <div class="field"><label class="field-label">شهر</label>
          <input class="input" name="city" maxlength="40" placeholder="نجف‌آباد"></div>
        <button class="btn btn-primary btn-block" type="submit">ساخت کسب‌وکار</button>
      </form>
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">حذف / تنظیم</h3>
      <form method="post" action="{prefix}/content/biz-del" class="mb-md">
        <input type="hidden" name="tab" value="content">
        <div class="field"><label class="field-label">حذف یکی (سطل بازیافت)</label>
          <select class="select" name="id" required>{biz_opts_html}</select></div>
        <button class="btn btn-glass btn-block" type="submit">حذف این کسب‌وکار</button>
      </form>
      <form method="post" action="{prefix}/content/wipe" data-confirm="همه حذف شوند؟">
        <input type="hidden" name="tab" value="content">
        <div class="field"><label class="field-label">حذف همه — این جمله را عیناً بنویس</label>
          <input class="input" name="confirm" placeholder="حذف همه کسب‌وکارها" required></div>
        <button class="btn btn-ghost btn-block" type="submit">حذف همه</button>
      </form>
      <hr class="divider">
      <form method="post" action="{prefix}/content/setting">
        <input type="hidden" name="tab" value="content">
        <div class="field"><label class="field-label">نام سایت</label>
          <input class="input" name="value" maxlength="80" placeholder="دست گیر" required></div>
        <button class="btn btn-glass btn-block" type="submit">ذخیرهٔ نام سایت</button>
      </form>
    </div>
  </div>

  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">ویرایش فیلد کسب‌وکار</h3>
      <p class="text-xs text-muted mb-sm">مثال: تلفن یا توضیح. ابزار: business_save با id.</p>
      <form method="post" action="{prefix}/content/biz-edit">
        <input type="hidden" name="tab" value="content">
        <div class="field"><label class="field-label">کسب‌وکار</label>
          <select class="select" name="id" required>{biz_opts_html}</select></div>
        <div class="field"><label class="field-label">فیلد</label>
          <select class="select" name="field" required>
            <option value="name">نام</option>
            <option value="phone">تلفن</option>
            <option value="city">شهر</option>
            <option value="descr">توضیح</option>
            <option value="address">نشانی</option>
            <option value="cat_slug">دسته</option>
          </select></div>
        <div class="field"><label class="field-label">مقدار تازه</label>
          <input class="input" name="value" required maxlength="400" placeholder="مثلاً ۰۳۱۴۲۴۱۲۳۴۵"></div>
        <button class="btn btn-glass btn-block" type="submit">ذخیرهٔ فیلد</button>
      </form>
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">کالای تازه</h3>
      <p class="text-xs text-muted mb-sm">مثال: نان سنگک ۴۰۰۰۰. ابزار: item_save.</p>
      <form method="post" action="{prefix}/content/item">
        <input type="hidden" name="tab" value="content">
        <div class="field"><label class="field-label">کسب‌وکار</label>
          <select class="select" name="biz_id" required>{biz_opts_html}</select></div>
        <div class="field"><label class="field-label">عنوان</label>
          <input class="input" name="title" required maxlength="120" placeholder="نان سنگک"></div>
        <div class="field"><label class="field-label">قیمت (تومان)</label>
          <input class="input" name="price" dir="ltr" maxlength="12" placeholder="40000"></div>
        <div class="field"><label class="field-label">توضیح</label>
          <input class="input" name="descr" maxlength="200" placeholder="تازه هر روز"></div>
        <button class="btn btn-primary btn-block" type="submit">ذخیرهٔ کالا</button>
      </form>
    </div>
  </div>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">دسته تازه</h3>
      <p class="text-xs text-muted mb-sm">مثال: «قنادی محله». ابزار: category_save.</p>
      <form method="post" action="{prefix}/content/cat">
        <input type="hidden" name="tab" value="content">
        <div class="field"><label class="field-label">نام</label>
          <input class="input" name="name" required maxlength="60" placeholder="قنادی محله"></div>
        <button class="btn btn-glass btn-block" type="submit">ذخیرهٔ دسته</button>
      </form>
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">صفحه about / rules</h3>
      <p class="text-xs text-muted mb-sm">متن کامل بازنویسی می‌شود. ابزار: page.</p>
      <form method="post" action="{prefix}/content/page">
        <input type="hidden" name="tab" value="content">
        <div class="field"><label class="field-label">صفحه</label>
          <select class="select" name="slug" required>
            <option value="about">درباره</option>
            <option value="rules">قوانین</option>
          </select></div>
        <div class="field"><label class="field-label">عنوان</label>
          <input class="input" name="title" required maxlength="100" placeholder="درباره ما"></div>
        <div class="field"><label class="field-label">متن</label>
          <textarea class="textarea" name="body" required maxlength="4000" placeholder="متن صفحه"></textarea></div>
        <button class="btn btn-glass btn-block" type="submit">ذخیرهٔ صفحه</button>
      </form>
    </div>
  </div>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">مقاله</h3>
      <p class="text-xs text-muted mb-sm">مثال: «جشنواره پاییز». ابزار: post_save.</p>
      <form method="post" action="{prefix}/content/post">
        <input type="hidden" name="tab" value="content">
        <div class="field"><label class="field-label">عنوان</label>
          <input class="input" name="title" required maxlength="120" placeholder="جشنواره پاییز"></div>
        <div class="field"><label class="field-label">متن</label>
          <textarea class="textarea" name="body" maxlength="8000" placeholder="متن مقاله"></textarea></div>
        <button class="btn btn-glass btn-block" type="submit">انتشار مقاله</button>
      </form>
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">رنگ سایت</h3>
      <p class="text-xs text-muted mb-sm">مثال: #0b6059. ابزار: setting.</p>
      <form method="post" action="{prefix}/content/color">
        <input type="hidden" name="tab" value="content">
        <div class="field"><label class="field-label">کدام رنگ</label>
          <select class="select" name="key">
            <option value="color_primary">اصلی</option>
            <option value="color_accent">تأکید</option>
            <option value="color_background">پس‌زمینه</option>
            <option value="color_foreground">متن</option>
          </select></div>
        <div class="field"><label class="field-label">مقدار</label>
          <input class="input" name="value" required dir="ltr" maxlength="7" placeholder="#0b6059"></div>
        <button class="btn btn-glass btn-block" type="submit">ذخیرهٔ رنگ</button>
      </form>
    </div>
  </div>
  {guides}

</section>

<section class="tab-panel" id="tab-talk"{vis('talk')} role="tabpanel">
  <p class="text-sm text-muted mb-md">نظر، تیکت، گزارش، ادعا، سفارش — هر کارت عدد زنده + دو دکمه. JSON لازم نیست. مثال: نظر pending را از همین‌جا تأیید کن.</p>
  <div class="grid grid-4 mb-lg">
    {stat_card("message", ts["reviews"], "نظر pending")}
    {stat_card("mail", ts["tickets"], "تیکت باز")}
    {stat_card("alert", ts["reports"], "گزارش باز")}
    {stat_card("clock", ts["bookings"], "نوبت جدید")}
  </div>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <div class="between mb-sm">
        <h3 class="card-title">نظرات در انتظار</h3>
        <form method="post" action="{prefix}/talk">
          <input type="hidden" name="tab" value="talk">
          <input type="hidden" name="kind" value="review-bulk">
          <button class="btn btn-glass btn-sm" type="submit">تأیید همه</button>
        </form>
      </div>
      <p class="text-xs text-muted mb-sm">ابزار: review_moderate / bulk_approve.</p>
      {review_table}
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">تیکت باز</h3>
      <p class="text-xs text-muted mb-sm">مثال: «سلام، بررسی شد.» — ابزار ticket_reply.</p>
      {ticket_table}
    </div>
  </div>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <div class="between mb-sm">
        <h3 class="card-title">گزارش تخلف</h3>
        <form method="post" action="{prefix}/talk">
          <input type="hidden" name="tab" value="talk">
          <input type="hidden" name="kind" value="report-bulk">
          <button class="btn btn-glass btn-sm" type="submit">حل همه</button>
        </form>
      </div>
      {report_table}
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">ادعای مالکیت</h3>
      <p class="text-xs text-muted mb-sm">ابزار: claim_moderate. ادعای pending: {fa(ts["claims"])}</p>
      {claim_table}
    </div>
  </div>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">سفارش جدید</h3>
      <p class="text-xs text-muted mb-sm">ابزار: order_status — تأیید یا لغو.</p>
      {order_table}
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">نوبت جدید</h3>
      <p class="text-xs text-muted mb-sm">ابزار: booking_status — تأیید یا لغو.</p>
      {booking_table}
    </div>
  </div>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">پیام همگانی</h3>
      <p class="text-xs text-muted mb-sm">به همهٔ مشتری‌ها اعلان می‌رود. جملهٔ تأیید را عیناً بنویس.</p>
      <form method="post" action="{prefix}/talk">
        <input type="hidden" name="tab" value="talk">
        <input type="hidden" name="kind" value="broadcast">
        <div class="field"><label class="field-label">متن</label>
          <textarea class="textarea" name="text" required maxlength="500" placeholder="مثلاً: فردا تعطیل هستیم"></textarea></div>
        <div class="field"><label class="field-label">تأیید — عیناً بنویس: ارسال همگانی</label>
          <input class="input" name="confirm" required placeholder="ارسال همگانی"></div>
        <button class="btn btn-glass btn-block" type="submit">ارسال اعلان</button>
      </form>
    </div>
  </div>
</section>

<section class="tab-panel" id="tab-money"{vis('money')} role="tabpanel">
  <p class="text-sm text-muted mb-md">اشتراک، بنر، کد تخفیف، پیشنهاد روز، نشان — فرم است. مثال: پلن plus برای سه ماه روی یک کسب‌وکار.</p>
  <div class="grid grid-4 mb-lg">
    {stat_card("wallet", ms["subs"], "اشتراک فعال")}
    {stat_card("tag", ms["coupons"], "کد تخفیف")}
    {stat_card("image", ms["ads"], "بنر فعال")}
    {stat_card("zap", ms["deals"], "پیشنهاد روز")}
  </div>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">اشتراک کسب‌وکار</h3>
      <p class="text-xs text-muted mb-sm">ابزار: subscription_set.</p>
      <form method="post" action="{prefix}/money">
        <input type="hidden" name="tab" value="money">
        <input type="hidden" name="kind" value="sub">
        <div class="field"><label class="field-label">کسب‌وکار</label>
          <select class="select" name="biz_id" required>{biz_opts_html}</select></div>
        <div class="field"><label class="field-label">پلن</label>
          <select class="select" name="plan_slug" required>{plans}</select></div>
        <div class="field"><label class="field-label">ماه (خالی = پیش‌فرض پلن)</label>
          <input class="input" name="months" dir="ltr" maxlength="3" placeholder="12"></div>
        <button class="btn btn-primary btn-block" type="submit">فعال‌سازی اشتراک</button>
      </form>
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">کد تخفیف</h3>
      <p class="text-xs text-muted mb-sm">مثال: کد SPRING با ۲۰٪. ابزار: coupon_save.</p>
      <form method="post" action="{prefix}/money">
        <input type="hidden" name="tab" value="money">
        <input type="hidden" name="kind" value="coupon">
        <div class="field"><label class="field-label">کد</label>
          <input class="input" name="code" required maxlength="40" dir="ltr" placeholder="SPRING"></div>
        <div class="field"><label class="field-label">عنوان</label>
          <input class="input" name="title" required maxlength="120" placeholder="تخفیف بهاری"></div>
        <div class="field"><label class="field-label">درصد</label>
          <input class="input" name="percent" required dir="ltr" maxlength="2" placeholder="20"></div>
        <div class="field"><label class="field-label">کسب‌وکار (اختیاری)</label>
          <select class="select" name="biz_id">{biz_opts_html}</select></div>
        <button class="btn btn-glass btn-block" type="submit">ذخیرهٔ کد</button>
      </form>
    </div>
  </div>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">بنر</h3>
      <p class="text-xs text-muted mb-sm">ابزار: ad_save — بدون عکس هم ذخیره می‌شود.</p>
      <form method="post" action="{prefix}/money">
        <input type="hidden" name="tab" value="money">
        <input type="hidden" name="kind" value="ad">
        <div class="field"><label class="field-label">عنوان</label>
          <input class="input" name="title" required maxlength="120" placeholder="بنر صفحهٔ نخست"></div>
        <div class="field"><label class="field-label">نشانی</label>
          <input class="input" name="url" dir="ltr" maxlength="300" placeholder="/"></div>
        <div class="field"><label class="field-label">جایگاه</label>
          <select class="select" name="slot">
            <option value="home">خانه</option>
            <option value="directory">فهرست</option>
            <option value="business">کسب‌وکار</option>
            <option value="sidebar">سایدبار</option>
          </select></div>
        <button class="btn btn-glass btn-block" type="submit">ذخیرهٔ بنر</button>
      </form>
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">پیشنهاد روز</h3>
      <p class="text-xs text-muted mb-sm">پایان مثل 2026-12-31 23:59. ابزار: flashdeal_save.</p>
      <form method="post" action="{prefix}/money">
        <input type="hidden" name="tab" value="money">
        <input type="hidden" name="kind" value="deal">
        <div class="field"><label class="field-label">کسب‌وکار</label>
          <select class="select" name="biz_id" required>{biz_opts_html}</select></div>
        <div class="field"><label class="field-label">عنوان</label>
          <input class="input" name="title" required maxlength="120" placeholder="۲۰٪ عصرانه"></div>
        <div class="field"><label class="field-label">درصد</label>
          <input class="input" name="percent" required dir="ltr" maxlength="2" placeholder="20"></div>
        <div class="field"><label class="field-label">پایان</label>
          <input class="input" name="ends" required dir="ltr" maxlength="20" placeholder="2026-12-31 23:59"></div>
        <button class="btn btn-glass btn-block" type="submit">ذخیرهٔ پیشنهاد</button>
      </form>
    </div>
  </div>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">نشان</h3>
      <p class="text-xs text-muted mb-sm">ابزار: badge_save. نشان فعال: {fa(ms["badges"])}</p>
      <form method="post" action="{prefix}/money">
        <input type="hidden" name="tab" value="money">
        <input type="hidden" name="kind" value="badge">
        <div class="field"><label class="field-label">نام</label>
          <input class="input" name="name" required maxlength="60" placeholder="ویژهٔ محله"></div>
        <div class="field"><label class="field-label">رنگ</label>
          <input class="input" name="color" dir="ltr" maxlength="7" placeholder="#059669"></div>
        <button class="btn btn-glass btn-block" type="submit">ذخیرهٔ نشان</button>
      </form>
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">کدها و بنرهای اخیر</h3>
      <div class="table-wrap mb-md"><table class="table"><thead><tr><th>#</th><th>کد</th><th>عنوان</th><th>%</th></tr></thead><tbody>{coupon_rows}</tbody></table></div>
      <div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>بنر</th><th>جایگاه</th></tr></thead><tbody>{ad_rows}</tbody></table></div>
    </div>
  </div>
</section>

<section class="tab-panel" id="tab-sys"{vis('sys')} role="tabpanel">
  <p class="text-sm text-muted mb-md">بکاپ، سلامت، سئو، کش، لاگ، SQL خواندنی، امنیت، ترمینال با پیش‌نمایش. خروجی کامل زیر دکمه‌ها می‌ماند. sqlite نوشتنی نیست.</p>
  <div class="grid grid-4 mb-lg">
    {stat_card("database", ss["backups"], "فایل بکاپ")}
    {stat_card("file", ss["dbkb"], "حجم DB (KB)")}
    {stat_card("activity", len(tools), "ابزار")}
    {stat_card("shield", 1 if has_rollback else 0, "rollback")}
  </div>
  {last_sys_html}
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">بکاپ و سلامت</h3>
      <p class="text-xs text-muted mb-sm">ابزار: backup_now / backup_list / health_check / seo_check / cache_clear.</p>
      <div class="cluster mb-md" style="flex-wrap:wrap;gap:8px">
        <form method="post" action="{prefix}/sys"><input type="hidden" name="tab" value="sys"><input type="hidden" name="kind" value="backup"><button class="btn btn-primary btn-sm" type="submit">بکاپ حالا</button></form>
        <form method="post" action="{prefix}/sys"><input type="hidden" name="tab" value="sys"><input type="hidden" name="kind" value="backups"><button class="btn btn-glass btn-sm" type="submit">فهرست بکاپ</button></form>
        <form method="post" action="{prefix}/sys"><input type="hidden" name="tab" value="sys"><input type="hidden" name="kind" value="health"><button class="btn btn-glass btn-sm" type="submit">سلامت</button></form>
        <form method="post" action="{prefix}/sys"><input type="hidden" name="tab" value="sys"><input type="hidden" name="kind" value="seo"><button class="btn btn-glass btn-sm" type="submit">سئو</button></form>
        <form method="post" action="{prefix}/sys"><input type="hidden" name="tab" value="sys"><input type="hidden" name="kind" value="cache"><button class="btn btn-ghost btn-sm" type="submit">پاک‌سازی کش</button></form>
      </div>
      {backup_html}
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">امنیت و سیستم</h3>
      <p class="text-xs text-muted mb-sm">ابزار: sec_report / sys_info / version_info / db_tables / log_tail.</p>
      <div class="cluster mb-md" style="flex-wrap:wrap;gap:8px">
        <form method="post" action="{prefix}/sys"><input type="hidden" name="tab" value="sys"><input type="hidden" name="kind" value="sec"><button class="btn btn-primary btn-sm" type="submit">گزارش امنیت</button></form>
        <form method="post" action="{prefix}/sys"><input type="hidden" name="tab" value="sys"><input type="hidden" name="kind" value="info"><button class="btn btn-glass btn-sm" type="submit">اطلاعات سیستم</button></form>
        <form method="post" action="{prefix}/sys"><input type="hidden" name="tab" value="sys"><input type="hidden" name="kind" value="version"><button class="btn btn-glass btn-sm" type="submit">نسخه</button></form>
        <form method="post" action="{prefix}/sys"><input type="hidden" name="tab" value="sys"><input type="hidden" name="kind" value="tables"><button class="btn btn-glass btn-sm" type="submit">جدول‌ها</button></form>
      </div>
      <form method="post" action="{prefix}/sys" class="mb-sm">
        <input type="hidden" name="tab" value="sys">
        <input type="hidden" name="kind" value="logs">
        <div class="dir-row" style="gap:6px">
          <input class="input" name="n" dir="ltr" maxlength="3" placeholder="40" value="40">
          <button class="btn btn-glass btn-sm" type="submit">لاگ</button>
        </div>
      </form>
    </div>
  </div>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">SQL فقط خواندنی</h3>
      <p class="text-xs text-muted mb-sm">مثال: SELECT COUNT(*) AS n FROM businesses — نوشتن رد می‌شود. ابزار: sql_read.</p>
      <form method="post" action="{prefix}/sys">
        <input type="hidden" name="tab" value="sys">
        <input type="hidden" name="kind" value="sql">
        <div class="field"><label class="field-label">پرس‌وجو</label>
          <textarea class="textarea" name="q" required maxlength="500" dir="ltr" style="font-family:monospace;min-height:80px" placeholder="SELECT COUNT(*) AS n FROM businesses"></textarea></div>
        <button class="btn btn-glass btn-block" type="submit">اجرای خواندنی</button>
      </form>
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">ترمینال با پیش‌نمایش</h3>
      <p class="text-xs text-muted mb-sm">اول بزن تا پیش‌نمایش بیاید. اجرا فقط با جملهٔ دقیق «اجرای فرمان». shell_exec فوری نیست.</p>
      <form method="post" action="{prefix}/sys">
        <input type="hidden" name="tab" value="sys">
        <input type="hidden" name="kind" value="shell">
        <div class="field"><label class="field-label">فرمان</label>
          <input class="input" name="cmd" required maxlength="500" dir="ltr" placeholder="uname -a"></div>
        <div class="field"><label class="field-label">تأیید — عیناً: اجرای فرمان</label>
          <input class="input" name="confirm" placeholder="اجرای فرمان"></div>
        <button class="btn btn-ghost btn-block" type="submit">پیش‌نمایش / اجرا</button>
      </form>
    </div>
  </div>
  {all_tools}
</section>


<section class="tab-panel" id="tab-play"{vis('play')} role="tabpanel">
  <p class="text-sm text-muted mb-md">دستور چندمرحله‌ای — فرم است، JSON لازم نیست. اول پیش‌نمایش کارها می‌آید. اجرا فقط با جملهٔ دقیق «اجرای دستور». نمونه: پنج کسب‌وکار + سئو. ترمینال و wipe اینجا نیست.</p>
  {play_last}
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">پنج کسب‌وکار نمونه + سئو</h3>
      <p class="text-xs text-muted mb-sm">نانوایی، کافه، داروخانه، تعمیرگاه، گل‌فروشی در نجف‌آباد. اگر نام از قبل باشد رد می‌شود. بعد seo_check.</p>
      <form method="post" action="{prefix}/play">
        <input type="hidden" name="tab" value="play">
        <input type="hidden" name="recipe" value="sample5">
        <div class="field"><label class="field-label">تأیید — عیناً بنویس: اجرای دستور</label>
          <input class="input" name="confirm" placeholder="اجرای دستور"></div>
        <button class="btn btn-primary btn-block" type="submit">پیش‌نمایش / اجرا</button>
      </form>
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">بررسی کامل</h3>
      <p class="text-xs text-muted mb-sm">سلامت + سئو + امنیت + فهرست بکاپ + نسخه. نوشتنی نیست ولی باز هم تأیید می‌خواهد.</p>
      <form method="post" action="{prefix}/play">
        <input type="hidden" name="tab" value="play">
        <input type="hidden" name="recipe" value="checkup">
        <div class="field"><label class="field-label">تأیید — عیناً: اجرای دستور</label>
          <input class="input" name="confirm" placeholder="اجرای دستور"></div>
        <button class="btn btn-glass btn-block" type="submit">پیش‌نمایش / اجرا</button>
      </form>
    </div>
  </div>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">تأیید صف</h3>
      <p class="text-xs text-muted mb-sm">کسب‌وکار pending و نظر pending — bulk_approve.</p>
      <form method="post" action="{prefix}/play">
        <input type="hidden" name="tab" value="play">
        <input type="hidden" name="recipe" value="queue">
        <div class="field"><label class="field-label">تأیید — عیناً: اجرای دستور</label>
          <input class="input" name="confirm" placeholder="اجرای دستور"></div>
        <button class="btn btn-glass btn-block" type="submit">پیش‌نمایش / اجرا</button>
      </form>
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">فروش نمونه</h3>
      <p class="text-xs text-muted mb-sm">کد PLAY325 ده درصد + بنر خانه.</p>
      <form method="post" action="{prefix}/play">
        <input type="hidden" name="tab" value="play">
        <input type="hidden" name="recipe" value="sales">
        <div class="field"><label class="field-label">تأیید — عیناً: اجرای دستور</label>
          <input class="input" name="confirm" placeholder="اجرای دستور"></div>
        <button class="btn btn-glass btn-block" type="submit">پیش‌نمایش / اجرا</button>
      </form>
    </div>
  </div>
  <div class="card glass card-pad mb-lg">
    <h3 class="card-title mb-sm">دستور سفارشی</h3>
    <p class="text-xs text-muted mb-sm">تیک بزن. shell_exec و wipe اینجا مسدود است. حداکثر ۱۲ کار.</p>
    <form method="post" action="{prefix}/play">
      <input type="hidden" name="tab" value="play">
      <input type="hidden" name="recipe" value="compose">
      <div class="cluster mb-md" style="flex-wrap:wrap;gap:10px">
        <label class="text-sm"><input type="checkbox" name="p_sample" value="1"> پنج نمونه</label>
        <label class="text-sm"><input type="checkbox" name="p_health" value="1"> سلامت</label>
        <label class="text-sm"><input type="checkbox" name="p_seo" value="1"> سئو</label>
        <label class="text-sm"><input type="checkbox" name="p_sec" value="1"> امنیت</label>
        <label class="text-sm"><input type="checkbox" name="p_backup" value="1"> بکاپ حالا</label>
        <label class="text-sm"><input type="checkbox" name="p_biz" value="1"> تأیید کسب‌وکار</label>
        <label class="text-sm"><input type="checkbox" name="p_rev" value="1"> تأیید نظر</label>
        <label class="text-sm"><input type="checkbox" name="p_coupon" value="1"> کد تخفیف</label>
        <label class="text-sm"><input type="checkbox" name="p_ad" value="1"> بنر</label>
      </div>
      <div class="field"><label class="field-label">تأیید — عیناً: اجرای دستور</label>
        <input class="input" name="confirm" placeholder="اجرای دستور"></div>
      <button class="btn btn-primary btn-block" type="submit">پیش‌نمایش / اجرا</button>
    </form>
  </div>
</section>

<section class="tab-panel" id="tab-intel"{vis('intel')} role="tabpanel">
  {brain_html}
  <div class="cluster mb-md" id="model-switcher" style="gap:8px;flex-wrap:wrap">
    <span class="text-sm"><b>مغز این چت:</b></span>
    <button type="button" class="chip is-active" data-model="auto">خودکار</button>
    <button type="button" class="chip" data-model="openrouter">اوپن‌روتر</button>
    <button type="button" class="chip" data-model="bynara">بای‌نارا</button>
    <button type="button" class="chip" data-model="opus">اپوس</button>
    <button type="button" class="chip" data-model="sonnet">سونت</button>
    <button type="button" class="chip" data-model="offline">آفلاین</button>
    <span class="badge badge-open" id="model-current">auto</span>
  </div>
  {model_card}
  <div class="card glass card-pad mb-lg">
    <h3 class="card-title mb-sm">{icon("message")} چت با سرور</h3>
    <div id="agent-chat-log" style="height:280px;overflow:auto;border:1px solid var(--color-border);border-radius:12px;padding:10px" class="mb-md text-sm">
      <div class="text-muted">مدل: <b id="log-model">auto</b> — مستقیم از سرور</div>
    </div>
    <div class="dir-row">
      <input class="input" id="agent-chat-input" placeholder="مثلاً: یک کسب‌وکار کافه در نجف‌آباد بساز">
      <button class="btn btn-primary" type="button" id="agent-chat-send">ارسال</button>
    </div>
  </div>
</section>

<section class="tab-panel" id="tab-tools"{vis('tools')} role="tabpanel">
  <p class="text-sm text-muted mb-md">اجرای خام ابزارها. کارهای روزمره را از تب محتوا انجام بده.</p>
  <div class="grid grid-2 mb-lg" style="align-items:start">
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">اجرای فوری</h3>
      <form method="post" action="{prefix}/exec">
        <input type="hidden" name="tab" value="tools">
        <div class="field"><label class="field-label">ابزار</label>
          <select class="select" id="ab-tool" name="tool" required>{tool_opts}</select></div>
        <div class="field"><label class="field-label">JSON</label>
          <textarea class="textarea" id="ab-args" name="args" style="min-height:90px;font-family:monospace;direction:ltr">{{}}</textarea></div>
        <button class="btn btn-accent btn-block" type="submit">اجرا</button>
      </form>
    </div>
    <div class="card glass card-pad">
      <h3 class="card-title mb-sm">صف دسته‌ای — {fa(len(staged))}</h3>
      <form method="post" action="{prefix}/batch/add" class="mb-sm">
        <input type="hidden" name="tab" value="tools">
        <div class="field"><label class="field-label">ابزار</label>
          <select class="select" name="tool" required>{tool_opts}</select></div>
        <div class="field"><label class="field-label">JSON</label>
          <textarea class="textarea" name="args" style="min-height:70px;font-family:monospace;direction:ltr">{{}}</textarea></div>
        <button class="btn btn-glass btn-block" type="submit">افزودن به صف</button>
      </form>
      <div class="cluster mb-sm">
        <form method="post" action="{prefix}/batch/apply" data-confirm="اعمال همه؟"><button class="btn btn-primary btn-sm" type="submit">اعمال</button></form>
        <form method="post" action="{prefix}/batch/clear" data-confirm="پاک؟"><button class="btn btn-ghost btn-sm" type="submit">پاک</button></form>
      </div>
      <div class="table-wrap"><table class="table"><tbody>{batch_rows}</tbody></table></div>
    </div>
  </div>
  {files_card}
</section>

<script>
(function(){{
  function show(id){{
    document.querySelectorAll('.tabs [data-tab]').forEach(function(b){{
      b.setAttribute('aria-selected', b.getAttribute('data-tab')===id ? 'true':'false');
    }});
    document.querySelectorAll('.tab-panel').forEach(function(p){{
      p.hidden = p.id !== 'tab-'+id;
    }});
  }}
  document.querySelectorAll('.tabs [data-tab]').forEach(function(b){{
    b.addEventListener('click', function(){{
      var id=b.getAttribute('data-tab');
      show(id);
      try{{ history.replaceState(null,'', (location.pathname||'') + '?tab='+id); }}catch(e){{}}
    }});
  }});
  var log=document.getElementById('agent-chat-log');
  var input=document.getElementById('agent-chat-input');
  var send=document.getElementById('agent-chat-send');
  function addMsg(who,txt){{
    if(!log) return;
    var d=document.createElement('div'); d.style.margin='6px 0';
    d.innerHTML='<b>'+who+':</b> '+String(txt||'').replace(/</g,'&lt;').replace(/\\n/g,'<br>');
    log.appendChild(d); log.scrollTop=log.scrollHeight;
  }}
  async function sendChat(){{
    if(!input) return;
    var t=input.value.trim(); if(!t) return;
    addMsg('شما',t); input.value='';
    addMsg('ایجنت','در حال فکر...');
    var model=(window.__agentModelGet && window.__agentModelGet()) || window.__agentModel || 'auto';
    try{{
      var r=await fetch('/api/agent/chat',{{method:'POST',credentials:'same-origin',
        headers:{{'Content-Type':'application/json'}},
        body:JSON.stringify({{text:t, model:model}})}});
      var j=await r.json();
      if(log && log.lastChild) log.removeChild(log.lastChild);
      if(j.ok){{
        addMsg('ایجنت ('+(j.model||model)+')', j.reply||j.text||'—');
        if(j.tool) addMsg('ابزار', j.tool.name+': '+JSON.stringify(j.tool.args));
      }} else addMsg('خطا', j.error||'خطا');
    }}catch(e){{
      if(log && log.lastChild) log.removeChild(log.lastChild);
      addMsg('خطا','ارتباط: '+e);
    }}
  }}
  if(send) send.addEventListener('click', sendChat);
  if(input) input.addEventListener('keydown', function(e){{ if(e.key==='Enter') sendChat(); }});
}})();
</script>
'''
    body = content + v321js
    title = "میز کار ایجنت — v327"
    if in_panel:
        return panel_page(s, title, "امروز · محتوا · گفت‌وگو · درآمد · سیستم · دستور · هوش", body,
                          "/panel/agent", token)
    return public_page(s, title, body, active="/agent")
