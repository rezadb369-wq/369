/* Bazarche — flash-deal countdown (v31) · v109: urgency state · v120: re-runnable */
const FA = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
const fa = n => String(n).replace(/\d/g, d => FA[+d]);

function startCountdowns(root = document) {
  root.querySelectorAll('[data-countdown]').forEach(el => {
    if (el.dataset.bzCount) return;               // v120: never double-tick after a live swap
    el.dataset.bzCount = '1';
    const end = new Date(el.dataset.countdown.replace(' ', 'T')).getTime();
    if (Number.isNaN(end)) { el.textContent = ''; return; }
    const tick = () => {
      const left = end - Date.now();
      if (left <= 0) { el.textContent = 'تمام شد'; el.classList.add('is-done'); return; }
      const h = Math.floor(left / 3600000);
      const m = Math.floor((left % 3600000) / 60000);
      const s = Math.floor((left % 60000) / 1000);
      // v109: under one hour the counter ticks hot — urgency is visible
      el.classList.toggle('is-urgent', left < 3600000);
      el.textContent = (h ? fa(h) + ':' : '') + fa(String(m).padStart(2,'0')) + ':' + fa(String(s).padStart(2,'0'));
    };
    tick();
    setInterval(tick, 1000);
  });
}

startCountdowns();
window.addEventListener('bz:needs-countdown', () => startCountdowns());
