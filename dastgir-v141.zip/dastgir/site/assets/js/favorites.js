/* Favorites page — uses the same v2/server-synced state as every heart. */
const KEY = 'bazarche.v2.favs';
const read = () => {
  if (window.BazarcheFavorites) return window.BazarcheFavorites.read();
  const boot = window.__BAZARCHE__ || {};
  if (boot.favoriteSignedIn && Array.isArray(boot.favoriteSlugs)) return boot.favoriteSlugs;
  try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (_) { return []; }
};
const esc = value => String(value == null ? '' : value)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

const ICON_HEART = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20s-7.5-4.7-7.5-9.6A4.4 4.4 0 0 1 12 7.4a4.4 4.4 0 0 1 7.5 3c0 4.9-7.5 9.6-7.5 9.6Z"/></svg>';
const ICON_PIN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 10.5c0 5.5-8 11.5-8 11.5s-8-6-8-11.5a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10.5" r="3"/></svg>';

function syncEmpty(list, empty) {
  const hasCards = Boolean(list?.querySelector('article'));
  if (list) list.hidden = !hasCards;
  if (empty) empty.hidden = hasCards;
}

async function boot() {
  const list = document.getElementById('fav-list');
  const empty = document.getElementById('fav-empty');
  if (!list) return;
  const favs = read();
  if (!favs.length) { syncEmpty(list, empty); return; }

  list.innerHTML = favs.map(() => '<div class="sk sk-card"></div>').join('');
  let all = [];
  try {
    const response = await fetch('/api/businesses');
    if (!response.ok) throw new Error('network');
    all = await response.json();
  } catch (_) {
    list.innerHTML = ''; syncEmpty(list, empty); return;
  }
  const rows = all.filter(business => favs.includes(business.slug));
  list.innerHTML = rows.map(business => `
    <article class="card card-hover glass" data-favorite-card="${esc(business.slug)}">
      <div class="card-body">
        <div class="between" style="align-items:flex-start;gap:8px">
          <h3 class="card-title"><a href="/b/${encodeURIComponent(business.slug)}">${esc(business.name)}</a></h3>
          <button class="btn-icon favorite-action" type="button"
                  data-fav="${esc(business.slug)}" data-fav-name="${esc(business.name)}"
                  aria-pressed="true" aria-label="علاقه‌مندی: ${esc(business.name)}">${ICON_HEART}</button>
        </div>
        <div class="card-meta">${ICON_PIN}<span>${esc(business.address || '')}</span></div>
        <a class="btn btn-glass btn-sm btn-block mt-md" href="/b/${encodeURIComponent(business.slug)}">مشاهدهٔ صفحه</a>
      </div>
    </article>`).join('');
  syncEmpty(list, empty);
  window.BazarcheFavorites?.paint();

  document.addEventListener('bazarche:favorites-changed', event => {
    const { slug, on } = event.detail || {};
    if (!slug || on) return;
    list.querySelector(`[data-favorite-card="${CSS.escape(slug)}"]`)?.remove();
    syncEmpty(list, empty);
  });
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
