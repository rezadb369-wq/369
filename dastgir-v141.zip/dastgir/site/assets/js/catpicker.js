/* ==========================================================================
   SEARCHABLE CATEGORY PICKER
   ---------------------------------------------------------------------------
   165 trades in a native <select> is a scroll marathon. A shopkeeper knows
   the word for their own trade ("نانوایی", "قالیشویی") but has to guess
   which of 22 parent groups it was filed under, then scroll to find it.

   This turns the same <select> into a type-to-filter list. The <select> is
   kept in the DOM (hidden) so the form still posts exactly what it always
   posted, and everything keeps working with JavaScript off.

   Searching folds Persian spelling the way db.normalize_fa() does on the
   server, so «قاليشويي» with Arabic ي finds «قالیشویی».
   ========================================================================== */

const FA_FOLD = [
  ['\u064A', '\u06CC'],   // Arabic yeh  -> Persian yeh
  ['\u0643', '\u06A9'],   // Arabic kaf  -> Persian keheh
  ['\u200C', ' '],        // ZWNJ counts as a space
  ['\u0623', '\u0627'], ['\u0625', '\u0627'], ['\u0622', '\u0627'],
  ['\u0629', '\u0647'], ['\u0624', '\u0648'], ['\u0626', '\u06CC'],
];

function fold(s) {
  let t = String(s || '').toLowerCase();
  for (const [a, b] of FA_FOLD) t = t.split(a).join(b);
  t = t.replace(/[\u064B-\u0652\u0640]/g, '');           // harakat + tatweel
  t = t.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)); // Persian digits
  return t.replace(/\s+/g, ' ').trim();
}

function build(sel) {
  const wrap = document.createElement('div');
  wrap.className = 'catpick';

  // read every option out of the native select, remembering its group
  const opts = [];
  sel.querySelectorAll('option').forEach(o => {
    if (!o.value) return;
    const grp = o.parentElement.tagName === 'OPTGROUP'
      ? o.parentElement.label : '';
    opts.push({ v: o.value, t: o.textContent.trim(), g: grp,
                key: fold(o.textContent + ' ' + grp) });
  });
  if (!opts.length) return;

  const current = opts.find(o => o.v === sel.value);

  wrap.innerHTML = `
    <button class="catpick-btn" type="button" aria-haspopup="listbox" aria-expanded="false">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"
           stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M7 12h10M10 18h4"/></svg>
      <span class="catpick-val">${current ? current.t : 'انتخاب دسته…'}</span>
      <svg class="catpick-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor"
           stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>
    </button>
    <div class="catpick-pop" hidden>
      <div class="catpick-sheet-head">
        <span>انتخاب دستهٔ شغلی</span>
        <button class="catpick-close" type="button" aria-label="بستن">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"
               stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="catpick-search">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"
             stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
        <input type="search" placeholder="نام شغلتان را بنویسید — مثلاً نانوایی"
               autocomplete="off" aria-label="جست‌وجوی دسته">
      </div>
      <div class="catpick-list" role="listbox"></div>
      <p class="catpick-empty" hidden>چیزی پیدا نشد. کلمهٔ دیگری امتحان کنید،
        یا نزدیک‌ترین دسته را انتخاب کنید — بعداً قابل تغییر است.</p>
    </div>`;

  sel.parentNode.insertBefore(wrap, sel);
  sel.classList.add('catpick-native');
  // the select stays in the DOM and keeps its name, so the POST is unchanged

  const btn   = wrap.querySelector('.catpick-btn');
  const pop   = wrap.querySelector('.catpick-pop');
  const input = wrap.querySelector('input');
  const list  = wrap.querySelector('.catpick-list');
  const empty = wrap.querySelector('.catpick-empty');
  const valEl = wrap.querySelector('.catpick-val');

  let shown = [];

  const render = (q = '') => {
    const nq = fold(q);
    shown = nq ? opts.filter(o => o.key.includes(nq)) : opts;
    list.innerHTML = shown.slice(0, 120).map((o, i) => `
      <button class="catpick-item${o.v === sel.value ? ' is-on' : ''}"
              type="button" role="option" data-v="${o.v}" data-i="${i}"
              aria-selected="${o.v === sel.value}">
        <span class="ci-name">${o.t}</span>
        ${o.g ? `<span class="ci-grp">${o.g}</span>` : ''}
      </button>`).join('');
    empty.hidden = shown.length > 0;
  };

  // Below 861px the popup is a full-screen sheet (see pages.css). The page
  // behind it must not scroll, or the list drags the form around under it.
  const isSheet = () => window.matchMedia('(max-width: 860px)').matches;

  const open = () => {
    // Measured, not guessed: the form card carries `backdrop-filter: blur()`,
    // and a filtered ancestor becomes the containing block for position:fixed
    // — so the "full-screen" sheet was fixed to the CARD (top 587, height 757)
    // instead of the viewport. Moving the node to <body> for the duration of
    // the sheet is the only fix that keeps the blur on the card.
    if (isSheet() && pop.parentElement !== document.body) {
      document.body.appendChild(pop);
    }
    pop.hidden = false;
    btn.setAttribute('aria-expanded', 'true');
    render(input.value);
    if (isSheet()) document.body.classList.add('catpick-open');
    // On a phone, focusing immediately raises the keyboard over the list
    // before it has painted. One frame is enough for the sheet to settle.
    requestAnimationFrame(() => input.focus());
  };
  const close = () => {
    pop.hidden = true;
    btn.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('catpick-open');
    // Put it back so the desktop layout (absolute, anchored to .catpick) works
    // again after a resize or an orientation change.
    if (pop.parentElement !== wrap) wrap.appendChild(pop);
  };

  wrap.querySelector('.catpick-close').addEventListener('click', () => {
    close(); btn.focus();
  });

  const pick = (v) => {
    const o = opts.find(x => x.v === v);
    if (!o) return;
    sel.value = v;
    // fire change so anything listening (dup-check, form submit) still runs
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    valEl.textContent = o.t;
    wrap.classList.add('has-value');
    close();
    btn.focus();
  };

  btn.addEventListener('click', () => (pop.hidden ? open() : close()));
  input.addEventListener('input', () => render(input.value));

  list.addEventListener('click', e => {
    const it = e.target.closest('.catpick-item');
    if (it) pick(it.dataset.v);
  });

  // keyboard: arrows move, enter picks, escape closes
  let cursor = -1;
  const move = (d) => {
    const items = [...list.querySelectorAll('.catpick-item')];
    if (!items.length) return;
    cursor = (cursor + d + items.length) % items.length;
    items.forEach((x, i) => x.classList.toggle('is-cursor', i === cursor));
    items[cursor].scrollIntoView({ block: 'nearest' });
  };
  input.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
    else if (e.key === 'Enter') {
      e.preventDefault();
      const items = [...list.querySelectorAll('.catpick-item')];
      const t = cursor >= 0 ? items[cursor] : items[0];
      if (t) pick(t.dataset.v);
    } else if (e.key === 'Escape') { close(); btn.focus(); }
  });

  // On a phone the sheet is re-parented to <body>, so `wrap.contains()` alone
  // would treat every tap INSIDE the sheet as an outside click and slam it
  // shut before the option registered. Test both nodes.
  document.addEventListener('click', e => {
    if (!wrap.contains(e.target) && !pop.contains(e.target)) close();
  });

  if (current) wrap.classList.add('has-value');
  render();
}

export function initCatPicker() {
  document.querySelectorAll('select[data-catpick]').forEach(build);
}

if (document.readyState === 'loading')
  document.addEventListener('DOMContentLoaded', initCatPicker);
else
  initCatPicker();
