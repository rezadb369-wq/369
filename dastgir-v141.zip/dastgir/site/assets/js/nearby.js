/* ==========================================================================
   "Near me" — browser geolocation + server-side haversine search.
   The coordinates never leave the request; nothing is stored.
   ========================================================================== */
const iconBg = (name, size) => {
  const aliases = { store:'business', shopping:'supermarket', briefcase:'business',
    camera:'photography', map:'attraction', compass:'attraction', pin:'attraction', mosque:'attraction' };
  const safe = /^[A-Za-z0-9_-]+$/.test(name || '') ? name : 'business';
  const picked = aliases[safe] || safe;
  return `width:${size}px;height:${size}px;` +
         `background-image:url(/assets/img/cats/${encodeURIComponent(picked)}.webp);` +
         'background-size:cover;background-position:center;';
};
const FA = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
const fa = (n) => String(n).replace(/\d/g, d => FA[+d]);
const esc = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const SVG = (d, w = 16) => `<svg width="${w}" height="${w}" viewBox="0 0 24 24" fill="none"
  stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"
  aria-hidden="true">${d}</svg>`;
const I_PIN = SVG('<path d="M20 10.5c0 5.5-8 11.5-8 11.5s-8-6-8-11.5a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10.5" r="3"/>');
const I_NAV = SVG('<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5.5-5.5 2 2-5.5 5.5-2Z"/>');
const I_STAR = SVG('<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L3.2 9.5l6.1-.9L12 3Z"/>', 14);
const I_HEART = SVG('<path d="M12 20s-7.5-4.7-7.5-9.6A4.4 4.4 0 0 1 12 7.4a4.4 4.4 0 0 1 7.5 3c0 4.9-7.5 9.6-7.5 9.6Z"/>', 20);

let pos = null;

function el(sel) { return document.querySelector(sel); }

function status(text) {
  const s = el('[data-near-status]');
  if (s) s.textContent = text;
}

function card(b) {
  const rating = b.nreviews
    ? `<span class="card-meta">${I_STAR}<strong class="nums">${fa(b.rating)}</strong>
       <span>(${fa(b.nreviews)} نظر)</span></span>`
    : '<span class="text-xs text-muted">هنوز نظری ثبت نشده</span>';
  const img = b.image
    ? `<img class="biz-cover" src="${esc(b.image)}" alt="" loading="lazy" decoding="async">`
    : `<div class="biz-thumb-art" aria-hidden="true"><span class="ic" style="${iconBg(b.icon || 'store', 96)}"></span></div>`;
  return `<article class="card card-hover glass reveal">
    <div class="card-media biz-thumb${b.image ? ' has-photo' : ''}">${img}
      <div class="media-corner-badge">
        <span class="badge badge-info badge-sm dist-badge">${I_NAV}<span class="nums">${fa(b.distance_km)}</span> کیلومتر</span>
      </div>
    </div>
    <div class="card-body">
      <div class="between" style="align-items:flex-start;gap:8px">
        <div class="card-title-wrap">
          <h3 class="card-title"><a href="/b/${esc(b.slug)}">${esc(b.name)}</a></h3>
        </div>
        <button class="fav-btn card-fav-btn" type="button" data-fav="${esc(b.slug)}"
                data-fav-name="${esc(b.name)}" aria-pressed="false"
                aria-label="علاقه‌مندی: ${esc(b.name)}">${I_HEART}</button>
      </div>
      <div class="card-meta">${rating}</div>
      <p class="card-desc">${esc(b.descr || '')}</p>
      <div class="card-foot">
        <span class="card-meta" style="margin:0">${I_PIN}<span>${esc(b.address || '')}</span></span>
        <a class="btn btn-ghost btn-sm" href="/b/${esc(b.slug)}">مشاهده</a>
      </div></div></article>`;
}

async function search() {
  if (!pos) return;
  const grid = el('[data-near-grid]');
  const empty = el('[data-near-empty]');
  const r = el('[data-near-range]')?.value || 3;
  const cat = el('[data-near-cat]')?.value || '';
  status('در حال جست‌وجو…');

  let data;
  try {
    const res = await fetch(`/api/nearby?lat=${pos.lat}&lng=${pos.lng}&r=${r}&cat=${encodeURIComponent(cat)}`);
    data = await res.json();
  } catch (e) {
    status('ارتباط با سرور برقرار نشد. دوباره تلاش کنید.');
    return;
  }

  const rows = data.results || [];
  if (!rows.length) {
    grid.innerHTML = '';
    if (empty) {
      empty.hidden = false;
      empty.innerHTML = `<div class="empty-state">
        <span class="icon-wrap">${I_PIN}</span>
        <h3>در این شعاع چیزی نبود</h3>
        <p>شعاع را بیشتر کنید یا دستهٔ دیگری را امتحان کنید.</p></div>`;
    }
    status(`در شعاع ${fa(r)} کیلومتری نتیجه‌ای نبود.`);
    return;
  }
  if (empty) empty.hidden = true;
  grid.innerHTML = rows.map(card).join('');
  window.BazarcheFavorites?.paint();
  status(`${fa(rows.length)} کسب‌وکار در شعاع ${fa(r)} کیلومتری شما`);
  grid.querySelectorAll('.reveal').forEach(n => n.classList.add('is-visible'));
}

function locate() {
  if (!navigator.geolocation) {
    status('مرورگر شما موقعیت‌یابی را پشتیبانی نمی‌کند.');
    window.Bazarche?.toast('موقعیت‌یابی در این مرورگر در دسترس نیست.', 'warn');
    return;
  }
  status('در حال گرفتن موقعیت…');
  navigator.geolocation.getCurrentPosition(
    (p) => {
      pos = { lat: p.coords.latitude.toFixed(6), lng: p.coords.longitude.toFixed(6) };
      search();
    },
    async (err) => {
      const msg = await (window.Bazarche && window.Bazarche.geoErrorText
        ? window.Bazarche.geoErrorText(err, 'از نقشهٔ شهر استفاده کنید.')
        : Promise.resolve('موقعیت شما پیدا نشد.'));
      status(msg);
      window.Bazarche?.toast(msg, 'warn');
    },
    { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 }
  );
}

function syncCategoryChips(catVal) {
  const chips = document.querySelectorAll('[data-near-chip]');
  chips.forEach(c => {
    const v = c.dataset.nearChip || '';
    c.classList.toggle('is-active', v === (catVal || ''));
  });
}

function boot() {
  const btn = el('[data-geo]');
  if (!btn) return;
  btn.addEventListener('click', locate);

  const range = el('[data-near-range]');
  const out = el('[data-near-r]');
  if (range) {
    const sync = () => { if (out) out.textContent = fa(range.value); };
    range.addEventListener('input', sync);
    range.addEventListener('change', search);
    sync();
  }

  const catSelect = el('[data-near-cat]');
  if (catSelect) {
    catSelect.addEventListener('change', () => {
      syncCategoryChips(catSelect.value);
      search();
    });
  }

  // Quick category chips
  const chipsContainer = el('[data-near-chips]');
  if (chipsContainer) {
    chipsContainer.addEventListener('click', (e) => {
      const chip = e.target.closest('[data-near-chip]');
      if (!chip || !catSelect) return;
      const targetSlug = chip.dataset.nearChip || '';
      catSelect.value = targetSlug;
      // Also update catpicker button text if present
      const catpickVal = catSelect.parentElement?.querySelector('.catpick-val');
      if (catpickVal) {
        const opt = catSelect.querySelector(`option[value="${targetSlug}"]`);
        catpickVal.textContent = opt ? opt.textContent.trim() : 'همهٔ دسته‌ها';
      }
      syncCategoryChips(targetSlug);
      search();
    });
  }

  // Category search input
  const searchIn = el('[data-near-cat-search]');
  if (searchIn && catSelect) {
    let debounceTimer;
    searchIn.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        const q = searchIn.value.trim().toLowerCase();
        if (!q) {
          catSelect.value = '';
          syncCategoryChips('');
          search();
          return;
        }
        // find best matching option
        const opts = Array.from(catSelect.querySelectorAll('option'));
        const match = opts.find(o => o.value && o.textContent.toLowerCase().includes(q));
        if (match) {
          catSelect.value = match.value;
          const catpickVal = catSelect.parentElement?.querySelector('.catpick-val');
          if (catpickVal) catpickVal.textContent = match.textContent.trim();
          syncCategoryChips(match.value);
          search();
        }
      }, 250);
    });
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}
