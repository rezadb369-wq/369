/* Catalog item form: adapt fields to the chosen kind, format money as you
   type, and mirror everything into a live preview card. */

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

const FA = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
const toFa = (s) => String(s).replace(/\d/g, d => FA[+d]);
const digits = (s) => String(s || '').replace(/[۰-۹]/g, d => FA.indexOf(d)).replace(/[^\d]/g, '');
const group = (n) => n ? toFa(Number(n).toLocaleString('en-US')).replace(/,/g, '٬') : '';

/* ---------- adapt fields to product / service / custom ---------- */
function initKindLogic() {
  const kind = $('[data-kind]');
  const ptype = $('[data-ptype]');
  if (!kind) return;

  const priceFields = $$('[data-price-field]');
  const serviceField = $('[data-service-field]');

  const sync = () => {
    const noPrice = ptype && (ptype.value === 'call' || ptype.value === 'free');
    priceFields.forEach(f => { f.style.display = noPrice ? 'none' : ''; });
    if (serviceField) {
      serviceField.style.display = (kind.value === 'service') ? '' : 'none';
    }
    updatePreview();
  };

  kind.addEventListener('change', () => {
    // bespoke work is quote-based by default
    if (kind.value === 'custom' && ptype && ptype.value === 'fixed') ptype.value = 'call';
    sync();
  });
  ptype?.addEventListener('change', sync);
  sync();
}

/* ---------- money inputs: show ۲۵۰٬۰۰۰ while storing 250000 ---------- */
function initMoney() {
  $$('[data-money]').forEach(inp => {
    const format = () => {
      const raw = digits(inp.value);
      inp.value = group(raw);
      inp.dataset.raw = raw;
    };
    inp.addEventListener('input', () => { format(); updatePreview(); });
    inp.addEventListener('blur', format);
    if (inp.value) format();

    // submit the plain number, not the formatted string
    inp.form?.addEventListener('submit', () => { inp.value = digits(inp.value); },
                               { capture: true });
  });
}

/* ---------- live preview ---------- */
function updatePreview() {
  const card = $('[data-preview-card]');
  if (!card) return;

  const title = $('#i-title')?.value?.trim();
  $('[data-pv-title]', card).textContent = title || 'عنوان محصول';

  const ptype = $('[data-ptype]')?.value || 'fixed';
  const price = digits($('#i-price')?.value);
  const oldP = digits($('#i-old')?.value);
  const unit = $('#i-unit')?.value?.trim();

  let txt;
  if (ptype === 'call') txt = 'استعلام قیمت';
  else if (ptype === 'free') txt = 'رایگان';
  else if (!price) txt = 'استعلام قیمت';
  else {
    txt = group(price) + ' تومان';
    if (unit) txt += ' / ' + unit;
    if (ptype === 'from') txt = 'از ' + txt;
  }
  const el = $('[data-pv-price]', card);
  el.innerHTML = (oldP && price && +oldP > +price && ptype !== 'call' && ptype !== 'free')
    ? `<s class="ip-old">${group(oldP)}</s> ${txt}`
    : txt;

  // mirror the first chosen image
  const field = $('[data-imagefield]');
  const first = field?.querySelector('.imgf-item img');
  const box = $('[data-pv-img]', card);
  if (first) box.innerHTML = `<img src="${first.src}" alt="">`;
}

function initPreview() {
  ['#i-title', '#i-unit', '#i-price', '#i-old'].forEach(sel => {
    $(sel)?.addEventListener('input', updatePreview);
  });
  // the image field re-renders its own grid; watch for changes
  const field = $('[data-imagefield]');
  if (field) new MutationObserver(updatePreview)
    .observe(field, { childList: true, subtree: true });
  updatePreview();
}

function boot() { initKindLogic(); initMoney(); initPreview(); }

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else { boot(); }
