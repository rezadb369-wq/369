/* Bulk selection bar for admin tables. */

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const FA = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
const fa = (n) => String(n).replace(/\d/g, d => FA[+d]);

function boot() {
  const form = $('[data-bulk]');
  if (!form) return;

  const bar = $('[data-bulk-bar]', form);
  const count = $('[data-bulk-count]', form);
  const all = $('[data-bulk-all]');
  const items = $$('[data-bulk-item]');
  if (!items.length) return;

  const sync = () => {
    const n = items.filter(i => i.checked).length;
    count.textContent = fa(n);
    bar.hidden = n === 0;
    if (all) {
      all.checked = n === items.length;
      all.indeterminate = n > 0 && n < items.length;
    }
  };

  items.forEach(i => i.addEventListener('change', sync));
  all?.addEventListener('change', () => {
    items.forEach(i => { i.checked = all.checked; });
    sync();
  });

  form.addEventListener('submit', (e) => {
    const btn = e.submitter;
    const n = items.filter(i => i.checked).length;
    if (!n) { e.preventDefault(); return; }
    if (btn && btn.value === 'delete') {
      const msg = form.dataset.confirmDelete || 'موارد انتخاب‌شده حذف شوند؟';
      if (!window.confirm(`${msg}\n\n(${n} مورد)`)) e.preventDefault();
    }
    if (btn && btn.value === 'move' && !$('[name="cat_to"]', form).value) {
      e.preventDefault();
      window.Bazarche?.toast('ابتدا دستهٔ مقصد را انتخاب کنید.', 'err');
    }
  });

  sync();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else { boot(); }
