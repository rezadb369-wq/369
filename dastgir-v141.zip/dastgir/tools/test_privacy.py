#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v116-audit phase 5: data lifecycle & privacy.

  P1  90-day IP blanking (v115 privacy promise)
  P2  2-year visits purge (v116)
  P3  2-year audit/searches purge (v116 phase-5 fix)
  P4  trash retention per entity (story 7d, item/review/report 24h)
  P5  chat-image GC: bytes AND row leave together
  P6  delete_owner: every owner-linked table handled
  P7  customer_delete: every customer-linked table handled
      (price_alerts via ON DELETE CASCADE — proven here)
  P8  public pages leak nothing sensitive (token/hash/paths/owner phone)

Run:  python3 tools/test_privacy.py   (server up on :8080)
"""
import os
import re
import sys
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa: E402
import uploads  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080")
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
PASS, FAIL = [], []


def ok(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(("  ✓ " if cond else "  ✗ ") + name + (f"   [{detail}]" if detail and not cond else ""))


def main():
    con = db.connect()

    print(f"\n{B}P1) پاک‌شدن IP پس از ۹۰ روز{X}")
    now = time.time()
    con.execute("INSERT INTO visits (ts,path,kind,ip,prov,city) "
                "VALUES (?,'/p1','page','9.9.9.9','X','Y')", (now - 91 * 86400,))
    con.execute("INSERT INTO visits (ts,path,kind,ip,prov,city) "
                "VALUES (?,'/p1','page','8.8.8.8','X','Y')", (now,))
    con.commit()
    db.init()   # the boot routine does the blanking
    old = db._one("SELECT ip, prov, city FROM visits WHERE path='/p1' AND ip='' ")
    fresh = db._one("SELECT ip FROM visits WHERE path='/p1' AND ip!=''")
    total = db._one("SELECT COUNT(*) n FROM visits WHERE path='/p1'")["n"]
    ok("آی‌پی ۹۱ روزه blank شد", old is not None and old["ip"] == "")
    ok("استان/شهر هم blank شد", old and old["prov"] == "" and old["city"] == "")
    ok("ردیف تازه دست‌نخورده", fresh and fresh["ip"] == "8.8.8.8")
    ok("آمار (ردیف) حفظ شد — فقط هویت رفت", total == 2, f"n={total}")
    con.execute("DELETE FROM visits WHERE path='/p1'")
    con.commit()

    print(f"\n{B}P2) purge بازدیدهای بالای ۲ سال{X}")
    con.execute("INSERT INTO visits (ts,path,kind,ip) VALUES (?,'/p2','page','7.7.7.7')",
                (now - 731 * 86400,))
    con.commit()
    db.init()
    left = db._one("SELECT COUNT(*) n FROM visits WHERE path='/p2'")["n"]
    ok("ردیف ۷۳۱ روزه حذف شد", left == 0, f"n={left}")

    print(f"\n{B}P3) purge لاگ‌های بالای ۲ سال (audit/searches){X}")
    con.execute("INSERT INTO audit (action, detail, created) "
                "VALUES ('p3.test','x', datetime('now','-731 days'))")
    con.execute("INSERT INTO searches (term,norm,cat,results,day,created) "
                "VALUES ('p3term','p3term','',0,'2024-01-01', datetime('now','-731 days'))")
    con.commit()
    db.init()
    a = db._one("SELECT COUNT(*) n FROM audit WHERE action='p3.test'")["n"]
    s = db._one("SELECT COUNT(*) n FROM searches WHERE term='p3term'")["n"]
    ok("audit کهنه purge شد", a == 0, f"n={a}")
    ok("searches کهنه purge شد", s == 0, f"n={s}")

    print(f"\n{B}P4) ماندگاری سطل بازیافت به تفکیک موجودیت{X}")
    day_old = now - 25 * 3600
    week_old = now - 8 * 86400
    con.execute("INSERT INTO trash(entity,ref_id,biz_id,title,payload,deleted_at) "
                "VALUES ('item',99901,0,'p4-item','{}',?)", (day_old,))
    con.execute("INSERT INTO trash(entity,ref_id,biz_id,title,payload,deleted_at) "
                "VALUES ('story',99902,0,'p4-story','{}',?)", (week_old,))
    con.execute("INSERT INTO trash(entity,ref_id,biz_id,title,payload,deleted_at) "
                "VALUES ('story',99903,0,'p4-story-fresh','{}',?)", (now,))
    con.commit()
    db.trash_purge()
    left = {r["title"]: 1 for r in db._rows(
        "SELECT title FROM trash WHERE ref_id IN (99901,99902,99903)")}
    ok("item ۲۵ ساعته purge شد (نگهداری ۲۴h)", "p4-item" not in left)
    ok("story ۸ روزه purge شد (نگهداری ۷d)", "p4-story" not in left)
    ok("story تازه ماند", "p4-story-fresh" in left)
    con.execute("DELETE FROM trash WHERE ref_id IN (99901,99902,99903)")
    con.commit()

    print(f"\n{B}P5) GC تصویر چت — بایت و ردیف با هم{X}")
    # fabricate an expired attachment + its bytes, then run the GC
    stored = "p5-fake-old.jpg"
    fpath = os.path.join(uploads.CHAT_UPLOAD_DIR, stored)
    with open(fpath, "wb") as f:
        f.write(b"\xff\xd8\xff\xd9")
    _bid = db._one("SELECT id FROM businesses LIMIT 1")["id"]
    cur = con.execute("INSERT INTO chat_threads (biz_id, customer_id, status, last_activity) "
                      "VALUES (?, NULL, 'closed', 0)", (_bid,))
    p5_tid = cur.lastrowid
    cur = con.execute("INSERT INTO chat_messages (thread_id, sender, body) "
                      "VALUES (?, 'c', 'p5')", (p5_tid,))
    con.execute(
        "INSERT INTO chat_attachments (message_id, stored_name, original_name, "
        "mime, size, kind, created) "
        "VALUES (?, ?, 'p5.jpg', 'image/jpeg', 4, 'image', datetime('now', ?))",
        (cur.lastrowid, stored, f"-{db.CHAT_RETENTION_DAYS + 1} days"))
    con.commit()
    import app as appmod
    n = appmod.purge_expired_chat_images()
    row = db._one("SELECT id FROM chat_attachments WHERE stored_name=?", (stored,))
    ok("بایت از دیسک رفت", not os.path.exists(fpath))
    ok("ردیف DB هم رفت", row is None, f"purged={n}")
    con.execute("DELETE FROM chat_messages WHERE thread_id=?", (p5_tid,))
    con.execute("DELETE FROM chat_threads WHERE id=?", (p5_tid,))
    con.commit()

    print(f"\n{B}P6) حذف حساب مالک — همهٔ ردیف‌ها{X}")
    # idempotency: sweep leftovers of a previously aborted run
    for _r in db._rows("SELECT id FROM owners WHERE phone='09000000111'"):
        db.delete_owner(_r["id"])
    # NOTE: commit the parent BEFORE touching helpers like db._one — connect()
    # rolls any still-open transaction back on re-acquire (v109 dangling-txn
    # guard). Production writes always commit immediately via _run.
    bid = db._one("SELECT id FROM businesses LIMIT 1")["id"]
    cur = con.execute("INSERT INTO owners (phone, name, status) "
                      "VALUES ('09000000111','p6-owner','active')")
    oid = cur.lastrowid
    con.commit()
    con.execute("UPDATE businesses SET owner_id=? WHERE id=?", (oid, bid))
    con.execute("INSERT INTO claims (owner_id, biz_id, status) VALUES (?,?, 'approved')",
                (oid, bid))
    con.execute("INSERT INTO sessions (owner_id, token, expires, created) "
                "VALUES (?, 'p6-tok', datetime('now','+1 day'), datetime('now'))", (oid,))
    con.execute("INSERT INTO tickets (owner_id, name, phone, subject, status) "
                "VALUES (?, 'p6','09000000111','p6-sub','open')", (oid,))
    con.commit()
    db.delete_owner(oid)
    checks = {
        "owners": db._one("SELECT COUNT(*) n FROM owners WHERE id=?", (oid,))["n"],
        "claims": db._one("SELECT COUNT(*) n FROM claims WHERE owner_id=?", (oid,))["n"],
        "sessions": db._one("SELECT COUNT(*) n FROM sessions WHERE owner_id=?", (oid,))["n"],
        "dangling_ticket_fk": db._one(
            "SELECT owner_id o FROM tickets WHERE subject='p6-sub'")["o"],
        "biz_detached": db._one("SELECT owner_id o FROM businesses WHERE id=?", (bid,))["o"],
    }
    ok("حساب حذف شد", checks["owners"] == 0)
    ok("claims و sessions رفتند", checks["claims"] == 0 and checks["sessions"] == 0)
    ok("تیکت بی‌صاحب شد (SET NULL) نه یتیمِ شکسته", checks["dangling_ticket_fk"] is None)
    ok("کسب‌وکار جدا شد ولی زنده است", checks["biz_detached"] is None)
    con.execute("DELETE FROM tickets WHERE subject='p6-sub'")
    con.commit()

    print(f"\n{B}P7) حذف حساب مشتری — هر ۹+۱ جدول{X}")
    for _r in db._rows("SELECT id FROM customers WHERE phone='09000000222'"):
        db.customer_delete(_r["id"])
    cur = con.execute("INSERT INTO customers (phone, name, status) "
                      "VALUES ('09000000222','p7-cust','active')")
    cid = cur.lastrowid
    con.commit()   # parent committed before children (see P6 note)
    con.execute("INSERT INTO customer_sessions (customer_id, token, expires) "
                "VALUES (?, 'p7-tok', datetime('now','+1 day'))", (cid,))
    con.execute("INSERT INTO notifications (customer_id, kind, text) VALUES (?, 'x','p7')", (cid,))
    con.execute("INSERT INTO favorites (customer_id, biz_id) VALUES (?,?)", (cid, bid))
    con.execute("INSERT INTO follows (customer_id, biz_id) VALUES (?,?)", (cid, bid))
    con.execute("INSERT INTO points (customer_id, amount, reason) VALUES (?, 5, 'p7')", (cid,))
    con.execute("INSERT INTO redemptions (customer_id, code, percent, points_spent) "
                "VALUES (?, 'p7c', 10, 1)", (cid,))
    con.execute("INSERT INTO price_alerts (customer_id, group_key) VALUES (?, 'p7-g')", (cid,))
    curt = con.execute("INSERT INTO chat_threads (customer_id, biz_id, last_activity) "
                       "VALUES (?,?,0)", (cid, bid))
    tid = curt.lastrowid
    con.execute("INSERT INTO chat_messages (thread_id, sender, body) VALUES (?, 'c','p7')", (tid,))
    con.execute("INSERT INTO orders (biz_id, customer_id, name, phone, address, total, status) "
                "VALUES (?,?,?,?, '', 1000, 'done')", (bid, cid, 'p7', '09000000222'))
    con.commit()
    db.customer_delete(cid)
    q = lambda sql: db._one(sql, (cid,))["n"]  # noqa: E731
    counts = {
        "customers": q("SELECT COUNT(*) n FROM customers WHERE id=?"),
        "customer_sessions": q("SELECT COUNT(*) n FROM customer_sessions WHERE customer_id=?"),
        "notifications": q("SELECT COUNT(*) n FROM notifications WHERE customer_id=?"),
        "favorites": q("SELECT COUNT(*) n FROM favorites WHERE customer_id=?"),
        "follows": q("SELECT COUNT(*) n FROM follows WHERE customer_id=?"),
        "points": q("SELECT COUNT(*) n FROM points WHERE customer_id=?"),
        "redemptions": q("SELECT COUNT(*) n FROM redemptions WHERE customer_id=?"),
        "price_alerts": q("SELECT COUNT(*) n FROM price_alerts WHERE customer_id=?"),
        "chat_threads": q("SELECT COUNT(*) n FROM chat_threads WHERE customer_id=?"),
        "orders_detached": q("SELECT COUNT(*) n FROM orders WHERE customer_id=?"),
    }
    ok("همهٔ جدول‌های مشتری صفر شدند", all(v == 0 for v in counts.values()), str(counts))
    msg = db._one("SELECT COUNT(*) n FROM chat_messages WHERE body='p7'")["n"]
    ok("پیام چت هم رفت", msg == 0, f"n={msg}")
    con.execute("DELETE FROM orders WHERE name='p7'")
    con.commit()

    print(f"\n{B}P8) نشت اطلاعات در صفحات عمومی{X}")
    token = db.owner_token()
    owner_phones = [r["phone"] for r in db._rows(
        "SELECT phone FROM owners UNION SELECT phone FROM customers")]
    slugs = [r["slug"] for r in db._rows(
        "SELECT slug FROM businesses WHERE status='published' LIMIT 6")]
    pages = ["/", "/businesses", "/catalog", "/map", "/cities", "/blog",
             "/contact", "/submit", "/login", "/prices", "/pricing",
             "/robots.txt", "/sitemap.xml"]
    pages += ["/b/" + s for s in slugs]
    needles = [token, "pass_hash", "phone_raw", "PBKDF2", "sha256$",
               "data/bazarche.db", "/home/user", "owner_token"]
    leaks = []
    skipped = []
    for u in pages:
        try:
            with urllib.request.urlopen(BASE + u, timeout=20) as r:
                html = r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            # feature-toggled pages (e.g. /prices, which the owner keeps off)
            # legitimately 404 — route health is the robustness suite's job.
            if e.code == 404:
                skipped.append(u)
                continue
            leaks.append(f"{u}: HTTP {e.code}")
            continue
        except Exception as e:  # noqa: BLE001
            leaks.append(f"{u}: {e}")
            continue
        for nd in needles:
            if nd and nd in html:
                leaks.append(f"{u}: needle {nd!r}")
        # A shop page PUBLICISES its own contact phone on purpose — and for
        # many owners that IS their own number. Owner/customer phones are
        # only a leak when they surface OUTSIDE a business page.
        if not u.startswith("/b/"):
            for ph in owner_phones:
                if ph and len(ph) >= 11 and ph in html:
                    leaks.append(f"{u}: owner/customer phone {ph}")
    ok("هیچ صفحهٔ عمومی چیزی لو نمی‌دهد", not leaks, " | ".join(leaks[:4]))
    if skipped:
        print(f"    (صفحات خاموش رد شدند: {', '.join(skipped)})")

    print("\n" + "═" * 58)
    print(f"  موفق: {G}{len(PASS)}{X}   ناموفق: {R}{len(FAIL)}{X}")
    if FAIL:
        print("  " + R + "، ".join(FAIL) + X)
        return 1
    print(f"  {G}حریم خصوصی و چرخهٔ عمر داده تأیید شد.{X}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
