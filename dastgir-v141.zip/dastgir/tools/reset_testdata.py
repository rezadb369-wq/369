# -*- coding: utf-8 -*-
"""
Wipe every trace of a test run so the next one starts from a clean slate.

The older suites (test_all, test_actions) create businesses, categories and
owner accounts and leave them behind, which made repeat runs fail on counts
that were correct the first time. Run this before a suite, or on its own to
hand the site over empty:

    python3 tools/reset_testdata.py            # remove test fixtures only
    python3 tools/reset_testdata.py --all      # remove ALL content
"""

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa: E402
import uploads  # noqa: E402

# Names and phones the test suites are known to create.
TEST_NAMES = (
    "کبابی شهرزاد", "سوپرمارکت ولیعصر", "نانوایی بربری سحر",
    "فروشگاه کاملاً دیگر", "فروشگاه کاملاً دیگ",
    "کسب‌وکار آزمون", "دکانٔ آزمون", "سقف تست", "کسب‌وکار آزمایشی",
    "دکانٔ ممیز", "کبابی آزمون", "آزمون آمار", "دکانٔ بافت",
)
# anything containing one of these words is a fixture, wherever it appears
TEST_WORDS = ("آزمون", "آزمایش", "ممیز", "تست")
TEST_CAT_PREFIX = ("khdmat-dampzshky",)
TEST_PHONES = ("0912", "0913555", "09127770000", "09355554444",
               "09139998877", "09121234567", "09131110099", "09131110088",
               # numbers used by hand while probing the ?next= redirect chain
               "0913400", "09131111222", "09132222333",
               # test_discovery.py
               "0913490", "0913491", "0913492",
               # test_appearance.py
               "0913495", "0913999")
TEST_PLAN_NAMES = ("پلن آزمون", "پلن تست", "سقف")
TEST_BADGE_NAMES = ("آزمون نشان",)


def wipe_all():
    private_chat_files = [f["name"] for f in uploads.list_chat_files()]
    con = db.connect()
    con.execute("PRAGMA foreign_keys = OFF")
    # Keep only installation defaults (categories, cities, settings, plans,
    # badges and editable static pages). Delete every table that can contain
    # user, demo or test activity. This list is intentionally child-first even
    # though foreign keys are suspended: older versions omitted stories,
    # haggles and price_history and therefore left invisible orphan rows.
    for t in ("ticket_attachments", "ticket_msgs", "tickets",
              "chat_attachments", "chat_messages", "chat_threads",
              "order_items", "orders", "price_alerts", "price_history",
              "favorites", "follows", "notifications", "points", "redemptions",
              "customer_sessions", "customers", "biz_badges", "biz_features",
              "review_scores", "questions", "reports", "edits", "subscriptions",
              "inquiries", "haggles", "stories", "items", "reviews", "bookings",
              "flashdeals", "toplists", "coupons", "events", "claims",
              "cityevents", "ads", "alerts", "businesses", "sessions",
              "admin_sessions", "otp", "owners", "messages", "posts",
              "searches", "audit", "ratelimit"): 
        try:
            con.execute(f"DELETE FROM {t}")
        except Exception:
            pass
    con.execute("PRAGMA foreign_keys = ON")
    con.commit()
    con.close()
    for name in private_chat_files:
        uploads.delete_chat_file(name)
    print("  همهٔ محتوا و فایل‌های خصوصی گفتگو پاک شد (دسته‌ها، پلن‌ها، نشان‌ها و تنظیمات دست‌نخورده ماند)")


def wipe_fixtures():
    n = 0

    for b in db.businesses(status=None):
        name = b["name"]
        if (any(name.startswith(x) or x in name for x in TEST_NAMES)
                or any(w in name for w in TEST_WORDS)
                or "نمونه‌آزمایشی" in (b.get("tags") or "")):
            db.delete_business(b["id"])
            n += 1
    print(f"  {n} کسب‌وکار آزمایشی حذف شد")

    m = 0
    defaults = {x[0] for x in db.DEFAULT_CATEGORIES}
    for c in db.categories(only_active=False):
        if c["slug"] in defaults:
            continue
        if any(c["slug"].startswith(p) for p in TEST_CAT_PREFIX):
            ok, _msg = db.delete_category(c["id"])
            m += 1 if ok else 0
    print(f"  {m} دستهٔ آزمایشی حذف شد")

    k = 0
    for o in db.owners():
        if any(o["phone"].startswith(p) or o["phone"] == p for p in TEST_PHONES):
            db.delete_owner(o["id"])
            k += 1
    print(f"  {k} حساب آزمایشی حذف شد")

    p_ = 0
    for pl in db.plans(only_active=False):
        if any(pl["name"].startswith(x) for x in TEST_PLAN_NAMES):
            db._run("DELETE FROM subscriptions WHERE plan_slug=?", (pl["slug"],))
            db._run("DELETE FROM plans WHERE id=?", (pl["id"],))
            p_ += 1
    print(f"  {p_} پلن آزمایشی حذف شد")

    g = 0
    for bg in db.badges(only_active=False):
        if any(bg["name"].startswith(x) for x in TEST_BADGE_NAMES):
            db.delete_badge(bg["id"])
            g += 1
    print(f"  {g} نشان آزمایشی حذف شد")

    db.rate_clear()
    db._run("DELETE FROM otp")
    print("  سطل محدودسازی نرخ و کدهای یک‌بارمصرف پاک شد")


if __name__ == "__main__":
    db.init()
    print("\nپاک‌سازی دادهٔ آزمایشی")
    print("─" * 46)
    if "--all" in sys.argv:
        wipe_all()
    else:
        wipe_fixtures()
    print("─" * 46)
    print(f"  اکنون: {len(db.businesses(status=None))} کسب‌وکار، "
          f"{len(db.categories(only_active=False))} دسته، "
          f"{len(db.owners())} حساب\n")
