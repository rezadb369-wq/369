# -*- coding: utf-8 -*-
"""
ممیزی UX فاز ۷ — صفحات عمومی با مرورگر واقعی (۲۰۲۶-۰۸-۳۱)

  صفحات عمومی (ایستا + پویا از دیتای زنده) × ۴ دستگاه (360/390/412/768):
    • سرریز افقی: document.scrollWidth ≤ عرض viewport + 1px
    • خطای جاوااسکریپت کنسول: صفر
    • هدف لمسی: عناصر تعاملی اصلی ≥ ۴۴px ارتفاع
    • رندر RTL + متای viewport
    • تصویر بدون alt / ورودی بدون برچسب (شمارش، نه فقط نمونه)

    BZ=http://127.0.0.1:8080 python3 tools/public_audit.py
"""

import os
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db          # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")

DEVICES = [(360, 740, "Android-S 360"), (390, 844, "iPhone 390"),
           (412, 915, "Pixel 412"), (768, 1024, "Tablet 768")]

CHECK_JS = """
(() => {
  const bad = {overflow: 0, tap: [], noAlt: 0, noLabel: 0, rtl: true, vp: true};
  const de = document.documentElement;
  bad.overflow = de.scrollWidth - de.clientWidth;
  bad.rtl = de.getAttribute('dir') === 'rtl';
  bad.vp = !!document.querySelector('meta[name=viewport]');
  document.querySelectorAll('.btn, .chip, .btn-icon, .pager a, .tabs a, .fab')
    .forEach(el => {
      const r = el.getBoundingClientRect();
      if (r.height > 0 && r.height < 43.5 && bad.tap.length < 5)
        bad.tap.push((el.className || el.tagName).toString().slice(0, 36)
                     + ' h=' + Math.round(r.height));
    });
  document.querySelectorAll('img').forEach(i => {
    if (!i.hasAttribute('alt')) bad.noAlt++;
  });
  document.querySelectorAll('input,select,textarea').forEach(i => {
    if (i.type === 'hidden' || i.closest('.sr-only')) return;
    const lab = i.id && document.querySelector(`label[for="${i.id}"]`);
    if (!lab && !i.getAttribute('aria-label') && !i.closest('label')
        && !i.getAttribute('placeholder') && !i.getAttribute('title'))
      bad.noLabel++;
  });
  return bad;
})()
"""


def build_pages():
    """Static publics + live dynamic URLs from the running site's DB."""
    con = db.connect()
    slug = con.execute(
        "SELECT slug FROM businesses WHERE status='published' ORDER BY id LIMIT 1"
    ).fetchone()["slug"]
    item = con.execute(
        "SELECT i.id FROM items i JOIN businesses b ON b.id=i.biz_id "
        "WHERE b.status='published' LIMIT 1").fetchone()
    post = con.execute("SELECT slug FROM posts ORDER BY id LIMIT 1").fetchone()
    con.close()
    pages = ["/", "/businesses", "/catalog", "/map", "/nearby", "/lists",
             "/deals", "/events", "/cities", "/areas", "/blog", "/pricing",
             "/contact", "/about", "/rules", "/submit", "/login",
             "/favorites", "/cart",
             "/businesses?q=" + urllib.parse.quote("کبابی"),
             "/catalog?q=" + urllib.parse.quote("نان"),
             f"/b/{slug}", f"/b/{slug}/chat"]
    if item:
        pages.append(f"/item/{item['id']}")
    if post:
        pages.append(f"/blog/{post['slug']}")
    return pages


def main():
    from playwright.sync_api import sync_playwright

    pages = build_pages()
    issues = []
    n_runs = 0
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        for w, h, name in DEVICES:
            ctx = browser.new_context(viewport={"width": w, "height": h},
                                      is_mobile=True, device_scale_factor=2,
                                      locale="fa-IR")
            page = ctx.new_page()
            errors = []
            page.on("console", lambda m: errors.append(m.text)
                    if m.type == "error"
                    and not any(k in m.text for k in
                                ("openstreetmap", "tile", "unpkg",
                                 "net::ERR_INTERNET", "Automatic fallback",
                                 "VALIDATE_STATUS")) else None)
            page.on("pageerror", lambda e: errors.append(str(e)))
            for path in pages:
                errors.clear()
                page.goto(BASE + path, wait_until="networkidle", timeout=30000)
                page.wait_for_timeout(500)
                n_runs += 1
                r = page.evaluate(CHECK_JS)
                tag = f"{name} {path.split('?')[0]}"
                if r["overflow"] > 1:
                    issues.append(f"{tag}: سرریز افقی {r['overflow']}px")
                if errors:
                    issues.append(f"{tag}: خطای JS: {errors[0][:80]}")
                if r["tap"]:
                    issues.append(f"{tag}: هدف لمسی <44px: {r['tap'][0]}")
                if not r["rtl"]:
                    issues.append(f"{tag}: dir≠rtl")
                if not r["vp"]:
                    issues.append(f"{tag}: متای viewport نیست")
                if r["noAlt"]:
                    issues.append(f"{tag}: {r['noAlt']} تصویر بدون alt")
                if r["noLabel"]:
                    issues.append(f"{tag}: {r['noLabel']} ورودی بدون برچسب")
            ctx.close()
        browser.close()

    print(f"\n\033[1m{len(DEVICES)}×{len(pages)} = {n_runs} اجرا بررسی شد\033[0m")
    if issues:
        # dedupe by (check, path) across devices for a readable report
        seen, uniq = set(), []
        for i in issues:
            key = i.split(": ", 1)[1] + i.split(" ")[1]
            if key not in seen:
                seen.add(key)
                uniq.append(i)
        for i in uniq:
            print(f"  \033[31m✗\033[0m {i}")
        sys.exit(1)
    print("  \033[32m✓ صفر ایراد: سرریز/JS/لمس/RTL/viewport/alt/برچسب.\033[0m")


if __name__ == "__main__":
    main()
