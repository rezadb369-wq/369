# -*- coding: utf-8 -*-
"""
قفل مرحلهٔ م۵ (تعدیل) — بازسازی فاز ۵ (۲۰۲۶-۰۸-۳۱)

  §V1  بن مشتری سرتاسری: ورود موفق → بن از پنل → سشن همان لحظه می‌میرد
       (GET /me به /login برمی‌گردد) → ورود دوباره با پیام «مسدود» رد
       می‌شود → آن‌بن → ورود دوباره موفق. + ردیف audit با customer.mod.
  §V2  بن دکان‌دار: ورود موفق → POST /panel/owner/<id> status=blocked →
       ورود رد با «مسدود» → آن‌بن → ورود موفق.
  §V3  فیلتر لاگ ممیزی + خروجی CSV: seed سه رویداد با action یکتا →
       ?action= فقط همان‌ها را می‌دهد؛ ?detail= هم؛ export CSV دارای
       هدر + همان ردیف‌ها + BOM اکسل؛ days=7 سالم.
  §V4  صف تعدیل یکپارچه /panel/moderation: نظر pending + گزارش open +
       پرسش pending ساخته → هر سه بخش دیده می‌شوند + دکمهٔ سریع
       approve نظر از خود صف کار می‌کند → resolve گزارش هم.

    BZ=http://127.0.0.1:8080 python3 tools/test_panel_mod.py
"""

import os
import sys
import time
import uuid
import http.cookiejar
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db          # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
PREFIX = f"mod5-{uuid.uuid4().hex[:6]}"
XFF = uuid.uuid4().hex[:12]          # fresh rate-limit bucket for this run

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append((label, detail))
        print(f"  \033[31m✗ {label}\033[0m  {detail}")


def head(t):
    print(f"\n\033[1m━━ {t}\033[0m")


class Client:
    """Tiny redirect-following HTTP client with its own cookie jar."""

    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        self.op = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.jar))

    def raw(self, path, data=None):
        req = urllib.request.Request(
            BASE + path, data=data,
            headers={"X-Forwarded-For": XFF,
                     "Content-Type": "application/x-www-form-urlencoded"})
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *a, **k):
                return None
        op2 = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.jar), NoRedirect())
        try:
            r = op2.open(req, timeout=15)
            return r.status, r.read().decode("utf-8", "replace"), dict(r.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace"), dict(e.headers)

    def post(self, path, fields):
        return self.raw(path, urllib.parse.urlencode(fields).encode())

    def get(self, path, follow=True):
        if follow:
            r = self.op.open(BASE + path, timeout=15)
            return r.geturl(), r.read().decode("utf-8", "replace")
        code, body, hdr = self.raw(path)
        return hdr.get("Location", ""), body


def login_post(c, username, password):
    """POST /login/password (the unified password door) — no redirect follow."""
    code, body, _ = c.post("/login/password", {"username": username,
                                               "password": password})
    return code, body


def main():
    tok = db.owner_token()
    admin = Client()
    admin.get(f"/panel?key={urllib.parse.quote(tok)}", follow=False)

    con = db.connect()
    stamp = int(time.time())

    # ------------------------------------------------------------ §V1
    head("م۵/V1 — بن مشتری: سشن می‌میرد، ورود رد، آن‌بن برمی‌گردد")
    uname = f"{PREFIX}-cust"
    con.execute(
        "INSERT INTO customers(phone,name,username,pass_hash,status) "
        "VALUES(?,?,?,?, 'active')",
        (f"0999{stamp % 10**7:07d}", f"مشتری {PREFIX}", uname,
         db.hash_password("pw-م۵")))
    cid = con.execute("SELECT last_insert_rowid()").fetchone()[0]
    con.commit()

    c1 = Client()
    code, body = login_post(c1, uname, "pw-م۵")
    check("ورود مشتری قبل از بن موفق (۳xx)", 300 <= code < 400, f"code={code}")
    ctok = next(c.value for c in c1.jar if c.name == "bzv2_cust")
    check("سشن مشتری برقرار است", db.customer_session_get(ctok) is not None, "")

    code, body, _ = admin.post(f"/panel/customer/{cid}",
                               {"action": "block"})
    st = con.execute("SELECT status FROM customers WHERE id=?",
                     (cid,)).fetchone()["status"]
    check("بن اعمال شد (status=blocked)", st == "blocked", st)
    audit = con.execute(
        "SELECT COUNT(*) FROM audit WHERE action='customer.mod' "
        "AND detail LIKE ?", (f"{cid} block",)).fetchone()[0]
    check("audit با customer.mod ثبت شد", audit >= 1, f"rows={audit}")

    check("سشن همان لحظه مرد (customer_session_get → None)",
          db.customer_session_get(ctok) is None, "session still alive")

    c2 = Client()
    code, body = login_post(c2, uname, "pw-م۵")
    check("ورود مشتری بن‌شده رد (فرم خطا، نه ریدایرکت)", code == 200
          and "مسدود" in body, f"code={code}")

    code, body, _ = admin.post(f"/panel/customer/{cid}",
                               {"action": "unblock"})
    c3 = Client()
    code, body = login_post(c3, uname, "pw-م۵")
    check("بعد از آن‌بن ورود موفق (۳xx)", 300 <= code < 400, f"code={code}")

    # ------------------------------------------------------------ §V2
    head("م۵/V2 — بن دکان‌دار: ورود رد، آن‌بن برمی‌گردد")
    oname = f"{PREFIX}-own"
    con.execute(
        "INSERT INTO owners(phone,name,username,pass_hash,status) "
        "VALUES(?,?,?,?, 'active')",
        (f"0988{stamp % 10**7:07d}", f"دکان‌دار {PREFIX}", oname,
         db.hash_password("pw-م۵")))
    oid = con.execute("SELECT last_insert_rowid()").fetchone()[0]
    con.commit()

    o1 = Client()
    code, body = login_post(o1, oname, "pw-م۵")
    check("ورود دکان‌دار قبل از بن موفق", 300 <= code < 400, f"code={code}")

    code, body, _ = admin.post(f"/panel/owner/{oid}", {"status": "blocked"})
    st = con.execute("SELECT status FROM owners WHERE id=?",
                     (oid,)).fetchone()["status"]
    check("بن دکان‌دار اعمال شد", st == "blocked", st)

    o2 = Client()
    code, body = login_post(o2, oname, "pw-م۵")
    check("ورود دکان‌دار بن‌شده رد با «مسدود»", code == 200
          and "مسدود" in body, f"code={code}")

    code, body, _ = admin.post(f"/panel/owner/{oid}", {"status": "active"})
    o3 = Client()
    code, body = login_post(o3, oname, "pw-م۵")
    check("بعد از آن‌بن ورود موفق", 300 <= code < 400, f"code={code}")

    # ------------------------------------------------------------ §V3
    head("م۵/V3 — فیلتر لاگ ممیزی + خروجی CSV")
    act = f"m5test.{uuid.uuid4().hex[:6]}"
    for i in range(3):
        db.log(act, f"جزئیات-{PREFIX}-{i}")
    other_act = f"zzother.{uuid.uuid4().hex[:6]}"
    db.log(other_act, "unrelated")

    url, body = admin.get(f"/panel/audit?action={urllib.parse.quote(act)}")
    check("فیلتر action: ردیف‌های seed دیده می‌شوند",
          body.count(f"جزئیات-{PREFIX}") >= 3, "seed rows missing")
    check("فیلتر action: ردیف نامرتبط پنهان",
          "unrelated" not in body, "leak")
    check("فرم فیلتر و لینک CSV در صفحه",
          'name="detail"' in body and "/panel/audit/export" in body, "")

    url, body = admin.get(
        f"/panel/audit?action={urllib.parse.quote(act)}"
        f"&detail={urllib.parse.quote('جزئیات-' + PREFIX + '-1')}")
    check("فیلتر detail: فقط ردیف منطبق",
          f"{PREFIX}-1" in body and f"{PREFIX}-0" not in body
          and f"{PREFIX}-2" not in body, "wrong rows visible")

    req = urllib.request.Request(
        BASE + f"/panel/audit/export?action={urllib.parse.quote(act)}",
        headers={"X-Forwarded-For": XFF})
    r = admin.op.open(req, timeout=15)
    csv_body = r.read().decode("utf-8")
    check("CSV: content-type درست",
          "text/csv" in r.headers.get("Content-Type", ""), "")
    check("CSV: BOM اکسل + هدر",
          csv_body.startswith("\ufeff") and csv_body.splitlines()[0].endswith(
              "id,action,detail,created"), "")
    data_lines = [l for l in csv_body.splitlines()[1:] if l.strip()]
    check("CSV: دقیقاً ۳ ردیف seed (ردیف نامرتبط فیلتر شد)",
          len(data_lines) == 3, f"lines={len(data_lines)}")
    check("CSV: جزئیات seed موجود", f"جزئیات-{PREFIX}-2" in csv_body, "")

    url, body = admin.get("/panel/audit?days=7")
    check("فیلتر days=7 صفحه را سالم نگه می‌دارد", "گزارش فعالیت‌ها" in body, "")

    # ------------------------------------------------------------ §V4
    head("م۵/V4 — صف تعدیل یکپارچه /panel/moderation")
    biz = db.businesses()[0]
    con.execute(
        "INSERT INTO reviews(biz_id,author,rating,body,status) "
        "VALUES(?,?,?,?, 'pending')",
        (biz["id"], f"نویسنده {PREFIX}", 4, f"متن {PREFIX}"))
    rid = con.execute("SELECT last_insert_rowid()").fetchone()[0]
    con.execute(
        "INSERT INTO reports(kind,target_id,biz_id,reason,body,status) "
        "VALUES('business',?,?,?,?, 'open')",
        (biz["id"], biz["id"], "spam", f"گزارش {PREFIX}"))
    repid = con.execute("SELECT last_insert_rowid()").fetchone()[0]
    con.execute(
        "INSERT INTO questions(biz_id,asker,body,status) "
        "VALUES(?,?,?, 'pending')",
        (biz["id"], f"پرسنده {PREFIX}", f"پرسش {PREFIX}"))
    qid = con.execute("SELECT last_insert_rowid()").fetchone()[0]
    con.commit()

    url, body = admin.get("/panel/moderation")
    check("صف تعدیل باز می‌شود (۲۰۰)", "صف تعدیل" in body, url)
    check("در ناوبری پنل", 'href="/panel/moderation"' in body, "")
    check("نظر pending در صف", f"نویسنده {PREFIX}" in body, "")
    check("گزارش open در صف", db.reason_label("spam") in body, "")
    check("پرسش pending در صف", f"پرسش {PREFIX}" in body, "")
    check("دکمهٔ سریع تأیید نظر در صف",
          f'action="/panel/review/{rid}"' in body, "")

    code, body, _ = admin.post(f"/panel/review/{rid}", {"action": "approve"})
    st = con.execute("SELECT status FROM reviews WHERE id=?",
                     (rid,)).fetchone()["status"]
    check("تأیید سریع نظر از صف کار می‌کند", st == "approved", st)

    code, body, _ = admin.post(f"/panel/report/{repid}",
                               {"action": "resolve"})
    st = con.execute("SELECT status FROM reports WHERE id=?",
                     (repid,)).fetchone()["status"]
    check("رسیدگی سریع گزارش از صف کار می‌کند", st == "resolved", st)

    # ------------------------------------------------------------ cleanup
    con.execute("DELETE FROM reviews WHERE id=?", (rid,))
    con.execute("DELETE FROM reports WHERE id=?", (repid,))
    con.execute("DELETE FROM questions WHERE id=?", (qid,))
    con.execute("DELETE FROM customers WHERE id=?", (cid,))
    con.execute("DELETE FROM owners WHERE id=?", (oid,))
    con.execute("DELETE FROM audit WHERE action IN (?, ?)",
                (act, other_act))
    con.commit()
    con.close()

    print(f"\n\033[1m{'═' * 46}\033[0m")
    print(f"  {ok_n} ✓   {bad_n} ✗")
    if bad_n:
        for lbl, d in FAILS:
            print(f"  ✗ {lbl}  [{d}]")
        sys.exit(1)
    print("  قفل م۵ سبز است.")


if __name__ == "__main__":
    main()
