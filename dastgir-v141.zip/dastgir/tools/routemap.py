#!/usr/bin/env python3
"""routemap.py — فهرست خودکار «هر مسیر در کدام فایل/خط است».

مسیرهای ثبت‌شده در server/*.py را پیدا می‌کند و جدول مارک‌داون می‌سازد
تا عیب‌یابی سریع باشد: «این URL مال کدام فایل است؟» → جدول.

استفاده:
    python3 tools/routemap.py            # چاپ روی خروجی
    python3 tools/routemap.py -o docs/FILE-MAP.md   # نوشتن در فایل
"""
import os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRV = os.path.join(ROOT, "server")

# الگوهای شرط مسیریابی در کد
PATTERNS = [
    re.compile(r'path\s*==\s*"([^"]+)"'),
    re.compile(r'path\s*\.startswith\("([^"]+)"\)'),
    re.compile(r'path\s*\.startswith\(f?"([^"]+)"\)'),
    re.compile(r're\.match\(r"\^([^"\\]+)'),
    re.compile(r'if\s+path\s*==\s*"([^"]+)"'),
]


def scan():
    rows = []  # (prefix, route, file, line)
    for fn in sorted(os.listdir(SRV)):
        if not fn.endswith(".py") or fn.startswith("__"):
            continue
        full = os.path.join(SRV, fn)
        with open(full, encoding="utf-8") as f:
            for ln, line in enumerate(f, 1):
                for pat in PATTERNS:
                    m = pat.search(line)
                    if m:
                        r = m.group(1)
                        if len(r) > 40:
                            continue
                        rows.append((r, fn, ln))
                        break
    return rows


def bucket(route):
    """دسته‌بندی مسیر برای گروه‌بندی جدول."""
    if route.startswith("/panel"):
        return "پنل مدیر (/panel)"
    if route.startswith("/my"):
        return "پنل دکان‌دار (/my)"
    if route.startswith("/me"):
        return "پنل مشتری (/me)"
    if route.startswith("/b/"):
        return "صفحهٔ کسب‌وکار (/b)"
    if route.startswith("/api"):
        return "API"
    if route.startswith("/assets") or route in ("/favicon.ico", "/sw.js",
                                                "/manifest.webmanifest",
                                                "/offline.html", "/robots.txt",
                                                "/sitemap.xml", "/qr/"):
        return "فایل‌های ثابت / PWA"
    return "عمومی / متفرقه"


def render(rows):
    groups = {}
    for r, fn, ln in rows:
        key = bucket(r)
        groups.setdefault(key, []).append((r, fn, ln))
    out = []
    out.append("# نقشهٔ مسیرها — هر URL کجاست؟\n")
    out.append("> تولید خودکار با `python3 tools/routemap.py -o docs/FILE-MAP.md` "
               "— اگر مسیر تازه‌ای اضافه شد، دوباره اجرا کنید.\n")
    order = ["پنل مدیر (/panel)", "پنل دکان‌دار (/my)", "پنل مشتری (/me)",
             "صفحهٔ کسب‌وکار (/b)", "API", "فایل‌های ثابت / PWA",
             "عمومی / متفرقه"]
    for key in order:
        items = groups.get(key)
        if not items:
            continue
        out.append(f"\n## {key}\n")
        out.append("| مسیر | فایل | خط |")
        out.append("|---|---|---|")
        for r, fn, ln in sorted(items, key=lambda x: (x[0] != "/", x[0])):
            if r != "/" and not r.startswith("/"):
                r = "/" + r
            out.append(f"| `{r}` | `server/{fn}` | {ln} |")
    return "\n".join(out) + "\n"


if __name__ == "__main__":
    rows = scan()
    md = render(rows)
    if len(sys.argv) > 1 and sys.argv[1] == "-o":
        out = sys.argv[2]
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with open(out, "w", encoding="utf-8") as f:
            f.write(md)
        print(f"نقشهٔ مسیرها: {len(rows)} ردیف → {out}")
    else:
        print(md)
