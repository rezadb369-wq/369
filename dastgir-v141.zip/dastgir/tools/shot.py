#!/usr/bin/env python3
"""shot.py — اسکرین‌شات سریع صفحه در چند ویوپورت (برای بازبینی طراحی)."""
import sys
from playwright.sync_api import sync_playwright

paths = sys.argv[1:]
vp = sys.argv[2] if len(sys.argv) > 2 else "m390"
SIZE = {"m320": (320, 700), "m390": (390, 844), "d1440": (1440, 900)}
w, h = SIZE.get(vp, SIZE["m390"])

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": w, "height": h})
    pg.goto("http://127.0.0.1:8080" + paths[0], wait_until="networkidle")
    pg.evaluate("document.fonts.ready.then(()=>{})")
    pg.wait_for_timeout(600)
    # full page shot with sticky-safe stitching (viewport chunks)
    out = f"/home/user/audit-v119/evidence/pre_{paths[0].strip('/').replace('/', '_') or 'home'}_{vp}.webp"
    pg.screenshot(path=out, full_page=True)
    print("saved:", out)
    b.close()
