# -*- coding: utf-8 -*-
"""v112 abuse-shield tests.

Simulates remote clients from localhost via X-Forwarded-For (the server only
honours XFF from a loopback peer, which is exactly this test's position) and
proves: normal traffic passes, scanners are 404'd then blocked, attack-tool
UAs are 403'd, rate storms are 429'd then blocked, the panel page reports the
numbers, and a manual unblock works.

Run:  python3 tools/test_abuse.py        (server on :8080)
"""
import os
import sys
import urllib.request
import urllib.error

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
passed = failed = 0
fails = []


def ok(label, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  {G}✓{X} {label}")
    else:
        failed += 1
        fails.append(label)
        print(f"  {R}✗{X} {label}   {detail}")


def req(path, ident=None, ua=None, post=None, key=None):
    url = BASE + path
    data = None
    headers = {"User-Agent": ua or "Mozilla/5.0 (X11; Linux) TestRunner/1.0"}
    if ident:
        headers["X-Forwarded-For"] = ident
    if post is not None:
        body = {**post}
        if key:
            body["key"] = key
        data = urllib.parse.urlencode(body).encode()
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    r = urllib.request.Request(url, data=data, headers=headers)

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None

    try:
        with urllib.request.build_opener(NoRedirect).open(r, timeout=10) as resp:
            return resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


import urllib.parse  # noqa: E402  (used by req)
import random

# fresh identities per run: blocks from a previous run must not mask behaviour
_r = random.Random()
N1 = f"10.{_r.randint(2,250)}.{_r.randint(2,250)}.1"   # normal
N2 = f"10.{_r.randint(2,250)}.{_r.randint(2,250)}.2"   # scanner
N3 = f"10.{_r.randint(2,250)}.{_r.randint(2,250)}.3"   # bad UA
N4 = f"10.{_r.randint(2,250)}.{_r.randint(2,250)}.4"   # storm

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "server"))
import db  # noqa: E402

TOK = db.owner_token()

print(f"\n{B}۱) ترافیک عادی عبور می‌کند{X}")
codes = [req("/", ident=N1)[0] for _ in range(5)]
ok("۵ درخواست عادی = ۲۰۰", codes == [200] * 5, str(codes))
codes = [req("/robots.txt")[0] for _ in range(30)]   # loopback, no XFF
ok("۳۰ درخواست لوپ‌بک بدون هویت جعلی = ۲۰۰", codes == [200] * 30, str(set(codes)))

print(f"\n{B}۲) اسکنر: ۴۰۴ و پس از ۳ ضربه مسدود{X}")
c1, _ = req("/.env", ident=N2)
c2, _ = req("/wp-login.php", ident=N2)
c3, _ = req("/.git/config", ident=N2)
ok("مسیرهای اسکنر ۴۰۴", (c1, c2, c3) == (404, 404, 404), f"{c1},{c2},{c3}")
c4, _ = req("/", ident=N2)
ok("بعد از ۳ ضربه، مسدود (۴۰۳)", c4 == 403, str(c4))

print(f"\n{B}۳) User-Agent ابزار مخرب{X}")
c, _ = req("/", ident=N3, ua="sqlmap/2.6#dev")
ok("sqlmap = ۴۰۳", c == 403, str(c))

print(f"\n{B}۴) طوفان نرخ: ۴۲ و سپس مسدود{X}")
seen = set()
for _ in range(200):
    seen.add(req("/robots.txt", ident=N4)[0])
ok("در بُرست ۲۰۰تایی، ۴۲۹ دیده شد", 429 in seen, str(seen))
c, _ = req("/robots.txt", ident=N4)
ok("ادامهٔ طوفان = مسدود (۴۰)", c == 403, str(c))

print(f"\n{B}۵) صفحهٔ ترافیک پنل{X}")
c, _ = req("/panel/traffic")
ok("بدون کلید ۴۰۳", c == 403, str(c))
c, body = req(f"/panel/traffic?key={TOK}")
ok("با کلید ۲۰۰", c == 200, str(c))
ok("عنوان سپر هست", "سپر ضد-اسپم" in body)
ok("آی‌پی اسکنر در گزارش هست", N2 in body)
ok("آی‌پی طوفان در گزارش هست", N4 in body)

print(f"\n{B}۶) برداشتن دستی مسدودی{X}")
c, _ = req("/panel/traffic/unblock", post={"ident": N2}, key=TOK)
ok("درخواست برداشتن = ۳۰۳", c == 303, str(c))
c, _ = req("/", ident=N2)
ok("بعد از برداشتن، دوباره ۲۰۰", c == 200, str(c))
c, _ = req("/panel/traffic/unblock", post={"ident": N4})
ok("بدون کلید ۴۰", c == 403, str(c))

print(f"\n{B}{'=' * 58}{X}")
if failed:
    print(f"{B}{R}  {passed} موفق، {failed} ناموفق{X}")
    for f in fails:
        print("    ✗", f)
else:
    print(f"{B}{G}  همه موفق — {passed} آزمون، ۰ ناموفق{X}")
sys.exit(1 if failed else 0)
