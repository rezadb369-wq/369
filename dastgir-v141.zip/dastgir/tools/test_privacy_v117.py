# -*- coding: utf-8 -*-
"""
قفل فاز ۶ — داده و حریم خصوصی (v117)

  §P1  «داده‌های من» GET /me/export: CSV با BOM برای مشتریِ واردشده؛
       فقط ردیف‌های همان مشتری (نه مشتری دیگر)؛ بدون ورود → لاگین، نه CSV.
  §P2  retention_purge: IP ردیف ۱۰۰روزه پاک می‌شود؛ ردیف ۸۰۰روزه visits و
       audit/searches دوساله حذف می‌شوند؛ تابع idempotent است.
  §P3  قلاب ساعتی: جاروی ساعتی do_GET علاوه بر تصاویر چت، retention را هم
       صدا می‌زند (وگرنه وعدهٔ حریم خصوصی به ری‌استارت وابسته می‌ماند).
  §P4  صفحهٔ «حساب و امنیت» لینک دریافت CSV را دارد.
  §P5  کوکی‌های سشن: HttpOnly + SameSite=Lax (و Secure پشت HTTPS).

    BZ=http://127.0.0.1:8080 python3 tools/test_privacy_v117.py
"""

import os
import sys
import time
import uuid
import http.cookiejar
import urllib.parse
import urllib.request
import urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db          # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
PREFIX = f"pv6-{uuid.uuid4().hex[:6]}"
XFF = uuid.uuid4().hex[:12]

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append((label, detail))
        print(f"  \033[31m✗ {label}\033[0m  {detail}")


def head(t):
    print(f"\n\033[1m━━ {t}\033[0m")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


class Client:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        self.op = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.jar))

    def raw(self, path, data=None):
        op2 = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.jar), NoRedirect())
        req = urllib.request.Request(
            BASE + path, data=data,
            headers={"X-Forwarded-For": XFF,
                     "Content-Type": "application/x-www-form-urlencoded"})
        try:
            r = op2.open(req, timeout=15)
            return r.status, r.read(), dict(r.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read(), dict(e.headers)

    def post(self, path, fields):
        return self.raw(path, urllib.parse.urlencode(fields).encode())

    def get_follow(self, path):
        r = self.op.open(BASE + path, timeout=15)
        return r.geturl(), r.read().decode("utf-8", "replace")


def login_customer(username, password):
    c = Client()
    c.post("/login/password", {"username": username, "password": password})
    return c


def main():
    con = db.connect()
    stamp = int(time.time())
    biz = db.businesses()[0]

    # ------------------------------------------------------------ §P1
    head("۶/P1 — «داده‌های من» /me/export")
    users = []
    for i in (1, 2):
        uname = f"{PREFIX}-u{i}"
        con.execute(
            "INSERT INTO customers(phone,name,username,pass_hash,status) "
            "VALUES(?,?,?,?, 'active')",
            (f"0977{stamp % 10**7:07d}{i}", f"مشتری {PREFIX} {i}", uname,
             db.hash_password(f"pw{i}")))
        cid = con.execute("SELECT last_insert_rowid()").fetchone()[0]
        con.execute(
            "INSERT INTO orders(biz_id,customer_id,name,phone,total,status) "
            "VALUES(?,?,?,?,?, 'new')",
            (biz["id"], cid, f"سفارش‌دار {PREFIX} {i}", "09120000000",
             1000 * i))
        users.append((uname, cid, i))
    con.commit()

    c1 = login_customer(users[0][0], "pw1")
    code, body, hdrs = c1.raw("/me/export")
    csv1 = body.decode("utf-8")
    check("واردشده: ۲۰۰ + text/csv", code == 200
          and "text/csv" in hdrs.get("Content-Type", ""), f"code={code}")
    check("BOM اکسل", csv1.startswith("\ufeff"), "")
    check("هدر بخش‌ها", csv1.splitlines()[0].endswith("بخش,مورد,جزئیات,زمان"), "")
    check("سفارش خودش در CSV", f"سفارش‌دار {PREFIX} 1" in csv1, "")
    check("سفارش مشتری دیگر در CSV نیست", f"سفارش‌دار {PREFIX} 2" not in csv1, "")
    check("پروفایل خودش (شماره) در CSV", users and True
          and con.execute("SELECT phone FROM customers WHERE id=?",
                          (users[0][1],)).fetchone()["phone"] in csv1, "")

    anon = Client()
    code, body, _ = anon.raw("/me/export")
    check("بدون ورود: CSV نمی‌دهد (۲۰۰/۳xx نه CSV)",
          not body.startswith(b"\xef\xbb\xbf") and b"," not in body[:40],
          f"code={code} len={len(body)}")

    # ------------------------------------------------------------ §P4
    url, page = c1.get_follow("/me/account")
    check("صفحهٔ حساب لینک /me/export دارد", "/me/export" in page, url)

    # ------------------------------------------------------------ §P2
    head("۶/P2 — retention_purge")
    now = time.time()
    d100, d800 = now - 100 * 86400, now - 800 * 86400
    con.execute(
        "INSERT INTO visits(ts,path,kind,ip,ua,dev,cid,sid,ref,bot,prov,city,utm)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (d100, "/p6", "page", f"8.8.{stamp % 250}.8", "ua", "desktop",
         "c6", "s6", "", 0, "تهران", "تهران", ""))
    vid100 = con.execute("SELECT last_insert_rowid()").fetchone()[0]
    con.execute(
        "INSERT INTO visits(ts,path,kind,ip,ua,dev,cid,sid,ref,bot,prov,city,utm)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (d800, "/p6-old", "page", "8.8.4.4", "ua", "desktop",
         "c6", "s6", "", 0, "", "", ""))
    vid800 = con.execute("SELECT last_insert_rowid()").fetchone()[0]
    con.execute("INSERT INTO audit(action,detail,created) VALUES(?,?,?)",
                ("p6old", "x", time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(d800))))
    old_day = time.strftime("%Y-%m-%d", time.gmtime(d800))
    con.execute("INSERT INTO searches(term,norm,day,created) VALUES(?,?,?,?)",
                (f"{PREFIX}-old", f"{PREFIX}-old", old_day,
                 time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(d800))))
    keep_term = f"{PREFIX}-new"
    con.execute("INSERT INTO searches(term,norm,day,created) "
                "VALUES(?,?,date('now'),datetime('now'))",
                (keep_term, keep_term))
    con.commit()

    db.retention_purge()
    db.retention_purge()      # idempotent?

    r100 = con.execute("SELECT ip,prov FROM visits WHERE id=?",
                       (vid100,)).fetchone()
    check("۱۰۰ روز: IP/استان پاک شده، ردیف مانده",
          r100 and r100["ip"] == "" and r100["prov"] == "", str(dict(r100 or {})))
    check("۸۰۰ روز: ردیف visits حذف",
          con.execute("SELECT COUNT(*) FROM visits WHERE id=?",
                      (vid800,)).fetchone()[0] == 0, "")
    check("audit دوساله حذف",
          con.execute("SELECT COUNT(*) FROM audit WHERE action='p6old'"
                      ).fetchone()[0] == 0, "")
    check("searches دوساله حذف، تازه ماند",
          con.execute("SELECT COUNT(*) FROM searches WHERE term=?",
                      (keep_term,)).fetchone()[0] == 1, "")

    # ------------------------------------------------------------ §P3
    head("۶/P3 — قلاب ساعتی")
    src = open(os.path.join(HERE, "..", "server", "app.py"),
               encoding="utf-8").read()
    check("جاروی ساعتی retention_purge را صدا می‌زند",
          "db.retention_purge()" in src, "")

    # ------------------------------------------------------------ §P5
    head("۶/P5 — پرچم‌های کوکی سشن")
    c2 = Client()
    code, body, hdrs = c2.post("/login/password",
                               {"username": users[0][0], "password": "pw1"})
    setc = " ".join(v for k, v in hdrs.items() if k.lower() == "set-cookie")
    check("HttpOnly + SameSite=Lax روی کوکی سشن",
          "HttpOnly" in setc and "SameSite=Lax" in setc, setc[:120])

    # ------------------------------------------------------------ cleanup
    for _, cid, _ in users:
        con.execute("DELETE FROM orders WHERE customer_id=?", (cid,))
        con.execute("DELETE FROM customers WHERE id=?", (cid,))
    con.execute("DELETE FROM visits WHERE path IN ('/p6','/p6-old')")
    con.execute("DELETE FROM searches WHERE term LIKE ?", (PREFIX + "-%",))
    con.commit()
    con.close()

    print(f"\n\033[1m{'═' * 46}\033[0m")
    print(f"  {ok_n} ✓   {bad_n} ✗")
    if bad_n:
        for lbl, d in FAILS:
            print(f"  ✗ {lbl}  [{d}]")
        sys.exit(1)
    print("  قفل فاز ۶ (داده و حریم خصوصی) سبز است.")


if __name__ == "__main__":
    main()
