# -*- coding: utf-8 -*-
"""v68 tests — torob-style price intelligence + divar-style personalization.

Covers: price history trail, trend math, sparkline markup, drop alerts into
the customer notification center, recently-viewed markup hooks and saved
search UI. Server-side truth only; the client-side half is exercised by the
browser suites.
"""
import os, re, sys, time, json
import urllib.parse, urllib.request
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
sys.path.insert(0, HERE)
import db

BASE = os.environ.get("BZ", "http://127.0.0.1:8080")
PASS, FAIL = [], []


def ok(name, cond, detail=""):
    (PASS if cond else FAIL).append((name, detail))
    print(("  ✓ " if cond else "  ✗ ") + name + (f"  [{detail}]" if detail and not cond else ""))


def get(op, path):
    try:
        r = op.open(BASE + path, timeout=15)
        return r.status, r.read().decode("utf-8", "ignore")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")


def main():
    saved_prices = db.get_settings().get("prices_enabled", "0")
    db.set_setting("prices_enabled", "1")
    print("\n" + "═" * 60 + "\n  ۱) تاریخچهٔ قیمت (ترب)\n" + "═" * 60)
    con = db.connect()
    biz = con.execute("SELECT id FROM businesses WHERE status='published' LIMIT 1").fetchone()
    if not biz:   # battery order may have wiped fixtures — stay self-contained
        bid0 = db.save_business({"name": "دکانٔ تست v68", "cat_slug": "cafe",
                                 "status": "published", "phone": "09120009911",
                                 "city": "نجف‌آباد", "address": "تست"})
        biz = {"id": bid0}
    con.close()
    ok("کسب‌وکار منتشرشده موجود است", bool(biz))
    bid = biz["id"]

    iid = db.save_item({"biz_id": bid, "kind": "product", "title": "روغن زیتون بکر یک لیتری",
                        "price": "900000", "price_type": "fixed", "available": 1})
    h = db.price_history(iid)
    ok("اولین قیمت ثبت شد", len(h) == 1 and h[0][0] == 900000, str(h))

    time.sleep(0.01)
    db.save_item({"price": "850000"}, iid)
    time.sleep(0.01)
    db.save_item({"price": "800000"}, iid)
    h = db.price_history(iid)
    ok("هر تغییر قیمت یک ردیف ساخت", len(h) == 3, str(len(h)))
    tr = db.price_trend(iid)
    ok("روند ≈ −۱۱٪", tr is not None and -12 <= tr <= -10, str(tr))
    spark = db.sparkline_svg([p for p, _ in h])
    ok("اسپارک‌لاین SVG ساخته شد", "<polyline" in spark and 'stroke="currentColor"' in spark
   and ('class="spark down"' in spark or 'class="spark up"' in spark), spark[:80])

    print("\n" + "═" * 60 + "\n  ۲) هشدار کاهش قیمت\n" + "═" * 60)
    con = db.connect()
    con.execute("DELETE FROM customers WHERE phone='09120007788'")
    con.commit(); con.close()
    cust = db.customer_by_phone("09120007788", create=True)
    key = db.price_key("روغن زیتون بکر یک لیتری")
    ok("کلید گروه معنادار است", bool(key), key)
    db.alert_set(cust["id"], key, "روغن زیتون بکر یک لیتری")
    ok("اشتراک هشدار ثبت شد", key in db.alert_keys(cust["id"]))

    db.save_item({"price": "700000"}, iid)   # drop -> should fire
    notes = db.connect().execute(
        "SELECT text, link FROM notifications WHERE customer_id=? ORDER BY id DESC LIMIT 1",
        (cust["id"],)).fetchone()
    ok("اعلان کاهش قیمت ساخته شد", bool(notes) and "ارزان‌تر" in notes["text"], str(notes))
    ok("لینک اعلان به مقایسه می‌رود", bool(notes) and notes["link"].startswith("/prices?key="))
    ok("اشتراک پس از اطلاع‌رسانی پاک شد", key not in db.alert_keys(cust["id"]))

    print("\n" + "═" * 60 + "\n  ۳) نشانه‌گذاری صفحه‌ها\n" + "═" * 60)
    op = urllib.request.build_opener()
    c, home = get(op, "/")
    ok("صفحهٔ اول جای ردیف بازدیدها را دارد", 'id="recent-wrap"' in home)
    slug = db.connect().execute(
        "SELECT slug FROM businesses WHERE status='published' LIMIT 1").fetchone()["slug"]
    c, bp = get(op, f"/b/{slug}")
    ok("صفحهٔ کسب‌وکار data-biz-slug دارد", f'data-biz-slug="{slug}"' in bp)
    c, dr = get(op, "/businesses")
    ok("دکمهٔ ذخیرهٔ جست‌وجو هست", 'id="save-search"' in dr)
    ok("شمارندهٔ نتایج برای اسکریپت هست", "data-dir-count" in dr)
    ok("جای چیپ‌های ذخیره‌شده هست", 'id="saved-chips"' in dr)

    print("\n" + "═" * 60 + "\n  ۴) صفحهٔ مقایسه\n" + "═" * 60)
    c, pr = get(op, "/prices")
    ok("صفحهٔ مقایسه باز می‌شود", c == 200)
    con = db.connect()
    biz2 = con.execute("SELECT id FROM businesses WHERE status='published' AND id!=? LIMIT 1",
                       (bid,)).fetchone()
    con.close()
    if biz2:
        db.save_item({"biz_id": biz2["id"], "kind": "product",
                      "title": "روغن زیتون بکر یک لیتری", "price": "950000",
                      "price_type": "fixed", "available": 1})
        c, pr = get(op, "/prices?key=" + urllib.parse.quote(key))
        ok("جزئیات مقایسه باز می‌شود", c == 200)
        ok("تاریخچه/اسپارک‌لاین در جزئیات هست", "price-history" in pr or "spark" in pr)
        ok("فرم هشدار یا راهنمای ورود هست", "/prices/alert" in pr or "وارد شوید" in pr)

    # cleanup our probe rows so other suites see a clean demo state
    con = db.connect()
    con.execute("DELETE FROM items WHERE title='روغن زیتون بکر یک لیتری'")
    con.execute("DELETE FROM customers WHERE phone='09120007788'")
    con.execute("DELETE FROM businesses WHERE name='دکانٔ تست v68'")
    con.commit(); con.close()
    db.set_setting("prices_enabled", saved_prices)

    print("\n" + "═" * 60)
    print(f"  {len(PASS)} موفق ، {len(FAIL)} ناموفق")
    print("═" * 60)
    for name, d in FAIL:
        print("   ✗", name, d)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
