# -*- coding: utf-8 -*-
"""v116-audit phase 3: performance & concurrency bench — stdlib only.

  B1 baseline latency (single client, median/p95) of the heavy pages
  B2 concurrent load: 50 / 200 / 500 clients hammering mixed pages
     → RPS, latency spread, errors, 429s, "database is locked"
  B3 server RSS growth across the run

Loopback traffic is shield-exempt by design (local admin), so this measures
raw server throughput, not the rate limiter (test_abuse covers that).

Run:  python3 tools/bench_load.py [requests_per_client]
"""
import http.client
import os
import statistics
import sys
import threading
import time
import urllib.parse

HOST, PORT = "127.0.0.1", int(os.environ.get("BZPORT", "8080"))
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"

PAGES = None  # filled after db lookup


def one_request(path, conn=None):
    own = conn is None
    if own:
        conn = http.client.HTTPConnection(HOST, PORT, timeout=30)
    t0 = time.perf_counter()
    try:
        conn.request("GET", path, headers={
            "User-Agent": "Mozilla/5.0 BenchLoad/1.0",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive"})
        r = conn.getresponse()
        body = r.read()
        dt = time.perf_counter() - t0
        return r.status, dt, len(body), None
    except Exception as e:  # noqa: BLE001
        return -1, time.perf_counter() - t0, 0, str(e)
    finally:
        if own:
            try:
                conn.close()
            except Exception:
                pass


def pct(vals, p):
    if not vals:
        return 0.0
    s = sorted(vals)
    return s[min(len(s) - 1, int(len(s) * p))]


def server_rss_kb():
    # find the run.py pid owning our port via /proc
    try:
        for pid in os.listdir("/proc"):
            if not pid.isdigit():
                continue
            try:
                with open(f"/proc/{pid}/cmdline", "rb") as f:
                    if b"run.py" in f.read():
                        with open(f"/proc/{pid}/status") as f:
                            for line in f:
                                if line.startswith("VmRSS:"):
                                    return int(line.split()[1])
            except OSError:
                continue
    except OSError:
        pass
    return -1


def bench_single(label, path, n=30):
    times, codes = [], set()
    for _ in range(n):
        st, dt, _, err = one_request(path)
        if st == 200:
            times.append(dt * 1000)
        codes.add(st)
    med = statistics.median(times) if times else -1
    p95 = pct(times, 0.95)
    print(f"  {label:<28} median {med:7.1f}ms  p95 {p95:7.1f}ms  codes={sorted(codes)}")
    return med


def bench_concurrent(clients, per_client, pages):
    results = []
    lock = threading.Lock()

    def worker(i):
        conn = http.client.HTTPConnection(HOST, PORT, timeout=30)
        local = []
        for j in range(per_client):
            st, dt, _, err = one_request(pages[(i + j) % len(pages)], conn)
            local.append((st, dt, err))
        try:
            conn.close()
        except Exception:
            pass
        with lock:
            results.extend(local)

    t0 = time.perf_counter()
    ths = [threading.Thread(target=worker, args=(i,)) for i in range(clients)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    wall = time.perf_counter() - t0

    total = len(results)
    n200 = sum(1 for st, _, _ in results if st == 200)
    n429 = sum(1 for st, _, _ in results if st == 429)
    n5xx = sum(1 for st, _, _ in results if 500 <= st < 600)
    errs = sum(1 for st, _, e in results if st == -1)
    locked = sum(1 for _, _, e in results if e and "locked" in e)
    lat = [dt * 1000 for st, dt, _ in results if st == 200]
    print(f"  {clients:>3} کلاینت × {per_client} = {total:>4} درخواست در {wall:5.1f}s"
          f" → {total / wall:6.1f} RPS | 200:{n200} 429:{n429} 5xx:{n5xx} err:{errs}"
          f" | p50 {pct(lat, .5):6.0f}ms p95 {pct(lat, .95):6.0f}ms max {max(lat) if lat else 0:6.0f}ms"
          + (f" | LOCKED:{locked}" if locked else ""))
    return {"rps": total / wall, "n200": n200, "n429": n429,
            "n5xx": n5xx, "errs": errs, "locked": locked,
            "p95": pct(lat, .95)}


def main():
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    "..", "server"))
    import db
    biz = db._one("SELECT slug FROM businesses WHERE status='published' LIMIT 1")
    slug = biz["slug"] if biz else "nothing"
    pages = ["/", "/businesses", f"/b/{slug}",
             "/businesses?q=" + urllib.parse.quote("آزمون"),
             "/map", "/blog"]

    rss0 = server_rss_kb()
    print(f"\n{B}B1) تأخیر تک‌کاربر (۳۰ درخواست){X}")
    bench_single("خانه /", "/")
    bench_single("فهرست /businesses", "/businesses")
    bench_single("صفحهٔ کسب‌وکار", f"/b/{slug}")
    bench_single("جست‌وجو q=آزمون",
                 "/businesses?q=" + urllib.parse.quote("آزمون"))
    bench_single("نقشه /map", "/map")

    print(f"\n{B}B2) بار موازی{X}")
    per = int(sys.argv[1]) if len(sys.argv) > 1 else 12
    summary = {}
    for clients in (50, 200, 500):
        summary[clients] = bench_concurrent(clients, per, pages)
        time.sleep(1)

    rss1 = server_rss_kb()
    print(f"\n{B}B3) حافظهٔ سرور{X}")
    print(f"  RSS: {rss0}KB → {rss1}KB (رشد {rss1 - rss0 if rss0 > 0 and rss1 > 0 else '?'}KB)")

    bad = (any(s["n5xx"] or s["errs"] or s["locked"] for s in summary.values()))
    print()
    if bad:
        print(f"  {R}خطا/قفل زیر بار دیده شد — بالا را ببینید.{X}")
        sys.exit(1)
    print(f"  {G}بدون ۵xx، بدون خطای اتصال، بدون قفل SQLite.{X}")


if __name__ == "__main__":
    main()
