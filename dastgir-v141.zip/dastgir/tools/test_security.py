# -*- coding: utf-8 -*-
"""v116-audit: dynamic tests for the phase-1 security findings.

Each test locks one fix in place so it can never silently regress:
  F1 open redirect via /alert back=...        -> must stay in-app
  F2 dev OTP visible over the wire            -> hidden once site_url is set
  F3 no HSTS behind an HTTPS proxy            -> header present on https only
  F4 DOM XSS via "recently viewed" innerHTML  -> payload stays inert text

Run:  python3 tools/test_security.py         (server on :8080)
"""
import os
import sys
import random
import urllib.parse
import urllib.request
import urllib.error

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
passed = failed = 0
fails = []


def ok(label, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  {G}✓{X} {label}")
    else:
        failed += 1
        fails.append(label)
        print(f"  {R}✗{X} {label}   {detail}")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def req(path, post=None, headers=None):
    hdrs = {"User-Agent": "Mozilla/5.0 SecuritySuite/1.0"}
    hdrs.update(headers or {})
    data = None
    if post is not None:
        data = urllib.parse.urlencode(post).encode()
        hdrs["Content-Type"] = "application/x-www-form-urlencoded"
    r = urllib.request.Request(BASE + path, data=data, headers=hdrs)
    try:
        with urllib.request.build_opener(NoRedirect).open(r, timeout=10) as resp:
            return resp.status, dict(resp.headers), resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read().decode("utf-8", "replace")


sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "server"))
import db  # noqa: E402

print(f"\n{B}F1) ریدایرکت باز در /alert بسته شد{X}")
st, hdrs, _ = req("/alert", post={"phone": "09120000000", "term": "تست",
                                  "back": "https://evil.example/pwn"})
loc = hdrs.get("Location", "")
ok("POST /alert = 303", st == 303, str(st))
ok("مقصد بیرونی رد شد — داخل سایت ماند",
   loc.startswith("/businesses") and "evil.example" not in loc, loc)
st, hdrs, _ = req("/alert", post={"phone": "09120000000", "term": "تست",
                                  "back": "//evil.example"})
loc = hdrs.get("Location", "")
ok("protocol-relative // هم رد شد",
   loc.startswith("/businesses") and "evil" not in loc, loc)
st, hdrs, _ = req("/alert", post={"phone": "09120000000", "term": "تست",
                                  "back": "/prices?x=1"})
loc = hdrs.get("Location", "")
ok("back مشروع هنوز کار می‌کند", loc.startswith("/prices?x=1&"), loc)

print(f"\n{B}F2) کد OTP روی سیم نشت نمی‌کند{X}")
old_url = db.get_settings().get("site_url", "")
# fresh phone per run: the per-phone OTP rate limit (5/15min) is real and a
# repeated run must not trip it and fake a failure.
PHONE = "0912%07d" % random.randint(0, 9999999)
db.set_setting("site_url", "https://bazarche-test.example")
st, _, body = req("/login", post={"phone": PHONE})
row = db._one("SELECT code FROM otp WHERE phone=?", (db.norm_phone(PHONE),))
ok("OTP صادر شد", bool(row))
if row:
    ok("با site_url تنظیم‌شده کد در HTML نیست", row["code"] not in body)
db.set_setting("site_url", "")
db._run("DELETE FROM otp WHERE phone=?", (db.norm_phone(PHONE),))
st, _, body = req("/login", post={"phone": PHONE})
row = db._one("SELECT code FROM otp WHERE phone=?", (db.norm_phone(PHONE),))
ok("لوپ‌بک محلی (Pydroid) کد را می‌بیند", bool(row) and row["code"] in body)
db.set_setting("site_url", old_url)
db._run("DELETE FROM otp WHERE phone=?", (db.norm_phone(PHONE),))

print(f"\n{B}F3) HSTS پشت پروکسی HTTPS{X}")
st, hdrs, _ = req("/", headers={"X-Forwarded-Proto": "https"})
ok("https → هدر HSTS دارد",
   hdrs.get("Strict-Transport-Security", "").startswith("max-age=31536000"),
   str(hdrs.get("Strict-Transport-Security")))
st, hdrs, _ = req("/")
ok("http معمولی → HSTS ندارد (درست per spec)",
   "Strict-Transport-Security" not in hdrs)

print(f"\n{B}F4) DOM XSS در «اخیراً دیده‌شده» خنثی شد{X}")
try:
    from playwright.sync_api import sync_playwright
    biz = db._one("SELECT slug FROM businesses WHERE status='published' LIMIT 1")
    with sync_playwright() as pw:
        br = pw.chromium.launch()
        pg = br.new_page()
        pg.goto(BASE + "/", wait_until="load")
        payload = '<img src=x onerror="window.__pwned=1">PAYLOAD'
        # stored entry uses a different slug than the page being opened —
        # the widget filters the current business out of its own list. The
        # widget itself renders on the HOME page, so that's where we probe.
        pg.evaluate(
            "(name) => localStorage.setItem('bz_recent',"
            " JSON.stringify([{slug: 'xss-probe', name: name, img: '', ts: 1}]))",
            payload)
        if biz:
            pg.goto(BASE + "/", wait_until="load")
            pg.wait_for_timeout(600)
            pwned = pg.evaluate("() => window.__pwned === 1")
            ok("پیامد XSS اجرا نشد", not pwned)
            shown = pg.evaluate(
                "() => (document.querySelector('.recent-name')||{}).textContent || ''")
            ok("نام مخرب به‌صورت متنِ ساده نمایش داده می‌شود",
               "PAYLOAD" in shown and "<img" in shown, shown[:60])
        br.close()
except ImportError:
    print("  (playwright نصب نیست — این بخش جا افتاد)")

print()
print(f"{B}{'='*58}{X}")
print(f"  موفق: {G}{passed}{X}   ناموفق: "
      f"{(R + str(failed) + X) if failed else '0'}")
if fails:
    print(f"  {R}ناموفق‌ها:{X} " + " · ".join(fails))
    sys.exit(1)
print(f"  {G}همه موفق — یافته‌های امنیتی فاز ۱ قفل شدند.{X}")
