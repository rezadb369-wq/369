# -*- coding: utf-8 -*-
"""
Browser proof for the three reported bugs:

  1. the header must show WHO is signed in, not "ورود / ثبت‌نام"
  2. the hamburger must offer the CURRENT area (panel / my / public)
  3. forms with data-validate must actually submit

Run the server first, then:
    cd tools && BZ=http://127.0.0.1:8080 python3 test_context.py
"""

import os
import sys
import asyncio

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa: E402
from playwright.async_api import async_playwright  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
KEY = db.owner_token()
PH = "09121230000"

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


HEADER_JS = """() => {
  const chip = document.querySelector('.account-chip');
  const hdr = document.querySelector('.header-actions');
  const login = hdr ? Array.from(hdr.querySelectorAll('a'))
      .some(a => (a.getAttribute('href') === '/login')) : false;
  return {
    chip: chip ? chip.innerText.split('\\n').join(' ').trim() : null,
    loginStillShown: login
  };
}"""

MENU_JS = """() => {
  // v134+: on admin pages the header hamburger opens the PANEL drawer
  // (#panel-drawer) — the site chrome deliberately does not re-wire the old
  // #mobile-nav there (that caused the «two menus» bug). Read the container
  // each page actually opens, so the assertions match real behaviour.
  const admin = document.body.classList.contains('page-admin');
  const n = admin ? document.querySelector('#panel-drawer') : document.querySelector('#mobile-nav');
  if (!n) return {missing: true};
  const links = Array.from(n.querySelectorAll('a'));
  const open = admin
    ? (!n.hidden && document.body.classList.contains('panel-drawer-open'))
    : n.classList.contains('is-open');
  const heads = admin
    ? Array.from(n.querySelectorAll('.panel-drawer-head strong')).map(e => e.innerText.trim())
    : Array.from(n.querySelectorAll('.mnav-head')).map(e => e.innerText.trim());
  return {
    open,
    heads,
    panelLinks: links.filter(a => (a.getAttribute('href')||'').indexOf('/panel') === 0).length,
    myLinks: links.filter(a => (a.getAttribute('href')||'').indexOf('/my') === 0).length,
    publicLinks: links.filter(a => (a.getAttribute('href')||'') === '/businesses').length,
    viewSite: links.some(a => (a.getAttribute('href')||'') === '/'),
    logout: admin
      ? !!document.querySelector('a[href*="logout"], form[action*="logout"], [data-logout]')
      : !!n.querySelector('.mnav-logout')
  };
}"""


async def login(pg):
    """Sign in through the real OTP screens, no shortcuts."""
    await pg.goto(BASE + "/login", wait_until="load")
    await pg.wait_for_timeout(500)
    await pg.fill("#ph", PH)
    await pg.click("form[action='/login'] button[type=submit]")
    await pg.wait_for_selector("#otp", timeout=10000)
    row = db._one("SELECT code FROM otp WHERE phone=?", (db.norm_phone(PH),))
    if not row:
        return False
    await pg.fill("#otp", row["code"])
    await pg.wait_for_timeout(300)
    if "/my" not in pg.url:
        try:
            async with pg.expect_navigation(timeout=10000):
                await pg.press("#otp", "Enter")
        except Exception:
            pass
    await pg.wait_for_timeout(600)
    return "/my" in pg.url


async def main():
    global bad_n
    print(f"\n\033[1m\033[36mآزمون بافت هدر و منو — {BASE}\033[0m")

    # ---- clean slate
    db._run("DELETE FROM otp")
    o = db.owner_by_phone(PH)
    if o:
        db.delete_owner(o["id"])
    for b in db.businesses(status=None):
        if b["name"] == "دکانٔ آزمون بافت":
            db.delete_business(b["id"])
    db.rate_clear()

    async with async_playwright() as pw:
        br = await pw.chromium.launch()

        # =============================================== forms really submit
        head("۱) فرم‌های data-validate واقعاً ارسال می‌شوند")
        # v114: real-visit analytics treats headless browsers as bots (they
        # are). This suite plays a REAL visitor, so it now sends a normal
        # browser UA — otherwise section 5 (stats) would legitimately count
        # its own page views as bot traffic.
        HUMAN_UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
        ctx = await br.new_context(viewport={"width": 390, "height": 800},
                                   user_agent=HUMAN_UA)
        pg = await ctx.new_page()
        signed = await login(pg)
        check("ورود با کد پیامکی از طریق فرم مرورگر", signed, pg.url)
        check("حساب در پایگاه داده ساخته شد",
              db.owner_by_phone(PH) is not None, "")

        owner = db.owner_by_phone(PH)
        cat = db.categories()[0]["slug"]
        BID = db.save_business({"name": "دکانٔ آزمون بافت", "cat_slug": cat,
                                "phone": PH, "status": "published",
                                "owner_id": owner["id"]})
        SLUG = db.business(bid=BID)["slug"]

        # a public form: post a review through the browser
        n0 = len(db.reviews(biz_id=BID))
        await pg.goto(BASE + f"/b/{SLUG}", wait_until="load")
        await pg.wait_for_timeout(700)
        await pg.fill("#rv-name", "آزمون مرورگر")
        await pg.fill("#rv-text", "این نظر از طریق فرم واقعی مرورگر ثبت شد.")
        try:
            async with pg.expect_navigation(timeout=10000):
                await pg.click("form[action='/b/%s/review'] button[type=submit]" % SLUG)
        except Exception:
            pass
        await pg.wait_for_timeout(600)
        n1 = len(db.reviews(biz_id=BID))
        check("ثبت نظر از فرم مرورگر در پایگاه داده نشست", n1 == n0 + 1,
              f"{n0} -> {n1}")

        # =============================================== header signed-in
        head("۲) هدر وضعیت ورود را نشان می‌دهد")
        for label, url in [("خانه", "/"), ("پنل من", "/my"),
                           ("پنل مدیریت", "/panel?key=" + KEY)]:
            await pg.goto(BASE + url, wait_until="load")
            await pg.wait_for_timeout(600)
            r = await pg.evaluate(HEADER_JS)
            check(f"[{label}] نشان «وارد شده‌اید» دیده می‌شود",
                  r["chip"] is not None and "وارد شده" in (r["chip"] or ""),
                  str(r["chip"]))
            check(f"[{label}] دکمهٔ «ورود / ثبت‌نام» دیگر نیست",
                  not r["loginStillShown"], "هنوز نمایش داده می‌شود")

        # =============================================== hamburger context
        head("۳) منوی سه‌خط بخش‌های همان ناحیه را می‌دهد")
        for label, url, want in [("سایت عمومی", "/", "public"),
                                 ("پنل من", "/my", "my"),
                                 ("پنل مدیریت", "/panel?key=" + KEY, "panel")]:
            await pg.goto(BASE + url, wait_until="load")
            await pg.wait_for_timeout(600)
            await pg.click("[data-nav-toggle]")
            await pg.wait_for_timeout(400)
            m = await pg.evaluate(MENU_JS)
            check(f"[{label}] منو باز می‌شود", m.get("open"), str(m))
            if want == "panel":
                # the panel drawer replaces the site menu on admin pages
                check("[پنل مدیریت] پیوند «مشاهدهٔ سایت اصلی» هست",
                      m.get("viewSite"), str(m.get("viewSite")))
            else:
                check(f"[{label}] لینک‌های سایت عمومی همیشه هست",
                      m.get("publicLinks", 0) >= 1, str(m))
            if want == "panel":
                check("[پنل مدیریت] بخش‌های پنل در منو هست",
                      m.get("panelLinks", 0) >= 20, f"{m.get('panelLinks')} لینک")
                check("[پنل مدیریت] عنوان بخش نمایش داده می‌شود",
                      any("پنل مدیریت" in h for h in m.get("heads", [])),
                      str(m.get("heads")))
            elif want == "my":
                check("[پنل من] بخش‌های کسب‌وکار من در منو هست",
                      m.get("myLinks", 0) >= 7, f"{m.get('myLinks')} لینک")
                check("[پنل من] عنوان بخش نمایش داده می‌شود",
                      any("کسب‌وکار من" in h for h in m.get("heads", [])),
                      str(m.get("heads")))
            check(f"[{label}] دکمهٔ خروج در منو هست", m.get("logout"), str(m))

        # =============================================== logout
        head("۴) خروج از حساب")
        # On a phone the header logout is hidden behind `hide-mobile`; the
        # real exit lives in the hamburger, so use that — the same path a
        # person on a phone would take.
        await pg.goto(BASE + "/", wait_until="load")
        await pg.wait_for_timeout(500)
        await pg.click("[data-nav-toggle]")
        await pg.wait_for_timeout(400)
        try:
            async with pg.expect_navigation(timeout=10000):
                await pg.click("#mobile-nav .mnav-logout")
        except Exception:
            pass
        await pg.wait_for_timeout(700)
        r = await pg.evaluate(HEADER_JS)
        check("پس از خروج، «ورود / ثبت‌نام» برمی‌گردد", r["loginStillShown"],
              str(r))
        check("نشان حساب دیگر نیست", r["chip"] is None, str(r["chip"]))

        # =============================================== stats really count
        head("۵) آمار واقعاً شمرده می‌شود")
        ev0 = db.stats_for(BID, 30)["view"]
        for _ in range(3):
            await pg.goto(BASE + f"/b/{SLUG}", wait_until="load")
            await pg.wait_for_timeout(250)
        ev1 = db.stats_for(BID, 30)["view"]
        check("بازدید صفحه در جدول events ثبت شد", ev1 >= ev0 + 3,
              f"{ev0} -> {ev1}")
        check("ستون views کسب‌وکار هم بالا رفت",
              db.business(bid=BID)["views"] >= 3,
              str(db.business(bid=BID)["views"]))
        check("سری روزانه روز جاری را پر دارد",
              any(v for _d, v in db.stats_for(BID, 30)["series"]), "")

        s0 = db.search_totals(30)["total"]
        await pg.goto(BASE + "/businesses?q=" + "%D8%A2%D8%B2%D9%85%D9%88%D9%86",
                      wait_until="load")
        await pg.wait_for_timeout(500)
        check("جست‌وجو در آمار ثبت شد", db.search_totals(30)["total"] > s0,
              f"{s0} -> {db.search_totals(30)['total']}")

        await br.close()

    # ---- cleanup
    for b in db.businesses(status=None):
        if b["name"] == "دکانٔ آزمون بافت":
            db.delete_business(b["id"])
    o = db.owner_by_phone(PH)
    if o:
        db.delete_owner(o["id"])
    db.clear_searches()
    db.rate_clear()

    print(f"\n\033[1m{'='*56}\033[0m")
    if bad_n == 0:
        print(f"\033[1m\033[32m  همه موفق — {ok_n} آزمون، ۰ ناموفق\033[0m")
    else:
        print(f"\033[1m\033[31m  {ok_n} موفق، {bad_n} ناموفق\033[0m")
        for f in FAILS:
            print(f"    • {f}")
    print(f"\033[1m{'='*56}\033[0m\n")
    return 1 if bad_n else 0


sys.exit(asyncio.run(main()))
