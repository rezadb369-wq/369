# -*- coding: utf-8 -*-
"""
تست بار ۱۰۰۰ کاربر — v117/فاز۸ (۲۰۲۶-۰۸-۳۱)

  فاز R (واقع‌گرایانه): ۱۰۰۰ کاربر مجازی که در ۵ ثانیه وارد می‌شوند؛ هر کدام
      یک نشست مرور واقعی (۵ صفحه با مکث فکری ۱۰۰-۴۰۰ms) دارد. هر کاربر
      IP یکتا (X-Forwarded-For) و اتصال keep-alive خودش را دارد.
  فاز T (رمبش هم‌زمان): ۳ دور، هر دور ۱۰۰۰ درخواست «هم‌زمان» روی یک سد
      (بدترین حالت: پیامک انبوه/رپورتاژ) — اندازه‌گیری صف و دنبالهٔ تأخیر.

  معیار سلامت: صفر خطای ۵xx، صفر «database is locked»، صفر اتصال رد‌شده در فاز R.

    python3 tools/bench_1000.py
"""

import http.client
import json
import os
import random
import resource
import statistics
import sys
import threading
import time
import urllib.parse

HOST, PORT = "127.0.0.1", int(os.environ.get("BZPORT", "8080"))
N_USERS = int(os.environ.get("BENCH_USERS", "1000"))
G, R, B, X, Y = "\033[32m", "\033[31m", "\033[1m", "\033[0m", "\033[33m"


def _raise_fds():
    soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    resource.setrlimit(resource.RLIMIT_NOFILE, (min(16384, hard), hard))
    return soft, min(16384, hard)


def server_rss_kb():
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            with open(f"/proc/{pid}/cmdline", "rb") as f:
                cmd = f.read().decode("utf-8", "replace")
            if "run.py" in cmd:
                with open(f"/proc/{pid}/status") as f:
                    for line in f:
                        if line.startswith("VmRSS:"):
                            return int(line.split()[1])
        except OSError:
            continue
    return -1


def site_pages():
    """میکس واقعی صفحات از دیتای زندهٔ سایت."""
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    "..", "server"))
    import db
    con = db.connect()
    slug = con.execute("SELECT slug FROM businesses WHERE status='published' "
                       "ORDER BY id LIMIT 1").fetchone()["slug"]
    item = con.execute("SELECT i.id FROM items i JOIN businesses b "
                       "ON b.id=i.biz_id WHERE b.status='published' "
                       "LIMIT 1").fetchone()["id"]
    con.close()
    q = urllib.parse.quote("کبابی")
    return ["/", "/businesses", "/catalog", "/map", "/login",
            f"/businesses?q={q}", f"/b/{slug}", f"/item/{item}",
            "/assets/css/pages.css?v117"]


def pct(vals, p):
    if not vals:
        return 0.0
    vals = sorted(vals)
    return vals[min(len(vals) - 1, int(len(vals) * p / 100))]


class Stats:
    def __init__(self):
        self.lock = threading.Lock()
        self.status = {}
        self.lat = []
        self.errors = []
        self.t0 = None
        self.t1 = None

    def rec(self, status, dt):
        with self.lock:
            self.status[status] = self.status.get(status, 0) + 1
            self.lat.append(dt)

    def err(self, kind):
        with self.lock:
            self.errors.append(kind)


def one(conn, path, stats):
    t0 = time.perf_counter()
    try:
        conn.request("GET", path, headers={
            "User-Agent": "Mozilla/5.0 Bench1000/1.0",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive"})
        r = conn.getresponse()
        r.read()
        stats.rec(r.status, time.perf_counter() - t0)
        return True
    except Exception as e:                    # noqa: BLE001
        stats.rec(-1, time.perf_counter() - t0)
        stats.err(type(e).__name__ + (f":{e}" if len(str(e)) < 40 else ""))
        return False


def phase_realistic(pages):
    print(f"\n{B}━━ فاز R — {N_USERS} کاربر واقع‌گرایانه (ورود تدریجی ۵ ثانیه) ━━{X}")
    stats = Stats()
    rss0 = server_rss_kb()
    stats.t0 = time.time()
    rng = random.Random(369)

    def worker(i):
        time.sleep(rng.random() * 5)                 # ramp-in over 5s
        ip = f"5.100.{(i // 250) % 250}.{i % 250 + 1}"   # هر کاربر یک IP
        pages_i = rng.sample(pages, 5)
        conn = None
        try:
            conn = http.client.HTTPConnection(HOST, PORT, timeout=45)
            for p in pages_i:
                if conn is None:
                    conn = http.client.HTTPConnection(HOST, PORT, timeout=45)
                if not one(conn, p, stats):
                    try:
                        conn.close()
                    except Exception:
                        pass
                    conn = None                      # one retry with fresh conn
                    conn = http.client.HTTPConnection(HOST, PORT, timeout=45)
                    one(conn, p, stats)
                time.sleep(rng.uniform(0.1, 0.4))    # think time
        except Exception as e:                       # noqa: BLE001
            stats.err("worker:" + type(e).__name__)
        finally:
            if conn:
                try:
                    conn.close()
                except Exception:
                    pass

    ths = [threading.Thread(target=worker, args=(i,), daemon=True)
           for i in range(N_USERS)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    stats.t1 = time.time()
    report(stats, rss0)
    return stats


def phase_thunder(pages):
    print(f"\n{B}━━ فاز T — رمبش: ۳ دور × {N_USERS} درخواست هم‌زمان ━━{X}")
    allstats = []
    for rnd in range(3):
        barrier = threading.Barrier(N_USERS + 1)
        stats = Stats()

        def worker():
            conn = http.client.HTTPConnection(HOST, PORT, timeout=60)
            barrier.wait()
            one(conn, "/", stats)
            try:
                conn.close()
            except Exception:
                pass

        ths = [threading.Thread(target=worker, daemon=True)
               for _ in range(N_USERS)]
        for t in ths:
            t.start()
        barrier.wait()
        stats.t0 = time.time()
        for t in ths:
            t.join()
        stats.t1 = time.time()
        print(f"  دور {rnd + 1}: ", end="")
        report_inline(stats)
        allstats.append(stats)
        time.sleep(1.5)
    return allstats


def report_inline(stats):
    n = sum(stats.status.values())
    bad = {k: v for k, v in stats.status.items() if k >= 500 or k < 0}
    healthy = not bad and not stats.errors
    lat = stats.lat
    print(f"{n} درخواست در {stats.t1 - stats.t0:4.1f}s "
          f"({n / (stats.t1 - stats.t0):6.0f} rps) | "
          f"p50={pct(lat, 50) * 1000:4.0f}ms p95={pct(lat, 95) * 1000:4.0f}ms "
          f"p99={pct(lat, 99) * 1000:4.0f}ms max={max(lat) * 1000:6.0f}ms | "
          f"۵xx/خطا: {sum(bad.values()) + len(stats.errors)}"
          f"{G + ' ✓' + X if healthy else R + ' ✗' + X}")
    if stats.errors:
        from collections import Counter
        print(f"     خطاها: {dict(Counter(stats.errors))}")


def report(stats, rss0):
    n = sum(stats.status.values())
    wall = stats.t1 - stats.t0
    lat = stats.lat
    print(f"  {n} درخواست در {wall:.1f}s — میانگین {n / wall:.0f} rps")
    print(f"  تأخیر: p50={pct(lat, 50) * 1000:.0f}ms  p95={pct(lat, 95) * 1000:.0f}ms  "
          f"p99={pct(lat, 99) * 1000:.0f}ms  max={max(lat) * 1000:.0f}ms")
    hist = dict(sorted(stats.status.items(), key=lambda kv: -kv[1]))
    print(f"  کدها: {hist}")
    if stats.errors:
        from collections import Counter
        print(f"  {R}خطاها ({len(stats.errors)}):{X} {dict(Counter(stats.errors))}")
    rss1 = server_rss_kb()
    print(f"  RSS سرور: {rss0} → {rss1} KB ({rss1 - rss0:+d})")
    s5 = sum(v for k, v in stats.status.items() if k >= 500)
    locked = sum(1 for e in stats.errors if "locked" in e.lower())
    conn_err = len(stats.errors)
    if s5 or locked or conn_err:
        print(f"  {R}✗ ناسالم: ۵xx={s5} locked={locked} خطای اتصال={conn_err}{X}")
    else:
        print(f"  {G}✓ صفر ۵xx، صفر قفل DB، صفر خطای اتصال{X}")


def main():
    soft, new = _raise_fds()
    print(f"fd limit: {soft} → {new}")
    pages = site_pages()
    print(f"میکس صفحات ({len(pages)}): {', '.join(pages[:6])} …")
    r = phase_realistic(pages)
    phase_thunder(pages)
    n5 = sum(v for k, v in r.status.items() if k >= 500)
    if n5 or r.errors:
        sys.exit(1)
    print(f"\n{G}{B} نتیجهٔ فاز واقع‌گرایانه: سالم — ۱۰۰۰ کاربر بدون خطا {X}")


if __name__ == "__main__":
    main()
