# -*- coding: utf-8 -*-
"""
Parity: app.js openState() vs db.open_state().

The "open now" rule is implemented twice — once in Python so the first paint
is right even with JavaScript off, once in JavaScript so a page left open
stays right. Two implementations of one rule drift silently unless something
compares them, so this drives the REAL browser function through a matrix of
fixtures, days and edge-case times and demands identical answers.

    python3 -u run.py            (or any server on :8003)
    python3 tools/test_open_parity.py
"""
import os, sys, json, datetime
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db
from playwright.sync_api import sync_playwright

FIX = {
 "simple":  {d:[["09:00","21:00"]] for d in db.DAY_KEYS},
 "late":    {d:[["20:00","02:00"]] for d in db.DAY_KEYS},
 "split":   {d:[["08:30","13:00"],["17:00","20:00"]] for d in db.DAY_KEYS},
 "frioff":  {d:[["09:00","18:00"]] for d in db.DAY_KEYS if d!="fri"},
 "empty":   {},
}
TIMES=["00:15","02:00","05:45","08:29","08:30","09:00","12:00","13:00",
       "16:59","17:00","19:30","20:00","20:59","21:00","23:59"]
DAYS=["sat","sun","mon","tue","wed","thu","fri"]

def at(day,hhmm):
    want=db.DAY_KEYS.index(day)
    base=db.iran_now().replace(second=0,microsecond=0)
    base+=datetime.timedelta(days=(want-base.weekday())%7)
    h,m=map(int,hhmm.split(":")); return base.replace(hour=h,minute=m)

cases=[]
for name,hm in FIX.items():
    for d in DAYS:
        for t in TIMES:
            n=at(d,t)
            cases.append({"fix":name,"day":d,"time":t,
                          "hours":json.dumps(hm),
                          # `n` is an Iran WALL-CLOCK time. The browser runs
                          # in UTC here, and iranNow() adds the offset itself,
                          # so hand it the matching UTC instant (W - 3:30) or
                          # the offset gets applied twice.
                          "iso":(n - datetime.timedelta(minutes=db.IRAN_OFFSET_MIN))
                                 .strftime("%Y-%m-%dT%H:%M:%S")+"Z",
                          "py":db.open_state({"hours_map":hm},n)["state"]})

with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page()
    BASE=os.environ.get("BZ","http://127.0.0.1:8080").rstrip("/")
    pg.goto(BASE+"/businesses"); pg.wait_for_load_state("networkidle")
    # freeze the clock per-case, then ask the page's own openState()
    js = """(cases) => cases.map(c => {
        const RealDate = Date;
        const fixed = new RealDate(c.iso);
        // openState() calls iranNow() -> new Date(); stub it for this call
        class D extends RealDate {
          constructor(...a){ if(!a.length) return new RealDate(fixed); return new RealDate(...a); }
          static now(){ return fixed.getTime(); }
        }
        globalThis.Date = D;
        let st;
        try { st = window.__openState(c.hours); } finally { globalThis.Date = RealDate; }
        return st ? st.state : 'ERR';
      })"""
    # expose the module-scoped function
    got = pg.evaluate("() => typeof window.__openState")
    print("openState exposed?", got)
    if got != "function":
        print("NOT EXPOSED — cannot compare"); br.close(); sys.exit(2)
    js_states = pg.evaluate(js, cases)
    br.close()

bad=[(c,j) for c,j in zip(cases,js_states) if c["py"]!=j]
print(f"\n\033[1m{'='*58}\033[0m")
if bad:
    print(f"\033[1m\033[31m  {len(cases)-len(bad)} موفق، {len(bad)} ناموفق\033[0m")
else:
    print(f"\033[1m\033[32m  همه موفق — {len(cases)} ترکیب، صفر اختلاف\033[0m")
print(f"\033[1m{'='*58}\033[0m")
for c,j in bad[:15]:
    print(f"  {c['fix']:8s} {c['day']} {c['time']}  py={c['py']:8s} js={j}")
sys.exit(1 if bad else 0)
