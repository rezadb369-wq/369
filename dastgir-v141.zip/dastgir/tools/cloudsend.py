#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cloudsend.py — ارسال امن به فضای ابری (فقط کتابخانهٔ استاندارد پایتون)
=======================================================================

دو کانال مستقل، بدون هیچ وابستگی خارجی (urllib + hashlib + hmac):

  ۱) تلگرام (Bot API)
       · getMe()          — تست صحت توکن
       · sendMessage()    — پیام متنی (هشدارها)
       · sendDocument()   — آپلود فایل (بکاپ) — سقف ۵۰ مگابایت برای بوت‌ها

  ۲) ذخیره‌سازی S3-سازگار (آروان‌کلاد، لیارا، MinIO، AWS)
       · PUT/DELETE با امضای AWS Signature V4 — بدون نیاز به boto3

توکن تلگرام از جدول settings دیتابیس (tg_token / tg_chat_id) یا متغیرهای
محیطی BZ_TG_TOKEN / BZ_TG_CHAT_ID خوانده می‌شود. تنظیمات S3 فقط از متغیرهای
محیطی BZ_S3_* می‌آیند. هیچ‌کدام خطا پرتاب نمی‌کنند — همیشه (ok, detail).
"""

import datetime
import hashlib
import hmac
import json
import os
import sqlite3
import urllib.parse
import urllib.request
import uuid

TIMEOUT = 60
TG_UPLOAD_LIMIT = 50 * 1024 * 1024   # سقف آپلود بوت تلگرام: ۵۰ مگابایت


# ============================================================================
#  تلگرام
# ============================================================================
def _tg_post(token, method, fields=None, file_field=None, timeout=TIMEOUT):
    """POST عمومی به Bot API. fields = dict؛ file_field = (name, path, mime)."""
    url = f"https://api.telegram.org/bot{urllib.parse.quote(token)}/{method}"
    if file_field is None:
        payload = urllib.parse.urlencode(fields or {}).encode("utf-8")
        req = urllib.request.Request(
            url, data=payload,
            headers={"Content-Type": "application/x-www-form-urlencoded"})
    else:
        fname, fpath, fmime = file_field
        boundary = "----bazarche" + uuid.uuid4().hex
        parts = []
        for k, v in (fields or {}).items():
            parts.append((f"--{boundary}\r\n"
                          f'Content-Disposition: form-data; name="{k}"\r\n\r\n'
                          f"{v}\r\n").encode("utf-8"))
        parts.append((f"--{boundary}\r\n"
                      f'Content-Disposition: form-data; name="{fname}"; '
                      f'filename="{os.path.basename(fpath)}"\r\n'
                      f"Content-Type: {fmime}\r\n\r\n").encode("utf-8"))
        with open(fpath, "rb") as f:
            parts.append(f.read())
        parts.append(f"\r\n--{boundary}--\r\n".encode("utf-8"))
        body = b"".join(parts)
        req = urllib.request.Request(
            url, data=body,
            headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        if data.get("ok"):
            return True, "ok"
        return False, f"telegram: {data.get('description', 'unknown')}"[:200]
    except Exception as e:
        return False, f"telegram: {e}"[:200]


def telegram_get_me(token):
    """تست توکن — نام ربات را برمی‌گرداند."""
    if not token:
        return False, "پیکربندی نشده (tg_token خالی است)"
    ok, detail = _tg_post(token, "getMe")
    if ok:
        return True, "توکن معتبر است"
    return False, detail


def telegram_send_text(token, chat_id, text):
    if not token or not chat_id:
        return False, "پیکربندی نشده (tg_token/tg_chat_id خالی است)"
    return _tg_post(token, "sendMessage",
                    {"chat_id": chat_id, "text": text,
                     "disable_web_page_preview": "true"})


def telegram_send_file(token, chat_id, path, caption=""):
    if not token or not chat_id:
        return False, "پیکربندی نشده (tg_token/tg_chat_id خالی است)"
    if os.path.getsize(path) > TG_UPLOAD_LIMIT:
        return False, (f"حجم فایل بیش از سقف ۵۰ مگابایت بوت تلگرام است "
                       f"({os.path.getsize(path) // (1024 * 1024)}MB)")
    return _tg_post(token, "sendDocument",
                    {"chat_id": chat_id, "caption": caption},
                    file_field=("document", path, "application/zip"),
                    timeout=300)


# ============================================================================
#  S3-سازگار (امضای AWS Signature V4)
# ============================================================================
def _aws_sign(secret, datestamp, region, service, string_to_sign):
    def hm(key, msg):
        return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()
    k_date = hm(("AWS4" + secret).encode("utf-8"), datestamp)
    k_region = hm(k_date, region)
    k_service = hm(k_region, service)
    k_signing = hm(k_service, "aws4_request")
    return hmac.new(k_signing, string_to_sign.encode("utf-8"),
                    hashlib.sha256).hexdigest()


def _s3_req(method, endpoint, region, bucket, key, access, secret, body=b""):
    """یک درخواست امضاشدهٔ S3 (PUT/DELETE/…). -> (ok, detail)."""
    endpoint = endpoint.strip().rstrip("/")
    if not endpoint.startswith("http"):
        endpoint = "https://" + endpoint
    host = urllib.parse.urlparse(endpoint).netloc
    safe_key = urllib.parse.quote(key.lstrip("/"), safe="/")
    payload_hash = hashlib.sha256(body).hexdigest()
    now = datetime.datetime.utcnow()
    amzdate = now.strftime("%Y%m%dT%H%M%SZ")
    datestamp = now.strftime("%Y%m%d")
    canonical_uri = "/" + bucket + "/" + safe_key
    canonical_headers = (f"host:{host}\n"
                         f"x-amz-content-sha256:{payload_hash}\n"
                         f"x-amz-date:{amzdate}\n")
    signed_headers = "host;x-amz-content-sha256;x-amz-date"
    canonical_request = "\n".join([method, canonical_uri, "",
                                   canonical_headers, signed_headers,
                                   payload_hash])
    scope = f"{datestamp}/{region}/s3/aws4_request"
    string_to_sign = "\n".join(["AWS4-HMAC-SHA256", amzdate, scope,
                                hashlib.sha256(
                                    canonical_request.encode()).hexdigest()])
    signature = _aws_sign(secret, datestamp, region, "s3", string_to_sign)
    authorization = (f"AWS4-HMAC-SHA256 Credential={access}/{scope}, "
                     f"SignedHeaders={signed_headers}, Signature={signature}")
    url = f"{endpoint}/{bucket}/{safe_key}"
    req = urllib.request.Request(
        url, data=body, method=method,
        headers={"x-amz-date": amzdate,
                 "x-amz-content-sha256": payload_hash,
                 "Authorization": authorization,
                 "Content-Type": "application/octet-stream"})
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            r.read()
        return True, f"{method} ok ({len(body)} bytes)"
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode("utf-8", "replace")[:200]
        except Exception:
            detail = ""
        return False, f"s3 HTTP {e.code}: {detail}"
    except Exception as e:
        return False, f"s3: {e}"[:200]


def _s3_env():
    """-> (endpoint, region, bucket, access, secret) یا None اگر ناقص باشد."""
    e = os.environ.get("BZ_S3_ENDPOINT", "").strip()
    r = os.environ.get("BZ_S3_REGION", "").strip() or "ir-thr-at1"
    b = os.environ.get("BZ_S3_BUCKET", "").strip()
    a = os.environ.get("BZ_S3_ACCESS", "").strip()
    s = os.environ.get("BZ_S3_SECRET", "").strip()
    if not (e and b and a and s):
        return None
    return e, r, b, a, s


def s3_put(endpoint, region, bucket, key, path, access, secret):
    with open(path, "rb") as f:
        body = f.read()
    return _s3_req("PUT", endpoint, region, bucket, key, access, secret,
                   body=body)


def s3_delete(endpoint, region, bucket, key, access, secret):
    return _s3_req("DELETE", endpoint, region, bucket, key, access, secret)


def s3_test(endpoint, region, bucket, access, secret):
    """یک شیء کوچک می‌نویسد و پاک می‌کند تا تنظیمات ثابت شود."""
    key = ".bazarche-test-" + uuid.uuid4().hex[:8] + ".txt"
    ok, detail = _s3_req("PUT", endpoint, region, bucket, key, access, secret,
                         body=b"dastgir s3 test")
    if not ok:
        return False, detail
    _, _ = s3_delete(endpoint, region, bucket, key, access, secret)
    return True, "PUT+DELETE موفق — تنظیمات S3 درست است"


# ============================================================================
#  خواندن تنظیمات تلگرام از دیتابیس (مستقل از اجرای سرور)
# ============================================================================
def read_telegram_settings(db_path):
    """-> (token, chat_id). متغیر محیطی مقدم است؛ بعد جدول settings."""
    token = os.environ.get("BZ_TG_TOKEN", "").strip()
    chat = os.environ.get("BZ_TG_CHAT_ID", "").strip()
    if token and chat:
        return token, chat
    if os.path.isfile(db_path):
        try:
            con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True,
                                  timeout=10)
            try:
                rows = dict(con.execute(
                    "SELECT key, value FROM settings "
                    "WHERE key IN ('tg_token','tg_chat_id')").fetchall())
            finally:
                con.close()
            token = token or (rows.get("tg_token") or "").strip()
            chat = chat or (rows.get("tg_chat_id") or "").strip()
        except Exception:
            pass
    return token, chat
