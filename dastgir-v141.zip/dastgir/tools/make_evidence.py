"""ساخت تصاویر شاهد برای گزارش نهایی ممیزی طراحی (فقط سندباکس)."""
import asyncio, sys, io, os
sys.path.insert(0, os.path.dirname(__file__))
from design_audit import BASE, new_context, clear_audit_ratelimit
from playwright.async_api import async_playwright
from PIL import Image

OUT = "/home/user/audit-design/evidence"
os.makedirs(OUT, exist_ok=True)

FIX_JS = """
const __auditInject = () => {
  const st = document.createElement('style');
  st.textContent = 'details:not([open]) > :not(summary){display:none !important}';
  document.documentElement.appendChild(st);
};
if (document.documentElement) __auditInject();
else document.addEventListener('DOMContentLoaded', __auditInject, { once: true });
"""

async def shot_crop(p, box, path, scale=2):
    x, y, w, h = box
    await p.evaluate(f"window.scrollTo(0, {max(0, y - 60)})")
    await p.wait_for_timeout(350)
    sy = int(await p.evaluate("window.scrollY") or 0)
    raw = await p.screenshot(type="png")
    im = Image.open(io.BytesIO(raw)).convert("RGB")
    cw, ch = im.size
    rx, ry = x, y - sy          # تبدیل مختصات صفحه به مختصات viewport
    x2, y2 = min(rx + w, cw), min(ry + h, ch)
    if x2 <= rx or y2 <= ry:
        raise RuntimeError(f"crop خارج از viewport: box={box} scrollY={sy}")
    crop = im.crop((rx, ry, x2, y2))
    if scale != 1:
        crop = crop.resize((crop.width * scale, crop.height * scale), Image.LANCZOS)
    crop.save(path, "WEBP", quality=80, method=4)
    print("✓", path, crop.size)

async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"])
        waiter = "Promise.race([document.fonts.ready.then(()=>true), new Promise(r=>setTimeout(()=>r(false),2500))])"

        # F1: عنوان لهشده در کارت ویژه — businesses m320
        c = await b.new_context(viewport={"width": 320, "height": 568}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        p = await c.new_page()
        await p.goto(BASE + "/businesses", wait_until="domcontentloaded")
        await p.wait_for_timeout(500)
        await p.evaluate(waiter)
        await shot_crop(p, (150, 660, 170, 240), f"{OUT}/f1_title_squeeze.webp")
        await c.close()

        # F1b: همان از home m320 (کارت ویژهٔ بخش خانه)
        c = await b.new_context(viewport={"width": 320, "height": 568}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        p = await c.new_page()
        await p.goto(BASE + "/", wait_until="domcontentloaded")
        await p.wait_for_timeout(500)
        await p.evaluate(waiter)
        r = await p.evaluate("""() => {
          const a = [...document.querySelectorAll('a.stretch-link')].find(el => { const b = el.getBoundingClientRect(); return b.width < 60 && b.width > 0; });
          if (!a) return null; const b = a.getBoundingClientRect();
          return {x: Math.round(b.x), y: Math.round(b.y), w: Math.round(b.width)};
        }""")
        if r:
            await shot_crop(p, (max(0, r["x"] - 140), r["y"] - 30, 300, 150), f"{OUT}/f1b_home_squeeze.webp")
        await c.close()

        # F2: biz-detail m390 — دکمهٔ مقایسه + ستارهها
        c = await b.new_context(viewport={"width": 390, "height": 844}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        p = await c.new_page()
        await p.goto(BASE + "/b/kbaby-bradran-hydry", wait_until="domcontentloaded")
        await p.wait_for_timeout(600)
        await p.evaluate(waiter)
        await shot_crop(p, (10, 830, 370, 80), f"{OUT}/f2_cmp_btn.webp")
        await shot_crop(p, (60, 4380, 300, 90), f"{OUT}/f2b_stars.webp")
        await c.close()

        # F3: owner/my m390 — ستون دکمههای باریک
        c = await b.new_context(viewport={"width": 390, "height": 844}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        clear_audit_ratelimit()
        cookies = new_context(None, "owner", None, None)
        if cookies:
            await c.add_cookies(cookies)
        p = await c.new_page()
        await p.goto(BASE + "/my", wait_until="domcontentloaded")
        await p.wait_for_timeout(600)
        await p.evaluate(waiter)
        r = await p.evaluate("""() => {
          const a = [...document.querySelectorAll('.btn-sm')].find(el => { const b = el.getBoundingClientRect(); return b.width > 0 && b.width < 40 && b.height > 40; });
          if (!a) return null; const b = a.getBoundingClientRect(); const row = a.closest('.between') || a.parentElement;
          const rb = row.getBoundingClientRect();
          return {x: Math.round(rb.x), y: Math.round(rb.y), w: Math.round(rb.width), h: Math.round(rb.height)};
        }""")
        if r:
            await shot_crop(p, (r["x"] - 5, r["y"] - 5, min(r["w"] + 10, 390 - r["x"] + 5), min(r["h"] + 10, 600)), f"{OUT}/f3_btn_sm.webp")
        await c.close()

        # F6: customer/me m390 — دکمهٔ بستن یادآور رمز
        c = await b.new_context(viewport={"width": 390, "height": 844}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        clear_audit_ratelimit()
        cookies = new_context(None, "customer", None, None)
        if cookies:
            await c.add_cookies(cookies)
        p = await c.new_page()
        await p.goto(BASE + "/me", wait_until="domcontentloaded")
        await p.wait_for_timeout(600)
        await p.evaluate(waiter)
        r = await p.evaluate("""() => {
          const x = document.querySelector('.pw-reminder-x');
          if (!x) return null; const b = x.getBoundingClientRect();
          const box = x.closest('[class*=reminder], .alert, .card') || x.parentElement;
          const bb = box.getBoundingClientRect();
          return {x: Math.round(bb.x), y: Math.round(bb.y), w: Math.round(bb.width), h: Math.round(bb.height)};
        }""")
        if r:
            await shot_crop(p, (r["x"] - 10, r["y"] - 10, min(r["w"] + 20, 390 - r["x"] + 10), min(r["h"] + 20, 120)), f"{OUT}/f6_pw_x.webp")
        await c.close()

        # F8: panel m320 — متن 10px
        c = await b.new_context(viewport={"width": 320, "height": 568}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        clear_audit_ratelimit()
        import sys as _s; _s.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), "server"))
        import db as _db
        _db.init()
        _key = _db.owner_token()
        cookies = new_context(None, "panel", _key, None)
        if cookies:
            await c.add_cookies(cookies)
        p = await c.new_page()
        await p.goto(BASE + "/panel", wait_until="domcontentloaded")
        await p.wait_for_timeout(600)
        await p.evaluate(waiter)
        r = await p.evaluate("""() => {
          const s = [...document.querySelectorAll('small.text-muted')].find(el => { const b = el.getBoundingClientRect(); const cs = getComputedStyle(el); return parseFloat(cs.fontSize) < 12 && b.width > 0; });
          if (!s) return null; const b = s.getBoundingClientRect();
          return {x: Math.round(b.x) - 8, y: Math.round(b.y) - 8, w: Math.round(b.width) + 16, h: Math.round(b.height) + 16, txt: (s.innerText||'').slice(0, 20)};
        }""")
        if r:
            await shot_crop(p, (max(0, r["x"]), max(0, r["y"]), min(r["w"], 320 - r["x"]), min(r["h"], 120)), f"{OUT}/f8_small10.webp")
        await c.close()

        # F10: home d1440 — blurb بریدهشده
        c = await b.new_context(viewport={"width": 1440, "height": 900}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        p = await c.new_page()
        await p.goto(BASE + "/", wait_until="domcontentloaded")
        await p.wait_for_timeout(500)
        await p.evaluate(waiter)
        r = await p.evaluate("""() => {
          const s = [...document.querySelectorAll('span.blurb')].find(el => { const b = el.getBoundingClientRect(); const cs = getComputedStyle(el); return cs.overflow === 'hidden' && b.width > 0 && el.scrollWidth > el.clientWidth + 1; });
          if (!s) return null; const b = s.getBoundingClientRect(); const t = s.closest('.cat-tile-head');
          const tb = t.getBoundingClientRect();
          return {x: Math.round(tb.x), y: Math.round(tb.y) - 20, w: Math.round(tb.width), h: Math.round(tb.height) + 40};
        }""")
        if r:
            await shot_crop(p, (r["x"], r["y"], min(r["w"], 1440 - r["x"]), min(r["h"], 260)), f"{OUT}/f10_blurb_clip.webp")
        await c.close()

        # کنترل: پنل فیلتر بسته در موبایل (تأیید درستی رندر)
        c = await b.new_context(viewport={"width": 360, "height": 800}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        p = await c.new_page()
        await p.goto(BASE + "/businesses", wait_until="domcontentloaded")
        await p.wait_for_timeout(500)
        await p.evaluate(waiter)
        r = await p.evaluate("""() => {
          const sum = document.querySelector('details.dir-filters > summary');
          const body = document.querySelector('.dir-filters-body');
          const sb = sum.getBoundingClientRect(); const bb = body.getBoundingClientRect();
          return {sum: [Math.round(sb.x) - 8, Math.round(sb.y) - 8, Math.round(sb.width) + 16, Math.round(sb.height) + 16],
                  bodyDisplay: getComputedStyle(body).display};
        }""")
        if r:
            await shot_crop(p, (r["sum"][0], r["sum"][1], min(r["sum"][2], 360), min(r["sum"][3], 80)), f"{OUT}/ctrl_filters_closed.webp")
        await c.close()

        await b.close()

asyncio.run(main())
print("DONE")
