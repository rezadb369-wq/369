# -*- coding: utf-8 -*-
"""
قفل یافته‌های ممیزی نسل دوم — دور اصلاح فاز ۱ (۲۰۲۶-۰۸-۳۱)

  F-002  متغیر مردهٔ EXEMPT_LOOPBACK از shield حذف شد (بدون تغییر رفتار)
  F-009  سهمیه‌های امنیتی (OTP/OTP-IP/رمز/پنل) با always=True از کلید
         «محافظت اسپم» مستقل شدند — خاموش‌کردن کلید، دیوار برuteforce را
         دیگر برنمی‌دارد.
  F-012  ردیف سفارشی که به کاتالوگ واقعی همان دکان ارجاع می‌دهد، قیمت و
         عنوانش از دیتابیس خوانده می‌شود؛ نقلِ کلاینت فقط برای ردیف آزاد.
  F-013  کلیدهای سرویس (کاوه‌نگار/تلگرام/نقشه/زرین‌پال) در فرم پنل ماسک‌اند؛
         ارسال خالی = حفظ مقدار ذخیره‌شده؛ چک‌باکس = پاک‌کردن صریح.
  F-014  قاعدهٔ واحد _safe_next برای همهٔ مسیرهای ورود (منع // ، \\ ، .. ،
         /panel، طول ۳۰۰+)

    BZ=http://127.0.0.1:8080 python3 tools/test_audit_fixes.py
"""

import os
import sys
import json
import urllib.parse
import urllib.request
import urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db          # noqa: E402
import features    # noqa: E402
import shield      # noqa: E402
import app as appmod  # noqa: E402  (module import only — no server starts)

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


def req(path, data=None):
    """POST when data given (urlencoded), else GET. -> (code, body)."""
    if data is None:
        r = urllib.request.Request(BASE + path, headers={"User-Agent": "bz-test"})
    else:
        body = urllib.parse.urlencode(data, doseq=True).encode()
        r = urllib.request.Request(BASE + path, data=body, headers={
            "User-Agent": "bz-test",
            "Content-Type": "application/x-www-form-urlencoded"})
    try:
        resp = urllib.request.urlopen(r, timeout=20)
        return resp.getcode(), resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


def main():
    head("F-002 — حذف متغیر مردهٔ EXEMPT_LOOPBACK")
    check("shield دیگر EXEMPT_LOOPBACK ندارد",
          not hasattr(shield, "EXEMPT_LOOPBACK"))
    check("check/unblock/report هنوز callable‌اند",
          callable(shield.check) and callable(shield.unblock)
          and callable(shield.report))

    head("F-014 — قاعدهٔ واحد _safe_next")
    S = appmod._safe_next
    check("مسیر عادی مجاز", S("/my/orders") == "/my/orders")
    check("کوئری‌دار مجاز", S("/catalog?q=1") == "/catalog?q=1")
    check("//evil.com رد", S("//evil.com") is None)
    check("https:// رد", S("https://evil.com") is None)
    check("بک‌اسلش رد", S("/a\\b") is None)
    check(".. رد", S("/a/../b") is None)
    check("/panel رد", S("/panel?key=1") is None)
    check("طول ۳۰۰+ رد", S("/" + "x" * 400) is None)
    check("خالی رد", S("") is None)

    head("F-009 — سهمیهٔ امنیتی مستقل از کلید ضد-اسپم")
    old = db.get_settings()
    had_pass = db.owner_pass_set()
    try:
        db.set_settings({"ratelimit_on": "0"})
        db.rate_clear()
        spam = "tst:fix:spam"
        allowed = [db.rate_ok(spam, limit=2, window=60) for _ in range(4)]
        check("سطل اسپم با کلید خاموش بی‌سقف است (رفتار قبلی حفظ شد)",
              all(allowed), str(allowed))
        sec = "tst:fix:otp"
        a1 = db.rate_ok(sec, limit=2, window=60, always=True)
        a2 = db.rate_ok(sec, limit=2, window=60, always=True)
        a3 = db.rate_ok(sec, limit=2, window=60, always=True)
        check("سطل امنیتی با کلید خاموش هنوز سقف دارد (always=True)",
              a1 and a2 and not a3, f"{a1},{a2},{a3}")
    finally:
        db.set_settings({"ratelimit_on": old.get("ratelimit_on") or "1"})
        db.rate_clear()

    head("F-012 — قیمت سفارش از دیتابیس، نه نقل کلاینت")
    tok = db.owner_token()
    if had_pass:                     # keep the panel gate key-only for the test
        db.set_owner_pass("")
    s0 = db.get_settings()
    slug = "tst-f012-biz"
    try:
        db.set_settings({"orders_enabled": "1", "prices_enabled": "1"})
        db._run("DELETE FROM businesses WHERE slug=?", (slug,))
        bid = db.save_business({"name": "دکان آزمون F012", "slug": slug,
                                "cat_slug": "test", "status": "published"}, None)
        iid = db.save_item({"biz_id": bid, "kind": "product",
                            "title": "کالای کاتالوگی F012", "price": 250000,
                            "price_type": "fixed", "available": 1}, None)
        db.rate_clear()
        code, _ = req("/order/create", {
            "biz_id": str(bid), "name": "تستر", "phone": "",
            "items": json.dumps([{"item_id": iid, "title": "قیمت جعلی",
                                  "price": 0, "qty": 2}]),
        })
        o = db._one("SELECT * FROM orders ORDER BY id DESC LIMIT 1")
        row = db._one("SELECT * FROM order_items WHERE order_id=? "
                      "ORDER BY id DESC LIMIT 1", (o["id"],)) if o else None
        check("سفارش ثبت شد (303→page)", code in (200, 303), str(code))
        check("قیمت ردیف از کاتالوگ آمد (نه ۰ کلاینت)",
              row and row["price"] == 250000, str(row and row["price"]))
        check("عنوان ردیف از کاتالوگ آمد",
              row and row["title"] == "کالای کاتالوگی F012",
              str(row and row["title"]))
        check("جمع کل = قیمت دیتابیس × تعداد",
              o and o["total"] == 500000, str(o and o["total"]))

        code, _ = req("/order/create", {
            "biz_id": str(bid), "name": "تستر", "phone": "",
            "items": json.dumps([
                {"item_id": iid, "title": "x", "price": 1, "qty": 1},
                {"title": "ردیف آزاد", "price": 99000, "qty": 1}]),
        })
        o2 = db._one("SELECT * FROM orders ORDER BY id DESC LIMIT 1")
        check("ردیف آزاد قیمت کلاینت را نگه می‌دارد + کاتالوگی از DB",
              o2 and o2["total"] == 250000 + 99000, str(o2 and o2["total"]))
    finally:
        for t, w in (("order_items", "order_id IN (SELECT id FROM orders WHERE biz_id=?)"),
                     ("orders", "biz_id=?")):
            try:
                db._run(f"DELETE FROM {t} WHERE {w}", (bid,))
            except Exception:
                pass
        try:
            db._run("DELETE FROM items WHERE biz_id=?", (bid,))
            db._run("DELETE FROM businesses WHERE slug=?", (slug,))
        except Exception:
            pass
        db.set_settings({"orders_enabled": s0.get("orders_enabled") or "1",
                         "prices_enabled": s0.get("prices_enabled") or "0"})
        db.rate_clear()

    head("F-013 — کلیدهای سرویس ماسک/حفظ/پاک")
    sec0 = {k: (old.get(k) or "") for k in
            ("sms_key", "tg_token", "gmaps_key", "zarinpal_merchant")}
    try:
        db.set_settings({"sms_key": "SECRET-KAV-X1", "tg_token": "111:SECTOK",
                         "gmaps_key": "AIzaSECRETK", "zarinpal_merchant": "ZP-M-77"})
        code, body = req("/panel/settings?key=" + urllib.parse.quote(tok))
        # server-side secrets must never be echoed; the gmaps key is
        # deliberately public (the browser needs it to load the map, exactly
        # like a GA id), so it is asserted as a MASKED input instead.
        leaked = [s for s in ("SECRET-KAV-X1", "111:SECTOK") if s in body]
        check("صفحهٔ تنظیمات رازهای سمت-سرور را اکو نمی‌کند", not leaked, str(leaked))
        check("نشانگر «ذخیره شده» دیده می‌شود", "ذخیره شده" in body)
        check("ورودی گوگل‌مپ ماسک است (value خالی)",
              'id="m-k" name="gmaps_key" value=""' in body)

        req("/panel/settings", {"key": tok, "sms_key": ""})
        check("ارسال خالی = حفظ کلید پیامک",
              (db.get_settings().get("sms_key") or "") == "SECRET-KAV-X1")
        req("/panel/settings", {"key": tok, "sms_key": "NEW-KAV-2"})
        check("مقدار تازه = جایگزینی",
              (db.get_settings().get("sms_key") or "") == "NEW-KAV-2")
        req("/panel/settings", {"key": tok, "clear_keys": "1"})
        s = db.get_settings()
        check("چک‌باکس = پاک‌کردن همهٔ کلیدها",
              not any((s.get(k) or "").strip()
                      for k in ("sms_key", "tg_token", "gmaps_key")))

        code, _ = req("/panel/plans/payment",
                      {"key": tok, "pay_method": "manual",
                       "zarinpal_merchant": ""})
        check("زرین‌پال: ارسال خالی = حفظ",
              (db.get_settings().get("zarinpal_merchant") or "") == "ZP-M-77")
        code, _ = req("/panel/plans/payment",
                      {"key": tok, "pay_method": "manual",
                       "zarinpal_merchant": "ZP-NEW-9"})
        check("زرین‌پال: مقدار تازه = جایگزینی",
              (db.get_settings().get("zarinpal_merchant") or "") == "ZP-NEW-9")
    finally:
        db.set_settings(sec0)
        if had_pass:
            pass  # password was cleared above; owner re-sets it from the panel

    head("F-016 — featured فقط با پلن؛ ویرایش مالک مقدار ادمین را پاک نمی‌کند")
    import http.cookiejar
    s0biz = db._one("SELECT value FROM settings WHERE key='owner_login'")
    s0fdr = db._one("SELECT value FROM settings WHERE key=?", (db.FOUNDER_LIMIT_KEY,))
    try:
        db.set_settings({"owner_login": "1",
                         db.FOUNDER_LIMIT_KEY: "0"})   # neutralise founder perk
        db._run("DELETE FROM owners WHERE phone=?", ("09120001616",))
        own = db.owner_by_phone("09120001616", create=True)
        db._run("DELETE FROM businesses WHERE slug=?", ("tst-f016-biz",))
        bid = db.save_business({"name": "دکان F016", "slug": "tst-f016-biz",
                                "cat_slug": "test", "status": "published",
                                "owner_id": own["id"]}, None)
        sess = db.session_new(own["id"])

        def opost(path, data_):
            import urllib.parse as up
            body = up.urlencode(data_, doseq=True).encode()
            r = urllib.request.Request(BASE + path, data=body, headers={
                "User-Agent": "bz-test", "Content-Type": "application/x-www-form-urlencoded",
                "Cookie": f"bzv2_sess={sess}"})
            try:
                resp = urllib.request.urlopen(r, timeout=20)
                return resp.getcode()
            except urllib.error.HTTPError as e:
                return e.code

        db._run("DELETE FROM items WHERE biz_id=?", (bid,))
        db.grant_feature(bid, "catalog")   # free plan has no catalog either
        db.rate_clear()
        # free plan has no featured perk (FEATURES/plan defaults) — craft the perk
        code = opost(f"/my/catalog/{bid}/item/new",
                     {"title": "کالای F016", "kind": "product",
                      "price": "1000", "featured": "1"})
        it = db._one("SELECT * FROM items WHERE biz_id=? ORDER BY id DESC LIMIT 1", (bid,))
        check("پلن بدون featured ⇒ مقدار ساختگی نادیده گرفته شد",
              code in (200, 303) and it and it["featured"] == 0,
              f"code={code} featured={it and it['featured']}")
        # admin grants featured directly; owner edits the item WITHOUT featured
        db._run("UPDATE items SET featured=1 WHERE id=?", (it["id"],))
        opost(f"/my/catalog/{bid}/item/{it['id']}",
              {"title": "کالای F016 ویرایش", "kind": "product", "price": "1000"})
        it2 = db.item(it["id"])
        check("ویرایش مالک featuredِ داده‌شده توسط ادمین را پاک نمی‌کند",
              it2 and it2["featured"] == 1, str(it2 and it2["featured"]))
        # unlock the perk for this biz (admin action API) -> owner may set it
        db.grant_feature(bid, "featured")
        if db.can(bid, "featured"):
            opost(f"/my/catalog/{bid}/item/{it['id']}",
                  {"title": "کالای F016", "kind": "product", "price": "1000",
                   "featured": "1"})
            it3 = db.item(it["id"])
            check("با فعال‌بودن perk، مالک می‌تواند featured بگذارد",
                  it3 and it3["featured"] == 1, str(it3 and it3["featured"]))
        else:
            check("perk قابل فعال‌سازی بود (bypass ساختاری)", False,
                  "grant_feature فعال نشد")
    finally:
        try:
            db._run("DELETE FROM items WHERE biz_id=(SELECT id FROM businesses WHERE slug='tst-f016-biz')")
            db._run("DELETE FROM businesses WHERE slug=?", ("tst-f016-biz",))
            db._run("DELETE FROM owners WHERE phone=?", ("09120001616",))
        except Exception:
            pass
        if s0biz is not None:
            db.set_settings({"owner_login": s0biz["value"]})
        if s0fdr is not None:
            db.set_settings({db.FOUNDER_LIMIT_KEY: s0fdr["value"]})
        db.access_cache_clear()
        db.rate_clear()

    head("F-003 — جاروی حافظهٔ shield (کلیدهای خاموش پاک می‌شوند)")
    class _StubH:
        def __init__(self, ident, path="/x", ua="Mozilla/5.0 (test)"):
            self._i, self.path, self.headers = ident, path, {"User-Agent": ua}
        def client_key(self):
            return self._i

    import time as _t
    for i in range(400):
        shield.check(_StubH(f"10.30.{i // 250}.{i % 250}"))
    check("۴۰۰ ident تازه ثبت شد", len(shield._hits) >= 400, str(len(shield._hits)))
    # پیرایش دستی: همهٔ پنجره‌ها را کهنه کن و جارو را اجبار کن
    old = _t.time() - 3600
    for dq in shield._hits.values():
        dq.clear(); dq.append(old)
    for dq in shield._strikes.values():
        dq.clear(); dq.append(old)
    shield._blocked[f"10.30.9.9"] = (_t.time() + 600, "rate")   # must survive
    shield._blocked[f"10.30.8.8"] = (old, "rate")               # expired
    shield._sweep(_t.time())
    check("کلیدهای کهنه حذف شدند", len(shield._hits) == 0, str(len(shield._hits)))
    check("مسدودِ فعال ماند", "10.30.9.9" in shield._blocked)
    check("مسدودِ منقضی پاک شد", "10.30.8.8" not in shield._blocked)
    _r_fresh = shield.check(_StubH("10.30.1.1"))
    check("کلاینت فعالِ تازه بعد از جارو کار می‌کند", _r_fresh is None, str(_r_fresh))
    shield._blocked.pop("10.30.9.9", None)

    print("\n" + "=" * 58)
    print(f"  موفق: \033[32m{ok_n}\033[0m   ناموفق: "
          f"\033[{'32' if not bad_n else '31'}m{bad_n}\033[0m")
    if bad_n:
        print("  ناموفق‌ها:")
        for f in FAILS:
            print(f"   - {f}")
    return 1 if bad_n else 0


if __name__ == "__main__":
    sys.exit(main())
