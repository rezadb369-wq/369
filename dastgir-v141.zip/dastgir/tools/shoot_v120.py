#!/usr/bin/env python3
"""v120: full-page screenshots of the redesigned homepage (light/dark, mobile/desktop)."""
import asyncio, os
from playwright.async_api import async_playwright

OUT = "/home/user/evidence-v120"
os.makedirs(OUT, exist_ok=True)
BASE = "http://localhost:8080"

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        shots = [
            ("home-light-m390", 390, 844, "light"),
            ("home-dark-m390", 390, 844, "dark"),
            ("home-light-d1440", 1440, 900, "light"),
            ("home-dark-d1440", 1440, 900, "dark"),
        ]
        for name, w, h, theme in shots:
            pg = await b.new_page(viewport={"width": w, "height": h})
            await pg.goto(BASE + "/", wait_until="networkidle")
            # theme is attribute-driven → set it directly, no reload needed
            await pg.evaluate(
                "document.documentElement.setAttribute('data-theme','%s')" % theme)
            await pg.wait_for_timeout(700)
            # scroll through the page (lazy images) and force every
            # scroll-reveal section to its final visible state for the shot
            await pg.evaluate("""async () => {
              for (let y = 0; y <= document.body.scrollHeight; y += 480) {
                window.scrollTo(0, y);
                await new Promise(r => setTimeout(r, 25));
              }
              document.querySelectorAll('.reveal, .reveal-3d')
                .forEach(el => el.classList.add('is-in'));
              window.scrollTo(0, 0);
              await new Promise(r => setTimeout(r, 300));
            }""")
            # measure page height + sample key colors for the record
            info = await pg.evaluate("""() => {
              const cs = getComputedStyle(document.body);
              const hero = document.querySelector('.h-hero');
              const heroBg = hero ? getComputedStyle(hero).backgroundImage.slice(0, 60) : '';
              const h1 = document.querySelector('.h-hero h1');
              const h1c = h1 ? getComputedStyle(h1).color : '';
              const cc = document.querySelector('.h-catcard');
              const ccBg = cc ? getComputedStyle(cc).backgroundImage.slice(0, 60) : '';
              const oc = document.querySelector('.owner-cta');
              const ocBg = oc ? getComputedStyle(oc).backgroundImage.slice(0, 60) : '';
              return {h: document.body.scrollHeight,
                      theme: document.documentElement.dataset.theme || 'light',
                      h1: h1c, hero: heroBg, cat: ccBg, cta: ocBg,
                      cards: document.querySelectorAll('.h-catcard').length,
                      biz: document.querySelectorAll('.biz-card').length};
            }""")
            await pg.screenshot(path=f"{OUT}/{name}.png", full_page=True)
            print(name, info)
            await pg.close()
        await b.close()

asyncio.run(main())
