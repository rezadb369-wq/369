# -*- coding: utf-8 -*-
"""v116-audit phase 2: robustness — bugs & senseless errors.

  R1 edge-input route fuzz: every public route with empty/huge/unicode/
     negative/garbage input → never a 500
  R2 dead-link crawl: every local href/action/src rendered on the main
     pages must resolve (no 404)
  R3 browser console: main pages must load with ZERO JS errors
  R4 empty/garbage form posts → never a 500

Run:  python3 tools/test_robustness.py     (server on :8080)
"""
import os
import re
import sys
import urllib.parse
import urllib.request
import urllib.error

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
passed = failed = 0
fails = []


def ok(label, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  {G}✓{X} {label}")
    else:
        failed += 1
        fails.append(label)
        print(f"  {R}✗{X} {label}   {detail}")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


HDRS = {"User-Agent": "Mozilla/5.0 RobustnessSuite/1.0"}


def get(path):
    try:
        with urllib.request.build_opener(NoRedirect).open(
                urllib.request.Request(BASE + path, headers=HDRS), timeout=15) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:  # noqa: BLE001
        raise SystemExit(f"سرور در دسترس نیست ({e}).")


def post(path, fields):
    data = urllib.parse.urlencode(fields).encode()
    h = dict(HDRS, **{"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.build_opener(NoRedirect).open(
                urllib.request.Request(BASE + path, data=data, headers=h),
                timeout=15) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "server"))
import db  # noqa: E402

biz = db._one("SELECT slug FROM businesses WHERE status='published' LIMIT 1")
SLUG = biz["slug"] if biz else "nothing"

print(f"\n{B}R1) فاز روت‌ها با ورودی لبه — هیچ ۵۰۰ مجاز نیست{X}")
HUGE = urllib.parse.quote("ا" * 4000)   # URLs must be percent-encoded
EDGE = [
    "/", "/?q=", "/?q=" + HUGE, "/?q=%00", "/?q=../../etc/passwd",
    "/businesses", "/businesses?page=0", "/businesses?page=-3",
    "/businesses?page=abc", "/businesses?page=999999999",
    "/businesses?q=" + HUGE, "/businesses?cat=" + urllib.parse.quote("../../x"),
    "/businesses?city=%00", "/businesses?sort=;DROP", "/businesses?open=maybe",
    f"/b/{SLUG}", "/b/", "/b/no-such-slug-xyz", "/b/" + urllib.parse.quote("ز" * 300),
    "/b/" + urllib.parse.quote("'<>\""),
    "/item/1", "/item/0", "/item/-5", "/item/abc", "/item/99999999999",
    "/item/" + "9" * 40,
    "/blog", "/blog/no-such-post", "/map", "/contact", "/favorites",
    "/prices", "/nearby", "/events", "/offline.html",
    "/haggle/-1", "/haggle/99999", "/offer/short",
    f"/qr/{SLUG}.svg?size=-5", f"/qr/{SLUG}.svg?size=999999",
    f"/qr/{SLUG}.svg?size=abc", "/qr/no-such.svg", "/vcard/no-such",
    "/api/search?q=", "/api/search?q=" + urllib.parse.quote("<script>"),
    "/robots.txt", "/sitemap.xml", "/manifest.webmanifest", "/sw.js",
    "/my", "/my/stats/1", "/panel/analytics", "/panel/traffic",
    "/no-such-page-at-all",
]
bad = []
for p in EDGE:
    st, _ = get(p)
    if st >= 500:
        bad.append(f"{p} → {st}")
ok(f"{len(EDGE)} روت/ورودی لبه: بدون ۵۰۰", not bad, " · ".join(bad))
# sanity: a few must be their intended codes, not just "not 500"
st, _ = get("/")
ok("خانه ۲۰۰", st == 200, str(st))
st, _ = get("/no-such-page-at-all")
ok("صفحهٔ نبود = ۴۰۴", st == 404, str(st))
st, _ = get("/my")
ok("/my بی‌نشست = ریدایرکت/۴۰۳", st in (303, 403), str(st))

print(f"\n{B}R2) خزش لینک‌های مرده{X}")
seen, actions, dead, checked = set(), set(), [], 0
pages = ["/", "/businesses", f"/b/{SLUG}", "/blog", "/contact", "/login",
         "/map", "/favorites"]
for pg in pages:
    st, body = get(pg)
    if st != 200:
        continue
    for m in re.finditer(r'(href|action|src)="(/[^"#]*?)"', body):
        u = m.group(2).split("?")[0]
        if "{" in u or "}" in u:          # unrendered template artifact = bug!
            dead.append(f"{pg}: الگوی رندرنشده {u}")
            continue
        if not u or u.startswith("//"):
            continue
        (actions if m.group(1) == "action" else seen).add(u)
for u in sorted(seen - actions):
    st, _ = get(u)
    checked += 1
    if st == 404:
        dead.append(f"{u} → 404")
    elif st >= 500:
        dead.append(f"{u} → {st}")
# form actions are POST endpoints — a GET 404 is correct; they must answer
# POST with anything BUT 404/500 (redirect/flash-error is the healthy path)
for u in sorted(actions):
    st, _ = post(u, {})
    checked += 1
    if st in (404,) or st >= 500:
        dead.append(f"action {u} → {st}")
ok(f"{checked} لینک/اکشن یکتا چک شد — مرده صفر", not dead, " · ".join(dead[:8]))

print(f"\n{B}R3) کنسول مرورگر — بدون خطای JS{X}")
try:
    from playwright.sync_api import sync_playwright
    errors = []
    with sync_playwright() as pw:
        br = pw.chromium.launch()
        pg = br.new_page()
        pg.on("pageerror", lambda e: errors.append(f"pageerror: {e}"))
        pg.on("console", lambda m: errors.append(f"console.{m.type}: {m.text}")
              if m.type == "error" else None)
        for u in ("/", "/businesses", f"/b/{SLUG}", "/login", "/map",
                  "/contact", "/favorites", "/blog"):
            pg.goto(BASE + u, wait_until="load")
            pg.wait_for_timeout(350)
        br.close()
    # a missing favicon/asset on file:// style pages is still a real error
    real = [e for e in errors if "favicon" not in e.lower()]
    ok(f"۸ صفحه بدون خطای کنسول", not real, " · ".join(real[:5]))
except ImportError:
    print("  (playwright نصب نیست — جا افتاد)")

print(f"\n{B}R4) فرم‌های خالی/زباله‌ای{X}")
forms = [
    ("/alert", {}),
    ("/alert", {"phone": "", "term": ""}),
    ("/login", {}),
    ("/login", {"phone": ""}),
    ("/login/verify", {}),
    ("/login/verify", {"phone": "09121234567", "code": ""}),
    ("/subscribe", {}),
    (f"/b/{SLUG}/review", {}),
    (f"/b/{SLUG}/review", {"rating": "abc", "body": "x"}),
    ("/api/stories/-1/view", {}),
]
bad = []
for path, fields in forms:
    st, body = post(path, fields)
    if st >= 500:
        bad.append(f"{path}{fields} → {st}")
ok(f"{len(forms)} POST خالی/زباله: بدون ۵۰۰", not bad, " · ".join(bad))

print()
print(f"{B}{'='*58}{X}")
print(f"  موفق: {G}{passed}{X}   ناموفق: "
      f"{(R + str(failed) + X) if failed else '0'}")
if fails:
    print(f"  {R}ناموفق‌ها:{X} " + " · ".join(fails))
    sys.exit(1)
print(f"  {G}همه موفق — باگ بی‌دلیل پیدا نشد.{X}")
