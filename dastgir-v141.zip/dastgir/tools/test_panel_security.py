# -*- coding: utf-8 -*-
"""
قفل مرحلهٔ م۱ (امنیت پنل) — بازسازی فاز ۵ (۲۰۲۶-۰۸-۳۱)

  • نشت کلید ۱: کلید خام مالک در همهٔ لینک‌های داخلی پنل (۵۸ لینک در
    views_panel/2 + هدر دسکتاپ + ناوبری موبایل + ناوبری کنار پنل) —
    اکنون ورود با کلید فقط «یک‌بار» انجام می‌شود و سشن ۷روزهٔ کوکی‌دار
    می‌سازد؛ ناوبری داخل پنل کاملاً بدون key است.
  • نشت کلید ۲: کلید خام به‌صورت فیلد مخفی در HTML همهٔ فرم‌ها و در
    JSON بوت صفحه‌ها و file_url چت — حذف شد (احراز POST با کوکی سشن).
  • باگ مرگبار میراث: فرم ورود با رمز هرگز key را POST نمی‌کرد ولی
    هندلر token_ok(form) می‌خواست → ورود با رمزِ درست هم همیشه رد
    می‌شد. رفع شد (رمز + سقف ۱۰/۱۵دقیقه کافی است).
  • noindex دوطرفه: متای robots + هدر X-Robots-Tag روی همهٔ /panel.
  • TTL سشن ادمین: ۳۰ روز → ۷ روز.
  • F-010: PBKDF2 از ۱۲۰k به ۶۰۰k + ارتقای شفاف هش‌های قدیمی هنگام
    ورود موفق (rehash-on-login) + چرخش کلید، همهٔ سشن‌ها را می‌کشد.

    BZ=http://127.0.0.1:8080 python3 tools/test_panel_security.py
"""

import os
import sys
import time
import http.cookiejar
import urllib.parse
import urllib.request
import urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db          # noqa: E402
import ui          # noqa: E402
import app as appmod  # noqa: E402  (module import only — no server starts)

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


class Client:
    """Tiny cookie-carrying browser: never auto-follows redirects."""

    def __init__(self, xff=None):
        self.xff = xff
        self.jar = http.cookiejar.CookieJar()
        self.op = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.jar),
            urllib.request.HTTPRedirectHandler)

    def get(self, path, follow=True):
        return self._req("GET", path, None, follow)

    def post(self, path, data, follow=True):
        return self._req("POST", path, data, follow)

    def _req(self, method, path, data, follow):
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *a, **k):
                return None
        op = self.op if follow else urllib.request.build_opener(
            NoRedirect, urllib.request.HTTPCookieProcessor(self.jar))
        body = urllib.parse.urlencode(data, doseq=True).encode() if data else None
        h = {"User-Agent": "bz-panel-sec",
             "Content-Type": "application/x-www-form-urlencoded"}
        if self.xff:
            h["X-Forwarded-For"] = self.xff
        r = urllib.request.Request(BASE + path, data=body, method=method,
                                   headers=h)
        try:
            resp = op.open(r, timeout=20)
            return resp.getcode(), resp.read().decode("utf-8", "replace"), dict(resp.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace"), dict(e.headers)
        except Exception as e:
            return 0, str(e), {}

    def cookie(self, name):
        for c in self.jar:
            if c.name == name:
                return c.value
        return None


def main():
    tok = db.owner_token()
    assert tok, "این تست به کلید مالک نیاز دارد (DB دمو)"

    # ---------------------------------------------------------------- §a
    head("م۱-a — ورود تک‌باره با کلید؛ ناوبری بدون key")

    c1 = Client()
    code, body, hdrs = c1.get(f"/panel?key={urllib.parse.quote(tok)}", follow=False)
    check("GET /panel?key=… → 303 (سشن ساخته شد، نه رندر با کلید در URL)",
          code in (200, 303), f"code={code}")
    # entry minted a session cookie?
    if code == 303:  # follow to the panel itself
        code, body, hdrs = c1.get("/panel")
    check("کوکی سشن ادمین ست شد", bool(c1.cookie("bzv2_admin")))
    check("پاسخ ورود 200 است", code == 200, f"code={code}")

    c2 = Client()
    code2, body2, _ = c2.get("/panel")
    check("بدون کلید و بدون کوکی → 403 دروازهٔ ورود", code2 == 403, f"code={code2}")

    c3 = Client()
    code3, _, _ = c3.get("/panel?key=definitely-wrong")
    check("کلید غلط → 403", code3 == 403, f"code={code3}")

    code4, body4, _ = c1.get("/panel")            # cookie only, no key
    check("داشتن فقط کوکی سشن → 200 (بدون هیچ key)",
          code4 == 200, f"code={code4}")

    raw_in_html = urllib.parse.quote(tok) in body or tok in body4
    check("کلید خام در HTML داشبورد نیست", not raw_in_html)

    def key_leaks(html):
        return ("?key=" in html or "&key=" in html
                or 'name="key"' in html or '"key":' in html)
    check("هیچ لینک ?key= در داشبورد نیست", not key_leaks(body4))
    for page in ("/panel/businesses", "/panel/reviews", "/panel/settings",
                 "/panel/customers", "/panel/audit"):
        cp, bp, _ = c1.get(page)
        expect = 2 if page == "/panel/settings" else 0   # entry-link display (input+copy)
        check(f"{page}: 200 با کوکی و بدون key در HTML",
              cp == 200 and bp.count("?key=") == expect
              and 'name="key"' not in bp, f"code={cp} n={bp.count('?key=')}")
    _, bset, _ = c1.get("/panel/settings")
    check("فرم تنظیمات فیلد مخفی key ندارد",
          'name="key"' not in bset)
    check("تنظیمات: کلید فقط در نمایش عمدی «لینک ورود» (۲ بار) است",
          bset.count("/panel?key=" + tok) == 2
          and bset.count(tok) == 2, f"n={bset.count(tok)}")
    check("تنظیمات «لینک ورود» عمدی را هنوز نشان می‌دهد (فقط برای ادمین)",
          'id="tok"' in bset)

    # POST by cookie alone (no key anywhere in the form)
    code5, _, _ = c1.post("/panel/list/new", {"title": ""}, follow=False)
    check("POST با فقط کوکی → پذیرفته (303 اعتبارسنجی، نه 403)",
          code5 == 303, f"code={code5}")
    c4 = Client()
    code6, _, _ = c4.post("/panel/list/new", {"title": ""}, follow=False)
    check("POST بدون کوکی و بدون کلید → 403", code6 == 403, f"code={code6}")

    # ---------------------------------------------------------------- §b
    head("م۱-b — noindex و حذف نشت‌های دیگر")

    _, _, hdrs_p = c1.get("/panel")
    check("هدر X-Robots-Tag: noindex روی /panel",
          "noindex" in (hdrs_p.get("X-Robots-Tag") or ""))
    _, bp2, _ = c1.get("/panel")
    check('متای <meta name="robots" content="noindex"> در HTML پنل',
          'name="robots"' in bp2 and "noindex" in bp2)
    cr = Client()
    _, robots, _ = cr.get("/robots.txt")
    check("robots.txt همچنان /panel راDisallow می‌کند",
          "Disallow: /panel" in robots)
    check("JSON بوت صفحه توکن ادمین را ندارد",
          '"token"' not in bp2)

    import inspect
    hdr_src = inspect.getsource(ui.header)
    check("هدر دسکتاپ: دکمهٔ پنل بدون key", "panel?key" not in hdr_src)
    ppage_src = inspect.getsource(ui.panel_page)
    check("ناوبری کنار پنل بدون key", "key=" not in ppage_src)

    # ---------------------------------------------------------------- §c
    head("م۱-c — سشن ۷روزه، خروج، چرخش کلید")

    check("ADMIN_SESSION_TTL = ۷ روز",
          db.ADMIN_SESSION_TTL == 7 * 86400, f"ttl={db.ADMIN_SESSION_TTL}")
    st = db.admin_session_new()
    check("سشن تازه معتبر است", db.admin_session_ok(st))
    con = db.connect()
    con.execute("UPDATE admin_sessions SET expires=? WHERE token=?",
                (time.time() - 10, st))
    con.commit(); con.close()
    check("سشن منقضی رد می‌شود", not db.admin_session_ok(st))
    con = db.connect()
    con.execute("DELETE FROM admin_sessions WHERE token=?", (st,))
    con.commit(); con.close()

    c5 = Client()
    c5.get(f"/panel?key={urllib.parse.quote(tok)}")
    c5.post("/panel/logout", {}, follow=False)
    code7, _, _ = c5.get("/panel")
    check("خروج → سشن مرده و پنل قفل (403)", code7 == 403, f"code={code7}")

    old_tok = db.get_settings().get("owner_token")
    try:
        db.rotate_owner_token()
        con = db.connect()
        n = con.execute("SELECT COUNT(*) c FROM admin_sessions").fetchone()["c"]
        con.close()
        check("چرخش کلید → همهٔ سشن‌های ادمین کشته شدند", n == 0, f"n={n}")
    finally:
        db.set_setting("owner_token", old_tok)

    # ---------------------------------------------------------------- §d
    head("م۱-d — رمز پنل و PBKDF2 600k (F-010)")

    check("PBKDF2_ITERS = 600,000", db.PBKDF2_ITERS == 600_000,
          f"iters={db.PBKDF2_ITERS}")

    old_hash = (db.get_settings().get("owner_pass_hash") or "")
    old_sess = []
    try:
        db.set_owner_pass("S3cret-Panel-Pass")
        h = db.get_settings().get("owner_pass_hash") or ""
        check("هش تازه با ۶۰۰هزار تکرار ساخته می‌شود",
              h.startswith("pbkdf2$600000$"), h[:24])
        check("هش هرگز در HTML پنل ظاهر نمی‌شود", h[:20] not in bp2)

        # legacy 120k hash still verifies + is transparently upgraded
        import hashlib
        salt = "abcd1234abcd1234"
        dk = hashlib.pbkdf2_hmac("sha256", b"legacy-pw", bytes.fromhex(salt),
                                 120_000)
        db.set_setting("owner_pass_hash",
                       f"pbkdf2$120000${salt}${dk.hex()}")
        check("هش قدیمی ۱۲۰k هنوز وارسی می‌شود",
              db.check_owner_pass("legacy-pw"))
        up = db.get_settings().get("owner_pass_hash") or ""
        check("وارسی موفق → ارتقای خودکار به ۶۰۰k",
              up.startswith("pbkdf2$600000$"), up[:24])
        check("رمز غلط رد می‌شود", not db.check_owner_pass("wrong"))

        # live two-step flow: key → password gate → login POST → cookie
        db.set_owner_pass("S3cret-Panel-Pass")
        c6 = Client()
        r6, b6, _ = c6.get(f"/panel?key={urllib.parse.quote(tok)}", follow=False)
        if r6 == 303:
            r6, b6, _ = c6.get("/panel")
        check("با رمزِ تعیین‌شده: GET پنل → 403 دروازهٔ رمز", r6 == 403,
              f"code={r6}")
        check("دروازهٔ رمز فرم ورود دارد", 'name="password"' in b6)
        c6 = Client(xff="10.77.7.6")   # fresh rate bucket for this section
        r7, _, _ = c6.post("/panel/login", {"password": "wrong-pass"},
                           follow=False)
        check("رمز غلط → 403", r7 == 403, f"code={r7}")
        r8, _, _ = c6.post("/panel/login", {"password": "S3cret-Panel-Pass"},
                           follow=False)
        check("رمز درست → 303 + کوکی (باگ مرگبار v116 رفع شد)",
              r8 == 303 and bool(c6.cookie("bzv2_admin")), f"code={r8}")
        r9, b9, _ = c6.get("/panel")
        check("بعد از ورود رمز: پنل با کوکی باز است", r9 == 200, f"code={r9}")

        # CRITICAL (v117/M1 tiering): a key-only (locked) session must keep
        # facing the password gate — the key alone can never satisfy the
        # second factor, even on the second request with its cookie set.
        c8 = Client(xff="10.77.7.8")
        c8.get(f"/panel?key={urllib.parse.quote(tok)}", follow=False)
        r10, b10, _ = c8.get("/panel")     # now carries the locked cookie
        check("سشنِ فقط-کلیدی (locked) همچنان دروازهٔ رمز می‌گیرد (۴۰۳)",
              r10 == 403 and "رمز عبور" in b10, f"code={r10}")
        r11, _, _ = c8.post("/panel/list/new", {"title": "x"}, follow=False)
        check("سشنِ فقط-کلیدی اجازهٔ POST ندارد (۴۰۳)",
              r11 == 403, f"code={r11}")

        c7 = Client(xff="10.77.7.7")
        last = 0
        for _ in range(11):
            last, _, _ = c7.post("/panel/login", {"password": "nope"},
                                 follow=False)
            if last == 429:
                break
        check("۱۱ تلاش رمز غلط → قفل نرخ 429", last == 429, f"code={last}")
    finally:
        db.set_setting("owner_pass_hash", old_hash)
        con = db.connect()
        con.execute("DELETE FROM admin_sessions")
        con.commit(); con.close()

    # ---------------------------------------------------------------- ⨯
    print(f"\n\033[1m{ok_n} passed, {bad_n} failed\033[0m")
    if FAILS:
        print("\n".join("  ✗ " + f for f in FAILS))
        sys.exit(1)


if __name__ == "__main__":
    main()
