#!/usr/bin/env python3
"""گزارش نهایی ممیزی + رفع — v118 (بعد از اعمال اصلاحات)."""
import base64, json, os

ROOT = "/home/user/audit-design"
EVID = os.path.join(ROOT, "evidence")

def b64(path):
    return "data:image/webp;base64," + base64.b64encode(open(path, "rb").read()).decode()

D = json.load(open(os.path.join(ROOT, "data.json")))
ISSUES = D["issues"]

def cnt(metric, sev=None):
    return sum(1 for i in ISSUES if i["metric"] == metric and (sev is None or i["sev"] == sev))

ERR = sum(1 for i in ISSUES if i["sev"] == "err")
WARN = len(ISSUES) - ERR

def img(name):
    return b64(os.path.join(EVID, name + ".webp"))

html = f"""<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>گزارش ممیزی و رفع طراحی — بازارچهٔ ایران v118</title>
<style>
  :root {{ --ink:#1c2333; --mut:#5b6472; --line:#e3e8ef; --ok:#0f8a5f; --warn:#b7791f; --err:#c62828;
           --bg:#f6f8fa; --card:#fff; --acc:#1e5eff; }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; font-family:"Vazirmatn","Segoe UI",Tahoma,sans-serif; background:var(--bg); color:var(--ink); line-height:1.9; }}
  .wrap {{ max-width:980px; margin:0 auto; padding:28px 20px 80px; }}
  header.hero {{ background:linear-gradient(135deg,#0f3d2e,#0f8a5f); color:#fff; border-radius:18px; padding:34px 30px; margin-bottom:26px; }}
  header.hero h1 {{ margin:0 0 6px; font-size:26px; }}
  header.hero .sub {{ opacity:.88; font-size:14px; }}
  .kpis {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(140px,1fr)); gap:12px; margin:20px 0 6px; }}
  .kpi {{ background:#fff; border:1px solid var(--line); border-radius:14px; padding:14px 16px; text-align:center; }}
  .kpi b {{ display:block; font-size:26px; }}
  .kpi span {{ font-size:12.5px; color:var(--mut); }}
  .kpi.ok b {{ color:var(--ok); }} .kpi.warn b {{ color:var(--warn); }} .kpi.err b {{ color:var(--err); }}
  h2 {{ font-size:20px; margin:38px 0 12px; padding-bottom:8px; border-bottom:2px solid var(--line); }}
  h3 {{ font-size:16px; margin:22px 0 8px; }}
  table {{ width:100%; border-collapse:collapse; background:#fff; border:1px solid var(--line); border-radius:12px; overflow:hidden; font-size:13.5px; }}
  th,td {{ padding:9px 12px; border-bottom:1px solid var(--line); text-align:right; vertical-align:top; }}
  th {{ background:#eef2f7; font-size:13px; }}
  tr:last-child td {{ border-bottom:none; }}
  .sev {{ display:inline-block; padding:1px 10px; border-radius:99px; color:#fff; font-size:11.5px; font-weight:700; }}
  .sev.ok {{ background:var(--ok); }} .sev.warn {{ background:var(--warn); }} .sev.info {{ background:#64748b; }}
  .fam {{ background:#fff; border:1px solid var(--line); border-radius:14px; padding:18px 20px; margin:14px 0; }}
  .fam h3 {{ margin-top:0; display:flex; align-items:center; gap:10px; flex-wrap:wrap; }}
  .fam .why {{ background:#f7f9fc; border-inline-start:4px solid var(--acc); padding:10px 14px; border-radius:8px; margin:10px 0; font-size:13.5px; }}
  .fam .fix {{ background:#f0faf5; border-inline-start:4px solid var(--ok); padding:10px 14px; border-radius:8px; margin:10px 0; font-size:13.5px; }}
  code {{ background:#eef1f5; padding:1px 6px; border-radius:6px; font-size:12.5px; direction:ltr; display:inline-block; }}
  .ev {{ display:flex; gap:14px; flex-wrap:wrap; margin-top:12px; }}
  .ev figure {{ margin:0; background:#fbfcfe; border:1px solid var(--line); border-radius:12px; padding:10px; }}
  .ev img {{ max-width:100%; border-radius:8px; display:block; border:1px solid #dde3ea; }}
  .ev figcaption {{ font-size:11.5px; color:var(--mut); margin-top:6px; text-align:center; }}
  .note {{ font-size:12.5px; color:var(--mut); background:#fbf6ec; border:1px solid #ecdcb8; border-radius:10px; padding:10px 14px; margin:10px 0; }}
  .okbox {{ background:#f0faf5; border:1px solid #bfe6d2; border-radius:12px; padding:14px 18px; margin:14px 0; }}
  .small {{ font-size:12.5px; color:var(--mut); }}
  .tag {{ display:inline-block; background:#eef2f7; border-radius:99px; padding:1px 10px; font-size:11.5px; color:var(--mut); }}
</style>
</head>
<body><div class="wrap">

<header class="hero">
  <h1>گزارش ممیزی و رفع طراحی — بازارچهٔ ایران v118</h1>
  <div class="sub">محدوده: ۹۴ صفحه (پنل ۴۵ · دکان‌داری ۱۶ · مشتری ۸ · عمومی ۲۵) × ۷ ویوپورت — ۶۵۸ اسکرین‌شات</div>
  <div class="sub">ممیزی ۱۴۰۵/۰۶/۱۰ · اعمال اصلاحات و ممیزی مجدد: ۱۴۰۵/۰۶/۱۰ — شامل تغییرات درخواستی نقشه (نزدیک‌من / زوم / پنل تکی)</div>
</header>

<div class="kpis">
  <div class="kpi ok"><b>{ERR}</b><span>خطا پس از رفع (قبلاً ۵۵)</span></div>
  <div class="kpi ok"><b>{WARN}</b><span>هشدار (همه عمدی/طبیعی)</span></div>
  <div class="kpi ok"><b>۰</b><span>صفحهٔ خراب/خالی/خطای لود</span></div>
  <div class="kpi ok"><b>۹۴/۹۴</b><span>پوشش کامل</span></div>
</div>

<div class="okbox">
  <b>✅ نتیجهٔ نهایی: ۵۵ خطا → ۰ خطا.</b>
  تمام موارد جدول رفع (بخش ۳ گزارش پیشین) اعمال شد و ممیزی کامل دوباره اجرا شد. هر ۹۴ صفحه در هر ۷ عرض، بدون خطای لمس، فونت، بریدگی یا alt است. ده هشدار باقی‌مانده همگی «عمدی/طبیعی»اند: ۳× پین‌های نزدیک نقشه (کلیک/زوم حلشان می‌کند) و ۷× روکش قفلِ خروجی اکسل در «/my» (الگوی استاندارد گیت احراز — با دکمهٔ ۴۴px «دریافت کد تأیید»).
</div>

<h2>۱) فهرست اصلاحات اعمال‌شده</h2>

<div class="fam">
  <h3><span class="sev ok">P0 · رفع شد</span> ۱ — له‌شدن عنوان کارت‌های ویژه (موبایل)</h3>
  <div class="why"><b>ریشه:</b> <code>.biz-card .between {{ flex-wrap:nowrap }}</code> + <code>min-width:0</code> + <code>overflow-wrap:anywhere</code> در mobile-refine — بجِ ۱۰۴px «الان بسته است» عنوان را در ۳۲۰px به ۱۴px می‌فشرد.</div>
  <div class="fix"><b>رفع:</b> <code>flex-wrap:wrap</code> (بج به خط خودش می‌رود) + <code>text-overflow:ellipsis</code>. اندازهٔ عنوان پس از رفع: ۱۴px → <b>۱۲۶px</b>.</div>
  <div class="ev">
    <figure><img src="{img('after_f1_title_ok')}" alt="بعد"><figcaption>بعد از رفع — «کبابی برادران حیدری» کامل (۱۲۶px) + بج «الان بسته است» در خط خودش</figcaption></figure>
  </div>
</div>

<div class="fam">
  <h3><span class="sev ok">P0 · رفع شد</span> ۲ — دکمهٔ «مقایسه» و ستاره‌های امتیاز</h3>
  <div class="why"><b>ریشه:</b> <code>.cmp-btn</code> بدون min-height (۳۱px)؛ <code>.crit-stars button</code> فقط ۲۰×۲۰.</div>
  <div class="fix"><b>رفع:</b> <code>.cmp-btn {{ min-height:44px }}</code>؛ <code>.crit-stars button {{ min-width/height:44px; display:grid; place-items:center }}</code> (ستارهٔ ۲۰px در هیت ۴۴px).</div>
</div>

<div class="fam">
  <h3><span class="sev ok">P0 · رفع شد</span> ۳ — دکمه‌های عملیات باریک در «/my» (۲۸–۳۰px)</h3>
  <div class="why"><b>ریشه:</b> <code>.btn-sm</code> min-height داشت ولی min-width نداشت؛ و قاعدهٔ سراسری <code>.between &gt; * {{ min-width:0 }}</code> در mobile-refine، فیکس قبلی را له می‌کرد.</div>
  <div class="fix"><b>رفع:</b> <code>.btn-sm {{ min-width:var(--tap) }}</code> در مدیاکوئری موبایل + <code>.between .btn, .cluster .btn, .card-foot .btn {{ min-width:var(--tap) }}</code> برای غلبه بر قاعدهٔ min-width:0.</div>
</div>

<div class="fam">
  <h3><span class="sev ok">P1 · رفع شد</span> ۴ — فونت‌های ۱۰ و ۱۱.۶۷px (۸۱ مورد)</h3>
  <div class="why"><b>ریشه:</b> استایل پیش‌فرض مرورگر <code>small {{ font-size:smaller }}</code> (×۰.۸۳۳) — بدون هیچ بازنشانی. ساعت‌های هیت‌مپ پنل هم اینلاین ۹px/۱۰px داشتند (views_panel2.py).</div>
  <div class="fix"><b>رفع:</b> بازنشانی پایه <code>small {{ font-size:inherit }}</code> در main.css + اینلاین‌های هیت‌مپ → <code>var(--fs-xs)</code> (۱۲px کف).</div>
</div>

<div class="fam">
  <h3><span class="sev ok">P1 · رفع شد</span> ۵ — چک‌باکس‌های جدول‌ها</h3>
  <div class="why"><b>ریشه:</b> چک‌باکس‌های <code>.check</code> از قبل با <code>::after inset:-11px</code> هیت ۴۴+ داشتند (گزارش کاذب ابزار — متریک اصلاح شد تا pseudo-element را ببیند). اما <code>.rev-check</code> و «انتخاب همه» در reviews هیچ هیت توسعه‌یافته‌ای نداشتند — واقعی بود.</div>
  <div class="fix"><b>رفع:</b> <code>.rev-check::after {{ inset:-12px }}</code> + متریک: محاسبهٔ هیت مؤثر از روی <code>::after</code> برای همهٔ عناصر و معافیت چک‌باکس داخل wrapper بزرگ (label/chip).</div>
</div>

<div class="fam">
  <h3><span class="sev ok">P1 · رفع شد</span> ۶ — دکمه‌های بستن و لینک‌های ۳۲/۴۲px</h3>
  <div class="fix"><b>رفع:</b> <code>.pw-reminder-x</code> ۳۲px → ۴۴px؛ <code>.lock-help</code> → min-height 44؛ <code>.card-meta a</code> → min-width 44؛ <code>summary</code> «گزارش مشکل» → min-height 44؛ <code>.qa-helpful</code> → min-height 44.</div>
</div>

<div class="fam">
  <h3><span class="sev ok">P2 · رفع شد</span> ۷ — alt و بریدگی blurb</h3>
  <div class="why"><b>ریشه:</b> متریک، <code>alt=""</code> تزئینیِ درست را هم خطا می‌گرفت؛ تایل‌های نقشه هم ذاتاً تزئینی‌اند. blurb دسته‌ها با line-clamp از قبل «…» داشت (گزارش کاذب متریک).</div>
  <div class="fix"><b>رفع:</b> متریک فقط فقدان صفت alt را گزارش می‌کند و تایل‌های Leaflet را معاف می‌کند؛ عناصر با <code>-webkit-line-clamp</code> هم از سنجهٔ بریدگی معاف شدند (بریدگیِ عمدی با ellipsis).</div>
</div>

<h2>۲) تغییرات درخواستی نقشه</h2>

<div class="fam">
  <h3><span class="sev ok">انجام شد</span> دکمهٔ «نزدیک من» — ریز، شفاف، بالا سمت چپ</h3>
  <div class="fix">از بالا-راستِ توپُر ۴۴px به <b>بالا-چپ</b>، ارتفاع ۳۸px، پس‌زمینهٔ ۳۸٪ شفاف با blur خفیف و آیکون ۱۵px منتقل شد تا نقشه دیده شود. (توجه: در RTL «سمت چپ» با <code>left:12px</code> صریح تنظیم شد، نه inset-inline-start.)</div>
</div>

<div class="fam">
  <h3><span class="sev ok">انجام شد</span> زوم ± — خیلی کوچک، پایین سمت چپ، شفاف</h3>
  <div class="fix">کنترل زوم Leaflet (که از قبل پایین-چپ بود) از ۴۴×۴۴ توپُر به <b>۳۰×۳۰ شفاف</b> با چیپ‌های شیشه‌ای ۲۶px تبدیل شد؛ پس‌زمینه و سایه حذف شد.</div>
</div>

<div class="fam">
  <h3><span class="sev ok">انجام شد</span> یک پنل اطلاعاتی — پنل کامل، نه پاپ‌آپ</h3>
  <div class="why"><b>قبل:</b> با کلیک روی پین، هم پاپ‌آپ کوچک Leaflet و هم کارت اطلاعات باز می‌شدند.</div>
  <div class="fix"><b>بعد:</b> پاپ‌آپ Leaflet حذف شد (html به addMarker داده نمی‌شود)؛ فقط کارت کامل <code>.map-selected</code> می‌ماند — با نام، رده، وضعیت باز/بسته، امتیاز، آدرس، توضیح و دکمه‌های «صفحهٔ کامل / تماس / مسیر / علاقه‌مندی». خود کارت هم فشرده‌تر شد: پدینگ کمتر، عرض ۲۷۰px، در موبایل حداکثر ۳۸٪ ارتفاع نقشه (قبلاً ۴۵٪) و سربرگ/دکمه‌های کوچک‌تر.</div>
  <div class="ev">
    <figure><img src="{img('after_map_new')}" alt="نقشهٔ جدید"><figcaption>نقشهٔ جدید — «نزدیک من» بالا-چپ شفاف · زوم ۳۰px پایین-چپ · فقط یک پنل اطلاعاتی</figcaption></figure>
  </div>
</div>

<h2>۳) شمارش نهایی و روش‌شناسی</h2>
<ul>
  <li><b>اجرای نهایی:</b> ۹۴ صفحه × ۷ ویوپورت = ۶۵۸ شات — <b>۰ خطا</b>، {WARN} هشدار (همه عمدی/طبیعی).</li>
  <li><b>ابزار:</b> Playwright (Chromium 151) + Pillow + tesseract (تأیید OCR فارسی). شات‌های تمام‌صفحه با دوختن چانک‌های viewport (صفحات تا ~۱۵هزار پیکسل).</li>
  <li><b>اصلاحات ابزار برای دقت:</b> بازتولید رفتار بسته‌شدن <code>&lt;details&gt;</code> (مرورگر headless آن را اعمال نمی‌کرد)؛ انتظار <code>document.fonts.ready</code>؛ حذف عناصر fixed/کلیپ‌شده/ناوبری ثابت از سنجهٔ تداخل؛ محاسبهٔ هیت واقعی pseudo-element در سنجهٔ لمس.</li>
  <li><b>خروجی‌ها:</b> <code>report.html</code> (داده‌محور)، <code>data.json</code>، <code>shots/</code> (۶۵۸ شات)، <code>gallery-*.html</code>، <code>evidence/</code> (تصاویر شاهد).</li>
  <li><b>بستهٔ نهایی:</b> زیپ v118 ساخته شد — منهای داده‌ها/شات‌ها/گزارش‌های ممیزی/کش‌ها (طبق روال).</li>
</ul>

<p class="small" style="margin-top:30px">بازسازی ممیزی: <code style="direction:ltr">BZ=http://127.0.0.1:8080 python3 tools/design_audit.py --out /home/user/audit-design</code></p>

</div></body></html>"""

out = os.path.join(ROOT, "audit-report-fa.html")
open(out, "w", encoding="utf-8").write(html)
print("report:", out, f"{os.path.getsize(out)/1024:.0f}KB")
