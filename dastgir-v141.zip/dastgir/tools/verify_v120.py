#!/usr/bin/env python3
"""v120: pixel-level verification — element screenshots + sampled colors + contrast."""
import asyncio, os
from PIL import Image
from playwright.async_api import async_playwright

OUT = "/home/user/evidence-v120"
os.makedirs(OUT, exist_ok=True)
BASE = "http://localhost:8080"

def lum(hexc):
    r, g, b = [int(hexc[i:i+2], 16) / 255 for i in (0, 2, 4)]
    def f(c): return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)

def contrast(a, b):
    la, lb = lum(a), lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)

def avg_color(img):
    im = img.convert("RGB")
    px = im.load()
    w, h = im.size
    rs = gs = bs = n = 0
    for y in range(0, h, 4):
        for x in range(0, w, 4):
            r, g, b = px[x, y]
            rs += r; gs += g; bs += b; n += 1
    return "#%02x%02x%02x" % (rs // n, gs // n, bs // n)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        for theme in ("light", "dark"):
            pg = await b.new_page(viewport={"width": 1440, "height": 900})
            await pg.goto(BASE + "/", wait_until="networkidle")
            await pg.evaluate("document.documentElement.setAttribute('data-theme','%s')" % theme)
            await pg.wait_for_timeout(700)
            for sel, tag in [(".h-hero", "hero"), (".h-catcard", "cat"),
                             (".h-deal", "deal"), (".owner-cta", "cta"),
                             (".h-open", "open")]:
                el = pg.locator(sel).first
                if await el.count() == 0:
                    print(theme, tag, "MISSING"); continue
                await el.scroll_into_view_if_needed()
                await pg.wait_for_timeout(350)
                await el.screenshot(path=f"{OUT}/el-{theme}-{tag}.png")
                im = Image.open(f"{OUT}/el-{theme}-{tag}.png")
                print(theme, tag, "avg=", avg_color(im), "size=", im.size)
            # text colors from computed styles
            info = await pg.evaluate("""() => {
              const g = (s, p) => { const e = document.querySelector(s); return e ? getComputedStyle(e)[p] : null };
              return {h1: g('.h-hero h1','color'), lead: g('.h-hero-lead','color'),
                      catname: g('.h-catcard-name','color'), catbg: g('.h-catcard','backgroundColor'),
                      dealTitle: g('.h-deal .card-title','color'), dealBg: g('.h-deal','backgroundImage') !== 'none' ? 'grad' : g('.h-deal','backgroundColor'),
                      ctaP: g('.owner-cta p','color'), ctaBg: g('.owner-cta','backgroundImage') !== 'none' ? 'grad' : g('.owner-cta','backgroundColor'),
                      openBg: g('.h-open','backgroundColor'), openTxt: g('.h-open-head','color')};
            }""")
            print(theme, info)
            await pg.close()
        await b.close()

asyncio.run(main())
