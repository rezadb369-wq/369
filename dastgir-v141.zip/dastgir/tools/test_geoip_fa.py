# -*- coding: utf-8 -*-
"""
قفل فاز ۶ — نقشهٔ فارسی شهرهای GeoIP (v117)

  §G1  fold یونیکد: واریانت‌های اعراب‌دار (Yāsūj/Kermān/Shahreẕā) با یک
       کلید ASCII مچ می‌شوند.
  §G2  پوشش: ≥۹۷٪ رنج‌های CSV نام فارسی برمی‌گردانند (قبل از فاز ۶: ۸۵٪).
  §G3  اسپات‌چک شهرهای واقعی (IP از خود CSV خوانده می‌شود — بدون هردکد).
  §G4  خالیِ صادقانه: IPv6/خصوصی/نامعتبر → ("", "")، هرگز شهر ساختگی.
  §G5  هیچ خروجیِ نگاشت‌شده‌ای حرف لاتین ندارد.

    BZ=http://127.0.0.1:8080 python3 tools/test_geoip_fa.py
"""

import csv
import os
import socket
import struct
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import geoip        # noqa: E402

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append((label, detail))
        print(f"  \033[31m✗ {label}\033[0m  {detail}")


def head(t):
    print(f"\n\033[1m━━ {t}\033[0m")


def _rows():
    with open(os.path.join(HERE, "..", "server", "geoip_ir.csv"),
              newline="", encoding="utf-8") as f:
        return [r for r in csv.reader(f) if len(r) >= 4 and r[3]]


def ip_of(n):
    return socket.inet_ntoa(struct.pack("!I", int(n)))


def main():
    geoip._load()

    # ------------------------------------------------------------- §G1
    head("۶/G1 — fold یونیکد")
    check("fold اعراب را می‌گیرد",
          geoip._fold("Kermān") == geoip._fold("Kerman") == "kerman",
          f"{geoip._fold('Kermān')}")
    check("fold پسوند « (...)» را می‌گیرد",
          geoip._fold("Marand (District 20)") == "marand")
    check("کلیدها همه fold شده‌اند",
          all(k == geoip._fold(k) for k in geoip._CITY_KEYS),
          "non-folded key in _CITY_KEYS")

    # ------------------------------------------------------------- §G2
    head("۶/G2 — پوشش رنج‌ها ≥۹۷٪")
    rows = _rows()
    mapped = sum(1 for r in rows
                 if geoip._fold(r[3]) in geoip._CITY_KEYS)
    ratio = mapped / len(rows)
    check(f"پوشش {100*ratio:.1f}% ≥ ۹۷٪", ratio >= 0.97,
          f"{len(rows)-mapped} رنج بی‌نقشه از {len(rows)}")

    # ------------------------------------------------------------- §G3
    head("۶/G3 — اسپات‌چک شهرها")
    for latin, fa in [("Tehran", "تهران"), ("Birjand", "بیرجند"),
                      ("Yāsūj", "یاسوج"), ("Kujuvar", "کوجووار"),
                      ("Deh-e Torkaman", "ده ترکمان"),
                      ("Sabzawār", "سبزوار"),
                      ("Shahreẕā", "شهرضا")]:
        hit = next((r for r in rows if r[3] == latin), None)
        if not hit:
            check(f"{latin} در CSV هست", False, "not found")
            continue
        prov, city = geoip.lookup(ip_of(hit[0]))
        check(f"{latin} → {fa}", city == fa, f"got {city!r}")

    # نام بی‌نقشه → شهر خالی، استان می‌ماند (نه نام لاتین)
    unmapped = next((r for r in rows
                     if geoip._fold(r[3]) not in geoip._CITY_KEYS), None)
    if unmapped:
        prov, city = geoip.lookup(ip_of(unmapped[0]))
        check(f"«{unmapped[3]}» → شهر خالی + استان فارسی",
              city == "" and prov and not any(
                  ch.isascii() and ch.isalpha() for ch in prov),
              f"got ({prov!r}, {city!r})")

    # ------------------------------------------------------------- §G4
    head("۶/G4 — خالیِ صادقانه")
    for ip in ("::1", "192.168.1.7", "10.0.0.5", "127.0.0.1"):
        out = geoip.lookup(ip)
        check(f"{ip} → خالی", out == ("", ""), f"got {out!r}")

    # ------------------------------------------------------------- §G5
    head("۶/G5 — هیچ نام لاتین در خروجی نگاشت‌شده")
    import random
    sample = random.Random(369).sample(rows, 300)
    latin_leaks = []
    for r in sample:
        _, city = geoip.lookup(ip_of(r[0]))
        if city and any(ch.isascii() and ch.isalpha() for ch in city):
            latin_leaks.append((r[3], city))
    check("۳۰۰ نمونهٔ تصادفی بدون نشت لاتین", not latin_leaks,
          str(latin_leaks[:5]))

    print(f"\n\033[1m{'═' * 46}\033[0m")
    print(f"  {ok_n} ✓   {bad_n} ✗")
    if bad_n:
        for lbl, d in FAILS:
            print(f"  ✗ {lbl}  [{d}]")
        sys.exit(1)
    print("  قفل GeoIP فاز ۶ سبز است.")


if __name__ == "__main__":
    main()
