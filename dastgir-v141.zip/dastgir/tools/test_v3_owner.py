# -*- coding: utf-8 -*-
"""
The shopkeeper side of the v3 features, exercised through a real OTP
login and a real cookie session:

  · answering questions on their own shop (and being blocked from others')
  · the subscription page and buying a plan end to end
  · plan limits actually stopping an over-quota upload
  · edit-approval routing owner edits into the admin queue
"""

import os
import sys
import json
import urllib.parse
import urllib.request
import urllib.error
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
KEY = db.owner_token()

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


def session():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def req(op, path, data=None, method=None):
    url = BASE + path
    if data is None:
        r = urllib.request.Request(url, method=method or "GET")
    else:
        r = urllib.request.Request(
            url, data=urllib.parse.urlencode(data, doseq=True).encode(),
            method="POST")
        r.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        res = op.open(r, timeout=25)
        return res.getcode(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


def login(op, phone):
    """Full OTP round trip — no shortcuts, the same path a real owner takes."""
    req(op, "/login", {"phone": phone})
    row = db._one("SELECT code FROM otp WHERE phone=?", (db.norm_phone(phone),))
    if not row:
        return False
    code, _ = req(op, "/login/verify", {"phone": phone, "code": row["code"]})
    return code in (200, 303)


print(f"\n\033[1m\033[36mآزمون پنل فروشنده — قابلیت‌های نسخهٔ ۳ — {BASE}\033[0m")

# ---------------------------------------------------------------- fixtures
head("آماده‌سازی")
db.set_setting("edit_approval", "0")
cat = db.categories()[0]["slug"]
P1, P2 = "09135550011", "09135550022"
o1 = db.owner_by_phone(P1, create=True)
o2 = db.owner_by_phone(P2, create=True)
B1 = db.save_business({"name": "دکانٔ آزمون مالک یک", "cat_slug": cat,
                       "descr": "برای آزمون پنل فروشنده.", "phone": P1,
                       "status": "published", "owner_id": o1["id"]})
B2 = db.save_business({"name": "دکانٔ آزمون مالک دو", "cat_slug": cat,
                       "descr": "متعلق به مالک دیگر.", "phone": P2,
                       "status": "published", "owner_id": o2["id"]})
S1 = db.business(bid=B1)["slug"]
check("دو مالک و دو کسب‌وکار آزمایشی ساخته شد", bool(B1 and B2), f"{B1},{B2}")

A = session()
check("ورود مالک یک با کد پیامکی", login(A, P1), "")
code, html = req(A, "/my")
check("داشبورد مالک باز می‌شود", code == 200, f"code={code}")

# ---------------------------------------------------------------- Q&A
head("۱) پرسش و پاسخ در پنل فروشنده")
code, html = req(A, "/my/questions")
check("صفحهٔ پرسش و پاسخ باز می‌شود", code == 200, f"code={code}")
check("لینک آن در منوی فروشنده هست", '/my/questions' in html, "")

Q1 = db.add_question(B1, "مشتری", "ساعت تعطیلی جمعه‌ها چند است؟", auto_publish=True)
Q2 = db.add_question(B2, "مشتری دیگر", "این سؤال مال دکانٔ دیگری است.",
                     auto_publish=True)

code, html = req(A, "/my/questions")
check("پرسش کسب‌وکار خودش را می‌بیند", "ساعت تعطیلی جمعه" in html, "")
check("پرسش کسب‌وکار دیگری را نمی‌بیند",
      "مال دکانٔ دیگری" not in html, "نشت اطلاعات بین مالکان!")

req(A, f"/my/question/{Q1}", {"answer": "جمعه‌ها تا ساعت ۱۴ باز هستیم."})
q = db.question(Q1)
check("پاسخ فروشنده ذخیره شد",
      q["answer"] == "جمعه‌ها تا ساعت ۱۴ باز هستیم.", q["answer"])
check("پاسخ فروشنده با برچسب owner ثبت شد", q["answered_by"] == "owner",
      q["answered_by"])

code, _ = req(A, f"/my/question/{Q2}", {"answer": "دخالت غیرمجاز"})
check("پاسخ به پرسش کسب‌وکار دیگری ۴۰۳ می‌گیرد", code == 403, f"code={code}")
check("و متن آن پرسش دست‌نخورده ماند", db.question(Q2)["answer"] == "",
      db.question(Q2)["answer"])

code, html = req(A, f"/b/{S1}")
check("پاسخ روی صفحهٔ عمومی دیده می‌شود", "تا ساعت ۱۴ باز هستیم" in html, "")

# ---------------------------------------------------------------- plans
head("۲) صفحهٔ تعرفهٔ عمومی از پایگاه داده می‌آید")
code, html = req(A, "/pricing")
check("صفحهٔ تعرفه باز می‌شود", code == 200, f"code={code}")
for p in db.plans():
    check(f"پلن «{p['name']}» روی صفحه هست", p["name"] in html, "")

NP = db.save_plan({"name": "پلن تست تعرفه", "price": "999000", "months": "3",
                   "perks": "امکان یکتای آزمون", "active": "1"})
code, html = req(A, "/pricing")
check("پلن تازه بلافاصله در تعرفه ظاهر شد", "پلن تست تعرفه" in html, "")
check("امکانات پلن هم نمایش داده می‌شود", "امکان یکتای آزمون" in html, "")

NPSLUG = db.plan(pid=NP)["slug"]
db.save_plan({"name": "پلن تست تعرفه", "price": "999000", "months": "3",
              "perks": "امکان یکتای آزمون", "active": "0"}, NP)
code, html = req(A, "/pricing")
check("غیرفعال کردن پلن آن را از تعرفه حذف می‌کند",
      "پلن تست تعرفه" not in html, "")
db.save_plan({"name": "پلن تست تعرفه", "price": "999000", "months": "3",
              "featured_slots": "1", "max_items": "3", "max_photos": "2",
              "perks": "امکان یکتای آزمون", "active": "1"}, NP)

# ---------------------------------------------------------------- subscribe
head("۳) خرید اشتراک از سمت فروشنده")
db.set_settings({"pay_method": "manual", "pay_card": "6037991111222233",
                 "pay_card_name": "بازارچه نجف‌آباد"})
code, html = req(A, f"/subscribe?plan={NPSLUG}")
check("صفحهٔ خرید پلن باز می‌شود", code == 200, f"code={code}")
check("شمارهٔ کارت پرداخت نمایش داده می‌شود", "6037991111222233" in html, "")
check("کسب‌وکار مالک در فرم هست", "دکانٔ آزمون مالک یک" in html, "")
check("کسب‌وکار مالک دیگر در فرم نیست",
      "دکانٔ آزمون مالک دو" not in html, "نشت بین مالکان!")

n0 = len(db.subscriptions(biz_id=B1))
req(A, "/subscribe", {"plan": NPSLUG, "biz_id": str(B1), "ref": "PAY-9911"})
subs = db.subscriptions(biz_id=B1)
check("درخواست اشتراک ثبت شد", len(subs) == n0 + 1, f"{n0} -> {len(subs)}")
SID = subs[0]["id"] if subs else None
check("در وضعیت «در انتظار پرداخت» است",
      subs and subs[0]["status"] == "pending", subs[0]["status"] if subs else "—")
check("کد پیگیری ذخیره شد", subs and subs[0]["ref"] == "PAY-9911",
      subs[0]["ref"] if subs else "—")

code, _ = req(A, "/subscribe", {"plan": NPSLUG, "biz_id": str(B2), "ref": "X"})
check("خرید پلن برای کسب‌وکار دیگری مسدود است",
      not [x for x in db.subscriptions(biz_id=B2) if x["ref"] == "X"], "")

code, html = req(A, "/my/plan")
check("صفحهٔ «اشتراک من» باز می‌شود", code == 200, f"code={code}")
check("درخواست در انتظار به فروشنده اعلام می‌شود",
      "در انتظار تأیید پرداخت" in html, "")

# admin approves
adm = session()
req(adm, f"/panel/subscription/{SID}", {"key": KEY, "action": "activate"})
sub = db.subscription_of(B1)
check("تأیید مدیر اشتراک را فعال کرد", sub and sub["status"] == "active",
      str(sub and sub["status"]))
check("کسب‌وکار ویژه شد", db.business(bid=B1)["featured"] == 1,
      str(db.business(bid=B1)["featured"]))

code, html = req(A, "/my/plan")
check("فروشنده پلن فعالش را می‌بیند", "پلن تست تعرفه" in html, "")
check("تاریخ انقضا به فروشنده نشان داده می‌شود", "اعتبار تا" in html, "")

# ---------------------------------------------------------------- limits
head("۴) سقف پلن واقعاً جلوی افزودن را می‌گیرد")
lim = db.plan_limits(B1)
check("سقف کالا از پلن خوانده می‌شود", lim["max_items"] == 3, str(lim))

for i in range(3):
    db.save_item({"biz_id": B1, "title": f"کالای آزمون {i+1}",
                  "price": "1000", "price_type": "fixed"})
check("سه کالا تا سقف افزوده شد", db.items_count(B1) == 3,
      str(db.items_count(B1)))

# the opener follows the redirect, so `html` is already the page the
# shopkeeper lands on — the flash must be right there, not on a later visit
code, html = req(A, f"/my/catalog/{B1}/item/new",
                 {"title": "کالای چهارم — باید رد شود", "kind": "product",
                  "price": "5000", "price_type": "fixed"})
check("افزودن فراتر از سقف انجام نشد", db.items_count(B1) == 3,
      str(db.items_count(B1)))
check("پیام سقف پلن بلافاصله به فروشنده نمایش داده می‌شود",
      "سقف پلن" in html and "alert-error" in html, "")
check("پیام راه‌حل هم می‌دهد (ارتقای پلن)", "ارتقا" in html, "")

# raising the plan raises the ceiling — same code path, no special case
db.save_plan({"name": "پلن تست تعرفه", "price": "999000", "months": "3",
              "featured_slots": "1", "max_items": "10", "max_photos": "2",
              "perks": "امکان یکتای آزمون", "active": "1"}, NP)
req(A, f"/my/catalog/{B1}/item/new",
    {"title": "کالای چهارم — حالا مجاز", "kind": "product",
     "price": "5000", "price_type": "fixed"})
check("پس از بالا بردن سقف، افزودن ممکن شد", db.items_count(B1) == 4,
      str(db.items_count(B1)))

# ---------------------------------------------------------------- approval
head("۵) تأیید تغییرات پروفایل")
db.set_setting("edit_approval", "1")
n0 = len(db.pending_edits())
req(A, f"/my/business/{B1}", {"name": "دکانٔ آزمون مالک یک",
                              "cat_slug": cat, "descr": "توضیح تازه از فروشنده",
                              "phone": P1, "address": "نشانی تازهٔ فروشنده",
                              "whatsapp": "", "tags": "", "instagram": "",
                              "telegram": "", "website": "", "lat": "", "lng": ""})
check("ویرایش فروشنده وارد صف تأیید شد",
      len(db.pending_edits()) == n0 + 1, f"{n0} -> {len(db.pending_edits())}")
check("تغییر هنوز روی سایت اعمال نشده",
      db.business(bid=B1)["address"] != "نشانی تازهٔ فروشنده",
      db.business(bid=B1)["address"])

EID = db.pending_edits()[0]["id"]
req(adm, f"/panel/edit/{EID}", {"key": KEY, "action": "approve"})
check("پس از تأیید مدیر، تغییر اعمال شد",
      db.business(bid=B1)["address"] == "نشانی تازهٔ فروشنده",
      db.business(bid=B1)["address"])

db.set_setting("edit_approval", "0")
req(A, f"/my/business/{B1}", {"name": "دکانٔ آزمون مالک یک",
                              "cat_slug": cat, "descr": "توضیح بدون تأیید",
                              "phone": P1, "address": "نشانی مستقیم",
                              "whatsapp": "", "tags": "", "instagram": "",
                              "telegram": "", "website": "", "lat": "", "lng": ""})
check("با خاموش بودن کلید، ویرایش مستقیم اعمال می‌شود",
      db.business(bid=B1)["address"] == "نشانی مستقیم",
      db.business(bid=B1)["address"])

# ---------------------------------------------------------------- isolation
head("۶) جداسازی کامل بین مالکان")
for path in [f"/my/business/{B2}", f"/my/catalog/{B2}", f"/my/gallery/{B2}",
             f"/my/stats/{B2}"]:
    code, _ = req(A, path)
    check(f"{path} برای مالک دیگر ۴۰۳ است", code == 403, f"code={code}")

B = session()
check("ورود مالک دو", login(B, P2), "")
code, html = req(B, "/my/questions")
check("مالک دو فقط پرسش خودش را می‌بیند",
      "مال دکانٔ دیگری" in html and "ساعت تعطیلی جمعه" not in html, "")
code, html = req(B, "/my/plan")
check("مالک دو اشتراک مالک یک را نمی‌بیند",
      "پلن تست تعرفه" not in html, "نشت اشتراک!")

# ---------------------------------------------------------------- cleanup
head("۷) پاک‌سازی")
db.delete_business(B1)
db.delete_business(B2)
db.delete_plan(NP)
for _p in (P1, P2):
    _o = db.owner_by_phone(_p)
    if _o:
        db.delete_owner(_o["id"])
db.set_settings({"pay_card": "", "pay_card_name": "", "edit_approval": "0"})
db.rate_clear()
check("کسب‌وکارهای آزمایشی حذف شدند",
      db.business(bid=B1) is None and db.business(bid=B2) is None, "")
check("مالکان آزمایشی حذف شدند",
      db.owner_by_phone(P1) is None and db.owner_by_phone(P2) is None, "")
check("پلن آزمایشی حذف شد", db.plan(pid=NP) is None, "")

print(f"\n\033[1m{'='*58}\033[0m")
if bad_n == 0:
    print(f"\033[1m\033[32m  همه موفق — {ok_n} آزمون، ۰ ناموفق\033[0m")
else:
    print(f"\033[1m\033[31m  {ok_n} موفق، {bad_n} ناموفق\033[0m")
    for f in FAILS:
        print(f"    • {f}")
print(f"\033[1m{'='*58}\033[0m\n")
sys.exit(1 if bad_n else 0)
