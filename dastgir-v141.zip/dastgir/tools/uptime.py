#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
uptime.py — پایش لحظه‌ایِ سلامت «دستگیر» + هشدار تلگرام
========================================================

هر اجرا یک بار وضعیت را می‌سنجد، تغییر وضعیت را ثبت می‌کند و در صورت
بالا/پایین‌شدن سایت به تلگرام خبر می‌دهد. برای اجرای دوره‌ای با
`tools/install-monitor.sh` (systemd timer هر ۲ دقیقه یا cron) نصب می‌شود.

بررسی‌ها:
  · healthz  (پیش‌فرض http://127.0.0.1:8080/healthz) — «ok» یعنی دیتابیس هم سالم است
  · صفحهٔ اصلی (اختیاری) — ۲۰۰ + وجود <title>

تنظیمات (متغیرهای محیطی):
  BZ_HEALTH_URL   نشانی بررسی سلامت (پیش‌فرض localhost:8080/healthz)
  BZ_HOME_URL     نشانی صفحهٔ اصلی (اختیاری)
  BZ_TG_TOKEN / BZ_TG_CHAT_ID   تلگرام (اگر نباشد از دیتابیس خوانده می‌شود)
  BZ_REALERT_MIN  فاصلهٔ یادآوری مجدد هنگام قطعی (دقیقه، پیش‌فرض ۶۰)
  BZ_STATE_DIR    محل فایل وضعیت و لاگ (پیش‌فرض /var/lib/bazarche)

کدهای خروج: 0 = بررسی شد (بالا یا پایین) · 1 = خطای داخلی
"""

import datetime
import json
import os
import sys
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cloudsend

APP_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DB_PATH = os.path.join(os.environ.get("BZ_DATA_DIR")
                       or os.path.join(APP_ROOT, "data"), "bazarche.db")
STATE_DIR = os.environ.get("BZ_STATE_DIR", "/var/lib/bazarche")
HEALTH_URL = os.environ.get("BZ_HEALTH_URL",
                            "http://127.0.0.1:8080/healthz")
HOME_URL = os.environ.get("BZ_HOME_URL", "").strip()
REALERT_MIN = 60
try:
    REALERT_MIN = int(os.environ.get("BZ_REALERT_MIN", "60"))
except ValueError:
    pass

STATE_FILE = os.path.join(STATE_DIR, "uptime.state")
LOG_FILE = os.path.join(STATE_DIR, "uptime.log")


def now():
    return datetime.datetime.now()


def check_one(url, need="status"):
    """-> (ok, detail). need: 'status' = هر 200 کافی؛ 'ok' = بدنه باید «ok»؛
    'title' = بدنه باید <title> داشته باشد."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "dastgir-uptime"})
        with urllib.request.urlopen(req, timeout=10) as r:
            code = r.status
            body = r.read(200000).decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return False, f"HTTP {e.code}"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"[:120]
    if code != 200:
        return False, f"HTTP {code}"
    if need == "ok" and body.strip() != "ok":
        return False, "پاسخ healthz غیرعادی است"
    if need == "title" and "<title>" not in body:
        return False, "بدون <title>"
    return True, "ok"


def check_all():
    details = []
    ok_h, d = check_one(HEALTH_URL, "ok")
    details.append(("healthz", ok_h, d))
    if HOME_URL:
        ok_m, d = check_one(HOME_URL, "title")
        details.append(("home", ok_m, d))
    up = all(x[1] for x in details)
    return up, details


def load_state():
    try:
        with open(STATE_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"status": "up", "since": now().timestamp(),
                "last_alert": 0.0}


def save_state(st):
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False)


def log_line(msg):
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"{now().strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")


def tg_alert(text):
    token, chat = cloudsend.read_telegram_settings(DB_PATH)
    ok, detail = cloudsend.telegram_send_text(token, chat, text)
    log_line("telegram " + ("ok" if ok else f"fail ({detail})"))


def main():
    up, details = check_all()
    state = load_state()
    ts = now().timestamp()
    detail_str = " · ".join(
        f"{name}={'✓' if ok else '✗'}({d})" for name, ok, d in details)

    prev = state.get("status", "up")
    changed = up != (prev == "up")

    if changed:
        prev_since = state.get("since", ts)
        state["status"] = "up" if up else "down"
        state["since"] = ts
        state["last_alert"] = ts
        if up:
            duration = ""
            try:
                duration = _human(ts - prev_since)
            except Exception:
                duration = ""
            tg_alert(f"✅ دستگیر دوباره آنلاین شد.\nمدت قطعی: {duration}\n"
                     f"{detail_str}")
            log_line(f"UP after {duration} — {detail_str}")
            print(f"✅ UP (بازگشت پس از {duration}) — {detail_str}")
        else:
            tg_alert(f"🚨 دستگیر از دسترس خارج شد!\n{detail_str}\n"
                     f"زمان: {now().strftime('%Y-%m-%d %H:%M:%S')}")
            log_line(f"DOWN — {detail_str}")
            print(f"🚨 DOWN — {detail_str}", file=sys.stderr)
    elif not up:
        # همچنان پایین است؛ برای قطعی طولانی، هر REALERT_MIN دقیقه یادآوری
        if ts - state.get("last_alert", 0) >= REALERT_MIN * 60:
            state["last_alert"] = ts
            tg_alert(f"⚠ دستگیر همچنان از دسترس خارج است.\n{detail_str}\n"
                     f"از {datetime.datetime.fromtimestamp(state.get('since', ts)).strftime('%H:%M')}")
            log_line(f"DOWN (reminder) — {detail_str}")
            print(f"⚠ DOWN (reminder) — {detail_str}", file=sys.stderr)
        else:
            print(f"down (no change) — {detail_str}")
    else:
        print(f"up — {detail_str}")

    # لاگ ضربان قلب ساعتی (برای اینکه معلوم شود پایش زنده است)
    state["_hb"] = ts
    save_state(state)
    return 0


def _human(seconds):
    m = int(seconds // 60)
    if m < 60:
        return f"{m} دقیقه"
    h = m // 60
    return f"{h} ساعت و {m % 60} دقیقه"


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print(f"✗ uptime error: {e}", file=sys.stderr)
        sys.exit(1)
