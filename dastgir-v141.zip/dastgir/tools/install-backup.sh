#!/usr/bin/env bash
# ============================================================================
#  نصب بکاپ‌گیری خودکار شبانه برای «دستگیر»
#  ---------------------------------------------------------------------------
#  یک بکاپ سازگار (tools/backup.py) هر شب ساعت ۳ اجرا می‌شود:
#    · systemd timer  (ترجیحی — لاگ در journalctl)
#    · cron           (اگر systemd نبود)
#
#  استفاده:
#      sudo bash tools/install-backup.sh
#  ---------------------------------------------------------------------------
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/bazarche}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/bazarche}"
PY="${PY:-/usr/bin/python3}"
HOUR="${HOUR:-3}"

[[ "$(id -u)" -eq 0 ]] || { echo "✗ با sudo اجرا کنید." >&2; exit 1; }

BACKUP_CMD="$PY $APP_DIR/tools/backup.py --dir $BACKUP_DIR --telegram --s3"

# پوشهٔ مقصد
mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"

echo "→ تست فوری یک بکاپ …"
if ! $BACKUP_CMD; then
  echo "✗ بکاپ آزمایشی ناموفق بود؛ نصب انجام نشد." >&2
  exit 1
fi
echo "  ✓ بکاپ آزمایشی موفق بود."

if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
  echo "→ نصب systemd timer (هر شب ساعت $HOUR) …"
  cat > /etc/systemd/system/bazarche-backup.service <<EOF
[Unit]
Description=Dastgir nightly backup (safe online SQLite snapshot)
After=network.target

[Service]
Type=oneshot
User=root
EnvironmentFile=-/etc/default/bazarche
ExecStart=$BACKUP_CMD

[Install]
WantedBy=multi-user.target
EOF
  cat > /etc/systemd/system/bazarche-backup.timer <<EOF
[Unit]
Description=Run Dastgir backup daily

[Timer]
OnCalendar=*-*-* $HOUR:00:00
RandomizedDelaySec=900
Persistent=true

[Install]
WantedBy=timers.target
EOF
  systemctl daemon-reload
  systemctl enable --now bazarche-backup.timer
  echo "✓ timer فعال شد."
  echo ""
  echo "  اجرای دستی:   systemctl start bazarche-backup.service"
  echo "  دیدن وضعیت:   systemctl list-timers bazarche-backup.timer"
  echo "  دیدن لاگ‌ها:  journalctl -u bazarche-backup.service -n 50"
else
  echo "→ systemd پیدا نشد؛ نصب cron …"
  CRON_LINE="0 $HOUR * * * $BACKUP_CMD >> $BACKUP_DIR/backup.log 2>&1"
  ( crontab -l 2>/dev/null | grep -v "tools/backup.py" ; echo "$CRON_LINE" ) | crontab -
  echo "✓ خط cron ثبت شد:"
  echo "    $CRON_LINE"
fi

echo ""
echo "✓ نصب کامل شد. بکاپ‌ها در $BACKUP_DIR نگه داشته می‌شوند."
echo "  گردش نسخه‌ها: ۱۴ روزانه + ۸ هفتگی + ۱۲ ماهانه (قدیمی‌ترها حذف می‌شوند)."
echo ""
echo "  ⚠ نکتهٔ امنیتی مهم: این بکاپ‌ها روی همان سرورند. برای حفاظت واقعی"
echo "     در برابر خرابی/هک سرور، هر چند روز یک‌بار یک نسخه را به جای امنی"
echo "     بیرون از سرور منتقل کنید (مثلاً دانلود «بکاپ کامل» از پنل مدیریت)."
