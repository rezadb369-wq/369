#!/usr/bin/env python3
"""
Slice the generated 3x3 icon sheets into individual square PNGs with a
transparent background, auto-cropped to the icon's own bounding box.

- white background -> alpha (soft threshold so anti-aliased edges survive)
- trims to content, then re-pads to a square canvas with consistent margin
- exports @1x (128px) and @2x (256px)
"""
import os
from PIL import Image, ImageFilter
import numpy as np

RAW = os.path.join(os.path.dirname(__file__), '..', 'raw')
OUT = os.path.join(os.path.dirname(__file__), '..', 'site', 'assets', 'img', 'icons')
os.makedirs(OUT, exist_ok=True)

SHEETS = {
    'icons-sheet-1.png': [
        'restaurant', 'shopping', 'cafe',
        'medical', 'auto', 'realestate',
        'barber', 'education', 'bakery',
    ],
    'icons-sheet-2.png': [
        'mobile', 'flowers', 'gym',
        'homeservice', 'photography', 'jewellery',
        'clothing', 'confectionery', 'pin',
    ],
}

WHITE_CUT = 238      # pixels brighter than this on all channels start fading out
WHITE_FULL = 252     # pixels brighter than this are fully transparent
MARGIN = 0.07        # square padding as a fraction of the final size


def remove_white(img: Image.Image) -> Image.Image:
    """Turn the near-white studio backdrop into alpha, keeping soft edges."""
    img = img.convert('RGBA')
    a = np.array(img).astype(np.float32)
    rgb = a[..., :3]

    # brightness of the *darkest* channel: coloured pixels keep a low value
    mn = rgb.min(axis=2)

    alpha = np.ones_like(mn)
    alpha[mn >= WHITE_FULL] = 0.0
    ramp = (mn > WHITE_CUT) & (mn < WHITE_FULL)
    alpha[ramp] = 1.0 - (mn[ramp] - WHITE_CUT) / float(WHITE_FULL - WHITE_CUT)

    a[..., 3] = a[..., 3] * alpha
    return Image.fromarray(a.astype(np.uint8), 'RGBA')


def largest_blob_bbox(alpha: np.ndarray, thresh: int = 24):
    """Bounding box of visible content (simple mask bbox, robust enough here)."""
    ys, xs = np.where(alpha > thresh)
    if len(xs) == 0:
        return None
    return xs.min(), ys.min(), xs.max() + 1, ys.max() + 1


def squarify(img: Image.Image, size: int) -> Image.Image:
    """Crop to content, then centre on a transparent square with even margin."""
    arr = np.array(img)
    bbox = largest_blob_bbox(arr[..., 3])
    if bbox:
        img = img.crop(bbox)

    inner = int(size * (1 - 2 * MARGIN))
    w, h = img.size
    scale = inner / max(w, h)
    nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    img = img.resize((nw, nh), Image.LANCZOS)

    canvas = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    canvas.paste(img, ((size - nw) // 2, (size - nh) // 2), img)
    return canvas


def main():
    made = []
    for sheet, names in SHEETS.items():
        path = os.path.join(RAW, sheet)
        if not os.path.exists(path):
            print(f'!! missing {path}')
            continue

        src = remove_white(Image.open(path))
        W, H = src.size
        cw, ch = W // 3, H // 3

        for i, name in enumerate(names):
            r, c = divmod(i, 3)
            cell = src.crop((c * cw, r * ch, (c + 1) * cw, (r + 1) * ch))

            if largest_blob_bbox(np.array(cell)[..., 3]) is None:
                print(f'   (empty cell for {name}, skipped)')
                continue

            for size, suffix in ((256, '@2x'), (128, '')):
                out = squarify(cell, size)
                fp = os.path.join(OUT, f'{name}{suffix}.png')
                out.save(fp, 'PNG', optimize=True)
            made.append(name)
            print(f' ok  {name}.png + {name}@2x.png')

    print(f'\n{len(made)} icons written to {os.path.abspath(OUT)}')


if __name__ == '__main__':
    main()
