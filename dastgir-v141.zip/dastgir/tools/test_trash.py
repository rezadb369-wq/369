"""v105 — functional test for the soft-delete recycle bin.

Covers every entity: story, item, review, report.
For each: create -> delete (goes to trash) -> appears in trash ->
restore -> back live and gone from trash. Plus the 7-day purge.

Run against the live server's DB (stdlib only, no network needed):
    cd site/bazarche/bazarche && python3 tools/test_trash.py
"""
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "server"))

import db
import features as F

PASS = FAIL = 0


def check(cond, label):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  \u2713 " + label)
    else:
        FAIL += 1
        print("  \u2717 " + label)


def in_trash(entity, ref_id):
    return [r for r in db.trash_list() if r["entity"] == entity and r["ref_id"] == ref_id]


def live(table, ref_id):
    return db._one(f"SELECT * FROM {table} WHERE id=?", (ref_id,)) is not None


def cycle(entity, table, create, delete, label):
    """create -> delete -> in trash -> restore -> live again."""
    rid = create()
    check(live(table, rid), f"{label}: created live (id {rid})")
    delete(rid)
    check(not live(table, rid), f"{label}: removed from {table} after delete")
    rows = in_trash(entity, rid)
    check(len(rows) == 1, f"{label}: snapshot in recycle bin")
    if rows:
        tid = rows[0]["id"]
        ok = db.trash_restore(tid)
        check(ok, f"{label}: restore returned True")
        check(live(table, rid), f"{label}: back live after restore")
        check(len(in_trash(entity, rid)) == 0, f"{label}: gone from bin after restore")
    return rid


def main():
    db.init()
    biz = db._one("SELECT id FROM businesses ORDER BY id LIMIT 1")
    if not biz:
        print("  \u2717 no business row to test against")
        return 1
    biz_id = biz["id"]
    print(f"\n  testing recycle bin against business id={biz_id}\n")

    created = {}

    # --- ITEM ---
    created["item"] = cycle(
        "item", "items",
        lambda: db.save_item({"biz_id": biz_id, "title": "TRASHTEST item", "price": 1000}),
        db.delete_item, "item")

    # --- REVIEW (add_review does not return the id; look it up) ---
    def _mk_review():
        db.add_review(biz_id, "TRASHTESTer", 5, "TRASHTEST review", auto_approve=True)
        return db._one("SELECT id FROM reviews WHERE author='TRASHTESTer' "
                       "ORDER BY id DESC LIMIT 1")["id"]
    created["review"] = cycle(
        "review", "reviews", _mk_review, db.delete_review, "review")

    # --- REPORT ---
    created["report"] = cycle(
        "report", "reports",
        lambda: db.add_report("business", biz_id, "other", "TRASHTEST report",
                              reporter="TRASHTESTer", biz_id=biz_id),
        db.delete_report, "report")

    # --- STORY ---
    created["story"] = cycle(
        "story", "stories",
        lambda: F.stories_add(biz_id, "/uploads/test.png", "TRASHTEST story", "image", 5),
        F.story_delete, "story")

    # --- biz-scoped listing (owner view) only shows this biz's rows ---
    probe = db.save_item({"biz_id": biz_id, "title": "TRASHTEST scoped", "price": 1})
    db.delete_item(probe)
    mine = db.trash_list(entities=["item"], biz_ids=[biz_id])
    check(any(r["ref_id"] == probe for r in mine), "owner scope: own deleted item listed")
    other = db.trash_list(entities=["item"], biz_ids=[-999])
    check(all(r["ref_id"] != probe for r in other), "owner scope: other biz not leaked")
    db.trash_restore([r["id"] for r in mine if r["ref_id"] == probe][0])

    # --- v109: per-entity retention — story 7 days, item/review/report 24h ---
    ret_item = db.save_item({"biz_id": biz_id, "title": "TRASHTEST retention item", "price": 1})
    db.delete_item(ret_item)
    ret_story = F.stories_add(biz_id, "/uploads/test.png", "TRASHTEST retention story", "image", 5)
    F.story_delete(ret_story)
    # age both rows to 2 days: the item must be gone, the story must remain
    db._run("UPDATE trash SET deleted_at=? WHERE title LIKE 'TRASHTEST retention%'",
            (time.time() - 2 * 86400,))
    db.trash_purge()
    check(len(in_trash("story", ret_story)) == 1, "retention: 2-day-old story STAYS (7d window)")
    check(len(in_trash("item", ret_item)) == 0, "retention: 2-day-old item is purged (24h window)")
    check(not live("items", ret_item), "retention: purged item not resurrected")
    # a brand-new item is still inside its 24h window
    fresh_item = db.save_item({"biz_id": biz_id, "title": "TRASHTEST fresh item", "price": 1})
    db.delete_item(fresh_item)
    check(len(in_trash("item", fresh_item)) == 1, "retention: fresh item in bin")
    # a story restored AFTER its 24h life gets a fresh 24h life on restore
    F.stories_add(biz_id, "/uploads/test.png", "TRASHTEST revive story", "image", 5)
    revive = db._one("SELECT id FROM stories WHERE caption='TRASHTEST revive story'")["id"]
    F.story_delete(revive)
    row = db._one("SELECT * FROM trash WHERE ref_id=? AND entity='story'", (revive,))
    import json as _json
    payload = _json.loads(row["payload"]); payload["expires"] = time.time() - 3600
    db._run("UPDATE trash SET payload=? WHERE id=?", (_json.dumps(payload), row["id"]))
    check(db.trash_restore(row["id"]), "revive: restore returned True")
    st = db._one("SELECT expires FROM stories WHERE id=?", (revive,))
    check(bool(st) and st["expires"] > time.time() + 23 * 3600,
          "revive: restored expired story got a fresh 24h life")

    # --- long-purge (7 days) still applies ---
    stale = db.save_item({"biz_id": biz_id, "title": "TRASHTEST stale", "price": 1})
    db.delete_item(stale)
    old = [r for r in db.trash_list(entities=["item"]) if r["ref_id"] == stale][0]
    db._run("UPDATE trash SET deleted_at=? WHERE id=?",
            (time.time() - (db.TRASH_DAYS + 1) * 86400, old["id"]))
    db.trash_purge()
    check(len(in_trash("item", stale)) == 0, f"purge: >{db.TRASH_DAYS}d row hard-deleted")
    check(not live("items", stale), "purge: stale item stays gone (no auto-restore)")

    # --- v109: an EXPIRED story (24h life over) lands in the bin too ---
    exp = F.stories_add(biz_id, "/uploads/test.png", "TRASHTEST expired story", "image", 5)
    db._run("UPDATE stories SET expires=? WHERE id=?", (time.time() - 60, exp))
    F.stories_active()                       # sweeps expired rows
    check(len(in_trash("story", exp)) == 1, "expiry: expired story snapshotted to bin (not erased)")
    check(not live("stories", exp), "expiry: expired story removed from live table")
    check(db.trash_restore([r for r in db.trash_list() if r["entity"] == "story" and r["ref_id"] == exp][0]["id"]),
          "expiry: expired story restorable")
    check(live("stories", exp) and db._one("SELECT expires FROM stories WHERE id=?", (exp,))["expires"] > time.time(),
          "expiry: restored story is live again with fresh 24h")

    # --- cleanup: remove every row this test created, live or trashed ---
    db._run("DELETE FROM items WHERE title LIKE 'TRASHTEST%'")
    db._run("DELETE FROM reviews WHERE author='TRASHTESTer'")
    db._run("DELETE FROM reports WHERE reporter='TRASHTESTer'")
    db._run("DELETE FROM stories WHERE caption LIKE 'TRASHTEST%'")
    db._run("DELETE FROM trash WHERE title LIKE '%TRASHTEST%'")

    print(f"\n  \u0645\u0648\u0641\u0642: {PASS}   \u0646\u0627\u0645\u0648\u0641\u0642: {FAIL}\n")
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
