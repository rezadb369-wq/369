"""ساخت تصاویر شاهد (نسخهٔ ۲): کراپ بر اساس rect عنصر پس از scrollIntoView."""
import asyncio, sys, io, os
sys.path.insert(0, os.path.dirname(__file__))
from design_audit import BASE, new_context, clear_audit_ratelimit
from playwright.async_api import async_playwright
from PIL import Image

OUT = "/home/user/audit-design/evidence"
os.makedirs(OUT, exist_ok=True)

FIX_JS = """
const __auditInject = () => {
  const st = document.createElement('style');
  st.textContent = 'details:not([open]) > :not(summary){display:none !important}';
  document.documentElement.appendChild(st);
};
if (document.documentElement) __auditInject();
else document.addEventListener('DOMContentLoaded', __auditInject, { once: true });
"""
WAIT = "Promise.race([document.fonts.ready.then(()=>true), new Promise(r=>setTimeout(()=>r(false),2500))])"


async def crop_el(p, el_js, path, pad=10, max_w=440, max_h=560):
    """scrollIntoView + کراپ دور عنصر (مختصات viewport)."""
    await p.evaluate(f"""() => {{ const el = {el_js}; if (el) el.scrollIntoView({{block:'center'}}); }}""")
    await p.wait_for_timeout(400)
    r = await p.evaluate(f"""() => {{ const el = {el_js}; if (!el) return null;
      const b = el.getBoundingClientRect();
      return {{x: Math.round(b.x), y: Math.round(b.y), w: Math.round(b.width), h: Math.round(b.height)}}; }}""")
    if not r:
        print("✗ عنصر پیدا نشد:", path)
        return
    x, y = max(0, r["x"] - pad), max(0, r["y"] - pad)
    raw = await p.screenshot(type="png")
    im = Image.open(io.BytesIO(raw)).convert("RGB")
    cw, ch = im.size
    x2, y2 = min(x + r["w"] + pad * 2, cw), min(y + r["h"] + pad * 2, ch)
    if x2 <= x or y2 <= y:
        print("✗ کراپ خالی:", path); return
    crop = im.crop((x, y, x2, y2))
    if crop.width > max_w or crop.height > max_h:
        crop.thumbnail((max_w, max_h), Image.LANCZOS)
    crop.save(path, "WEBP", quality=82, method=4)
    print("✓", path, crop.size)


async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"])

        # F1: عنوان لهشده — کارت ویژهٔ اول businesses
        c = await b.new_context(viewport={"width": 320, "height": 568}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        p = await c.new_page()
        await p.goto(BASE + "/businesses", wait_until="domcontentloaded")
        await p.wait_for_timeout(500); await p.evaluate(WAIT)
        await crop_el(p, "document.querySelector('.biz-card')", f"{OUT}/f1_title_squeeze.webp", pad=10, max_w=480, max_h=700)
        await c.close()

        # F2: biz-detail — دکمهٔ مقایسه و ستارهها
        c = await b.new_context(viewport={"width": 390, "height": 844}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        p = await c.new_page()
        await p.goto(BASE + "/b/kbaby-bradran-hydry", wait_until="domcontentloaded")
        await p.wait_for_timeout(600); await p.evaluate(WAIT)
        await crop_el(p, "document.querySelector('.cmp-btn')", f"{OUT}/f2_cmp_btn.webp", pad=14)
        await p.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        await p.wait_for_timeout(600)
        await crop_el(p, "document.querySelector('.crit-stars')", f"{OUT}/f2b_stars.webp", pad=16)
        await c.close()

        # F3: owner/my — ستون دکمههای باریک
        c = await b.new_context(viewport={"width": 390, "height": 844}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        clear_audit_ratelimit()
        cookies = new_context(None, "owner", None, None)
        if cookies: await c.add_cookies(cookies)
        p = await c.new_page()
        await p.goto(BASE + "/my", wait_until="domcontentloaded")
        await p.wait_for_timeout(600); await p.evaluate(WAIT)
        await p.wait_for_timeout(1200)
        await p.evaluate("window.scrollTo(0, 3000)")
        await p.wait_for_timeout(900)
        await crop_el(p, "[...document.querySelectorAll('.btn-sm')].find(el => { const b = el.getBoundingClientRect(); return b.width > 0 && b.width < 40; }).closest('.card, .row, .list-item') || [...document.querySelectorAll('.btn-sm')].find(el => { const b = el.getBoundingClientRect(); return b.width > 0 && b.width < 40; })", f"{OUT}/f3_btn_sm.webp", pad=12, max_w=480, max_h=760)
        await c.close()

        # F6: customer/me — دکمهٔ بستن یادآور
        c = await b.new_context(viewport={"width": 390, "height": 844}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        clear_audit_ratelimit()
        cookies = new_context(None, "customer", None, None)
        if cookies: await c.add_cookies(cookies)
        p = await c.new_page()
        await p.goto(BASE + "/me", wait_until="domcontentloaded")
        await p.wait_for_timeout(600); await p.evaluate(WAIT)
        await crop_el(p, "document.querySelector('.pw-reminder-x')", f"{OUT}/f6_pw_x.webp", pad=18)
        await c.close()

        # F8: panel m320 — متن 10px
        c = await b.new_context(viewport={"width": 320, "height": 568}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        clear_audit_ratelimit()
        import sys as _s, pathlib as _p; _s.path.insert(0, str(_p.Path(__file__).resolve().parent.parent / "server"))
        import db as _db
        _db.init()
        _key = _db.owner_token()
        cookies = new_context(None, "panel", _key, None)
        if cookies: await c.add_cookies(cookies)
        p = await c.new_page()
        await p.goto(BASE + "/panel", wait_until="domcontentloaded")
        await p.wait_for_timeout(600); await p.evaluate(WAIT)
        await crop_el(p, "[...document.querySelectorAll('small.text-muted')].find(el => { const cs = getComputedStyle(el); return parseFloat(cs.fontSize) < 12 && el.getBoundingClientRect().width > 0; })", f"{OUT}/f8_small10.webp", pad=10)
        await c.close()

        # F10: home d1440 — blurb بریدهشده
        c = await b.new_context(viewport={"width": 1440, "height": 900}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        p = await c.new_page()
        await p.goto(BASE + "/", wait_until="domcontentloaded")
        await p.wait_for_timeout(500); await p.evaluate(WAIT)
        await crop_el(p, "[...document.querySelectorAll('span.blurb')].find(el => { const cs = getComputedStyle(el); return cs.overflow === 'hidden' && el.scrollWidth > el.clientWidth + 1; })", f"{OUT}/f10_blurb_clip.webp", pad=16)
        await c.close()

        # کنترل: فیلتر بسته روی موبایل
        c = await b.new_context(viewport={"width": 360, "height": 800}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        p = await c.new_page()
        await p.goto(BASE + "/businesses", wait_until="domcontentloaded")
        await p.wait_for_timeout(500); await p.evaluate(WAIT)
        await crop_el(p, "document.querySelector('details.dir-filters > summary')", f"{OUT}/ctrl_filters_closed.webp", pad=12)
        await c.close()

        await b.close()

asyncio.run(main())
print("DONE")
