#!/usr/bin/env bash
# ============================================================================
#  نصب پایش لحظه‌ایِ سلامت «دستگیر» + هشدار تلگرام
#  ---------------------------------------------------------------------------
#  tools/uptime.py هر ۲ دقیقه اجرا می‌شود و در صورت قطع/بازگشت سایت،
#  به تلگرام خبر می‌دهد (توکن از دیتابیس یا متغیرهای محیطی خوانده می‌شود).
#
#  استفاده:
#      sudo bash tools/install-monitor.sh
#
#  تنظیمات اختیاری (فایل /etc/default/bazarche — در صورت وجود خوانده می‌شود):
#      BZ_HEALTH_URL=http://127.0.0.1:8080/healthz
#      BZ_HOME_URL=https://example.ir/
#      BZ_TG_TOKEN=...        (اختیاری — خودش از دیتابیس می‌خواند)
#      BZ_TG_CHAT_ID=...      (اختیاری)
# ============================================================================
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/bazarche}"
PY="${PY:-/usr/bin/python3}"

[[ "$(id -u)" -eq 0 ]] || { echo "✗ با sudo اجرا کنید." >&2; exit 1; }

CMD="$PY $APP_DIR/tools/uptime.py"
ENVFILE="/etc/default/bazarche"
ENVLINE=""
[[ -f "$ENVFILE" ]] && ENVLINE="EnvironmentFile=-$ENVFILE"

echo "→ تست فوری یک اجرا …"
if ! "$PY" "$APP_DIR/tools/uptime.py"; then
  echo "⚠ اجرای آزمایشی با خطا برگشت (شاید سایت در دسترس نیست — ادامه می‌دهیم)."
fi

if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
  echo "→ نصب systemd timer (هر ۲ دقیقه) …"
  cat > /etc/systemd/system/bazarche-uptime.service <<EOF
[Unit]
Description=Dastgir uptime probe + Telegram alert
After=network-online.target

[Service]
Type=oneshot
User=root
$ENVLINE
ExecStart=$CMD

[Install]
WantedBy=multi-user.target
EOF
  cat > /etc/systemd/system/bazarche-uptime.timer <<EOF
[Unit]
Description=Run Dastgir uptime probe every 2 minutes

[Timer]
OnBootSec=60
OnUnitActiveSec=120
RandomizedDelaySec=20
Persistent=true

[Install]
WantedBy=timers.target
EOF
  systemctl daemon-reload
  systemctl enable --now bazarche-uptime.timer
  echo "✓ timer فعال شد."
  echo ""
  echo "  اجرای دستی:   systemctl start bazarche-uptime.service"
  echo "  دیدن وضعیت:   systemctl list-timers bazarche-uptime.timer"
  echo "  دیدن لاگ:     journalctl -u bazarche-uptime.service -n 50"
else
  echo "→ systemd پیدا نشد؛ نصب cron (هر ۲ دقیقه) …"
  CRON_LINE="*/2 * * * * $CMD >> /var/lib/bazarche/uptime-cron.log 2>&1"
  mkdir -p /var/lib/bazarche
  ( crontab -l 2>/dev/null | grep -v "tools/uptime.py" ; echo "$CRON_LINE" ) | crontab -
  echo "✓ خط cron ثبت شد."
fi

echo ""
echo "✓ نصب کامل شد."
echo "  هشدارها به تلگرام (tg_token/tg_chat_id تنظیمات سایت) می‌روند."
echo "  برای پایش از بیرونِ سرور (تشخیص قطعی کل سرور/شبکه)، یک نمونهٔ دوم از این"
echo "  اسکریپت را روی یک سرور یا کامپیوتر دیگر با BZ_HEALTH_URL=https://دامنه/healthz"
echo "  اجرا کنید."
