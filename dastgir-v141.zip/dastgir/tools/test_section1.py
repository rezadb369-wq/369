#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regression tests for section 1: notifications heading + live search rows.

The owner reported two visual defects on a phone:
  1. «اعلان‌های من» sat too low and the action dropped below it.
  2. live-search results glued the business name to its category.

Run with the server already listening:
    BZ=http://127.0.0.1:8080 python3 tools/test_section1.py
"""

import os
import sys

from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "server"))
import db  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
PHONE = "09129997101"
BIZ_NAME = "آزمایشگاه جست‌وجوی بخش اول"
QUERY = "آزمایشگاه"
WIDTHS = (360, 390, 412)

passed = failed = 0
failures = []


def check(label, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print(f"  ✓ {label}")
    else:
        failed += 1
        failures.append(f"{label}: {detail}")
        print(f"  ✗ {label}  [{detail}]")


def clean_probe_data():
    con = db.connect()
    ids = [r["id"] for r in con.execute(
        "SELECT id FROM businesses WHERE name=?", (BIZ_NAME,))]
    con.close()
    for bid in ids:
        db.delete_business(bid)
    cust = db.customer_by_phone(PHONE)
    if cust:
        db.customer_delete(cust["id"])


def prepare_probe_data():
    clean_probe_data()
    category = db.categories(only_active=True)[0]
    db.save_business({
        "name": BIZ_NAME,
        "cat_slug": category["slug"],
        "phone": PHONE,
        "address": "نجف‌آباد، نشانی آزمون",
        "city": "نجف‌آباد",
        "province": "اصفهان",
        "lat": 32.634,
        "lng": 51.366,
        "status": "published",
    })
    customer = db.customer_by_phone(PHONE, create=True)
    db.customer_set_profile(customer["id"], "کاربر", "آزمون")
    db.notify(customer["id"], "info",
              "این اعلان برای سنجش جای عنوان صفحه ساخته شده است.",
              "/businesses")
    return db.customer_session_new(customer["id"])


def notification_metrics(page):
    return page.evaluate("""() => {
      const rect = (el) => {
        const r = el.getBoundingClientRect();
        return {top:r.top, bottom:r.bottom, height:r.height,
                center:(r.top + r.bottom) / 2};
      };
      return {
        breadcrumb: rect(document.querySelector('.breadcrumb')),
        hero: rect(document.querySelector('.page-hero')),
        heading: rect(document.querySelector('.page-hero h1')),
        action: rect(document.querySelector('.page-hero button')),
      };
    }""")


def suggestion_metrics(page, box_selector):
    return page.evaluate("""([boxSelector, wanted]) => {
      const buttons = Array.from(document.querySelectorAll(boxSelector + ' button'));
      const button = buttons.find(b => (b.textContent || '').includes(wanted));
      if (!button) return null;
      const name = button.querySelector('.sugg-name');
      const sub = button.querySelector('.sugg-sub');
      if (!name || !sub) return null;
      const nr = name.getBoundingClientRect();
      const sr = sub.getBoundingClientRect();
      const main = button.querySelector('.sugg-main');
      return {
        gapY: sr.top - nr.bottom,
        sameLine: Math.abs(sr.top - nr.top) < 3,
        display: getComputedStyle(main).display,
        text: button.innerText,
      };
    }""", [box_selector, BIZ_NAME])


def open_and_check_search(page, path, input_selector, box_selector, label,
                          settle=0):
    # Wait for the page's redirects/service-worker hand-off to settle before
    # evaluating geometry; domcontentloaded alone can race a redirect.
    page.goto(BASE + path, wait_until="networkidle", timeout=30000)
    if settle:
        page.wait_for_timeout(settle)
    page.fill(input_selector, QUERY)
    page.wait_for_selector(box_selector + ":not([hidden])", timeout=10000)
    page.wait_for_timeout(250)
    metrics = suggestion_metrics(page, box_selector)
    check(f"{label}: نتیجهٔ آزمون پیدا شد", metrics is not None,
          "ردیف کسب‌وکار در پیشنهادها نبود")
    if metrics:
        check(f"{label}: نام بالای دسته است",
              not metrics["sameLine"] and metrics["gapY"] >= 2,
              str(metrics))
        check(f"{label}: متن‌ها به هم نچسبیده‌اند",
              "\n" in metrics["text"], repr(metrics["text"]))


def main():
    print("\n══ آزمون بخش اول: اعلان‌ها و نتیجه‌های جست‌وجو ══")
    token = prepare_probe_data()
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch()

            # Three real phone widths required by the project rules.
            for width in WIDTHS:
                context = browser.new_context(
                    viewport={"width": width, "height": 844},
                    locale="fa-IR", is_mobile=True, has_touch=True)
                context.add_cookies([{
                    "name": "bzv2_cust", "value": token, "url": BASE
                }])
                page = context.new_page()

                page.goto(BASE + "/me/notifications",
                          wait_until="networkidle", timeout=30000)
                page.wait_for_selector(".page-hero h1", timeout=10000)
                page.wait_for_timeout(250)
                m = notification_metrics(page)
                top_gap = m["heading"]["top"] - m["breadcrumb"]["bottom"]
                center_gap = abs(m["heading"]["center"] - m["action"]["center"])
                check(f"{width}px: عنوان اعلان کمی بالاتر آمده",
                      top_gap <= 12, f"فاصله از بردکرامب {top_gap:.1f}px")
                check(f"{width}px: عنوان و خواندن همه هم‌ردیف‌اند",
                      center_gap <= 6, f"اختلاف مرکز {center_gap:.1f}px")
                check(f"{width}px: سربرگ اعلان بی‌دلیل بلند نیست",
                      m["hero"]["height"] <= 80,
                      f"ارتفاع {m['hero']['height']:.1f}px")

                open_and_check_search(
                    page, "/", "#hero-q", "#hero-sugg",
                    f"جست‌وجوی خانه در {width}px")
                context.close()

            # Every live-result surface: the global search, directory, catalog,
            # and the map's own local suggestion renderer.
            context = browser.new_context(
                viewport={"width": 390, "height": 844},
                locale="fa-IR", is_mobile=True, has_touch=True)
            context.add_cookies([{
                "name": "bzv2_cust", "value": token, "url": BASE
            }])
            page = context.new_page()
            open_and_check_search(page, "/businesses", "#dq", ".live-sugg",
                                  "جست‌وجوی کسب‌وکارها")
            open_and_check_search(page, "/catalog", "#cq", ".live-sugg",
                                  "جست‌وجوی محصولات")
            open_and_check_search(page, "/map", "#mq", "[data-map-sugg]",
                                  "جست‌وجوی نقشه", settle=1800)
            context.close()
            browser.close()
    finally:
        clean_probe_data()

    print("\n" + "═" * 55)
    print(f"  {passed} موفق، {failed} ناموفق")
    for item in failures:
        print("   ✗", item)
    print("═" * 55)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
