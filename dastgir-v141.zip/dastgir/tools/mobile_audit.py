# -*- coding: utf-8 -*-
"""
قفل مرحلهٔ م۴ — ممیزی موبایل پنل با مرورگر واقعی (بازسازی فاز ۵، ۲۰۲۶-۰۸-۳۱)

  ۲۲ صفحهٔ پنل × ۴ دستگاه (360/390/412/768):
    • سرریز افقی: document.scrollWidth ≤ عرض viewport + 1px
    • خطای جاوااسکریپت کنسول: صفر
    • هدف لمسی: عناصر تعاملی اصلی (btn/chip/btn-icon/nav a) ≥ ۴۴px ارتفاع
    • رندر RTL در عرض دستگاه (html[dir=rtl] و متای viewport)

    BZ=http://127.0.0.1:8080 python3 tools/mobile_audit.py
"""

import os
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")

DEVICES = [(360, 740, "Android-S 360"), (390, 844, "iPhone 390"),
           (412, 915, "Pixel 412"), (768, 1024, "Tablet 768")]

PAGES = ["/panel", "/panel/businesses", "/panel/reviews", "/panel/bookings",
         "/panel/customers", "/panel/orders", "/panel/chats", "/panel/tickets",
         "/panel/messages", "/panel/inquiries", "/panel/claims", "/panel/reports",
         "/panel/edits", "/panel/alerts", "/panel/subscriptions", "/panel/owners",
         "/panel/search?q=", "/panel/settings", "/panel/appearance", "/panel/plans",
         "/panel/trash", "/panel/insights",
         "/panel/moderation", "/panel/audit"]      # v117/M5

TAP_JS = """
(() => {
  const sel = '.btn, .chip, .btn-icon, .panel-nav a, .pager a, .tk-row, .thread-row';
  const bad = [];
  document.querySelectorAll(sel).forEach(el => {
    const r = el.getBoundingClientRect();
    if (r.height > 0 && r.height < 43.5)
      bad.push(el.className.toString().slice(0, 40) + ' h=' + Math.round(r.height));
  });
  return bad.slice(0, 5);
})()
"""


def main():
    from playwright.sync_api import sync_playwright
    import db
    tok = db.owner_token()

    issues = []
    n_runs = 0
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        for w, h, name in DEVICES:
            ctx = browser.new_context(viewport={"width": w, "height": h},
                                      is_mobile=True, device_scale_factor=2,
                                      locale="fa-IR")
            page = ctx.new_page()
            errors = []
            page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
            page.on("pageerror", lambda e: errors.append(str(e)))
            # key entry once per context (mints the session cookie)
            page.goto(BASE + f"/panel?key={urllib.parse.quote(tok)}",
                      wait_until="networkidle", timeout=30000)
            for path in PAGES:
                errors.clear()
                page.goto(BASE + path, wait_until="networkidle", timeout=30000)
                n_runs += 1
                overflow = page.evaluate(
                    "document.documentElement.scrollWidth - document.documentElement.clientWidth")
                if overflow > 1:
                    issues.append(f"{name} {path}: سرریز افقی {overflow}px")
                if errors:
                    issues.append(f"{name} {path}: خطای JS: {errors[0][:80]}")
                bad_taps = page.evaluate(TAP_JS)
                if bad_taps:
                    issues.append(f"{name} {path}: هدف لمسی <44px: {bad_taps[0]}")
                rtl = page.evaluate("document.documentElement.getAttribute('dir')")
                if rtl != "rtl":
                    issues.append(f"{name} {path}: dir≠rtl")
            ctx.close()
        browser.close()

    print(f"\n\033[1m{len(DEVICES)}×{len(PAGES)} = {n_runs} اجرا بررسی شد\033[0m")
    if issues:
        for i in issues:
            print(f"  \033[31m✗\033[0m {i}")
        sys.exit(1)
    print("  \033[32m✓ صفر ایراد: بدون سرریز افقی، بدون خطای JS، اهداف لمسی ≥۴۴px، RTL.\033[0m")


if __name__ == "__main__":
    main()
