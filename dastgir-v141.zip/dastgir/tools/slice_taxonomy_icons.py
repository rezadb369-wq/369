#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Slice the generated 3x3 icon sheets for the full category taxonomy.

Same treatment as slice_icons.py (white backdrop -> alpha, crop to content,
re-pad to a square, export @1x/@2x) but driven by the sheet->names map below
so the 130+ taxonomy icons all come out matching the original 22.
"""
import os
import sys
from PIL import Image
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '..', 'raw')
OUT = os.path.join(HERE, '..', 'site', 'assets', 'img', 'icons')
os.makedirs(OUT, exist_ok=True)

SHEETS = {
    'sheet-01.png': ['kebab', 'fastfood', 'broth',
                     'hall', 'seafood', 'juice',
                     'teahouse', 'chocolate', 'nuts'],
    'sheet-02.png': ['greengrocer', 'butcher', 'dairy',
                     'spice', 'organic', 'womenswear',
                     'menswear', 'kidswear', 'shoes'],
    'sheet-03.png': ['tailor', 'fabric', 'sportswear',
                     'silver', 'watch', 'dentist',
                     'pharmacy', 'lab', 'physio'],
    'sheet-04.png': ['optician', 'psychology', 'medequip',
                     'nutrition', 'salon', 'nails',
                     'skincare', 'cosmetics', 'furniture'],
    'sheet-05.png': ['carpet', 'curtain', 'appliance',
                     'kitchenware', 'bedding', 'decor',
                     'tools', 'materials', 'electrician'],
    'sheet-06.png': ['plumber', 'painter', 'tiles',
                     'aluminium', 'cooling', 'welding',
                     'carpentry', 'builder', 'architect'],
    'sheet-07.png': ['survey', 'bodyshop', 'autoparts',
                     'carwash', 'tyre', 'cardealer',
                     'motorcycle', 'battery', 'cng'],
    'sheet-08.png': ['mobilerepair', 'computer', 'electronics',
                     'cctv', 'internet', 'language',
                     'tutoring', 'music', 'skillschool'],
    'sheet-09.png': ['kindergarten', 'bookstore', 'printshop',
                     'briefcase', 'lawyer', 'accountant',
                     'insurance', 'notary', 'advertising'],
    'sheet-10.png': ['itservice', 'govservice', 'exchange',
                     'bank', 'laundry', 'cleaning',
                     'moving', 'applianceRepair', 'pestcontrol'],
    'sheet-11.png': ['keysmith', 'waterfilter', 'pool',
                     'martialarts', 'sportshop', 'gameclub',
                     'kidsplay', 'petshop', 'vet'],
    'sheet-12.png': ['nursery', 'agriculture', 'camera',
                     'weddinghall', 'rental', 'giftshop',
                     'funeral', 'taxi', 'freight'],
    'sheet-13.png': ['travel', 'courier', 'carrental',
                     'factory', 'packaging', 'wholesale',
                     'recycling', 'textileFactory', None],
    # second batch — the trades the first pass missed
    'sheet-14.png': ['hotel', 'guesthouse', 'attraction',
                     'drivingschool', 'translation', 'marriageoffice',
                     'officeequip', 'secondhand', 'elevator'],
    'sheet-15.png': ['glass', 'landscaping', 'carpetwash',
                     'homecare', 'toyshop', 'towing',
                     None, None, None],
}

WHITE_CUT = 238
WHITE_FULL = 252
MARGIN = 0.07


def remove_white(img):
    img = img.convert('RGBA')
    a = np.array(img).astype(np.float32)
    mn = a[..., :3].min(axis=2)
    alpha = np.ones_like(mn)
    alpha[mn >= WHITE_FULL] = 0.0
    ramp = (mn > WHITE_CUT) & (mn < WHITE_FULL)
    alpha[ramp] = 1.0 - (mn[ramp] - WHITE_CUT) / float(WHITE_FULL - WHITE_CUT)
    a[..., 3] = a[..., 3] * alpha
    return Image.fromarray(a.astype(np.uint8), 'RGBA')


def bbox_of(alpha, thresh=24):
    ys, xs = np.where(alpha > thresh)
    if len(xs) == 0:
        return None
    return xs.min(), ys.min(), xs.max() + 1, ys.max() + 1


def keep_largest_blob(img, thresh=24, min_frac=0.02):
    """Drop stray specks that bleed in from a neighbouring grid cell.

    A cell sometimes catches the corner of the icon next to it; that speck
    then dominates the bounding box and the real icon ends up tiny and
    off-centre. Flood-fill the alpha mask, keep components that are a
    meaningful fraction of the biggest one, and erase the rest.
    """
    arr = np.array(img)
    mask = arr[..., 3] > thresh
    if not mask.any():
        return img

    h, w = mask.shape
    labels = np.zeros((h, w), dtype=np.int32)
    sizes = [0]
    cur = 0
    idx = np.argwhere(mask)
    seen = np.zeros((h, w), dtype=bool)
    for sy, sx in idx:
        if seen[sy, sx]:
            continue
        cur += 1
        stack = [(sy, sx)]
        seen[sy, sx] = True
        n = 0
        while stack:
            y, x = stack.pop()
            labels[y, x] = cur
            n += 1
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and mask[ny, nx] and not seen[ny, nx]:
                    seen[ny, nx] = True
                    stack.append((ny, nx))
        sizes.append(n)

    if cur <= 1:
        return img
    biggest = max(sizes)
    keep = {i for i, n in enumerate(sizes) if i and n >= biggest * min_frac}
    drop = ~np.isin(labels, list(keep))
    arr[..., 3][drop] = 0
    return Image.fromarray(arr, 'RGBA')


def squarify(img, size):
    arr = np.array(img)
    bb = bbox_of(arr[..., 3])
    if bb:
        img = img.crop(bb)
    inner = int(size * (1 - 2 * MARGIN))
    w, h = img.size
    scale = inner / max(w, h)
    nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    img = img.resize((nw, nh), Image.LANCZOS)
    canvas = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    canvas.paste(img, ((size - nw) // 2, (size - nh) // 2), img)
    return canvas


def main():
    only = sys.argv[1:] or None
    made, missing_sheets, empty = [], [], []
    for sheet, names in SHEETS.items():
        if only and sheet not in only:
            continue
        path = os.path.join(RAW, sheet)
        if not os.path.exists(path):
            missing_sheets.append(sheet)
            continue
        src = remove_white(Image.open(path))
        W, H = src.size
        cw, ch = W // 3, H // 3
        for i, name in enumerate(names):
            if not name:
                continue
            r, c = divmod(i, 3)
            cell = src.crop((c * cw, r * ch, (c + 1) * cw, (r + 1) * ch))
            cell = keep_largest_blob(cell)
            if bbox_of(np.array(cell)[..., 3]) is None:
                empty.append(name)
                continue
            for size, suffix in ((256, '@2x'), (128, '')):
                squarify(cell, size).save(
                    os.path.join(OUT, f'{name}{suffix}.png'), 'PNG', optimize=True)
            made.append(name)

    print(f'  ساخته شد: {len(made)} آیکون')
    if empty:
        print(f'  خالی بود : {", ".join(empty)}')
    if missing_sheets:
        print(f'  شیت نبود : {", ".join(missing_sheets)}')

    # completeness report against the taxonomy
    sys.path.insert(0, HERE)
    try:
        import taxonomy
        have = {f[:-7] for f in os.listdir(OUT) if f.endswith('@2x.png')}
        gaps = [n for n in taxonomy.all_icons() if n not in have]
        print(f'\n  آیکون‌های لازم تاکسونومی : {len(taxonomy.all_icons())}')
        print(f'  موجود روی دیسک          : {len(have)}')
        if gaps:
            print(f'  \033[31mکم است ({len(gaps)})\033[0m: {", ".join(gaps)}')
        else:
            print('  \033[32m✓ هیچ آیکونی کم نیست\033[0m')
    except Exception as e:
        print('  (taxonomy check skipped:', e, ')')


if __name__ == '__main__':
    main()
