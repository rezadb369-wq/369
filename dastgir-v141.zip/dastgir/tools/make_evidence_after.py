import asyncio, io, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from playwright.async_api import async_playwright
from PIL import Image

OUT = "/home/user/audit-design/evidence"
os.makedirs(OUT, exist_ok=True)

FIX_JS = """
const __auditInject = () => {
  const st = document.createElement('style');
  st.textContent = 'details:not([open]) > :not(summary){display:none !important}';
  document.documentElement.appendChild(st);
};
if (document.documentElement) __auditInject();
else document.addEventListener('DOMContentLoaded', __auditInject, { once: true });
"""
WAIT = "Promise.race([document.fonts.ready.then(()=>true), new Promise(r=>setTimeout(()=>r(false),2500))])"

SCROLL_JS = "() => { const el = window.__EV; if (el) el.scrollIntoView({block:'center'}); }"
RECT_JS = """() => {
  const el = window.__EV; if (!el) return null;
  const b = el.getBoundingClientRect();
  return {x: Math.round(b.x), y: Math.round(b.y), w: Math.round(b.width), h: Math.round(b.height)};
}"""

async def crop_el(p, el_js, path, pad=10):
    await p.evaluate("window.__EV = " + el_js)
    await p.evaluate(SCROLL_JS)
    await p.wait_for_timeout(400)
    r = await p.evaluate(RECT_JS)
    if not r:
        print("not found:", path)
        return
    x, y = max(0, r["x"] - pad), max(0, r["y"] - pad)
    raw = await p.screenshot(type="png")
    im = Image.open(io.BytesIO(raw)).convert("RGB")
    cw, ch = im.size
    x2, y2 = min(x + r["w"] + pad * 2, cw), min(y + r["h"] + pad * 2, ch)
    if x2 <= x or y2 <= y:
        print("empty:", path)
        return
    crop = im.crop((x, y, x2, y2))
    if max(crop.size) > 700:
        crop.thumbnail((700, 700), Image.LANCZOS)
    crop.save(path, "WEBP", quality=82, method=4)
    print("ok", path, crop.size)


async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"])

        # AFTER: biz-card title now full width (fix 1)
        c = await b.new_context(viewport={"width": 320, "height": 568}, locale="fa-IR")
        await c.add_init_script(FIX_JS)
        p = await c.new_page()
        await p.goto("http://127.0.0.1:8080/businesses", wait_until="domcontentloaded")
        await p.wait_for_timeout(600)
        await p.evaluate(WAIT)
        await crop_el(p, "document.querySelector('.biz-card')", f"{OUT}/after_f1_title_ok.webp", pad=8)
        await c.close()

        # AFTER: map — new small transparent controls + single info panel
        c = await b.new_context(viewport={"width": 390, "height": 844}, locale="fa-IR")
        p = await c.new_page()
        await p.goto("http://127.0.0.1:8080/map", wait_until="domcontentloaded")
        await p.wait_for_timeout(2400)
        await p.evaluate("() => { const m = document.querySelector('.leaflet-marker-icon'); if (m) m.click(); }")
        await p.wait_for_timeout(900)
        raw = await p.screenshot(type="png")
        im = Image.open(io.BytesIO(raw)).convert("RGB")
        st = await p.evaluate("""() => {
          const b = document.querySelector('.map-stage').getBoundingClientRect();
          return {x: Math.round(b.x), y: Math.round(b.y), w: Math.round(b.width), h: Math.round(b.height)};
        }""")
        im.crop((st["x"], st["y"], st["x"] + st["w"], st["y"] + st["h"])).save(
            f"{OUT}/after_map_new.webp", "WEBP", quality=82, method=4)
        print("ok", "after_map_new.webp")
        await c.close()

        await b.close()


asyncio.run(main())
print("DONE")
