# -*- coding: utf-8 -*-
"""
قفل مرحلهٔ م۳ (کارایی پنل) — بازسازی فاز ۵ (۲۰۲۶-۰۸-۳۱)

  سرور آزمایشی جدا (BZ_DATA_DIR=/tmp/panelbench، پورت آزاد بعد از 8080)
  با دادهٔ سنگین:
     ۶۰۰۰ نظر · ۴۰۰۰ نوبت · ۶۰۰۰ مشتری · ۳۰۰۰ پیام · ۲۰۰۰ تیکت
     ۲۵۰۰ گفتگو (×۲ پیام) · ۱۵۰۰ اشتراک · ۱۲۰۰ ویرایش · ۸۰۰ گزارش
     ۶۰۰ ادعا · ۷۰۰ هشدار · ۹۰۰ استعلام · ۴۰۰ دکان‌دار · ۵۰۰۰ سفارش

  سنجه per صفحهٔ پنل: میانهٔ ۳ اجرا (ms) + اندازهٔ پاسخ خام (KB، بدون gzip)
  آستانهٔ قبولی (SPEC م۳): هر صفحه < 500ms و < 400KB.

    python3 tools/bench_panel.py            # کل جریان: seed → bench → cleanup
"""

import http.client
import os
import statistics
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
BENCH_DIR = "/tmp/panelbench"
os.environ["BZ_DATA_DIR"] = BENCH_DIR
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db          # noqa: E402  (same BENCH DB as the spawned server)

G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
BUDGET_MS, BUDGET_KB = 500, 400

PAGES = [
    "/panel", "/panel/businesses", "/panel/reviews", "/panel/bookings",
    "/panel/customers", "/panel/orders", "/panel/chats", "/panel/tickets",
    "/panel/messages", "/panel/inquiries", "/panel/claims", "/panel/reports",
    "/panel/edits", "/panel/alerts", "/panel/subscriptions", "/panel/owners",
    "/panel/audit", "/panel/follows",
]


def seed():
    import shutil
    if os.path.exists(BENCH_DIR):
        shutil.rmtree(BENCH_DIR)
    os.makedirs(BENCH_DIR, exist_ok=True)
    db.init()
    con = db.connect()
    con.execute("PRAGMA journal_mode=OFF")
    con.execute("PRAGMA synchronous=OFF")
    # 40 shops / 40 owners
    con.executemany(
        "INSERT INTO owners(phone,name,pass_hash) VALUES(?,?,?)",
        [(f"0990000{i:05d}", f"دکان‌دار {i}", "") for i in range(40)])
    con.executemany(
        "INSERT INTO businesses(name,slug,cat_slug,city,phone,status,owner_id)"
        " VALUES(?,?,?,?,?,?,?)",
        [(f"دکان {i}", f"shop-{i}", "rest", "najafabad",
          f"0911000{i:05d}", "published", (i % 40) + 1) for i in range(40)])
    con.executemany(
        "INSERT INTO customers(phone,name) VALUES(?,?)",
        [(f"0935000{i:05d}", f"مشتری {i}") for i in range(6000)])
    con.executemany(
        "INSERT INTO reviews(biz_id,author,rating,body,status)"
        " VALUES(?,?,?,?,?)",
        [((i % 40) + 1, f"نویسنده {i}", (i % 5) + 1,
          "نظر آزمایشی bench " * 4, "approved") for i in range(6000)])
    con.executemany(
        "INSERT INTO bookings(biz_id,name,phone,date,time,status)"
        " VALUES(?,?,?,?,?,?)",
        [((i % 40) + 1, f"نوبت‌گیر {i}", f"0922000{i:05d}",
          "2026-09-01", "10:00", "new") for i in range(4000)])
    con.executemany(
        "INSERT INTO messages(name,email,subject,body,kind,status)"
        " VALUES(?,?,?,?,?,?)",
        [(f"فرستنده {i}", f"u{i}@x.ir", "موضوع", "متن پیام بنچ", "form",
          "new") for i in range(3000)])
    con.executemany(
        "INSERT INTO tickets(subject,name,phone,topic,status)"
        " VALUES(?,?,?,?,?)",
        [(f"تیکت {i}", f"کاربر {i}", f"0923000{i:05d}", "tech", "open")
         for i in range(2000)])
    thr = con.executemany(
        "INSERT INTO chat_threads(biz_id,customer_id,subject,last_activity)"
        " VALUES(?,?,?,?)",
        [((i % 40) + 1, (i % 6000) + 1, f"گفتگو {i}",
          "2026-08-31 10:00:00") for i in range(2500)])
    con.execute(
        "INSERT INTO chat_messages(thread_id,sender,body)"
        " SELECT id,'customer','پیام اول' FROM chat_threads")
    con.execute(
        "INSERT INTO chat_messages(thread_id,sender,body)"
        " SELECT id,'owner','پیام دوم' FROM chat_threads")
    con.executemany(
        "INSERT INTO subscriptions(biz_id,plan_slug,status,amount,expires)"
        " VALUES(?,?,?,?,?)",
        [((i % 40) + 1, "pro", "active", 1200000, "2026-12-31")
         for i in range(1500)])
    con.executemany(
        "INSERT INTO edits(biz_id,owner_id,payload,status)"
        " VALUES(?,?,?,?)",
        [((i % 40) + 1, (i % 40) + 1, '{"name":"نام جدید"}', "pending")
         for i in range(1200)])
    con.executemany(
        "INSERT INTO reports(target_id,reason,kind,status)"
        " VALUES(?,?,?,?)",
        [((i % 40) + 1, "محتوای نامناسب", "review", "open")
         for i in range(800)])
    con.executemany(
        "INSERT INTO claims(biz_id,owner_id,status) VALUES(?,?,?)",
        [((i % 40) + 1, (i % 40) + 1, "pending") for i in range(600)])
    con.executemany(
        "INSERT INTO alerts(phone,term,active) VALUES(?,?,1)",
        [(f"0924000{i:05d}", "قهوه") for i in range(700)])
    con.executemany(
        "INSERT INTO inquiries(biz_id,name,phone,body,status)"
        " VALUES(?,?,?,?,?)",
        [((i % 40) + 1, f"پرسنده {i}", f"0925000{i:05d}", "متن", "new")
         for i in range(900)])
    con.executemany(
        "INSERT INTO orders(biz_id,customer_id,name,phone,total,status)"
        " VALUES(?,?,?,?,?,?)",
        [((i % 40) + 1, (i % 6000) + 1, f"سفارش‌دهنده {i}",
          f"0926000{i:05d}", 50000, "new") for i in range(5000)])
    con.commit()
    con.close()
    print("  seed: " + ", ".join(f"{n} {t}" for n, t in [
        (6000, "نظر"), (4000, "نوبت"), (6000, "مشتری"), (3000, "پیام"),
        (2000, "تیکت"), (2500, "گفتگو"), (1500, "اشتراک"), (1200, "ویرایش"),
        (800, "گزارش"), (600, "ادعا"), (700, "هشدار"), (900, "استعلام"),
        (5000, "سفارش")]))


def spawn_server():
    env = dict(os.environ, BZ_DATA_DIR=BENCH_DIR)
    p = subprocess.Popen([sys.executable, os.path.join(HERE, "..", "run.py")],
                         env=env, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL)
    for port in range(8081, 8096):
        for _ in range(30):
            try:
                c = http.client.HTTPConnection("127.0.0.1", port, timeout=1)
                c.request("GET", "/", headers={"Accept-Encoding": "identity"})
                r = c.getresponse(); r.read(); c.close()
                if r.status == 200:
                    return p, port
            except Exception:
                time.sleep(0.3)
    raise RuntimeError("bench server did not come up")


def main():
    print(f"{B}── bench_panel: seed{X}")
    seed()
    print(f"{B}── سرور آزمایشی…{X}")
    proc, port = spawn_server()
    print(f"  http://127.0.0.1:{port}")
    try:
        tok = db.owner_token()
        c = http.client.HTTPConnection("127.0.0.1", port, timeout=30)
        c.request("GET", f"/panel?key={tok}",
                  headers={"Accept-Encoding": "identity"})
        r = c.getresponse(); r.read()
        cookie = r.getheader("Set-Cookie") or ""
        sess = cookie.split(";")[0]
        rows = []
        bad = []
        print(f"\n{B}── سنجه (میانهٔ ۳ اجرا، بدون gzip){X}")
        print(f"{'صفحه':28s} {'ms':>8s} {'KB':>9s}")
        for path in PAGES:
            times, size = [], 0
            for _ in range(3):
                t0 = time.perf_counter()
                c.request("GET", path, headers={
                    "Accept-Encoding": "identity", "Cookie": sess})
                r = c.getresponse()
                body = r.read()
                times.append((time.perf_counter() - t0) * 1000)
                size = len(body)
                if r.status != 200:
                    size = -1
                    break
            ms = statistics.median(times)
            kb = size / 1024
            ok = (size >= 0) and ms < BUDGET_MS and kb < BUDGET_KB
            rows.append((path, ms, kb, ok))
            if not ok:
                bad.append((path, ms, kb))
            print(f"{path:28s} {ms:8.1f} {kb:9.1f}  "
                  f"{G}✓{X}" if ok else f"{path:28s} {ms:8.1f} {kb:9.1f}  {R}✗{X}")
        print(f"\n{B}نتیجه: {len(rows)-len(bad)}/{len(rows)} صفحه در بودجهٔ "
              f"<{BUDGET_MS}ms و <{BUDGET_KB}KB{X}")
        if bad:
            for p, ms, kb in bad:
                print(f"  {R}✗ {p}: {ms:.0f}ms {kb:.0f}KB{X}")
            sys.exit(1)
        print(f"  {G}همهٔ صفحات پنل در بودجهٔ کارایی م۳ هستند.{X}")
    finally:
        proc.terminate()
        proc.wait(timeout=10)


if __name__ == "__main__":
    main()
