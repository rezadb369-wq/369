# -*- coding: utf-8 -*-
"""
مقایسهٔ قیمت محلی — the "same goods, different shops, different prices" page.

What must be true for this feature to be worth trusting:

  · grouping survives the ways Persian is actually typed (ZWNJ, word order,
    filler words like «یک عدد») but does NOT collide unrelated products
  · only genuinely comparable listings take part — a service quoted
    "on request" has no price to compare
  · one shop cannot inflate a group by listing the same item twice
  · the cheapest offer is really the cheapest, and the percentages add up
  · a shop's own page tells the truth about where it ranks, including when
    it is NOT the cheapest

    BZ=http://127.0.0.1:8080 python3 tools/test_prices.py
"""

import os
import sys
import urllib.parse
import urllib.request
import urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa: E402
import views_public2 as V2  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
TAG = "آزمون-قیمت"

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


def get(path):
    try:
        r = urllib.request.urlopen(BASE + path, timeout=25)
        return r.getcode(), r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


print(f"\n\033[1m\033[36mآزمون مقایسهٔ قیمت محلی — {BASE}\033[0m")
# Prices are intentionally OFF on the public site by default in v75. This
# dedicated suite enables its own feature prerequisite, then restores it.
_saved_prices = db.get_settings().get("prices_enabled", "0")
db.set_setting("prices_enabled", "1")

# --------------------------------------------------------------- grouping
head("۱) گروه‌بندی با املای واقعی فارسی کنار می‌آید")
SAME = [
    ("پنیر لیقوان", "پنیر\u200cلیقوان", "نیم‌فاصله"),
    ("نان سنگک", "یک عدد نان سنگک", "کلمهٔ پرکننده «یک عدد»"),
    ("چلوکباب کوبیده", "کوبیده چلوکباب", "ترتیب کلمات"),
    ("شیر کاله", "شير كاله", "ی و ک عربی"),
    ("روغن  لادن", "روغن لادن", "فاصلهٔ اضافه"),
    ("برنج هاشمی ویژه", "برنج هاشمی", "صفت تبلیغاتی «ویژه»"),
]
for a, b, why in SAME:
    check(f"«{a}» و «{b}» یک گروه‌اند ({why})",
          db.price_key(a) == db.price_key(b),
          f"{db.price_key(a)!r} != {db.price_key(b)!r}")

head("۲) کالاهای بی‌ربط با هم قاطی نمی‌شوند")
DIFF = [("پنیر لیقوان", "پنیر پیتزا"),
        ("نان سنگک", "نان بربری"),
        ("شیر کاله", "شیر عالیس"),
        ("روغن زیتون", "روغن موتور")]
for a, b in DIFF:
    check(f"«{a}» با «{b}» یکی شمرده نمی‌شود",
          db.price_key(a) != db.price_key(b), db.price_key(a))

check("عنوان بی‌معنا کلید خالی می‌دهد", db.price_key("یک عدد ویژه") == "",
      db.price_key("یک عدد ویژه"))
check("عنوان خالی خطا نمی‌دهد", db.price_key("") == "" and db.price_key(None) == "", "")

# --------------------------------------------------------------- fixture
head("۳) آماده‌سازی سه دکان با یک کالا")
for b in db.businesses(status=None):
    if TAG in (b.get("tags") or ""):
        db.delete_business(b["id"])

cat = db.categories()[0]["slug"]
SHOPS = [("دکانٔ ارزان آزمون", 100000),
         ("دکانٔ متوسط آزمون", 120000),
         ("دکانٔ گران آزمون", 150000)]
ids = []
for name, price in SHOPS:
    bid = db.save_business({"name": name, "cat_slug": cat, "status": "published",
                            "phone": "09130000000", "tags": TAG})
    ids.append(bid)
    db.save_item({"biz_id": bid, "kind": "product", "title": "کالای آزمون قیمت",
                  "price": price, "price_type": "fixed", "available": 1})
check("سه دکان با یک کالا ساخته شد", len(ids) == 3, str(ids))


def group():
    return next((g for g in db.comparable_items()
                 if db.price_key("کالای آزمون قیمت") == g["key"]), None)


g = group()
check("گروه مقایسه ساخته شد", g is not None, "")
if g:
    check("هر سه دکان در گروه هستند", g["n"] == 3, str(g["n"]))
    check("ارزان‌ترین درست است", g["min"] == 100000, str(g["min"]))
    check("گران‌ترین درست است", g["max"] == 150000, str(g["max"]))
    check("اختلاف درست حساب شده", g["spread"] == 50000, str(g["spread"]))
    check("درصد اختلاف درست است", g["spread_pct"] == 50, str(g["spread_pct"]))
    check("پیشنهادها از ارزان به گران مرتب‌اند",
          [o["price"] for o in g["offers"]] == [100000, 120000, 150000],
          str([o["price"] for o in g["offers"]]))
    check("فقط ارزان‌ترین نشان «ارزان‌ترین» دارد",
          sum(1 for o in g["offers"] if o["is_cheapest"]) == 1, "")
    mid = g["offers"][1]
    check("درصد گرانی نسبت به ارزان‌ترین درست است",
          mid["over_pct"] == 20 and mid["over_min"] == 20000,
          f"{mid['over_pct']}٪ / {mid['over_min']}")

head("۴) چیزهایی که نباید وارد مقایسه شوند")
solo = db.save_business({"name": "دکانٔ تک آزمون", "cat_slug": cat,
                         "status": "published", "phone": "09130000000", "tags": TAG})
db.save_item({"biz_id": solo, "kind": "product", "title": "کالای تک‌فروش آزمون",
              "price": 50000, "price_type": "fixed", "available": 1})
check("کالایی که فقط یک دکان دارد، مقایسه نمی‌شود",
      not any(g2["key"] == db.price_key("کالای تک‌فروش آزمون")
              for g2 in db.comparable_items()), "")

# a service with no fixed price cannot be compared
for bid in ids[:2]:
    db.save_item({"biz_id": bid, "kind": "service", "title": "خدمت آزمون قیمت",
                  "price": 0, "price_type": "call", "available": 1})
check("خدمت «استعلامی» وارد مقایسه نمی‌شود",
      not any(g2["key"] == db.price_key("خدمت آزمون قیمت")
              for g2 in db.comparable_items()), "")

# an unavailable item should drop out
db.save_item({"biz_id": ids[0], "kind": "product", "title": "کالای ناموجود آزمون",
              "price": 1000, "price_type": "fixed", "available": 0})
db.save_item({"biz_id": ids[1], "kind": "product", "title": "کالای ناموجود آزمون",
              "price": 2000, "price_type": "fixed", "available": 0})
check("کالای ناموجود وارد مقایسه نمی‌شود",
      not any(g2["key"] == db.price_key("کالای ناموجود آزمون")
              for g2 in db.comparable_items()), "")

head("۵) یک دکان نمی‌تواند گروه را باد کند")
db.save_item({"biz_id": ids[0], "kind": "product", "title": "کالای آزمون قیمت",
              "price": 95000, "price_type": "fixed", "available": 1})
g = group()
check("ثبت دوبارهٔ یک کالا، دکان را دوبار نمی‌شمارد",
      g is not None and g["n"] == 3, str(g and g["n"]))
check("و ارزان‌ترین قیمتِ همان دکان ملاک است",
      g is not None and g["min"] == 95000, str(g and g["min"]))

head("۶) دکانٔ پنهان یا تأییدنشده در مقایسه نیست")
db._run("UPDATE businesses SET status='hidden' WHERE id=?", (ids[2],))
g = group()
check("دکانٔ مخفی از گروه حذف شد", g is not None and g["n"] == 2, str(g and g["n"]))
db._run("UPDATE businesses SET status='published' WHERE id=?", (ids[2],))

# ------------------------------------------------------------ integration
head("۷) صفحهٔ /prices")
code, html = get("/prices")
check("صفحه باز می‌شود", code == 200, f"code={code}")
check("کالای آزمون روی صفحه هست", "کالای آزمون قیمت" in html, "")
check("نام دکانٔ ارزان روی صفحه هست", "دکانٔ ارزان آزمون" in html, "")
check("هیچ NaN روی صفحه نیست", "NaN" not in html, "")

g = group()
if g:
    code, dhtml = get("/prices?key=" + urllib.parse.quote(g["key"], safe=""))
    check("مقایسهٔ کامل باز می‌شود", code == 200, f"code={code}")
    check("جدول مقایسه رندر شده", "price-table" in dhtml, "")
    check("هر سه دکان در جدول هستند",
          all(n in dhtml for n, _ in SHOPS), "")
    # count inside the detail table only — the same word legitimately
    # appears again in the summary card further down the page
    import re as _re
    tbl = _re.search(r'<table class="table price-table">.*?</table>', dhtml, _re.S)
    tbl = tbl.group(0) if tbl else ""
    check("در جدول مقایسه فقط یک دکان «ارزان‌ترین» است",
          tbl.count("ارزان‌ترین") == 1, str(tbl.count("ارزان‌ترین")))
    check("و ردیف ارزان‌ترین برجسته شده",
          tbl.count('class="is-best"') == 1, str(tbl.count('class="is-best"')))

code, shtml = get("/prices?q=" + urllib.parse.quote("کالای آزمون"))
check("جست‌وجوی کالا کار می‌کند",
      code == 200 and "کالای آزمون قیمت" in shtml, f"code={code}")
code, nhtml = get("/prices?q=" + urllib.parse.quote("چیزی-که-وجود-ندارد"))
check("جست‌وجوی بی‌نتیجه، صفحهٔ خالی مرتب می‌دهد",
      code == 200 and "پیدا نشد" in nhtml, f"code={code}")

head("۸) کلید نامعتبر صفحه را نمی‌شکند")
for bad in ("../../etc/passwd", "<script>alert(1)</script>", "x" * 300, ""):
    code, h = get("/prices?key=" + urllib.parse.quote(bad, safe=""))
    check(f"کلید نامعتبر مدیریت شد ({bad[:18]!r})", code == 200, f"code={code}")
    if bad.startswith("<script"):
        check("و اسکریپت تزریق‌شده اجرا نمی‌شود",
              "<script>alert(1)</script>" not in h, "XSS!")

head("۹) صفحهٔ دکان، جایگاه واقعی‌اش را می‌گوید")
cheap, dear = db.business(bid=ids[0]), db.business(bid=ids[2])
blk = V2.price_context_block(ids[0])
check("دکانٔ ارزان، بلوک مقایسه دارد", bool(blk), "")
check("و «ارزان‌ترین در شهر» را نشان می‌دهد", "ارزان‌ترین در شهر" in blk, "")

blk2 = V2.price_context_block(ids[2])
check("دکانٔ گران هم بلوک دارد (پنهان نمی‌شود)", bool(blk2), "")
check("و صادقانه می‌گوید ارزان‌ترین نیست",
      "بیشتر از ارزان‌ترین" in blk2, "")
check("و ادعای «ارزان‌ترین» نمی‌کند",
      "ارزان‌ترین در شهر" not in blk2, "")

code, bh = get(f"/b/{cheap['slug']}")
check("بلوک روی صفحهٔ واقعی دکان رندر می‌شود",
      code == 200 and "price-context" in bh, f"code={code}")

head("۱۰) دکانٔ بدون کالای مشترک، بلوک خالی نمی‌گیرد")
check("دکانٔ تک‌فروش بلوک مقایسه ندارد",
      V2.price_context_block(solo) == "", "بلوک بی‌مورد ساخته شد")

head("۱۱) پاک‌سازی")
for b in db.businesses(status=None):
    if TAG in (b.get("tags") or ""):
        db.delete_business(b["id"])
left = [b for b in db.businesses(status=None) if TAG in (b.get("tags") or "")]
check("داده‌های آزمایشی حذف شدند", not left, f"{len(left)} مانده")
check("و از مقایسه هم رفتند",
      not any("آزمون" in g2["title"] for g2 in db.comparable_items()), "")
db.set_setting("prices_enabled", _saved_prices)

print(f"\n\033[1m{'='*58}\033[0m")
if bad_n == 0:
    print(f"\033[1m\033[32m  همه موفق — {ok_n} آزمون، ۰ ناموفق\033[0m")
else:
    print(f"\033[1m\033[31m  {ok_n} موفق، {bad_n} ناموفق\033[0m")
    for f in FAILS:
        print(f"    • {f}")
print(f"\033[1m{'='*58}\033[0m\n")
sys.exit(1 if bad_n else 0)
