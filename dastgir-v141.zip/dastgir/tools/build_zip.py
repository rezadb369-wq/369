#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build the release zip for dastgir (excludes data/raw/shots/caches/logs)."""
import os, sys, zipfile

ROOT = "/home/user/repo-369"
OUT = sys.argv[1] if len(sys.argv) > 1 else "/home/user/dastgir-v132.zip"

EXCLUDE_DIRS = {"__pycache__", "data", "raw", "shots", ".git", "node_modules",
                ".arena", ".cache", "dist", "build", "target", "out"}
# v134: user-generated media must never ship inside a code release — a deploy
# zip that carried uploads would overwrite/leak real user files on the server.
EXCLUDE_PREFIX = ("site/assets/img/uploads",)
EXCLUDE_EXT = {".db", ".db-wal", ".db-shm", ".log", ".zip", ".pyc"}

def keep(rel):
    if any(p in EXCLUDE_DIRS for p in rel.split("/")):
        return False
    if rel.startswith(EXCLUDE_PREFIX):
        return False
    base = os.path.basename(rel)
    if base.endswith(".db") or base.endswith(".log"):
        return False
    return os.path.splitext(base)[1].lower() not in EXCLUDE_EXT

n = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for dirpath, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for f in files:
            full = os.path.join(dirpath, f)
            rel = os.path.relpath(full, ROOT)
            if not keep(rel):
                continue
            z.write(full, rel)
            n += 1

print(f"wrote {OUT}: {n} files, {os.path.getsize(OUT):,} bytes")
with zipfile.ZipFile(OUT) as z:
    names = z.namelist()
    bad = [x for x in names if x.startswith(("data/", "raw/", "shots/")) or "__pycache__" in x or x.endswith((".db", ".log"))]
    print("excluded-violations:", bad[:5] if bad else "none")
