# -*- coding: utf-8 -*-
"""v111 contrast audit — «تمام فونت‌ها در حالت روز و شب درست باشند».

For every public page × both themes, walk the rendered DOM and measure the
REAL contrast of every visible text run against its REAL composited
background (translucent surfaces included). Any run under WCAG AA (4.5:1 for
body text, 3:1 for ≥18.7px/bold text) is reported with selector + colours, so
a faint font can never ship unnoticed again.

Run:  python3 tools/contrast_audit.py          (server on :8080)
      BZ=http://127.0.0.1:8080 python3 tools/contrast_audit.py
Exit code 0 only when both themes are clean.
"""
import os
import sys
from playwright.sync_api import sync_playwright

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
PAGES = ["/", "/catalog", "/businesses", "/map", "/login", "/cities", "/contact"]


def _dyn():
    """v117/فاز۷: صفحات پویا هم کنتراست را می‌گیرند — از دیتای زنده."""
    import sys as _s, os as _o
    _s.path.insert(0, _o.path.join(_o.path.dirname(_o.path.abspath(__file__)),
                                   "..", "server"))
    import db as _db
    con = _db.connect()
    out = []
    r = con.execute("SELECT slug FROM businesses WHERE status='published' "
                    "ORDER BY id LIMIT 1").fetchone()
    if r:
        out += [f"/b/{r['slug']}", f"/b/{r['slug']}/chat"]
    it = con.execute("SELECT i.id FROM items i JOIN businesses b "
                     "ON b.id=i.biz_id WHERE b.status='published' LIMIT 1"
                     ).fetchone()
    if it:
        out.append(f"/item/{it['id']}")
    po = con.execute("SELECT slug FROM posts ORDER BY id LIMIT 1").fetchone()
    if po:
        out.append(f"/blog/{po['slug']}")
    con.close()
    return out


PAGES += _dyn()
THEMES = ("light", "dark")

# text that intentionally sits on photo/video media with its own shadow
WHITELIST = (".sv-caption", ".sv-link", ".story-media", ".biz-hero.has-cover",
             ".leaflet-container", ".hero-art", "img", "video", "canvas")

# coloured bands whose own background may be a gradient: their TEXT is checked
# against the FLAT composited surface underneath (the v111 bug class was a
# white-on-grey band token, invisible in one theme).
BANDS = (".cta-band", ".cta-band h2", ".cta-band p", ".feat-band", ".feat-band h2",
         ".feat-band p", ".feat-card", ".badge", ".alert", ".btn", ".bottom-nav a",
         ".site-header", ".hero h1", ".hero-lead")

AUDIT_JS = r"""() => {
  const parse = c => {
    const m = c.match(/rgba?\(([\d.]+), *([\d.]+), *([\d.]+)(?:, *([\d.]+))?\)/);
    return m ? [ +m[1], +m[2], +m[3], m[4] === undefined ? 1 : +m[4] ] : null;
  };
  const lum = ([r, g, b]) => {
    const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4; };
    return .2126 * f(r) + .7152 * f(g) + .0722 * f(b);
  };
  const ratio = (a, b) => {
    const la = lum(a), lb = lum(b);
    return (Math.max(la, lb) + .05) / (Math.min(la, lb) + .05);
  };
  // composite fg over an alpha stack of backgrounds up to the html root
  const effBg = el => {
    const stack = [];
    let n = el;
    while (n && n.nodeType === 1) {
      const s = getComputedStyle(n);
      if (s.backgroundImage && s.backgroundImage !== "none") return null; // decorative
      const bg = parse(s.backgroundColor);
      if (bg && bg[3] > 0) stack.push(bg);
      if (bg && bg[3] >= 1) break;
      n = n.parentElement;
    }
    if (!stack.length) return [255, 255, 255];
    let [r, g, b] = [255, 255, 255];          // assume white page under everything
    for (let i = stack.length - 1; i >= 0; i--) {
      const [sr, sg, sb, sa] = stack[i];
      r = sr * sa + r * (1 - sa);
      g = sg * sa + g * (1 - sa);
      b = sb * sa + b * (1 - sa);
    }
    return [r, g, b];
  };
  const sel = el => {
    let s = el.tagName.toLowerCase();
    if (el.id) return s + "#" + el.id;
    if (el.className && typeof el.className === "string")
      s += "." + el.className.trim().split(/\s+/).slice(0, 2).join(".");
    return s;
  };
  const out = [];
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
  const seen = new Set();
  while (walker.nextNode()) {
    const el = walker.currentNode;
    if (!el.children.length || true) { /* check any element holding text */ }
    const txt = Array.from(el.childNodes)
      .filter(n => n.nodeType === 3 && n.textContent.trim()).map(n => n.textContent.trim()).join(" ");
    if (!txt) continue;
    if (WHITELIST.some(w => el.closest(w))) continue;
    const s = getComputedStyle(el);
    if (s.display === "none" || s.visibility === "hidden") continue;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) continue;
    const fg = parse(s.color);
    const bg = effBg(el);
    if (!fg || !bg) continue;
    const fs = parseFloat(s.fontSize);
    const large = fs >= 18.7 || (fs >= 14 && (parseInt(s.fontWeight) >= 700 || s.fontWeight === "bold"));
    const need = large ? 3 : 4.5;
    const cr = ratio(fg, bg);
    const key = sel(el) + "|" + Math.round(cr * 10) / 10;
    if (cr < need && !seen.has(key)) {
      seen.add(key);
      out.push({ sel: sel(el), text: txt.slice(0, 26), fs: Math.round(fs),
                 fg: s.color, cr: Math.round(cr * 100) / 100, need });
    }
    if (fs < 12) out.push({ sel: sel(el), text: txt.slice(0, 26), fs: Math.round(fs),
                            fg: s.color, cr: "TINY", need: 12 });
  }
  // ---- pass 2: coloured bands / chrome (buttons, badges, nav, header) ----
  // fills may be solid OR gradient; a gradient fill yields every stop as a
  // candidate surface and the worst stop decides.
  const effSelf = el => {
    const s = getComputedStyle(el);
    if (s.backgroundImage && s.backgroundImage.includes("linear-gradient")) {
      const stops = [...s.backgroundImage.matchAll(/rgba?\([\d.]+, *[\d.]+, *[\d.]+(?:, *[\d.]+)?\)/g)]
        .map(m => parse(m[0])).filter(Boolean);
      if (stops.length) return stops;
    }
    const own = parse(s.backgroundColor);
    if (own && own[3] >= .85) return [[own[0], own[1], own[2]]];
    let n = el.parentElement;
    while (n && n.nodeType === 1) {
      const s2 = getComputedStyle(n);
      const bg = parse(s2.backgroundColor);
      if (bg && bg[3] >= 0.9) return [[bg[0], bg[1], bg[2]]];
      if (s2.backgroundImage && (s2.backgroundImage.includes("linear-gradient") || s2.backgroundImage.includes("radial-gradient"))) {
        const stops = [...s2.backgroundImage.matchAll(/rgba?\([\d.]+, *[\d.]+, *[\d.]+(?:, *[\d.]+)?\)/g)]
          .map(m => parse(m[0])).filter(Boolean);
        if (stops.length) return stops;
      }
      n = n.parentElement;
    }
    return [[255, 255, 255]];
  };
  for (const sel of BANDS) {
    for (const el of document.querySelectorAll(sel)) {
      const s = getComputedStyle(el);
      if (s.display === "none" || s.visibility === "hidden") continue;
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) continue;
      const fg = parse(s.color);
      const bgs = effSelf(el);
      if (!fg) continue;
      const fs = parseFloat(s.fontSize);
      const large = fs >= 18.7 || (fs >= 14 && parseInt(s.fontWeight) >= 700);
      const need = large ? 3 : 4.5;
      const cr = Math.min(...bgs.map(c => ratio(fg, c)));
      if (cr < need) out.push({ sel: "BAND " + sel, text: (el.textContent || "").trim().slice(0, 22),
                              fs: Math.round(fs), fg: s.color,
                              cr: Math.round(cr * 100) / 100, need });
    }
  }
  return out;
}
""".replace("WHITELIST", json_list := repr(list(WHITELIST)).replace("'", '"')) \
   .replace("BANDS", json_bands := repr(list(BANDS)).replace("'", '"'))


def main():
    total = 0
    with sync_playwright() as p:
        b = p.chromium.launch(args=["--no-sandbox", "--enable-unsafe-swiftshader"])
        for theme in THEMES:
            ctx = b.new_context(viewport={"width": 1280, "height": 900})
            pg = ctx.new_page()
            for url in PAGES:
                pg.goto(BASE + url, wait_until="commit")
                pg.evaluate(f"localStorage.setItem('bz-theme','{theme}')")
                pg.reload(wait_until="networkidle")
                pg.wait_for_timeout(350)
                # expand lazy sections
                pg.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                pg.wait_for_timeout(250)
                bad = pg.evaluate(AUDIT_JS)
                if bad:
                    total += len(bad)
                    print(f"\n== {url} [{theme}] — {len(bad)} مورد")
                    for x in bad[:14]:
                        print(f"   {x['sel']:<38} {str(x['cr']):<6} (نیاز {x['need']}) "
                              f"fs={x['fs']}px  «{x['text']}»  fg={x['fg']}")
                else:
                    print(f"   ✓ {url} [{theme}]")
            ctx.close()
        b.close()
    print("\nمجموع خطاهای کنتراست:", total)
    sys.exit(0 if total == 0 else 1)


if __name__ == "__main__":
    main()
