# Messenger Chat Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** تبدیل چت متنی فعلی به پیام‌رسان موبایل‌اول با پیوست خصوصی و نظارت کامل مدیر.

**Architecture:** متادیتای فایل و read cursor در SQLite قرار می‌گیرد، بایت فایل بیرون web root در `data/chat-files` ذخیره می‌شود و فقط controller احرازشده آن را تحویل می‌دهد. HTML مشترک سه نقش به `views_chat.py` منتقل می‌شود و polling فعلی بدون WebSocket حفظ اما امن و دسترس‌پذیر می‌شود.

**Tech Stack:** Python 3.11+ standard library، SQLite، server-rendered HTML، CSS، JavaScript ES modules، Playwright فقط برای آزمون توسعه.

**Spec:** `docs/superpowers/specs/2026-08-23-messenger-chat-design.md`

## Global Constraints

- پاسخ کاربر فارسی؛ کد و شناسه‌ها انگلیسی.
- runtime فقط کتابخانهٔ استاندارد پایتون و سازگار با Pydroid 3.
- موبایل‌اول؛ تست اجباری ۳۶۰، ۳۹۰ و ۴۱۲px؛ هدف لمسی حداقل ۴۴px.
- فایل خصوصی، allowlist، magic bytes، سقف ۸MB، نام تصادفی، بدون SVG/Office/ZIP.
- هیچ متن/نام فایل/مسیر داخلی بدون escape یا کنترل دسترسی به خروجی نمی‌رود.
- TDD: هر رفتار تازه ابتدا باید در `tools/test_chat_v73.py` شکست بخورد.
- نسخهٔ نهایی v73 و Service Worker/cache همگی v73.

---

### Task 1: Schema, private storage, and data contracts

**Files:**
- Modify: `server/db.py:205-221, 865-1018`
- Modify: `server/features.py:175-310, 918-990`
- Modify: `server/uploads.py`
- Create: `tools/test_chat_v73.py`

**Interfaces:**
- Consumes: `db.connect()`, existing `chat_threads`, `chat_messages`, multipart parser.
- Produces: `save_chat_file`, `delete_chat_file`, `read_chat_file`, `gc_chat_files`, `chat_send(..., attachment=None)`, `chat_attachment`, `chat_attachment_names`, `chat_mark_read`, `chat_unread_count`, grouped thread queries.

- [ ] **Step 1: Write failing schema and data tests**

Create tests that call `db.init()`, assert `chat_attachments` exists and the three `*_read_to` columns exist, then create two customers/two owners/two shops and assert:

```python
mid = db.chat_send(tid, "customer", "سلام")
check("message id returned", isinstance(mid, int) and mid > 0)
check("empty message rejected", db.chat_send(tid, "customer", "") is None)
db.chat_mark_read(tid, "owner")
check("owner unread cleared", db.chat_unread_count(tid, "owner") == 0)
```

- [ ] **Step 2: Run RED**

Run: `BZ=http://127.0.0.1:8080 python3 tools/test_chat_v73.py`  
Expected: FAIL because attachment table/columns/functions do not exist and `chat_send` returns bool.

- [ ] **Step 3: Add schema and migration**

Add `chat_attachments`, indexes, and idempotent `ALTER TABLE chat_threads ADD COLUMN ...` guarded by `PRAGMA table_info`.

- [ ] **Step 4: Add private file validator/storage**

Implement:

```python
CHAT_MAX_FILE = 8 * 1024 * 1024
CHAT_UPLOAD_DIR = os.path.join(ROOT, "data", "chat-files")

def save_chat_file(data, original_name):
    # size -> magic/type -> random name -> write -> metadata dict
```

JPEG/PNG/WebP/GIF use strict signatures; PDF requires `%PDF-` and `%%EOF` near the end; TXT must decode UTF-8 and contain no NUL. Return Persian error strings without using the browser-supplied Content-Type.

- [ ] **Step 5: Replace chat data functions**

Make `chat_send` transactional, join attachments in `chat_messages`, update sender read cursor, and replace per-thread N+1 loops with one last-message join plus one unread subquery.

- [ ] **Step 6: Run GREEN for Task 1**

Run the focused data/storage section and verify all assertions pass; run `python3 -m compileall -q server tools`.

- [ ] **Step 7: Commit**

```bash
git add server/db.py server/features.py server/uploads.py tools/test_chat_v73.py
git commit -m "feat: add secure chat attachments and unread state"
```

---

### Task 2: Authenticated send, poll, download, and admin controls

**Files:**
- Modify: `server/app.py:610-764, 1215-1262, 1416-1444, 1808-1823, 2183-2397`
- Modify: `run.py` or `server/app.py:make_server`
- Test: `tools/test_chat_v73.py`

**Interfaces:**
- Consumes: Task 1 storage/data contracts and current cookie/key authentication.
- Produces: `_chat_access`, `_chat_send`, `/chat-file/<id>`, multipart chat routes, status route, sanitized poll JSON.

- [ ] **Step 1: Write failing HTTP/security tests**

Using four cookie jars (customer A, customer B, owner A, owner B) and admin key, assert:

```text
customer A own thread/file = 200
customer B foreign thread/file = 403
owner A own shop thread/file = 200
owner B foreign thread/file = 403
admin key thread/file = 200
anonymous file = 403
```

Also POST a fake `evil.php.jpg`, SVG and oversized payload and assert no message/attachment/file is created.

- [ ] **Step 2: Run RED**

Expected: multipart chat routes and `/chat-file` return 404; security/header assertions fail.

- [ ] **Step 3: Add centralized access resolution**

Implement a method that returns `customer`, `owner`, `admin`, or `None` from a thread and the current cookies/query. All poll, send and download paths must call it before data/file access.

- [ ] **Step 4: Add text and multipart send flows**

Keep old form-urlencoded POSTs. For multipart, read `body` plus the single `attachment`; save bytes, insert DB metadata, delete the file if DB insertion fails, then redirect with Persian `ok`/`err`.

- [ ] **Step 5: Add private download response**

Read attachment metadata only after authorization. Image responses are inline; PDF/TXT attachment-only. Add:

```python
{
  "Cache-Control": "private, no-store",
  "Content-Disposition": "attachment; filename*=UTF-8''...",
}
```

Never include `stored_name` in JSON or HTML.

- [ ] **Step 6: Fix polling and add status control**

Poll JSON contains only public attachment fields and read cursors. Admin polling includes key from the page. Add `/panel/chat/<id>/status` allowing only `open|closed`.

- [ ] **Step 7: Add orphan-file GC hook**

At server start call `uploads.gc_chat_files(set(db.chat_attachment_names()))` with age protection.

- [ ] **Step 8: Run GREEN for Task 2**

Run all HTTP/IDOR/upload assertions and inspect that rejected uploads leave disk and DB counts unchanged.

- [ ] **Step 9: Commit**

```bash
git add server/app.py run.py server/uploads.py tools/test_chat_v73.py
git commit -m "feat: secure chat upload and download routes"
```

---

### Task 3: Shared messenger UI for customer and shopkeeper

**Files:**
- Create: `server/views_chat.py`
- Modify: `server/views_customer.py:214-260`
- Modify: `server/views_owner.py:1528-1575`
- Modify: `server/ui.py:159-171`
- Modify: `site/assets/css/main.css:1361-1387`
- Modify: `site/assets/css/mobile-standard.css`
- Modify: `site/assets/js/chat.js`
- Test: `tools/test_chat_v73.py`

**Interfaces:**
- Consumes: messages/thread rows with attachment fields and unread count.
- Produces: `thread_list`, `chat_room`, `message_markup`, messenger behavior in `chat.js`.

- [ ] **Step 1: Write failing markup/browser tests**

Assert customer and owner pages contain:

```text
data-chat-room, role="log", aria-live="polite"
enctype="multipart/form-data"
input[type=file] accept="image/jpeg,image/png,image/webp,image/gif,application/pdf,text/plain"
textarea composer, attachment preview, new-message button
```

In Playwright at 360/390/412 assert no overflow, composer controls ≥44px, Enter submits, Shift+Enter does not, selected file name appears, console has no errors.

- [ ] **Step 2: Run RED**

Expected: shared module and messenger hooks missing; current single-line input/layout fails.

- [ ] **Step 3: Create shared view module**

Render list rows, sender labels, attachment previews/cards, read state, date/time and the common room shell. Use `esc()` for every user value and build file URLs from numeric attachment IDs only.

- [ ] **Step 4: Replace customer/owner duplicate HTML**

Customer uses viewer `customer`, owner uses viewer `owner`; each passes correct post/back URLs. Add `/my/chats` to the mobile owner-area navigation.

- [ ] **Step 5: Implement messenger CSS**

Use existing luxury tokens, not a generic blue messenger clone: emerald own bubbles, dark glass received bubbles, amber admin stripe, sticky composer, compact inbox rows, responsive full-width room on phones.

- [ ] **Step 6: Implement chat JavaScript**

Render polled text and attachments safely with DOM APIs, preserve user scroll, show new-message affordance, auto-grow textarea, keyboard behavior, file preview/removal and live status. No `innerHTML` with server/user text.

- [ ] **Step 7: Run GREEN for Task 3**

Run browser assertions at all required widths and `node --check site/assets/js/chat.js`.

- [ ] **Step 8: Commit**

```bash
git add server/views_chat.py server/views_customer.py server/views_owner.py server/ui.py site/assets/css/main.css site/assets/css/mobile-standard.css site/assets/js/chat.js tools/test_chat_v73.py
git commit -m "feat: redesign customer and owner chat as messenger"
```

---

### Task 4: Admin conversation control center

**Files:**
- Modify: `server/views_panel2.py:1360-1418`
- Modify: `server/app.py:1139-1145, 2385-2397`
- Modify: `server/features.py`
- Modify: `site/assets/css/pages.css`
- Test: `tools/test_chat_v73.py`

**Interfaces:**
- Consumes: grouped admin thread query, shared `views_chat` room/list.
- Produces: searchable/filterable `/panel/chats`, admin read badge, close/reopen action, transparent admin messages.

- [ ] **Step 1: Write failing admin tests**

Create two shops/threads and assert query `q=<shop/customer>` narrows rows, `status=closed` filters, stats match, admin unread clears on view, admin reply appears to both parties as «مدیر بازارچه», and status POST rejects invalid values.

- [ ] **Step 2: Run RED**

Expected: current admin page has no search/stats/status and admin unread does not exist.

- [ ] **Step 3: Implement control center**

Add GET search/filter form, summary cards, list rows with last sender/unread/file preview, participant metadata, direct shop link and open/close form. Use shared room renderer with `data-key` for polling/download URLs.

- [ ] **Step 4: Run GREEN for Task 4**

Run admin functional, IDOR, polling and browser tests.

- [ ] **Step 5: Commit**

```bash
git add server/views_panel2.py server/app.py server/features.py site/assets/css/pages.css tools/test_chat_v73.py
git commit -m "feat: add admin chat control center"
```

---

### Task 5: Versioning, documentation, and full verification

**Files:**
- Modify: all runtime `?v72` references to `?v73`
- Modify: `site/sw.js`
- Modify: `WHATS-NEW.md`
- Create: `REPORT-v73.md`
- Modify external memory: `/home/user/HANDOFF.md`, `/home/user/CLAUDE.md`

**Interfaces:**
- Consumes: completed Tasks 1-4.
- Produces: verified `bazarche-najafabad-v73.zip` without data.

- [ ] **Step 1: Bump cache version**

Replace runtime `?v72` with `?v73` and `bazarche-v72` with `bazarche-v73`; assert no stale runtime refs remain.

- [ ] **Step 2: Run syntax and focused tests**

```bash
python3 -m compileall -q server tools run.py
for f in site/assets/js/*.js; do node --check "$f"; done
BZ=http://127.0.0.1:8080 python3 tools/test_chat_v73.py
```

- [ ] **Step 3: Run all existing suites and audits**

Run the 20 principal suites, `mobile_audit.py`, `audit.py`, `verify.py`, `walkthrough_e2e.py`, and record exact successes/failures. Do not claim completion if a chat regression fails.

- [ ] **Step 4: Security verification**

Re-run forged extensions, oversized body, path traversal filename, anonymous/foreign file GET, poll IDOR, XSS body/filename and DB integrity. Verify no internal stored filename appears in responses.

- [ ] **Step 5: Write report and memory**

Document design, allowed types/limits, route matrix, RED/GREEN evidence, test counts and any unrelated pre-existing issue honestly.

- [ ] **Step 6: Package and inspect**

Create `/home/user/bazarche-najafabad-v73.zip`, excluding `.git/`, `data/`, `raw/`, `shots/`, `__pycache__/` and caches. Run `ZipFile.testzip()`, path-traversal scan, forbidden-path scan and SHA-256.

- [ ] **Step 7: Commit**

```bash
git add server site tools WHATS-NEW.md REPORT-v73.md docs/superpowers
 git commit -m "release: prepare v73 messenger chat"
```
