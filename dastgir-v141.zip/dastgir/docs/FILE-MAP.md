# FILE-MAP — نقشهٔ کامل فایل‌های سایت (هر بخش کجاست)

> **هدف:** هر کس (یا هر عامل) بخواهد چیزی را در سایت تغییر دهد یا باگی را
> عیب‌یابی کند، از این یک سند بفهمد **فایلِ آن بخش کجاست**. این سند با
> `tools/routemap.py` و `tools/build_filemap.py` تولید می‌شود.

## ۰) یک‌نگاه — درخت پوشه‌ها

```
repo-369/
├── run.py                  نقطهٔ ورود اجرا (پورت خودکار، سقف fd، systemd-ready)
│
├── server/                 ⬅ همهٔ منطق سمت سرور (پایتون خالص، stdlib-only)
│   ├── app.py              هسته: HTTP handler + مسیریابی + auth/سشن + آپلود + هدرها
│   ├── db.py               لایهٔ داده: ۵۷+ جدول، CRUD، rate_ok، مهاجرت/سازگاری SCHEMA
│   ├── features.py         زیرسیستم‌های چندجدولی: چت، سفارش، تیکت، علاقه‌مندی، چانه
│   ├── ui.py               قالب صفحات: کروم، هدر/فوتر، منو، قفل‌ها، بامپ ?vNNN
│   ├── pagecache.py        کش صفحات مهمان (TTL ۸s، ابطال با هر POST)
│   ├── shield.py           سپر ضد-اسپم/حمله: rate-limit، اسکنر، UA مخرب
│   ├── analytics.py        آمار بازدید واقعی (IP/دستگاه/نشست، فیلتر بات)
│   ├── uploads.py          پارسر multipart دستی + سقف‌ها + EXIF-strip
│   ├── sms.py              کد یک‌بارمصرف (SMS/نمایش توسعه)
│   ├── qr.py               رمزگذار QR بدون کتابخانه (SVG)
│   ├── views_public.py     صفحات عمومی: خانه، فهرست، دکان، ثبت‌نام، جست‌وجو
│   ├── views_public2.py    عمومی ۲: مقایسه، نزدیک‌من، رویداد، چانه، تماس
│   ├── views_catalog.py    کاتالوگ/ویترین/کشف
│   ├── views_chat.py       چت بلادرنگ
│   ├── views_customer.py   پنل مشتری (/me)
│   ├── views_owner.py      پنل دکان‌دار (/my)
│   ├── views_panel.py      پنل مدیر بخش ۱ (کسب‌وکارها، نظرات، محتوا…)
│   ├── views_panel2.py     پنل مدیر بخش ۲ (moderation/audit/traffic/قابلیت‌ها)
│   └── views_extra.py      صفحه‌های ریز (درباره/تماس/آفلاین)
│
├── site/                   ⬅ فایل‌های سمت مرورگر
│   ├── sw.js               سرویس‌ورکر (PWA) — VERSION اینجا بامپ می‌شود
│   ├── offline.html        صفحهٔ آفلاین فارسی
│   ├── manifest.webmanifest  مانیفست PWA (نصب روی گوشی)
│   └── assets/
│       ├── css/            ۷ فایل — جدول آن‌ها در بخش ۲
│       ├── js/             ۲۰ فایل — جدول آن‌ها در بخش ۳
│       ├── fonts/          Vazirmatn (وزیرمتن)
│       ├── img/            آیکون‌ها، لوگو، هیرو (195 فایل)
│       └── vendor/         کتابخانه‌های محلی: Leaflet و… (بدون CDN)
│
├── tools/                  ⬅ ابزارها و آزمون‌ها (جدول بخش ۵)
├── data/                   ⬅ دیتابیس + آپلودها (در زیپ تحویلی نیست)
├── docs/                   گزارش‌های ممیزی، تحقیق پنل، نقشهٔ مسیرها
└── *.md                    مستندات (HANDBOOK/READY/DEPLOY/…)
```

## ۱) «این صفحه/بخش کدام فایل است؟» — جدول بخش‌ها

| بخش سایت | مسیرها | فایل‌های منطق | فایل‌های ظاهر | فایل‌های رفتار (JS) |
|---|---|---|---|---|
| صفحهٔ اصلی | `/` | `views_public.py` | `main.css`, `pages.css` | `app.js`, `stories.js` |
| فهرست/جست‌وجو/دسته‌ها | `/businesses`, `/areas` | `views_public.py` | `pages.css` | `app.js`, `catpicker.js` |
| صفحهٔ کسب‌وکار | `/b/<slug>` | `views_public.py` | `pages.css`, `main.css` | `app.js`, `gallery.js` |
| نقشه | `/map` | `views_public2.py` | `pages.css` (`.map-*`) | `mappage.js` |
| مقایسهٔ قیمت | `/prices` | `views_public2.py` | `pages.css` | `app.js` |
| کاتالوگ/ویترین | `/catalog` | `views_catalog.py` | `pages.css` | `app.js` |
| چانه‌زنی | `/haggle/*`, `/offer/*` | `views_public2.py` | `pages.css` | `app.js` |
| ثبت کسب‌وکار | `/submit` | `views_public.py` | `pages.css` | `app.js`, `catpicker.js` |
| پنل مشتری | `/me/*` | `views_customer.py` | `pages.css` | `app.js` |
| پنل دکان‌دار | `/my/*` | `views_owner.py` | `main.css`, `pages.css` | `app.js`, `imagefield.js` |
| پنل مدیر | `/panel/*` | `views_panel.py`, `views_panel2.py` | `main.css`, `pages.css` | `panel.js` |
| چت | `/chat/*` | `views_chat.py` | `pages.css` | `chat.js` |
| ورود/OTP | `/login*`, `/alert` | `app.py` (auth) + `views_public.py` | `main.css` | `app.js` |
| API | `/api/*` | `app.py` | — | — |

## ۲) فایل‌های CSS (چه چیزی کجاست)

| فایل | اندازه (خط) | نقش |
|---|---|---|
| `main.css` | 2021 | — |
| `mobile-refine.css` | 323 | — |
| `mobile-standard.css` | 131 | — |
| `pages.css` | 3635 | — |
| `theme-light.css` | 35 | — |
| `theme-night.css` | 35 | — |
| `tokens.css` | 314 | — |

- **توکن‌ها** همه در `tokens.css` (`:root` روز + `[data-theme]` شب).
- **رنگ خام در ویوها ممنوع است** (قانون معماری) — فقط توکن.
- **چیدمان موبایل:** `mobile-refine.css` و `mobile-standard.css` — هدف لمس ≥۴۴px با
  `var(--tap)`.
- **کامپوننت‌های نقشه** (نزدیک‌من/زوم/کارت انتخاب‌شده) همگی با پیشوند `.map-`
  در `pages.css`.

## ۳) فایل‌های JS (رفتار)

| فایل | خط | نقش |
|---|---|---|
| `admin-edit.js` | 84 | — |
| `app.js` | 1723 | — |
| `bulk.js` | 53 | — |
| `cart.js` | 129 | — |
| `catpicker.js` | 194 | — |
| `chat.js` | 276 | — |
| `compare.js` | 133 | — |
| `compress.js` | 301 | — |
| `countdown.js` | 19 | — |
| `dupcheck.js` | 119 | — |
| `favorites.js` | 64 | — |
| `imagefield.js` | 390 | — |
| `itemform.js` | 106 | — |
| `map.js` | 284 | — |
| `mappage.js` | 470 | — |
| `nearby.js` | 142 | — |
| `qa.js` | 72 | — |
| `social.js` | 50 | — |
| `stories.js` | 236 | — |
| `upload.js` | 182 | — |

قانون: HTML سمت سرور رندر می‌شود؛ JS فقط رفتار (تعامل، OTP خودکار، بیکن آمار).

## ۴) نقشهٔ مسیرها (تولید خودکار)

# نقشهٔ مسیرها — هر URL کجاست؟

> تولید خودکار با `python3 tools/routemap.py -o docs/FILE-MAP.md` — اگر مسیر تازه‌ای اضافه شد، دوباره اجرا کنید.


## پنل مدیر (/panel)

| مسیر | فایل | خط |
|---|---|---|
| `/panel` | `server/app.py` | 756 |
| `/panel` | `server/app.py` | 971 |
| `/panel` | `server/app.py` | 979 |
| `/panel` | `server/app.py` | 1440 |
| `/panel/ad/(` | `server/app.py` | 3697 |
| `/panel/ad/new` | `server/app.py` | 2909 |
| `/panel/ads` | `server/app.py` | 1532 |
| `/panel/alert/(` | `server/app.py` | 3788 |
| `/panel/alerts` | `server/app.py` | 1538 |
| `/panel/analytics` | `server/app.py` | 1500 |
| `/panel/analytics/export` | `server/app.py` | 1502 |
| `/panel/appearance` | `server/app.py` | 1466 |
| `/panel/appearance` | `server/app.py` | 2874 |
| `/panel/appearance` | `server/app.py` | 3358 |
| `/panel/areas` | `server/app.py` | 1612 |
| `/panel/areas/rename` | `server/app.py` | 3015 |
| `/panel/audit` | `server/app.py` | 1583 |
| `/panel/audit/export` | `server/app.py` | 1585 |
| `/panel/backup` | `server/app.py` | 1623 |
| `/panel/backup/export` | `server/app.py` | 1625 |
| `/panel/backup/full` | `server/app.py` | 1631 |
| `/panel/backup/import` | `server/app.py` | 3800 |
| `/panel/badge/(` | `server/app.py` | 3587 |
| `/panel/badge/new` | `server/app.py` | 3577 |
| `/panel/badges` | `server/app.py` | 1526 |
| `/panel/badges/auto` | `server/app.py` | 3620 |
| `/panel/badges/grant` | `server/app.py` | 3610 |
| `/panel/booking/(` | `server/app.py` | 3325 |
| `/panel/bookings` | `server/app.py` | 1458 |
| `/panel/broadcast` | `server/app.py` | 1608 |
| `/panel/broadcast` | `server/app.py` | 3098 |
| `/panel/business/(` | `server/app.py` | 1446 |
| `/panel/business/(` | `server/app.py` | 3195 |
| `/panel/business/(` | `server/app.py` | 3201 |
| `/panel/business/(` | `server/app.py` | 3243 |
| `/panel/business/(new|` | `server/app.py` | 3164 |
| `/panel/business/new` | `server/app.py` | 1444 |
| `/panel/businesses` | `server/app.py` | 1442 |
| `/panel/businesses/bulk` | `server/app.py` | 3457 |
| `/panel/businesses/export` | `server/app.py` | 1619 |
| `/panel/businesses/import` | `server/app.py` | 1617 |
| `/panel/businesses/import` | `server/app.py` | 3478 |
| `/panel/catalog/(` | `server/app.py` | 1482 |
| `/panel/catalog/(` | `server/app.py` | 1486 |
| `/panel/catalog/(` | `server/app.py` | 3513 |
| `/panel/catalog/(` | `server/app.py` | 3520 |
| `/panel/categories` | `server/app.py` | 1450 |
| `/panel/category/(` | `server/app.py` | 1452 |
| `/panel/category/(` | `server/app.py` | 3262 |
| `/panel/category/(` | `server/app.py` | 3272 |
| `/panel/category/new` | `server/app.py` | 3253 |
| `/panel/chat/(` | `server/app.py` | 1558 |
| `/panel/chat/(` | `server/app.py` | 2955 |
| `/panel/chat/(` | `server/app.py` | 2967 |
| `/panel/chats` | `server/app.py` | 1556 |
| `/panel/claim/(` | `server/app.py` | 3496 |
| `/panel/claims` | `server/app.py` | 1474 |
| `/panel/customer/(` | `server/app.py` | 3080 |
| `/panel/customer/(` | `server/app.py` | 3091 |
| `/panel/customers` | `server/app.py` | 1606 |
| `/panel/deal/(` | `server/app.py` | 3074 |
| `/panel/deal/new` | `server/app.py` | 3065 |
| `/panel/deals` | `server/app.py` | 1575 |
| `/panel/demo` | `server/app.py` | 1614 |
| `/panel/demo` | `server/app.py` | 3022 |
| `/panel/edit/(` | `server/app.py` | 3735 |
| `/panel/editor` | `server/app.py` | 1581 |
| `/panel/editor` | `server/app.py` | 3002 |
| `/panel/edits` | `server/app.py` | 1536 |
| `/panel/edits/toggle` | `server/app.py` | 3742 |
| `/panel/event/(` | `server/app.py` | 3723 |
| `/panel/event/new` | `server/app.py` | 3716 |
| `/panel/events` | `server/app.py` | 1534 |
| `/panel/features` | `server/app.py` | 1544 |
| `/panel/features` | `server/app.py` | 3131 |
| `/panel/follows` | `server/app.py` | 1610 |
| `/panel/gallery/(` | `server/app.py` | 1478 |
| `/panel/gallery/(` | `server/app.py` | 3508 |
| `/panel/inbox` | `server/app.py` | 1542 |
| `/panel/inline-edit` | `server/app.py` | 1950 |
| `/panel/inquiries` | `server/app.py` | 1476 |
| `/panel/inquiry/(` | `server/app.py` | 3503 |
| `/panel/insights` | `server/app.py` | 1540 |
| `/panel/list/(` | `server/app.py` | 1571 |
| `/panel/list/(` | `server/app.py` | 3049 |
| `/panel/list/(` | `server/app.py` | 3059 |
| `/panel/list/new` | `server/app.py` | 3040 |
| `/panel/lists` | `server/app.py` | 1569 |
| `/panel/login` | `server/app.py` | 1923 |
| `/panel/logout` | `server/app.py` | 1944 |
| `/panel/media` | `server/app.py` | 1657 |
| `/panel/media/delete` | `server/app.py` | 3449 |
| `/panel/media/gc` | `server/app.py` | 3443 |
| `/panel/message/(` | `server/app.py` | 3342 |
| `/panel/messages` | `server/app.py` | 1462 |
| `/panel/moderation` | `server/app.py` | 1604 |
| `/panel/order/(` | `server/app.py` | 2984 |
| `/panel/order/(` | `server/app.py` | 2989 |
| `/panel/orders` | `server/app.py` | 1565 |
| `/panel/owner/(` | `server/app.py` | 3485 |
| `/panel/owners` | `server/app.py` | 1472 |
| `/panel/pages` | `server/app.py` | 1464 |
| `/panel/pages` | `server/app.py` | 3352 |
| `/panel/plan/(` | `server/app.py` | 3637 |
| `/panel/plan/new` | `server/app.py` | 3626 |
| `/panel/plans` | `server/app.py` | 1528 |
| `/panel/plans/payment` | `server/app.py` | 3650 |
| `/panel/post/(` | `server/app.py` | 3336 |
| `/panel/post/new` | `server/app.py` | 3331 |
| `/panel/posts` | `server/app.py` | 1460 |
| `/panel/qa` | `server/app.py` | 1492 |
| `/panel/question/(` | `server/app.py` | 3530 |
| `/panel/report/(` | `server/app.py` | 3565 |
| `/panel/reports` | `server/app.py` | 1494 |
| `/panel/reports/bulk` | `server/app.py` | 3549 |
| `/panel/review/(` | `server/app.py` | 3309 |
| `/panel/reviews` | `server/app.py` | 1456 |
| `/panel/reviews/bulk` | `server/app.py` | 3293 |
| `/panel/rotate-token` | `server/app.py` | 3412 |
| `/panel/search` | `server/app.py` | 1468 |
| `/panel/searches/clear` | `server/app.py` | 3783 |
| `/panel/security` | `server/app.py` | 3418 |
| `/panel/settings` | `server/app.py` | 1470 |
| `/panel/settings` | `server/app.py` | 3378 |
| `/panel/stories` | `server/app.py` | 1577 |
| `/panel/story/(` | `server/app.py` | 3111 |
| `/panel/subscription/(` | `server/app.py` | 3677 |
| `/panel/subscription/new` | `server/app.py` | 3665 |
| `/panel/subscriptions` | `server/app.py` | 1530 |
| `/panel/ticket/(` | `server/app.py` | 1548 |
| `/panel/ticket/(` | `server/app.py` | 2745 |
| `/panel/ticket/(` | `server/app.py` | 3140 |
| `/panel/tickets` | `server/app.py` | 1546 |
| `/panel/tickets/bulk` | `server/app.py` | 3279 |
| `/panel/traffic` | `server/app.py` | 1498 |
| `/panel/traffic/unblock` | `server/app.py` | 3121 |
| `/panel/trash` | `server/app.py` | 1496 |
| `/panel/trash/(` | `server/app.py` | 3115 |
| `/panel/unlock/(` | `server/app.py` | 3749 |
| `/panel/unlocks` | `server/app.py` | 1552 |
| `/panel/unlocks/founder` | `server/app.py` | 3772 |

## پنل دکان‌دار (/my)

| مسیر | فایل | خط |
|---|---|---|
| `/my` | `server/app.py` | 758 |
| `/my` | `server/app.py` | 1006 |
| `/my` | `server/app.py` | 1299 |
| `/my/` | `server/app.py` | 2251 |
| `/my/account` | `server/app.py` | 1339 |
| `/my/account` | `server/app.py` | 2265 |
| `/my/booking/(` | `server/app.py` | 2474 |
| `/my/bookings` | `server/app.py` | 1321 |
| `/my/business/(` | `server/app.py` | 1360 |
| `/my/business/(` | `server/app.py` | 2422 |
| `/my/businesses` | `server/app.py` | 1317 |
| `/my/catalog/(` | `server/app.py` | 1372 |
| `/my/catalog/(` | `server/app.py` | 1376 |
| `/my/catalog/(` | `server/app.py` | 2365 |
| `/my/catalog/(` | `server/app.py` | 2495 |
| `/my/catalog/(` | `server/app.py` | 2514 |
| `/my/chat/(` | `server/app.py` | 1303 |
| `/my/chat/(` | `server/app.py` | 2272 |
| `/my/chats` | `server/app.py` | 1301 |
| `/my/claim` | `server/app.py` | 1325 |
| `/my/claim` | `server/app.py` | 2484 |
| `/my/export` | `server/app.py` | 1341 |
| `/my/gallery/(` | `server/app.py` | 1364 |
| `/my/gallery/(` | `server/app.py` | 2521 |
| `/my/inquiries` | `server/app.py` | 1323 |
| `/my/inquiry/(` | `server/app.py` | 2528 |
| `/my/logout` | `server/app.py` | 2243 |
| `/my/offer/(` | `server/app.py` | 2393 |
| `/my/offers` | `server/app.py` | 1329 |
| `/my/order/(` | `server/app.py` | 2290 |
| `/my/order/(` | `server/app.py` | 2295 |
| `/my/orders` | `server/app.py` | 1311 |
| `/my/plan` | `server/app.py` | 1337 |
| `/my/question/(` | `server/app.py` | 2460 |
| `/my/questions` | `server/app.py` | 1327 |
| `/my/review/(` | `server/app.py` | 2450 |
| `/my/reviews` | `server/app.py` | 1319 |
| `/my/stats/(` | `server/app.py` | 1368 |
| `/my/stories` | `server/app.py` | 1313 |
| `/my/story/(` | `server/app.py` | 996 |
| `/my/story/(` | `server/app.py` | 2309 |
| `/my/story/add` | `server/app.py` | 2761 |
| `/my/ticket/(` | `server/app.py` | 1333 |
| `/my/ticket/(` | `server/app.py` | 2346 |
| `/my/ticket/(` | `server/app.py` | 2730 |
| `/my/tickets` | `server/app.py` | 1331 |
| `/my/tickets` | `server/app.py` | 2328 |
| `/my/tickets` | `server/app.py` | 2709 |
| `/my/trash` | `server/app.py` | 1315 |
| `/my/trash/(` | `server/app.py` | 2317 |

## پنل مشتری (/me)

| مسیر | فایل | خط |
|---|---|---|
| `/me` | `server/app.py` | 760 |
| `/me` | `server/app.py` | 1019 |
| `/me` | `server/app.py` | 1385 |
| `/me/account` | `server/app.py` | 1407 |
| `/me/account` | `server/app.py` | 1785 |
| `/me/chat/(` | `server/app.py` | 1391 |
| `/me/chat/(` | `server/app.py` | 1905 |
| `/me/chats` | `server/app.py` | 1389 |
| `/me/export` | `server/app.py` | 1409 |
| `/me/favorites` | `server/app.py` | 1405 |
| `/me/following` | `server/app.py` | 1416 |
| `/me/login` | `server/app.py` | 1015 |
| `/me/login` | `server/app.py` | 1729 |
| `/me/login/password` | `server/app.py` | 1750 |
| `/me/login/verify` | `server/app.py` | 1744 |
| `/me/logout` | `server/app.py` | 1753 |
| `/me/name` | `server/app.py` | 1776 |
| `/me/notifications` | `server/app.py` | 1414 |
| `/me/notifications/read` | `server/app.py` | 1823 |
| `/me/order/(` | `server/app.py` | 1401 |
| `/me/order/(` | `server/app.py` | 1895 |
| `/me/orders` | `server/app.py` | 1399 |
| `/me/profile` | `server/app.py` | 1387 |
| `/me/profile` | `server/app.py` | 1761 |

## صفحهٔ کسب‌وکار (/b)

| مسیر | فایل | خط |
|---|---|---|
| `/b/` | `server/app.py` | 1191 |
| `/b/([^/]+)/ask-question$` | `server/app.py` | 2075 |
| `/b/([^/]+)/book$` | `server/app.py` | 2229 |
| `/b/([^/]+)/chat$` | `server/app.py` | 1088 |
| `/b/([^/]+)/report$` | `server/app.py` | 2112 |
| `/b/([^/]+)/review$` | `server/app.py` | 2149 |
| `/b/([^/]+)/review$` | `server/app.py` | 2786 |

## API

| مسیر | فایل | خط |
|---|---|---|
| `/api/alert` | `server/app.py` | 2128 |
| `/api/businesses` | `server/app.py` | 1151 |
| `/api/chat/(` | `server/app.py` | 1103 |
| `/api/check-duplicate` | `server/app.py` | 2066 |
| `/api/favorite` | `server/app.py` | 1795 |
| `/api/follow` | `server/app.py` | 1812 |
| `/api/nearby` | `server/app.py` | 1132 |
| `/api/question-helpful` | `server/app.py` | 2102 |
| `/api/review-helpful` | `server/app.py` | 1830 |
| `/api/search` | `server/app.py` | 1158 |
| `/api/stories` | `server/app.py` | 1064 |
| `/api/stories/(` | `server/app.py` | 1712 |

## فایل‌های ثابت / PWA

| مسیر | فایل | خط |
|---|---|---|
| `/assets/` | `server/app.py` | 878 |
| `/favicon.ico` | `server/app.py` | 882 |
| `/robots.txt` | `server/app.py` | 884 |
| `/sitemap.xml` | `server/app.py` | 898 |

## عمومی / متفرقه

| مسیر | فایل | خط |
|---|---|---|
| `/` | `server/app.py` | 1173 |
| `/([a-f0-9]{16})` | `server/analytics.py` | 143 |
| `/(me|my|panel)/chat/(` | `server/app.py` | 2683 |
| `/(my|panel)/catalog/(` | `server/app.py` | 2934 |
| `/(my|panel)/gallery/(` | `server/app.py` | 2819 |
| `/.well-known/security.txt` | `server/app.py` | 911 |
| `/ad/(` | `server/app.py` | 1265 |
| `/alert` | `server/app.py` | 2137 |
| `/area/([^/]+)$` | `server/app.py` | 1041 |
| `/areas` | `server/app.py` | 1035 |
| `/blog` | `server/app.py` | 1196 |
| `/blog/` | `server/app.py` | 1198 |
| `/businesses` | `server/app.py` | 1175 |
| `/cart` | `server/app.py` | 1031 |
| `/catalog` | `server/app.py` | 1078 |
| `/categories` | `server/app.py` | 1037 |
| `/chat-file/(` | `server/app.py` | 933 |
| `/cities` | `server/app.py` | 1039 |
| `/compare` | `server/app.py` | 1252 |
| `/contact` | `server/app.py` | 1285 |
| `/contact` | `server/app.py` | 1988 |
| `/deals` | `server/app.py` | 1060 |
| `/events` | `server/app.py` | 1258 |
| `/events/` | `server/app.py` | 1262 |
| `/favorites` | `server/app.py` | 1275 |
| `/features` | `server/app.py` | 1290 |
| `/haggle/(` | `server/app.py` | 1201 |
| `/haggle/(` | `server/app.py` | 2174 |
| `/healthz` | `server/app.py` | 900 |
| `/item/(` | `server/app.py` | 1074 |
| `/list/([^/]+)$` | `server/app.py` | 1054 |
| `/lists` | `server/app.py` | 1050 |
| `/login` | `server/app.py` | 1957 |
| `/login/password` | `server/app.py` | 1963 |
| `/login/verify` | `server/app.py` | 1960 |
| `/map` | `server/app.py` | 1194 |
| `/nearby` | `server/app.py` | 1254 |
| `/offer/([A-Za-z0-9_-]{6,64})$` | `server/app.py` | 1207 |
| `/offer/([A-Za-z0-9_-]{6,64})$` | `server/app.py` | 2201 |
| `/order/create` | `server/app.py` | 1838 |
| `/order/ok` | `server/app.py` | 1045 |
| `/prices` | `server/app.py` | 1246 |
| `/prices/alert` | `server/app.py` | 1732 |
| `/pricing` | `server/app.py` | 1277 |
| `/qr/([^/]+)` | `server/app.py` | 1217 |
| `/submit` | `server/app.py` | 1287 |
| `/submit` | `server/app.py` | 1994 |
| `/subscribe` | `server/app.py` | 1279 |
| `/subscribe` | `server/app.py` | 1967 |
| `/ticket-file/(` | `server/app.py` | 952 |
| `/vcard/([^/]+)$` | `server/app.py` | 1236 |

## ۵) ابزارها و آزمون‌ها (tools/)

| ابزار | نقش |
|---|---|
| `routemap.py` | ⭐ همین نقشهٔ مسیرها را می‌سازد (بعد از هر مسیر تازه اجرا کنید) |
| `build_filemap.py` | این سند را می‌سازد |
| `design_audit.py` | ممیزی جامع طراحی: ۹۴ صفحه × ۷ عرض، شات + متریک (tap/font/overflow/…) |
| `mobile_audit.py` | ممیزی موبایل (۴ دستگاه) |
| `contrast_audit.py` | کنتراست دو تم (AA) |
| `audit.py` | شکار کنترل‌های بی‌عمل (۴۶+ صفحه) |
| `navfit.py` | اندازه‌گیری سرریز هدر |
| `bench_load.py`, `bench_1000.py`, `bench_panel.py` | بار/کارایی (۵۰۰–۱۰۰۰ کاربر) |
| `test_*.py` (۴۰+ فایل) | باتری رگرسیون — فهرست کامل در `ARCHITECTURE.md` بخش ۷ |
| `seed_demo.py`, `reset_testdata.py` | دادهٔ نمونه / پاک‌سازی |
| `taxonomy.py`, `slice_taxonomy_icons.py` | درخت ۱۶۵ دسته و برش آیکون‌ها |
| `make_evidence*.py` | شواهد تصویری ممیزی (Playwright) |

## ۶) «برای تغییر X کجا بروم؟» — برگهٔ تقلب

| می‌خواهم… | برو به |
|---|---|
| متن/تایتل صفحه‌ای را عوض کنم | ویو همان مسیر (بخش ۱ یا جدول مسیرها) |
| رنگ/فونت/فاصله را عوض کنم | `site/assets/css/` — اول `tokens.css`، بعد `main.css`/`pages.css` |
| رفتار دکمه/فرم را عوض کنم | `site/assets/js/app.js` (یا فایل JS همان بخش) |
| مسیر جدید اضافه کنم | `server/app.py` → `route_get`/`route_post` + ویو مناسب |
| ستون/جدول جدید در دیتابیس | `server/db.py` → `SCHEMA` + `_reconcile_schema()` (مهاجرت خودکار) |
| سقف/قاعدهٔ امنیتی | `server/shield.py` + `db.rate_ok` + `SECURITY_HEADERS` در app.py |
| کش/سرعت | `server/pagecache.py` + بخش gzip/ETag در `app.py` |
| نسخهٔ assetها را بامپ کنم | `server/ui.py` (`?vNNN`) + `site/sw.js` (`VERSION`) + `tools/test_migration.py` |
| باگی در پنل مدیر | `views_panel.py` / `views_panel2.py` + `test_panel_*.py` |
| استقرار روی هاست | `DEPLOY.md` + `docs/HOSTING-v119.md` |
