#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Entry point for Hugging Face Spaces, Cloud PaaS, and Mobile Deployments.
Supports auto-extracting zip packages when uploaded directly from mobile devices.
"""
import os
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

def auto_extract_zip():
    """Auto-extracts any project zip file if running on a fresh host/Space."""
    if not os.path.isdir(os.path.join(HERE, "server")) or not os.path.isdir(os.path.join(HERE, "site")):
        for item in os.listdir(HERE):
            if item.endswith(".zip") and not item.startswith("."):
                zip_path = os.path.join(HERE, item)
                print(f"  ▸ استخراج خودکار پکیج زیپ موبایل: {item}...")
                try:
                    with zipfile.ZipFile(zip_path, "r") as zf:
                        zf.extractall(HERE)
                    print("  ✓ استخراج با موفقیت انجام شد.")
                    break
                except Exception as e:
                    print(f"  ✕ خطا در استخراج زیپ: {e}")

if __name__ == "__main__":
    auto_extract_zip()
    if "PORT" not in os.environ:
        os.environ["PORT"] = "7860"
    import run
    sys.exit(run.main())
