# -*- coding: utf-8 -*-
"""
Customer-facing pages: account (OTP), chat with shops, orders, favourites.
Standard library only — same constraints as the rest of the app.
"""

import json
import urllib.parse

import db
import views_chat as CH
from ui import (icon, stars, fa, fa_group, esc, page, breadcrumb, empty_state,
                section_head, stat_card, flash, json_embed, password_reminder)
from ui import jdate, jdatetime, jdatetime_ts


def _msg(q):
    if q.get("ok"):
        return flash("ok", q["ok"][0])
    if q.get("err"):
        return flash("err", q["err"][0])
    return ""


# ------------------------------------------------------------------ auth
def login(s, phone="", err="", code_stage=False, dev_code="", note="", nxt=""):
    cats = db.category_tree()
    if code_stage:
        form_html = f'''<form method="post" action="/me/login/verify" data-validate>
      <input type="hidden" name="phone" value="{esc(phone)}">
      <input type="hidden" name="next" value="{esc(nxt)}">
      <input type="hidden" name="favs" id="c-favs" value="">
      <div class="field"><label class="field-label" for="c-code">کد ورود</label>
        <input class="input nums" id="c-code" name="code" type="tel" dir="ltr" required
               inputmode="numeric" pattern="[0-9]{{5}}" maxlength="5" autocomplete="one-time-code"
               placeholder="•••••"></div>
      <button class="btn btn-primary btn-block" type="submit">
        {icon("check")}<span>ورود</span></button>
      <p class="field-hint" style="text-align:center;margin-top:10px">
        <a href="/me/login">شماره را اشتباه وارد کردم</a></p>
    </form>
    <script>
      try {{
        var favs = JSON.parse(localStorage.getItem('bazarche.v2.favs') || '[]');
        var f = document.getElementById('c-favs');
        if (f && Array.isArray(favs)) f.value = JSON.stringify(favs);
      }} catch (e) {{}}
    </script>'''
        dev_html = (f'<div class="alert alert-warn" style="text-align:center">{icon("eye")}'
                    f'<span>کد نمایشی (بدون پیامک): <strong class="nums" dir="ltr">{esc(dev_code)}</strong></span></div>'
                    if dev_code else '')
    else:
        form_html = f'''<form method="post" action="/me/login" data-validate>
      <input type="hidden" name="next" value="{esc(nxt)}">
      <div class="field"><label class="field-label" for="c-phone">شمارهٔ موبایل</label>
        <input class="input nums" id="c-phone" name="phone" type="tel" dir="ltr" required
               inputmode="numeric" pattern="0[0-9]{{10}}" maxlength="11"
               value="{esc(phone)}" placeholder="۰۹۱۲۳۴۵۶۷۸۹"></div>
      <button class="btn btn-primary btn-block" type="submit">
        {icon("send")}<span>دریافت کد ورود</span></button>
    </form>'''
        dev_html = ''
    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass">
    <div class="auth-head"><span class="mark">{icon("user")}</span>
      <h1>ورود مشتری</h1>
      <p>با شمارهٔ موبایل وارد شوید تا سفارش‌ها، گفتگوها و علاقه‌مندی‌هایتان
        روی همهٔ دستگاه‌ها بماند. رمز عبور لازم نیست.</p></div>
    {flash("err", err) if err else ''}
    {f'<div class="alert alert-success">{icon("check-circle")}<span>{esc(note)}</span></div>' if note else ''}
    {dev_html}
    {form_html}
    <hr class="divider">
    <details class="auth-alt">
      <summary class="btn btn-ghost btn-block">{icon("lock")}<span>ورود با نام کاربری و رمز عبور</span></summary>
      <form method="post" action="/me/login/password" data-validate class="mt-md">
        <input type="hidden" name="next" value="{esc(nxt)}">
        <div class="field">
          <label class="field-label" for="c-lu">نام کاربری</label>
          <input class="input" id="c-lu" name="username" dir="ltr" required autocomplete="username"
                 placeholder="نام کاربری شما">
        </div>
        <div class="field">
          <label class="field-label" for="c-lp">رمز عبور</label>
          <input class="input" id="c-lp" name="password" type="password" dir="ltr" required
                 autocomplete="current-password" placeholder="••••••">
        </div>
        <button class="btn btn-primary btn-block" type="submit" aria-label="ورود با رمز عبور">{icon("lock")}<span>ورود</span></button>
      </form>
    </details>
    <p class="field-hint" style="text-align:center;margin-top:12px">
      با ورود، <a href="/rules">قوانین</a> را می‌پذیرید.</p>
  </div></div></div>'''
    return page(s, "ورود مشتری", body, "", cats=cats)


# --------------------------------------------------- complete profile (v65)
def profile(s, cust, q=None, err=""):
    """Name is REQUIRED after first login; family name is optional."""
    q = q or {}
    cats = db.category_tree()
    name = cust.get("name") or ""
    family = cust.get("family") or ""
    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass">
    <div class="auth-head"><span class="mark">{icon("user")}</span>
      <h1>خوش آمدید — نام شما چیست؟</h1>
      <p>برای ادامه، نام خود را بنویسید. نام خانوادگی اختیاری است و
        شمارهٔ تلفن شما همیشه محرمانه می‌ماند.</p></div>
    {flash("err", err) if err else ""}
    <form method="post" action="/me/profile" data-validate>
      <div class="field"><label class="field-label" for="pf-n">نام<span class="req">*</span></label>
        <input class="input" id="pf-n" name="name" maxlength="60" required minlength="2"
               placeholder="مثلاً: علی" value="{esc(name)}"></div>
      <div class="field"><label class="field-label" for="pf-f">نام خانوادگی</label>
        <input class="input" id="pf-f" name="family" maxlength="60"
               placeholder="اختیاری — مثلاً: محمدی" value="{esc(family)}"></div>
      <button class="btn btn-primary btn-block" type="submit">
        {icon("check")}<span>ثبت و ادامه</span></button>
    </form>
  </div></div></div>'''
    return page(s, "تکمیل حساب", body, "", cats=cats)


# ------------------------------------------------------------------ dashboard
def dashboard(s, cust, q=None):
    q = q or {}
    cats = db.category_tree()
    orders = db.orders_for_customer(cust["id"])[:5]
    chats = db.chat_threads_for_customer(cust["id"])[:5]
    favs = db.fav_list(cust["id"])
    prices_on = s.get("prices_enabled") == "1"

    ord_html = "".join(f'''<a class="todo-item" href="/me/order/{o["id"]}">
      {icon("shopping")}<span><strong>{esc(o["bizname"])}</strong><br>
      <small class="text-muted">{f'{fa_group(o["total"])} تومان · ' if prices_on else ''}
        <span class="badge {db.ORDER_LABELS.get(o["status"], ("badge-neutral",""))[0]}">{esc(o["status_label"])}</span></small></span>
      {icon("chevron-left")}</a>''' for o in orders)
    if not ord_html:
        ord_html = empty_state("shopping", "هنوز سفارشی ندارید",
                               "از کاتالوگ محصولات، اولین سفارش خود را ثبت کنید.")

    chat_html = "".join(f'''<a class="todo-item" href="/me/chat/{t["id"]}">
      {icon("message")}<span><strong>{esc(t["bizname"])}</strong><br>
      <small class="text-muted">{esc((t.get("last") or {}).get("body", "")[:60])}</small></span>
      {icon("chevron-left")}</a>''' for t in chats)
    if not chat_html:
        chat_html = empty_state("message", "گفتگویی ندارید",
                                "از صفحهٔ هر کسب‌وکار می‌توانید گفتگو را شروع کنید.")

    body = f'''{_msg(q)}
{password_reminder("/me/account") if not db.customer_has_password(cust["id"]) else ""}
<div class="container-wide">
  {breadcrumb(("حساب من", None))}
  <header class="page-hero"><h1>سلام، {esc(cust["name"] or "مشتری عزیز")}</h1>
    <p>سفارش‌ها، گفتگوها و علاقه‌مندی‌های شما — همه در یک جا.</p></header>
  <div class="grid grid-3 mb-lg" data-stagger>
    {stat_card("shopping", len(db.orders_for_customer(cust["id"])), "سفارش")}
    {stat_card("message", len(db.chat_threads_for_customer(cust["id"])), "گفتگو", delay=60)}
    {stat_card("heart", len(favs), "علاقه‌مندی", delay=120)}
  </div>
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-md">{icon("user")} همهٔ بخش‌های پنل من</h2>
    <p class="text-sm text-muted mb-md">حساب شخصی شما — جدا از پنل دکان.</p>
    <div class="quick-grid">
      <a class="quick-tile" href="/me/profile">{icon("user")}<span>پروفایل</span><small>نام و تصویر شما</small></a>
      <a class="quick-tile" href="/me/orders">{icon("cart")}<span>سفارش‌های من</span><small>خریدهایی که ثبت کرده‌اید</small></a>
      <a class="quick-tile" href="/me/chats">{icon("message")}<span>گفت‌وگوهای من</span><small>پیام به دکان‌ها</small></a>
      <a class="quick-tile" href="/me/favorites">{icon("heart")}<span>علاقه‌مندی‌ها</span><small>دکان‌های نشان‌شده</small></a>
      <a class="quick-tile" href="/me/following">{icon("users")}<span>دنبال‌شده‌ها</span><small>اخبار دکان‌ها</small></a>
      <a class="quick-tile" href="/me/notifications">{icon("bell")}<span>اعلان‌ها</span><small>هشدارها و تخفیف‌ها</small></a>
      <a class="quick-tile" href="/me/account">{icon("lock")}<span>حساب و امنیت</span><small>نام کاربری و رمز</small></a>
    </div>
  </div>
  <div class="grid grid-2" style="align-items:start">
    <div class="card glass card-pad">
      <div class="between mb-md"><h2 class="card-title">{icon("shopping")} آخرین سفارش‌ها</h2>
        <a class="btn btn-ghost btn-sm" href="/me/orders">همه</a></div>
      {ord_html}
    </div>
    <div class="card glass card-pad">
      <div class="between mb-md"><h2 class="card-title">{icon("message")} گفتگوها</h2>
        <a class="btn btn-ghost btn-sm" href="/me/chats">همه</a></div>
      {chat_html}
    </div>
  </div>
  <div class="card glass card-pad mt-lg">
    <div class="between">
      <div><h2 class="card-title">{icon("heart")} علاقه‌مندی‌ها</h2>
        <p class="text-sm text-muted">روی همهٔ دستگاه‌ها همگام می‌ماند.</p></div>
      <a class="btn btn-glass" href="/favorites">{icon("grid")}<span>مشاهده</span></a>
    </div>
  </div>
  <div class="card glass card-pad mt-lg">
    <h2 class="card-title mb-md">{icon("user")} نام و نام خانوادگی</h2>
    <form method="post" action="/me/name" class="grid grid-2" style="gap:var(--space-md)">
      <div class="field"><label class="field-label" for="nm">نام<span class="req">*</span></label>
        <input class="input" id="nm" name="name" maxlength="60" required minlength="2"
               placeholder="نام شما" value="{esc(cust.get('name') or '')}"></div>
      <div class="field"><label class="field-label" for="fm">نام خانوادگی</label>
        <input class="input" id="fm" name="family" maxlength="60"
               placeholder="اختیاری" value="{esc(cust.get('family') or '')}"></div>
      <div class="cluster" style="grid-column:1/-1">
        <button class="btn btn-glass" type="submit">{icon("check")}<span>ذخیره</span></button>
      </div>
    </form>
  </div>
  <div class="cluster mt-lg" style="justify-content:center">
    <form method="post" action="/me/logout" style="display:inline">
      <button class="btn btn-ghost" type="submit">{icon("x")}<span>خروج</span></button>
    </form>
  </div>
</div>'''
    return page(s, "حساب من", body, "", cats=cats)


# ------------------------------------------------------------------ chat
def chats_list(s, cust, q=None):
    cats = db.category_tree()
    rows = db.chat_threads_for_customer(cust["id"])
    items = CH.thread_list(
        rows, "customer", "/me/chat",
        empty_title="گفتگویی ندارید",
        empty_text="از صفحهٔ هر کسب‌وکار می‌توانید گفتگو را شروع کنید.")
    unread = db.chat_unread_customer(cust["id"])
    body = f'''{_msg(q or {})}<div class="container-wide chat-inbox-page">
  {breadcrumb(("حساب من", "/me"), ("گفت‌وگوها", None))}
  {CH.conversations_tabs("customer", "chats", counts={"chats": unread})}
  <div class="chat-inbox-card">{items}</div>
</div>'''
    return page(s, "گفت‌وگوها", body, "", cats=cats)


def chat_view(s, cust, tid, q=None):
    thread = db.chat_thread(tid)
    if not thread or thread.get("customer_id") != cust["id"]:
        return None
    biz = db.business(bid=thread["biz_id"]) or {}
    cats = db.category_tree()
    messages = db.chat_messages(tid)
    room = CH.chat_room(
        thread, messages, "customer",
        biz.get("name", "کسب‌وکار"),
        "گفتگوی مستقیم؛ مدیر دستگیر در صورت نیاز امکان نظارت دارد.",
        f"/me/chat/{tid}", "/me/chats", status=thread.get("status", "open"))
    body = f'''{_msg(q or {})}<div class="container-wide chat-page">
  {breadcrumb(("حساب من", "/me"), ("گفتگوها", "/me/chats"), ("گفتگو", None))}
  {room}
</div>
<script type="module" src="/assets/js/chat.js?v109"></script>'''
    return page(s, "گفتگو", body, "", cats=cats)


# ------------------------------------------------------------------ orders
def orders_list(s, cust, q=None):
    cats = db.category_tree()
    rows = db.orders_for_customer(cust["id"])
    prices_on = s.get("prices_enabled") == "1"
    items = "".join(f'''<a class="todo-item" href="/me/order/{o["id"]}">
      {icon("shopping")}<span><strong>{esc(o["bizname"])}</strong><br>
      <small class="text-muted">{f'{fa_group(o["total"])} تومان · ' if prices_on else ''}
      {esc(jdatetime(o["created"]))}</small></span>
      <span class="badge {db.ORDER_LABELS.get(o["status"], ("badge-neutral",""))[0]}">{esc(o["status_label"])}</span>
      {icon("chevron-left")}</a>''' for o in rows)
    if not items:
        items = empty_state("shopping", "هنوز سفارشی ندارید",
                            "از کاتالوگ محصولات، اولین سفارش خود را ثبت کنید.")
    body = f'''{_msg(q or {})}<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("سفارش‌ها", None))}
  <header class="page-hero"><h1>سفارش‌های من</h1><p>پیگیری وضعیت همهٔ سفارش‌ها.</p></header>
  <div class="card glass card-pad"><div class="todo-list">{items}</div></div>
</div>'''
    return page(s, "سفارش‌های من", body, "", cats=cats)


def order_view(s, cust, oid, q=None):
    o = db.order(oid)
    if not o or o.get("customer_id") != cust["id"]:
        return None
    biz = db.business(bid=o["biz_id"]) or {}
    cats = db.category_tree()
    rows = db.order_items(oid)
    prices_on = s.get("prices_enabled") == "1"
    if prices_on:
        items = "".join(f'''<tr><td>{esc(r["title"])}</td>
          <td class="nums">{fa_group(r["price"])} × {fa(r["qty"])}</td>
          <td class="nums">{fa_group(r["price"] * r["qty"])}</td></tr>''' for r in rows)
        item_head = "<tr><th>عنوان</th><th>قیمت</th><th>جمع</th></tr>"
        item_foot = (f'<tr><th colspan="2">مجموع</th><td class="nums">'
                     f'<strong>{fa_group(o["total"])}</strong></td></tr>')
    else:
        items = "".join(f'''<tr><td>{esc(r["title"])}</td>
          <td class="nums">{fa(r["qty"])} عدد</td></tr>''' for r in rows)
        item_head = "<tr><th>عنوان</th><th>تعداد</th></tr>"
        item_foot = ""
    badge = db.ORDER_LABELS.get(o["status"], ("badge-neutral", o["status"]))
    cancel_box=""
    if o.get("cancel_requested"):
        cancel_box=f'<div class="alert alert-warn mt-lg">{icon("clock")}<span>درخواست لغو برای دکان‌دار ارسال شده و منتظر تصمیم اوست.</span></div>'
    elif o.get("status") not in ("done","cancelled"):
        cancel_box=f'''<form class="card glass card-pad mt-lg" method="post" action="/me/order/{oid}/cancel" data-confirm="درخواست لغو ثبت شود؟">
          <h2 class="card-title mb-md">{icon("x-circle")} لغو سفارش</h2>
          <div class="field"><label class="field-label" for="cancel-reason">دلیل (اختیاری)</label><input class="input" id="cancel-reason" name="reason" maxlength="500"></div>
          <button class="btn btn-ghost" type="submit">ثبت لغو / درخواست لغو</button>
          <p class="field-hint">تا مهلت تعیین‌شده مستقیم لغو می‌شود؛ بعد از آن نیازمند تأیید دکان‌دار است.</p></form>'''
    body = f'''{_msg(q or {})}<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("سفارش‌ها", "/me/orders"), ("سفارش", None))}
  <header class="page-hero"><h1>سفارش #{fa(o["id"])} — {esc(biz.get("name", "کسب‌وکار"))}</h1>
    <div class="cluster mt-md">
      <span class="badge {badge[0]}">{esc(badge[1])}</span>
      <span class="badge badge-neutral">{esc(jdatetime(o["created"]))}</span>
    </div></header>
  <div class="grid grid-2" style="align-items:start">
    <div class="card glass card-pad">
      <h2 class="card-title mb-md">{icon("shopping")} اقلام</h2>
      <div class="table-wrap"><table class="table">
        <thead>{item_head}</thead><tbody>{items}</tbody>
        {f'<tfoot>{item_foot}</tfoot>' if item_foot else ''}
      </table></div>
    </div>
    <div class="card glass card-pad">
      <h2 class="card-title mb-md">{icon("cart")} مشخصات تحویل</h2>
      <p class="text-sm"><strong>نام:</strong> {esc(o["name"])}</p>
      <p class="text-sm"><strong>تلفن:</strong> {esc(o["phone"])}</p>
      <p class="text-sm"><strong>نشانی:</strong> {esc(o["address"] or "—")}</p>
      <p class="text-sm"><strong>یادداشت:</strong> {esc(o["note"] or "—")}</p>
    </div>
  </div>
  {cancel_box}
</div>'''
    return page(s, "سفارش", body, "", cats=cats)


# ------------------------------------------------------------------ server favourites
def favorites_server(s, cust):
    cats = db.category_tree()
    fav_ids = db.fav_list(cust["id"])
    rows = [b for b in db.businesses() if b["id"] in fav_ids]
    ci = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}
    from ui import biz_card
    cards = "".join(biz_card(b, ci, i * 50) for i, b in enumerate(rows))
    body = f'''<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("علاقه‌مندی‌ها", None))}
  <header class="page-hero"><h1>علاقه‌مندی‌های من</h1>
    <p>روی همهٔ دستگاه‌ها همگام می‌ماند.</p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div class="grid grid-3">{cards or empty_state("heart", "هنوز چیزی ذخیره نکرده‌اید",
    "روی نشان قلب در کارت هر کسب‌وکار بزنید تا اینجا ذخیره شود.")}</div>
</div></section>'''
    return page(s, "علاقه‌مندی‌های من", body, "", cats=cats)


# ------------------------------------------------------------------ order done
def order_done(s, oid):
    cats = db.category_tree()
    o = db.order(oid)
    body = f'''<div class="container-wide"><section class="section">
  {empty_state("check-circle", "سفارش شما ثبت شد",
    "کسب‌وکار به‌زودی با شما تماس می‌گیرد. وضعیت سفارش را از «حساب من → سفارش‌ها» دنبال کنید.",
    f'<div class="cluster" style="justify-content:center"><a class="btn btn-primary" href="/me/order/{oid}">{icon("shopping")}<span>مشاهدهٔ سفارش</span></a><a class="btn btn-glass" href="/catalog">{icon("grid")}<span>ادامهٔ خرید</span></a></div>')}
</section></div>''' if o else ''
    return page(s, "ثبت شد", body, "", cats=cats)


# ------------------------------------------------------------------ cart
def cart_page(s, token=""):
    cats = db.category_tree()
    body = f'''<div class="container-wide">
  {breadcrumb(("سبد خرید", None))}
  <header class="page-hero"><h1>سبد خرید</h1><p>اقلام انتخاب‌شده از کاتالوگ شهر.</p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div id="cart-root"></div>
</section>
<script type="module" src="/assets/js/cart.js?v109"></script>'''
    return page(s, "سبد خرید", body, "", token=token, cats=cats)


# ------------------------------------------------------------------ areas
def areas_page(s, token=""):
    cats = db.category_tree()
    rows = db.areas()
    tiles = "".join(f'''<a class="cat-tile tilt reveal-3d" data-tilt="7" data-delay="{i*40}"
      href="/area/{urllib.parse.quote(r['area'])}">
      <span class="sheen" aria-hidden="true"></span>
      <span class="art layer-2">{icon("pin")}</span>
      <span class="name layer-1">{esc(r['area'])}</span>
      <span class="count layer-1">{fa(r['c'])} کسب‌وکار</span></a>''' for i, r in enumerate(rows))
    body = f'''<div class="container-wide">
  {breadcrumb(("محله‌ها", None))}
  <header class="page-hero"><h1>محله‌های نجف‌آباد</h1>
    <p>کسب‌وکارها را محله‌به‌محله بگردید.</p></header></div>
<section class="section-sm"><div class="container-wide">
  <div class="cat-grid">{tiles or empty_state("pin", "هنوز محله‌ای ثبت نشده",
    "از پنل مدیریت، برای کسب‌وکارها «محله» تعیین کنید.")}</div>
</div></section>'''
    return page(s, "محله‌ها", body, "", token=token, cats=cats)


def area_page(s, area, token=""):
    cats = db.category_tree()
    rows = db.businesses_in_area(area)
    if not rows:
        return None
    ci = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}
    from ui import biz_card
    cards = "".join(biz_card(b, ci, i * 50) for i, b in enumerate(rows))
    body = f'''<div class="container-wide">
  {breadcrumb(("محله‌ها", "/areas"), (area, None))}
  <header class="page-hero"><h1>محلهٔ {esc(area)}</h1>
    <p>{fa(len(rows))} کسب‌وکار در این محله.</p></header></div>
<section class="section-sm"><div class="container-wide">
  <div class="grid grid-3">{cards}</div>
</div></section>'''
    return page(s, f"محلهٔ {area}", body, "", token=token, cats=cats)


# ------------------------------------------------------------------ notifications (v32)
NOTIF_ICON = {"order": "cart", "chat": "message", "reply": "message", "info": "bell"}
NOTIF_LABEL = {"order": "سفارش", "chat": "گفتگو", "reply": "پاسخ", "info": "اطلاعیه"}


def notifications_page(s, cust, q=None):
    q = q or {}
    cats = db.category_tree()
    rows = db.notifications(cust["id"])
    items = "".join(f'''<a class="todo-item {'is-unread' if not n['read'] else ''}"
      href="{esc(n['link'] or '/me')}">
      {icon(NOTIF_ICON.get(n['kind'], 'bell'))}
      <span><strong>{esc(NOTIF_LABEL.get(n['kind'], n['kind']))}</strong><br>
      <small class="text-muted">{esc(n['text'])}</small></span>
      <small class="text-muted nums">{esc(str(n['created'])[5:16])}</small>
      {icon('chevron-left')}</a>''' for n in rows)
    if not items:
        items = empty_state("bell", "اعلانی ندارید",
                            "پاسخ‌ها، وضعیت سفارش و پیام‌های جدید اینجا می‌آیند.")
    body = f'''{_msg(q)}
<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("اعلان‌ها", None))}
  <header class="page-hero notifications-hero"><h1>{icon("bell")} اعلان‌های من</h1>
    <form method="post" action="/me/notifications/read">
      <button class="btn btn-glass btn-sm" type="submit">{icon("check")}<span>خواندن همه</span></button>
    </form></header>
  <div class="card glass card-pad"><div class="todo-list">{items}</div></div>
</div>'''
    return page(s, "اعلان‌های من", body, "", cats=cats)


def following_page(s, cust, q=None):
    q = q or {}
    cats = db.category_tree()
    ids = db.following_ids(cust["id"])
    rows = [b for b in db.businesses() if b["id"] in ids]
    ci = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}
    from ui import biz_card
    cards = "".join(biz_card(b, ci, i * 50) for i, b in enumerate(rows))
    body = f'''{_msg(q)}
<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("دنبال‌شده‌ها", None))}
  <header class="page-hero"><h1>{icon("heart")} کسب‌وکارهایی که دنبال می‌کنم</h1>
    <p>تازه‌های این کسب‌وکارها را دنبال کنید.</p></header>
  <section class="section-sm"><div class="container-wide">
    <div class="grid grid-3">{cards or empty_state("heart", "هنوز کسی را دنبال نمی‌کنید",
      "از صفحهٔ هر کسب‌وکار دکمهٔ «دنبال کردن» را بزنید.")}</div>
  </div></section>
</div>'''
    return page(s, "دنبال‌شده‌ها", body, "", cats=cats)


# ------------------------------------------------------------------ account & security
def account(s, cust, q=None):
    """Set a username + password so the customer can sign in without SMS."""
    q = q or {}
    has_pw = db.customer_has_password(cust["id"])
    cur_user = (cust.get("username") or "")
    if has_pw:
        status = (f'<div class="alert alert-success mb-lg">{icon("check-circle")}'
                  f'<span>نام کاربری و رمز عبور فعال است.</span></div>')
    else:
        status = (f'<div class="alert alert-warn mb-lg">{icon("info")}'
                  f'<span>هنوز نام کاربری و رمز تعیین نکرده‌اید. اینجا تنظیمش کنید تا ورود بعدی بدون پیامک باشد.</span></div>')

    body = f'''{_msg(q)}{status}
<div class="container">
  {breadcrumb(("حساب و امنیت", None))}
  <div class="card glass card-pad">
    <h2 class="card-title mb-md">{icon("lock")} نام کاربری و رمز عبور</h2>
    <p class="text-sm text-muted mb-lg">با تعیین نام کاربری و رمز، ورود بعدی شما بدون پیامک انجام می‌شود.</p>
    <form method="post" action="/me/account" data-validate>
      <div class="field">
        <label class="field-label" for="c-ac-user">نام کاربری<span class="req">*</span></label>
        <input class="input" id="c-ac-user" name="username" dir="ltr" required
               autocomplete="username" maxlength="24" value="{esc(cur_user)}"
               placeholder="مثلاً maryam_1370" data-msg-pattern="۳ تا ۲۴ نویسه: حروف، عدد، _ . -">
        <p class="field-hint">۳ تا ۲۴ نویسه؛ حروف فارسی یا انگلیسی، عدد، خط تیره و نقطه. بدون فاصله.</p>
      </div>
      <div class="field">
        <label class="field-label" for="c-ac-pw">رمز عبور جدید<span class="req">*</span></label>
        <input class="input" id="c-ac-pw" name="password" type="password" dir="ltr" required
               autocomplete="new-password" minlength="6" maxlength="72"
               placeholder="دست‌کم ۶ نویسه">
      </div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیرهٔ نام کاربری و رمز</span></button>
    </form>
  </div>
</div>
<div class="card glass card-pad mt-lg">
  <h2 class="card-title mb-md">{icon("download")} داده‌های من</h2>
  <p class="text-sm text-muted mb-lg">همهٔ داده‌هایی که به حساب شما گره خورده است
  (پروفایل، سفارش‌ها، علاقه‌مندی‌ها، دنبال‌شده‌ها، هشدارها، گفت‌وگوها و اعلان‌ها)
  در یک فایل CSV قابل‌بازکردن در اکسل دریافت کنید.</p>
  <a class="btn btn-glass" href="/me/export" download>{icon("download")}<span>دریافت CSV</span></a>
</div>'''
    cats = db.category_tree()
    return page(s, "حساب و امنیت", body, "", cats=cats)
