# -*- coding: utf-8 -*-
"""v117/کارایی — کشِ TTL صفحات عمومی مهمان.

چرا: رندر صفحات داینامیک پایتونیِ CPU-بند است (GIL)؛ زیر رمبشِ هزار
کاربر، هر درخواست ~۷-۲۰ms رندر پشت قفل سرریال می‌شود (اندازه‌گیری:
p50 از ۱۸ms به ۱.۳s در ۶۴ هم‌زمانی). صفحات مهمانِ عمومی برای همهٔ
بازدیدکنندگان یکسان‌اند (توکن مهمان همیشه ''، هدر احراز سمت‌کلاینت)،
پس بدنهٔ HTML همان صفحه می‌تواند TTL کوتاه کش شود.

ایمنی:
  • آمار بازدید و کوکی‌ها در Handler.send ثبت می‌شوند، نه در بدنه —
    کشِ بدنه هیچ آماری را نمی‌بلعد.
  • هر POST کل کش را باطل می‌کند (ویرایش ادمین/کاربر فوراً دیده می‌شود).
  • سقف ۱۲۸ کلید؛ پر شد → پاک‌سازی کامل (ساده و بی‌نشتی).
"""
import threading
import time

_TTL = 8.0
_MAX = 128
_lock = threading.Lock()
_store = {}


def get(key):
    with _lock:
        v = _store.get(key)
        if not v:
            return None
        html, exp = v
        if time.time() > exp:
            _store.pop(key, None)
            return None
        return html


def put(key, html):
    with _lock:
        if len(_store) >= _MAX:
            _store.clear()
        _store[key] = (html, time.time() + _TTL)


def clear():
    with _lock:
        _store.clear()
