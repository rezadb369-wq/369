"""v115: offline city lookup for Iranian IPv4 addresses — stdlib only.

Data: server/geoip_ir.csv (start_int, end_int, region, city), extracted from
DB-IP's free "DB-IP City Lite" open database (CC-BY 4.0, db-ip.com) — Iranian
ranges only, 501 KB, no network call, works inside Pydroid. IP geolocation is
approximate by nature (ISP-level); the panel says so.

Lookup is a binary search over sorted, non-overlapping ranges plus a small
in-memory cache. Unknown / IPv6 / private addresses honestly return ("", "")
rather than a guess.
"""

import bisect
import csv
import os
import unicodedata

_DATA = None
_STARTS = None
_cache = {}

REGION_FA = {
    "Alborz": "البرز", "Alborz Province": "البرز",
    "Ardabil Province": "اردبیل", "Bushehr": "بوشهر",
    "Chaharmahal and Bakhtiari": "چهارمحال و بختیاری",
    "East Azerbaijan": "آذربایجان شرقی", "West Azerbaijan": "آذربایجان غربی",
    "Fars": "فارس", "Gilan Province": "گیلان", "Gīlān": "گیلان",
    "Golestan": "گلستان", "Hamadan Province": "همدان", "Hamadān": "همدان",
    "Hormozgan": "هرمزگان", "Ilam Province": "ایلام", "Isfahan": "اصفهان",
    "Kerman": "کرمان", "Kermanshah Province": "کرمانشاه",
    "Khuzestan": "خوزستان",
    "Kohgiluyeh and Boyer-Ahmad": "کهگیلویه و بویراحمد",
    "Kordestān": "کردستان", "Kurdistan Province": "کردستان",
    "Lorestan Province": "لرستان", "Markazi": "مرکزی",
    "Māzandarān": "مازندران", "North Khorasan": "خراسان شمالی",
    "Qazvin Province": "قزوین", "Qazvīn": "قزوین",
    "Qom": "قم", "Qom Province": "قم",
    "Razavi Khorasan": "خراسان رضوی",
    "South Khorasan Province": "خراسان جنوبی", "Semnan": "سمنان",
    "Sistan and Baluchestan": "سیستان و بلوچستان",
    "Tehran": "تهران", "Tehrān": "تهران",
    "Yazd": "یزد", "Yazd Province": "یزد", "Zanjan": "زنجان",
}

CITY_FA = {
    "Tehran": "تهران", "Tehrān": "تهران", "Shiraz": "شیراز",
    "Isfahan": "اصفهان", "Mashhad": "مشهد", "Tajrīsh": "تجریش",
    "Karaj": "کرج", "Qom": "قم", "Tabriz": "تبریز", "Ahvāz": "اهواز",
    "Rasht": "رشت", "Kerman": "کرمان", "Yazd": "یزد", "Sanandaj": "سنندج",
    "Bushehr": "بوشهر", "Gorgan": "گرگان", "Arak": "اراک",
    "Zahedan": "زاهدان", "Bandar Abbas": "بندرعباس", "Urmia": "ارومیه",
    "Qazvin": "قزوین", "Kermanshah": "کرمانشاه", "Zanjan": "زنجان",
    "Hamadan": "همدان", "Semnan": "سمنان", "Babol": "بابل",
    "Ardabil": "اردبیل", "Īlām": "ایلام", "Bojnourd": "بجنورد",
    "Khorramabad": "خرم‌آباد", "Rey": "ری", "Shahr-e Kord": "شهرکرد",
    "Sari": "ساری", "Najafābād": "نجف‌آباد", "Najafabad": "نجف‌آباد",
    "Eslāmābād": "اسلام‌آباد", "Vaḩīdīyeh": "وحیدیه", "Fardīs": "فردیس",
    "Qarchak": "قرچک", "Shahr-e Ṣadrā": "شهر صدرا", "Sīrjān": "سیرجان",
    "Bandar-e Emam Khomeyni": "بندر امام خمینی", "Ţorqabeh": "طرقبه",
    "Lamerd": "لامرد", "Varamin": "ورامین", "Varāmīn": "ورامین",
    "Khomeyni Shahr": "خمینی‌شهر", "Kāshān": "کاشان", "Kashan": "کاشان",
    "Dezful": "دزفول", "Borūjerd": "بروجرد", "Malāyer": "ملایر",
    "Sāveh": "ساوه", "Saveh": "ساوه", "Shāhīn Shahr": "شاهین‌شهر",
    "Islamshahr": "اسلامشهر", "Eslāmshahr": "اسلامشهر",
    "Pākdasht": "پاکدشت", "Shahrīār": "شهریار", "Shahriar": "شهریار",
    "Maragheh": "مراغه", "Marāgheh": "مراغه", "Khowy": "خوی", "Khoy": "خوی",
    "Zābol": "زابل", "Zabol": "زابل", "Gonbad-e Kāvūs": "گنبد کاووس",
    "Āmol": "آمل", "Amol": "آمل", "Sārī": "ساری",
}


# ---- v117/فاز۶: پوشش کامل‌تر شهرها -----------------------------------
# نام‌ها با کلید ASCII ساده نوشته می‌شوند؛ _fold اعراب‌های ترانویسی
# (ā/ī/ū/ḩ/ţ/ş/…) را حذف می‌کند تا «Kermān» و «Kerman» یکی باشند.
CITY_FA.update({
    # مراکز استان و شهرهای بزرگ
    "Birjand": "بیرجند", "Yasuj": "یاسوج", "Kish": "کیش", "Qods": "قدس",
    "Pardis": "پردیس", "Jahrom": "جهرم", "Lahijan": "لاهیجان",
    "Piranshahr": "پیرانشهر", "Chabahar": "چابهار", "Abadeh": "آباده",
    "Bastak": "بستک", "Parand": "پرند", "Nowshahr": "نوشهر",
    "Mobarakeh": "مبارکه", "Chalus": "چالوس", "Kamalshahr": "کمالشهر",
    "Nazarabad": "نظرآباد", "Famenin": "فامینین", "Paveh": "پاوه",
    "Bumehen": "بومهن", "Sardrud": "سردرود", "Torbat-e Jam": "تربت جام",
    "Gachsaran": "گچساران", "Gerash": "گراش", "Lavasan": "لواسان",
    "Fulad Shahr": "فولادشهر", "Neka": "نکا", "Aleshtar": "الیشتر",
    "Borazjan": "برازجان", "Pishva": "پیشوا", "Fasa": "فسا",
    "Bafq": "بافق", "Zarqan": "زرقان", "Darab": "داراب",
    "Javanrud": "جوانرود", "Qeshm": "قشم", "Behshahr": "بهشهر",
    "Babolsar": "بابلسر", "Qaem Shahr": "قائم‌شهر",
    "Tonekabon": "تنکابن", "Eqlid": "اقلید", "Farrokh Shahr": "فرخشهر",
    "Shahreza": "شهرضا", "Chenaran": "چناران", "Konarak": "کنارک",
    "Iranshahr": "ایرانشهر", "Omidiyeh": "امیدیه", "Anar": "انار",
    "Firuzabad": "فیروزآباد", "Evaz": "اوز", "Khonj": "خنج",
    "Mehestan": "مهستان", "Qidar": "قیدار", "Nur": "نور",
    "Ahar": "اهر", "Bijar": "بیجار", "Bandar-e Asaluyeh": "بندر عسلیه",
    "Kashmar": "کاشمر", "Damghan": "دامغان", "Qorveh": "قروه",
    "Marvdasht": "مرودشت", "Abadan": "آبادان", "Buin Zahra": "بوئین‌زهرا",
    "Astaneh-ye Ashrafiyeh": "آستانه اشرفیه", "Langarud": "لنگرود",
    "Astara": "آستارا", "Harsin": "هرسین", "Golpayegan": "گلپایگان",
    "Zarrin Shahr": "زرین‌شهر", "Bam": "بم", "Quchan": "قوچان",
    "Hendijan": "هندیجان", "Zarand": "زرند", "Nasirshahr": "نصیرشهر",
    "Shushtar": "شوشتر", "Meybod": "میبد", "Eshtehard": "اشتهارد",
    "Rezvanshahr": "رضوانشهر", "Khomam": "خمام", "Osku": "اسکو",
    "Shabestar": "شبستر", "Eyvan": "ایوان", "Damavand": "دماوند",
    "Bostanabad": "بستان‌آباد", "Juybar": "جویبار", "Marand": "مرند",
    "Khalkhal": "خلخال", "Siakal": "سیاهکل", "Germi": "گرمی",
    "Nehbandan": "نهبندان", "Neyshabur": "نیشابور",
    "Torbat-e Heydariyeh": "تربت حیدریه", "Izeh": "ایذه",
    "Estahban": "استهبان", "Kord Kuy": "کردکوی", "Nasimshahr": "نسیمشهر",
    "Minab": "میناب", "Kordan": "کردان", "Razan": "رزن",
    "Mahabad": "مهاباد", "Khomeyn": "خمین", "Mahriz": "مهریز",
    "Shazand": "شازند", "Nain": "نائین", "Dorud": "دورود",
    "Khalilabad": "خلیل‌آباد", "Ajab Shir": "عجب‌شیر", "Mahan": "ماهان",
    "Namin": "نمین", "Kahnuj": "کهنوج", "Sardasht": "سردشت",
    "Khansar": "خوانسار", "Zarch": "زارچ", "Esfahanak": "اصفهانک",
    "Poldasht": "پلدشت", "Ferdows": "فردوس", "Tafresh": "تفرش",
    "Sarakhs": "سرخس", "Julfa": "جلفا", "Mianeh": "میانه",
    "Firuzkuh": "فیروزکوه", "Saqqez": "سقز", "Meshkin Shahr": "مشکین‌شهر",
    "Bukan": "بوکان", "Shut": "شوط", "Andimeshk": "اندیمشک",
    "Aligoodarz": "الیگودرز", "Jiroft": "جیرفت", "Semirum": "سمیرم",
    "Nurabad": "نورآباد", "Shahr-e Babak": "شهر بابک", "Tabas": "طبس",
    "Nikshahr": "نیک‌شهر", "Aran Bidgol": "آران و بیدگل",
    "Chadegan": "چادگان", "Poldokhtar": "پلدختر", "Sonqor": "سنقر",
    "Darreh Shahr": "دره‌شهر", "Baruq": "باروق", "Eyvanekey": "ایوانکی",
    "Khvaf": "خواف", "Bostan": "بوستان", "Shirvan": "شیروان",
    "Fuman": "فومن", "Sarab": "سراب", "Bonab": "بناب",
    "Mahdishahr": "ماهدیشهر", "Golestan": "گلستان", "Bastam": "بسطام",
    "Takestan": "تاکستان", "Abhar": "ابهر",
    "Dehdasht": "دهدشت", "Marivan": "مریوان", "Rudsar": "رودسر",
    "Salmanshahr": "سلمانشهر", "Khark": "خارک", "Takab": "تکاب",
    "Khavar Shahr": "خاورشهر", "Bandar-e Deyr": "بندر دیر",
    "Khorramshahr": "خرمشهر", "Shahrud": "شاهرود", "Malard": "ملارد",
    "Salmas": "سلماس", "Hashtgerd": "هشتگرد", "Rafsanjan": "رفسنجان",
    "Baharestan": "بهارستان", "Delijan": "دلیجان", "Mahdasht": "ماهدشت",
    "Kamard": "کمرد", "Farrashband": "فراشبند", "Safadasht": "صفادشت",
    "Bagershahr": "باقرشهر", "Bostanu": "بستانو", "Gilandeh": "گیلانده",
    "Jongiyeh": "جنگیه", "Sabzawar": "سبزوار", "Jam": "جام",
    "Kahrizak": "کهریزک", "Garmdarreh": "گرمدره",
    "Dastgerd": "دستگرد", "Pardisan": "پردیسان", "Kujuvar": "کوجووار",
    "Fereydun Kenar": "فریدون‌کنار", "Kelarabad": "کلارآباد",
    "Meshkin Dasht": "مشکین‌دشت", "Lali": "لالی", "Gav Khaneh": "گاوخانه",
    "Hasanabad": "حسن‌آباد", "Hajiabad": "حاجی‌آباد",
    "Aliabad-e Katul": "علی‌آباد کتول", "Soltanabad": "سلطان‌آباد",
    "Baghestan": "باغستان", "Vazvan": "وزوان", "Hashatjin": "هشترین",
    "Amir Kola": "امیرکلا", "Abbasabad": "عباس‌آباد",
    "Khur": "خور", "Bahregan": "بهرگان", "Azadi": "آزادی",
    "Kut-e Abdollah": "کوت عبدالله", "Eyn-e Do": "عین دو", "Qir": "قیر",
    "Chahar Dangeh": "چهار دانجه", "Sefidar": "سفیدار",
    "Qaleh-ye Khvajeh": "قلعه خواجه", "Khomeyn Shahr": "خمینی‌شهر",
    # کرج/تهران — شهرک‌ها و روستاهای پرتکرار
    "Suleqan": "سولقان", "Deh-e Torkaman": "ده ترکمان",
    "Keshar-e Olya": "کشار علیا", "Shahrak-e Nahal Va Bazr": "شهرک نهال و بذر",
    "Shahrestanak": "شاهرستانک", "Shabankareh": "شبانکاره",
    "Morteza Gerd": "مرتضی گرد", "Vardij": "وردیج", "Kahriz": "کهریز",
    "Rehnan": "رهنان", "Bozveh": "بزوه",
    "Shadbad-e Mashayekh": "شادباد مشایخ", "Golestanak": "گلستانک",
    "Shahrak-e Goldasteh": "شهرک گلدسته", "Shahrak-e Alain": "شهرک علائین",
    "Shahrestan-e Bandar-e Mahshahr": "شهرستان بندر ماهشهر",
    "Ahmad Abad Mostufi": "احمدآباد مستوفی", "Tus-e Sofla": "توس سفلی",
    "Chehreh": "چهره", "Zargan-e Karaneh": "زرگان کرانه",
    "Rudehen": "رودهن", "Alvand": "الوند", "Khowrzuq": "خورزوق",
    "Shahre Jadide Andisheh": "شهر جدید اندیشه",
    "Firuzbahram": "فیروزبهرام", "Eshkavand": "اشکاوند",
    "Salehieh": "صالحیه", "Bandar-e Anzali": "بندر انزلی",
    "Mahajeran": "مهاجران", "Shapur Jan": "شاپورجان",
    "Daghagheleh": "دغاغله", "Sedeh Lanjan": "سده لنجان",
    "Qaemiyeh": "قائمیه", "Karkaj": "کرکج", "Abali": "آبعلی",
    "Sharifabad": "شریف‌آباد", "Khatunabad": "خاتون‌آباد",
    "Bandar-e Torkaman": "بندر ترکمن", "Mahmudabad": "محمودآباد",
    "Saidabad": "سعیدآباد", "Namileh": "نامیله", "Baravat": "براوت",
    "Moghan": "مغان", "Nurai-ye Now": "نورایی نو",
    "Haftshuyeh": "هفتشویه", "Bandar-e Mahshahr": "بندر ماهشهر",
    "Minushahr": "مینوشهر", "Shahr-e Jadid-e Lar": "شهر جدید لار",
    "Three Castles": "سه قلعه",
    "Sabbashahr": "صباشهر", "Qiamdasht": "قیامدشت", "Hashtpar": "هشتپر",
    "Hendudar": "هندودر", "Chamgordan": "چامگردان",
    "Shahr-e Khezr": "شهر خضر", "Deh Pahn": "ده پهن",
    "Ramsheh": "رامشه", "Sarbandan": "سربندان",
    "Vazirabad": "وزیرآباد", "Qom Tappeh": "قم تپه",
    "Hoseynabad": "حسین‌آباد", "Tazehabad": "تازه‌آباد",
    "Khoshk Bijar": "خشکبیجار", "Jafariyeh": "جعفریه",
    "Delvar": "دلوار", "Banaruyeh": "بنارویه", "Galedar": "گله‌دار",
    "Galleh Dar": "گله‌دار", "Karkevand": "کرکوند",
    "Shahrak-e Azadi": "شهرک آزادی", "Eslamshahr": "اسلامشهر",
    "Qeshlaq-e Pain": "قشلاق پایین", "Zenivand": "زنیوند",
    "Shorudan": "شورودان", "Lalan": "لالان", "Khvachekin": "خواچکین",
    "Dorcheh Piaz": "درچه پیاز", "Kiashahr": "کیاشهر",
    "Golzar-e Bala": "گلزار بالا", "Dehram": "دهرم", "Fishvar": "فیشور",
    "Jalalabad": "جلال‌آباد", "Baziar Kola": "بازیار کلا",
    "Bala Afrakoti": "بالا آفراکتی", "Shahedshahr": "شاهدشهر",
    "Chaykhansar": "چایخانسر", "Goldasht": "گلدشت",
    "Moshkenan": "مشکنان", "Kalleh Bast": "کله بست",
    "Ebrahimabad": "ابراهیم‌آباد", "Kesheh": "کشه", "Karaj": "کرج",
})


def _fold(c):
    """'Shahrestān-e …' → 'shahrestan-e …' — اعراب‌های ترانویسی حذف می‌شوند
    تا یک کلید ASCII ساده با همهٔ واریانت‌های دیاکریتیک مچ شود."""
    c = c[:c.find(" (")] if " (" in c else c
    c = unicodedata.normalize("NFD", c)
    c = "".join(ch for ch in c if unicodedata.category(ch) != "Mn")
    return "".join(ch for ch in c.lower() if ch not in "'\u2019\u2018").strip()


_CITY_KEYS = {_fold(k): v for k, v in CITY_FA.items()}


def _norm_city(c):
    """'Tehran (District 6)' -> 'Tehran'; keeps base name mappings working."""
    i = c.find(" (")
    return c[:i] if i > 0 else c


def _load():
    global _DATA, _STARTS
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "geoip_ir.csv")
    rows = []
    try:
        with open(path, newline="") as f:
            for r in csv.reader(f):
                if len(r) >= 4:
                    rows.append((int(r[0]), int(r[1]), r[2], r[3]))
    except OSError:
        rows = []
    rows.sort()
    _DATA = rows
    _STARTS = [r[0] for r in rows]


def _ip2int(ip):
    parts = ip.split(".")
    if len(parts) != 4:
        return None                       # IPv6 or garbage — honest empty
    n = 0
    for p in parts:
        if not p.isdigit():
            return None
        v = int(p)
        if v > 255:
            return None
        n = n * 256 + v
    return n


def lookup(ip):
    """(province_fa, city_fa) for an IPv4 string.

    Returns ("", "") for anything not found — never a fabricated city.
    """
    if not ip:
        return ("", "")
    hit = _cache.get(ip)
    if hit is not None:
        return hit
    n = _ip2int(ip)
    if n is None:
        return ("", "")
    if _DATA is None:
        _load()
    if not _DATA:
        return ("", "")
    i = bisect.bisect_right(_STARTS, n) - 1
    if i < 0:
        return ("", "")
    s, e, reg, city = _DATA[i]
    if n > e:                             # fell in a gap between ranges
        return ("", "")
    prov = REGION_FA.get(reg, reg)
    # v117/فاز۶: اگر نام فارسی شهر در نقشه نیست، خالیِ صادقانه برمی‌گردیم
    # (استان می‌ماند) — نام لاتین در گزارش فارسی فقط نویز است.
    out = (prov, _CITY_KEYS.get(_fold(city), ""))
    if len(_cache) < 8192:
        _cache[ip] = out
    return out
