# -*- coding: utf-8 -*-
"""
HTTP application for Bazarche Najafabad.
Standard library only — runs unmodified inside Pydroid 3.
"""

import os
import re
import io
import time
import gzip
import hashlib
import zipfile
import secrets
import sys
import json
import threading
import mimetypes
import posixpath
import html as _html
import urllib.parse
import pagecache
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
SITE = os.path.join(ROOT, "site")
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "tools"))

import db
import ui
import sms
import shield
import analytics
import uploads
import qr as qrlib
import features
import views_public as V
import views_panel as P
import views_owner as O
import views_catalog as C
import views_panel2 as P2
import views_public2 as V2
import views_customer as CU
import views_extra as VX

mimetypes.add_type("text/javascript", ".js")
mimetypes.add_type("text/javascript", ".mjs")
mimetypes.add_type("font/woff2", ".woff2")
mimetypes.add_type("image/svg+xml", ".svg")
mimetypes.add_type("application/manifest+json", ".webmanifest")

MAX_BODY = 4 * 1024 * 1024   # 4 MB cap on form posts

# ------------------------------------------------------------------ hygiene
# User-submitted text is capped at the application boundary so no single field
# can balloon the database. Numbers/JSON/structural keys are intentionally
# absent — they are validated elsewhere. HTML `maxlength` mirrors these.
FORM_LIMITS = {
    "name": 100, "title": 150, "descr": 2000, "body": 2000, "excerpt": 300,
    "address": 300, "phone": 20, "whatsapp": 20, "email": 120, "subject": 150,
    "tags": 200, "note": 500, "quote": 80, "budget": 60, "author": 60,
    "reporter": 80, "asker": 60, "reason": 40, "topic": 40, "code": 40,
    "brand": 60, "warranty": 60, "unit": 30, "duration": 30, "options": 120,
    "spec": 120, "weight": 60, "bulk_price": 40, "min_order": 40,
    "old_price": 20, "price": 20, "floor_price": 20, "percent": 6,
    "video": 200, "instagram": 120, "telegram": 120, "website": 120,
    "site_name": 60, "tagline": 120, "hero_title": 120, "hero_lead": 400,
    "hero_cta": 60, "footer_note": 160, "blurb": 200, "icon": 40,
    "parent": 40, "cat_to": 40, "term": 120, "ref": 60, "answer": 1000,
    "area": 100, "old": 100, "new": 100,
}


def clip_form(form):
    """Truncate every user text field to its limit, in place. Mutates the
    parse_qs result (lists of strings) before any handler reads it, so the
    cap holds for every endpoint at once."""
    for k, n in FORM_LIMITS.items():
        if k not in form:
            continue
        v = form[k]
        if isinstance(v, list):
            form[k] = [x[:n] for x in v if isinstance(x, str)]
        elif isinstance(v, str):
            form[k] = v[:n]


def is_spambot(form):
    """Honeypot: a hidden field that real humans never fill. Bots that autofill
    every input trip it, and we silently drop the submission."""
    hp = form_get(form, "website_hp", "").strip()
    return bool(hp)


# SQLite INTEGER is a signed 64-bit value; ids beyond this range raise
# OverflowError when bound, which used to surface as a 500 on crafted URLs
# (DoS by huge id). Clamp every parsed int to this range.
_SQLITE_MAX = 2**63 - 1
_SQLITE_MIN = -(2**63)


def safe_int(v, default=0):
    """Parse an int without ever raising — and clamp to the SQLite range so a
    crafted giant number can never overflow a bound parameter."""
    try:
        n = int(v)
    except (TypeError, ValueError):
        return default
    if n > _SQLITE_MAX:
        return _SQLITE_MAX
    if n < _SQLITE_MIN:
        return _SQLITE_MIN
    return n


def clamp_int(v, lo, hi, default=0):
    v = safe_int(v, default)
    return max(lo, min(hi, v))

# Security headers sent on every response. CSP is deliberately permissive
# about inline scripts/styles (the page injects the boot config and the
# owner-chosen theme CSS inline, and a few confirm() handlers are inline)
# but locks everything else to same-origin, with the map/image CDNs allowed.
# 'unsafe-inline' for scripts is the price of the zero-build architecture:
# six inline event handlers (auto-submit selects + confirm buttons) and the
# boot JSON live inside the generated HTML. Everything else is locked down,
# and all third-party code (Leaflet, fonts) is vendored locally, not a CDN.
# v66: connect-src narrowed to 'self' (no browser-side external calls),
# frame-src 'none' (no iframes), worker/media-src pinned.
SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-Frame-Options": "DENY",
    # v119: cross-origin isolation hardening — no other origin may open our
    # documents as a window (COOP) or embed/read our resources (CORP).
    "Cross-Origin-Opener-Policy": "same-origin",
    "Cross-Origin-Resource-Policy": "same-origin",
    "Permissions-Policy": "geolocation=(self), camera=(), microphone=(), payment=()",
    "Content-Security-Policy": (
        "default-src 'self'; "
        "img-src 'self' data: blob: https:; "  # blob: = client-side upload previews (v89)
        # v114: googletagmanager/google-analytics only ever load when the
        # owner has pasted a GA4 measurement id (ui.py injects the tag).
        "script-src 'self' 'unsafe-inline' https://unpkg.com https://maps.googleapis.com https://www.googletagmanager.com; "
        "style-src 'self' 'unsafe-inline' https://unpkg.com; "
        "font-src 'self'; "
        "connect-src 'self' https://www.google-analytics.com https://*.google-analytics.com https://*.analytics.google.com; "
        "frame-src 'none'; "
        "worker-src 'self'; "
        "media-src 'self' blob:; "
        "object-src 'none'; "
        "base-uri 'self'; "
        "form-action 'self'; "
        "frame-ancestors 'none'"
    ),
}

# --------------------------------------------------------------------------
# v66: on-the-fly gzip. zlib ships with the Python standard library, so this
# stays Pydroid-safe. Only text-like payloads are compressed, and only when
# the client advertises gzip; binaries (photos, video, fonts, the sprite)
# are already compressed formats and would only grow.
COMPRESSIBLE = ("text/html", "text/css", "text/plain", "text/xml",
                "text/javascript",          # py3.13 mimetypes maps .js here
                "application/javascript", "application/json",
                "application/manifest+json", "image/svg+xml",
                "application/xml")
MIN_COMPRESS = 860          # below this, gzip framing eats the savings


def _client_accepts_gzip(headers):
    enc = headers.get("Accept-Encoding", "")
    return "gzip" in enc.lower()


def _looks_like_ip(v):
    """v119: keep only plausible IP literals / CIDR in the panel allowlist
    (IPv4 or IPv6, with optional /prefix). Anything else is dropped."""
    import ipaddress as _ia
    try:
        if "/" in v:
            _ia.ip_network(v, strict=False)
        else:
            _ia.ip_address(v)
        return True
    except ValueError:
        return False


# In-memory cache of gzipped static bodies so the 2MB icon sprite is not
# recompressed on every hit. Keyed by (path, mtime, size); evicted when the
# file changes. Capped so a pathological assets dir cannot eat memory.
_GZ_CACHE = {}
_GZ_CACHE_MAX = 64


# ------------------------------------------------------------------ helpers
def form_get(form, key, default=""):
    v = form.get(key)
    if isinstance(v, list):
        return v[0] if v else default
    return v if v is not None else default


def checkbox(form, key):
    return 1 if form.get(key) else 0


def _token_eq(got, want):
    """Constant-time owner-key comparison.

    `==` on strings short-circuits on the first mismatched byte, which in
    theory leaks the key through request timing. compare_digest is constant
    time. The try/except keeps a malformed (non-ASCII) key from raising a 500
    — it is simply not the key.
    """
    if not want:
        return False
    try:
        return secrets.compare_digest(str(got), str(want))
    except TypeError:
        return False


def _safe_next(nxt):
    """A login `next` target must only ever be a same-site path.

    ONE shared rule for every login flow (audit F-014: the owner flow also
    rejected ``..`` and /panel|/admin while the customer /me/profile copy
    did not). Returns the target when safe, else None."""
    nxt = str(nxt or "")
    if not (nxt.startswith("/") and not nxt.startswith("//")):
        return None
    if "\\" in nxt or len(nxt) >= 300:
        return None
    if ".." in nxt.split("?")[0].split("/"):
        return None
    if posixpath.normpath(nxt.split("?")[0]).startswith(("/panel", "/admin")):
        return None
    return nxt


def build_hours(form):
    out = {}
    for k, _ in P.DAYS:
        if form.get(f"h_{k}_closed"):
            continue
        o = form_get(form, f"h_{k}_open")
        c = form_get(form, f"h_{k}_close")
        if o and c:
            out[k] = [[o, c]]
    return out


class App(BaseHTTPRequestHandler):
    server_version = "Bazarche/2.0"
    protocol_version = "HTTP/1.1"

    # -------------------------------------------------------------- output
    def send(self, body, code=200, ctype="text/html; charset=utf-8", headers=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        # v114: real-visit analytics — every rendered HTML page is one visit
        # row (IP + visitor cookie + device). Never allowed to break a page.
        if code == 200 and ctype.split(";")[0].strip().lower() == "text/html":
            try:
                analytics.track_page(self)
            except Exception:
                pass
        extra = dict(headers or {})
        # v117/M1: panel pages must never be indexed — belt (meta) and
        # suspenders (response header), for crawlers that skip robots.txt.
        if getattr(self, "_panel_noindex", False):
            extra.setdefault("X-Robots-Tag", "noindex, nofollow")
        # v116-audit: when we are behind an HTTPS-terminating proxy, pin the
        # domain to HTTPS for a year (HSTS). Only sent on https responses,
        # per spec — sending it over plain http must not happen.
        # v119: the same proxy signal also upgrades every http:// asset URL
        # inside the page (upgrade-insecure-requests) — one less class of
        # mixed-content mistakes on production.
        shdrs = SECURITY_HEADERS
        if self.headers.get("X-Forwarded-Proto") == "https":
            extra.setdefault("Strict-Transport-Security",
                             "max-age=31536000; includeSubDomains")
            shdrs = dict(SECURITY_HEADERS)
            shdrs["Content-Security-Policy"] = (
                SECURITY_HEADERS["Content-Security-Policy"]
                + "; upgrade-insecure-requests")
        # gzip when the client accepts it and the payload is worth compressing.
        # Never double-compress: serve_static may hand us a body that is
        # already gzipped (its disk cache) with Content-Encoding pre-set —
        # compressing again is exactly what shipped broken CSS to Chrome.
        base_type = ctype.split(";")[0].strip().lower()
        if (len(body) >= MIN_COMPRESS and base_type in COMPRESSIBLE
                and "Content-Encoding" not in extra
                and _client_accepts_gzip(self.headers)):
            body = gzip.compress(body, compresslevel=6)
            extra["Content-Encoding"] = "gzip"
            extra["Vary"] = "Accept-Encoding"
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in shdrs.items():
            self.send_header(k, v)
        for k, v in extra.items():
            self.send_header(k, v)
        for c in getattr(self, "_extra_cookies", []):
            self.send_header("Set-Cookie", c)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def redirect(self, location):
        """HTTP headers are latin-1 only, so percent-encode any Persian text
        (flash messages) before it ever reaches send_header()."""
        safe = urllib.parse.quote(location, safe="/?=&#%:+")
        self.send_response(303)
        self.send_header("Location", safe)
        self.send_header("Content-Length", "0")
        for c in getattr(self, "_extra_cookies", []):
            self.send_header("Set-Cookie", c)
        self.end_headers()

    def json_out(self, obj, code=200):
        self.send(json.dumps(obj, ensure_ascii=False),
                  code, "application/json; charset=utf-8")

    # -------------------------------------------------------------- static
    def serve_static(self, relpath):
        relpath = urllib.parse.unquote(relpath).lstrip("/")
        safe = posixpath.normpath(relpath)
        if safe.startswith("..") or safe.startswith("/"):
            return self.send("forbidden", 403, "text/plain; charset=utf-8")
        full = os.path.join(SITE, safe)
        if not os.path.isfile(full):
            return False
        st = os.stat(full)
        ctype, _ = mimetypes.guess_type(full)
        ctype = ctype or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript",
                                                  "application/json",
                                                  "application/manifest+json"):
            ctype += "; charset=utf-8"
        # ETag from mtime+size: lets no-cache assets revalidate with a cheap
        # 304 instead of re-downloading on every page view.
        etag = '"%s"' % hashlib.md5(
            f"{st.st_mtime_ns}-{st.st_size}".encode()).hexdigest()
        if self.headers.get("If-None-Match") == etag:
            self.send_response(304)
            for k, v in SECURITY_HEADERS.items():
                self.send_header(k, v)
            self.send_header("ETag", etag)
            self.end_headers()
            return True
        with open(full, "rb") as f:
            data = f.read()
        cache = "public, max-age=31536000, immutable" \
            if safe.startswith(("assets/fonts", "assets/vendor", "assets/img")) \
            else "no-cache"
        extra = {"Cache-Control": cache, "ETag": etag}
        # Pre-gzip big text assets once and serve the cached result — the
        # sprite/CSS would otherwise burn CPU compressing on every request.
        base_type = ctype.split(";")[0].strip().lower()
        if (len(data) >= MIN_COMPRESS and base_type in COMPRESSIBLE
                and _client_accepts_gzip(self.headers)):
            key = (full, st.st_mtime_ns, st.st_size)
            gz = _GZ_CACHE.get(key)
            if gz is None:
                gz = gzip.compress(data, compresslevel=6)
                if len(_GZ_CACHE) >= _GZ_CACHE_MAX:
                    _GZ_CACHE.clear()
                _GZ_CACHE[key] = gz
            data = gz
            extra["Content-Encoding"] = "gzip"
            extra["Vary"] = "Accept-Encoding"
        self.send(data, 200, ctype, extra)
        return True

    # -------------------------------------------------------------- cookies
    def cookies(self):
        raw = self.headers.get("Cookie") or ""
        out = {}
        for part in raw.split(";"):
            if "=" in part:
                k, v = part.split("=", 1)
                out[k.strip()] = urllib.parse.unquote(v.strip())
        return out

    # Versioned on purpose. A cookie is scoped to host+path, NOT to the program
    # that set it, so the prototype's "bz_sess" was still being presented to the
    # new server — pointing at a session row that no longer means anything.
    # Bumping the name makes every stale session invisible in one stroke, and
    # SESSION_COOKIE is the single place to bump it again if it ever recurs.
    SESSION_COOKIE = "bzv2_sess"
    LEGACY_COOKIES = ("bz_sess",)
    ADMIN_COOKIE = "bzv2_admin"
    CUSTOMER_COOKIE = "bzv2_cust"

    def set_cookie(self, name, value, days=30):
        self._extra_cookies = getattr(self, "_extra_cookies", [])
        exp = "" if days else "; Max-Age=0"
        if days:
            exp = f"; Max-Age={days * 86400}"
        # Behind HTTPS (directly or via a proxy that sets X-Forwarded-Proto)
        # mark the session cookie Secure so it never travels over plain HTTP.
        # (Security fix.)
        sec = "; Secure" if self.headers.get("X-Forwarded-Proto") == "https" else ""
        self._extra_cookies.append(
            f"{name}={urllib.parse.quote(value)}; Path=/; HttpOnly; SameSite=Lax{exp}{sec}")

    def site_origin(self, s=None):
        """Absolute origin for links that leave the page (QR, sitemap, share).

        Prefers the configured site_url so a printed QR keeps working after the
        site moves to a real domain. Falls back to the Host header — never to a
        hard-coded 127.0.0.1:8000, which is how a QR printed on a shop window
        ended up pointing at the port the prototype used.
        """
        s = s if s is not None else db.get_settings()
        cfg = (s.get("site_url") or "").strip().rstrip("/")
        if cfg:
            if not cfg.startswith(("http://", "https://")):
                cfg = "https://" + cfg
            return cfg
        host = (self.headers.get("Host", "") or "").strip()
        # Host is attacker-controllable; only accept a plausible hostname or
        # IP[:port]. Anything else (quotes, brackets, CR/LF, HTML) is dropped
        # so it cannot be reflected into sitemap.xml / QR / share links.
        # (Security fix.) Setting site_url is still the definitive control.
        if host and not re.fullmatch(r"[A-Za-z0-9.\-:\[\]]+(:\d{1,5})?", host):
            host = ""
        # When site_url is NOT configured, never trust an arbitrary remote
        # hostname for links that leave the page (QR/sitemap): a crafted Host
        # header would otherwise poison them. Only loopback/LAN hosts are
        # honoured in that state; everything else falls back to the bound
        # address. Once site_url is set, this branch is never reached.
        if host and not host.lower().split(":")[0].replace(".", "").isdigit():
            if not host.lower().startswith(("localhost", "127.", "10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.", "172.2", "172.30.", "172.31.", "::1")):
                host = ""
        if not host:
            host = f"127.0.0.1:{self.server.server_address[1]}"
        proto = "https" if self.headers.get("X-Forwarded-Proto") == "https" else "http"
        return f"{proto}://{host}"

    def current_owner(self):
        return db.session_owner(self.cookies().get(self.SESSION_COOKIE))

    def current_customer(self):
        return db.customer_session_get(self.cookies().get(self.CUSTOMER_COOKIE))

    # ------------------------------------------------ v69 unified auth ----
    # One door, two roles: the same OTP signs the visitor in as customer and
    # (when the phone owns or matches a business) as shopkeeper. Legacy
    # /me/login* routes alias into these so nothing external breaks.
    def _unified_issue(self, s, form):
        if is_spambot(form):
            return self.redirect("/login")
        # v77 (P0): سهمیهٔ OTP دیگر فقط بر اساس IP نیست. روی شبکه‌های موبایل
        # ایران (CGNAT) صدها کاربر یک IP مشترک دارند و سقف ۵-در-۱۵-دقیقه بر
        # اساس IP، همهٔ آن‌ها را قفل می‌کرد. حالا دو سطل جدا داریم:
        #   · سطل «شماره»: جلوی اسپمِ یک شماره را می‌گیرد (۵ در ۱۵ دقیقه).
        #   · سطل «IP»: سقف سبک‌تر (۲۰ در ۵ دقیقه) فقط برای جلوگیری از
        #     جاروی انبوه شماره‌های متفاوت از یک منبع.
        phone = db.norm_phone(form_get(form, "phone"))
        if db.valid_phone(phone) and \
                not db.rate_ok(f"otp:{phone}", limit=5, window=900, always=True):
            return self.send(O.login_unified(s, "phone",
                err="برای این شماره کد زیاد خواسته شد. کمی بعد دوباره تلاش کنید.",
                nxt=form_get(form, "next")))
        if not db.rate_ok(f"otpip:{self.client_key()}", limit=20, window=900, always=True):
            return self.send(O.login_unified(s, "phone",
                err="تعداد درخواست کد زیاد است. کمی بعد دوباره تلاش کنید.",
                nxt=form_get(form, "next")))
        if not db.valid_phone(phone):
            return self.send(O.login_unified(s, "phone",
                err="شمارهٔ موبایل معتبر نیست.", nxt=form_get(form, "next")))
        code, left, throttled = db.otp_issue(phone)
        delivered, note = sms.send_otp(s, phone, code)
        # v116-audit: the dev code used to be printed on the page for ANY
        # visitor when SMS was unconfigured — on a deployed box without
        # site_url that is full account takeover. Now it is shown only to
        # the machine itself (Pydroid/desktop owner), never over the wire.
        local_peer = (self.client_address[0] or "") in ("127.0.0.1", "::1")
        dev = (code if (local_peer and not delivered
                        and not (s.get("site_url") or "").strip()) else "")
        if (s.get("site_url") or "").strip() and not delivered:
            note = "سرویس پیامک در دسترس نیست. با مدیریت تماس بگیرید."
        if throttled:
            note = f"کد قبلی هنوز معتبر است ({int(left)} ثانیه)."
        return self.send(O.login_unified(s, "code", phone, note=note,
                                         dev_code=dev, nxt=form_get(form, "next")))

    def _unified_verify(self, s, form):
        phone = db.norm_phone(form_get(form, "phone"))
        nxt = form_get(form, "next")
        ok, msg = db.otp_check(phone, form_get(form, "code"))
        if not ok:
            return self.send(O.login_unified(s, "code", phone, err=msg, nxt=nxt))
        linked = 0
        owner_granted = False
        no_name = False
        if s.get("owner_login") == "1":
            owner = db.owner_by_phone(phone, create=True)
            if owner and owner.get("status") != "blocked":
                owner_granted = True
                self.set_cookie(self.SESSION_COOKIE, db.session_new(owner["id"]))
                linked = db.link_orphans_to_owner(owner["id"], phone)
        if s.get("shop_account") == "1":
            cust = db.customer_by_phone(phone, create=True)
            self.set_cookie(self.CUSTOMER_COOKIE,
                            db.customer_session_new(cust["id"]))
            favs = form.get("favs") or []
            if favs and isinstance(favs, list):
                try:
                    favs = json.loads(favs[0])
                except (TypeError, ValueError):
                    favs = []
            elif isinstance(favs, str):
                try:
                    favs = json.loads(favs)
                except (TypeError, ValueError):
                    favs = []
            db.fav_merge(cust["id"], favs)
            # shopkeepers get their name from the shop; don't bounce a
            # brand-new owner into the customer profile form on first login
            no_name = (not owner_granted) and not db.customer_has_name(cust["id"])
        if linked:
            return self.redirect("/my/businesses?ok=" + urllib.parse.quote(
                f"{linked} کسب‌وکار ثبت‌شده با این شماره به حساب شما متصل شد."))
        safe_nxt = _safe_next(nxt)
        if no_name:
            return self.redirect("/me/profile" + (
                ("?next=" + urllib.parse.quote(safe_nxt)) if safe_nxt else ""))
        if safe_nxt:
            return self.redirect(safe_nxt)
        return self.redirect("/my")

    def _unified_password(self, s, form):
        nxt = form_get(form, "next")
        if not db.rate_ok(f"pw:{self.client_key()}", limit=10, window=900, always=True):
            return self.send(O.login_unified(s, "password",
                err="تلاش‌های ورود زیاد است. ۱۵ دقیقه بعد دوباره امتحان کنید.", nxt=nxt))
        username = form_get(form, "username").strip()
        password = form_get(form, "password")
        owner = db.owner_by_username(username)
        if owner and db.owner_check_password(owner["id"], password):
            if owner.get("status") == "blocked":
                return self.send(O.login_unified(s, "password",
                    err="این حساب مسدود شده است.", nxt=nxt))
            self.set_cookie(self.SESSION_COOKIE, db.session_new(owner["id"]))
            if s.get("shop_account") == "1" and owner.get("phone"):
                cust = db.customer_by_phone(owner["phone"], create=True)
                self.set_cookie(self.CUSTOMER_COOKIE,
                                db.customer_session_new(cust["id"]))
            db.link_orphans_to_owner(owner["id"], owner.get("phone", ""))
            return self.redirect("/my")
        cust = db.customer_by_username(username)
        if cust and db.customer_check_password(cust["id"], password):
            if cust.get("status") == "blocked":
                return self.send(O.login_unified(s, "password",
                    err="این حساب مسدود شده است.", nxt=nxt))
            self.set_cookie(self.CUSTOMER_COOKIE,
                            db.customer_session_new(cust["id"]))
            if s.get("owner_login") == "1" and cust.get("phone"):
                ow = db.owner_by_phone(cust["phone"], create=True)
                if ow and ow.get("status") != "blocked":
                    self.set_cookie(self.SESSION_COOKIE, db.session_new(ow["id"]))
                    db.link_orphans_to_owner(ow["id"], cust["phone"])
            return self.redirect("/my")
        return self.send(O.login_unified(s, "password",
            err="نام کاربری یا رمز عبور درست نیست.", nxt=nxt))

    def clear_legacy_cookies(self):
        """Delete anything the older build left behind on this device.

        Without this the old cookie sits there forever: harmless to the server,
        but it is the reason a phone that ran the prototype kept behaving like
        it. Runs once per visit, costs nothing when there is nothing to clear.
        """
        have = self.cookies()
        for name in self.LEGACY_COOKIES:
            if name in have:
                self.set_cookie(name, "", days=0)

    def gate(self, biz_id, key, back):
        """Server-side enforcement. The blurred UI is a courtesy; this is the
        wall. Returns a redirect response when the shop lacks the feature."""
        if db.can(biz_id, key):
            return None
        label = db.FEATURE_LABELS.get(key, key)
        sep = "&" if "?" in back else "?"
        self.redirect(f"{back}{sep}err=" + urllib.parse.quote(
            f"«{label}» در پلن فعلی شما قفل است. برای باز کردن، پلن را ارتقا دهید."))
        return True

    def client_key(self):
        """Identity used for rate limiting.

        X-Forwarded-For is only honoured when the direct peer is a trusted
        proxy (loopback). A remote client can set XFF to any value, so
        trusting it unconditionally lets an attacker rotate the header and
        reset the rate-limit bucket on every request. (Security fix.)"""
        try:
            peer = str(self.client_address[0])
        except Exception:
            peer = "unknown"
        if peer in ("127.0.0.1", "::1", "localhost"):
            fwd = self.headers.get("X-Forwarded-For", "")
            if fwd:
                return fwd.split(",")[0].strip()[:45]
        return peer[:45]

    # -------------------------------------------------------------- auth
    def token_ok(self, q_or_form):
        want = db.owner_token()
        got = form_get(q_or_form, "key")
        return _token_eq(got, want)

    def admin_ok(self, q_or_form):
        """v117/M1: panel access = a valid admin session cookie (minted at
        key entry or password login), OR the legacy key-in-form path when no
        password is set. When a password IS set, the session cookie is the
        lock and forms no longer need to embed the raw key."""
        if not self._panel_ip_allowed():
            return False
        if db.admin_session_ok(self.cookies().get(self.ADMIN_COOKIE),
                               unlocked_only=db.owner_pass_set()):
            return True
        if not self.token_ok(q_or_form):
            return False
        return not db.owner_pass_set()

    # v119: optional panel IP allowlist (defense-in-depth, not the only gate).
    # Empty = everyone (normal). When set (comma/newline separated), only
    # those IPv4/IPv6 reach the panel — the session cookie is still required.
    _PANEL_IP_CACHE = (None, 0.0)  # (allowlist, fetched_at)

    def _panel_ip_allowed(self):
        """Loopback is always allowed so the admin can never lock herself
        out from the server itself. Behind a proxy (X-Forwarded-Proto:
        https) the real client is the first X-Forwarded-For hop; the header
        is only trusted when the request actually arrived via the proxy."""
        now = time.time()
        allow, ts = self._PANEL_IP_CACHE
        if now - ts > 5.0:
            allow = (db.get_settings().get("panel_allow_ips") or "").strip()
            self._PANEL_IP_CACHE = (allow, now)
        if not allow:
            return True
        peer = self.client_address[0]
        if peer in ("127.0.0.1", "::1"):
            return True
        if (self.headers.get("X-Forwarded-Proto") == "https"
                and peer in ("127.0.0.1", "::1", "::ffff:127.0.0.1")):
            xff = self.headers.get("X-Forwarded-For", "")
            if xff:
                peer = xff.split(",")[0].strip()
        allowed = {a.strip() for a in allow.replace(";", ",").replace("\n", ",")
                   .split(",") if a.strip()}
        return peer in allowed

    def chat_role(self, thread, q_or_form=None, requested=""):
        """Resolve an authorized role for one conversation.

        Unified accounts may carry customer and owner cookies together, so a
        page can request its intended role. The role hint never bypasses the
        matching customer/ownership/admin checks.
        """
        if not thread:
            return None
        q_or_form = q_or_form or {}
        cust = self.current_customer()
        owner = self.current_owner()
        allowed = {
            "customer": bool(cust and thread.get("customer_id") == cust["id"]),
            "owner": bool(owner and db.owns(owner["id"], thread["biz_id"])),
            "admin": bool(self.admin_ok(q_or_form)),
        }
        if requested in allowed:
            return requested if allowed[requested] else None
        for role in ("admin", "owner", "customer"):
            if allowed[role]:
                return role
        return None

    def store_chat_message(self, thread, sender, body, files, settings):
        """Validate one optional private attachment and create one message."""
        candidates = [(fn, data) for field, fn, data in (files or [])
                      if field == "attachment" and data]
        if len(candidates) > 1:
            return None, "در هر پیام فقط یک فایل می‌توانید بفرستید."
        attachment = None
        if candidates:
            filename, blob = candidates[0]
            attachment, err = uploads.save_chat_file(blob, filename)
            if not attachment:
                return None, err or "فایل ذخیره نشد."
        mid = db.chat_send(thread["id"], sender, body, attachment=attachment)
        if not mid:
            if attachment:
                uploads.delete_chat_file(attachment["stored_name"])
            return None, "متن پیام یا فایل را وارد کنید."

        if sender in ("owner", "admin") and thread.get("customer_id") \
                and settings.get("notif_enabled") == "1":
            biz = db.business(bid=thread["biz_id"]) or {}
            who = ("مدیر دستگیر" if sender == "admin"
                   else f"«{biz.get('name', 'کسب‌وکار')}»")
            db.notify(thread["customer_id"], "chat", f"{who} به گفتگوی شما پاسخ داد.",
                      f"/me/chat/{thread['id']}")
        elif sender == "customer":
            biz = db.business(bid=thread["biz_id"]) or {}
            sms.notify_owner(settings, f"پیام تازه برای «{biz.get('name', 'کسب‌وکار')}»")
        db.log("chat.send", f"thread={thread['id']} sender={sender} file={1 if attachment else 0}")
        return mid, ""

    def _inline_edit(self, form):
        """Site-wide inline edit. Admin clicks text on any page -> saved here.
        Strict allow-list: only the named (type, field) pairs may change, so a
        crafted request can never write an arbitrary column."""
        typ = form_get(form, "type")
        fid = form_get(form, "id")
        field = form_get(form, "field")
        value = form_get(form, "value")
        BIZ = {"name", "descr", "address", "phone", "tags"}
        SET = {"hero_title", "hero_lead", "hero_cta", "site_name",
               "tagline", "description", "footer_note"}
        CAT = {"name", "blurb"}
        try:
            if typ == "business" and field in BIZ and fid.isdigit():
                db.save_business({field: value}, safe_int(fid))
            elif typ == "setting" and field in SET:
                db.set_setting(field, value)
            elif typ == "category" and field in CAT and fid.isdigit():
                db.save_category({field: value}, safe_int(fid))
            elif typ == "page" and fid in ("about", "rules") and field in ("body", "title"):
                p = db.get_page(fid)
                if field == "title":
                    db.save_page(fid, value, p["body"])
                else:
                    db.save_page(fid, p["title"], value)
            else:
                return {"ok": False, "error": "این بخش قابل ویرایش نیست"}
            db.log("inline.edit", f"{typ}:{fid}:{field}")
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)[:60]}

    # -------------------------------------------------------------- GET
    def prime_context(self, path, admin_token=""):
        """Tell ui.py who is signed in and which area this URL belongs to, so
        the header and the mobile menu can reflect it. Set once per request."""
        area = "public"
        if path == "/panel" or path.startswith("/panel/"):
            area = "panel"
        elif path == "/my" or path.startswith("/my/"):
            area = "my"
        elif path == "/me" or path.startswith("/me/"):
            area = "me"
        ui.set_context(self.current_owner(), area, admin_token,
                       customer=self.current_customer())

    def do_GET(self):
        try:
            # v112 abuse shield: storms/scanners answered before any work is done.
            sh = shield.check(self)
            if sh:
                self.send(f"<h1>{sh[1]}</h1>", sh[0])
                return
            # Hourly retention sweep so a long-lived server still purges
            # week-old chat images without needing a restart.
            if time.time() - _last_chat_gc > _CHAT_GC_EVERY:
                purge_expired_chat_images()
                db.trash_purge()   # v105: recycle-bin 7-day purge
                # v117/فاز۶: privacy retention must not depend on a restart
                db.retention_purge()
            self.route_get()
        except BrokenPipeError:
            pass
        except Exception as e:
            import traceback; traceback.print_exc()
            self.send(f"<h1>خطای داخلی سرور</h1><p>خطایی رخ داد. لطفاً کمی بعد دوباره تلاش کنید.</p>", 500)
        finally:
            # threads are reused, so a stale signed-in user must never leak
            # into the next request served by this thread
            ui.clear_context()
            db.request_done()   # v109: never idle-hold SQLite's writer lock

    def do_HEAD(self):
        self.do_GET()

    # صفحات عمومی مهمان که بدنه‌شان برای همه یکسان است (v117/کارایی)
    PAGECACHE_PATHS = frozenset((
        "/", "/businesses", "/catalog", "/deals", "/lists", "/events",
        "/cities", "/nearby", "/areas", "/blog", "/pricing", "/contact",
        "/about", "/rules", "/map"))
    # صفحات الگو-دار مهمان: صفحهٔ کسب‌وکار و کالا (توکن مهمان همیشه '' و
    # دکمه‌های حالت‌دار — دنبال/گفت‌وگو — سمت کلاینت رندر می‌شوند)
    PAGECACHE_RE = (re.compile(r"^/b/[^/]+$"), re.compile(r"^/item/\d+$"))

    def route_get(self):
        """v117/کارایی: پاسخ‌های HTML مهمانِ صفحه‌های پربازدید، TTL کوتاه
        کش می‌شوند (رندر پایتونیِ CPU-بند زیر رمبش سرریال می‌شد). هر POST
        کل کش را باطل می‌کند؛ آمار بازدید در send() ثبت می‌شود، نه بدنه."""
        parsed = urllib.parse.urlparse(self.path)
        path_only = parsed.path.rstrip("/") or "/"
        cacheable = (len(path_only) < 120 and "key" not in parsed.query
                     and "frag" not in parsed.query
                     and len(parsed.query) < 200
                     and (path_only in self.PAGECACHE_PATHS
                          or any(rx.match(path_only)
                                 for rx in self.PAGECACHE_RE)))
        if cacheable:
            # v117/رفع: صفحات عمومی برای کاربر واردشده «شخصی‌سازی» می‌شوند
            # (قلب علاقه‌مندی با aria-pressed سمت سرور رندر می‌شود — تست
            # favorites گرفت). کش فقط برای مهمانِ خالص: هیچ کوکی احرازی نباشد.
            _ck = self.cookies()
            if any(_ck.get(c) for c in (self.SESSION_COOKIE,
                                        self.CUSTOMER_COOKIE,
                                        self.ADMIN_COOKIE)):
                cacheable = False
        if cacheable:
            # اثرانگشت محتوا در کلید: نوشتن از «هر فرایندی» (پنل/تست/CLI)
            # کلید را تازه می‌کند — کشِ حافظه هرگز کهنه پاسخ نمی‌دهد.
            key = (db.page_fingerprint() + ":" + path_only
                   + ("?" + parsed.query if parsed.query else ""))
            # v119/سرعت: صفحه‌های مهمان کش‌پذیر، هدرهای کش مرورگر هم می‌گیرند
            # — ETag از اثرانگشت محتوا + max-age برابر TTL کش سرور (۸ ثانیه).
            # مرورگر پس از ۸ ثانیه با If-None-Match بازبینی می‌کند و اگر
            # محتوا عوض نشده باشد، ۳۰۴ بی‌بدنه می‌گیرد (بدون رندر/بدون بدنه).
            _etag = '"' + hashlib.sha1(key.encode("utf-8")).hexdigest()[:16] + '"'
            if self.headers.get("If-None-Match") == _etag:
                self.send_response(304)
                self.send_header("ETag", _etag)
                self.end_headers()
                return
            _browser_cc = {"Cache-Control": "public, max-age=8", "ETag": _etag}
            hit = pagecache.get(key)
            if hit is not None:
                # مسیر کش هم باید پاک‌سازی کوکی نسخهٔ قدیمی را انجام دهد
                # (تست isolation همین را می‌گیرد) — رندر خودش می‌کند.
                self.clear_legacy_cookies()
                return self.send(hit, headers=_browser_cc)
            orig_send = self.send

            def _send_store(body, code=200, *a, **kw):
                if (code == 200 and isinstance(body, str)
                        and "text/html" in (kw.get("ctype")
                                            or (a[0] if a else "text/html"))):
                    pagecache.put(key, body)
                if code == 200:
                    hdrs = dict(kw.get("headers") or {})
                    hdrs.setdefault("Cache-Control", "public, max-age=8")
                    hdrs.setdefault("ETag", _etag)
                    kw["headers"] = hdrs
                return orig_send(body, code, *a, **kw)

            self.send = _send_store
            try:
                return self._route_render()
            finally:
                self.send = orig_send
        return self._route_render()

    def _route_render(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        q = urllib.parse.parse_qs(parsed.query)
        s = db.get_settings()
        tok = db.owner_token()
        given = (q.get("key") or [""])[0]
        # v117/M1 (panel key leak fix): the raw owner key must live in the
        # URL only ONCE — at entry. A correct key mints a server-side admin
        # session (7-day cookie); every later panel request authenticates by
        # cookie, so internal links, Referer, history and page HTML never
        # carry the key again.
        owner = _token_eq(given, tok) or db.admin_session_ok(
            self.cookies().get(self.ADMIN_COOKIE))
        if _token_eq(given, tok) and not db.admin_session_ok(
                self.cookies().get(self.ADMIN_COOKIE)):
            # v117/M1: key-only sessions are marked locked — with a panel
            # password set they still face the password gate.
            self.set_cookie(self.ADMIN_COOKIE,
                            db.admin_session_new(locked=db.owner_pass_set()))
        # Public pages never receive the admin token — the admin UI lives only
        # inside /panel. This is what stops visitors from ever seeing an edit
        # bar or admin links on the site.
        vis_tok = ""
        self.prime_context(path, vis_tok)
        self.clear_legacy_cookies()

        # static assets
        if path.startswith("/assets/") or path in ("/favicon.ico", "/manifest.webmanifest",
                                                   "/sw.js", "/robots.txt", "/sitemap.xml",
                                                   "/offline.html", "/healthz",
                                                   "/.well-known/security.txt"):
            if path == "/favicon.ico":
                return self.redirect("/assets/img/favicon.svg")
            if path == "/robots.txt":
                # v113: private areas stay out of every index, and AI training
                # crawlers (the 2026 traffic storm) are told to stay off entirely.
                # Compliant bots obey this; the shield handles the rest.
                return self.send(
                    "User-agent: *\nAllow: /\nDisallow: /panel\nDisallow: /my\n"
                    "Disallow: /me\nDisallow: /chat-file/\n\n"
                    "User-agent: GPTBot\nUser-agent: ChatGPT-User\n"
                    "User-agent: CCBot\nUser-agent: Bytespider\n"
                    "User-agent: Amazonbot\nUser-agent: PerplexityBot\n"
                    "User-agent: Google-Extended\nUser-agent: Applebot-Extended\n"
                    "User-agent: anthropic-ai\nUser-agent: Claude-Web\n"
                    "Disallow: /\n",
                    200, "text/plain; charset=utf-8")
            if path == "/sitemap.xml":
                return self.sitemap(s)
            if path == "/healthz":
                # v119: zero-dependency uptime probe for the host's monitor
                # (uptime-kuma / cron). Cheap DB ping; text/plain so it never
                # touches analytics or the page cache.
                try:
                    db.get_settings()
                    body, code = "ok", 200
                except Exception:
                    body, code = "db error", 500
                return self.send(body, code, "text/plain; charset=utf-8",
                                 {"Cache-Control": "no-store"})
            if path == "/.well-known/security.txt":
                # v119: vulnerability disclosure contact (RFC 9116) — helps
                # good-faith researchers report issues to the site owner.
                email = (s.get("email") or "").strip()
                safe_email = _html.escape(email, quote=True).replace("%0d", "").replace("%0a", "")
                contact = f"mailto:{safe_email}" if email else "https://example.com/contact"
                _host_raw = (self.headers.get("Host") or "localhost").split(":")[0]
                host = re.sub(r"[^A-Za-z0-9.\-]", "", _host_raw)
                if not host:
                    host = "localhost"
                return self.send(
                    "Contact: " + contact + "\n"
                    "Expires: 2027-09-01T00:00:00Z\n"
                    "Preferred-Languages: fa, en\n"
                    "Policy: https://" + host + "/rules\n"
                    "Encryption: https://" + host + "\n",
                    200, "text/plain; charset=utf-8")
            if self.serve_static(path):
                return
            return self.send("not found", 404, "text/plain; charset=utf-8")

        # Private messenger files never live under /assets. Authorization is
        # checked before reading a single byte from disk.
        m = re.match(r"^/chat-file/(\d+)$", path)
        if m:
            attachment = db.chat_attachment(safe_int(m.group(1), 0))
            if not attachment:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            thread = db.chat_thread(attachment["thread_id"])
            requested = (q.get("as") or [""])[0]
            if not self.chat_role(thread, q, requested):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            data = uploads.read_chat_file(attachment["stored_name"])
            if data is None:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            disposition = "inline" if attachment.get("kind") == "image" else "attachment"
            safe_name = urllib.parse.quote(attachment.get("original_name") or "file")
            return self.send(data, 200, attachment.get("mime") or "application/octet-stream", {
                "Cache-Control": "private, no-store",
                "Content-Disposition": f"{disposition}; filename*=UTF-8''{safe_name}",
            })

        m = re.match(r"^/ticket-file/(\d+)$", path)
        if m:
            attachment = db.ticket_attachment(safe_int(m.group(1), 0))
            if not attachment:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            owner = self.current_owner()
            allowed = bool(owner and attachment.get("owner_id") == owner["id"]) or self.admin_ok(q)
            if not allowed:
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            data = uploads.read_chat_file(attachment["stored_name"])
            if data is None:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            disp = "inline" if attachment.get("kind") == "image" else "attachment"
            name = urllib.parse.quote(attachment.get("original_name") or "file")
            return self.send(data, 200, attachment.get("mime") or "application/octet-stream", {
                "Cache-Control":"private, no-store",
                "Content-Disposition":f"{disp}; filename*=UTF-8''{name}"})

        # maintenance gate
        if s.get("maintenance") == "1" and not owner and not path.startswith("/panel"):
            body = f'''<div class="container-wide"><section class="section">
              {ui.empty_state("settings","سایت در حال به‌روزرسانی است",
                "به‌زودی با امکانات تازه برمی‌گردیم. از شکیبایی شما سپاسگزاریم.")}
            </section></div>'''
            return self.send(ui.page(s, "به‌زودی", body, "", cats=[], show_chrome=False), 503)

        # ---------------- owner panel
        if path == "/panel" or path.startswith("/panel/"):
            self._panel_noindex = True   # v117/M1: header on every panel byte
            if not owner:
                return self.send(P.login_gate(s), 403)
            if db.owner_pass_set() and not db.admin_session_ok(
                    self.cookies().get(self.ADMIN_COOKIE), unlocked_only=True):
                return self.send(P.password_gate(s), 403)
            return self.panel_get(path, q, s, tok)

        # ---------------- owner area (business owners, cookie session)
        # /register and /signup were 404s left over from the static build;
        # registration IS login here, so alias them instead of dead-ending.
        if path in ("/login", "/register", "/signup", "/owner"):
            if self.current_owner() or self.current_customer():
                return self.redirect("/my")
            return self.send(O.login_unified(s, "phone", nxt=(q.get("next") or [""])[0]))
        # v100: anonymised story view stats — owner only, aggregate counts.
        m = re.match(r"^/my/story/(\d+)/views$", path)
        if m:
            me = self.current_owner()
            sid = safe_int(m.group(1))
            st = db._one("SELECT biz_id FROM stories WHERE id=?", (sid,)) if me else None
            if not me or not st or not db.owns(me["id"], st["biz_id"]):
                return self.json_out({"ok": False}, 403)
            out = db.story_view_stats(sid)
            out["ok"] = True
            return self.json_out(out)
        if path == "/my" or path.startswith("/my/"):
            me = self.current_owner()
            if not me:
                # Remember where they were headed instead of dumping them on
                # the dashboard after sign-in.
                return self.redirect("/login?next=" + urllib.parse.quote(path))
            return self.owner_get(path, q, s, me)

        # ---------------- customer area (OTP login, cookie session)
        if path == "/me/login":
            # v69: one door — the customer login page merged into /login
            nxt = (q.get("next") or [""])[0]
            return self.redirect("/login" + (("?" + "next=" + urllib.parse.quote(nxt)) if nxt else ""))
        if path == "/me" or path.startswith("/me/"):
            # v84: /me is the PERSONAL panel («پنل من») again — it no longer
            # bounces into the shop panel. A shopkeeper reaches the business
            # side via «پنل دکان» (/my); their personal account lives here.
            if s.get("shop_account") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            cust = self.current_customer()
            if not cust:
                return self.redirect("/login")
            return self.customer_get(path, q, s, cust)

        # ---------------- cart (client-side) + areas (public)
        if path == "/cart":
            if s.get("orders_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            return self.send(CU.cart_page(s, vis_tok))
        if path == "/areas":
            return self.send(CU.areas_page(s, vis_tok))
        if path == "/categories":
            return self.send(V.categories_page(s, vis_tok))
        if path == "/cities":
            return self.send(VX.cities_page(s, vis_tok))
        m = re.match(r"^/area/([^/]+)$", path)
        if m:
            html = CU.area_page(s, urllib.parse.unquote(m.group(1)), vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        if path == "/order/ok":
            _oid = (q.get("id") or ["0"])[0]
            return self.send(CU.order_done(s, safe_int(_oid, 0)))

        # ---------------- v31: top lists + flash deals + stories API
        if path == "/lists":
            if s.get("lists_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            return self.send(VX.lists_page(s, vis_tok))
        m = re.match(r"^/list/([^/]+)$", path)
        if m:
            if s.get("lists_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            html = VX.list_page(s, urllib.parse.unquote(m.group(1)), vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        if path == "/deals":
            if s.get("deals_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            return self.send(VX.deals_page(s, vis_tok))
        if path == "/api/stories":
            if s.get("stories_enabled") != "1":
                return self.json_out({"stories": []})
            rows = db.stories_active()
            return self.json_out({"stories": [
                {"id": r["id"], "image": r["image"], "kind": r.get("kind") or "image",
                 "caption": r.get("caption") or "", "duration": r.get("duration") or 0,
                 "bizname": r["bizname"], "bizslug": r["bizslug"]} for r in rows]})
        if path == "/api/live":
            # v120: بازبینی زندهٔ محتوا — کلاینت (live.js) هر چند ثانیه با
            # If-None-Match همین ETag را می‌پرسد؛ ۳۰۴ = هیچ تغییری (بدون بدنه)،
            # ۲۰۰ = ETag تازه → کلاینت صفحه را دوباره می‌گیرد و <main> را بدون
            # رفرش جابه‌جا می‌کند. ETag دقیقاً همان فرمول صفحات کش‌پذیر است
            # (اثرانگشت محتوا + مسیر) تا همیشه با هدر واقعی صفحه هم‌خانواده باشد.
            _lp = (q.get("p") or [""])[0]
            _lp_ok = (0 < len(_lp) < 120 and _lp.startswith("/")
                      and ".." not in _lp and not _lp.startswith("/api/")
                      and " " not in _lp and "\n" not in _lp and "\r" not in _lp)
            if not _lp_ok:
                return self.json_out({"error": "bad path"}, 400)
            _lk = db.page_fingerprint() + ":" + _lp
            _letag = '"' + hashlib.sha1(_lk.encode("utf-8")).hexdigest()[:16] + '"'
            if self.headers.get("If-None-Match") == _letag:
                self.send_response(304)
                self.send_header("ETag", _letag)
                self.end_headers()
                return
            return self.json_out({"etag": _letag})

        # ---------------- catalog
        m = re.match(r"^/item/(\d+)$", path)
        if m:
            html = C.item_detail(s, safe_int(m.group(1)), vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        if path == "/catalog":
            _ct = (q.get("q") or [""])[0]
            _kind = (q.get("kind") or [""])[0]
            _frag = "frag" in q
            if _ct.strip():
                db.log_search(_ct, "catalog",
                              len(db.search_items(_ct, _kind)))
            res = C.browse(s, _ct, _kind, vis_tok, frag=_frag)
            if _frag:
                return self.send(res.encode("utf-8") if isinstance(res, str) else res,
                                 200, "text/html; charset=utf-8",
                                 {"Cache-Control": "no-store"})
            return self.send(res)
        # v88: «گفتگو با دکان‌دار» — open (or reuse) the customer↔shop chat
        # thread and land in the messenger. Replaces the old anonymous
        # /ask inquiry, which the customer could never find again.
        m = re.match(r"^/b/([^/]+)/chat$", path)
        if m:
            if s.get("chat_enabled") != "1":
                return self.redirect(f"/b/{m.group(1)}")
            cust = self.current_customer()
            if not cust:
                return self.redirect("/me/login?next="
                                     + urllib.parse.quote(f"/b/{m.group(1)}/chat"))
            b = db.business(slug=m.group(1))
            if not b:
                return self.send(V.not_found(s, vis_tok), 404)
            tid = db.chat_start(b["id"], cust["id"], subject=f"گفتگو دربارهٔ {b['name']}")
            return self.redirect(f"/me/chat/{tid}")

        # ---------------- API
        m = re.match(r"^/api/chat/(\d+)/msgs$", path)
        if m:
            tid = safe_int(m.group(1))
            thread = db.chat_thread(tid)
            if not thread:
                return self.json_out({"ok": False}, 404)
            requested = (q.get("as") or [""])[0]
            role = self.chat_role(thread, q, requested)
            if not role:
                return self.json_out({"ok": False}, 403)
            after = safe_int((q.get("after") or ["0"])[0], 0)
            rows = db.chat_messages(tid, after=after)
            # File URLs contain only numeric attachment IDs. v117/M1: the
            # admin session cookie authenticates /chat-file now, so the raw
            # key no longer rides inside the JSON payload.
            for row in rows:
                aid = row.get("attachment_id")
                if aid:
                    row["file_url"] = f"/chat-file/{aid}?as=" + role
            db.chat_mark_read(tid, role)
            fresh = db.chat_thread(tid) or thread
            return self.json_out({
                "ok": True,
                "msgs": rows,
                "read": {k: int(fresh.get(f"{k}_read_to") or 0)
                         for k in ("customer", "owner", "admin")},
                "status": fresh.get("status", "open"),
            })

        if path == "/api/nearby":
            try:
                lat = float((q.get("lat") or ["0"])[0])
                lng = float((q.get("lng") or ["0"])[0])
                rad = float((q.get("r") or ["3"])[0])
            except ValueError:
                return self.json_out({"results": [], "error": "bad coords"}, 400)
            rad = max(0.2, min(50.0, rad))
            ci = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}
            rows = db.nearby(lat, lng, rad, (q.get("cat") or [""])[0],
                             (q.get("q") or [""])[0])
            return self.json_out({"results": [
                {"slug": b["slug"], "name": b["name"], "descr": b.get("descr") or "",
                 "address": b.get("address") or "", "distance_km": b["distance_km"],
                 "rating": b.get("rating") or 0, "nreviews": b.get("nreviews") or 0,
                 "icon": ci.get(b["cat_slug"], "store"),
                 "image": (b.get("images") or [""])[0]}
                for b in rows]})

        if path == "/api/businesses":
            rows = db.businesses()
            return self.json_out([{k: b[k] for k in
                                   ("slug","name","cat_slug","address","lat","lng",
                                    "featured","hours")} for b in rows])

        # ---- live search suggestions for the hero box (v50)
        if path == "/api/search":
            term = (q.get("q") or [""])[0].strip()
            out = []
            if term:
                # businesses + their trade name, capped and cheap
                for b in db.search(term=term)[:6]:
                    out.append({"kind": "biz", "slug": b["slug"], "name": b["name"],
                                "cat": (db.category(b["cat_slug"]) or {}).get("name", "")})
                # matching categories, so "کباب" also surfaces the trade itself
                for c in db.categories(only_active=True):
                    if term in (c["name"] or "") and len(out) < 8:
                        out.append({"kind": "cat", "slug": c["slug"], "name": c["name"], "cat": ""})
            return self.json_out({"results": out[:8]})

        # ---------------- public
        if path == "/":
            return self.send(V.home(s, vis_tok))
        if path == "/businesses":
            pg = (q.get("page") or ["1"])[0]
            term = (q.get("q") or [""])[0]
            city = (q.get("city") or [""])[0]
            if term.strip():
                # count it once, on the first page only, so paging through
                # results does not inflate the number
                if pg in ("", "1"):
                    n_hits = len(db.search(term=term, cat=(q.get("cat") or [""])[0], city=city))
                    db.log_search(term, (q.get("cat") or [""])[0], n_hits)
            _frag = (q.get("frag") or [""])[0] == "1"
            html = V.businesses(s, term,
                                (q.get("cat") or [""])[0],
                                (q.get("sort") or ["featured"])[0], vis_tok,
                                pg_no=int(pg) if pg.isdigit() else 1,
                                open_now=(q.get("open") or [""])[0] == "1",
                                city=city, frag=_frag)
            if _frag:
                # v120: fragment for the live directory search — never cached
                return self.send(html, ctype="text/html; charset=utf-8",
                                 headers={"Cache-Control": "no-store"})
            return self.send(html)
        if path.startswith("/b/"):
            html = V.business(s, path[3:], vis_tok, q)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        if path == "/map":
            return self.send(V.map_page(s, vis_tok))
        if path == "/blog":
            return self.send(V.blog(s, vis_tok))
        if path.startswith("/blog/"):
            html = V.blog_post(s, path[6:], vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        m = re.match(r"^/haggle/(\d+)$", path)
        if m:
            if s.get("prices_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            html = V2.haggle_form(s, safe_int(m.group(1)), vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        m = re.match(r"^/offer/([A-Za-z0-9_-]{6,64})$", path)
        if m:
            if s.get("prices_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            db.expire_haggles()
            html = V2.haggle_thread_page(s, m.group(1), vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        # ---- QR image for a shop, as SVG. A shopkeeper sticks this on the
        # window; research puts shop-window scan rates at 5-10% against
        # 1-3% for print advertising. SVG so it prints at any size.
        m = re.match(r"^/qr/([^/]+)\.svg$", path)
        if m:
            b = db.business(slug=urllib.parse.unquote(m.group(1)))
            if not b:
                return self.send(V.not_found(s, vis_tok), 404)
            url = f"{self.site_origin(s)}/b/{b['slug']}"
            try:
                size = int((q.get("size") or ["512"])[0])
            except Exception:
                size = 512
            size = max(128, min(2048, size))
            dl = (q.get("dl") or [""])[0] == "1"
            hdr = {}
            if dl:
                fn = re.sub(r"[^\w.-]", "_", b["slug"])[:40] or "qr"
                hdr["Content-Disposition"] = f'attachment; filename="{fn}-qr.svg"'
            return self.send(qrlib.svg(url, size=size), 200,
                             "image/svg+xml; charset=utf-8", hdr)

        m = re.match(r"^/vcard/([^/]+)$", path)
        if m:
            b = db.business(slug=urllib.parse.unquote(m.group(1)))
            if not b or b.get("status") != "published":
                return self.send(V.not_found(s, vis_tok), 404)
            db.track(b["id"], "vcard")
            fname = re.sub(r"[^\w.-]", "_", b["slug"])[:40] or "contact"
            return self.send(db.vcard(b), 200, "text/vcard; charset=utf-8",
                             {"Content-Disposition":
                              f'attachment; filename="{fname}.vcf"'})
        if path == "/prices":
            if s.get("prices_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            return self.send(V2.price_compare(
                s, (q.get("q") or [""])[0], (q.get("cat") or [""])[0],
                (q.get("key") or [""])[0], vis_tok))
        if path == "/compare":
            return self.send(V2.compare(s, q.get("b") or [], vis_tok))
        if path == "/nearby":
            if s.get("nearby_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            return self.send(V2.nearby_page(s, vis_tok))
        if path == "/events":
            if s.get("events_enabled") != "1":
                return self.send(V.not_found(s, vis_tok), 404)
            return self.send(V2.events(s, vis_tok))
        if path.startswith("/events/"):
            html = V2.event_detail(s, path[8:], vis_tok)
            return self.send(html) if html else self.send(V.not_found(s, vis_tok), 404)
        m = re.match(r"^/ad/(\d+)$", path)
        if m:
            a = db.ad_click(safe_int(m.group(1)))
            dest = (a or {}).get("url") or ""
            if not dest and a and a.get("biz_id"):
                b = db.business(a["biz_id"])
                if b and b.get("slug"):
                    dest = f"/b/{b['slug']}"
            if not dest:
                dest = "/"
            if dest.startswith("//") or not dest.startswith(("/", "http://", "https://")):
                dest = "/"
            return self.redirect(dest)
        if path == "/favorites":
            return self.send(V.favorites(s, vis_tok))
        if path == "/pricing":
            return self.send(V.pricing(s, vis_tok, q))
        if path == "/subscribe":
            if s.get("plans_enabled") != "1":
                return self.redirect("/pricing")
            html = V.subscribe(s, (q.get("plan") or [""])[0],
                               self.current_owner(), vis_tok, q)
            return self.send(html) if html else self.redirect("/pricing")
        if path == "/contact":
            return self.send(V.contact(s, vis_tok, sent=bool(q.get("sent"))))
        if path == "/submit":
            return self.send(V.submit(s, vis_tok, sent=bool(q.get("sent")),
                                      me=self.current_owner()))
        if path == "/features":
            return self.send(V2.features(s, vis_tok, self.current_owner()))
        if path in ("/about", "/rules"):
            return self.send(V.static_page(s, path[1:], vis_tok))

        return self.send(V.not_found(s, vis_tok), 404)

    # -------------------------------------------------------------- owner GET
    def owner_get(self, path, q, s, me):
        if path == "/my":
            return self.send(O.dashboard(s, me, q, cust=self.current_customer()))
        if path == "/my/chats":
            return self.send(O.owner_chats(s, me, q))
        m = re.match(r"^/my/chat/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1))
            thread = db.chat_thread(tid)
            if thread and db.owns(me["id"], thread["biz_id"]):
                db.chat_mark_read(tid, "owner")
            html = O.owner_chat_view(s, me, tid, q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        if path == "/my/orders":
            return self.send(O.owner_orders(s, me, q))
        if path == "/my/stories":
            return self.send(O.owner_stories(s, me, q))
        if path == "/my/trash":                       # v105: recycle bin
            return self.send(O.owner_trash(s, me, q))
        if path == "/my/businesses":
            return self.send(O.biz_list(s, me, q))
        if path == "/my/reviews":
            return self.send(O.reviews(s, me, q))
        if path == "/my/bookings":
            return self.send(O.bookings(s, me, q))
        if path == "/my/inquiries":
            return self.send(C.inquiry_list(s, me, q))
        if path == "/my/claim":
            return self.send(O.claim(s, me, q, (q.get("q") or [""])[0]))
        if path == "/my/questions":
            return self.send(O.questions(s, me, q))
        if path == "/my/offers":
            return self.send(O.offers(s, me, q))
        if path == "/my/tickets":
            return self.send(O.tickets(s, me, q))
        m = re.match(r"^/my/ticket/(\d+)$", path)
        if m:
            html = O.ticket_view(s, me, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        if path == "/my/plan":
            return self.send(O.plan_page(s, me, q))
        if path == "/my/account":
            return self.send(O.account(s, me, q))
        if path == "/my/export":
            # The `export` paid feature. Gate on the owner's shops: if none of
            # them holds it, bounce back with the reason rather than a file.
            mine = db.businesses_of(me["id"])
            if not mine:
                return self.redirect("/my/plan?err=" + urllib.parse.quote(
                    "ابتدا یک کسب‌وکار ثبت کنید."))
            if not any(db.can(b["id"], "export") for b in mine):
                return self.gate(mine[0]["id"], "export", "/my/plan") or \
                       self.redirect("/my/plan")
            kind = (q.get("kind") or ["customers"])[0]
            if kind not in ("customers", "bookings", "inquiries", "items"):
                kind = "customers"
            db.log("export.owner", f"owner {me['id']}: {kind}")
            return self.send(db.owner_export_csv(me["id"], kind), 200,
                             "text/csv; charset=utf-8",
                             {"Content-Disposition":
                              f'attachment; filename="bazarche-{kind}.csv"'})

        m = re.match(r"^/my/business/(\d+)$", path)
        if m:
            html = O.biz_edit(s, me, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        m = re.match(r"^/my/gallery/(\d+)$", path)
        if m:
            html = O.gallery(s, me, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        m = re.match(r"^/my/stats/(\d+)$", path)
        if m:
            html = O.stats(s, me, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        m = re.match(r"^/my/catalog/(\d+)$", path)
        if m:
            html = C.manage(s, me, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        m = re.match(r"^/my/catalog/(\d+)/item/(new|\d+)$", path)
        if m:
            iid = None if m.group(2) == "new" else safe_int(m.group(2))
            html = C.item_edit(s, me, safe_int(m.group(1)), iid, q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        return self.send(V.not_found(s), 404)

    # -------------------------------------------------------------- customer GET
    def customer_get(self, path, q, s, cust):
        if path == "/me":
            return self.send(CU.dashboard(s, cust, q))
        if path == "/me/profile":
            return self.send(CU.profile(s, cust, q))
        if path == "/me/chats":
            return self.send(CU.chats_list(s, cust, q))
        m = re.match(r"^/me/chat/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1))
            thread = db.chat_thread(tid)
            if thread and thread.get("customer_id") == cust["id"]:
                db.chat_mark_read(tid, "customer")
            html = CU.chat_view(s, cust, tid, q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        if path == "/me/orders":
            return self.send(CU.orders_list(s, cust, q))
        m = re.match(r"^/me/order/(\d+)$", path)
        if m:
            html = CU.order_view(s, cust, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 403)
        if path == "/me/favorites":
            return self.send(CU.favorites_server(s, cust))
        if path == "/me/account":
            return self.send(CU.account(s, cust, q))
        if path == "/me/export":          # v117/فاز۶: my data, portable
            return self.send(db.customer_export_csv(cust["id"]), 200,
                             "text/csv; charset=utf-8",
                             {"Content-Disposition":
                              'attachment; filename="my-data.csv"'})
        if path == "/me/notifications":
            return self.send(CU.notifications_page(s, cust, q))
        if path == "/me/following":
            return self.send(CU.following_page(s, cust, q))
        return self.send(V.not_found(s), 404)

    def sitemap(self, s):
        urls = ["/", "/businesses", "/map", "/blog",
                "/pricing", "/contact", "/about", "/rules",
                "/catalog", "/areas", "/nearby", "/events",
                "/lists", "/deals"]
        if s.get("prices_enabled") == "1":
            urls.append("/prices")
        urls += [f"/b/{b['slug']}" for b in db.businesses()]
        urls += [f"/blog/{p['slug']}" for p in db.posts()]
        urls += [f"/area/{urllib.parse.quote(a['area'])}" for a in db.areas()]
        urls += [f"/list/{t['slug']}" for t in db.toplists()]
        origin = self.site_origin(s)
        items = "".join(f"<url><loc>{origin}{u}</loc></url>" for u in urls)
        xml = ('<?xml version="1.0" encoding="UTF-8"?>'
               '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
               f"{items}</urlset>")
        self.send(xml, 200, "application/xml; charset=utf-8")

    # -------------------------------------------------------------- panel GET
    def panel_get(self, path, q, s, tok):
        if path == "/panel":
            return self.send(P.dashboard(s, tok, q))
        if path == "/panel/businesses":
            return self.send(P.biz_list(s, tok, q))
        if path == "/panel/business/new":
            return self.send(P.biz_edit(s, tok, None, q))
        m = re.match(r"^/panel/business/(\d+)$", path)
        if m:
            html = P.biz_edit(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        if path == "/panel/categories":
            return self.send(P.cat_list(s, tok, q))
        m = re.match(r"^/panel/category/(\d+)$", path)
        if m:
            html = P.cat_edit(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        if path == "/panel/reviews":
            return self.send(P.rev_list(s, tok, q))
        if path == "/panel/bookings":
            return self.send(P.book_list(s, tok, q))
        if path == "/panel/posts":
            return self.send(P.post_list(s, tok, q))
        if path == "/panel/messages":
            return self.send(P.msg_list(s, tok, q))
        if path == "/panel/pages":
            return self.send(P.pages_edit(s, tok, q))
        if path == "/panel/appearance":
            return self.send(P.appearance(s, tok, q))
        if path == "/panel/search":                # v117/M4
            return self.send(P2.panel_search(s, tok, q))
        if path == "/panel/settings":
            return self.send(P.settings_page(s, tok, q))
        if path == "/panel/owners":
            return self.send(P.owner_list(s, tok, q))
        if path == "/panel/claims":
            return self.send(P.claim_list(s, tok, q))
        if path == "/panel/inquiries":
            return self.send(C.inquiry_list(s, None, q, admin_token=tok))
        m = re.match(r"^/panel/gallery/(\d+)$", path)
        if m:
            html = O.gallery(s, None, safe_int(m.group(1)), q, admin_token=tok)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        m = re.match(r"^/panel/catalog/(\d+)$", path)
        if m:
            html = C.manage(s, None, safe_int(m.group(1)), q, admin_token=tok)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        m = re.match(r"^/panel/catalog/(\d+)/item/(new|\d+)$", path)
        if m:
            iid = None if m.group(2) == "new" else safe_int(m.group(2))
            html = C.item_edit(s, None, safe_int(m.group(1)), iid, q, admin_token=tok)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        # ---- v3 admin screens
        if path == "/panel/qa":
            return self.send(P2.qa_list(s, tok, q))
        if path == "/panel/reports":
            return self.send(P2.report_list(s, tok, q))
        if path == "/panel/trash":                     # v105: recycle bin (all)
            return self.send(P2.admin_trash(s, tok, q))
        if path == "/panel/traffic":                   # v112: abuse shield report
            return self.send(P2.admin_traffic(s, tok, q))
        if path == "/panel/analytics":                 # v114: real-visit analytics
            return self.send(P2.admin_analytics(s, tok, q))
        if path == "/panel/analytics/export":          # v115: CSV export (Excel-ready)
            import csv as _csv
            days = safe_int((q.get("days") or ["30"])[0]) or 30
            days = min(max(days, 1), 365)
            buf = io.StringIO()
            w = _csv.writer(buf)
            w.writerow(["ts_utc", "path", "kind", "biz_id", "item_id",
                        "story_id", "ip", "prov", "city", "device",
                        "visitor_id", "session_id", "referrer", "utm", "bot"])
            for r in db._rows(
                    "SELECT ts,path,kind,biz_id,item_id,story_id,ip,prov,city,"
                    "dev,cid,sid,ref,utm,bot FROM visits WHERE ts>=? "
                    "ORDER BY id DESC", (time.time() - days * 86400,)):
                w.writerow([time.strftime("%Y-%m-%d %H:%M:%S",
                                          time.gmtime(r["ts"])),
                            r["path"], r["kind"], r["biz_id"] or "",
                            r["item_id"] or "", r["story_id"] or "",
                            r["ip"], r["prov"], r["city"], r["dev"],
                            r["cid"], r["sid"], r["ref"], r["utm"], r["bot"]])
            body = "\ufeff" + buf.getvalue()           # BOM = Excel reads UTF-8
            return self.send(
                body, 200, "text/csv; charset=utf-8",
                {"Content-Disposition":
                 f'attachment; filename="bazarche-visits-{days}d.csv"'})
        if path == "/panel/badges":
            return self.send(P2.badge_list(s, tok, q))
        if path == "/panel/plans":
            return self.send(P2.plan_list(s, tok, q))
        if path == "/panel/subscriptions":
            return self.send(P2.sub_list(s, tok, q))
        if path == "/panel/ads":
            return self.send(P2.ad_list(s, tok, q))
        if path == "/panel/events":
            return self.send(P2.event_list(s, tok, q))
        if path == "/panel/edits":
            return self.send(P2.edit_list(s, tok, q))
        if path == "/panel/alerts":
            return self.send(P2.alert_list(s, tok, q))
        if path == "/panel/insights":
            return self.send(P2.insights(s, tok, q))
        if path == "/panel/inbox":
            return self.send(P2.inbox_page(s, tok, q))
        if path == "/panel/features":
            return self.send(P2.features_page(s, tok, q))
        if path == "/panel/tickets":
            return self.send(P2.ticket_list(s, tok, q))
        m = re.match(r"^/panel/ticket/(\d+)$", path)
        if m:
            html = P2.ticket_detail(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s), 404)
        if path == "/panel/unlocks":
            return self.send(P2.unlock_list(s, tok, q))

        # ---- v28: admin sees ALL chats and orders
        if path == "/panel/chats":
            return self.send(P2.admin_chats(s, tok, q))
        m = re.match(r"^/panel/chat/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1))
            if db.chat_thread(tid):
                db.chat_mark_read(tid, "admin")
            html = P2.admin_chat_view(s, tok, tid, q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        if path == "/panel/orders":
            return self.send(P2.admin_orders(s, tok, q))

        # ---- v31: top lists, deals, stories
        if path == "/panel/lists":
            return self.send(P2.admin_lists(s, tok, q))
        m = re.match(r"^/panel/list/(\d+)$", path)
        if m:
            html = P2.admin_list_edit(s, tok, safe_int(m.group(1)), q)
            return self.send(html) if html else self.send(V.not_found(s, tok), 404)
        if path == "/panel/deals":
            return self.send(P2.admin_deals(s, tok, q))
        if path == "/panel/stories":
            return self.send(P2.admin_stories(s, tok, q))

        # ---- v29: content editor, activity log, customers, areas
        if path == "/panel/editor":
            return self.send(P2.editor_page(s, tok, q))
        if path == "/panel/audit":
            return self.send(P2.audit_page(s, tok, q))
        if path == "/panel/audit/export":           # v117/M5: filterable CSV
            import csv as _csv5
            f_act = (q.get("action") or [""])[0].strip()[:40]
            f_det = (q.get("detail") or [""])[0].strip()[:60]
            try:
                f_days = min(730, max(0, int((q.get("days") or ["0"])[0])))
            except ValueError:
                f_days = 0
            buf = io.StringIO()
            buf.write("\ufeff")   # Excel reads the Persian text correctly
            w = _csv5.writer(buf)
            w.writerow(["id", "action", "detail", "created"])
            for r in db.audit_log(50000, action=f_act, detail=f_det, days=f_days):
                w.writerow([r["id"], r["action"], r["detail"],
                            str(r["created"])[:19]])
            return self.send(buf.getvalue(), 200, "text/csv; charset=utf-8",
                             {"Content-Disposition":
                              'attachment; filename="audit-log.csv"'})

        if path == "/panel/moderation":             # v117/M5: unified queue
            return self.send(P2.moderation_page(s, tok, q))
        if path == "/panel/customers":
            return self.send(P2.customers_page(s, tok, q))
        if path == "/panel/broadcast":
            return self.send(P2.broadcast_page(s, tok, q))
        if path == "/panel/follows":
            return self.send(P2.follows_page(s, tok, q))
        if path == "/panel/areas":
            return self.send(P2.areas_page(s, tok, q))
        if path == "/panel/demo":
            return self.send(P2.demo_page(s, tok, q))

        if path == "/panel/businesses/import":
            return self.send(P.csv_import(s, tok, q))
        if path == "/panel/businesses/export":
            return self.send(db.export_csv(), 200, "text/csv; charset=utf-8",
                             {"Content-Disposition":
                              'attachment; filename="bazarche-businesses.csv"'})
        if path == "/panel/backup":
            return self.send(P.backup_page(s, tok, q))
        if path == "/panel/backup/export":
            data = json.dumps(db.export_all(), ensure_ascii=False, indent=1)
            db.set_setting("last_backup_at", time.strftime("%Y-%m-%d %H:%M"))
            return self.send(data, 200, "application/json; charset=utf-8",
                             {"Content-Disposition":
                              'attachment; filename="bazarche-backup.json"'})
        if path == "/panel/backup/full":
            # JSON + every uploaded image, zipped — a complete, portable backup.
            import datetime as _dt
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                _backup_all = db.export_all()
                _backup_json = json.dumps(_backup_all, ensure_ascii=False,
                                          indent=1)
                z.writestr("backup.json", _backup_json)
                # v135: a manifest with sha256 so a downloaded backup can be
                # verified for corruption before anyone trusts it.
                z.writestr("manifest.json", json.dumps({
                    "created": _dt.datetime.now().isoformat(timespec="seconds"),
                    "sha256_backup_json":
                        hashlib.sha256(_backup_json.encode("utf-8")).hexdigest(),
                    "tables": len(_backup_all),
                }, ensure_ascii=False, indent=1))
                for f in uploads.list_files():
                    full = os.path.join(uploads.UPLOAD_DIR, f["name"])
                    try:
                        z.write(full, "uploads/" + f["name"])
                    except OSError:
                        continue
                # Private messenger bytes live outside the web root, but a
                # complete backup must travel with their SQLite metadata.
                for f in uploads.list_chat_files():
                    full = os.path.join(uploads.CHAT_UPLOAD_DIR, f["name"])
                    try:
                        z.write(full, "chat-files/" + f["name"])
                    except OSError:
                        continue
            db.set_setting("last_backup_at", time.strftime("%Y-%m-%d %H:%M"))
            stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M")
            return self.send(buf.getvalue(), 200, "application/zip",
                             {"Content-Disposition":
                              f'attachment; filename="bazarche-backup-{stamp}.zip"'})
        if path == "/panel/backup/db":
            # v134: a real, consistent snapshot of the SQLite database via
            # SQLite's online backup API (safe while the site is running — a
            # plain file copy of a WAL-mode DB can silently miss the newest
            # transactions). Restore: stop the service, drop this file into
            # data/ as bazarche.db, remove -wal/-shm, start the service.
            import sqlite3 as _sqlite3
            import tempfile as _tempfile
            import datetime as _dt
            tmpf = _tempfile.NamedTemporaryFile(suffix=".db", delete=False)
            tmpf.close()
            try:
                src = _sqlite3.connect(db.DB_PATH, timeout=15)
                dst = _sqlite3.connect(tmpf.name)
                try:
                    src.backup(dst)
                finally:
                    dst.close()
                    src.close()
                chk = _sqlite3.connect(f"file:{tmpf.name}?mode=ro", uri=True)
                try:
                    good = chk.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
                finally:
                    chk.close()
                if not good:
                    raise RuntimeError("integrity_check failed")
                with open(tmpf.name, "rb") as f:
                    raw = f.read()
            finally:
                try:
                    os.unlink(tmpf.name)
                except OSError:
                    pass
            db.set_setting("last_backup_at", time.strftime("%Y-%m-%d %H:%M"))
            stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M")
            return self.send(raw, 200, "application/x-sqlite3",
                             {"Content-Disposition":
                              f'attachment; filename="bazarche-db-{stamp}.db"'})
        if path == "/panel/media":
            return self.send(P2.media_page(s, tok, q))
        return self.send(V.not_found(s, tok), 404)

    # -------------------------------------------------------------- POST
    def do_POST(self):
        try:
            sh = shield.check(self)          # v112 abuse shield
            if sh:
                self.send(f"<h1>{sh[1]}</h1>", sh[0])
                return
            pagecache.clear()   # v117/کارایی: هر نوشتن، صفحات کش‌شده را تازه می‌کند
            self.route_post()
        except BrokenPipeError:
            pass
        except Exception as e:
            import traceback; traceback.print_exc()
            self.send(f"<h1>خطای داخلی سرور</h1><p>خطایی رخ داد. لطفاً کمی بعد دوبارم تلاش کنید.</p>", 500)
        finally:
            ui.clear_context()
            db.request_done()   # v109: never idle-hold SQLite's writer lock

    def read_form(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0 or n > MAX_BODY:
            return {}
        raw = self.rfile.read(n).decode("utf-8", "replace")
        return urllib.parse.parse_qs(raw, keep_blank_values=True)

    def read_multipart(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0 or n > uploads.MAX_BODY:
            return {}, []
        raw = self.rfile.read(n)
        return uploads.parse_multipart(raw, self.headers.get("Content-Type", ""))

    def route_post(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        s = db.get_settings()
        tok = db.owner_token()
        # v117/M1: the admin token never enters the ui context — panel
        # chrome authenticates by cookie and renders keyless links.
        self.prime_context(path, "")

        # ---- analytics beacon (no body, fire and forget)
        m = re.match(r"^/t/([^/]+)/(view|phone|whatsapp|route|share|catalog|save|instagram|telegram|website)$", path)
        if m:
            b = db.business(slug=m.group(1))
            if b:
                db.track(b["id"], m.group(2))
            return self.send(b"", 204, "text/plain")

        # ---- v100: record one anonymous story view (no identity stored, only a
        #      timestamp). Plain POST (not multipart) so it lives in route_post.
        m = re.match(r"^/api/stories/(\d+)/view$", path)
        if m:
            sid = safe_int(m.group(1))
            if db._one("SELECT 1 FROM stories WHERE id=?", (sid,)):
                db.story_view_add(sid)
                analytics.track_story(self, sid)   # v114: full identity
            return self.json_out({"ok": True})

        # ---- multipart endpoints (image uploads) handle their own body
        ctype = self.headers.get("Content-Type", "")
        if ctype.startswith("multipart/form-data"):
            return self.route_multipart(path, s, tok)

        form = self.read_form()
        clip_form(form)

        # ---------------- v69: legacy customer login aliases (one door now)
        if path == "/me/login":
            return self._unified_issue(s, form)

        if path == "/prices/alert":      # v68: torob-style price-drop alert
            if s.get("prices_enabled") != "1":
                return self.send(V.not_found(s), 404)
            cust = self.current_customer()
            if not cust:
                return self.redirect("/me/login")
            key = form_get(form, "key")
            if key:
                db.alert_set(cust["id"], key, form_get(form, "title"),
                             on=form_get(form, "on") == "1")
            return self.redirect("/prices?key=" + urllib.parse.quote(key))

        if path == "/me/login/verify":
            return self._unified_verify(s, form)

        # ---- v69 legacy alias
        # v77: بلاک مردهٔ «if False:» حذف شد — _unified_password خودش مسیر
        # بازگشت (next) را مدیریت می‌کند و این کد هرگز اجرا نمی‌شد.
        if path == "/me/login/password":
            return self._unified_password(s, form)

        if path == "/me/logout":
            db.customer_session_kill(self.cookies().get(self.CUSTOMER_COOKIE, ""))
            self.set_cookie(self.CUSTOMER_COOKIE, "", days=0)
            db.session_kill(self.cookies().get(self.SESSION_COOKIE, ""))
            self.set_cookie(self.SESSION_COOKIE, "", days=0)
            return self.redirect("/")

        # v65: complete profile — name is required, family name optional.
        if path == "/me/profile":
            cust = self.current_customer()
            if not cust:
                return self.redirect("/me/login")
            name = form_get(form, "name").strip()
            family = form_get(form, "family").strip()
            if len(name) < 2:
                return self.send(CU.profile(s, cust, err="نام را درست وارد کنید (دست‌کم ۲ نویسه)."))
            db.customer_set_profile(cust["id"], name, family)
            nxt = form_get(form, "next")
            safe_nxt = _safe_next(nxt)
            if safe_nxt:
                return self.redirect(safe_nxt)
            return self.redirect("/me?ok=حساب شما کامل شد.")

        if path == "/me/name":
            cust = self.current_customer()
            if cust:
                db.customer_set_profile(cust["id"], form_get(form, "name"),
                                        form_get(form, "family"))
                return self.redirect("/me?ok=نام ذخیره شد.")
            return self.redirect("/me/login")

        # ---- account & security: username + password (v57)
        if path == "/me/account":
            cust = self.current_customer()
            if not cust:
                return self.redirect("/me/login")
            ok, msg = db.customer_set_credentials(cust["id"], form_get(form, "username"),
                                                  form_get(form, "password"))
            key = "ok" if ok else "err"
            return self.redirect(f"/me/account?{key}={urllib.parse.quote(msg)}")

        # ---- favourite / unfavourite a business (v74, server-synced)
        if path == "/api/favorite":
            cust = self.current_customer()
            if not cust:
                return self.json_out({"ok": False, "error": "login"}, 403)
            slug = form_get(form, "slug").strip()
            bid = safe_int(form_get(form, "biz_id"), 0)
            business = db.business(slug=slug) if slug else (db.business(bid=bid) if bid else None)
            if not business or business.get("status") != "published":
                return self.json_out({"ok": False, "error": "not_found"}, 404)
            on = db.fav_toggle(cust["id"], business["id"])
            return self.json_out({
                "ok": True, "on": on, "slug": business["slug"],
                "count": len(db.fav_list(cust["id"])),
                "slugs": db.fav_slugs(cust["id"]),
            })

        # ---- follow / unfollow a business (v32, Instagram-style)
        if path == "/api/follow":
            cust = self.current_customer()
            if not cust or s.get("follow_enabled") != "1":
                return self.json_out({"ok": False, "error": "login"}, 403)
            bid = safe_int(form_get(form, "biz_id"), 0)
            if not db.business(bid=bid):
                return self.json_out({"ok": False}, 404)
            on = db.follow_toggle(cust["id"], bid)
            return self.json_out({"ok": True, "on": on, "count": db.follow_count(bid)})

        # ---- mark notifications read (v32)
        if path == "/me/notifications/read":
            cust = self.current_customer()
            if cust:
                db.notifications_mark_read(cust["id"])
            return self.redirect("/me/notifications")

        # ---- helpful vote on a review (v32)
        if path == "/api/review-helpful":
            rid = safe_int(form_get(form, "id"), 0)
            if not rid or not db.rate_ok(f"rh:{self.client_key()}", limit=40):
                return self.json_out({"ok": False}, 429)
            n = db.review_helpful(rid)
            return self.json_out({"ok": True, "helpful": n})

        # ---------------- orders (v28)
        if path == "/order/create":
            if s.get("orders_enabled") != "1":
                return self.redirect("/catalog")
            if s.get("prices_enabled") != "1":
                return self.redirect("/cart?err=" + urllib.parse.quote(
                    "قیمت‌ها فعلاً غیرفعال‌اند؛ ثبت سفارش آنلاین تا فعال‌شدن دوباره ممکن نیست."))
            if is_spambot(form):
                return self.redirect("/cart")
            if not db.rate_ok(f"ord:{self.client_key()}", limit=10, window=600):
                return self.redirect("/cart?err=" + urllib.parse.quote(
                    "تعداد سفارش‌ها زیاد است. کمی بعد دوباره تلاش کنید."))
            cust = self.current_customer()
            _bid = form_get(form, "biz_id")
            if not str(_bid).isdigit():
                return self.redirect("/cart?err=" + urllib.parse.quote("کسب‌وکار نامعتبر است."))
            biz_id = int(_bid)
            b = db.business(bid=biz_id)
            if not b:
                return self.redirect("/cart?err=" + urllib.parse.quote("کسب‌وکار نامعتبر است."))
            try:
                raw_items = json.loads(form_get(form, "items", "[]"))
            except Exception:
                raw_items = []
            # sanitize every field — crafted JSON must never raise or store junk
            items = []
            for i in raw_items:
                if not isinstance(i, dict) or not i.get("title"):
                    continue
                items.append({
                    "item_id": safe_int(i.get("item_id"), 0) or None,
                    "title": str(i.get("title"))[:150],
                    "price": clamp_int(i.get("price"), 0, 10**9, 0),
                    "qty": clamp_int(i.get("qty"), 1, 99, 1),
                })
            if not items:
                return self.redirect("/cart?err=" + urllib.parse.quote("سبد خرید خالی است."))
            # audit F-012: any row that references a REAL catalogue item of
            # this business is re-priced from the database — the cart's own
            # numbers are never trusted for catalogue rows.
            items = features.price_items_from_catalog(biz_id, items)
            name=form_get(form,"name").strip(); phone=form_get(form,"phone").strip()
            if len(name)<2:return self.redirect("/cart?err="+urllib.parse.quote("نام الزامی است."))
            if phone and not db.valid_phone(phone):return self.redirect("/cart?err="+urllib.parse.quote("شمارهٔ موبایل را درست وارد کنید یا خالی بگذارید."))
            oid = db.create_order(biz_id, cust["id"] if cust else None,
                                  name, phone, form_get(form, "address"), form_get(form, "note"), items,
                                  share_phone=checkbox(form,"share_phone") and bool(phone))
            # notify the customer their order was received
            if cust and s.get("notif_enabled") == "1":
                db.notify(cust["id"], "order",
                          f"سفارش #{oid} ثبت شد و به کسب‌وکار رسید.", f"/me/order/{oid}")
            if b.get("phone"):
                sms.notify(s, db.norm_phone(b["phone"]),
                           f"سفارش آنلاین جدید در {s.get('site_name')}")
            sms.notify_owner(s, f"سفارش آنلاین جدید برای «{b['name']}» "
                                f"({len(items)} قلم)")
            return self.redirect(f"/order/ok?id={oid}")

        m=re.match(r"^/me/order/(\d+)/cancel$",path)
        if m:
            cust=self.current_customer()
            if not cust:return self.redirect("/login")
            result=db.request_order_cancel(safe_int(m.group(1)),cust["id"],form_get(form,"reason"))
            msg=("سفارش لغو شد." if result.get("result")=="cancelled" else
                 "درخواست لغو برای دکان‌دار ارسال شد." if result.get("result")=="requested" else "لغو ممکن نیست.")
            return self.redirect(f"/me/order/{m.group(1)}?"+("ok=" if result.get("ok") else "err=")+urllib.parse.quote(msg))

        # ---------------- chat (v28) — the customer sends from the messenger
        m = re.match(r"^/me/chat/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1), 0)
            thread = db.chat_thread(tid)
            if not thread:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            if not self.chat_role(thread, form, "customer"):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            if not db.rate_ok(f"chat:customer:{self.client_key()}", limit=60, window=600):
                err = "تعداد پیام‌ها زیاد است. کمی بعد دوباره تلاش کنید."
            else:
                _mid, err = self.store_chat_message(
                    thread, "customer", form_get(form, "body"), [], s)
            if err:
                return self.redirect(f"/me/chat/{tid}?err=" + urllib.parse.quote(err))
            return self.redirect(f"/me/chat/{tid}?ok=" + urllib.parse.quote("پیام ارسال شد."))

        # ---- admin panel login (password) ----
        if path == "/panel/login":
            # Brute-force wall: the panel URL key already leaked publicly once,
            # so a password-guesser who holds the key must still be slowed to
            # a crawl. Cap attempts per client; a lockout message is returned
            # beyond the limit rather than a plain 403. (Security fix.)
            if not db.rate_ok(f"apl:{self.client_key()}", limit=10, window=900, always=True):
                return self.send(P.password_gate(s, err="تلاش‌های ورود زیاد است. ۱۵ دقیقه بعد دوباره امتحان کنید."), 429)
            pw = form_get(form, "password", "")
            nxt = form_get(form, "next", "")
            # v117/M1: the gate form never carried the key (it posts from a
            # key-protected page), so requiring token_ok(form) here made a
            # CORRECT password always fail — password login was dead in v116.
            # The password itself (PBKDF2-600k) + the 10/15min rate limit are
            # the proof; success mints the admin session.
            if db.owner_pass_set() and db.check_owner_pass(pw):
                self.set_cookie(self.ADMIN_COOKIE, db.admin_session_new())
                dest = nxt if (nxt.startswith("/panel") and not nxt.startswith("//")) \
                    else "/panel"
                return self.redirect(dest)
            return self.send(P.password_gate(s, err="رمز عبور درست نیست."), 403)

        if path == "/panel/logout":
            db.admin_session_kill(self.cookies().get(self.ADMIN_COOKIE))
            self.set_cookie(self.ADMIN_COOKIE, "", days=0)
            return self.redirect("/panel")

        # ---- admin inline edit (site-wide edit mode) ----
        if path == "/panel/inline-edit":
            if not self.admin_ok(form):
                return self.json_out({"ok": False, "error": "دسترسی ندارید"}, 403)
            return self.json_out(self._inline_edit(form))

        # ---------------- public posts
        # ---------------- owner OTP login
        if path == "/login":
            return self._unified_issue(s, form)

        if path == "/login/verify":
            return self._unified_verify(s, form)

        if path == "/login/password":
            return self._unified_password(s, form)

        # ---------------- contact the shopkeeper (v65: no phone required)
        if path == "/subscribe":
            # v139: one handler serves BOTH bodies — urlencoded, and multipart
            # when the buyer attaches a bank receipt image.
            return self.subscribe_post(s, form)
        if path == "/contact":
            # v76: support is accountable and two-way; the legacy one-way
            # contact inbox no longer accepts new support messages.
            return self.redirect("/my/tickets" if self.current_owner()
                                 else "/login?next=/my/tickets")

        if path == "/submit":
            if is_spambot(form):
                return self.redirect("/submit?sent=1")    # drop silently
            if s.get("reg_open") != "1":
                return self.redirect("/submit")
            # A shared connection (an office, a net cafe, a phone on carrier
            # NAT) can legitimately register several shops, so the cap is
            # generous; duplicate detection is what really stops abuse here.
            if not db.rate_ok(f"sub:{self.client_key()}", limit=12):
                return self.redirect("/submit?err="
                    + urllib.parse.quote("تعداد ثبت‌ها زیاد است. کمی بعد دوباره تلاش کنید."))

            name = form_get(form, "name")
            phone = form_get(form, "phone")
            addr = form_get(form, "address")

            # Refuse an exact duplicate outright — this is what caused people
            # to submit the same shop again and again.
            dups = db.find_duplicates(name=name, phone=phone, address=addr)
            exact = [d for d in dups if d["strength"] == "exact"]
            if exact and not form.get("confirm_dup"):
                me_now = self.current_owner()
                return self.send(V.submit(s, "", dups=exact, form=form, me=me_now))

            me = self.current_owner()
            data = {
                "name": name,
                "cat_slug": form_get(form, "cat_slug"),
                "descr": form_get(form, "descr"),
                "phone": phone,
                "whatsapp": form_get(form, "whatsapp"),
                "address": addr,
                "tags": form_get(form, "tags"),
                "area": form_get(form, "area"),
                "city": form_get(form, "city"),
                "province": form_get(form, "province"),
                "status": "pending",
            }
            # The optional block on /submit now offers everything the edit page
            # does, so it has to be SAVED here too — a field that renders but
            # never persists is worse than no field at all. Only non-empty
            # values are copied, so the three-field fast path is unchanged.
            for key in ("instagram", "telegram", "website"):
                val = form_get(form, key).strip()
                if val:
                    data[key] = val
            for key in ("lat", "lng"):
                raw = form_get(form, key).strip()
                if raw:
                    try:
                        # a shopkeeper may paste Persian digits from a map app
                        en = raw.translate(str.maketrans(
                            "۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
                        data[key] = float(en)
                    except (TypeError, ValueError):
                        pass          # a typo must not lose the registration
            hours = build_hours(form)
            if hours:
                data["hours"] = json.dumps(hours, ensure_ascii=False)
            # THE FIX: remember who submitted it, so it shows up in their panel
            if me:
                data["owner_id"] = me["id"]
            bid = db.save_business(data)
            db.log("business.submit", f"{bid} by {me['phone'] if me else 'guest'}")

            sms.notify_owner(s, f"کسب‌وکار جدید ثبت شد: «{data['name']}» — در انتظار تأیید شما.")
            if me:
                return self.redirect("/my/businesses?ok="
                    + urllib.parse.quote("ثبت شد و در انتظار تأیید مدیر است."))
            return self.redirect("/submit?sent=1")

        # ---- live duplicate check while the applicant types
        if path == "/api/check-duplicate":
            dups = db.find_duplicates(
                name=form_get(form, "name"), phone=form_get(form, "phone"),
                address=form_get(form, "address"),
                exclude_id=safe_int(form_get(form, "exclude", "0"), 0) or None)
            return self.json_out({"duplicates": dups})

        # ---- v3 public posts -------------------------------------------
        # question on a business page
        m = re.match(r"^/b/([^/]+)/ask-question$", path)
        if m:
            if is_spambot(form):
                return self.redirect(f"/b/{m.group(1)}")   # drop silently
            if s.get("qa_enabled") != "1":
                return self.redirect(f"/b/{m.group(1)}")
            if not db.rate_ok(f"qa:{self.client_key()}"):
                return self.redirect(f"/b/{m.group(1)}?err="
                    + urllib.parse.quote("تعداد درخواست‌ها زیاد است. کمی بعد دوباره تلاش کنید."))
            b = db.business(slug=m.group(1))
            if b:
                asker = form_get(form, "asker").strip()
                body = form_get(form, "body").strip()
                if len(asker) >= 2 and len(body) >= 8:
                    db.add_question(b["id"], asker, body,
                                    auto_publish=(s.get("qa_moderated") != "1"))
                    if b.get("phone"):
                        sms.notify(s, db.norm_phone(b["phone"]),
                                   f"پرسش تازه دربارهٔ «{b['name']}» در {s.get('site_name')}")
                    sms.notify_owner(s, f"پرسش جدید دربارهٔ «{b['name']}» از {asker}")
                    msg = ("پرسش شما ثبت شد و پس از بررسی منتشر می‌شود."
                           if s.get("qa_moderated") == "1" else "پرسش شما منتشر شد.")
                    return self.redirect(f"/b/{m.group(1)}?ok={urllib.parse.quote(msg)}#qa")
            return self.redirect(f"/b/{m.group(1)}?err="
                + urllib.parse.quote("نام و متن پرسش را کامل بنویسید."))

        # helpful vote on a question
        if path == "/api/question-helpful":
            qid = form_get(form, "id")
            if not qid.isdigit():
                return self.json_out({"ok": False}, 400)
            if not db.rate_ok(f"qh:{self.client_key()}", limit=40):
                return self.json_out({"ok": False, "error": "too many"}, 429)
            n = db.question_helpful(safe_int(qid))
            return self.json_out({"ok": True, "helpful": n})

        # abuse / wrong-info report
        m = re.match(r"^/b/([^/]+)/report$", path)
        if m:
            if s.get("reports_enabled") != "1":
                return self.redirect(f"/b/{m.group(1)}")
            if not db.rate_ok(f"rep:{self.client_key()}"):
                return self.redirect(f"/b/{m.group(1)}?err="
                    + urllib.parse.quote("تعداد گزارش‌ها زیاد است. کمی بعد دوباره تلاش کنید."))
            b = db.business(slug=m.group(1))
            if b:
                db.add_report("business", b["id"], form_get(form, "reason", "other"),
                              form_get(form, "body"), form_get(form, "reporter"))
                db.log("report.add", f"{b['id']} {form_get(form, 'reason')}")
            return self.redirect(f"/b/{m.group(1)}?ok="
                + urllib.parse.quote("گزارش شما ثبت شد. ممنون که کمک کردید اطلاعات درست بماند."))

        # saved-search alert
        if path == "/api/alert":
            if s.get("alerts_enabled") != "1":
                return self.json_out({"ok": False, "error": "غیرفعال است"}, 404)
            if not db.rate_ok(f"al:{self.client_key()}"):
                return self.json_out({"ok": False, "error": "بعداً تلاش کنید"}, 429)
            aid, msg = db.add_alert(form_get(form, "phone"), form_get(form, "term"),
                                    form_get(form, "cat"))
            return self.json_out({"ok": bool(aid), "message": msg})

        if path == "/alert":
            aid, msg = db.add_alert(form_get(form, "phone"), form_get(form, "term"),
                                    form_get(form, "cat"))
            back = form_get(form, "back", "/businesses")
            # v116-audit: `back` is attacker-controllable form input — without
            # this it was an open redirect (phishing pivot after a real POST).
            if not back.startswith("/") or back.startswith("//"):
                back = "/businesses"
            sep = "&" if "?" in back else "?"
            key = "ok" if aid else "err"
            return self.redirect(f"{back}{sep}{key}={urllib.parse.quote(msg)}")

        m = re.match(r"^/b/([^/]+)/review$", path)
        if m:
            if is_spambot(form):
                return self.redirect(f"/b/{m.group(1)}?ok="
                    + urllib.parse.quote("نظر شما ثبت شد."))   # drop silently
            if not db.rate_ok(f"rv:{self.client_key()}"):
                return self.redirect(f"/b/{m.group(1)}?err="
                    + urllib.parse.quote("تعداد نظرهای ارسالی زیاد است. کمی بعد دوباره تلاش کنید."))
            b = db.business(slug=m.group(1))
            if b:
                scores = {}
                if s.get("multicriteria") == "1":
                    for code, _lbl in db.REVIEW_CRITERIA:
                        v = form_get(form, f"crit_{code}")
                        if str(v).isdigit():
                            scores[code] = int(v)
                db.add_review_full(b["id"], form_get(form, "author"),
                                   clamp_int(form_get(form, "rating", "5"), 1, 5, 5),
                                   form_get(form, "body"), scores=scores,
                                   auto_approve=(s.get("reviews_moderated") != "1"))
                sms.notify_owner(s, f"نظر جدید برای «{b['name']}» از "
                                    f"{form_get(form, 'author')}")
            return self.redirect(f"/b/{m.group(1)}?ok="
                + urllib.parse.quote("نظر شما ثبت شد."))

        m = re.match(r"^/haggle/(\d+)$", path)
        if m:
            if s.get("prices_enabled") != "1":
                return self.send(V.not_found(s), 404)
            iid = safe_int(m.group(1))
            it = db.item(iid)
            if not it or not db.haggle_allowed(it):
                return self.send(V.not_found(s), 404)
            if not db.rate_ok(f"hg:{self.client_key()}"):
                return self.send(V2.haggle_form(
                    s, iid, err="پیشنهادهای زیادی فرستاده‌اید. کمی بعد دوباره تلاش کنید."))
            offer = int(re.sub(r"[^\d]", "", form_get(form, "offer", "0")) or 0)
            name = form_get(form, "name").strip()
            phone = form_get(form, "phone").strip()
            if offer <= 0 or not name or not phone:
                return self.send(V2.haggle_form(
                    s, iid, err="قیمت، نام و شمارهٔ تماس را کامل وارد کنید."))
            if offer > int(it["price"]):
                return self.send(V2.haggle_form(
                    s, iid, err="پیشنهاد شما از قیمت اعلام‌شده بیشتر است — "
                                "می‌توانید همان قیمت را مستقیم بخرید."))
            hid, tok, verdict = db.make_offer(
                it["biz_id"], iid, name, phone, offer,
                form_get(form, "qty", "1"), form_get(form, "note"))
            return self.send(V2.haggle_form(
                s, iid, sent={"token": tok, "verdict": verdict, "id": hid}))

        m = re.match(r"^/offer/([A-Za-z0-9_-]{6,64})$", path)
        if m:
            if s.get("prices_enabled") != "1":
                return self.send(V.not_found(s), 404)
            tok = m.group(1)
            rows = db.haggle_thread(token=tok)
            if not rows:
                return self.send(V.not_found(s), 404)
            last = rows[-1]
            if last["status"] not in ("open", "countered") or last["is_buyer"]:
                return self.redirect(f"/offer/{urllib.parse.quote(tok)}")
            action = form_get(form, "action", "counter")
            root = rows[0]
            if action == "accept":
                db.set_haggle_status(last["id"], "accepted")
                db.set_haggle_status(root["id"], "accepted")
            else:
                offer = int(re.sub(r"[^\d]", "", form_get(form, "offer", "0")) or 0)
                if offer <= 0:
                    return self.send(V2.haggle_thread_page(
                        s, tok, err="قیمت پیشنهادی را وارد کنید."))
                db.set_haggle_status(last["id"], "countered")
                db.make_offer(root["biz_id"], root["item_id"], root["name"],
                              root["phone"], offer, root.get("qty", 1),
                              form_get(form, "note"), parent=last["id"],
                              side="buyer")
            return self.redirect(f"/offer/{urllib.parse.quote(tok)}")

        m = re.match(r"^/b/([^/]+)/book$", path)
        if m:
            if is_spambot(form):
                return self.redirect(f"/b/{m.group(1)}?booked=1")   # drop silently
            b = db.business(slug=m.group(1))
            if b:
                db.add_booking(b["id"], form_get(form, "name"), form_get(form, "phone"),
                               form_get(form, "date"), form_get(form, "time"),
                               form_get(form, "note"))
                sms.notify_owner(s, f"رزرو نوبت جدید برای «{b['name']}» در "
                                    f"{form_get(form, 'date')} {form_get(form, 'time')}")
            return self.redirect(f"/b/{m.group(1)}?booked=1")

        # ---------------- business-owner posts (cookie session)
        if path == "/my/logout":
            db.session_kill(self.cookies().get(self.SESSION_COOKIE, ""))
            self.set_cookie(self.SESSION_COOKIE, "", days=0)
            # v69 one account: leaving the shop side signs the person out
            # of the customer side too
            db.customer_session_kill(self.cookies().get(self.CUSTOMER_COOKIE, ""))
            self.set_cookie(self.CUSTOMER_COOKIE, "", days=0)
            return self.redirect("/")
        if path.startswith("/my/"):
            me = self.current_owner()
            if not me:
                return self.redirect("/login")
            return self.owner_post(path, form, s, me)

        # ---------------- admin posts
        if not self.admin_ok(form):
            return self.send(P.login_gate(s), 403)
        return self.panel_post(path, form, s, tok)

    # -------------------------------------------------------------- owner POST
    def owner_post(self, path, form, s, me):
        # ---- account & security: username + password (v57)
        if path == "/my/account":
            ok, msg = db.owner_set_credentials(me["id"], form_get(form, "username"),
                                               form_get(form, "password"))
            key = "ok" if ok else "err"
            return self.redirect(f"/my/account?{key}={urllib.parse.quote(msg)}")

        # ---- chat reply (v28)
        m = re.match(r"^/my/chat/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1), 0)
            thread = db.chat_thread(tid)
            if not thread:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            if not self.chat_role(thread, {}, "owner"):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            if not db.rate_ok(f"chat:owner:{self.client_key()}", limit=60, window=600):
                err = "تعداد پیام‌ها زیاد است. کمی بعد دوباره تلاش کنید."
            else:
                _mid, err = self.store_chat_message(
                    thread, "owner", form_get(form, "body"), [], s)
            if err:
                return self.redirect(f"/my/chat/{tid}?err=" + urllib.parse.quote(err))
            return self.redirect(f"/my/chat/{tid}?ok=" + urllib.parse.quote("پیام ارسال شد."))

        # ---- order status / cancellation decision
        m=re.match(r"^/my/order/(\d+)/cancel$",path)
        if m:
            oid=safe_int(m.group(1));approve=form_get(form,"action")=="approve"
            if not db.decide_order_cancel(oid,me["id"],approve):return self.send(V.not_found(s),403)
            return self.redirect("/my/orders?ok="+urllib.parse.quote("درخواست لغو تأیید شد." if approve else "درخواست لغو رد شد."))
        m = re.match(r"^/my/order/(\d+)$", path)
        if m:
            o = db.order(safe_int(m.group(1)))
            if o and db.owns(me["id"], o["biz_id"]):
                st = form_get(form, "status", "new")
                db.set_order_status(o["id"], st)
                if o.get("customer_id") and s.get("notif_enabled") == "1":
                    label = db.ORDER_LABELS.get(st, ("badge-neutral", st))[1]
                    db.notify(o["customer_id"], "order",
                              f"وضعیت سفارش #{o['id']} به «{label}» تغییر کرد.",
                              f"/me/order/{o['id']}")
            return self.redirect("/my/orders?ok=وضعیت سفارش به‌روزرسانی شد.")

        # ---- story delete (v31)
        m = re.match(r"^/my/story/(\d+)/delete$", path)
        if m:
            sid = safe_int(m.group(1))
            # only the story's own shop owner may delete it
            rows = db.stories_for_owner(me["id"])
            if any(r["id"] == sid for r in rows):
                db.story_delete(sid)
            return self.redirect("/my/stories?ok=استوری حذف شد.")
        m = re.match(r"^/my/trash/(\d+)/restore$", path)   # v105: owner restore
        if m:
            tid = safe_int(m.group(1))
            row = db._one("SELECT * FROM trash WHERE id=?", (tid,))
            biz_ids = [b["id"] for b in db.businesses_of(me["id"])]
            if row and row["biz_id"] in biz_ids:
                db.trash_restore(tid)
                return self.redirect("/my/trash?ok=محتوا بازیابی شد.")
            return self.redirect("/my/trash?err=دسترسی یا مورد معتبر نیست.")

        # ---- support tickets: a real two-way thread with the admin
        if path == "/my/tickets":
            if not db.rate_ok(f"tk:{self.client_key()}", limit=10):
                return self.redirect("/my/tickets?err=" + urllib.parse.quote(
                    "تعداد تیکت‌ها زیاد است. کمی بعد دوباره تلاش کنید."))
            subject = form_get(form, "subject").strip()
            body = form_get(form, "body").strip()
            if len(subject) < 3 or len(body) < 10:
                return self.redirect("/my/tickets?err=" + urllib.parse.quote(
                    "عنوان و متن پیام را کامل بنویسید."))
            bid = form_get(form, "biz_id", "")
            bid = int(bid) if str(bid).isdigit() and db.owns(me["id"], int(bid)) else None
            tid, tok = db.create_ticket(
                subject, body, name=me.get("name") or "", phone=me.get("phone", ""),
                owner_id=me["id"], biz_id=bid,
                topic=form_get(form, "topic", "other"))
            return self.redirect(f"/my/ticket/{tid}?ok=" + urllib.parse.quote(
                "تیکت شما ثبت شد. پاسخ را همین‌جا می‌بینید."))

        m = re.match(r"^/my/ticket/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1))
            t = db.ticket(tid=tid)
            if not t or t.get("owner_id") != me["id"]:
                return self.send(V.not_found(s), 403)
            if form_get(form, "action") == "close":
                db.set_ticket(tid, status="closed")
                return self.redirect(f"/my/ticket/{tid}?ok=" +
                                     urllib.parse.quote("تیکت بسته شد."))
            if db.ticket_reply(tid, form_get(form, "body"), side="user"):
                return self.redirect(f"/my/ticket/{tid}?ok=" +
                                     urllib.parse.quote("پیام شما ارسال شد."))
            return self.redirect(f"/my/ticket/{tid}?err=" +
                                 urllib.parse.quote("متن پیام خالی است."))

        # ---- quick-add a catalogue item: two fields instead of forty-five.
        # Runs through exactly the same ownership check, feature gate and
        # plan quota as the full form -- it is a shorter door, not a back one.
        m = re.match(r"^/my/catalog/(\d+)/quick$", path)
        if m:
            bid = safe_int(m.group(1))
            if not db.owns(me["id"], bid):
                return self.send(V.not_found(s), 403)
            if self.gate(bid, "catalog", "/my"):
                return
            lim = db.access(bid)
            if db.items_count(bid) >= lim["max_items"]:
                return self.redirect("/my?err=" + urllib.parse.quote(
                    f"سقف پلن «{lim['plan_name']}» {lim['max_items']} مورد است. "
                    f"برای افزودن بیشتر، پلن را ارتقا دهید."))
            title = form_get(form, "title").strip()
            if len(title) < 2:
                return self.redirect("/my?err=" + urllib.parse.quote(
                    "نام کالا را بنویسید."))
            raw = re.sub(r"[^\d]", "", form_get(form, "price", ""))
            price = int(raw or 0)
            db.save_item({
                "biz_id": bid, "kind": "product", "title": title,
                "price": price,
                # no price given means "ask" rather than "free"
                "price_type": "fixed" if price else "call",
                "available": 1,
            })
            return self.redirect("/my?ok=" + urllib.parse.quote(
                f"«{title}» اضافه شد."))

        m = re.match(r"^/my/offer/(\d+)$", path)
        if m:
            h = db.haggle(safe_int(m.group(1)))
            if not h or not db.owns(me["id"], h["biz_id"]):
                return self.send(V.not_found(s), 403)
            if self.gate(h["biz_id"], "inquiry", "/my/offers"):
                return
            thread = db.haggle_thread(root_id=h["id"])
            last = thread[-1] if thread else h
            action = form_get(form, "action", "")
            if action == "accept":
                db.set_haggle_status(h["id"], "accepted")
                db.set_haggle_status(last["id"], "accepted")
                msg = "پیشنهاد پذیرفته شد."
            elif action == "decline":
                db.set_haggle_status(h["id"], "declined")
                msg = "پیشنهاد رد شد."
            else:
                offer = int(re.sub(r"[^\d]", "", form_get(form, "offer", "0")) or 0)
                if offer <= 0:
                    return self.redirect("/my/offers?err="
                        + urllib.parse.quote("قیمت پیشنهادی خود را وارد کنید."))
                db.set_haggle_status(h["id"], "countered")
                db.make_offer(h["biz_id"], h["item_id"], "", "", offer,
                              h.get("qty", 1), form_get(form, "note"),
                              parent=last["id"], side="seller")
                msg = "پیشنهاد متقابل شما ثبت شد."
            return self.redirect("/my/offers?ok=" + urllib.parse.quote(msg))

        m = re.match(r"^/my/business/(\d+)$", path)
        if m:
            bid = safe_int(m.group(1))
            if not db.owns(me["id"], bid):
                return self.send(V.not_found(s), 403)
            data = {k: form_get(form, k) for k in
                    ("name", "cat_slug", "descr", "phone", "whatsapp", "address",
                     "tags", "instagram", "telegram", "website", "lat", "lng", "area",
                     "city", "province")}
            data["booking_on"] = checkbox(form, "booking_on")
            # silently drop fields the shop has not unlocked, rather than
            # failing the whole save — the UI already shows them as locked
            if not db.can(bid, "social"):
                for f in ("instagram", "telegram", "website"):
                    data.pop(f, None)
            if not db.can(bid, "booking"):
                data["booking_on"] = 0
            data["hours"] = json.dumps(build_hours(form), ensure_ascii=False)
            # When the admin turned on review-before-publish, an owner edit is
            # queued instead of applied, so nothing changes behind their back.
            if s.get("edit_approval") == "1":
                eid = db.queue_edit(bid, me["id"], data)
                msg = ("تغییری نسبت به قبل نبود." if not eid else
                       "تغییرات برای بررسی مدیر ثبت شد و پس از تأیید اعمال می‌شود.")
                return self.redirect(f"/my/business/{bid}?ok={urllib.parse.quote(msg)}")
            db.save_business(data, bid)
            return self.redirect(f"/my/business/{bid}?ok=تغییرات ذخیره شد.")

        m = re.match(r"^/my/review/(\d+)$", path)
        if m:
            rid = safe_int(m.group(1))
            r = [x for x in db.reviews() if x["id"] == rid]
            if r and db.owns(me["id"], r[0]["biz_id"]):
                if self.gate(r[0]["biz_id"], "reply", "/my/reviews"):
                    return
                db.update_review(rid, reply=form_get(form, "reply"))
            return self.redirect("/my/reviews?ok=پاسخ ثبت شد.")

        m = re.match(r"^/my/question/(\d+)$", path)
        if m:
            qid = safe_int(m.group(1))
            qq = db.question(qid)
            if not qq or not db.owns(me["id"], qq["biz_id"]):
                return self.send(V.not_found(s), 403)
            if self.gate(qq["biz_id"], "qa", "/my/questions"):
                return
            ans = form_get(form, "answer").strip()
            if not ans:
                return self.redirect("/my/questions?err=متن پاسخ خالی است.")
            db.answer_question(qid, ans, by="owner")
            return self.redirect("/my/questions?ok=پاسخ ثبت و منتشر شد.")

        m = re.match(r"^/my/booking/(\d+)$", path)
        if m:
            kid = safe_int(m.group(1))
            k = [x for x in db.bookings() if x["id"] == kid]
            if k and db.owns(me["id"], k[0]["biz_id"]):
                if self.gate(k[0]["biz_id"], "booking", "/my/bookings"):
                    return
                db.update_booking(kid, status=form_get(form, "status", "new"))
            return self.redirect("/my/bookings?ok=وضعیت به‌روزرسانی شد.")

        if path == "/my/claim":
            bid = form_get(form, "biz_id")
            if bid.isdigit():
                ok, msg = db.claim_add(int(bid), me["id"])
                if ok:
                    sms.notify_owner(s, f"درخواست تصاحب کسب‌وکار جدید از {me.get('phone')}")
                key = "ok" if ok else "err"
                return self.redirect(f"/my/claim?{key}={urllib.parse.quote(msg)}")
            return self.redirect("/my/claim")

        # catalog
        m = re.match(r"^/my/catalog/(\d+)/item/(new|\d+)$", path)
        if m:
            bid = safe_int(m.group(1))
            if not db.owns(me["id"], bid):
                return self.send(V.not_found(s), 403)
            iid = None if m.group(2) == "new" else safe_int(m.group(2))
            # a plan limit that is only printed on a page is decoration;
            # this is where it actually bites
            if iid is None:
                if self.gate(bid, "catalog", f"/my/catalog/{bid}"):
                    return
                lim = db.access(bid)
                if db.items_count(bid) >= lim["max_items"]:
                    return self.redirect(f"/my/catalog/{bid}?err=" + urllib.parse.quote(
                        f"سقف پلن «{lim['plan_name']}» {lim['max_items']} مورد است. "
                        f"برای افزودن بیشتر، پلن را ارتقا دهید."))
            self.save_item_from(form, bid, iid, None)
            return self.redirect(f"/my/catalog/{bid}?ok=ذخیره شد.")

        m = re.match(r"^/my/catalog/(\d+)/item/(\d+)/delete$", path)
        if m:
            bid = safe_int(m.group(1))
            if db.owns(me["id"], bid):
                db.delete_item(safe_int(m.group(2)))
            return self.redirect(f"/my/catalog/{bid}?ok=حذف شد.")

        m = re.match(r"^/my/gallery/(\d+)/(delete|cover|banner)$", path)
        if m:
            bid, act = safe_int(m.group(1)), m.group(2)
            if db.owns(me["id"], bid):
                self.gallery_op(bid, act, form_get(form, "src"))
            return self.redirect(f"/my/gallery/{bid}?ok=انجام شد.")

        m = re.match(r"^/my/inquiry/(\d+)$", path)
        if m:
            if self.inquiry_op(safe_int(m.group(1)), form, me):
                return self.redirect("/my/inquiries?ok=انجام شد.")
            return self.redirect("/my/inquiries?err=" + urllib.parse.quote(
                "این درخواست متعلق به کسب‌وکار شما نیست."))

        return self.send(V.not_found(s), 404)

    # -------------------------------------------------------------- shared ops
    def save_item_images(self, form, files, iid):
        """Merge kept images (in the order the owner arranged them) with new
        uploads, and delete anything they removed."""
        old_imgs = db.item_images(iid) if iid else []
        try:
            keep = json.loads(form_get(form, "images_keep", "[]"))
        except Exception:
            keep = None

        new_paths = []
        for fname, _fn, data in files:
            if fname != "images":
                continue
            if len(new_paths) + (len(keep) if keep else 0) >= 6:
                break
            path, err = uploads.save_image(data, "item")
            if path:
                new_paths.append(path)

        if keep is None:
            # no JS payload (plain form post) -> just append
            final = old_imgs + new_paths
        else:
            it = iter(new_paths)
            final = []
            for slot in keep:
                if slot == "@new":
                    nxt = next(it, None)
                    if nxt:
                        final.append(nxt)
                elif slot in old_imgs:
                    final.append(slot)
            final.extend(it)          # any extras

        for gone in set(old_imgs) - set(final):
            uploads.delete_image(gone)
        return final[:6]

    def save_item_from(self, form, bid, iid, file_bytes):
        data = {
            "biz_id": bid,
            "kind": form_get(form, "kind", "product"),
            "title": form_get(form, "title"),
            "descr": form_get(form, "descr"),
            "price": form_get(form, "price", "0"),
            "price_type": form_get(form, "price_type", "fixed"),
            "unit": form_get(form, "unit"),
            "duration": form_get(form, "duration"),
            "tags": form_get(form, "tags"),
            "options": form_get(form, "options"),
            "old_price": form_get(form, "old_price", "0"),
            "stock": form_get(form, "stock", ""),
            "code": form_get(form, "code"),
            "min_order": form_get(form, "min_order"),
            "note": form_get(form, "note"),
            # ---- shop-window fields
            "brand": form_get(form, "brand"),
            "warranty": form_get(form, "warranty"),
            "prep_days": form_get(form, "prep_days"),
            "delivery": form_get(form, "delivery"),
            "bulk_price": form_get(form, "bulk_price"),
            "video": form_get(form, "video"),
            "spec": form_get(form, "spec"),
            "weight": form_get(form, "weight"),
            "handmade": checkbox(form, "handmade"),
            "returnable": checkbox(form, "returnable"),
            # ---- چانه‌زنی (floor price stays server-side; buyers never see it)
            "haggle": checkbox(form, "haggle"),
            "floor_price": form_get(form, "floor_price", "0"),
            "available": checkbox(form, "available"),
            "sort": form_get(form, "sort", "0"),
        }
        # audit F-016: `featured` is a metered plan perk (featured_slots) and
        # ranks items first in the public catalog. The owner's own form never
        # sends it, so a crafted POST could grab free placement — and an
        # ordinary edit used to clobber an admin-granted featured back to 0.
        # Only plans/unlocks that include the perk may set it; otherwise the
        # key is omitted entirely so a saved item keeps its current value.
        if db.can(bid, "featured"):
            data["featured"] = checkbox(form, "featured")
        old = db.item(iid) if iid else None
        if file_bytes:
            path, err = uploads.save_image(file_bytes, "item")
            if path:
                if old and old.get("image"):
                    uploads.delete_image(old["image"])
                data["image"] = path
        elif form.get("remove_image"):
            if old and old.get("image"):
                uploads.delete_image(old["image"])
            data["image"] = ""
        return db.save_item(data, iid)

    def gallery_op(self, bid, act, src):
        imgs = db.biz_images(bid)
        if act == "delete" and src in imgs:
            imgs.remove(src)
            uploads.delete_image(src)
            # a deleted photo must not stay as the page banner
            b = db.business(bid=bid)
            if b and b.get("cover") == src:
                db.save_business({"cover": ""}, bid)
        elif act == "cover" and src in imgs:
            imgs.remove(src)
            imgs.insert(0, src)
        elif act == "banner":
            # the shop's own background behind its page header. Empty string
            # clears it and falls back to the site gradient.
            db.save_business({"cover": src if src in imgs else ""}, bid)
            return
        db.biz_images_set(bid, imgs)

    def inquiry_op(self, qid, form, me=None, is_admin=False):
        # Ownership wall: a shopkeeper may only touch inquiries addressed to
        # one of their own businesses. (Security fix — previously any signed-in
        # owner could delete/quote every inquiry in the city by id.) The admin
        # panel path passes is_admin=True and is already token-gated.
        q = db.inquiry(qid)
        if not q:
            return False
        if not is_admin and (not me or not db.owns(me["id"], q["biz_id"])):
            return False
        act = form_get(form, "action")
        if act == "delete":
            return db.delete_inquiry(qid)
        if act in ("won", "lost"):
            return db.update_inquiry(qid, status=act)
        db.update_inquiry(qid, quote=form_get(form, "quote"), status="quoted")
        return True

    # /subscribe may arrive urlencoded or multipart (bank receipt attached).
    # One handler for both bodies — v139.
    def subscribe_post(self, s, form, files=None):
        me = self.current_owner()
        if not me:
            return self.redirect("/login")
        plan_slug = form_get(form, "plan")
        bid = form_get(form, "biz_id")
        months = form_get(form, "months")
        # v136: keep the chosen billing period on every redirect so it never
        # snaps back to the plan's own (yearly) length.
        back = f"/subscribe?plan={urllib.parse.quote(plan_slug)}"
        if months and str(months).isdigit():
            back += f"&months={int(months)}"
        if not bid.isdigit() or not db.owns(me["id"], int(bid)):
            return self.redirect(back + "&err=" + urllib.parse.quote(
                "این کسب‌وکار متعلق به شما نیست."))
        if not db.rate_ok(f"sb:{self.client_key()}", limit=6):
            return self.redirect(back + "&err=" + urllib.parse.quote(
                "تعداد درخواست‌ها زیاد است. کمی بعد تلاش کنید."))
        receipt_path = ""
        for n, fn, data in (files or []):
            if n == "receipt" and data:
                receipt_path, rerr = uploads.save_image(data, "receipt")
                if not receipt_path:
                    return self.redirect(back + "&err=" + urllib.parse.quote(
                        rerr or "فیش ارسالی معتبر نیست — یک تصویر انتخاب کنید."))
                break
        sid, msg = db.request_subscription(int(bid), plan_slug,
                                           form_get(form, "ref"), "manual",
                                           form_get(form, "note"),
                                           months=months, receipt=receipt_path)
        if not sid:
            return self.redirect(f"/pricing?err={urllib.parse.quote(msg)}")
        db.log("subscription.request", f"biz {bid} plan {plan_slug} by {me['phone']}")
        return self.redirect(f"/my/plan?ok={urllib.parse.quote(msg)}")

    # -------------------------------------------------------------- multipart
    def route_multipart(self, path, s, tok):
        fields, files = self.read_multipart()
        clip_form(fields)
        if path == "/subscribe":
            return self.subscribe_post(s, fields, files)
        # v117/M1: uploads authenticate like every other panel POST — an
        # unlocked admin session cookie, or the legacy key when no password
        # is set (upload forms no longer embed the raw key).
        admin = db.admin_session_ok(
            self.cookies().get(self.ADMIN_COOKIE),
            unlocked_only=db.owner_pass_set()) or (
            _token_eq(fields.get("key", ""), tok)
            and not db.owner_pass_set())
        me = self.current_owner()

        # ---- messenger attachment/text send (v73)
        m = re.match(r"^/(me|my|panel)/chat/(\d+)$", path)
        if m:
            area, tid = m.group(1), safe_int(m.group(2), 0)
            thread = db.chat_thread(tid)
            if not thread:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            sender = {"me": "customer", "my": "owner", "panel": "admin"}[area]
            role = self.chat_role(thread, fields, sender)
            if not role or (sender == "admin" and not admin):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            if not db.rate_ok(f"chat:{sender}:{self.client_key()}", limit=60, window=600):
                err = "تعداد پیام‌ها زیاد است. کمی بعد دوباره تلاش کنید."
            else:
                _mid, err = self.store_chat_message(
                    thread, sender, form_get(fields, "body"), files, s)
            if area == "panel":
                back = f"/panel/chat/{tid}"
            else:
                back = f"/{area}/chat/{tid}"
            if err:
                return self.redirect(back + ("&" if "?" in back else "?")
                                     + "err=" + urllib.parse.quote(err))
            return self.redirect(back + ("&" if "?" in back else "?")
                                 + "ok=" + urllib.parse.quote("پیام ارسال شد."))

        # ---- support ticket attachments (v76) -- private, authenticated
        if path == "/my/tickets":
            if not me:
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            blob = next(((fn,d) for n,fn,d in files if n=="attachment" and d), None)
            attachment = None
            if blob:
                attachment, err = uploads.save_chat_file(blob[1], blob[0], prefix="ticket")
                if not attachment:
                    return self.redirect("/my/tickets?err="+urllib.parse.quote(err or "فایل نامعتبر است."))
            subject=form_get(fields,"subject").strip(); body=form_get(fields,"body").strip()
            if len(subject)<3 or (len(body)<2 and not attachment):
                if attachment: uploads.delete_chat_file(attachment["stored_name"])
                return self.redirect("/my/tickets?err="+urllib.parse.quote("عنوان و متن را کامل کنید."))
            bid=safe_int(fields.get("biz_id"),0) or None
            if bid and not db.owns(me["id"],bid): bid=None
            tid,_tok=db.create_ticket(subject,body,name=me.get("name") or "",phone=me.get("phone") or "",owner_id=me["id"],biz_id=bid,topic=form_get(fields,"topic","other"),attachment=attachment)
            if not tid:
                if attachment: uploads.delete_chat_file(attachment["stored_name"])
                return self.redirect("/my/tickets?err="+urllib.parse.quote("ثبت تیکت انجام نشد."))
            return self.redirect(f"/my/ticket/{tid}?ok="+urllib.parse.quote("تیکت ثبت شد."))

        m=re.match(r"^/my/ticket/(\d+)$",path)
        if m:
            tid=safe_int(m.group(1)); t=db.ticket(tid=tid)
            if not me or not t or t.get("owner_id")!=me["id"]:
                return self.send("forbidden",403,"text/plain; charset=utf-8")
            if form_get(fields,"action")=="close":
                db.set_ticket(tid,status="closed");return self.redirect(f"/my/ticket/{tid}?ok=تیکت بسته شد.")
            blob=next(((fn,d) for n,fn,d in files if n=="attachment" and d),None);attachment=None
            if blob:
                attachment,err=uploads.save_chat_file(blob[1],blob[0],prefix="ticket")
                if not attachment:return self.redirect(f"/my/ticket/{tid}?err="+urllib.parse.quote(err or "فایل نامعتبر است."))
            mid=db.ticket_reply(tid,form_get(fields,"body"),side="user",attachment=attachment)
            if not mid and attachment:uploads.delete_chat_file(attachment["stored_name"])
            return self.redirect(f"/my/ticket/{tid}?"+("ok=پیام ارسال شد." if mid else "err=پیام خالی است."))

        m=re.match(r"^/panel/ticket/(\d+)$",path)
        if m:
            if not admin:return self.send("forbidden",403,"text/plain; charset=utf-8")
            tid=safe_int(m.group(1));action=form_get(fields,"action","reply")
            if action=="delete":db.delete_ticket(tid);return self.redirect(f"/panel/tickets?ok=تیکت حذف شد.")
            db.set_ticket(tid,status=form_get(fields,"status","open"),priority=form_get(fields,"priority","normal"))
            if action=="save":return self.redirect(f"/panel/ticket/{tid}?ok=وضعیت ذخیره شد.")
            blob=next(((fn,d) for n,fn,d in files if n=="attachment" and d),None);attachment=None
            if blob:
                attachment,err=uploads.save_chat_file(blob[1],blob[0],prefix="ticket")
                if not attachment:return self.redirect(f"/panel/ticket/{tid}?err="+urllib.parse.quote(err or "فایل نامعتبر است."))
            mid=db.ticket_reply(tid,form_get(fields,"body"),side="admin",attachment=attachment)
            if not mid and attachment:uploads.delete_chat_file(attachment["stored_name"])
            return self.redirect(f"/panel/ticket/{tid}?"+("ok=پاسخ ارسال شد." if mid else "err=پیام خالی است."))

        # ---- shop story upload (v31)
        if path == "/my/story/add":
            if not me:
                return self.redirect("/login")
            bid = safe_int(fields.get("biz_id"), 0)
            if not db.owns(me["id"], bid):
                return self.redirect("/my/stories?err=" + urllib.parse.quote(
                    "این کسب‌وکار متعلق به شما نیست."))
            blob = next((d for n, fn, d in files if n == "story_media"), None)
            if not blob:
                return self.redirect("/my/stories?err=" + urllib.parse.quote(
                    "عکس یا ویدیویی انتخاب نشده است."))
            path_, kind, err = uploads.save_media(blob, "story")
            if not path_:
                return self.redirect("/my/stories?err=" + urllib.parse.quote(err or "خطا در فایل"))
            try:
                _dur = float(fields.get("duration", "0") or 0)
            except (TypeError, ValueError):
                _dur = 0.0
            db.stories_add(bid, path_, fields.get("caption", ""), kind=kind or "image",
                           duration=max(0.0, min(_dur, 30.0)))
            db.log("story.add", f"{bid} {kind}")
            return self.redirect("/my/stories?ok=" + urllib.parse.quote(
                "استوری منتشر شد." if kind == "image" else "ویدیو-استوری منتشر شد."))

        # ---- review with optional photo (v28)
        m = re.match(r"^/b/([^/]+)/review$", path)
        if m:
            if is_spambot(fields):
                return self.redirect(f"/b/{m.group(1)}?ok="
                    + urllib.parse.quote("نظر شما ثبت شد."))
            if not db.rate_ok(f"rv:{self.client_key()}"):
                return self.redirect(f"/b/{m.group(1)}?err="
                    + urllib.parse.quote("تعداد نظرهای ارسالی زیاد است. کمی بعد دوباره تلاش کنید."))
            b = db.business(slug=m.group(1))
            if b:
                img_path = ""
                blob = next((d for n, fn, d in files if n == "review_image"), None)
                if blob:
                    img_path, _err = uploads.save_image(blob, "review")
                    if not img_path:
                        img_path = ""
                scores = {}
                if s.get("multicriteria") == "1":
                    for code, _lbl in db.REVIEW_CRITERIA:
                        v = fields.get(f"crit_{code}")
                        if v and str(v).isdigit():
                            scores[code] = int(v)
                db.add_review_full(b["id"], fields.get("author", ""),
                                   clamp_int(fields.get("rating", "5"), 1, 5, 5),
                                   fields.get("body", ""), scores=scores,
                                   auto_approve=(s.get("reviews_moderated") != "1"),
                                   image=img_path)
                sms.notify_owner(s, f"نظر جدید برای «{b['name']}» از "
                                    f"{fields.get('author', '')}")
            return self.redirect(f"/b/{m.group(1)}?ok="
                + urllib.parse.quote("نظر شما ثبت شد."))

        # ---- gallery upload (JSON response, called by fetch)
        m = re.match(r"^/(my|panel)/gallery/(\d+)/upload$", path)
        if m:
            bid = safe_int(m.group(2))
            if not admin and not (me and db.owns(me["id"], bid)):
                return self.json_out({"ok": False, "error": "دسترسی ندارید"}, 403)
            old_imgs = db.biz_images(bid)
            # The photo cap IS the gallery gate. The old code refused any
            # second photo whenever `gallery` was locked, which contradicted
            # the free plan's advertised 3 photos. max_photos already encodes
            # free=3 / founder=6 / paid=20+, so trust that single number.
            acc = db.access(bid)
            cap = uploads.MAX_FILES if admin else min(uploads.MAX_FILES, acc["max_photos"])
            try:
                keep = json.loads(fields.get("images_keep", "[]"))
            except Exception:
                keep = None

            new_paths, errs = [], []
            for fname, _fn, data in files:
                if fname != "images":
                    continue
                if len(new_paths) + (len(keep) if keep else len(old_imgs)) >= cap:
                    errs.append("ظرفیت گالری تکمیل شد")
                    break
                path, err = uploads.save_image(data, f"biz{bid}")
                if path:
                    new_paths.append(path)
                elif err:
                    errs.append(err)

            if keep is None:
                final = old_imgs + new_paths
            else:
                it = iter(new_paths)
                final = []
                for slot in keep:
                    if slot == "@new":
                        nxt = next(it, None)
                        if nxt:
                            final.append(nxt)
                    elif slot in old_imgs:
                        final.append(slot)
                final.extend(it)
            final = final[:cap]

            for gone in set(old_imgs) - set(final):
                uploads.delete_image(gone)
            db.biz_images_set(bid, final)

            back = (f"/panel/gallery/{bid}?"
                    if admin else f"/my/gallery/{bid}?")
            back += f"ok={urllib.parse.quote('گالری ذخیره شد.')}"
            return self.redirect(back)

        # ---- appearance (logo upload)
        if path == "/panel/appearance":
            if not admin:
                return self.send(P.login_gate(s), 403)
            try:
                keep = json.loads(fields.get("logo_keep", "[]"))
            except Exception:
                keep = None
            old_logo = s.get("site_logo", "")
            new_logo = old_logo
            blob = next((d for n, fn, d in files if n == "logo"), None)
            if blob:
                path_, err = uploads.save_image(blob, "logo")
                if path_:
                    if old_logo:
                        uploads.delete_image(old_logo)
                    new_logo = path_
            elif keep is not None and not keep:
                if old_logo:
                    uploads.delete_image(old_logo)
                new_logo = ""
            db.set_settings({
                "site_logo": new_logo,
                "color_primary": form_get(fields, "color_primary"),
                "color_accent": form_get(fields, "color_accent"),
                "color_background": form_get(fields, "color_background"),
                "color_foreground": form_get(fields, "color_foreground"),
                "hero_title": form_get(fields, "hero_title"),
                "hero_lead": form_get(fields, "hero_lead"),
                "hero_cta": form_get(fields, "hero_cta"),
                "footer_note": form_get(fields, "footer_note"),
            })
            return self.redirect(f"/panel/appearance"
                                 f"&ok={urllib.parse.quote('ظاهر سایت به‌روزرسانی شد.')}")

        # ---- ad banner with image
        if path == "/panel/ad/new":
            if not admin:
                return self.send(P.login_gate(s), 403)
            title = form_get(fields, "title")
            if not title:
                return self.redirect(f"/panel/ads"
                                     f"&err={urllib.parse.quote('عنوان بنر الزامی است.')}")
            img = ""
            blob = next((d for n, fn, d in files if n == "image" and d), None)
            if blob:
                p_, _err = uploads.save_image(blob, "ad")
                img = p_ or ""
            db.save_ad({"title": title, "body": form_get(fields, "body"),
                        "url": form_get(fields, "url"),
                        "slot": form_get(fields, "slot", "home"),
                        "biz_id": form_get(fields, "biz_id"),
                        "starts": form_get(fields, "starts"),
                        "ends": form_get(fields, "ends"),
                        "weight": form_get(fields, "weight", "1"),
                        "image": img,
                        "active": checkbox(fields, "active")})
            return self.redirect(f"/panel/ads"
                                 f"&ok={urllib.parse.quote('بنر ساخته شد.')}")

        # ---- catalog item with image (normal form post -> redirect)
        m = re.match(r"^/(my|panel)/catalog/(\d+)/item/(new|\d+)$", path)
        if m:
            bid = safe_int(m.group(2))
            if not admin and not (me and db.owns(me["id"], bid)):
                return self.send(V.not_found(s), 403)
            iid = None if m.group(3) == "new" else safe_int(m.group(3))
            if iid is None:
                iid = self.save_item_from(fields, bid, None, None)
            else:
                self.save_item_from(fields, bid, iid, None)
            imgs = self.save_item_images(fields, files, iid)
            db.item_images_set(iid, imgs)
            if admin:
                return self.redirect(f"/panel/catalog/{bid}?ok=ذخیره شد.")
            return self.redirect(f"/my/catalog/{bid}?ok=ذخیره شد.")

        return self.send(V.not_found(s), 404)

    def panel_post(self, path, form, s, tok):

        # ---- admin chat reply and control (v73 messenger)
        m = re.match(r"^/panel/chat/(\d+)/status$", path)
        if m:
            tid = safe_int(m.group(1), 0)
            status = form_get(form, "status")
            if status not in ("open", "closed"):
                return self.send("bad status", 400, "text/plain; charset=utf-8")
            if not db.chat_set_status(tid, status):
                return self.send("not found", 404, "text/plain; charset=utf-8")
            db.log("chat.status", f"thread={tid} status={status}")
            return self.redirect(f"/panel/chat/{tid}?ok=" + urllib.parse.quote(
                "گفتگو باز شد." if status == "open" else "گفتگو بسته شد."))

        m = re.match(r"^/panel/chat/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1), 0)
            thread = db.chat_thread(tid)
            if not thread:
                return self.send("not found", 404, "text/plain; charset=utf-8")
            if not db.rate_ok(f"chat:admin:{self.client_key()}", limit=120, window=600):
                err = "تعداد پیام‌ها زیاد است. کمی بعد دوباره تلاش کنید."
            else:
                _mid, err = self.store_chat_message(
                    thread, "admin", form_get(form, "body"), [], s)
            if err:
                return self.redirect(f"/panel/chat/{tid}?err=" + urllib.parse.quote(err))
            return self.redirect(f"/panel/chat/{tid}?ok=" + urllib.parse.quote(
                "پیام مدیر ارسال شد."))

        # ---- admin order status / cancellation
        m=re.match(r"^/panel/order/(\d+)/cancel$",path)
        if m:
            oid=safe_int(m.group(1));approve=form_get(form,"action")=="approve"
            if not db.decide_order_cancel(oid,None,approve):return self.send(V.not_found(s),404)
            return self.redirect(f"/panel/orders?ok="+urllib.parse.quote("درخواست لغو بررسی شد."))
        m = re.match(r"^/panel/order/(\d+)$", path)
        if m:
            oid = safe_int(m.group(1))
            st = form_get(form, "status", "new")
            db.set_order_status(oid, st)
            o = db.order(oid)
            if o and o.get("customer_id") and s.get("notif_enabled") == "1":
                label = db.ORDER_LABELS.get(st, ("badge-neutral", st))[1]
                db.notify(o["customer_id"], "order",
                          f"وضعیت سفارش #{oid} به «{label}» تغییر کرد.", f"/me/order/{oid}")
            return self.redirect(f"/panel/orders?ok=وضعیت سفارش ذخیره شد.")

        # ---- site content editor (v29)
        if path == "/panel/editor":
            upd = {k: form_get(form, k) for k in
                   ("site_name", "tagline", "description",
                    "hero_title", "hero_lead", "hero_cta", "footer_note")}
            db.set_settings(upd)
            db.save_page("about", form_get(form, "about_title", "درباره ما"),
                         form_get(form, "about_body", ""))
            db.save_page("rules", form_get(form, "rules_title", "قوانین و مقررات"),
                         form_get(form, "rules_body", ""))
            db.log("editor.save", "site content updated")
            return self.redirect(f"/panel/editor?ok=همهٔ تغییرات ذخیره شد.")

        # ---- neighbourhood rename (v29)
        if path == "/panel/areas/rename":
            n = db.rename_area(form_get(form, "old"), form_get(form, "new").strip())
            db.log("area.rename", f"'{form_get(form, 'old')}' -> '{form_get(form, 'new')}' ({n})")
            return self.redirect(f"/panel/areas?ok=" + urllib.parse.quote(
                f"نام محله به‌روزرسانی شد ({n} کسب‌وکار)."))

        # ---- demo data: one-click fill / wipe for previewing the site
        if path == "/panel/demo":
            import seed_demo
            act = form_get(form, "action", "")
            if act == "seed":
                seed_demo.clear()
                seed_demo.seed()
                n = len(db.businesses(status=None))
                db.log("demo.seed", f"{n} businesses")
                return self.redirect(f"/panel/demo?ok=" + urllib.parse.quote(
                    f"دادهٔ نمونه ساخته شد — اکنون {n} کسب‌وکار در سایت است."))
            if act == "clear":
                seed_demo.clear()
                db.log("demo.clear", "sample data wiped")
                return self.redirect(f"/panel/demo?ok=" + urllib.parse.quote(
                    "همهٔ دادهٔ نمونه پاک شد."))
            return self.redirect(f"/panel/demo")

        # ---- top lists (v31)
        if path == "/panel/list/new":
            title = form_get(form, "title").strip()
            if not title:
                return self.redirect(f"/panel/lists?err=عنوان الزامی است.")
            db.save_toplist({"title": title, "descr": form_get(form, "descr"),
                             "kind": form_get(form, "kind", "manual"),
                             "limit_n": clamp_int(form_get(form, "limit_n"), 3, 50, 10)})
            db.log("list.create", title)
            return self.redirect(f"/panel/lists?ok=لیست ساخته شد.")
        m = re.match(r"^/panel/list/(\d+)$", path)
        if m:
            items = [x for x in form.get("items") or [] if str(x).isdigit()]
            db.save_toplist({"title": form_get(form, "title"),
                             "descr": form_get(form, "descr"),
                             "kind": form_get(form, "kind", "manual"),
                             "items": [int(x) for x in items],
                             "limit_n": clamp_int(form_get(form, "limit_n"), 3, 50, 10),
                             "active": checkbox(form, "active")}, safe_int(m.group(1)))
            return self.redirect(f"/panel/lists?ok=لیست ذخیره شد.")
        m = re.match(r"^/panel/list/(\d+)/delete$", path)
        if m:
            db.delete_toplist(safe_int(m.group(1)))
            return self.redirect(f"/panel/lists?ok=لیست حذف شد.")

        # ---- flash deals (v31)
        if path == "/panel/deal/new":
            db.save_flashdeal({"biz_id": safe_int(form_get(form, "biz_id"), 0),
                               "title": form_get(form, "title"),
                               "descr": form_get(form, "descr"),
                               "percent": clamp_int(form_get(form, "percent"), 1, 90, 20),
                               "ends": form_get(form, "ends"),
                               "active": 1})
            db.log("deal.create", form_get(form, "title"))
            return self.redirect(f"/panel/deals?ok=فلش‌سیل ساخته شد.")
        m = re.match(r"^/panel/deal/(\d+)/delete$", path)
        if m:
            db.delete_flashdeal(safe_int(m.group(1)))
            return self.redirect(f"/panel/deals?ok=حذف شد.")

        # ---- customer moderation (v34)
        m = re.match(r"^/panel/customer/(\d+)$", path)
        if m:
            cid = safe_int(m.group(1))
            act = form_get(form, "action")
            if act in ("block", "unblock"):
                db.customer_set_status(cid, "blocked" if act == "block" else "active")
                db.log("customer.mod", f"{cid} {act}")
                return self.redirect(f"/panel/customers?ok=" + urllib.parse.quote(
                    "مشتری مسدود شد." if act == "block" else "مسدودی برداشته شد."))
            return self.redirect(f"/panel/customers")

        m = re.match(r"^/panel/customer/(\d+)/delete$", path)
        if m:
            db.customer_delete(safe_int(m.group(1)))
            db.log("customer.delete", m.group(1))
            return self.redirect(f"/panel/customers?ok=مشتری حذف شد.")

        # ---- broadcast to all customers (v34)
        if path == "/panel/broadcast":
            text = form_get(form, "text").strip()
            if not text:
                return self.redirect(f"/panel/broadcast?err=متن پیام الزامی است.")
            link = form_get(form, "link").strip()
            if link and not link.startswith("/"):
                link = ""
            n = db.notify_all("info", text, link)
            db.log("broadcast", f"{n} customers")
            return self.redirect(f"/panel/broadcast?ok=" + urllib.parse.quote(
                f"اعلان برای {n} مشتری ارسال شد."))

        # ---- story delete (admin, v31)
        m = re.match(r"^/panel/story/(\d+)/delete$", path)
        if m:
            db.story_delete(safe_int(m.group(1)))
            return self.redirect(f"/panel/stories?ok=استوری حذف شد.")
        m = re.match(r"^/panel/trash/(\d+)/restore$", path)   # v105: admin restore
        if m:
            db.trash_restore(safe_int(m.group(1)))
            return self.redirect(f"/panel/trash?ok=محتوا بازیابی شد.")

        # v112: lift a shield block by hand (a shared NAT/CGNAT IP may be banned)
        if path == "/panel/traffic/unblock":
            if not self.admin_ok(form):
                return self.send("forbidden", 403, "text/plain; charset=utf-8")
            ident = form_get(form, "ident", "").strip()[:45]
            shield.unblock(ident)
            db.log("shield.unblock", ident)
            return self.redirect(f"/panel/traffic?ok=مسدودی برداشته شد.")

        # ---- feature switches. An unchecked box posts nothing, so the
        # full list must be walked and every absent key written as "0".
        if path == "/panel/features":
            keys = [k for _t, items in P2.SITE_FEATURES for k, *_ in items]
            for k in keys:
                db.set_setting(k, "1" if form.get(k) else "0")
            db.log("features.save", f"{sum(1 for k in keys if form.get(k))}/{len(keys)} on")
            return self.redirect(f"/panel/features?ok="
                + urllib.parse.quote("قابلیت‌ها ذخیره شد."))

        # ---- support tickets
        m = re.match(r"^/panel/ticket/(\d+)$", path)
        if m:
            tid = safe_int(m.group(1))
            if not db.ticket(tid=tid):
                return self.send(V.not_found(s), 404)
            action = form_get(form, "action", "reply")
            if action == "delete":
                db.delete_ticket(tid)
                return self.redirect(f"/panel/tickets?ok="
                    + urllib.parse.quote("تیکت حذف شد."))
            # status/priority always follow the form; a reply, when present,
            # overrides the status to "answered" inside db.ticket_reply()
            db.set_ticket(tid, status=form_get(form, "status", "open"),
                          priority=form_get(form, "priority", "normal"))
            body = form_get(form, "body").strip()
            if action == "reply" and body:
                db.ticket_reply(tid, body, side="admin")
                msg = "پاسخ شما ارسال شد."
            else:
                msg = "وضعیت ذخیره شد."
            return self.redirect(f"/panel/ticket/{tid}?ok="
                                 + urllib.parse.quote(msg))

        # ---- business create / update
        m = re.match(r"^/panel/business/(new|\d+)$", path)
        if m:
            bid = None if m.group(1) == "new" else safe_int(m.group(1))
            data = {
                "name": form_get(form, "name"),
                "cat_slug": form_get(form, "cat_slug"),
                "descr": form_get(form, "descr"),
                "phone": form_get(form, "phone"),
                "whatsapp": form_get(form, "whatsapp"),
                "address": form_get(form, "address"),
                "tags": form_get(form, "tags"),
                "instagram": form_get(form, "instagram"),
                "telegram": form_get(form, "telegram"),
                "website": form_get(form, "website"),
                "area": form_get(form, "area"),
                "city": form_get(form, "city"),
                "province": form_get(form, "province"),
                "lat": form_get(form, "lat"),
                "lng": form_get(form, "lng"),
                "status": form_get(form, "status", "published"),
                "featured": checkbox(form, "featured"),
                "verified": checkbox(form, "verified"),
                "booking_on": checkbox(form, "booking_on"),
                "hours": json.dumps(build_hours(form), ensure_ascii=False),
            }
            if not data["name"] or not data["cat_slug"]:
                return self.redirect(f"/panel/businesses?err=نام و دسته الزامی است.")
            db.save_business(data, bid)
            db.log("business.save", data["name"])
            return self.redirect(f"/panel/businesses?ok=با موفقیت ذخیره شد.")

        m = re.match(r"^/panel/business/(\d+)/delete$", path)
        if m:
            db.delete_business(safe_int(m.group(1)))
            return self.redirect(f"/panel/businesses?ok=کسب‌وکار حذف شد.")

        # ---- approve / reject / hide a submitted business
        m = re.match(r"^/panel/business/(\d+)/status$", path)
        if m:
            bid = safe_int(m.group(1))
            new_status = form_get(form, "status", "published")
            if new_status not in ("published", "pending", "hidden", "rejected"):
                new_status = "pending"
            b = db.business(bid=bid)
            db.save_business({"status": new_status}, bid)
            db.log("business.status", f"{bid} -> {new_status}")

            # If an account already exists for this phone, hand ownership over
            # on approval so the shopkeeper finds it waiting for them.
            if new_status == "published" and b and not b.get("owner_id") and b.get("phone"):
                existing = db.owner_by_phone(b["phone"])
                if existing:
                    db.set_business_owner(bid, existing["id"])

            # tell everyone who asked to be alerted about a shop like this
            if new_status == "published" and b and s.get("alerts_enabled") == "1":
                fresh = db.business(bid=bid)
                for al in db.matching_alerts(fresh or b):
                    sms.notify(s, al["phone"],
                               f"«{(fresh or b)['name']}» در {s.get('site_name')} ثبت شد: "
                               f"/b/{(fresh or b)['slug']}")
                    db.mark_alert_sent(al["id"])

            # tell the applicant what happened
            if b and b.get("phone") and new_status in ("published", "rejected"):
                site = s.get("site_name", "")
                txt = (f"کسب‌وکار «{b['name']}» در {site} تأیید و منتشر شد."
                       if new_status == "published"
                       else f"متأسفانه ثبت «{b['name']}» در {site} تأیید نشد.")
                sms.notify(s, db.norm_phone(b["phone"]), txt)

            msg = {"published": "کسب‌وکار تأیید و منتشر شد.",
                   "rejected": "درخواست رد شد.",
                   "hidden": "کسب‌وکار مخفی شد.",
                   "pending": "به حالت در انتظار بازگشت."}[new_status]
            back = form_get(form, "back", "/panel/businesses")
            sep = "&" if "?" in back else "?"
            return self.redirect(f"{back}{sep}ok={urllib.parse.quote(msg)}")

        m = re.match(r"^/panel/business/(\d+)/toggle$", path)
        if m:
            bid = safe_int(m.group(1))
            b = db.business(bid=bid)
            fld = form_get(form, "field", "featured")
            if b and fld in ("featured", "verified"):
                db.save_business({fld: 0 if b[fld] else 1}, bid)
            return self.redirect(f"/panel/businesses?ok=به‌روزرسانی شد.")

        # ---- categories
        if path == "/panel/category/new":
            name = form_get(form, "name")
            if not name:
                return self.redirect(f"/panel/categories?err=نام دسته الزامی است.")
            db.save_category({"name": name, "icon": form_get(form, "icon", "store"),
                              "parent": form_get(form, "parent"),
                              "blurb": form_get(form, "blurb")})
            return self.redirect(f"/panel/categories?ok=دسته ایجاد شد.")

        m = re.match(r"^/panel/category/(\d+)$", path)
        if m:
            db.save_category({"name": form_get(form, "name"),
                              "icon": form_get(form, "icon", "store"),
                              "blurb": form_get(form, "blurb"),
                              "parent": form_get(form, "parent"),
                              "sort": form_get(form, "sort", "0") or 0,
                              "active": checkbox(form, "active")}, safe_int(m.group(1)))
            return self.redirect(f"/panel/categories?ok=دسته به‌روزرسانی شد.")

        m = re.match(r"^/panel/category/(\d+)/delete$", path)
        if m:
            ok, msg = db.delete_category(safe_int(m.group(1)))
            kind = "ok" if ok else "err"
            return self.redirect(f"/panel/categories?{kind}={urllib.parse.quote(msg)}")

        # ---- reviews
        if path == "/panel/tickets/bulk":          # v117/M4
            ids = [safe_int(x) for x in (form.get("ids") or [])
                   if str(x).isdigit()]
            act = form_get(form, "action")
            n = 0
            for tid in ids:
                if act == "delete":
                    db.delete_ticket(tid); n += 1
                else:
                    db.set_ticket(tid, status="closed" if act == "close" else "open"); n += 1
            db.log("ticket.bulk", f"{act}:{n}")
            return self.redirect(f"/panel/tickets?ok=" + urllib.parse.quote(
                f"{n} تیکت به‌روزرسانی شد."))

        if path == "/panel/reviews/bulk":          # v117/M4
            ids = [safe_int(x) for x in (form.get("ids") or [])
                   if str(x).isdigit()]
            act = form_get(form, "action")
            n = 0
            for rid in ids:
                if act == "delete":
                    db.delete_review(rid); n += 1
                elif act == "approve":
                    db.update_review(rid, status="approved"); n += 1
                elif act == "reject":
                    db.update_review(rid, status="rejected"); n += 1
            db.log("review.bulk", f"{act}:{n}")
            return self.redirect(f"/panel/reviews?ok=" + urllib.parse.quote(
                f"{n} نظر {'حذف' if act == 'delete' else ('تأیید' if act == 'approve' else 'رد')} شد."))

        m = re.match(r"^/panel/review/(\d+)$", path)
        if m:
            rid = safe_int(m.group(1))
            act = form_get(form, "action")
            if act == "delete":
                db.delete_review(rid)
                return self.redirect(f"/panel/reviews?ok=نظر حذف شد.")
            if act == "approve":
                db.update_review(rid, status="approved")
            elif act == "reject":
                db.update_review(rid, status="rejected")
            else:
                db.update_review(rid, reply=form_get(form, "reply"), status="approved")
            return self.redirect(f"/panel/reviews?ok=انجام شد.")

        # ---- bookings
        m = re.match(r"^/panel/booking/(\d+)$", path)
        if m:
            db.update_booking(safe_int(m.group(1)), status=form_get(form, "status", "new"))
            return self.redirect(f"/panel/bookings?ok=وضعیت نوبت به‌روزرسانی شد.")

        # ---- posts
        if path == "/panel/post/new":
            db.save_post({"title": form_get(form, "title"),
                          "excerpt": form_get(form, "excerpt"),
                          "body": form_get(form, "body")})
            return self.redirect(f"/panel/posts?ok=مطلب منتشر شد.")
        m = re.match(r"^/panel/post/(\d+)/delete$", path)
        if m:
            db.delete_post(safe_int(m.group(1)))
            return self.redirect(f"/panel/posts?ok=مطلب حذف شد.")

        # ---- messages
        m = re.match(r"^/panel/message/(\d+)$", path)
        if m:
            mid = safe_int(m.group(1))
            if form_get(form, "action") == "delete":
                db.delete_message(mid)
                return self.redirect(f"/panel/messages?ok=پیام حذف شد.")
            db.update_message(mid, status="read")
            return self.redirect(f"/panel/messages?ok=علامت‌گذاری شد.")

        # ---- static pages
        if path == "/panel/pages":
            db.save_page(form_get(form, "slug"), form_get(form, "title"),
                         form_get(form, "body"))
            return self.redirect(f"/panel/pages?ok=صفحه ذخیره شد.")

        # ---- appearance
        if path == "/panel/appearance":
            if form.get("reset"):
                db.set_settings({k: db.DEFAULT_SETTINGS[k] for k in
                                 ("color_primary","color_accent","color_background",
                                  "color_foreground","hero_title","hero_lead",
                                  "hero_cta","footer_note")})
                return self.redirect(f"/panel/appearance?ok=به پیش‌فرض بازگشت.")
            db.set_settings({
                "color_primary": form_get(form, "color_primary"),
                "color_accent": form_get(form, "color_accent"),
                "color_background": form_get(form, "color_background"),
                "color_foreground": form_get(form, "color_foreground"),
                "hero_title": form_get(form, "hero_title"),
                "hero_lead": form_get(form, "hero_lead"),
                "hero_cta": form_get(form, "hero_cta"),
                "footer_note": form_get(form, "footer_note"),
            })
            return self.redirect(f"/panel/appearance?ok=ظاهر سایت به‌روزرسانی شد.")

        # ---- settings
        if path == "/panel/settings":
            plain = ("site_url","site_name","tagline","description","phone","phone_raw","email",
                     "address","instagram","telegram","whatsapp","map_provider",
                     "gmaps_key","map_lat","map_lng","map_zoom",
                     "sms_key","sms_sender","sms_template",
                     "tg_token","tg_chat_id","ga_measurement_id")
            upd = {k: form_get(form, k) for k in plain if k in form}
            # audit F-013: the key fields render EMPTY in the form (masked),
            # so submitting them blank must keep the stored value; typing a
            # new value replaces it; the explicit checkbox clears the keys.
            SECRETS = ("sms_key", "tg_token", "gmaps_key")
            if form.get("clear_keys"):
                for k in SECRETS:
                    upd[k] = ""
            else:
                cur = db.get_settings()
                for k in SECRETS:
                    if k in upd and not str(upd[k]).strip() \
                            and str(cur.get(k) or "").strip():
                        del upd[k]
            # toggles only present on the features tab
            # One source of truth: if ANY feature toggle is present the request
            # came from the features tab, so save the whole group. Listing them
            # twice used to silently drop the newer switches.
            TOGGLES = ("reg_open", "reviews_moderated", "booking_enabled",
                       "blog_enabled", "maintenance",
                       "claims_enabled", "owner_login", "catalog_enabled",
                       "inquiry_enabled")
            if form.get("features_tab") or any(t in form for t in TOGGLES):
                for t in TOGGLES:
                    upd[t] = checkbox(form, t)
            db.set_settings(upd)
            return self.redirect(f"/panel/settings?ok=تنظیمات ذخیره شد.")

        if path == "/panel/rotate-token":
            new = db.rotate_owner_token()
            return self.redirect(f"/panel/settings?key={urllib.parse.quote(new)}"
                                 f"&ok=کلید جدید ساخته شد. این نشانی را ذخیره کنید.")

        # ---- panel password (set / change / clear)
        if path == "/panel/security":
            # v119: optional IP allowlist for the panel (defense-in-depth).
            # The field is always posted by the security tab; empty = open.
            if "panel_allow_ips" in form:
                raw = form_get(form, "panel_allow_ips", "")
                clean = ",".join(a.strip() for a in raw.replace(";", ",")
                                 .replace("\n", ",").split(",")
                                 if a.strip() and _looks_like_ip(a.strip()))
                db.set_settings({"panel_allow_ips": clean})
                self._PANEL_IP_CACHE = (None, 0.0)
                return self.redirect("/panel/settings?ok=" + urllib.parse.quote(
                    "فهرست آی‌پی‌های مجاز پنل ذخیره شد. خالی = همهٔ آی‌پی‌ها."))
            pw = form_get(form, "owner_password", "")
            if form.get("clear_password"):
                db.set_owner_pass("")
                db.admin_session_kill(self.cookies().get(self.ADMIN_COOKIE))
                self.set_cookie(self.ADMIN_COOKIE, "", days=0)
                return self.redirect(f"/panel/settings?ok=رمز عبور حذف شد؛ پنل فقط با کلید باز می‌شود.")
            if len(pw) < 6:
                return self.redirect(f"/panel/settings?err=رمز عبور باید دست‌کم ۶ نویسه باشد.")
            db.set_owner_pass(pw)
            self.set_cookie(self.ADMIN_COOKIE, db.admin_session_new())
            return self.redirect(f"/panel/settings?ok=رمز عبور پنل تنظیم شد. از این پس برای ورود لازم است.")

        # ---- media manager
        if path == "/panel/media/gc":
            refs = db.all_upload_refs()
            removed, freed = uploads.gc(refs)
            db.log("media.gc", f"-{removed} files, {freed} bytes")
            return self.redirect(f"/panel/media?ok=" + urllib.parse.quote(
                f"{removed} فایل بدون استفاده پاک شد ({freed // 1024} کیلوبایت)."))
        if path == "/panel/media/delete":
            target = form_get(form, "path", "")
            ok = uploads.delete_file(target) if target else False
            db.log("media.delete", (target or "")[:80])
            return self.redirect(f"/panel/media?ok=" + urllib.parse.quote(
                "فایل حذف شد." if ok else "فایل یافت نشد."))

        # ---- bulk actions on the business table
        if path == "/panel/businesses/bulk":
            raw = form.get("ids") or []
            ids = [int(x) for x in raw if str(x).isdigit()]
            act = form_get(form, "action")
            n = 0
            if act == "publish":
                n = db.bulk_business(ids, "status", "published")
            elif act == "hide":
                n = db.bulk_business(ids, "status", "hidden")
            elif act == "feature":
                n = db.bulk_business(ids, "featured", "1")
            elif act == "unfeature":
                n = db.bulk_business(ids, "featured", "0")
            elif act == "move":
                n = db.bulk_business(ids, "category", form_get(form, "cat_to"))
            elif act == "delete":
                n = db.bulk_business(ids, "delete")
            db.log("business.bulk", f"{act} x{n}")
            return self.redirect(f"/panel/businesses?ok="
                                 + urllib.parse.quote(f"{n} مورد به‌روزرسانی شد."))

        if path == "/panel/businesses/import":
            added, updated, errors = db.import_csv(form_get(form, "csv", ""))
            db.log("business.import", f"+{added} ~{updated} !{len(errors)}")
            return self.send(P.csv_import(s, tok, q=None,
                                          result=(added, updated, errors)))

        # ---- owners / claims / inquiries / catalog / gallery (admin)
        m = re.match(r"^/panel/owner/(\d+)$", path)
        if m:
            oid = safe_int(m.group(1))
            if form_get(form, "action") == "delete":
                db.delete_owner(oid)
                db.log("owner.delete", str(oid))
                return self.redirect(f"/panel/owners?ok="
                    + urllib.parse.quote("حساب حذف شد؛ کسب‌وکارهایش بدون مالک ماندند."))
            db.set_owner_status(oid, form_get(form, "status", "active"))
            return self.redirect(f"/panel/owners?ok=وضعیت کاربر تغییر کرد.")

        m = re.match(r"^/panel/claim/(\d+)$", path)
        if m:
            approve = form_get(form, "action") == "approve"
            db.claim_decide(safe_int(m.group(1)), approve)
            msg = "کسب‌وکار واگذار شد." if approve else "درخواست رد شد."
            return self.redirect(f"/panel/claims?ok={urllib.parse.quote(msg)}")

        m = re.match(r"^/panel/inquiry/(\d+)$", path)
        if m:
            self.inquiry_op(safe_int(m.group(1)), form, is_admin=True)
            return self.redirect(f"/panel/inquiries?ok=انجام شد.")

        m = re.match(r"^/panel/gallery/(\d+)/(delete|cover|banner)$", path)
        if m:
            self.gallery_op(safe_int(m.group(1)), m.group(2), form_get(form, "src"))
            return self.redirect(f"/panel/gallery/{m.group(1)}?ok=انجام شد.")

        m = re.match(r"^/panel/catalog/(\d+)/item/(new|\d+)$", path)
        if m:
            bid = safe_int(m.group(1))
            iid = None if m.group(2) == "new" else safe_int(m.group(2))
            self.save_item_from(form, bid, iid, None)
            return self.redirect(f"/panel/catalog/{bid}?ok=ذخیره شد.")

        m = re.match(r"^/panel/catalog/(\d+)/item/(\d+)/delete$", path)
        if m:
            db.delete_item(safe_int(m.group(2)))
            return self.redirect(f"/panel/catalog/{m.group(1)}?ok=حذف شد.")

        # ================================================================
        #  v3 admin actions
        # ================================================================

        # ---- questions
        m = re.match(r"^/panel/question/(\d+)$", path)
        if m:
            qid = safe_int(m.group(1))
            act = form_get(form, "action")
            if act == "delete":
                db.delete_question(qid)
                return self.redirect(f"/panel/qa?ok=پرسش حذف شد.")
            if act == "publish":
                db.set_question_status(qid, "published")
            elif act == "reject":
                db.set_question_status(qid, "rejected")
            else:
                ans = form_get(form, "answer").strip()
                if not ans:
                    return self.redirect(f"/panel/qa?err=متن پاسخ خالی است.")
                db.answer_question(qid, ans, by="admin")
            return self.redirect(f"/panel/qa?ok=انجام شد.")

        # ---- reports
        if path == "/panel/reports/bulk":          # v117/M4
            ids = [safe_int(x) for x in (form.get("ids") or [])
                   if str(x).isdigit()]
            act = form_get(form, "action")
            n = 0
            for rid in ids:
                if act == "delete":
                    db.delete_report(rid); n += 1
                else:
                    db.resolve_report(
                        rid, "dismissed" if act == "dismiss" else "resolved",
                        form_get(form, "note")); n += 1
            db.log("report.bulk", f"{act}:{n}")
            return self.redirect(f"/panel/reports?ok=" + urllib.parse.quote(
                f"{n} گزارش به‌روزرسانی شد."))

        m = re.match(r"^/panel/report/(\d+)$", path)
        if m:
            rid = safe_int(m.group(1))
            act = form_get(form, "action")
            if act == "delete":
                db.delete_report(rid)
                return self.redirect(f"/panel/reports?ok=گزارش حذف شد.")
            db.resolve_report(rid, "dismissed" if act == "dismiss" else "resolved",
                              form_get(form, "note"))
            return self.redirect(f"/panel/reports?ok=وضعیت گزارش به‌روزرسانی شد.")

        # ---- badges
        if path == "/panel/badge/new":
            name = form_get(form, "name")
            if not name:
                return self.redirect(f"/panel/badges?err=نام نشان الزامی است.")
            db.save_badge({"name": name, "icon": form_get(form, "icon", "award"),
                           "color": form_get(form, "color", "#059669"),
                           "descr": form_get(form, "descr"),
                           "active": checkbox(form, "active")})
            return self.redirect(f"/panel/badges?ok=نشان ساخته شد.")

        m = re.match(r"^/panel/badge/(\d+)$", path)
        if m:
            bid = safe_int(m.group(1))
            act = form_get(form, "action")
            if act == "delete":
                db.delete_badge(bid)
                return self.redirect(f"/panel/badges?ok=نشان حذف شد.")
            if act == "toggle":
                b = db.badge(bid=bid)
                if b:
                    db.save_badge({"name": b["name"], "icon": b["icon"],
                                   "color": b["color"], "descr": b["descr"],
                                   "sort": b["sort"],
                                   "active": 0 if b["active"] else 1}, bid)
                return self.redirect(f"/panel/badges?ok=وضعیت نشان تغییر کرد.")
            db.save_badge({"name": form_get(form, "name"),
                           "icon": form_get(form, "icon", "award"),
                           "color": form_get(form, "color", "#059669"),
                           "descr": form_get(form, "descr"),
                           "sort": form_get(form, "sort", "0"),
                           "active": checkbox(form, "active")}, bid)
            return self.redirect(f"/panel/badges?ok=نشان ذخیره شد.")

        if path == "/panel/badges/grant":
            bid = form_get(form, "biz_id")
            if bid.isdigit():
                ids = [x for x in (form.get("badge_ids") or []) if str(x).isdigit()]
                n = db.set_biz_badges(int(bid), ids)
                db.log("badge.grant", f"biz {bid} -> {n} badges")
                return self.redirect(f"/panel/badges?ok="
                    + urllib.parse.quote(f"{n} نشان برای این کسب‌وکار ثبت شد."))
            return self.redirect(f"/panel/badges?err=کسب‌وکار مشخص نیست.")

        if path == "/panel/badges/auto":
            n = db.auto_badges()
            return self.redirect(f"/panel/badges?ok="
                + urllib.parse.quote(f"{n} تغییر در نشان «برترین امتیاز» اعمال شد."))

        # ---- plans
        if path == "/panel/plan/new":
            if not form_get(form, "name"):
                return self.redirect(f"/panel/plans?err=نام پلن الزامی است.")
            db.save_plan({"name": form_get(form, "name"),
                          "tagline": form_get(form, "tagline"),
                          "price": form_get(form, "price", "0"),
                          "months": form_get(form, "months", "12"),
                          "featured_slots": form_get(form, "featured_slots", "0"),
                          "max_items": form_get(form, "max_items", "10"),
                          "max_photos": form_get(form, "max_photos", "6"),
                          "perks": form_get(form, "perks"),
                          "badge_slug": form_get(form, "badge_slug"),
                          "active": checkbox(form, "active")})
            return self.redirect(f"/panel/plans?ok=پلن ساخته شد.")

        m = re.match(r"^/panel/plan/(\d+)$", path)
        if m:
            pid = safe_int(m.group(1))
            if form_get(form, "action") == "delete":
                ok, msg = db.delete_plan(pid)
                kind = "ok" if ok else "err"
                return self.redirect(f"/panel/plans?{kind}={urllib.parse.quote(msg)}")
            db.save_plan({k: form_get(form, k) for k in
                          ("name", "tagline", "price", "months", "featured_slots",
                           "max_items", "max_photos", "perks", "badge_slug")}
                         | {"active": checkbox(form, "active")}, pid)
            return self.redirect(f"/panel/plans?ok=پلن ذخیره شد.")

        if path == "/panel/plans/payment":
            _card_raw = form_get(form, "pay_card")
            _fa_map = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
            _card_norm = "".join(c for c in _card_raw.translate(_fa_map) if c.isdigit())
            pay_upd = {
                "pay_method": form_get(form, "pay_method", "manual"),
                "pay_card": _card_norm,
                "pay_card_name": form_get(form, "pay_card_name"),
                "pay_bank": form_get(form, "pay_bank"),
            }
            # audit F-013: masked field — an empty submit keeps the stored
            # merchant id; only typing a new value replaces it.
            zm = form_get(form, "zarinpal_merchant").strip()
            if zm or not str(db.get_settings().get("zarinpal_merchant") or "").strip():
                pay_upd["zarinpal_merchant"] = zm
            db.set_settings(pay_upd)
            return self.redirect(f"/panel/plans?ok=روش پرداخت ذخیره شد.")

        # ---- subscriptions
        if path == "/panel/subscription/new":
            bid = form_get(form, "biz_id")
            ps = form_get(form, "plan_slug")
            if not bid.isdigit() or not ps:
                return self.redirect(f"/panel/subscriptions?err=کسب‌وکار و پلن الزامی است.")
            sid, msg = db.request_subscription(int(bid), ps, form_get(form, "ref"),
                                               "manual", "ثبت دستی توسط مدیر",
                                               months=form_get(form, "months"))
            if sid and form.get("activate"):
                db.activate_subscription(sid, months=form_get(form, "months"))
                msg = "اشتراک ثبت و فعال شد."
            return self.redirect(f"/panel/subscriptions?ok={urllib.parse.quote(msg)}")

        m = re.match(r"^/panel/subscription/(\d+)$", path)
        if m:
            sid = safe_int(m.group(1))
            act = form_get(form, "action")
            if act == "delete":
                db.delete_subscription(sid)
                return self.redirect(f"/panel/subscriptions?ok=ردیف حذف شد.")
            if act == "cancel":
                db.cancel_subscription(sid)
                return self.redirect(f"/panel/subscriptions?ok=اشتراک لغو شد.")
            if act == "reject":
                db.reject_subscription(sid)
                return self.redirect(f"/panel/subscriptions?ok=درخواست رد شد؛ هیچ مبلغی برداشت نشده بود.")
            db.activate_subscription(sid, months=form_get(form, "months"))
            sub = [x for x in db.subscriptions() if x["id"] == sid]
            if sub and sub[0].get("bizname"):
                b = db.business(bid=sub[0]["biz_id"])
                if b and b.get("phone"):
                    sms.notify(s, db.norm_phone(b["phone"]),
                               f"اشتراک «{b['name']}» در {s.get('site_name')} فعال شد.")
            return self.redirect(f"/panel/subscriptions?ok=اشتراک فعال شد.")

        # ---- ads
        m = re.match(r"^/panel/ad/(\d+)$", path)
        if m:
            aid = safe_int(m.group(1))
            act = form_get(form, "action")
            if act == "delete":
                a = db.ad(aid)
                if a and a.get("image"):
                    uploads.delete_image(a["image"])
                db.delete_ad(aid)
                return self.redirect(f"/panel/ads?ok=بنر حذف شد.")
            if act == "reset":
                db.reset_ad_stats(aid)
                return self.redirect(f"/panel/ads?ok=آمار بنر صفر شد.")
            a = db.ad(aid)
            if a:
                db.save_ad(dict(a, active=0 if a["active"] else 1), aid)
            return self.redirect(f"/panel/ads?ok=وضعیت بنر تغییر کرد.")

        # ---- events
        if path == "/panel/event/new":
            if not form_get(form, "title"):
                return self.redirect(f"/panel/events?err=عنوان رویداد الزامی است.")
            db.save_cityevent({k: form_get(form, k) for k in
                               ("title", "descr", "place", "date", "time", "biz_id")})
            return self.redirect(f"/panel/events?ok=رویداد ثبت شد.")

        m = re.match(r"^/panel/event/(\d+)$", path)
        if m:
            eid = safe_int(m.group(1))
            if form_get(form, "action") == "delete":
                db.delete_cityevent(eid)
                return self.redirect(f"/panel/events?ok=رویداد حذف شد.")
            db.save_cityevent({k: form_get(form, k) for k in
                               ("title", "descr", "place", "date", "time",
                                "biz_id", "status")}, eid)
            return self.redirect(f"/panel/events?ok=رویداد ذخیره شد.")

        # ---- edit approvals
        m = re.match(r"^/panel/edit/(\d+)$", path)
        if m:
            approve = form_get(form, "action") == "approve"
            db.decide_edit(safe_int(m.group(1)), approve)
            msg = "تغییرات اعمال شد." if approve else "درخواست رد شد."
            return self.redirect(f"/panel/edits?ok={urllib.parse.quote(msg)}")

        if path == "/panel/edits/toggle":
            cur = db.get_settings().get("edit_approval") == "1"
            db.set_setting("edit_approval", "0" if cur else "1")
            return self.redirect(f"/panel/edits?ok="
                + urllib.parse.quote("تأیید تغییرات " + ("خاموش شد." if cur else "روشن شد.")))

        # ---- feature unlocks (the admin's key)
        m = re.match(r"^/panel/unlock/(\d+)$", path)
        if m:
            bid = safe_int(m.group(1))
            if not db.business(bid=bid):   # v117/M2: no FK crash on bad ids
                return self.redirect("/panel/unlocks?err="
                                     + urllib.parse.quote(
                                         "کسب‌وکاری با این شناسه نیست."))
            act = form_get(form, "action")
            if act == "all":
                keys = list(db.FEATURE_LABELS)
            elif act == "none":
                keys = []
            else:
                keys = [x for x in (form.get("feat") or []) if x in db.FEATURE_LABELS]
            n = db.set_manual_grants(bid, keys)
            b = db.business(bid=bid)
            # tell the shopkeeper the good news
            if act in ("all", "save") and n and b and b.get("phone"):
                sms.notify(s, db.norm_phone(b["phone"]),
                           f"قابلیت‌های تازه‌ای در {s.get('site_name')} برای «{b['name']}» فعال شد.")
            return self.redirect(f"/panel/unlocks?ok="
                + urllib.parse.quote(f"{n} قابلیت برای این کسب‌وکار باز است."))

        if path == "/panel/unlocks/founder":
            upd = {}
            for f in ("founder_limit", "founder_max_items", "founder_max_photos",
                      "free_max_items", "free_max_photos"):
                v = form_get(form, f)
                if v.strip().isdigit():
                    upd[f] = v.strip()
            if upd:
                db.set_settings(upd)
            return self.redirect(f"/panel/unlocks?ok=تنظیمات ذخیره شد.")

        if path == "/panel/searches/clear":
            db.clear_searches()
            return self.redirect(f"/panel/insights?ok=آمار جست‌وجو پاک شد.")

        # ---- alerts
        m = re.match(r"^/panel/alert/(\d+)$", path)
        if m:
            aid = safe_int(m.group(1))
            if form_get(form, "action") == "delete":
                db.delete_alert(aid)
                return self.redirect(f"/panel/alerts?ok=هشدار حذف شد.")
            a = [x for x in db.alerts() if x["id"] == aid]
            if a:
                db.toggle_alert(aid, 0 if a[0]["active"] else 1)
            return self.redirect(f"/panel/alerts?ok=وضعیت هشدار تغییر کرد.")

        # ---- backup
        if path == "/panel/backup/import":
            try:
                payload = json.loads(form_get(form, "payload"))
                db.import_all(payload)
                return self.redirect(f"/panel/backup?ok=داده‌ها بازیابی شد.")
            except Exception as e:
                return self.redirect(f"/panel/backup?err="
                                     f"{urllib.parse.quote('فایل معتبر نیست: ' + str(e)[:60])}")

        return self.send(V.not_found(s, tok), 404)

    # -------------------------------------------------------------- plumbing
    def handle_one_request(self):
        """A browser closing a keep-alive socket is normal, not an error.
        Without this, every page load printed a ConnectionResetError stack
        trace and buried the real messages."""
        try:
            return super().handle_one_request()
        except (ConnectionResetError, BrokenPipeError, TimeoutError):
            self.close_connection = True

    # -------------------------------------------------------------- logging
    def log_message(self, fmt, *args):
        code = str(args[1]) if len(args) > 1 else ""
        if code.startswith(("4", "5")) and "favicon" not in str(args[0]):
            sys.stdout.write("  [%s] %s\n" % (code, args[0]))


class Server(ThreadingHTTPServer):
    daemon_threads = True
    # ---- v116-perf: the stock BaseHTTPServer backlog is 5(!) — under any
    # burst the kernel refused connections (measured: 2850 errors at 500
    # concurrent clients). 128 lets a spike queue instead of dropping.
    # v117/کارایی: با رمبش ۱۰۰۰ اتصال، صف ۱۲۸ سرریز کرد و ۹ اتصال ریست شد
    # (اندازه‌گیری دور ۱۸). ۵۱۲ یعنی اسپایک صف می‌شود، نه ریست.
    request_queue_size = 512
    # ---- v116-perf: unbounded handler threads meant 500 keep-alive clients
    # = 500 threads = 500 SQLite connections (2MB page cache each) = +242MB
    # RSS and seconds of latency. Cap concurrent workers; extra connections
    # simply wait in the kernel backlog. Override with BZ_MAX_WORKERS.
    MAX_WORKERS = int(os.environ.get("BZ_MAX_WORKERS", "64"))
    _slots = threading.BoundedSemaphore(MAX_WORKERS)

    def process_request(self, request, client_address):
        # Acquire BEFORE spawning the thread so a flood cannot create
        # unbounded threads; the accept loop parks here while the pool is
        # full and the kernel backlog holds the queue.
        self._slots.acquire()
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()

    def handle_error(self, request, client_address):
        """Same reasoning as handle_one_request: a dropped client socket is
        routine. Only real faults should reach the console."""
        exc = sys.exc_info()[1]
        if isinstance(exc, (ConnectionResetError, BrokenPipeError, TimeoutError)):
            return
        super().handle_error(request, client_address)


_CHAT_GC_EVERY = 3600            # re-check expired chat images hourly
_last_chat_gc = 0.0


def purge_expired_chat_images(days=None):
    """Delete chat images past the retention window -- bytes AND db rows.

    Runs at startup and then hourly on a long-lived server, so a photo leaves
    the disk about a week after it was sent. The query is sender-agnostic, so
    customer-sent and shopkeeper-sent images are purged on the same clock.
    """
    global _last_chat_gc
    _last_chat_gc = time.time()
    try:
        rows = db.expired_chat_attachments(
            db.CHAT_RETENTION_DAYS if days is None else days)
    except Exception:
        return 0
    if not rows:
        return 0
    for row in rows:
        try:
            uploads.delete_chat_file(row["stored_name"])
        except Exception:
            pass
    db.delete_chat_attachments([r["id"] for r in rows])
    try:
        db.log("chat.gc", f"purged {len(rows)} attachment(s) older than "
                          f"{db.CHAT_RETENTION_DAYS}d")
    except Exception:
        pass
    return len(rows)


def make_server(port, host="0.0.0.0"):
    db.init()
    # Attachment metadata cascades with deleted chats; clean old orphan bytes
    # outside the web root after a one-hour safety window.
    uploads.gc_chat_files(set(db.chat_attachment_names()), min_age_seconds=3600)
    # Drop chat images that have passed the 7-day retention window.
    purge_expired_chat_images()
    db.trash_purge()   # v105: hard-purge recycle-bin rows older than 7 days
    return Server((host, port), App)
