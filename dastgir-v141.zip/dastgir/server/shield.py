# -*- coding: utf-8 -*-
"""v112 abuse shield — request-level protection against bot storms & scanners.

چرا: محدودیت‌های قبلی فقط «سطحِ کنش» بودند (OTP/چت/سفارش/نظر). هیچ‌چیز نرخِ کلِ
درخواست‌ها را محدود نمی‌کرد، مسیرهای اسکنر را نمی‌بست، و نشان نمی‌داد چه کسی به
سایت می‌کوبد. در ۲۰۲۶ ترافیک بات از انسان پیشی گرفته و خزنده‌های تهاجمی می‌توانند
یک سرورِ هم‌اندازهٔ گوشی را زمین بزنند — پس سپر باید سه کار بکند:

  ۱) مسیر اسکنر (/.env, /wp-*, /phpmyadmin, …)  → 404 + strike؛ ۳ ضربه در ۶۰ ثانیه = ۳۰ دقیقه مسدود
  ۲) User-Agent ابزارهای مخرب/اسکنر             → 403 + strike؛ همان قانون مسدودی
  ۳) بیش از RATE_LIMIT درخواست در RATE_WINDOW   → 429؛ تکرار پشت‌سرهم = ۱۰ دقیقه مسدود

و یک گزارش زنده برای پنل (/panel/traffic) تا حدسِ «اسپم» با عدد ثابت شود.

فقط کتابخانهٔ استاندارد؛ شمارنده‌ها در حافظه‌اند (ری‌استارت یعنی شروع تازه — برای
سپر کافی است). هویت = `client_key()` همان تابع app.py: peer واقعی، و XFF فقط وقتی
peer لوپ‌بک است محترم شمرده می‌شود (تا مهاجم با چرخاندن هدر باکت را صفر نکند).

لوپ‌بک (مدیر محلی/تست‌ها) مستثنی است، مگر اینکه درخواست X-Forwarded-For داشته باشد
(که در آن صورت هویتِ جعلیِ تست است و مثل کلاینت دوردست رفتار می‌شود).
"""
import os
import re
import time
import threading
import urllib.parse
from collections import deque

_lock = threading.RLock()

RATE_LIMIT = int(os.environ.get("BZ_SHIELD_RATE", "120"))     # requests …
RATE_WINDOW = float(os.environ.get("BZ_SHIELD_WINDOW", "10")) # … per this many seconds
THROTTLE_BLOCK = 30   # throttled requests in a row => it is a storm, not a user
# Loopback (local admin / the test battery) is exempt below — unless the
# request itself carries X-Forwarded-For, which client_key() then treats as
# the identity, i.e. exactly how the abuse tests simulate a remote client.
BLOCK_RATE_S = 600     # 10 min after sustained throttling
BLOCK_SCAN_S = 1800    # 30 min after repeated scanning
STRIKE_WINDOW = 60.0
STRIKES_TO_BLOCK = 3

# vulnerability scanners / backup hunting / shell hunting
SCAN_RE = re.compile(
    r"^/(\.env|\.git|\.svn|\.hg|\.aws|\.ssh|\.vscode|\.idea|"
    r"wp-|wordpress|xmlrpc\.php|phpmyadmin|adminer|cgi-bin|vendor/|node_modules/|"
    r".*\.php(\?|$)|.*\.(sql|bak|old|orig)(\?|$)|config\.php|backup|"
    r"etc/passwd|proc/self|boot\.ini|telescope|actuator|console|solr|memcached)",
    re.I)

# attack tools + mass scanners. (Legitimate search crawlers are NOT here —
# the owner's complaint is abusive volume, not indexing.)
BAD_UA_RE = re.compile(
    r"(sqlmap|nikto|masscan|zgrab|nmap|nuclei|dirbuster|gobuster|ffuf|wpscan|"
    r"acunetix|nessus|openvas|havij|morfeus|grabber|whatweb)", re.I)

_hits = {}      # ident -> deque of request timestamps inside the window
_throttle = {}  # ident -> consecutive throttled requests
_strikes = {}   # ident -> deque of strike timestamps
_blocked = {}   # ident -> (until_ts, reason)
_events = deque(maxlen=120)          # (ts, ident, reason, path)
_recent = deque(maxlen=4000)         # (ts, ident, ua, path) for the traffic report
_stats = {"total": 0, "throttled": 0, "scan": 0, "badua": 0, "blocks": 0}

# audit F-003 (gen-2, phase 4): the dicts above only ever GREW — one key per
# distinct client IP, forever. Behind CGNAT and bot storms that is millions
# of keys on a long-lived server. A light sweep (<= every 5 min) retires
# state that has gone quiet; active blocks always survive until they expire.
_sweep_at = 0.0
SWEEP_EVERY = 300.0


def _sweep(now):
    stale = max(RATE_WINDOW, STRIKE_WINDOW) * 2
    for d in (_hits, _strikes):
        for k in [k for k, dq in d.items() if not dq or now - dq[-1] > stale]:
            del d[k]
    for k in [k for k, n in _throttle.items() if n <= 0]:
        _throttle.pop(k, None)
    for k in [k for k, (until, _r) in _blocked.items() if until <= now]:
        _blocked.pop(k, None)

_LOOPBACK = ("127.0.0.1", "::1", "localhost")


def _purge(dq, now, span):
    while dq and now - dq[0] > span:
        dq.popleft()


def _strike(ident, now, reason, path):
    dq = _strikes.setdefault(ident, deque())
    dq.append(now)
    _purge(dq, now, STRIKE_WINDOW)
    _events.append((now, ident, reason, path))
    if len(dq) >= STRIKES_TO_BLOCK:
        _blocked[ident] = (now + BLOCK_SCAN_S, reason)
        _stats["blocks"] += 1
        _events.append((now, ident, "block", path))


def check(handler):
    """Run at the top of every request. Returns None (pass) or (status, fa_msg)."""
    ident = handler.client_key()
    ua = (handler.headers.get("User-Agent") or "").strip()
    raw_path = urllib.parse.urlparse(handler.path).path or "/"
    now = time.time()
    with _lock:
        _stats["total"] += 1
        global _sweep_at
        if now - _sweep_at > SWEEP_EVERY:
            _sweep_at = now
            _sweep(now)
        _recent.append((now, ident, ua[:60], raw_path[:80]))
        # local admin / the test battery never lock themselves out — unless the
        # request itself carries a forged identity (XFF from loopback), which is
        # exactly how the abuse tests exercise the limits.
        if ident in _LOOPBACK:
            return None
        blk = _blocked.get(ident)
        if blk:
            if blk[0] > now:
                _stats["throttled"] += 1
                return 403, "دسترسی موقتاً مسدود است (رفتار غیرعادی)"
            _blocked.pop(ident, None)
        if SCAN_RE.search(raw_path):
            _stats["scan"] += 1
            _strike(ident, now, "scan", raw_path)
            return 404, "یافت نشد"
        if ua and BAD_UA_RE.search(ua):
            _stats["badua"] += 1
            _strike(ident, now, "badua", raw_path)
            return 403, "دسترسی غیرمجاز"
        dq = _hits.setdefault(ident, deque())
        _purge(dq, now, RATE_WINDOW)
        dq.append(now)
        if len(dq) > RATE_LIMIT:
            _stats["throttled"] += 1
            n = _throttle.get(ident, 0) + 1
            _throttle[ident] = n
            if n >= THROTTLE_BLOCK:      # kept slamming past the limit => storm
                _blocked[ident] = (now + BLOCK_RATE_S, "rate")
                _stats["blocks"] += 1
                _events.append((now, ident, "block-rate", raw_path))
            return 429, "تعداد درخواست زیاد است؛ چند ثانیه بعد دوباره"
        _throttle[ident] = 0
        return None


def unblock(ident):
    with _lock:
        return bool(_blocked.pop(ident, None))


def report():
    """Snapshot for /panel/traffic."""
    now = time.time()
    with _lock:
        per_ip, per_ua = {}, {}
        for ts, ident, ua, path in _recent:
            if now - ts > 600:
                continue
            per_ip[ident] = per_ip.get(ident, 0) + 1
            per_ua[ua or "(بدون User-Agent)"] = per_ua.get(ua or "(بدون User-Agent)", 0) + 1
        top_ip = sorted(per_ip.items(), key=lambda kv: -kv[1])[:10]
        top_ua = sorted(per_ua.items(), key=lambda kv: -kv[1])[:8]
        blocked = [(i, r, max(0, int(u - now))) for i, (u, r) in _blocked.items() if u > now]
        events = list(_events)[-25:]
        return {"stats": dict(_stats), "top_ip": top_ip, "top_ua": top_ua,
                "blocked": blocked, "events": events, "now": now,
                "limit": RATE_LIMIT, "window": int(RATE_WINDOW)}
