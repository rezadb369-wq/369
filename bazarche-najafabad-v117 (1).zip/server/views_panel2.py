# -*- coding: utf-8 -*-
"""
Admin screens for the v3 world-class features.

Every screen here is wired to a real table and a real POST route:
Q&A, reports, badges, plans, subscriptions, ads, city events,
edit approvals, saved alerts and whole-site insights.
"""

import json
import urllib.parse
import db
import uploads
import views_chat as CH
from ui import (icon, stars, fa, fa_group, esc, panel_page, stat_card, flash,
                empty_state)
from views_panel import _msg, ICON_CHOICES, _pg, panel_pager

UP_JS = '<script type="module" src="/assets/js/imagefield.js?v109"></script>'


def _empty(ic, title, text):
    return (f'<div class="empty-state"><span class="icon-wrap">{icon(ic)}</span>'
            f'<h3>{esc(title)}</h3><p>{esc(text)}</p></div>')


def _biz_options(selected=None, blank="— بدون کسب‌وکار —"):
    out = f'<option value="">{esc(blank)}</option>'
    for b in db.businesses(status=None, order="name"):
        sel = " selected" if str(selected or "") == str(b["id"]) else ""
        out += f'<option value="{b["id"]}"{sel}>{esc(b["name"])}</option>'
    return out


def _hidden(token, extra=""):
    return f'{extra}'


# ==========================================================================
#  QUESTIONS & ANSWERS
# ==========================================================================
Q_BADGE = {"pending": "badge-warn", "published": "badge-open", "rejected": "badge-closed"}
Q_LABEL = {"pending": "در انتظار", "published": "منتشرشده", "rejected": "رد شده"}


def qa_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or [""])[0]
    rows = db.questions(status=status or None)

    cards = "".join(f'''<article class="review">
      <div class="review-head">
        <span class="avatar" aria-hidden="true">{esc((r['asker'] or '?')[:1])}</span>
        <div style="flex:1"><strong>{esc(r['asker'])}</strong>
          <div class="card-meta" style="margin-top:3px">
            <a href="/b/{esc(r['bizslug'])}" target="_blank" rel="noopener">{esc(r['bizname'])}</a>
            <span aria-hidden="true">·</span>
            <span class="text-xs nums">{fa(str(r['created'])[:16])}</span>
            <span aria-hidden="true">·</span>
            <span class="text-xs">{fa(r['helpful'])} نفر مفید دانستند</span></div></div>
        <span class="badge {Q_BADGE.get(r['status'],'badge-neutral')}">{esc(Q_LABEL.get(r['status'], r['status']))}</span>
      </div>
      <p class="review-body">{esc(r['body'])}</p>
      {f'<div class="review-reply"><strong>{icon("store")}پاسخ</strong>{esc(r["answer"])}</div>' if r['answer'] else ''}
      <form method="post" action="/panel/question/{r['id']}" class="mt-md">
        {_hidden(token)}
        <label class="sr-only" for="qa{r['id']}">پاسخ به پرسش</label>
        <textarea class="textarea" id="qa{r['id']}" name="answer" style="min-height:80px"
          placeholder="پاسخ شما به این پرسش…">{esc(r['answer'])}</textarea>
        <div class="cluster mt-sm">
          <button class="btn btn-primary btn-sm" type="submit" name="action" value="answer">
            {icon("send")}<span>ثبت پاسخ و انتشار</span></button>
          <button class="btn btn-glass btn-sm" type="submit" name="action" value="publish">
            {icon("check")}<span>انتشار بدون پاسخ</span></button>
          <button class="btn btn-glass btn-sm" type="submit" name="action" value="reject">
            {icon("x")}<span>رد</span></button>
          <button class="btn btn-ghost btn-sm" type="submit" name="action" value="delete"
            style="color:var(--color-destructive)">{icon("trash")}<span>حذف</span></button>
        </div>
      </form></article>''' for r in rows)

    if not cards:
        cards = _empty("help", "پرسشی در این بخش نیست",
                       "وقتی بازدیدکنندگان از یک کسب‌وکار سؤال بپرسند، اینجا می‌آید.")

    filt = "".join(f'<a class="chip{" is-active" if status==v else ""}" '
                   f'href="/panel/qa?status={v}">{t}</a>'
                   for v, t in [("", "همه"), ("pending", "در انتظار"),
                                ("published", "منتشرشده"), ("rejected", "رد شده")])
    content = f'''{_msg(q)}
<div class="cluster mb-lg">{filt}</div>
<div class="card glass card-pad">{cards}</div>'''
    return panel_page(s, "پرسش و پاسخ",
                      "سؤال‌های مشتریان دربارهٔ کسب‌وکارها را پاسخ دهید یا منتشر کنید.",
                      content, "/panel/qa", token)


# ==========================================================================
#  REPORTS
# ==========================================================================
R_BADGE = {"open": "badge-warn", "resolved": "badge-open", "dismissed": "badge-closed"}
R_LABEL = {"open": "باز", "resolved": "رسیدگی‌شده", "dismissed": "رد شده"}
KIND_LABEL = {"business": "کسب‌وکار", "review": "نظر", "item": "کالا/خدمت", "question": "پرسش"}


def report_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or [""])[0]
    page = _pg(q)
    res = db.reports(status=status or None, page=page)
    rows, pages = res["rows"], res["pages"]

    trs = "".join(f'''<tr>
      <td><input type="checkbox" form="bulk-rp" name="ids" value="{r['id']}" aria-label="انتخاب گزارش {r['id']}"></td>
      <td><span class="badge badge-neutral">{esc(KIND_LABEL.get(r['kind'], r['kind']))}</span></td>
      <td><strong>{esc(db.reason_label(r['reason']))}</strong>
        {f'<br><small class="text-muted">{esc(r["body"][:110])}</small>' if r['body'] else ''}</td>
      <td>{f'<a href="/b/{esc(r["bizslug"])}" target="_blank" rel="noopener">{esc(r["bizname"])}</a>' if r.get('bizslug') else '<span class="text-muted">—</span>'}</td>
      <td class="nums">{esc(r['reporter']) or '<span class="text-muted">ناشناس</span>'}</td>
      <td class="num nums">{fa(str(r['created'])[:10])}</td>
      <td><span class="badge {R_BADGE.get(r['status'],'badge-neutral')}">{esc(R_LABEL.get(r['status'], r['status']))}</span></td>
      <td class="actions">
        <form method="post" action="/panel/report/{r['id']}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="resolve">
          <button class="btn-icon btn-approve" type="submit" title="رسیدگی شد"
            aria-label="رسیدگی به گزارش {r['id']}">{icon("check-circle")}</button></form>
        <form method="post" action="/panel/report/{r['id']}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="dismiss">
          <button class="btn-icon" type="submit" title="بی‌مورد است"
            aria-label="رد گزارش {r['id']}">{icon("x-circle")}</button></form>
        {f'<a class="btn-icon" href="/panel/business/{r["biz_id"]}" title="ویرایش کسب‌وکار" aria-label="ویرایش">{icon("edit")}</a>' if r.get('biz_id') else ''}
        <form method="post" action="/panel/report/{r['id']}" style="display:inline"
              data-confirm="این گزارش حذف شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف" aria-label="حذف گزارش {r['id']}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for r in rows)

    if not trs:
        trs = ('<tr><td colspan="8" class="text-center text-muted" '
               'style="padding:var(--space-xl)">گزارشی ثبت نشده — یعنی اطلاعات سایت سالم است.</td></tr>')

    bulk_rp = f'''<form id="bulk-rp" method="post" action="/panel/reports/bulk" class="bulk-bar">
      <label class="chip" data-check-all="form:bulk-rp"><input type="checkbox" aria-label="انتخاب همه"> همه</label>
      <select class="select" name="action" aria-label="عملیات گروهی">
        <option value="resolve">رسیدگی شد</option>
        <option value="dismiss">بی‌مورد</option>
        <option value="delete">حذف</option>
      </select>
      <button class="btn btn-primary btn-sm" type="submit">{icon("zap")}<span>اجرا روی انتخاب‌شده‌ها</span></button>
    </form>'''

    filt = "".join(f'<a class="chip{" is-active" if status==v else ""}" '
                   f'href="/panel/reports?status={v}">{t}</a>'
                   for v, t in [("", "همه"), ("open", "باز"),
                                ("resolved", "رسیدگی‌شده"), ("dismissed", "رد شده")])
    content = f'''{_msg(q)}
{bulk_rp}
{panel_pager("/panel/reports", page, pages)}
<div class="cluster mb-lg">{filt}</div>
<div class="card glass card-pad">
  <div class="table-wrap"><table class="table">
    <thead><tr><th aria-label="انتخاب"></th><th>نوع</th><th>دلیل</th><th>کسب‌وکار</th><th>گزارش‌دهنده</th>
      <th>تاریخ</th><th>وضعیت</th><th>عملیات</th></tr></thead>
    <tbody>{trs}</tbody></table></div></div>'''
    return panel_page(s, "گزارش تخلف",
                      "گزارش کاربران دربارهٔ اطلاعات نادرست، تعطیلی یا محتوای نامناسب.",
                      content, "/panel/reports", token)


# ==========================================================================
#  BADGES
# ==========================================================================
def badge_list(s, token, q=None):
    q = q or {}
    rows = db.badges(only_active=False)
    icon_opts = "".join(f'<option value="{i}">{i}</option>' for i in ICON_CHOICES + ["award", "zap", "clock", "users", "shield", "star", "heart", "target", "trending"])

    trs = "".join(f'''<tr>
      <td><span class="badge" style="--bz:{esc(b['color'])};background:color-mix(in oklab,var(--bz) 12%,transparent);border-color:color-mix(in oklab,var(--bz) 30%,transparent);color:color-mix(in oklab,var(--bz) 70%,var(--color-foreground))">
        {icon(b['icon'] if b['icon'] in ICON_CHOICES + ["award","zap","clock","users","shield","star","heart","target","trending"] else "award")}
        <span>{esc(b['name'])}</span></span></td>
      <td><small class="text-muted">{esc(b['descr'])[:70]}</small></td>
      <td class="num">{fa(b['count'])}</td>
      <td><span class="badge {"badge-open" if b['active'] else "badge-neutral"}">
        {"فعال" if b['active'] else "غیرفعال"}</span></td>
      <td class="actions">
        <form method="post" action="/panel/badge/{b['id']}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="toggle">
          <button class="btn-icon" type="submit" title="فعال/غیرفعال"
            aria-label="تغییر وضعیت {esc(b['name'])}">{icon("eye")}</button></form>
        <form method="post" action="/panel/badge/{b['id']}" style="display:inline"
              data-confirm="نشان «{esc(b['name'])}» و همهٔ اعطاهایش حذف شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف" aria-label="حذف {esc(b['name'])}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for b in rows)
    if not trs:
        trs = '<tr><td colspan="5" class="text-center text-muted">نشانی تعریف نشده</td></tr>'

    # grant/revoke panel
    bizs = db.businesses(status=None, order="name")
    bmap = db.badges_map()
    grant_rows = "".join(f'''<tr>
      <td><strong>{esc(b['name'])}</strong></td>
      <td><form method="post" action="/panel/badges/grant" class="cluster" style="gap:6px;flex-wrap:wrap">
        {_hidden(token)}<input type="hidden" name="biz_id" value="{b['id']}">
        {"".join(f"""<label class="check" style="margin:0"><input type="checkbox" name="badge_ids" value="{bg['id']}"
          {'checked' if bg['id'] in [x['id'] for x in bmap.get(b['id'], [])] else ''}><span>{esc(bg['name'])}</span></label>"""
          for bg in db.badges())}
        <button class="btn btn-primary btn-sm" type="submit">{icon("check")}<span>ذخیره</span></button>
      </form></td></tr>''' for b in bizs[:60])
    if not grant_rows:
        grant_rows = '<tr><td colspan="2" class="text-center text-muted">هنوز کسب‌وکاری ثبت نشده</td></tr>'

    content = f'''{_msg(q)}
<div class="grid grid-2 mb-lg" style="grid-template-columns:minmax(0,1fr) minmax(0,340px);align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("award")} نشان‌های تعریف‌شده</h2>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>نشان</th><th>توضیح</th><th>تعداد</th><th>وضعیت</th><th>عملیات</th></tr></thead>
      <tbody>{trs}</tbody></table></div>
    <form method="post" action="/panel/badges/auto" class="mt-lg">
      {_hidden(token)}
      <button class="btn btn-glass btn-sm" type="submit">{icon("refresh")}
        <span>محاسبهٔ خودکار نشان «برترین امتیاز»</span></button>
      <p class="field-hint mt-sm">کسب‌وکارهایی با امتیاز ۴٫۵ به بالا و دست‌کم ۱۰ نظر، نشان می‌گیرند؛ بقیه پس گرفته می‌شود.</p>
    </form>
  </div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("plus")} نشان جدید</h2>
    <form method="post" action="/panel/badge/new" data-validate>
      {_hidden(token)}
      <div class="field"><label class="field-label" for="bg-name">نام نشان<span class="req">*</span></label>
        <input class="input" id="bg-name" name="name" required placeholder="ارسال رایگان"></div>
      <div class="field"><label class="field-label" for="bg-desc">توضیح</label>
        <input class="input" id="bg-desc" name="descr" placeholder="برای خرید بالای ۵۰۰ هزار تومان"></div>
      <div class="field"><label class="field-label" for="bg-icon">آیکون</label>
        <select class="select" id="bg-icon" name="icon">{icon_opts}</select></div>
      <div class="field"><label class="field-label" for="bg-color">رنگ</label>
        <input class="input" id="bg-color" name="color" type="color" value="#059669"></div>
      <label class="check mb-lg"><input type="checkbox" name="active" checked><span>فعال باشد</span></label>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>ایجاد نشان</span></button>
    </form>
  </div>
</div>
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("store")} اعطای نشان به کسب‌وکارها</h2>
  <div class="table-wrap"><table class="table">
    <thead><tr><th style="width:220px">کسب‌وکار</th><th>نشان‌ها</th></tr></thead>
    <tbody>{grant_rows}</tbody></table></div>
</div>'''
    return panel_page(s, "نشان‌ها و اعتماد",
                      "نشان‌های سفارشی بسازید و به کسب‌وکارهای شایسته بدهید.",
                      content, "/panel/badges", token)


# ==========================================================================
#  PLANS & SUBSCRIPTIONS
# ==========================================================================
S_BADGE = {"pending": "badge-warn", "active": "badge-open",
           "expired": "badge-closed", "cancelled": "badge-neutral"}
S_LABEL = {"pending": "در انتظار پرداخت", "active": "فعال",
           "expired": "منقضی", "cancelled": "لغو شده"}


def plan_list(s, token, q=None):
    q = q or {}
    rows = db.plans(only_active=False)
    badge_opts = '<option value="">— بدون نشان —</option>' + "".join(
        f'<option value="{esc(b["slug"])}">{esc(b["name"])}</option>' for b in db.badges())

    cards = "".join(f'''<form class="card glass card-pad" method="post" action="/panel/plan/{p['id']}">
      {_hidden(token)}
      <div class="between mb-md"><h3 class="card-title">{icon("wallet")} {esc(p['name'])}</h3>
        <span class="badge {"badge-open" if p['active'] else "badge-neutral"}">
          {"فعال" if p['active'] else "غیرفعال"}</span></div>
      <div class="grid grid-2" style="gap:10px">
        <div class="field" style="margin:0"><label class="field-label" for="pn{p['id']}">نام</label>
          <input class="input" id="pn{p['id']}" name="name" value="{esc(p['name'])}"></div>
        <div class="field" style="margin:0"><label class="field-label" for="pt{p['id']}">شعار کوتاه</label>
          <input class="input" id="pt{p['id']}" name="tagline" value="{esc(p.get('tagline',''))}"
                 placeholder="مناسب کسب‌وکارهای فعال"></div>
        <div class="field" style="margin:0"><label class="field-label" for="pp{p['id']}">قیمت (تومان)</label>
          <input class="input nums" id="pp{p['id']}" name="price" type="number" min="0" value="{p['price']}"></div>
        <div class="field" style="margin:0"><label class="field-label" for="pm{p['id']}">مدت (ماه)</label>
          <input class="input nums" id="pm{p['id']}" name="months" type="number" min="1" value="{p['months']}"></div>
        <div class="field" style="margin:0"><label class="field-label" for="pf{p['id']}">جایگاه ویژه</label>
          <input class="input nums" id="pf{p['id']}" name="featured_slots" type="number" min="0" value="{p['featured_slots']}"></div>
        <div class="field" style="margin:0"><label class="field-label" for="pi{p['id']}">حداکثر کالا</label>
          <input class="input nums" id="pi{p['id']}" name="max_items" type="number" min="1" value="{p['max_items']}"></div>
        <div class="field" style="margin:0"><label class="field-label" for="ph{p['id']}">حداکثر تصویر</label>
          <input class="input nums" id="ph{p['id']}" name="max_photos" type="number" min="1" value="{p['max_photos']}"></div>
      </div>
      <div class="field mt-md"><label class="field-label" for="pb{p['id']}">نشان همراه پلن</label>
        <select class="select" id="pb{p['id']}" name="badge_slug">{badge_opts.replace(f'value="{esc(p["badge_slug"])}"', f'value="{esc(p["badge_slug"])}" selected') if p['badge_slug'] else badge_opts}</select></div>
      <div class="field"><label class="field-label" for="pk{p['id']}">امکانات (هر خط یک مورد)</label>
        <textarea class="textarea" id="pk{p['id']}" name="perks" style="min-height:150px">{esc(p['perks'])}</textarea></div>
      <label class="check mb-md"><input type="checkbox" name="active" {"checked" if p['active'] else ""}><span>در صفحهٔ تعرفه نمایش داده شود</span></label>
      <div class="cluster">
        <button class="btn btn-primary btn-sm" type="submit" name="action" value="save">
          {icon("check")}<span>ذخیره</span></button>
        <button class="btn btn-ghost btn-sm" type="submit" name="action" value="delete"
          style="color:var(--color-destructive)"
          onclick="return confirm('پلن حذف شود؟')">{icon("trash")}<span>حذف</span></button>
      </div>
    </form>''' for p in rows)

    if not cards:
        cards = _empty("wallet", "پلنی تعریف نشده", "با فرم کناری اولین پلن را بسازید.")

    content = f'''{_msg(q)}
<div class="grid grid-2 mb-lg" style="grid-template-columns:minmax(0,1fr) minmax(0,320px);align-items:start">
  <div class="grid" style="gap:var(--space-lg)">{cards}</div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("plus")} پلن جدید</h2>
    <form method="post" action="/panel/plan/new" data-validate>
      {_hidden(token)}
      <div class="field"><label class="field-label" for="np-name">نام پلن<span class="req">*</span></label>
        <input class="input" id="np-name" name="name" required placeholder="طلایی"></div>
      <div class="field"><label class="field-label" for="np-tag">شعار کوتاه</label>
        <input class="input" id="np-tag" name="tagline" placeholder="مناسب کسب‌وکارهای بزرگ"></div>
      <div class="field"><label class="field-label" for="np-price">قیمت (تومان)</label>
        <input class="input nums" id="np-price" name="price" type="number" min="0" value="0"></div>
      <div class="field"><label class="field-label" for="np-months">مدت (ماه)</label>
        <input class="input nums" id="np-months" name="months" type="number" min="1" value="12"></div>
      <div class="field"><label class="field-label" for="np-perks">امکانات</label>
        <textarea class="textarea" id="np-perks" name="perks" style="min-height:90px"
          placeholder="هر خط یک مورد"></textarea></div>
      <label class="check mb-lg"><input type="checkbox" name="active" checked><span>فعال</span></label>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>ایجاد پلن</span></button>
    </form>
    <hr class="divider">
    <h3 class="card-title mb-md">{icon("credit-card")} روش پرداخت</h3>
    <form method="post" action="/panel/plans/payment">
      {_hidden(token)}
      <div class="field"><label class="field-label" for="pay-m">روش</label>
        <select class="select" id="pay-m" name="pay_method">
          <option value="manual"{" selected" if s.get("pay_method")!="zarinpal" else ""}>کارت‌به‌کارت با تأیید مدیر</option>
          <option value="zarinpal"{" selected" if s.get("pay_method")=="zarinpal" else ""}>زرین‌پال (نیازمند کد پذیرنده)</option>
        </select></div>
      <div class="field"><label class="field-label" for="pay-c">شمارهٔ کارت</label>
        <input class="input nums" id="pay-c" name="pay_card" dir="ltr"
               value="{esc(s.get('pay_card',''))}" placeholder="6037-9900-0000-0000"></div>
      <div class="field"><label class="field-label" for="pay-n">نام صاحب کارت</label>
        <input class="input" id="pay-n" name="pay_card_name" value="{esc(s.get('pay_card_name',''))}"></div>
      <div class="field"><label class="field-label" for="pay-z">کد پذیرندهٔ زرین‌پال</label>
        <input class="input" id="pay-z" name="zarinpal_merchant" dir="ltr" autocomplete="off"
               value="" placeholder="{('(ذخیره شده — برای تغییر، مقدار تازه بنویسید)') if (s.get('zarinpal_merchant') or '').strip() else 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'}"></div>
      <button class="btn btn-glass btn-block" type="submit">{icon("check")}<span>ذخیرهٔ روش پرداخت</span></button>
    </form>
  </div>
</div>'''
    return panel_page(s, "پلن‌ها و تعرفه",
                      "پلن‌های اشتراک واقعی؛ آنچه اینجا تعریف کنید در صفحهٔ تعرفه دیده می‌شود.",
                      content, "/panel/plans", token)


def sub_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or [""])[0]
    n_exp = db.expire_subscriptions()
    page = _pg(q)
    res = db.subscriptions(status=status or None, page=page)
    rows, pages = res["rows"], res["pages"]
    soon = db.expiring_soon(14)

    trs = "".join(f'''<tr>
      <td><a href="/b/{esc(r['bizslug'])}" target="_blank" rel="noopener"><strong>{esc(r['bizname'])}</strong></a></td>
      <td>{esc(r.get('planname') or r['plan_slug'])}</td>
      <td class="num nums">{fa_group(r['amount'])}</td>
      <td class="num nums">{fa(r['starts']) if r['starts'] else '—'}</td>
      <td class="num nums">{fa(r['expires']) if r['expires'] else '—'}
        {f'<br><small class="text-muted">{fa(r["days_left"])} روز مانده</small>' if r.get('days_left') is not None and r['status']=='active' else ''}</td>
      <td class="nums">{esc(r['ref']) or '<span class="text-muted">—</span>'}</td>
      <td><span class="badge {S_BADGE.get(r['status'],'badge-neutral')}">{esc(S_LABEL.get(r['status'], r['status']))}</span></td>
      <td class="actions">
        {f"""<form method="post" action="/panel/subscription/{r["id"]}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="activate">
          <button class="btn-icon btn-approve" type="submit" title="تأیید پرداخت و فعال‌سازی"
            aria-label="فعال‌سازی اشتراک {esc(r["bizname"])}">{icon("check-circle")}</button></form>""" if r['status'] in ('pending','expired','cancelled') else ''}
        {f"""<form method="post" action="/panel/subscription/{r["id"]}" style="display:inline"
              data-confirm="اشتراک «{esc(r["bizname"])}» لغو شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="cancel">
          <button class="btn-icon" type="submit" title="لغو اشتراک"
            aria-label="لغو اشتراک {esc(r["bizname"])}">{icon("x-circle")}</button></form>""" if r['status']=='active' else ''}
        <form method="post" action="/panel/subscription/{r['id']}" style="display:inline"
              data-confirm="این ردیف حذف شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف" aria-label="حذف ردیف {r['id']}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for r in rows)
    if not trs:
        trs = ('<tr><td colspan="8" class="text-center text-muted" '
               'style="padding:var(--space-xl)">اشتراکی ثبت نشده</td></tr>')

    warn = ""
    if soon:
        items = "".join(f'<li>{esc(x["bizname"])} — {fa(x["days_left"])} روز تا انقضا</li>' for x in soon)
        warn = (f'<div class="alert alert-warn mb-lg">{icon("bell")}<span>'
                f'<strong>{fa(len(soon))} اشتراک نزدیک به انقضا:</strong><ul style="margin:6px 0 0;padding-inline-start:18px">{items}</ul>'
                f'</span></div>')
    if n_exp:
        warn = flash("info", f"{n_exp} اشتراک منقضی شد و امتیازهایش برداشته شد.") + warn

    revenue = sum(r["amount"] for r in db.subscriptions(status="active"))
    pending_n = len(db.subscriptions(status="pending"))
    live_n = len([r for r in db.subscriptions(status="active") if r["is_live"]])

    filt = "".join(f'<a class="chip{" is-active" if status==v else ""}" '
                   f'href="/panel/subscriptions?status={v}">{t}</a>'
                   for v, t in [("", "همه"), ("pending", "در انتظار پرداخت"),
                                ("active", "فعال"), ("expired", "منقضی"),
                                ("cancelled", "لغو شده")])

    bizopts = _biz_options(blank="— انتخاب کسب‌وکار —")
    planopts = "".join(f'<option value="{esc(p["slug"])}">{esc(p["name"])} — '
                       f'{fa_group(p["price"])} تومان</option>' for p in db.plans())

    content = f'''{_msg(q)}{warn}
{panel_pager("/panel/subscriptions", page, pages)}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("check-circle", live_n, "اشتراک فعال")}
  {stat_card("clock", pending_n, "در انتظار پرداخت", delay=60)}
  {stat_card("wallet", revenue, "درآمد فعال (تومان)", delay=120)}
  {stat_card("bell", len(soon), "نزدیک انقضا", delay=180)}
</div>
<div class="cluster mb-lg">{filt}</div>
<div class="card glass card-pad mb-lg">
  <div class="table-wrap"><table class="table">
    <thead><tr><th>کسب‌وکار</th><th>پلن</th><th>مبلغ</th><th>شروع</th><th>انقضا</th>
      <th>کد پیگیری</th><th>وضعیت</th><th>عملیات</th></tr></thead>
    <tbody>{trs}</tbody></table></div>
</div>
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("plus")} ثبت اشتراک دستی</h2>
  <form method="post" action="/panel/subscription/new" class="grid grid-3" style="align-items:end" data-validate>
    {_hidden(token)}
    <div class="field" style="margin:0"><label class="field-label" for="sb-biz">کسب‌وکار<span class="req">*</span></label>
      <select class="select" id="sb-biz" name="biz_id" required>{bizopts}</select></div>
    <div class="field" style="margin:0"><label class="field-label" for="sb-plan">پلن<span class="req">*</span></label>
      <select class="select" id="sb-plan" name="plan_slug" required>{planopts}</select></div>
    <div class="field" style="margin:0"><label class="field-label" for="sb-ref">کد پیگیری پرداخت</label>
      <input class="input nums" id="sb-ref" name="ref" placeholder="اختیاری"></div>
    <label class="check" style="margin:0"><input type="checkbox" name="activate" checked>
      <span>بلافاصله فعال شود</span></label>
    <button class="btn btn-primary" type="submit">{icon("plus")}<span>ثبت اشتراک</span></button>
  </form>
</div>'''
    return panel_page(s, "اشتراک‌ها",
                      "پرداخت‌ها را تأیید کنید؛ فعال‌سازی، انقضا و نشان‌ها خودکار اعمال می‌شود.",
                      content, "/panel/subscriptions", token)


# ==========================================================================
#  ADS
# ==========================================================================
SLOTS = [("home", "صفحهٔ نخست"), ("directory", "فهرست کسب‌وکارها"),
         ("business", "صفحهٔ کسب‌وکار"), ("sidebar", "ستون کناری")]


def ad_list(s, token, q=None):
    q = q or {}
    rows = db.ads()
    tot_v = sum(a["views"] for a in rows)
    tot_c = sum(a["clicks"] for a in rows)
    ctr = round(tot_c * 100.0 / tot_v, 1) if tot_v else 0

    trs = "".join(f'''<tr>
      <td><strong>{esc(a['title'])}</strong>
        {f'<br><small class="text-muted">{esc(a["body"])[:70]}</small>' if a['body'] else ''}</td>
      <td>{esc(dict(SLOTS).get(a['slot'], a['slot']))}</td>
      <td>{esc(a.get('bizname') or '—')}</td>
      <td class="num nums">{fa_group(a['views'])}</td>
      <td class="num nums">{fa_group(a['clicks'])}</td>
      <td class="num nums">{fa(a['ctr'])}٪</td>
      <td><span class="badge {"badge-open" if a['active'] else "badge-neutral"}">
        {"فعال" if a['active'] else "غیرفعال"}</span></td>
      <td class="actions">
        <form method="post" action="/panel/ad/{a['id']}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="toggle">
          <button class="btn-icon" type="submit" title="فعال/غیرفعال"
            aria-label="تغییر وضعیت {esc(a['title'])}">{icon("eye")}</button></form>
        <form method="post" action="/panel/ad/{a['id']}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="reset">
          <button class="btn-icon" type="submit" title="صفر کردن آمار"
            aria-label="صفر کردن آمار {esc(a['title'])}">{icon("refresh")}</button></form>
        <form method="post" action="/panel/ad/{a['id']}" style="display:inline"
              data-confirm="بنر «{esc(a['title'])}» حذف شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف" aria-label="حذف {esc(a['title'])}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for a in rows)
    if not trs:
        trs = ('<tr><td colspan="8" class="text-center text-muted" '
               'style="padding:var(--space-xl)">بنری ساخته نشده</td></tr>')

    slot_opts = "".join(f'<option value="{v}">{t}</option>' for v, t in SLOTS)

    content = f'''{_msg(q)}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("eye", tot_v, "نمایش کل")}
  {stat_card("target", tot_c, "کلیک کل", delay=60)}
  {stat_card("trending", ctr, "نرخ کلیک", suffix="٪", delay=120)}
  {stat_card("zap", len([a for a in rows if a['active']]), "بنر فعال", delay=180)}
</div>
<div class="grid grid-2" style="grid-template-columns:minmax(0,1fr) minmax(0,340px);align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("zap")} بنرهای تبلیغاتی</h2>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>عنوان</th><th>جایگاه</th><th>کسب‌وکار</th><th>نمایش</th>
        <th>کلیک</th><th>نرخ</th><th>وضعیت</th><th>عملیات</th></tr></thead>
      <tbody>{trs}</tbody></table></div>
    <p class="field-hint mt-md">{icon("info")} شمارش نمایش و کلیک واقعی است؛ هر بار بنر رندر شود «نمایش» و هر بار کاربر روی آن بزند «کلیک» بالا می‌رود.</p>
  </div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("plus")} بنر جدید</h2>
    <form method="post" action="/panel/ad/new" enctype="multipart/form-data" data-validate>
      {_hidden(token)}
      <div class="field"><label class="field-label" for="ad-t">عنوان<span class="req">*</span></label>
        <input class="input" id="ad-t" name="title" required placeholder="افتتاحیهٔ شعبهٔ جدید"></div>
      <div class="field"><label class="field-label" for="ad-b">متن کوتاه</label>
        <textarea class="textarea" id="ad-b" name="body" style="min-height:70px"></textarea></div>
      <div class="field"><label class="field-label" for="ad-u">لینک مقصد</label>
        <input class="input" id="ad-u" name="url" dir="ltr" placeholder="/b/slug یا https://…"></div>
      <div class="field"><label class="field-label" for="ad-s">جایگاه</label>
        <select class="select" id="ad-s" name="slot">{slot_opts}</select></div>
      <div class="field"><label class="field-label" for="ad-z">کسب‌وکار مرتبط</label>
        <select class="select" id="ad-z" name="biz_id">{_biz_options()}</select></div>
      <div class="grid grid-2" style="gap:10px">
        <div class="field" style="margin:0"><label class="field-label" for="ad-st">شروع</label>
          <input class="input nums" id="ad-st" name="starts" type="date"></div>
        <div class="field" style="margin:0"><label class="field-label" for="ad-en">پایان</label>
          <input class="input nums" id="ad-en" name="ends" type="date"></div>
      </div>
      <div class="field"><label class="field-label" for="ad-w">وزن نمایش</label>
        <input class="input nums" id="ad-w" name="weight" type="number" min="1" max="10" value="1">
        <p class="field-hint">هرچه بیشتر، بیشتر نمایش داده می‌شود.</p></div>
      <div class="field"><label class="field-label" for="ad-img">تصویر بنر</label>
        <input class="input" id="ad-img" name="image" type="file" accept="image/*"></div>
      <label class="check mb-lg"><input type="checkbox" name="active" checked><span>فعال باشد</span></label>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>ساخت بنر</span></button>
    </form>
  </div>
</div>'''
    return panel_page(s, "تبلیغات",
                      "بنرهای درآمدزا با شمارش واقعی نمایش و کلیک.",
                      content, "/panel/ads", token, extra_js=UP_JS)


# ==========================================================================
#  CITY EVENTS
# ==========================================================================
def event_list(s, token, q=None):
    q = q or {}
    rows = db.cityevents(status=None)
    trs = "".join(f'''<tr>
      <td><strong>{esc(e['title'])}</strong>
        {f'<br><small class="text-muted">{esc(e["descr"])[:70]}</small>' if e['descr'] else ''}</td>
      <td class="nums">{fa(e['date']) if e['date'] else '—'} {fa(e['time']) if e['time'] else ''}</td>
      <td>{esc(e['place'] or '—')}</td>
      <td>{esc(e.get('bizname') or '—')}</td>
      <td><span class="badge {"badge-closed" if e['past'] else ("badge-open" if e['status']=='published' else "badge-neutral")}">
        {"برگزار شده" if e['past'] else ("منتشرشده" if e['status']=='published' else "پیش‌نویس")}</span></td>
      <td class="actions">
        <a class="btn-icon" href="/events/{esc(e['slug'])}" target="_blank" rel="noopener"
           title="مشاهده" aria-label="مشاهدهٔ {esc(e['title'])}">{icon("external")}</a>
        <form method="post" action="/panel/event/{e['id']}" style="display:inline"
              data-confirm="رویداد «{esc(e['title'])}» حذف شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف" aria-label="حذف {esc(e['title'])}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for e in rows)
    if not trs:
        trs = ('<tr><td colspan="6" class="text-center text-muted" '
               'style="padding:var(--space-xl)">رویدادی ثبت نشده</td></tr>')

    content = f'''{_msg(q)}
<div class="grid grid-2" style="grid-template-columns:minmax(0,1fr) minmax(0,340px);align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("calendar")} رویدادهای شهر</h2>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>عنوان</th><th>زمان</th><th>مکان</th><th>کسب‌وکار</th><th>وضعیت</th><th></th></tr></thead>
      <tbody>{trs}</tbody></table></div></div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("plus")} رویداد جدید</h2>
    <form method="post" action="/panel/event/new" data-validate>
      {_hidden(token)}
      <div class="field"><label class="field-label" for="ev-t">عنوان<span class="req">*</span></label>
        <input class="input" id="ev-t" name="title" required placeholder="جشنوارهٔ تخفیف پاییزه"></div>
      <div class="field"><label class="field-label" for="ev-d">توضیح</label>
        <textarea class="textarea" id="ev-d" name="descr" style="min-height:80px"></textarea></div>
      <div class="grid grid-2" style="gap:10px">
        <div class="field" style="margin:0"><label class="field-label" for="ev-dt">تاریخ</label>
          <input class="input nums" id="ev-dt" name="date" type="date"></div>
        <div class="field" style="margin:0"><label class="field-label" for="ev-tm">ساعت</label>
          <input class="input nums" id="ev-tm" name="time" type="time"></div>
      </div>
      <div class="field"><label class="field-label" for="ev-p">مکان</label>
        <input class="input" id="ev-p" name="place" placeholder="میدان امام، بازارچهٔ مرکزی"></div>
      <div class="field"><label class="field-label" for="ev-b">کسب‌وکار برگزارکننده</label>
        <select class="select" id="ev-b" name="biz_id">{_biz_options()}</select></div>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>ثبت رویداد</span></button>
    </form></div></div>'''
    return panel_page(s, "رویدادهای شهر",
                      "جشنواره‌ها، افتتاحیه‌ها و مناسبت‌های نجف‌آباد.",
                      content, "/panel/events", token)


# ==========================================================================
#  EDIT APPROVALS
# ==========================================================================
def edit_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or ["pending"])[0]
    page = _pg(q)
    res = db.pending_edits(status=status or None, page=page)
    rows, pages = res["rows"], res["pages"]

    cards = "".join(f'''<div class="pending-card">
      <div class="pending-main">
        <strong>{esc(e['bizname'])}</strong>
        <div class="text-xs text-muted nums">{esc(e.get('ownerphone') or 'مدیر')} · {fa(str(e['created'])[:16])}</div>
        <table class="table mt-sm"><tbody>
          {"".join(f"<tr><td style='width:130px'>{esc(db.FIELD_LABELS.get(k, k))}</td><td><strong>{esc(str(v)[:160])}</strong></td></tr>" for k, v in e['fields'].items())}
        </tbody></table>
      </div>
      <div class="pending-actions">
        <form method="post" action="/panel/edit/{e['id']}">
          {_hidden(token)}<input type="hidden" name="action" value="approve">
          <button class="btn btn-primary btn-sm btn-block" type="submit">
            {icon("check")}<span>تأیید و اعمال</span></button></form>
        <form method="post" action="/panel/edit/{e['id']}">
          {_hidden(token)}<input type="hidden" name="action" value="reject">
          <button class="btn btn-glass btn-sm btn-block" type="submit">
            {icon("x")}<span>رد</span></button></form>
      </div></div>''' for e in rows)

    if not cards:
        cards = _empty("check-circle", "تغییری در انتظار نیست",
                       "وقتی صاحب کسب‌وکاری اطلاعاتش را عوض کند، اینجا برای تأیید می‌آید.")

    filt = "".join(f'<a class="chip{" is-active" if status==v else ""}" '
                   f'href="/panel/edits?status={v}">{t}</a>'
                   for v, t in [("pending", "در انتظار"), ("approved", "تأییدشده"),
                                ("rejected", "رد شده"), ("", "همه")])
    onoff = s.get("edit_approval") == "1"
    content = f'''{_msg(q)}
{panel_pager("/panel/edits", page, pages)}
<div class="card glass card-pad mb-lg">
  <form method="post" action="/panel/edits/toggle" class="between" style="gap:12px;flex-wrap:wrap">
    {_hidden(token)}
    <div><strong>{"تأیید تغییرات روشن است" if onoff else "تأیید تغییرات خاموش است"}</strong>
      <p class="text-sm text-muted" style="margin:4px 0 0">
        {"هر ویرایش صاحب کسب‌وکار اول به شما نشان داده می‌شود." if onoff else "ویرایش‌های صاحبان کسب‌وکار مستقیم روی سایت اعمال می‌شود."}</p></div>
    <button class="btn {"btn-glass" if onoff else "btn-primary"} btn-sm" type="submit">
      {icon("shield")}<span>{"خاموش کردن" if onoff else "روشن کردن"}</span></button>
  </form>
</div>
<div class="cluster mb-lg">{filt}</div>
<div class="pending-grid">{cards}</div>'''
    return panel_page(s, "تأیید تغییرات",
                      "ویرایش‌هایی که صاحبان کسب‌وکار درخواست کرده‌اند.",
                      content, "/panel/edits", token)


# ==========================================================================
#  SAVED SEARCH ALERTS
# ==========================================================================
def alert_list(s, token, q=None):
    q = q or {}
    page = _pg(q)
    res = db.alerts(page=page)
    rows, pages = res["rows"], res["pages"]
    cats = {c["slug"]: c["name"] for c in db.categories(only_active=False)}
    trs = "".join(f'''<tr>
      <td class="nums">{esc(a['phone'])}</td>
      <td>{esc(a['term']) or '<span class="text-muted">—</span>'}</td>
      <td>{esc(cats.get(a['cat_slug'], a['cat_slug'])) or '<span class="text-muted">همه</span>'}</td>
      <td class="num nums">{fa(a['sent'])}</td>
      <td><span class="badge {"badge-open" if a['active'] else "badge-neutral"}">
        {"فعال" if a['active'] else "غیرفعال"}</span></td>
      <td class="actions">
        <form method="post" action="/panel/alert/{a['id']}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="toggle">
          <button class="btn-icon" type="submit" title="فعال/غیرفعال"
            aria-label="تغییر وضعیت هشدار {a['id']}">{icon("eye")}</button></form>
        <form method="post" action="/panel/alert/{a['id']}" style="display:inline"
              data-confirm="این هشدار حذف شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف" aria-label="حذف هشدار {a['id']}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for a in rows)
    if not trs:
        trs = ('<tr><td colspan="6" class="text-center text-muted" '
               'style="padding:var(--space-xl)">کسی هشدار جست‌وجو ثبت نکرده</td></tr>')

    content = f'''{_msg(q)}
{panel_pager("/panel/alerts", page, pages)}
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("bell")} هشدارهای جست‌وجو</h2>
  <p class="text-sm text-muted mb-lg">وقتی جست‌وجوی کاربری نتیجه ندارد، می‌تواند شماره‌اش را بگذارد.
    به‌محض ثبت کسب‌وکار مطابق، برایش پیامک می‌رود.</p>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>موبایل</th><th>عبارت</th><th>دسته</th><th>پیامک‌شده</th><th>وضعیت</th><th></th></tr></thead>
    <tbody>{trs}</tbody></table></div>
</div>'''
    return panel_page(s, "هشدار جست‌وجو",
                      "کاربرانی که منتظر ثبت یک کسب‌وکار خاص هستند.",
                      content, "/panel/alerts", token)


# ==========================================================================
#  SITE INSIGHTS
# ==========================================================================
def insights(s, token, q=None):
    q = q or {}
    days = (q.get("days") or ["30"])[0]
    days = int(days) if days.isdigit() and 7 <= int(days) <= 365 else 30
    d = db.site_insights(days)
    t = d["totals"]

    peak = max((x["view"] for x in d["daily"]), default=0) or 1
    bars = "".join(
        f'<div class="ins-bar" style="--h:{max(2, round(x["view"]*100/peak))}%" '
        f'title="{x["day"]}: {x["view"]} بازدید"><span class="sr-only">{x["day"]}: {x["view"]}</span></div>'
        for x in d["daily"])

    toprows = "".join(f'''<tr><td><a href="/b/{esc(x['slug'])}" target="_blank" rel="noopener">
      {esc(x['name'])}</a></td><td class="num nums">{fa_group(x['t'])}</td></tr>'''
      for x in d["top"]) or '<tr><td colspan="2" class="text-center text-muted">داده‌ای نیست</td></tr>'

    catmax = max((c["n"] for c in d["cats"]), default=0) or 1
    catrows = "".join(f'''<div class="ins-row">
      <span class="ins-label">{esc(c['name'])}</span>
      <span class="ins-track"><span class="ins-fill" style="width:{round(c['n']*100/catmax)}%"></span></span>
      <span class="nums">{fa(c['n'])}</span></div>''' for c in d["cats"]) or \
      '<p class="text-sm text-muted">دسته‌ای داده ندارد</p>'

    gmax = max((g["n"] for g in d["growth"]), default=0) or 1
    growrows = "".join(f'''<div class="ins-row">
      <span class="ins-label nums">{esc(g['m'])}</span>
      <span class="ins-track"><span class="ins-fill alt" style="width:{round(g['n']*100/gmax)}%"></span></span>
      <span class="nums">{fa(g['n'])}</span></div>''' for g in d["growth"]) or \
      '<p class="text-sm text-muted">هنوز کسب‌وکاری ثبت نشده</p>'

    c = d["counts"]
    todo = ""
    for cond, ic, label, href in (
        (c["reports_open"], "alert", f'{fa(c["reports_open"])} گزارش تخلف باز', "/panel/reports"),
        (c["questions_open"], "help", f'{fa(c["questions_open"])} پرسش بی‌پاسخ', "/panel/qa"),
        (c["subs_pending"], "wallet", f'{fa(c["subs_pending"])} پرداخت در انتظار تأیید', "/panel/subscriptions"),
        (c["edits_pending"], "edit", f'{fa(c["edits_pending"])} ویرایش در انتظار', "/panel/edits"),
    ):
        if cond:
            todo += (f'<a class="todo-item" href="{href}">{icon(ic)}'
                     f'<span>{label}</span>{icon("chevron-left")}</a>')
    if not todo:
        todo = (f'<div class="alert alert-success">{icon("check-circle")}'
                f'<span>هیچ کار معوقی در بخش‌های جدید نیست.</span></div>')

    # ---- what the city searched for
    st_search = db.search_totals(days)
    srows = db.top_searches(days, limit=12)
    searchrows = "".join(f'''<tr>
      <td>{esc(r['term'])}</td>
      <td class="num nums">{fa(r['n'])}</td>
      <td>{'<span class="badge badge-closed">بی‌نتیجه</span>' if not r['best']
           else f'<span class="badge badge-open">{fa(r["best"])} مورد</span>'}</td>
    </tr>''' for r in srows) or (
        '<tr><td colspan="3" class="text-center text-muted" '
        'style="padding:var(--space-lg)">هنوز کسی جست‌وجو نکرده</td></tr>')

    zrows = db.top_searches(days, limit=12, zero_only=True)
    zerorows = "".join(f'''<tr>
      <td><strong>{esc(r['term'])}</strong></td>
      <td class="num nums">{fa(r['n'])}</td></tr>''' for r in zrows) or (
        '<tr><td colspan="2" class="text-center text-muted" '
        'style="padding:var(--space-lg)">هر جست‌وجو نتیجه داشته — عالی است</td></tr>')

    dopts = "".join(f'<a class="chip{" is-active" if days==n else ""}" '
                    f'href="/panel/insights?days={n}">{fa(n)} روز</a>'
                    for n in (7, 30, 90, 365))

    content = f'''{_msg(q)}
<div class="cluster mb-lg">{dopts}</div>
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("eye", t['view'], f"بازدید صفحهٔ کسب‌وکار ({fa(days)} روز)")}
  {stat_card("phone", t['phone'], "کلیک تماس", delay=60)}
  {stat_card("whatsapp", t['whatsapp'], "کلیک واتساپ", delay=120)}
  {stat_card("map", t['route'], "درخواست مسیر", delay=180)}
</div>
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("wallet", d['revenue'], "درآمد اشتراک فعال (تومان)")}
  {stat_card("search", st_search['total'], "جست‌وجو", delay=60)}
  {stat_card("alert", st_search['zero'], "جست‌وجوی بی‌نتیجه", delay=120)}
  {stat_card("calendar", c['events'], "رویداد پیش‌رو", delay=180)}
</div>

<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-lg">{icon("chart")} روند بازدید روزانه</h2>
  <div class="ins-chart" role="img" aria-label="نمودار بازدید {fa(days)} روز اخیر">{bars}</div>
  <div class="between text-xs text-muted mt-sm">
    <span>{esc(d['daily'][0]['day'])}</span><span>{esc(d['daily'][-1]['day'])}</span></div>
</div>

<div class="grid grid-2 mb-lg" style="align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("trending")} پربازدیدترین کسب‌وکارها</h2>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>کسب‌وکار</th><th>بازدید</th></tr></thead>
      <tbody>{toprows}</tbody></table></div>
  </div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("bell")} کارهای در انتظار</h2>
    <div class="todo-list">{todo}</div>
  </div>
</div>

<div class="grid grid-2 mb-lg" style="align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("layers")} توزیع دسته‌ها</h2>{catrows}</div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("trending")} رشد ماهانهٔ ثبت‌نام</h2>{growrows}</div>
</div>

<div class="grid grid-2" style="align-items:start">
  <div class="card glass card-pad">
    <div class="between mb-lg">
      <h2 class="card-title">{icon("search")} پرجست‌وجوترین عبارت‌ها</h2>
      <span class="badge badge-neutral">{icon("target")}
        <span>نرخ موفقیت {fa(st_search['hit_rate'])}٪</span></span></div>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>عبارت</th><th>دفعات</th><th>نتیجه</th></tr></thead>
      <tbody>{searchrows}</tbody></table></div>
  </div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("alert")} جست‌وجوهای بی‌نتیجه</h2>
    <p class="text-sm text-muted mb-md">مردم این‌ها را خواستند و چیزی پیدا نکردند.
      هر ردیف یعنی یک صنف که جایش در بازارچه خالی است.</p>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>عبارت</th><th>دفعات</th></tr></thead>
      <tbody>{zerorows}</tbody></table></div>
    {f"""<form method="post" action="/panel/searches/clear" class="mt-md">
      {_hidden(token)}
      <button class="btn btn-ghost btn-sm" type="submit"
        onclick="return confirm('همهٔ آمار جست‌وجو پاک شود؟')">
        {icon("trash")}<span>پاک کردن آمار جست‌وجو</span></button></form>"""
     if st_search['total'] else ''}
  </div>
</div>'''
    return panel_page(s, "بینش و آمار سایت",
                      "تصویر کامل از رفتار کاربران، درآمد و رشد بازارچه.",
                      content, "/panel/insights", token)


# ==========================================================================
#  FEATURE UNLOCKS  —  the key the site owner holds
# ==========================================================================
def unlock_list(s, token, q=None):
    """One screen to see every shop's plan and flip any feature by hand.

    This is the lever behind the whole business model: a shopkeeper pays you
    however they pay you, and you turn the switch here. Nothing about it is
    decorative — every checkbox writes to biz_features and takes effect on
    the next page load.
    """
    q = q or {}
    term = (q.get("q") or [""])[0].strip()
    only = (q.get("only") or [""])[0]

    rows = db.businesses(status=None, order="newest")
    if term:
        t = db.normalize_fa(term)
        rows = [b for b in rows
                if t in db.normalize_fa(f"{b['name']} {b.get('phone','')}")]
    if only == "founder":
        rows = [b for b in rows if db.is_founder(b["id"])]
    elif only == "paid":
        rows = [b for b in rows if db.access(b["id"])["paid"]]
    elif only == "granted":
        rows = [b for b in rows if db._manual_grants(b["id"])]

    cfg = db.founder_settings()
    left = db.founders_left()

    cards = ""
    for b in rows[:40]:
        acc = db.access(b["id"])
        manual = db._manual_grants(b["id"])
        boxes = ""
        for key, label, _ic, _f, why in db.FEATURES:
            on = key in acc["keys"]
            src = acc["source"].get(key, "")
            by_manual = key in manual
            # a feature already granted by plan or founder status cannot be
            # switched off here — say so instead of showing a dead checkbox
            fixed = on and not by_manual
            note = ""
            if fixed:
                lbl = {"plan": "از پلن", "founder": "بنیان‌گذار"}.get(src, src)
                note = f'<span class="unlock-src src-{src}">{esc(lbl)}</span>'
            boxes += f'''<label class="unlock-row{" is-on" if on else ""}">
          <input type="checkbox" name="feat" value="{esc(key)}"
                 {"checked" if by_manual else ""} {"disabled" if fixed else ""}>
          <span class="u-label">{esc(label)}<span class="u-why">{esc(why)}</span></span>
          {note}</label>'''

        badge = ""
        if acc["founder"]:
            badge = (f'<span class="badge" style="background:color-mix(in oklab, var(--color-warning) 14%, transparent);color:var(--color-warning-text)">'
                     f'{icon("award")}<span>بنیان‌گذار #{fa(acc["rank"])}</span></span>')
        if acc["paid"]:
            badge += (f'<span class="badge badge-featured">{icon("wallet")}'
                      f'<span>{esc(acc["plan_name"])}</span></span>')

        cards += f'''<form class="card glass card-pad mb-lg" method="post"
        action="/panel/unlock/{b["id"]}">
      {_hidden(token)}
      <div class="between mb-md" style="flex-wrap:wrap;gap:8px">
        <div><h3 class="card-title">{esc(b["name"])}</h3>
          <div class="text-xs text-muted nums">{esc(b.get("phone") or "—")} ·
            {fa(len(acc["keys"]))} از {fa(len(db.FEATURES))} قابلیت فعال ·
            سقف {fa(acc["max_items"])} کالا / {fa(acc["max_photos"])} عکس</div></div>
        <div class="cluster">{badge}</div>
      </div>
      <div class="unlock-grid">{boxes}</div>
      <div class="cluster mt-md">
        <button class="btn btn-primary btn-sm" type="submit" name="action" value="save">
          {icon("check")}<span>ذخیرهٔ دسترسی‌ها</span></button>
        <button class="btn btn-glass btn-sm" type="submit" name="action" value="all">
          {icon("zap")}<span>باز کردن همه</span></button>
        <button class="btn btn-ghost btn-sm" type="submit" name="action" value="none"
          style="color:var(--color-destructive)">{icon("lock")}<span>بستن همه</span></button>
        <a class="btn btn-ghost btn-sm" href="/b/{esc(b["slug"])}" target="_blank"
           rel="noopener">{icon("external")}<span>دیدن صفحه</span></a>
      </div>
    </form>'''

    if not cards:
        cards = _empty("lock", "کسب‌وکاری پیدا نشد",
                       "عبارت جست‌وجو را تغییر دهید یا فیلتر را بردارید.")

    chips = "".join(
        f'<a class="chip{" is-active" if only == v else ""}" '
        f'href="/panel/unlocks{"&only=" + v if v else ""}">{t}</a>'
        for v, t in [("", "همه"), ("founder", "بنیان‌گذاران"),
                     ("paid", "پلن پولی"), ("granted", "دسترسی دستی")])

    content = f'''{_msg(q)}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("store", len(db.businesses(status=None)), "کل کسب‌وکارها")}
  {stat_card("award", cfg["limit"] - left, "عضو بنیان‌گذار", delay=60)}
  {stat_card("lock", left, "جای باقی‌ماندهٔ بنیان‌گذار", delay=120)}
  {stat_card("wallet", len([x for x in db.subscriptions(status="active") if x["is_live"]]),
             "اشتراک فعال", delay=180)}
</div>

<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-md">{icon("award")} پنجرهٔ عضویت بنیان‌گذار</h2>
  <p class="text-sm text-muted mb-lg">قولی که سر در دکان می‌دهید: صد کسب‌وکار
    نخست، قابلیت‌های پایه را همیشه رایگان دارند. شمارهٔ هر کسب‌وکار بر پایهٔ
    ترتیب ثبت است و هرگز عوض نمی‌شود.</p>
  <form method="post" action="/panel/unlocks/founder" class="grid grid-4" style="align-items:end">
    {_hidden(token)}
    <div class="field" style="margin:0"><label class="field-label" for="f-lim">تعداد بنیان‌گذاران</label>
      <input class="input nums" id="f-lim" name="founder_limit" type="number" min="0"
             value="{cfg['limit']}"></div>
    <div class="field" style="margin:0"><label class="field-label" for="f-it">سقف کالا (بنیان‌گذار)</label>
      <input class="input nums" id="f-it" name="founder_max_items" type="number" min="1"
             value="{cfg['items']}"></div>
    <div class="field" style="margin:0"><label class="field-label" for="f-ph">سقف عکس (بنیان‌گذار)</label>
      <input class="input nums" id="f-ph" name="founder_max_photos" type="number" min="1"
             value="{cfg['photos']}"></div>
    <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
  </form>
  <hr class="divider">
  <form method="post" action="/panel/unlocks/founder" class="grid grid-4" style="align-items:end">
    {_hidden(token)}
    <div class="field" style="margin:0"><label class="field-label" for="p-it">سقف کالا (رایگان عادی)</label>
      <input class="input nums" id="p-it" name="free_max_items" type="number" min="1"
             value="{cfg['plain_items']}"></div>
    <div class="field" style="margin:0"><label class="field-label" for="p-ph">سقف عکس (رایگان عادی)</label>
      <input class="input nums" id="p-ph" name="free_max_photos" type="number" min="1"
             value="{cfg['plain_photos']}"></div>
    <button class="btn btn-glass" type="submit">{icon("check")}<span>ذخیرهٔ سقف رایگان</span></button>
  </form>
</div>

<form class="dir-toolbar mb-lg" method="get" action="/panel/unlocks">
    <div class="dir-row">
    <span class="search-wrap">{icon("search", cls="search-icon")}
      <label class="sr-only" for="uq">جست‌وجوی کسب‌وکار</label>
      <input class="input" id="uq" name="q" type="search" value="{esc(term)}"
             placeholder="نام یا شمارهٔ کسب‌وکار…"></span>
    <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
  </div>
  <div class="dir-chips">{chips}</div>
</form>

{cards}
{f'<p class="text-sm text-muted text-center">{fa(len(rows) - 40)} مورد دیگر — برای دیدنشان جست‌وجو کنید.</p>' if len(rows) > 40 else ''}'''

    return panel_page(s, "کلید قابلیت‌ها",
                      "هر قابلیت را برای هر کسب‌وکار دستی باز یا بسته کنید.",
                      content, "/panel/unlocks", token)


# ==========================================================================
#  TICKETS  --  the admin's inbox
# ==========================================================================
def ticket_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or [""])[0]
    term = (q.get("q") or [""])[0]
    page = _pg(q)
    res = db.tickets(status=status or None, q=term, page=page)
    rows, pages = res["rows"], res["pages"]
    st = db.ticket_stats()

    tabs = ""
    for val, lbl in (("", "همه"), ("open", "باز"), ("answered", "پاسخ‌داده"),
                     ("waiting", "در انتظار کاربر"), ("closed", "بسته")):
        on = " is-active" if status == val else ""
        n = {"": st["total"], "open": st["open"], "answered": st["answered"],
             "closed": st["closed"]}.get(val)
        _cnt = f'<small class="chip-n nums">{fa(n)}</small>' if n else ""
        tabs += (f'<a class="chip{on}" href="/panel/tickets'
                 f'{f"&status={val}" if val else ""}">{esc(lbl)}'
                 f'{_cnt}</a>')

    items = ""
    for t in rows:
        unread = '<span class="tk-dot"></span>' if t["unread_admin"] else ""
        pri = ('<span class="badge badge-closed">فوری</span>'
               if t["priority"] == "high" else "")
        # v117/M4: the row is a DIV with a stretched overlay link — a tel:
        # link inside the old row anchor was invalid nested-<a> HTML.
        items += f'''<div class="tk-row">
      <input class="tk-check" type="checkbox" form="bulk-tk" name="ids" value="{t['id']}" aria-label="انتخاب تیکت {t['id']}">
      {unread}
      <div class="tk-main">
        <strong>{esc(t['subject'])}</strong>
        <div class="tk-meta">
          <span>{esc(t['name'] or '—')}</span>
          {f'<a href="tel:{esc(t["phone"])}" class="nums tk-tel">· {esc(t["phone"])}</a>' if t.get('phone') else ''}
          <span>· {esc(t['topic_label'])}</span>
          {f'<span>· {esc(t["bizname"])}</span>' if t.get('bizname') else ''}
          <span>· {fa(t['nmsg'])} پیام</span>
          <span>· {esc(str(t['updated'])[:16])}</span>
        </div>
      </div>
      {pri}
      <span class="badge {t['status_cls']}">{esc(t['status_label'])}</span>
      {icon("chevron-left")}
      <a class="tk-link" href="/panel/ticket/{t['id']}" aria-label="جزئیات تیکت {esc(t['subject'])}"></a>
    </div>'''

    if not items:
        items = _empty("message", "تیکتی نیست",
                       "وقتی دکان‌داران سؤالی داشته باشند، اینجا می‌بینید.")

    bulk = f'''<form id="bulk-tk" method="post" action="/panel/tickets/bulk" class="bulk-bar">
      <label class="chip" data-check-all="form:bulk-tk"><input type="checkbox" aria-label="انتخاب همه"> همه</label>
      <select class="select" name="action" aria-label="عملیات گروهی">
        <option value="open">باز کردن</option>
        <option value="close">بستن</option>
        <option value="delete">حذف</option>
      </select>
      <button class="btn btn-primary btn-sm" type="submit">{icon("zap")}<span>اجرا روی انتخاب‌شده‌ها</span></button>
    </form>'''

    _chat_unread = sum(1 for r in db.chat_threads_all() if r.get("unread"))
    content = f'''{CH.conversations_tabs("admin", "tickets", token, counts={"chats": _chat_unread, "tickets": st['unread']})}{_msg(q) if callable(globals().get("_msg")) else ""}
{bulk}
{panel_pager("/panel/tickets", page, pages)}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("message", st['total'], "کل تیکت‌ها")}
  {stat_card("bell", st['unread'], "خوانده‌نشده", delay=60)}
  {stat_card("clock", st['open'], "در انتظار پاسخ شما", delay=120)}
  {stat_card("check-circle", st['closed'], "بسته‌شده", delay=180)}
</div>

<form class="dir-toolbar mb-lg" method="get" action="/panel/tickets">
    <div class="dir-row">
    <span class="search-wrap">{icon("search", cls="search-icon")}
      <label class="sr-only" for="tq">جست‌وجو</label>
      <input class="input" id="tq" name="q" type="search" value="{esc(term)}"
             placeholder="عنوان، نام یا شمارهٔ تماس…"></span>
    <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
  </div>
  <div class="dir-chips mt-md">{tabs}</div>
</form>

<div class="card glass card-pad"><div class="tk-list">{items}</div></div>'''
    return panel_page(s, "تیکت‌های پشتیبانی",
                      "گفت‌وگوی مستقیم با دکان‌داران.",
                      content, "/panel/tickets", token)


def ticket_detail(s, token, tid, q=None):
    t = db.ticket(tid=tid)
    if not t:
        return None
    msgs = db.ticket_msgs(tid)
    db.set_ticket(tid, unread_admin=0)

    bubbles = ""
    for m in msgs:
        admin = m["side"] == "admin"
        attachment = ""
        if m.get("attachment_id"):
            attachment=(f'<a class="tk-attachment" href="/ticket-file/{m["attachment_id"]}" target="_blank" rel="noopener">'
                        f'{icon("file")}<span>{esc(m.get("file_name") or "فایل")}</span>'
                        f'<small>{fa(max(1,int(m.get("file_size") or 0)//1024))} KB</small></a>')
        bubbles += f'''<div class="tk-bubble {"is-me" if admin else "is-admin"}">
      <div class="tk-who">{icon("shield" if admin else "user")}
        <span>{"شما (مدیر)" if admin else esc(t['name'] or 'کاربر')}</span>
        <time class="nums">{esc(str(m['created'])[:16])}</time></div>
      {f'<p>{esc(m["body"])}</p>' if m.get("body") else ''}{attachment}
    </div>'''

    # if this person owns a shop, one click to their unlock page — this is
    # the most common reason a ticket exists at all
    quick = ""
    if t.get("biz_id"):
        quick = (f'<a class="btn btn-glass btn-sm" '
                 f'href="/panel/unlocks?q={esc(t.get("bizname") or "")}">'
                 f'{icon("lock")}<span>کلید قابلیت‌های این کسب‌وکار</span></a>')

    sel = lambda v, cur: ' selected' if v == cur else ''
    content = f'''
<div class="card glass card-pad mb-lg">
  <div class="between mb-md" style="align-items:flex-start;gap:10px">
    <div>
      <h2 class="card-title">{esc(t['subject'])}</h2>
      <div class="tk-meta">
        <strong>{esc(t['name'] or '—')}</strong>
        {f'· <a href="tel:{esc(t["phone"])}" class="nums">{esc(t["phone"])}</a>' if t.get('phone') else ''}
        · {esc(t['topic_label'])}
        {f'· <a href="/b/{esc(t["bizslug"])}" target="_blank" rel="noopener">{esc(t["bizname"])}</a>' if t.get('bizname') else ''}
        · <span class="nums">{esc(str(t['created'])[:16])}</span>
      </div>
    </div>
    <span class="badge {t['status_cls']}">{esc(t['status_label'])}</span>
  </div>
  <div class="cluster">{quick}</div>
</div>

<div class="tk-thread">{bubbles}</div>

<form class="card glass card-pad mt-lg" method="post" action="/panel/ticket/{tid}" enctype="multipart/form-data">
    <div class="field"><label class="field-label" for="ad-rp">پاسخ شما</label>
    <textarea class="textarea" id="ad-rp" name="body"
      placeholder="پاسخ خود را بنویسید…"></textarea></div>
  <div class="field"><label class="field-label" for="ad-file">پیوست امن</label>
    <input class="input" id="ad-file" type="file" name="attachment"
      accept="image/jpeg,image/png,image/webp,image/gif,application/pdf,text/plain"></div>
  <div class="grid grid-2" style="gap:0 var(--space-md)">
    <div class="field"><label class="field-label" for="ad-st">وضعیت</label>
      <select class="select" id="ad-st" name="status">
        <option value="open"{sel("open", t["status"])}>باز</option>
        <option value="answered"{sel("answered", t["status"])}>پاسخ داده شد</option>
        <option value="waiting"{sel("waiting", t["status"])}>در انتظار کاربر</option>
        <option value="closed"{sel("closed", t["status"])}>بسته</option>
      </select></div>
    <div class="field"><label class="field-label" for="ad-pr">اولویت</label>
      <select class="select" id="ad-pr" name="priority">
        <option value="low"{sel("low", t["priority"])}>کم</option>
        <option value="normal"{sel("normal", t["priority"])}>عادی</option>
        <option value="high"{sel("high", t["priority"])}>فوری</option>
      </select></div>
  </div>
  <div class="cluster">
    <button class="btn btn-primary" type="submit" name="action" value="reply">
      {icon("send")}<span>ارسال پاسخ</span></button>
    <button class="btn btn-glass" type="submit" name="action" value="save" formnovalidate>
      {icon("check")}<span>فقط ذخیرهٔ وضعیت</span></button>
    <button class="btn btn-ghost" type="submit" name="action" value="delete"
      formnovalidate data-confirm="این تیکت حذف شود؟"
      style="color:var(--color-destructive)">{icon("trash")}<span>حذف</span></button>
  </div>
</form>'''
    return panel_page(s, f"تیکت: {t['subject'][:40]}",
                      "پاسخ به دکان‌دار.", content, "/panel/tickets", token)


# ==========================================================================
#  INBOX  --  the single place that answers "does anything need me?"
# ==========================================================================
def inbox_page(s, token, q=None):
    data = db.inbox()
    K = esc(token)

    if not data["total"]:
        body = _empty("check-circle", "همه‌چیز رسیدگی شده",
                      "هیچ درخواستی منتظر تأیید شما نیست. "
                      "هر وقت کاسبی چیزی بفرستد، همین‌جا می‌بینید.")
        return panel_page(s, "درخواست‌های کاسبان",
                          "هرچه منتظر تأیید شماست، یکجا.",
                          f'<div class="card glass card-pad">{body}</div>',
                          "/panel/inbox", token)

    blocks = ""
    for g in data["groups"]:
        rows = ""
        for it in g["items"]:
            rows += f'''<a class="ib-row" href="{esc(it['href'])}">
        <div class="ib-main">
          <strong>{esc(it['title'])}</strong>
          {f'<div class="ib-sub">{esc(it["sub"])}</div>' if it.get('sub') else ''}
        </div>
        <time class="ib-when nums">{esc(it['when'])}</time>
        {icon("chevron-left")}
      </a>'''
        more = ""
        if g["n"] > len(g["items"]):
            more = (f'<a class="ib-more" href="{esc(g["href"])}'
                    f'">'
                    f'{fa(g["n"] - len(g["items"]))} مورد دیگر ←</a>')
        blocks += f'''<div class="card glass card-pad mb-lg">
      <div class="between mb-md">
        <h2 class="card-title">{icon(g['icon'])} {esc(g['label'])}
          <span class="badge badge-warn nums">{fa(g['n'])}</span></h2>
        <a class="btn btn-glass btn-sm" href="{esc(g['href'])}">
          {icon("external")}<span>مدیریت</span></a>
      </div>
      <div class="ib-list">{rows}</div>
      {more}
    </div>'''

    head = f'''<div class="alert alert-warn mb-lg">{icon("bell")}<span>
      <strong>{fa(data['total'])} مورد</strong> منتظر تأیید یا پاسخ شماست.
      هرچه زودتر رسیدگی کنید، کاسب‌ها بیشتر به سایت اعتماد می‌کنند.</span></div>'''

    return panel_page(s, "درخواست‌های کاسبان",
                      "هرچه منتظر تأیید شماست، یکجا.",
                      head + blocks, "/panel/inbox", token)


# ==========================================================================
#  FEATURE SWITCHES  --  turn whole capabilities on and off
# ==========================================================================
# Every switch here maps to a settings key the rest of the site already
# honours. Nothing is deleted when a feature is off — the pages simply stop
# being offered, and turning it back on restores everything untouched.
SITE_FEATURES = [
    ("قابلیت‌های ویژه", [
        ("haggle_enabled",  "چانه‌زنی",
         "مشتری روی کالا قیمت پیشنهاد می‌دهد؛ بالاتر از کف قیمت خودکار پذیرفته می‌شود.",
         "tag"),
        ("prices_enabled",  "نمایش قیمت کالاها",
         "قیمت در کاتالوگ، سفارش، چانه‌زنی و مقایسهٔ محلی روی سایت عمومی دیده شود.", "chart"),
        ("compare_enabled", "مقایسهٔ کسب‌وکارها",
         "انتخاب چند دکان و مقایسهٔ کنار هم.", "layers"),
        ("nearby_enabled",  "نزدیک من",
         "جست‌وجوی شعاعی بر پایهٔ موقعیت مشتری.", "compass"),
    ]),
    ("تعامل با مشتری", [
        ("booking_enabled", "نوبت‌دهی آنلاین", "رزرو نوبت بدون تماس.", "calendar"),
        ("qa_enabled",      "پرسش و پاسخ", "سؤال عمومی زیر صفحهٔ هر دکان.", "help"),
        ("inquiry_enabled", "ارتباط با دکان‌دار", "مشتری بدون شمارهٔ تلفن پیام می‌دهد.", "message"),
        ("reports_enabled", "گزارش تخلف", "مشتری اطلاعات غلط را گزارش کند.", "alert"),
        ("alerts_enabled",  "اعلان کسب‌وکار تازه",
         "به کسانی که خبرم کن زده‌اند پیامک می‌رود.", "bell"),
    ]),
    ("محتوا و فروش", [
        ("catalog_enabled", "ویترین محصولات", "کاتالوگ کالا و خدمات هر دکان.", "shopping"),
        ("events_enabled",  "رویدادهای شهر", "حراج، افتتاحیه و جشنواره.", "calendar"),
        ("blog_enabled",    "اخبار شهر", "بخش خبر و مقاله.", "book"),
        ("ads_enabled",     "بنر تبلیغاتی", "جایگاه تبلیغ در صفحات.", "zap"),
        ("plans_enabled",   "تعرفه و اشتراک", "صفحهٔ پلن‌ها و خرید.", "wallet"),
    ]),
    ("ثبت‌نام و ورود", [
        ("reg_open",        "ثبت کسب‌وکار جدید", "فرم ثبت عمومی باز باشد.", "plus"),
        ("owner_login",     "ورود صاحبان کسب‌وکار", "پنل دکان‌دار فعال باشد.", "user"),
        ("claims_enabled",  "تصاحب کسب‌وکار", "درخواست مالکیت یک صفحهٔ موجود.", "shield"),
        ("support_widget",  "ویجت پشتیبانی", "دکمهٔ شناور راهنما و سؤالات متداول.", "help"),
    ]),
    ("اجتماعی (شبیه اینستاگرام)", [
        ("stories_enabled", "استوری کسب‌وکارها", "عکس‌های ۲۴ ساعته با نوار استوری در صفحهٔ اول.", "image"),
        ("follow_enabled",  "دنبال‌کردن کسب‌وکار", "مشتری کسب‌وکار را دنبال کند و تازه‌هایش را ببیند.", "heart"),
        ("notif_enabled",   "اعلان‌های مشتری", "پاسخ‌ها و وضعیت سفارش در مرکز اعلان.", "bell"),
        ("chat_enabled",    "گفتگوی مشتری و دکان‌دار", "چت مستقیم داخل سایت.", "message"),
    ]),
    ("فروش", [
        ("shop_account",    "حساب مشتری", "ورود با موبایل، سفارش و علاقه‌مندی.", "user"),
        ("orders_enabled",  "سبد خرید و سفارش", "سفارش آنلاین از کاتالوگ.", "cart"),
        ("lists_enabled",   "برترین‌های شهر", "لیست‌های رتبه‌بندی دستی و خودکار.", "trophy"),
        ("deals_enabled",   "پیشنهاد روز / فلش‌سیل", "تخفیف لحظه‌ای با شمارش معکوس.", "zap"),
    ]),
]


def features_page(s, token, q=None):
    K = esc(token)
    groups = ""
    n_on = n_tot = 0
    for title, items in SITE_FEATURES:
        rows = ""
        for key, label, why, ic in items:
            on = s.get(key, "1") == "1"
            n_tot += 1
            n_on += 1 if on else 0
            rows += f'''<label class="feat-row">
        <input type="checkbox" name="{esc(key)}" value="1"{" checked" if on else ""}>
        <span class="feat-ic">{icon(ic)}</span>
        <span class="feat-txt"><strong>{esc(label)}</strong>
          <small>{esc(why)}</small></span>
        <span class="feat-state">{"روشن" if on else "خاموش"}</span>
      </label>'''
        groups += f'''<div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-md">{esc(title)}</h2>
      <div class="feat-list">{rows}</div>
    </div>'''

    content = f'''
<div class="alert alert-info mb-lg">{icon("info")}<span>
  هر قابلیتی را که الان نمی‌خواهید خاموش کنید — <strong>هیچ داده‌ای پاک
  نمی‌شود</strong>. هر وقت دوباره روشن کنید، همه‌چیز سر جایش برمی‌گردد.
  الان <strong>{fa(n_on)}</strong> از {fa(n_tot)} قابلیت روشن است.</span></div>

<form method="post" action="/panel/features">
    {groups}
  <div class="cluster">
    <button class="btn btn-primary btn-lg" type="submit">
      {icon("check")}<span>ذخیرهٔ تغییرات</span></button>
    <a class="btn btn-ghost" href="/panel/settings">
      {icon("settings")}<span>بقیهٔ تنظیمات</span></a>
  </div>
</form>'''
    return panel_page(s, "قابلیت‌های سایت",
                      "هر بخش را جداگانه روشن یا خاموش کنید.",
                      content, "/panel/features", token)


# ==========================================================================
#  MEDIA MANAGER  (all uploaded files, referenced vs orphan)
# ==========================================================================
def media_page(s, token, q=None):
    import time as _t
    files = uploads.list_files()
    refs = db.all_upload_refs()
    now = _t.time()

    def fmt_size(b):
        if b >= 1048576:
            return f"{b / 1048576:.1f} مگابایت"
        return f"{max(1, b // 1024)} کیلوبایت"

    rows = []
    total_size = 0
    orphan_count = 0
    for f in files:
        used = f["path"] in refs
        orphan = not used and (now - f["mtime"]) > 3600
        if orphan:
            orphan_count += 1
        total_size += f["size"]
        rows.append(f'''
      <tr>
        <td><span dir="ltr" class="nums" style="font-size:12px">{esc(f["name"])}</span></td>
        <td><span class="nums">{fmt_size(f["size"])}</span></td>
        <td>{f'<span class="badge badge-open">در حال استفاده</span>' if used
             else f'<span class="badge badge-warn">بدون استفاده</span>'}</td>
        <td><form method="post" action="/panel/media/delete" data-confirm="این فایل برای همیشه حذف شود؟"
                  style="display:inline">
                            <input type="hidden" name="path" value="{esc(f["path"])}">
              <button class="btn btn-ghost btn-sm" type="submit">{icon("x")}<span>حذف</span></button>
            </form></td>
      </tr>''')

    if not rows:
        rows.append(f'<tr><td colspan="4">{esc("هنوز فایلی آپلود نشده است.")}</td></tr>')

    content = f'''{_msg(q)}
<div class="card glass card-pad mb-lg">
  <div class="between">
    <div><h2 class="card-title">{icon("image")} فایل‌های آپلودشده</h2>
      <p class="text-sm text-muted mt-sm">{fa(len(files))} فایل · {fmt_size(total_size)} در مجموع ·
        {fa(orphan_count)} فایل بدون استفاده</p></div>
    <form method="post" action="/panel/media/gc" data-confirm="فایل‌های بدون استفاده و قدیمی‌تر از یک ساعت پاک شوند؟">
            <button class="btn btn-danger" type="submit">{icon("trash")}<span>پاک‌سازی خودکار</span></button>
    </form>
  </div>
</div>
<div class="card glass card-pad">
  <div class="table-wrap">
    <table class="table">
      <thead><tr><th>نام فایل</th><th>حجم</th><th>وضعیت</th><th></th></tr></thead>
      <tbody>{''.join(rows)}</tbody>
    </table>
  </div>
</div>'''
    return panel_page(s, "مدیریت فایل‌ها", "همهٔ تصاویر آپلودشده و پاک‌سازی فایل‌های یتیم.",
                      content, "/panel/media", token)


# ==========================================================================
#  ADMIN: ALL CHATS & ALL ORDERS  (v28 — the owner sees everything)
# ==========================================================================
def admin_chats(s, token, q=None):
    q = q or {}
    term = (q.get("q") or [""])[0].strip()
    status = (q.get("status") or [""])[0]
    page = _pg(q)
    res = db.chat_threads_all(term=term, status=status, page=page)
    rows, pages = res["rows"], res["pages"]
    all_rows = db.chat_threads_all()
    n_open = sum(1 for row in all_rows if row.get("status") == "open")
    n_closed = len(all_rows) - n_open
    n_attention = sum(1 for row in all_rows if row.get("unread"))
    items = CH.thread_list(
        rows, "admin", "/panel/chat",
        empty_title="گفتگویی با این فیلتر نیست",
        empty_text="عبارت یا وضعیت را تغییر دهید؛ همهٔ گفتگوها بدون حذف داده قابل جست‌وجو هستند.")
    status_options = "".join(
        f'<option value="{value}"{" selected" if status == value else ""}>{label}</option>'
        for value, label in (("", "همهٔ وضعیت‌ها"), ("open", "باز"), ("closed", "بسته")))
    _tk_unread = sum(1 for t in db.tickets() if t.get("unread_admin"))
    content = f'''{CH.conversations_tabs("admin", "chats", token, counts={"chats": n_attention, "tickets": _tk_unread})}{_msg(q)}
{panel_pager("/panel/chats", page, pages)}
<div class="grid grid-4 mb-lg" data-admin-chat-stats>
  {stat_card("message", len(all_rows), "کل گفتگوها")}
  {stat_card("activity", n_open, "گفتگوی باز", delay=50)}
  {stat_card("bell", n_attention, "نیازمند توجه شما", delay=100)}
  {stat_card("check-circle", n_closed, "گفتگوی بسته", delay=150)}
</div>
<form class="dir-toolbar mb-lg" method="get" action="/panel/chats">
    <div class="dir-row">
    <span class="search-wrap">{icon("search", cls="search-icon")}
      <label class="sr-only" for="chat-q">جست‌وجوی گفتگو</label>
      <input class="input" id="chat-q" name="q" type="search" value="{esc(term)}"
             placeholder="نام کسب‌وکار، مشتری، شماره یا موضوع…"></span>
    <label class="sr-only" for="chat-status">وضعیت</label>
    <select class="select" id="chat-status" name="status">{status_options}</select>
    <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
    <a class="btn btn-glass" href="/panel/chats">پاک کردن</a>
  </div>
</form>
<div class="chat-inbox-card">{items}</div>'''
    return panel_page(s, "مرکز کنترل گفتگوها",
                      "همهٔ پیام‌های مشتری و دکان‌دار؛ جست‌وجو، نظارت و پاسخ شفاف مدیر.",
                      content, "/panel/chats", token)


def admin_chat_view(s, token, tid, q=None):
    thread = db.chat_thread(tid)
    if not thread:
        return None
    biz = db.business(bid=thread["biz_id"]) or {}
    cust = db.customer_by_id(thread.get("customer_id")) or {}
    customer_name = cust.get("name") or "مشتری بدون نام"
    next_status = "closed" if thread.get("status") == "open" else "open"
    action_label = "بستن گفتگو" if next_status == "closed" else "بازکردن گفتگو"
    room = CH.chat_room(
        thread, db.chat_messages(tid), "admin",
        f'''{customer_name} ↔ {biz.get("name", "کسب‌وکار")}''',
        "شما با هویت روشن «مدیر بازارچه» در این گفتگو حضور دارید.",
        f"/panel/chat/{tid}", "/panel/chats",
        status=thread.get("status", "open"))
    content = f'''{_msg(q or {})}
<div class="chat-admin-context mb-lg">
  <div><span class="eyebrow">{icon("shield")}<span>نظارت مدیر</span></span>
    <h2>{esc(biz.get("name", "کسب‌وکار"))}</h2>
    <p>مشتری: <strong>{esc(customer_name)}</strong> · <span class="nums" dir="ltr">{esc(cust.get("phone") or "—")}</span></p></div>
  <div class="cluster">
    {f'<a class="btn btn-glass" href="/b/{esc(biz.get("slug", ""))}" target="_blank" rel="noopener">{icon("external")}<span>صفحهٔ کسب‌وکار</span></a>' if biz.get("slug") else ''}
    <form method="post" action="/panel/chat/{tid}/status">
            <input type="hidden" name="status" value="{next_status}">
      <button class="btn {"btn-ghost" if next_status == "closed" else "btn-primary"}" type="submit">{icon("lock" if next_status == "closed" else "refresh")}<span>{action_label}</span></button>
    </form>
  </div>
</div>
{room}
<script type="module" src="/assets/js/chat.js?v109"></script>'''
    return panel_page(s, "مدیریت گفتگو", "مشاهده و پاسخ به‌عنوان مدیر بازارچه.",
                      content, "/panel/chats", token)


def admin_orders(s, token, q=None):
    q = q or {}
    page = _pg(q)
    res = db.orders_all(page=page)
    rows, pages = res["rows"], res["pages"]
    def cancel_admin(o):
        if not o.get("cancel_requested"): return ""
        return (f'<form method="post" action="/panel/order/{o["id"]}/cancel" style="display:flex;gap:4px;margin-top:4px">'
                f''
                '<button class="btn btn-primary btn-sm" name="action" value="approve">تأیید لغو</button>'
                '<button class="btn btn-ghost btn-sm" name="action" value="reject">رد</button></form>')
    trs = "".join(f'''<tr>
      <td class="nums">#{fa(o["id"])}</td>
      <td>{esc(o["bizname"])}</td>
      <td>{esc(o["name"])}<br><small class="text-muted nums" dir="ltr">{esc(o["phone"])}</small></td>
      <td class="nums">{fa_group(o["total"])} تومان</td>
      <td><span class="badge {db.ORDER_LABELS.get(o["status"], ("badge-neutral",""))[0]}">{esc(o["status_label"])}</span></td>
      <td class="nums">{esc(str(o["created"])[:16])}</td>
      <td><form method="post" action="/panel/order/{o["id"]}" style="display:inline-flex;gap:4px">
                <select class="select" name="status" style="min-height:36px">
          {''.join(f'<option value="{st}"{" selected" if o["status"]==st else ""}>{lbl}</option>' for st, lbl in [("new","جدید"),("confirmed","تأیید"),("ready","آماده"),("done","تحویل"),("cancelled","لغو")])}
        </select>
        <button class="btn btn-glass btn-sm" type="submit">ذخیره</button></form>{cancel_admin(o)}</td>
    </tr>''' for o in rows)
    if not trs:
        trs = f'<tr><td colspan="7">{esc("هنوز سفارشی ثبت نشده است.")}</td></tr>'
    content = f'''{_msg(q)}
{panel_pager("/panel/orders", page, pages)}
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("cart")} همهٔ سفارش‌های سایت</h2>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>شماره</th><th>کسب‌وکار</th><th>مشتری</th><th>مبلغ</th><th>وضعیت</th><th>تاریخ</th><th>عملیات</th></tr></thead>
    <tbody>{trs}</tbody></table></div>
</div>'''
    return panel_page(s, "همهٔ سفارش‌ها", "نظارت کامل بر سفارش‌های آنلاین.",
                      content, "/panel/orders", token)


# ==========================================================================
#  SITE CONTENT EDITOR  (v29) — all public text, edited inside the panel only
# ==========================================================================
def editor_page(s, token, q=None):
    q = q or {}
    about = db.get_page("about") or {"title": "درباره ما", "body": ""}
    rules = db.get_page("rules") or {"title": "قوانین و مقررات", "body": ""}

    # a live, server-rendered preview of the hero copy (no iframe, no edit bar)
    preview = f'''<div class="card glass card-pad mb-lg" style="overflow:hidden">
  <span class="eyebrow">{icon("sparkles")}<span>پیش‌نمایش قهرمان صفحهٔ اصلی</span></span>
  <h1 style="font-size:1.5rem;margin:10px 0">{esc(s.get("hero_title", "")).replace(chr(10), "<br>")}</h1>
  <p class="text-muted" style="line-height:1.8">{esc(s.get("hero_lead", ""))}</p>
  <div class="cluster mt-md">
    <span class="btn btn-accent btn-lg" style="pointer-events:none">{icon("plus")}<span>{esc(s.get("hero_cta", ""))}</span></span>
    <span class="btn btn-glass btn-lg" style="pointer-events:none">{icon("map")}<span>نقشهٔ شهر</span></span>
  </div>
</div>'''

    content = f'''{_msg(q)}
{preview}
<form method="post" action="/panel/editor" data-validate>
  
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("store")} هویت سایت</h2>
    <div class="grid grid-2" style="align-items:start">
      <div class="field"><label class="field-label" for="e-name">نام سایت</label>
        <input class="input" id="e-name" name="site_name" maxlength="60" value="{esc(s.get('site_name'))}"></div>
      <div class="field"><label class="field-label" for="e-tag">شعار کوتاه</label>
        <input class="input" id="e-tag" name="tagline" maxlength="120" value="{esc(s.get('tagline'))}"></div>
    </div>
    <div class="field"><label class="field-label" for="e-desc">توضیح سایت (سئو)</label>
      <textarea class="textarea" id="e-desc" name="description" maxlength="400" rows="2">{esc(s.get('description'))}</textarea></div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("zap")} قهرمان صفحهٔ اصلی (Hero)</h2>
    <div class="field"><label class="field-label" for="e-ht">تیتر اصلی</label>
      <textarea class="textarea" id="e-ht" name="hero_title" maxlength="120" rows="2">{esc(s.get('hero_title'))}</textarea>
      <p class="field-hint">برای خط جدید، Enter بزنید.</p></div>
    <div class="field"><label class="field-label" for="e-hl">متن زیر تیتر</label>
      <textarea class="textarea" id="e-hl" name="hero_lead" maxlength="400" rows="3">{esc(s.get('hero_lead'))}</textarea></div>
    <div class="field"><label class="field-label" for="e-hc">متن دکمهٔ اصلی</label>
      <input class="input" id="e-hc" name="hero_cta" maxlength="60" value="{esc(s.get('hero_cta'))}"></div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("file")} صفحات ثابت</h2>
    <div class="grid grid-2" style="align-items:start">
      <div>
        <h3 class="card-title mb-md" style="font-size:1rem">{icon("book")} درباره ما</h3>
        <div class="field"><label class="field-label" for="e-at">عنوان</label>
          <input class="input" id="e-at" name="about_title" maxlength="100" value="{esc(about['title'])}"></div>
        <div class="field"><label class="field-label" for="e-ab">متن</label>
          <textarea class="textarea" id="e-ab" name="about_body" maxlength="4000" rows="7">{esc(about['body'])}</textarea></div>
      </div>
      <div>
        <h3 class="card-title mb-md" style="font-size:1rem">{icon("shield")} قوانین و مقررات</h3>
        <div class="field"><label class="field-label" for="e-rt">عنوان</label>
          <input class="input" id="e-rt" name="rules_title" maxlength="100" value="{esc(rules['title'])}"></div>
        <div class="field"><label class="field-label" for="e-rb">متن</label>
          <textarea class="textarea" id="e-rb" name="rules_body" maxlength="4000" rows="7">{esc(rules['body'])}</textarea></div>
      </div>
    </div>
  </div>

  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("pin")} پاورقی</h2>
    <div class="field"><label class="field-label" for="e-fn">متن پاورقی</label>
      <input class="input" id="e-fn" name="footer_note" maxlength="160" value="{esc(s.get('footer_note'))}"></div>
  </div>

  <div class="cluster">
    <button class="btn btn-primary btn-lg" type="submit">{icon("check")}<span>ذخیرهٔ همهٔ تغییرات</span></button>
    <a class="btn btn-glass" href="/" target="_blank" rel="noopener">{icon("external")}<span>دیدن سایت</span></a>
  </div>
</form>'''
    return panel_page(s, "ویرایش محتوای سایت", "همهٔ متن‌های عمومی سایت را همین‌جا تغییر دهید.",
                      content, "/panel/editor", token)


# ==========================================================================
#  ACTIVITY LOG (v29)
# ==========================================================================
def audit_page(s, token, q=None):
    q = q or {}
    # v117/M5: filters (action / detail / horizon) + CSV export + paging
    f_act = (q.get("action") or [""])[0].strip()[:40]
    f_det = (q.get("detail") or [""])[0].strip()[:60]
    f_days = (q.get("days") or ["0"])[0]
    page = _pg(q)
    res = db._page_slice(db.audit_log(100000, action=f_act, detail=f_det,
                                      days=safe_days(f_days)), page, 50)
    rows, pages = res["rows"], res["pages"]
    qsexp = urllib.parse.urlencode(
        {k: v for k, v in (("action", f_act), ("detail", f_det),
                           ("days", f_days)) if v and v != "0"})
    trs = "".join(f'''<tr>
      <td class="nums">{fa(r["id"])}</td>
      <td><code>{esc(r["action"])}</code></td>
      <td class="text-muted text-sm">{esc(r["detail"])}</td>
      <td class="nums text-muted">{esc(str(r["created"])[:19])}</td>
    </tr>''' for r in rows)
    if not trs:
        trs = f'<tr><td colspan="4">{esc("هنوز فعالیتی ثبت نشده است.")}</td></tr>'
    actions = db.audit_actions()
    act_opts = "".join(
        f'<option value="{esc(a)}"{" selected" if a == f_act else ""}>{esc(a)}</option>'
        for a in actions)
    content = f'''{_msg(q)}
<form class="dir-toolbar" method="get" action="/panel/audit" style="position:static">
  <div class="dir-row">
    <label class="sr-only" for="au-act">رویداد</label>
    <select class="select" id="au-act" name="action">
      <option value="">همهٔ رویدادها</option>{act_opts}</select>
    <label class="sr-only" for="au-det">جست‌وجو در جزئیات</label>
    <input class="input" id="au-det" name="detail" type="search" value="{esc(f_det)}"
           placeholder="جست‌وجو در جزئیات…">
    <label class="sr-only" for="au-days">بازهٔ زمانی</label>
    <select class="select" id="au-days" name="days">
      <option value="0"{" selected" if f_days == "0" else ""}>همهٔ زمان‌ها</option>
      <option value="7"{" selected" if f_days == "7" else ""}>۷ روز اخیر</option>
      <option value="30"{" selected" if f_days == "30" else ""}>۳۰ روز اخیر</option>
      <option value="90"{" selected" if f_days == "90" else ""}>۹۰ روز اخیر</option></select>
    <button class="btn btn-primary btn-sm" type="submit">{icon("search")}<span>اعمال فیلتر</span></button>
    <a class="btn btn-glass btn-sm" href="/panel/audit/export?{qsexp}">
      {icon("download")}<span>خروجی CSV</span></a>
  </div>
</form>
<div class="cluster mb-lg nums text-muted text-sm">{fa(res["total"])} ردیف</div>
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("activity")} گزارش فعالیت‌ها</h2>
  <p class="text-sm text-muted mb-lg">هر تغییر مهم در سایت اینجا ثبت می‌شود — برای پیگیری و ممیزی.</p>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>#</th><th>رویداد</th><th>جزئیات</th><th>زمان</th></tr></thead>
    <tbody>{trs}</tbody></table></div>
</div>
{panel_pager("/panel/audit", page, pages, extra=qsexp)}'''
    return panel_page(s, "گزارش فعالیت‌ها", "رد پای همهٔ تغییرات سایت.",
                      content, "/panel/audit", token)


def safe_days(v):
    try:
        return min(730, max(0, int(v)))
    except (TypeError, ValueError):
        return 0


# ==========================================================================
#  CUSTOMERS (v29)
# ==========================================================================
def customers_page(s, token, q=None):
    q = q or {}
    page = _pg(q)
    res = db.customers_list(page=page)
    rows, pages = res["rows"], res["pages"]
    trs = "".join(f'''<tr>
      <td class="nums">{fa(r["id"])}</td>
      <td class="nums" dir="ltr">{esc(r["phone"])}</td>
      <td>{esc(r.get("name") or "—")}</td>
      <td><span class="badge {"badge-open" if r.get("status","active")=="active" else "badge-closed"}">
        {"فعال" if r.get("status","active")=="active" else "مسدود"}</span></td>
      <td class="nums">{fa(r["n_orders"])} / {fa(r["n_chats"])}</td>
      <td class="nums text-muted">{esc(str(r["created"])[:16])}</td>
      <td class="actions" style="white-space:nowrap">
        <form method="post" action="/panel/customer/{r["id"]}" style="display:inline">
                    <input type="hidden" name="action" value="{"unblock" if r.get("status","active")=="blocked" else "block"}">
          <button class="btn btn-glass btn-sm" type="submit">{"رفع مسدودی" if r.get("status","active")=="blocked" else "مسدود"}</button>
        </form>
        <form method="post" action="/panel/customer/{r["id"]}/delete" data-confirm="مشتری و همهٔ داده‌هایش حذف شود؟" style="display:inline">
                    <button class="btn btn-ghost btn-sm" type="submit">{icon("trash")}<span>حذف</span></button>
        </form>
      </td>
    </tr>''' for r in rows)
    if not trs:
        trs = f'<tr><td colspan="7">{esc("هنوز مشتری ثبت‌نام نکرده است.")}</td></tr>'
    content = f'''{_msg(q)}
{panel_pager("/panel/customers", page, pages)}
<div class="card glass card-pad">
  <div class="between mb-lg">
    <h2 class="card-title">{icon("users")} مشتری‌های سایت</h2>
    <a class="btn btn-primary" href="/panel/broadcast">{icon("send")}<span>ارسال اعلان همگانی</span></a>
  </div>
  <p class="text-sm text-muted mb-lg">هر کسی که با شمارهٔ موبایل وارد «حساب من» شده است. مسدودسازی، نشست فعال او را هم فوراً باطل می‌کند.</p>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>#</th><th>موبایل</th><th>نام</th><th>وضعیت</th><th>سفارش / گفتگو</th><th>عضویت</th><th>عملیات</th></tr></thead>
    <tbody>{trs}</tbody></table></div>
</div>'''
    return panel_page(s, "مشتری‌ها", "مدیریت و مسدودسازی کاربران نهایی سایت.",
                      content, "/panel/customers", token)


def broadcast_page(s, token, q=None):
    q = q or {}
    n_cust = len(db.customers_list())
    content = f'''{_msg(q)}
<div class="card glass card-pad" style="max-width:640px">
  <h2 class="card-title mb-lg">{icon("send")} اعلان همگانی به مشتری‌ها</h2>
  <p class="text-sm text-muted mb-lg">پیام برای <strong class="nums">{fa(n_cust)}</strong> مشتری فعال ارسال می‌شود و در
    «اعلان‌های من» آن‌ها ظاهر می‌گردد.</p>
  <form method="post" action="/panel/broadcast" data-validate>
        <div class="field"><label class="field-label" for="bc-text">متن پیام</label>
      <textarea class="textarea" id="bc-text" name="text" maxlength="200" rows="3" required
        placeholder="مثلاً: جشنوارهٔ تخفیف این هفته آغاز شد!"></textarea></div>
    <div class="field"><label class="field-label" for="bc-link">لینک (اختیاری)</label>
      <input class="input" id="bc-link" name="link" maxlength="200" dir="ltr" placeholder="/deals"></div>
    <button class="btn btn-primary" type="submit">{icon("send")}<span>ارسال به همه</span></button>
  </form>
</div>'''
    return panel_page(s, "اعلان همگانی", "پیام به همهٔ مشتری‌ها.",
                      content, "/panel/broadcast", token)


def follows_page(s, token, q=None):
    q = q or {}
    rows = db.top_followed(50)
    trs = "".join(f'''<tr>
      <td class="nums">{fa(i + 1)}</td>
      <td><a href="/b/{esc(r["slug"])}" target="_blank" rel="noopener">{esc(r["name"])}</a></td>
      <td class="nums"><strong>{fa(r["n"])}</strong> دنبال‌کننده</td>
    </tr>''' for i, r in enumerate(rows) if r["n"])
    if not trs:
        trs = f'<tr><td colspan="3">{esc("هنوز کسی کسب‌وکاری را دنبال نکرده است.")}</td></tr>'
    content = f'''{_msg(q)}
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("heart")} محبوب‌ترین کسب‌وکارها</h2>
  <p class="text-sm text-muted mb-lg">کسب‌وکارها بر اساس تعداد دنبال‌کننده — نشانهٔ علاقهٔ واقعی مشتری‌ها.</p>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>رتبه</th><th>کسب‌وکار</th><th>دنبال‌کننده</th></tr></thead>
    <tbody>{trs}</tbody></table></div>
</div>'''
    return panel_page(s, "دنبال‌کننده‌ها", "کسب‌وکارهای محبوب از نگاه مشتری‌ها.",
                      content, "/panel/follows", token)


# ==========================================================================
#  AREAS (neighbourhoods) manager (v29)
# ==========================================================================
def areas_page(s, token, q=None):
    q = q or {}
    rows = db.areas()
    cards = "".join(f'''<div class="card glass card-pad mb-md" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
      <span class="badge badge-info">{icon("pin")}<span>{esc(r["area"])}</span></span>
      <span class="nums text-muted">{fa(r["c"])} کسب‌وکار</span>
      <form method="post" action="/panel/areas/rename" style="display:inline-flex;gap:8px;flex:1;min-width:240px"
            data-confirm="نام محله برای همهٔ کسب‌وکارها عوض شود؟">
                <input type="hidden" name="old" value="{esc(r['area'])}">
        <input class="input" name="new" maxlength="100" placeholder="نام جدید…" value="{esc(r['area'])}">
        <button class="btn btn-glass btn-sm" type="submit">{icon("check")}<span>تغییر نام</span></button>
      </form>
    </div>''' for r in rows)
    if not cards:
        cards = empty_state("pin", "هنوز محله‌ای ثبت نشده",
            "از فرم ویرایش کسب‌وکارها، فیلد «محله» را پر کنید تا اینجا فهرست شود.")
    content = f'''{_msg(q)}
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("pin")} محله‌های شهر</h2>
  <p class="text-sm text-muted mb-lg">تغییر نام یک محله، روی همهٔ کسب‌وکارهای همان محله اعمال می‌شود.</p>
  {cards}
</div>'''
    return panel_page(s, "محله‌ها", "مدیریت نام محله‌ها و یکدست‌سازی آن‌ها.",
                      content, "/panel/areas", token)


# ==========================================================================
#  ADMIN: TOP LISTS  (v31)
# ==========================================================================
def admin_lists(s, token, q=None):
    q = q or {}
    rows = db.toplists(active_only=False)
    trs = "".join(f'''<tr>
      <td>{esc(t["title"])}</td>
      <td><span class="badge badge-info">{esc({"manual":"دستی","auto_rating":"برترین امتیاز","auto_views":"پربازدید","auto_featured":"ویژه‌ها","auto_new":"تازه‌ها"}.get(t["kind"], t["kind"]))}</span></td>
      <td class="nums">{fa(len(db.toplist_businesses(t)))}</td>
      <td><span class="badge {"badge-open" if t["active"] else "badge-neutral"}">{"فعال" if t["active"] else "غیرفعال"}</span></td>
      <td class="actions">
        <a class="btn-icon" href="/panel/list/{t["id"]}" aria-label="ویرایش">{icon("edit")}</a>
        <form method="post" action="/panel/list/{t["id"]}/delete" data-confirm="لیست حذف شود؟" style="display:inline">
                    <button class="btn-icon" type="submit" aria-label="حذف">{icon("trash")}</button></form>
      </td>
    </tr>''' for t in rows)
    if not trs:
        trs = f'<tr><td colspan="5">{esc("هنوز لیستی ساخته نشده است.")}</td></tr>'

    biz_opts = "".join(f'<option value="{b["id"]}">{esc(b["name"])}</option>' for b in db.businesses())
    content = f'''{_msg(q)}
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-lg">{icon("trophy")} لیست جدید</h2>
  <form method="post" action="/panel/list/new" data-validate>
        <div class="grid grid-2" style="align-items:start">
      <div class="field"><label class="field-label">عنوان</label>
        <input class="input" name="title" aria-label="عنوان لیست" maxlength="100" required placeholder="مثلاً بهترین کبابی‌ها"></div>
      <div class="field"><label class="field-label">نوع</label>
        <select class="select" name="kind" aria-label="نوع لیست">
          <option value="manual">دستی</option>
          <option value="auto_rating">خودکار: برترین امتیاز</option>
          <option value="auto_views">خودکار: پربازدیدترین</option>
          <option value="auto_featured">خودکار: ویژه‌ها</option>
          <option value="auto_new">خودکار: تازه‌ترین‌ها</option>
        </select></div>
    </div>
    <div class="field"><label class="field-label">توضیح</label>
      <input class="input" name="descr" aria-label="توضیح لیست" maxlength="200" placeholder="یک جمله دربارهٔ این لیست"></div>
    <button class="btn btn-primary" type="submit">{icon("plus")}<span>ساخت لیست</span></button>
  </form>
</div>
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("list")} لیست‌های موجود</h2>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>عنوان</th><th>نوع</th><th>تعداد</th><th>وضعیت</th><th></th></tr></thead>
    <tbody>{trs}</tbody></table></div>
</div>'''
    return panel_page(s, "برترین‌های شهر", "لیست‌های رتبه‌بندی سایت.",
                      content, "/panel/lists", token)


def admin_list_edit(s, token, tid, q=None):
    q = q or {}
    t = db.toplist(tid=tid)
    if not t:
        return None
    rows = db.toplist_businesses(t)
    try:
        saved_ids = [int(x) for x in json.loads(t.get("items") or "[]")]
    except (TypeError, ValueError):
        saved_ids = []
    # candidates: current members first, then the rest
    members = [b for b in db.businesses() if b["id"] in saved_ids]
    others = [b for b in db.businesses() if b["id"] not in saved_ids]

    def _opt(b, in_list):
        return f'<option value="{b["id"]}"{" selected" if in_list else ""}>{esc(b["name"])}</option>'

    member_opts = "".join(_opt(b, True) for b in members) or '<option value="">— خالی —</option>'
    other_opts = "".join(_opt(b, False) for b in others)

    content = f'''{_msg(q)}
<form method="post" action="/panel/list/{tid}" data-validate>
    <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("edit")} ویرایش لیست</h2>
    <div class="grid grid-2" style="align-items:start">
      <div class="field"><label class="field-label">عنوان</label>
        <input class="input" name="title" maxlength="100" value="{esc(t["title"])}" required></div>
      <div class="field"><label class="field-label">نوع</label>
        <select class="select" name="kind">
          {''.join(f'<option value="{k}"{" selected" if t["kind"]==k else ""}>{l}</option>' for k, l in [("manual","دستی"),("auto_rating","خودکار: برترین امتیاز"),("auto_views","خودکار: پربازدید"),("auto_featured","خودکار: ویژه‌ها"),("auto_new","خودکار: تازه‌ها")])}
        </select></div>
    </div>
    <div class="field"><label class="field-label">توضیح</label>
      <input class="input" name="descr" maxlength="200" value="{esc(t.get("descr") or "")}"></div>
    <div class="grid grid-2" style="align-items:start">
      <div class="field"><label class="field-label">حداکثر تعداد</label>
        <input class="input nums" name="limit_n" type="number" min="3" max="50" value="{int(t.get("limit_n") or 10)}"></div>
      <div class="field"><label class="field-label">وضعیت</label>
        <select class="select" name="active">
          <option value="1"{" selected" if t["active"] else ""}>فعال</option>
          <option value="0"{" selected" if not t["active"] else ""}>غیرفعال</option>
        </select></div>
    </div>
  </div>
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-lg">{icon("store")} کسب‌وکارهای لیست (به‌ترتیب)</h2>
    <p class="text-sm text-muted mb-lg">برای لیست دستی، ترتیب انتخاب همان ترتیب نمایش است.</p>
    <select class="select" name="items" multiple size="14" style="height:auto">
      {member_opts}{other_opts}
    </select>
    <p class="field-hint">با نگه‌داشتن Ctrl/لمس چندتایی انتخاب کنید. برای لیست خودکار، این بخش نادیده گرفته می‌شود.</p>
  </div>
  <button class="btn btn-primary btn-lg" type="submit">{icon("check")}<span>ذخیره</span></button>
</form>'''
    return panel_page(s, f"ویرایش لیست: {t['title']}", "",
                      content, "/panel/lists", token)


# ==========================================================================
#  ADMIN: FLASH DEALS  (v31)
# ==========================================================================
def admin_deals(s, token, q=None):
    q = q or {}
    rows = db.flashdeals(active_only=False)
    trs = "".join(f'''<tr>
      <td>{esc(d["title"])}</td>
      <td>{esc(d["bizname"])}</td>
      <td class="nums">{fa(d["percent"])}٪</td>
      <td class="nums text-muted">{esc(str(d["ends"])[:16])}</td>
      <td><span class="badge {"badge-open" if d["active"] else "badge-neutral"}">{"فعال" if d["active"] else "غیرفعال"}</span></td>
      <td><form method="post" action="/panel/deal/{d["id"]}/delete" data-confirm="حذف شود؟" style="display:inline">
                <button class="btn-icon" type="submit" aria-label="حذف">{icon("trash")}</button></form></td>
    </tr>''' for d in rows)
    if not trs:
        trs = f'<tr><td colspan="6">{esc("هنوز فلش‌سیلی ساخته نشده است.")}</td></tr>'

    biz_opts = "".join(f'<option value="{b["id"]}">{esc(b["name"])}</option>' for b in db.businesses())
    content = f'''{_msg(q)}
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-lg">{icon("zap")} فلش‌سیل جدید</h2>
  <form method="post" action="/panel/deal/new" data-validate>
        <div class="grid grid-2" style="align-items:start">
      <div class="field"><label class="field-label">عنوان</label>
        <input class="input" name="title" aria-label="عنوان فلش‌سیل" maxlength="100" required placeholder="مثلاً ۲۰٪ تخفیف امروز"></div>
      <div class="field"><label class="field-label">کسب‌وکار</label>
        <select class="select" name="biz_id" aria-label="کسب‌وکار" required>{biz_opts}</select></div>
      <div class="field"><label class="field-label">درصد تخفیف</label>
        <input class="input nums" name="percent" aria-label="درصد تخفیف" type="number" min="1" max="90" value="20"></div>
      <div class="field"><label class="field-label">پایان (تاریخ و ساعت)</label>
        <input class="input" name="ends" aria-label="زمان پایان" dir="ltr" required placeholder="2026-08-19 23:59"></div>
    </div>
    <div class="field"><label class="field-label">توضیح</label>
      <input class="input" name="descr" aria-label="توضیح فلش‌سیل" maxlength="200" placeholder="شرط تخفیف، محدودیت و…"></div>
    <button class="btn btn-primary" type="submit">{icon("plus")}<span>ساخت فلش‌سیل</span></button>
  </form>
</div>
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("list")} فلش‌سیل‌های موجود</h2>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>عنوان</th><th>کسب‌وکار</th><th>تخفیف</th><th>پایان</th><th>وضعیت</th><th></th></tr></thead>
    <tbody>{trs}</tbody></table></div>
</div>'''
    return panel_page(s, "پیشنهادهای روز", "تخفیف‌های لحظه‌ای با شمارش معکوس.",
                      content, "/panel/deals", token)


# ==========================================================================
#  ADMIN: STORIES  (v31)
# ==========================================================================
def admin_stories(s, token, q=None):
    q = q or {}
    rows = db.stories_active()
    items = "".join(f'''<div class="card glass card-pad mb-md" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
      <img src="{esc(r["image"])}" alt="" style="width:64px;height:64px;object-fit:cover;border-radius:12px" loading="lazy">
      <div style="flex:1;min-width:180px">
        <strong>{esc(r["bizname"])}</strong>
        <p class="text-sm text-muted">{esc(r.get("caption") or "بدون توضیح")}</p>
      </div>
      <form method="post" action="/panel/story/{r["id"]}/delete" data-confirm="استوری حذف شود؟" style="display:inline">
                <button class="btn btn-ghost btn-sm" type="submit">{icon("x")}<span>حذف</span></button>
      </form>
    </div>''' for r in rows)
    if not items:
        items = empty_state("image", "استوری‌ای فعال نیست",
                            "استوری‌های ۲۴ ساعتهٔ کسب‌وکارها اینجا می‌آیند.")
    content = f'''{_msg(q)}
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("image")} همهٔ استوری‌های فعال</h2>
  {items}
</div>'''
    return panel_page(s, "استوری‌ها", "نظارت بر استوری‌های ۲۴ ساعته.",
                      content, "/panel/stories", token)


# ==========================================================================
#  DEMO DATA  —  one-click sample data for previewing the site
#
#  Lets the owner fill the site with believable sample businesses (with
#  reviews, questions, catalogue, stories, an event, a banner and a coupon)
#  to judge the design, then wipe every trace in one go. The same logic as
#  tools/seed_demo.py, but reachable from inside the panel — no terminal.
# ==========================================================================
def demo_page(s, token, q=None):
    q = q or {}
    n_biz = len(db.businesses(status=None))
    n_demo = sum(1 for b in db.businesses(status=None)
                 if "نمونه‌آزمایشی" in (b.get("tags") or ""))
    n_items = len(db.items())
    content = f'''{_msg(q)}
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-md">{icon("sparkles")} دادهٔ نمونهٔ آزمایشی</h2>
  <p class="text-sm text-muted mb-lg">برای دیدن سایت «پر و زنده» قبل از انتشار، یک‌دکمه‌ای
     ده کسب‌وکار نمونه با نظر، پرسش، کاتالوگ، استوری، رویداد، بنر و کد تخفیف می‌سازد.
     همهٔ این‌ها با برچسب «نمونه‌آزمایشی» علامت می‌خورند تا بعداً دقیق و بی‌خطا پاک شوند —
     بدون دست‌زدن به دادهٔ واقعی شما.</p>
  <div class="grid grid-3" style="gap:10px">
    {stat_card("store", n_biz, "کل کسب‌وکارها")}
    {stat_card("sparkles", n_demo, "نمونهٔ آزمایشی", delay=60)}
    {stat_card("shopping", n_items, "اقلام کاتالوگ", delay=120)}
  </div>
</div>

<div class="grid grid-2" style="gap:14px">
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("check-circle")} ساخت دادهٔ نمونه</h3>
    <p class="text-sm text-muted mb-lg">سایت را با ۱۰ کسب‌وکار واقع‌نما پر می‌کند تا بتوانید
       همهٔ بخش‌ها (نقشه، استوری، مقایسهٔ قیمت، فلش‌سیل، برترین‌ها) را زنده ببینید.
       اگر نمونهٔ قبلی باشد، اول همان پاک و از نو ساخته می‌شود.</p>
    <form method="post" action="/panel/demo" data-confirm="دادهٔ نمونه ساخته شود؟ (نمونهٔ قبلی پاک و از نو ساخته می‌شود)">
            <input type="hidden" name="action" value="seed">
      <button class="btn btn-primary btn-block" type="submit">{icon("sparkles")}<span>ایجاد دادهٔ نمونه</span></button>
    </form>
  </div>
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("trash")} پاک‌کردن دادهٔ نمونه</h3>
    <p class="text-sm text-muted mb-lg">فقط چیزهایی را حذف می‌کند که برچسب «نمونه‌آزمایشی»
       دارند (یا کد تخفیف DEMO). کسب‌وکارهای واقعی و تنظیمات شما دست‌نخورده می‌مانند.</p>
    <form method="post" action="/panel/demo" data-confirm="همهٔ دادهٔ نمونه حذف شود؟ این کار بازگشت ندارد.">
            <input type="hidden" name="action" value="clear">
      <button class="btn btn-danger btn-block" type="submit">{icon("trash")}<span>پاک‌کردن همهٔ دادهٔ نمونه</span></button>
    </form>
  </div>
</div>'''
    return panel_page(s, "دادهٔ نمونه", "پر و خالی‌کردن سریع سایت برای پیش‌نمایش.",
                      content, "/panel/demo", token)


# ==========================================================================
#  v105 — RECYCLE BIN (admin: every entity, 7-day retention, restorable)
# ==========================================================================
def admin_traffic(s, token, q=None):
    """v112: live abuse-shield report — who is hitting the site, who is
    throttled/blocked, and why. The owner asked for real numbers behind the
    'spam requests' feeling; this page is the evidence."""
    import time as _t
    import shield
    q = q or {}
    r = shield.report()
    st = r["stats"]
    tiles = "".join(
        f'<div class="card glass card-pad" style="flex:1 1 120px;text-align:center">'
        f'<strong class="nums" style="font-size:22px;display:block">{fa(v)}</strong>'
        f'<small class="text-muted">{esc(k)}</small></div>'
        for k, v in (("کل درخواست‌ها", st["total"]), ("۴۲۹ (نرخ)", st["throttled"]),
                     ("اسکنر", st["scan"]), ("بات مخرب", st["badua"]),
                     ("مسدودی", st["blocks"])))
    if r["top_ip"]:
        rows = "".join(
            f'<tr><td class="nums">{esc(ip)}</td><td class="nums">{fa(c)}</td></tr>'
            for ip, c in r["top_ip"])
        top_ip = ('<table><thead><tr><th>آی‌پی (۱۰ دقیقهٔ اخیر)</th><th>درخواست</th>'
                  '</tr></thead><tbody>' + rows + '</tbody></table>')
    else:
        top_ip = '<p class="text-muted text-sm">در ۱۰ دقیقهٔ اخیر ترافیکی ثبت نشده.</p>'
    if r["top_ua"]:
        rows = "".join(
            f'<tr><td style="direction:ltr;text-align:left">{esc(ua)}</td>'
            f'<td class="nums">{fa(c)}</td></tr>'
            for ua, c in r["top_ua"])
        top_ua = ('<table><thead><tr><th>User-Agent</th><th>تعداد</th></tr></thead><tbody>'
                  + rows + '</tbody></table>')
    else:
        top_ua = ""
    if r["blocked"]:
        rows = ""
        for ip, reason, sec in r["blocked"]:
            rows += (f'<tr><td class="nums">{esc(ip)}</td><td>{esc(reason)}</td>'
                     f'<td class="nums">{fa(sec // 60)} دقیقه مانده</td>'
                     f'<td><form method="post" action="/panel/traffic/unblock" style="display:inline">'
                     f''
                     f'<input type="hidden" name="ident" value="{esc(ip)}">'
                     f'<button class="btn btn-glass btn-sm" type="submit"><span>برداشتن مسدودی</span></button>'
                     f'</form></td></tr>')
        blocked = ('<table><thead><tr><th>آی‌پی</th><th>دلیل</th><th>مانده</th><th></th>'
                   '</tr></thead><tbody>' + rows + '</tbody></table>')
    else:
        blocked = '<p class="text-muted text-sm">الان کسی مسدود نیست.</p>'
    if r["events"]:
        evs = ""
        for ts, ip, why, path in reversed(r["events"]):
            evs += (f'<li class="text-sm" style="direction:ltr;text-align:left">'
                    f'{_t.strftime("%H:%M:%S", _t.localtime(ts))} · {esc(why)} · '
                    f'{esc(ip)} · {esc(path)}</li>')
        events = f'<ul style="display:grid;gap:4px">{evs}</ul>'
    else:
        events = '<p class="text-muted text-sm">رویدادی ثبت نشده — یعنی الگوی مخربی دیده نشده.</p>'
    content = f'''{_msg(q)}
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-md">سپر ضد-اسپم (v112)</h2>
  <p class="text-sm text-muted mb-lg">نرخ: بیش از {fa(r["limit"])} درخواست در {fa(r["window"])} ثانیه از یک آی‌پی = ۴۲۹؛
  تکرار = مسدود ۱۰ دقیقه‌ای. مسیرهای اسکنر و ابزارهای مخرب = ۴۰۳/۴۰ و پس از ۳ ضربه، مسدود ۳۰ دقیقه‌ای.
  آی‌پی مشترک (CGNAT) اشتباهی مسدود شد؟ از همین صفحه بردارید.</p>
  <div style="display:flex;gap:10px;flex-wrap:wrap" class="mb-lg">{tiles}</div>
  <div style="display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(240px,1fr))">
    <div><h3 class="mb-sm">پرمراجعه‌ترین آی‌پی‌ها</h3>{top_ip}</div>
    <div><h3 class="mb-sm">عامل‌های کاربر (UA)</h3>{top_ua or '<p class="text-muted text-sm">—</p>'}</div>
  </div>
  <h3 class="mt-lg mb-sm">مسدودهای فعال</h3>{blocked}
  <h3 class="mt-lg mb-sm">رویدادهای اخیر سپر</h3>{events}
</div>'''
    return panel_page(s, "ترافیک و سپر",
                      "چه کسی به سایت می‌کوبد؟ عددها این‌جانند، نه حدس.",
                      content, "/panel/traffic", token)


def admin_analytics(s, token, q=None):
    """v114: real-visit analytics — every public page view is one row in
    `visits` with the real visitor identity (IP + bz_cid cookie + device +
    session + referrer). Bots are recorded but excluded from the "real
    people" numbers and from the public counters."""
    import time as _t
    import analytics
    q = q or {}
    r = analytics.overview()
    tiles = "".join(
        f'<div class="card glass card-pad" style="flex:1 1 120px;text-align:center">'
        f'<strong class="nums" style="font-size:22px;display:block">{fa(v)}</strong>'
        f'<small class="text-muted">{esc(k)}</small></div>'
        for k, v in (("الان آنلاین", r["online"]),
                     ("بازدید ۲۴ ساعت", r["pv24"]), ("بازدیدکننده ۲۴ ساعت", r["uv24"]),
                     ("بازدید ۷ روز", r["pv7"]), ("بازدید ۳۰ روز", r["pv30"]),
                     ("نشست ۲۴ ساعت", r["sessions24"]), ("بات ۲۴ ساعت", r["bots24"])))
    spark = db.sparkline_svg([n for _, n in r["series"]], w=320, h=48) or \
        '<span class="text-muted text-sm">هنوز داده‌ای برای نمودار نیست.</span>'

    def tbl(headers, rows):
        if not rows:
            return '<p class="text-muted text-sm">—</p>'
        th = "".join(f"<th>{h}</th>" for h in headers)
        tr = "".join(f"<tr>{c}</tr>" for c in rows)
        return f"<table><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table>"

    kind = analytics.KIND_FA
    top_pages = tbl(("صفحه", "نوع", "بازدید", "بازدیدکننده"), [
        f'<td style="direction:ltr;text-align:left">{esc(x["path"])}</td>'
        f'<td>{esc(kind.get(x["kind"], x["kind"]))}</td>'
        f'<td class="nums">{fa(x["n"])}</td><td class="nums">{fa(x["uv"])}</td>'
        for x in r["top_pages"]])
    top_biz = tbl(("کسب‌وکار", "بازدید", "بازدیدکننده"), [
        f'<td><a href="/b/{esc(x["slug"])}">{esc(x["name"])}</a></td>'
        f'<td class="nums">{fa(x["n"])}</td><td class="nums">{fa(x["uv"])}</td>'
        for x in r["top_biz"]])
    top_stories = tbl(("استوری", "بازدید", "بازدیدکننده"), [
        f'<td class="nums">#{fa(x["story_id"])}</td>'
        f'<td class="nums">{fa(x["n"])}</td><td class="nums">{fa(x["uv"])}</td>'
        for x in r["top_stories"]])
    dev_fa = {"mobile": "موبایل", "tablet": "تبلت", "desktop": "دسکتاپ"}
    devices = tbl(("دستگاه", "بازدید"), [
        f'<td>{esc(dev_fa.get(x["dev"], x["dev"]))}</td>'
        f'<td class="nums">{fa(x["n"])}</td>' for x in r["devices"]])
    refs = tbl(("منبع ورود", "بازدید"), [
        f'<td style="direction:ltr;text-align:left">{esc(host)}</td>'
        f'<td class="nums">{fa(n)}</td>' for host, n in r["referrers"]])
    cities = tbl(("شهر", "استان", "بازدید", "بازدیدکننده"), [
        f'<td>{esc(x["city"])}</td><td>{esc(x["prov"])}</td>'
        f'<td class="nums">{fa(x["n"])}</td><td class="nums">{fa(x["uv"])}</td>'
        for x in r["top_cities"]])
    campaigns = tbl(("کمپین (utm)", "بازدید", "بازدیدکننده"), [
        f'<td style="direction:ltr;text-align:left">{esc(x["utm"])}</td>'
        f'<td class="nums">{fa(x["n"])}</td><td class="nums">{fa(x["uv"])}</td>'
        for x in r["campaigns"]])
    # 7×24 heat grid — formal styling: token border cells, intensity via
    # color-mix on the primary token (no baked colours, both themes safe).
    days_fa = ("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")
    hmax = max((v for row in r["heat"] for v in row), default=0) or 1
    hrs = "".join(f'<th class="nums" style="font-size:9px;padding:2px">{fa(h)}</th>'
                  for h in range(0, 24, 2))
    grid = ""
    for i, row in enumerate(r["heat"]):
        cells = ""
        for h in range(24):
            v = row[h]
            pct = int(v / hmax * 88) + (4 if v else 0)
            style = (f'background:color-mix(in srgb, var(--color-primary) {pct}%, transparent)'
                     if v else "")
            cells += (f'<td title="{days_fa[i]} ساعت {fa(h)}: {fa(v)}" '
                      f'style="height:16px;min-width:10px;padding:0;{style}"></td>')
        grid += f'<tr><th style="font-size:10px;white-space:nowrap;padding-inline-end:6px">{days_fa[i]}</th>{cells}</tr>'
    heat = (f'<div style="overflow-x:auto"><table style="border-collapse:collapse">'
            f'<thead><tr><th></th>{hrs}</tr></thead><tbody>{grid}</tbody></table></div>'
            f'<p class="text-xs text-muted mt-sm">پررنگ‌تر = بازدید بیشتر · '
            f'بیشترین خانه: {fa(hmax)} بازدید در یک ساعت</p>')
    if r["recent"]:
        rows = ""
        for x in r["recent"]:
            badge = ('<span class="badge">بات</span>' if x["bot"]
                     else '<span class="badge badge-featured">واقعی</span>')
            rows += (f'<tr><td class="nums">{_t.strftime("%m-%d %H:%M", _t.localtime(x["ts"]))}</td>'
                     f'<td>{esc(kind.get(x["kind"], x["kind"]))}</td>'
                     f'<td style="direction:ltr;text-align:left">{esc(x["path"])}</td>'
                     f'<td class="nums" style="direction:ltr">{esc(x["ip"])}</td>'
                     f'<td>{esc(dev_fa.get(x["dev"], x["dev"]))}</td>'
                     f'<td class="nums" style="direction:ltr">{esc((x["cid"] or "")[:8])}…</td>'
                     f'<td>{badge}</td></tr>')
        recent = ('<div style="overflow-x:auto"><table><thead><tr><th>زمان</th><th>نوع</th>'
                  '<th>مسیر</th><th>آی‌پی</th><th>دستگاه</th><th>شناسهٔ بازدیدکننده</th>'
                  '<th></th></tr></thead><tbody>' + rows + '</tbody></table></div>')
    else:
        recent = '<p class="text-muted text-sm">هنوز بازدیدی ثبت نشده.</p>'
    ga = (s.get("ga_measurement_id") or "").strip()
    ga_note = (f'گوگل‌آنالیتیکس فعال است (<span class="nums" style="direction:ltr">{esc(ga)}</span>) — '
               'کوکی‌های _ga روی مرورگر بازدیدکننده‌ها ثبت می‌شود.'
               if ga else
               'گوگل‌آنالیتیکس هنوز فعال نیست — شناسهٔ G-… را در «تنظیمات سایت» وارد کنید '
               '(راهنما: docs/google-analytics.md).')
    export_href = f"/panel/analytics/export?days=30"
    content = f'''{_msg(q)}
<div class="card glass card-pad mb-lg">
  <div class="between mb-md" style="flex-wrap:wrap;gap:8px">
    <h2 class="card-title">آمار بازدید واقعی (v115)</h2>
    <a class="btn btn-glass btn-sm" href="{export_href}">{icon("download")}<span>خروجی CSV (۳۰ روز)</span></a>
  </div>
  <p class="text-sm text-muted mb-lg">هر بازدیدِ صفحه با هویت واقعی ثبت می‌شود: آی‌پی،
  شهر (تقریبی، از روی بازهٔ IP — پایگاه آفلاین DB-IP)، دستگاه، کوکی شناسهٔ
  بازدیدکننده (bz_cid) و نشست ۳۰ دقیقه‌ای. بات‌ها ثبت می‌شوند ولی از عددهای
  «واقعی» بیرون می‌مانند. آی‌پی‌ها حداکثر ۹۰ روز نگه‌داشته و سپس پاک می‌شوند. {ga_note}</p>
  <div style="display:flex;gap:10px;flex-wrap:wrap" class="mb-lg">{tiles}</div>
  <h3 class="mb-sm">روند ۱۴ روز گذشته</h3>
  <div class="mb-lg">{spark}</div>
  <h3 class="mb-sm">ساعت اوج — چه زمانی مشتری‌ها آنلاین‌اند؟</h3>
  <div class="mb-lg">{heat}</div>
  <div style="display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(240px,1fr))">
    <div><h3 class="mb-sm">صفحه‌های پربازدید (۷ روز)</h3>{top_pages}</div>
    <div><h3 class="mb-sm">کسب‌وکارهای پربازدید (۷ روز)</h3>{top_biz}</div>
    <div><h3 class="mb-sm">استوری‌های پربازدید (۷ روز)</h3>{top_stories}</div>
    <div><h3 class="mb-sm">شهرها (۷ روز)</h3>{cities}</div>
    <div><h3 class="mb-sm">دستگاه‌ها (۷ روز)</h3>{devices}</div>
    <div><h3 class="mb-sm">منابع ورود (۷ روز)</h3>{refs}</div>
    <div><h3 class="mb-sm">کمپین‌های utm (۳۰ روز)</h3>{campaigns}</div>
  </div>
  <h3 class="mt-lg mb-sm">آخرین بازدیدها</h3>{recent}
</div>'''
    return panel_page(s, "آمار بازدید",
                      "بازدید واقعی با آی‌پی و هویت جداگانهٔ افراد — بدون حدس.",
                      content, "/panel/analytics", token)


def admin_trash(s, token, q=None):
    import time as _t
    q = q or {}
    label = {"story": "استوری", "item": "محصول/خدمت", "review": "نظر", "report": "گزارش"}
    rows = db.trash_list()
    if rows:
        items = ""
        for r in rows:
            keep = "۷ روز" if r["entity"] == "story" else "۲۴ ساعت"
            left_s = db.trash_left_seconds(r)
            left = (f"{left_s // 3600} ساعت مانده" if left_s >= 3600
                    else f"{max(1, left_s // 60)} دقیقه مانده")
            items += f'''<div class="card glass card-pad mb-md" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
              <span class="badge">{label.get(r["entity"], r["entity"])}</span>
              <div style="flex:1;min-width:160px"><strong>{esc(r["title"] or "بدون عنوان")}</strong>
                <small class="text-muted nums"> کسب‌وکار {esc(str(r["biz_id"]))} · حذف در
                {_t.strftime("%m-%d %H:%M", _t.localtime(r["deleted_at"]))} · مهلت {keep} ({left})</small></div>
              <form method="post" action="/panel/trash/{r["id"]}/restore" style="display:inline">
                                <button class="btn btn-glass btn-sm" type="submit"><span>بازیابی</span></button>
              </form>
            </div>'''
    else:
        items = empty_state("x", "سطل خالی است",
                            "استوری حذف‌شده تا ۷ روز و محصول/نظر/گزارش حذف‌شده تا ۲۴ ساعت "
                            "این‌جا می‌ماند و بعد برای همیشه پاک می‌شود.")
    content = f'''{_msg(q)}
<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-lg">سطل بازیافت (سراسری)</h2>
  <p class="text-sm text-muted mb-lg">استوری حذف‌شده تا ۷ روز، محصول/نظر/گزارش تا ۲۴ ساعت —
  برای پیگیری گزارش‌ها و بازیابی تصادفی‌ها.</p>
  {items}
</div>'''
    return panel_page(s, "سطل بازیافت",
                      "حذف‌شده‌های اخیر کل سایت با امکان بازیابی.",
                      content, "/panel/trash", token)


# ==========================================================================
#  PANEL SEARCH (v117/M4) — one no-JS page that sweeps every entity the
#  palette can reach, so the admin can find anything from one box.
# ==========================================================================
def panel_search(s, token, q=None):
    q = q or {}
    term = (q.get("q") or [""])[0].strip()[:80]
    like = f"%{term}%"
    sections = []

    def section(icon_name, title, rows, href_fn, label_fn):
        if not rows:
            return ""
        lis = "".join(
            f'<a class="todo-item" href="{href_fn(r)}">{icon("chevron-left")}'
            f'<span>{label_fn(r)}</span>{icon("chevron-left")}</a>'
            for r in rows[:8])
        more = (f'<span class="text-muted text-sm nums">+{fa(len(rows) - 8)} مورد دیگر</span>'
                if len(rows) > 8 else "")
        return (f'<div class="card glass card-pad mb-lg"><h2 class="card-title mb-md">'
                f'{icon(icon_name)} {esc(title)} <span class="nums text-muted">'
                f'{fa(len(rows))}</span> {more}</h2>{lis}</div>')

    if term:
        con = db.connect()
        biz = con.execute(
            "SELECT id, name, slug, phone FROM businesses WHERE name LIKE ? "
            "OR phone LIKE ? OR slug LIKE ? ORDER BY id DESC LIMIT 30",
            (like, like, like)).fetchall()
        cust = con.execute(
            "SELECT id, phone, name FROM customers WHERE phone LIKE ? OR name LIKE ? "
            "ORDER BY id DESC LIMIT 30", (like, like)).fetchall()
        rev = con.execute(
            "SELECT r.id, r.author, b.name bizname FROM reviews r JOIN businesses b "
            "ON b.id=r.biz_id WHERE r.author LIKE ? OR r.body LIKE ? "
            "ORDER BY r.id DESC LIMIT 30", (like, like)).fetchall()
        tkt = con.execute(
            "SELECT id, subject, name FROM tickets WHERE subject LIKE ? OR name LIKE ? "
            "OR phone LIKE ? ORDER BY id DESC LIMIT 30", (like, like, like)).fetchall()
        own = con.execute(
            "SELECT id, phone, name FROM owners WHERE phone LIKE ? OR name LIKE ? "
            "ORDER BY id DESC LIMIT 30", (like, like)).fetchall()
        con.close()

        sections.append(section("store", "کسب‌وکارها", biz,
                                lambda r: f"/panel/business/{r['id']}",
                                lambda r: f"{r['name']} — {r['phone']}"))
        sections.append(section("users", "مشتری‌ها", cust,
                                lambda r: f"/panel/customer/{r['id']}",
                                lambda r: f"{r['name'] or 'بدون نام'} — {r['phone']}"))
        sections.append(section("message", "نظرات", rev,
                                lambda r: f"/panel/reviews?q={urllib.parse.quote(term)}",
                                lambda r: f"{r['author']} دربارهٔ {r['bizname']}"))
        sections.append(section("help", "تیکت‌ها", tkt,
                                lambda r: f"/panel/ticket/{r['id']}",
                                lambda r: r["subject"]))
        sections.append(section("shield", "دکان‌داران", own,
                                lambda r: f"/panel/owner/{r['id']}",
                                lambda r: f"{r['name'] or '—'} — {r['phone']}"))
        body = "".join(sections) or _empty("search", "چیزی یافت نشد",
                                           "عبارت دیگری را امتحان کنید.")
    else:
        body = _empty("search", "جست‌وجو در پنل",
                      "نام کسب‌وکار، تلفن مشتری یا دکان‌دار، موضوع تیکت یا متن نظر را بنویسید.")

    content = f'''<form class="dir-toolbar" method="get" action="/panel/search">
      <span class="search-wrap">{icon("search", cls="search-icon")}
        <label class="sr-only" for="ps-q">جست‌وجو</label>
        <input class="input" id="ps-q" name="q" type="search" value="{esc(term)}"
               placeholder="مثلاً: نام دکان، تلفن، موضوع تیکت…" autofocus></span>
      <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
    </form>
    {body}'''
    return panel_page(s, "جست‌وجوی پنل", "یافتن هر چیز در همهٔ بخش‌های پنل.",
                      content, "/panel/search", token)


# ==========================================================================
#  UNIFIED MODERATION QUEUE (v117/M5) — every pending thing on one page.
#  Sections mirror the sidebar counters; quick actions reuse the existing
#  per-item POST endpoints (no new mutations, one place to work through).
# ==========================================================================
def moderation_page(s, token, q=None):
    con = db.connect()
    pend_biz = con.execute(
        "SELECT id, name FROM businesses WHERE status='pending' ORDER BY id DESC LIMIT 5").fetchall()
    pend_rev = con.execute(
        "SELECT r.id, r.author, b.name bizname FROM reviews r JOIN businesses b "
        "ON b.id=r.biz_id WHERE r.status='pending' ORDER BY r.id DESC LIMIT 5").fetchall()
    open_rep = con.execute(
        "SELECT id, reason FROM reports WHERE status='open' ORDER BY id DESC LIMIT 5").fetchall()
    pend_edits = con.execute(
        "SELECT e.id, b.name bizname FROM edits e JOIN businesses b ON b.id=e.biz_id "
        "WHERE e.status='pending' ORDER BY e.id DESC LIMIT 5").fetchall()
    pend_claims = con.execute(
        "SELECT c.id, b.name bizname FROM claims c JOIN businesses b ON b.id=c.biz_id "
        "WHERE c.status='pending' ORDER BY c.id DESC LIMIT 5").fetchall()
    pend_qa = con.execute(
        "SELECT id, body FROM questions WHERE status='pending' ORDER BY id DESC LIMIT 5").fetchall()
    pend_sub = con.execute(
        "SELECT id, biz_id FROM subscriptions WHERE status='pending' ORDER BY id DESC LIMIT 5").fetchall()
    con.close()

    def quick_review(r):
        return (f'<div class="todo-item"><span class="icon-wrap">{icon("message")}</span>'
                f'<span class="mod-item"><strong>{esc(r["author"])}</strong> '
                f'<small class="text-muted">دربارهٔ {esc(r["bizname"])}</small></span>'
                f'<form method="post" action="/panel/review/{r["id"]}">'
                f'<input type="hidden" name="action" value="approve">'
                f'<button class="btn-icon btn-approve" type="submit" title="تأیید" aria-label="تأیید نظر">{icon("check-circle")}</button></form>'
                f'<form method="post" action="/panel/review/{r["id"]}">'
                f'<input type="hidden" name="action" value="reject">'
                f'<button class="btn-icon" type="submit" title="رد" aria-label="رد نظر">{icon("x-circle")}</button></form>'
                f'</div>')

    def quick_report(r):
        return (f'<div class="todo-item"><span class="icon-wrap">{icon("alert")}</span>'
                f'<span class="mod-item"><strong>{esc(db.reason_label(r["reason"]))}</strong></span>'
                f'<form method="post" action="/panel/report/{r["id"]}">'
                f'<input type="hidden" name="action" value="resolve">'
                f'<button class="btn-icon btn-approve" type="submit" title="رسیدگی شد">{icon("check-circle")}</button></form>'
                f'<form method="post" action="/panel/report/{r["id"]}">'
                f'<input type="hidden" name="action" value="dismiss">'
                f'<button class="btn-icon" type="submit" title="بی‌مورد">{icon("x-circle")}</button></form>'
                f'</div>')

    def link_row(ic, label, href):
        return (f'<a class="todo-item" href="{href}">{icon(ic)}'
                f'<span>{esc(label)}</span>{icon("chevron-left")}</a>')

    def section(icon_name, title, count, href, inner):
        if not count:
            return ""
        return (f'<div class="card glass card-pad mb-lg">'
                f'<h2 class="card-title mb-md">{icon(icon_name)} {esc(title)} '
                f'<a class="text-sm" href="{href}">همه ←</a></h2>{inner}</div>')

    parts = []
    if pend_biz:
        rows = "".join(link_row("store", b["name"], f"/panel/business/{b['id']}") for b in pend_biz)
        parts.append(section("store", "کسب‌وکار در انتظار تأیید", len(pend_biz),
                             "/panel/businesses?status=pending", rows))
    if pend_rev:
        parts.append(section("message", "نظرات در انتظار", len(pend_rev),
                             "/panel/reviews?status=pending",
                             "".join(quick_review(r) for r in pend_rev)))
    if open_rep:
        parts.append(section("alert", "گزارش‌های باز", len(open_rep),
                             "/panel/reports?status=open",
                             "".join(quick_report(r) for r in open_rep)))
    if pend_edits:
        rows = "".join(link_row("edit", e["bizname"], "/panel/edits?status=pending")
                       for e in pend_edits)
        parts.append(section("edit", "تغییرات در انتظار تأیید", len(pend_edits),
                             "/panel/edits?status=pending", rows))
    if pend_claims:
        rows = "".join(link_row("shield", c["bizname"], "/panel/claims?status=pending")
                       for c in pend_claims)
        parts.append(section("shield", "درخواست‌های تصاحب", len(pend_claims),
                             "/panel/claims?status=pending", rows))
    if pend_qa:
        rows = "".join(link_row("help", (qq["body"] or "")[:60], "/panel/qa?status=pending")
                       for qq in pend_qa)
        parts.append(section("help", "پرسش‌های در انتظار", len(pend_qa),
                             "/panel/qa?status=pending", rows))
    if pend_sub:
        rows = "".join(link_row("credit-card", f"اشتراک کسب‌وکار #{sp['biz_id']}",
                                "/panel/subscriptions?status=pending") for sp in pend_sub)
        parts.append(section("credit-card", "اشتراک‌های در انتظار", len(pend_sub),
                             "/panel/subscriptions?status=pending", rows))

    body = "".join(parts) or _empty("check-circle", "صف خالی است",
                                    "هیچ چیز در انتظار تعدیل نیست — عالی!")
    content = f'''{_msg(q or {})}
{body}'''
    return panel_page(s, "صف تعدیل", "همهٔ کارهای در انتظار، یک‌جا.",
                      content, "/panel/moderation", token)
