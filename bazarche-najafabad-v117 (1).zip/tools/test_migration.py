#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v116-audit phase 4: migration on an OLD database + backup completeness.

M1  copy the live DB, then amputate it back to an old release:
    drop v114/v115 columns (visits.prov/city/utm, businesses.views),
    drop whole tables (events), drop settings rows added later.
    Run db.init() on the crippled copy and assert:
      - every missing column/table comes back
      - pre-existing rows survive with their data intact
      - a second init() run changes nothing (idempotent)
M2  /panel/backup/export returns JSON covering all live tables
M3  /panel/backup/full zip contains backup.json + uploads/ + chat-files/
M4  PWA: sw.js served, version marker current, manifest installable,
    service worker registers and the shell is cached (offline-ready)

Run:  python3 tools/test_migration.py   (server must be up on :8080)
"""
import io
import json
import os
import shutil
import sqlite3
import sys
import urllib.request
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080")
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"
PASS, FAIL = [], []


def ok(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(("  ✓ " if cond else "  ✗ ") + name + (f"   [{detail}]" if detail and not cond else ""))


def get(path, raw=False):
    with urllib.request.urlopen(BASE + path, timeout=30) as r:
        data = r.read()
        return r.status, (data if raw else data.decode("utf-8", "replace"))


def main():
    print(f"\n{B}M1) مهاجرت روی DB قدیمیِ شبیه‌سازی‌شده{X}")
    tmp = "/tmp/bz_mig_test.sqlite"
    for ext in ("", "-wal", "-shm"):
        try:
            os.remove(tmp + ext)
        except OSError:
            pass
    # checkpoint so the plain copy carries everything
    live = sqlite3.connect(db.DB_PATH)
    live.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    live.close()
    shutil.copy2(db.DB_PATH, tmp)

    # ---- amputate: pretend this DB predates v114/v115
    con = sqlite3.connect(tmp)
    con.execute("ALTER TABLE visits DROP COLUMN prov")
    con.execute("ALTER TABLE visits DROP COLUMN city")
    con.execute("ALTER TABLE visits DROP COLUMN utm")
    con.execute("ALTER TABLE businesses DROP COLUMN views")
    con.execute("DROP TABLE IF EXISTS events")
    con.execute("DELETE FROM settings WHERE key = 'last_backup_at'")
    # a row that must survive the migration untouched
    con.execute("INSERT OR REPLACE INTO settings(key, value) "
                "VALUES ('mig_canary', 'alive')")
    con.commit()
    vcols0 = {r[1] for r in con.execute("PRAGMA table_info(visits)")}
    bcols0 = {r[1] for r in con.execute("PRAGMA table_info(businesses)")}
    tabs0 = {r[0] for r in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table'")}
    ok("DB کهنه شد (ستون‌ها/جدول حذف)",
       "prov" not in vcols0 and "views" not in bcols0 and "events" not in tabs0)
    con.close()

    # ---- run the boot migration on the crippled copy
    real_path = db.DB_PATH
    db.DB_PATH = tmp
    db._thread_local.con = None
    try:
        db.init()
        con = sqlite3.connect(tmp)
        vcols = {r[1] for r in con.execute("PRAGMA table_info(visits)")}
        bcols = {r[1] for r in con.execute("PRAGMA table_info(businesses)")}
        tabs = {r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        ok("visits.prov/city/utm برگشت",
           {"prov", "city", "utm"} <= vcols, str(sorted(vcols)))
        ok("businesses.views برگشت", "views" in bcols)
        ok("جدول events ساخته شد", "events" in tabs)
        can = con.execute("SELECT value FROM settings WHERE key='mig_canary'").fetchone()
        ok("دادهٔ موجود سالم ماند (canary)", can and can[0] == "alive")
        biz = con.execute("SELECT COUNT(*) FROM businesses").fetchone()[0]
        ok("کسب‌وکارها سر جایشان", biz > 0, f"count={biz}")
        # idempotency: second run must be a no-op
        before = con.execute("SELECT COUNT(*) FROM settings").fetchone()[0]
        con.close()
        db.init()
        con = sqlite3.connect(tmp)
        after = con.execute("SELECT COUNT(*) FROM settings").fetchone()[0]
        ok("init() دوم بی‌اثر است (idempotent)", after == before,
           f"{before} → {after}")
        con.close()
    finally:
        db.DB_PATH = real_path
        db._thread_local.con = None

    print(f"\n{B}M2) خروجی JSON پنل{X}")
    key = db.owner_token()
    st, body = get(f"/panel/backup/export?key={key}")
    data = json.loads(body)
    tables = {k for k in data.keys() if k != "_meta"}
    live_tables = {r[0] for r in sqlite3.connect(db.DB_PATH).execute(
        "SELECT name FROM sqlite_master WHERE type='table' "
        "AND name NOT LIKE 'sqlite_%'")}
    # legitimately absent: ephemeral security state (sessions/otp/ratelimit —
    # restoring old ones would be a hazard), derived FTS (rebuilt at boot),
    # and cities (deterministically re-seeded at boot).
    exempt = {"sessions", "customer_sessions", "admin_sessions", "otp",
              "ratelimit", "cities"} | {t for t in live_tables
                                       if t.startswith("businesses_fts")}
    missing = live_tables - tables - exempt
    ok("export همهٔ جدول‌های داده را دارد", not missing, f"missing={sorted(missing)}")
    ok("export JSON معتبر و فارسی‌دار", "بازارچه" in body or "نجف" in body or len(body) > 1000)

    print(f"\n{B}M3) زیپ پشتیبان کامل{X}")
    st, blob = get(f"/panel/backup/full?key={key}", raw=True)
    zf = zipfile.ZipFile(io.BytesIO(blob))
    names = zf.namelist()
    ok("backup.json داخل زیپ", "backup.json" in names)
    ok("uploads/ داخل زیپ", any(n.startswith("uploads/") for n in names),
       f"{len(names)} entry")
    ok("chat-files/ داخل زیپ", any(n.startswith("chat-files/") for n in names)
       or not os.listdir(os.path.join(os.path.dirname(db.DB_PATH), "chat-files"))
       if os.path.isdir(os.path.join(os.path.dirname(db.DB_PATH), "chat-files"))
       else True)
    inner = json.loads(zf.read("backup.json"))
    ok("JSON داخل زیپ معتبر", isinstance(inner, dict) and len(str(inner)) > 100)

    print(f"\n{B}M4) PWA{X}")
    st, sw = get("/sw.js")
    ok("sw.js سرو می‌شود", st == 200 and "bazarche-v" in sw)
    st, man = get("/manifest.webmanifest")
    m = json.loads(man)
    ok("مانیفست نصب‌پذیر", st == 200 and m.get("display") in ("standalone", "fullscreen")
       and bool(m.get("icons")) and bool(m.get("start_url")), str(m.get("display")))
    st, home = get("/")
    st2, appjs = get("/assets/js/app.js")
    ok("app.js سرویس‌ورکر را ثبت می‌کند",
       "serviceWorker.register" in appjs and "app.js" in home)
    ok("نسخهٔ sw با نسخهٔ جاری یکی است", "bazarche-v117" in sw,   # v117
       "VERSION در sw.js با نسخهٔ انتشار نمی‌خواند")

    print("\n" + "═" * 58)
    print(f"  موفق: {G}{len(PASS)}{X}   ناموفق: {R}{len(FAIL)}{X}")
    if FAIL:
        print("  " + R + "، ".join(FAIL) + X)
        return 1
    print(f"  {G}سلامت و یکپارچگی تأیید شد.{X}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
