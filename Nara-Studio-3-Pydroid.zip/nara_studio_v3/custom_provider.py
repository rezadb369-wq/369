"""Opt-in OpenAI Chat Completions connector for a user-owned local installation.

No secret is persisted. Only /models and /chat/completions are built from the
validated base URL; redirects are forbidden so auth cannot cross origins.
"""
import ipaddress
import json
import re
import socket
import urllib.error
import urllib.parse
import urllib.request

import core

_PATH = re.compile(r"^/[A-Za-z0-9_./-]{0,160}$")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise core.RemoteError(502, "سرویس به نشانی دیگری هدایت کرد. برای حفاظت کلید، آدرس نهایی را خودتان ثبت کنید.")


OPENER = urllib.request.build_opener(NoRedirect())


def validate_base_url(value, allow_local=False):
    if not isinstance(value, str) or len(value) > 400:
        raise core.RemoteError(400, "نشانی سرویس معتبر نیست.")
    value = value.strip().rstrip("/")
    try:
        parsed = urllib.parse.urlsplit(value)
        port = parsed.port
    except ValueError:
        raise core.RemoteError(400, "نشانی سرویس یا پورت آن معتبر نیست.")
    host = (parsed.hostname or "").lower().rstrip(".")
    local = host in ("localhost", "127.0.0.1", "::1")
    if not host or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.scheme not in ("http", "https"):
        raise core.RemoteError(400, "نشانی سرویس باید یک مبنای سادهٔ HTTP(S)، بدون رمز، Query یا Fragment باشد.")
    if parsed.scheme != "https" and not (local and allow_local):
        raise core.RemoteError(400, "HTTPS لازم است؛ HTTP فقط برای localhost با تأیید صریح مجاز است.")
    if local and not allow_local:
        raise core.RemoteError(400, "برای اتصال به سرویس localhost، گزینهٔ مخصوص آن را تأیید کنید.")
    if not _PATH.fullmatch(parsed.path or "/") or ".." in parsed.path or "//" in parsed.path or "%" in parsed.path:
        raise core.RemoteError(400, "مسیر مبنای API معتبر نیست.")
    if port is not None and not 1 <= port <= 65535:
        raise core.RemoteError(400, "پورت معتبر نیست.")
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        ip = None
    if ip and not ip.is_global and not local:
        raise core.RemoteError(400, "IP خصوصی/داخلی مجاز نیست؛ برای مدل محلی از 127.0.0.1 استفاده کنید.")
    netloc = host if ":" not in host else "["+host+"]"
    if port is not None:
        netloc += ":"+str(port)
    return urllib.parse.urlunsplit((parsed.scheme, netloc, parsed.path.rstrip("/"), "", ""))


def _check_dns(base_url):
    parsed = urllib.parse.urlsplit(base_url)
    host = parsed.hostname or ""
    if host in ("localhost", "127.0.0.1", "::1"):
        return
    try:
        records = socket.getaddrinfo(host, parsed.port or 443, type=socket.SOCK_STREAM)
    except OSError:
        raise core.RemoteError(502, "نام میزبانِ سرویس دلخواه پیدا نشد.")
    if not records or any(not ipaddress.ip_address(record[4][0]).is_global for record in records):
        raise core.RemoteError(400, "نشانی سرویس دلخواه به IP داخلی/رزروشده اشاره می‌کند.")
    # TLS validates the hostname again during connection. DNS rebind is a
    # residual risk; public hosting is explicitly unsupported.


def request(config, key, endpoint, body=None, timeout=120):
    """Open a trusted-user configured endpoint; the caller owns/streams the response."""
    if endpoint not in ("models", "chat/completions"):
        raise core.RemoteError(400, "فقط دو مسیر شناخته‌شدهٔ API دلخواه مجاز است.")
    options = config.get("options") or {}
    base = validate_base_url(config.get("base_url"), allow_local=options.get("allow_local") is True)
    _check_dns(base)
    host = urllib.parse.urlsplit(base).hostname
    no_auth = options.get("no_auth") is True and host in ("localhost", "127.0.0.1", "::1")
    if not no_auth and (not isinstance(key, str) or not 1 <= len(key) <= 320 or any(c in key for c in "\r\n\x00")):
        raise core.RemoteError(400, "کلید این سرویس را وارد کنید؛ حالت بدون کلید فقط برای localhost مجاز است.")
    url = base + "/" + endpoint
    headers = {"Accept": "text/event-stream, application/json", "User-Agent": "NaraStudio/3.0"}
    if not no_auth:
        headers["Authorization"] = "Bearer " + key
    if body is not None:
        payload = json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        if len(payload) > 18 * 1024 * 1024:
            raise core.RemoteError(413, "بدنهٔ درخواست برای حافظهٔ گوشی بیش از حد بزرگ است.")
        headers["Content-Type"] = "application/json"
    else:
        payload = None
    req = urllib.request.Request(url, data=payload, headers=headers, method="POST" if payload is not None else "GET")
    try:
        return OPENER.open(req, timeout=timeout)
    except urllib.error.HTTPError as error:
        raw = error.read(4000).decode("utf-8", "replace")
        try:
            obj = json.loads(raw)
            detail = (obj.get("error", obj) if isinstance(obj, dict) else obj)
            detail = detail.get("message", str(detail)) if isinstance(detail, dict) else str(detail)
        except ValueError:
            detail = raw
        raise core.RemoteError(error.code, core.redact(detail) or "سرویس دلخواه خطا داد.")
    except core.RemoteError:
        raise
    except (urllib.error.URLError, TimeoutError, OSError) as error:
        raise core.RemoteError(502, "اتصال به سرویس دلخواه ممکن نشد: " + core.redact(getattr(error, "reason", error)))


def models(config, key):
    with request(config, key, "models", timeout=45) as response:
        raw = response.read(3000000+1)
    if len(raw) > 3000000:
        raise core.RemoteError(502, "فهرست سرویس دلخواه بیش از حد بزرگ است.")
    try:
        data = json.loads(raw)
    except (ValueError, UnicodeError):
        raise core.RemoteError(502, "فهرست سرویس دلخواه JSON معتبر نداشت.")
    items = data.get("data", []) if isinstance(data, dict) else []
    return [m for m in items if isinstance(m, dict) and isinstance(m.get("id"),str)
            and core.MODEL_ID.fullmatch(m["id"])]
