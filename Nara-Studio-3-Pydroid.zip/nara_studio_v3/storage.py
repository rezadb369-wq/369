"""Versioned, local-only SQLite state for Nara Studio 3.

The database intentionally does not hold API keys or uploaded binary files. All SQL
values are bound parameters. SQLite backups are taken *before* schema migration.
"""
import json
import os
import sqlite3
import time
import uuid
from contextlib import closing, contextmanager
from pathlib import Path

SCHEMA_VERSION = 3
KINDS = ("chat", "group", "bench")


def data_dir():
    configured = os.environ.get("NARA_STUDIO_DATA", "").strip()
    path = Path(configured).expanduser() if configured else Path.home() / ".nara_studio"
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        path.chmod(0o700)
    except OSError:
        pass
    return path


DB_PATH = data_dir() / "history.sqlite3"


@contextmanager
def connect():
    db = sqlite3.connect(str(DB_PATH), timeout=10)
    try:
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA busy_timeout=10000")
        with db:
            yield db
    finally:
        db.close()


def _backup_existing(suffix):
    if not DB_PATH.exists() or DB_PATH.stat().st_size == 0:
        return None
    name = "history_%s_%s_%s.sqlite3" % (suffix, time.strftime("%Y%m%d_%H%M%S"), uuid.uuid4().hex[:8])
    path = DB_PATH.parent / name
    with connect() as source, closing(sqlite3.connect(str(path))) as target:
        source.backup(target)
    try:
        path.chmod(0o600)
    except OSError:
        pass
    return path


def create_backup():
    """Online consistent SQLite backup for a user-requested download."""
    return _backup_existing("manual")


def init_db():
    existed = DB_PATH.exists() and DB_PATH.stat().st_size > 0
    with connect() as db:
        old_version = db.execute("PRAGMA user_version").fetchone()[0]
    if old_version > SCHEMA_VERSION:
        raise RuntimeError("پایگاه داده از برنامه جدیدتر است؛ نسخهٔ قدیمی را روی آن اجرا نکنید.")
    if existed and old_version < SCHEMA_VERSION:
        _backup_existing("before_v%d" % SCHEMA_VERSION)
    with connect() as db:
        db.execute("PRAGMA journal_mode=WAL")
        if old_version < 1:
            db.executescript("""
              CREATE TABLE IF NOT EXISTS conversations (
                id TEXT PRIMARY KEY, kind TEXT NOT NULL, title TEXT NOT NULL,
                config_json TEXT NOT NULL DEFAULT '{}',
                created_at REAL NOT NULL, updated_at REAL NOT NULL
              );
              CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
                role TEXT NOT NULL, speaker TEXT NOT NULL, content TEXT NOT NULL,
                model TEXT NOT NULL DEFAULT '', provider TEXT NOT NULL DEFAULT '',
                meta_json TEXT NOT NULL DEFAULT '{}', created_at REAL NOT NULL
              );
              CREATE INDEX IF NOT EXISTS ix_messages_conversation ON messages(conversation_id,id);
              CREATE INDEX IF NOT EXISTS ix_conversations_updated ON conversations(updated_at DESC);
            """)
            db.execute("PRAGMA user_version=1")
        if old_version < 2:
            db.executescript("""
              CREATE TABLE IF NOT EXISTS media_jobs (
                id TEXT PRIMARY KEY, model TEXT NOT NULL, mode TEXT NOT NULL,
                status TEXT NOT NULL, detail_json TEXT NOT NULL DEFAULT '{}',
                created_at REAL NOT NULL, updated_at REAL NOT NULL
              );
              CREATE INDEX IF NOT EXISTS ix_media_jobs_updated ON media_jobs(updated_at DESC);
            """)
            db.execute("PRAGMA user_version=2")
        if old_version < 3:
            db.executescript("""
              ALTER TABLE conversations ADD COLUMN pinned INTEGER NOT NULL DEFAULT 0;
              ALTER TABLE conversations ADD COLUMN archived INTEGER NOT NULL DEFAULT 0;
              ALTER TABLE conversations ADD COLUMN folder TEXT NOT NULL DEFAULT '';
              ALTER TABLE conversations ADD COLUMN draft TEXT NOT NULL DEFAULT '';
              ALTER TABLE conversations ADD COLUMN context_note TEXT NOT NULL DEFAULT '';
              ALTER TABLE conversations ADD COLUMN profile_id TEXT NOT NULL DEFAULT '';
              CREATE INDEX IF NOT EXISTS ix_conversations_board ON conversations(archived,pinned,updated_at DESC);
              CREATE TABLE IF NOT EXISTS profiles (
                id TEXT PRIMARY KEY, title TEXT NOT NULL,
                system_prompt TEXT NOT NULL DEFAULT '', options_json TEXT NOT NULL DEFAULT '{}',
                created_at REAL NOT NULL, updated_at REAL NOT NULL
              );
              CREATE TABLE IF NOT EXISTS custom_providers (
                id TEXT PRIMARY KEY, label TEXT NOT NULL, base_url TEXT NOT NULL,
                models_json TEXT NOT NULL DEFAULT '[]',
                options_json TEXT NOT NULL DEFAULT '{}',
                created_at REAL NOT NULL, updated_at REAL NOT NULL
              );
              CREATE TABLE IF NOT EXISTS skills (
                id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
                code TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL, updated_at REAL NOT NULL
              );
            """)
            db.execute("PRAGMA user_version=3")
        db.commit()
    try:
        DB_PATH.chmod(0o600)
    except OSError:
        pass


def _valid_id(value):
    return isinstance(value, str) and len(value) == 32 and all(c in "0123456789abcdef" for c in value)


def _json(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _decode(value, default):
    try:
        result = json.loads(value)
    except (ValueError, TypeError):
        return default
    return result if isinstance(result, type(default)) else default


def create_conversation(kind="chat", title="گفتگوی تازه", config=None, folder="", profile_id=""):
    if kind not in KINDS or not isinstance(config or {}, dict):
        raise ValueError("نوع/تنظیم گفتگو نامعتبر است")
    conv_id, now = uuid.uuid4().hex, time.time()
    with connect() as db:
        db.execute("""INSERT INTO conversations
            (id,kind,title,config_json,created_at,updated_at,folder,profile_id)
            VALUES (?,?,?,?,?,?,?,?)""",
            (conv_id, kind, str(title).strip()[:140] or "گفتگوی تازه", _json(config or {}),
             now, now, str(folder)[:70], str(profile_id)[:32]))
    return conv_id


def _conversation_row(row):
    result = dict(row)
    result["config"] = _decode(result.pop("config_json"), {})
    return result


def get_conversation(conv_id, include_messages=True, limit=None, before_id=None):
    if not _valid_id(conv_id):
        return None
    with connect() as db:
        row = db.execute("SELECT * FROM conversations WHERE id=?", (conv_id,)).fetchone()
        if row is None:
            return None
        result = _conversation_row(row)
        result["message_count"] = db.execute("SELECT COUNT(*) FROM messages WHERE conversation_id=?", (conv_id,)).fetchone()[0]
        if include_messages:
            if limit is None:
                rows = db.execute("SELECT * FROM messages WHERE conversation_id=? ORDER BY id ASC", (conv_id,)).fetchall()
            else:
                limit = min(max(1, int(limit)), 300)
                before = int(before_id) if before_id is not None else 2**63-1
                # Fetch latest page, then return in chronological order.
                rows = list(reversed(db.execute(
                    "SELECT * FROM messages WHERE conversation_id=? AND id<? ORDER BY id DESC LIMIT ?",
                    (conv_id, before, limit)).fetchall()))
            result["messages"] = [_message_row(r) for r in rows]
            result["has_older"] = bool(rows and db.execute(
                "SELECT 1 FROM messages WHERE conversation_id=? AND id<? LIMIT 1",
                (conv_id, rows[0]["id"])).fetchone())
        return result


def _message_row(row):
    item = dict(row)
    item["meta"] = _decode(item.pop("meta_json"), {})
    return item


def list_conversations(limit=50, offset=0, query="", kind="", archived=False, folder=""):
    limit = min(max(1, int(limit)), 200)
    offset = max(0, int(offset))
    query = str(query or "").strip()[:140]
    clause = ["c.archived=?"]
    args = [int(bool(archived))]
    if kind in KINDS:
        clause.append("c.kind=?")
        args.append(kind)
    if folder:
        clause.append("c.folder=?")
        args.append(str(folder)[:70])
    if query:
        pattern = "%" + query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        clause.append("(c.title LIKE ? ESCAPE '\\' OR c.folder LIKE ? ESCAPE '\\' OR EXISTS (SELECT 1 FROM messages m WHERE m.conversation_id=c.id AND m.content LIKE ? ESCAPE '\\'))")
        args.extend((pattern, pattern, pattern))
    where = " AND ".join(clause)
    with connect() as db:
        total = db.execute("SELECT COUNT(*) FROM conversations c WHERE " + where, args).fetchone()[0]
        rows = db.execute("SELECT c.*,(SELECT COUNT(*) FROM messages m WHERE m.conversation_id=c.id) AS message_count FROM conversations c WHERE " + where +
                          " ORDER BY c.pinned DESC,c.updated_at DESC,c.id DESC LIMIT ? OFFSET ?", args+[limit, offset]).fetchall()
        return [_conversation_row(r) for r in rows], total


def update_conversation(conv_id, **changes):
    if not _valid_id(conv_id):
        return False
    fields = {}
    for name, value in changes.items():
        if name == "title":
            if not isinstance(value, str) or not value.strip():
                raise ValueError("نام گفتگو معتبر نیست")
            fields[name] = value.strip()[:140]
        elif name in ("pinned", "archived"):
            if not isinstance(value, bool):
                raise ValueError("وضعیت سنجاق/بایگانی باید درست یا نادرست باشد")
            fields[name] = int(value)
        elif name == "folder":
            if not isinstance(value, str):
                raise ValueError("نام پوشه معتبر نیست")
            fields[name] = value.strip()[:70]
        elif name == "draft":
            if not isinstance(value, str) or len(value) > 2000000:
                raise ValueError("پیش‌نویس معتبر نیست یا حافظهٔ گوشی را پر می‌کند")
            fields[name] = value
        elif name == "context_note":
            if not isinstance(value, str) or len(value) > 120000:
                raise ValueError("یادداشت زمینه معتبر نیست")
            fields[name] = value
        elif name == "profile_id":
            fields[name] = value if value == "" or _valid_id(value) else ""
        elif name == "config":
            if not isinstance(value, dict) or len(_json(value)) > 120000:
                raise ValueError("تنظیمات گفتگو معتبر نیست")
            fields["config_json"] = _json(value)
        else:
            raise ValueError("تنظیم ناشناخته برای گفتگو")
    if not fields:
        return False
    # Typing an unsent draft must not reorder the whole conversation list.
    if any(key != "draft" for key in fields):
        fields["updated_at"] = time.time()
    with connect() as db:
        sql = "UPDATE conversations SET " + ",".join(name+"=?" for name in fields) + " WHERE id=?"
        return db.execute(sql, list(fields.values())+[conv_id]).rowcount > 0


def save_message(conv_id, role, speaker, text, model="", provider="", meta=None):
    if not _valid_id(conv_id) or role not in ("user", "assistant", "notice") or not isinstance(text, str):
        raise ValueError("پیام معتبر نیست")
    if not isinstance(meta or {}, dict) or len(_json(meta or {})) > 160000:
        raise ValueError("اطلاعات اضافی پیام معتبر نیست")
    now = time.time()
    with connect() as db:
        cur = db.execute("""INSERT INTO messages
            (conversation_id,role,speaker,content,model,provider,meta_json,created_at)
            VALUES (?,?,?,?,?,?,?,?)""",
            (conv_id, role, str(speaker)[:110], text, str(model)[:110], str(provider)[:60], _json(meta or {}), now))
        db.execute("UPDATE conversations SET updated_at=? WHERE id=?", (now, conv_id))
        return cur.lastrowid


def get_message(message_id):
    try:
        ident = int(message_id)
    except (TypeError, ValueError):
        return None
    if ident < 1:
        return None
    with connect() as db:
        row = db.execute("SELECT * FROM messages WHERE id=?", (ident,)).fetchone()
        return _message_row(row) if row else None


def update_message(message_id, content=None, meta=None):
    fields = {}
    if content is not None:
        if not isinstance(content, str):
            raise ValueError("متن معتبر نیست")
        fields["content"] = content
    if meta is not None:
        if not isinstance(meta, dict) or len(_json(meta)) > 160000:
            raise ValueError("اطلاعات پیام نامعتبر است")
        fields["meta_json"] = _json(meta)
    if not fields:
        return False
    with connect() as db:
        return db.execute("UPDATE messages SET " + ",".join(k+"=?" for k in fields)+" WHERE id=?",
                          list(fields.values())+[int(message_id)]).rowcount > 0


def delete_conversation(conv_id):
    if not _valid_id(conv_id):
        return False
    with connect() as db:
        return db.execute("DELETE FROM conversations WHERE id=?", (conv_id,)).rowcount > 0


def duplicate_conversation(conv_id, through_id=None):
    if not _valid_id(conv_id):
        raise ValueError("گفتگو یافت نشد")
    with connect() as db:
        row = db.execute("SELECT * FROM conversations WHERE id=?", (conv_id,)).fetchone()
        if row is None:
            raise ValueError("گفتگو یافت نشد")
        if through_id is not None:
            through_id = int(through_id)
            if not db.execute("SELECT 1 FROM messages WHERE id=? AND conversation_id=?", (through_id, conv_id)).fetchone():
                raise ValueError("پیامِ موردنظر متعلق به این گفتگو نیست")
        new_id, now = uuid.uuid4().hex, time.time()
        db.execute("""INSERT INTO conversations
           (id,kind,title,config_json,created_at,updated_at,pinned,archived,folder,draft,context_note,profile_id)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
           (new_id, row["kind"], "شاخه · " + row["title"][:125], row["config_json"], now, now,
            0, 0, row["folder"], "", row["context_note"], row["profile_id"]))
        query = "SELECT * FROM messages WHERE conversation_id=?"
        args = [conv_id]
        if through_id is not None:
            query += " AND id<=?"
            args.append(through_id)
        for msg in db.execute(query+" ORDER BY id", args):
            db.execute("""INSERT INTO messages
              (conversation_id,role,speaker,content,model,provider,meta_json,created_at)
              VALUES (?,?,?,?,?,?,?,?)""",
              (new_id, msg["role"], msg["speaker"], msg["content"], msg["model"],
               msg["provider"], msg["meta_json"], now))
        return new_id


def upsert_media_job(job_id, model, mode, status, detail=None):
    now = time.time()
    with connect() as db:
        db.execute("""INSERT INTO media_jobs (id,model,mode,status,detail_json,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
            status=excluded.status,detail_json=excluded.detail_json,updated_at=excluded.updated_at""",
            (str(job_id)[:150], str(model)[:110], str(mode)[:20], str(status)[:40], _json(detail or {})[:12000], now, now))


def media_jobs(limit=50):
    with connect() as db:
        rows = db.execute("SELECT * FROM media_jobs ORDER BY updated_at DESC LIMIT ?", (min(max(1, int(limit)), 100),)).fetchall()
        return [{**{k: row[k] for k in ("id", "model", "mode", "status", "created_at", "updated_at")},
                 "detail": _decode(row["detail_json"], {})} for row in rows]


def save_profile(title, system_prompt="", options=None, profile_id=None):
    if not isinstance(title, str) or not title.strip() or not isinstance(system_prompt, str) or not isinstance(options or {}, dict):
        raise ValueError("پروفایل معتبر نیست")
    if len(system_prompt) > 100000 or len(_json(options or {})) > 20000:
        raise ValueError("پروفایل بسیار بزرگ است")
    profile_id = profile_id if _valid_id(profile_id) else uuid.uuid4().hex
    now = time.time()
    with connect() as db:
        db.execute("""INSERT INTO profiles (id,title,system_prompt,options_json,created_at,updated_at)
          VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
          title=excluded.title,system_prompt=excluded.system_prompt,
          options_json=excluded.options_json,updated_at=excluded.updated_at""",
          (profile_id, title.strip()[:120], system_prompt, _json(options or {}), now, now))
    return profile_id


def profiles():
    with connect() as db:
        rows = db.execute("SELECT * FROM profiles ORDER BY updated_at DESC").fetchall()
        return [{**{k:r[k] for k in ("id","title","system_prompt","created_at","updated_at")},
                 "options":_decode(r["options_json"], {})} for r in rows]


def delete_profile(profile_id):
    if not _valid_id(profile_id):
        return False
    with connect() as db:
        db.execute("UPDATE conversations SET profile_id='' WHERE profile_id=?", (profile_id,))
        return db.execute("DELETE FROM profiles WHERE id=?", (profile_id,)).rowcount > 0


def save_provider(label, base_url, models=None, provider_id=None, options=None):
    if (not isinstance(label, str) or not label.strip() or not isinstance(base_url, str)
            or not isinstance(models or [], list) or not isinstance(options or {}, dict)):
        raise ValueError("ارائه‌دهنده معتبر نیست")
    if not all(isinstance(model, str) and len(model) <= 110 for model in (models or [])) or len(models or []) > 300:
        raise ValueError("شناسه‌های مدل معتبر نیست")
    if len(_json(options or {})) > 20000:
        raise ValueError("تنظیمات ارائه‌دهنده بیش از حد بزرگ است")
    provider_id = provider_id if _valid_id(provider_id) else uuid.uuid4().hex
    now = time.time()
    with connect() as db:
        db.execute("""INSERT INTO custom_providers (id,label,base_url,models_json,options_json,created_at,updated_at)
          VALUES (?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
          label=excluded.label,base_url=excluded.base_url,models_json=excluded.models_json,
          options_json=excluded.options_json,updated_at=excluded.updated_at""",
          (provider_id, label.strip()[:100], base_url[:500], _json(models or []),
           _json(options or {}), now, now))
    return provider_id


def providers():
    with connect() as db:
        rows = db.execute("SELECT * FROM custom_providers ORDER BY updated_at DESC").fetchall()
        return [{**{k:r[k] for k in ("id","label","base_url","created_at","updated_at")},
                 "models":_decode(r["models_json"], []),
                 "options":_decode(r["options_json"], {})} for r in rows]


def delete_provider(provider_id):
    if not _valid_id(provider_id):
        return False
    with connect() as db:
        return db.execute("DELETE FROM custom_providers WHERE id=?", (provider_id,)).rowcount > 0


def save_skill(title, code, description="", skill_id=None):
    if not isinstance(title, str) or not title.strip() or not isinstance(code, str) or not isinstance(description, str):
        raise ValueError("ابزار معتبر نیست")
    if len(code) > 120000 or len(description) > 1000:
        raise ValueError("کد ابزار بیش از حد بزرگ است")
    skill_id = skill_id if _valid_id(skill_id) else uuid.uuid4().hex
    now = time.time()
    with connect() as db:
        db.execute("""INSERT INTO skills (id,title,description,code,created_at,updated_at)
          VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
          title=excluded.title,description=excluded.description,code=excluded.code,updated_at=excluded.updated_at""",
          (skill_id, title.strip()[:120], description, code, now, now))
    return skill_id


def skills():
    with connect() as db:
        return [dict(row) for row in db.execute("SELECT * FROM skills ORDER BY updated_at DESC").fetchall()]


def delete_skill(skill_id):
    if not _valid_id(skill_id):
        return False
    with connect() as db:
        return db.execute("DELETE FROM skills WHERE id=?", (skill_id,)).rowcount > 0


def export_bundle():
    """Human-readable export. Uploaded binaries and API secrets have never entered this DB."""
    with connect() as db:
        conversations = []
        for row in db.execute("SELECT * FROM conversations ORDER BY created_at,id").fetchall():
            item = _conversation_row(row)
            item["messages"] = [_message_row(msg) for msg in db.execute(
                "SELECT * FROM messages WHERE conversation_id=? ORDER BY id", (row["id"],)).fetchall()]
            conversations.append(item)
    return {"format":"nara-studio-backup", "version":SCHEMA_VERSION,
            "exported_at":time.time(),"conversations":conversations,
            "profiles":profiles(), "custom_providers":providers(), "skills":skills(),
            "media_jobs":media_jobs(100)}


def import_bundle(bundle):
    """Import with new IDs to avoid overwriting existing chats; never import API keys."""
    if not isinstance(bundle, dict):
        raise ValueError("قالب فایل پشتیبان معتبر نیست")
    if bundle.get("format") == "nara-studio-conversation-v3":
        bundle = {"format":"nara-studio-backup", "conversations":[bundle.get("conversation")]}
    if bundle.get("format") != "nara-studio-backup":
        raise ValueError("قالب فایل پشتیبان معتبر نیست")
    items = bundle.get("conversations")
    if not isinstance(items, list) or len(items) > 5000:
        raise ValueError("تعداد گفتگوهای فایل معتبر نیست")
    # Validate every record before *any* write, then import in one transaction.
    for item in items:
        if not isinstance(item, dict) or item.get("kind") not in KINDS or not isinstance(item.get("messages"), list):
            raise ValueError("دادهٔ یکی از گفتگوها معتبر نیست")
        if len(item["messages"]) > 50000 or not isinstance(item.get("config", {}), dict):
            raise ValueError("تعداد پیام‌ها یا تنظیمات نامعتبر است")
        for msg in item["messages"]:
            if (not isinstance(msg, dict) or msg.get("role") not in ("user","assistant","notice")
                    or not isinstance(msg.get("content"), str) or not isinstance(msg.get("meta", {}), dict)):
                raise ValueError("یکی از پیام‌ها نامعتبر است")
    now = time.time()
    with connect() as db:
        count = 0
        for item in items:
            cid = uuid.uuid4().hex
            title = str(item.get("title") or "گفتگوی بازیابی‌شده")[:140]
            db.execute("""INSERT INTO conversations
             (id,kind,title,config_json,created_at,updated_at,pinned,archived,folder,draft,context_note,profile_id)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
             (cid,item["kind"],title,_json(item.get("config",{})),now,now,int(bool(item.get("pinned"))),
              int(bool(item.get("archived"))),str(item.get("folder", ""))[:70],
              str(item.get("draft", ""))[:2000000],str(item.get("context_note", ""))[:120000],""))
            for msg in item["messages"]:
                db.execute("""INSERT INTO messages
                (conversation_id,role,speaker,content,model,provider,meta_json,created_at)
                VALUES (?,?,?,?,?,?,?,?)""",
                (cid,msg["role"],str(msg.get("speaker", ""))[:110],msg["content"],
                 str(msg.get("model", ""))[:110],str(msg.get("provider", ""))[:60],
                 _json(msg.get("meta",{})),now))
            count += 1
    # Profiles/providers/skills are not imported automatically: their instructions,
    # network destinations or executable code require deliberate review and re-entry.
    return {"imported":count,"skipped_config":"پروفایل‌ها، آدرس‌های API و کد ابزارها برای امنیت خودکار وارد نشدند."}
