"""Bounded local text extraction. No untrusted document content is executed."""
import base64
import binascii
import io
import re
import zipfile
from xml.etree import ElementTree as ET

MAX_DOCUMENT = 8 * 1024 * 1024
# Memory guard, not a token cap. Longer files must be split rather than silently cropped.
MAX_TEXT = 2_000_000
TEXT_EXTENSIONS = {"txt", "md", "markdown", "csv", "tsv", "json", "jsonl", "xml", "html", "htm",
                   "css", "js", "jsx", "ts", "tsx", "py", "java", "kt", "c", "cpp", "hpp", "h",
                   "go", "rs", "rb", "php", "sh", "sql", "yaml", "yml", "toml", "ini", "log",
                   "srt", "vtt", "tex"}


class ExtractionError(ValueError):
    pass


def read_member(z, name, limit=2500000):
    try:
        item = z.getinfo(name)
    except KeyError:
        raise ExtractionError("ساختار استاندارد این فایل Office پیدا نشد.")
    if item.file_size > limit:
        raise ExtractionError("بخشی از سند بیش از حد بزرگ است.")
    with z.open(item) as source:
        content = source.read(limit + 1)
    if len(content) > limit:
        raise ExtractionError("اندازه فایل پس از فشرده‌گشایی بیش از حد است.")
    return content


def office_text(ext, binary, warnings):
    if not zipfile.is_zipfile(io.BytesIO(binary)):
        raise ExtractionError("سند Office سالم نیست یا قابل خواندن نیست.")
    try:
        with zipfile.ZipFile(io.BytesIO(binary)) as z:
            if ext == "docx":
                root = ET.fromstring(read_member(z, "word/document.xml"))
                ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
                return "\n".join("".join(node.text or "" for node in para.iter(ns + "t"))
                                 for para in root.iter(ns + "p"))
            if ext == "pptx":
                paths = sorted((p for p in z.namelist() if re.fullmatch(r"ppt/slides/slide\d+\.xml", p)),
                               key=lambda p: int(re.search(r"slide(\d+)", p).group(1)))
                if len(paths) > 35:
                    warnings.append("فقط ۳۵ اسلاید اول از %d اسلاید استخراج شد؛ برای بقیه فایل را تقسیم کنید." % len(paths))
                paths = paths[:35]
                ns = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
                parts = []
                for i, path in enumerate(paths, 1):
                    root = ET.fromstring(read_member(z, path))
                    parts.append("اسلاید %s:\n" % i + "\n".join((t.text or "") for t in root.iter(ns + "t")))
                    if sum(map(len, parts)) >= MAX_TEXT:
                        raise ExtractionError("متن سند از سقف حافظهٔ هر فایل (۲ میلیون نویسه) بزرگ‌تر است؛ سند را تقسیم کنید.")
                return "\n\n".join(parts)
            if ext == "xlsx":
                ns = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
                shared = []
                if "xl/sharedStrings.xml" in z.namelist():
                    root = ET.fromstring(read_member(z, "xl/sharedStrings.xml"))
                    shared = ["".join(t.text or "" for t in item.iter(ns + "t"))
                              for item in root.iter(ns + "si")][:10000]
                paths = sorted((p for p in z.namelist() if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", p)),
                               key=lambda p: int(re.search(r"sheet(\d+)", p).group(1)))
                if len(paths) > 12:
                    warnings.append("فقط ۱۲ برگهٔ اول از %d برگه استخراج شد؛ بقیه را جداگانه بفرستید." % len(paths))
                paths = paths[:12]
                parts = []
                for path in paths:
                    root = ET.fromstring(read_member(z, path))
                    lines = []
                    for row in root.iter(ns + "row"):
                        cells = []
                        for c in row.iter(ns + "c"):
                            value = c.find(ns + "v")
                            text = value.text if value is not None and value.text else ""
                            if c.get("t") == "s" and text.isdigit():
                                i = int(text)
                                text = shared[i] if i < len(shared) else ""
                            elif c.get("t") == "inlineStr":
                                text = "".join(t.text or "" for t in c.iter(ns + "t"))
                            cells.append(text)
                        if cells:
                            lines.append("\t".join(cells))
                        if len(lines) > 350 or sum(map(len, lines)) > 16000:
                            warnings.append("برگهٔ %s فقط تا این سطر/حجم خوانده شد؛ بقیهٔ داده‌ها را در فایل جدا بفرستید." % path)
                            break
                    parts.append(path.rsplit("/", 1)[-1] + "\n" + "\n".join(lines))
                    if sum(map(len, parts)) > MAX_TEXT:
                        raise ExtractionError("متن برگه‌ها از سقف حافظهٔ هر فایل (۲ میلیون نویسه) بزرگ‌تر است؛ فایل را تقسیم کنید.")
                return "\n\n".join(parts)
    except (zipfile.BadZipFile, ET.ParseError, RuntimeError) as exc:
        raise ExtractionError("ساختار سند قابل خواندن نیست: " + str(type(exc).__name__))
    raise ExtractionError("نوع سند پشتیبانی نمی‌شود.")


def extract(name, b64):
    if not isinstance(name, str) or len(name) > 200 or not isinstance(b64, str):
        raise ExtractionError("نام یا محتوای فایل نامعتبر است.")
    if len(b64) > ((MAX_DOCUMENT + 2) // 3) * 4 + 10:
        raise ExtractionError("حداکثر اندازه فایل ۸ مگابایت است.")
    try:
        binary = base64.b64decode(b64, validate=True)
    except (binascii.Error, ValueError):
        raise ExtractionError("داده فایل معتبر نیست.")
    if len(binary) > MAX_DOCUMENT:
        raise ExtractionError("حداکثر اندازه فایل ۸ مگابایت است.")
    ext = name.rsplit(".", 1)[-1].lower()
    warnings = []
    if ext in TEXT_EXTENSIONS:
        if b"\x00" in binary[:512] and not binary.startswith((b"\xff\xfe", b"\xfe\xff")):
            raise ExtractionError("این فایل ظاهراً متنی نیست.")
        try:
            text = binary.decode("utf-16" if binary.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig")
        except UnicodeDecodeError:
            raise ExtractionError("رمزگذاری متن باید UTF-8 یا UTF-16 دارای BOM باشد.")
    elif ext in ("docx", "xlsx", "pptx"):
        text = office_text(ext, binary, warnings)
    elif ext == "pdf":
        try:
            from pypdf import PdfReader
        except ImportError:
            raise ExtractionError("برای PDF متنی، بسته pypdf را در Pip برنامه Pydroid نصب کنید.")
        try:
            reader = PdfReader(io.BytesIO(binary))
            if reader.is_encrypted:
                raise ExtractionError("PDF رمزدار پشتیبانی نمی‌شود.")
            if len(reader.pages) > 35:
                warnings.append("فقط ۳۵ صفحهٔ اول از %d صفحه استخراج شد؛ برای بقیه PDF را تقسیم کنید." % len(reader.pages))
            parts = []
            for i in range(min(35, len(reader.pages))):
                page = reader.pages[i]
                parts.append("صفحه %s:\n" % (i + 1) + (page.extract_text() or ""))
                if sum(map(len, parts)) >= MAX_TEXT:
                    raise ExtractionError("متن PDF از سقف حافظهٔ هر فایل (۲ میلیون نویسه) بزرگ‌تر است؛ فایل را تقسیم کنید.")
            text = "\n\n".join(parts)
        except ExtractionError:
            raise
        except Exception:
            raise ExtractionError("متن PDF قابل استخراج نبود؛ PDF اسکن‌شده به OCR نیاز دارد.")
    else:
        raise ExtractionError("فقط متن/کد مجاز، DOCX، XLSX، PPTX و PDF متنی پشتیبانی می‌شود.")
    text = re.sub(r"[\x00-\x08\x0b-\x1f]", " ", text).strip()
    if not text:
        raise ExtractionError("متن خوانایی پیدا نشد؛ فایل تصویری احتمالاً به OCR نیاز دارد.")
    if len(text) > MAX_TEXT:
        raise ExtractionError("متن این فایل از سقف حافظهٔ یک درخواست (۲ میلیون نویسه) بیشتر است؛ فایل را تقسیم کنید؛ هیچ بخشی بی‌اطلاع شما حذف نمی‌شود.")
    return {"name": name, "text": text, "chars": len(text),
            "truncated": bool(warnings), "warnings": warnings}
