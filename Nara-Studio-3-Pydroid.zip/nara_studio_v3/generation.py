"""Honest context accounting and output-control policy, independent of any provider.

Storage is never truncated. A context window belongs to a single API request, not to
how many messages can be kept in SQLite or to an entire user's lifetime.
"""
from dataclasses import dataclass


class ContextError(ValueError):
    pass


@dataclass
class ContextPlan:
    messages: list
    total_count: int
    sent_count: int
    omitted_count: int
    estimated_input_tokens: int
    token_budget: int | None
    reserve_tokens: int | None
    approximate: bool = True

    def public(self):
        return {"total_count": self.total_count, "sent_count": self.sent_count,
                "omitted_count": self.omitted_count,
                "estimated_input_tokens": self.estimated_input_tokens,
                "token_budget": self.token_budget,
                "reserve_tokens": self.reserve_tokens, "approximate": self.approximate,
                "message": ("%d پیام قدیمی فقط از ورودی این درخواست کنار می‌ماند؛ در تاریخچه حذف نشده است."
                            % self.omitted_count if self.omitted_count else "تمام پیام‌های این گفتگو در ورودی جا می‌شوند.")}


def output_limit(value, provider="bynara", api="chat"):
    """Return None for auto; caller omits optional output fields.

    Atria Messages requires max_tokens. Its documented maximum is 65,536; no
    smaller application cap is imposed. Other services validate their own limits.
    """
    if value in (None, "", "auto", 0, "0"):
        return 65536 if provider == "atria" and api == "messages" else None
    if isinstance(value, bool):
        raise ContextError("سقف خروجی باید عدد مثبت یا «خودکار» باشد.")
    try:
        number = int(value)
    except (ValueError, TypeError):
        raise ContextError("سقف خروجی باید عدد مثبت یا «خودکار» باشد.")
    if number <= 0:
        raise ContextError("سقف خروجی باید عدد مثبت باشد.")
    if provider == "atria" and number > 65536:
        raise ContextError("حد خروجی مستند Atria در هر درخواست ۶۵٬۵۳۶ توکن است؛ از دکمهٔ ادامه استفاده کنید.")
    if number > 2**31 - 1:
        raise ContextError("عدد در پروتکل API قابل ارسال نیست؛ گزینهٔ خودکار را انتخاب کنید.")
    return number


def estimate_tokens(text):
    """Conservative, deliberately inexact heuristic; never claim tokenizer accuracy."""
    text = str(text or "")
    return max(1, (len(text) + 1)//2, (len(text.encode("utf-8")) + 3)//4)


def plan_context(messages, context_window=None, requested_output=None, system="", note=""):
    """Choose a coherent recent suffix, with explicit accounting of omitted messages.

    Reject a too-large current message instead of secretly cropping it. Unknown
    model context -> send all and let the upstream enforce its real constraint.
    """
    if not isinstance(messages, list) or not messages:
        raise ContextError("پیام آخر وجود ندارد.")
    if messages[-1].get("role") != "user":
        raise ContextError("آخرین پیام ورودی باید از کاربر باشد.")
    for m in messages:
        if not isinstance(m, dict) or m.get("role") not in ("user", "assistant") or not isinstance(m.get("content"), str):
            raise ContextError("ساختار تاریخچه معتبر نیست.")
    try:
        window = int(context_window) if context_window else None
    except (ValueError, TypeError):
        window = None
    if window is not None and window <= 0:
        window = None
    if window is not None:
        # Reserve space for output/reasoning without claiming exact provider token counts.
        if requested_output is not None and int(requested_output) >= window - 512:
            raise ContextError("سقف خروجی انتخابی به‌تنهایی پنجرهٔ این مدل را پر می‌کند؛ برای پاسخ بلند از ادامه استفاده کنید.")
        reserve = (int(requested_output) if requested_output is not None
                   else min(32768, max(256, window//10), max(1, window//2)))
        budget = window - reserve - estimate_tokens(system) - estimate_tokens(note) - 256
        if budget <= 0:
            raise ContextError("دستور و یادداشت زمینه همراه با خروجی انتخابی از پنجرهٔ مدل بزرگ‌ترند.")
    else:
        budget, reserve = None, None
    selected, used = [], 0
    for m in reversed(messages):
        amount = estimate_tokens(m["content"]) + 8
        if budget is not None and used + amount > budget:
            if not selected:
                raise ContextError("آخرین پیام در پنجرهٔ این مدل جا نمی‌شود؛ متن را تقسیم یا مدل با زمینهٔ بزرگ‌تر انتخاب کنید.")
            break
        selected.insert(0, {"role": m["role"], "content": m["content"]})
        used += amount
    # Some Messages-compatible APIs require the first turn to be a user.
    while len(selected) > 1 and selected[0]["role"] == "assistant":
        used -= estimate_tokens(selected[0]["content"]) + 8
        selected.pop(0)
    return ContextPlan(messages=selected, total_count=len(messages), sent_count=len(selected),
                       omitted_count=len(messages)-len(selected),
                       estimated_input_tokens=used + estimate_tokens(system) + estimate_tokens(note),
                       token_budget=budget, reserve_tokens=reserve)


def is_length_finish(value):
    if not isinstance(value, str):
        return False
    return value.lower() in ("length", "max_tokens", "max_output_tokens", "token_limit", "incomplete")


def continue_prompt():
    return ("Please continue the immediately preceding assistant answer from the next point. "
            "Avoid repeating completed text. If the answer is already complete, briefly say so. "
            "Keep the same language and cite only sources actually present in the context.")
