"""Manual-only local workspace tools for a personal Pydroid installation.

Executing Python is NOT a sandbox: it can access everything Pydroid can access.
The HTTP layer requires an explicit short-lived review token bound to SHA-256 of the
exact code and confirmation for every run. No AI output is executed automatically.
"""
import ast
import hashlib
import os
import signal
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

import storage


class ToolError(ValueError):
    pass


def root():
    folder = storage.data_dir() / "workspace"
    folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    return folder.resolve()


def path_for(name):
    if not isinstance(name, str) or len(name) > 200 or not name or name.startswith(('/', '\\')) or '\x00' in name:
        raise ToolError("مسیر فایل باید نسبی و معتبر باشد.")
    parts = Path(name).parts
    if any(part in (".", "..") for part in parts) or any('\\' in part for part in parts):
        raise ToolError("خروج از پوشهٔ اختصاصی ابزار مجاز نیست.")
    base = root()
    target = (base / name).resolve(strict=False)
    if target != base and base not in target.parents:
        raise ToolError("پیوند/مسیر فایل به خارج از پوشهٔ اختصاصی اشاره می‌کند.")
    return target


def list_files():
    base = root()
    items = []
    for path in sorted(base.rglob('*')):
        if len(items) >= 500:
            break
        rel = str(path.relative_to(base))
        if path.is_symlink():
            items.append({'path':rel,'kind':'symlink-blocked','size':0})
            continue
        if path.is_file():
            items.append({'path':rel,'kind':'file','size':path.stat().st_size})
    return items


def read_text(name):
    path = path_for(name)
    if not path.is_file() or path.stat().st_size > 4 * 1024 * 1024:
        raise ToolError("فایل یافت نشد یا بیش از ۴ مگابایت است.")
    try:
        return path.read_text(encoding='utf-8')
    except UnicodeError:
        raise ToolError("فایل متنی UTF-8 نیست.")


def save_text(name, text):
    if not isinstance(text,str) or len(text.encode('utf-8')) > 4 * 1024 * 1024:
        raise ToolError("حداکثر حجم فایل متنی ۴ مگابایت است.")
    path = path_for(name)
    if path.suffix.lower() not in ('.txt','.md','.json','.csv','.py','.js','.css','.html','.sql','.yaml','.yml','.srt'):
        raise ToolError("برای ذخیره فقط فرمت‌های متنی و کد مجازند.")
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(text,encoding='utf-8')
    return {'path':str(path.relative_to(root())),'size':path.stat().st_size}


def syntax_check(code):
    if not isinstance(code,str) or len(code.encode('utf-8')) > 250000:
        raise ToolError("کد باید متن UTF-8 با حجم کمتر از ۲۵۰KB باشد.")
    try:
        compile(code,'<nara-user-script>','exec')
        return {'ok':True,'sha256':hashlib.sha256(code.encode()).hexdigest()}
    except SyntaxError as error:
        return {'ok':False,'error':error.msg,'line':error.lineno,'sha256':hashlib.sha256(code.encode()).hexdigest()}


def run_python(code, timeout=25):
    """Run explicitly approved *user-owned* code, never LLM-generated code implicitly.

    This is a separate process and output/time-bounded, but it is NOT an OS sandbox.
    The subprocess still inherits Pydroid's filesystem/network permissions.
    """
    check = syntax_check(code)
    if not check['ok']:
        raise ToolError("کد Python از نظر نحوی معتبر نیست: %s (خط %s)" % (check['error'],check['line']))
    try:
        timeout = int(timeout)
    except (TypeError,ValueError):
        raise ToolError("زمان اجرا باید عدد باشد.")
    if timeout < 1 or timeout > 1800:
        raise ToolError("برای حفاظت گوشی، زمان هر اجرا بین ۱ ثانیه و ۳۰ دقیقه است.")
    base = root()
    filename = '.nara_manual_%s.py' % uuid.uuid4().hex
    path = base / filename
    path.write_text(code,encoding='utf-8')
    try:
        path.chmod(0o600)
    except OSError:
        pass
    # Environment clean-up is defense in depth, NOT a sandbox.
    env = {k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('KEY','TOKEN','SECRET','PASSWORD','CREDENTIAL'))}
    env['PYTHONUNBUFFERED']='1'
    started = time.monotonic()
    timed_out = False
    try:
        with tempfile.TemporaryFile() as output:
            try:
                proc = subprocess.Popen([sys.executable, str(path)], cwd=str(base),
                                        stdout=output, stderr=subprocess.STDOUT,
                                        stdin=subprocess.DEVNULL, env=env, shell=False,
                                        start_new_session=True)
            except OSError as error:
                raise ToolError("اجرای Python در این نسخهٔ Pydroid ممکن نشد: "+str(error))
            try:
                proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                try:
                    os.killpg(proc.pid,signal.SIGKILL)
                except (OSError,AttributeError):
                    proc.kill()
                proc.wait(timeout=4)
            output.seek(0,os.SEEK_END)
            size=output.tell()
            output.seek(0)
            text=output.read(200001).decode('utf-8','replace')
            if len(text)>200000:
                text=text[:200000]
            return {'stdout':text,'truncated':size>200000,'exit_code':proc.returncode,
                    'timed_out':timed_out,'elapsed':round(time.monotonic()-started,2),
                    'sha256':check['sha256'],
                    'warning':'این اجرا sandbox امنیتی ندارد؛ کد به مجوزهای Pydroid دسترسی دارد.'}
    finally:
        try: path.unlink(missing_ok=True)
        except OSError: pass


_ALLOWED_OPS = {ast.Add:lambda a,b:a+b,ast.Sub:lambda a,b:a-b,ast.Mult:lambda a,b:a*b,
                ast.Div:lambda a,b:a/b,ast.FloorDiv:lambda a,b:a//b,ast.Mod:lambda a,b:a%b,
                ast.Pow:lambda a,b:a**b}


def calculate(expression):
    if not isinstance(expression,str) or len(expression)>800:
        raise ToolError("عبارت حسابی معتبر نیست.")
    try:
        rootnode=ast.parse(expression,mode='eval')
    except SyntaxError:
        raise ToolError("ساختار عبارت ریاضی معتبر نیست.")
    def walk(node,depth=0):
        if depth>30:
            raise ToolError("عبارت بیش از حد پیچیده است.")
        if isinstance(node,ast.Expression):return walk(node.body,depth+1)
        if isinstance(node,ast.Constant) and type(node.value) in (int,float):
            if abs(node.value)>10**20: raise ToolError("عدد ورودی بسیار بزرگ است.")
            return node.value
        if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
            val=walk(node.operand,depth+1)
            return val if isinstance(node.op,ast.UAdd) else -val
        if isinstance(node,ast.BinOp) and type(node.op) in _ALLOWED_OPS:
            a,b=walk(node.left,depth+1),walk(node.right,depth+1)
            if type(node.op)==ast.Pow and (abs(b)>100 or abs(a)>10**20):
                raise ToolError("توان بسیار بزرگ است.")
            try:
                result=_ALLOWED_OPS[type(node.op)](a,b)
            except (ArithmeticError,OverflowError):
                raise ToolError("محاسبه معتبر نیست؛ تقسیم بر صفر یا سرریز رخ داد.")
            if abs(result)>10**100:
                raise ToolError("نتیجه بیش از حد بزرگ است.")
            return result
        raise ToolError("فقط عدد و عملگرهای ریاضی پایه مجازند؛ کد را در ابزار Python دستی اجرا کنید.")
    return walk(rootnode)
