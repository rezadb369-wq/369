"""Offline, API-key-free v3 data regression tests."""
import json
import sqlite3
import sys
import tempfile
import unittest
from contextlib import closing
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import storage


class DatabaseV3Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.original = storage.DB_PATH
        storage.DB_PATH = Path(self.temp.name) / 'history.sqlite3'

    def tearDown(self):
        storage.DB_PATH = self.original
        self.temp.cleanup()

    def test_many_chats_and_pagination_and_search_and_archive(self):
        storage.init_db()
        ids = [storage.create_conversation(title='گفتگو %02d' % i) for i in range(77)]
        self.assertEqual(len(set(ids)), 77)
        first, total = storage.list_conversations(limit=30, offset=0)
        second, again = storage.list_conversations(limit=30, offset=30)
        last, _ = storage.list_conversations(limit=30, offset=60)
        self.assertEqual(total, again)
        self.assertEqual(total, 77)
        self.assertEqual(len(set(x['id'] for x in first+second+last)), 77)
        storage.save_message(ids[0], 'user', 'user', 'شناسهٔ خاص: ماه‌تاب')
        matched, count = storage.list_conversations(query='ماه‌تاب')
        self.assertEqual((count, matched[0]['id']), (1, ids[0]))
        storage.update_conversation(ids[0], title='نام جدید', pinned=True, folder='پژوهش', draft='متن ذخیره‌نشده')
        self.assertEqual(storage.list_conversations()[0][0]['id'], ids[0])
        self.assertEqual(storage.get_conversation(ids[0])['draft'], 'متن ذخیره‌نشده')
        storage.update_conversation(ids[0], archived=True)
        self.assertEqual(storage.list_conversations(query='نام جدید')[1], 0)
        self.assertEqual(storage.list_conversations(archived=True)[1], 1)
        self.assertEqual(storage.list_conversations(archived=True, folder='پژوهش')[1], 1)
        self.assertTrue(storage.delete_conversation(ids[1]))
        self.assertEqual(storage.list_conversations()[1], 75)

    def test_branch_export_import_full_history(self):
        storage.init_db()
        origin = storage.create_conversation('chat', 'مقاله')
        a = storage.save_message(origin, 'user', 'user', 'پرسش ۱')
        b = storage.save_message(origin, 'assistant', 'model', 'جواب ۱')
        storage.save_message(origin, 'user', 'user', 'پرسش ۲')
        branch = storage.duplicate_conversation(origin, through_id=b)
        self.assertEqual([m['content'] for m in storage.get_conversation(branch)['messages']], ['پرسش ۱', 'جواب ۱'])
        self.assertEqual(len(storage.get_conversation(origin)['messages']), 3)
        with self.assertRaises(ValueError):
            storage.duplicate_conversation(branch, through_id=b)  # message belongs to origin
        storage.save_profile('منتقد', system_prompt='نقد کن')
        storage.save_skill('خطر بالقوه', 'print(1)')
        backup = storage.export_bundle()
        self.assertEqual(len(backup['conversations']), 2)
        self.assertEqual(len(backup['skills']), 1)
        restored = storage.import_bundle(json.loads(json.dumps(backup)))
        self.assertEqual(restored['imported'], 2)
        self.assertEqual(storage.list_conversations()[1], 4)
        self.assertEqual(len(storage.skills()), 1)  # imported code is NOT executed or duplicated
        self.assertIn('خودکار وارد نشدند', restored['skipped_config'])
        with self.assertRaises(ValueError):
            storage.import_bundle({'format':'nara-studio-backup',
                                   'conversations':[{'kind':'chat','messages':[{'role':'system','content':'no'}]}]})
        self.assertEqual(storage.list_conversations()[1], 4)  # atomic validation
        self.assertEqual(a, 1)

    def test_large_history_page_keeps_every_message(self):
        storage.init_db()
        cid = storage.create_conversation()
        for i in range(424):
            storage.save_message(cid, 'user', 'user', 'پیام شماره '+str(i))
        all_messages = storage.get_conversation(cid)
        self.assertEqual(all_messages['message_count'], 424)
        self.assertEqual(len(all_messages['messages']), 424)
        chunk = storage.get_conversation(cid, limit=200)
        self.assertEqual(len(chunk['messages']), 200)
        self.assertTrue(chunk['has_older'])
        before = chunk['messages'][0]['id']
        older = storage.get_conversation(cid, limit=200, before_id=before)
        self.assertEqual(len(older['messages']), 200)
        oldest = storage.get_conversation(cid, limit=200, before_id=older['messages'][0]['id'])
        self.assertEqual(len(oldest['messages']), 24)
        self.assertFalse(oldest['has_older'])

    def test_upgrade_from_v2_preserves_messages_and_makes_backup(self):
        with closing(sqlite3.connect(storage.DB_PATH)) as db:
            db.executescript('''
              CREATE TABLE conversations(id TEXT PRIMARY KEY, kind TEXT, title TEXT, config_json TEXT, created_at REAL, updated_at REAL);
              CREATE TABLE messages(id INTEGER PRIMARY KEY,conversation_id TEXT,role TEXT,speaker TEXT,content TEXT,
                                    model TEXT,provider TEXT,meta_json TEXT,created_at REAL);
              CREATE TABLE media_jobs(id TEXT PRIMARY KEY,model TEXT,mode TEXT,status TEXT,detail_json TEXT,created_at REAL,updated_at REAL);
              INSERT INTO conversations VALUES ('1234567890abcdef1234567890abcdef','chat','قدیمی','{}',1,1);
              INSERT INTO messages VALUES (1,'1234567890abcdef1234567890abcdef','user','user','متن تاریخی','', '', '{}',1);
              PRAGMA user_version=2;
            ''')
            db.commit()
        storage.init_db()
        backups = list(Path(self.temp.name).glob('history_before_v3_*.sqlite3'))
        self.assertEqual(len(backups), 1)
        with closing(sqlite3.connect(backups[0])) as old:
            self.assertEqual(old.execute('PRAGMA user_version').fetchone()[0], 2)
        conv = storage.get_conversation('1234567890abcdef1234567890abcdef')
        self.assertEqual(conv['messages'][0]['content'], 'متن تاریخی')
        self.assertEqual(conv['pinned'], 0)
        self.assertEqual(conv['draft'], '')
        with closing(sqlite3.connect(storage.DB_PATH)) as current:
            self.assertEqual(current.execute('PRAGMA user_version').fetchone()[0], 3)
        storage.init_db()
        self.assertEqual(len(list(Path(self.temp.name).glob('history_before_v3_*.sqlite3'))), 1)


if __name__ == '__main__':
    unittest.main()
