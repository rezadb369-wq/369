"""Local two-server chat integration: no paid API calls or outside networking."""
import http.client
import http.server
import json
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
import storage


class MockChat(http.server.BaseHTTPRequestHandler):
    lock=threading.Lock()
    received=[]
    def log_message(self,*_): pass
    def do_GET(self):
        data=json.dumps({'data':[{'id':'my-local-model','context_window':4000},{'id':'other-local-model','context_window':4000}]}).encode()
        self.send_response(200);self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def do_POST(self):
        body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        with MockChat.lock:MockChat.received.append(body)
        history=body['messages']
        latest=history[-1]['content']
        first='CUT' in latest or 'SLOW' in latest
        continued='Please continue' in latest
        answer='پاسخ اول' if first else ('بخش بعدی' if continued else 'عادی')
        finish='length' if first else 'stop'
        if not body.get('stream'):
            blob=json.dumps({'choices':[{'message':{'content':answer},'finish_reason':finish}]}).encode()
            self.send_response(200);self.send_header('Content-Length',str(len(blob)))
            self.end_headers();self.wfile.write(blob);return
        self.send_response(200);self.send_header('Content-Type','text/event-stream')
        self.end_headers()
        def event(obj):
            self.wfile.write(b'data: '+json.dumps(obj,ensure_ascii=False).encode()+b'\n\n');self.wfile.flush()
        try:
            event({'choices':[{'delta':{'content':answer},'finish_reason':None}]})
            if 'SLOW' in latest: time.sleep(0.8)
            event({'choices':[{'delta':{},'finish_reason':finish}]})
            self.wfile.write(b'data: [DONE]\n\n');self.wfile.flush()
        except (BrokenPipeError,ConnectionResetError):pass


class ChatHttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.old_db=storage.DB_PATH
        storage.DB_PATH=Path(cls.tmp.name)/'test.sqlite3';storage.init_db()
        cls.mock=http.server.ThreadingHTTPServer(('127.0.0.1',0),MockChat)
        cls.mock_thread=threading.Thread(target=cls.mock.serve_forever,daemon=True);cls.mock_thread.start()
        cls.server=app.LocalServer(('127.0.0.1',0),app.Handler)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
        cls.cookie='';cls.csrf=''
        s,boot,h=cls.call('GET','/api/bootstrap')
        assert s==200
        cls.cookie=h['set-cookie'].split(';')[0];cls.csrf=boot['csrf']
        s,created,_=cls.call('POST','/api/custom-providers',{'action':'save','label':'فقط تست محلی',
                 'base_url':f'http://127.0.0.1:{cls.mock.server_port}/v1',
                 'options':{'allow_local':True,'no_auth':True,'context_window':2000},'confirm_local':True})
        assert s==200,(s,created)
        cls.provider='custom:'+created['id']
        s,_,_=cls.call('POST','/api/connect',{'provider':cls.provider,'key':''})
        assert s==200

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join(timeout=3)
        cls.mock.shutdown();cls.mock.server_close();cls.mock_thread.join(timeout=3)
        storage.DB_PATH=cls.old_db;cls.tmp.cleanup()

    @classmethod
    def call(cls,method,path,payload=None):
        conn=http.client.HTTPConnection('127.0.0.1',cls.server.server_port,timeout=12)
        headers={}
        if cls.cookie:headers['Cookie']=cls.cookie
        if cls.csrf:headers['X-Local-CSRF']=cls.csrf
        if payload is not None:headers['Content-Type']='application/json'
        conn.request(method,path,json.dumps(payload).encode() if payload is not None else None,headers)
        res=conn.getresponse();raw=res.read();status=res.status
        head={k.lower():v for k,v in res.getheaders()};conn.close()
        if 'x-ndjson' in head.get('content-type',''):
            data=[json.loads(line) for line in raw.splitlines() if line]
        else:
            data=json.loads(raw) if 'json' in head.get('content-type','') else raw
        return status,data,head

    def new_chat(self):
        return self.call('POST','/api/conversations/create',{'kind':'chat','title':'تست پاسخ'})[1]['conversation']['id']

    def test_explicit_paid_guard_and_opt_in_probe(self):
        q={'provider':self.provider,'id':'my-local-model'}
        self.assertEqual(self.call('POST','/api/probe-model',q)[0],400)
        s,data,_=self.call('POST','/api/probe-model',dict(q,confirm_cost=True))
        self.assertEqual(s,200)
        self.assertEqual(data['result']['status'],'ok')
        self.assertTrue(data['catalog'][self.provider][0]['tested_now'])
        session=self.server.sessions[self.cookie.split('=',1)[1]]
        session['keys']['atria']='synthetic_mock_key_only'
        self.assertEqual(self.call('POST','/api/raw',{'provider':'atria','endpoint':'chat','body':{}})[0],400)
        session['keys'].pop('atria')
        self.assertEqual(self.call('POST','/api/raw',{'provider':self.provider,'endpoint':'models'})[0],400)

    def test_manual_and_auto_continuation_and_isolation(self):
        cid=self.new_chat();base={'conversation_id':cid,'provider':self.provider,'model':'my-local-model','message':'CUT','max_tokens':'auto'}
        preview=self.call('POST','/api/chat/preview',base)[1]
        self.assertFalse(preview['requires_context_ack'])
        self.assertIsNone(preview['output_limit'])
        status,events,_=self.call('POST','/api/chat',base)
        self.assertEqual(status,200)
        self.assertEqual(len([e for e in events if e['type']=='part_done']),1)
        self.assertEqual([e for e in events if e['type']=='part_done'][0]['finish'],'length')
        convo=storage.get_conversation(cid)
        self.assertEqual([m['role'] for m in convo['messages']],['user','assistant'])
        self.assertEqual(convo['messages'][0]['content'],'CUT')
        self.assertEqual(convo['title'],'تست پاسخ')  # explicit titles are never overwritten
        second=self.call('POST','/api/chat',dict(base,mode='continue',message=''))[1]
        self.assertEqual([e for e in second if e['type']=='part_done'][0]['text'],'بخش بعدی')
        self.assertEqual(len(storage.get_conversation(cid)['messages']),3)
        self.assertEqual(storage.get_conversation(cid)['messages'][-1]['meta']['continued'],True)
        cid2=self.new_chat()
        self.call('POST','/api/chat',dict(base,conversation_id=cid2,auto_continue=True,auto_batch=2))
        self.assertEqual(len(storage.get_conversation(cid2)['messages']),3)
        self.assertEqual(len(storage.get_conversation(cid)['messages']),3)
        self.assertTrue(all(m['content']!='CUT' or m['role']=='user' for m in storage.get_conversation(cid)['messages']))
        first_user=storage.get_conversation(cid)['messages'][0]
        s,edited,_=self.call('POST','/api/messages/edit',{'conversation_id':cid,
                                                'message_id':first_user['id'],'text':'سؤال تصحیح شد'})
        self.assertEqual(s,200)
        self.assertEqual(edited['message']['content'],'سؤال تصحیح شد')
        self.assertIn('edited_at',edited['message']['meta'])
        self.assertEqual(self.call('POST','/api/messages/edit',{'conversation_id':cid2,
                             'message_id':first_user['id'],'text':'اشتباه'})[0],404)

    def test_first_message_gives_untitled_chat_a_useful_title(self):
        cid=self.call('POST','/api/conversations/create',{'kind':'chat'})[1]['conversation']['id']
        self.call('POST','/api/chat',{'conversation_id':cid,'provider':self.provider,
                                    'model':'my-local-model','message':'موضوع جلسه: آزمایش مستقل'})
        self.assertEqual(storage.get_conversation(cid)['title'],'موضوع جلسه: آزمایش مستقل')

    def test_context_preview_required_and_no_history_deletion(self):
        cid=self.new_chat()
        for i in range(8):
            storage.save_message(cid,'user','user','q'+str(i)+'A'*600)
            storage.save_message(cid,'assistant','mock','r'+str(i)+'B'*600)
        request={'conversation_id':cid,'provider':self.provider,'model':'my-local-model','message':'last CUT'}
        count=storage.get_conversation(cid)['message_count']
        s,p,_=self.call('POST','/api/chat/preview',request)
        self.assertEqual(s,200)
        self.assertGreater(p['context']['omitted_count'],0)
        self.assertEqual(p['context']['total_count'],count+1)
        s,err,_=self.call('POST','/api/chat',request)
        self.assertEqual(s,409)
        self.assertEqual(storage.get_conversation(cid)['message_count'],count)
        events=self.call('POST','/api/chat',dict(request,ack_context_trim=True))[1]
        self.assertEqual(events[-1]['type'],'done')
        self.assertEqual(storage.get_conversation(cid)['message_count'],count+2)
        self.assertLess(len(MockChat.received[-1]['messages']),count+2)

    def test_group_user_models_critique_and_benchmark_are_persistent(self):
        panel=[{'provider':self.provider,'model':'my-local-model','role':'پژوهشگر'},
               {'provider':self.provider,'model':'other-local-model','role':'منتقد'}]
        room={'mode':'debate','panel':panel,'message':'این ایده را نقد کنید','synthesis':True,'max_tokens':'auto'}
        preview=self.call('POST','/api/room/preview',room)[1]
        self.assertEqual(preview['calls_max'],5)
        self.assertFalse(preview['requires_context_ack'])
        before=len(MockChat.received)
        s,events,_=self.call('POST','/api/room',room)
        self.assertEqual(s,200)
        self.assertEqual(events[-1]['type'],'room_done')
        self.assertEqual(events[-1]['answers'],5)
        cid=events[0]['conversation_id']
        convo=storage.get_conversation(cid)
        self.assertEqual(convo['kind'],'group')
        self.assertEqual(len(convo['messages']),6)
        self.assertEqual(convo['config']['members'][1]['role'],'منتقد')
        calls=MockChat.received[before:]
        self.assertEqual(len(calls),5)
        self.assertTrue(all('max_tokens' not in call for call in calls))
        self.assertIn('پژوهشگر',calls[0]['messages'][0]['content'])
        self.assertTrue(any('UNTRUSTED' in str(m['content']) for m in calls[2]['messages']))
        follow={'conversation_id':cid,'message':'حالا یک بازبینی دیگر','synthesis':False}
        s,events,_=self.call('POST','/api/room',follow)
        self.assertEqual(s,200)
        self.assertEqual(events[-1]['answers'],4)
        self.assertEqual(len(storage.get_conversation(cid)['messages']),11)
        bench=self.call('POST','/api/room',dict(room,mode='bench',synthesis=False))[1]
        self.assertEqual(bench[-1]['answers'],2)
        self.assertEqual(storage.get_conversation(bench[0]['conversation_id'])['kind'],'bench')

    def test_cancel_preserves_partial_and_does_not_block_another_chat(self):
        cid=self.new_chat();other=self.new_chat()
        conn=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=12)
        body={'conversation_id':cid,'provider':self.provider,'model':'my-local-model','message':'SLOW'}
        conn.request('POST','/api/chat',json.dumps(body).encode(),{'Content-Type':'application/json',
                     'Cookie':self.cookie,'X-Local-CSRF':self.csrf})
        res=conn.getresponse();self.assertEqual(res.status,200)
        first=json.loads(res.readline());self.assertEqual(first['type'],'start')
        self.assertEqual(json.loads(res.readline())['type'],'part_start')
        self.assertEqual(json.loads(res.readline())['type'],'delta')
        rid=first['request_id']
        s,blocked,_=self.call('POST','/api/chat',body)
        self.assertEqual(s,409)
        s,other_events,_=self.call('POST','/api/chat',dict(body,conversation_id=other,message='hello'))
        self.assertEqual(s,200)
        self.assertEqual(other_events[-1]['type'],'done')
        self.assertEqual(self.call('POST','/api/cancel',{'request_id':rid})[1]['cancel_requested'],True)
        more=[json.loads(line) for line in res.read().splitlines() if line]
        conn.close()
        self.assertTrue(any(e['type']=='cancelled' for e in more),more)
        answer=storage.get_conversation(cid)['messages'][-1]
        self.assertEqual(answer['content'],'پاسخ اول')
        self.assertTrue(answer['meta']['partial'])
        self.assertEqual(len(storage.get_conversation(other)['messages']),2)


if __name__=='__main__':unittest.main()
