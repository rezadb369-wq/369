/* Optional desktop browser smoke test; NOT required for Pydroid or normal use.
   On a development computer: npm install --no-save playwright &&
   npx playwright install chromium && node tests/browser_smoke_optional.js
   Uses a local mock API; no external AI key, paid request, or production URL.
*/
'use strict';
const assert=require('node:assert/strict');
const http=require('node:http');
const os=require('node:os');
const fs=require('node:fs');
const path=require('node:path');
const {spawn}=require('node:child_process');
const {chromium}=require('playwright');
const project=path.resolve(__dirname,'..');
const data=fs.mkdtempSync(path.join(os.tmpdir(),'nara-v3-ui-'));
const mock=http.createServer((req,res)=>{
 if(req.url==='/v1/models'){
  res.writeHead(200,{'Content-Type':'application/json'});
  res.end(JSON.stringify({data:[{id:'model-local-a',context_window:2000},{id:'model-local-b',context_window:2000}]}));return;
 }
 if(req.url!=='/v1/chat/completions'){res.writeHead(404);res.end();return}
 let text='';req.on('data',chunk=>text+=chunk);req.on('end',()=>{
  const body=JSON.parse(text),prompt=body.messages.at(-1).content;
  const answer=prompt.includes('CUT')?'بخش اول':prompt.includes('Please continue')?'بخش دوم':'پاسخ mock محلی';
  const finish=prompt.includes('CUT')?'length':'stop';
  if(body.stream){res.writeHead(200,{'Content-Type':'text/event-stream'});
   res.write('data: '+JSON.stringify({choices:[{delta:{content:answer},finish_reason:null}]})+'\n\n');
   res.end('data: '+JSON.stringify({choices:[{delta:{},finish_reason:finish}]})+'\n\ndata: [DONE]\n\n');
  }else{res.writeHead(200,{'Content-Type':'application/json'});
   res.end(JSON.stringify({choices:[{message:{content:answer},finish_reason:finish}]}));}
 });
});
function waitForURL(child){return new Promise((resolve,reject)=>{
 let output='';const timeout=setTimeout(()=>reject(Error('Python server did not start. '+output)),15000);
 child.stdout.on('data',chunk=>{output+=chunk.toString();const match=output.match(/http:\/\/127\.0\.0\.1:\d+\//);
  if(match){clearTimeout(timeout);resolve(match[0]);}});
 child.stderr.on('data',chunk=>{output+=chunk.toString()});
 child.on('exit',code=>{clearTimeout(timeout);reject(Error('Server exited '+code+': '+output))});
});}
(async()=>{
 await new Promise(resolve=>mock.listen(0,'127.0.0.1',resolve));
 const server=spawn(process.env.PYTHON||'python',['app.py','--no-browser','--port','0'],
  {cwd:project,env:{...process.env,NARA_STUDIO_DATA:data},stdio:['ignore','pipe','pipe']});
 let browser;
 try{
  const url=await waitForURL(server);
  browser=await chromium.launch({headless:true,args:['--no-sandbox']});
  const page=await browser.newPage({viewport:{width:1300,height:850}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto(url);await page.waitForFunction(()=>typeof state!=='undefined'&&!!state.csrf);
  await page.locator('#newChat').click();
  await page.waitForFunction(()=>!!state.currentChat&&state.history.some(c=>c.id===state.currentChat));
  const first=await page.evaluate(()=>state.currentChat);
  await page.locator('#newChat').click();
  await page.waitForFunction(id=>!!state.currentChat&&state.currentChat!==id&&state.history.some(c=>c.id===state.currentChat),first);
  const second=await page.evaluate(()=>state.currentChat);
  assert(first&&second&&first!==second,'Two independent conversations must exist');
  await page.locator('#settingsButton').click();
  await page.locator('#customLabel').fill('Mock service');
  await page.locator('#customUrl').fill('http://127.0.0.1:'+mock.address().port+'/v1');
  await page.locator('#customAllowLocal').check();await page.locator('#customNoAuth').check();
  await page.locator('#customSave').click();await page.waitForFunction(()=>!!state.customId);
  await page.locator('#customConnect').click();await page.waitForFunction(()=>state.providers['custom:'+state.customId]);
  await page.locator('#settingsDialog .dialog-footer button').click();
  await page.locator('#chatOptions summary').click();
  await page.locator('#chatProvider').selectOption({value:await page.evaluate(()=>'custom:'+state.customId)});
  await page.locator('#chatModel').selectOption('model-local-a');
  await page.locator('#chatPrompt').fill('CUT');await page.locator('#chatSend').click();
  await page.waitForFunction(()=>state.chatConvo?.messages?.some(m=>m.content==='بخش اول'));
  assert(await page.locator('#chatContinue').isEnabled(),'Manual continuation enabled');
  await page.locator('#chatContinue').click();
  await page.waitForFunction(()=>state.chatConvo?.messages?.some(m=>m.content==='بخش دوم'));
  await page.locator('.history-row[data-id="'+first+'"]').click();
  await page.waitForFunction(id=>state.currentChat===id,first);
  assert.equal((await page.locator('#chatMessages .message').count()),0,'Other chat stays empty');
  await page.locator('#chatOrganize').click();await page.locator('#manageTitle').fill('فایل مستقل');
  await page.locator('#managePinned').check();await page.locator('#manageSave').click();
  await page.waitForFunction(()=>state.chatConvo?.title==='فایل مستقل');
  await page.locator('#settingsButton').click();await page.locator('#themeSelect').selectOption('dark');
  await page.locator('#fontScaleSelect').selectOption('1.25');
  await page.locator('#readingWidthSelect').selectOption('620px');
  await page.locator('#accentSelect').selectOption('teal');
  await page.locator('#settingsDialog .dialog-footer button').click();
  await page.setViewportSize({width:390,height:844});await page.waitForTimeout(350);
  const metrics=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth-innerWidth,
   theme:document.documentElement.dataset.theme,accent:document.documentElement.dataset.accent,
   font:getComputedStyle(document.documentElement).getPropertyValue('--message-font-size').trim(),
   width:getComputedStyle(document.documentElement).getPropertyValue('--reading-width').trim(),
   storage:Object.keys(localStorage).sort()}));
  assert(metrics.overflow<=3,JSON.stringify(metrics));assert.equal(metrics.theme,'dark');
  assert.equal(metrics.accent,'teal');assert.equal(metrics.font,'16.25px');assert.equal(metrics.width,'620px');
  assert.deepEqual(metrics.storage,['nara-accent-v3','nara-density-v3','nara-font-v3','nara-theme-v3','nara-width-v3'],
   'Only appearance preferences, never API keys, may be stored in localStorage');
  await page.reload();
  await page.waitForFunction(ids=>!!state.csrf&&ids.every(id=>state.history.some(c=>c.id===id))&&!!state.currentChat,[first,second]);
  const restored=await page.evaluate(()=>({theme:document.documentElement.dataset.theme,
   accent:document.documentElement.dataset.accent,
   font:getComputedStyle(document.documentElement).getPropertyValue('--message-font-size').trim(),
   width:getComputedStyle(document.documentElement).getPropertyValue('--reading-width').trim()}));
  assert.deepEqual(restored,{theme:'dark',accent:'teal',font:'16.25px',width:'620px'});
  await page.locator('#menuButton').click();assert(await page.locator('#sidebar').evaluate(e=>e.classList.contains('open')));
  await page.locator('.history-row[data-id="'+second+'"]').click();
  await page.waitForFunction(id=>state.currentChat===id&&state.chatConvo?.messages?.some(m=>m.content==='بخش دوم'),second);
  assert.deepEqual(errors,[],'No JavaScript runtime exceptions');
  console.log('PASS: independent and restored chats, mock connection, manual continuation, management, mobile, persisted appearance, no JS errors.');
 }finally{
  if(browser)await browser.close();server.kill('SIGTERM');await new Promise(resolve=>mock.close(resolve));
  fs.rmSync(data,{recursive:true,force:true});
 }
})().catch(e=>{console.error(e);process.exitCode=1});
