import sys
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import chat_flow
import core


class ChatFlowTests(unittest.TestCase):
    def test_profile_and_note_are_visible_and_editable(self):
        profiles=[{'id':'p1','system_prompt':'با من صادق باش','options':{'effort':'high','max_tokens':'auto'}}]
        conv={'profile_id':'p1','context_note':'نام پروژه = نیلوفر','messages':[]}
        settings=chat_flow.settings_for({'system':'جواب به فارسی','integrity_prompt':False},conv,profiles,'bynara','chat')
        self.assertIn('نیلوفر',settings['system'])
        self.assertIn('جواب به فارسی',settings['system'])
        self.assertEqual(settings['effort'],'high')
        self.assertIsNone(settings['max_tokens'])
        self.assertFalse(settings['integrity_prompt'])
        plan,text=chat_flow.context_for(conv,'سؤال', 'send',{'context_window':512000},settings,'bynara')
        self.assertEqual(plan.omitted_count,0)
        self.assertEqual(text,'سؤال')

    def test_manual_continuation_is_not_silent_new_question(self):
        c={'messages':[{'role':'user','content':'x'},{'role':'assistant','content':'start'}]}
        history,text=chat_flow.history_for(c,'','continue')
        self.assertIn('continue',text.lower())
        self.assertEqual(history[-1]['role'],'user')
        c['messages'].append({'role':'user','content':'new message'})
        with self.assertRaises(core.RemoteError):chat_flow.history_for(c,'','continue')

    def test_context_window_reports_omission(self):
        c={'messages':[]}
        for i in range(100):
            c['messages'] += [{'role':'user','content':'A'*100},{'role':'assistant','content':'B'*100}]
        settings=chat_flow.settings_for({},c,[], 'atria','chat')
        plan,_=chat_flow.context_for(c,'last?', 'send',{},settings,'atria')
        self.assertEqual(plan.omitted_count,0) # well below Atria's 256k
        plan,_=chat_flow.context_for(c,'last?', 'send',{'context_window':1500},settings,'bynara')
        self.assertGreater(plan.omitted_count,0)


if __name__=='__main__':unittest.main()
