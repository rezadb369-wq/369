"""Offline regression tests; no API keys or paid requests."""
import base64
import io
import json
import sqlite3
import sys
import tempfile
import unittest
import zipfile
import urllib.request
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app
import core
import extract
import storage


class CoreTests(unittest.TestCase):
    def test_redaction_and_header_validation(self):
        self.assertNotIn('sk-nry-secret', core.redact('failed sk-nry-secret-secrethere'))
        self.assertNotIn('atr_mysecret', core.redact('atr_mysecret_too_long_12345'))
        with self.assertRaises(core.RemoteError):
            core.check_key('bynara', 'sk-nry-abc\r\nX-Injected: true')

    def test_api_key_redirect_never_crosses_host(self):
        req = urllib.request.Request('https://router.bynara.id/v1/models',
                                     headers={'Authorization': 'Bearer fake_secret'})
        with self.assertRaises(core.RemoteError):
            core.FixedRedirect().redirect_request(req, None, 302, 'Redirect', {},
                                                   'https://api-images.bynara.id/v1/models')
        safe = core.FixedRedirect().redirect_request(req, None, 302, 'Redirect', {},
                                                      'https://router.bynara.id/v1/models-new')
        self.assertEqual(safe.full_url, 'https://router.bynara.id/v1/models-new')

    def test_media_magic_bytes_and_limit(self):
        png = app.make_red_png()
        decoded = core.validate_images([{'base64': base64.b64encode(png).decode()}])
        self.assertEqual(decoded[0]['mime'], 'image/png')
        self.assertEqual(decoded[0]['bytes'], png)
        with self.assertRaises(core.RemoteError):
            core.validate_images([{'base64': base64.b64encode(b'<svg>evil</svg>').decode()}])
        with self.assertRaises(core.RemoteError):
            core.validate_images([{'base64': base64.b64encode(png).decode()}]*4)

    def test_responses_shape_and_no_thinking(self):
        path, body = core.chat_payload('bynara', 'responses', 'agnes-2.5-flash',
                                       [{'role': 'user', 'content': 'hi'}], max_tokens=300,
                                       effort='low', stream=False)
        self.assertEqual(path, '/v1/responses')
        self.assertEqual(body['input'][0]['content'][0]['type'], 'input_text')
        answer = core.final_answer('responses', {'output': [
            {'type': 'reasoning', 'content': [{'type': 'reasoning_text', 'text': 'PRIVATE'}]},
            {'type': 'message', 'content': [{'type': 'output_text', 'text': 'OK'}]}]})
        self.assertEqual(answer['text'], 'OK')
        self.assertEqual(core.stream_delta('chat', {'choices': [{'delta': {'reasoning_content': 'PRIVATE', 'content': 'OK'}}]})[0], 'OK')

    def test_vision_requires_verified_route(self):
        image = {'base64': base64.b64encode(app.make_red_png()).decode()}
        with self.assertRaises(core.RemoteError):
            core.chat_payload('atria', 'chat', 'Atria-Dawn-Preview', [{'role': 'user', 'content': 'hi'}], images=[image])
        with self.assertRaises(core.RemoteError):
            core.chat_payload('bynara', 'responses', 'agnes-2.5-flash', [{'role': 'user', 'content': 'hi'}], images=[image], vision=True)
        _, payload = core.chat_payload('bynara', 'chat', 'agnes-2.5-flash',
                                       [{'role': 'user', 'content': 'What color?'}], images=[image], vision=True)
        content = payload['messages'][-1]['content']
        self.assertEqual(content[1]['type'], 'image_url')
        self.assertTrue(content[1]['image_url']['url'].startswith('data:image/png;base64,'))

    def test_plain_text_extract(self):
        data = 'کد سریال: 31415'.encode('utf-8')
        result = extract.extract('report.txt', base64.b64encode(data).decode())
        self.assertIn('31415', result['text'])
        self.assertEqual(result['chars'], len(result['text']))
        longer = extract.extract('long.txt', base64.b64encode(b'A'*90000).decode())
        self.assertEqual(longer['chars'], 90000)
        self.assertFalse(longer['truncated'])
        with self.assertRaises(extract.ExtractionError):
            extract.extract('too-long.txt', base64.b64encode(b'A'*(extract.MAX_TEXT+1)).decode())
        with self.assertRaises(extract.ExtractionError):
            extract.extract('file.txt', base64.b64encode(b'\x00\x01bad').decode())

    def test_office_docx_text_extract(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as z:
            z.writestr('word/document.xml', '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>سلام آزمون</w:t></w:r></w:p></w:body></w:document>')
        result = extract.extract('sample.docx', base64.b64encode(buf.getvalue()).decode())
        self.assertIn('سلام آزمون', result['text'])
        with self.assertRaises(extract.ExtractionError):
            extract.extract('bad.zip', base64.b64encode(buf.getvalue()).decode())

    def test_media_payloads_match_documented_forms_without_charging(self):
        fake = {'id': 'testvideo_123', 'status': 'pending'}
        with patch.object(core, 'remote_json', return_value=(fake, 202)) as transport:
            result, code = core.video_create('not_a_real_key', 'happyhorse-1.1-t2v',
                                             'A little bird flying', duration=5)
            self.assertEqual((result['status'], code), ('pending', 202))
            args, kwargs = transport.call_args
            self.assertEqual(args[2], '/v1/videos')
            self.assertEqual(args[3]['mode'], 't2v')
            self.assertEqual(args[3]['duration'], 5)
        png = {'base64': base64.b64encode(app.make_red_png()).decode()}
        with patch.object(core, 'remote_json', return_value=(fake, 202)) as transport:
            core.video_create('not_a_real_key', 'happyhorse-1.1-i2v', 'The scene moves',
                              mode='i2v', images=[png])
            form, content_type = transport.call_args.kwargs['multipart']
            self.assertIn(b'name="image"; filename="upload.png"', form)
            self.assertIn(b'name="mode"\r\n\r\ni2v', form)
            self.assertIn('multipart/form-data', content_type)
        with patch.object(core, 'remote_json', return_value=({'data': []}, 200)) as transport:
            core.image_generate('not_a_real_key', 'agnes-image-2.0-flash', 'Red circle')
            self.assertEqual(transport.call_args.args[2], '/v1/images/generations')
            self.assertTrue(transport.call_args.kwargs['image_host'])

    def test_video_validation_no_network(self):
        with self.assertRaises(core.RemoteError):
            core.video_create('unused_dummy_secret', 'agnes-video-v2.0', 'hi', mode='i2v', images=[])
        with self.assertRaises(core.RemoteError):
            core.video_status('unused_dummy_secret', 'http://localhost/private')


class StorageTests(unittest.TestCase):
    def test_upgrade_creates_original_backup(self):
        original = storage.DB_PATH
        with tempfile.TemporaryDirectory() as tmp:
            try:
                storage.DB_PATH = Path(tmp) / 'history.sqlite3'
                with closing(sqlite3.connect(storage.DB_PATH)) as old:
                    old.execute('CREATE TABLE legacy_data (value TEXT)')
                    old.execute("INSERT INTO legacy_data VALUES ('keep me')")
                    old.execute('CREATE TABLE conversations (id TEXT PRIMARY KEY, kind TEXT, title TEXT, config_json TEXT, created_at REAL, updated_at REAL)')
                    old.execute('CREATE TABLE messages (id INTEGER PRIMARY KEY, conversation_id TEXT, role TEXT, speaker TEXT, content TEXT, model TEXT, provider TEXT, meta_json TEXT, created_at REAL)')
                    old.execute('PRAGMA user_version=1')
                    old.commit()
                storage.init_db()
                backups = list(Path(tmp).glob('history_before_v3_*.sqlite3'))
                self.assertEqual(len(backups), 1)
                with closing(sqlite3.connect(backups[0])) as saved:
                    self.assertEqual(saved.execute('SELECT value FROM legacy_data').fetchone()[0], 'keep me')
                with closing(sqlite3.connect(storage.DB_PATH)) as upgraded:
                    self.assertEqual(upgraded.execute('PRAGMA user_version').fetchone()[0], 3)
            finally:
                storage.DB_PATH = original

    def test_schema_and_history_and_backup(self):
        original = storage.DB_PATH
        with tempfile.TemporaryDirectory() as tmp:
            try:
                storage.DB_PATH = Path(tmp) / 'history.sqlite3'
                storage.init_db()
                cid = storage.create_conversation('group', 'یک گروه', {'members': ['a', 'b']})
                storage.save_message(cid, 'user', 'user', 'سلام')
                storage.save_message(cid, 'assistant', 'model-a', 'درود', model='model-a')
                self.assertEqual(len(storage.get_conversation(cid)['messages']), 2)
                self.assertEqual(storage.list_conversations()[1], 1)
                storage.upsert_media_job('test-video-id', 'agnes-video-v2.0', 't2v', 'pending')
                self.assertEqual(storage.media_jobs()[0]['status'], 'pending')
                storage.init_db()  # idempotent
                self.assertTrue(storage.delete_conversation(cid))
                self.assertFalse(storage.get_conversation(cid))
            finally:
                storage.DB_PATH = original


if __name__ == '__main__':
    unittest.main()
