"""HTTP-level tests use a private loopback server; never touch a real API key."""
import http.client
import base64
import json
import sqlite3
import sys
import tempfile
import threading
import unittest
from urllib.parse import quote
from contextlib import closing
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
import storage


class V3HttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        cls.old_db=storage.DB_PATH
        storage.DB_PATH=Path(cls.temp.name)/'history.sqlite3'
        storage.init_db()
        cls.server=app.LocalServer(('127.0.0.1',0),app.Handler)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
        cls.cookie='';cls.csrf=''
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join(timeout=3)
        storage.DB_PATH=cls.old_db
        cls.temp.cleanup()

    def call(self,method,path,obj=None,csrf=True):
        con=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=10)
        headers={}
        if self.cookie:headers['Cookie']=self.cookie
        if self.csrf and csrf:headers['X-Local-CSRF']=self.csrf
        if obj is not None:headers['Content-Type']='application/json'
        con.request(method,path,json.dumps(obj).encode() if obj is not None else None,headers)
        res=con.getresponse();blob=res.read();headers=dict((k.lower(),v) for k,v in res.getheaders())
        status=res.status;con.close()
        return status, (json.loads(blob) if 'json' in headers.get('content-type','') else blob), headers

    def bootstrap(self):
        s,d,h=self.call('GET','/api/bootstrap')
        self.assertEqual(s,200)
        self.csrf=d['csrf']
        self.cookie=h.get('set-cookie',self.cookie).split(';')[0]
        return d

    def test_many_chats_visible_without_deleting_and_organize(self):
        self.bootstrap()
        baseline=self.call('GET','/api/conversations')[1]['total']
        ids=[]
        for n in range(51):
            status,body,_=self.call('POST','/api/conversations/create',{'kind':'chat','title':'گفتگو %s'%n})
            self.assertEqual(status,200)
            ids.append(body['conversation']['id'])
        status,listing,_=self.call('GET','/api/conversations?limit=30&offset=0')
        self.assertEqual((status,len(listing['conversations']),listing['total']),(200,30,baseline+51))
        second=self.call('GET','/api/conversations?limit=30&offset=30')[1]
        self.assertEqual(len(second['conversations']),min(30,baseline+21))
        new_id=ids[-1]
        s,updated,_=self.call('POST','/api/conversations/update',
                              {'id':new_id,'changes':{'title':'پروندهٔ پژوهشی','pinned':True,'draft':'ناتمام'}})
        self.assertEqual(s,200)
        self.assertEqual(updated['conversation']['draft'],'ناتمام')
        self.assertEqual(self.call('GET','/api/conversations?q='+quote('پژوهشی'))[1]['total'],1)
        branch=self.call('POST','/api/conversations/clone',{'id':new_id})[1]['conversation']
        self.assertNotEqual(branch['id'],new_id)
        self.assertEqual(self.call('GET','/api/conversations')[1]['total'],baseline+52)
        self.call('POST','/api/conversations/update',{'id':new_id,'changes':{'archived':True}})
        self.assertEqual(self.call('GET','/api/conversations?archived=1')[1]['total'],1)
        self.assertEqual(self.call('GET','/api/conversations')[1]['total'],baseline+51)
        original=storage.get_conversation(new_id)
        self.assertEqual(self.call('POST','/api/conversations/delete',{'id':new_id})[0],400)
        self.assertEqual(self.call('POST','/api/conversations/delete',
            {'id':new_id,'confirm_delete':True,'confirm_title':'اشتباه'})[0],400)
        self.assertEqual(self.call('POST','/api/conversations/delete',
            {'id':new_id,'confirm_delete':True,'confirm_title':original['title']})[1]['deleted'],True)

    def test_export_import_and_sqlite_backup(self):
        self.bootstrap()
        self.call('POST','/api/conversations/create',{'kind':'chat','title':'پشتیبان تست'})
        bundle=self.call('POST','/api/backup/export',{})[1]['bundle']
        self.assertEqual(bundle['format'],'nara-studio-backup')
        count=len(bundle['conversations'])
        self.assertGreaterEqual(count,1)
        imported=self.call('POST','/api/backup/import',{'bundle':bundle})[1]
        self.assertEqual(imported['imported'],count)
        single=self.call('POST','/api/conversations/export',{'id':bundle['conversations'][0]['id']})[1]
        self.assertEqual(single['format'],'nara-studio-conversation-v3')
        self.assertEqual(self.call('POST','/api/backup/import',{'bundle':single})[1]['imported'],1)
        status,blob,headers=self.call('GET','/api/backup/sqlite')
        self.assertEqual(status,200)
        self.assertTrue(blob.startswith(b'SQLite format 3'))
        with tempfile.NamedTemporaryFile(suffix='.sqlite3') as f:
            f.write(blob);f.flush()
            with closing(sqlite3.connect(f.name)) as con:
                self.assertEqual(con.execute('PRAGMA user_version').fetchone()[0],3)

    def test_vision_requires_per_session_probe_or_historical_consent(self):
        self.bootstrap()
        sess=self.server.sessions[self.cookie.split('=',1)[1]]
        sess['keys']['bynara']='fake_offline_key'
        sess['catalog']['bynara']=[{'id':'agnes-2.5-flash','context_window':512000,'vision':True}]
        sess['vision_ok'].clear()
        img=base64.b64encode(app.make_red_png()).decode()
        req={'provider':'bynara','model':'agnes-2.5-flash','message':'رنگ این تصویر چیست؟','images':[{'base64':img}]}
        self.assertEqual(self.call('POST','/api/chat/preview',req)[0],400)
        status,preview,_=self.call('POST','/api/chat/preview',dict(req,accept_historical_vision=True))
        self.assertEqual(status,200)
        self.assertIn('در SQLite ذخیره نمی‌شوند',preview['image_note'])
        self.assertEqual(self.call('POST','/api/probe-vision',{'provider':'bynara','id':'agnes-2.5-flash'})[0],400)
        sess['keys'].pop('bynara');sess['catalog'].pop('bynara')

    def test_profiles_skills_and_manual_code_review(self):
        self.bootstrap()
        s,p,_=self.call('POST','/api/profiles',{'action':'save','title':'صداقت','system_prompt':'اگر نمی‌دانی بگو نمی‌دانم','options':{'effort':'high'}})
        self.assertEqual(s,200);self.assertEqual(p['profiles'][0]['title'],'صداقت')
        s,k,_=self.call('POST','/api/skills',{'action':'save','title':'ابزار دستی','code':'print(2+2)'})
        self.assertEqual(s,200)
        skill=k['skills'][0]
        denied=self.call('POST','/api/tools/execute',{'nonce':'wrong','confirm_run':True})
        self.assertEqual(denied[0],403)
        approved=self.call('POST','/api/tools/review',{'skill_id':skill['id']})
        self.assertTrue(approved[1]['ok'])
        self.assertIn('print(2+2)',approved[1]['code'])
        nonce=approved[1]['nonce']
        s,result,_=self.call('POST','/api/tools/execute',{'nonce':nonce,'confirm_run':True,'timeout':4})
        self.assertEqual(s,200)
        self.assertEqual(result['execution']['stdout'].strip(),'4')
        self.assertEqual(self.call('POST','/api/tools/execute',{'nonce':nonce,'confirm_run':True})[0],403)
        self.assertEqual(self.call('POST','/api/tools/calculate',{'expression':'(3*120)*0.9+40'})[1]['result'],364)
        self.assertEqual(self.call('POST','/api/tools/save',{'name':'../bad.txt','text':'no','confirm_write':True})[0],400)
        self.assertEqual(self.call('POST','/api/tools/save',{'name':'notes.txt','text':'hello','confirm_write':True})[0],200)
        self.assertEqual(self.call('POST','/api/tools/read',{'name':'notes.txt'})[1]['text'],'hello')


if __name__=='__main__':unittest.main()
