"""Local HTTP contract/security tests. No external requests or real credentials."""
import base64
import http.client
import json
import sys
import tempfile
import threading
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app
import storage


class ServerContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.db_original = storage.DB_PATH
        storage.DB_PATH = Path(cls.temp.name) / 'history.sqlite3'
        storage.init_db()
        cls.server = app.LocalServer(('127.0.0.1', 0), app.Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.cookie = ''
        cls.csrf = ''

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=3)
        storage.DB_PATH = cls.db_original
        cls.temp.cleanup()

    def request(self, method, path, payload=None, headers=None, cookie=True, csrf=True):
        conn = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=8)
        hdrs = dict(headers or {})
        if cookie and self.cookie:
            hdrs.setdefault('Cookie', self.cookie)
        if csrf and self.csrf:
            hdrs.setdefault('X-Local-CSRF', self.csrf)
        body = None if payload is None else json.dumps(payload).encode('utf-8')
        if body is not None:
            hdrs['Content-Type'] = 'application/json'
        conn.request(method, path, body=body, headers=hdrs)
        res = conn.getresponse()
        headers = {k.lower(): v for k, v in res.getheaders()}
        content = res.read()
        status = res.status
        conn.close()
        return status, json.loads(content), headers

    def test_bootstrap_cookie_and_csrf(self):
        status, data, hdr = self.request('GET', '/api/bootstrap', cookie=False)
        self.assertEqual(status, 200)
        self.assertTrue(data['csrf'])
        self.assertIn('HttpOnly', hdr['set-cookie'])
        self.assertIn('SameSite=Strict', hdr['set-cookie'])
        self.assertEqual(hdr['cache-control'], 'no-store')
        self.__class__.cookie = hdr['set-cookie'].split(';', 1)[0]
        self.__class__.csrf = data['csrf']

    def test_unauthenticated_and_invalid_origin(self):
        self.test_bootstrap_cookie_and_csrf()
        status, _, _ = self.request('POST', '/api/media/image', {'confirm_cost': True}, csrf=False)
        self.assertEqual(status, 403)
        status, _, _ = self.request('POST', '/api/media/image', {'confirm_cost': True},
                                    headers={'Origin': 'http://untrusted.example'})
        self.assertEqual(status, 403)
        status, _, _ = self.request('GET', '/api/bootstrap',
                                    headers={'Host': 'attacker.example'}, cookie=False, csrf=False)
        self.assertEqual(status, 403)

    def test_file_request_and_paid_guard(self):
        self.test_bootstrap_cookie_and_csrf()
        payload = {'name': 'report.md', 'base64': base64.b64encode('گزارش مالی'.encode()).decode()}
        status, data, _ = self.request('POST', '/api/files/extract', payload)
        self.assertEqual(status, 200)
        self.assertIn('گزارش', data['text'])
        token = self.cookie.split('=', 1)[1]
        self.server.sessions[token]['keys']['bynara'] = 'synthetic_local_test_key'
        status, error, _ = self.request('POST', '/api/media/image', {'action': 'generate', 'confirm_cost': False})
        self.assertEqual(status, 400)
        self.assertIn('هزینه', error['error'])


if __name__ == '__main__':
    unittest.main()
