import io
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import core


class CoreV3Tests(unittest.TestCase):
    def test_no_ui_token_cap_and_optional_field(self):
        history = [{'role':'user','content':'سلام'}]
        _, chat = core.chat_payload('bynara','chat','agnes-2.5-flash',history,max_tokens='auto')
        self.assertNotIn('max_tokens', chat)
        _, response = core.chat_payload('atria','responses','Atria-Dawn-Preview',history,max_tokens=None)
        self.assertNotIn('max_output_tokens', response)
        _, msg = core.chat_payload('atria','messages','Atria-Dawn-Preview',history,max_tokens='auto')
        self.assertEqual(msg['max_tokens'], 65536)
        _, large = core.chat_payload('bynara','chat','agnes-2.5-flash',history,max_tokens=190000)
        self.assertEqual(large['max_tokens'],190000)
        with self.assertRaisesRegex(core.RemoteError, 'Atria'):
            core.chat_payload('atria','chat','Atria-Dawn-Preview',history,max_tokens=65537)
        self.assertIsNone(core.estimate_cost({'input_idr_per_1m':1,'output_idr_per_1m':2},100,None))

    def test_past_70_turns_and_editable_integrity(self):
        history = [{'role': 'user' if i%2==0 else 'assistant','content':str(i)} for i in range(150)]
        history.append({'role':'user','content':'final'})
        _, body = core.chat_payload('bynara','chat','agnes-2.5-flash',history,integrity_prompt=False)
        self.assertEqual(len(body['messages']),152)
        self.assertNotIn('untrusted', body['messages'][0]['content'])

    def test_responses_incomplete_finish_reason(self):
        parsed = core.final_answer('responses',{'output_text':'unfinished','status':'incomplete',
                    'incomplete_details':{'reason':'max_output_tokens'}})
        self.assertEqual(parsed['finish'],'max_output_tokens')
        event = {'type':'response.incomplete','response':{'status':'incomplete',
                 'incomplete_details':{'reason':'max_output_tokens'}}}
        self.assertEqual(core.stream_delta('responses',event)[1],'max_output_tokens')

    def test_stream_cancels_with_partial_emit(self):
        data = b''.join([b'data: '+json.dumps({'choices':[{'delta':{'content':ch},'finish_reason':None}]}).encode()+b'\n\n'
                         for ch in 'abcdef'])+b'data: [DONE]\n\n'
        emitted = []
        with self.assertRaises(core.RemoteError) as exc:
            core.collect_stream('chat',io.BytesIO(data),emitted.append,cancelled=lambda:len(emitted)>=2)
        self.assertEqual(exc.exception.kind,'cancelled')
        self.assertEqual(''.join(e['text'] for e in emitted),'ab')


if __name__=='__main__':
    unittest.main()
