import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import storage
import workspace_tools as tools


class ManualToolsTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.patch=patch.object(storage,'data_dir',return_value=Path(self.temp.name))
        self.patch.start()
    def tearDown(self):
        self.patch.stop();self.temp.cleanup()

    def test_workspace_boundary_and_user_files(self):
        record=tools.save_text('notes/project.md','hello سلام')
        self.assertEqual(record['path'],'notes/project.md')
        self.assertEqual(tools.read_text('notes/project.md'),'hello سلام')
        self.assertEqual(len(tools.list_files()),1)
        for path in ('../private.txt','/etc/passwd','notes/../../../bad.txt'):
            with self.assertRaises(tools.ToolError,msg=path):tools.path_for(path)
        secret=Path(self.temp.name)/'elsewhere.txt';secret.write_text('not yours')
        (tools.root()/'shortcut.txt').symlink_to(secret)
        with self.assertRaises(tools.ToolError):tools.read_text('shortcut.txt')
        with self.assertRaises(tools.ToolError):tools.save_text('evil.exe','x')

    def test_user_manually_run_python_not_a_sandbox(self):
        code='print("manual code OK")'
        sha=tools.syntax_check(code)['sha256']
        result=tools.run_python(code,timeout=5)
        self.assertIn('manual code OK',result['stdout'])
        self.assertEqual(result['sha256'],sha)
        self.assertIn('sandbox',result['warning'])
        self.assertFalse([p for p in tools.root().iterdir() if p.name.startswith('.nara_manual')])
        bad=tools.syntax_check('if (')
        self.assertFalse(bad['ok'])
        with self.assertRaises(tools.ToolError):tools.run_python('if (')

    def test_calculator_is_deterministic_and_non_executable(self):
        self.assertEqual(tools.calculate('(3*120)*0.9+40'),364.0)
        with self.assertRaises(tools.ToolError):tools.calculate('__import__("os").system("true")')
        with self.assertRaises(tools.ToolError):tools.calculate('2**100000')
        with self.assertRaises(tools.ToolError):tools.calculate('1/0')


if __name__=='__main__':unittest.main()
