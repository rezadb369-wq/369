import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import generation


class GenerationTests(unittest.TestCase):
    def test_output_auto_removes_app_cap_except_required_messages(self):
        self.assertIsNone(generation.output_limit('auto', 'bynara', 'chat'))
        self.assertIsNone(generation.output_limit('', 'atria', 'responses'))
        self.assertEqual(generation.output_limit('auto', 'atria', 'messages'), 65536)
        self.assertEqual(generation.output_limit(230000, 'bynara', 'chat'), 230000)
        self.assertEqual(generation.output_limit(65536, 'atria', 'chat'), 65536)
        with self.assertRaisesRegex(generation.ContextError, 'Atria'):
            generation.output_limit(65537, 'atria', 'chat')
        with self.assertRaises(generation.ContextError):
            generation.output_limit(True)

    def test_context_is_explicit_not_lost_from_storage(self):
        original = []
        for i in range(30):
            original.extend([{'role':'user','content':'درخواست %s '%i+'الف'*300},
                             {'role':'assistant','content':'پاسخ %s '%i+'ب'*300}])
        original.append({'role':'user','content':'آخرین پرسش'})
        plan = generation.plan_context(original, context_window=2300, requested_output=250)
        self.assertGreater(plan.omitted_count, 0)
        self.assertEqual(len(original), 61)
        self.assertEqual(plan.messages[-1]['content'], 'آخرین پرسش')
        self.assertEqual(plan.messages[0]['role'], 'user')
        self.assertEqual(plan.public()['total_count'], 61)
        self.assertIn('تاریخچه حذف نشده', plan.public()['message'])
        unlimited = generation.plan_context(original, context_window=None)
        self.assertEqual(unlimited.omitted_count, 0)
        self.assertEqual(len(unlimited.messages), 61)

    def test_last_turn_never_silently_cropped(self):
        with self.assertRaisesRegex(generation.ContextError, 'آخرین پیام'):
            generation.plan_context([{'role':'user','content':'متن'*30000}], context_window=1500)
        with self.assertRaisesRegex(generation.ContextError, 'پنجره'):
            generation.plan_context([{'role':'user','content':'سلام'}], context_window=1000, requested_output=950)

    def test_continuation_is_triggered_only_by_reported_limit(self):
        self.assertTrue(generation.is_length_finish('length'))
        self.assertTrue(generation.is_length_finish('max_output_tokens'))
        self.assertFalse(generation.is_length_finish(None))
        self.assertFalse(generation.is_length_finish('stop'))
        self.assertFalse(generation.is_length_finish('content_filter'))
        self.assertIn('continue', generation.continue_prompt().lower())


if __name__ == '__main__':
    unittest.main()
