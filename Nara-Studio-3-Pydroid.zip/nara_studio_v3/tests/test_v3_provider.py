import http.server
import json
import sys
import threading
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import core
import custom_provider


class FakeAI(http.server.BaseHTTPRequestHandler):
    captured = []
    def log_message(self,*args):
        pass
    def do_GET(self):
        body = json.dumps({'data':[{'id':'my-local-model'}]}).encode()
        self.send_response(200);self.send_header('Content-Length',str(len(body)))
        self.end_headers();self.wfile.write(body)
    def do_POST(self):
        data = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        FakeAI.captured.append((self.path,self.headers.get('Authorization'),data))
        body = json.dumps({'choices':[{'message':{'content':'MOCK OK'},'finish_reason':'stop'}]}).encode()
        self.send_response(200);self.send_header('Content-Length',str(len(body)))
        self.end_headers();self.wfile.write(body)


class CustomProviderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = http.server.ThreadingHTTPServer(('127.0.0.1',0),FakeAI)
        cls.thread = threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
        cls.config={'base_url':'http://127.0.0.1:%s/v1'%cls.server.server_port,
                    'options':{'allow_local':True,'no_auth':True}}
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join(timeout=3)

    def test_opt_in_local_models_and_chat(self):
        model_list=custom_provider.models(self.config,'')
        self.assertEqual(model_list[0]['id'],'my-local-model')
        _,payload=core.chat_payload('custom','chat','my-local-model',
                                    [{'role':'user','content':'Hi'}],max_tokens='auto')
        with custom_provider.request(self.config,'','chat/completions',payload) as response:
            result=json.load(response)
        self.assertEqual(core.final_answer('chat',result)['text'],'MOCK OK')
        self.assertIsNone(FakeAI.captured[-1][1])
        self.assertEqual(FakeAI.captured[-1][0],'/v1/chat/completions')

    def test_private_urls_and_redirects_are_refused(self):
        for url in ('http://10.0.0.1/v1','http://127.0.0.1:1234/v1',
                    'https://example.com@127.0.0.1/v1','ftp://example.com/v1',
                    'https://example.com/v1?key=secret','https://example.com/%2e%2e/v1'):
            with self.assertRaises(core.RemoteError,msg=url):
                custom_provider.validate_base_url(url)
        self.assertEqual(custom_provider.validate_base_url('https://api.example.com/v1'),
                         'https://api.example.com/v1')
        with self.assertRaises(core.RemoteError):
            custom_provider.request(self.config,'','metadata')
        with self.assertRaises(core.RemoteError):
            custom_provider.NoRedirect().redirect_request(None,None,302,'','',
                                                        'https://evil.example/collect')


if __name__=='__main__':
    unittest.main()
