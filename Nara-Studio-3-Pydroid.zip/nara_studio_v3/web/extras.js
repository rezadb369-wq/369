/* Model evidence, manual local tools, optional media and raw API laboratory. */
'use strict';
function renderCatalog(){const provider=$('catalogProvider').value,box=$('catalogList');box.replaceChildren();
 const all=(state.catalog[provider]||[]).filter(m=>m.enabled!==false);if(!state.providers[provider]){
  const panel=el('div','panel');panel.append(el('h2','','ابتدا سرویس را وصل کنید'),el('p','','از تنظیمات، کلید Bynara/Atria یا آدرس سرویس دلخواه را وارد کنید. کلید ذخیره نمی‌شود.'));
  const btn=el('button','btn primary','باز کردن تنظیمات');btn.onclick=openSettings;panel.append(btn);box.append(panel);return}
 const query=$('catalogSearch').value.trim().toLowerCase(),filter=$('catalogFilter').value;
 let items=all.filter(m=>String(m.id+' '+(m.name||'')).toLowerCase().includes(query));
 if(filter==='recommended')items=items.filter(m=>m.historically_tested||m.tested_now||m.payg_enabled===false||m.output_idr_per_1m===0||provider.startsWith('custom:')||provider==='atria');
 if(filter==='tested')items=items.filter(m=>m.historically_tested||m.tested_now);
 if(filter==='vision')items=items.filter(m=>m.vision);
 items.sort(sortModels);
 $('catalogLegend').textContent=items.length+' مدل از '+all.length+' مدل متنی فهرست‌شده · «تاریخی» آزمون قبلی است، نه کلید فعلی. هر درخواست آزمون ممکن است هزینه داشته باشد.';
 if(!items.length){box.append(el('div','panel','با این فیلتر مدلی نیست؛ برای دیدن تمام مدل‌های فهرست، «تمام مدل‌ها» را انتخاب کنید.'));return}
 for(const model of items){const card=el('article','model-card');const title=el('h3','',model.id);card.append(title);
 const badges=el('div','badge-row');function badge(text,cls=''){badges.append(el('span','badge '+cls,text))}
 if(model.tested_now)badge('پاسخ همین جلسه','good');else if(model.historically_tested)badge('پاسخ در آزمون قبلی','good');else badge('فقط فهرست شده','warn');
 if(model.payg_enabled===false||model.output_idr_per_1m===0)badge('قیمت توکنی صفر در فهرست؛ سهمیه ممکن است');
 if(model.vision_verified)badge('بینایی همین جلسه','good');else if(model.vision_historically_tested)badge('بینایی تاریخی');
 else if(model.vision)badge('مدل دارای تصویر؛ آزموده‌نشده');
 card.append(badges);
 let price='قیمت یا ظرفیت اعلام نشده';if(Number.isFinite(Number(model.output_idr_per_1m))&&model.output_idr_per_1m!==null&&model.output_idr_per_1m!==undefined)
  price='ورودی Rp '+(model.input_idr_per_1m??'?')+' / خروجی Rp '+model.output_idr_per_1m+' در ۱M توکن';
 card.append(el('p','model-descr','زمینه: '+(model.context_window?Number(model.context_window).toLocaleString('fa-IR'):'نامعلوم')+' توکن · '+price));
 if(model.check?.error)card.append(el('p','model-descr','آخرین آزمون: '+model.check.error));
 const actions=el('div','action-row'),use=el('button','btn secondary','انتخاب برای گفتگو');use.type='button';use.onclick=()=>chooseCatalogModel(provider,model.id);actions.append(use);
 const join=el('button','btn quiet','عضو گروه');join.type='button';join.onclick=()=>joinCatalogRoom(provider,model.id);actions.append(join);
 const test=el('button','btn quiet','آزمون پاسخ');test.type='button';test.onclick=()=>probeCatalogModel(provider,model.id);actions.append(test);
 if(provider==='bynara'&&model.vision){const vision=el('button','btn quiet','آزمون عکس');vision.type='button';vision.onclick=()=>probeCatalogVision(model.id);actions.append(vision)}
 card.append(actions);box.append(card)}
}
async function chooseCatalogModel(provider,id){try{if(!state.currentChat)await newChat();go('chat');$('chatProvider').value=provider;fillModels('chatProvider','chatModel',id);$('chatOptions').open=true;
 await saveChatOptions();toast('مدل این گفتگو تغییر کرد؛ قبل از ارسال، قیمت و پشتیبانی آن را بررسی کنید.');}catch(error){showError(error,'انتخاب مدل')}}
function joinCatalogRoom(provider,id){go('room');if(state.roomMembers.some(m=>m.provider===provider&&m.model===id)){toast('این مدل در اعضای اتاق هست.');return}
 if(state.roomMembers.length>=8){toast('در هر نوبت تا ۸ عضو قابل انتخاب است.',true);return}state.roomMembers.push({provider,model:id,api:'chat',role:''});renderRoomMembers();$('roomOptions').open=true;toast('مدل به اعضای اتاق افزوده شد.')}
async function refreshCatalog(){const provider=$('catalogProvider').value;if(!state.providers[provider]){toast('ابتدا سرویس را وصل کنید.',true);return}
 try{const data=await requestJSON('/api/refresh-models',{provider});state.catalog=data.catalog;fillProviders();renderCatalog();toast('فهرست مدل‌ها تازه شد؛ فهرست شدن اثبات پاسخ‌دهی نیست.')}catch(error){showError(error,'تازه‌سازی مدل‌ها')}}
async function probeCatalogModel(provider,id){if(!await confirmAction({title:'آزمون عملی مدل',text:'یک درخواست متنی واقعی به '+displayProvider(provider)+' / '+id+' فرستاده می‌شود و ممکن است اعتبار مصرف کند. با موجودی رایگان فقط اگر مطمئنید تأیید کنید.',button:'اجازهٔ آزمون'}))return;
 try{const data=await requestJSON('/api/probe-model',{provider,id,confirm_cost:true});state.catalog=data.catalog;renderCatalog();toast('وضعیت آزمون '+id+': '+data.result.status+(data.result.preview?' · '+data.result.preview:data.result.error?' · '+data.result.error:''),data.result.status!=='ok');}catch(error){showError(error,'آزمون مدل')}}
async function probeCatalogVision(id){if(!await confirmAction({title:'آزمون واقعی بینایی',text:'یک PNG قرمز کوچک به مدل '+id+' در Bynara فرستاده می‌شود. ممکن است اعتبار مصرف کند و نتیجهٔ مثبت فقط مربوط به همین اتصال است.',button:'اجازهٔ آزمون تصویر'}))return;
 try{const data=await requestJSON('/api/probe-vision',{provider:'bynara',id,confirm_cost:true});state.catalog=data.catalog;renderCatalog();toast(data.result.ok?'مدل با کلید فعلی رنگ تصویر را درست تشخیص داد.':'پاسخ تصویر با این کلید تأیید نشد: '+data.result.answer,!data.result.ok)}catch(error){showError(error,'آزمون تصویر')}}
async function refreshTools(){if(!state.csrf)return;try{const [skills,files]=await Promise.all([requestJSON('/api/skills',{action:'list'}),requestJSON('/api/tools/list',{})]);
 state.skills=skills.skills;renderSkills();renderWorkspace(files.files);}catch(error){showError(error,'ابزارها')}}
function renderSkills(){const list=$('skillList');list.replaceChildren();if(!state.skills?.length)list.append(el('p','field-help','اسکیلی ذخیره نشده است. متن کد را بنویسید و قبل از هر اجرا مرور کنید.'));
 for(const item of state.skills||[]){const row=el('div','list-chip'),pick=el('button','chip-main',item.title+(item.description?' · '+item.description:''));pick.type='button';
 pick.onclick=()=>{state.skillId=item.id;$('skillTitle').value=item.title;$('skillDesc').value=item.description;$('skillCode').value=item.code;toast('کد اسکیل در ویرایشگر بارگذاری شد؛ پیش از اجرا بخوانید.')};
 const del=el('button','chip-remove','حذف');del.type='button';del.onclick=()=>deleteSkill(item);row.append(pick,del);list.append(row)}
}
function clearSkill(){state.skillId=null;$('skillTitle').value='';$('skillDesc').value='';$('skillCode').value=''}
async function saveSkill(){try{const data=await requestJSON('/api/skills',{action:'save',id:state.skillId||undefined,title:$('skillTitle').value,
 description:$('skillDesc').value,code:$('skillCode').value});state.skillId=data.id;state.skills=data.skills;renderSkills();toast('اسکیل ذخیره شد؛ صرف ذخیره‌سازی کدی اجرا نکرده است.')}
 catch(error){showError(error,'ذخیره اسکیل')}}
async function deleteSkill(item){if(!await confirmAction({title:'حذف اسکیل',text:'اسکیل «'+item.title+'» از این دستگاه پاک می‌شود؛ کدی اجرا نمی‌شود.',button:'حذف'}))return;
 try{const data=await requestJSON('/api/skills',{action:'delete',id:item.id});state.skills=data.skills;if(state.skillId===item.id)clearSkill();renderSkills();toast('اسکیل حذف شد.')}catch(error){showError(error,'حذف اسکیل')}}
async function reviewAndExecute(){const code=$('skillCode').value;if(!code.trim()){toast('کدی برای بررسی وارد کنید.',true);return}
 try{const reviewed=await requestJSON('/api/tools/review',{code});if(!reviewed.ok){$('toolOutput').textContent='خطای نحو در خط '+reviewed.line+': '+reviewed.error;return}
 const sure=await confirmAction({title:'تأیید اجرای دستی Python',text:'این کد روی دستگاه شما اجرا می‌شود و sandbox نیست: به فایل‌ها، شبکه و مجوزهای Pydroid دسترسی دارد. خروجی AI به خودی خود هرگز اجرا نمی‌شود.\nSHA-256: '+reviewed.sha256+'\nکل کد نمایش‌داده‌شده را بخوانید؛ برای اجرا «اجرا» را تایپ کنید.',code:reviewed.code,phrase:'اجرا',button:'اجرای کدِ مرورشده'});
 if(!sure)return;$('toolOutput').textContent='در حال اجرای کد تأییدشده…';
 const response=await requestJSON('/api/tools/execute',{nonce:reviewed.nonce,confirm_run:true,timeout:25});const out=response.execution;
 $('toolOutput').textContent=(out.stdout||'(بدون خروجی)')+'\n\n--- پایان ---\nکد خروج: '+out.exit_code+' · زمان: '+out.elapsed+' ثانیه'+(out.timed_out?' · مهلت پایان یافت':'')+(out.truncated?' · خروجی نمایش کوتاه شده':'')+'\n'+out.warning;
 toast('اجرای دستی پایان یافت.');
 }catch(error){showError(error,'اجرای دستی');$('toolOutput').textContent='خطا: '+error.message}}
function renderWorkspace(files){const list=$('workspaceList');list.replaceChildren();if(!files?.length)list.append(el('p','field-help','فایلی در پوشهٔ اختصاصی نیست.'));
 for(const file of files||[]){const row=el('div','list-chip');const button=el('button','chip-main',file.path+' · '+file.size+' بایت'+(file.kind!=='file'?' · مسدود':''));button.type='button';
 button.onclick=()=>{if(file.kind==='file'){$('workFileName').value=file.path;readWorkspace()}};row.append(button);list.append(row)}}
async function readWorkspace(){try{const data=await requestJSON('/api/tools/read',{name:$('workFileName').value});$('workFileText').value=data.text;toast('متن فایل از پوشهٔ اختصاصی خوانده شد.')}catch(error){showError(error,'خواندن فایل')}}
async function saveWorkspace(){const name=$('workFileName').value.trim();if(!name){toast('نام نسبی فایل را وارد کنید.',true);return}
 if(!await confirmAction({title:'تأیید ذخیرهٔ فایل',text:'متن فعلی در پوشهٔ اختصاصی ابزار روی دستگاه ذخیره می‌شود. اگر فایل هم‌نام باشد بازنویسی می‌شود.\nمسیر: '+name,phrase:name,button:'ذخیره / بازنویسی'}))return;
 try{const data=await requestJSON('/api/tools/save',{name,text:$('workFileText').value,confirm_write:true});toast('ذخیره شد: '+data.file.path);refreshTools()}catch(error){showError(error,'ذخیره فایل')}}
async function calculate(){try{const data=await requestJSON('/api/tools/calculate',{expression:$('calcExpr').value});$('calcResult').textContent=String(data.result)}catch(error){showError(error,'محاسبه')}}
async function runImage(){if(!state.providers.bynara){toast('ابتدا Bynara را وصل کنید.',true);return}if(!$('imageConsent').checked){toast('برای درخواست رسانه تأیید هزینه لازم است.',true);return}
 try{const body={action:$('imageAction').value,model:$('imageModel').value.trim(),prompt:$('imagePrompt').value.trim(),size:$('imageSize').value,confirm_cost:true};
 if(body.action==='edit'){const file=$('imageFile').files[0];if(!file)throw Error('برای ویرایش دقیقاً یک تصویر انتخاب کنید.');if(file.size>4*1024*1024)throw Error('تصویر ورودی باید زیر ۴ مگابایت باشد.');body.images=[{base64:await readBase64(file)}]}
 $('imageRun').disabled=true;$('imageResult').textContent='در حال دریافت پاسخ واقعی سرویس…';
 const data=await requestJSON('/api/media/image',body);renderImageResult(data.result);toast('پاسخ سرویس تصویر رسید. خروجی را فوراً ذخیره کنید.');
 }catch(error){$('imageResult').textContent='تصویر ساخته نشد: '+error.message;showError(error,'رسانه')}finally{$('imageRun').disabled=false}}
function renderImageResult(result){const container=$('imageResult');container.replaceChildren();const items=Array.isArray(result?.data)?result.data:Array.isArray(result?.images)?result.images:[];
 if(!items.length){container.append(el('pre','result-box',JSON.stringify(result,null,2).slice(0,35000)));return}
 for(const [i,item] of items.entries()){const raw=item.b64_json||item.base64;
  if(raw){const format=raw.startsWith('/9j/')?['image/jpeg','jpg']:raw.startsWith('UklGR')?['image/webp','webp']:raw.startsWith('R0lGOD')?['image/gif','gif']:['image/png','png'];
   const image=el('img');image.alt='تصویر خروجی شمارهٔ '+(i+1);image.src='data:'+format[0]+';base64,'+raw;container.append(image);
   const download=el('button','btn secondary','ذخیره تصویر '+(i+1));download.type='button';download.onclick=()=>{
    try{const bytes=Uint8Array.from(atob(raw),c=>c.charCodeAt(0));downloadFile(new Blob([bytes],{type:format[0]}),'nara-image-'+(i+1)+'.'+format[1],format[0])}
    catch(e){toast('ذخیره تصویر ممکن نشد.',true)}};container.append(download)}
  else if(typeof item.url==='string'){
   let allowed;try{allowed=new URL(item.url).protocol==='https:'}catch(e){allowed=false}
   if(!allowed){container.append(el('p','field-help','آدرس تصویر نامعتبر یا ناامن بود؛ لینک نمایش داده نشد.'));continue}
   const link=el('a','btn secondary','دریافت تصویر '+(i+1));link.href=item.url;link.target='_blank';link.rel='noopener noreferrer';container.append(link)}
  else container.append(el('pre','result-box',JSON.stringify(item,null,2).slice(0,8000)))}
}
async function runVideo(){if(!state.providers.bynara){toast('ابتدا Bynara را وصل کنید.',true);return}if(!$('videoConsent').checked){toast('تأیید هزینهٔ احتمالی ویدئو لازم است.',true);return}
 try{const mode=$('videoMode').value,files=[...$('videoFiles').files];if(mode==='i2v'&&files.length!==1||mode==='r2v'&&(files.length<1||files.length>3)||mode==='t2v'&&files.length)throw Error('تعداد تصاویر با حالت ویدئو سازگار نیست.');
 if(files.some(f=>f.size>4*1024*1024))throw Error('هر تصویر زیر ۴ مگابایت باشد.');
 const images=[];for(const file of files)images.push({base64:await readBase64(file)});
 $('videoRun').disabled=true;$('videoResult').textContent='درخواست در حال ثبت نزد API واقعی…';
 const data=await requestJSON('/api/media/video',{model:$('videoModel').value.trim(),prompt:$('videoPrompt').value.trim(),mode,
 duration:Number($('videoDuration').value),resolution:$('videoResolution').value,ratio:$('videoRatio').value,images,confirm_cost:true});
 renderVideoResult(data.result);const job=data.result.id||data.result.task_id;if(job){state.videoId=job;await reloadJobs();toast('کار ویدئو ثبت شد؛ تا آماده‌شدن وضعیت را تازه کنید.')}else toast('شناسهٔ کار برنگشت؛ پاسخ خام را ببینید.',true);
 }catch(error){$('videoResult').textContent='ویدئو ساخته نشد: '+error.message;showError(error,'ویدئو')}finally{$('videoRun').disabled=false}}
function renderVideoResult(result){const box=$('videoResult');box.replaceChildren();const id=result?.id||result?.task_id||state.videoId;
 box.append(el('p','',id?'شناسه: '+id+' · وضعیت: '+(result.status||'نامعلوم'):'پاسخ بدون شناسهٔ کار'));
 if(result?.error)box.append(el('p','',typeof result.error==='string'?result.error:JSON.stringify(result.error)));
 if(id){const check=el('button','btn quiet','دریافت وضعیت');check.type='button';check.onclick=()=>refreshVideo(id);box.append(check);
 if(['succeeded','completed'].includes(result.status)){const download=el('button','btn primary','دریافت MP4');download.type='button';download.onclick=()=>downloadVideo(id);box.append(download)}}
 if(!id)box.append(el('pre','result-box',JSON.stringify(result,null,2).slice(0,10000)))}
async function reloadJobs(){try{const data=await requestJSON('/api/bootstrap');state.mediaJobs=data.media_jobs||[];renderMediaJobs()}catch(error){showError(error,'فهرست ویدئو')}}
function renderMediaJobs(){const list=$('mediaJobs');list.replaceChildren();if(!state.mediaJobs?.length)list.append(el('p','field-help','هنوز کاری برای ویدئو در این دستگاه ثبت نشده است.'));
 for(const item of state.mediaJobs||[]){const row=el('div','list-chip');row.append(el('span','',item.model+' · '+item.status+' · '+item.id.slice(0,14)));
 const check=el('button','btn quiet','وضعیت');check.type='button';check.onclick=()=>refreshVideo(item.id);row.append(check);
 if(['succeeded','completed'].includes(item.status)){const download=el('button','btn secondary','MP4');download.type='button';download.onclick=()=>downloadVideo(item.id);row.append(download)}list.append(row)}}
async function refreshVideo(id){try{const data=await requestJSON('/api/media/video-status',{id});state.videoId=id;renderVideoResult({...data.result,id});await reloadJobs();toast('وضعیت کار تازه شد.')}catch(error){showError(error,'وضعیت ویدئو')}}
async function downloadVideo(id){try{const response=await fetch('/api/video/download/'+encodeURIComponent(id),{credentials:'same-origin',cache:'no-store',headers:{'X-Local-CSRF':state.csrf}});
 if(!response.ok){let data;try{data=await response.json()}catch(e){}throw Error(data?.error||'دریافت MP4 ناموفق بود.')}
 downloadFile(await response.blob(),'nara-video-'+id+'.mp4','video/mp4');toast('فایل ویدئو دریافت شد.');
 }catch(error){showError(error,'دریافت ویدئو')}}
function labExamples(){const provider=$('labProvider').value,endpoint=$('labEndpoint').value;
 for(const option of $('labEndpoint').options)option.disabled=provider!=='bynara'&&['embeddings','rerank'].includes(option.value);
 if(provider!=='bynara'&&['embeddings','rerank'].includes(endpoint)){$('labEndpoint').value='models';return labExamples()}
 const model=provider==='atria'?'Atria-Dawn-Preview':'nemotron-3-ultra-free';const examples={chat:{model,messages:[{role:'user',content:'سلام، دقیق جواب بده.'}]},
 messages:{model,max_tokens:256,messages:[{role:'user',content:'سلام'}]},
 responses:{model,input:provider==='atria'?'سلام':[{role:'user',content:[{type:'input_text',text:'سلام'}]}]},
 embeddings:{model:'text-embedding-3-small',input:'عبارت نمونه'},
 rerank:{model:'rerank-v3',query:'هزینهٔ API',documents:['راهنمای قیمت','راهنمای نصب'],top_n:2}};
 $('labBody').disabled=endpoint==='models';$('labBody').value=endpoint==='models'?'':JSON.stringify(examples[endpoint],null,2);
 $('labConsent').disabled=endpoint==='models';if(endpoint==='models')$('labConsent').checked=false;
}
async function runLab(){const provider=$('labProvider').value,endpoint=$('labEndpoint').value;
 if(!state.providers[provider]){openSettings();toast('سرویس '+provider+' وصل نیست.',true);return}
 if(endpoint!=='models'&&!$('labConsent').checked){toast('درخواست خام به تأیید هزینه نیاز دارد.',true);return}
 let body=null;try{if(endpoint!=='models')body=JSON.parse($('labBody').value)}catch(e){toast('بدنه JSON معتبر نیست.',true);return}
 try{$('labRun').disabled=true;$('labOutput').textContent='در حال دریافت پاسخ API…';
 const data=await requestJSON('/api/raw',{provider,endpoint,body,confirm_cost:endpoint==='models'?false:true});
 state.rawJson=JSON.stringify(data.result,null,2);$('labOutput').textContent=state.rawJson.length>200000?state.rawJson.slice(0,200000)+'\n… نمایش کوتاه شد؛ فایل JSON کامل را دانلود کنید.':state.rawJson;
 $('labDownload').disabled=false;toast('پاسخ API دریافت شد · HTTP '+data.upstream_status);
 }catch(error){$('labOutput').textContent='خطا: '+error.message;showError(error,'API خام')}finally{$('labRun').disabled=false}}
function wireExtras(){$('catalogProvider').onchange=renderCatalog;$('catalogSearch').oninput=renderCatalog;$('catalogFilter').onchange=renderCatalog;$('catalogRefresh').onclick=refreshCatalog;
 $('skillSave').onclick=saveSkill;$('skillClear').onclick=clearSkill;$('skillReview').onclick=reviewAndExecute;
 $('workRead').onclick=readWorkspace;$('workSave').onclick=saveWorkspace;$('workRefresh').onclick=refreshTools;$('calcRun').onclick=calculate;
 $('imageModel').value='agnes-image-2.0-flash';$('imageAction').onchange=()=>$('imageFileWrap').classList.toggle('hidden',$('imageAction').value!=='edit');$('imageRun').onclick=runImage;
 $('videoMode').onchange=()=>$('videoFileWrap').classList.toggle('hidden',$('videoMode').value==='t2v');$('videoRun').onclick=runVideo;$('jobsRefresh').onclick=reloadJobs;
 $('labProvider').onchange=labExamples;$('labEndpoint').onchange=labExamples;$('labRun').onclick=runLab;
 $('labDownload').onclick=()=>state.rawJson&&downloadFile(state.rawJson,'nara-api-result.json','application/json;charset=utf-8');labExamples();}
