/* Nara Studio 3 — shared local UI state, persistence and access controls. */
'use strict';
const $=id=>document.getElementById(id);
const state={csrf:'',providers:{},catalog:{},customProviders:[],profiles:[],mediaJobs:[],history:[],historyTotal:0,historyOffset:0,
 currentChat:null,currentRoom:null,chatConvo:null,roomConvo:null,view:'chat',active:new Map(),sending:new Set(),
 chatAttachments:[],roomAttachments:[],roomMembers:[],customId:null,profileId:null,skillId:null,rawJson:'',videoId:null};
const el=(tag,cls='',text)=>{const node=document.createElement(tag);if(cls)node.className=cls;if(text!==undefined)node.textContent=String(text);return node};
const fmtTime=timestamp=>{try{return new Date(timestamp*1000).toLocaleString('fa-IR',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})}catch(e){return ''}};
function toast(message,isError=false){const box=el('div','toast'+(isError?' error':''),message);$('toasts').append(box);setTimeout(()=>box.remove(),6500)}
function showError(error,where='درخواست'){toast(where+': '+(error?.message||String(error)),true)}
async function requestJSON(path,payload){const config={credentials:'same-origin',cache:'no-store',headers:{}};
 if(state.csrf)config.headers['X-Local-CSRF']=state.csrf;
 if(payload!==undefined){config.method='POST';config.headers['Content-Type']='application/json';config.body=JSON.stringify(payload)}
 const response=await fetch(path,config);let data;
 try{data=await response.json()}catch(e){throw Error('پاسخ سرور قابل خواندن نیست (HTTP '+response.status+').')}
 if(!response.ok)throw Error(data?.error||'خطای HTTP '+response.status);
 return data;
}
async function requestStream(path,payload,onEvent){const response=await fetch(path,{method:'POST',credentials:'same-origin',cache:'no-store',
 headers:{'Content-Type':'application/json','X-Local-CSRF':state.csrf},body:JSON.stringify(payload)});
 if(!response.ok){let data;try{data=await response.json()}catch(e){}throw Error(data?.error||'خطای HTTP '+response.status)}
 if(!response.body)throw Error('مرورگر پخش تدریجی پاسخ را پشتیبانی نمی‌کند.');
 const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='',last=null;
 try{while(true){const {done,value}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});let split;
     while((split=buffer.indexOf('\n'))!==-1){const line=buffer.slice(0,split).trim();buffer=buffer.slice(split+1);if(!line)continue;
       let event;try{event=JSON.parse(line)}catch(e){continue}last=event;onEvent(event)}}
   buffer+=decoder.decode();if(buffer.trim()){try{last=JSON.parse(buffer.trim());onEvent(last)}catch(e){}}
 }finally{reader.releaseLock()}
 if(!last||!['done','room_done','audit_done'].includes(last.type))throw Error('جریان پاسخ بدون پایان مشخص قطع شد؛ تاریخچه را تازه کنید.');
 return last;
}
function setTheme(value){if(!['light','dark','system'].includes(value))value='light';document.documentElement.dataset.theme=value;$('themeSelect').value=value;try{localStorage.setItem('nara-theme-v3',value)}catch(e){}}
function setDensity(value){if(!['comfortable','compact'].includes(value))value='comfortable';document.documentElement.dataset.density=value;$('densitySelect').value=value;try{localStorage.setItem('nara-density-v3',value)}catch(e){}}
function setFontScale(value){if(!['1','1.12','1.25','1.38'].includes(String(value)))value='1';
 $('fontScaleSelect').value=String(value);document.documentElement.style.setProperty('--message-font-size',(13*Number(value)).toFixed(2)+'px');
 document.documentElement.style.setProperty('--composer-font-size',(14*Number(value)).toFixed(2)+'px');
 try{localStorage.setItem('nara-font-v3',String(value))}catch(e){}}
function setReadingWidth(value){if(!['780px','620px','1040px'].includes(value))value='780px';
 $('readingWidthSelect').value=value;document.documentElement.style.setProperty('--reading-width',value);
 try{localStorage.setItem('nara-width-v3',value)}catch(e){}}
function setAccent(value){if(!['blue','teal','purple'].includes(value))value='blue';
 $('accentSelect').value=value;document.documentElement.dataset.accent=value;
 try{localStorage.setItem('nara-accent-v3',value)}catch(e){}}
function sidebar(open){$('sidebar').classList.toggle('open',!!open);$('sidebarShade').classList.toggle('hidden',!open);$('menuButton').setAttribute('aria-expanded',String(!!open))}
function go(view){if(!['chat','room','catalog','tools','media','lab','help'].includes(view))return;
 state.view=view;document.querySelectorAll('.view').forEach(node=>node.classList.toggle('active',node.id==='view-'+view));
 document.querySelectorAll('[data-view]').forEach(node=>{node.classList.toggle('active',node.dataset.view===view);if(node.dataset.view===view)node.setAttribute('aria-current','page');else node.removeAttribute('aria-current')});
 sidebar(false);$('content').scrollTop=0;renderHistory();
 if(view==='catalog')renderCatalog();if(view==='tools')refreshTools();if(view==='media')renderMediaJobs();
 if(view==='chat')updateChatControls();if(view==='room')updateRoomControls();
}
function openSettings(){$('settingsDialog').showModal();renderCustomProviders();renderProfiles()}
function confirmAction({title='تأیید عملیات',text='',code='',phrase='',button='تأیید'}={}){
 return new Promise(resolve=>{const dlg=$('confirmDialog');$('confirmHeading').textContent=title;$('confirmText').textContent=text;
  $('confirmCode').textContent=code;$('confirmCode').classList.toggle('hidden',!code);
  $('confirmInputWrap').classList.toggle('hidden',!phrase);$('confirmInput').value='';$('confirmInput').placeholder=phrase;
  $('confirmYes').textContent=button;
  let settled=false;
  function end(ok){if(settled)return;settled=true;dlg.removeEventListener('cancel',cancel);$('confirmNo').removeEventListener('click',no);$('confirmYes').removeEventListener('click',yes);dlg.close();resolve(ok)}
  const cancel=()=>end(false),no=()=>end(false),yes=()=>{if(phrase&&$('confirmInput').value.trim()!==phrase){toast('عبارت تأیید دقیقاً مطابق خواسته نیست.',true);$('confirmInput').focus();return}end(true)};
  dlg.addEventListener('cancel',cancel);$('confirmNo').addEventListener('click',no);$('confirmYes').addEventListener('click',yes);dlg.showModal();if(phrase)$('confirmInput').focus();else $('confirmNo').focus();
 });
}
function downloadFile(blob,name,type='application/octet-stream'){const value=blob instanceof Blob?blob:new Blob([blob],{type});const url=URL.createObjectURL(value);const a=el('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),90000)}
function displayProvider(provider){if(provider==='bynara')return 'Bynara';if(provider==='atria')return 'Atria';return state.customProviders.find(p=>'custom:'+p.id===provider)?.label||provider}
function friendlySpeaker(speaker){if(speaker==='moderator')return 'داور';
 for(const p of state.customProviders){const prefix='custom:'+p.id+':';if(speaker.startsWith(prefix))return p.label+' · '+speaker.slice(prefix.length)}
 if(speaker.startsWith('bynara:'))return 'Bynara · '+speaker.slice(7);
 if(speaker.startsWith('atria:'))return 'Atria · '+speaker.slice(6);
 return speaker}
function sortModels(a,b){const score=m=>{const cost=Number(m.output_idr_per_1m);return (m.tested_now?0:m.historically_tested?20:100)+(m.payg_enabled===false?0:(Number.isFinite(cost)&&cost===0?2:40))+(Number.isFinite(cost)?Math.min(cost/1000,30):15)};
 return score(a)-score(b)||String(a.id).localeCompare(String(b.id))}
function modelLabel(m){const tag=m.tested_now?'✓ همین جلسه':m.historically_tested?'✓ آزمون تاریخی':
 m.check?.status==='empty'?'⚠ پاسخ خالی':m.check?.status==='error'?'⚠ خطای آزمون':'فقط فهرست‌شده';
 return m.id+' · '+tag}
function fillProviders(){const ids=['bynara','atria',...state.customProviders.map(p=>'custom:'+p.id)];
 for(const select of document.querySelectorAll('select.provider-select')){const old=select.value;select.replaceChildren();for(const id of ids){const opt=el('option','',displayProvider(id)+(state.providers[id]?' · وصل':' · قطع'));opt.value=id;select.append(opt)}select.value=ids.includes(old)?old:ids.find(i=>state.providers[i])||'bynara'}
 fillModels('chatProvider','chatModel');fillModels('memberProvider','memberModel');$('catalogProvider').value=ids.includes($('catalogProvider').value)?$('catalogProvider').value:'bynara';renderStatus();
}
function fillModels(providerId,modelId,selected=''){const selector=$(providerId),select=$(modelId);const wanted=selected||select.value;
 select.replaceChildren();const items=(state.catalog[selector.value]||[]).filter(m=>m.enabled!==false).sort(sortModels);
 if(!items.length){const opt=el('option','',state.providers[selector.value]?'مدل چت یافت نشد':'ابتدا سرویس را وصل کنید');opt.value='';select.append(opt);select.disabled=true;return}
 select.disabled=false;for(const m of items){const opt=el('option','',modelLabel(m));opt.value=m.id;select.append(opt)}
 const proposed=items.find(m=>m.id===wanted)?.id||items.find(m=>m.id==='nemotron-3-ultra-free')?.id||items[0].id;select.value=proposed;
 if(providerId==='chatProvider')updateChatModelNote();
}
function fillProfiles(){for(const id of ['chatProfile','roomProfile']){const select=$(id),old=select.value;select.replaceChildren();const none=el('option','','بدون پروفایل');none.value='';select.append(none);
  for(const p of state.profiles){const opt=el('option','',p.title);opt.value=p.id;select.append(opt)}select.value=state.profiles.some(p=>p.id===old)?old:''}}
function updateChatModelNote(){const provider=$('chatProvider').value,id=$('chatModel').value;const model=(state.catalog[provider]||[]).find(m=>m.id===id);
 let message='مدل انتخاب نشده است. سرویس را وصل کنید.';
 if(model){const cost=Number(model.output_idr_per_1m),hasCost=model.output_idr_per_1m!==null&&model.output_idr_per_1m!==undefined;
 const price=hasCost&&Number.isFinite(cost)?(' · خروجی تقریبی فهرست: Rp '+cost+'/۱M توکن'):' · قیمت نامعلوم';
 message=(model.tested_now?'پاسخ متنی با کلید این جلسه آزموده شده.':model.historically_tested?'قبلاً با درخواست واقعی پاسخ داده؛ کلید فعلی جداگانه آزموده نشده.':'فقط در فهرست؛ هنوز پاسخ متنی برای این اتصال اثبات نشده.')+
  (model.vision_verified?' · بینایی در این جلسه آزموده شده.':model.vision_historically_tested?' · تصویر فقط در ارزیابی تاریخی جواب داده.':'')+price;
 }$('chatModelNote').textContent=message;
}
function renderStatus(){const connected=Object.keys(state.providers).filter(p=>state.providers[p]);
 $('connectionPill').textContent=connected.length?'● '+connected.map(displayProvider).join(' + '):'● بدون اتصال';$('connectionPill').classList.toggle('connected',!!connected.length);
 for(const id of ['bynara','atria'])$(id+'Status').textContent=state.providers[id]?'وصل · کلید در RAM':'وصل نیست';
}
async function bootstrap(){try{const data=await requestJSON('/api/bootstrap');state.csrf=data.csrf;state.providers=data.providers||{};state.catalog=data.catalog||{};
 state.customProviders=data.custom_providers||[];state.profiles=data.profiles||[];state.mediaJobs=data.media_jobs||[];
 $('dataPath').textContent=data.data_local||'—';$('workspacePath').textContent=data.workspace_local||'—';
 state.history=data.conversations||[];state.historyTotal=data.conversation_total||0;state.historyOffset=state.history.length;fillProviders();fillProfiles();renderHistory();renderCustomProviders();renderProfiles();renderMediaJobs();
 const first=state.history.find(c=>c.kind==='chat'&&!c.archived);if(first)await openConversation(first.id);
 else go('chat');
 }catch(error){showError(error,'راه‌اندازی');$('historyList').textContent='سرور در دسترس نیست. مطمئن شوید app.py در Pydroid اجرا شده است.'}}
async function refreshHistory(reset=true){if(!state.csrf)return;try{const params=new URLSearchParams({limit:'40',offset:String(reset?0:state.historyOffset),q:$('historySearch').value,
 kind:$('historyKind').value,archived:$('historyArchived').value});const data=await requestJSON('/api/conversations?'+params);
 if(reset){state.history=data.conversations;state.historyOffset=data.conversations.length}else{
  const known=new Set(state.history.map(c=>c.id));state.history.push(...data.conversations.filter(c=>!known.has(c.id)));state.historyOffset+=data.conversations.length}
 state.historyTotal=data.total;renderHistory();
 }catch(error){showError(error,'فهرست گفتگوها')}}
function renderHistory(){const list=$('historyList');list.replaceChildren();$('conversationCount').textContent=String(state.historyTotal);
 if(!state.history.length)list.append(el('p','empty-mini','گفتگویی در این فیلتر پیدا نشد. ساخت گفتگوی تازه، قبلی‌ها را حذف نمی‌کند.'));
 for(const convo of state.history){const selected=convo.id===(convo.kind==='chat'?state.currentChat:state.currentRoom)&&
    state.view===(convo.kind==='chat'?'chat':'room');const row=el('button','history-row'+(selected?' active':''));row.type='button';row.dataset.id=convo.id;
 const icon=el('span','history-icon',convo.kind==='chat'?'✦':convo.kind==='group'?'◇':'≡');
 const body=el('span','history-body');body.append(el('span','history-title',convo.title));
 body.append(el('span','history-desc',[(convo.folder||''),convo.kind==='chat'?'گفتگو':convo.kind==='group'?'گروه':'مقایسه',String(convo.message_count||0)+' پیام',fmtTime(convo.updated_at)].filter(Boolean).join(' · ')));
 row.append(icon,body);if(convo.pinned)row.append(el('span','history-pin','★'));if(state.active.has(convo.id))row.append(el('span','history-running'));
 row.addEventListener('click',()=>openConversation(convo.id));list.append(row)}
 $('historyMore').hidden=state.historyOffset>=state.historyTotal;$('historyMeta').textContent=state.historyTotal+' گفتگو · همه در SQLite محلی';
}
async function openConversation(id){try{const data=await requestJSON('/api/conversation?id='+encodeURIComponent(id)+'&limit=120');const convo=data.conversation;
 if(convo.kind==='chat'){state.currentChat=id;state.chatConvo=convo;go('chat');fillChatConversation(convo)}
 else{state.currentRoom=id;state.roomConvo=convo;go('room');fillRoomConversation(convo)}
 renderHistory();sidebar(false);
 }catch(error){showError(error,'بازکردن گفتگو')}}
async function newChat(){try{const config={provider:$('chatProvider').value||'bynara',model:$('chatModel').value||'',api:$('chatApi').value||'chat'};
 const data=await requestJSON('/api/conversations/create',{kind:'chat',title:'گفتگوی تازه',config});state.currentChat=data.conversation.id;state.chatConvo=data.conversation;state.chatAttachments=[];
 go('chat');fillChatConversation(data.conversation);$('chatPrompt').value='';$('chatPrompt').focus();await refreshHistory();toast('گفتگوی مستقل ساخته شد؛ گفتگوهای قبلی حفظ شدند.');
 }catch(error){showError(error,'ساخت گفتگو')}}
function newRoom(){state.currentRoom=null;state.roomConvo=null;state.roomMembers=[];state.roomAttachments=[];
 $('roomHeading').textContent='اتاق تازه';$('roomSubhead').textContent='اعضا و نقش‌ها را انتخاب کنید و یک نوبت تازه آغاز کنید.';
 $('roomMode').value='collaborate';$('roomMaxTokens').value='auto';$('roomEffort').value='medium';$('roomSynthesis').checked=true;$('roomStream').checked=true;$('roomHistoricalVision').checked=false;$('roomSystem').value='';$('roomPrompt').value='';$('roomProfile').value='';
 renderRoomMembers();renderTranscript(null,'roomMessages');renderAttachments('room');go('room');$('roomOptions').open=true;$('memberProvider').focus();toast('اتاق تازه آماده است؛ اتاق‌های قبلی حفظ شدند.');
}
async function patchConversation(id,changes){const data=await requestJSON('/api/conversations/update',{id,changes});return data.conversation}
function manageChat(){const convo=state.view==='room'?state.roomConvo:state.chatConvo;
 if(!convo){toast('ابتدا یک گفتگو/اتاق انتخاب کنید.',true);return}
 state.manageId=convo.id;state.manageKind=convo.kind;$('manageHeading').textContent='مدیریت · '+convo.title;
 $('manageTitle').value=convo.title;$('manageFolder').value=convo.folder||'';
 $('managePinned').checked=!!convo.pinned;$('manageArchived').checked=!!convo.archived;
 $('manageDialog').showModal();}
function closeManage(){$('manageDialog').close()}
async function saveManage(){const id=state.manageId;try{const data=await patchConversation(id,{title:$('manageTitle').value,folder:$('manageFolder').value,
 pinned:$('managePinned').checked,archived:$('manageArchived').checked});closeManage();
 $('historyArchived').value=data.archived?'1':'0';await refreshHistory();
 if(state.currentChat===id||state.currentRoom===id)await openConversation(id);
 toast(data.archived?'گفتگو بایگانی شد؛ حذف نشده است.':'تنظیمات گفتگو ذخیره شد.');
 }catch(error){showError(error,'مدیریت گفتگو')}}
async function deleteManaged(){const id=state.manageId,title=$('manageTitle').value;
 const latest=await requestJSON('/api/conversation?id='+encodeURIComponent(id)+'&limit=1').then(d=>d.conversation).catch(()=>null);
 if(!latest){toast('گفتگو پیدا نشد.',true);return}
 if(!await confirmAction({title:'حذف دائمی و غیرقابل‌بازگشت',text:'همهٔ پیام‌های «'+latest.title+'» از دستگاه حذف می‌شوند.\nبرای نگه‌داشتن تاریخچه، بایگانی یا پشتیبان را انتخاب کنید.',phrase:latest.title,button:'حذف دائمی'}))return;
 try{await requestJSON('/api/conversations/delete',{id,confirm_delete:true,confirm_title:latest.title});closeManage();
 if(state.currentChat===id){state.currentChat=null;state.chatConvo=null;renderTranscript(null,'chatMessages');$('chatHeading').textContent='یک ایده، یک فضای تازه'}
 if(state.currentRoom===id){state.currentRoom=null;state.roomConvo=null;renderTranscript(null,'roomMessages');$('roomHeading').textContent='چند نگاه، یک میز'}
 await refreshHistory();toast('گفتگو با تأیید دقیق شما حذف شد.');
 }catch(error){showError(error,'حذف گفتگو')}}
async function branchManaged(){const id=state.manageId;try{const data=await requestJSON('/api/conversations/clone',{id});closeManage();
 await refreshHistory();await openConversation(data.conversation.id);toast('یک شاخهٔ مستقل ساخته شد؛ اصل گفتگو حفظ شد.');
 }catch(error){showError(error,'شاخه‌سازی')}}
async function exportOne(id){const data=await requestJSON('/api/conversations/export',{id});downloadFile(JSON.stringify(data,null,2),'nara-conversation-'+id.slice(0,9)+'.json','application/json;charset=utf-8')}
async function branchChat(throughId=null){const cid=state.currentChat;if(!cid){toast('گفتگویی برای شاخه‌سازی انتخاب نشده.',true);return}try{
 const data=await requestJSON('/api/conversations/clone',{id:cid,through_id:throughId||undefined});await refreshHistory();await openConversation(data.conversation.id);toast('یک شاخهٔ مستقل ساخته شد؛ اصل گفتگو دست‌نخورده ماند.');
 }catch(error){showError(error,'شاخه‌سازی')}}
async function connectBuiltin(provider){const field=$(provider+'Key'),key=field.value.trim();if(!key){toast('کلید '+provider+' را وارد کنید.',true);return}try{
 const data=await requestJSON('/api/connect',{provider,key});state.providers[provider]=true;state.catalog=data.catalog;fillProviders();renderCatalog();toast('فهرست مدل‌ها دریافت شد. پاسخ‌دهی مدل‌ها در این اتصال هنوز خودکار آزموده نشده است.');
 }catch(error){showError(error,'اتصال '+provider)}finally{field.value=''}}
async function disconnectProvider(provider){try{await requestJSON('/api/disconnect',{provider});state.providers[provider]=false;state.catalog[provider]=[];fillProviders();renderCatalog();toast('اتصال قطع شد؛ کلید از جلسه حذف شد.')}catch(error){showError(error,'قطع اتصال')}}
function renderCustomProviders(){const list=$('customProviderList');list.replaceChildren();if(!state.customProviders.length)list.append(el('p','field-help','هنوز سرویسی تعریف نشده است.'));
 for(const item of state.customProviders){const row=el('div','list-chip');const button=el('button','chip-main',item.label+' · '+item.base_url+(state.providers['custom:'+item.id]?' · وصل':''));button.type='button';button.onclick=()=>selectCustom(item);
 const del=el('button','chip-remove','حذف');del.type='button';del.onclick=()=>deleteCustom(item);row.append(button,del);list.append(row)}
 $('customSelected').textContent=state.customId?'در حال ویرایش/اتصال: '+displayProvider('custom:'+state.customId):'برای اتصال، ابتدا آدرس را ذخیره و از فهرست انتخاب کنید.'}
function selectCustom(item){state.customId=item.id;$('customLabel').value=item.label;$('customUrl').value=item.base_url;
 $('customModels').value=(item.models||[]).join(', ');$('customContext').value=item.options?.context_window||'';
 $('customVision').value=(item.options?.vision_models||[]).join(', ');$('customAllowLocal').checked=!!item.options?.allow_local;$('customNoAuth').checked=!!item.options?.no_auth;
 renderCustomProviders()}
function clearCustom() {state.customId=null;for(const id of ['customLabel','customUrl','customModels','customContext','customVision','customKey'])$(id).value='';$('customAllowLocal').checked=false;$('customNoAuth').checked=false;renderCustomProviders()}
function commaList(value){return value.split(',').map(i=>i.trim()).filter(Boolean)}
async function saveCustom(){try{const options={allow_local:$('customAllowLocal').checked,no_auth:$('customNoAuth').checked,
 context_window:$('customContext').value||null,vision_models:commaList($('customVision').value)};
 const data=await requestJSON('/api/custom-providers',{action:'save',id:state.customId||undefined,label:$('customLabel').value,
 base_url:$('customUrl').value,models:commaList($('customModels').value),options,confirm_local:options.allow_local});
 state.customId=data.id;state.customProviders=data.providers;state.catalog=data.catalog;state.providers['custom:'+data.id]=false;
 fillProviders();renderCustomProviders();toast('آدرس ذخیره شد؛ برای این سرویس یک‌بار «اتصال» بزنید.');
 }catch(error){showError(error,'ذخیره سرویس')}}
async function connectCustom(){if(!state.customId){toast('ابتدا آدرس را ذخیره/انتخاب کنید.',true);return}const provider='custom:'+state.customId,key=$('customKey').value;
 try{const data=await requestJSON('/api/connect',{provider,key});state.providers[provider]=true;state.catalog=data.catalog;fillProviders();renderCustomProviders();
 $('chatProvider').value=provider;fillModels('chatProvider','chatModel');toast('مدل‌های سرویس دلخواه آماده‌اند؛ فهرست‌شدن به معنی پاسخ‌دادن نیست.');
 }catch(error){showError(error,'اتصال سرویس دلخواه')}finally{$('customKey').value=''}}
async function deleteCustom(item){const okay=await confirmAction({title:'حذف آدرس سرویس',text:'آدرس و تنظیم این سرویس حذف می‌شود؛ گفتگوهای قدیمی دست‌نخورده می‌مانند. کلید جلسه نیز فراموش می‌شود.\nنام: '+item.label,phrase:item.label,button:'حذف آدرس'});if(!okay)return;
 try{const data=await requestJSON('/api/custom-providers',{action:'delete',id:item.id});state.customProviders=data.providers;state.catalog=data.catalog;delete state.providers['custom:'+item.id];if(state.customId===item.id)clearCustom();fillProviders();renderCustomProviders();toast('آدرس سرویس حذف شد.')}catch(error){showError(error,'حذف سرویس')}}
function renderProfiles(){const list=$('profileList');list.replaceChildren();if(!state.profiles.length)list.append(el('p','field-help','پروفایلی ذخیره نشده است.'));
 for(const item of state.profiles){const row=el('div','list-chip');const b=el('button','chip-main',item.title);b.type='button';b.onclick=()=>{state.profileId=item.id;$('profileTitle').value=item.title;$('profilePrompt').value=item.system_prompt;$('profileEffort').value=item.options?.effort||'medium';toast('پروفایل برای ویرایش انتخاب شد.')};
 const del=el('button','chip-remove','حذف');del.type='button';del.onclick=()=>deleteProfile(item);row.append(b,del);list.append(row)}}
async function saveProfile(){try{const data=await requestJSON('/api/profiles',{action:'save',id:state.profileId||undefined,title:$('profileTitle').value,system_prompt:$('profilePrompt').value,
 options:{effort:$('profileEffort').value,max_tokens:'auto',integrity_prompt:true}});state.profileId=data.id;state.profiles=data.profiles;fillProfiles();renderProfiles();toast('پروفایل ذخیره شد؛ آن را در تنظیمات گفتگو انتخاب کنید.');
 }catch(error){showError(error,'پروفایل')}}
async function deleteProfile(item){if(!await confirmAction({title:'حذف پروفایل',text:'پروفایل «'+item.title+'» حذف می‌شود؛ متن گفت‌وگوها حذف نمی‌شود.',button:'حذف پروفایل'}))return;
 try{const data=await requestJSON('/api/profiles',{action:'delete',id:item.id});state.profiles=data.profiles;if(state.profileId===item.id)clearProfile();fillProfiles();renderProfiles();toast('پروفایل حذف شد.')}catch(error){showError(error,'حذف پروفایل')}}
function clearProfile(){state.profileId=null;$('profileTitle').value='';$('profilePrompt').value='';$('profileEffort').value='medium'}
async function downloadBackup(){try{const response=await fetch('/api/backup/sqlite',{credentials:'same-origin',cache:'no-store',headers:{'X-Local-CSRF':state.csrf}});
 if(!response.ok){let error;try{error=await response.json()}catch(e){}throw Error(error?.error||'دریافت ناموفق')}
 downloadFile(await response.blob(),'nara-studio-v3.sqlite3','application/vnd.sqlite3');toast('پشتیبان سازگار SQLite دریافت شد.');
 }catch(error){showError(error,'پشتیبان SQLite')}}
async function downloadJSONBackup(){try{const data=await requestJSON('/api/backup/export',{});downloadFile(JSON.stringify(data.bundle),'nara-studio-v3.json','application/json;charset=utf-8');toast('خروجی JSON دریافت شد.')}catch(error){showError(error,'خروجی JSON')}}
async function importJSON(file){if(!file)return;if(file.size>20*1024*1024){toast('فایل JSON بیش از حد بزرگ است؛ نسخهٔ SQLite را برای انتقال حجیم استفاده کنید.',true);return}
 try{const data=JSON.parse(await file.text());if(!await confirmAction({title:'درون‌ریزی گفتگوها',text:'گفتگوهای فایل با شناسهٔ تازه اضافه می‌شوند و موارد فعلی باقی می‌مانند. دستورهای پروفایل، آدرس API و کد ابزارها عمداً خودکار وارد نمی‌شوند.',button:'افزودن گفتگوها'}))return;
 const result=await requestJSON('/api/backup/import',{bundle:data});await refreshHistory();toast(result.imported+' گفتگو وارد شد. '+result.skipped_config);
 }catch(error){showError(error,'درون‌ریزی')}}
function applyProfileDefaults(selectId,effortId,maxId){const p=state.profiles.find(p=>p.id===$(selectId).value);if(!p)return;$(effortId).value=p.options?.effort||'medium';$(maxId).value=p.options?.max_tokens||'auto'}
function wireBase(){document.querySelectorAll('[data-view]').forEach(button=>button.addEventListener('click',()=>go(button.dataset.view)));
 $('settingsButton').onclick=openSettings;$('menuButton').onclick=()=>sidebar(true);$('sidebarShade').onclick=()=>sidebar(false);
 $('newChat').onclick=newChat;$('newRoom').onclick=newRoom;$('roomFresh').onclick=newRoom;
 $('chatOrganize').onclick=manageChat;$('roomManage').onclick=manageChat;$('chatBranch').onclick=()=>branchChat();
 $('manageClose').onclick=closeManage;$('manageSave').onclick=saveManage;$('manageDelete').onclick=deleteManaged;
 $('manageBranch').onclick=branchManaged;$('manageExport').onclick=async()=>{try{await exportOne(state.manageId);toast('گفتگو دانلود شد.')}catch(e){showError(e,'خروجی گفتگو')}};
 $('historyMore').onclick=()=>refreshHistory(false);
 let searchTimer;$('historySearch').oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>refreshHistory(),300)};
 for(const id of ['historyKind','historyArchived'])$(id).onchange=()=>refreshHistory();
 $('bynaraConnect').onclick=()=>connectBuiltin('bynara');$('atriaConnect').onclick=()=>connectBuiltin('atria');
 $('bynaraDisconnect').onclick=()=>disconnectProvider('bynara');$('atriaDisconnect').onclick=()=>disconnectProvider('atria');
 $('customSave').onclick=saveCustom;$('customConnect').onclick=connectCustom;$('customClear').onclick=clearCustom;
 $('profileSave').onclick=saveProfile;$('profileClear').onclick=clearProfile;
 $('themeSelect').onchange=e=>setTheme(e.target.value);$('densitySelect').onchange=e=>setDensity(e.target.value);
 $('fontScaleSelect').onchange=e=>setFontScale(e.target.value);$('readingWidthSelect').onchange=e=>setReadingWidth(e.target.value);
 $('accentSelect').onchange=e=>setAccent(e.target.value);
 $('sqliteBackup').onclick=downloadBackup;$('jsonBackup').onclick=downloadJSONBackup;$('jsonImport').onclick=()=>$('importFile').click();
 $('importFile').onchange=e=>{importJSON(e.target.files[0]);e.target.value=''};
 $('chatProfile').onchange=()=>applyProfileDefaults('chatProfile','chatEffort','chatMaxTokens');
 $('roomProfile').onchange=()=>applyProfileDefaults('roomProfile','roomEffort','roomMaxTokens');
 $('chatProvider').onchange=()=>{fillModels('chatProvider','chatModel');if($('chatProvider').value.startsWith('custom:'))$('chatApi').value='chat'};
 $('chatModel').onchange=updateChatModelNote;$('memberProvider').onchange=()=>fillModels('memberProvider','memberModel');
 $('chatProvider').onfocus=()=>sidebar(false);
 document.querySelectorAll('[data-suggestion]').forEach(node=>node.onclick=()=>{$('chatPrompt').value=node.dataset.suggestion;$('chatPrompt').focus()});
 document.addEventListener('keydown',event=>{if(event.key==='Escape')sidebar(false)});
}
function init(){let theme='light',density='comfortable',font='1',width='780px',accent='blue';
 try{theme=localStorage.getItem('nara-theme-v3')||theme;density=localStorage.getItem('nara-density-v3')||density;
  font=localStorage.getItem('nara-font-v3')||font;width=localStorage.getItem('nara-width-v3')||width;
  accent=localStorage.getItem('nara-accent-v3')||accent}catch(e){}
 setTheme(theme);setDensity(density);setFontScale(font);setReadingWidth(width);setAccent(accent);
 wireBase();wireChat();wireExtras();bootstrap();}
document.addEventListener('DOMContentLoaded',init);
