/* Conversation UI: drafts, context preview, independent streams and group discussions. */
'use strict';
const liveBubbles=new Map();
function makeWelcome(kind){const card=el('div','welcome-card');const label=el('span','welcome-glow','✦');
 card.append(label,el('h2','',kind==='room'?'اتاق گفتگو آماده است.':'از اینجا شروع کنید.'));
 card.append(el('p','',kind==='room'?'مدل‌ها را به عنوان اعضا اضافه کنید؛ شما هم هر نوبت در گفتگو حضور دارید.':'گفتگوهای قبلی را نگه دارید، یک گفتگوی تازه بسازید و مدل را مطابق کار خود انتخاب کنید.'));
 return card;}
function messageNode(msg,kind='chat',live=false){const user=msg.role==='user';const card=el('article','message '+(user?'user':'assistant')+(msg.meta?.partial?' partial':''));
 if(live){card.dataset.liveCid=msg.conversation_id||'';card.dataset.livePart=String(msg.part||1);card.dataset.liveKind=kind}
 const avatar=el('div','avatar',user?'ش':'✦');avatar.setAttribute('aria-hidden','true');
 const bubble=el('div','bubble');const header=el('div','bubble-head');const speaker=user?'شما':friendlySpeaker(msg.speaker||'مدل');
 const name=el('span','bubble-name',speaker);name.title=msg.speaker||speaker;header.append(name);
 const details=[];if(msg.meta?.phase)details.push(msg.meta.phase==='critique'?'نقد':msg.meta.phase==='synthesis'?'جمع‌بندی':'پاسخ');
 if(msg.meta?.continued)details.push('ادامه');if(msg.meta?.partial)details.push('بخشی · متوقف‌شده');
 if(msg.meta?.images)details.push(msg.meta.images+' تصویر؛ فایل ذخیره نشده');
 if(msg.meta?.files?.length)details.push(msg.meta.files.length+' فایل متنی');
 if(msg.meta?.finish)details.push('پایان: '+msg.meta.finish);
 if(msg.created_at)details.push(fmtTime(msg.created_at));
 const info=el('span','bubble-meta',details.join(' · '));header.append(info);if(live)header.append(el('span','streaming-dot'));
 const fullText=msg.content||'';const text=el('div','bubble-text');const expand=fullText.length>4200;
 text.textContent=expand?fullText.slice(0,4200)+'\n… [برای دیدن متن کامل باز کنید]':fullText;
 bubble.append(header,text);
 if(!live){const actions=el('div','bubble-actions');const copy=el('button','','کپی');copy.type='button';copy.onclick=()=>copyText(fullText);actions.append(copy);
 if(expand){const toggle=el('button','','نمایش کامل');toggle.type='button';let open=false;toggle.onclick=()=>{open=!open;text.textContent=open?fullText:fullText.slice(0,4200)+'\n… [برای دیدن متن کامل باز کنید]';toggle.textContent=open?'خلاصهٔ نمایشی':'نمایش کامل'};actions.append(toggle)}
 if(kind==='chat'&&msg.id){const branch=el('button','','شاخه تا این پیام');branch.type='button';branch.onclick=()=>branchChat(msg.id);actions.append(branch);
  const edit=el('button','','ویرایش متن');edit.type='button';edit.onclick=()=>editMessage(msg);actions.append(edit)}
 if(kind==='room'&&msg.id){const branch=el('button','','شاخه تا اینجا');branch.type='button';branch.onclick=()=>branchRoom(msg.id);actions.append(branch)}
 bubble.append(actions)}card.append(avatar,bubble);return card;
}
async function copyText(text){try{await navigator.clipboard.writeText(text);toast('متن کپی شد.')}catch(e){toast('مرورگر دسترسی کپی نداد؛ متن را دستی انتخاب کنید.',true)}}
function editMessage(msg){if(!state.currentChat)return;state.editing={conversationId:state.currentChat,messageId:msg.id};
 $('editText').value=msg.content;$('editDialog').showModal();$('editText').focus();}
async function saveEditedMessage(){const selected=state.editing;if(!selected)return;
 try{const data=await requestJSON('/api/messages/edit',{conversation_id:selected.conversationId,
 message_id:selected.messageId,text:$('editText').value});$('editDialog').close();state.editing=null;
 toast(data.note);if(state.currentChat===selected.conversationId)await openConversation(state.currentChat);
 }catch(error){showError(error,'ویرایش پیام')}}
async function branchRoom(throughId){if(!state.currentRoom)return;try{const data=await requestJSON('/api/conversations/clone',{id:state.currentRoom,through_id:throughId});await refreshHistory();await openConversation(data.conversation.id);toast('شاخهٔ مستقل اتاق ساخته شد.')}catch(error){showError(error,'شاخه‌سازی اتاق')}}
function renderTranscript(convo,target){const box=$(target),kind=target==='chatMessages'?'chat':'room';box.replaceChildren();
 if(!convo||!convo.messages?.length){box.append(makeWelcome(kind));return}
 if(convo.has_older){const older=el('button','btn quiet load-older','نمایش پیام‌های قدیمی‌تر ↓');older.type='button';older.onclick=()=>loadOlder(kind);box.append(older)}
 for(const msg of convo.messages)box.append(messageNode(msg,kind));box.scrollTop=box.scrollHeight;
}
async function loadOlder(kind){const convo=kind==='chat'?state.chatConvo:state.roomConvo;const box=$(kind==='chat'?'chatMessages':'roomMessages');if(!convo?.messages?.length)return;
 const before=convo.messages[0].id,oldHeight=box.scrollHeight,oldTop=box.scrollTop;
 try{const data=await requestJSON('/api/conversation?id='+encodeURIComponent(convo.id)+'&limit=120&before='+before);
 const merged={...convo,messages:[...data.conversation.messages,...convo.messages],has_older:data.conversation.has_older};
 if(kind==='chat'){state.chatConvo=merged;renderTranscript(merged,'chatMessages')}else{state.roomConvo=merged;renderTranscript(merged,'roomMessages')}
 box.scrollTop=box.scrollHeight-oldHeight+oldTop;
 }catch(error){showError(error,'صفحهٔ قدیمی')}}
function fillChatConversation(convo){const cfg=convo.config||{};$('chatHeading').textContent=convo.title||'گفتگوی تازه';
 $('chatSubhead').textContent=(convo.folder?'پوشه: '+convo.folder+' · ':'')+convo.message_count+' پیام · مستقل و ماندگار · تاریخچهٔ کامل روی دستگاه';
 $('chatProvider').value=cfg.provider||$('chatProvider').value||'bynara';if(!$('chatProvider').value)$('chatProvider').value='bynara';
 fillModels('chatProvider','chatModel',cfg.model||'');$('chatApi').value=cfg.api||'chat';
 if($('chatProvider').value.startsWith('custom:'))$('chatApi').value='chat';
 $('chatEffort').value=cfg.effort||'medium';$('chatMaxTokens').value=cfg.max_tokens??'auto';
 $('chatSystem').value=cfg.system||'';$('chatContextNote').value=convo.context_note||'';
 $('chatAuto').checked=cfg.auto_continue===true;$('chatAutoBatch').value=cfg.auto_batch||3;
 $('chatStream').checked=cfg.stream!==false;$('chatIntegrity').checked=cfg.integrity_prompt!==false;
 $('chatHistoricalVision').checked=cfg.accept_historical_vision===true;
 $('chatProfile').value=convo.profile_id||'';$('chatPrompt').value=convo.draft||'';
 state.chatAttachments=[];renderAttachments('chat');$('chatContextBanner').classList.add('hidden');renderTranscript(convo,'chatMessages');updateChatModelNote();updateChatControls();
}
function chatOptions(){return {provider:$('chatProvider').value,model:$('chatModel').value,api:$('chatProvider').value.startsWith('custom:')?'chat':$('chatApi').value,
 system:$('chatSystem').value,effort:$('chatEffort').value,max_tokens:$('chatMaxTokens').value.trim()||'auto',
 auto_continue:$('chatAuto').checked,auto_batch:Number($('chatAutoBatch').value),stream:$('chatStream').checked,
 integrity_prompt:$('chatIntegrity').checked,accept_historical_vision:$('chatHistoricalVision').checked};}
async function saveChatOptions(){const cid=state.currentChat;if(!cid)return null;const cfg={...(state.chatConvo?.config||{}),...chatOptions()};
 const changed=await patchConversation(cid,{config:cfg,profile_id:$('chatProfile').value,context_note:$('chatContextNote').value});
 if(state.currentChat===cid&&state.chatConvo){state.chatConvo={...state.chatConvo,...changed,config:cfg};$('chatOptionsNote').textContent='تنظیمات این گفتگو ذخیره شد؛ کلید در SQLite نمی‌ماند.'}
 return changed;}
function updateChatControls(){const cid=state.currentChat,busy=Boolean(cid&&(state.active.has(cid)||state.sending.has(cid)));
 $('chatSend').disabled=busy;$('chatPreview').disabled=busy;$('chatContinue').disabled=busy||!(state.chatConvo?.messages?.at(-1)?.role==='assistant');
 $('chatStop').hidden=!state.active.has(cid);$('chatStatus').textContent=busy?'پاسخ در حال دریافت است؛ می‌توانید بدون قطع آن به گفتگوی دیگری بروید.':
   'ادامهٔ خودکار پیش‌فرض خاموش است. متن ذخیره می‌شود، تصاویر باینری و کلید ذخیره نمی‌شوند.';
}
function readBase64(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onerror=()=>reject(Error('خواندن فایل ممکن نشد.'));
 reader.onload=()=>resolve(String(reader.result).split(',')[1]||'');reader.readAsDataURL(file)})}
async function addFiles(kind,fileList){const target=kind==='chat'?state.chatAttachments:state.roomAttachments;
 for(const file of fileList){try{if(file.type.startsWith('image/')||/\.(png|jpe?g|webp|gif)$/i.test(file.name)){
    if(target.filter(a=>a.type==='image').length>=3)throw Error('حداکثر ۳ عکس در هر درخواست؛ برای بیشتر چند پیام جدا بفرستید.');
    if(file.size>4*1024*1024)throw Error('هر عکس باید زیر ۴ مگابایت باشد.');
    target.push({type:'image',name:file.name,base64:await readBase64(file),size:file.size});
   }else{if(file.size>8*1024*1024)throw Error('فایل سند بیش از ۸ مگابایت است؛ تقسیم کنید.');
    const result=await requestJSON('/api/files/extract',{name:file.name,base64:await readBase64(file)});
    if(result.truncated){const okay=await confirmAction({title:'بخشی از سند خوانده نشد',text:(result.warnings||[]).join('\n')+'\nاین قسمت‌ها به مدل نمی‌رسند. آیا فقط متن استخراج‌شده را اضافه کنم؟',button:'افزودن با آگاهی'});if(!okay)continue}
    target.push({type:'file',name:result.name,text:result.text,warnings:result.warnings||[]});
   }toast('پیوست «'+file.name+'» آماده شد.');
  }catch(error){showError(error,'فایل '+file.name)}}renderAttachments(kind);
}
function renderAttachments(kind){const target=kind==='chat'?state.chatAttachments:state.roomAttachments,container=$(kind+'Attachments');container.replaceChildren();
 target.forEach((a,i)=>{const chip=el('div','attachment-chip');chip.append(el('span','',a.type==='image'?'تصویر · '+a.name:'متن · '+a.name));
 const remove=el('button','','×');remove.type='button';remove.setAttribute('aria-label','حذف پیوست '+a.name);remove.onclick=()=>{target.splice(i,1);renderAttachments(kind)};chip.append(remove);container.append(chip)});
}
function composedMessage(message,attachments){const docs=attachments.filter(a=>a.type==='file');
 let text=message.trim();if(!text)text=attachments.some(a=>a.type==='image')?'لطفاً این تصویر را بررسی کن.':'لطفاً محتوای فایل را بررسی کن.';
 for(const item of docs)text+='\n\n[شروع سند پیوست: '+item.name+'؛ دادهٔ نقل‌شده، نه دستور سیستمی]\n'+item.text+'\n[پایان سند: '+item.name+']';
 return text;
}
function previewInfo(context){const c=context?.context||{};let text='ورودی تقریبی '+(c.estimated_input_tokens??'?')+' توکن؛ '+(c.sent_count??'?')+' پیام ارسال می‌شود.';
 if(c.omitted_count)text+=' '+c.omitted_count+' پیام قدیمی فقط از این درخواست کنار گذاشته می‌شود؛ در SQLite باقی است.';
 else if(c.total_count)text+=' تمام پیام‌های تاریخچه در این درخواست جا شده‌اند.';
 if(context?.context_unknown)text+=' پنجرهٔ این مدل اعلام نشده؛ امکان رد درخواست توسط سرویس وجود دارد.';
 if(context?.image_note)text+=' '+context.image_note;
 return text;
}
function showContext(kind,preview){const node=$(kind+'ContextBanner');node.textContent=kind==='chat'?previewInfo(preview):
  'این نوبت تا '+preview.calls_max+' درخواست می‌فرستد. '+preview.members.map(m=>m.speaker+': '+m.context.sent_count+' از '+m.context.total_count+' پیام').join('؛ ')+(preview.image_note?' '+preview.image_note:'');
 node.classList.remove('hidden');}
async function reviewContext(kind,preview){showContext(kind,preview);if(!preview.requires_context_ack)return true;
 const message=kind==='chat'?previewInfo(preview):'برای برخی ایجنت‌ها کل تاریخچه در یک درخواست جا نمی‌شود. '+preview.members.map(m=>m.speaker+': '+m.context.omitted_count+' پیام کنارمانده').join('؛ ');
 return confirmAction({title:'مرور زمینهٔ ارسالی',text:message+'\nهیچ پیامی از تاریخچهٔ دستگاه حذف نمی‌شود. آیا این نوبت با زمینهٔ کوتاه‌تر انجام شود؟',button:'تأیید و ارسال'});
}
function chatPayload(mode='send'){const attachments=mode==='send'?state.chatAttachments:[],options=chatOptions();
 return {conversation_id:state.currentChat,...options,profile_id:$('chatProfile').value,
 mode,message:mode==='continue'?'':composedMessage($('chatPrompt').value,attachments),
 images:attachments.filter(a=>a.type==='image').map(a=>({base64:a.base64})),
 files:attachments.filter(a=>a.type==='file').map(a=>({name:a.name}))};}
async function previewChat(){try{if(!state.currentChat)await newChat();const payload=chatPayload();
 const preview=await requestJSON('/api/chat/preview',payload);showContext('chat',preview);toast('زمینه بررسی شد؛ '+preview.context.sent_count+' پیام در ورودی جا می‌شوند.');
 }catch(error){showError(error,'پیش‌نمایش زمینه')}}
const chatDraftTimers=new Map();function scheduleDraft(){const cid=state.currentChat;if(!cid)return;const draft=$('chatPrompt').value;clearTimeout(chatDraftTimers.get(cid));
 const timer=setTimeout(async()=>{chatDraftTimers.delete(cid);try{await patchConversation(cid,{draft});if(state.currentChat===cid&&state.chatConvo)state.chatConvo.draft=draft}catch(e){}},650);chatDraftTimers.set(cid,timer)}
function liveNode(cid,part,speaker,kind,phase=''){const key=kind+':'+cid+':'+part+':'+speaker+':'+phase;
 const box=$(kind==='chat'?'chatMessages':'roomMessages'),current=kind==='chat'?state.currentChat:state.currentRoom;
 if(cid!==current||state.view!==kind)return null;
 let node=liveBubbles.get(key);if(node&&!box.contains(node))node=null;
 if(!node){if(box.querySelector('.welcome-card'))box.replaceChildren();node=messageNode({role:'assistant',speaker,content:'',conversation_id:cid,part,meta:{phase}},kind,true);box.append(node);liveBubbles.set(key,node);box.scrollTop=box.scrollHeight}
 return node;}
function liveDelta(event,kind){const node=liveNode(event.conversation_id,event.part||1,event.speaker||'مدل',kind,event.phase||'');
 if(node){const text=node.querySelector('.bubble-text');text.textContent+=event.text||'';const box=$(kind==='chat'?'chatMessages':'roomMessages');box.scrollTop=box.scrollHeight}}
function liveComplete(event,kind){const node=liveNode(event.conversation_id,event.part||1,event.speaker||'مدل',kind,event.phase||'');if(!node)return;
 node.querySelector('.bubble-text').textContent=event.text||node.querySelector('.bubble-text').textContent;
 node.querySelector('.streaming-dot')?.remove();const suffix=event.partial?'بخش ناتمام':event.finish||'پایان';node.querySelector('.bubble-meta').textContent=(event.phase||'')+' · '+suffix;
}
function showStreamNotice(kind,cid,text,error=false){if((kind==='chat'?state.currentChat:state.currentRoom)!==cid||state.view!==kind)return;
 const node=el('div','message-notice'+(error?' message-error':''),text);$(kind==='chat'?'chatMessages':'roomMessages').append(node);node.scrollIntoView({block:'nearest'});}
async function sendChat(mode='send'){let cid=state.currentChat;if(!cid){await newChat();cid=state.currentChat}if(!cid)return;
 if(state.sending.has(cid)||state.active.has(cid)){toast('این گفتگو در حال پاسخ‌گویی است؛ گفتگوی دیگری را باز کنید.',true);return}
 if(mode==='send'&&!$('chatPrompt').value.trim()&&!state.chatAttachments.length){toast('پیام یا پیوستی برای ارسال وجود ندارد.',true);return}
 const payload=chatPayload(mode);state.sending.add(cid);updateChatControls();
 try{await saveChatOptions();const preview=await requestJSON('/api/chat/preview',payload);
 if(!await reviewContext('chat',preview))return;payload.ack_context_trim=preview.requires_context_ack;
 let finished=false;
 await requestStream('/api/chat',payload,event=>{if(event.type==='start'){
   state.active.set(cid,{rid:event.request_id,kind:'chat'});updateChatControls();renderHistory();
   if(mode==='send'&&state.currentChat===cid&&state.view==='chat'){$('chatMessages').querySelector('.welcome-card')?.remove();
     $('chatMessages').append(messageNode({role:'user',speaker:'user',content:payload.message,created_at:Date.now()/1000,meta:{images:payload.images.length,files:payload.files}},'chat'));$('chatMessages').scrollTop=$('chatMessages').scrollHeight}
  }else if(event.type==='delta')liveDelta(event,'chat');
  else if(event.type==='part_start')liveNode(cid,event.part,payload.provider+':'+payload.model,'chat');
  else if(event.type==='part_done')liveComplete(event,'chat');
  else if(event.type==='context_review'){showStreamNotice('chat',cid,'ادامهٔ خودکار متوقف شد: '+event.context.message,true)}
  else if(event.type==='notice')showStreamNotice('chat',cid,event.text);
  else if(event.type==='error'||event.type==='cancelled')showStreamNotice('chat',cid,event.error||'درخواست متوقف شد.',event.type==='error');
  else if(event.type==='done')finished=true;
 });
 if(mode==='send'&&finished){
  try{await patchConversation(cid,{draft:''})}catch(e){}
  clearTimeout(chatDraftTimers.get(cid));chatDraftTimers.delete(cid);
  if(state.currentChat===cid){$('chatPrompt').value='';state.chatAttachments=[];renderAttachments('chat')}}
 }catch(error){showError(error,'گفتگو');if(mode==='send')toast('اگر پیام در تاریخچه ثبت شده، پیش از ارسال دوباره آن را بررسی کنید.',true)}
 finally{state.sending.delete(cid);state.active.delete(cid);updateChatControls();await refreshHistory();if(state.currentChat===cid)await openConversation(cid)}
}
async function stopConversation(kind){const cid=kind==='chat'?state.currentChat:state.currentRoom;const active=state.active.get(cid);
 if(!active){toast('درخواست فعالی برای توقف یافت نشد.');return}
 try{const data=await requestJSON('/api/cancel',{request_id:active.rid});toast(data.cancel_requested?'درخواست توقف فرستاده شد؛ ممکن است تا قطعهٔ بعدی طول بکشد.':'درخواست قبلاً تمام شده است.')}
 catch(error){showError(error,'توقف پاسخ')}}
function renderRoomMembers(){const list=$('roomMembers');list.replaceChildren();if(!state.roomMembers.length)list.append(el('p','field-help','هنوز عضوی انتخاب نشده؛ حداقل دو مدل متفاوت لازم است.'));
 state.roomMembers.forEach((m,i)=>{const chip=el('div','member-chip');chip.append(el('span','',displayProvider(m.provider)+' · '+m.model+(m.role?' · '+m.role:'')));
 const remove=el('button','','×');remove.type='button';remove.setAttribute('aria-label','برداشتن '+m.model);remove.onclick=()=>{state.roomMembers.splice(i,1);renderRoomMembers()};chip.append(remove);list.append(chip)});
 const current=$('roomModerator').value;$('roomModerator').replaceChildren();for(const member of state.roomMembers){const opt=el('option','',member.model+' · '+displayProvider(member.provider));opt.value=member.provider+':'+member.model;$('roomModerator').append(opt)}
 if([...$('roomModerator').options].some(o=>o.value===current))$('roomModerator').value=current;
}
function addRoomMember(){const provider=$('memberProvider').value,model=$('memberModel').value,role=$('memberRole').value.trim();if(!model){toast('ابتدا سرویس متصل و مدل را انتخاب کنید.',true);return}
 if(state.roomMembers.some(m=>m.provider===provider&&m.model===model)){toast('این مدل از قبل عضو است؛ مدل دیگری انتخاب کنید.',true);return}
 if(state.roomMembers.length>=8){toast('برای جلوگیری از فراخوانی ناخواسته در هر نوبت، حداکثر ۸ عضو انتخاب کنید.',true);return}
 state.roomMembers.push({provider,model,api:provider.startsWith('custom:')?'chat':'chat',role});$('memberRole').value='';renderRoomMembers();}
function fillRoomConversation(convo){const cfg=convo.config||{};$('roomHeading').textContent=convo.title||'اتاق گفتگو';
 $('roomSubhead').textContent=convo.message_count+' پیام · گفتگو میان شما و اعضا · قابل ادامه بدون حذف تاریخچه';
 state.roomMembers=Array.isArray(cfg.members)?cfg.members.map(m=>({...m})):[];renderRoomMembers();$('roomMode').value=cfg.mode|| (convo.kind==='bench'?'bench':'collaborate');
 $('roomModerator').value=cfg.moderator||state.roomMembers[0]?.provider+':'+state.roomMembers[0]?.model;
 $('roomProfile').value=convo.profile_id||'';$('roomMaxTokens').value=cfg.max_tokens??'auto';$('roomEffort').value=cfg.effort||'medium';
 $('roomSystem').value=cfg.system||'';$('roomSynthesis').checked=cfg.synthesis!==false;$('roomStream').checked=cfg.stream!==false;
 $('roomHistoricalVision').checked=cfg.accept_historical_vision===true;$('roomPrompt').value=convo.draft||'';
 state.roomAttachments=[];renderAttachments('room');$('roomContextBanner').classList.add('hidden');renderTranscript(convo,'roomMessages');updateRoomControls();}
function updateRoomControls(){const cid=state.currentRoom,busy=Boolean(cid&&(state.active.has(cid)||state.sending.has(cid)));
 $('roomSend').disabled=busy;$('roomPreview').disabled=busy;$('roomStop').hidden=!state.active.has(cid);
 $('roomStatus').textContent=busy?'پاسخ گروه در حال دریافت است؛ جابه‌جایی به اتاق دیگر مجاز است.':'در هر نوبت فقط با درخواست شما چند مدل فراخوانی می‌شوند.';}
const roomDraftTimers=new Map();
function scheduleRoomDraft(){const cid=state.currentRoom;if(!cid)return;const draft=$('roomPrompt').value;clearTimeout(roomDraftTimers.get(cid));
 const timer=setTimeout(async()=>{roomDraftTimers.delete(cid);try{await patchConversation(cid,{draft});if(state.currentRoom===cid&&state.roomConvo)state.roomConvo.draft=draft}catch(e){}},650);roomDraftTimers.set(cid,timer)}
function roomPayload(){const a=state.roomAttachments;return {conversation_id:state.currentRoom||undefined,panel:state.roomMembers,
 mode:$('roomMode').value,moderator:$('roomModerator').value||undefined,profile_id:$('roomProfile').value,
 system:$('roomSystem').value,effort:$('roomEffort').value,max_tokens:$('roomMaxTokens').value.trim()||'auto',
 synthesis:$('roomSynthesis').checked,stream:$('roomStream').checked,
 accept_historical_vision:$('roomHistoricalVision').checked,message:composedMessage($('roomPrompt').value,a),
 images:a.filter(v=>v.type==='image').map(v=>({base64:v.base64}))};}
async function saveRoomOptions(){if(!state.currentRoom)return;const cfg={...(state.roomConvo?.config||{}),mode:$('roomMode').value,
 moderator:$('roomModerator').value,members:state.roomMembers,system:$('roomSystem').value,
 effort:$('roomEffort').value,max_tokens:$('roomMaxTokens').value.trim()||'auto',synthesis:$('roomSynthesis').checked,
 stream:$('roomStream').checked,accept_historical_vision:$('roomHistoricalVision').checked};
 const updated=await patchConversation(state.currentRoom,{config:cfg,profile_id:$('roomProfile').value});
 if(state.roomConvo)state.roomConvo={...state.roomConvo,...updated,config:cfg};}
async function previewRoom(){try{const preview=await requestJSON('/api/room/preview',roomPayload());showContext('room',preview);
 toast('پیش‌نمایش اتاق آماده است؛ حداکثر '+preview.calls_max+' تماس در این نوبت.');}catch(error){showError(error,'پیش‌نمایش گروه')}}
async function sendRoom(){if(!$('roomPrompt').value.trim()&&!state.roomAttachments.length){toast('پیام گروه را بنویسید.',true);return}
 const cid=state.currentRoom;if(cid&&(state.active.has(cid)||state.sending.has(cid))){toast('این اتاق در حال پاسخ‌گویی است.',true);return}
 const lock=cid||'new-room';if(state.sending.has(lock))return;state.sending.add(lock);updateRoomControls();
 let actualId=cid;
 try{if(cid)await saveRoomOptions();const payload=roomPayload();const preview=await requestJSON('/api/room/preview',payload);
 if(!await reviewContext('room',preview))return;payload.ack_context_trim=preview.requires_context_ack;
 await requestStream('/api/room',payload,event=>{if(event.type==='room_start'){
   actualId=event.conversation_id;if(!state.currentRoom||state.currentRoom===cid)state.currentRoom=actualId;
   state.active.set(actualId,{rid:event.request_id,kind:'room'});updateRoomControls();renderHistory();
   if(state.view==='room'){$('roomMessages').querySelector('.welcome-card')?.remove();$('roomMessages').append(messageNode({role:'user',speaker:'user',content:payload.message,created_at:Date.now()/1000,meta:{images:payload.images.length}},'room'));$('roomMessages').scrollTop=$('roomMessages').scrollHeight}
 }else if(event.type==='agent_start')liveNode(event.conversation_id,1,event.speaker,'room',event.phase||'initial');
 else if(event.type==='delta')liveDelta({...event,part:1},'room');
 else if(event.type==='agent_done')liveComplete({...event,part:1},'room');
 else if(event.type==='agent_error'||event.type==='error')showStreamNotice('room',event.conversation_id,event.error,true);
 else if(event.type==='context_review')showStreamNotice('room',event.conversation_id,'پیش از مرحلهٔ بعد، کنارماندن زمینه باید تأیید شود: '+event.context.message,true);
 else if(event.type==='notice')showStreamNotice('room',event.conversation_id,event.text);
 });
 if(actualId&&state.currentRoom===actualId){$('roomPrompt').value='';state.roomAttachments=[];renderAttachments('room')}
 if(actualId){clearTimeout(roomDraftTimers.get(actualId));roomDraftTimers.delete(actualId);try{await patchConversation(actualId,{draft:''})}catch(e){}}
 }catch(error){showError(error,'گفتگوی گروهی')}
 finally{state.sending.delete(lock);if(actualId)state.active.delete(actualId);updateRoomControls();await refreshHistory();if(actualId&&state.currentRoom===actualId)await openConversation(actualId)}
}
function wireChat(){$('editClose').onclick=()=>$('editDialog').close();$('editCancel').onclick=()=>$('editDialog').close();$('editSave').onclick=saveEditedMessage;
 $('chatSaveOptions').onclick=async()=>{try{await saveChatOptions();toast('تنظیمات همین گفتگو ذخیره شد.')}catch(error){showError(error,'تنظیمات گفتگو')}};
 $('chatAttach').onclick=()=>$('chatFiles').click();$('roomAttach').onclick=()=>$('roomFiles').click();
 $('chatFiles').onchange=e=>{addFiles('chat',[...e.target.files]);e.target.value=''};
 $('roomFiles').onchange=e=>{addFiles('room',[...e.target.files]);e.target.value=''};
 $('chatPreview').onclick=previewChat;$('chatSend').onclick=()=>sendChat('send');$('chatContinue').onclick=()=>sendChat('continue');$('chatStop').onclick=()=>stopConversation('chat');
 $('chatPrompt').oninput=scheduleDraft;$('chatPrompt').onkeydown=e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();sendChat()}};
 $('memberAdd').onclick=addRoomMember;$('roomPreview').onclick=previewRoom;$('roomSend').onclick=sendRoom;$('roomStop').onclick=()=>stopConversation('room');
 $('roomPrompt').oninput=scheduleRoomDraft;
 $('roomPrompt').onkeydown=e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();sendRoom()}};
 $('roomMode').onchange=()=>{if($('roomMode').value==='debate'&&state.roomMembers.length>4)toast('در مناظره حداکثر ۴ مدل انتخاب کنید.',true)};
}
