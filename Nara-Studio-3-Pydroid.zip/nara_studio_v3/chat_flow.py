"""Validated chat planning; independent of HTTP and remote API calls."""
import core
import generation


def settings_for(data, conversation, profiles, provider, api):
    if not isinstance(data, dict) or api not in ("chat", "messages", "responses"):
        raise core.RemoteError(400, "تنظیمات چت معتبر نیست.")
    profile_id = data.get("profile_id") or conversation.get("profile_id", "")
    profile = next((p for p in profiles if p["id"] == profile_id), None)
    option = profile.get("options", {}) if profile else {}
    system_from_profile = profile.get("system_prompt", "") if profile else ""
    system_from_turn = data.get("system", "")
    if not isinstance(system_from_turn, str):
        raise core.RemoteError(400, "متن دستور چت معتبر نیست.")
    note = conversation.get("context_note", "")
    system = "\n\n".join(x for x in (system_from_profile, system_from_turn,
                          "یادداشت ثابت کاربر (ممکن است خلاصه باشد، متن کامل در دستگاه مانده است):\n"+note if note else "") if x)
    effort = data.get("effort", option.get("effort", "medium"))
    if effort not in core.EFFORTS:
        raise core.RemoteError(400, "عمق استدلال معتبر نیست.")
    raw_limit = data.get("max_tokens", option.get("max_tokens", "auto"))
    try:
        limit = generation.output_limit(raw_limit, provider if provider in ("atria","bynara") else "custom", api)
    except generation.ContextError as exc:
        raise core.RemoteError(400, str(exc))
    integrity = data.get("integrity_prompt", option.get("integrity_prompt", True)) is not False
    return {"system":system,"effort":effort,"max_tokens":limit,"api":api,"integrity_prompt":integrity,
            "profile_id":profile_id if profile else "", "note_used":bool(note)}


def history_for(conversation, current_text, mode="send"):
    if mode not in ("send", "continue"):
        raise core.RemoteError(400, "حالت ارسال پیام معتبر نیست.")
    if mode == "continue":
        previous = next((m for m in reversed(conversation.get("messages", [])) if m["role"] in ("assistant", "user")), None)
        if previous is None or previous["role"] != "assistant":
            raise core.RemoteError(400, "برای ادامه، آخرین پیام باید پاسخ یک مدل باشد.")
        current_text = generation.continue_prompt()
    if not isinstance(current_text, str) or not current_text.strip():
        raise core.RemoteError(400, "متن پیام معتبر نیست.")
    if len(current_text.encode("utf-8")) > 12*1024*1024:
        raise core.RemoteError(413, "این پیام برای یک درخواست گوشی بزرگ است؛ به چند بخش تقسیم کنید.")
    older = [{"role":m["role"],"content":m["content"]}
             for m in conversation.get("messages", [])
             if m["role"] in ("user","assistant") and m["content"]]
    older.append({"role":"user","content":current_text})
    return older, current_text


def context_for(conversation, current_text, mode, model_info, settings, provider):
    history, text = history_for(conversation,current_text,mode)
    ctx = model_info.get("context_window")
    if provider == "atria" and not ctx:
        ctx = 256000  # Official Atria-Dawn-Preview context, /v1/models may omit it.
    try:
        plan = generation.plan_context(history,ctx,settings["max_tokens"],settings["system"])
    except generation.ContextError as exc:
        raise core.RemoteError(413,str(exc))
    return plan,text
