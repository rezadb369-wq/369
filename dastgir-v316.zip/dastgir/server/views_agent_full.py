# -*- coding: utf-8 -*-
"""v316 full agent console — standalone /agent + /panel/agent — arena removed, upgraded
Per owner request: external browser completely deleted, no trace.
Only management agent remains, upgraded and more powerful.
"""

import json as _js
import os, time as _t, html as _html
import urllib.parse as _uq
import db

# v316 (دستور مدیر): تمام بخش آرنا پاک شد — فقط ابزارهای مدیریتی داخلی
TOOL_FA = {
    "setting": "⚙️ تنظیمات سایت", "page": "📄 ساخت/ویرایش صفحه",
    "post_save": "📰 ذخیرهٔ مقاله/پست", "post_delete": "🗑️ حذف مقاله",
    "category_save": "🗂️ ذخیرهٔ دسته", "category_delete": "🗑️ حذف دسته",
    "business_save": "🏪 ذخیرهٔ کسب‌وکار", "item_save": "📦 ذخیرهٔ کالا",
    "item_delete": "🗑️ حذف کالا", "review_moderate": "⭐ تعدیل نظر",
    "review_delete": "🗑️ حذف نظر", "biz_moderate": "🚦 تعدیل کسب‌وکار",
    "broadcast": "📣 پیام همگانی", "coupon_save": "🎟️ ذخیرهٔ کد تخفیف",
    "coupon_delete": "🗑️ حذف کد تخفیف", "toplist_save": "🏆 ذخیرهٔ لیست برترین",
    "toplist_delete": "🗑️ حذف لیست برترین", "flashdeal_save": "⚡ ذخیرهٔ پیشنهاد لحظه‌ای",
    "flashdeal_delete": "🗑️ حذف پیشنهاد لحظه‌ای", "event_save": "📅 ذخیرهٔ رویداد",
    "event_delete": "🗑️ حذف رویداد", "ad_save": "🖼️ ذخیرهٔ بنر/تبلیغ",
    "ad_delete": "🗑️ حذف بنر", "plan_save": "💎 ذخیرهٔ پلن اشتراک",
    "plan_delete": "🗑️ حذف پلن", "badge_save": "🎖️ ذخیرهٔ نشان",
    "badge_delete": "🗑️ حذف نشان", "story_add": "📸 افزودن استوری",
    "story_delete": "🗑️ حذف استوری", "claim_moderate": "🔏 تعدیل ادعای مالکیت",
    "ticket_reply": "🎫 پاسخ تیکت", "customer_moderate": "👤 تعدیل مشتری",
    "order_status": "🧾 تغییر وضعیت سفارش", "booking_status": "📆 تغییر وضعیت نوبت",
    "area_rename": "🗺️ ویرایش محله", "trash_restore": "♻️ بازگردانی از سطل بازیافت",
    "code_list": "📁 فهرست فایل‌های کد", "code_read": "📖 خواندن کد",
    "code_edit": "✏️ ویرایش کد", "code_write": "📝 نوشتن فایل تازه",
    "code_revert": "↩️ برگشت تغییر کد", "code_search": "🔍 جست‌وجوی کد",
    "code_status": "🚦 وضعیت صف کد", "ai_setup": "🤖 تنظیم هوش سایت",
    "service_restart": "🔄 ری‌استارت سرویس", "brain_switch": "🧠 سوئیچ مغز مدیر",
    "panel_read": "🔎 خواندن بخش پنل", "panel_sections": "🧭 فهرست بخش‌های پنل",
    "subscription_set": "💳 تنظیم اشتراک", "owner_moderate": "⛔ مسدود/آزادسازی مالک",
    "sec_report": "🛡️ گزارش زندهٔ امنیت", "bulk_approve": "✅ تأیید گروهی",
    "backup_now": "💾 بکاپ فوری", "cache_clear": "🧹 پاک‌سازی کش",
    "seo_check": "🌐 بررسی سئو", "health_check": "❤️ بررسی سلامت",
    "file_list": "📃 فهرست فایل‌های تبادل",
    "file_upload": "📤 ارسال فایل", "file_download": "📥 دریافت فایل",
    "shell_exec": "🖥️ اجرای فرمان (ترمینال)",
    "sql_read": "🗄️ پرس‌وجوی خواندنی دیتابیس",
    "log_tail": "📜 لاگ زندهٔ سرویس",
    "sys_info": "🖥️ اطلاعات سیستم",
    "file_read": "📖 خواندن فایل تبادل",
    "file_write": "📝 نوشتن فایل تبادل",
    "file_edit": "✏️ ویرایش فایل تبادل",
    "file_delete": "🗑️ حذف فایل تبادل",
    "db_tables": "🗄️ جدول‌ها و تعداد",
    "backup_list": "💾 فهرست بکاپ‌ها",
    "version_info": "🏷️ نسخه و پین‌ها",
}
from ui import av, icon, esc, fa, fa_group, stat_card, empty_state, page as public_page, panel_page
from views_panel import _msg, _pg, panel_pager
from ui import jdate, jdatetime, jdatetime_ts

def _live_data():
    import json as _js, pathlib as _pl
    pend_data = {}
    try:
        pf = "/tmp/dastgir-admin-pending.json"
        if _pl.Path(pf).exists():
            pend_data = _js.loads(_pl.Path(pf).read_text(encoding="utf-8")[:8000] or "{}")
    except Exception:
        pend_data = {}
    try:
        batches = db.agent_batch_list()
        staged = [b for b in batches if b["status"]=="staged"]
        applied = [b for b in batches if b["status"]=="applied"]
    except Exception:
        batches, staged, applied = [], [], []
    try:
        last = {}
        lp = "/tmp/dastgir-agent-last-action.json"
        if _pl.Path(lp).exists():
            last = _js.loads(_pl.Path(lp).read_text(encoding="utf-8")[:8000] or "{}")
    except Exception:
        last = {}
    try:
        has_rb = _pl.Path(os.path.join(db.DATA_DIR, "agent-rollback.json")).exists()
    except Exception:
        has_rb = False
    try:
        import adminbot_content as CT
        ok_h, msg_h = CT.tool_execute("health_check", {})
        health_msg = str(msg_h)[:3000]
    except Exception as e:
        health_msg = f"خطا: {e}"
    try:
        import adminbot_content as CT
        tools = list(CT.TOOLS)
    except Exception:
        tools = ["setting","business_save","item_save","backup_now","health_check","seo_check","bulk_approve","cache_clear","code_read","code_search","code_edit","sec_report","panel_read","shell_exec","sql_read","log_tail","file_list","file_upload","file_download","sys_info","db_tables","version_info"]
    return pend_data, batches, staged, applied, last, has_rb, health_msg, tools

def _files_card():
    """v316 صندوق تبادل فایل ایجنت — ارتقا یافته، بدون آرنا"""
    try:
        import agent_browser as _ABX
        files = _ABX.exchange_list()
    except Exception:
        files = []
    rows = ""
    for f in files[:20]:
        try:
            nm = str(f.get("name") or "")
            kb = int(f.get("size") or 0) // 1024
            when = jdatetime_ts(f.get("mtime")) if f.get("mtime") else ""
            rows += ('<tr><td dir="ltr"><code>' + esc(nm) + '</code></td>'
                     '<td class="nums">' + fa(kb) + ' KB</td>'
                     '<td class="nums text-xs">' + esc(str(when)) + '</td>'
                     '<td><a class="btn btn-ghost btn-sm" href="/agent/file/'
                     + _uq.quote(nm) + '">📥 دریافت</a></td></tr>')
        except Exception:
            pass
    if not rows:
        rows = ('<tr><td colspan="4" class="text-center text-muted">'
                'صندوق تبادل خالی است — فایل بفرست تا اینجا فهرست شود.</td></tr>')
    return f"""
<div class="card glass card-pad mb-lg">
  <div class="between mb-md" style="flex-wrap:wrap;gap:10px">
    <h3 class="card-title">📦 تبادل فایل ایجنت — ارسال و دریافت</h3>
    <span class="text-xs text-muted">صندوق: <code>data/agent-exchange/</code> · دانلود فقط با نشست ایجنت/مدیر · v316 بدون آرنا</span>
  </div>
  <form method="post" action="/agent/upload" enctype="multipart/form-data" class="dir-row mb-md">
    <input class="input" type="file" name="file" required>
    <button class="btn btn-primary" type="submit"><span>📤 ارسال فایل</span></button>
  </form>
  <div class="table-wrap"><table class="table"><thead><tr><th>فایل</th><th>اندازه</th><th>زمان</th><th></th></tr></thead><tbody>{rows}</tbody></table></div>
  <p class="field-hint mt-sm">این صندوق پل امن بین شما و ایجنت مدیریتی است — هر فایلی را اینجا بیندازید تا ایجنت با ابزار file_read/file_write آن را بخواند/ویرایش کند.</p>
</div>"""

def agent_email_gate(s, token="", next_url="/agent"):
    body = f'''
<div class="container" style="max-width:520px;margin:60px auto">
  <div class="card glass card-pad" style="text-align:center">
    <div class="auth-head"><span class="mark">{icon("mail")}</span>
      <h1>ورود با ایمیل — پنل ایجنت مدیریتی</h1>
      <p class="text-sm text-muted">ایمیلتو وارد کن، کد ۶ رقمی میاد، بعد وارد کنسول همه‌کاره ایجنت مدیریتی میشی — v316 بدون آرنا، فقط مدیریت داخلی.</p>
    </div>
    <form method="post" action="/login/email" class="mt-lg" style="text-align:start">
      <input type="hidden" name="next" value="{esc(next_url)}">
      <div class="field"><label class="field-label">ایمیل</label>
        <input class="input" name="email" type="email" dir="ltr" placeholder="you@example.com" required></div>
      <button class="btn btn-primary btn-block" type="submit">{icon("mail")}<span>ارسال کد ورود</span></button>
    </form>
    <p class="field-hint mt-md">یا با موبایل: <a href="/login?next={esc(next_url)}">ورود با موبایل</a></p>
  </div>
</div>'''
    return public_page(s, "ورود ایمیلی — ایجنت مدیریتی", body, active="/agent")

def agent_key_gate(s, token="", customer=None, owner=None):
    email = ""
    if customer:
        email = customer.get("email") or customer.get("phone") or f"#{customer.get('id')}"
    elif owner:
        email = owner.get("phone") or f"owner#{owner.get('id')}"
    body = f'''
<div class="container" style="max-width:640px;margin:40px auto">
  <div class="card glass card-pad">
    <h2 class="card-title">{icon("lock")} کلید خصوصی ایجنت لازم است</h2>
    <p class="text-sm text-muted">وارد شدی به عنوان <b>{esc(email)}</b> — برای دسترسی ایجنت مدیریتی یا با ایمیلِ مالک سایت وارد شو (خودکار دسترسی کامل می‌گیری) یا کلید یک‌بارمصرف بگیر.</p>
    <div class="alert alert-info mt-md">{icon("info")}<span>در ربات بله مدیر بزن <code>/agent</code> یا <code>پنل ایجنت</code> — ربات لینک یک‌بارمصرف میده مثل <code>/agent?ak=...</code> — روش بزن تا کوکی ست بشه. v316: بخش مرورگر خارجی آرنا حذف شد.</span></div>
    <div class="cluster mt-md">
      <a class="btn btn-glass" href="/panel/agent">{icon("settings")}<span>رفتن به /panel/agent (ادمین)</span></a>
      <a class="btn btn-ghost" href="/">{icon("store")}<span>سایت اصلی</span></a>
    </div>
  </div>
</div>'''
    if token:
        return panel_page(s, "کلید ایجنت", "کلید خصوصی از ربات بله", body, "/panel/agent", token)
    return public_page(s, "کلید ایجنت", body, active="/agent")

def agent_standalone_page(s, token, q=None, customer=None, owner=None, agent_ok=False):
    """Full standalone /agent — v316 upgraded, no arena, only internal management agent"""
    q = q or {}
    pend_data, batches, staged, applied, last_action, has_rollback, health_msg, tools = _live_data()
    try:
        ai_today = 0
        import pathlib as _pl, json as _js
        # try to get stats from assistant if available
        try:
            import assistant
            ai_today = assistant.stats(7).get("today",{}).get("n",0)
        except Exception:
            pass
    except Exception:
        ai_today = 0

    tool_opts = "".join(f'<option value="{esc(t)}">{esc(TOOL_FA.get(t, t))} — {esc(t)}</option>' for t in tools)

    try:
        keys = db.agent_key_list(limit=8)
        keys_html = "".join(f'<tr><td class="nums" dir="ltr" style="font-size:11px">{esc(k["token"][:16])}…</td><td class="nums">{esc(jdatetime_ts(k["created"]))}</td><td>{fa(max(0,int((k["expires"]-_t.time())//60)))} د</td><td>{"✅" if k["used"] else "⏳"}</td></tr>' for k in keys) or '<tr><td colspan="4" class="text-muted">—</td></tr>'
    except Exception:
        keys_html = '<tr><td colspan="4">—</td></tr>'

    pend_html = ""
    if pend_data and pend_data.get("action")=="agent_confirm":
        try:
            tgt = _js.loads(pend_data.get("target") or "{}")
            pend_html = f'''<div class="alert alert-warn"><b>در انتظار تایید بله:</b><br><pre style="white-space:pre-wrap;max-height:240px;overflow:auto" dir="ltr">{esc(_js.dumps(tgt, ensure_ascii=False, indent=2)[:2500])}</pre>
            <div class="cluster mt-sm"><form method="post" action="/agent/confirm" style="display:inline"><button class="btn btn-primary btn-sm">✅ تایید و اجرا</button></form>
            <form method="post" action="/agent/cancel" style="display:inline"><button class="btn btn-glass btn-sm">❌ لغو</button></form></div></div>'''
        except Exception:
            pend_html = f'<div class="alert alert-warn">pending: {esc(str(pend_data)[:400])}</div>'

    batch_rows = ""
    for b in staged[-30:]:
        try:
            args = _js.loads(b["args"]) if b["args"] else {}
            args_s = _js.dumps(args, ensure_ascii=False)[:400]
        except Exception:
            args_s = (b["args"] or "")[:400]
        batch_rows += f'''<tr>
          <td class="nums">#{b["id"]}</td><td><code>{esc(b["tool"])}</code></td><td class="text-xs"><pre style="white-space:pre-wrap;max-height:120px;overflow:auto">{esc(args_s)}</pre></td>
          <td><span class="badge badge-warn">{esc(b["status"])}</span></td>
          <td class="nums text-xs">{esc(jdatetime_ts(b["created"]))}</td>
          <td><form method="post" action="/agent/batch/remove" style="display:inline"><input type="hidden" name="id" value="{b["id"]}"><button class="btn btn-ghost btn-sm">✕</button></form></td>
        </tr>'''
    if not batch_rows:
        batch_rows = '<tr><td colspan="6" class="text-center text-muted">صف خالی — ابزار اضافه کن تا با یک دستور همه اعمال شوند.</td></tr>'

    last_html = ""
    if last_action:
        last_html = f'<div class="card glass card-pad mb-lg"><h3 class="card-title mb-md">{icon("activity")} آخرین اقدام</h3><pre style="max-height:220px;overflow:auto" dir="ltr">{esc(_js.dumps(last_action, ensure_ascii=False, indent=2)[:4000])}</pre></div>'

    switcher = '''
<div class="cluster mb-md" id="model-switcher" style="gap:8px;flex-wrap:wrap">
  <span class="text-sm"><b>مغز ایجنت مدیریتی:</b></span>
  <button class="chip is-active" data-model="auto">🤖 خودکار (مغز فعال)</button>
  <button class="chip" data-model="opus">🧠 اپوس ۵</button>
  <button class="chip" data-model="sonnet">⚡ سونت ۵</button>
  <button class="chip" data-model="haiku">🪶 هایکو ۴.۵</button>
  <button class="chip" data-model="openrouter">🌐 اوپن‌روتر</button>
  <button class="chip" data-model="glm">✨ GLM ۵.۳</button>
  <button class="chip" data-model="offline">📴 آفلاین (نامحدود)</button>
  <span class="badge badge-open" id="model-current">auto</span>
</div>
'''

    cust_label = ""
    if customer:
        cust_label = customer.get("email") or customer.get("phone") or f"cust#{customer.get('id')}"
    elif owner:
        cust_label = owner.get("phone") or "owner"

    content = f'''
{_msg(q)}
<div class="between mb-lg" style="flex-wrap:wrap;gap:12px">
  <div><h1 style="margin:0">{icon("sparkles")} پنل ایجنت مدیریتی — v316 ارتقا یافته <span class="badge badge-open">✅ فعال — {esc(cust_label)}</span></h1>
  <p class="text-sm text-muted mt-sm">کنسول همه‌کاره مدیریت داخلی — {fa(len(tools))} ابزار فعال — بدون وابستگی خارجی — تبادل فایل امن — ترمینال — دیتابیس — بکاپ — سئو — امنیت</p></div>
  <div class="cluster">
    <a class="btn btn-glass btn-sm" href="/panel/agent">{icon("settings")}<span>نسخه پنلی</span></a>
    <a class="btn btn-ghost btn-sm" href="/">{icon("store")}<span>سایت</span></a>
  </div>
</div>

{switcher}

<div class="card glass card-pad mb-lg" style="border:2px solid #22c55e">
  <div class="between" style="flex-wrap:wrap;gap:12px">
    <div><h3 class="card-title">✅ v316 — بخش مرورگر خارجی آرنا حذف شد + ایجنت مدیریتی ارتقا یافت</h3>
    <p class="text-sm text-muted">به درخواست مدیر، بخش مرورگر خارجی کامل حذف شد و هیچ اثری در پنل نماند. فقط ایجنت مدیریتی داخلی باقی ماند و ارتقا یافت — با صندوق تبادل فایل، ترمینال، SQL خواندنی، لاگ زنده، اطلاعات سیستم، بکاپ، امنیت.</p></div>
    <div class="cluster"><span class="badge badge-open">v316 بدون آرنا</span></div>
  </div>
</div>

<div class="grid grid-4 mb-lg">
  {stat_card("activity", len(staged), "در صف (staged)")}
  {stat_card("check-circle", len(applied), "اعمال شده")}
  {stat_card("zap", ai_today, "پیام امروز")}
  {stat_card("shield", 1 if has_rollback else 0, "Rollback")}
</div>

{pend_html}

<div class="grid grid-2 mb-lg" style="align-items:start">
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("plus")} افزودن به صف دسته‌ای</h3>
    <form method="post" action="/agent/batch/add" data-validate>
      <div class="field"><label class="field-label">ابزار</label><select class="select" id="ab-tool" name="tool" required>{tool_opts}</select></div>
      <div class="field"><label class="field-label">JSON args</label><textarea class="textarea" id="ab-args" name="args" style="min-height:110px;font-family:monospace;direction:ltr" placeholder='{{"key":"site_name","value":"نام جدید"}}'>{{}}</textarea></div>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>افزودن به صف</span></button>
    </form>
    <hr class="divider">
    <h4 class="card-title mb-sm">{icon("zap")} اجرای فوری</h4>
    <form method="post" action="/agent/exec">
      <div class="field"><label class="field-label">ابزار</label><select class="select" name="tool" required>{tool_opts}</select></div>
      <div class="field"><label class="field-label">JSON</label><textarea class="textarea" name="args" style="min-height:80px;font-family:monospace;direction:ltr">{{}}</textarea></div>
      <button class="btn btn-accent btn-block" type="submit">{icon("zap")}<span>اجرای فوری</span></button>
    </form>
    <div class="cluster mt-md" style="flex-wrap:wrap">
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"setting","args":{{"key":"site_name","value":"دست گیر"}}}}'>نام سایت</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"health_check","args":{{}}}}'>سلامت</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"seo_check","args":{{}}}}'>سئو</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"backup_now","args":{{}}}}'>بکاپ</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"cache_clear","args":{{}}}}'>پاکسازی کش</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"sys_info","args":{{}}}}'>سیستم</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"db_tables","args":{{}}}}'>جدول‌ها</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"version_info","args":{{}}}}'>نسخه</button>
    </div>
  </div>
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("shield")} کلیدها + سلامت</h3>
    <div class="table-wrap"><table class="table"><thead><tr><th>کلید</th><th>ساخته</th><th>انقضا</th><th>وضعیت</th></tr></thead><tbody>{keys_html}</tbody></table></div>
    <p class="field-hint mt-sm">کلید فقط یک‌بار در بله نمایش داده می‌شود — در DB فقط هش.</p>
    <hr class="divider">
    <h4 class="card-title mb-sm">{icon("activity")} سلامت زنده</h4>
    <pre style="max-height:180px;overflow:auto;white-space:pre-wrap" class="text-xs">{esc(health_msg[:2000])}</pre>
  </div>
</div>

<div class="card glass card-pad mb-lg">
  <div class="between mb-md"><h3 class="card-title">{icon("layers")} صف دسته‌ای — {fa(len(staged))} آماده</h3>
  <div class="cluster">
    <form method="post" action="/agent/batch/apply" data-confirm="همه اعمال شود؟"><button class="btn btn-primary" type="submit">⚡ اعمال همه ({fa(len(staged))})</button></form>
    <form method="post" action="/agent/batch/clear" data-confirm="پاک شود؟"><button class="btn btn-ghost" type="submit">پاک‌سازی</button></form>
  </div></div>
  <div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>ابزار</th><th>args</th><th>وضعیت</th><th>زمان</th><th></th></tr></thead><tbody>{batch_rows}</tbody></table></div>
</div>

{last_html}
{_files_card()}

<div class="grid grid-2 mb-lg">
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("file")} کد — دسترسی آزاد</h3>
    <form method="get" action="/agent/code" class="grid grid-2" style="align-items:end">
      <div class="field" style="margin:0"><label class="field-label">مسیر فایل</label><input class="input" name="f" dir="ltr" placeholder="server/db.py"></div>
      <button class="btn btn-glass" type="submit">{icon("search")}<span>خواندن</span></button>
    </form>
    <form method="get" action="/agent/code" class="mt-md">
      <div class="field"><label class="field-label">جستجو</label><div class="dir-row"><input class="input" name="q" placeholder="email_otp"><button class="btn btn-glass" type="submit">جستجو</button></div></div>
    </form>
    <hr class="divider">
    <h4 class="card-title mb-sm">🖥️ ترمینال + دیتابیس + لاگ</h4>
    <form method="post" action="/agent/exec" class="grid grid-1">
      <div class="field"><label class="field-label">فرمان ترمینال</label><div class="dir-row"><input class="input" name="args" dir="ltr" placeholder='{{"cmd":"ls -la"}}' value='{{"cmd":""}}'><button class="btn btn-ghost" type="submit">اجرا</button></div></div>
    </form>
    <form method="post" action="/agent/exec" class="mt-sm">
      <div class="field"><label class="field-label">SQL خواندنی</label><div class="dir-row"><input class="input" name="args" dir="ltr" placeholder='{{"q":"SELECT * FROM businesses LIMIT 5"}}'><button class="btn btn-ghost" type="submit">پرس‌وجو</button></div></div>
      <input type="hidden" name="tool" value="sql_read">
    </form>
  </div>
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("message")} چت زنده ایجنت مدیریتی — ارتقا یافته</h3>
    <div id="agent-chat-log" style="height:280px;overflow:auto;border:1px solid var(--color-border);border-radius:12px;padding:10px;background:var(--color-card)" class="mb-md text-sm"><div class="text-muted">پیام‌ها اینجا — مدل فعلی: <b id="log-model">auto</b> — نامحدود شخصی — v316 بدون آرنا</div></div>
    <div class="dir-row"><input class="input" id="agent-chat-input" placeholder="مثلاً: ۵ کسب‌وکار نمونه بساز و سئو چک کن"><button class="btn btn-primary" id="agent-chat-send">ارسال</button></div>
    <p class="field-hint mt-sm">مغز هر پیام با چیپ‌های بالا انتخاب می‌شود: خودکار = مغز فعال مدیر؛ آفلاین = نامحدود و بدون کلید. همهٔ {fa(len(tools))} ابزار داخلی فعال است.</p>
  </div>
</div>

<div class="card glass card-pad mb-lg">
  <h3 class="card-title mb-md">{icon("shield")} امنیت و قابلیت‌های v316</h3>
  <ul class="text-sm" style="line-height:1.9">
    <li>✅ v316: بخش مرورگر خارجی آرنا کامل حذف شد — هیچ مسیر، دکمه، راهنما، ابزار، فایل یا اشاره‌ای در سایت و پنل نماند</li>
    <li>🔐 نشست مدیر/ورود ایمیلی مالک = دسترسی کامل — بدون نیاز به کلید بله (کلید بله اختیاری: ۳۲ بایت، هش SHA256، TTL ۱h، کوکی ۷d HttpOnly)</li>
    <li>📧 ورود ایمیلی — OTP ۶ رقمی، ۵ دقیقه، throttling</li>
    <li>♾️ نامحدود شخصی — وقتی ایجنت فعاله سهمیه بی‌نهایت</li>
    <li>🧠 مغز هر پیام جدا: خودکار/اپوس/سونت/هایکو/اوپن‌روتر/GLM/آفلاین — مغز سراسری مدیر عوض نمی‌شود</li>
    <li>🖥️ ترمینال: اجرای فرمان (shell_exec) — با تأیید بله برای پیشنهاد هوش، اجرای مستقیم برای مدیر</li>
    <li>🗄️ دیتابیس خواندنی: sql_read — فقط SELECT/WITH/PRAGMA — ۵۰ ردیف</li>
    <li>📜 لاگ زنده: log_tail — journalctl -u bazarche</li>
    <li>📦 صندوق تبادل فایل ارتقا یافته — ۲۰ فایل آخر، آپلود/دانلود امن، خواندن/نوشتن/ویرایش/حذف از طریق ابزارها</li>
    <li>🛡️ امنیت: sec_report — گزارش SSH/fail2ban/فایروال/سپر/پنل با عدد و دلیل</li>
    <li>💾 بکاپ فوری، فهرست بکاپ‌ها، پاکسازی کش، سئو، سلامت، تأیید گروهی</li>
  </ul>
</div>

<script>
(function(){{
  var LS_KEY="bz-agent-model";
  var curModel=localStorage.getItem(LS_KEY)||"auto";
  function setModel(m){{
    curModel=m;
    localStorage.setItem(LS_KEY,m);
    document.querySelectorAll('#model-switcher [data-model]').forEach(function(b){{
      b.classList.toggle('is-active', b.getAttribute('data-model')===m);
    }});
    var el=document.getElementById('model-current'); if(el) el.textContent=m;
    var el2=document.getElementById('log-model'); if(el2) el2.textContent=m;
  }}
  setModel(curModel);
  document.querySelectorAll('#model-switcher [data-model]').forEach(function(b){{
    b.addEventListener('click',function(){{setModel(b.getAttribute('data-model'));}});
  }});
  document.querySelectorAll('[data-quick]').forEach(function(b){{
    b.addEventListener('click',function(){{
      try{{var o=JSON.parse(b.getAttribute('data-quick'));document.getElementById('ab-tool').value=o.tool;document.getElementById('ab-args').value=JSON.stringify(o.args,null,2);}}catch(e){{}}
    }});
  }});
  var log=document.getElementById('agent-chat-log');
  var input=document.getElementById('agent-chat-input');
  var send=document.getElementById('agent-chat-send');
  function addMsg(who,txt){{
    var d=document.createElement('div'); d.style.margin='6px 0';
    d.innerHTML='<b>'+who+':</b> '+txt.replace(/</g,'&lt;').replace(/\\n/g,'<br>');
    log.appendChild(d); log.scrollTop=log.scrollHeight;
  }}
  async function poll(){{
    try{{var r=await fetch('/api/agent/status',{{credentials:'same-origin'}}); var j=await r.json(); if(j.ok){{var e=document.querySelector('[data-agent-staged]'); if(e) e.textContent=j.staged;}} }}catch(e){{}}
  }}
  setInterval(poll,4000);
  async function sendChat(){{
    var t=input.value.trim(); if(!t) return;
    addMsg('شما',t); input.value='';
    addMsg('ایجنت','⏳ در حال فکر...');
    try{{
      var r=await fetch('/api/agent/chat',{{method:'POST',credentials:'same-origin',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{text:t,model:curModel}})}});
      var j=await r.json();
      if(log.lastChild) log.removeChild(log.lastChild);
      if(j.ok){{
        addMsg('ایجنت ('+ (j.model||curModel) +')', j.reply || j.text || '—');
        if(j.tool) addMsg('ابزار', j.tool.name+': '+JSON.stringify(j.tool.args));
      }}else{{
        addMsg('خطا', j.error || 'خطا');
      }}
    }}catch(e){{
      if(log.lastChild) log.removeChild(log.lastChild);
      addMsg('خطا','ارتباط برقرار نشد: '+e);
    }}
  }}
  send.addEventListener('click',sendChat);
  input.addEventListener('keydown',function(e){{if(e.key==='Enter') sendChat();}});
}})();
</script>
'''
    return public_page(s, "پنل ایجنت مدیریتی — v316", content, active="/agent", extra_js="", extra_head="")

def agent_panel_page(s, token, q=None, agent_ok=False):
    """v316 panel version — upgraded, no arena"""
    pend_data, batches, staged, applied, last_action, has_rollback, health_msg, tools = _live_data()
    try:
        ai_today = 0
        try:
            import assistant
            ai_today = assistant.stats(7).get("today",{}).get("n",0)
        except Exception:
            pass
    except Exception:
        ai_today = 0
    tool_opts = "".join(f'<option value="{esc(t)}">{esc(TOOL_FA.get(t, t))} — {esc(t)}</option>' for t in tools)
    try:
        keys = db.agent_key_list(limit=5)
        keys_html = "".join(f'<tr><td class="nums" dir="ltr" style="font-size:11px">{esc(k["token"][:16])}…</td><td class="nums">{esc(jdatetime_ts(k["created"]))}</td><td>{fa(max(0,int((k["expires"]-_t.time())//60)))} د</td><td>{"✅" if k["used"] else "⏳"}</td></tr>' for k in keys) or '<tr><td colspan="4" class="text-muted">—</td></tr>'
    except Exception:
        keys_html = '<tr><td colspan="4">—</td></tr>'
    pend_html = ""
    if pend_data and pend_data.get("action")=="agent_confirm":
        try:
            tgt = _js.loads(pend_data.get("target") or "{}")
            pend_html = f'''<div class="alert alert-warn"><b>در انتظار تایید بله:</b><br><pre style="white-space:pre-wrap;max-height:240px;overflow:auto" dir="ltr">{esc(_js.dumps(tgt, ensure_ascii=False, indent=2)[:2500])}</pre>
            <div class="cluster mt-sm"><form method="post" action="/panel/agent/confirm" style="display:inline"><button class="btn btn-primary btn-sm">✅ تایید</button></form>
            <form method="post" action="/panel/agent/cancel" style="display:inline"><button class="btn btn-glass btn-sm">❌ لغو</button></form></div></div>'''
        except Exception:
            pend_html = f'<div class="alert alert-warn">pending: {esc(str(pend_data)[:400])}</div>'
    batch_rows = ""
    for b in staged[-20:]:
        try:
            args = _js.loads(b["args"]) if b["args"] else {}
            args_s = _js.dumps(args, ensure_ascii=False)[:400]
        except Exception:
            args_s = (b["args"] or "")[:400]
        batch_rows += f'''<tr><td class="nums">#{b["id"]}</td><td><code>{esc(b["tool"])}</code></td><td class="text-xs"><pre style="white-space:pre-wrap">{esc(args_s)}</pre></td><td><span class="badge badge-warn">{esc(b["status"])}</span></td><td class="nums">{esc(jdatetime_ts(b["created"]))}</td><td><form method="post" action="/panel/agent/batch/remove" style="display:inline"><input type="hidden" name="id" value="{b["id"]}"><button class="btn btn-ghost btn-sm">✕</button></form></td></tr>'''
    if not batch_rows:
        batch_rows = '<tr><td colspan="6" class="text-center text-muted">صف خالی</td></tr>'
    last_html = ""
    if last_action:
        last_html = f'<div class="card glass card-pad mb-lg"><h3 class="card-title mb-md">{icon("activity")} آخرین اقدام</h3><pre style="max-height:220px;overflow:auto" dir="ltr">{esc(_js.dumps(last_action, ensure_ascii=False, indent=2)[:4000])}</pre></div>'
    agent_status = f'<span class="badge {"badge-open" if agent_ok else "badge-closed"}">{"✅ فعال — نامحدود شخصی" if agent_ok else "🔒 کلید اختیاری"}</span>'
    switcher = '''
<div class="cluster mb-md" id="model-switcher" style="gap:8px;flex-wrap:wrap">
  <span class="text-sm"><b>مغز ایجنت:</b></span>
  <button class="chip is-active" data-model="auto">🤖 خودکار</button>
  <button class="chip" data-model="opus">🧠 اپوس</button>
  <button class="chip" data-model="sonnet">⚡ سونت</button>
  <button class="chip" data-model="haiku">🪶 هایکو</button>
  <button class="chip" data-model="openrouter">🌐 اوپن‌روتر</button>
  <button class="chip" data-model="glm">✨ GLM</button>
  <button class="chip" data-model="offline">📴 آفلاین</button>
  <span class="badge badge-open" id="model-current">auto</span>
</div>
'''
    content = f'''
{_msg(q or {})}
<div class="between mb-lg" style="flex-wrap:wrap;gap:12px">
  <div><h2 class="card-title">{icon("sparkles")} پنل ایجنت مدیریتی — v316 ارتقا یافته {agent_status}</h2>
  <p class="text-sm text-muted">نسخه پنلی — جدا هم در <a href="/agent">/agent</a> با ورود ایمیلی موجوده — {fa(len(tools))} ابزار داخلی فعال — بدون آرنا</p></div>
  <div class="cluster">
    <a class="btn btn-glass btn-sm" href="/agent">{icon("external")}<span>/agent جدا</span></a>
    <a class="btn btn-glass btn-sm" href="/panel/assistant">{icon("settings")}<span>دستیار</span></a>
  </div>
</div>
{switcher}

<div class="card glass card-pad mb-lg" style="border:2px solid #22c55e">
  <div class="between" style="flex-wrap:wrap;gap:12px">
    <div><h3 class="card-title">✅ v316 — آرنا حذف شد، ایجنت مدیریتی ارتقا یافت</h3>
    <p class="text-sm text-muted">تمام مسیرهای مرورگر خارجی و پل آرنا حذف شد. این پنل فقط مدیریت داخلی است — تبادل فایل، ترمینال، SQL، لاگ، سیستم، بکاپ، امنیت، سئو.</p></div>
    <div><span class="badge badge-open">v316 بدون آرنا</span></div>
  </div>
</div>

<div class="grid grid-4 mb-lg">
  {stat_card("activity", len(staged), "صف")}
  {stat_card("check-circle", len(applied), "اعمال شده")}
  {stat_card("zap", ai_today, "پیام امروز")}
  {stat_card("shield", 1 if has_rollback else 0, "Rollback")}
</div>
{pend_html}
<div class="grid grid-2 mb-lg" style="align-items:start">
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("plus")} افزودن به صف</h3>
    <form method="post" action="/panel/agent/batch/add">
      <div class="field"><label class="field-label">ابزار</label><select class="select" id="ab-tool" name="tool" required>{tool_opts}</select></div>
      <div class="field"><label class="field-label">JSON args</label><textarea class="textarea" id="ab-args" name="args" style="min-height:110px;font-family:monospace;direction:ltr">{{}}</textarea></div>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>افزودن</span></button>
    </form>
    <hr class="divider">
    <h4 class="card-title mb-sm">{icon("zap")} اجرای فوری</h4>
    <form method="post" action="/panel/agent/exec">
      <div class="field"><label class="field-label">ابزار</label><select class="select" name="tool" required>{tool_opts}</select></div>
      <div class="field"><label class="field-label">JSON</label><textarea class="textarea" name="args" style="min-height:80px;font-family:monospace;direction:ltr">{{}}</textarea></div>
      <button class="btn btn-accent btn-block" type="submit">{icon("zap")}<span>اجرای فوری</span></button>
    </form>
    <div class="cluster mt-md" style="flex-wrap:wrap">
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"sys_info","args":{{}}}}'>سیستم</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"health_check","args":{{}}}}'>سلامت</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"version_info","args":{{}}}}'>نسخه</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"backup_now","args":{{}}}}'>بکاپ</button>
    </div>
  </div>
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("shield")} کلیدها + سلامت</h3>
    <div class="table-wrap"><table class="table"><thead><tr><th>کلید</th><th>ساخته</th><th>انقضا</th><th>وضعیت</th></tr></thead><tbody>{keys_html}</tbody></table></div>
    <pre style="max-height:180px;overflow:auto;white-space:pre-wrap" class="text-xs mt-md">{esc(health_msg[:2000])}</pre>
  </div>
</div>
<div class="card glass card-pad mb-lg">
  <div class="between mb-md"><h3 class="card-title">{icon("layers")} صف — {fa(len(staged))} آماده</h3>
  <div class="cluster">
    <form method="post" action="/panel/agent/batch/apply" data-confirm="اعمال همه؟"><button class="btn btn-primary" type="submit">⚡ اعمال همه</button></form>
    <form method="post" action="/panel/agent/batch/clear" data-confirm="پاک؟"><button class="btn btn-ghost" type="submit">پاک‌سازی</button></form>
  </div></div>
  <div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>ابزار</th><th>args</th><th>وضعیت</th><th>زمان</th><th></th></tr></thead><tbody>{batch_rows}</tbody></table></div>
</div>
{last_html}
{_files_card()}
<div class="grid grid-2 mb-lg">
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("file")} کد + ترمینال + SQL</h3>
    <form method="get" action="/panel/agent/code" class="grid grid-2" style="align-items:end">
      <div class="field" style="margin:0"><label class="field-label">فایل</label><input class="input" name="f" dir="ltr" placeholder="server/db.py"></div>
      <button class="btn btn-glass" type="submit">{icon("search")}<span>خواندن</span></button>
    </form>
    <form method="get" action="/panel/agent/code" class="mt-md">
      <div class="field"><label class="field-label">جستجو</label><div class="dir-row"><input class="input" name="q" placeholder="agent_key"><button class="btn btn-glass" type="submit">جستجو</button></div></div>
    </form>
  </div>
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("message")} چت زنده — سوئیچ هوش‌ها</h3>
    <div id="agent-chat-log" style="height:240px;overflow:auto;border:1px solid var(--color-border);border-radius:12px;padding:10px;background:var(--color-card)" class="mb-md text-sm"><div class="text-muted">مدل: <b id="log-model">auto</b> — نامحدود — v316</div></div>
    <div class="dir-row"><input class="input" id="agent-chat-input" placeholder="پیام..."><button class="btn btn-primary" id="agent-chat-send">ارسال</button></div>
  </div>
</div>
<script>
(function(){{
  var LS_KEY="bz-agent-model";
  var curModel=localStorage.getItem(LS_KEY)||"auto";
  function setModel(m){{
    curModel=m; localStorage.setItem(LS_KEY,m);
    document.querySelectorAll('#model-switcher [data-model]').forEach(function(b){{b.classList.toggle('is-active', b.getAttribute('data-model')===m);}});
    var el=document.getElementById('model-current'); if(el) el.textContent=m;
    var el2=document.getElementById('log-model'); if(el2) el2.textContent=m;
  }}
  setModel(curModel);
  document.querySelectorAll('#model-switcher [data-model]').forEach(function(b){{b.addEventListener('click',function(){{setModel(b.getAttribute('data-model'));}});}});
  var log=document.getElementById('agent-chat-log');
  var input=document.getElementById('agent-chat-input');
  var send=document.getElementById('agent-chat-send');
  function addMsg(who,txt){{
    var d=document.createElement('div'); d.style.margin='6px 0';
    d.innerHTML='<b>'+who+':</b> '+txt.replace(/</g,'&lt;').replace(/\\n/g,'<br>');
    log.appendChild(d); log.scrollTop=log.scrollHeight;
  }}
  async function sendChat(){{
    var t=input.value.trim(); if(!t) return;
    addMsg('شما',t); input.value='';
    addMsg('ایجنت','⏳...');
    try{{
      var r=await fetch('/api/agent/chat',{{method:'POST',credentials:'same-origin',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{text:t,model:curModel}})}});
      var j=await r.json();
      if(log.lastChild) log.removeChild(log.lastChild);
      if(j.ok){{addMsg('ایجنت ('+(j.model||curModel)+')', j.reply||j.text||'—'); if(j.tool) addMsg('ابزار', j.tool.name+': '+JSON.stringify(j.tool.args));}}else{{addMsg('خطا', j.error||'خطا');}}
    }}catch(e){{if(log.lastChild) log.removeChild(log.lastChild); addMsg('خطا','ارتباط: '+e);}}
  }}
  send.addEventListener('click',sendChat);
  input.addEventListener('keydown',function(e){{if(e.key==='Enter') sendChat();}});
}})();
</script>
'''
    return panel_page(s, "پنل ایجنت مدیریتی — v316", "زنده، خصوصی، دسته‌ای، نامحدود — بدون آرنا — فقط مدیریت داخلی.", content, "/panel/agent", token)
