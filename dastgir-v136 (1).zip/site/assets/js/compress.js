/* ==========================================================================
   Bazarche v126 — powerful in-browser media compressor (image + video).

   Runs on the device BEFORE a byte is uploaded, so the site stays
   dependency-free (no external/WASM library) and uploads stay light.

   Owner rules implemented here:
     1. EVERY photo and video is re-encoded (compressed) — even when the
        result is not smaller, compression is never skipped;
     2. «در حال فشرده‌سازی…» is shown while it runs, then a preview with a
        «لغو» button so the user can cancel before publishing;
     3. each story is capped at 30 seconds — a longer clip gets a trim UI so
        the user picks the segment BEFORE upload/compression;
     4. only stories accept video (chat and the rest stay image-only);
     5. No uncompressed submission allowed. The publish button is strictly
        tied to compression completion.
   ========================================================================== */

const IMG_EDGE = 1600;          // longest side for photos
const IMG_Q    = 0.82;          // JPEG quality (visually lossless)
const VID_EDGE = 720;           // longest side for story video
const VID_BITRATE = 1_200_000;  // ~1.2 Mbps target
const VID_MAX_S = 30;           // hard story limit: 30 seconds

const size = (b) => b > 1048576 ? (b / 1048576).toFixed(1) + ' مگابایت'
                                : Math.max(1, Math.round(b / 1024)) + ' کیلوبایت';
const isVideo = (f) => Boolean(f) && (/^video\//.test(f.type || '') || /\.(mp4|mov|m4v|webm)$/i.test(f.name || ''));

function loadImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('bad image')); };
    img.src = url;
  });
}

function videoMeta(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const v = document.createElement('video');
    v.preload = 'metadata'; v.muted = true; v.playsInline = true; v.src = url;
    v.onloadedmetadata = () => { URL.revokeObjectURL(url); resolve({ duration: v.duration || 0, w: v.videoWidth, h: v.videoHeight }); };
    v.onerror = () => { URL.revokeObjectURL(url); reject(new Error('bad video')); };
  });
}

/* ---- image: canvas resize + re-encode to JPEG (ALWAYS) ---- */
async function compressImage(file) {
  let img;
  try { img = await loadImage(file); } catch (_) { return null; }
  const scale = Math.min(1, IMG_EDGE / Math.max(img.width, img.height));
  const w = Math.round(img.width * scale);
  const h = Math.round(img.height * scale);
  const canvas = document.createElement('canvas');
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingQuality = 'high';
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h);   // flatten transparency
  ctx.drawImage(img, 0, 0, w, h);
  const blob = await new Promise(r => canvas.toBlob(r, 'image/jpeg', IMG_Q));
  if (!blob) return null;
  const name = (file.name || 'image').replace(/\.[a-z0-9]+$/i, '') + '.jpg';
  return { blob, name, kind: 'image', url: canvas.toDataURL('image/jpeg', 0.6),
           before: file.size, after: blob.size };
}

/* ---- video: trim [start,end] then re-encode (canvas.captureStream + MediaRecorder) ---- */
async function compressVideo(file, start = 0, end = Infinity, onProgress) {
  if (typeof MediaRecorder === 'undefined' || !HTMLCanvasElement.prototype.captureStream) return null;
  const url = URL.createObjectURL(file);
  const v = document.createElement('video');
  v.muted = true; v.playsInline = true; v.preload = 'auto'; v.src = url;
  try {
    await new Promise((res, rej) => { v.onloadedmetadata = res; v.onerror = () => rej(new Error('v')); });
    const dur = v.duration || 0;
    const s = Math.max(0, Math.min(start, dur));
    const e = Math.min(end == null ? dur : end, dur);
    const span = Math.max(0.2, e - s);
    if (!dur || !v.videoWidth) throw new Error('no video track');
    const scale = Math.min(1, VID_EDGE / Math.max(v.videoWidth, v.videoHeight));
    const w = Math.round(v.videoWidth * scale), h = Math.round(v.videoHeight * scale);
    const canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d');
    const mixed = new MediaStream(canvas.captureStream(30).getVideoTracks());
    try {
      const src = v.captureStream ? v.captureStream() : (v.mozCaptureStream && v.mozCaptureStream());
      if (src) src.getAudioTracks().forEach(t => mixed.addTrack(t));
    } catch (_) { /* video-only fallback */ }
    const mime = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus') ? 'video/webm;codecs=vp9,opus'
               : MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus') ? 'video/webm;codecs=vp8,opus'
               : MediaRecorder.isTypeSupported('video/webm') ? 'video/webm' : '';
    if (!mime) throw new Error('no webm');
    const rec = new MediaRecorder(mixed, { mimeType: mime, videoBitsPerSecond: VID_BITRATE, audioBitsPerSecond: 96000 });
    const chunks = []; rec.ondataavailable = ev => ev.data && ev.data.size && chunks.push(ev.data);
    const stopped = new Promise(res => { rec.onstop = res; });
    v.currentTime = s;
    await new Promise(res => { v.onseeked = res; setTimeout(res, 800); });
    rec.start(200);
    await v.play();
    const draw = () => {
      ctx.drawImage(v, 0, 0, w, h);
      onProgress && onProgress(Math.min(0.98, (v.currentTime - s) / span));
      if (v.currentTime < e && !v.ended) requestAnimationFrame(draw);
    };
    draw();
    await new Promise(res => {
      const t = setInterval(() => { if (v.currentTime >= e || v.ended) { clearInterval(t); res(); } }, 80);
      setTimeout(() => { clearInterval(t); res(); }, (span + 2) * 1000);
    });
    v.pause(); rec.stop(); await stopped;
    URL.revokeObjectURL(url);
    const blob = new Blob(chunks, { type: 'video/webm' });
    if (!blob.size) return null;
    const name = (file.name || 'story').replace(/\.[a-z0-9]+$/i, '') + '.webm';
    return { blob, name, kind: 'video', url: URL.createObjectURL(blob),
             before: file.size, after: blob.size, duration: span };
  } catch (_) {
    URL.revokeObjectURL(url);
    return null;
  }
}

async function compress(file, opts = {}) {
  const { start = 0, end = Infinity, onProgress } = opts;
  if (isVideo(file)) {
    const r = await compressVideo(file, start, end, onProgress);
    const span = (end == null || end === Infinity) ? 0 : Math.max(0, end - start);
    return r || { blob: file, name: file.name, kind: 'video',
                  url: URL.createObjectURL(file), before: file.size, after: file.size,
                  original: true, duration: span };
  }
  const r = await compressImage(file);
  return r || { blob: file, name: file.name, kind: 'image',
                url: URL.createObjectURL(file), before: file.size, after: file.size, original: true };
}

window.BazarcheCompress = { compress, compressImage, compressVideo, isVideo, videoMeta, size, VID_MAX_S };

/* ---- auto-wire any form marked data-compress ---- */
function initForm(form) {
  const input = form.querySelector('input[data-compress-input]') || form.querySelector('input[type=file]');
  if (!input) return;
  const submit = form.querySelector('[type=submit]');

  // Disable submit button by default until a compressed file is prepared
  let isCompressedReady = false;
  if (submit) {
    submit.disabled = true;
  }

  const ui = document.createElement('div');
  ui.className = 'cz';
  ui.innerHTML = `
    <p class="cz-status" data-cz-status hidden></p>
    <div class="cz-trim" data-cz-trim hidden>
      <p class="cz-trim-msg"></p>
      <video class="cz-trim-video" data-cz-trim-video muted playsinline preload="metadata" controls></video>
      <div class="cz-trim-step">
        <span class="cz-trim-label">شروع</span>
        <div class="cz-stepper">
          <button type="button" class="cz-step" data-cz-step="start" data-dir="-1" aria-label="کم کردن زمان شروع">−</button>
          <input type="number" class="cz-time nums" data-cz-start inputmode="decimal" min="0" step="0.001" value="0" aria-label="زمان شروع به ثانیه">
          <button type="button" class="cz-step" data-cz-step="start" data-dir="1" aria-label="زیاد کردن زمان شروع">+</button>
        </div>
        <span class="cz-sec">ثانیه</span>
      </div>
      <div class="cz-trim-step">
        <span class="cz-trim-label">پایان</span>
        <div class="cz-stepper">
          <button type="button" class="cz-step" data-cz-step="end" data-dir="-1" aria-label="کم کردن زمان پایان">−</button>
          <input type="number" class="cz-time nums" data-cz-end inputmode="decimal" min="0" step="0.001" value="30" aria-label="زمان پایان به ثانیه">
          <button type="button" class="cz-step" data-cz-step="end" data-dir="1" aria-label="زیاد کردن زمان پایان">+</button>
        </div>
        <span class="cz-sec">ثانیه</span>
      </div>
      <p class="cz-trim-hint">با − و + تا دهمِ ثانیه جابه‌جا شوید؛ برای دقت میلی‌ثانیه‌ای، عدد را تایپ کنید یا دکمه را نگه دارید.</p>
      <div class="cz-trim-actions">
        <button type="button" class="btn btn-primary btn-sm" data-cz-trim-ok>فشرده‌سازی و آماده‌سازی</button>
        <button type="button" class="btn btn-ghost btn-sm" data-cz-trim-cancel>لغو</button>
      </div>
    </div>
    <div class="cz-preview" data-cz-preview hidden>
      <div class="cz-media" data-cz-media></div>
      <div class="cz-meta">
        <span class="cz-size" data-cz-size></span>
        <button type="button" class="btn btn-ghost btn-sm" data-cz-cancel>لغو و انتخاب دوباره</button>
      </div>
    </div>`;
  (input.closest('label') || input).after(ui);

  const statusEl = ui.querySelector('[data-cz-status]');
  const trimEl   = ui.querySelector('[data-cz-trim]');
  const prevEl   = ui.querySelector('[data-cz-preview]');
  const mediaEl  = ui.querySelector('[data-cz-media]');
  const sizeEl   = ui.querySelector('[data-cz-size]');
  const cancelEl = ui.querySelector('[data-cz-cancel]');
  const trimVideo = ui.querySelector('[data-cz-trim-video]');
  const startIn = ui.querySelector('[data-cz-start]');
  const endIn   = ui.querySelector('[data-cz-end]');
  const trimOk  = ui.querySelector('[data-cz-trim-ok]');
  const trimCancel = ui.querySelector('[data-cz-trim-cancel]');

  const setStatus = (t) => { statusEl.textContent = t || ''; statusEl.hidden = !t; };
  const setBusy = (on) => {
    if (submit) submit.disabled = on || !isCompressedReady;
    ui.classList.toggle('is-busy', on);
  };
  const reset = () => {
    input.value = '';
    isCompressedReady = false;
    if (submit) submit.disabled = true;
    prevEl.hidden = true;
    trimEl.hidden = true;
    mediaEl.innerHTML = '';
    trimVideo.removeAttribute('src');
    setStatus('');
  };

  cancelEl.addEventListener('click', () => { reset(); setStatus('لغو شد — فایلی انتخاب نشده.'); });
  trimCancel.addEventListener('click', () => { reset(); setStatus('لغو شد — فایلی انتخاب نشده.'); });

  async function runCompress(file, start, end) {
    const video = isVideo(file);
    isCompressedReady = false;
    if (submit) submit.disabled = true;
    setBusy(true);
    setStatus(video ? 'در حال فشرده‌سازی ویدیو…' : 'در حال فشرده‌سازی تصویر…');
    try {
      const r = await compress(file, { start, end, onProgress: (p) => setStatus(
        (video ? 'در حال فشرده‌سازی ویدیو… ' : 'در حال فشرده‌سازی تصویر… ') + Math.round(p * 100) + '٪') });
      const dt = new DataTransfer();
      dt.items.add(new File([r.blob], r.name, { type: r.blob.type || (r.kind === 'video' ? 'video/webm' : 'image/jpeg') }));
      input.files = dt.files;   // swap in the compressed bytes
      
      let durField = form.querySelector('input[name="duration"]');
      if (!durField) {
        durField = document.createElement('input');
        durField.type = 'hidden'; durField.name = 'duration'; form.appendChild(durField);
      }
      durField.value = r.kind === 'video' ? String(Math.round((r.duration || 0) * 10) / 10) : '0';
      mediaEl.innerHTML = r.kind === 'video'
        ? `<video src="${r.url}" muted playsinline controls preload="metadata"></video>`
        : `<img src="${r.url}" alt="پیش‌نمایش">`;
      sizeEl.textContent = r.original
        ? `فشرده‌سازی در مرورگر ممکن نشد (${size(r.after)})`
        : `${size(r.before)} ← ${size(r.after)}`;
      trimEl.hidden = true;
      prevEl.hidden = false;
      isCompressedReady = true;
      if (submit) submit.disabled = false;
      setStatus(r.original ? 'آمادهٔ انتشار' : 'فشرده شد و آمادهٔ انتشار است.');
    } catch (_) {
      setStatus('فشرده‌سازی ناموفق بود.');
      reset();
    } finally {
      setBusy(false);
    }
  }

  const fmt = (n) => String(Math.round(n * 1000) / 1000);   // ms precision, no float dust
  const readDur = () => Number(endIn.max) || VID_MAX_S;
  function showTrim(file, meta) {
    const dur = Math.max(0.1, meta.duration);
    trimVideo.src = URL.createObjectURL(file);
    startIn.max = endIn.max = String(dur);
    startIn.value = '0';
    endIn.value = fmt(Math.min(VID_MAX_S, dur));
    ui.querySelector('.cz-trim-msg').textContent =
      `ویدیو ${Math.round(dur)} ثانیه است. هر استوری حداکثر ${VID_MAX_S} ثانیه — بازهٔ دلخواه را انتخاب کنید:`;
    trimEl.hidden = false;
    isCompressedReady = false;
    if (submit) submit.disabled = true;
    setStatus('');
  }
  const clampTrim = () => {
    let s = Number(startIn.value) || 0;
    let e = Number(endIn.value) || 0;
    const dur = readDur();
    if (s < 0) s = 0;
    if (e > dur) e = dur;
    if (e - s > VID_MAX_S) e = Math.min(dur, s + VID_MAX_S);
    if (e <= s) s = Math.max(0, e - 0.5);
    startIn.value = fmt(s); endIn.value = fmt(e);
    return { s, e };
  };
  // Typing-friendly: never move the OTHER field while the user is still typing.
  const lightClamp = () => {
    let s = Number(startIn.value) || 0;
    let e = Number(endIn.value) || 0;
    const dur = readDur();
    if (s < 0) s = 0;
    if (e > dur) e = dur;
    if (e - s > VID_MAX_S) e = Math.min(dur, s + VID_MAX_S);
    startIn.value = fmt(s); endIn.value = fmt(e);
  };
  const bindStepper = (btn, which) => {
    const dir = Number(btn.dataset.dir);
    const el = () => (which === 'start' ? startIn : endIn);
    let holdTimer = null, repeatTimer = null, held = 0, wasHeld = false;
    const tick = (coarse) => {
      let v = Number(el().value) || 0;
      const step = coarse ? 0.1 : 0.001;              // fine = 1 ms
      v = Math.max(0, Math.min(readDur(), v + dir * step));
      el().value = fmt(v);
      clampTrim();
    };
    const stopHold = () => {
      if (holdTimer) { clearTimeout(holdTimer); holdTimer = null; }
      if (repeatTimer) { clearTimeout(repeatTimer); repeatTimer = null; }
      held = 0;
    };
    const loop = () => {
      held += 1;
      tick(held <= 5);                                // few coarse hops, then 1 ms fine
      repeatTimer = setTimeout(loop, held <= 5 ? 180 : 50);
    };
    btn.addEventListener('pointerdown', () => {
      wasHeld = false; stopHold();
      holdTimer = setTimeout(() => { wasHeld = true; tick(true); loop(); }, 350);
    });
    btn.addEventListener('pointerup', stopHold);
    btn.addEventListener('pointerleave', stopHold);
    btn.addEventListener('pointercancel', stopHold);
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      if (wasHeld) { wasHeld = false; return; }        // hold already stepped
      tick(true);                                      // single tap = 0.1s
    });
  };
  ui.querySelectorAll('[data-cz-step]').forEach((b) => bindStepper(b, b.dataset.czStep));
  startIn.addEventListener('input', lightClamp);
  startIn.addEventListener('change', clampTrim);
  endIn.addEventListener('input', lightClamp);
  endIn.addEventListener('change', clampTrim);
  trimOk.addEventListener('click', () => {
    const f = input.files && input.files[0];
    if (!f) return;
    const { s, e } = clampTrim();
    runCompress(f, s, e);
  });

  input.addEventListener('change', async () => {
    const f = input.files && input.files[0];
    if (!f) { reset(); return; }
    prevEl.hidden = true; trimEl.hidden = true;
    isCompressedReady = false;
    if (submit) submit.disabled = true;
    if (isVideo(f)) {
      let meta;
      try { meta = await videoMeta(f); } catch (_) { setStatus('ویدیو خوانده نشد.'); return; }
      if (meta.duration > VID_MAX_S + 0.5) { showTrim(f, meta); return; }
      runCompress(f, 0, Math.min(meta.duration, VID_MAX_S));
      return;
    }
    if (!/^image\//.test(f.type || '') && !/\.(jpe?g|png|webp|gif|heic|heif)$/i.test(f.name || '')) {
      setStatus('فقط عکس یا فیلم معتبر.'); return;
    }
    runCompress(f, 0, Infinity);
  });

  // Guard against uncompressed submits
  form.addEventListener('submit', (e) => {
    if (!isCompressedReady && input.files && input.files.length > 0) {
      e.preventDefault();
      setStatus('لطفاً تا پایان فشرده‌سازی فایل شکیبا باشید.');
    }
  });
}

/* ---- anonymised story view stats (owner panel) ---- */
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-story-stats]');
  if (!btn) return;
  const id = btn.dataset.storyStats;
  const panel = document.querySelector(`[data-story-stats-panel="${id}"]`);
  if (!panel) return;
  if (!panel.hidden) { panel.hidden = true; return; }
  panel.hidden = false;
  panel.innerHTML = '<span class="text-muted">در حال بارگذاری…</span>';
  try {
    const r = await fetch(`/my/story/${id}/views`, { headers: { Accept: 'application/json' } });
    const j = await r.json();
    if (!j.ok) throw new Error('forbidden');
    const days = (j.per_day || []).map(d =>
      `<li><span class="nums">${d.day}</span><span class="nums">${d.n} بازدید</span></li>`).join('');
    panel.innerHTML = `
      <div class="story-stats-head"><strong class="nums">${j.total}</strong> بازدید کل
        <span class="text-muted">· ۲۴ ساعت اخیر: <span class="nums">${j.last24h}</span></span></div>
      <p class="text-sm text-muted">اطلاعات بازدیدکنندگان محرمانه است؛ فقط تعداد بازدید نمایش داده می‌شود.</p>
      <ul class="story-stats-days">${days || '<li class="text-muted">هنوز بازدیدی ثبت نشده.</li>'}</ul>`;
  } catch (_) {
    panel.innerHTML = '<span class="text-muted">آمار در دسترس نیست.</span>';
  }
});

function boot() { document.querySelectorAll('form[data-compress]').forEach(initForm); }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
