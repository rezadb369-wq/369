/* Bazarche v73 — accessible messenger polling, composer and attachments. */
const room = document.querySelector('[data-chat-room]');

if (room) {
  const tid = room.dataset.thread;
  const me = room.dataset.me || 'customer';
  const api = room.dataset.api || `/api/chat/${tid}/msgs?as=${encodeURIComponent(me)}`;
  let lastId = Number.parseInt(room.dataset.last || '0', 10) || 0;
  const newButton = document.querySelector('[data-chat-new]');
  const threadState = document.querySelector('[data-thread-status]');

  const roleLabel = { customer: 'مشتری', owner: 'مغازه‌دار', admin: 'مدیر بازارچه' };
  const nearBottom = () => room.scrollHeight - room.scrollTop - room.clientHeight < 90;
  const scrollBottom = (smooth = false) => {
    room.scrollTo({ top: room.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
    if (newButton) newButton.hidden = true;
  };
  requestAnimationFrame(() => scrollBottom(false));

  const sizeLabel = (value) => {
    const n = Number(value) || 0;
    if (n >= 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} مگابایت`;
    return `${Math.max(1, Math.round(n / 1024))} کیلوبایت`;
  };

  function attachmentNode(message) {
    if (!message.attachment_id || !message.file_url) return null;
    if (message.file_kind === 'image') {
      const link = document.createElement('a');
      link.className = 'msg-image'; link.href = message.file_url;
      link.target = '_blank'; link.rel = 'noopener';
      link.setAttribute('aria-label', `باز کردن تصویر ${message.file_name || ''}`);
      const image = document.createElement('img');
      image.src = message.file_url; image.alt = `پیوست تصویری: ${message.file_name || 'تصویر'}`;
      image.loading = 'lazy'; image.decoding = 'async';
      const caption = document.createElement('span');
      caption.textContent = message.file_name || 'تصویر';
      link.append(image, caption);
      return link;
    }
    const link = document.createElement('a');
    link.className = 'msg-file'; link.href = message.file_url; link.setAttribute('download', '');
    const fileIcon = document.createElement('span'); fileIcon.className = 'msg-file-icon';
    fileIcon.textContent = '↓'; fileIcon.setAttribute('aria-hidden', 'true');
    const meta = document.createElement('span');
    const strong = document.createElement('strong'); strong.textContent = message.file_name || 'فایل';
    const small = document.createElement('small'); small.textContent = sizeLabel(message.file_size);
    meta.append(strong, small);
    const arrow = document.createElement('span'); arrow.textContent = '↓'; arrow.setAttribute('aria-hidden', 'true');
    link.append(fileIcon, meta, arrow);
    return link;
  }

  function messageNode(message) {
    const sender = message.sender || 'customer';
    const article = document.createElement('article');
    article.className = `msg ${sender === me ? 'me' : (sender === 'admin' ? 'admin' : 'them')}`;
    article.dataset.msgId = String(message.id || 0); article.dataset.sender = sender;

    const label = document.createElement('div'); label.className = 'msg-label';
    label.textContent = roleLabel[sender] || sender;
    const bubble = document.createElement('div'); bubble.className = 'msg-bubble';
    if (message.body) {
      const text = document.createElement('div'); text.className = 'msg-text';
      text.textContent = message.body; bubble.appendChild(text);
    }
    const attachment = attachmentNode(message);
    if (attachment) bubble.appendChild(attachment);

    const meta = document.createElement('div'); meta.className = 'msg-meta';
    const time = document.createElement('time');
    time.textContent = String(message.created || '').slice(5, 16);
    const delivery = document.createElement('span'); delivery.dataset.delivery = '';
    if (sender === me) delivery.textContent = ' · ارسال شد';
    meta.append(time, delivery);
    article.append(label, bubble, meta);
    return article;
  }

  function updateRead(read = {}) {
    let peer = 0;
    if (me === 'customer') peer = Math.max(read.owner || 0, read.admin || 0);
    else if (me === 'owner') peer = Math.max(read.customer || 0, read.admin || 0);
    else peer = Math.max(read.customer || 0, read.owner || 0);
    room.querySelectorAll(`.msg.me[data-msg-id]`).forEach(message => {
      const label = message.querySelector('[data-delivery]');
      if (label) label.textContent = Number(message.dataset.msgId) <= peer ? ' · دیده شد' : ' · ارسال شد';
    });
  }

  function updateState(status) {
    if (!threadState || !status) return;
    threadState.classList.toggle('is-open', status === 'open');
    threadState.classList.toggle('is-closed', status === 'closed');
    threadState.textContent = status === 'open' ? 'گفتگو باز است' : 'گفتگو بسته است';
  }

  async function poll() {
    if (document.hidden) return;
    try {
      const url = new URL(api, location.origin);
      url.searchParams.set('after', String(lastId));
      const response = await fetch(url, { headers: { Accept: 'application/json' } });
      if (!response.ok) return;
      const data = await response.json();
      if (!data.ok) return;
      const shouldFollow = nearBottom();
      let added = 0;
      for (const message of data.msgs || []) {
        if (Number(message.id) <= lastId) continue;
        lastId = Number(message.id); room.appendChild(messageNode(message)); added += 1;
      }
      updateRead(data.read || {}); updateState(data.status);
      if (added && shouldFollow) scrollBottom(true);
      else if (added && newButton) newButton.hidden = false;
    } catch (_) {
      // Offline is recoverable: the next interval retries without breaking UI.
    }
  }

  window.setInterval(poll, 3000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) poll(); });
  newButton?.addEventListener('click', () => scrollBottom(true));

  const form = document.querySelector('[data-chat-form]');
  const composer = document.querySelector('[data-chat-compose]');
  const file = document.querySelector('[data-chat-file]');
  const preview = document.querySelector('[data-attach-preview]');
  const previewName = document.querySelector('[data-attach-name]');
  const previewSize = document.querySelector('[data-attach-size]');
  const removeFile = document.querySelector('[data-attach-remove]');
  const status = document.querySelector('[data-chat-status]');
  const send = document.querySelector('[data-chat-send]');
  const MAX_FILE = 8 * 1024 * 1024;

  const setStatus = (text) => { if (status) status.textContent = text; };
  const clearFile = () => {
    if (file) file.value = '';
    if (preview) preview.hidden = true;
    if (previewName) previewName.textContent = '';
    if (previewSize) previewSize.textContent = '';
  };
  const grow = () => {
    if (!composer) return;
    composer.style.height = 'auto';
    composer.style.height = `${Math.min(composer.scrollHeight, 120)}px`;
  };

  composer?.addEventListener('input', grow);
  composer?.addEventListener('keydown', event => {
    if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
      event.preventDefault(); form?.requestSubmit();
    }
  });
  file?.addEventListener('change', () => {
    const selected = file.files?.[0];
    if (!selected) { clearFile(); return; }
    if (selected.size > MAX_FILE) {
      clearFile(); setStatus('حجم فایل بیشتر از ۸ مگابایت است.'); return;
    }
    if (previewName) previewName.textContent = selected.name;
    if (previewSize) previewSize.textContent = sizeLabel(selected.size);
    if (preview) preview.hidden = false;
    setStatus(`فایل ${selected.name} آمادهٔ ارسال است.`);
  });
  removeFile?.addEventListener('click', () => { clearFile(); setStatus('فایل حذف شد.'); });
  form?.addEventListener('submit', event => {
    const hasText = Boolean(composer?.value.trim());
    const hasFile = Boolean(file?.files?.length);
    if (!hasText && !hasFile) {
      event.preventDefault(); setStatus('متن پیام یا فایل را وارد کنید.'); composer?.focus(); return;
    }
    form.setAttribute('aria-busy', 'true');
    if (send) send.disabled = true;
    setStatus(hasFile ? 'در حال ارسال پیام و فایل…' : 'در حال ارسال پیام…');
  });
}
