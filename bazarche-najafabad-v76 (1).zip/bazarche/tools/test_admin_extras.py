# -*- coding: utf-8 -*-
"""
Admin inbox · feature switches · QR · click tracking.

Each of these exists because something was measurably broken or missing:

  · click tracking — the /t/ endpoint existed but NOTHING called it, so
    every "phone click" stat on a live site stayed at zero forever
  · inbox — approvals were spread over nine pages, so a pending shop could
    sit unnoticed for a week
  · switches — no way to turn a whole capability off without deleting code
  · QR — hand-rolled encoder (Pydroid cannot install a QR library), so it
    must be verified against a real decoder, not by eye

    BZ=http://127.0.0.1:8080 python3 tools/test_admin_extras.py
"""

import os
import sys
import urllib.parse
import urllib.request
import urllib.error
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db      # noqa: E402
import qr      # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
KEY = db.owner_token()
TAG = "آزمون-ادمین"

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


def session():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def req(op, path, data=None):
    url = BASE + path
    if data is None:
        r = urllib.request.Request(url)
    else:
        r = urllib.request.Request(
            url, data=urllib.parse.urlencode(data, doseq=True).encode())
        r.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        res = op.open(r, timeout=25)
        return res.getcode(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


print(f"\n\033[1m\033[36mآزمون صندوق، کلیدها، QR و رهگیری — {BASE}\033[0m")

head("آماده‌سازی")
db.rate_clear()
for b in db.businesses(status=None):
    if TAG in (b.get("tags") or ""):
        db.delete_business(b["id"])
for t in db.tickets():
    if "زآزمون" in t["subject"]:
        db.delete_ticket(t["id"])

cat = db.categories()[0]["slug"]
BID = db.save_business({"name": "مغازهٔ ادمین آزمون", "cat_slug": cat,
                        "status": "published", "phone": "09131114444",
                        "whatsapp": "989131114444",
                        # coordinates matter: without them the directions
                        # link is not rendered at all, and an earlier version
                        # of this test failed on its own missing fixture
                        "lat": 32.6340, "lng": 51.3670,
                        "tags": TAG})
SLUG = db.business(bid=BID)["slug"]
A = session()
check("کسب‌وکار آزمایشی ساخته شد", bool(BID), "")

# ---------------------------------------------------------------- tracking
head("۱) رهگیری کلیک — قبلاً هیچ‌جا صدا زده نمی‌شد")


def ev(kind):
    r = db._one("SELECT SUM(n) s FROM events WHERE biz_id=? AND kind=?",
                (BID, kind))
    return (r["s"] or 0) if r else 0


code, html = req(A, f"/b/{SLUG}")
check("صفحهٔ مغازه باز می‌شود", code == 200, f"code={code}")
check("دکمهٔ تماس برچسب رهگیری دارد", 'data-track="phone"' in html, "")
check("دکمهٔ ذخیره در مخاطبین هم دارد", 'data-track="save"' in html, "")
check("لینک مسیریابی هم دارد", 'data-track="route"' in html, "")

for kind in ("phone", "whatsapp", "route", "save", "share"):
    before = ev(kind)
    code, _ = req(A, f"/t/{SLUG}/{kind}", {})
    check(f"رویداد «{kind}» ثبت شد", ev(kind) == before + 1,
          f"{before} -> {ev(kind)}")

code, _ = req(A, f"/t/{SLUG}/hack", {})
# an unrecognised kind is not matched by the tracking route and falls
# through to the admin gate, which refuses with 403. Either answer is a
# refusal; what matters is that nothing is written.
before_junk = db._one("SELECT COUNT(*) c FROM events WHERE kind='hack'")["c"]
check("نوع رویداد نامعتبر رد می‌شود", code in (403, 404), f"code={code}")
check("و هیچ رویداد جعلی ثبت نمی‌شود", before_junk == 0, str(before_junk))
code, _ = req(A, "/t/does-not-exist/phone", {})
check("مغازهٔ ناموجود خطا نمی‌دهد", code in (204, 404), f"code={code}")

# ------------------------------------------------------------------ inbox
head("۲) صندوق درخواست‌ها")
ADM = session()
code, html = req(ADM, "/panel/inbox")
check("بدون کلید ۴۰۳ است", code == 403, f"code={code}")

n0 = db.inbox()["total"]
PB = db.save_business({"name": "زآزمون منتظر تأیید", "cat_slug": cat,
                       "status": "pending", "phone": "09130009999", "tags": TAG})
db.create_ticket("زآزمون تیکت", "متن آزمایشی برای صندوق", name="کاسب")
inb = db.inbox()
check("کسب‌وکار در انتظار وارد صندوق شد", inb["total"] >= n0 + 2,
      f"{n0} -> {inb['total']}")
keys = [g["key"] for g in inb["groups"]]
check("گروه کسب‌وکار هست", "business" in keys, str(keys))
check("گروه تیکت هست", "ticket" in keys, str(keys))

code, html = req(ADM, f"/panel/inbox?key={urllib.parse.quote(KEY)}")
check("صفحهٔ صندوق باز می‌شود", code == 200, f"code={code}")
check("مورد در انتظار روی صفحه دیده می‌شود", "زآزمون منتظر تأیید" in html, "")
check("تیکت هم دیده می‌شود", "زآزمون تیکت" in html, "")
check("لینک مستقیم به مدیریت دارد", "/panel/business/" in html, "")

# approving must clear it from the inbox
db._run("UPDATE businesses SET status='published' WHERE id=?", (PB,))
check("پس از تأیید، از صندوق خارج می‌شود",
      not any("زآزمون منتظر" in i["title"]
              for g in db.inbox()["groups"] for i in g["items"]), "")

# ------------------------------------------------------------- switches
head("۳) کلیدهای قابلیت")
code, html = req(ADM, f"/panel/features?key={urllib.parse.quote(KEY)}")
check("صفحهٔ قابلیت‌ها باز می‌شود", code == 200, f"code={code}")
check("کلید چانه‌زنی هست", 'name="haggle_enabled"' in html, "")
check("کلید نوبت‌دهی هست", 'name="booking_enabled"' in html, "")

# The POST writes "0" for every key NOT present, which is correct for a
# checkbox form -- but it means a partial post silently switches the whole
# site off. An earlier version of this test did exactly that and knocked
# out owner_login, reg_open and claims for every later suite. So: capture
# the real state, post it back in full with one key flipped, restore after.
import views_panel2 as _P2
ALL_KEYS = [k for _t, items in _P2.SITE_FEATURES for k, *_ in items]
saved_all = {k: db.get_settings().get(k, "1") for k in ALL_KEYS}

def post_features(**flip):
    """Post every switch at its saved value, with `flip` applied."""
    state = dict(saved_all)
    state.update(flip)
    data = {"key": KEY}
    for k, v in state.items():
        if v == "1":
            data[k] = "1"          # unchecked boxes simply are not sent
    return req(ADM, "/panel/features", data)

code, _ = post_features(haggle_enabled="0")
check("خاموش کردن ذخیره شد",
      db.get_settings().get("haggle_enabled") == "0",
      db.get_settings().get("haggle_enabled"))
check("و قابلیت واقعاً غیرفعال شد",
      db.haggle_settings()["enabled"] is False, "")

IID = db.save_item({"biz_id": BID, "kind": "product", "title": "کالای آزمون کلید",
                    "price": 500000, "price_type": "fixed", "available": 1,
                    "haggle": 1, "floor_price": 450000})
check("کالای چانه‌زنی‌دار هم بسته می‌شود",
      db.haggle_allowed(db.item(IID)) is False, "")
code, _ = req(A, f"/haggle/{IID}")
check("و صفحهٔ پیشنهاد قیمت باز نمی‌شود",
      "چانه‌زنی ندارد" in _ or code == 404, f"code={code}")

code, _ = post_features(haggle_enabled="1")
check("روشن کردن دوباره کار می‌کند",
      db.haggle_settings()["enabled"] is True, "")
check("و کالا بدون تغییر برگشت",
      db.haggle_allowed(db.item(IID)) is True, "داده از دست رفت!")
for k, v in saved_all.items():
    db.set_setting(k, v)

code, _ = req(session(), "/panel/features", {"haggle_enabled": "1"})
check("بدون کلید نمی‌شود تغییر داد", code == 403, f"code={code}")

# ---------------------------------------------------------------- QR code
head("۴) بارکد QR")
code, svg = req(A, f"/qr/{SLUG}.svg")
check("بارکد ساخته می‌شود", code == 200, f"code={code}")
check("خروجی SVG است", svg.lstrip().startswith("<svg"), svg[:40])
check("محتوا دارد", "<path" in svg and len(svg) > 500, str(len(svg)))

code2, hdrs = req(A, f"/qr/{SLUG}.svg?size=256")
check("اندازهٔ دلخواه کار می‌کند", 'width="256"' in hdrs, "")
code3, _ = req(A, "/qr/does-not-exist.svg")
check("مغازهٔ ناموجود ۴۰۴ می‌دهد", code3 == 404, f"code={code3}")

# the encoder is hand-written; prove it against a real decoder
try:
    import cv2
    import numpy as np
    urls = [f"http://x/b/{SLUG}", "https://bazarche.ir/b/a-very-long-shop-slug-here"]
    good = 0
    for u in urls:
        m = qr.matrix(u)
        n = len(m)
        S, Q = 10, 4
        img = np.full(((n + 2 * Q) * S, (n + 2 * Q) * S), 255, dtype="uint8")
        for r in range(n):
            for c in range(n):
                if m[r][c]:
                    img[(r + Q) * S:(r + Q + 1) * S,
                        (c + Q) * S:(c + Q + 1) * S] = 0
        txt, _pts, _ = cv2.QRCodeDetector().detectAndDecode(img)
        good += (txt == u)
    check(f"بارکد با دیکدر واقعی خوانده می‌شود ({good}/{len(urls)})",
          good == len(urls), "خوانده نشد")
except ImportError:
    print("     (opencv نصب نیست — بررسی دیکد رد شد)")

try:
    qr.matrix("x" * 400)
    check("متن بلندتر از ظرفیت، خطای روشن می‌دهد", False, "خطا نداد")
except ValueError:
    check("متن بلندتر از ظرفیت، خطای روشن می‌دهد", True, "")

# ------------------------------------------------------------- owner badges
head("۵) شمارندهٔ اعلان مغازه‌دار")
o = db.owner_by_phone("09125558888", create=True)
db._run("UPDATE businesses SET owner_id=? WHERE id=?", (o["id"], BID))
b0 = db.owner_badges(o["id"])
db.add_booking(BID, "مشتری آزمون", "09120000000", "1405-06-10", "10:00")
b1 = db.owner_badges(o["id"])
check("نوبت تازه شمرده می‌شود", b1["bookings"] == b0["bookings"] + 1,
      f"{b0['bookings']} -> {b1['bookings']}")
check("مجموع هم بالا رفت", b1["total"] > b0["total"], "")

tid, _tok = db.create_ticket("زآزمون پاسخ", "متن", owner_id=o["id"])
db.ticket_reply(tid, "پاسخ مدیر", side="admin")
check("تیکت پاسخ‌داده‌شده شمرده می‌شود",
      db.owner_badges(o["id"])["tickets"] == 1, "")

head("۶) پاک‌سازی")
for b in db.businesses(status=None):
    if TAG in (b.get("tags") or ""):
        db.delete_business(b["id"])
for t in db.tickets():
    if "زآزمون" in t["subject"]:
        db.delete_ticket(t["id"])
oo = db.owner_by_phone("09125558888")
if oo:
    db.delete_owner(oo["id"])
db.rate_clear()
check("داده‌های آزمایشی حذف شدند", db.business(bid=BID) is None, "")

print(f"\n\033[1m{'='*58}\033[0m")
if bad_n == 0:
    print(f"\033[1m\033[32m  همه موفق — {ok_n} آزمون، ۰ ناموفق\033[0m")
else:
    print(f"\033[1m\033[31m  {ok_n} موفق، {bad_n} ناموفق\033[0m")
    for f in FAILS:
        print(f"    • {f}")
print(f"\033[1m{'='*58}\033[0m\n")
sys.exit(1 if bad_n else 0)
