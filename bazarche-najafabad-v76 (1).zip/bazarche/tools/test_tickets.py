# -*- coding: utf-8 -*-
"""
تیکت پشتیبانی — a real two-way conversation with the admin.

What must hold:
  · a shopkeeper can open a ticket and see their own replies
  · the admin sees it, can answer, and the status follows automatically
  · one shopkeeper can never read or touch another's ticket
  · unread flags flip to the correct side
  · closing works from both ends

    BZ=http://127.0.0.1:8080 python3 tools/test_tickets.py
"""

import os
import sys
import urllib.parse
import urllib.request
import urllib.error
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
KEY = db.owner_token()
PH_A, PH_B = "09125557001", "09125557002"

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


def session():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def req(op, path, data=None):
    url = BASE + path
    if data is None:
        r = urllib.request.Request(url)
    else:
        r = urllib.request.Request(
            url, data=urllib.parse.urlencode(data, doseq=True).encode())
        r.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        res = op.open(r, timeout=25)
        return res.getcode(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


def login(op, phone):
    req(op, "/login", {"phone": phone})
    row = db._one("SELECT code FROM otp WHERE phone=?", (db.norm_phone(phone),))
    if not row:
        return False
    c, _ = req(op, "/login/verify", {"phone": phone, "code": row["code"]})
    return c in (200, 303)


print(f"\n\033[1m\033[36mآزمون تیکت پشتیبانی — {BASE}\033[0m")

head("آماده‌سازی")
db.rate_clear()
db._run("DELETE FROM otp")
for t in db.tickets():
    db.delete_ticket(t["id"])
for ph in (PH_A, PH_B):
    o = db.owner_by_phone(ph)
    if o:
        db.delete_owner(o["id"])
for b in db.businesses(status=None):
    if "تیکت آزمون" in b["name"]:
        db.delete_business(b["id"])

oa = db.owner_by_phone(PH_A, create=True)
ob = db.owner_by_phone(PH_B, create=True)
cat = db.categories()[0]["slug"]
BID = db.save_business({"name": "مغازهٔ تیکت آزمون", "cat_slug": cat,
                        "status": "published", "phone": "09131110000",
                        "owner_id": oa["id"]})
check("آماده شد", bool(BID and oa and ob), "")

A, B, ADM = session(), session(), session()
check("ورود مالک یک", login(A, PH_A), "")
check("ورود مالک دو", login(B, PH_B), "")

head("۱) ساخت تیکت")
code, html = req(A, "/my/tickets")
check("صفحهٔ پشتیبانی باز می‌شود", code == 200, f"code={code}")
check("فرم تیکت جدید هست", 'name="subject"' in html, "")

code, _ = req(A, "/my/tickets", {
    "subject": "زوپالف واریزی مرداد", "topic": "payment", "biz_id": str(BID),
    "body": "کارت به کارت کردم ۱۲۰۰۰۰۰ تومان، لطفاً قابلیت‌ها را باز کنید."})
rows = db.tickets(owner_id=oa["id"])
check("تیکت ساخته شد", len(rows) == 1, str(len(rows)))
TID = rows[0]["id"] if rows else 0
check("وضعیت اولیه «باز» است", rows and rows[0]["status"] == "open",
      rows[0]["status"] if rows else "")
check("برای مدیر خوانده‌نشده علامت خورد",
      rows and rows[0]["unread_admin"] == 1, "")
check("موضوع درست ثبت شد", rows and rows[0]["topic"] == "payment", "")
check("به کسب‌وکار وصل شد", rows and rows[0]["biz_id"] == BID, "")

head("۲) اعتبارسنجی")
n0 = len(db.tickets())
req(A, "/my/tickets", {"subject": "x", "body": "y"})
check("عنوان و متن کوتاه رد می‌شود", len(db.tickets()) == n0, "")

head("۳) خواندن تیکت خودم")
code, html = req(A, f"/my/ticket/{TID}")
check("تیکت باز می‌شود", code == 200, f"code={code}")
check("متن پیام دیده می‌شود", "کارت به کارت" in html, "")
check("عنوان دیده می‌شود", "زوپالف واریزی مرداد" in html, "")

head("۴) جداسازی بین کاربران")
code, html = req(B, f"/my/ticket/{TID}")
check("مالک دیگر تیکت من را نمی‌بیند (۴۰۳)", code == 403, f"code={code}")
code, html = req(B, "/my/tickets")
# NB: match a unique subject, not a phrase that also appears in the form's
# own placeholder text — the first version of this check failed on its own
# example copy rather than on a real leak.
check("و در فهرست خودش هم نیست", "زوپالف واریزی مرداد" not in html, "")
code, _ = req(B, f"/my/ticket/{TID}", {"body": "دخالت", "action": "reply"})
msgs = db.ticket_msgs(TID)
check("و نمی‌تواند در آن پیام بگذارد", len(msgs) == 1, str(len(msgs)))

head("۵) پنل مدیر")
code, html = req(ADM, f"/panel/tickets?key={urllib.parse.quote(KEY)}")
check("فهرست تیکت‌ها باز می‌شود", code == 200, f"code={code}")
check("تیکت در فهرست هست", "زوپالف واریزی مرداد" in html, "")
code, html = req(ADM, f"/panel/tickets")
check("بدون کلید ۴۰۳ است", code == 403, f"code={code}")

code, html = req(ADM, f"/panel/ticket/{TID}?key={urllib.parse.quote(KEY)}")
check("جزئیات تیکت باز می‌شود", code == 200, f"code={code}")
check("شمارهٔ تماس کاربر دیده می‌شود", db.norm_phone(PH_A) in html, "")

head("۶) پاسخ مدیر")
code, _ = req(ADM, f"/panel/ticket/{TID}", {
    "key": KEY, "action": "reply", "status": "open", "priority": "high",
    "body": "سلام، دریافت شد. تا امشب باز می‌کنم."})
t = db.ticket(tid=TID)
msgs = db.ticket_msgs(TID)
check("پیام مدیر ثبت شد", len(msgs) == 2, str(len(msgs)))
check("و از سمت admin است", msgs[-1]["side"] == "admin", msgs[-1]["side"])
check("وضعیت خودکار «پاسخ داده شد» شد", t["status"] == "answered", t["status"])
check("برای کاربر خوانده‌نشده علامت خورد", t["unread_user"] == 1, "")
check("و علامت مدیر پاک شد", t["unread_admin"] == 0, "")
check("اولویت ذخیره شد", t["priority"] == "high", t["priority"])

head("۷) کاربر پاسخ را می‌بیند و جواب می‌دهد")
code, html = req(A, f"/my/ticket/{TID}")
check("پاسخ مدیر روی صفحهٔ کاربر هست", "تا امشب باز می‌کنم" in html, "")
check("و علامت خوانده‌نشدهٔ کاربر پاک شد",
      db.ticket(tid=TID)["unread_user"] == 0, "")

code, _ = req(A, f"/my/ticket/{TID}", {"action": "reply", "body": "ممنون، منتظرم."})
t = db.ticket(tid=TID)
check("پاسخ کاربر ثبت شد", len(db.ticket_msgs(TID)) == 3, "")
check("وضعیت دوباره «باز» شد", t["status"] == "open", t["status"])
check("و مدیر خبردار شد", t["unread_admin"] == 1, "")

head("۸) بستن تیکت")
code, _ = req(A, f"/my/ticket/{TID}", {"action": "close"})
check("کاربر می‌تواند تیکت را ببندد",
      db.ticket(tid=TID)["status"] == "closed", db.ticket(tid=TID)["status"])
code, html = req(A, f"/my/ticket/{TID}")
check("پس از بستن، فرم پاسخ برداشته می‌شود",
      'name="body"' not in html, "فرم هنوز هست")

head("۹) فیلتر و جست‌وجوی مدیر")
db.create_ticket("مشکل فنی", "سایت باز نمی‌شود", name="کاربر دو",
                 owner_id=ob["id"], topic="bug")
code, html = req(ADM, f"/panel/tickets?key={urllib.parse.quote(KEY)}&status=open")
check("فیلتر «باز» فقط تیکت باز را می‌آورد",
      "مشکل فنی" in html and "زوپالف واریزی مرداد" not in html, "")
code, html = req(ADM, f"/panel/tickets?key={urllib.parse.quote(KEY)}"
                      f"&q={urllib.parse.quote('زوپالف')}")
check("جست‌وجو کار می‌کند", "زوپالف واریزی مرداد" in html, "")

head("۱۰) آمار")
st = db.ticket_stats()
check("آمار جمع می‌زند", st["total"] == 2, str(st))
check("تیکت بسته شمرده می‌شود", st["closed"] == 1, str(st["closed"]))

head("۱۱) حذف توسط مدیر")
code, _ = req(ADM, f"/panel/ticket/{TID}", {"key": KEY, "action": "delete"})
check("مدیر می‌تواند حذف کند", db.ticket(tid=TID) is None, "")
check("و پیام‌هایش هم آبشاری رفتند",
      db._one("SELECT 1 FROM ticket_msgs WHERE ticket_id=?", (TID,)) is None, "")

head("۱۲) پاک‌سازی")
for t in db.tickets():
    db.delete_ticket(t["id"])
db.delete_business(BID)
for ph in (PH_A, PH_B):
    o = db.owner_by_phone(ph)
    if o:
        db.delete_owner(o["id"])
db.rate_clear()
check("داده‌های آزمایشی حذف شدند", not db.tickets(), "")

print(f"\n\033[1m{'='*58}\033[0m")
if bad_n == 0:
    print(f"\033[1m\033[32m  همه موفق — {ok_n} آزمون، ۰ ناموفق\033[0m")
else:
    print(f"\033[1m\033[31m  {ok_n} موفق، {bad_n} ناموفق\033[0m")
    for f in FAILS:
        print(f"    • {f}")
print(f"\033[1m{'='*58}\033[0m\n")
sys.exit(1 if bad_n else 0)
