# -*- coding: utf-8 -*-
"""
Proof that feature gating is real, not decorative.

The rule under test: the blurred UI is a courtesy, the server is the wall.
Every locked capability must be refused even when the request is crafted by
hand, and every unlock must take effect immediately.

    python3 run.py
    cd tools && BZ=http://127.0.0.1:8080 python3 test_gates.py
"""

import os
import sys
import urllib.parse
import urllib.request
import urllib.error
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
sys.path.insert(0, HERE)
import db  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
KEY = db.owner_token()
PH = "09125550001"

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


def session():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def req(op, path, data=None):
    url = BASE + path
    if data is None:
        r = urllib.request.Request(url)
    else:
        r = urllib.request.Request(
            url, data=urllib.parse.urlencode(data, doseq=True).encode())
        r.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        res = op.open(r, timeout=25)
        return res.getcode(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


def login(op, phone):
    req(op, "/login", {"phone": phone})
    row = db._one("SELECT code FROM otp WHERE phone=?", (db.norm_phone(phone),))
    if not row:
        return False
    c, _ = req(op, "/login/verify", {"phone": phone, "code": row["code"]})
    return c in (200, 303)


print(f"\n\033[1m\033[36mآزمون قفل قابلیت‌ها — {BASE}\033[0m")

# ---------------------------------------------------------------- fixture
head("آماده‌سازی")
db._run("DELETE FROM otp")
db.rate_clear()
_o = db.owner_by_phone(PH)
if _o:
    db.delete_owner(_o["id"])
for b in db.businesses(status=None):
    if b["name"] == "مغازهٔ قفل آزمون":
        db.delete_business(b["id"])

owner = db.owner_by_phone(PH, create=True)
cat = db.categories()[0]["slug"]
BID = db.save_business({"name": "مغازهٔ قفل آزمون", "cat_slug": cat,
                        "phone": PH, "status": "published",
                        "owner_id": owner["id"]})
SLUG = db.business(bid=BID)["slug"]
# put this shop OUTSIDE the founder window so it starts genuinely locked
_saved_limit = db.get_settings().get("founder_limit", "100")
db.set_setting("founder_limit", "0")
db.set_manual_grants(BID, [])
check("کسب‌وکار آزمایشی ساخته شد", bool(BID), f"id={BID}")

A = session()
check("ورود صاحب کسب‌وکار", login(A, PH), "")

# ---------------------------------------------------------------- defaults
head("۱) پلن رایگان عادی — همه‌چیز قفل است")
acc = db.access(BID)
check("عضو بنیان‌گذار نیست", acc["founder"] is False, str(acc["founder"]))
check("هیچ قابلیتی باز نیست", len(acc["keys"]) == 0, str(sorted(acc["keys"])))
check("سقف کالا محدود است", acc["max_items"] == 3, str(acc["max_items"]))
check("سقف عکس محدود است", acc["max_photos"] == 3, str(acc["max_photos"]))
for key in ("booking", "catalog", "stats", "gallery", "reply"):
    check(f"can({key}) نادرست است", db.can(BID, key) is False, "")

# ---------------------------------------------------------------- ui blur
head("۲) قفل در رابط کاربری دیده می‌شود ولی پنهان نیست")
code, html = req(A, "/my/plan")
check("صفحهٔ اشتراک باز می‌شود", code == 200, f"code={code}")
check("بخش «قفل» نمایش داده می‌شود", "unlock-row" in html, "")
check("نام قابلیت قفل‌شده دیده می‌شود", "نوبت‌دهی آنلاین" in html, "")
check("دکمهٔ «باز کن» هست", "باز کن" in html, "")
check("دلیل ارزش قابلیت نوشته شده",
      "دفتر نوبت کاغذی حذف می‌شود" in html, "")

code, html = req(A, "/my")
check("قفل در منوی کناری با آیکون نشان داده می‌شود",
      'class="is-locked"' in html, "")

# ---------------------------------------------------------------- server wall
head("۳) دیوار سمت سرور — درخواست دستی هم رد می‌شود")
n0 = db.items_count(BID)
code, html = req(A, f"/my/catalog/{BID}/item/new",
                 {"title": "کالای قفل", "kind": "product",
                  "price": "1000", "price_type": "fixed"})
check("افزودن کالا با قفل کاتالوگ انجام نشد",
      db.items_count(BID) == n0, f"{n0} -> {db.items_count(BID)}")
check("پیام قفل به فروشنده نشان داده شد",
      "قفل است" in html, "")

rid = db.add_review_full(BID, "مشتری", 5, "نظر آزمایشی برای سنجش قفل پاسخ.",
                         auto_approve=True)
code, html = req(A, f"/my/review/{rid}", {"reply": "پاسخ غیرمجاز"})
r = [x for x in db.reviews(biz_id=BID) if x["id"] == rid][0]
check("پاسخ به نظر با قفل reply ثبت نشد", not r["reply"], repr(r["reply"]))

qid = db.add_question(BID, "پرسنده", "سؤال آزمایشی؟", auto_publish=True)
code, html = req(A, f"/my/question/{qid}", {"answer": "پاسخ غیرمجاز"})
check("پاسخ به پرسش با قفل qa ثبت نشد",
      not db.question(qid)["answer"], repr(db.question(qid)["answer"]))

db.add_booking(BID, "مشتری", PH, "2026-10-01", "10:00")
kid = [k for k in db.bookings() if k["biz_id"] == BID][0]["id"]
code, html = req(A, f"/my/booking/{kid}", {"status": "confirmed"})
k = [x for x in db.bookings() if x["id"] == kid][0]
check("تغییر وضعیت نوبت با قفل booking انجام نشد",
      k["status"] == "new", k["status"])

req(A, f"/my/business/{BID}", {
    "name": "مغازهٔ قفل آزمون", "cat_slug": cat, "descr": "توضیح",
    "phone": PH, "address": "نشانی", "whatsapp": "", "tags": "",
    "instagram": "https://instagram.com/hack", "telegram": "", "website": "",
    "lat": "", "lng": "", "booking_on": "on"})
fresh = db.business(bid=BID)
check("لینک اینستاگرام با قفل social ذخیره نشد",
      not fresh["instagram"], repr(fresh["instagram"]))
check("نوبت‌دهی با قفل booking روشن نشد",
      fresh["booking_on"] == 0, str(fresh["booking_on"]))

# ---------------------------------------------------------------- admin key
head("۴) کلید مدیر — باز کردن دستی")
adm = session()
code, html = req(adm, f"/panel/unlocks?key={urllib.parse.quote(KEY)}")
check("صفحهٔ کلید قابلیت‌ها باز می‌شود", code == 200, f"code={code}")
check("کسب‌وکار آزمایشی در فهرست هست", "مغازهٔ قفل آزمون" in html, "")
code, _ = req(adm, "/panel/unlocks")
check("بدون کلید ۴۰۳ می‌دهد", code == 403, f"code={code}")

req(adm, f"/panel/unlock/{BID}",
    {"key": KEY, "action": "save", "feat": ["catalog", "reply"]})
check("کاتالوگ با کلید مدیر باز شد", db.can(BID, "catalog"), "")
check("پاسخ به نظر باز شد", db.can(BID, "reply"), "")
check("بقیه همچنان قفل است", not db.can(BID, "booking"), "")
check("منبع دسترسی «دستی» ثبت شد",
      db.access(BID)["source"].get("catalog") == "manual",
      str(db.access(BID)["source"].get("catalog")))

n0 = db.items_count(BID)
req(A, f"/my/catalog/{BID}/item/new",
    {"title": "کالای مجاز", "kind": "product", "price": "1000",
     "price_type": "fixed"})
check("حالا افزودن کالا کار می‌کند", db.items_count(BID) == n0 + 1,
      f"{n0} -> {db.items_count(BID)}")

req(A, f"/my/review/{rid}", {"reply": "پاسخ مجاز"})
r = [x for x in db.reviews(biz_id=BID) if x["id"] == rid][0]
check("حالا پاسخ به نظر ثبت می‌شود", r["reply"] == "پاسخ مجاز", repr(r["reply"]))

req(adm, f"/panel/unlock/{BID}", {"key": KEY, "action": "all"})
check("«باز کردن همه» همهٔ قابلیت‌ها را داد",
      len(db.access(BID)["keys"]) == len(db.FEATURES),
      f"{len(db.access(BID)['keys'])}/{len(db.FEATURES)}")

req(adm, f"/panel/unlock/{BID}", {"key": KEY, "action": "none"})
check("«بستن همه» همه را پس گرفت",
      len(db.access(BID)["keys"]) == 0, str(len(db.access(BID)["keys"])))

# ---------------------------------------------------------------- founder
head("۵) پنجرهٔ عضویت بنیان‌گذار")
db.set_setting("founder_limit", "10000")   # everyone is a founder
acc = db.access(BID)
check("حالا عضو بنیان‌گذار است", acc["founder"] is True, "")
check("قابلیت‌های بنیان‌گذار باز شد",
      set(db.FOUNDER_FEATURES).issubset(acc["keys"]),
      str(sorted(acc["keys"])))
check("قابلیت‌های پولی همچنان قفل است",
      not db.can(BID, "banner"), "")
check("سقف بنیان‌گذار اعمال شد", acc["max_items"] == 10, str(acc["max_items"]))
check("منبع دسترسی «بنیان‌گذار» است",
      acc["source"].get("booking") == "founder",
      str(acc["source"].get("booking")))

req(A, f"/my/business/{BID}", {
    "name": "مغازهٔ قفل آزمون", "cat_slug": cat, "descr": "توضیح",
    "phone": PH, "address": "نشانی", "whatsapp": "", "tags": "",
    "instagram": "https://instagram.com/ok", "telegram": "", "website": "",
    "lat": "", "lng": "", "booking_on": "on"})
fresh = db.business(bid=BID)
check("حالا لینک اینستاگرام ذخیره می‌شود",
      fresh["instagram"] == "https://instagram.com/ok", repr(fresh["instagram"]))
check("حالا نوبت‌دهی روشن می‌شود", fresh["booking_on"] == 1, "")

db.set_setting("founder_limit", "0")
check("خارج از پنجره، دوباره قفل می‌شود",
      not db.can(BID, "booking"), "")

# ---------------------------------------------------------------- plan
head("۶) پلن پولی قابلیت می‌دهد")
sid, _m = db.request_subscription(BID, "plus", "TEST")
db.activate_subscription(sid)
acc = db.access(BID)
check("پلن حرفه‌ای فعال شد", acc["paid"] is True, str(acc["plan_name"]))
check("قابلیت‌های پلن باز شد", db.can(BID, "booking") and db.can(BID, "stats"), "")
check("منبع دسترسی «پلن» است",
      acc["source"].get("booking") == "plan", str(acc["source"].get("booking")))
check("سقف پلن اعمال شد", acc["max_items"] == 60, str(acc["max_items"]))
check("قابلیت خارج از پلن قفل ماند", not db.can(BID, "banner"), "")

db.cancel_subscription(sid)
check("با لغو اشتراک، قابلیت‌ها پس گرفته شد",
      not db.can(BID, "booking"), "")

# ---------------------------------------------------------------- priority
head("۷) اولویت منابع دسترسی")
db.set_manual_grants(BID, ["banner"])
db.set_setting("founder_limit", "10000")
acc = db.access(BID)
check("دستی و بنیان‌گذار با هم جمع می‌شوند",
      db.can(BID, "banner") and db.can(BID, "booking"), "")
check("منبع بنر «دستی» می‌ماند",
      acc["source"]["banner"] == "manual", acc["source"]["banner"])
db.set_setting("founder_limit", "0")
check("پس از بستن پنجره، اعطای دستی باقی می‌ماند",
      db.can(BID, "banner"), "")

# ------------------------------------------------ newly-applied gates (v5)
head("۹) قفل روی صفحه‌های واقعی پنل فروشنده")
db.set_setting("founder_limit", "0")
db.set_manual_grants(BID, [])

# Each page must render 200 (never a dead end) AND carry the blur wrapper.
for path, key, label in (("/my/reviews", "reply", "نظرات"),
                         ("/my/bookings", "booking", "نوبت‌ها"),
                         ("/my/questions", "qa", "پرسش و پاسخ"),
                         (f"/my/stats/{BID}", "stats", "آمار")):
    code, html = req(A, path)
    check(f"{label}: صفحه باز می‌شود (بن‌بست نیست)", code == 200, f"code={code}")
    check(f"{label}: محتوا تار و قفل‌دار است",
          f'data-locked="{key}"' in html, "بدون پوشش قفل")
    check(f"{label}: دکمهٔ ارتقا در دسترس است",
          'href="/pricing"' in html, "")

# The nag banner must not appear while the answering itself is locked.
code, html = req(A, "/my/questions")
check("وقتی پاسخ قفل است، هشدار «پرسش بی‌پاسخ» نشان داده نمی‌شود",
      "پرسش بی‌پاسخ دارید" not in html, "")

head("۱۰) باز کردن قفل، تاری را بلافاصله برمی‌دارد")
db.set_manual_grants(BID, ["reply", "booking", "qa", "stats"])
for path, key, label in (("/my/reviews", "reply", "نظرات"),
                         ("/my/bookings", "booking", "نوبت‌ها"),
                         ("/my/questions", "qa", "پرسش و پاسخ"),
                         (f"/my/stats/{BID}", "stats", "آمار")):
    code, html = req(A, path)
    check(f"{label}: پس از باز کردن، تاری برداشته شد",
          code == 200 and f'data-locked="{key}"' not in html, f"code={code}")
db.set_manual_grants(BID, [])

head("۱۱) خروجی اکسل — قابلیت export")
code, html = req(A, "/my")
check("داشبورد جعبهٔ خروجی را نشان می‌دهد", "خروجی اکسل" in html, "")
check("و آن را قفل نشان می‌دهد", 'data-locked="export"' in html, "")
code, body = req(A, "/my/export?kind=customers")
check("دانلود قفل‌شده فایل نمی‌دهد", "نام,تلفن" not in body, body[:60])
check("و دلیلش را می‌گوید", "قفل" in body or code in (302, 303), f"code={code}")

db.grant_feature(BID, "export")
code, body = req(A, "/my/export?kind=customers")
check("پس از باز کردن، فایل واقعی دانلود می‌شود",
      code == 200 and body.startswith("\ufeff"), f"code={code} {body[:40]}")
code, body = req(A, "/my/export?kind=items")
check("خروجی کاتالوگ هم کار می‌کند",
      code == 200 and "عنوان" in body, f"code={code}")
code, body = req(A, "/my/export?kind=../../etc/passwd")
check("نوع نامعتبر به «مشتریان» برمی‌گردد و نشت نمی‌دهد",
      code == 200 and "root:" not in body, f"code={code}")
db.revoke_feature(BID, "export")

head("۱۲) جایگاه ویژه و صفحهٔ نخست واقعاً اعمال می‌شوند")
db._run("UPDATE businesses SET featured=1 WHERE id=?", (BID,))
db.set_manual_grants(BID, [])
rows = db.apply_promotion(db.businesses(status="published"))
mine = next((r for r in rows if r["id"] == BID), None)
check("نشان «ویژه» بدون پرداخت برداشته می‌شود",
      mine is not None and not mine["featured"], str(mine and mine["featured"]))
check("و در صفحهٔ نخست جای ویژه نمی‌گیرد",
      mine is not None and not mine["on_homepage"], "")

db.set_manual_grants(BID, ["featured", "homepage"])
rows = db.apply_promotion(db.businesses(status="published"))
mine = next((r for r in rows if r["id"] == BID), None)
check("پس از باز کردن، نشان «ویژه» برمی‌گردد",
      mine is not None and bool(mine["featured"]), "")
check("و در فهرست صفحهٔ نخست می‌آید",
      any(b["id"] == BID for b in db.homepage_businesses(6)), "")
db.set_manual_grants(BID, [])
db._run("UPDATE businesses SET featured=0 WHERE id=?", (BID,))

head("۱۳) سقف عکس با آنچه سرور اجرا می‌کند یکی است")
acc = db.access(BID)
code, html = req(A, f"/my/gallery/{BID}")
check("شمارندهٔ گالری همان سقف واقعی پلن را می‌گوید",
      f'data-max="{acc["max_photos"]}"' in html, f"انتظار {acc['max_photos']}")
db.set_manual_grants(BID, ["gallery"])
db.set_manual_grants(BID, [])

# ---------------------------------------------------------------- cleanup
head("۸) پاک‌سازی")
db.set_setting("founder_limit", _saved_limit)
db.delete_business(BID)
_o = db.owner_by_phone(PH)
if _o:
    db.delete_owner(_o["id"])
db.rate_clear()
check("داده آزمایشی حذف شد", db.business(bid=BID) is None, "")
check("رکورد دسترسی هم آبشاری حذف شد",
      db._one("SELECT 1 FROM biz_features WHERE biz_id=?", (BID,)) is None, "")

print(f"\n\033[1m{'='*56}\033[0m")
if bad_n == 0:
    print(f"\033[1m\033[32m  همه موفق — {ok_n} آزمون، ۰ ناموفق\033[0m")
else:
    print(f"\033[1m\033[31m  {ok_n} موفق، {bad_n} ناموفق\033[0m")
    for f in FAILS:
        print(f"    • {f}")
print(f"\033[1m{'='*56}\033[0m\n")
sys.exit(1 if bad_n else 0)
