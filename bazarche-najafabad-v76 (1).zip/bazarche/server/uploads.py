# -*- coding: utf-8 -*-
"""
Image uploads without any third-party library.

`cgi` was removed in Python 3.13, so multipart/form-data is parsed by hand.
Pillow is not available in Pydroid either, so images are downscaled in the
BROWSER (canvas -> JPEG) before upload; the server validates the magic bytes,
enforces a size cap, and stores the file.
"""

import os
import re
import json
import time
import secrets

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
UPLOAD_DIR = os.path.join(ROOT, "site", "assets", "img", "uploads")
CHAT_UPLOAD_DIR = os.path.join(ROOT, "data", "chat-files")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(CHAT_UPLOAD_DIR, exist_ok=True)

PUBLIC_PREFIX = "/assets/img/uploads/"
MAX_FILE = 3 * 1024 * 1024          # 3 MB per image after browser downscale
MAX_FILES = 15
MAX_BODY = 30 * 1024 * 1024

MAGIC = {
    b"\xff\xd8\xff": ".jpg",
    b"\x89PNG\r\n\x1a\n": ".png",
    b"RIFF": ".webp",               # RIFF....WEBP
    b"GIF87a": ".gif",
    b"GIF89a": ".gif",
}

# Video magic bytes (story videos). The server stores the bytes verbatim;
# playback happens client-side so no re-encoding is needed.
VIDEO_MAGIC = {
    b"\x00\x00\x00\x18ftyp": ".mp4",   # MP4/MOV (ftyp box)
    b"\x00\x00\x00\x1cftyp": ".mp4",
    b"\x1aE\xdf\xa3": ".webm",          # Matroska/WebM
}


def sniff(data):
    """Return an extension if the bytes really are an image, else None."""
    for magic, ext in MAGIC.items():
        if data.startswith(magic):
            if ext == ".webp" and data[8:12] != b"WEBP":
                continue
            return ext
    return None


def sniff_media(data):
    """-> (ext, kind) where kind is 'image' | 'video', or (None, None)."""
    ext = sniff(data)
    if ext:
        return ext, "image"
    for magic, ext in VIDEO_MAGIC.items():
        if data.startswith(magic):
            return ext, "video"
    return None, None


# --------------------------------------------------------------------------
# multipart/form-data parser
# --------------------------------------------------------------------------
def parse_multipart(body, content_type):
    """
    -> (fields: {name: str}, files: [(field, filename, bytes)])
    Tolerant of CRLF/LF and quoted or bare boundary values.
    """
    m = re.search(r'boundary=(?:"([^"]+)"|([^;\s]+))', content_type or "", re.I)
    if not m:
        return {}, []
    boundary = (m.group(1) or m.group(2)).encode()
    delim = b"--" + boundary

    fields, files = {}, []
    for part in body.split(delim):
        if not part or part in (b"--", b"--\r\n", b"\r\n"):
            continue
        part = part.lstrip(b"\r\n")
        if part.startswith(b"--"):
            continue
        head, sep, payload = part.partition(b"\r\n\r\n")
        if not sep:
            continue
        payload = payload.rstrip(b"\r\n")

        headers = head.decode("utf-8", "replace")
        name_m = re.search(r'name="([^"]*)"', headers)
        if not name_m:
            continue
        name = name_m.group(1)
        file_m = re.search(r'filename="([^"]*)"', headers)

        if file_m:
            fn = file_m.group(1)
            if fn and payload:
                files.append((name, fn, payload))
        else:
            fields[name] = payload.decode("utf-8", "replace")
    return fields, files


# --------------------------------------------------------------------------
# storage
# --------------------------------------------------------------------------
def save_image(data, prefix="img"):
    """-> (public_path, error). Validates real image bytes."""
    if len(data) > MAX_FILE:
        return None, "حجم تصویر بیش از حد مجاز است (حداکثر ۳ مگابایت)."
    ext = sniff(data)
    if not ext:
        return None, "فایل انتخابی یک تصویر معتبر نیست."
    name = f"{prefix}-{int(time.time())}-{secrets.token_hex(4)}{ext}"
    with open(os.path.join(UPLOAD_DIR, name), "wb") as f:
        f.write(data)
    return PUBLIC_PREFIX + name, None


VIDEO_MAX = 20 * 1024 * 1024        # 20 MB story videos


def save_media(data, prefix="story"):
    """-> (public_path, kind, error). Accepts a real image OR a short video
    (mp4/webm/mov by magic bytes) — used for stories."""
    if len(data) > VIDEO_MAX:
        return None, None, "حجم فایل بیش از حد مجاز است (حداکثر ۲۰ مگابایت)."
    ext, kind = sniff_media(data)
    if not ext:
        return None, None, "فایل انتخابی تصویر یا ویدیوی معتبر نیست."
    name = f"{prefix}-{int(time.time())}-{secrets.token_hex(4)}{ext}"
    with open(os.path.join(UPLOAD_DIR, name), "wb") as f:
        f.write(data)
    return PUBLIC_PREFIX + name, kind, None


# --------------------------------------------------------------------------
# private chat attachments (v73)
# --------------------------------------------------------------------------
CHAT_MAX_FILE = 8 * 1024 * 1024
CHAT_ALLOWED_LABEL = "عکس، PDF یا فایل متنی"


def _chat_type(data):
    """Return (extension, MIME, kind) from bytes, never from the filename."""
    ext = sniff(data)
    if ext:
        # A forged signature alone is not an image. Verify the mandatory end
        # marker/container length as a second signal without any third-party
        # decoder (Pydroid runtime must stay standard-library-only).
        structurally_valid = {
            ".jpg": data.rfind(b"\xff\xd9") >= max(0, len(data) - 64),
            ".png": len(data) >= 20 and data.endswith(b"IEND\xaeB`\x82"),
            ".gif": len(data) >= 14 and data.endswith(b";"),
            ".webp": (len(data) >= 20 and int.from_bytes(data[4:8], "little") + 8 <= len(data)),
        }[ext]
        if not structurally_valid:
            return None
        mime = {".jpg": "image/jpeg", ".png": "image/png", ".webp": "image/webp",
                ".gif": "image/gif"}[ext]
        return ext, mime, "image"
    if data.startswith(b"%PDF-") and b"%%EOF" in data[-2048:]:
        return ".pdf", "application/pdf", "file"
    if not data or b"\x00" in data:
        return None
    if data.startswith((b"PK\x03\x04", b"PK\x05\x06", b"MZ", b"\x7fELF")):
        return None
    # A text note may contain tabs/newlines, not arbitrary binary controls.
    if any(byte < 32 and byte not in (9, 10, 13) for byte in data):
        return None
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return None
    # Plain notes are useful; active/document formats are deliberately not.
    # They are not accepted merely because they happen to be UTF-8 text.
    probe = text.lstrip().lower()[:512]
    if probe.startswith(("<svg", "<!doctype", "<html", "<?php", "#!/")):
        return None
    return ".txt", "text/plain", "file"


def _safe_chat_original(original_name, detected_ext):
    raw = os.path.basename(str(original_name or "").replace("\\", "/"))
    raw = re.sub(r"[\x00-\x1f\x7f<>:\"/\\|?*]", "_", raw).strip(" ._")
    stem = os.path.splitext(raw)[0].strip(" ._") or "file"
    # Keep room for the trusted, detected extension.
    stem = stem[:max(1, 120 - len(detected_ext))]
    return stem + detected_ext


def save_chat_file(data, original_name, prefix="chat"):
    """Validate and store one private chat attachment.

    Returns (metadata, error). `full_path` is for the controller's rollback
    only and must never be serialized to a browser or inserted into messages.
    """
    data = bytes(data or b"")
    if len(data) > CHAT_MAX_FILE:
        return None, "حجم فایل بیش از حد مجاز است (حداکثر ۸ مگابایت)."
    detected = _chat_type(data)
    if not detected:
        return None, f"این فایل مجاز نیست. فقط {CHAT_ALLOWED_LABEL} پذیرفته می‌شود."
    ext, mime, kind = detected
    safe_prefix = re.sub(r"[^A-Za-z0-9_-]", "", str(prefix or "chat"))[:40] or "chat"
    stored_name = f"{safe_prefix}-{int(time.time())}-{secrets.token_hex(12)}{ext}"
    full_path = os.path.abspath(os.path.join(CHAT_UPLOAD_DIR, stored_name))
    if os.path.commonpath([full_path, CHAT_UPLOAD_DIR]) != CHAT_UPLOAD_DIR:
        return None, "نام فایل نامعتبر است."
    try:
        with open(full_path, "xb") as f:
            f.write(data)
        os.chmod(full_path, 0o600)
    except OSError:
        return None, "ذخیرهٔ فایل ممکن نشد. دوباره تلاش کنید."
    return {
        "stored_name": stored_name,
        "original_name": _safe_chat_original(original_name, ext),
        "mime": mime,
        "size": len(data),
        "kind": kind,
        "full_path": full_path,
    }, None


def _chat_full_path(stored_name):
    name = str(stored_name or "")
    if not name or name != os.path.basename(name) or not re.fullmatch(
            r"[A-Za-z0-9_-]{1,80}\.(?:jpg|png|webp|gif|pdf|txt)", name):
        return None
    full = os.path.abspath(os.path.join(CHAT_UPLOAD_DIR, name))
    if os.path.commonpath([full, CHAT_UPLOAD_DIR]) != CHAT_UPLOAD_DIR:
        return None
    return full


def read_chat_file(stored_name):
    full = _chat_full_path(stored_name)
    if not full:
        return None
    try:
        with open(full, "rb") as f:
            return f.read()
    except OSError:
        return None


def delete_chat_file(stored_name):
    full = _chat_full_path(stored_name)
    if not full:
        return False
    try:
        os.remove(full)
        return True
    except OSError:
        return False


def gc_chat_files(referenced, min_age_seconds=3600):
    """Delete private attachment bytes no longer referenced by SQLite."""
    keep = {str(x) for x in (referenced or ())}
    now = time.time()
    removed, freed = 0, 0
    for name in os.listdir(CHAT_UPLOAD_DIR):
        if name in keep:
            continue
        full = _chat_full_path(name)
        if not full or not os.path.isfile(full):
            continue
        try:
            if now - os.path.getmtime(full) < min_age_seconds:
                continue
            size = os.path.getsize(full)
            os.remove(full)
            removed += 1
            freed += size
        except OSError:
            continue
    return removed, freed


def list_chat_files():
    out = []
    for name in sorted(os.listdir(CHAT_UPLOAD_DIR)):
        full = _chat_full_path(name)
        if not full or not os.path.isfile(full):
            continue
        try:
            st = os.stat(full)
            out.append({"name": name, "size": st.st_size, "mtime": st.st_mtime})
        except OSError:
            continue
    return out


def delete_image(public_path):
    """Remove a stored upload. Refuses anything outside the upload dir."""
    if not public_path or not public_path.startswith(PUBLIC_PREFIX):
        return False
    name = os.path.basename(public_path)
    full = os.path.abspath(os.path.join(UPLOAD_DIR, name))
    if not full.startswith(UPLOAD_DIR):
        return False
    try:
        os.remove(full)
        return True
    except OSError:
        return False


def disk_usage():
    total = 0
    n = 0
    for f in os.listdir(UPLOAD_DIR):
        try:
            total += os.path.getsize(os.path.join(UPLOAD_DIR, f))
            n += 1
        except OSError:
            pass
    return n, total


def list_files():
    """-> [{name, path, size, mtime}] for the media manager."""
    out = []
    for f in sorted(os.listdir(UPLOAD_DIR)):
        if f == ".gitkeep":
            continue
        full = os.path.join(UPLOAD_DIR, f)
        if not os.path.isfile(full):
            continue
        try:
            st = os.stat(full)
            out.append({"name": f, "path": PUBLIC_PREFIX + f,
                        "size": st.st_size, "mtime": st.st_mtime})
        except OSError:
            continue
    return out


def delete_file(public_path):
    """Delete one upload by its public path. Refuses paths outside the upload
    dir. -> bool"""
    if not public_path or not public_path.startswith(PUBLIC_PREFIX):
        return False
    name = os.path.basename(public_path)
    full = os.path.abspath(os.path.join(UPLOAD_DIR, name))
    if not full.startswith(UPLOAD_DIR):
        return False
    try:
        os.remove(full)
        return True
    except OSError:
        return False


def gc(referenced, min_age_seconds=3600):
    """Delete upload files nobody references anymore. A file must be BOTH
    unreferenced AND older than min_age so an upload still in flight (or a
    preview the user hasn't saved yet) is never touched.

    -> (removed_count, freed_bytes)"""
    if referenced is None:
        referenced = set()
    now = time.time()
    removed, freed = 0, 0
    for f in os.listdir(UPLOAD_DIR):
        if f == ".gitkeep":
            continue
        full = os.path.join(UPLOAD_DIR, f)
        if not os.path.isfile(full):
            continue
        if PUBLIC_PREFIX + f in referenced:
            continue
        try:
            if now - os.path.getmtime(full) < min_age_seconds:
                continue
            freed += os.path.getsize(full)
            os.remove(full)
            removed += 1
        except OSError:
            continue
    return removed, freed
