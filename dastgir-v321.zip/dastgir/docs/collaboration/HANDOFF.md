# HANDOFF — v321 (۲۲/۰۹/۲۰۲۶)

بخوان: `RULES.md` · `CURRENT-STATE.md` · `KNOWLEDGE.md` · `WHATS-NEW.md` · همین فایل.

## الان چیست

- **هوش سایت + مغز ربات + ایجنت پنل** از کلید اوپن‌روتر بسته (قابل جایگزینی با `/کلید openrouter` یا فرم پنل ایجنت).
- مدل پیش‌فرض تست‌شده: `nvidia/nemotron-3-ultra-550b-a55b:free` (id برگشتی = درخواستی).
- پنل `/agent` هوش را **مستقیم از سرور** می‌گیرد، نه از ربات بله و نه PhonePilot.
- فهرست زندهٔ مدل‌ها + تست قبل از اعمال؛ اگر پاسخ خالی یا مدل دیگری باشد، عوض نمی‌شود.
- ساخت/حذف کسب‌وکار همچنان با ابزارهای v320 (توضیح + تأیید). sqlite ممنوع.
- PhonePilot/OpenClaw هنوز به ۷۰ ابزار وصل نیست — کار محتوا از `/agent` یا بات مدیر دست‌گیر.

## پین

| فایل | مقدار |
|---|---|
| `VERSION.txt` | `321` |
| `site/sw.js` | `bazarche-v321` |
| `DIAG_LATEST` | `"321"` |

## تست

```
python3 tools/test_v321.py
python3 tools/test_v320.py
python3 tools/test_security_v318.py
```
