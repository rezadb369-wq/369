#!/usr/bin/env bash
# v253: اعمال مغز پخته‌شده در بسته (deploy/brain.env) روی فایل رازها؛
# idempotent با stamp. قابل تست: DASTGIR_APP / DASTGIR_SECRETS.
#
# v317 (دستور مدیر: «کلید byNara به همهٔ قسمت‌ها اضافه شود»):
#  1) به‌جای پاک‌کردنِ همهٔ خط‌های AI_*، حالت ادغام اسلاتی: فقط اسلات‌هایی
#     که در brain.env همین بسته تعریف شده جایگزین می‌شوند؛ کلید مغزهای
#     دیگر (اپوس/سونت/هایکو/GGM/اوپن‌روتر…) دست‌نخورده می‌ماند تا با یک
#     نصب ساده، مغزهای زندهٔ قبلی از بین نرود. کلید اسلات هم‌نام قدیمی
#     همان‌طور کامل حذف/جایگزین می‌شود (ردپای توکن تکراری نمی‌ماند).
#  2) مهاجرت یک‌بارهٔ نصب: اگر بسته کلید byNara دارد ولی مغز فعال فعلی
#     کلید ندارد (یا مغز دستی بدون کلید)، مغز فعال روی «bynara» گذاشته
#     می‌شود — فقط در لحظهٔ نصب، نه fallback خودکار در زمان اجرا؛
#     سوئیچ دستی /مغز همچنان دست‌نخورده است.
set -euo pipefail
APP="${DASTGIR_APP:-/opt/dastgir}"
SECRETS="${DASTGIR_SECRETS:-/etc/dastgir-secrets.env}"
BRAIN="$APP/deploy/brain.env"
[ -f "$BRAIN" ] || exit 0
H="$(sha256sum "$BRAIN" | cut -d' ' -f1)"
STAMP="$SECRETS.brain-stamp"
if [ "$(cat "$STAMP" 2>/dev/null || true)" = "$H" ]; then exit 0; fi
touch "$SECRETS"
cp -f "$SECRETS" "$SECRETS.new"
# v317: merge per-slot — فقط کلیدهای تعریف‌شده در brain.env تازه می‌شوند.
while IFS= read -r ln; do
  case "$ln" in
    ''|\#*) continue ;;
    *=*) k="${ln%%=*}" ;;
    *) continue ;;
  esac
  sed -i "/^${k}=/d" "$SECRETS.new"
done < "$BRAIN"
cat "$BRAIN" >> "$SECRETS.new"
mv -f "$SECRETS.new" "$SECRETS"
chmod 600 "$SECRETS"
# v255: بدون باقی‌گذاشتن فایل پشتیبانِ گذرا.
rm -f "$SECRETS.bak"
printf '%s\n' "$H" > "$STAMP"
chmod 600 "$STAMP"
echo "مغز هوش مصنوعی بسته نصب شد (ادغام اسلاتی — مغزهای دیگر دست‌نخورده)."
# v317: مهاجرت یک‌باره — مغز فعال بی‌کلید ← بای‌نارا (فقط با کلید بسته).
if grep -q '^AI_BRAIN_BYNARA_KEY=.' "$SECRETS" 2>/dev/null && [ -d "$APP/server" ]; then
  python3 - "$APP" "$SECRETS" <<'PYMIG' 2>/dev/null || true
import os, sys
app, secrets = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(app, "server"))
env = {}
try:
    for ln in open(secrets, encoding="utf-8"):
        ln = ln.strip()
        if ln and not ln.startswith("#") and "=" in ln:
            k, v = ln.split("=", 1)
            env[k.strip()] = v.strip()
except OSError:
    pass
try:
    import db
    s = db.get_settings()
    b = (s.get("ai_brain_active") or "sonnet").strip().lower()
    slotmap = {"opus": "AI_BRAIN_OPUS_KEY", "sonnet": "AI_BRAIN_SONNET_KEY",
               "haiku": "AI_BRAIN_HAIKU_KEY", "openrouter": "AI_BRAIN_OR_KEY",
               "glm": "AI_BRAIN_GLM_KEY", "bynara": "AI_BRAIN_BYNARA_KEY"}
    active_key = (env.get(slotmap.get(b, "")) or
                  ("" if b in slotmap else env.get("AI_API_KEY", "")))
    bynara = env.get("AI_BRAIN_BYNARA_KEY", "")
    orkey = env.get("AI_BRAIN_OR_KEY", "")
    # v321 (دستور مدیر): کلید اوپن‌روتر بسته = مغز فعال اوپن‌روتر
    # (فقط نصب، نه fallback زمان اجرا).
    if orkey:
        db.set_settings({"ai_brain_active": "openrouter",
                         "ai_brain_or_model": "nvidia/nemotron-3-ultra-550b-a55b:free",
                         "ai_site_model": "nvidia/nemotron-3-ultra-550b-a55b:free"})
        print("v321: مغز فعال + هوش سایت روی اوپن‌روتر.")
    elif bynara and not active_key:
        db.set_settings({"ai_brain_active": "bynara"})
        print("v317: مغز فعال بی‌کلید بود — روی بای‌نارا تنظیم شد.")
    else:
        print("v317: مغز فعال دست‌نخورده ماند (%s)." % (b or "custom"))
except Exception as e:
    print("v317 migrate: skip", e)
PYMIG
fi
