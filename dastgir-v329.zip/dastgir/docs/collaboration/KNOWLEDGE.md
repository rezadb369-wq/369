# 📚 KNOWLEDGE.md — دانش جاری سایت «دست گیر / بازارچه» در v328

> **مرجع شروع هر چت.** این فایل فقط «الان» را می‌گوید: معماری، لایهٔ ضداسپم، لنگرهای کد، و درس‌ها به‌صورت **قاعدهٔ جاری**.
> قوانین همکاری: `RULES.md` (کنار همین فایل) — آن را هم بخوان. وضعیت لحظه‌ای و کار بعدی: `CURRENT-STATE.md`. قابلیت‌های جاری: `WHATS-NEW.md`.
> تاریخ: ۲۰۲۶-۰۹-۲۲ · نسخهٔ زنده: `VERSION.txt` = ۳۲۸.

---

## ۰س) v327 — نوبت امروز + مغز ربات جدا از چت پنل (فاز ۶)
- تب امروز: کارت «نوبت جدید» با عدد زنده (`bookings.status='new'`) + تأیید/لغو فرم `booking_status`.
- تب گفت‌وگو: همان جدول نوبت کنار سفارش. `handle_talk("booking")` → `booking_status`.
- تب هوش: `_brain_status_html` — مغز ربات بله و هوش سایت جدا از چیپ چت همین صفحه. کلید چاپ نمی‌شود. سوئیچ خودکار نیست.
- مسیر POST همان `/agent/talk` (tab=today یا talk). فاز ۱–۵ سر جایشان.
- تست: `tools/test_v327.py`.

## ۰ن) v324 — سیستم (فاز ۳)
- تب سیستم: `handle_sys` → backup_now / backup_list / health_check / seo_check / cache_clear / log_tail / sql_read / db_tables / sys_info / version_info / sec_report / shell_exec.
- ترمینال فقط با confirm دقیق «اجرای فرمان». پیش‌نمایش بدون آن جمله اجرا نمی‌شود.
- خروجی کامل در `/tmp/dastgir-agent-sys-last.json`. راهنمای ۷۲ ابزار با مثال.
- مسیر POST: `/agent/sys` (+ پنلی). مهمان ۴۰۳. sqlite نوشتنی ممنوع. `shell_exec` در IMMEDIATE نیست.

## ۰م) v323 — گفت‌وگو و درآمد (فاز ۲)
- تب گفت‌وگو: `handle_talk` → review_moderate / ticket_reply / claim_moderate / order_status / broadcast.
- تب درآمد: `handle_money` → subscription_set / coupon_save / ad_save / flashdeal_save / badge_save.
- مسیر POST: `/agent/talk` و `/agent/money` (+ پنلی). همگانی فقط با confirm دقیق «ارسال همگانی».
- مهمان ۴۰۳. sqlite برای محتوا ممنوع.

## ۰ل) v322 — میز کار تب‌دار ایجنت (فاز ۱)
- یک کد: `server/views_agent_desk.py` برای `/agent` و `/panel/agent`.
- تب امروز: شمار زنده کسب‌وکار/pending/نظر/سفارش/تیکت. تأیید از فرم `biz_moderate`.
- تب محتوا: فرم `handle_content` → `business_save` / `business_delete` / `businesses_wipe` / `setting`. JSON روزمره لازم نیست.
- مسیر POST: `/agent/content/biz|biz-del|wipe|moderate|bulk|setting` و دوقلوهای پنلی.
- آرنا در میز کار نیست. مهمان ۴۰۳. sqlite برای محتوا ممنوع.

## ۰ک) v321 — اوپن‌روتر همه جا + پنل ایجنت از سرور
- SITE_DEFAULT_BASE = openrouter.ai · مدل پیش‌فرض nemotron-free تست‌شده.
- orouter.py: list_models + test_model (id واقعی باید یکی باشد).
- پنل ایجنت: نه بله، نه PhonePilot. مثال هر بخش.
- PhonePilot همچنان محدود است؛ wipe از `/agent` یا بات ۷۰ابزاری.

## ۰ی) v320 — نوشتن محتوا با توضیح + تأیید (دستور مدیر)
- IMMEDIATE = فقط خواندن (`_READ_IMMEDIATE`). همهٔ نوشتن‌ها `_CONFIRM_TOOLS`.
- ابزار جدید: `business_delete`، `businesses_wipe` (confirm دقیق `حذف همه کسب‌وکارها`). سطل بازیافت، نه SQL خام.
- `reject_sqlite_diy` جایگزین دستور sqlite3/DELETE FROM در جواب بدون ابزار. `shell_exec` نوشتن `.db` را رد می‌کند.
- پرامپت: هرگز sqlite3 نده؛ اول فارسی توضیح بده.
- OpenClaw SOUL همان سیاست. PhonePilot مغز جداست و به ۷۰ ابزار وصل نیست.
- تست: `tools/test_v320.py`.

## ۰ط) v319 — دسترسی آزاد واقعی ایجنت (دستور مدیر)
- IMMEDIATE_TOOLS = همهٔ TOOLS منهای shell_exec/service_restart/broadcast. دیوار تأیید v297 فقط برای همان سه تا.
- file_read کل ROOT (رازها برای مالک). file_write همه جا جز اعتبارنامه/git/sqlite؛ PermissionError → صف کدگارد.
- code_read/code_edit: DENY_FILES خالی؛ DENY_PREFIX فقط data/ uploads/ backups/ .git. adminbot.py خواندنی/ویرایشی از راه کدگارد.
- مهمان: /api/agent/* = ۴۰۳. path traversal بسته. SQL نوشتنی بسته.
- تست: tools/test_v319.py + tools/test_security_v318.py زنده.

## ۰ح) v318 — ایجنت کامل + ling + پنل زیر ایجنت (دستور مدیر)
- پیش‌فرض مغز/سایت: `ling-3.0-flash-sante-free` (بای‌نارا). ۵۰ مدل در `BYNARA_MODELS`. سوئیچ خودکار مغز ممنوع (v265). اسلات سایت جدا (v269) با پس‌انداز کلید bynara وقتی `AI_SITE_API_KEY` خالی است.
- `server/agent_cmds.py`: سطح اسلش OpenClaw روی بات مدیر؛ `/help` `/status` `/panel` `/diagnose` fall-through. `/exec|/bash|/shell` در `handle_text` → `do_shell("sh "+rest)`.
- فایل: `_resolve_owner_file` زیر ROOT. خواندن آزاد به‌جز راز (`brain.env` / `.env` / کلیدها). نوشتن: پین `VERSION.txt`+`site/sw.js` + `deploy/` + `data/` به‌جز `agent-exchange`. `shell_exec` در IMMEDIATE_TOOLS نیست.
- ناوی: `OWNER_NAV_GROUPS[0] = ایجنت`. کارت هاب در `views_agent_full` (standalone + panel).
- OpenClaw: merge-only `deploy/openclaw/apply-openclaw.sh`. توکن ایجنت در زیپ نیست. هرگز `BALE_BOT_TOKEN`/`BALE_ADMIN_TOKEN` را عوض نکن. `tapi.bale.ai` بدون `/bot`. پالر دوم ممنوع.
- `apply-brain.sh` v318: اگر مدل بای‌نارا/سایت خالی یا هنوز agnes باشد → ling. مدل انتخاب‌شدهٔ دیگر دست‌نخورده.

## ۰ز) v310 — ترمینال بله + مغز هر پیام + ابزارهای جدید (دستور مدیر)
- `adminbot.do_shell` — مسیر مستقیم `sh <فرمان>`: تیم‌چت (DENIED بالا)، بدون هوش، `subprocess.run(shell=True, cwd=ROOT, timeout=90)`، خروجی `_REDACT_RX` + `html.escape` + سقف ۳۲۰۰. `sh bg` = `Popen(start_new_session=True)`. dispatch بعد از بلوک `/stop` در `handle_text`؛ صفحه‌کلید ۱۰ ردیف ماند (پین v271): `["چت‌ها","ترمینال"]` و `["اسپم","ایجنت"]`.
- اوراید مغز: `assistant._BRAIN_TL` (thread-local — سرور Threading است) + `set/clear/brain_override`؛ `config()` = `brain_override() or active_brain()`. هر دو هندلر چت (JSON قبل از read_form + فرم در panel_post) با try/finally پاک می‌کنند. نگاشت `AGENT_BRAIN_ALIAS` در app.py (smart→opus, fast→haiku).
- ابزارها: `shell_exec` (عمداً NOT در IMMEDIATE_TOOLS — پیشنهاد هوش از «بله» رد می‌شود) · `sql_read` (regex پیش‌چک: select/with/pragma/explain، بدون ; داخلی، `db.connect()` thread-local با close خنثی ⇒ قفل نمی‌کند) · `log_tail` (journalctl؛ نبودش = پیام صادقانه). aliasها در `_TOOL_ALIAS`.
- `TOOL_FA` در `views_agent_full.py` = برچسب فارسی ۵۱ ابزار؛ `_files_card()` = صندوق تبادل فایل در هر دو کنسول؛ ریدایرکت `/agent/upload` برپایهٔ Referer به مبدأ برمی‌گردد.
- تست: `tools/test_agent_tools_v310.py`.

## ۰و) v309 — ایجنت بدون کلید بله (دستور مدیر: «بخش ایجنت سایت دیگه نیاز به کلید از بله نداشته باشه»)
- احراز ایجنت شش نقطه داشت و همه یک قاعده گرفتند: `agent_ok = کلید(bzv2_agent) OR نشست مالک OR ادمین` — دروازهٔ GET `/agent`، بلوک POST مستقل، چت JSON (`route_post` قبل از read_form)، بلوک POST `/panel/agent`، `/api/agent/status`، و نمای `/panel/agent` (agent_ok=True).
- درس احراز: «کلید فقط از بله» عملاً دو قفل مستقل ساخته بود (کوکی ایجنت + نشست ادمین) که هرکدام دیگری را ۴۰۳ می‌کرد — `/api/agent/status` و POST پنلی حتی با ادمین رد می‌شدند. قاعدهٔ تازه: یک کانال اجباری (نشست) + یک کانال اختیاری (کلید بله).
- مرز امنیتی: مشتریِ فقط-ایمیلی بدون کلید هیچ ابزار ادمینی نمی‌گیرد — کنسول `/agent` ابزار `adminbot_content.TOOLS` را execute می‌کند، پس دروازهٔ کلید برای غیرمالک سر جایش ماند.
- تست: `tools/test_agent_nokey_v309.py` (۱۵ بررسی زنده) — الگو: کوکی‌ها را با هدر خام `Cookie:` بسازید (جار لازم نیست) و `Sec-Fetch-Site: same-origin` برای عبور از دروازهٔ CSRF بفرستید.

## ۰) v296 — لنگر عملیات پنل: جزئیات سفارش + فیلتر/جستجو/CSV (تازه)
- الگوی «لیست عملیاتی کامل»: چیپ وضعیت لینک‌پذیر (`_status_chips` در `views_panel.py`) + جستجوی `?q=` + خروجی CSV با BOM (`export_*_csv` در `features.py`) + صفحهٔ جزئیات با ۴۰۴ صادقانه.
- سفارش‌ها: `order_get` در `features.py` (باید `status_label` را دستی پر کند — اشتباه رایج: فقط `_order_rows` لیست‌ساز آن را می‌سازد).
- تست: `tools/test_panel_ops_v296.py` (۲۹) — نکتهٔ درس: آدرس‌های تستی با حروف فارسی حتماً `urllib.parse.quote` شوند و تطبیق حضور ردیف با لینک یکتا (`/panel/order/<id>`) سنجیده شود نه زیررشتهٔ عدد.

## ۰ب) v295 — لنگر ویرایش استوری + قفل سئو
- استوری هم مثل بنر/فلش‌سیل «ویرایش پس از انتشار» گرفت: `admin_stories` (لیست همه + وضعیت فعال/منقضی + ساعت مانده + دکمه‌های ویرایش/تمدید/حذف) و `story_edit` (پیش‌نمایش، کپشن، تمدید ۲۴س، آمار دیده‌شدن) در `views_panel2.py`؛ مسیرها `GET/POST /panel/story/<id>` در `app.py` با `action=save|extend`؛ تمدید از `max(now, expires)` جمع می‌زند تا استوری منقضی هم زنده شود.
- قاعدهٔ جدید سئو: هیچ صفحهٔ عمومی بدون تست سئو تحویل نمی‌شود — `tools/test_seo_v295.py` چک‌لیست زندهٔ متا/کانونیکال/OG/JSON-LD/رباتز/سایت‌مپ/404 است.
- درس: متای رباتز `page()` فقط از پیشوند مسیر تشخیص می‌داد؛ برای ۴۰۴ پارامتر `force_noindex` به امضای `page()` اضافه شد (`ui.py`).
- تست: `tools/test_story_edit_v295.py` (۱۵) + `tools/test_seo_v295.py` (۲۵) — هر دو با سرور زنده (`PORT=8097 python3 run.py`) اجرا می‌شوند.

## ۰ج) v294 — لنگر ویرایش فلش‌سیل
- الگو: هر بخش داده‌ای پنل باید «ویرایش پس از انتشار» داشته باشد (ad_edit v293 → deal_edit v294). مسیر GET + POST(save/toggle) + اعتبارسنجی سرور + ۴۰۴ صادقانه + نشانگر وضعیت هوشمند در لیست.
- تست: `tools/test_deal_edit_v294.py` (۲۳) — نکته: فرم‌های بدون چک‌باکس active یعنی غیرفعال؛ تست‌ها را با پیش‌فرض نسبی بنویسید.

## ۰د) v293 — لنگرهای امنیت پنل و ویرایش تبلیغات

| بخش | لنگر |
|---|---|
| ویرایش بنر (نما) | `server/views_panel2.py::ad_edit` — فرم پیش‌پرشده + پیش‌نمایش؛ نشانگر وضعیت هوشمند در `ad_list` |
| ویرایش بنر (مسیر) | `GET /panel/ad/<id>` در `app.py::panel_get`؛ `action=save` در `app.py::route_multipart` |
| لایهٔ اول (نشانی مخفی) | تنظیم `panel_hidden_path`؛ گیت در `_route_render` (بلاک پنل) و ابتدای `route_post`؛ متد `_panel_hidden_path` |
| لایهٔ سوم (تأیید بله) | `_bale_confirm_needed` + جدول `panel_approvals`؛ صفحهٔ انتظار `views_panel.approve_wait`؛ پولینگ `/api/panel/approve-status` |
| تصمیم تأیید در ربات | `adminbot.notify_panel_login` + `adminbot.decide_panel_approval` («تأیید/رد <کد>») |
| گیت فعال‌سازی ربات | `adminbot.gate_*` + `gate_step`/`gate_handle_phone`؛ فرمان `/369` در `handle_text`؛ رازها در `deploy/gate.env` |
| تست‌ها | `tools/test_ad_edit_v293.py` (۲۵) · `test_panel_security_v293.py` (۱۹) · `test_bot_gate_v293.py` (۲۱) |

**درس‌های این نسخه:**
- مسیر `POST /panel/ad/<id>` قبلاً فقط حذف/صفر/toggle داشت؛ وقتی `save_ad(data, aid)` ویرایش را ساپورت می‌کند ولی هندلر/نما نیست = قابلیت «روی کاغذ هست، در عمل نیست». همیشه هندلر + نما + تست سه‌تایی را با هم چک کن.
- فرم چندبخشی (فایل‌دار) از `route_multipart` می‌گذرد نه `panel_post`؛ ویرایش بنر چون عکس دارد حتماً در `route_multipart` با کلید/کوکی احراز می‌شود.
- لایهٔ سوم تأیید بله فقط وقتی مسلح می‌شود که ربات واقعاً فعال باشد (`adminbot.enabled()` و گیت `/369` عبور کرده باشد) — وگرنه خودکار خاموش است تا مدیر قفل نشود.
- نشانی مخفی فعال + بازدید اول `/panel?key=…` = هنوز ۴۰۴ (کوکی در همان درخواست نیست)؛ ورود باید از خودِ نشانی مخفی باشد.
- گیت `/369`: در مرحلهٔ شماره، متنِ بی‌رقم «تلاش شماره» حساب نمی‌شود (سهمیه نمی‌سوزاند)؛ سطل شماره و رمز جدا (هرکدام ۸/۱۵دقیقه).

---

## ۱) آیین شروع کار (هر چت/عامل تازه)

1. `VERSION.txt` را بخوان؛ با `DIAG_LATEST` در `server/adminbot.py:648`، `const VERSION` در `site/sw.js:9`، سربرگ `README.md` و خط اول همین پوشه (`CURRENT-STATE.md`) مقایسه کن — این پنج‌جا با تست پین شده‌اند و ناهمگامی یعنی بسته خراب است.
2. `RULES.md` را بخوان (قوانین مدیر، غیرقابل‌مذاکره).
3. قبل از هر ادعا، **اجرا کن**: `python3 tools/test_*.py` مربوطه + `curl` واقعی. «درست شد» بدون خروجی سبز = نقض قانون ۱.
4. صحنهٔ تست را از پایگاه واقعی بخوان، نه از حافظهٔ چت قبلی.
5. دادهٔ کاربر (`data/`) هرگز در زیپ/ریپو نمی‌رود؛ رازها هرگز در چت/سند/لاگ چاپ نمی‌شوند.

---

## ۲) پروژه در یک نگاه (v280)

| چیز | واقعیت جاری (خروجی واقعی فرمان) |
|---|---|
| زبان/وابستگی | پایتون ۳ **فقط کتابخانهٔ استاندارد** — صفر `pip`؛ روی Pydroid اندروید و VPS |
| داده | SQLite در `data/bazarche.db` (+`-wal`/`-shm`)؛ **۸۴ جدول** + یک FTS (`businesses_fts`) |
| وب | `http.server` دست‌نویس؛ `server/app.py` = مسیریاب + امنیت (۳۰۳٬۰۳۵ بایت، ۲۲۲ شرط مسیر) |
| نما | `server/ui.py` کروم/توکن روز/GA4 + `views_*.py` (۹ فایل نما) + `site/` (۲۴۲ فایل assets) |
| سرویس | systemd `bazarche` · `WorkingDirectory=/opt/dastgir` · `ExecStart=/usr/bin/python3 /opt/dastgir/run.py --port 8080` · `User=www-data` |
| رازها | فقط `/etc/dastgir-secrets.env` با `root:root/600` (واحد systemd با `EnvironmentFile=-` می‌خواند) |
| سخت‌گیری واحد | `NoNewPrivileges` · `PrivateTmp` · `ProtectSystem=full` · `ProtectHome` · `ReadWritePaths=/opt/dastgir/data /opt/dastgir/site/assets/img/uploads` |
| پراکسی | nginx روی ۸۰ → `127.0.0.1:8080`؛ `client_max_body_size 25m`؛ مسیر webhook با `access_log off` |
| تست | **۱۱۶ سوئیت** `tools/test_*.py` + ۷۴ ابزار غیرتستی |
| دامنه/سرور | `daastgir.ir` · VPS `130.185.78.237` · `/opt/dastgir` |

سه نقش: **بازدیدکننده** (بدون حساب) · **مشتری/دکان‌دار** (ورود فقط با تأیید بله یا سروش‌پلاس — بدون رمز و پیامک) · **مدیر کل** (`/panel?key=…`).

---

## ۳) معماری — لنگرهای کد (file:line واقعی v280)

| بخش | لنگر |
|---|---|
| مسیریاب/امنیت/سپر | `server/app.py` — `spam_gate` در `:279`، کنسول اسپم `:1965`، سیاست کنسول `:4453`، درگاه `loginlock` `:558` و `:619`، درگاه `itemdup` `:3424`/`:3584`/`:4222` |
| لایهٔ ضداسپم ماندگار | `server/antispam.py` (۴۴۹ خط) — `POLICY :22`، `event :65`، `ban :84`، `lift :96`، `banned :104`، `_escalate :115`، `_policy :133`، `policy_set :151`، `policy_clear :166`، `ban_now :174`، `bans_active :184`، `stats_today :201`، `held_counts :226`، `guard :245`، `strike :287`، `enum_check :302`، `bytes_add :328`، `prune :352`، `report :373`، `content_score :404`، `content_gate :420` |
| سپر درخواستی | `server/shield.py` (۱۷۸ خط) — `RATE_LIMIT=120` `:31`، `RATE_WINDOW=10` `:32`، `BLOCK_RATE_S=600` `:37`، `check(handler) :101`، `_strike :90` |
| داده | `server/db.py` (۳۳۶٬۵۵۰ بایت) — `rate_ok`، `rate_clear`، `log`، `get_settings`/`set_setting`، درگاه `stockdup` `:7696` |
| مغز هوشمند | `server/assistant.py` (۱۶۹٬۲۷۹ بایت) — `global_quota_today :264`، `global_cap :273`، `remaining :277`، `KNOWLEDGE :318` (۳۵ مدخل)، `_knowledge_pool :377` (ویرایش مدیر برنده است)، `_OFFLINE_TOPICS :394` (۲۵ موضوع)، `THREAD_TTL=600 :1149`، `digest_counts :1745` |
| بات مدیر | `server/adminbot.py` (۹۳٬۱۸۷ بایت) — `DIAG_LATEST="280" :648`، مقایسهٔ نسخه در «تشخیص» `:660-661`، دستور «اسپم» `:1702`، گزارش ضداسپم `:477-512`، بازنشر خودکار صفحه‌کلید با `admin_kb_ver` `:1899-1901` |
| ابزار کد بات مدیر | `server/adminbot_code.py` + `server/adminbot_content.py` (۹۷٬۲۱۰ بایت) — جست‌وجو/خواندن/ویرایش/نوشتن/برگشت + صف استقرار |
| بات‌های عمومی | `server/bot_menu.py` (۷۵٬۰۲۵ بایت) — `/menu` `/account` `/help` `/search` `/orders` `/bookings` `/favorites` `/messages` `/stock` `/notifications` `/owner`؛ درگاه `regsub` در `server/bot_register.py:520-527` |
| بازوها | `server/bale.py` (بله) · `server/soroush.py` (سروش‌پلاس، webhook رسمی + `update_id` پایدار + resolver `soroush://resolve?domain=<bot>`) |
| ثبت‌نام وب | `server/register_web.py` — سطل per-IP `regip` در `:120-122` (۳۰ در ۶۰۰ ثانیه، `always=True`) |
| نقشهٔ IP فارسی | `server/geoip.py` + `server/geoip_ir.csv` (۵۱۳٬۸۴۸ بایت) — IPv6/خصوصی/نامعتبر ⇒ `("", "")`، هرگز شهر ساختگی |
| فایل/آپلود | `server/uploads.py` — حذف EXIF، مجوز قبل از خواندن |
| کش‌شکن UI | `server/ui.py:694` → اسکریپت چت با پرس‌وجوی کش‌شکن (رشتهٔ دقیقش با سوئیت دستیار پین شده؛ تغییرش یعنی بامپ هم‌زمان همان پین) |
| استقرار | `deploy/install.sh` (نصب اول) · `deploy/update.sh` (به‌روزرسانی اتمیک) · `deploy/codeguard.sh` (کرون هر دقیقه) · `deploy/backup.sh` · `tools/backup.py` (اسنپ‌شات سازگار با API رسمی SQLite) |

---

## ۴) لایهٔ ضداسپم در v280 — مرجع کامل

چرا سه لایه: `shield.py` فقط «حجم کل» را می‌بیند و در حافظه است؛ سطل‌های `db.rate_ok` جزیره‌ای‌اند و تکرارِ متخلف پلهٔ تنبیه نداشت. `antispam.py` سه چیز اضافه می‌کند: (۱) سیاست مرکزی per-کنش با **نام درگاه در پیام خطا**، (۲) رویدادنامهٔ ماندگار `spam_events` + ban ماندگار `spam_bans` که ری‌استارت را زنده می‌ماند و `shield` هم می‌خواندش، (۳) پلهٔ تنبیه + سقف بایت روزانه per-حساب.

### ۴٫۱ سیاست مرکزی (`POLICY`، `antispam.py:22`) — action → (limit, window_s, always)

| گروه | کنش‌ها |
|---|---|
| مشتری | `fav` 30/600 · `follow` 30/600 · `pushsub` 10/600 · `pushunsub` 10/600 · **`notifyme` 6/600 always** · `ticketreply` 30/600 · `ticketnew` 10/600 |
| مهمان | `pricealert` 10/600 · **`checkdup` 20/600 always** (ضد enumeration) · **`offer` 10/900 always** (ضد حدس کد) |
| خواندنی ضدscrape | **`view` 60/600 always · `search` 60/600 always · `msgpoll` 120/600 always** |
| دکان‌دار | `storyadd` 10/600 · `upload` 30/600 · `itemsave` 60/3600 · `claim` 5/3600 · **`ordstatus` 30/600 always** · `omod` 60/600 · `bcastfd` 30/600 |

`always=True` یعنی کلید `ratelimit_on` مدیر آن را خاموش نمی‌کند؛ کنسول هم **نمی‌تواند** همیشه‌بودن را بگیرد (`_policy` پرچم را فقط از کد می‌خواند). اورراید زمان‌اجرا در تنظیم `spam_pol_<action>` به شکل `limit:window` می‌نشیند و بازهٔ مجازش `limit 0..100000` و `window 60..86400` است؛ `limit=0` = رد بی‌قیدوشرط.

### ۴٫۲ gateها و پیام خطا

`guard(action, ident, actor)` ⇒ `(ok, gate, retry_s)`. مسیر HTTP از `Handler.spam_gate()` (`app.py:279`) رد می‌شود: **خودش پاسخ را می‌فرستد** و `True` برمی‌گرداند یعنی «رد شد». پیام‌ها برای `/api/*` JSON با ۴۲۹ و برای بقیه متن ساده با ۴۲۹ است و همیشه نام درگاه را می‌گوید: «محدودیت ضداسپم؛ درگاه: <gate>». پارامتر `silent=(payload, code)` برای مسیرهای ضد-oracle یک پاسخ بی‌ضرر می‌دهد — ولی **دقیقاً یک پاسخ** اجازهٔ خروج دارد.

دروازه‌های نام‌دار که در پیام کاربر دیده می‌شوند:

| درگاه | جا | رفتار |
|---|---|---|
| `ban` | `antispam.banned` / `guard` | ban ماندگار فعال ⇒ همهٔ کنش‌ها رد؛ `retry=3600` |
| `loginlock` | `app.py:558`، `:619` | ۵ تأیید ناموفق برای (شماره،IP) یا (نام‌کاربری،IP) ⇒ ۱۵ دقیقه قفل؛ مسیرهای OTP/رمز از قبل ۴۰۴اند — این defence in depth است |
| `logindiv` | `enum_check(action="logindiv")`، `antispam.py:302` + `DIV_WINDOW=600`/`DIV_THRESHOLD=3` | تنوع شماره per-IP را می‌شمارد؛ از ۳ شمارهٔ متمایز به بعد هر درخواست یک `deny` ثبت می‌کند و پله می‌تواند ban بدهد. **مستقیم رد نمی‌کند** (CGNAT) |
| `regip` | `register_web.py:120` | سطل per-IP ویزارد ثبت: ۳۰ در ۶۰۰ ثانیه، `always=True` |
| `regsub` | `bot_register.py:520-527` | cooldown ثبت هم‌هویت (وب و بات): ۲ در ۳۰ دقیقه؛ توکن نمی‌سوزد |
| `itemdup` | `app.py:3424`/`:3584`/`:4222` | عنوان تکراری با کالای موجود ⇒ رویداد `hold` + `spam_flag=1` ⇒ پنهان از عموم/جست‌وجو تا بررسی مدیر |
| `stockdup` | `db.py:7696` | «خبرم کن» dedup ۲۴ساعته پس از fulfill/dismiss |
| `bytes` | `bytes_add`، `antispam.py:328` | سقف حجم روزانهٔ آپلود per-حساب = `BYTES_DAY` (۶۰MB) |
| نام کنش | همهٔ سطل‌های `POLICY` | وقتی سطل پر شد، نام خود کنش gate است |

### ۴٫۳ ban و پلهٔ تنبیه

`STRIKE_LIMIT=6` در `STRIKE_WINDOW=600` ⇒ `_escalate` بلاک می‌دهد: بار اول `BAN_T1=3600` (یک ساعت)؛ اگر قبلی در ۲۴ ساعت ساخته شده باشد `BAN_T2=86400` (یک روز). ban در `spam_bans` با `ON CONFLICT(ident) DO UPDATE` می‌نشیند ⇒ ری‌استارت و بازیابی بکاپ هم ban را زنده نگه می‌دارد و `shield.check` همان را می‌خواند. `ban_now(ident, hours, by)` برای مدیر است و ساعت را به `1..720` محدود می‌کند. `lift(ident)` برمی‌دارد. رویدادنامه `spam_events` با `EVENTS_MAX=5000` و `EVENTS_KEEP_DAYS=7` هرس می‌شود (هر ۱۰۰ رویداد یک‌بار + `prune()` از sweep ساعتی). `spam_bans` **در بکاپ هست** و `spam_events` گذراست (عمداً بیرون می‌ماند، مثل `sessions`).

### ۴٫۴ هوش محتوایی (`content_gate`)

`content_score(text)` پرچم می‌دهد: ≥۳ لینک (`https?://|www.|t.me/|telegram.me/`) ⇒ `flags+=2` · ≥۳ نویسهٔ نامرئی/کنترلی/RTL-override ⇒ `flags+=2` · طول > ۴۰۰۰ ⇒ `flags+=1`. `content_gate(action, ident, text)` متن نرمال‌شده (lower + ی/ک + حذف ZWNJ/ZWJ + فشرده‌سازی فاصله) را sha1 می‌زند و تکرار سراسری همان متن را در ۱۰ دقیقه می‌شمارد:

- `dup >= 4` یا `flags >= 4` ⇒ **reject**
- `dup >= 2` یا `flags >= 2` ⇒ **hold** (`spam_flag=1` + صف نگه‌بررسی)
- وگرنه ⇒ **ok**

هرگز استثنا نمی‌دهد (ضداسپم نباید سایت را بخواباند) و در خطا `("ok", action)` برمی‌گرداند. سقف فرم متنی ۶۴KB با ۴۱۳ و نام gate. honeypot روی فرم تیکت/نظر/پرسش: فیلد تله پر ⇒ بی‌صدا دور ریخته می‌شود. دِدوپ رأی پرسش در `question_votes` (موازی `review_votes`): ۳۰ رأی از یک رأی‌دهنده ⇒ شمار ۱.

### ۴٫۵ کنسول `/panel/spam` و دستور «اسپم» بات

`/panel/spam` (`app.py:1965`): کاشی‌های زندهٔ شمار per-کنش (`stats_today`) + محتوای نگه‌بررسی (`held_counts` روی `reviews`/`questions`/`tickets`/`items`) + ویرایش سیاست هر کنش (`/panel/spam/policy` و `/panel/spam/policy-reset`) + ban دستی (`/panel/spam/ban`) و lift (`/panel/spam/lift`) + ۵۰ رویداد اخیر. لینکش از sidebar و صفحهٔ «ترافیک و سپر» است.
بات مدیر (`adminbot.py:1702`، گزارش در `:477-512`): «اسپم» = گزارش ۲۴ ساعت اخیر؛ «اسپم ban <شناسه> [ساعت]» و «اسپم lift <شناسه>» — **فقط چت تیم**، و ردیف «اسپم» در صفحه‌کلید هم هست.

### ۴٫۶ نگهبان پوشش (مکانیکی، همیشه قرمز می‌شود)

`tools/test_coverage_guard.py`: هر مسیر POST غیرمدیر باید یا درگاه ضداسپم/سطل داشته باشد یا در `EXEMPT` **با دلیل**؛ کنش‌های اعلان‌ساز/ضدscrape باید `always` باشند؛ وب‌هوک‌ها always؛ sweep ساعتی هرس‌ها را صدا می‌زند؛ جدول‌ها و بکاپ درست؛ Handler timeout دارد؛ shield به banهای ماندگار وصل است. **مسیر نوشتنی تازهٔ بدون سیاست ⇒ این تست قرمز می‌شود.**

---

## ۵) امنیت — وضعیت جاری پس از برنامهٔ شش‌فازی

برنامهٔ ضداسپم شش فاز داشت و هر فاز با کد + تست سبز + بامپ + زیپ + نصب یک‌فرمانی بسته شد. وضعیت جاری هر شش فاز:

1. **هستهٔ ماندگار** — سیاست مرکزی، رویدادنامه، ban ماندگار، پلهٔ تنبیه، سقف بایت، سطل برای همهٔ کنش‌های بی‌سطل، درگاه‌های HTTP با نام دقیق.
2. **هوش محتوایی** — verdict سه‌حالته، honeypot، دِدوپ رأی پرسش، سقف ۶۴KB فرم متنی.
3. **سخت‌سازی ورود** — secret غلط وب‌هوک = strike قطعی (۶ ضربه/۱۰ دقیقه ⇒ بلاک موقت IP از راه shield)؛ `loginlock`؛ سطل per-شماره با هش؛ `logindiv`؛ پین G18: پاسخ ورود برای شمارهٔ ثبت‌شده/نشده **کاملاً یکسان**.
4. **ثبت/محصول/فراخوان** — `regip` + `regsub` + hold برای نام/تلفن/نشانی تقریباً تکراری + `itemdup` با `spam_flag` + `stockdup`.
5. **کنسول دیده‌شدنی** — `/panel/spam` + «اسپم» در بات (قانون §78: قابلیت بدون UI دیده‌شدنی = انجام‌نشده).
6. **تهاجم زنده + IDOR** — سناریوهای تهاجمی روی سرور در حال اجرا باید **شکست بخورند**: طوفان محتوایی نظر، تهاجم‌گر چندکنشی ⇒ ban، سیل «فراخوان قیمت» ⇒ ۴۲۹ سپس ۴۰۳، پایداری ban پس از ری‌استارت/بکاپ، honeypot بی‌صدا، پمپ رأی پرسش، scrape جست‌وجو ⇒ ۴۲۹، تورم بیکن بازدید استوری ⇒ deny ثبت می‌شود با پاسخ بی‌صدا. پین سراسری IDOR (G25): هر مسیر مالکیت‌دار باید در برابر حساب دیگر ۴۰۳/۴۰۴ بدهد — `/me/order/<id>`، `POST /my/order/<id>/cancel` و تغییر وضعیت، `POST /my/booking/<id>`، `POST /my/trash/<id>/restore`، `POST /my/broadcast/fulfill` — با تست زندهٔ cross-account، نه با ادعا.

**باگ‌کلاس واقعی که در فاز ۶ پیدا و رفع شد:** ۲۲ نقطه «پاسخ دوم پس از `spam_gate`». چون `spam_gate()` خودش پاسخ می‌فرستد، هر `return self.redirect(...)`/`json_out(...)` بعدش = نوشتن هدر دوم روی اتصال keep-alive ⇒ ۵۰۰. latent بود چون هیچ تستی به مسیر reject نمی‌رسید؛ پنتست لو داد. همه به پاسخ یگانه اصلاح شدند + نگهبان براستی.

سایر قفل‌های جاری: کلید پنل + رمز اختیاری PBKDF2 · مسیرهای OTP/رمز مشتری ۴۰۴ · رازها فقط در `/etc/dastgir-secrets.env` · `data/` هرگز در زیپ نیست · EXIF حذف می‌شود · فایل چت خصوصی با مجوز قبل از خواندن · سطل بازیافت ۷روزه · HSTS + `upgrade-insecure-requests` فقط پشت پراکسی HTTPS · `X-Robots-Tag: noindex` روی صفحات پنل · `robots.txt` خزنده‌های آموزشی AI را ممنوع می‌کند · nginx مسیر webhook را لاگ نمی‌کند.

ماتریس پوشش سطر‌به‌سطر: `docs/SECURITY-MATRIX.md` · وضعیت و معماری لایه: `docs/SECURITY-SPAM-PLAN.md` · ممیزی امنیتی جاری: `docs/audit-2026-08-security.md`.

---

## ۶) هوش مصنوعی — دو محیط کاملاً جدا (دستور مدیر)

| | هوش عمومی سایت (چت کاربران) | محیط مدیر/تیم |
|---|---|---|
| اسلات | `AI_SITE_BASE_URL` / `AI_SITE_API_KEY` / `AI_SITE_MODEL` در `deploy/brain.env` | ۵ کلید مغز: `AI_BRAIN_OPUS_KEY` / `AI_BRAIN_SONNET_KEY` / `AI_BRAIN_HAIKU_KEY` / `AI_BRAIN_OR_KEY` / `AI_BRAIN_GLM_KEY` + `AI_TIMEOUT=40` |
| پیش‌فرض بسته | AvalAI + `glm-5.3-flash` (کلید `aa-…` مخصوص سایت) | مغز فعال = تنظیم `ai_brain_active` (پیش‌فرض sonnet) |
| تعداد مدل | **تک‌مدل** — لایهٔ smart برای کاربران حذف شده | ۶ مغز: `claude-opus-5` / `claude-sonnet-5` / `claude-haiku-4-5` / `nvidia/nemotron-3-ultra-550b-a55b:free` / `glm-5.3-flash` / `agnes-2.5-flash` (پیش‌فرض مغز پنجم GLM با `/مدل` قابل سوئیچ؛ مغز ششم v317 بای‌نارا با ۵۰ مدل و `/مدل بای‌نارا` قابل سوئیچ) |
| سوئیچ | دکمهٔ «هوش سایت» در پنل + `/کلید سایت <کلید> [مدل]` + «مدل سایت <شناسه>» (تست زندهٔ اجباری) | دکمهٔ انتخابگر مغز در بله + `/مغز` + `/مدل` + دکمهٔ «کلیدها» (توکن تک‌تک مدل‌ها، هر کلید در اسلات همان مغز) |
| سهمیه | مهمان‌ها مدل صدا نمی‌زنند (قاعده + کش رایگان + دعوت به ورود)؛ واردشده‌ها پاسخ کامل؛ `ai_guest_model` در `/panel/assistant` (پیش‌فرض خاموش) | بدون سهمیه، دسترسی کامل |
| حافظه | `THREAD_TTL=600` (۱۰ دقیقه) در `ai_threads`؛ تایمر دیده‌شدنی در صفحهٔ چت؛ رفرش چت را نمی‌پرد و فقط تایمر را پاک می‌کند (`localStorage {until,msgs,mode}`) | — |
| ثبت | هر تبادل (llm/cache/rule/confirm) یک خط JSONL در `data/site_chats.log`؛ آی‌پی مهمان ماسک «guest»؛ دانلود با «چت‌ها» | لاگ عملیات در DB |

**قاعده‌های سخت:** سوئیچ خودکار/یدک ممنوع است (نه fallback، نه `AI_FALLBACK_*`) — مغز مرده = پیام صادقانه. پرامپت چت بدون محدودیت موضوعی است (رد نمی‌کند). در پایان سهمیه `remaining=0` برگردانده می‌شود (نه ۱) + بنر «سهمیه تمام شد؛ به هوش آفلاین وصل شدید» + سوییچ خودکار کلاینت به آفلاین؛ gate سهمیه اسلات هوش سایت (`site_configured`) را هم پوشش می‌دهد. حالت `mode=offline` هرگز مدل را صدا نمی‌زند و فقط از ۳۵ مدخل `KNOWLEDGE` + ۲۵ موضوع `_OFFLINE_TOPICS` + کش رایگان جواب می‌دهد؛ `_knowledge_pool()` ویرایش مدیر را برنده می‌کند. کلید لخت که در چت بله paste شود، `handle_update` پیام حاوی کلید را best-effort با `deleteMessage` حذف و در پاسخ/حافظه redact می‌کند («🧹 پیام حاوی کلید حذف شد»)؛ اگر حذف نشد صادقانه می‌گوید دستی پاک کنید — کلید هرگز بازتاب داده نمی‌شود. کیرا کاملاً حذف شده: هیچ `kira`/`کیرا`/`kiraai.vn` در کد فعال نیست؛ `/مغز کیرا` و کلید `kira_…` پذیرفته نمی‌شوند و پیام راهنمای صادقانه می‌گیرید. `BALE_ADMIN_CHAT` چندتایی با کاما = تیم با دسترسی کامل (دستورها + عکس + «بله» + اعلان کدگارد/گزارش هفتگی).

---

## ۷) بات‌ها و ورود

- **ورود فقط با تأیید بله/سروش‌پلاس.** حساب شناخته‌شده دکمهٔ تأیید ورود می‌گیرد؛ کاربر تازه اول شماره را با دکمهٔ رسمی `request_contact` تأیید می‌کند سپس دکمهٔ جداگانهٔ «تأیید ثبت‌نام و ورود» را می‌زند. تطبیق `contact.user_id == message.from.id` اجباری است و پاسخ callback هم اجباری.
- **سروش‌پلاس:** webhook رسمی، `update_id` پایدار، replay-guard، rate-limit، handoff مستقیم به اپ با `soroush://resolve?domain=<bot>` + کپی کلید کوتاه‌عمر در همان کلیک؛ صفحهٔ مرورگر برای polling باز می‌ماند و پس از تأیید خودکار وارد می‌شود.
- **بات‌های عمومی:** هر ۱۱ فرمان بالا، فقط در گفت‌وگوی خصوصی، با تأیید دومرحله‌ای و hash-only confirmation؛ اطلاعات تماس/آدرس/یادداشت خصوصی هرگز وارد پیام بات نمی‌شود.
- **ثبت کسب‌وکار:** هر سه کانال (وب/بله/سروش) یک پیش‌نویس مشترک دارند؛ در وب ویزارد مرحله‌ای `/register-business` است.
- **بات مدیر:** «بله» فقط برای دستورهای مستقیم (ری‌استارت/ریست/پیام همگانی/ساخت رمز ورود)؛ بقیه فوراً اجرا می‌شود. هر رد شدن ابزار دلیل دقیقش را می‌گوید («ابزار X درست بود ولی اجرا نشد: <کدام ورودی و چرا>»). پس از هر نصب، اگر `admin_kb_ver` با نسخهٔ جاری یکی نباشد صفحه‌کلید یک‌بار خودکار بازنشر می‌شود.

---

## ۸) استقرار و به‌روزرسانی

`deploy/update.sh` (رفتار واقعی، ۲۴۴۴ بایت): root اجباری → چک وجود زیپ → چک `unzip rsync python3` → `mktemp -d` → استخراج و اعتبارسنجی ساختار (`dastgir/run.py` + `dastgir/VERSION.txt`) + `unzip -t` → ساخت/تکمیل مسیرها → **بکاپ سازگار با `tools/backup.py --dir /var/backups/dastgir --no-rotate`** → `systemctl stop bazarche` → `rsync -a --delete` با exclude روی `/data/`، `/site/assets/img/uploads/`، `/site/assets/chat-files/` → ساخت `data/chat-files`، `data/code-jobs`، `data/code-backups` → نصب کرون کدگارد در `/etc/cron.d/dastgir-codeguard` (هر دقیقه، فقط اگر نباشد) → `chown -R www-data:www-data` → `install -m 0644 bazarche.service` → `daemon-reload` → `apply-brain.sh` (اعمال مغز بسته) → `systemctl start` → `sleep 2` → `is-active` + `curl -fsS http://127.0.0.1:8080/healthz` → چاپ «نسخه <VERSION.txt> با موفقیت نصب شد.»؛ `trap cleanup EXIT` در صورت شکست سرویس را برمی‌گرداند.

راهنمای قدم‌به‌قدم به‌روزرسانی از گوشی با ترموکس (SSH + فرمان یک‌خطی): **`docs/TERMUX-GUIDE.md`**. نصب اول روی VPS تازه: `deploy/install.sh` + `deploy/README-fa.md`. پشتیبان‌گیری و بازیابی: `UPGRADE.md`.

---

## ۹) تست و رگرسیون — قواعد جاری

- ۱۱۶ سوئیت `tools/test_*.py`، همه stdlib. اجرای کل باتری: حلقهٔ `timeout 300 python3 "$f"` و شمارش PASS/FAIL. بعضی سوئیت‌ها به **سرور زنده/اینترنت** نیاز دارند (`test_all.py`، `test_browser.py`، `bench_*`، `qa_*` مرورگری) — آن‌ها را جدا فهرست کن.
- **پین نسخه ۵جایی** (پنج سوئیت `test_adminbot_*` در `tools/`): `VERSION.txt` + `DIAG_LATEST` + `bazarche-v280` در `sw.js` + `دست گیر — v280` در ۲۰ خط اول `README.md` + `v280` در خط اول `CURRENT-STATE.md`.
- پین محتوایی همین فایل: سوئیت دستیار `tools/test_assistant_v2*` سرفصل‌های `## §43`، `## §44`، `## §45` و نشانه‌های «تمیزکاری نهایی»، `booking_reminders`، `digest_counts` و درس race را در همین سند می‌جوید.
- صحنهٔ استاندارد قبل از هر باتری: وضعیت را از پایگاه بخوان و برگردان؛ fixtureهای ماندهٔ دور قبل شمارها را غلط می‌کنند حتی وقتی کد سالم است.
- پنتست زنده روی سرور موقت با دیتابیس خالی هم باید سبز باشد (سناریوها خود-بسنده‌اند؛ پمپ رأی بدون پرسش = رد محترمانه).

---

## §43 — ابزارهای دستیار و صفحهٔ مالک (وضعیت جاری)

دستیار مدیر ابزار محتوایی تمام‌قد دارد: هر سطح محتوای پنل (تنظیمات، صفحات، مقاله، دسته، کسب‌وکار و نقشه، محصول، نظر، کد تخفیف، لیست برترین‌ها، پیشنهاد لحظه‌ای، رویداد، بنر، پلن، نشان، استوری، ادعای مالکیت، تیکت، مشتری، سفارش، رزرو/`booking_reminders`، محله، سطل بازیافت، پیام همگانی) از چت **فوراً** انجام می‌شود؛ عکس در چت پذیرفته می‌شود و ابزارها استفاده‌اش می‌کنند. صفحهٔ مالک همان داده را با نمای وب نشان می‌دهد. قاعده: ابزار باید پیشنهاد (propose) و صف (job) داشته باشد تا قابل ردیابی و برگشت باشد.

## §44 — تمیزکاری و حلقهٔ بسته (وضعیت جاری)

حلقهٔ بستهٔ دستیار: جست‌وجو → خواندن → دیدن → ویرایش با تطبیق هوشمند متن → پشتیبان → بررسی کامپایل → تست سلامت → اعمال با کرون کدگارد → برگشت خودکار اگر ناسالم بود. شمارنده‌های زنده: `global_quota_today()`، `global_cap()`، `remaining(user_key, tier)` و `digest_counts(owner_id)` باید هم‌زمان درست جواب بدهند و هیچ شمارندهٔ مرده‌ای در ماژول نماند. تمیزکاری یعنی حذف مسیر مرده، نه خاموش‌کردنش.

## §45 — v232 تمیزکاری نهایی (قاعدهٔ جاری)

نشانه‌های این فاز که هنوز زنده‌اند و با تست پین شده‌اند: `booking_reminders` (یادآور نوبت‌ها)، `digest_counts` (خلاصهٔ شمار مالک)، و نبودِ هیچ `global_today` مرده در سورس/ماژول. **درس ماندگار: ادیت موازی هم‌فایل race می‌کند** — دو ویرایش هم‌زمان روی یک فایل، یکی را بی‌صدا می‌بلعد؛ پس ویرایش کد باید سریالیزه شود (صف استقرار + کدگارد) و رسید هر ویرایش خوانا بماند.

---

## ۱۰) درس‌ها به‌صورت قاعدهٔ جاری (سیاههٔ ضدتکرار)

**کد و ویرایش**
- بعد از دروازه‌ای که خودش پاسخ می‌فرستد (مثل `spam_gate`) **هیچ پاسخ دومی نفرست** — هدر دوم روی keep-alive ⇒ ۵۰۰.
- پیام خطا باید **دقیقاً همان دروازه‌ای** را نام ببرد که رد کرده، نه لایهٔ بالاتر را. «ابزار X شناخته نشد» فقط وقتی صادق است که نام واقعاً ناشناخته باشد.
- ویرایش هم‌فایل موازی race می‌کند ⇒ صف + رسید + برگشت.
- بریدن JS داخل f-string ممنوع (براکت‌ها) ⇒ JS را رشتهٔ خام جدا کن.
- `hidden` + `display:grid` = پوشش صفحه ⇒ همیشه `[hidden]{display:none}` همراهش.
- `except` بی‌صدا ممنوع؛ ضداسپم/اعلان‌ها عمداً `except: pass` دارند چون هرگز نباید سایت را بخواباند — این استثنا فقط در همان لایه مجاز است.

**تست**
- نردبان dup روی متن `author + body` نرمال‌شده می‌شمارد ⇒ تست سیل باید author ثابت بدهد وگرنه متن‌ها متمایز می‌شوند.
- متن با ≥۳ لینک از همان بار اول `flags=2` ⇒ hold است (نه ok)؛ نردبان dup را با متن بی‌پرچم تست کن.
- fixture زباله: `trash_put` دستی با payload ناقص ⇒ restore واقعی ۵۰۰ می‌دهد؛ همیشه از جریان واقعی `delete_item` استفاده کن.
- آزمون آماری درون‌مجموعه‌ای با ident پویا بنویس؛ فیلد دست‌خوردهٔ صحنه مالِ باتری‌های دیگر است.
- باتری‌ها با تغییر رفتار باید **هم‌زمان** به‌روز شوند.
- هر رفع تازه با باتریِ همان مسیر قفل شود؛ «موفقیت جعل» خانوادهٔ باگ‌های تکراری این پروژه است.

**زیرساخت/عملیات**
- قفل SQLite: اتصال خامِ خودت با تراکنش باز، `db._run` سرور را قفل می‌کند ⇒ کامیت مرحله‌به‌مرحله. ریشهٔ «database is locked» دوگانه بود: گرسنگی WAL (truncate پیش‌گیرانهٔ >1.5MB در کد هست) + اتصال کامیت‌نشده در finally باتری‌ها.
- `pkill -f` الگوی خود شل را هم می‌کشد (خود-کش) ⇒ bash با کد -1 تمام می‌شود؛ سرور فقط با ابزار فرایند، توقف با ابزار توقف.
- کپی توکن/رمز از موبایل پرخطاست ⇒ بعد از ذخیرهٔ هر توکن، اول verify (یا تست معادل) قبل از استفاده.
- کراولرهای حدسی ۴۰۴ می‌گیرند (`/top`، `/panel/questions`، `/panel/owner/{id}`) ⇒ اول لینک واقعی UI را از DOM بگیر.
- سرریز `sitemap.xml` خام در sweep کامل طبیعی است (سند XML برای ربات، نه UI) — ملاک سرریز، باتری موبایل روی صفحات UI است.
- لینک‌های میزبان موقت فایل (x0.at) بعداً حذف می‌شوند ⇒ پشتیبان همیشه `/root/*.zip` روی VPS.
- بات‌تست: کپی پروژه در `/tmp` (بدون `data/qa/shots`) → `PORT=8097 python3 run.py` → curl → kill با pid → پاک‌سازی.

**همکاری/گزارش**
- هیچ ادعایی بدون مدرک؛ «انجام شد» فقط با خروجی واقعی فرمان. چیزی که اجرا نشده ⇒ بنویس «اجرا نشد».
- اول شواهد، بعد فیکس: اگر چیزی «مدام تلاش می‌شود اما نمی‌شود»، قبل از هر تغییر گزارش زنده از خود سرور بگیر (دستور «تشخیص»).
- قابلیت بدون UI دیده‌شدنی = انجام‌نشده (§78).
- دسترسی مدیر حداکثری است؛ موعظهٔ امنیتی به خود مدیر ممنوع.
- ادعای `git push` ممنوع تا خروجی موفقش دیده شود.

---

## ۱۱) پین‌های نسخه و پروتکل تحویل

| جا | مقدار جاری |
|---|---|
| `VERSION.txt` | `280` |
| `server/adminbot.py:648` | `DIAG_LATEST = "280"` |
| `site/sw.js:9` | `const VERSION = 'bazarche-v280';` |
| `README.md` (۲۰ خط اول) | `# 🛒 دست گیر — v280` |
| `CURRENT-STATE.md` (خط اول) | `# وضعیت جاری پروژهٔ «دست گیر» — v280` |

هر تحویل: زیپ کامل تازه (بدون `data/` و بدون عکس‌های `admin-*.png`) با `tools/build_zip.py` + بامپ هر پنج‌جا با هم + کش‌شکن `?vNNN` در `server/ui.py` + به‌روزرسانی `WHATS-NEW.md` (قابلیت‌های جاری) و همین فایل + تست پین سبز + لینک دانلود و sha256 واقعی و **بازدانلود و مقایسهٔ بایت‌به‌بایت**. منبع حقیقت بسته: ریپوی `rezadb369-wq/369`.
