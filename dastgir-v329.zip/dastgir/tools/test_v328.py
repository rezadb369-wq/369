# -*- coding: utf-8 -*-
"""v328 — فقط ۵ مدل رایگان زندهٔ بای‌نارا در پنل و هر دو بات.

اجرا: python3 tools/test_v328.py
"""
import ast
import json
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
G, R, X = "\033[32m", "\033[31m", "\033[0m"
n = 0
fails = []


def ck(ok, label):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        print("  " + R + "✗ " + label + X)


TMP = tempfile.mkdtemp(prefix="v328-")
os.environ["BZ_DATA_DIR"] = os.environ.get("BZ_DATA_DIR", TMP)
os.environ.setdefault("BALE_ADMIN_TOKEN", "test-token-not-real")
os.environ.setdefault("BALE_ADMIN_SECRET", "s" * 40)
os.environ.setdefault("BALE_ADMIN_CHAT", "893219571")
sys.path.insert(0, os.path.join(ROOT, "server"))

import assistant as AI  # noqa: E402
import adminbot as A  # noqa: E402
import db  # noqa: E402
import app as APP  # noqa: E402

db.init()
ver = open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8").read().strip()
sw = open(os.path.join(ROOT, "site", "sw.js"), encoding="utf-8").read()
readme = open(os.path.join(ROOT, "README.md"), encoding="utf-8").read()
cs = open(os.path.join(ROOT, "docs", "collaboration", "CURRENT-STATE.md"),
          encoding="utf-8").read()

print("v328 — پنج مدل رایگان زنده")

ck(ver == "328" and A.DIAG_LATEST == "328", "پین نسخه 328")
ck("bazarche-v328" in sw, "sw.js v328")
ck("دست گیر — v328" in readme, "README v328")
ck("v328" in cs.splitlines()[0], "CURRENT-STATE خط اول")

FREE = (
    "ling-3.0-flash-sante-free",
    "agnes-2.5-flash",
    "ling-3.0-flash-fin-free",
    "ling-3.0-flash-vl-free",
    "nemotron-3-ultra-free",
)
ck(AI.BYNARA_MODELS == FREE, "BYNARA_MODELS = ۵ زنده")
ck(AI.FREE_MODELS == FREE, "FREE_MODELS alias")
ck(AI.BYNARA_MODELS[0] == "ling-3.0-flash-sante-free", "پیش‌فرض ling")
ck(AI.SITE_DEFAULT_BASE.rstrip("/") == "https://router.bynara.id/v1",
   "سایت = bynara")
ck(AI.SITE_DEFAULT_MODEL == "ling-3.0-flash-sante-free", "مدل سایت = ling")
ck(AI.BRAINS["bynara"][2] == "ling-3.0-flash-sante-free", "مغز ششم = ling")
ck("nemotron-3-super-free" not in AI.BYNARA_MODELS, "super خالی در فهرست نیست")
ck("nvidia/nemotron-3-ultra-550b-a55b:free" not in AI.BYNARA_MODELS,
   "شناسه اوپن‌روتر در فهرست بای‌نارا نیست")

kb = A.SITE_KEYBOARD["keyboard"]
flat = [c for row in kb for c in row]
ck(all(m in flat for m in FREE), "SITE_KEYBOARD همان ۵ مدل")
ck("openai/gpt-4o-mini" not in flat, "gpt-4o-mini از کیبورد خارج شد")

# picker accuracy: bynara id is NOT treated as openrouter/brain name
APP._agent_apply_model("ling-3.0-flash-sante-free")
ck(AI.brain_override() == "bynara", "چیپ ling → مغز bynara")
ck(AI.model_override() == "ling-3.0-flash-sante-free", "چیپ ling → مدل دقیق")
APP._agent_apply_model("agnes-2.5-flash")
ck(AI.model_override() == "agnes-2.5-flash", "چیپ agnes → مدل دقیق")
APP._agent_apply_model("auto")
ck(not AI.brain_override() and not AI.model_override(), "auto اوراید را پاک می‌کند")

msg, _ = A.do_brain_models("", "bynara")
ck("ling-3.0-flash-sante-free" in msg and "agnes-2.5-flash" in msg, "/مدل فهرست ۵ تا")
ck("nemotron-3-super-free" not in msg, "/مدل super ندارد")
msg, _ = A.do_brain_models("", "openrouter")
ck("۴۰۱" in msg or "401" in msg, "/مدل اوپن‌روتر صادقانه ۴۰۱")

# unknown id rejected without calling network
r = AI.test_free_model("gpt-4o-mini")
ck(not r.get("ok") and "نیست" in (r.get("error") or ""), "مدل خارج از فهرست رد")

brain = open(os.path.join(ROOT, "deploy", "brain.env"), encoding="utf-8").read()
ck("AI_SITE_BASE_URL=https://router.bynara.id/v1" in brain, "brain.env سایت بای‌نارا")
ck("AI_SITE_MODEL=ling-3.0-flash-sante-free" in brain, "brain.env مدل ling")
ck("AI_BASE_URL=https://router.bynara.id/v1" in brain, "brain.env AI_BASE بای‌نارا")
ck("sk-or-v1-" in brain, "کلید اوپن‌روتر هنوز در بسته است")

abrain = open(os.path.join(ROOT, "deploy", "apply-brain.sh"), encoding="utf-8").read()
ck("v328" in abrain and "bynara" in abrain.lower(), "apply-brain v328")
ck('ai_brain_active": "openrouter"' not in abrain, "apply-brain اوپن‌روتر را اجبار نمی‌کند")

frag = json.loads(open(os.path.join(ROOT, "deploy", "openclaw",
                                    "openclaw.fragment.json"), encoding="utf-8").read())
ck(len(frag["models"]["providers"]["bynara"]["models"]) == 5, "fragment ۵ مدل")
ck(frag["agents"]["defaults"]["model"]["primary"] == "bynara/ling-3.0-flash-sante-free",
   "fragment primary ling")

src_app = open(os.path.join(ROOT, "server", "app.py"), encoding="utf-8").read()
ck("test_free_model" in src_app, "model-test بای‌نارا")
ck("BYNARA_MODELS" in src_app and "list_models()" not in src_app.split("/api/agent/models")[1][:800],
   "/api/agent/models از BYNARA نه ۴۴۴ اوپن‌روتر")

src_vaf = open(os.path.join(ROOT, "server", "views_agent_full.py"), encoding="utf-8").read()
ck("۵ مدل" in src_vaf or "5 مدل" in src_vaf or "رایگان زنده" in src_vaf,
   "کارت مدل پنل متن رایگان زنده")
ck("openai/gpt-4o-mini" not in src_vaf, "کارت مدل بدون gpt-4o-mini")

src_desk = open(os.path.join(ROOT, "server", "views_agent_desk.py"), encoding="utf-8").read()
ck('data-model="ling-3.0-flash-sante-free"' in src_desk, "چیپ لینگ در میز")
ck("میز کار ایجنت — v328" in src_desk, "عنوان v328")

# same-model helper
ck(AI._same_model("ling-3.0-flash-sante-free", "ling-3.0-flash-sante-free"),
   "same model exact")
ck(not AI._same_model("agnes-2.5-flash", "ling-3.0-flash-sante-free"),
   "مدل دیگر رد")

needle = "55164" + "6991"
hits = []
for dirpath, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ("__pycache__", "data", ".git")]
    for fn in files:
        if fn.endswith((".pyc", ".zip", ".db")):
            continue
        rel = os.path.relpath(os.path.join(dirpath, fn), ROOT)
        if rel.replace("\\", "/").startswith("tools/test_"):
            continue
        fp = os.path.join(dirpath, fn)
        try:
            txt = open(fp, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        if needle in txt:
            hits.append(rel)
ck(not hits, "توکن ایجنت بله در درخت نیست" + ((" — " + ",".join(hits[:5])) if hits else ""))

for rel in ("server/assistant.py", "server/app.py", "server/adminbot.py",
            "server/agent_cmds.py", "server/views_agent_full.py",
            "server/views_agent_desk.py"):
    ast.parse(open(os.path.join(ROOT, rel), encoding="utf-8").read())
ck(True, "فایل‌های کلیدی parse")

print()
print("موفق: %d   ناموفق: %d" % (n, len(fails)))
if fails:
    for x in fails:
        print("  -", x)
    sys.exit(1)
print("همه موفق — v328 قفل شد.")
