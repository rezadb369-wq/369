# -*- coding: utf-8 -*-
"""v322 — میز کار تب‌دار /agent = /panel/agent + فرم محتوا.

اجرا: python3 tools/test_v322.py
"""
import ast
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
G, R, X = "\033[32m", "\033[31m", "\033[0m"
n = 0
fails = []


def ck(ok, label):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        print("  " + R + "✗ " + label + X)


TMP = tempfile.mkdtemp(prefix="v322-")
os.environ["BZ_DATA_DIR"] = os.environ.get("BZ_DATA_DIR", TMP)
os.environ.setdefault("BALE_ADMIN_TOKEN", "test-token-not-real")
os.environ.setdefault("BALE_ADMIN_SECRET", "s" * 40)
os.environ.setdefault("BALE_ADMIN_CHAT", "893219571")
sys.path.insert(0, os.path.join(ROOT, "server"))

import adminbot as A  # noqa: E402
import adminbot_content as CT  # noqa: E402
import db  # noqa: E402
import views_agent_desk as desk  # noqa: E402
import views_agent_full as V  # noqa: E402

db.init()
ver = open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8").read().strip()
sw = open(os.path.join(ROOT, "site", "sw.js"), encoding="utf-8").read()
readme = open(os.path.join(ROOT, "README.md"), encoding="utf-8").read()
cs = open(os.path.join(ROOT, "docs", "collaboration", "CURRENT-STATE.md"),
          encoding="utf-8").read()

print("v322 — میز کار تب‌دار + فرم محتوا")

ck(ver == A.DIAG_LATEST and ver.isdigit() and int(ver) >= 322, "پین نسخه ≥322")
ck(("bazarche-v" + ver) in sw, "sw.js با VERSION")
ck(("دست گیر — v" + ver) in readme, "README با VERSION")
ck(("v" + ver) in cs.splitlines()[0], "CURRENT-STATE خط اول با VERSION")

src_app = open(os.path.join(ROOT, "server", "app.py"), encoding="utf-8").read()
ck("/agent/content/biz" in src_app and "/panel/agent/content/biz" in src_app,
   "مسیر فرم ساخت کسب‌وکار دوقلو")
ck("/agent/content/wipe" in src_app and "handle_content" in src_app,
   "مسیر wipe + handle_content")
ck('&tab=" + urllib.parse.quote(tab)' in src_app or "&tab=" in src_app,
   "ریدایرکت تب را نگه می‌دارد")

src_desk = open(os.path.join(ROOT, "server", "views_agent_desk.py"),
                encoding="utf-8").read()
ck("def render_workbench" in src_desk and "def handle_content" in src_desk,
   "میز کار و handle_content")
ck("Arena" not in src_desk and "آرنا" not in src_desk,
   "بنر آرنا در میز کار نیست")
ck("PhonePilot" in src_desk, "هوش از سرور نه PhonePilot")

src_vaf = open(os.path.join(ROOT, "server", "views_agent_full.py"),
               encoding="utf-8").read()
ck("from views_agent_desk import render_workbench" in src_vaf,
   "هر دو صفحه از یک میز کار می‌آیند")
ck(src_vaf.count("from views_agent_desk import render_workbench") >= 2,
   "standalone و panel هر دو نازک‌اند")

s = db.get_settings()
html_a = V.agent_standalone_page(s, token="", q={})
html_p = V.agent_panel_page(s, token="t", q={})
ck("میز کار ایجنت" in html_a and "میز کار ایجنت" in html_p,
   "عنوان میز کار در هر دو مسیر")
ck('data-tab="today"' in html_a and 'data-tab="content"' in html_a,
   "تب امروز و محتوا")
ck("/agent/content/biz" in html_a and 'name="cat_slug"' in html_a,
   "فرم ساخت در /agent")
ck("/panel/agent/content/biz" in html_p, "فرم ساخت در /panel/agent")
ck("Arena" not in html_a and "آرنا" not in html_a, "HTML بدون آرنا")
ck("کسب‌وکار" in html_a, "کارت شمار زنده")

# فرم‌ها واقعاً ابزار را صدا می‌زنند (دیتابیس موقت — نه سایت زنده)
ok, msg = desk.handle_content("biz", {})
ck(not ok, "ساخت بدون نام رد می‌شود")
ok, msg = desk.handle_content("biz", {"name": "نانوایی نمونه", "cat_slug": "cafe",
                                      "phone": "03112345678", "city": "نجف‌آباد"})
ck(ok, "ساخت کسب‌وکار با فرم: " + str(msg)[:80])
row = db._one("SELECT id, name, status FROM businesses WHERE name=?",
              ("نانوایی نمونه",))
ck(bool(row) and row.get("name") == "نانوایی نمونه", "ردیف در دیتابیس نشست")
bid = int((row or {}).get("id") or 0)
ok, msg = desk.handle_content("biz-del", {"id": str(bid)})
ck(ok, "حذف یکی با فرم")
gone = db._one("SELECT id FROM businesses WHERE id=?", (bid,))
ck(gone is None, "پس از حذف ردیف نیست")

ok, msg = desk.handle_content("wipe", {"confirm": "نه"})
ck(not ok, "wipe بدون جملهٔ دقیق رد می‌شود")

ok, msg = desk.handle_content("setting", {"value": "دست‌گیر آزمایشی"})
ck(ok, "تنظیم نام سایت با فرم")

ck("business_save" in CT.TOOLS and "businesses_wipe" in CT.TOOLS,
   "ابزار محتوا سر جایش")
ck("business_save" in CT._CONFIRM_TOOLS, "نوشتن هنوز تأیید می‌خواهد (چت)")

# مهمان: مسیر فرم زیر گیت /agent/
ck('if path.startswith("/agent/")' in src_app and "agent_ok" in src_app,
   "گیت نشست روی /agent/*")
ck('json_out({"ok": False, "error": "agent key required"}, 403)' in src_app
   or 'error": "agent key required"' in src_app,
   "مهمان /agent/* → ۴۰۳")

needle = "55164" + "6991"
hits = []
for dirpath, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ("__pycache__", "data", ".git")]
    for fn in files:
        if fn.endswith((".pyc", ".zip", ".db")):
            continue
        rel = os.path.relpath(os.path.join(dirpath, fn), ROOT)
        if rel.replace("\\", "/").startswith("tools/test_"):
            continue
        fp = os.path.join(dirpath, fn)
        try:
            txt = open(fp, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        if needle in txt:
            hits.append(rel)
ck(not hits, "توکن ایجنت بله در درخت نیست")

for rel in ("server/views_agent_desk.py", "server/views_agent_full.py",
            "server/app.py"):
    ast.parse(open(os.path.join(ROOT, rel), encoding="utf-8").read())
ck(True, "parse فایل‌های v322")

print()
print("موفق: %d   ناموفق: %d" % (n, len(fails)))
if fails:
    for x in fails:
        print("  -", x)
    sys.exit(1)
print("همه موفق — v322 قفل شد.")
