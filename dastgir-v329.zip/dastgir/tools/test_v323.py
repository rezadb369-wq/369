# -*- coding: utf-8 -*-
"""v323 — تب گفت‌وگو و درآمد روی میز کار ایجنت.

اجرا: python3 tools/test_v323.py
"""
import ast
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
G, R, X = "\033[32m", "\033[31m", "\033[0m"
n = 0
fails = []


def ck(ok, label):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        print("  " + R + "✗ " + label + X)


TMP = tempfile.mkdtemp(prefix="v323-")
os.environ["BZ_DATA_DIR"] = os.environ.get("BZ_DATA_DIR", TMP)
os.environ.setdefault("BALE_ADMIN_TOKEN", "test-token-not-real")
os.environ.setdefault("BALE_ADMIN_SECRET", "s" * 40)
os.environ.setdefault("BALE_ADMIN_CHAT", "893219571")
sys.path.insert(0, os.path.join(ROOT, "server"))

import adminbot as A  # noqa: E402
import adminbot_content as CT  # noqa: E402
import db  # noqa: E402
import views_agent_desk as desk  # noqa: E402
import views_agent_full as V  # noqa: E402

db.init()
ver = open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8").read().strip()
sw = open(os.path.join(ROOT, "site", "sw.js"), encoding="utf-8").read()
readme = open(os.path.join(ROOT, "README.md"), encoding="utf-8").read()
cs = open(os.path.join(ROOT, "docs", "collaboration", "CURRENT-STATE.md"),
          encoding="utf-8").read()

print("v323 — گفت‌وگو و درآمد")

ck(ver == A.DIAG_LATEST and ver.isdigit() and int(ver) >= 323, "پین نسخه ≥323")
ck("bazarche-v" + ver in sw, "sw.js با VERSION")
ck("دست گیر — v" + ver in readme, "README با VERSION")
ck("v" + ver in cs.splitlines()[0] or "v323" in cs.splitlines()[0],
   "CURRENT-STATE خط اول نسخه")

src_app = open(os.path.join(ROOT, "server", "app.py"), encoding="utf-8").read()
ck('"/agent/talk"' in src_app and '"/panel/agent/talk"' in src_app,
   "مسیر /agent/talk دوقلو")
ck('"/agent/money"' in src_app and '"/panel/agent/money"' in src_app,
   "مسیر /agent/money دوقلو")
ck("handle_talk" in src_app and "handle_money" in src_app,
   "handle_talk/handle_money در app")

src_desk = open(os.path.join(ROOT, "server", "views_agent_desk.py"),
                encoding="utf-8").read()
ck("def handle_talk" in src_desk and "def handle_money" in src_desk,
   "توابع تب گفت‌وگو و درآمد")
ck("Arena" not in src_desk and "آرنا" not in src_desk, "بدون آرنا")
ck("shell_exec" not in CT.IMMEDIATE_TOOLS, "shell_exec فوری نیست")

s = db.get_settings()
html_a = V.agent_standalone_page(s, token="", q={})
html_p = V.agent_panel_page(s, token="t", q={})
ck("میز کار ایجنت" in html_a and "میز کار ایجنت" in html_p,
   "عنوان میز کار در هر دو مسیر")
ck('data-tab="talk"' in html_a and 'data-tab="money"' in html_a,
   "تب گفت‌وگو و درآمد")
ck("/agent/talk" in html_a and "/agent/money" in html_a, "فرم‌ها روی /agent")
ck("/panel/agent/talk" in html_p and "/panel/agent/money" in html_p,
   "فرم‌ها روی /panel/agent")
ck("ارسال همگانی" in html_a, "تأیید همگانی در UI")
ck("Arena" not in html_a and "آرنا" not in html_a, "HTML بدون آرنا")

# کسب‌وکار پایه برای بقیهٔ فرم‌ها (دیتابیس موقت)
ok, msg = desk.handle_content("biz", {"name": "کافه فاز۲", "cat_slug": "cafe"})
ck(ok, "کسب‌وکار پایه: " + str(msg)[:60])
biz = db._one("SELECT id FROM businesses WHERE name=?", ("کافه فاز۲",))
bid = int((biz or {}).get("id") or 0)
ck(bid > 0, "شناسه کسب‌وکار")

db.add_review(bid, "علی", 5, "عالی بود")
rev = db._one("SELECT id, status FROM reviews WHERE biz_id=?", (bid,))
ok, msg = desk.handle_talk("review", {})
ck(not ok, "نظر بدون id رد")
ok, msg = desk.handle_talk("review", {"id": str(rev["id"]), "action": "approve"})
ck(ok, "تأیید نظر: " + str(msg)[:80])
st = db._one("SELECT status FROM reviews WHERE id=?", (rev["id"],))
ck((st or {}).get("status") == "approved", "نظر approved شد")

tid, _mid = db.create_ticket("موضوع تست", "متن تیکت", name="مینا")
ok, msg = desk.handle_talk("ticket", {"id": str(tid), "body": ""})
ck(not ok, "پاسخ خالی رد")
ok, msg = desk.handle_talk("ticket", {"id": str(tid), "body": "سلام، بررسی شد."})
ck(ok, "پاسخ تیکت: " + str(msg)[:80])

ok, msg = desk.handle_talk("broadcast", {"text": "سلام", "confirm": "نه"})
ck(not ok, "همگانی بدون جملهٔ دقیق رد")

ok, msg = desk.handle_money("coupon", {"code": "SPRING", "title": "بهار",
                                       "percent": "20"})
ck(ok, "کد تخفیف: " + str(msg)[:80])
cp = db._one("SELECT code, percent FROM coupons WHERE code=?", ("SPRING",))
ck(bool(cp) and int(cp.get("percent") or 0) == 20, "کد در DB")

ok, msg = desk.handle_money("ad", {"title": "بنر صفحه نخست", "url": "/",
                                   "slot": "home"})
ck(ok, "بنر: " + str(msg)[:80])
ad = db._one("SELECT title, slot FROM ads WHERE title=?", ("بنر صفحه نخست",))
ck(bool(ad) and ad.get("slot") == "home", "بنر در DB")

ok, msg = desk.handle_money("deal", {"biz_id": str(bid), "title": "۲۰٪ عصرانه",
                                    "percent": "20", "ends": "2026-12-31 23:59"})
ck(ok, "پیشنهاد روز: " + str(msg)[:80])

ok, msg = desk.handle_money("badge", {"name": "ویژه محله", "color": "#059669"})
ck(ok, "نشان: " + str(msg)[:80])

ok, msg = desk.handle_money("sub", {"biz_id": str(bid), "plan_slug": "plus",
                                   "months": "3"})
ck(ok, "اشتراک: " + str(msg)[:80])
sub = db.subscription_of(bid)
ck(bool(sub) and (sub.get("plan_slug") == "plus" or sub.get("status") == "active"),
   "اشتراک فعال")

rid = db.add_report("business", bid, "spam", "متن گزارش", "مهمان", bid)
ok, msg = desk.handle_talk("report", {"id": str(rid), "action": "resolve"})
ck(ok, "حل گزارش: " + str(msg)[:80])

ck("review_moderate" in CT.TOOLS and "subscription_set" in CT.TOOLS,
   "ابزار گفت‌وگو/درآمد سر جایش")
ck('if path.startswith("/agent/")' in src_app, "گیت /agent/*")
ck('error": "agent key required"' in src_app, "مهمان ۴۰۳")

needle = "55164" + "6991"
hits = []
for dirpath, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ("__pycache__", "data", ".git")]
    for fn in files:
        if fn.endswith((".pyc", ".zip", ".db")):
            continue
        rel = os.path.relpath(os.path.join(dirpath, fn), ROOT)
        if rel.replace("\\", "/").startswith("tools/test_"):
            continue
        fp = os.path.join(dirpath, fn)
        try:
            txt = open(fp, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        if needle in txt:
            hits.append(rel)
ck(not hits, "توکن ایجنت بله در درخت نیست")

for rel in ("server/views_agent_desk.py", "server/views_agent_full.py",
            "server/app.py"):
    ast.parse(open(os.path.join(ROOT, rel), encoding="utf-8").read())
ck(True, "parse فایل‌های v323")

print()
print("موفق: %d   ناموفق: %d" % (n, len(fails)))
if fails:
    for x in fails:
        print("  -", x)
    sys.exit(1)
print("همه موفق — v323 قفل شد.")
