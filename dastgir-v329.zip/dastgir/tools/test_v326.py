# -*- coding: utf-8 -*-
"""v326 — تب محتوا کامل: کالا/دسته/صفحه/مقاله/ویرایش/رنگ.

اجرا: python3 tools/test_v326.py
"""
import ast
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
G, R, X = "\033[32m", "\033[31m", "\033[0m"
n = 0
fails = []


def ck(ok, label):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        print("  " + R + "✗ " + label + X)


TMP = tempfile.mkdtemp(prefix="v326-")
os.environ["BZ_DATA_DIR"] = os.environ.get("BZ_DATA_DIR", TMP)
os.environ.setdefault("BALE_ADMIN_TOKEN", "test-token-not-real")
os.environ.setdefault("BALE_ADMIN_SECRET", "s" * 40)
os.environ.setdefault("BALE_ADMIN_CHAT", "893219571")
sys.path.insert(0, os.path.join(ROOT, "server"))

import adminbot as A  # noqa: E402
import adminbot_content as CT  # noqa: E402
import db  # noqa: E402
import views_agent_desk as desk  # noqa: E402
import views_agent_full as V  # noqa: E402

db.init()
ver = open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8").read().strip()
sw = open(os.path.join(ROOT, "site", "sw.js"), encoding="utf-8").read()
readme = open(os.path.join(ROOT, "README.md"), encoding="utf-8").read()
cs = open(os.path.join(ROOT, "docs", "collaboration", "CURRENT-STATE.md"),
          encoding="utf-8").read()

print("v326 — محتوا کامل")

ck(ver == A.DIAG_LATEST and ver.isdigit() and int(ver) >= 326, "پین نسخه ≥326")
ck("bazarche-v" + ver in sw, "sw.js با VERSION")
ck("دست گیر — v" + ver in readme, "README با VERSION")
ck("v" + ver in cs.splitlines()[0] or "v326" in cs.splitlines()[0],
   "CURRENT-STATE خط اول نسخه")

src_app = open(os.path.join(ROOT, "server", "app.py"), encoding="utf-8").read()
ck('"/agent/content/item"' in src_app and '"/panel/agent/content/item"' in src_app,
   "مسیر کالا دوقلو")
ck('"/agent/content/page"' in src_app and '"/agent/content/post"' in src_app,
   "مسیر صفحه و مقاله")
ck('"/agent/content/biz-edit"' in src_app and '"/agent/content/color"' in src_app,
   "مسیر ویرایش و رنگ")
ck('"slug"' in src_app and '"descr"' in src_app, "کلید فرم slug/descr")

src_desk = open(os.path.join(ROOT, "server", "views_agent_desk.py"),
                encoding="utf-8").read()
ck('kind == "item"' in src_desk and 'kind == "page"' in src_desk, "توابع محتوا")
ck("Arena" not in src_desk and "آرنا" not in src_desk, "بدون آرنا")
ck("shell_exec" not in CT.IMMEDIATE_TOOLS, "shell_exec فوری نیست")

s = db.get_settings()
html_a = V.agent_standalone_page(s, token="", q={})
html_p = V.agent_panel_page(s, token="t", q={})
ck("میز کار ایجنت" in html_a and "میز کار ایجنت" in html_p,
   "عنوان میز کار در هر دو مسیر")
ck("/agent/content/item" in html_a and "/agent/content/page" in html_a,
   "فرم کالا/صفحه روی /agent")
ck("/panel/agent/content/item" in html_p, "فرم کالا روی /panel/agent")
ck("Arena" not in html_a and "آرنا" not in html_a, "HTML بدون آرنا")
ck('data-tab="play"' in html_a, "تب دستور سر جایش")
ck(len(CT.TOOLS) == 72, "تعداد ابزار ۷۲")

ok, msg = desk.handle_content("biz", {
    "name": "کافه فاز۵", "cat_slug": "cafe", "city": "نجف‌آباد"})
ck(ok, "ساخت کسب‌وکار: " + str(msg)[:80])
row = db._one("SELECT id FROM businesses WHERE name=?", ("کافه فاز۵",))
ck(bool(row), "کسب‌وکار در DB")
bid = str((row or {}).get("id") or 0)

ok, msg = desk.handle_content("biz-edit", {
    "id": bid, "field": "phone", "value": "03142419999"})
ck(ok, "ویرایش تلفن: " + str(msg)[:80])
ck((db._one("SELECT phone FROM businesses WHERE id=?", (int(bid),)) or {}
    ).get("phone") == "03142419999", "تلفن ذخیره شد")

ok, msg = desk.handle_content("biz-edit", {"id": "0", "field": "phone", "value": "1"})
ck(not ok, "ویرایش بدون کسب‌وکار رد")

ok, msg = desk.handle_content("item", {
    "biz_id": bid, "title": "نان سنگک", "price": "40000", "descr": "تازه"})
ck(ok, "کالا: " + str(msg)[:80])
ck(desk._n("SELECT COUNT(*) AS n FROM items") >= 1, "کالا در DB")

ok, msg = desk.handle_content("item", {"biz_id": "0", "title": "x"})
ck(not ok, "کالا بدون کسب‌وکار رد")

ok, msg = desk.handle_content("cat", {"name": "قنادی محله"})
ck(ok, "دسته: " + str(msg)[:80])
ck(bool(db._one("SELECT id FROM categories WHERE name=?", ("قنادی محله",))),
   "دسته در DB")

ok, msg = desk.handle_content("page", {
    "slug": "about", "title": "درباره ما",
    "body": "متن درباره دست‌گیر برای تست فاز پنج."})
ck(ok, "صفحه about: " + str(msg)[:80])
ck((db._one("SELECT title FROM pages WHERE slug='about'") or {}
    ).get("title") == "درباره ما", "صفحه ذخیره شد")
ok, msg = desk.handle_content("page", {"slug": "home", "title": "x", "body": "y"})
ck(not ok, "صفحه ناشناخته رد")

ok, msg = desk.handle_content("post", {
    "title": "جشنواره پاییز", "body": "خبر جشنواره."})
ck(ok, "مقاله: " + str(msg)[:80])
ck(bool(db._one("SELECT id FROM posts WHERE title=?", ("جشنواره پاییز",))),
   "مقاله در DB")

ok, msg = desk.handle_content("color", {
    "key": "color_primary", "value": "#0b6059"})
ck(ok, "رنگ: " + str(msg)[:80])
ck(db.get_settings().get("color_primary") == "#0b6059", "رنگ در تنظیمات")
ok, msg = desk.handle_content("color", {"key": "color_primary", "value": "red"})
ck(not ok, "رنگ نامعتبر رد")

ck("item_save" in CT.TOOLS and "page" in CT.TOOLS and "post_save" in CT.TOOLS,
   "ابزار محتوا سر جایش")
ck('if path.startswith("/agent/")' in src_app, "گیت /agent/*")
ck('error": "agent key required"' in src_app, "مهمان ۴۰۳")

needle = "55164" + "6991"
hits = []
for dirpath, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ("__pycache__", "data", ".git")]
    for fn in files:
        if fn.endswith((".pyc", ".zip", ".db")):
            continue
        rel = os.path.relpath(os.path.join(dirpath, fn), ROOT)
        if rel.replace("\\", "/").startswith("tools/test_"):
            continue
        fp = os.path.join(dirpath, fn)
        try:
            txt = open(fp, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        if needle in txt:
            hits.append(rel)
ck(not hits, "توکن ایجنت بله در درخت نیست")

for rel in ("server/views_agent_desk.py", "server/views_agent_full.py",
            "server/app.py"):
    ast.parse(open(os.path.join(ROOT, rel), encoding="utf-8").read())
ck(True, "parse فایل‌های v326")

print()
print("موفق: %d   ناموفق: %d" % (n, len(fails)))
if fails:
    for x in fails:
        print("  -", x)
    sys.exit(1)
print("همه موفق — v326 قفل شد.")
