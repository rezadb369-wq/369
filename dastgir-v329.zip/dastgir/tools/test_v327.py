# -*- coding: utf-8 -*-
"""v327 — نوبت امروز + مغز ربات جدا از چت پنل.

اجرا: python3 tools/test_v327.py
"""
import ast
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
G, R, X = "\033[32m", "\033[31m", "\033[0m"
n = 0
fails = []


def ck(ok, label):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        print("  " + R + "✗ " + label + X)


TMP = tempfile.mkdtemp(prefix="v327-")
os.environ["BZ_DATA_DIR"] = os.environ.get("BZ_DATA_DIR", TMP)
os.environ.setdefault("BALE_ADMIN_TOKEN", "test-token-not-real")
os.environ.setdefault("BALE_ADMIN_SECRET", "s" * 40)
os.environ.setdefault("BALE_ADMIN_CHAT", "893219571")
sys.path.insert(0, os.path.join(ROOT, "server"))

import adminbot as A  # noqa: E402
import adminbot_content as CT  # noqa: E402
import db  # noqa: E402
import views_agent_desk as desk  # noqa: E402
import views_agent_full as V  # noqa: E402

db.init()
ver = open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8").read().strip()
sw = open(os.path.join(ROOT, "site", "sw.js"), encoding="utf-8").read()
readme = open(os.path.join(ROOT, "README.md"), encoding="utf-8").read()
cs = open(os.path.join(ROOT, "docs", "collaboration", "CURRENT-STATE.md"),
          encoding="utf-8").read()

print("v327 — نوبت و مغز")

ck(ver == A.DIAG_LATEST and ver.isdigit() and int(ver) >= 327, "پین نسخه ≥327")
ck(("bazarche-v"+ver) in sw, "sw.js با VERSION")
ck(("دست گیر — v"+ver) in readme, "README با VERSION")
ck(("v"+ver) in cs.splitlines()[0] or "v327" in cs.splitlines()[0], "CURRENT-STATE نسخه")

src_desk = open(os.path.join(ROOT, "server", "views_agent_desk.py"),
                encoding="utf-8").read()
ck('kind == "booking"' in src_desk, "handle_talk نوبت")
ck("def _brain_status_html" in src_desk, "کارت مغز ربات")
ck("def _booking_table" in src_desk, "جدول نوبت")
ck("Arena" not in src_desk and "آرنا" not in src_desk, "بدون آرنا")
ck("shell_exec" not in CT.IMMEDIATE_TOOLS, "shell_exec فوری نیست")
ck("booking_status" in CT.TOOLS, "ابزار booking_status")

s = db.get_settings()
html_a = V.agent_standalone_page(s, token="", q={})
html_p = V.agent_panel_page(s, token="t", q={})
ck("میز کار ایجنت — v" in html_a and "میز کار ایجنت — v" in html_p,
   "عنوان میز کار در هر دو مسیر")
ck("نوبت جدید" in html_a and "booking_status" in html_a, "نوبت در امروز")
ck('id="brain-status"' in html_a and "مغز ربات بله" in html_a,
   "کارت مغز جدا از چت")
ck("سوئیچ خودکار نیست" in html_a, "بدون سوئیچ خودکار مغز")
ck("Arena" not in html_a and "آرنا" not in html_a, "HTML بدون آرنا")
ck('data-tab="play"' in html_a and "/agent/content/item" in html_a,
   "فاز ۴ و ۵ سر جایشان")
ck(len(CT.TOOLS) == 72, "تعداد ابزار ۷۲")

ok, msg = desk.handle_content("biz", {"name": "کافه نوبت", "cat_slug": "cafe"})
ck(ok, "کسب‌وکار پایه: " + str(msg)[:80])
bid = (db._one("SELECT id FROM businesses WHERE name=?", ("کافه نوبت",)) or {}).get("id")
ck(bool(bid), "شناسه کسب‌وکار")
kid = db.add_booking(bid, "علی", "09131234567", "2026-09-22", "10:00", "تست")
ck(int(kid or 0) > 0, "نوبت ثبت شد")
html2 = V.agent_standalone_page(db.get_settings(), token="", q={})
ck('name="kind" value="booking"' in html2, "فرم نوبت وقتی نوبت هست")
ok, msg = desk.handle_talk("booking", {"id": str(kid), "status": "confirmed"})
ck(ok, "تأیید نوبت: " + str(msg)[:80])
st = (db._one("SELECT status FROM bookings WHERE id=?", (kid,)) or {}).get("status")
ck(st == "confirmed", "وضعیت confirmed")
ok, msg = desk.handle_talk("booking", {"id": "0", "status": "confirmed"})
ck(not ok, "نوبت بدون شناسه رد")
ok, msg = desk.handle_talk("booking", {"id": str(kid), "status": "nope"})
ck(not ok, "وضعیت نامعتبر رد")

ck('if path.startswith("/agent/")' in open(
    os.path.join(ROOT, "server", "app.py"), encoding="utf-8").read(),
   "گیت /agent/*")

needle = "55164" + "6991"
hits = []
for dirpath, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ("__pycache__", "data", ".git")]
    for fn in files:
        if fn.endswith((".pyc", ".zip", ".db")):
            continue
        rel = os.path.relpath(os.path.join(dirpath, fn), ROOT)
        if rel.replace("\\", "/").startswith("tools/test_"):
            continue
        fp = os.path.join(dirpath, fn)
        try:
            txt = open(fp, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        if needle in txt:
            hits.append(rel)
ck(not hits, "توکن ایجنت بله در درخت نیست")

for rel in ("server/views_agent_desk.py", "server/views_agent_full.py",
            "server/app.py"):
    ast.parse(open(os.path.join(ROOT, rel), encoding="utf-8").read())
ck(True, "parse فایل‌های v327")

print()
print("موفق: %d   ناموفق: %d" % (n, len(fails)))
if fails:
    for x in fails:
        print("  -", x)
    sys.exit(1)
print("همه موفق — v327 قفل شد.")
