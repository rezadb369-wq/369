# -*- coding: utf-8 -*-
"""v325 — تب دستور چندمرحله‌ای روی میز کار ایجنت.

اجرا: python3 tools/test_v325.py
"""
import ast
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
G, R, X = "\033[32m", "\033[31m", "\033[0m"
n = 0
fails = []


def ck(ok, label):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        print("  " + R + "✗ " + label + X)


TMP = tempfile.mkdtemp(prefix="v325-")
os.environ["BZ_DATA_DIR"] = os.environ.get("BZ_DATA_DIR", TMP)
os.environ.setdefault("BALE_ADMIN_TOKEN", "test-token-not-real")
os.environ.setdefault("BALE_ADMIN_SECRET", "s" * 40)
os.environ.setdefault("BALE_ADMIN_CHAT", "893219571")
sys.path.insert(0, os.path.join(ROOT, "server"))

import adminbot as A  # noqa: E402
import adminbot_content as CT  # noqa: E402
import db  # noqa: E402
import views_agent_desk as desk  # noqa: E402
import views_agent_full as V  # noqa: E402

db.init()
ver = open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8").read().strip()
sw = open(os.path.join(ROOT, "site", "sw.js"), encoding="utf-8").read()
readme = open(os.path.join(ROOT, "README.md"), encoding="utf-8").read()
cs = open(os.path.join(ROOT, "docs", "collaboration", "CURRENT-STATE.md"),
          encoding="utf-8").read()

print("v325 — دستور")

ck(ver == A.DIAG_LATEST and ver.isdigit() and int(ver) >= 325, "پین نسخه ≥325")
ck("bazarche-v" + ver in sw, "sw.js با VERSION")
ck("دست گیر — v" + ver in readme, "README با VERSION")
ck("v" + ver in cs.splitlines()[0] or "v325" in cs.splitlines()[0],
   "CURRENT-STATE خط اول نسخه")

src_app = open(os.path.join(ROOT, "server", "app.py"), encoding="utf-8").read()
ck('"/agent/play"' in src_app and '"/panel/agent/play"' in src_app,
   "مسیر /agent/play دوقلو")
ck("handle_play" in src_app, "handle_play در app")
ck('"recipe"' in src_app, "کلید فرم recipe")

src_desk = open(os.path.join(ROOT, "server", "views_agent_desk.py"),
                encoding="utf-8").read()
ck("def handle_play" in src_desk and "def play_steps" in src_desk,
   "تابع تب دستور")
ck("Arena" not in src_desk and "آرنا" not in src_desk, "بدون آرنا")
ck("shell_exec" not in CT.IMMEDIATE_TOOLS, "shell_exec فوری نیست")
ck("اجرای دستور" in src_desk, "جملهٔ تأیید دستور")
ck("shell_exec" in desk._PLAY_BLOCK and "businesses_wipe" in desk._PLAY_BLOCK,
   "شل و wipe در دستور مسدود")
ck("service_restart" not in src_desk.split("def play_steps")[1].split(
    "def handle_play")[0], "service_restart در دستورها نیست")

s = db.get_settings()
html_a = V.agent_standalone_page(s, token="", q={})
html_p = V.agent_panel_page(s, token="t", q={})
ck("میز کار ایجنت" in html_a and "میز کار ایجنت" in html_p,
   "عنوان میز کار در هر دو مسیر")
ck('data-tab="play"' in html_a and 'id="tab-play"' in html_a, "تب دستور")
ck("/agent/play" in html_a, "فرم‌ها روی /agent")
ck("/panel/agent/play" in html_p, "فرم‌ها روی /panel/agent")
ck("اجرای دستور" in html_a, "تأیید دستور در UI")
ck("پنج کسب‌وکار نمونه" in html_a, "دستور نمونه در UI")
ck("Arena" not in html_a and "آرنا" not in html_a, "HTML بدون آرنا")
ck(len(CT.TOOLS) == 72, "تعداد ابزار ۷۲")

before = desk._n("SELECT COUNT(*) AS n FROM businesses")
ok, msg = desk.handle_play("sample5", {})
ck(not ok and "پیش‌نمایش" in str(msg) and "اجرای دستور" in str(msg),
   "بدون تأیید = پیش‌نمایش: " + str(msg)[:80])
after = desk._n("SELECT COUNT(*) AS n FROM businesses")
ck(after == before, "پیش‌نمایش کسب‌وکار نساخت")
last = desk._play_load()
ck(last.get("phase") == "preview" and last.get("recipe") == "sample5",
   "last پیش‌نمایش ذخیره شد")

ok, msg = desk.handle_play("sample5", {"confirm": "اجرای دستور"})
ck(ok, "نمونه با تأیید: " + str(msg)[:100])
names = [b["name"] for b in desk._SAMPLE_BIZ]
have = []
for nm in names:
    row = db._one("SELECT id FROM businesses WHERE name=?", (nm,))
    have.append(bool(row))
ck(all(have), "پنج کسب‌وکار نمونه ساخته شد")
ck(desk._n("SELECT COUNT(*) AS n FROM businesses") >= 5, "حداقل ۵ کسب‌وکار")

ok, msg = desk.handle_play("sample5", {"confirm": "اجرای دستور"})
ck(ok and "رد" in str(msg), "اجرای دوباره نام تکراری را رد می‌کند: " + str(msg)[:80])
last = desk._play_load()
ck(last.get("phase") == "done" and int(last.get("skip_n") or 0) >= 5,
   "۵ رد در اجرای دوم")

ok, msg = desk.handle_play("checkup", {})
ck(not ok and "پیش‌نمایش" in str(msg), "بررسی بدون تأیید = پیش‌نمایش")
ok, msg = desk.handle_play("checkup", {"confirm": "اجرای دستور"})
ck(ok, "بررسی با تأیید: " + str(msg)[:100])

ok, msg = desk.handle_play("queue", {"confirm": "اجرای دستور"})
ck(ok, "صف با تأیید: " + str(msg)[:80])

ok, msg = desk.handle_play("sales", {"confirm": "اجرای دستور"})
ck(ok, "فروش با تأیید: " + str(msg)[:80])
coup = db._one("SELECT id FROM coupons WHERE code=?", ("PLAY325",))
ck(bool(coup), "کد PLAY325 ساخته شد")

ok, msg = desk.handle_play("compose", {})
ck(not ok and "خالی" in str(msg), "سفارشی خالی رد")
ok, msg = desk.handle_play("compose", {"p_health": "1"})
ck(not ok and "پیش‌نمایش" in str(msg), "سفارشی بدون تأیید = پیش‌نمایش")
ok, msg = desk.handle_play(
    "compose", {"p_health": "1", "confirm": "اجرای دستور"})
ck(ok, "سفارشی سلامت با تأیید: " + str(msg)[:80])

ok, msg = desk.handle_play(
    "compose",
    {"steps": "shell_exec\nbusinesses_wipe", "confirm": "اجرای دستور"})
ck(ok, "شل/wipe در سفارشی اجرا نشد (رد شد): " + str(msg)[:80])
last = desk._play_load()
blocked = [st for st in (last.get("steps") or []) if st.get("skip")]
ck(len(blocked) >= 2, "دو خط مسدود در last")

ok, msg = desk.handle_play("nope", {})
ck(not ok, "دستور ناشناخته رد")

ck("backup_now" in CT.TOOLS and "business_save" in CT.TOOLS, "ابزار محتوا سر جایش")
ck('if path.startswith("/agent/")' in src_app, "گیت /agent/*")
ck('error": "agent key required"' in src_app, "مهمان ۴۰۳")

needle = "55164" + "6991"
hits = []
for dirpath, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ("__pycache__", "data", ".git")]
    for fn in files:
        if fn.endswith((".pyc", ".zip", ".db")):
            continue
        rel = os.path.relpath(os.path.join(dirpath, fn), ROOT)
        if rel.replace("\\", "/").startswith("tools/test_"):
            continue
        fp = os.path.join(dirpath, fn)
        try:
            txt = open(fp, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        if needle in txt:
            hits.append(rel)
ck(not hits, "توکن ایجنت بله در درخت نیست")

for rel in ("server/views_agent_desk.py", "server/views_agent_full.py",
            "server/app.py"):
    ast.parse(open(os.path.join(ROOT, rel), encoding="utf-8").read())
ck(True, "parse فایل‌های v325")

print()
print("موفق: %d   ناموفق: %d" % (n, len(fails)))
if fails:
    for x in fails:
        print("  -", x)
    sys.exit(1)
print("همه موفق — v325 قفل شد.")
