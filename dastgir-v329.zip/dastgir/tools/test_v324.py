# -*- coding: utf-8 -*-
"""v324 — تب سیستم روی میز کار ایجنت.

اجرا: python3 tools/test_v324.py
"""
import ast
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
G, R, X = "\033[32m", "\033[31m", "\033[0m"
n = 0
fails = []


def ck(ok, label):
    global n
    if ok:
        n += 1
        print("  " + G + "✓" + X + " " + label)
    else:
        fails.append(label)
        print("  " + R + "✗ " + label + X)


TMP = tempfile.mkdtemp(prefix="v324-")
os.environ["BZ_DATA_DIR"] = os.environ.get("BZ_DATA_DIR", TMP)
os.environ.setdefault("BALE_ADMIN_TOKEN", "test-token-not-real")
os.environ.setdefault("BALE_ADMIN_SECRET", "s" * 40)
os.environ.setdefault("BALE_ADMIN_CHAT", "893219571")
sys.path.insert(0, os.path.join(ROOT, "server"))

import adminbot as A  # noqa: E402
import adminbot_content as CT  # noqa: E402
import db  # noqa: E402
import views_agent_desk as desk  # noqa: E402
import views_agent_full as V  # noqa: E402

db.init()
ver = open(os.path.join(ROOT, "VERSION.txt"), encoding="utf-8").read().strip()
sw = open(os.path.join(ROOT, "site", "sw.js"), encoding="utf-8").read()
readme = open(os.path.join(ROOT, "README.md"), encoding="utf-8").read()
cs = open(os.path.join(ROOT, "docs", "collaboration", "CURRENT-STATE.md"),
          encoding="utf-8").read()

print("v324 — سیستم")

ck(ver == A.DIAG_LATEST and ver.isdigit() and int(ver) >= 324, "پین نسخه ≥324")
ck("bazarche-v" + ver in sw, "sw.js با VERSION")
ck("دست گیر — v" + ver in readme, "README با VERSION")
ck("v" + ver in cs.splitlines()[0] or "v324" in cs.splitlines()[0],
   "CURRENT-STATE خط اول نسخه")

src_app = open(os.path.join(ROOT, "server", "app.py"), encoding="utf-8").read()
ck('"/agent/sys"' in src_app and '"/panel/agent/sys"' in src_app,
   "مسیر /agent/sys دوقلو")
ck("handle_sys" in src_app, "handle_sys در app")
ck('"cmd"' in src_app and '"query"' in src_app, "کلید فرم cmd/q")

src_desk = open(os.path.join(ROOT, "server", "views_agent_desk.py"),
                encoding="utf-8").read()
ck("def handle_sys" in src_desk, "تابع تب سیستم")
ck("Arena" not in src_desk and "آرنا" not in src_desk, "بدون آرنا")
ck("shell_exec" not in CT.IMMEDIATE_TOOLS, "shell_exec فوری نیست")
ck("اجرای فرمان" in src_desk, "جملهٔ تأیید ترمینال")

s = db.get_settings()
html_a = V.agent_standalone_page(s, token="", q={})
html_p = V.agent_panel_page(s, token="t", q={})
ck("میز کار ایجنت" in html_a and "میز کار ایجنت" in html_p,
   "عنوان میز کار در هر دو مسیر")
ck('data-tab="sys"' in html_a and 'id="tab-sys"' in html_a, "تب سیستم")
ck("/agent/sys" in html_a, "فرم‌ها روی /agent")
ck("/panel/agent/sys" in html_p, "فرم‌ها روی /panel/agent")
ck("اجرای فرمان" in html_a, "تأیید ترمینال در UI")
ck("Arena" not in html_a and "آرنا" not in html_a, "HTML بدون آرنا")
ck("all-tools-guide" in html_a, "راهنمای کامل ابزار")
missing = [t for t in CT.TOOLS if t not in html_a]
ck(not missing, "هر ۷۲ ابزار در راهنما" + (": " + ",".join(missing[:8]) if missing else ""))
ck(len(CT.TOOLS) == 72, "تعداد ابزار ۷۲")
ck(len(desk._TOOL_EX) == 72 and not [t for t in CT.TOOLS if t not in desk._TOOL_EX],
   "مثال برای هر ابزار")

ok, msg = desk.handle_sys("backup", {})
ck(ok, "بکاپ حالا: " + str(msg)[:80])
ok, msg = desk.handle_sys("backups", {})
ck(ok, "فهرست بکاپ: " + str(msg)[:80])
ok, msg = desk.handle_sys("health", {})
ck(ok, "سلامت: " + str(msg)[:80])
ok, msg = desk.handle_sys("seo", {})
ck(ok, "سئو: " + str(msg)[:80])
ok, msg = desk.handle_sys("tables", {})
ck(ok, "جدول‌ها: " + str(msg)[:80])
ok, msg = desk.handle_sys("version", {})
ck(ok, "نسخه: " + str(msg)[:80])
ok, msg = desk.handle_sys("info", {})
ck(ok, "سیستم: " + str(msg)[:80])
ok, msg = desk.handle_sys("sec", {})
ck(ok, "امنیت: " + str(msg)[:80])
ok, msg = desk.handle_sys("logs", {"n": "20"})
ck(ok, "لاگ: " + str(msg)[:80])
ok, msg = desk.handle_sys("sql", {"q": "SELECT 1 AS n"})
ck(ok, "SQL خواندنی: " + str(msg)[:80])
ok, msg = desk.handle_sys("sql", {"q": "DELETE FROM businesses"})
ck(not ok, "SQL نوشتنی رد")
ok, msg = desk.handle_sys("sql", {"q": ""})
ck(not ok, "SQL خالی رد")
ok, msg = desk.handle_sys("shell", {"cmd": "uname -a"})
ck(not ok and "پیش‌نمایش" in str(msg), "شل بدون تأیید = پیش‌نمایش")
ok, msg = desk.handle_sys("shell", {"cmd": ""})
ck(not ok, "شل خالی رد")
ok, msg = desk.handle_sys("shell", {"cmd": "uname -a", "confirm": "اجرای فرمان"})
ck(ok, "شل با تأیید: " + str(msg)[:80])
ok, msg = desk.handle_sys("cache", {})
ck(ok, "کش: " + str(msg)[:80])
last = desk._sys_load()
ck(bool(last.get("msg")), "خروجی سیستم ذخیره شد")

ck("backup_now" in CT.TOOLS and "sec_report" in CT.TOOLS and "sql_read" in CT.TOOLS,
   "ابزار سیستم سر جایش")
ck('if path.startswith("/agent/")' in src_app, "گیت /agent/*")
ck('error": "agent key required"' in src_app, "مهمان ۴۰۳")

needle = "55164" + "6991"
hits = []
for dirpath, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in ("__pycache__", "data", ".git")]
    for fn in files:
        if fn.endswith((".pyc", ".zip", ".db")):
            continue
        rel = os.path.relpath(os.path.join(dirpath, fn), ROOT)
        if rel.replace("\\", "/").startswith("tools/test_"):
            continue
        fp = os.path.join(dirpath, fn)
        try:
            txt = open(fp, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        if needle in txt:
            hits.append(rel)
ck(not hits, "توکن ایجنت بله در درخت نیست")

for rel in ("server/views_agent_desk.py", "server/views_agent_full.py",
            "server/app.py"):
    ast.parse(open(os.path.join(ROOT, rel), encoding="utf-8").read())
ck(True, "parse فایل‌های v324")

print()
print("موفق: %d   ناموفق: %d" % (n, len(fails)))
if fails:
    for x in fails:
        print("  -", x)
    sys.exit(1)
print("همه موفق — v324 قفل شد.")
