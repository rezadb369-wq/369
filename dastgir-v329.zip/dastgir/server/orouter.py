# -*- coding: utf-8 -*-
"""v321 — کاتالوگ زندهٔ OpenRouter + تست مدل واقعی.

کلید هرگز چاپ نمی‌شود. فهرست از GET /models می‌آید (کش ۱۵ دقیقه).
تست = یک chat.completions کوتاه؛ مدلِ برگشتی API باید با درخواستی یکی باشد
و متن خالی رد می‌شود (مثل ling :free که ۲۰۰ خالی می‌داد).
"""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request

OR_BASE = "https://openrouter.ai/api/v1"
OR_DEFAULT = "nvidia/nemotron-3-ultra-550b-a55b:free"

# مدل‌هایی که ۲۰۲۶-۰۹-۲۲ با کلید مالک زنده جواب دادند و id برگشتی = id درخواستی.
OR_FEATURED = (
    "nvidia/nemotron-3-ultra-550b-a55b:free",
    "openai/gpt-4o-mini",
    "google/gemini-2.5-flash",
    "anthropic/claude-sonnet-5",
    "meta-llama/llama-4-scout",
    "nex-agi/nex-n2.5-mini:free",
)

_CACHE = {"ts": 0.0, "models": []}
_CACHE_TTL = 900


def _key():
    return (
        (os.environ.get("AI_BRAIN_OR_KEY") or "").strip()
        or (os.environ.get("AI_SITE_API_KEY") or "").strip()
        or (os.environ.get("AI_API_KEY") or "").strip()
    )


def _headers(key, json_body=False):
    h = {
        "Authorization": "Bearer " + key,
        "User-Agent": "dastgir-orouter/321",
        "HTTP-Referer": "https://daastgir.ir",
        "X-Title": "dastgir",
    }
    if json_body:
        h["Content-Type"] = "application/json"
    return h


def has_key():
    return bool(_key())


def list_models(force=False):
    """[{id, name, free}] — خالی اگر کلید نباشد یا شبکه قطع باشد."""
    now = time.time()
    if not force and _CACHE["models"] and (now - _CACHE["ts"]) < _CACHE_TTL:
        return list(_CACHE["models"])
    key = _key()
    if not key:
        return []
    req = urllib.request.Request(
        OR_BASE + "/models", headers=_headers(key), method="GET")
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
    except Exception:
        return list(_CACHE["models"] or [])
    out = []
    for m in data.get("data") or []:
        mid = str(m.get("id") or "").strip()
        if not mid or mid.startswith("~"):
            continue
        name = str(m.get("name") or mid)
        free = mid.endswith(":free") or ":free" in mid
        out.append({"id": mid, "name": name, "free": free})
    out.sort(key=lambda x: (not x["free"], x["id"]))
    _CACHE["ts"] = now
    _CACHE["models"] = out
    return list(out)


def test_model(model, key=None, timeout=25):
    """Live ping. Returns dict: ok, requested, used, text, ms, error.

    ok فقط وقتی True است که HTTP ۲۰۰، متن غیرخالی، و مدلِ پاسخ همان
    مدلِ درخواستی باشد (یا پیشوند یکسان — بعضی روترها تگ :free را برمی‌دارند).
    """
    key = (key or _key() or "").strip()
    model = (model or "").strip()[:120]
    t0 = time.time()
    if not key:
        return {"ok": False, "requested": model, "used": "", "text": "",
                "ms": 0, "error": "کلید اوپن‌روتر نیست"}
    if not model:
        return {"ok": False, "requested": model, "used": "", "text": "",
                "ms": 0, "error": "مدل خالی است"}
    token = "PONG-" + model.split("/")[-1][:16]
    body = json.dumps({
        "model": model,
        "messages": [{"role": "user",
                      "content": "Reply with exactly: " + token}],
        "max_tokens": 48,
        "temperature": 0,
    }).encode("utf-8")
    req = urllib.request.Request(
        OR_BASE + "/chat/completions", data=body, method="POST",
        headers=_headers(key, json_body=True))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            data = json.loads(raw.decode("utf-8", "replace"))
            status = r.status
    except urllib.error.HTTPError as e:
        err = e.read()[:240].decode("utf-8", "replace")
        return {"ok": False, "requested": model, "used": "", "text": "",
                "ms": int((time.time() - t0) * 1000),
                "error": "HTTP %s %s" % (e.code, err[:160])}
    except Exception as e:
        return {"ok": False, "requested": model, "used": "", "text": "",
                "ms": int((time.time() - t0) * 1000),
                "error": type(e).__name__ + ": " + str(e)[:120]}
    used = str(data.get("model") or "")
    txt = (((data.get("choices") or [{}])[0].get("message") or {})
           .get("content") or "")
    txt = str(txt).strip()
    ms = int((time.time() - t0) * 1000)
    same = _same_model(model, used)
    if status == 200 and txt and same:
        return {"ok": True, "requested": model, "used": used or model,
                "text": txt[:200], "ms": ms, "error": ""}
    if status == 200 and txt and not same:
        return {"ok": False, "requested": model, "used": used,
                "text": txt[:200], "ms": ms,
                "error": "مدل واقعی پاسخ «%s» بود نه «%s»" % (used, model)}
    if status == 200 and not txt:
        return {"ok": False, "requested": model, "used": used or model,
                "text": "", "ms": ms, "error": "پاسخ خالی (مدل جواب نداد)"}
    return {"ok": False, "requested": model, "used": used,
            "text": txt[:120], "ms": ms, "error": "نامشخص"}


def _same_model(requested, used):
    a = (requested or "").strip().lower()
    b = (used or "").strip().lower()
    if not a or not b:
        return False
    if a == b:
        return True
    # some providers echo without :free / with a date suffix
    def norm(x):
        x = x.split(":")[0]
        return x
    return norm(a) == norm(b)


def featured_or_live():
    """Featured ids that exist in the live catalog (fallback = hardcoded)."""
    live = {m["id"] for m in list_models()}
    if not live:
        return list(OR_FEATURED)
    return [x for x in OR_FEATURED if x in live] or list(OR_FEATURED)
