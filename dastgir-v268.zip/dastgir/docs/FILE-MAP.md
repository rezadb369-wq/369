# FILE-MAP — نقشهٔ کامل فایل‌های سایت (هر بخش کجاست)

> **هدف:** هر کس (یا هر عامل) بخواهد چیزی را در سایت تغییر دهد یا باگی را
> عیب‌یابی کند، از این یک سند بفهمد **فایلِ آن بخش کجاست**. این سند با
> `tools/routemap.py` و `tools/build_filemap.py` تولید می‌شود.

## ۰) یک‌نگاه — درخت پوشه‌ها

```
repo-369/
├── run.py                  نقطهٔ ورود اجرا (پورت خودکار، سقف fd، systemd-ready)
│
├── server/                 ⬅ همهٔ منطق سمت سرور (پایتون خالص، stdlib-only)
│   ├── app.py              هسته: HTTP handler + مسیریابی + auth/سشن + آپلود + هدرها
│   ├── db.py               لایهٔ داده: ۵۷+ جدول، CRUD، rate_ok، مهاجرت/سازگاری SCHEMA
│   ├── features.py         زیرسیستم‌های چندجدولی: چت، سفارش، تیکت، علاقه‌مندی، چانه
│   ├── ui.py               قالب صفحات: کروم، هدر/فوتر، منو، قفل‌ها، بامپ ?vNNN
│   ├── pagecache.py        کش صفحات مهمان (TTL ۸s، ابطال با هر POST)
│   ├── shield.py           سپر ضد-اسپم/حمله: rate-limit، اسکنر، UA مخرب
│   ├── analytics.py        آمار بازدید واقعی (IP/دستگاه/نشست، فیلتر بات)
│   ├── uploads.py          پارسر multipart دستی + سقف‌ها + EXIF-strip
│   ├── sms.py              کد یک‌بارمصرف (SMS/نمایش توسعه)
│   ├── qr.py               رمزگذار QR بدون کتابخانه (SVG)
│   ├── views_public.py     صفحات عمومی: خانه، فهرست، دکان، ثبت‌نام، جست‌وجو
│   ├── views_public2.py    عمومی ۲: مقایسه، نزدیک‌من، رویداد، چانه، تماس
│   ├── views_catalog.py    کاتالوگ/ویترین/کشف
│   ├── views_chat.py       چت بلادرنگ
│   ├── views_customer.py   پنل مشتری (/me)
│   ├── views_owner.py      پنل دکان‌دار (/my)
│   ├── views_panel.py      پنل مدیر بخش ۱ (کسب‌وکارها، نظرات، محتوا…)
│   ├── views_panel2.py     پنل مدیر بخش ۲ (moderation/audit/traffic/قابلیت‌ها)
│   └── views_extra.py      صفحه‌های ریز (درباره/تماس/آفلاین)
│
├── site/                   ⬅ فایل‌های سمت مرورگر
│   ├── sw.js               سرویس‌ورکر (PWA) — VERSION اینجا بامپ می‌شود
│   ├── offline.html        صفحهٔ آفلاین فارسی
│   ├── manifest.webmanifest  مانیفست PWA (نصب روی گوشی)
│   └── assets/
│       ├── css/            ۷ فایل — جدول آن‌ها در بخش ۲
│       ├── js/             ۲۰ فایل — جدول آن‌ها در بخش ۳
│       ├── fonts/          Vazirmatn (وزیرمتن)
│       ├── img/            آیکون‌ها، لوگو، هیرو (195 فایل)
│       └── vendor/         کتابخانه‌های محلی: Leaflet و… (بدون CDN)
│
├── tools/                  ⬅ ابزارها و آزمون‌ها (جدول بخش ۵)
├── data/                   ⬅ دیتابیس + آپلودها (در زیپ تحویلی نیست)
├── docs/                   گزارش‌های ممیزی، تحقیق پنل، نقشهٔ مسیرها
└── *.md                    مستندات (HANDBOOK/READY/DEPLOY/…)
```

## ۱) «این صفحه/بخش کدام فایل است؟» — جدول بخش‌ها

| بخش سایت | مسیرها | فایل‌های منطق | فایل‌های ظاهر | فایل‌های رفتار (JS) |
|---|---|---|---|---|
| صفحهٔ اصلی | `/` | `views_public.py` | `main.css`, `pages.css` | `app.js`, `stories.js` |
| فهرست/جست‌وجو/دسته‌ها | `/businesses`, `/areas` | `views_public.py` | `pages.css` | `app.js`, `catpicker.js` |
| صفحهٔ کسب‌وکار | `/b/<slug>` | `views_public.py` | `pages.css`, `main.css` | `app.js`, `gallery.js` |
| نقشه | `/map` | `views_public2.py` | `pages.css` (`.map-*`) | `mappage.js` |
| مقایسهٔ قیمت | `/prices` | `views_public2.py` | `pages.css` | `app.js` |
| کاتالوگ/ویترین | `/catalog` | `views_catalog.py` | `pages.css` | `app.js` |
| چانه‌زنی | `/haggle/*`, `/offer/*` | `views_public2.py` | `pages.css` | `app.js` |
| ثبت کسب‌وکار | `/submit` | `views_public.py` | `pages.css` | `app.js`, `catpicker.js` |
| پنل مشتری | `/me/*` | `views_customer.py` | `pages.css` | `app.js` |
| پنل دکان‌دار | `/my/*` | `views_owner.py` | `main.css`, `pages.css` | `app.js`, `imagefield.js` |
| پنل مدیر | `/panel/*` | `views_panel.py`, `views_panel2.py` | `main.css`, `pages.css` | `panel.js` |
| چت | `/chat/*` | `views_chat.py` | `pages.css` | `chat.js` |
| ورود/OTP | `/login*`, `/alert` | `app.py` (auth) + `views_public.py` | `main.css` | `app.js` |
| API | `/api/*` | `app.py` | — | — |

## ۲) فایل‌های CSS (چه چیزی کجاست)

| فایل | اندازه (خط) | نقش |
|---|---|---|
| `jdatepicker.css` | 150 | — |
| `main.css` | 2205 | — |
| `mobile-refine.css` | 555 | — |
| `mobile-standard.css` | 142 | — |
| `pages.css` | 4710 | — |
| `theme-light.css` | 35 | — |
| `theme-night.css` | 35 | — |
| `tokens.css` | 311 | — |

- **توکن‌ها** همه در `tokens.css` (`:root` روز + `[data-theme]` شب).
- **رنگ خام در ویوها ممنوع است** (قانون معماری) — فقط توکن.
- **چیدمان موبایل:** `mobile-refine.css` و `mobile-standard.css` — هدف لمس ≥۴۴px با
  `var(--tap)`.
- **کامپوننت‌های نقشه** (نزدیک‌من/زوم/کارت انتخاب‌شده) همگی با پیشوند `.map-`
  در `pages.css`.

## ۳) فایل‌های JS (رفتار)

| فایل | خط | نقش |
|---|---|---|
| `admin-edit.js` | 84 | — |
| `app.js` | 2231 | — |
| `assist.js` | 122 | — |
| `bulk.js` | 53 | — |
| `cart.js` | 129 | — |
| `catpicker.js` | 194 | — |
| `chat.js` | 279 | — |
| `compress.js` | 634 | — |
| `countdown.js` | 27 | — |
| `dupcheck.js` | 125 | — |
| `favorites.js` | 64 | — |
| `imagefield.js` | 390 | — |
| `itemform.js` | 106 | — |
| `jalali.js` | 115 | — |
| `jdatepicker.js` | 260 | — |
| `live.js` | 125 | — |
| `map.js` | 334 | — |
| `mappage.js` | 497 | — |
| `nearby.js` | 208 | — |
| `notifpoll.js` | 41 | — |
| `notifpush.js` | 171 | — |
| `qa.js` | 98 | — |
| `regwizard.js` | 88 | — |
| `social.js` | 50 | — |
| `stories.js` | 252 | — |
| `upload.js` | 182 | — |

قانون: HTML سمت سرور رندر می‌شود؛ JS فقط رفتار (تعامل، OTP خودکار، بیکن آمار).

## ۴) نقشهٔ مسیرها (تولید خودکار)

# نقشهٔ مسیرها — هر URL کجاست؟

> تولید خودکار با `python3 tools/routemap.py -o docs/FILE-MAP.md` — اگر مسیر تازه‌ای اضافه شد، دوباره اجرا کنید.


## پنل مدیر (/panel)

| مسیر | فایل | خط |
|---|---|---|
| `/panel` | `server/app.py` | 788 |
| `/panel` | `server/app.py` | 1093 |
| `/panel` | `server/app.py` | 1101 |
| `/panel` | `server/app.py` | 1818 |
| `/panel/ad/(` | `server/app.py` | 5007 |
| `/panel/ad/new` | `server/app.py` | 3953 |
| `/panel/ads` | `server/app.py` | 1914 |
| `/panel/alert/(` | `server/app.py` | 5119 |
| `/panel/alerts` | `server/app.py` | 1924 |
| `/panel/analytics` | `server/app.py` | 1882 |
| `/panel/analytics/export` | `server/app.py` | 1884 |
| `/panel/appearance` | `server/app.py` | 1848 |
| `/panel/appearance` | `server/app.py` | 3916 |
| `/panel/appearance` | `server/app.py` | 4536 |
| `/panel/areas` | `server/app.py` | 2000 |
| `/panel/areas/rename` | `server/app.py` | 4062 |
| `/panel/assistant` | `server/app.py` | 1969 |
| `/panel/assistant` | `server/app.py` | 4631 |
| `/panel/audit` | `server/app.py` | 1971 |
| `/panel/audit/export` | `server/app.py` | 1973 |
| `/panel/backup` | `server/app.py` | 2011 |
| `/panel/backup/db` | `server/app.py` | 2055 |
| `/panel/backup/export` | `server/app.py` | 2013 |
| `/panel/backup/full` | `server/app.py` | 2019 |
| `/panel/backup/import` | `server/app.py` | 5135 |
| `/panel/badge/(` | `server/app.py` | 4863 |
| `/panel/badge/new` | `server/app.py` | 4853 |
| `/panel/badges` | `server/app.py` | 1908 |
| `/panel/badges/auto` | `server/app.py` | 4904 |
| `/panel/badges/grant` | `server/app.py` | 4892 |
| `/panel/booking/(` | `server/app.py` | 4458 |
| `/panel/bookings` | `server/app.py` | 1836 |
| `/panel/broadcast` | `server/app.py` | 1996 |
| `/panel/broadcast` | `server/app.py` | 4184 |
| `/panel/business/(` | `server/app.py` | 1824 |
| `/panel/business/(` | `server/app.py` | 4296 |
| `/panel/business/(` | `server/app.py` | 4302 |
| `/panel/business/(` | `server/app.py` | 4366 |
| `/panel/business/(new|` | `server/app.py` | 4261 |
| `/panel/business/new` | `server/app.py` | 1822 |
| `/panel/businesses` | `server/app.py` | 1820 |
| `/panel/businesses/bulk` | `server/app.py` | 4708 |
| `/panel/businesses/export` | `server/app.py` | 2007 |
| `/panel/businesses/import` | `server/app.py` | 2005 |
| `/panel/businesses/import` | `server/app.py` | 4729 |
| `/panel/catalog/(` | `server/app.py` | 1864 |
| `/panel/catalog/(` | `server/app.py` | 1868 |
| `/panel/catalog/(` | `server/app.py` | 4778 |
| `/panel/catalog/(` | `server/app.py` | 4785 |
| `/panel/categories` | `server/app.py` | 1828 |
| `/panel/category/(` | `server/app.py` | 1830 |
| `/panel/category/(` | `server/app.py` | 3681 |
| `/panel/category/(` | `server/app.py` | 4385 |
| `/panel/category/(` | `server/app.py` | 4395 |
| `/panel/category/new` | `server/app.py` | 3658 |
| `/panel/category/new` | `server/app.py` | 4376 |
| `/panel/chat/(` | `server/app.py` | 1944 |
| `/panel/chat/(` | `server/app.py` | 4001 |
| `/panel/chat/(` | `server/app.py` | 4013 |
| `/panel/chats` | `server/app.py` | 1942 |
| `/panel/claim/(` | `server/app.py` | 4756 |
| `/panel/claims` | `server/app.py` | 1856 |
| `/panel/customer/(` | `server/app.py` | 4157 |
| `/panel/customer/(` | `server/app.py` | 4172 |
| `/panel/customers` | `server/app.py` | 1994 |
| `/panel/deal/(` | `server/app.py` | 4146 |
| `/panel/deal/new` | `server/app.py` | 4121 |
| `/panel/deals` | `server/app.py` | 1961 |
| `/panel/demo` | `server/app.py` | 2002 |
| `/panel/demo` | `server/app.py` | 4069 |
| `/panel/edit/(` | `server/app.py` | 5058 |
| `/panel/editor` | `server/app.py` | 1967 |
| `/panel/editor` | `server/app.py` | 4048 |
| `/panel/edits` | `server/app.py` | 1922 |
| `/panel/edits/toggle` | `server/app.py` | 5073 |
| `/panel/event/(` | `server/app.py` | 1918 |
| `/panel/event/(` | `server/app.py` | 5035 |
| `/panel/event/new` | `server/app.py` | 5028 |
| `/panel/events` | `server/app.py` | 1916 |
| `/panel/features` | `server/app.py` | 1930 |
| `/panel/features` | `server/app.py` | 4225 |
| `/panel/follows` | `server/app.py` | 1998 |
| `/panel/gallery/(` | `server/app.py` | 1860 |
| `/panel/gallery/(` | `server/app.py` | 4773 |
| `/panel/inbox` | `server/app.py` | 1928 |
| `/panel/inline-edit` | `server/app.py` | 2784 |
| `/panel/inquiries` | `server/app.py` | 1858 |
| `/panel/inquiry/(` | `server/app.py` | 4768 |
| `/panel/insights` | `server/app.py` | 1926 |
| `/panel/list/(` | `server/app.py` | 1957 |
| `/panel/list/(` | `server/app.py` | 4096 |
| `/panel/list/(` | `server/app.py` | 4111 |
| `/panel/list/new` | `server/app.py` | 4087 |
| `/panel/lists` | `server/app.py` | 1955 |
| `/panel/login` | `server/app.py` | 2757 |
| `/panel/logout` | `server/app.py` | 2778 |
| `/panel/media` | `server/app.py` | 2093 |
| `/panel/media/delete` | `server/app.py` | 4700 |
| `/panel/media/gc` | `server/app.py` | 4694 |
| `/panel/message/(` | `server/app.py` | 4510 |
| `/panel/messages` | `server/app.py` | 1844 |
| `/panel/moderation` | `server/app.py` | 1992 |
| `/panel/order/(` | `server/app.py` | 4030 |
| `/panel/order/(` | `server/app.py` | 4035 |
| `/panel/orders` | `server/app.py` | 1951 |
| `/panel/owner/(` | `server/app.py` | 4736 |
| `/panel/owners` | `server/app.py` | 1854 |
| `/panel/pages` | `server/app.py` | 1846 |
| `/panel/pages` | `server/app.py` | 4524 |
| `/panel/plan/(` | `server/app.py` | 4925 |
| `/panel/plan/new` | `server/app.py` | 4910 |
| `/panel/plans` | `server/app.py` | 1910 |
| `/panel/plans/payment` | `server/app.py` | 4944 |
| `/panel/post/(` | `server/app.py` | 1840 |
| `/panel/post/(` | `server/app.py` | 4473 |
| `/panel/post/(` | `server/app.py` | 4499 |
| `/panel/post/new` | `server/app.py` | 4489 |
| `/panel/posts` | `server/app.py` | 1838 |
| `/panel/qa` | `server/app.py` | 1874 |
| `/panel/question/(` | `server/app.py` | 4795 |
| `/panel/report/(` | `server/app.py` | 4837 |
| `/panel/reports` | `server/app.py` | 1876 |
| `/panel/reports/bulk` | `server/app.py` | 4818 |
| `/panel/review/(` | `server/app.py` | 4437 |
| `/panel/reviews` | `server/app.py` | 1834 |
| `/panel/reviews/bulk` | `server/app.py` | 4420 |
| `/panel/rotate-token` | `server/app.py` | 4663 |
| `/panel/search` | `server/app.py` | 1850 |
| `/panel/searches/clear` | `server/app.py` | 5114 |
| `/panel/security` | `server/app.py` | 4669 |
| `/panel/settings` | `server/app.py` | 1852 |
| `/panel/settings` | `server/app.py` | 4557 |
| `/panel/stories` | `server/app.py` | 1963 |
| `/panel/story/(` | `server/app.py` | 4197 |
| `/panel/subscription/(` | `server/app.py` | 4981 |
| `/panel/subscription/new` | `server/app.py` | 4963 |
| `/panel/subscriptions` | `server/app.py` | 1912 |
| `/panel/ticket/(` | `server/app.py` | 1934 |
| `/panel/ticket/(` | `server/app.py` | 3792 |
| `/panel/ticket/(` | `server/app.py` | 4237 |
| `/panel/tickets` | `server/app.py` | 1932 |
| `/panel/tickets/bulk` | `server/app.py` | 4406 |
| `/panel/traffic` | `server/app.py` | 1880 |
| `/panel/traffic/unblock` | `server/app.py` | 4211 |
| `/panel/trash` | `server/app.py` | 1878 |
| `/panel/trash/(` | `server/app.py` | 4201 |
| `/panel/unlock/(` | `server/app.py` | 5080 |
| `/panel/unlocks` | `server/app.py` | 1938 |
| `/panel/unlocks/founder` | `server/app.py` | 5103 |

## پنل دکان‌دار (/my)

| مسیر | فایل | خط |
|---|---|---|
| `/my` | `server/app.py` | 790 |
| `/my` | `server/app.py` | 1128 |
| `/my` | `server/app.py` | 1552 |
| `/my/` | `server/app.py` | 3033 |
| `/my/account` | `server/app.py` | 1618 |
| `/my/account` | `server/app.py` | 3058 |
| `/my/assistant` | `server/app.py` | 1588 |
| `/my/booking/(` | `server/app.py` | 3355 |
| `/my/bookings` | `server/app.py` | 1598 |
| `/my/broadcast` | `server/app.py` | 1616 |
| `/my/broadcast/(fulfill|dismiss)$` | `server/app.py` | 3205 |
| `/my/broadcast/send` | `server/app.py` | 3187 |
| `/my/business/(` | `server/app.py` | 1639 |
| `/my/business/(` | `server/app.py` | 3133 |
| `/my/business/(` | `server/app.py` | 3297 |
| `/my/businesses` | `server/app.py` | 1594 |
| `/my/catalog/(` | `server/app.py` | 1651 |
| `/my/catalog/(` | `server/app.py` | 1655 |
| `/my/catalog/(` | `server/app.py` | 3235 |
| `/my/catalog/(` | `server/app.py` | 3382 |
| `/my/catalog/(` | `server/app.py` | 3401 |
| `/my/chat/(` | `server/app.py` | 1569 |
| `/my/chat/(` | `server/app.py` | 1578 |
| `/my/chat/(` | `server/app.py` | 3065 |
| `/my/chats` | `server/app.py` | 1576 |
| `/my/claim` | `server/app.py` | 1602 |
| `/my/claim` | `server/app.py` | 3371 |
| `/my/export` | `server/app.py` | 1620 |
| `/my/gallery/(` | `server/app.py` | 1643 |
| `/my/gallery/(` | `server/app.py` | 3408 |
| `/my/inquiries` | `server/app.py` | 1600 |
| `/my/inquiry/(` | `server/app.py` | 3415 |
| `/my/logout` | `server/app.py` | 3025 |
| `/my/notif-settings` | `server/app.py` | 1556 |
| `/my/notif-settings` | `server/app.py` | 3051 |
| `/my/notif/(` | `server/app.py` | 1558 |
| `/my/notifications` | `server/app.py` | 1554 |
| `/my/notifications/read` | `server/app.py` | 3047 |
| `/my/offer/(` | `server/app.py` | 3263 |
| `/my/offers` | `server/app.py` | 1606 |
| `/my/order/(` | `server/app.py` | 3085 |
| `/my/order/(` | `server/app.py` | 3090 |
| `/my/orders` | `server/app.py` | 1586 |
| `/my/plan` | `server/app.py` | 1614 |
| `/my/question/(` | `server/app.py` | 3341 |
| `/my/questions` | `server/app.py` | 1604 |
| `/my/review/(` | `server/app.py` | 3328 |
| `/my/reviews` | `server/app.py` | 1596 |
| `/my/stats/(` | `server/app.py` | 1647 |
| `/my/stories` | `server/app.py` | 1590 |
| `/my/story/(` | `server/app.py` | 1118 |
| `/my/story/(` | `server/app.py` | 3104 |
| `/my/story/add` | `server/app.py` | 3808 |
| `/my/ticket/(` | `server/app.py` | 1610 |
| `/my/ticket/(` | `server/app.py` | 3216 |
| `/my/ticket/(` | `server/app.py` | 3777 |
| `/my/tickets` | `server/app.py` | 1608 |
| `/my/tickets` | `server/app.py` | 3168 |
| `/my/tickets` | `server/app.py` | 3756 |
| `/my/trash` | `server/app.py` | 1592 |
| `/my/trash/(` | `server/app.py` | 3112 |

## پنل مشتری (/me)

| مسیر | فایل | خط |
|---|---|---|
| `/me` | `server/app.py` | 792 |
| `/me` | `server/app.py` | 1141 |
| `/me` | `server/app.py` | 1664 |
| `/me/account` | `server/app.py` | 1686 |
| `/me/account` | `server/app.py` | 2496 |
| `/me/bale/connect` | `server/app.py` | 1688 |
| `/me/chat/(` | `server/app.py` | 1670 |
| `/me/chat/(` | `server/app.py` | 1737 |
| `/me/chat/(` | `server/app.py` | 2697 |
| `/me/chat/(` | `server/app.py` | 2717 |
| `/me/chats` | `server/app.py` | 1668 |
| `/me/export` | `server/app.py` | 1708 |
| `/me/favorites` | `server/app.py` | 1684 |
| `/me/following` | `server/app.py` | 1748 |
| `/me/login` | `server/app.py` | 1137 |
| `/me/login` | `server/app.py` | 2440 |
| `/me/login/password` | `server/app.py` | 2461 |
| `/me/login/verify` | `server/app.py` | 2455 |
| `/me/logout` | `server/app.py` | 2464 |
| `/me/name` | `server/app.py` | 2487 |
| `/me/notif-settings` | `server/app.py` | 1746 |
| `/me/notif-settings` | `server/app.py` | 2593 |
| `/me/notif/(` | `server/app.py` | 1713 |
| `/me/notifications` | `server/app.py` | 1744 |
| `/me/notifications/read` | `server/app.py` | 2576 |
| `/me/order/(` | `server/app.py` | 1680 |
| `/me/order/(` | `server/app.py` | 1726 |
| `/me/order/(` | `server/app.py` | 2687 |
| `/me/orders` | `server/app.py` | 1678 |
| `/me/profile` | `server/app.py` | 1666 |
| `/me/profile` | `server/app.py` | 2472 |
| `/me/soroush/connect` | `server/app.py` | 1700 |

## صفحهٔ کسب‌وکار (/b)

| مسیر | فایل | خط |
|---|---|---|
| `/b/` | `server/app.py` | 1403 |
| `/b/` | `server/app.py` | 1416 |
| `/b/([^/?#]+)$` | `server/app.py` | 1728 |
| `/b/([^/]+)/ask-question$` | `server/app.py` | 2845 |
| `/b/([^/]+)/book$` | `server/app.py` | 2996 |
| `/b/([^/]+)/chat$` | `server/app.py` | 1249 |
| `/b/([^/]+)/report$` | `server/app.py` | 2884 |
| `/b/([^/]+)/review$` | `server/app.py` | 2921 |
| `/b/([^/]+)/review$` | `server/app.py` | 3833 |

## API

| مسیر | فایل | خط |
|---|---|---|
| `/api/alert` | `server/app.py` | 2900 |
| `/api/assistant/chat` | `server/app.py` | 2400 |
| `/api/assistant/status` | `server/app.py` | 1314 |
| `/api/businesses` | `server/app.py` | 1357 |
| `/api/chat/(` | `server/app.py` | 1270 |
| `/api/check-duplicate` | `server/app.py` | 2817 |
| `/api/favorite` | `server/app.py` | 2506 |
| `/api/follow` | `server/app.py` | 2523 |
| `/api/live` | `server/app.py` | 1195 |
| `/api/nearby` | `server/app.py` | 1338 |
| `/api/push/config` | `server/app.py` | 1302 |
| `/api/push/subscribe` | `server/app.py` | 2534 |
| `/api/push/unsubscribe` | `server/app.py` | 2557 |
| `/api/question-helpful` | `server/app.py` | 2874 |
| `/api/review-helpful` | `server/app.py` | 2604 |
| `/api/search` | `server/app.py` | 1364 |
| `/api/soroush` | `server/app.py` | 1059 |
| `/api/stories` | `server/app.py` | 1187 |
| `/api/stories/(` | `server/app.py` | 2391 |
| `/api/unread-count` | `server/app.py` | 1323 |

## فایل‌های ثابت / PWA

| مسیر | فایل | خط |
|---|---|---|
| `/assets/` | `server/app.py` | 931 |
| `/favicon.ico` | `server/app.py` | 935 |
| `/robots.txt` | `server/app.py` | 937 |
| `/sitemap.xml` | `server/app.py` | 954 |

## عمومی / متفرقه

| مسیر | فایل | خط |
|---|---|---|
| `/` | `server/adminbot.py` | 1483 |
| `/` | `server/app.py` | 1379 |
| `/` | `server/bale.py` | 170 |
| `/` | `server/soroush.py` | 130 |
| `/#[0-9a-fA-F]{6}$` | `server/adminbot_content.py` | 934 |
| `/(` | `server/features.py` | 1027 |
| `/((?:13|14)` | `server/assistant.py` | 1168 |
| `/((?:13|14)` | `server/features.py` | 1010 |
| `/([01]?` | `server/assistant.py` | 1190 |
| `/([a-f0-9]{16})` | `server/analytics.py` | 143 |
| `/(me|my|panel)/chat/(` | `server/app.py` | 3721 |
| `/(my|panel)/catalog/(` | `server/app.py` | 3980 |
| `/(my|panel)/gallery/(` | `server/app.py` | 3861 |
| `/.well-known/security.txt` | `server/app.py` | 967 |
| `/?(search|جست‌?وجو)` | `server/assistant.py` | 353 |
| `/ad/(` | `server/app.py` | 1504 |
| `/alert` | `server/app.py` | 2909 |
| `/area/([^/]+)$` | `server/app.py` | 1163 |
| `/areas` | `server/app.py` | 1157 |
| `/assistant` | `server/app.py` | 1529 |
| `/auth/bale` | `server/app.py` | 1029 |
| `/auth/soroush` | `server/app.py` | 1044 |
| `/blog` | `server/app.py` | 1431 |
| `/blog/` | `server/app.py` | 1437 |
| `/businesses` | `server/app.py` | 1381 |
| `/cart` | `server/app.py` | 1153 |
| `/catalog` | `server/app.py` | 1233 |
| `/categories` | `server/app.py` | 1159 |
| `/chat-file/(` | `server/app.py` | 990 |
| `/cities` | `server/app.py` | 1161 |
| `/contact` | `server/app.py` | 1527 |
| `/contact` | `server/app.py` | 2805 |
| `/deals` | `server/app.py` | 1183 |
| `/events` | `server/app.py` | 1497 |
| `/events/` | `server/app.py` | 1501 |
| `/favorites` | `server/app.py` | 1517 |
| `/features` | `server/app.py` | 1543 |
| `/feed.xml` | `server/app.py` | 952 |
| `/haggle/(` | `server/app.py` | 1442 |
| `/haggle/(` | `server/app.py` | 2941 |
| `/healthz` | `server/app.py` | 956 |
| `/item/(` | `server/app.py` | 1217 |
| `/item/(` | `server/app.py` | 1727 |
| `/item/(` | `server/app.py` | 2828 |
| `/list/([^/]+)$` | `server/app.py` | 1177 |
| `/lists` | `server/app.py` | 1173 |
| `/login` | `server/app.py` | 2791 |
| `/login/password` | `server/app.py` | 2797 |
| `/login/verify` | `server/app.py` | 2794 |
| `/map` | `server/app.py` | 1429 |
| `/nearby` | `server/app.py` | 1493 |
| `/offer/([A-Za-z0-9_-]{6,64})$` | `server/app.py` | 1448 |
| `/offer/([A-Za-z0-9_-]{6,64})$` | `server/app.py` | 2968 |
| `/order/create` | `server/app.py` | 2626 |
| `/order/ok` | `server/app.py` | 1167 |
| `/prices` | `server/app.py` | 1487 |
| `/prices/alert` | `server/app.py` | 2443 |
| `/pricing` | `server/app.py` | 1519 |
| `/qr/([^/]+)` | `server/app.py` | 1458 |
| `/start(?:@` | `server/app.py` | 2201 |
| `/submit` | `server/app.py` | 1537 |
| `/submit` | `server/app.py` | 2813 |
| `/subscribe` | `server/app.py` | 1521 |
| `/subscribe` | `server/app.py` | 2801 |
| `/subscribe` | `server/app.py` | 3645 |
| `/ticket-file/(` | `server/app.py` | 1009 |
| `/vcard/([^/]+)$` | `server/app.py` | 1477 |
| `/[a-z0-9_-]{2,30}$` | `server/adminbot_content.py` | 578 |

## ۵) ابزارها و آزمون‌ها (tools/)

| ابزار | نقش |
|---|---|
| `routemap.py` | ⭐ همین نقشهٔ مسیرها را می‌سازد (بعد از هر مسیر تازه اجرا کنید) |
| `build_filemap.py` | این سند را می‌سازد |
| `design_audit.py` | ممیزی جامع طراحی: ۹۴ صفحه × ۷ عرض، شات + متریک (tap/font/overflow/…) |
| `mobile_audit.py` | ممیزی موبایل (۴ دستگاه) |
| `contrast_audit.py` | کنتراست دو تم (AA) |
| `audit.py` | شکار کنترل‌های بی‌عمل (۴۶+ صفحه) |
| `navfit.py` | اندازه‌گیری سرریز هدر |
| `bench_load.py`, `bench_1000.py`, `bench_panel.py` | بار/کارایی (۵۰۰–۱۰۰۰ کاربر) |
| `test_*.py` (۴۰+ فایل) | باتری رگرسیون — فهرست کامل در `ARCHITECTURE.md` بخش ۷ |
| `seed_demo.py`, `reset_testdata.py` | دادهٔ نمونه / پاک‌سازی |
| `taxonomy.py`, `slice_taxonomy_icons.py` | درخت ۱۶۵ دسته و برش آیکون‌ها |
| `make_evidence*.py` | شواهد تصویری ممیزی (Playwright) |

## ۶) «برای تغییر X کجا بروم؟» — برگهٔ تقلب

| می‌خواهم… | برو به |
|---|---|
| متن/تایتل صفحه‌ای را عوض کنم | ویو همان مسیر (بخش ۱ یا جدول مسیرها) |
| رنگ/فونت/فاصله را عوض کنم | `site/assets/css/` — اول `tokens.css`، بعد `main.css`/`pages.css` |
| رفتار دکمه/فرم را عوض کنم | `site/assets/js/app.js` (یا فایل JS همان بخش) |
| مسیر جدید اضافه کنم | `server/app.py` → `route_get`/`route_post` + ویو مناسب |
| ستون/جدول جدید در دیتابیس | `server/db.py` → `SCHEMA` + `_reconcile_schema()` (مهاجرت خودکار) |
| سقف/قاعدهٔ امنیتی | `server/shield.py` + `db.rate_ok` + `SECURITY_HEADERS` در app.py |
| کش/سرعت | `server/pagecache.py` + بخش gzip/ETag در `app.py` |
| نسخهٔ assetها را بامپ کنم | `server/ui.py` (`?vNNN`) + `site/sw.js` (`VERSION`) + `tools/test_migration.py` |
| باگی در پنل مدیر | `views_panel.py` / `views_panel2.py` + `test_panel_*.py` |
| استقرار روی هاست | `DEPLOY.md` + `docs/HOSTING-v119.md` |
