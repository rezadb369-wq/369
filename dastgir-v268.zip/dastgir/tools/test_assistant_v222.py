#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v222 «آگاهی از مکان و زمان» — offline tests with a fake model.

Near answers use real coords from ctx (db.nearby + live distances); without
coords the generic answer + a hint is served. The model pack always carries a
Tehran time block and, with coords, a location block + per-hit distances.
Coords are request-scoped: never cached, never persisted, never logged.
"""
import os, sys, tempfile, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v222-')
os.environ['BZ_DATA_DIR'] = TMP
for k in ('AI_BASE_URL', 'AI_API_KEY', 'AI_MODEL', 'AI_MODEL_SMART', 'AI_FALLBACK_BASE_URL', 'AI_FALLBACK_API_KEY', 'AI_FALLBACK_MODEL'):
    os.environ.pop(k, None)
sys.path.insert(0, str(ROOT / 'server'))
sys.path.insert(0, str(ROOT / 'tools'))
import db, assistant as A
from layout import g2j
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
ctx = lambda key, **kw: dict({"channel": "web", "user_key": key, "customer": None, "owner": None}, **kw)
LAT, LON = 35.7000, 51.4000
own = db.owner_by_phone("09120000091", create=True)
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id,lat,lng) VALUES(?,?,?,?,?,?,?)",
            ("cafe-nazdik", "کافه نزدیک", "services", "published", own["id"], 35.7020, 51.4020))
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id,lat,lng) VALUES(?,?,?,?,?,?,?)",
            ("cafe-door", "کافه دور", "services", "published", own["id"], 35.8000, 51.5000))
con.commit(); con.close()

# ---- 1. Tehran time block + prompt rule
now = db.iran_now().replace(tzinfo=None)
jy, jm, jd = g2j(now.year, now.month, now.day)
tb = A.time_block()
ck("امروز" in tb and A._J_WEEKDAYS[now.weekday()] in tb, 'time block names the weekday in Persian')
ck(f"{jd} {A._J_MONTHS[jm]} {jy}" in tb and f"{now.hour:02d}" in tb, 'time block carries the Jalali date + Tehran hour')
ck("## زمان فعلی" in A.build_context("سلام", "", ctx("g0")), 'context pack always carries the time block')
ck("زمان فعلی" in A.ANSWER_PROMPT and "فاصله‌ها" in A.ANSWER_PROMPT, 'answer prompt grounds today/distances in the data')

# ---- 2. near intent with coords: real businesses, real distances (rules)
here = ctx("g1", lat=LAT, lon=LON)
r = A.answer("کافه نزدیک من", here)
ck(r["ok"] and r["intent"] == "near" and r["source"] == "rule", 'near intent answered by rules')
ck("کافه نزدیک" in r["text"] and "کافه دور" not in r["text"], 'only businesses within 5km listed')
ck("متر" in r["text"] and "/b/cafe-nazdik" in [h for _, h in r["links"]], 'live distance + link to the near business')
r = A.answer("نزدیک من", here)
ck("کافه نزدیک" in r["text"], 'bare near works without a query term')
r = A.answer("کافه نزدیک من", ctx("g1b", lat="35.7000", lon="51.4000"))
ck("کافه نزدیک" in r["text"], 'string coords coerced')
for bad in (dict(lat=999, lon=LON), dict(lat=LAT, lon="abc"), dict(lat=None, lon=None)):
    r = A.answer("کافه نزدیک من", ctx("gbad", **bad))
    assert "کافه نزدیک" not in r["text"] and "/nearby" in [h for _, h in r["links"]], bad
ck(True, 'invalid coords fall back to the generic answer, no crash')

# ---- 3. near without coords: generic + hint; bots unchanged
r = A.answer("کافه نزدیک من", ctx("g2"))
ck("/nearby" in [h for _, h in r["links"]] and "💡" in r["text"], 'generic answer points at /nearby + location hint')
r = A.answer("کافه نزدیک من", dict(ctx("b1"), channel="bale"))
ck("گیرهٔ پیوست" in r["text"] and "💡" not in r["text"], 'bot answer keeps the send-location flow')

# ---- 4. coords and the cache never mix (fake model)
calls = []
def fake_chat(base, key, model, messages, timeout, max_tokens=220):
    calls.append(messages[0]["content"])
    ans = {"answer": "مدل.", "links": [], "scope": True, "intent": "search"}
    return json.dumps(ans, ensure_ascii=False), 100
A._chat = fake_chat
os.environ.update(AI_BASE_URL="https://api.example.invalid/v1", AI_API_KEY="test-key-not-real",
                  AI_MODEL="fake-lite")
# v259 (دستور مدیر: «توکن فقط برای پنل کاربری و مدیرتیم»): این بخش تعامل
# مختصات با مدل/کش را با مهمان می‌سنجد پس سوییچ لحظه‌ای روشن می‌شود.
db.set_settings({"ai_guest_model": "1"})
Q1, Q2, Q3 = "رنگ آسمان چیست", "هوای امروز چطور است", "بهترین فیلم سال"
c1 = ctx("m1", lat=LAT, lon=LON)
ck(A.answer(Q1, c1)["source"] == "llm" and A.answer(Q1, c1)["source"] == "llm", 'same question + coords → model twice, never cache')
ck(len(calls) == 2, 'two provider calls prove no hit')
ck(A.answer(Q2, ctx("m2"))["source"] == "llm", 'Q2 without coords answered + stored')
ck(A.answer(Q2, ctx("m2", lat=LAT, lon=LON))["source"] == "llm", 'Q2 with coords skips the stored row')
ck(A.answer(Q2, ctx("m2"))["source"] == "cache", 'Q2 without coords hits: the row exists, coords bypassed it')
ck(A.answer(Q3, c1)["source"] == "llm" and A.answer(Q3, ctx("m3"))["source"] == "llm", 'coords answers are never stored')
ck(A.cache_lookup(Q1, c1) is None and A.cache_store(Q1, c1, None, "x", [], "s", "f", 1) is False,
   'lookup/store refuse coords directly')

# ---- 5. the model sees place + time
A.answer("کافه نزدیک", ctx("m4", lat=LAT, lon=LON))
ck("## موقعیت کاربر" in calls[-1] and "35.7000" in calls[-1] and "## زمان فعلی" in calls[-1],
   'model context carries location + time blocks')
ck("فاصله: " in calls[-1] and "کافه نزدیک" in calls[-1], 'near hit annotated with its live distance')
A.answer("کافه نزدیک", ctx("m5"))
ck("## موقعیت کاربر" not in calls[-1] and "فاصله: " not in calls[-1], 'no coords → no location block, no distances')

db.set_settings({"ai_guest_model": "0"})   # v259: سوییچ برمی‌گردد به پیش‌فرض خاموش

# ---- 6. coords never persisted anywhere
cust = db.customer_by_phone("09120000092", create=True)
cc = ctx(f"cust:{cust['id']}", customer=cust, lat=LAT, lon=LON)
A.answer("کافه نزدیک من", cc)
texts = [r["text"] for r in db._rows("SELECT text FROM ai_threads WHERE tkey=?", (f"cust:{cust['id']}",))]
ck(texts and not any("35.7" in t or "51.4" in t for t in texts), 'threads keep the words only, never the coords')
for t in ("ai_usage", "ai_threads", "ai_cache"):
    cols = {r[1] for r in db.connect().execute(f"PRAGMA table_info({t})")}
    assert "lat" not in cols and "lon" not in cols and "coords" not in cols, t
ck(True, 'no coords column in usage/threads/cache tables')

# ---- 7. client sends coords only when already granted (static)
js = (ROOT / "site" / "assets" / "js" / "assist.js").read_text(encoding="utf-8")
ck("permissions" in js and "geolocation" in js and "payload.lat" in js and "state !== 'granted'" in js,
   'assist.js attaches location only on pre-granted permission')

print(f"v222: {n} checks passed")
