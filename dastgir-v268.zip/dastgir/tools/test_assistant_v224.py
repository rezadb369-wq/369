#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v224 «اعلان مالک + مشاهده‌پذیری AI».

A) request_order_cancel really tells the shopkeeper: «requested» →
in-app approval nudge linking /my/orders (where the buttons are);
direct «cancelled» → heads-up. Nothing on failure paths; the site-wide
switch and mutes are respected. Covers the site UI and the assistant
alike, since both go through this one function.
B) generate() records which provider answered (primary/smart/fallback);
the panel shows it next to the last error — never the key.
"""
import os, sys, tempfile, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v224-')
os.environ['BZ_DATA_DIR'] = TMP
for k in ('AI_BASE_URL', 'AI_API_KEY', 'AI_MODEL', 'AI_MODEL_SMART', 'AI_FALLBACK_BASE_URL', 'AI_FALLBACK_API_KEY', 'AI_FALLBACK_MODEL'):
    os.environ.pop(k, None)
sys.path.insert(0, str(ROOT / 'server'))
import db, assistant as A
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
db.set_settings({"ai_quota_free": "100"})
own = db.owner_by_phone("09120000091", create=True)
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id) VALUES(?,?,?,?,?)",
            ("notif-shop", "مغازه اعلان", "services", "published", own["id"]))
con.commit(); con.close()
biz = db.business(slug="notif-shop")
cust = db.customer_by_phone("09120000092", create=True)
custB = db.customer_by_phone("09120000093", create=True)
mk = lambda: db.create_order(biz["id"], cust["id"], "کیوای", cust["phone"], "نشانی", "",
                             [{"title": "کالا", "price": 9000, "qty": 1}])
o_fresh, o_stale, o_stale2, o_done = mk(), mk(), mk(), mk()
db._run("UPDATE orders SET created='2026-09-01 10:00:00' WHERE id IN (?,?,?)", (o_stale, o_stale2, o_done))
db._run("UPDATE orders SET status='done' WHERE id=?", (o_done,))
notes = lambda: db._rows("SELECT owner_id, kind, text, link FROM owner_notifications ORDER BY id")

# ---- A1. approval-request notifies the shopkeeper with the decide link
n0 = len(notes())   # create_order already notifies per order; count deltas
r = db.request_order_cancel(o_stale, cust["id"], "نمی‌خوام")
ck(r == {"ok": True, "result": "requested", "limit": r["limit"]}, 'stale order → requested (return shape unchanged)')
nn = notes()
ck(len(nn) == n0 + 1 and nn[-1]["owner_id"] == own["id"] and nn[-1]["kind"] == "order", 'exactly one in-app note to the right owner')
ck(f"#{o_stale}" in nn[-1]["text"] and "تأیید یا رد" in nn[-1]["text"] and nn[-1]["link"] == "/my/orders", 'note names the order, the action, and links the buttons page')

# ---- A2. direct cancel also tells the owner (they may be preparing it)
n0 = len(notes())
r = db.request_order_cancel(o_fresh, cust["id"])
ck(r["result"] == "cancelled", 'fresh order → cancelled')
nn = notes()
ck(len(nn) == n0 + 1 and f"#{o_fresh}" in nn[-1]["text"] and "لغو شد" in nn[-1]["text"] and nn[-1]["link"] == "/my/orders", 'owner told about the direct cancel')

# ---- A3. failure paths stay silent
before = len(notes())
ck(db.request_order_cancel(o_done, cust["id"]) == {"ok": False, "error": "final"}, 'done order → final')
ck(db.request_order_cancel(o_stale2, custB["id"]) == {"ok": False, "error": "access"}, "someone else's order → access")
ck(db.request_order_cancel(999999, cust["id"]) == {"ok": False, "error": "access"}, 'missing order → access')
ck(len(notes()) == before, 'no notification when nothing happened')

# ---- A4. the site-wide switch is respected
db.set_settings({"notif_enabled": "0"})
r = db.request_order_cancel(o_stale2, cust["id"])
ck(r["result"] == "requested" and len(notes()) == before, 'request still recorded, but no note while muted site-wide')
db.set_settings({"notif_enabled": "1"})

# ---- A5. the assistant's «فرستاده شد» promise now holds end to end
def fake_chat(base, key, model, messages, timeout, max_tokens=220):
    q = str(messages[-1].get("content") or "")
    tc = {"name": "cancel_order", "args": {"id": o_stale2}} if "ORD" in q else None
    return json.dumps({"answer": "مدل.", "links": [], "scope": True, "intent": "orders", "tool_call": tc}, ensure_ascii=False), 10
A._chat = fake_chat
os.environ.update(AI_BASE_URL="https://api.example.invalid/v1", AI_API_KEY="test-key-not-real", AI_MODEL="fake-lite")
ckey = f"cust:{cust['id']}"
ctx = {"channel": "web", "user_key": ckey, "customer": cust, "owner": None}
ck("⚠️" in A.answer("ORD لطفا", ctx)["text"], 'assistant proposes the stale cancel')
ck("دکان‌دار" in A.answer("بله", ctx)["text"], '…and tells the user the request went to the shopkeeper')
ck(any(f"#{o_stale2}" in t["text"] and t["link"] == "/my/orders" for t in notes()), '…who really got the note this time')

# ---- B1. primary success is recorded
calls = []
def ok_chat(base, key, model, messages, timeout, max_tokens=220):
    calls.append(model)
    return json.dumps({"answer": "هست.", "links": [], "scope": True, "intent": "faq"}, ensure_ascii=False), 5
A._chat = ok_chat
p, t, c, s = A.generate("ساعت کاری؟", {"channel": "web", "user_key": "t1"})
ck(p is not None and A.last_provider()["which"] == "primary" and A.last_provider()["model"] == "fake-lite", 'primary answer recorded with its model')

# ---- B2. v265: fallback env is ignored — one attempt, then None (never another brain)
def flaky_chat(base, key, model, messages, timeout, max_tokens=220):
    if model == "fake-lite":
        raise ConnectionError("primary down")
    return json.dumps({"answer": "هست.", "links": [], "scope": True, "intent": "faq"}, ensure_ascii=False), 7
A._chat = flaky_chat
os.environ.update(AI_FALLBACK_BASE_URL="https://fb.example.invalid/v1", AI_FALLBACK_API_KEY="fb-key", AI_FALLBACK_MODEL="fake-fb")
p, t, c, s = A.generate("ساعت کاری؟", {"channel": "web", "user_key": "t1"})
ck(p is None and c == 1, 'dead primary → None after exactly 1 call (no fallback)')
ck(A.last_provider()["which"] == "primary", 'last good provider untouched by the dead call')
ck("fake-lite" in A.last_error()["what"], 'primary failure still in the last error')

# ---- B3. total failure changes nothing about the last good answer
def dead_chat(base, key, model, messages, timeout, max_tokens=220):
    raise TimeoutError("all down")
A._chat = dead_chat
ck(A.generate("ساعت کاری؟", {"channel": "web", "user_key": "t1"})[:3] == (None, 0, 1), 'no attempts left → None (single attempt)')
ck(A.last_provider()["which"] == "primary", 'last good provider untouched by total failure')

# ---- B4. smart routing is recorded as smart
A._chat = ok_chat
os.environ.update(AI_MODEL_SMART="fake-smart")
p, t, c, s = A.generate("س" + "ؤال طولانی " * 40 + "؟", {"channel": "web", "user_key": "t1"})
ck(s is True and calls[-1] == "fake-smart", 'long message routed to the smart model')
ck(A.last_provider()["which"] == "smart", 'smart answer recorded as smart')

# ---- B5. the panel shows it — and never the key
import views_panel2 as P2
html = P2.assistant_page({"ai_enabled": "1"}, "t", {})
ck("آخرین پاسخ موفق مدل از" in html and "مدل قوی" in html and "fake-smart" in html, 'panel names the last provider')
ck("test-key-not-real" not in html and "fb-key" not in html, 'no secret leaks into the panel')
ck(set(A.last_provider()) == {"when", "which", "model"}, 'provider record shape')

print(f"v224: {n} checks passed")
