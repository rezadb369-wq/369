#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v213 «دستیار هوشمند دست گیر» — offline tests with a fake model.
No network: assistant._chat is replaced by a stub; env has no real key."""
import os, sys, tempfile, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; TMP = tempfile.mkdtemp(prefix='ai-v213-')
os.environ['BZ_DATA_DIR'] = TMP
for k in ('AI_BASE_URL', 'AI_API_KEY', 'AI_MODEL', 'AI_MODEL_SMART', 'AI_FALLBACK_BASE_URL', 'AI_FALLBACK_API_KEY', 'AI_FALLBACK_MODEL'):
    os.environ.pop(k, None)
sys.path.insert(0, str(ROOT / 'server'))
import db, assistant as A, bot_menu
n = 0
def ck(ok, label):
    global n
    assert ok, label; n += 1; print('  ✓', label)

db.init()
ctx = lambda key, **kw: dict({"channel": "web", "user_key": key, "customer": None, "owner": None}, **kw)

# ---- 1. no key → configured False, rule-based still answers
ck(not A.configured() and A.public_config()["has_key"] is False, 'no env key → not configured, has_key False')
ck('api_key' not in A.public_config(), 'public_config never carries the key')
r = A.answer("چطور کسب‌وکارم رو ثبت کنم", ctx("u1"))
ck(r["ok"] and r["intent"] == "register" and r["source"] == "rule" and any(h == "/register-business" for _, h in r["links"]), 'register intent answered by rules with link')
r = A.answer("یک شعر درباره بهار بگو", ctx("u1"))
ck(r["ok"] and r["intent"] in ("unknown", "off_topic") and "دست گیر" in r["text"], 'off-topic without model → scoped help, no hallucination')
r = A.answer("سفارش‌های من", ctx("u1"))
ck(r["intent"] == "orders" and "وارد" in r["text"] and "/login" in r["links"][0][1], 'orders for guest → login prompt')
r = A.answer("تعرفه", ctx("u1"))
ck(r["intent"] == "plans" and "حرفه‌ای" in r["text"] and "ویژهٔ دست گیر" in r["text"], 'plans answer lists seeded plan names')
ck(A.answer("", ctx("u1"))["error"] == "empty", 'empty text rejected without counting')

# ---- 2. v219 policy: rule answers are FREE and unlimited; the 5/20/50 quota
# counts model-written answers only (see test_assistant_v219.py for q-counting).
ck(A.usage_today("u1") == 4, 'usage counter counts only answered messages')
for _ in range(4):
    r = A.answer("کافه", ctx("u1"))
ck(r["ok"] and r["source"] == "rule", 'rule answers never hit the quota wall')
ck(A.usage_today("u1") == 8 and A.quota_used_today("u1") == 0, 'messages counted, model quota untouched')
ck(A.remaining("u1", "free") == 5, 'remaining stays full while only rules answer')

# ---- 3. tiers by live subscription
owner = db.owner_by_phone('09121112233', create=True); cust = db.customer_by_phone('09121112233', create=True)
con = db.connect()
con.execute("INSERT INTO businesses(slug,name,cat_slug,status,owner_id) VALUES('ai-shop','دکان هوشمند','services','published',?)", (owner['id'],))
con.commit(); con.close()
biz = db.business(slug='ai-shop')
ck(A.tier_of(cust, None) == "free", 'owner without subscription → free tier')
sid = db.request_subscription(biz["id"], "plus")[0]
db._run("UPDATE subscriptions SET status='active', expires=date('now','+30 day') WHERE id=?", (sid,))
db.access_cache_clear()
ck(A.tier_of(cust, None) == "plus" and A.quota_for("plus") == 20, 'active حرفه‌ای (plus) → 20/day')
sid2 = db.request_subscription(biz["id"], "pro")[0]
db._run("UPDATE subscriptions SET status='active', expires=date('now','+30 day') WHERE id=?", (sid2,))
db.access_cache_clear()
ck(A.tier_of(cust, None) == "pro" and A.quota_for("pro") == 50, 'active ویژهٔ دست گیر (pro) → 50/day')
db._run("UPDATE subscriptions SET status='expired', expires=date('now','-1 day') WHERE id=?", (sid2,))
db._run("UPDATE subscriptions SET status='expired', expires=date('now','-1 day') WHERE id=?", (sid,))
db.access_cache_clear()
ck(A.tier_of(cust, None) == "free", 'expired subscriptions fall back to free quota')
db.set_settings({"ai_quota_free": "7"})
ck(A.quota_for("free") == 7, 'admin can change quotas from settings')
db.set_settings({"ai_quota_free": "5"})

# ---- 4. signed-in customer answers use real data
oid = db.create_order(biz['id'], cust['id'], 'کاربر', '09121112233', 'خیابان محرمانه', '', [{'title': 'کالا', 'price': 12000, 'qty': 1}])
r = A.answer("سفارشام", ctx(f"cust:{cust['id']}", customer=cust))
ck(r["intent"] == "orders" and "دکان هوشمند" in r["text"] and f"#{A._fa(oid)}" in r["text"], 'orders answer lists the customer\'s real order')
ck("نشانی" not in r["text"], 'orders answer never leaks address')
r = A.answer("دکان هوشمند", ctx("u2"))
ck(r["intent"] == "search" and "دکان هوشمند" in r["text"] and "/b/ai-shop" in [h for _, h in r["links"]], 'search answer finds published business with link')

# ---- 5. fake model: the model WRITES the answer from a grounded context pack
calls = []
def fake_chat(base, key, model, messages, timeout, max_tokens=220):
    sysmsg = messages[0]["content"]; txt = messages[-1]["content"]
    calls.append((base, model, txt, sysmsg))
    if "بد" in txt:
        return "not json at all", 20
    biz = [l for l in sysmsg.splitlines() if "لینک: /b/" in l]
    scope = "شعر" not in txt
    ans = {"answer": ("متأسفم، فقط برای کارهای دست گیر هستم." if not scope else f"{len(biz)} کسب‌وکار مرتبط پیدا کردم."),
           "links": [{"label": "دکان", "href": "/b/ai-shop"}, {"label": "bad", "href": "https://evil.example"}],
           "scope": scope, "intent": "search" if scope else "faq"}
    return "```json\n" + json.dumps(ans, ensure_ascii=False) + "\n```", 150
A._chat = fake_chat
os.environ.update(AI_BASE_URL="https://api.example.invalid/v1", AI_API_KEY="test-key-not-real", AI_MODEL="fake-lite")
ck(A.configured() and A.public_config()["has_key"], 'env → configured')
# v259 (دستور مدیر: «توکن فقط برای پنل کاربری و مدیرتیم»): فراخوانی مدل
# فقط با زمینهٔ واردشده؛ مهمان degraded=login می‌گیرد (تست تازه در v259).
r = A.answer("یک شعر درباره بهار بگو", ctx("u3", customer=cust))
ck(r["source"] == "llm" and r["intent"] == "off_topic" and "فقط برای کارهای دست گیر" in r["text"], 'model marks off-topic → intent off_topic, model\'s polite refusal shown')
ck(calls[-1][1] == "fake-lite" and calls[-1][0].endswith("/v1"), 'primary model + base url used')
r = A.answer("یه جای خوب برای دکان هوشمند این اطراف میخوام", ctx("u3", customer=cust))
ck(r["source"] == "llm" and "1 کسب‌وکار" in r["text"], 'model answer grounded: live search hit for the user\'s words was in its context')
ctxpack = calls[-1][3]
ck("دکان هوشمند" in ctxpack and "/register-business" in ctxpack and "حرفه‌ای" in ctxpack and "نقش:" in ctxpack, 'context pack carries business hit, routes, plans and signed-in state')
ck(r["links"] == [("دکان", "/b/ai-shop")], 'external links from the model are dropped; internal kept')
r = A.answer("سفارشام", ctx(f"cust:{cust['id']}", customer=cust))
ck(f"سفارش #{oid}" in calls[-1][3] and "خیابان محرمانه" not in calls[-1][3] and "نقش: دکان‌دار" in calls[-1][3] and "موارد ناقص پروفایل" in calls[-1][3], 'signed-in context: orders + owner coaching data, never the customer address')
r = A.answer("این چیز بد است؟", ctx("u3", customer=cust))
ck(r["ok"] and r["source"] == "rule-fallback" and A.last_error()["what"].startswith("bad-json"), 'bad model JSON → rule fallback + last_error recorded')
ck(all("test-key-not-real" not in str(c) for c in calls) and "test-key-not-real" not in json.dumps(A.public_config()), 'key never appears in captured payload/config')
st = A.stats()
ck(st["today"]["llm"] >= 4 and st["today"]["tokens"] >= 450 and any(i["intent"] == "off_topic" for i in st["intents"]), 'usage stats count model calls, tokens and intents')
ck(A.parse_answer_json('{"answer":"","links":[]}') is None and A.parse_answer_json('{"answer":"x","links":[{"href":"javascript:alert(1)"}]}')["links"] == [], 'answer parser rejects empty answer and non-path links')

# v265: primary failure degrades to rules — the fallback below must NEVER fire
def failing_chat(base, key, model, messages, timeout, max_tokens=220):
    calls.append((base, model, messages[-1]["content"], messages[0]["content"]))
    if "fallback" in base:
        return json.dumps({"answer": "پلن پایه رایگان است.", "links": [{"label": "تعرفه‌ها", "href": "/pricing"}], "scope": True, "intent": "plans"}), 90
    raise TimeoutError("timed out")
A._chat = failing_chat
os.environ.update(AI_FALLBACK_BASE_URL="https://fallback.example.invalid/v1", AI_FALLBACK_API_KEY="fb", AI_FALLBACK_MODEL="fb-model")
# v259 (دستور مدیر): کش معنایی فقط با مدلِ مهمان پر می‌شود (پاسخ واردشده
# دادهٔ شخصی دارد و هرگز کش نمی‌شود) — پس سوییچ را لحظه‌ای روشن می‌کنیم.
db.set_settings({"ai_guest_model": "1"})
r = A.answer("این چیزا چقدر آب میخوره؟", ctx("u4"))
ck(r["source"] in ("rule", "rule-fallback") and all(c[1] != "fb-model" for c in calls), 'v265: primary timeout → rules degrade, fallback never called')
db.set_settings({"ai_guest_model": "0"})
for k in ('AI_FALLBACK_BASE_URL', 'AI_FALLBACK_API_KEY', 'AI_FALLBACK_MODEL'):
    os.environ.pop(k)
r = A.answer("این چیزای دیگه چقدر آب میخوره؟", ctx("u4", customer=cust))
ck(r["ok"] and r["source"] == "rule-fallback", 'all providers failing → still answers by rules')

# parse hardening
ck(A.parse_model_json('{"intent":"delete_all","q":"","reply":""}') is None, 'unknown intent rejected')
ck(A.parse_model_json('{"intent":"search","q":"' + 'x' * 500 + '"}')["q"].__len__() == 60, 'q clipped to 60')
ck(A.parse_model_json('[1,2]') is None and A.parse_model_json('') is None, 'non-object JSON rejected')

# global cap + disable switch (v219: the cap gates the model only; exhausted
# model budget degrades to rules instead of erroring)
db.set_settings({"ai_daily_cap": "1"})
# v259 (دستور مدیر): مهمان degraded=login می‌گیرد، پس تست سقف با واردشده.
r = A.answer("کافه", ctx("u5", customer=cust))
ck(r["ok"] and r["source"] == "rule" and r["degraded"] == "cap", 'rule answers bypass the global cap (budget state still flagged)')
r = A.answer("یک سؤال که فقط مدل میتواند جواب بدهد چیست؟", ctx("u5", customer=cust))
ck(r["ok"] and r["degraded"] == "cap" and r["source"] == "rule-fallback", 'cap exhausted → graceful rule fallback, flagged')
db.set_settings({"ai_daily_cap": "2000", "ai_enabled": "0"})
ck(A.answer("کافه", ctx("u5"))["error"] == "disabled", 'admin switch disables assistant')
db.set_settings({"ai_enabled": "1"})

# ---- 6. bots: free text → assistant, links as URL buttons, quota footer
A._chat = fake_chat
sent = []
def send(chat, text, markup=None): sent.append((str(chat), text, markup)); return True
con = db.connect()
con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,?,?,?)", (cust['id'], 'bale', 'ab1', '30'))
con.execute("INSERT INTO messenger_accounts(customer_id,platform,platform_user_id,chat_id) VALUES(?,?,?,?)", (cust['id'], 'soroush', 'as1', '31'))
con.commit(); con.close()
ck(bot_menu.handle_message('bale', 'ab1', '30', 'دکان هوشمند', send), 'Bale free text consumed by assistant')
kb = json.dumps(sent[-1][2], ensure_ascii=False)
ck('کسب‌وکار مرتبط' in sent[-1][1] and 'https://daastgir.ir/b/ai-shop' in kb and 'dg198:menu' in kb, 'Bale reply = model text + site URL buttons + main menu')
ck('پاسخ هوشمند دیگر امروز' in sent[-1][1], 'Bale reply shows remaining smart quota')
sent.clear()
ck(bot_menu.handle_message('soroush', 'as1', '31', 'میخوام مغازه‌ام رو ثبت کنم', send), 'Soroush free text consumed')
ck(sent and 'dg198:menu' in json.dumps(sent[-1][2]), 'Soroush reply rendered with menu button')
A._chat = None; os.environ.pop('AI_API_KEY')   # offline → rules
sent.clear(); bot_menu.handle_message('soroush', 'as1', '31', 'میخوام مغازه‌ام رو ثبت کنم', send)
ck('dg198:reg_start' in json.dumps(sent[-1][2]) and 'ثبت' in sent[-1][1], 'register intent (offline rules) in bot offers in-bot registration callback')
os.environ['AI_API_KEY'] = 'test-key-not-real'; A._chat = fake_chat
sent.clear()
ck(bot_menu.handle_message('bale', 'ab1', '30', '/orders', send) and 'dg198' in json.dumps(sent[-1][2]), 'menu commands still take precedence over assistant')
sent.clear()
ck(bot_menu.handle_message('bale', 'unknown-user', '99', 'کافه', send) and sent, 'unlinked user still gets assistant (free quota by platform id)')
ck(bot_menu.handle_message('bale', 'ab1', '30', '/nonexistent_cmd', send) is False, 'unknown slash command not consumed (menu fallback)')
sent.clear()
for i in range(60):
    bot_menu.handle_message('bale', 'ab1', '30', 'کافه', send)
ck(any('سهمیهٔ امروز' in t for _, t, _ in sent) or any('زیاد است' in t for _, t, _ in sent), 'bot quota/rate limits enforced')

# ---- 7. export/import include counters
ex = db.export_all()
ck("ai_usage" in ex and "ai_intents" in ex and len(ex["ai_usage"]) >= 3, 'backup export includes assistant counters')
ck(all("text" not in row for row in ex["ai_usage"]), 'no message text stored anywhere')

print(f"\nassistant v213: {n} checks passed")
