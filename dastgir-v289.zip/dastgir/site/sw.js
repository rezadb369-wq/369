/* Bazarche Najafabad — service worker
   Cache-first for immutable assets, network-first for HTML.
   Anything session-dependent is never cached, so a stale shell can never
   make the site look blank or logged-out. */

/* Bumped from v141. The activate handler below deletes every cache whose name
   is not exactly VERSION, so changing this string is what evicts the shell the
   prototype saved on a phone. If a stale page ever reappears, bump it again. */
const VERSION = 'bazarche-v289-merchant1';

const OFFLINE = '/offline.html';

const SHELL = [
  OFFLINE,
  '/assets/css/tokens.css',
  '/assets/css/main.css',
  '/assets/css/pages.css',
  '/assets/css/mobile-refine.css',
  '/assets/css/mobile-standard.css',
  '/assets/css/theme-night.css',
  '/assets/js/app.js',
  '/assets/js/map.js',
  '/assets/js/jalali.js',
  '/assets/js/jdatepicker.js',
  '/assets/css/jdatepicker.css',
  '/assets/vendor/leaflet/leaflet.css',
  '/assets/vendor/leaflet/leaflet.js',
  '/assets/fonts/Vazirmatn-Variable.woff2',
  '/assets/img/favicon.svg',
  '/assets/img/logo-mark.svg',
  '/assets/img/logo-source.png?v180',
  '/assets/img/logo-display.png?v183',
  '/assets/img/logo.svg',
];

// Never cache: owner panel, shop-owner area, auth, tracking, API.
const NO_CACHE = ['/panel', '/my', '/login', '/logout', '/t/', '/api/'];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(VERSION)
      .then(c => c.addAll(SHELL).catch(() => {}))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then(keys => {
        const old = keys.filter(k => k !== VERSION);
        return Promise.all(old.map(k => caches.delete(k))).then(() => old.length > 0);
      })
      // v66 root-caused: the unconditional force-reload aborted the very load
      // that was installing the worker (REQFAIL noise + a jarring mid-visit
      // reload for FIRST-TIME visitors who have nothing stale to evict).
      // Now we only force-reload open tabs when an older cache actually
      // existed — i.e. a genuine upgrade from a previous build.
      .then(hadOld => hadOld
        ? self.clients.matchAll({ type: 'window' })
            .then(list => list.forEach(c => { try { c.navigate(c.url); } catch (err) {} }))
        : null)
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', (e) => {
  if (e.data === 'skipWaiting') self.skipWaiting();
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (NO_CACHE.some(p => url.pathname.startsWith(p))) return;

  // Immutable assets: cache first.
  if (url.pathname.startsWith('/assets/')) {
    e.respondWith(
      // v272: on a cache miss bypass the BROWSER http cache (no-store) — a
      // stale immutable response under an old ?v… URL could otherwise outlive
      // the upgrade; the VERSION-scoped cache above is the only cache we trust.
      caches.match(req).then(hit => hit || fetch(req, { cache: 'no-store' }).then(res => {
        const copy = res.clone();
        caches.open(VERSION).then(c => c.put(req, copy)).catch(() => {});
        return res;
      }))
    );
    return;
  }

  // HTML: network first. Never store the response — every page now renders a
  // header that depends on who is signed in, so a cached copy would show the
  // previous visitor's account (or a stale "ورود / ثبت‌نام" after login).
  // The offline fallback is a single generic shell, not the real page.
  e.respondWith(
    fetch(req, {cache:'reload'})
      .catch(() => caches.match(OFFLINE).then(hit => hit || caches.match('/offline.html')))
  );
});

/* v142 — web push (Google FCM). The in-app notification page is the source
   of truth; the pushed payload only mirrors it. Data arrives from FCM HTTP
   v1 as {"notification":{title,body},"data":{url,icon,v}}. */
self.addEventListener('push', (e) => {
  let data = {};
  try { data = e.data ? e.data.json() : {}; } catch (_) {}
  const title = (data.notification && data.notification.title)
    || data.title || 'دست گیر';
  const body = (data.notification && data.notification.body) || data.body || '';
  const url = (data.data && data.data.url) || '/';
  const icon = (data.data && data.data.icon) || '/assets/img/icons/app-192.png';
  e.waitUntil(
    self.registration.showNotification(title, {
      body,
      icon,
      badge: '/assets/img/favicon.svg',
      data: { url },
      dir: 'rtl',
      lang: 'fa'
    }).catch(() => {})
  );
});

/* Click on the system notification: open (or focus) the notification's page. */
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  let target;
  try {
    target = new URL(e.notification.data && e.notification.data.url || '/',
                     self.location.origin);
    if (target.protocol !== 'https:' && target.protocol !== 'http:') return;
    if (target.origin !== self.location.origin) target = new URL('/', self.location.origin);
  } catch (_) {
    target = new URL('/', self.location.origin);
  }
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((list) => {
        for (const c of list) {
          if (new URL(c.url).origin !== self.location.origin) continue;
          c.focus();
          if (new URL(c.url).pathname !== target.pathname) {
            try { return c.navigate(target.href); } catch (_) {}
          }
          return undefined;
        }
        return self.clients.openWindow(target.href).catch(() => {});
      })
  );
});
