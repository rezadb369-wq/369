#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۱۱ — سیستم (۱): ویرایش محتوای سایت · صفحات ثابت · ظاهر و رنگ‌ها · قابلیت‌های سایت.
XSS محتوا، بازگردانی پیش‌فرض، پیامد خاموش‌کردن فلگ‌ها (رد پای یافتهٔ ۱۶).
هر تست اثر واقعی را در پایگاه/صفحه بررسی می‌کند و تمیزکاری برمی‌گرداند."""
import re, sys, json, sqlite3, time, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []
ADMIN_PHONE = "09131110011"
SHOP_PHONE = "09352223344"

def q(sql, args=()):
    c = sqlite3.connect(DB); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None):
    h = {}
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data, doseq=True).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(BASE + path, data=body, headers=h)
    try:
        r = op.open(req, timeout=25)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

def mp_post(op, path, fields, file_field=None, blob=b"", fname="x.png"):
    bnd = "----qa11boundary"
    out = b""
    for k, v in fields:
        out += f"--{bnd}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode()
    if file_field:
        out += (f"--{bnd}\r\nContent-Disposition: form-data; name=\"{file_field}\"; "
                f"filename=\"{fname}\"\r\nContent-Type: image/png\r\n\r\n").encode() + blob + b"\r\n"
    out += f"--{bnd}--\r\n".encode()
    req = urllib.request.Request(BASE + path, data=out,
        headers={"Content-Type": f"multipart/form-data; boundary={bnd}"})
    try:
        r = op.open(req, timeout=25)
        return r.status, r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.geturl()

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def clear_rl():
    q("delete from ratelimit")

def login(phone, admin=False):
    clear_rl()
    op = sess()
    go(op, "/login")
    go(op, "/login", {"phone": phone})
    go(op, "/login/verify", {"phone": phone, "code": otp_code(phone)})
    if admin:
        go(op, "/panel?key=" + DBM.owner_token())
    return op

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:240]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

DEFAULTS = {"color_primary": "#0b6059", "color_accent": "#b45309",
            "color_background": "#f7f3ec", "color_foreground": "#241d14",
            "hero_title": "دستتان را می\u200cگیریم؛\nهر چه می\u200cخواهید، همین نزدیکی است",
            "hero_lead": "دست گیر یعنی دست گرفتن و یاری رساندن. راهنمای زندهٔ کسب\u200cوکارهای شهر شما — با ساعت کاری لحظه\u200cای، نقشه، نظرات واقعی مشتریان و سفارش آنلاین؛ راحت و بی\u200cدردسر.",
            "hero_cta": "ثبت رایگان کسب\u200cوکار",
            "footer_note": "ساخته\u200cشده با مهر، برای کسب\u200cوکارهای ایران"}
SAVED = {}

def remember():
    for k in DEFAULTS:
        SAVED[k] = q("select value from settings where key=?", (k,))[0][0]

def restore():
    op = login(ADMIN_PHONE, admin=True)
    go(op, "/panel/editor", [(k, SAVED.get(k, DEFAULTS[k])) for k in DEFAULTS] + [
        ("site_name", "بازارچهٔ نجف\u200cآباد"), ("tagline", ""), ("description", ""),
        ("about_title", "درباره ما"), ("about_body", ""), ("rules_title", "قوانین و مقررات"), ("rules_body", "")])

# ─────────────────── T1 ویرایش محتوای سایت ───────────────────
def t1():
    print("── T1 ویرایش محتوای سایت (editor)")
    op = login(ADMIN_PHONE, admin=True)
    remember()
    st, b, _ = go(op, "/panel/editor")
    check("T1.1", "صفحهٔ ویرایشگر 200", st == 200)
    # ذخیرهٔ متا + صفحات
    st, b, url = go(op, "/panel/editor", {
        "site_name": "بازارچهٔ آزمون۱۷۳", "tagline": "شعار آزمون فاز ۱۱",
        "description": "توضیح آزمون برای موتورها", "hero_title": "سرصفحهٔ آزمون فاز ۱۱",
        "hero_lead": "زیرنویس آزمون برای فاز ۱۱ ممیزی.", "hero_cta": "کلیک آزمون",
        "footer_note": "پانوشت آزمون", "about_title": "دربارهٔ آزمون",
        "about_body": "متن دربارهٔ ما از آزمون فاز ۱۱.", "rules_title": "قوانین آزمون",
        "rules_body": "متن قوانین از آزمون فاز ۱۱."})
    meta = dict(q("select key,value from settings where key in ('site_name','hero_title','footer_note')"))
    pg = dict((r[0], r[1]) for r in q("select slug,title from pages where slug in ('about','rules')"))
    check("T1.2", "ذخیرهٔ متا و صفحات", meta.get("site_name") == "بازارچهٔ آزمون۱۷۳"
          and meta.get("hero_title") == "سرصفحهٔ آزمون فاز ۱۱"
          and pg.get("about") == "دربارهٔ آزمون", str(meta))
    time.sleep(5.2)
    # عمومی: خانه + /about + /rules
    st, b, _ = go(sess(), "/")
    check("T1.3", "خانه متای تازه را نشان می‌دهد", "بازارچهٔ آزمون۱۷۳" in b and "سرصفحهٔ آزمون فاز ۱۱" in b)
    st, b, _ = go(sess(), "/about")
    st2, b2, _ = go(sess(), "/rules")
    check("T1.4", "/about و /rules محتوای تازه", "متن دربارهٔ ما از آزمون فاز ۱۱" in b
          and "متن قوانین از آزمون فاز ۱۱" in b2, f"{st}/{st2}")
    # XSS محتوا در صفحات ثابت
    st, b, url = go(op, "/panel/editor", {
        "site_name": "بازارچهٔ آزمون۱۷۳", "tagline": "", "description": "",
        "hero_title": "سرصفحهٔ آزمون فاز ۱۱", "hero_lead": "زیرنویس آزمون برای فاز ۱۱ ممیزی.",
        "hero_cta": "کلیک آزمون", "footer_note": "پانوشت آزمون",
        "about_title": "<img src=x onerror=alert(3)>دربارهٔ تزریقی",
        "about_body": "پیلواد <script>alert(4)</script> دربارهٔ ما — آزمون escape.",
        "rules_title": "قوانین آزمون", "rules_body": "پیلواد دوم <svg onload=alert(5)> قوانین."})
    time.sleep(5.2)
    st, b, _ = go(sess(), "/about")
    st2, b2, _ = go(sess(), "/rules")
    st3, b3, _ = go(sess(), "/")
    raw_about = "<img src=x onerror" in b or "<script>alert(4)" in b
    raw_rules = "<svg onload" in b2
    raw_hero = "onerror=alert" in b3.replace("&lt;", "")
    check("T1.5", "XSS صفحهٔ ثابت: همه escaped، تگ خام صفر",
          "&lt;img" in b and "&lt;script" in b and "&lt;svg" in b2
          and not raw_about and not raw_rules, f"about_raw={raw_about} rules_raw={raw_rules}")
    check("T1.6", "hero خانه escaped", "&lt;" not in b3 or "onerror" not in b3, None)
    # دکاندار 403
    sop = login(SHOP_PHONE)
    g1 = go(sop, "/panel/editor")[0]
    g2 = go(sop, "/panel/editor", {"site_name": "هک"})[0]
    check("T1.7", "دکاندار 403×2", (g1, g2) == (403, 403), str((g1, g2)))

# ─────────────────── T2 ظاهر و رنگ‌ها ───────────────────
def t2():
    print("── T2 ظاهر و رنگ‌ها")
    op = login(ADMIN_PHONE, admin=True)
    # رنگ سالم → در CSS روز تزریق می‌شود
    st, b, url = mp_post(op, "/panel/appearance", [
        ("color_primary", "#123456"), ("color_accent", "#654321"),
        ("color_background", "#ffffff"), ("color_foreground", "#000000"),
        ("hero_title", "سرصفحهٔ آزمون فاز ۱۱"), ("hero_lead", "زیرنویس آزمون برای فاز ۱۱ ممیزی."),
        ("hero_cta", "کلیک آزمون"), ("footer_note", "پانوشت آزمون"), ("logo_keep", "true")])
    check("T2.1", "ذخیرهٔ ظاهر → آدرس سالم (#32)",
          "/panel/appearance?ok=" in url and "به‌روزرسانی شد" in urllib.parse.unquote(url), url)
    q("update settings set value='#123456' where key='color_primary'")
    time.sleep(5.2)
    st, b, _ = go(sess(), "/")
    check("T2.2", "رنگ تازه در CSS روز", "--color-primary:#123456" in b)
    # رنگ زباله → بازگردانی پیش‌فرض (hex_rgb گارد)
    q("update settings set value='red; background:url(//evil)' where key='color_primary'")
    time.sleep(5.2)
    st, b, _ = go(sess(), "/")
    css_evil = "background:url(//evil)" in b
    css_default = "--color-primary:#0b6059" in b
    check("T2.3", "رنگ زباله → پیش‌فرض، بدون CSS تزریقی", css_default and not css_evil,
          f"def={css_default} evil={css_evil}")
    # لوگو: آپلود معتبر + حذف با keep=false
    png = bytes.fromhex("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000a49444154789c6360000002000154a24f5f0000000049454e44ae426082")
    st, b, url = mp_post(op, "/panel/appearance", [
        ("color_primary", "#123456"), ("color_accent", "#654321"),
        ("color_background", "#ffffff"), ("color_foreground", "#000000"),
        ("hero_title", "سرصفحهٔ آزمون فاز ۱۱"), ("hero_lead", "زیرنویس آزمون برای فاز ۱۱ ممیزی."),
        ("hero_cta", "کلیک آزمون"), ("footer_note", "پانوشت آزمون")],
        file_field="logo", blob=png, fname="logo.png")
    logo1 = q("select value from settings where key='site_logo'")[0][0]
    check("T2.4", "آپلود لوگو → مسیر عمومی", logo1.lstrip("/").startswith("assets/img/uploads/logo-"), logo1)
    st, b, url = mp_post(op, "/panel/appearance", [
        ("color_primary", "#123456"), ("color_accent", "#654321"),
        ("color_background", "#ffffff"), ("color_foreground", "#000000"),
        ("hero_title", "سرصفحهٔ آزمون فاز ۱۱"), ("hero_lead", "زیرنویس آزمون برای فاز ۱۱ ممیزی."),
        ("hero_cta", "کلیک آزمون"), ("footer_note", "پانوشت آزمون"), ("logo_keep", "false")])
    logo2 = q("select value from settings where key='site_logo'")[0][0]
    import os
    gone = not os.path.exists("site/" + logo1)
    check("T2.5", "حذف لوگو → تنظیم خالی + فایل پاک", logo2 == "" and gone, f"{logo2} gone={gone}")
    # لوگوی جعلی رد (فایل غیرتصویر)
    st, b, url = mp_post(op, "/panel/appearance", [
        ("color_primary", "#123456"), ("color_accent", "#654321"),
        ("color_background", "#ffffff"), ("color_foreground", "#000000"),
        ("hero_title", "سرصفحهٔ آزمون فاز ۱۱"), ("hero_lead", "زیرنویس آزمون برای فاز ۱۱ ممیزی."),
        ("hero_cta", "کلیک آزمون"), ("footer_note", "پانوشت آزمون")],
        file_field="logo", blob=b"#!/bin/sh\nrm -rf /\n", fname="evil.png")
    logo3 = q("select value from settings where key='site_logo'")[0][0]
    check("T2.6", "فایل غیرتصویر → لوگو ذخیره نمی‌شود", logo3 == "", logo3)
    # دکاندار 403
    sop = login(SHOP_PHONE)
    g1 = go(sop, "/panel/appearance")[0]
    st2_, b2_, _ = mp_post(sop, "/panel/appearance", [("color_primary", "#ff0000")])
    check("T2.7", "دکاندار 403×2", g1 == 403 and st2_ == 403, str((g1, st2_)))

# ─────────────────── T3 پیامد خاموشی فلگ‌ها (رد پای ۱۶) ───────────────────
def t3():
    print("── T3 پیامد خاموشی فلگ‌ها")
    op = login(ADMIN_PHONE, admin=True)
    keys = [k for _t, items in __import__("views_panel2", fromlist=["SITE_FEATURES"]).SITE_FEATURES for k, *_ in items]
    before = dict(q("select key,value from settings where key in (%s)" % ",".join("?" * len(keys)), keys))
    # blog خاموش → /blog 404 و ورودی از خانه می‌رود
    st, b, url = go(op, "/panel/features", [(k, before[k]) for k in keys if before[k] == "1" and k != "blog_enabled"])
    time.sleep(5.2)
    st, b, _ = go(sess(), "/blog")
    check("T3.1", "blog_enabled=0 → /blog 404", st == 404, f"st={st}")
    # events خاموش → /events 404
    st, b, url = go(op, "/panel/features", [(k, before[k]) for k in keys if before[k] == "1" and k != "events_enabled"])
    time.sleep(5.2)
    st, b, _ = go(sess(), "/events")
    st2, b2, _ = go(sess(), "/blog")
    check("T3.2", "events خاموش: /events 404 و /blog برگشت (بازگردانی)",
          st == 404 and st2 == 200, f"{st}/{st2}")
    # کامل به قبل
    st, b, url = go(op, "/panel/features", [(k, before[k]) for k in keys if before[k] == "1"])
    after = dict(q("select key,value from settings where key in (%s)" % ",".join("?" * len(keys)), keys))
    check("T3.3", "بازگردانی کامل فلگ‌ها", after == before,
          str([k for k in keys if after.get(k) != before.get(k)]))
    time.sleep(5.2)
    st, b, _ = go(sess(), "/events")
    check("T3.4", "/events دوباره 200", st == 200)

def main():
    try:
        t1()
        t2()
        t3()
    finally:
        restore()
        # بازگردانی رنگ‌ها به پیش‌فرض برند
        for k, v in DEFAULTS.items():
            q("update settings set value=? where key=?", (v, k))
        q("update settings set value='' where key='site_logo'")
        time.sleep(5.2)
    json.dump(RESULTS, open("qa/phase11-results.json", "w"), ensure_ascii=False, indent=1)
    fails = [r for r in RESULTS if not r["ok"]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(fails)} | قرمز: {len(fails)}")
    for r in fails:
        print("  ❌", r["id"], r["name"], "—", r["detail"])
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
