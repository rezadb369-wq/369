#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QA فاز ۱ — پنل مدیر: هر تست = عمل واقعی + بررسی اثر واقعی (پایگاه/صفحهٔ عمومی)
هر چیزی که می‌سازد پاک می‌کند و هر چیزی که عوض می‌کند برمی‌گرداند."""
import re, sys, json, sqlite3, uuid, urllib.request, urllib.parse, urllib.error, http.cookiejar

BASE = "http://127.0.0.1:8080"
sys.path.insert(0, "server")
import db as DBM

DB = "data/bazarche.db"
RESULTS = []

def key():
    return DBM.owner_token()

def q(sql, args=()):
    c = sqlite3.connect(DB); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r

def sess():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

def go(op, path, data=None, headers=None, raw=False):
    h = dict(headers or {})
    if data is not None and "Content-Type" not in h and not isinstance(data, (bytes, str)):
        data = urllib.parse.urlencode(data, doseq=True).encode(); h["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(data, str): data = data.encode()
    req = urllib.request.Request(BASE + path, data=data, headers=h)
    try:
        r = op.open(req, timeout=25)
        body = r.read()
        return r.status, body if raw else body.decode("utf-8", "replace"), dict(r.headers)
    except urllib.error.HTTPError as e:
        body = e.read()
        return e.code, body if raw else body.decode("utf-8", "replace"), dict(e.headers)

def otp_code(phone):
    return q("select code from otp where phone=? order by rowid desc limit 1", (phone,))[0][0]

def clear_ratelimit():
    q("delete from ratelimit where bucket like 'otp%'")

def check(tid, name, ok, detail=""):
    RESULTS.append({"id": tid, "name": name, "ok": bool(ok), "detail": str(detail)[:220]})
    print(("  ✅" if ok else "  ❌"), f"[{tid}] {name}" + ("" if ok else f" — {detail}"))

def do_login(phone, gate=True):
    clear_ratelimit()
    op = sess()
    go(op, "/login")
    go(op, "/login", {"phone": phone})
    go(op, "/login/verify", {"phone": phone, "code": otp_code(phone)})
    if gate:
        st, _, _ = go(op, "/panel?key=" + key())
    return op

# ─────────────────────────── T1 گیت ───────────────────────────
def t1_gate():
    print("── T1 گیت پنل")
    anon = sess()
    st, b, _ = go(anon, "/panel")
    check("T1.1", "/panel بدون کلید و کوکی → 403", st == 403, f"got {st}")
    st, b, _ = go(anon, "/panel?key=WRONGKEY123")
    check("T1.2", "کلید غلط → 403", st == 403, f"got {st}")
    n0 = q("select count(*) from categories")[0][0]
    st, b, _ = go(anon, "/panel/category/new", {"name": "هک", "parent": "", "icon": "x", "blurb": ""})
    n1 = q("select count(*) from categories")[0][0]
    check("T1.3", "POST بدون احراز → 403 و دسته ساخته نمی‌شود", st == 403 and n0 == n1, f"st={st} n0={n0} n1={n1}")
    st, b, _ = go(anon, "/panel/settings")
    check("T1.4", "صفحهٔ تنظیمات بدون احراز → 403", st == 403, f"got {st}")

# ─────────────────── T2 ورود OTP + کوکی ادمین ───────────────────
def t2_login():
    print("── T2 ورود مالک و کوکی ادمین")
    op = do_login("09131110011")
    st, b, hdr = go(op, "/panel")
    check("T2.1", "گیت با کلید درست → داشبورد 200 و کوکی = بلیت", st == 200, f"got {st}")
    st, b, _ = go(op, "/panel/insights")
    check("T2.2", "صفحهٔ تحلیل پنل با کوکی → 200", st == 200, f"got {st}")
    # نرخ‌سنجی OTP: درخواست فوری دوم باید پیام خنک‌سنجی بدهد
    anon2 = sess()
    go(anon2, "/login")
    st, b, _ = go(anon2, "/login", {"phone": "09131110011"})
    hit = ("دیر" in b) or ("بعد" in b) or ("دوباره" in b)
    check("T2.3", "نرخ‌سنجی OTP: درخواست پشت‌سرهم بلاک می‌شود (امنیت مثبت)", hit, "پیام خنک‌سنجی نبود")
    clear_ratelimit()
    return op

# ─────────────────────────── T3 دسته‌ها ───────────────────────────
def t3_categories(op):
    print("── T3 دسته‌ها: ساخت/ویرایش/حذف")
    name = "آزمون QA " + uuid.uuid4().hex[:6]
    st, b, _ = go(op, "/panel/category/new", {"name": name, "parent": "", "icon": "🧪", "blurb": "تست فاز ۱"})
    row = q("select id from categories where name=?", (name,))
    check("T3.1", "ساخت دسته از پنل (اثر در پایگاه)", row, f"st={st} row={row}")
    if not row: return
    cid = row[0][0]
    st, b, _ = go(sess(), "/categories")
    check("T3.2", "دستهٔ تازه در صفحهٔ عمومی دسته‌ها دیده می‌شود", name in b)
    newname = name + "-ویرایش"
    st, b, _ = go(op, f"/panel/category/{cid}", {"name": newname, "parent": "", "icon": "🧪", "blurb": "ویرایش‌شده"})
    row2 = q("select name from categories where id=?", (cid,))
    check("T3.3", "ویرایش نام دسته", row2 and row2[0][0] == newname, f"row2={row2}")
    st, b, _ = go(op, f"/panel/category/{cid}/delete", {})
    row3 = q("select id from categories where id=?", (cid,))
    check("T3.4", "حذف دسته (اثر در پایگاه)", not row3, f"st={st} row3={row3}")

# ────────────────────── T4 تأیید/رد کسب‌وکار ──────────────────────
def t4_business(op):
    print("── T4 کسب‌وکار: وضعیت + گیت پیش‌نمایش (رفع v160)")
    bid, slug = 214, "dkan-azmvn-malk-yk"
    q("update businesses set status='pending' where id=?", (bid,))
    st, b, _ = go(sess(), f"/b/{slug}")
    check("T4.1", "pending → برای عموم 404", st == 404, f"got {st}")
    st, b, _ = go(op, f"/b/{slug}")
    check("T4.2", "pending → مدیر پیش‌نمایش می‌بیند (200)", st == 200, f"got {st}")
    q("update businesses set owner_id=2 where id=?", (bid,))
    shop = sess()
    go(shop, "/me/login")
    go(shop, "/me/login", {"phone": "09352223344"})
    go(shop, "/me/login/verify", {"phone": "09352223344", "code": otp_code("09352223344")})
    st, b, _ = go(shop, f"/b/{slug}")
    check("T4.3", "pending → مالک همان دکان پیش‌نمایش می‌بیند (200)", st == 200, f"got {st}")
    st, b, _ = go(op, f"/panel/business/{bid}/status", {"status": "published"})
    pub = q("select status from businesses where id=?", (bid,))[0][0]
    st2, b2, _ = go(sess(), f"/b/{slug}")
    check("T4.4", "تأیید و انتشار از پنل → عمومی 200", pub == "published" and st2 == 200, f"pub={pub} st2={st2}")
    st, b, _ = go(op, f"/panel/business/{bid}/status", {"status": "rejected"})
    rej = q("select status from businesses where id=?", (bid,))[0][0]
    st2, b2, _ = go(sess(), f"/b/{slug}")
    check("T4.5", "رد از پنل → عمومی 404", rej == "rejected" and st2 == 404, f"rej={rej} st2={st2}")
    go(op, f"/panel/business/{bid}/status", {"status": "published"})
    back = q("select status, owner_id from businesses where id=?", (bid,))[0]
    q("update businesses set owner_id=NULL where id=?", (bid,))
    check("T4.6", "بازگردانی published (پاک‌سازی)", back[0] == "published")

# ────────────────────── T5 کالا: ویرایش/ساخت/حذف ──────────────────────
def t5_items(op):
    print("── T5 کالاها از پنل")
    iid, bid = 336, 214
    orig = q("select title,price,descr,price_type,tags from items where id=?", (iid,))[0]
    st, b, _ = go(op, f"/panel/catalog/{bid}/item/{iid}",
                  {"title": "کالای آزمون 1 ویرایش", "price": "2500", "descr": orig[2] or "",
                   "price_type": orig[3] or "fixed", "tags": orig[4] or ""})
    now = q("select title,price from items where id=?", (iid,))[0]
    check("T5.1", "ویرایش کالا از پنل اثر می‌گذارد", now[0] == "کالای آزمون 1 ویرایش" and int(now[1]) == 2500, f"now={now}")
    st, b, _ = go(sess(), f"/item/{iid}")
    check("T5.2", "صفحهٔ عمومی کالا عنوان تازه را نشان می‌دهد", "کالای آزمون 1 ویرایش" in b, f"st={st}")
    go(op, f"/panel/catalog/{bid}/item/{iid}",
       {"title": orig[0], "price": str(orig[1]), "descr": orig[2] or "",
        "price_type": orig[3] or "fixed", "tags": orig[4] or ""})
    back = q("select title from items where id=?", (iid,))[0][0]
    check("T5.3", "بازگردانی عنوان/قیمت", back == orig[0], f"back={back}")
    tmp = "موقت QA " + uuid.uuid4().hex[:5]
    st, b, _ = go(op, f"/panel/catalog/{bid}/item/new",
                  {"title": tmp, "price": "100", "descr": "موقت", "price_type": "fixed", "tags": ""})
    row = q("select id from items where title=?", (tmp,))
    check("T5.4", "ساخت کالای تازه از پنل", row, f"st={st}")
    if row:
        nid = row[0][0]
        go(op, f"/panel/catalog/{bid}/item/{nid}/delete", {})
        gone = q("select id from items where id=?", (nid,))
        check("T5.5", "حذف کالا از پنل", not gone, f"gone={gone}")

# ─────────────────────────── T6 نظرات ───────────────────────────
def t6_reviews(op):
    print("── T6 نظرات: تأیید/پاسخ")
    rid = q("select id from reviews order by id desc limit 1")[0][0]
    q("update reviews set status='pending' where id=?", (rid,))
    st, b, _ = go(op, f"/panel/review/{rid}", {"action": "approve", "reply": ""})
    s = q("select status from reviews where id=?", (rid,))[0][0]
    check("T6.1", "تأیید نظر از پنل", s == "approved", f"st={st} status={s}")
    st, b, _ = go(op, f"/panel/review/{rid}", {"action": "reply", "reply": "پاسخ آزمونی QA"})
    rep = q("select reply from reviews where id=?", (rid,))[0][0]
    check("T6.2", "پاسخ مدیر به نظر ثبت می‌شود", rep == "پاسخ آزمونی QA", f"reply={rep!r}")
    q("update reviews set reply=NULL, status='approved' where id=?", (rid,))

# ─────────────────────────── T7 تیکت ───────────────────────────
def t7_tickets(op):
    print("── T7 تیکت: پاسخ پشتیبانی")
    tid = q("select id from tickets order by id desc limit 1")[0][0]
    n0 = q("select count(*) from ticket_msgs where ticket_id=?", (tid,))[0][0]
    boundary = "----QAboundary1234"
    mp = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"body\"\r\n\r\n"
          f"پاسخ آزمونی QA فاز ۱\r\n--{boundary}--\r\n").encode()
    st, b, _ = go(op, f"/panel/ticket/{tid}", mp,
                  {"Content-Type": f"multipart/form-data; boundary={boundary}"})
    n1 = q("select count(*) from ticket_msgs where ticket_id=?", (tid,))[0][0]
    check("T7.1", "پاسخ تیکت از پنل ثبت می‌شود (اثر در پایگاه)", n1 == n0 + 1, f"st={st} n0={n0} n1={n1}")
    q("delete from ticket_msgs where ticket_id=? and body like 'پاسخ آزمونی QA%'", (tid,))

# ─────────────────────── T8 ظاهر و متون ───────────────────────
def t8_appearance(op):
    print("── T8 ظاهر: تغییر متن اصلی و بازگردانی")
    import html as _h
    st, b, _ = go(op, "/panel/appearance")
    def val(name):
        m = re.search(rf'name="{name}"[^>]*value="([^"]*)"', b)
        if not m:
            m = re.search(rf'name="{name}"[^>]*>\s*([^<]*?)\s*</', b)
        return _h.unescape(m.group(1)) if m else ""
    orig = {k: val(k) for k in ["hero_title", "hero_lead", "hero_cta", "footer_note"]}
    st, b, _ = go(op, "/panel/appearance", {"hero_title": "عنوان آزمونی QA", "hero_lead": orig.get("hero_lead", ""),
                                            "hero_cta": orig.get("hero_cta", ""), "footer_note": orig.get("footer_note", "")})
    st, b, _ = go(sess(), "/")
    check("T8.1", "تغییر عنوان اصلی در خانه دیده می‌شود", "عنوان آزمونی QA" in b, f"st={st}")
    st, b, _ = go(op, "/panel/appearance", {"hero_title": orig.get("hero_title", ""), "hero_lead": orig.get("hero_lead", ""),
                                            "hero_cta": orig.get("hero_cta", ""), "footer_note": orig.get("footer_note", "")})
    cur = q("select value from settings where key='hero_title'")[0][0]
    check("T8.2", "بازگردانی متن اصلی (برابر مقدار اولیه)", cur == orig.get("hero_title", ""),
          f"cur={cur[:60]!r} orig={orig.get('hero_title','')[:60]!r}")

# ─────────────────────── T9 پشتیبان‌گیری ───────────────────────
def t9_backup(op):
    print("── T9 پشتیبان‌گیری از پنل")
    st, b, _ = go(op, "/panel/backup")
    check("T9.1", "صفحهٔ پشتیبان‌گیری 200", st == 200, f"got {st}")
    st, raw, hdr = go(op, "/panel/backup/db", raw=True)
    check("T9.2", "دانلود پشتیبان DB (فایل واقعی)", st == 200 and len(raw) > 10000, f"st={st} len={len(raw)}")
    st, raw, hdr = go(op, "/panel/backup/export", raw=True)
    check("T9.3", "خروجی JSON داده‌ها", st == 200 and len(raw) > 100, f"st={st} len={len(raw)}")

# ───────────────── T10 رگرسیونِ رفع‌های فاز ۰ ─────────────────
def t10_regressions(op):
    print("── T10 رگرسیون رفع‌های قبلی")
    st, b, _ = go(op, "/panel/unlocks?only=founder")
    check("T10.1", "چیپ unlocks با ?only= → 200", st == 200, f"got {st}")
    st, b, _ = go(op, "/panel/unlocks&only=paid")
    check("T10.2", "لینک کهنهٔ &only هنوز 404 است (رفع باقی است)", st == 404, f"got {st}")

# ───────────────── T11 چرخش کلید (تست امنیتی، آخرِ کار) ─────────────────
def t11_rotate():
    print("── T11 چرخش کلید پنل")
    old = key()
    opA = do_login("09131110011")   # نشست A — چرخاننده
    opB = do_login("09131110011")   # نشست B — تماشاگر
    st, b, _ = go(opB, "/panel")
    assert st == 200, "پیش‌شرط: نشست B فعال"
    go(opA, "/panel/rotate-token", {})
    new = key()
    check("T11.1", "rotate-token کلید را عوض می‌کند", new != old, f"old==new؟ {new == old}")
    st, b, _ = go(opB, "/panel")
    check("T11.2", "نشست‌های دیگر بعد از چرخش می‌میرند (403)", st == 403, f"got {st}")
    st, b, _ = go(opA, "/panel")
    check("T11.3", "چرخاننده با کلید تازهٔ ریدایرکت زنده می‌ماند (200)", st == 200, f"got {st}")
    op2 = do_login("09131110011")
    st, b, _ = go(op2, "/panel?key=" + new)
    st2, b2, _ = go(op2, "/panel")
    check("T11.4", "ورود دوباره با کلید تازه → داشبورد 200", st == 200 and st2 == 200, f"gate={st} panel={st2}")

def main():
    t1_gate()
    op = t2_login()
    t3_categories(op)
    t4_business(op)
    t5_items(op)
    t6_reviews(op)
    t7_tickets(op)
    t8_appearance(op)
    t9_backup(op)
    t10_regressions(op)
    t11_rotate()
    json.dump(RESULTS, open("qa/phase1-results.json", "w"), ensure_ascii=False, indent=1)
    fails = [r for r in RESULTS if not r["ok"]]
    print(f"\n═══ جمع: {len(RESULTS)} تست | سبز: {len(RESULTS)-len(fails)} | قرمز: {len(fails)}")
    for r in fails:
        print("  ❌", r["id"], r["name"], "—", r["detail"])
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
