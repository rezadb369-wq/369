#!/usr/bin/env bash
# ============================================================================
# پشتیبان شبانهٔ دستگیر — بدون نصب هیچ بسته‌ای (پایتون استاندارد + tar)
#   پایگاه:      SQLite با API رسمی backup  →  db_تاریخ.db
#   فایل‌ها:     عکس‌های آپلودی و chat-files  →  files_تاریخ.tar.gz
#   نگهداری:     KEEP روز (پیش‌فرض ۱۴)
#   بازیابی:     فایل db را روی data/bazarche.db کپی کنید + tar را در جای خودش بکشید
# ============================================================================
set -euo pipefail
APP_DIR="${APP_DIR:-/opt/dastgir}"
DEST="${DEST:-/var/backups/dastgir}"
KEEP="${KEEP:-14}"
mkdir -p "$DEST"
TS=$(date +%Y-%m-%d_%H%M)

# ۱) کپی امنِ SQLite (وسط کار هم پشتیبان یکپارچه می‌گیرد)
python3 - "$APP_DIR/data/bazarche.db" "$DEST/db_$TS.db" <<'PY'
import sqlite3, sys
src, dst = sys.argv[1], sys.argv[2]
s = sqlite3.connect(src)
d = sqlite3.connect(dst)
s.backup(d)
d.close(); s.close()
PY

# ۲) فایل‌های آپلودی (عکس کالا/دکان + پیوست‌های گفتگو)
tar czf "$DEST/files_$TS.tar.gz" -C "$APP_DIR" \
    "site/assets/img/uploads" "data/chat-files" 2>/dev/null || true

# ۳) پاک‌سازی پشتیبان‌های کهنه
find "$DEST" -name 'db_*.db'        -mtime "+$KEEP" -delete
find "$DEST" -name 'files_*.tar.gz' -mtime "+$KEEP" -delete
echo "✓ پشتیبان $TS ساخته شد → $DEST"
