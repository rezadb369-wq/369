#!/usr/bin/env bash
# ============================================================================
# به‌روزرسانی دستگیر از زیپ تازه — «داده‌ها دست‌نخورده می‌مانند»
#   روش:  sudo bash /opt/dastgir/deploy/update.sh dastgir-vNNN.zip
# زیپِ انتشار data/ ندارد؛ پس unzip -o فقط کد را جایگزین می‌کند و پایگاه،
# تنظیمات و عکس‌های آپلودی سر جایشان می‌مانند.
# ============================================================================
set -euo pipefail
ZIP="${1:-}"
[ -n "$ZIP" ] && [ -f "$ZIP" ] || { echo "روش درست:  sudo bash deploy/update.sh dastgir-vNNN.zip"; exit 1; }
echo "۱/۴) توقف سرویس…"
systemctl stop bazarche
echo "۲/۴) جایگزینی کد از $ZIP"
unzip -oq "$ZIP" -d /opt
chown -R www-data:www-data /opt/dastgir
echo "۳/۴) روشن‌کردن دوباره…"
systemctl restart bazarche
sleep 2
echo "۴/۴) وضعیت:"
systemctl --no-pager status bazarche | head -6
echo
echo "اگر assetها بامپ خورده‌اند (که در انتشارهای رسمی می‌خورند) کاربران چیزی از دست نمی‌دهند."
