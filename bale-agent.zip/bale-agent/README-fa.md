# ایجنت بله — فقط همین یک ربات

ربات بله با شناسهٔ `551646991` را به مغز **byNara** (`agnes-2.5-flash`) وصل می‌کند.

- ربات فروشگاه (`daastgirbot` / `BALE_BOT_TOKEN`) دست نخورده می‌ماند.
- ربات مدیر دست‌گیر (`BALE_ADMIN_TOKEN`) دست نخورده می‌ماند.
- `/opt/dastgir` و `/etc/dastgir-secrets.env` دست نخورده می‌مانند.
- [OpenClaw](https://openclaw.ai/) کانال رسمی بله ندارد؛ اگر OpenClaw روی سرور باشد و کانال تلگرام خالی/همین‌ربات باشد، همان کانال تلگرام با `apiRoot=https://tapi.bale.ai` تنظیم می‌شود. اگر OpenClaw تلگرام جدا داشته باشد، **هجوم نمی‌کنیم** و سرویس پایتون `bale-agent` نصب می‌شود.

## نصب (ترمیوس، روی سرور ایران)

از همین پوشه، بعد از آپلود zip:

```bash
cd /tmp && rm -rf bale-agent bale-agent.zip
# zip را در /tmp بگذار (scp یا همان الگوی گیت‌هاب)، سپس:
unzip -o /tmp/bale-agent.zip -d /tmp
sudo bash /tmp/bale-agent/setup.sh
```

اسکریپت:

1. `getMe` روی `tapi.bale.ai` — اگر توکن غلط باشد همان‌جا می‌ایستد.
2. `deleteWebhook` — تا long-poll پیام بگیرد (وب‌هوک قبلی این ربات را آزاد می‌کند، نه ربات‌های دیگر).
3. اگر OpenClaw امن باشد وصلش می‌کند؛ وگرنه `systemd` سرویس `bale-agent`.

## بعد از نصب

در بله به **همین ربات** بفرست:

- `/start` — راهنما
- `/ping` — باید `pong` بیاید
- `/new` — گفتگوی تازه
- هر متن دیگر — جواب با مغز byNara

لاگ:

```bash
journalctl -u bale-agent -f
```

اگر مسیر OpenClaw انتخاب شده باشد:

```bash
openclaw channels status --probe
openclaw logs --follow
```

## توقف / حذف (فقط همین ایجنت)

```bash
sudo systemctl disable --now bale-agent
sudo rm -f /etc/systemd/system/bale-agent.service /etc/bale-agent.env
sudo rm -rf /opt/bale-agent /var/lib/bale-agent
sudo systemctl daemon-reload
```

توکن و کلید در `/etc/bale-agent.env` هستند (دسترسی `600`). در گیت نگذار.

## چرا OpenClaw به‌تنهایی بله را زنده نمی‌کند؟

کانال‌های رسمی OpenClaw: تلگرام، واتساپ، دیسکورد، سیگنال، اسلک، … — **بله نیست**. API بله شبیه تلگرام است (`https://tapi.bale.ai`)؛ این بسته همان سازگاری را با خاموش‌کردن دستورهای native تلگرام (که در بله نیستند) به کار می‌گیرد.
