#!/bin/bash
# Install the isolated BALE agent for ONE bot token.
# Does NOT touch /opt/dastgir, /etc/dastgir-secrets.env, daastgirbot, or the admin bot.
set -euo pipefail

APP="${DASTGIR_BALE_AGENT_APP:-/opt/bale-agent}"
ENVF="${DASTGIR_BALE_AGENT_ENV:-/etc/bale-agent.env}"
STATE="${DASTGIR_BALE_AGENT_STATE:-/var/lib/bale-agent}"
HERE="$(cd "$(dirname "$0")" && pwd)"

BALE_AGENT_TOKEN="${BALE_AGENT_TOKEN:-551646991:uvaavr8JQXbNoUHCIt3-wFG74S7iWaDoKoA}"
AI_BRAIN_BYNARA_KEY="${AI_BRAIN_BYNARA_KEY:-sk-nry-kdYriEsKcM3iBfeY0mavRjMoz2mXdf_iEMJ_4OP_3NY}"
AI_BASE_URL="${AI_BASE_URL:-https://router.bynara.id/v1}"
AI_MODEL="${AI_MODEL:-agnes-2.5-flash}"
BALE_API_ROOT="${BALE_API_ROOT:-https://tapi.bale.ai/bot}"

if [ "$(id -u)" -ne 0 ]; then
  echo "با sudo اجرا کن: sudo bash $0" >&2
  exit 1
fi

echo "== BALE agent setup (bot id ${BALE_AGENT_TOKEN%%:*}) =="
echo "  این اسکریپت BALE_BOT_TOKEN / BALE_ADMIN_TOKEN دست‌گیر را دست نمی‌زند."

install -d -m 0755 "$APP" "$STATE"
install -m 0644 "$HERE/agent.py" "$APP/agent.py"
install -m 0644 "$HERE/merge_openclaw.py" "$APP/merge_openclaw.py"
install -m 0644 "$HERE/bale-agent.service" /etc/systemd/system/bale-agent.service

umask 077
cat > "$ENVF" <<EOF
# Isolated BALE agent — do not copy into git / dastgir-secrets.env
BALE_AGENT_TOKEN=$BALE_AGENT_TOKEN
BALE_API_ROOT=$BALE_API_ROOT
BALE_AGENT_STATE=$STATE
AI_BRAIN_BYNARA_KEY=$AI_BRAIN_BYNARA_KEY
AI_BASE_URL=$AI_BASE_URL
AI_MODEL=$AI_MODEL
EOF
chmod 600 "$ENVF"

echo "-- getMe (BALE) --"
ME_JSON="$(python3 - "$ENVF" <<'PY'
import json, os, urllib.request, sys
env = {}
for line in open(sys.argv[1], encoding="utf-8"):
    line=line.strip()
    if not line or line.startswith("#") or "=" not in line: continue
    k,v=line.split("=",1); env[k]=v
tok=env["BALE_AGENT_TOKEN"]; root=env.get("BALE_API_ROOT","https://tapi.bale.ai/bot").rstrip("/")
url=f"{root}{tok}/getMe"
try:
    req=urllib.request.Request(url, data=b"{}", headers={"Content-Type":"application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=20) as r:
        print(r.read().decode("utf-8","replace"))
except Exception as e:
    print(json.dumps({"ok": False, "description": str(e)}))
PY
)"
echo "$ME_JSON"
python3 -c 'import json,sys; d=json.loads(sys.argv[1]);
raise SystemExit(0 if d.get("ok") else 2)' "$ME_JSON" || {
  echo "getMe شکست — توکن یا دسترسی به tapi.bale.ai را چک کن." >&2
  exit 2
}

echo "-- deleteWebhook (تا long-poll کار کند) --"
python3 - "$ENVF" <<'PY'
import json, os, urllib.request, sys
env = {}
for line in open(sys.argv[1], encoding="utf-8"):
    line=line.strip()
    if not line or line.startswith("#") or "=" not in line: continue
    k,v=line.split("=",1); env[k]=v
tok=env["BALE_AGENT_TOKEN"]; root=env.get("BALE_API_ROOT","https://tapi.bale.ai/bot").rstrip("/")
url=f"{root}{tok}/deleteWebhook"
req=urllib.request.Request(url, data=b'{"drop_pending_updates":false}',
                           headers={"Content-Type":"application/json"}, method="POST")
try:
    with urllib.request.urlopen(req, timeout=15) as r:
        print(r.read().decode("utf-8","replace"))
except Exception as e:
    print("deleteWebhook:", e)
PY

OPENCLAW_BIN="$(command -v openclaw || true)"
OPENCLAW_CFG=""
USED_OPENCLAW=0
if [ -n "$OPENCLAW_BIN" ]; then
  for cand in /root/.openclaw/openclaw.json "$HOME/.openclaw/openclaw.json" /home/*/.openclaw/openclaw.json; do
    if [ -f "$cand" ]; then OPENCLAW_CFG="$cand"; break; fi
  done
  if [ -z "$OPENCLAW_CFG" ]; then
    if [ -d /root/.openclaw ]; then OPENCLAW_CFG=/root/.openclaw/openclaw.json
    elif [ -n "${SUDO_USER:-}" ] && [ -d "/home/$SUDO_USER/.openclaw" ]; then
      OPENCLAW_CFG="/home/$SUDO_USER/.openclaw/openclaw.json"
    fi
  fi
fi

if [ -n "$OPENCLAW_BIN" ] && [ -n "$OPENCLAW_CFG" ]; then
  echo "-- OpenClaw پیدا شد: $OPENCLAW_BIN  config=$OPENCLAW_CFG --"
  set +e
  MERGE_OUT="$(BALE_AGENT_TOKEN="$BALE_AGENT_TOKEN" AI_BRAIN_BYNARA_KEY="$AI_BRAIN_BYNARA_KEY" \
    python3 "$APP/merge_openclaw.py" "$OPENCLAW_CFG")"
  MERGE_RC=$?
  set -e
  echo "$MERGE_OUT"
  if [ "$MERGE_RC" -eq 0 ] && echo "$MERGE_OUT" | grep -q '"applied": true'; then
    USED_OPENCLAW=1
    echo "OpenClaw به apiRoot=https://tapi.bale.ai وصل شد (دستورات native بله خاموش)."
    if command -v systemctl >/dev/null 2>&1; then
      systemctl restart openclaw-gateway 2>/dev/null || \
      systemctl restart openclaw 2>/dev/null || \
      "$OPENCLAW_BIN" gateway restart 2>/dev/null || \
      echo "Gateway را دستی ری‌استارت کن: openclaw gateway restart"
    fi
  else
    echo "OpenClaw دست نخورده ماند (احتمالاً تلگرام جدا دارد). ایجنت پایتون نصب می‌شود."
  fi
elif [ -n "$OPENCLAW_BIN" ]; then
  echo "openclaw هست ولی openclaw.json پیدا نشد — ایجنت پایتون نصب می‌شود."
else
  echo "OpenClaw روی این سرور در PATH نیست — ایجنت پایتون نصب می‌شود."
fi

if [ "$USED_OPENCLAW" -eq 1 ]; then
  echo "-- OpenClaw مسئول این ربات است؛ سرویس پایتون را فعال نمی‌کنم (تداخل getUpdates). --"
  systemctl disable --now bale-agent 2>/dev/null || true
  echo "OK openclaw-bale"
  echo "در بله به ربات پیام بده. اگر pairing خواست:"
  echo "  openclaw pairing list telegram"
  echo "  openclaw pairing approve telegram <CODE>"
  echo "(این کانال dmPolicy=open است و باید بدون pairing جواب بدهد.)"
  exit 0
fi

echo "-- systemd bale-agent --"
systemctl daemon-reload
systemctl enable --now bale-agent
sleep 2
systemctl --no-pager --full status bale-agent | head -25 || true
echo
echo "لاگ زنده: journalctl -u bale-agent -f"
echo "در بله به همین ربات /start بفرست."
echo "OK python-bale-agent"
