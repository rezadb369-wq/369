# -*- coding: utf-8 -*-
"""Unit tests for the isolated BALE agent (no live network)."""
import json
import os
import sys
import tempfile
import unittest
from unittest import mock

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

os.environ["BALE_AGENT_TOKEN"] = "551646991:unit-test-token-not-real"
os.environ["AI_BRAIN_BYNARA_KEY"] = "sk-nry-unit-test-key"
os.environ["AI_BASE_URL"] = "https://router.bynara.id/v1"
os.environ["AI_MODEL"] = "agnes-2.5-flash"
os.environ["BALE_AGENT_STATE"] = tempfile.mkdtemp(prefix="bale-agent-test-")

import agent  # noqa: E402


class AgentTests(unittest.TestCase):
    def setUp(self):
        agent.STATE_DIR = tempfile.mkdtemp(prefix="bale-mem-")
        os.environ["BALE_AGENT_STATE"] = agent.STATE_DIR

    def test_redact_bot_token_and_keys(self):
        s = agent.redact("tok 551646991:uvaavr8JQXbNoUHCIt3-wFG74S7iWaDoKoA and sk-nry-abc123456789")
        self.assertNotIn("uvaavr8", s)
        self.assertNotIn("sk-nry-abc", s)
        self.assertIn("کلید مخفی", s)

    def test_private_only(self):
        self.assertTrue(agent.is_private({"chat": {"type": "private", "id": 1}}))
        self.assertFalse(agent.is_private({"chat": {"type": "group", "id": -5}}))
        self.assertFalse(agent.is_private({"chat": {"type": "supergroup", "id": -100}}))

    def test_start_help(self):
        out = agent.handle_text(1, "/start")
        self.assertIn("ایجنت", out)
        self.assertIn("/ping", out)
        self.assertIn("agnes-2.5-flash", out)

    def test_new_clears_history(self):
        agent.history_set(7, [{"role": "user", "content": "hi"}])
        out = agent.handle_text(7, "/new")
        self.assertIn("پاک", out)
        self.assertEqual(agent.history_for(7), [])

    def test_ping(self):
        self.assertIn("pong", agent.handle_text(1, "/ping"))

    def test_model(self):
        out = agent.handle_text(1, "/model")
        self.assertIn("agnes-2.5-flash", out)
        self.assertIn("bynara.id", out)

    def test_chat_calls_llm_and_stores(self):
        with mock.patch.object(agent, "llm_chat", return_value="۳+۳ می‌شود ۶") as llm:
            out = agent.handle_text(42, "۳ بعلاوه ۳ چند می‌شود؟")
        self.assertEqual(out, "۳+۳ می‌شود ۶")
        llm.assert_called_once()
        msgs = llm.call_args[0][0]
        self.assertEqual(msgs[0]["role"], "system")
        self.assertEqual(msgs[-1]["role"], "user")
        hist = agent.history_for(42)
        self.assertEqual(hist[-1]["role"], "assistant")
        self.assertEqual(hist[-2]["content"], "۳ بعلاوه ۳ چند می‌شود؟")

    def test_group_update_ignored(self):
        with mock.patch.object(agent, "bale_send") as send, mock.patch.object(agent, "handle_text") as ht:
            agent.handle_update({
                "update_id": 1,
                "message": {
                    "chat": {"id": -100, "type": "group"},
                    "text": "سلام",
                    "from": {"id": 9, "is_bot": False},
                },
            })
        send.assert_not_called()
        ht.assert_not_called()

    def test_private_update_sends_reply(self):
        with mock.patch.object(agent, "bale_typing"), \
             mock.patch.object(agent, "handle_text", return_value="سلام"), \
             mock.patch.object(agent, "bale_send", return_value={"ok": True}) as send:
            agent.handle_update({
                "update_id": 2,
                "message": {
                    "chat": {"id": 99, "type": "private"},
                    "text": "hi",
                    "from": {"id": 9, "is_bot": False},
                },
            })
        send.assert_called_once()
        self.assertEqual(send.call_args[0][0], 99)
        self.assertEqual(send.call_args[0][1], "سلام")

    def test_llm_parses_openai_shape(self):
        fake = {"choices": [{"message": {"content": "ok-from-brain"}}]}
        with mock.patch.object(agent, "_http_json", return_value=fake):
            self.assertEqual(agent.llm_chat([{"role": "user", "content": "x"}]), "ok-from-brain")

    def test_llm_error_message(self):
        fake = {"error": {"message": "rate_limited"}}
        with mock.patch.object(agent, "_http_json", return_value=fake):
            out = agent.llm_chat([{"role": "user", "content": "x"}])
        self.assertIn("rate_limited", out)

    def test_chunk_send(self):
        calls = []

        def fake_call(method, payload=None, timeout=20):
            calls.append((method, payload))
            return {"ok": True}

        long = "آ" * (agent.MAX_REPLY + 50)
        with mock.patch.object(agent, "bale_call", side_effect=fake_call):
            out = agent.bale_send(5, long)
        self.assertTrue(out.get("ok"))
        sends = [c for c in calls if c[0] == "sendMessage"]
        self.assertEqual(len(sends), 2)
        self.assertEqual(len(sends[0][1]["text"]), agent.MAX_REPLY)

    def test_does_not_touch_dastgir_env_names_in_token_fn(self):
        src = open(os.path.join(ROOT, "agent.py"), encoding="utf-8").read()
        self.assertNotIn("BALE_BOT_TOKEN", src)
        self.assertNotIn("BALE_ADMIN_TOKEN", src)
        self.assertNotIn("daastgirbot", src)


class MergeTests(unittest.TestCase):
    def test_skip_when_other_telegram_token(self):
        import merge_openclaw as m
        cfg = {"channels": {"telegram": {"botToken": "111:OTHER", "apiRoot": "https://api.telegram.org"}}}
        decision = m.can_bind(cfg, "551646991:THIS")
        self.assertFalse(decision["ok"])
        self.assertIn("telegram", decision["reason"])

    def test_bind_when_empty(self):
        import merge_openclaw as m
        cfg = {}
        decision = m.can_bind(cfg, "551646991:THIS")
        self.assertTrue(decision["ok"])
        out = m.merge(cfg, "551646991:THIS", "sk-nry-key")
        tg = out["channels"]["telegram"]
        self.assertEqual(tg["apiRoot"], "https://tapi.bale.ai")
        self.assertEqual(tg["botToken"], "551646991:THIS")
        self.assertEqual(tg["allowFrom"], ["*"])
        self.assertFalse(tg["commands"]["native"])
        self.assertEqual(out["agents"]["defaults"]["model"]["primary"], "bynara/agnes-2.5-flash")
        self.assertEqual(out["models"]["providers"]["bynara"]["baseUrl"], "https://router.bynara.id/v1")

    def test_bind_when_already_this_bot(self):
        import merge_openclaw as m
        cfg = {"channels": {"telegram": {"botToken": "551646991:THIS", "dmPolicy": "pairing"}}}
        self.assertTrue(m.can_bind(cfg, "551646991:THIS")["ok"])
        out = m.merge(cfg, "551646991:THIS", "sk-nry-key")
        self.assertEqual(out["channels"]["telegram"]["apiRoot"], "https://tapi.bale.ai")


if __name__ == "__main__":
    unittest.main(verbosity=2)
