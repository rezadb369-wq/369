# -*- coding: utf-8 -*-
"""Merge BALE bot + byNara into OpenClaw config — never hijack a real Telegram bot."""
from __future__ import annotations

import copy
import json
import os
from typing import Any

BALE_API_ROOT = "https://tapi.bale.ai"
BYNARA_BASE = "https://router.bynara.id/v1"
DEFAULT_MODEL = "agnes-2.5-flash"


def _tg(cfg: dict) -> dict:
    ch = cfg.get("channels") if isinstance(cfg.get("channels"), dict) else {}
    tg = ch.get("telegram") if isinstance(ch.get("telegram"), dict) else {}
    return tg


def can_bind(cfg: dict, bot_token: str) -> dict:
    tg = _tg(cfg)
    existing = str(tg.get("botToken") or tg.get("token") or "").strip()
    api_root = str(tg.get("apiRoot") or "").rstrip("/")
    if not existing:
        return {"ok": True, "reason": "no telegram token yet"}
    if existing == bot_token:
        return {"ok": True, "reason": "already this bale bot"}
    if "tapi.bale.ai" in api_root:
        return {"ok": True, "reason": "already pointed at bale"}
    return {
        "ok": False,
        "reason": "openclaw already has a different telegram bot — will not hijack it",
    }


def merge(cfg: dict, bot_token: str, bynara_key: str, model: str = DEFAULT_MODEL) -> dict:
    out = copy.deepcopy(cfg) if isinstance(cfg, dict) else {}
    channels = out.setdefault("channels", {})
    if not isinstance(channels, dict):
        channels = {}
        out["channels"] = channels
    tg = channels.get("telegram") if isinstance(channels.get("telegram"), dict) else {}
    tg.update({
        "enabled": True,
        "botToken": bot_token,
        "apiRoot": BALE_API_ROOT,
        "dmPolicy": "open",
        "allowFrom": ["*"],
        "groupPolicy": "disabled",
        "joinIntro": False,
        "configWrites": False,
        "linkPreview": False,
        "reactionNotifications": "off",
        "streaming": {"mode": "off"},
        "commands": {"native": False, "nativeSkills": False},
        "actions": {"reactions": False, "sendMessage": True},
        "network": {"dnsResultOrder": "ipv4first"},
    })
    # Public chat only — no shell/write on the OpenClaw host.
    tg.setdefault("direct", {})
    if isinstance(tg["direct"], dict):
        tg["direct"].setdefault("*", {})
        if isinstance(tg["direct"]["*"], dict):
            tools = tg["direct"]["*"].setdefault("tools", {})
            if isinstance(tools, dict):
                deny = tools.setdefault("deny", [])
                if isinstance(deny, list):
                    for t in ("exec", "process", "write", "edit", "apply_patch", "browser"):
                        if t not in deny:
                            deny.append(t)
    channels["telegram"] = tg

    models = out.setdefault("models", {})
    if not isinstance(models, dict):
        models = {}
        out["models"] = models
    models.setdefault("mode", "merge")
    providers = models.setdefault("providers", {})
    if not isinstance(providers, dict):
        providers = {}
        models["providers"] = providers
    providers["bynara"] = {
        "baseUrl": BYNARA_BASE,
        "apiKey": bynara_key,
        "api": "openai-completions",
        "models": [
            {
                "id": "agnes-2.5-flash",
                "name": "Agnes 2.5 Flash (byNara)",
                "reasoning": False,
                "input": ["text"],
                "contextWindow": 128000,
                "maxTokens": 8192,
            },
            {
                "id": "nemotron-3-ultra-free",
                "name": "Nemotron 3 Ultra Free",
                "reasoning": False,
                "input": ["text"],
                "contextWindow": 128000,
                "maxTokens": 8192,
            },
        ],
    }
    agents = out.setdefault("agents", {})
    if not isinstance(agents, dict):
        agents = {}
        out["agents"] = agents
    defaults = agents.setdefault("defaults", {})
    if not isinstance(defaults, dict):
        defaults = {}
        agents["defaults"] = defaults
    model_block = defaults.setdefault("model", {})
    if not isinstance(model_block, dict):
        model_block = {}
        defaults["model"] = model_block
    model_block["primary"] = f"bynara/{model}"
    return out


def apply_file(path: str, bot_token: str, bynara_key: str) -> dict:
    try:
        with open(path, encoding="utf-8") as f:
            raw = f.read()
        cfg = json.loads(raw) if raw.strip() else {}
    except FileNotFoundError:
        cfg = {}
    if not isinstance(cfg, dict):
        raise SystemExit(f"openclaw config is not an object: {path}")
    decision = can_bind(cfg, bot_token)
    if not decision["ok"]:
        return {"applied": False, **decision}
    merged = merge(cfg, bot_token, bynara_key)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(merged, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, path)
    return {"applied": True, **decision, "path": path}


if __name__ == "__main__":
    import os
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.expanduser("~/.openclaw/openclaw.json")
    tok = os.environ["BALE_AGENT_TOKEN"]
    key = os.environ.get("AI_BRAIN_BYNARA_KEY") or os.environ["AI_API_KEY"]
    print(json.dumps(apply_file(path, tok, key), ensure_ascii=False, indent=2))
