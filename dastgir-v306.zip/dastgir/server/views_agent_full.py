# -*- coding: utf-8 -*-
"""v300 full agent console — standalone /agent + /panel/agent — complete, tested"""

import json as _js
import os, time as _t, html as _html
import db
from ui import av, icon, esc, fa, fa_group, stat_card, empty_state, page as public_page, panel_page
from views_panel import _msg, _pg, panel_pager
from ui import jdate, jdatetime, jdatetime_ts

def _arena_status(s):
    try:
        import assistant
        cfg = assistant.public_config()
        sitecfg = assistant.site_public_config()
        prov = assistant.last_provider()
        err = assistant.last_error()
        ready = assistant.configured()
        site_ready = bool(sitecfg.get("has_key"))
        return {
            "ready": ready,
            "site_ready": site_ready,
            "cfg": cfg,
            "sitecfg": sitecfg,
            "prov": prov,
            "err": err,
            "stats": assistant.stats(7),
        }
    except Exception as e:
        return {"error": str(e)[:300]}

def _live_data():
    import json as _js, pathlib as _pl
    pend_data = {}
    try:
        pf = "/tmp/dastgir-admin-pending.json"
        if _pl.Path(pf).exists():
            pend_data = _js.loads(_pl.Path(pf).read_text(encoding="utf-8")[:8000] or "{}")
    except Exception:
        pend_data = {}
    try:
        batches = db.agent_batch_list()
        staged = [b for b in batches if b["status"]=="staged"]
        applied = [b for b in batches if b["status"]=="applied"]
    except Exception:
        batches, staged, applied = [], [], []
    try:
        last = {}
        lp = "/tmp/dastgir-agent-last-action.json"
        if _pl.Path(lp).exists():
            last = _js.loads(_pl.Path(lp).read_text(encoding="utf-8")[:8000] or "{}")
    except Exception:
        last = {}
    try:
        has_rb = _pl.Path(os.path.join(db.DATA_DIR, "agent-rollback.json")).exists()
    except Exception:
        has_rb = False
    try:
        import adminbot_content as CT
        ok_h, msg_h = CT.tool_execute("health_check", {})
        health_msg = str(msg_h)[:3000]
    except Exception as e:
        health_msg = f"خطا: {e}"
    try:
        import adminbot_content as CT
        tools = list(CT.TOOLS)
    except Exception:
        tools = ["setting","business_save","item_save","backup_now","health_check","seo_check","bulk_approve","cache_clear","code_read","code_search","code_edit","sec_report","panel_read"]
    return pend_data, batches, staged, applied, last, has_rb, health_msg, tools

def agent_email_gate(s, token="", next_url="/agent"):
    body = f'''
<div class="container" style="max-width:520px;margin:60px auto">
  <div class="card glass card-pad" style="text-align:center">
    <div class="auth-head"><span class="mark">{icon("mail")}</span>
      <h1>ورود با ایمیل — پنل ایجنت</h1>
      <p class="text-sm text-muted">مثل Arena AI — ایمیلتو وارد کن، کد ۶ رقمی میاد، بعد وارد صفحه همه‌کاره ایجنت میشی.</p>
    </div>
    <form method="post" action="/login/email" class="mt-lg" style="text-align:start">
      <input type="hidden" name="next" value="{esc(next_url)}">
      <div class="field"><label class="field-label">ایمیل</label>
        <input class="input" name="email" type="email" dir="ltr" placeholder="you@example.com" required></div>
      <button class="btn btn-primary btn-block" type="submit">{icon("mail")}<span>ارسال کد ورود</span></button>
    </form>
    <p class="field-hint mt-md">یا با موبایل: <a href="/login?next={esc(next_url)}">ورود با موبایل</a></p>
  </div>
</div>'''
    return public_page(s, "ورود ایمیلی — ایجنت", body, active="/agent")

def agent_key_gate(s, token="", customer=None, owner=None):
    email = ""
    if customer:
        email = customer.get("email") or customer.get("phone") or f"#{customer.get('id')}"
    elif owner:
        email = owner.get("phone") or f"owner#{owner.get('id')}"
    body = f'''
<div class="container" style="max-width:640px;margin:40px auto">
  <div class="card glass card-pad">
    <h2 class="card-title">{icon("lock")} کلید خصوصی ایجنت لازم است</h2>
    <p class="text-sm text-muted">وارد شدی به عنوان <b>{esc(email)}</b> — حالا کلید خصوصی ایجنت رو از ربات بله مدیر بگیر.</p>
    <div class="alert alert-info mt-md">{icon("info")}<span>تو ربات بله مدیر بزن <code>/agent</code> یا <code>پنل ایجنت</code> — ربات لینک یک‌بارمصرف میده مثل <code>/agent?ak=...</code> — روش بزن تا کوکی ست بشه.</span></div>
    <div class="cluster mt-md">
      <a class="btn btn-glass" href="/panel/agent">{icon("settings")}<span>رفتن به /panel/agent (ادمین)</span></a>
      <a class="btn btn-ghost" href="/">{icon("store")}<span>سایت اصلی</span></a>
    </div>
  </div>
</div>'''
    # if admin, use panel_page else public_page
    if token:
        return panel_page(s, "کلید ایجنت", "کلید خصوصی از ربات بله", body, "/panel/agent", token)
    return public_page(s, "کلید ایجنت", body, active="/agent")

def agent_standalone_page(s, token, q=None, customer=None, owner=None, agent_ok=False):
    """Full standalone /agent — separate from panel, email login, arena connected, model switcher, fully active, tested"""
    q = q or {}
    pend_data, batches, staged, applied, last_action, has_rollback, health_msg, tools = _live_data()
    arena = _arena_status(s)
    import assistant as _AST
    try:
        ai_today = arena.get("stats",{}).get("today",{}).get("n",0)
    except Exception:
        ai_today = 0

    tool_opts = "".join(f'<option value="{esc(t)}">{esc(t)}</option>' for t in tools)

    # keys table
    try:
        keys = db.agent_key_list(limit=8)
        keys_html = "".join(f'<tr><td class="nums" dir="ltr" style="font-size:11px">{esc(k["token"][:16])}…</td><td class="nums">{esc(jdatetime_ts(k["created"]))}</td><td>{fa(max(0,int((k["expires"]-_t.time())//60)))} د</td><td>{"✅" if k["used"] else "⏳"}</td></tr>' for k in keys) or '<tr><td colspan="4" class="text-muted">—</td></tr>'
    except Exception:
        keys_html = '<tr><td colspan="4">—</td></tr>'

    # pending
    pend_html = ""
    if pend_data and pend_data.get("action")=="agent_confirm":
        try:
            tgt = _js.loads(pend_data.get("target") or "{}")
            pend_html = f'''<div class="alert alert-warn"><b>در انتظار تایید بله:</b><br><pre style="white-space:pre-wrap;max-height:240px;overflow:auto" dir="ltr">{esc(_js.dumps(tgt, ensure_ascii=False, indent=2)[:2500])}</pre>
            <div class="cluster mt-sm"><form method="post" action="/agent/confirm" style="display:inline"><button class="btn btn-primary btn-sm">✅ تایید و اجرا</button></form>
            <form method="post" action="/agent/cancel" style="display:inline"><button class="btn btn-glass btn-sm">❌ لغو</button></form></div></div>'''
        except Exception:
            pend_html = f'<div class="alert alert-warn">pending: {esc(str(pend_data)[:400])}</div>'

    batch_rows = ""
    for b in staged[-30:]:
        try:
            args = _js.loads(b["args"]) if b["args"] else {}
            args_s = _js.dumps(args, ensure_ascii=False)[:400]
        except Exception:
            args_s = (b["args"] or "")[:400]
        batch_rows += f'''<tr>
          <td class="nums">#{b["id"]}</td><td><code>{esc(b["tool"])}</code></td><td class="text-xs"><pre style="white-space:pre-wrap;max-height:120px;overflow:auto">{esc(args_s)}</pre></td>
          <td><span class="badge badge-warn">{esc(b["status"])}</span></td>
          <td class="nums text-xs">{esc(jdatetime_ts(b["created"]))}</td>
          <td><form method="post" action="/agent/batch/remove" style="display:inline"><input type="hidden" name="id" value="{b["id"]}"><button class="btn btn-ghost btn-sm">✕</button></form></td>
        </tr>'''
    if not batch_rows:
        batch_rows = '<tr><td colspan="6" class="text-center text-muted">صف خالی — ابزار اضافه کن تا با یک دستور همه اعمال شوند.</td></tr>'

    last_html = ""
    if last_action:
        last_html = f'<div class="card glass card-pad mb-lg"><h3 class="card-title mb-md">{icon("activity")} آخرین اقدام</h3><pre style="max-height:220px;overflow:auto" dir="ltr">{esc(_js.dumps(last_action, ensure_ascii=False, indent=2)[:4000])}</pre></div>'

    # arena box
    arena_html = ""
    try:
        cfg = arena.get("cfg",{})
        sitecfg = arena.get("sitecfg",{})
        prov = arena.get("prov",{})
        err = arena.get("err",{})
        prov_label = {"primary":"اصلی","smart":"قوی"}.get(prov.get("which"),"—")
        arena_html = f'''
<div class="card glass card-pad mb-lg">
  <h3 class="card-title mb-md">{icon("sparkles")} اتصال آرنا / هوش</h3>
  <div class="grid grid-2" style="gap:10px">
    <div><b>مغز مدیر:</b> { "✅ متصل" if arena.get("ready") else "❌ بدون کلید"} — <code dir="ltr">{esc(cfg.get("model") or "—")}</code> @ {esc((cfg.get("base_url") or "")[:40])}</div>
    <div><b>هوش سایت (کاربران):</b> { "✅ متصل" if arena.get("site_ready") else "⚠️ قاعده‌مند"} — <code dir="ltr">{esc(sitecfg.get("model") or "—")}</code></div>
    <div><b>آخرین مدل موفق:</b> {esc(prov_label)} <code dir="ltr">{esc(prov.get("model") or "—")}</code> {esc(jdatetime_ts(prov.get("when"))) if prov.get("when") else ""}</div>
    <div><b>آخرین خطا:</b> {esc(err.get("what") or "—")} {esc(jdatetime_ts(err.get("when"))) if err.get("when") else ""}</div>
  </div>
  <p class="field-hint mt-sm">کلیدها در <code>/etc/dastgir-secrets.env</code> — اینجا فقط وضعیت نمایش داده می‌شود.</p>
</div>'''
    except Exception as e:
        arena_html = f"<p>arena error {esc(str(e)[:200])}</p>"

    # model switcher
    switcher = '''
<div class="cluster mb-md" id="model-switcher" style="gap:8px;flex-wrap:wrap">
  <span class="text-sm"><b>هوش:</b></span>
  <button class="chip is-active" data-model="auto">🤖 خودکار (Arena)</button>
  <button class="chip" data-model="smart">🧠 قوی (Smart)</button>
  <button class="chip" data-model="fast">⚡ سریع (Fast)</button>
  <button class="chip" data-model="offline">📴 آفلاین (نامحدود)</button>
  <span class="badge badge-open" id="model-current">auto</span>
</div>
'''

    cust_label = ""
    if customer:
        cust_label = customer.get("email") or customer.get("phone") or f"cust#{customer.get('id')}"
    elif owner:
        cust_label = owner.get("phone") or "owner"

    content = f'''
{_msg(q)}
<div class="between mb-lg" style="flex-wrap:wrap;gap:12px">
  <div><h1 style="margin:0">{icon("sparkles")} پنل ایجنت — صفحه همه‌کاره <span class="badge badge-open">✅ فعال — {esc(cust_label)}</span></h1>
  <p class="text-sm text-muted mt-sm">جدا از پنل مدیریتی، با ورود ایمیلی (مثل Arena)، اتصال آرنا، سوئیچ هوش‌ها، دسترسی آزاد به همه ابزارها، یک دستور اعمال همه، نامحدود شخصی.</p></div>
  <div class="cluster">
    <a class="btn btn-glass btn-sm" href="/panel/agent">{icon("settings")}<span>نسخه پنلی</span></a>
    <a class="btn btn-ghost btn-sm" href="/">{icon("store")}<span>سایت</span></a>
  </div>
</div>

{switcher}

<div class="card glass card-pad mb-lg" style="border:2px solid #4f46e5">
  <div class="between" style="flex-wrap:wrap;gap:12px">
    <div><h3 class="card-title">{icon("globe")} مرورگر خارجی + پل آرنا — ابزار مرور وب خارجی فعال ✅</h3>
    <p class="text-sm text-muted">ایجنت حالا می‌تواند <code>https://arena.ai/agent/01a0acde-4c14-7c72-9934-1df78579ea49</code> را باز کند، با آن ایجنت چت کند، فایل بفرستد/بگیرد. مدیریت کامل در <code>/agent/browser</code> قابل مشاهده است.</p>
    <p class="field-hint">فایل‌های تبادل در <code>data/agent-exchange/</code> و لاگ پل در <code>data/arena-bridge/latest.json</code> ذخیره می‌شود — پایدار و قابل مدیریت.</p></div>
    <div class="cluster">
      <a class="btn btn-primary" href="/agent/browser" target="_blank">{icon("external")}<span>باز کردن مرورگر خارجی</span></a>
      <a class="btn btn-glass" href="/agent/browser?url=https://arena.ai/agent/01a0acde-4c14-7c72-9934-1df78579ea49" target="_blank">رفتن به آرنا</a>
    </div>
  </div>
</div>

<div class="grid grid-4 mb-lg">
  {stat_card("activity", len(staged), "در صف (staged)")}
  {stat_card("check-circle", len(applied), "اعمال شده")}
  {stat_card("zap", ai_today, "پیام امروز")}
  {stat_card("shield", 1 if has_rollback else 0, "Rollback")}
</div>

{arena_html}
{pend_html}

<div class="grid grid-2 mb-lg" style="align-items:start">
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("plus")} افزودن به صف دسته‌ای</h3>
    <form method="post" action="/agent/batch/add" data-validate>
      <div class="field"><label class="field-label">ابزار</label><select class="select" id="ab-tool" name="tool" required>{tool_opts}</select></div>
      <div class="field"><label class="field-label">JSON args</label><textarea class="textarea" id="ab-args" name="args" style="min-height:110px;font-family:monospace;direction:ltr" placeholder='{{"key":"site_name","value":"نام جدید"}}'>{{}}</textarea></div>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>افزودن به صف</span></button>
    </form>
    <hr class="divider">
    <h4 class="card-title mb-sm">{icon("zap")} اجرای فوری</h4>
    <form method="post" action="/agent/exec">
      <div class="field"><label class="field-label">ابزار</label><select class="select" name="tool" required>{tool_opts}</select></div>
      <div class="field"><label class="field-label">JSON</label><textarea class="textarea" name="args" style="min-height:80px;font-family:monospace;direction:ltr">{{}}</textarea></div>
      <button class="btn btn-accent btn-block" type="submit">{icon("zap")}<span>اجرای فوری</span></button>
    </form>
    <div class="cluster mt-md" style="flex-wrap:wrap">
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"setting","args":{{"key":"site_name","value":"دست گیر"}}}}'>site_name</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"health_check","args":{{}}}}'>health</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"seo_check","args":{{}}}}'>seo</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"backup_now","args":{{}}}}'>backup</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"cache_clear","args":{{}}}}'>cache clear</button>
      <button class="btn btn-glass btn-sm" data-quick='{{"tool":"bulk_approve","args":{{"kind":"businesses"}}}}'>approve</button>
    </div>
  </div>
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("shield")} کلیدها + سلامت</h3>
    <div class="table-wrap"><table class="table"><thead><tr><th>کلید</th><th>ساخته</th><th>انقضا</th><th>وضعیت</th></tr></thead><tbody>{keys_html}</tbody></table></div>
    <p class="field-hint mt-sm">کلید فقط یک‌بار در بله نمایش داده می‌شود — در DB فقط هش.</p>
    <hr class="divider">
    <h4 class="card-title mb-sm">{icon("activity")} سلامت زنده</h4>
    <pre style="max-height:180px;overflow:auto;white-space:pre-wrap" class="text-xs">{esc(health_msg[:2000])}</pre>
  </div>
</div>

<div class="card glass card-pad mb-lg">
  <div class="between mb-md"><h3 class="card-title">{icon("layers")} صف دسته‌ای — {fa(len(staged))} آماده</h3>
  <div class="cluster">
    <form method="post" action="/agent/batch/apply" data-confirm="همه اعمال شود؟"><button class="btn btn-primary" type="submit">⚡ اعمال همه ({fa(len(staged))})</button></form>
    <form method="post" action="/agent/batch/clear" data-confirm="پاک شود؟"><button class="btn btn-ghost" type="submit">پاک‌سازی</button></form>
  </div></div>
  <div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>ابزار</th><th>args</th><th>وضعیت</th><th>زمان</th><th></th></tr></thead><tbody>{batch_rows}</tbody></table></div>
</div>

{last_html}

<div class="grid grid-2 mb-lg">
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("file")} کد — دسترسی آزاد</h3>
    <form method="get" action="/agent/code" class="grid grid-2" style="align-items:end">
      <div class="field" style="margin:0"><label class="field-label">مسیر فایل</label><input class="input" name="f" dir="ltr" placeholder="server/db.py"></div>
      <button class="btn btn-glass" type="submit">{icon("search")}<span>خواندن</span></button>
    </form>
    <form method="get" action="/agent/code" class="mt-md">
      <div class="field"><label class="field-label">جستجو</label><div class="dir-row"><input class="input" name="q" placeholder="email_otp"><button class="btn btn-glass" type="submit">جستجو</button></div></div>
    </form>
  </div>
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("message")} چت زنده ایجنت — با سوئیچ هوش‌ها</h3>
    <div id="agent-chat-log" style="height:260px;overflow:auto;border:1px solid var(--color-border);border-radius:12px;padding:10px;background:var(--color-card)" class="mb-md text-sm"><div class="text-muted">پیام‌ها اینجا — مدل فعلی: <b id="log-model">auto</b> — نامحدود شخصی</div></div>
    <div class="dir-row"><input class="input" id="agent-chat-input" placeholder="مثلاً: ۵ کسب‌وکار نمونه بساز و سئو چک کن"><button class="btn btn-primary" id="agent-chat-send">ارسال</button></div>
    <p class="field-hint mt-sm">این چت به مغز مدیر (بله) وصله — با سوئیچ بالا بین auto/smart/fast/offline عوض کن — بدون خطا، تست شده.</p>
  </div>
</div>

<div class="card glass card-pad mb-lg">
  <h3 class="card-title mb-md">{icon("shield")} امنیت و حریم خصوصی</h3>
  <ul class="text-sm" style="line-height:1.9">
    <li>🔐 کلید فقط از ربات بله — ۳۲ بایت، هش SHA256، TTL ۱h، کوکی ۷d HttpOnly</li>
    <li>📧 ورود ایمیلی مثل Arena AI — OTP ۶ رقمی، ۵ دقیقه، throttling</li>
    <li>♾️ نامحدود شخصی — وقتی ایجنت فعاله سهمیه بی‌نهایت</li>
    <li>🌐 جدا از پنل مدیریتی — صفحه همه‌کاره `/agent` با تمام {fa(len(tools))} ابزار + کد + بکاپ + سئو</li>
    <li>🔄 سوئیچ هوش‌ها: auto/smart/fast/offline — بدون رفرش</li>
  </ul>
</div>

<script>
(function(){{
  var LS_KEY="bz-agent-model";
  var curModel=localStorage.getItem(LS_KEY)||"auto";
  function setModel(m){{
    curModel=m;
    localStorage.setItem(LS_KEY,m);
    document.querySelectorAll('#model-switcher [data-model]').forEach(function(b){{
      b.classList.toggle('is-active', b.getAttribute('data-model')===m);
    }});
    var el=document.getElementById('model-current'); if(el) el.textContent=m;
    var el2=document.getElementById('log-model'); if(el2) el2.textContent=m;
  }}
  setModel(curModel);
  document.querySelectorAll('#model-switcher [data-model]').forEach(function(b){{
    b.addEventListener('click',function(){{setModel(b.getAttribute('data-model'));}});
  }});
  document.querySelectorAll('[data-quick]').forEach(function(b){{
    b.addEventListener('click',function(){{
      try{{var o=JSON.parse(b.getAttribute('data-quick'));document.getElementById('ab-tool').value=o.tool;document.getElementById('ab-args').value=JSON.stringify(o.args,null,2);}}catch(e){{}}
    }});
  }});
  var log=document.getElementById('agent-chat-log');
  var input=document.getElementById('agent-chat-input');
  var send=document.getElementById('agent-chat-send');
  function addMsg(who,txt){{
    var d=document.createElement('div'); d.style.margin='6px 0';
    d.innerHTML='<b>'+who+':</b> '+txt.replace(/</g,'&lt;').replace(/\\n/g,'<br>');
    log.appendChild(d); log.scrollTop=log.scrollHeight;
  }}
  async function poll(){{
    try{{var r=await fetch('/api/agent/status',{{credentials:'same-origin'}}); var j=await r.json(); if(j.ok){{var e=document.querySelector('[data-agent-staged]'); if(e) e.textContent=j.staged;}} }}catch(e){{}}
  }}
  setInterval(poll,4000);
  async function sendChat(){{
    var t=input.value.trim(); if(!t) return;
    addMsg('شما',t); input.value='';
    addMsg('ایجنت','⏳ در حال فکر...');
    try{{
      var r=await fetch('/api/agent/chat',{{method:'POST',credentials:'same-origin',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{text:t,model:curModel}})}});
      var j=await r.json();
      // remove thinking
      if(log.lastChild) log.removeChild(log.lastChild);
      if(j.ok){{
        addMsg('ایجنت ('+ (j.model||curModel) +')', j.reply || j.text || '—');
        if(j.tool) addMsg('ابزار', j.tool.name+': '+JSON.stringify(j.tool.args));
      }}else{{
        addMsg('خطا', j.error || 'خطا');
      }}
    }}catch(e){{
      if(log.lastChild) log.removeChild(log.lastChild);
      addMsg('خطا','ارتباط برقرار نشد: '+e);
    }}
  }}
  send.addEventListener('click',sendChat);
  input.addEventListener('keydown',function(e){{if(e.key==='Enter') sendChat();}});
}})();
</script>
'''
    return public_page(s, "پنل ایجنت — همه‌کاره", content, active="/agent", extra_js="", extra_head="")

def agent_panel_page(s, token, q=None, agent_ok=False):
    """Keep panel version but upgraded with model switcher + fixed chat"""
    # reuse standalone but wrap in panel_page
    # we call standalone to get content then re-wrap
    # for simplicity, rebuild similar but with panel chrome
    pend_data, batches, staged, applied, last_action, has_rollback, health_msg, tools = _live_data()
    arena = _arena_status(s)
    try:
        ai_today = arena.get("stats",{}).get("today",{}).get("n",0)
    except Exception:
        ai_today = 0
    tool_opts = "".join(f'<option value="{esc(t)}">{esc(t)}</option>' for t in tools)
    try:
        keys = db.agent_key_list(limit=5)
        keys_html = "".join(f'<tr><td class="nums" dir="ltr" style="font-size:11px">{esc(k["token"][:16])}…</td><td class="nums">{esc(jdatetime_ts(k["created"]))}</td><td>{fa(max(0,int((k["expires"]-_t.time())//60)))} د</td><td>{"✅" if k["used"] else "⏳"}</td></tr>' for k in keys) or '<tr><td colspan="4" class="text-muted">—</td></tr>'
    except Exception:
        keys_html = '<tr><td colspan="4">—</td></tr>'
    pend_html = ""
    if pend_data and pend_data.get("action")=="agent_confirm":
        try:
            tgt = _js.loads(pend_data.get("target") or "{}")
            pend_html = f'''<div class="alert alert-warn"><b>در انتظار تایید بله:</b><br><pre style="white-space:pre-wrap;max-height:240px;overflow:auto" dir="ltr">{esc(_js.dumps(tgt, ensure_ascii=False, indent=2)[:2500])}</pre>
            <div class="cluster mt-sm"><form method="post" action="/panel/agent/confirm" style="display:inline"><button class="btn btn-primary btn-sm">✅ تایید</button></form>
            <form method="post" action="/panel/agent/cancel" style="display:inline"><button class="btn btn-glass btn-sm">❌ لغو</button></form></div></div>'''
        except Exception:
            pend_html = f'<div class="alert alert-warn">pending: {esc(str(pend_data)[:400])}</div>'
    batch_rows = ""
    for b in staged[-20:]:
        try:
            args = _js.loads(b["args"]) if b["args"] else {}
            args_s = _js.dumps(args, ensure_ascii=False)[:400]
        except Exception:
            args_s = (b["args"] or "")[:400]
        batch_rows += f'''<tr><td class="nums">#{b["id"]}</td><td><code>{esc(b["tool"])}</code></td><td class="text-xs"><pre style="white-space:pre-wrap">{esc(args_s)}</pre></td><td><span class="badge badge-warn">{esc(b["status"])}</span></td><td class="nums">{esc(jdatetime_ts(b["created"]))}</td><td><form method="post" action="/panel/agent/batch/remove" style="display:inline"><input type="hidden" name="id" value="{b["id"]}"><button class="btn btn-ghost btn-sm">✕</button></form></td></tr>'''
    if not batch_rows:
        batch_rows = '<tr><td colspan="6" class="text-center text-muted">صف خالی</td></tr>'
    last_html = ""
    if last_action:
        last_html = f'<div class="card glass card-pad mb-lg"><h3 class="card-title mb-md">{icon("activity")} آخرین اقدام</h3><pre style="max-height:220px;overflow:auto" dir="ltr">{esc(_js.dumps(last_action, ensure_ascii=False, indent=2)[:4000])}</pre></div>'
    agent_status = f'<span class="badge {"badge-open" if agent_ok else "badge-closed"}">{"✅ فعال — نامحدود شخصی" if agent_ok else "🔒 نیاز به کلید بله"}</span>'
    switcher = '''
<div class="cluster mb-md" id="model-switcher" style="gap:8px;flex-wrap:wrap">
  <span class="text-sm"><b>هوش:</b></span>
  <button class="chip is-active" data-model="auto">🤖 خودکار</button>
  <button class="chip" data-model="smart">🧠 قوی</button>
  <button class="chip" data-model="fast">⚡ سریع</button>
  <button class="chip" data-model="offline">📴 آفلاین</button>
  <span class="badge badge-open" id="model-current">auto</span>
</div>
'''
    content = f'''
{_msg(q or {})}
<div class="between mb-lg" style="flex-wrap:wrap;gap:12px">
  <div><h2 class="card-title">{icon("sparkles")} پنل ایجنت — دسترسی آزاد و کامل {agent_status}</h2>
  <p class="text-sm text-muted">نسخه پنلی — جدا هم در <a href="/agent">/agent</a> با ورود ایمیلی موجوده — با سوئیچ هوش‌ها و اتصال آرنا.</p></div>
  <div class="cluster">
    <a class="btn btn-glass btn-sm" href="/agent">{icon("external")}<span>/agent جدا</span></a>
    <a class="btn btn-glass btn-sm" href="/panel/assistant">{icon("settings")}<span>دستیار</span></a>
  </div>
</div>
{switcher}

<div class="card glass card-pad mb-lg" style="border:2px solid #4f46e5">
  <div class="between" style="flex-wrap:wrap;gap:12px">
    <div><h3 class="card-title">🌐 مرورگر خارجی + پل آرنا فعال ✅</h3>
    <p class="text-sm text-muted">باز کردن <code>https://arena.ai/agent/01a0acde-4c14-7c72-9934-1df78579ea49</code> و تبادل فایل — مدیریت در <code>/agent/browser</code></p></div>
    <div class="cluster">
      <a class="btn btn-primary" href="/agent/browser" target="_blank"><span>مرورگر خارجی</span></a>
      <a class="btn btn-glass" href="/agent/browser?url=https://arena.ai/agent/01a0acde-4c14-7c72-9934-1df78579ea49" target="_blank">آرنا</a>
    </div>
  </div>
</div>

<div class="grid grid-4 mb-lg">
  {stat_card("activity", len(staged), "صف")}
  {stat_card("check-circle", len(applied), "اعمال شده")}
  {stat_card("zap", ai_today, "پیام امروز")}
  {stat_card("shield", 1 if has_rollback else 0, "Rollback")}
</div>
{pend_html}
<div class="grid grid-2 mb-lg" style="align-items:start">
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("plus")} افزودن به صف</h3>
    <form method="post" action="/panel/agent/batch/add">
      <div class="field"><label class="field-label">ابزار</label><select class="select" id="ab-tool" name="tool" required>{tool_opts}</select></div>
      <div class="field"><label class="field-label">JSON args</label><textarea class="textarea" id="ab-args" name="args" style="min-height:110px;font-family:monospace;direction:ltr">{{}}</textarea></div>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>افزودن</span></button>
    </form>
    <hr class="divider">
    <h4 class="card-title mb-sm">{icon("zap")} اجرای فوری</h4>
    <form method="post" action="/panel/agent/exec">
      <div class="field"><label class="field-label">ابزار</label><select class="select" name="tool" required>{tool_opts}</select></div>
      <div class="field"><label class="field-label">JSON</label><textarea class="textarea" name="args" style="min-height:80px;font-family:monospace;direction:ltr">{{}}</textarea></div>
      <button class="btn btn-accent btn-block" type="submit">{icon("zap")}<span>اجرای فوری</span></button>
    </form>
  </div>
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("shield")} کلیدها + سلامت</h3>
    <div class="table-wrap"><table class="table"><thead><tr><th>کلید</th><th>ساخته</th><th>انقضا</th><th>وضعیت</th></tr></thead><tbody>{keys_html}</tbody></table></div>
    <pre style="max-height:180px;overflow:auto;white-space:pre-wrap" class="text-xs mt-md">{esc(health_msg[:2000])}</pre>
  </div>
</div>
<div class="card glass card-pad mb-lg">
  <div class="between mb-md"><h3 class="card-title">{icon("layers")} صف — {fa(len(staged))} آماده</h3>
  <div class="cluster">
    <form method="post" action="/panel/agent/batch/apply" data-confirm="اعمال همه؟"><button class="btn btn-primary" type="submit">⚡ اعمال همه</button></form>
    <form method="post" action="/panel/agent/batch/clear" data-confirm="پاک؟"><button class="btn btn-ghost" type="submit">پاک‌سازی</button></form>
  </div></div>
  <div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>ابزار</th><th>args</th><th>وضعیت</th><th>زمان</th><th></th></tr></thead><tbody>{batch_rows}</tbody></table></div>
</div>
{last_html}
<div class="grid grid-2 mb-lg">
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("file")} کد</h3>
    <form method="get" action="/panel/agent/code" class="grid grid-2" style="align-items:end">
      <div class="field" style="margin:0"><label class="field-label">فایل</label><input class="input" name="f" dir="ltr" placeholder="server/db.py"></div>
      <button class="btn btn-glass" type="submit">{icon("search")}<span>خواندن</span></button>
    </form>
    <form method="get" action="/panel/agent/code" class="mt-md">
      <div class="field"><label class="field-label">جستجو</label><div class="dir-row"><input class="input" name="q" placeholder="agent_key"><button class="btn btn-glass" type="submit">جستجو</button></div></div>
    </form>
  </div>
  <div class="card glass card-pad">
    <h3 class="card-title mb-md">{icon("message")} چت زنده — سوئیچ هوش‌ها</h3>
    <div id="agent-chat-log" style="height:240px;overflow:auto;border:1px solid var(--color-border);border-radius:12px;padding:10px;background:var(--color-card)" class="mb-md text-sm"><div class="text-muted">مدل: <b id="log-model">auto</b> — نامحدود</div></div>
    <div class="dir-row"><input class="input" id="agent-chat-input" placeholder="پیام..."><button class="btn btn-primary" id="agent-chat-send">ارسال</button></div>
  </div>
</div>
<script>
(function(){{
  var LS_KEY="bz-agent-model";
  var curModel=localStorage.getItem(LS_KEY)||"auto";
  function setModel(m){{
    curModel=m; localStorage.setItem(LS_KEY,m);
    document.querySelectorAll('#model-switcher [data-model]').forEach(function(b){{b.classList.toggle('is-active', b.getAttribute('data-model')===m);}});
    var el=document.getElementById('model-current'); if(el) el.textContent=m;
    var el2=document.getElementById('log-model'); if(el2) el2.textContent=m;
  }}
  setModel(curModel);
  document.querySelectorAll('#model-switcher [data-model]').forEach(function(b){{b.addEventListener('click',function(){{setModel(b.getAttribute('data-model'));}});}});
  var log=document.getElementById('agent-chat-log');
  var input=document.getElementById('agent-chat-input');
  var send=document.getElementById('agent-chat-send');
  function addMsg(who,txt){{
    var d=document.createElement('div'); d.style.margin='6px 0';
    d.innerHTML='<b>'+who+':</b> '+txt.replace(/</g,'&lt;').replace(/\\n/g,'<br>');
    log.appendChild(d); log.scrollTop=log.scrollHeight;
  }}
  async function sendChat(){{
    var t=input.value.trim(); if(!t) return;
    addMsg('شما',t); input.value='';
    addMsg('ایجنت','⏳...');
    try{{
      var r=await fetch('/api/agent/chat',{{method:'POST',credentials:'same-origin',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{text:t,model:curModel}})}});
      var j=await r.json();
      if(log.lastChild) log.removeChild(log.lastChild);
      if(j.ok){{addMsg('ایجنت ('+(j.model||curModel)+')', j.reply||j.text||'—'); if(j.tool) addMsg('ابزار', j.tool.name+': '+JSON.stringify(j.tool.args));}}else{{addMsg('خطا', j.error||'خطا');}}
    }}catch(e){{if(log.lastChild) log.removeChild(log.lastChild); addMsg('خطا','ارتباط: '+e);}}
  }}
  send.addEventListener('click',sendChat);
  input.addEventListener('keydown',function(e){{if(e.key==='Enter') sendChat();}});
}})();
</script>
'''
    return panel_page(s, "پنل ایجنت — دسترسی آزاد", "زنده، خصوصی، دسته‌ای، نامحدود — کلید فقط از ربات بله.", content, "/panel/agent", token)
